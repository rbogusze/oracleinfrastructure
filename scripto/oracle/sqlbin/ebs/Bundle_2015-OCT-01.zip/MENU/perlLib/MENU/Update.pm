# $Id: Update.pm 200.1 2015/10/01 kjharris $
# +===========================================================================+
# |  Copyright (c) 2014 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# |
# | FILENAME: Update.pm
# |
# | Container for subs to do analyzer bundle updates 
# | 
# | PLATFORM
# |   Unix Generic
# |
# | NOTES
# |
# | HISTORY
# | 200.0 Creation (Nov-11-2014) 
# | 200.1 Creation (Unzip Fixes, creation of the archive directory) 
# | -- all unzipped files (successful) are moved to update/archive/ 
# +===========================================================================+

use Cwd; 

# +---------------------------
# | Sub updateMenu
# +---------------------------
# | the menu displayed after the user chooses "updates" from the main menu. 
# |
# +---------------------------
sub updateMenu
{
	my $userSel; 
	until (2 == 1) 
	{
		my $countDepth = $dir =~ tr/\///;
		system("clear"); 
		print "\n\n               ", RESET; 
		print BOLD WHITE ON_BLUE "Analyzer Bundle Updates Menu", RESET, "\n\n"; 
	
		print "   [1] Begin Update\n"; 
		
		print "   ...\n"; 
		print BOLD WHITE ON_BLUE "\n   [B]ack | [H]elp | E[x]it\n"; 
		print BOLD WHITE ON_YELLOW "\n Invalid Selection", RESET if $userSel eq 'invalid'; 
		print "\n   Selection:"; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i;
		
		if ($userSel =~ /^b{1}/i)
		{
			return(); 
		}
		elsif ($userSel == 1)
		{
			#autoUpdate(); 
			beginUpdate(); 
		}
		# elsif	($userSel == 2)
		# {
			# manualUpdate(); 
		# }
		elsif ($userSel =~ /^h{1}/i)
		{ 
				system ("clear"); 
				print "\n"; 
				print BOLD WHITE ON_BLUE "   Updates Menu Help", RESET, "\n"; 
				print qq (
 o [1] Begin Update 
 
   Starts the update process by looking at the MENU/update/ directory for 
   valid bundle zip files. If there is a bundle zip file in that directory 
   which has a higher version than the current version, the user is prompted
   to use that version or check My Oracle Support for a newer version. Once 
   a bundle zip has been established, it is unzipped into MENU/ and a restart
   of Menu.pl is required. Once the restart is completed, a list is provided 
   pick which Analyzers are reinstalled. 
 

  Press [Enter] to continue:); 
my $z=<STDIN>;
		
		}
		else
		{
			$userSel = 'invalid'; 
		}
	} #end until loop 

}

# +---------------------------+
# | sub: beginUpdate 
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub beginUpdate 
{
	my ($mode) = (@_);
	# --> check for updated bundle.zip in update dir 
	my ($latestZipFile, $latestZipVer) = getHighVersionBundle(); 
	my $currVer = getBundleVer(); 
	prnt2Log("INFO: running beginUpdate()");
	if ($mode eq 'R')
	{
		my $status; 
		unlink ('.update');
		prnt2Log "\n\n   INFO: Resuming Update. \n"; 
		print "\n\n   INFO: Resuming Update. Press [Enter]: "; 
		<STDIN>; 
		$status = pickListMenu(); 
		if ($status == 0) 
		{
			prnt2LogSTDOUT "\n\n   INFO: Update successful \n"; 
			return(0); 
		}
		else 
		{
			prnt2LogSTDOUT "\n\n   ERROR: Update failed. \n"; 
			return(1); 
		}
	}
	
	
	my $userSel;
	# if the updated bundle.zip is newer, use it or prompt to check for new? 
	if (defined $latestZipFile)
	{
		system("clear"); 
		until ($userSel =~ /^u{1}$/i || $userSel =~ /^d{1}$/i || $userSel =~ /^b{1}$/i)
		{
			print "   INFO: Found file: $latestZipFile, version: \'$latestZipVer\' \n";
			print "   INFO: You are currently using bundle version: \'$currVer\' \n"; 
			print "   WARNING: The current Bundle is newer or equal to $latestZipFile\n\n   Updating is NOT recommended.\n\n" if $currVer >= $latestZipVer; 
			print "   INFO: The current Bundle is lower than $latestZipFile\n\n   Updating is recommended.\n\n" if $currVer < $latestZipVer; 
			print "\n   Use this bundle or attempt to download* a newer one?\n    [*requires My Oracle Support connectivity]\n\n";
			print BOLD WHITE ON_BLUE "   [U]se | [B]ack | [D]ownload",RESET ;
			print BOLD WHITE ON_YELLOW "  Invalid Selection", RESET if defined $userSel; 
			print "\n\n   Selection:"; 
			chomp($userSel = <STDIN>); 
			system("clear");
		}
	}
	else #didn't get a zip version 
	{
		until ($userSel =~ /^u{1}$/i || $userSel =~ /^d{1}$/i || $userSel =~ /^b{1}$/i)
		{
			system("clear"); 
			print "\n\n   INFO: No valid Bundle zip file was found in \'MENU/update\' \n   [D]ownload from Doc ID: 1939637.1?\n\n"   ; 
			print BOLD WHITE ON_BLUE "   [D]ownload   [B]ack  ",RESET ;
			print BOLD WHITE ON_YELLOW "  Invalid Selection", RESET if defined $userSel;  
			print "\n\n   Selection:"; 
			chomp($userSel = <STDIN>);
			system("clear"); 
		} 
	}
	
	if ($userSel =~ /^d{1}/i)
	{
		#download 
		my $status = getBundleUpdate(); 
		if ($status == 0) 
		{
			my ($zip) = getHighVersionBundle(); 
			my $status = unzipBundle($zip); #the file name when automatically downloaded will always be bundle.zip  
			if ($status == 0) 
			{
				_reboot(); 
			}
			else
			{
				print "\n\n   ERROR: Unzip failed, cannot continue.\nPress [Enter]:"; 
				<STDIN>; 
				return(); 
			}
		}
		else 
		{
			print "\n\n   ERROR: Failed to download new Bundle. \n   Download the bundle manually from Doc ID: 1939637.1\n   and place the zip into the MENU/update directory. \n   Then retry the update process selecting the [U]se option when prompted.  \n\n   Press [Enter] to continue:"; 
			<STDIN>;
			return(); 
		}
		
	}
	elsif ($userSel =~ /^b{1}/i)
	{
		return(); 
	}
	
	elsif ($userSel =~ /^u{1}/i)
	{
		#use the existing MENU/update/bundle.zip 
		#unzip $latestZipFile 
		prnt2LogSTDOUT("INFO: Unzipping new Bundle.."); 
		my $status = unzipBundle($latestZipFile); 
		if ($status == 0) 
		{
			_reboot(); 
		}
		else
		{
			print "\n\n   ERROR: Unzip failed, cannot continue.\nPress [Enter]:";
			<STDIN>;
			return(); 
		}
		
	}
	
	
	# -----> if the in-place bundle.zip isn't avail or old, then attempt a download 
	# -------> If the download fails, prompt them to download manually and put it in the update dir 
	# ---> Unzip 
	# --> Run pick list 
	# --> 
	#private sub 
	sub _reboot
	{
		# reboot 
		open (my $fh, '>', '.update' ) || die "beginUpdate(): Cannot create .update: $! \n"; 
		close $fh; 
		print "\n\n   INFO: Next task: Reinstall Concurrent Programs\n   A menu will be displayed upon restart\n\n   Menu.pl needs to be restarted using \'perl Menu.pl\' \n   The update process will resume after the restart. \n\n";
		exit;
	}
}


# +---------------------------
# | Sub pickListMenu 
# +--------------------------- 
# | displays the list of installed analyzers  
# |
# +---------------------------
sub pickListMenu
{
my ($mode) = @_; 
#CCPs is hash: 
my $analyzers = getInstalledCCPs();
#add in New analyzers 
getNewAnalyzers(\%$analyzers) if $mode ne 'show'; 
my $userSel; 
my $invSel = 0;
my $change; 

	if ($analyzers == 1)
		{
			#no analyzers found 
			system("clear"); 
			print BOLD WHITE ON_BLUE "\n\n   No Analyzer Concurrent Programs Installed", RESET, "\n   Press [Enter] to Continue:";
			<STDIN>; 
			return(); 
		}
	
	foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
	{
			#Add MFG/CRM/FIN/ATG/HCM to front of title 
		if ($$analyzers{$ID}->{'FILE'} =~ /01_E-Business_Suite_Core_Analyzers/)
		{
			$$analyzers{$ID}->{'CCPTITLE'} = 'ATG: ' . $$analyzers{$ID}->{'CCPTITLE'}; 
		}
		elsif($$analyzers{$ID}->{'FILE'} =~ /02_Financials_Analyzers/)
		{
			$$analyzers{$ID}->{'CCPTITLE'} = 'FIN: ' . $$analyzers{$ID}->{'CCPTITLE'};
		}
		elsif($$analyzers{$ID}->{'FILE'} =~ /03_Manufacturing_Analyzers/)
		{
			$$analyzers{$ID}->{'CCPTITLE'} = 'MFG: ' . $$analyzers{$ID}->{'CCPTITLE'};
		}
		elsif($$analyzers{$ID}->{'FILE'} =~ /04_Human_Capital_Management_Analyzers/)
		{
			$$analyzers{$ID}->{'CCPTITLE'} = 'HCM: ' . $$analyzers{$ID}->{'CCPTITLE'};
		}
		elsif($$analyzers{$ID}->{'FILE'} =~ /05_Customer_Relationship_Management_Analyzers/)
		{
			$$analyzers{$ID}->{'CCPTITLE'} = 'CRM: ' . $$analyzers{$ID}->{'CCPTITLE'};
		}
				
		#if either of the versions could not be detected, default to reload 
		if ($$analyzers{$ID}->{'CURRFILEVER'} =~ /null|new/ || $$analyzers{$ID}->{'NEWFILEVER'} eq '<null>')
		{
			$$analyzers{$ID}->{'SELECTED'} = '+';
		}
		else
		{
			my ($status, $action) = compVersions($$analyzers{$ID}->{'NEWFILEVER'}, $$analyzers{$ID}->{'CURRFILEVER'}); 
			#action will be replace, same or existing_higher 
			#status of 1 means version check could not be performed 
			if ($status == 0 && $action eq 'replace')
			{
				$$analyzers{$ID}->{'SELECTED'} = '+';
			}
			else
			{
				$$analyzers{$ID}->{'SELECTED'} = ' ';
			}
		}
	}
	#print Dumper(%$analyzers); 

if ($mode ne 'show')
{
#loop forever. Other exit mechanisms are in place. (keeps the menu alive until user specifies)
my $newCount = 0; 
until (1 == 2) 
	{
		my ($spc1, $spc2, $verLgth); 
		system("clear"); 
		$| = 1;
		
		foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
		{	
			$newCount++ if $$analyzers{$ID}->{'CURRFILEVER'} =~ /NONE/; 
		
			if ($ID == 1 && $$analyzers{$ID}->{'CURRFILEVER'} =~ /^\d/) 
			{
				print BOLD WHITE ON_GREEN "\n Legend: [+] = Selected To be Reinstalled";
			}
			print BOLD WHITE ON_BLUE "\n  \#  SELECTED  TITLE                                  INSTALLED | NEW", RESET, "\n" if $ID == 1; 
			print BOLD WHITE ON_GREEN "\n Legend: [+] = Selected To be Installed (New Analyzers)" if $newCount == 1;
			print BOLD WHITE ON_BLUE "\n  \#  SELECTED  TITLE                                  INSTALLED | NEW", RESET, "\n" if $newCount == 1;
			$spc1 = "  " if $ID > 9;
			$spc1 = "   " if $ID <= 9;
			my $title = $$analyzers{$ID}->{'CCPTITLE'}; 
			if (length $title > 38) 
				{ $title = substr($title, 0, 36); $title .= "..."; } 
			my $tabs; 
			my $length=((length($$analyzers{$ID}->{'CCPTITLE'}) + length("[$ID]"))); 
			$tabs = "\t\t\t\t" if $length > 12 && $length <= 18; 
			$tabs = "\t\t\t" if $length >= 19 && $length <= 28; 
			$tabs = "\t\t" if $length >= 28 && $length <= 34; 
			# $tabs = "\t" if $length > 22 && $length <= 23; 
			$tabs = "\t" if $length >= 35;   
			$verLgth = length($$analyzers{$ID}->{'CURRFILEVER'}); 
			$spc2 = "   | " if $verLgth == 5;
			$spc2 = "  | " if $verLgth == 6;
			$spc2 = " | " if $verLgth == 7;

			#print "$length\n"; 
			print " [$ID]", $spc1, "[$$analyzers{$ID}->{'SELECTED'}]","     $title ",$tabs,"$$analyzers{$ID}->{'CURRFILEVER'}",$spc2,"$$analyzers{$ID}->{'NEWFILEVER'}	\n"; 
		}
		
		print BOLD WHITE ON_BLUE "\n   [L]oad | [B]ack | [H]elp | E[x]it", RESET; 
		print BOLD WHITE ON_YELLOW "\n Invalid Selection", RESET if $invSel != 0; 
		print "   \n   ...\n   Toggle Selections by Number\n";
		print "   Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 

	if (defined $$analyzers{$userSel}) 
	{
		if ($$analyzers{$userSel}->{'SELECTED'} =~ /\+/) {$$analyzers{$userSel}->{'SELECTED'} = ' ';}
		else {$$analyzers{$userSel}->{'SELECTED'} = '+';}
	}
	elsif ( $userSel =~ /^b$/i )
		{return;}
	elsif ($userSel =~ /^l$/i)
	{
		system("clear"); 
		print qq(\n\n   Reload the selected "[+]" Analyzers?\n   [Y|N]:); 
		my $cont;
		until ($cont =~ /^y|^n/i)
		{
			chomp($cont = <STDIN>);
		}
		if ( $cont =~ /^y/i )
		{
			my @arrayOfSelected;
			#load an array to pass to floadbulk that contains all the selected analyzers 
			foreach my $ID (keys %$analyzers)
			{
				push (@arrayOfSelected, $$analyzers{$ID}->{'FILE'}) if $$analyzers{$ID}->{'SELECTED'} eq '+' ; 
			}
			#foreach (@arrayOfSelected) {print "debug106: $_ \n";}
			floadBulkUpdates(\@arrayOfSelected) if scalar @arrayOfSelected > 0;
			return; 
		}
	}
	elsif ($userSel =~ /^h$/i) 
	{
			system("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "   Reinstall Existing & New Analyzers as Concurrent Programs Help", RESET, "\n"; 
			print qq (
 o This menu lists and loads analyzers detected as previously installed in the 
   database as concurrent programs, as well as brand new Analyzers
 o Analyzers marked with a "+" will be loaded
 o All new analyzers as well as updated analyzers are marked to 
   be reinstalled by default
 o Selecting "Load" [L] will reinstall the Analyzer's package file (if required)
   and reload the analyzers LDT Program Definition file
 o Loading Analyzers from this menu *only loads the Concurrent Program LDT*, not the 
   Request Group LDT
 o Toggle which analyzers are loaded by selecting the associated number 

Press [Enter] to continue:); 
			my $w = <STDIN>;
	}
	elsif ($userSel =~ /^x$/i)
	{
		exitLog(); 
	} 
	else
	{
		$invSel = 1; 
		#repeat the menu again 
		#need to write a loop around the line 146 foreach menu to redisplay it 
	}
	$newCount = 0; 
	}#end until (1 == 2)
	
}#end if mode ne show
elsif ($mode eq 'show') 
{

	# use Data::Dumper; 
	# print Dumper(%$analyzers);<STDIN>;  
	#loop forever. Other exit mechanisms are in place. (keeps the menu alive until user specifies)
until (1 == 2) 
	{
		my ($spc1, $spc2, $verLgth); 
		system("clear"); 
		print "\n            "; 
		print BOLD WHITE ON_BLUE "Installed Concurrent Programs", RESET; 
		print BOLD WHITE ON_BLUE "\n  \#    TITLE                                    VERSION", RESET; 
		print "\n"; 
		
		$| = 1;
		foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
		{
			$spc1 = "  " if $ID > 9; 
			$spc1 = "   " if $ID <= 9; 
			my $title = $$analyzers{$ID}->{'CCPTITLE'}; 
			if (length $title > 38) 
				{ $title = substr($title, 0, 36); $title .= "..."; } 
			my $tabs; 
			my $length=((length($$analyzers{$ID}->{'CCPTITLE'}) + length("[$ID]"))); 
			$tabs = "\t\t\t\t" if $length > 12 && $length <= 18; 
			$tabs = "\t\t\t" if $length >= 19 && $length <= 28; 
			$tabs = "\t\t" if $length >= 28 && $length <= 34; 
			# $tabs = "\t" if $length > 22 && $length <= 23; 
			$tabs = "\t" if $length >= 35;  
			$verLgth = length($$analyzers{$ID}->{'CURRFILEVER'}); 
			$spc2 = "   | " if $verLgth == 5;
			$spc2 = "  | " if $verLgth == 6;
			$spc2 = " | " if $verLgth == 7;

			#print "$length\n"; 
			print " [$ID]", $spc1,"$title ",$tabs,"$$analyzers{$ID}->{'CURRFILEVER'}\n"; 
		}
		print BOLD WHITE ON_BLUE "\n   [B]ack | [H]elp | E[x]it", RESET; 
		print BOLD WHITE ON_YELLOW "\n Invalid Selection", RESET if $invSel != 0; 
		print "\n   Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 

	if ( $userSel =~ /^b$/i )
		{return;}
	elsif ($userSel =~ /^h$/i) 
	{
			system("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "   Concurrent Program Installed List Help", RESET, "\n"; 
			print qq (
 o This lists analyzers detected as installed in the 
   database as concurrent programs.
 o Note that the version listed is the version of the code which is executed 
   as the analyzer is called by the Concurrent Managers. This may not be 
   the same as the SQL version of analyzers which use a SQL \"wrapper\" to 
   call their corresponding stored PLSQL packages. 
 o <null> version indicates the version could not be determined 

Press [Enter] to continue:); 
			my $w = <STDIN>;
	}
	elsif ($userSel =~ /^x$/i)
	{
		exitLog();
	}
	else
	{
		$invSel = 1; 
		#repeat the menu again 
		#need to write a loop around the line 146 foreach menu to redisplay it 
	}


	}#end until (1 == 2)  
}#end mode eq show 

 
} #end pickListMenu

# +---------------------------
# | Sub getBundleUpdate
# +--------------------------- 
# | uses wget.sh to download the bundle.zip from DocID: 1939637.1:BUNDLE 
# |
# +---------------------------
sub getBundleUpdate
{
	system("clear"); 
	my $status; 
	#check for wget 
	`which wget >& /dev/null`;
	$status = $?; 
	print "   \n\nERROR: wget executable is required, but not found in the \$PATH \n" if $status > 0; 
	
	#check for unzip 
	`which unzip >& /dev/null`; 
	$status += $?; 
	print "   \n\nERROR: unzip executable is required, but not found in the \$PATH \n" if $status > 0; 
	
	if ($status > 0)
	{
		print "   \n\nERROR: wget and unzip are required in the \$PATH in order \n    to run this update option. \n   Ensure those utilities are available in the UNIX \$PATH environment variable\n    and retry. \n"; 
		print "   \n\nPATH: $ENV{PATH}"; 
	}
	elsif ($status == 0) 
	{
		my $baseURL = hostdomain;
		$baseURL =~ /\.oracle\.com^/ ? $baseURL = 'support.oracle.com' :  $baseURL = 'mosemp.us.oracle.com';
		chmod 0755, "update/wget.sh"; 
		$status = system("update/wget.sh $baseURL"); 
	}
	#Download the bundle to <base>/updates 

	return($status); 
}	#end getBundleUpdate

# +---------------------------+
# | sub:  getHighVersionBundle
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: n/a 
# +---------------------------+
# | Returns: the zip file from MENU/update dir 
# | that has the highest version 
# | 
# +---------------------------+

sub getHighVersionBundle
{
	my @zips; 
	find( sub {return unless /.+?\.zip$/i; push @zips, $File::Find::name;}, "update/" );
	
	my $version = 0; 
	my $highVer = 0;  
	my $highVerFile;  
	foreach (@zips) 
	{
		#print "version is: $version \n\n"; 
		my $file = $_ ; 
		my @unzip = `unzip -z $_`; 
		($version) = grep(/version/i, @unzip);
		$version = $+ if $version =~ /(\d*\.\d*)/;
		#print "file: $file version: $version\n"; 
		
		if ($version > $highVer)
		{
			$highVer = $version; 
			$highVerFile = $file; 
		}
	}
	$highVer = trim($highVer); 
	return ($highVerFile, $highVer); 
}


	
# +---------------------------
# | Sub manualUpdate
# +---------------------------
# |
# | 
# +---------------------------	
sub manualUpdate
{
my ($currVer, $ver); 
my $userSel = 0; 

sub _rebootManual
	{
		#reboot 
		open (my $fh, '>', '.updateManual' ) || die "manualUpdate(): Cannot create .updateManual: $! \n"; 
		close $fh; 
		print "\n\n   The Perl menu needs to be restarted using \'perl Menu.pl\' \n   The update process will resume after the restart. \n   Press [Enter]: "; 
		<STDIN>; 
		exit; 
	}

	if (-f '.updateManual') 
	{
		print "   INFO: Bundle unzipped successfully. Resuming Update. \n   Press [Enter]: "; 
		<STDIN>;
	
		unlink ('.updateManual');
		pickListMenu();
	}
	 
	

until (1 == 2) 
	{
			system("clear");
			print BOLD WHITE ON_BLUE "\n   Manual Download & Update",RESET ; 
			print "\n\n"; 
			#print "   [1] Check bundle.zip version\n"; 
			#print "   [2] Download new bundle.zip\n"; 
			print "   [1] Unzip update/bundle.zip\n"; 
			print "   [2] Reinstall Concurrent Programs\n"; 
			print "\n   ...\n"; 
			print BOLD WHITE ON_BLUE "   [B]ack | [H]elp | E[x]it",RESET ; 
			print BOLD WHITE ON_YELLOW "   Invalid Selection",RESET if $userSel eq 'invalid'; 
			print "\n\n   Selection:"; 
			chomp($userSel=<STDIN>); 

	if ($userSel =~ /^1{1}$/i)
	{
		system("clear"); 
		print "\n\n   INFO: Please ensure that you have downloaded bundle.zip from \n   Doc ID: 1939637.1, named it \'bundle.zip\' and placed it into the\n   \'MENU/update\' directory.\n\n    Press [Enter] to continue: "; 
		<STDIN>; 
		unzipBundle(); 
		_rebootManual(); 
	}
	elsif ($userSel =~ /^2{1}$/i)
	{
		pickListMenu(); 
	}
	elsif ($userSel =~ /^h{1}$/i)
	{
			system ("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "   Manual Download & Update Menu Help", RESET, "\n"; 
			print qq(
 
 o [1] Unzip "update/bundle.zip"
   Unzips the bundle.zip into the base, "MENU" directory. 
   
 o [2] Reinstall Concurrent Programs
    Provides a picklist menu where the user can see which analyzers were 
    previously installed as Concurrent Programs and can choose which ones 
    to reinstall. Reinstalling after an update ensures any new parameters
    are in sync and new features can be used by the Concurrent Program users. 
  
   
     Press [Enter] to continue:); 
			my $w = <STDIN>; 
	}
	elsif ($userSel =~ /^b{1}$/i)
	{
		return(); 
	}
	elsif ($userSel =~ /^x{1}$/i)
	{
		exitLog(); 
	}		
	else 
	{
		$userSel='invalid'; 
	}
		
		
	}#end until loop 
}#end manualUpdate 

# +---------------------------
# | sub getBundleVer 
# +---------------------------
# | 
# | 
# | 
# +---------------------------
sub getBundleVer
	{
		my $line; 
		open (my $fh, '<', 'Menu.pl' ) || die "getBundleVer(): Cannot open Menu.pl: $! \n"; 
		for (0 .. 2) 
			{
				$line = <$fh>; 
				last if $line =~ /\$Id:/; 
			}
		close $fh; 
		my @ar = split(' ', $line); 
		$ver = $ar[3]; 
		$ver = trim($ver); 
		return ($ver); 
	}
	
# +---------------------------
# | Sub getInstalledCCPs
# +---------------------------
# |#Gets the list of installed analyzers 
# | Returns a hash of Key: CCP Short Name Value: Analyzer File (full path) 
# +---------------------------
sub getInstalledCCPs 
{
	my $cs = $main::connStrg->getConnStrg(); 
	my $progName; 
	my $relVer = getRelVer();
	#build the "IN ('','','') arg and SQL command by grabbing the "PROG_NAME: <name>" line off the header of all valid analyzers.  
	my %analyzers;
	my %instAnalyzers; 
	
	#find all analyzer files 
	my @files; 
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @files, $File::Find::name if (($progName) = grep (/ANALYZER_BUNDLE_START/, @file)); }, 'analyzers/SQL' ); 
	
	foreach (@files) 
	{
		my $currFile = $_;
		#check if the file is compat 
		my ($compat, $valid) = checkCompat($currFile,$relVer);
		if ($valid == 1) 
		{
			my $analyzer = analyzer MENU::Analyzer($currFile);
			my $CCP = $analyzer->getCCPName(); 
			$analyzers{$CCP}=$currFile if length($CCP) && length($currFile); 
		}
	}


	#analyzers hash built: Key: CCP name, value: relative path from MENU dir to
	#	file, ex: analyzers/SQL/03_Manufacturing_Analyzers/Procurement/analyze_all.sql 

	my $in = qq(\(\');
	my $i = 0; 
	for my $key (keys %analyzers)
	{
		$i++; 
		$in .= $key . "\'," if $i == 1;
		$in .= "\'" . $key . "\'," if $i > 1;
	} 
	$in =~ s/,$//; 
	$in .= qq(\)\;);
	

	unlink('sql/run.sql') if -f 'sql/run.sql';
	unlink('sql/installed_ccps.lst') if -f 'sql/installed_ccps.lst'; 

my @sql = qq(
set serveroutput on
set term off 
set verify off 
set head off
spool "sql/installed_ccps.lst" 

select 'title:' || cp.user_concurrent_program_name, 'name:' || cp.concurrent_program_name, 
'exe:' || decode(cp.execution_method_code,'I', upper(substr(fe.EXECUTION_FILE_NAME,0,instr(fe.EXECUTION_FILE_NAME,'.')-1)), 'Q', '\$'||fa.basepath||'/sql/'||fe.EXECUTION_FILE_NAME||'.sql', cp.execution_method_code)
from FND_EXECUTABLES fe, FND_EXECUTABLES_TL fet, fnd_concurrent_programs_vl cp, fnd_application fa
where fe.EXECUTABLE_ID = fet.EXECUTABLE_ID
and cp.executable_id =  fe.executable_id
and fe.application_id =  Fa.Application_Id
and cp.concurrent_program_name in 
$in
spool off;
exit); 
# my @sql = qq(
# set serveroutput on
# set term off 
# set verify off 
# set head off
# spool "sql/installed_ccps.lst"

# select 'title:' || cp.user_concurrent_program_name, 'name:' || cp.concurrent_program_name, 
# 'exe:' || decode(cp.execution_method_code,'I', upper(substr(fe.EXECUTION_FILE_NAME,0,instr(fe.EXECUTION_FILE_NAME,'.')-1)), 'Q', '\$'||fa.basepath||'/sql/'||fe.EXECUTION_FILE_NAME||'.sql', cp.execution_method_code)
# from FND_EXECUTABLES fe, fnd_concurrent_programs_vl cp, fnd_application fa
# and cp.executable_id =  fe.executable_id
# and fe.application_id =  Fa.Application_Id
# and cp.concurrent_program_name in 
# $in
# spool off;
# exit);

	open (my $fh, '>', 'sql/run.sql' ) || die "Cannot open sql/run.sql: $! \n"; 
	print $fh @sql;
	close $fh;
	my $status = system("sqlplus -l -s $cs \@sql\/run.sql"); 
	# check_installed_ccps.lst
	print "   INFO: getInstalledCCPs: SQLPLUS exited with status: $status \n"; 
	
	open (my $fh, '<', 'sql/installed_ccps.lst' ) || die "Cannot open sql/installed_ccps.lst: $! \n"; 
	
	my @ccps; 
	while (my $line = <$fh>)
	{
		push @ccps, $line if length($line) > 3; 
	}
	close $fh; 
	
	if (! grep /title:/, @ccps) 
		{
			#print "   INFO: getInstalledCCPs did not find any Analyzer Concurrent Programs \n"; 
			return(1);  
		}
	
	#@ccps is the list of installed CCPs(concurrent progs) returned from the above DB query 
	
	#loop through the @ccps array, which is the spool file.. contents are such: 
	
	# title:AP Data Validation Report
	# name:APGDFVAL
	# exe:AP_GDF_DETECT_PKG
	my $id = 0; 
	for (my $i=0; $i < $#ccps; $i++)
		{
			my $line = $ccps[$i]; 
			chomp($line); 
			if ($line =~ /^title:/) 
			{
				$id++; 
				until ($line =~ /^exe:/)
				{
					$i++ if length($line) < 3; 
					$instAnalyzers{$id}->{'ID'} = $id;
					$instAnalyzers{$id}->{'CCPTITLE'} = $+ if $line =~ /^title:(.+)/;
					#trim trailing spaces / returns: 
					$instAnalyzers{$id}->{'CCPTITLE'} =~ s/\s+$//;
					
					my $ccpName = $+ if $line =~ /^name:(\w+)/;
					if ($ccpName)
					{
						$instAnalyzers{$id}->{'CCP'} = $ccpName;
						$instAnalyzers{$id}->{'FILE'} = $analyzers{$ccpName};
					}
					
					$i++; 
					$line = $ccps[$i];
					chomp($line); 
				}
				$instAnalyzers{$id}->{'EXECUTABLE'} = $+ if $line =~ /^exe:(\$*.+)/;
				$instAnalyzers{$id}->{'EXECUTABLE'} =~ s/\s+$//;
				
				#get versions if file 
				if ($instAnalyzers{$id}->{'EXECUTABLE'} =~ /^\$/)
				{
					#file version checks 
					
					#convert "$PAY_TOP/sql/retropay_analyzer.sql" to full path 
					my $fullPath = $+ if $instAnalyzers{$id}->{'EXECUTABLE'} =~ /\$(\w+_TOP)\//; 
					$fullPath = $ENV{$fullPath} . '/sql/' . basename($instAnalyzers{$id}->{'EXECUTABLE'});
		
					#my $file = ENV{} . 
					my $ver = getFileVer($fullPath);
					if ($ver == 1) 
					{
						$instAnalyzers{$id}->{'CURRFILEVER'} ='<null>';
					}
					elsif ($ver == 2) 
					{
						$instAnalyzers{$id}->{'CURRFILEVER'} = 'NO_FILE'; 
					}
					else 
					{
						#got ver 
						$instAnalyzers{$id}->{'CURRFILEVER'} =$ver;
					}
				}
				else
				{
					my ($status, $ver) = getDBPkgVer($instAnalyzers{$id}->{'EXECUTABLE'});
					if ($status == 0)
					{
						#got ver 
						$instAnalyzers{$id}->{'CURRFILEVER'} = $ver;
					}
					elsif ($status == 2) 
					{
						#package does not exist 
						$instAnalyzers{$id}->{'CURRFILEVER'} ='NO_PACKAGE';
						# use Data::Dumper; 
						# print Dumper(%instAnalyzers); 
						# <STDIN>; 
					}
					else
					{
						$instAnalyzers{$id}->{'CURRFILEVER'} ='<null>';
					}
				}
			} # END if ($line =~ /^title:/)  
		}

	for my $id (keys %instAnalyzers)
	{
		if (-e $instAnalyzers{$id}->{'FILE'})
		{
			#We need the version of the deps getDeps() 
			my $analyzer = analyzer MENU::Analyzer($instAnalyzers{$id}->{'FILE'});
			my $depFile = $analyzer->getDeps(); 
			my $ver; 
			if ($#$depFile == 0) 
			{
				foreach (@$depFile) 
				{
					$ver = getFileVer($_); 
				}
			}
			else 
			{
				$ver = getFileVer($instAnalyzers{$id}->{'FILE'}); 
			}
			
			if ($ver == 1) 
			{
				$instAnalyzers{$id}->{'NEWFILEVER'} ='<null>'; 
			}
			else 
			{
				#got ver 
				$instAnalyzers{$id}->{'NEWFILEVER'} =$ver; 
			}
		}
		else
		{
			$instAnalyzers{$id}->{'FILE'} = 'NO_FILE'; 
		}
	}

	# open (my $fh, '>', '/tmp/dump.txt' ) || die "Cannot open  $! \n"; 
	# use Data::Dumper; 
	# print $fh Dumper(%instAnalyzers); exit; 
	# close $fh; 
	
	unlink('sql/installed_ccps.lst') if -e 'sql/installed_ccps.lst'; 
	unlink('sql/run.sql') if -e 'sql/run.sql';
	return (\%instAnalyzers); 
	}

# +---------------------------
# | Sub unzipBundle() 
# +---------------------------
# |
# | 01-OCT-2015: 
# | Create archive dir if it doesn't exist 
# | move all zips into the archive dir 
# +---------------------------
sub unzipBundle
{
	my ($file) = @_; 
	my $status; 
	my $unzip=`which unzip`; 
	#check for unzip 
	my @ar = `unzip -v`; 
	prnt2Log("\nINFO: Running unzipBundle\n\n"); 
	
	if (grep (/Info-ZIP/, @ar)) 
	{
		prnt2LogSTDOUT("   INFO: Found unzip in the \$PATH\n"); 
	}
	else
	{
		prnt2LogSTDOUT("   ERROR: No unzip in the \$PATH. \n   Add \'unzip\' to your \$PATH and try again. \n");
		my $w; 
		print "   Press [Enter] to continue: \n"; 
		$w=<STDIN>;
		return($status); 
	}

	my $newDir = 'analyzers_' . (strftime "%Y-%m-%d_%H%M%S", localtime); 
	prnt2LogSTDOUT("   INFO: Renaming the \'analyzers\' directory to: $newDir \n"); 
	rename("analyzers", $newDir) if -d 'analyzers'; 
	prnt2LogSTDOUT("   INFO: Unzipping $file.. \n");
	my $cmd = qq(unzip -o $file -d ../ &> /dev/null); 
	$status = system($cmd);
	if ($status > 0) 
	{
		prnt2LogSTDOUT("   ERROR: Unzip exited with status: $status \n");
		print "   Press [Enter] to continue:"; 
		<STDIN>; 
		return($status); 
	}
	elsif ($status == 0) 
	{
		prnt2LogSTDOUT("   INFO: Unzip successful, status: $status \n");
		
		if (! -d "update/archive") 
		{
			prnt2LogSTDOUT("   INFO: Creating update/archive directory\n\n"); 
			mkdir("update/archive"); 
		}
		my $newFile = "update/archive/" . basename($file); 
		prnt2LogSTDOUT("   INFO: Moving $file to $newFile");
		move($file, $newFile); 
		print "\n\n   Press [Enter] to continue:"; 
		<STDIN>; 
		return($status); 
	}
}


# +---------------------------+
# | sub: uninstall() 
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub uninstall
{
my $userSel; 

prnt2Log("\nINFO: Running uninstall()\n"); 
until (1 == 2) #endless loop 
	{
		$| = 1;
		system("clear");
		my $count=0; 
		printf "\n               ", RESET;
		printf BOLD WHITE ON_BLUE "Analyzers Uninstall", RESET, "\n\n" if $count == 0;
		printf BOLD WHITE ON_BLUE "\n   Choose an Option:", RESET, "\n\n" if $count == 0; 
		printf "   [1] Uninstall All Analyzers \n"; 
		printf "   [2] Remove Individual Analyzers\n";
		printf "   ...\n"; 
		printf BOLD WHITE ON_BLUE "\n   [B]ack | [H]elp | E[x]it"; 
		print BOLD WHITE ON_YELLOW "   Invalid Selection", RESET if $userSel eq 'invalid'; 
		printf "\n\n  Selection:"; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}/i; 
				
			if ($userSel =~ /^1{1}/i)
			{
				prnt2Log("\nINFO: User Selected to Uninstall all\n"); 
				uninstallAll(); 
			}
			elsif ($userSel =~ /^B{1}/i) 
			{
				return(); 
			}
			elsif ($userSel =~ /^2{1}/i) 
			{
				uninstallPickList(); 
			}
			elsif ($userSel =~ /^H{1}/i) 
			{
				#Help
				system("clear"); 
				print "\n"; 
				printf BOLD WHITE ON_BLUE "   Analyzers \"Remove All\" Help", RESET; 
				print qq(\n   This option removes all remnants of the Analyzers from your system. The\n   following steps are taken: \n   o Remove all Concurrent Program Request Group Entries\n   o Remove all Concurrent Program Definitions\n   o Remove all Concurrent Executable Definitions\n   o Drop all Analyzer Database Objects\n   o Delete all Analyzer Files from <PROD_TOP>/sql\n\n   Note: All Concurrent Program Data Manipulation (DML) is achieved by this\n   script using the FND_PROGRAM API provided by Oracle Development. \n   See the Oracle Developers Guide for more information. \n\n   The Analyzer Bundle 'MENU' directory structure can be manually removed once \n   the uninstall is completed. (This script does not remove the bundle files). \n\n   Press [Enter] to return to the menu: ); 
				<STDIN>; 
			}
			else
			{
				$userSel='invalid'; 
			}
	}
}
####### ##########
#  Subs 
########## #########
	
# +---------------------------
# | sub uninstallPickList 
# | 
# +---------------------------
# +---------------------------+
# | sub:  uninstallPickList
# +---------------------------+
# | Desc: without a mode passed, shows an uninstall picklist to remove analyzers 
# | if mode = show, shows a static list 
# | 
# +---------------------------+
# | Args: <null> (default) or "show" 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub uninstallPickList 
{

	my $analyzers = getInstalledCCPs(); 
	my $userSel; 
	my $invSel = 0;
	my $change; 

	# open (my $fh, '>', '/orahelp/01kjharris/02-bundle/CreateBundle/MENU/dump1' ); 
	# use Data::Dumper; 
	# print $fh Dumper (%$analyzers);
	# close $fh; 
	
	for my $id (keys %$analyzers) 
	{
		$$analyzers{$id}->{'SELECTED'} = ' '; 
		if ($$analyzers{$id}->{'EXECUTABLE'} !~ /^\$/)
		{
			$$analyzers{$id}->{'DROP'} = "drop package $$analyzers{$id}->{'EXECUTABLE'}"; 
		}
	}
	
	if (! defined $$analyzers{'1'}->{'CCPTITLE'})
		{
			print "   INFO: No Analyzers to Remove\n"; 
			print "   Press [Enter] to Continue: "; 
			<STDIN>; 
			return(); 
		}
	#loop forever. Other exit mechanisms are in place. 
	#keeps the menu alive until user specifies
	#Menu entry:
		my $spc = '   ';
		until (1 == 2)
		{
			system("clear");
			print BOLD WHITE ON_GREEN "\n Legend: [+] = Selected To be Uninstalled"; 
			print BOLD WHITE ON_BLUE "\n #  Selected          Title                             ", RESET; 
			print "\n"; 
			$| = 1;
			foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
			{
				my $title = $$analyzers{$ID}->{'CCPTITLE'}; 
				$spc = '  ' if ($ID > 9);
				$spc = '   ' if ($ID < 9);
						
				if (length $title > 59) 
					{ $title = substr($title, 0, 60); $title .= "..."; } 
				my $tabs; 
				my $length=((length($$analyzers{$ID}->{'CCP'}) + length("[$ID]"))); 
				$tabs = "\t\t\t" if $length <= 13;
				$tabs = "\t\t"  if $length >= 14 && $length <=16; 
				$tabs = "\t\t" if $length > 16 && $length <= 20; 
				$tabs = "\t" if $length > 20;
				print "[$ID]",$spc,"[$$analyzers{$ID}->{'SELECTED'}]     $title \n"; 
			}
			print BOLD WHITE ON_BLUE "   [U]ninstall | Select [A]ll | [S]how Analyzers w/ No Concurrent Prog.\n", RESET; 
			print BOLD WHITE ON_BLUE "   [B]ack | [H]elp | E[x]it", RESET; 
			print BOLD WHITE ON_YELLOW "Invalid Selection", RESET if $invSel != 0; 
			print "   \n   ...\n   Toggle Selections by Number, [U] to Proceed with Removal\n";
			print "   Selection:"; 
			$invSel = 0; 
			chomp($userSel = <STDIN>);
			exitLog() if $userSel =~ /^x{1}$/i; 

		if (defined $$analyzers{$userSel}) 
		{
			if ($$analyzers{$userSel}->{'SELECTED'} =~ /\+/) {$$analyzers{$userSel}->{'SELECTED'} = ' ';}
			elsif ($$analyzers{$userSel}->{'SELECTED'} eq ' ') {$$analyzers{$userSel}->{'SELECTED'} = '+';}
		}
		elsif ($userSel =~ /^s{1}/i)
		{
			getAnalyzersNoCCP();
			return(); 
		}
		elsif ($userSel =~ /^u{1}/i)
		{
			prnt2Log("INFO: Running uninstallPickList()"); 
			prnt2Log("\n*** *** ***\nINFO: Removing Analyzers:");
			foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
			{
				prnt2Log("\n----\nFILE: $$analyzers{$ID}->{'FILE'}\nConcurrent Program: $$analyzers{$ID}->{'CCPTITLE'} \($$analyzers{$ID}->{'CCP'}\)\n----\n ") if $$analyzers{$ID}->{'SELECTED'} =~ /\+/; 
			}
			prnt2Log("\n*** *** ***\n");
			
			removeReqGroupEntries($analyzers);
			removeConcProgs($analyzers);
			dropObjects($analyzers); 
			deleteFiles('TARGETED', $analyzers);
			return(); 
		}
		elsif ($userSel =~ /^b{1}/i)
		{	
			return(); 
		}
		elsif ($userSel =~ /^a{1}/i)
		{
			for my $id (keys %$analyzers)
			{
				if ($$analyzers{$id}->{'SELECTED'} eq ' ') {$$analyzers{$id}->{'SELECTED'} = '+';}
			}
			
		}	
		elsif ($userSel =~ /^h{1}/i) 
		{
				system("clear"); 
				print "\n"; 
				print BOLD WHITE ON_BLUE "   Concurrent Program Reinstall Menu Help", RESET, "\n"; 
				print qq (
  INFO: 
  o This menu lists and uninstalls analyzers detected as installed in the 
   database as concurrent programs.
  o Analyzers marked with a "+" will be uninstalled.  
  o Selecting "Uninstall" [U] will remove: 
    -The Concurrent Program Definition 
    -Any Responsibility Group entries 
    -Any database objects associated with the analyzer
    -Any files installed in the <PROD_TOP>/sql for the analyzer
  USAGE: 
  o Toggle which analyzers are loaded by selecting a number 
    -Please note that the presence of a menu item indicates that either a 
     Concurrent Program or Executable definition exists 

	Press [Enter] to continue:); 
				<STDIN>;
			}
		elsif ($userSel =~ /^x$/i)
		{
			exitLog(); 
		} 
		else
		{
			#invalid selection. 
			$invSel = 1; 
		}
	}#end until (1 == 2)
	
} #end pickListMenu


# +---------------------------
# | sub uninstallAll 
# | 
# +---------------------------
sub uninstallAll 
{
	my $analyzers=getInstalledCCPs();
	my $analyzerDBObjs=getInstalledDBobjs();
	my $sizeAnalyzers = keys %{ $analyzers }; 
	my $sizeAnalyzerDBObjs = keys %{ $analyzerDBObjs }; 
	if ($sizeAnalyzers == 0 && $sizeAnalyzerDBObjs == 0) 
	{
		print "   INFO: No Analyzers to Remove. \n   Press [Enter] To Continue: "; 
		<STDIN>; 
		return(); 
	}
	
	system("clear");
	prnt2Log("\nINFO: Running uninstallAll\n"); 
	prnt2LogSTDOUT("\n   INFO: You are about to remove all Analyzers from this system. \n\n"); 
	print "   The following will be removed: \n"; 
	print qq"   o Analyzer Entries in Concurrent Request Groups\n      [via the plsql API: fnd_program.remove_from_group]\n\n   o Analyzer Concurrent Programs\n     [via the plsql API: fnd_program.delete_program]\n\n   o Analyzer Concurrent Executables\n      [via the plsql API: fnd_program.delete_executable]\n\n   o Analyzer Database Objects   \n\n   o Analyzer Files stored in Product Tops \"sql\" directories\n\n"; 
	my $validAns; 
	my $ans; 
	until ($validAns =~ /^y$/i || $validAns =~ /^n$/i)
	{
		prnt2Log(""); 
		print BOLD WHITE ON_BLUE "   Continue with Uninstall? [Y|N] :",RESET;
		chomp($ans = <STDIN>); 
		$validAns = $ans; 
	}
		if ($validAns =~ /^y$/i)
		{
			#build list of all analyzer CCPs
			if ($$analyzers{'1'}->{'CCPTITLE'})
			{
				prnt2Log("INFO: Running uninstallAll()"); 
				prnt2Log("\nINFO: User Selected To Continue with Uninstall All \n"); 
				#remove CCPs 
				prnt2Log("\n*** *** ***\nINFO: Removing Analyzers:");
				foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
				{
					prnt2Log("\n----FILE: $$analyzers{$ID}->{'FILE'}\nConcurrent Program: $$analyzers{$ID}->{'CCPTITLE'} \($$analyzers{$ID}->{'CCP'}\)\n----\n ") if $$analyzers{$ID}->{'SELECTED'} = '+'; 
				}
				prnt2Log("\n*** *** ***\n");
				removeReqGroupEntries($analyzers);
				removeConcProgs($analyzers);
			}
			
			#check for all DB objects
			 
			dropObjects($analyzerDBObjs); 
			#check & Delete files 
			deleteFiles('all'); 
		}
		else 
		{return();}
			
print "   INFO: Uninstall Complete.\n"; 
print "   Press [Enter] to Continue: "; 
<STDIN>; 
return(); 

}#end uninstallAll


# +---------------------------
# | sub deleteFiles
# | 
# | IF user is using the "uninstall" all option
# | then we'll just check for all possible files by checking an 
# | analyzer's template and removing any files that exist. 
# | Else we can take and return an array of files which exist 
# | 
# | mode: "get" -> return hash with 
# | mode: "all" -> check for and del all possible files from PROD_TOP/sql dirs 
# | mode: "targeted" -> remove files passed in 
# +---------------------------
sub deleteFiles
{
	my ($mode, $analyzers) = @_; 
	my @validAnalyzers; 
	#get the largest Hash Key so we can add to it 
	my $i = getLargestHashKey($analyzers); 
	my $match; 
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @validAnalyzers, $File::Find::name . '::' . $match if (($match) = grep{/PROG_TEMPLATE:\s+?(\w+\.ldt)/} @file) }, cwd() );
	if ($mode eq 'all') 
	{
		foreach (@validAnalyzers) 
		{
			my $f = $_; 
			my ($file, $template) = split('::', $f); 
			$template = $+ if $template =~ /PROG_TEMPLATE:\s+?(\w+\.ldt)/; 
			$template = 'analyzers/template/' . $template; 
			open (my $fh, '<', $template ) || die "Cannot open1 $template $! \n"; 
			my @a=<$fh>; 
			close $fh; 
			if (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a))
			{
				my $analyzerObj = analyzer MENU::Analyzer($file);
				my $prodTop = $ENV{$analyzerObj->getProdTop} . '/sql/';
				$file = $prodTop . basename($file); 
				#print "DEBUG 205: File $file \n" if -f $file; 
				unlink($file) or warn "Unable to delete $file: $!" if -f $file; 
			}
		}	
	}
	elsif ($mode eq 'get') 
		{
			my @exists;
			foreach (@validAnalyzers) 
			{
				my $f = $_; 
				my ($file, $template) = split('::', $f); 
				$template = $+ if $template =~ /PROG_TEMPLATE:\s+?(\w+\.ldt)/; 
				$template = 'analyzers/template/' . $template; 
				open (my $fh, '<', $template ) || die "Cannot open1 $template $! \n"; 
				my @a=<$fh>; 
				close $fh; 
				if (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a))
				{
					my $analyzerObj = analyzer MENU::Analyzer($file);
					my $prodTop = $ENV{$analyzerObj->getProdTop} . '/sql/';
					$file = $prodTop . basename($file);
					if (-f $file) #exists in PROD_TOP/sql, so "installed" 
					{
						my $title = $analyzerObj->getTitle();
						#check to see if the hash already contains this title 
						# so as to not add a duplicate. 
						my $match; 
						for my $id (keys %$analyzers)
						{
							if ($title eq $$analyzers{$id}->{'CCPTITLE'})
							{
								$match = 'Y';
								$$analyzers{$id}->{'FILE_PROD_TOP'}=$file;
								last; 
							}
						}
						if ($match ne 'Y')
						{
							$i++;
							$$analyzers{$i}->{'ID'}=$i; 
							$$analyzers{$i}->{'FILE_PROD_TOP'}=$file; 
							$$analyzers{$i}->{'SELECTED'}='+'; 
							$$analyzers{$i}->{'CCPTITLE'}=$title; 
						}
					}
				}
			}
			return($analyzers); 
		}
	elsif ($mode eq 'TARGETED') 
	{
		for my $id (keys %$analyzers)
		{
			if ($$analyzers{$id}->{'SELECTED'} =~ /\+/ && $$analyzers{$id}->{'EXECUTABLE'} =~ /^\$/ )
			{
				my $file = $+ if $$analyzers{$id}->{'EXECUTABLE'} =~ /\$(\w+?_\w+?)\//; 
				$file = $ENV{$file}; 
				my $path = $+ if $exe =~ /\$\w+?_\w+?\/(.+)/; 
				$file = $file . '/' . $path; 
				unlink($file) or warn "Unable to delete \"$file\": $!" if -f $file;
			}
		}
	}
	return(); 
}#END deleteFilesCPP
		
# +---------------------------
# | sub dropObjects
# | 
# | Drops database objects as passed in via a hash with a "DROP" key 
# | objects are dropped if they have SELECTED eq '+'; 
# +---------------------------
sub dropObjects 
{
	my ($analyzers) = @_; 
	my $i = 0; 
	my $cs = $main::connStrg->getConnStrg();
	# use Data::Dumper;
	# print Dumper(@_); 
	# print Dumper(%$analyzers);
	# print "waiting for return: DropObjects \n"; 
	# <STDIN>; 


	unlink "sql/drop.sql" if -f "sql/drop.sql"; 
	#build a SQL File with the drop statements. 
	open (my $fh, '>', 'sql/drop.sql' ) || die "Cannot open sql/drop.sql: $! \n"; 

	for my $id (keys %$analyzers) 
		{
			if ($$analyzers{$id}->{'SELECTED'} =~ /\+/ && length($$analyzers{$id}->{'DROP'}) > 5)
			{ 
				#print $fh "$$analyzers{$id}->{'DROP'} \;\n";
				print $fh "$$analyzers{$id}->{'DROP'}\n";
				$i++; 
			} 
		}
	print $fh "\nexit;"; 
	close $fh; 
	system("clear"); 
	#show the drop statements & give the user a chance to abort 
	if ($i >= 1) 
	{
		print "\n   INFO: About to run the following statments: \n   ...\n\n"; 
		open (my $fh, '<', 'sql/drop.sql' ) || die "Cannot open sql/drop.sql: $! \n";
		while (<$fh>)
		{
			print "    $_"; 
		}
		close $fh;
		print BOLD WHITE ON_BLUE "\n   [B] to go Back or [Enter] to Continue:", RESET; 
		my $cont; 
		chomp($cont=<STDIN>); 
		return if $cont =~ /^b$/i ; 
		#run the SQL 
		my $status = system("sqlplus -L -S $cs \@sql/drop.sql") if length($cont) < 1; 
		#print "   SQLPLUS exited with status: $status, Press [Enter] to continue:"; 
		#<STDIN>; 
	}

	unlink "sql/drop.sql" if -e "sql/drop.sql";
	return();
}	
	
# +---------------------------
# | sub getInstalledDBobjs 
# | 
# | gets all objects which are possible to create from all SQL files under $PWD+ 
# | 
# | Filters list of all objects by objects that are installed. 
# +---------------------------
sub getInstalledDBobjs
{			
	my @sqlFiles; 
	my $line; 
	my %instAnalyzers;
	my $id = 0; 
	my @DBObjs; 
	my @sql;  
	my $cs = $main::connStrg->getConnStrg();
	my $appsUser = $+ if $cs =~ /(\w+?)\//;
	
			find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @sqlFiles, $File::Find::name if grep (/create\s.*?(package\sbody|table|view|function|package)/i, @file) || grep (/create\s*?or\s*?replace/i,@file); }, 'analyzers/SQL' );
		
	foreach (@sqlFiles) 
	{
		my $file = $_; 
		open (my $fh, '<', $file ) || die "Cannot open $file : $! \n";
		while (<$fh>)
		{
			$line = $_; 
			$line = clean($line); 
			$line = <$fh> until eof($fh) || $line =~ /create/i;
			if ($line =~ /^\s*create\s.*?(package\sbody|table|view|function|package)/i || $line =~ /create\s*?or\s*?replace/i)  
			{
				my ($objectName, $objectType);
				$objectType = $+; 
				if (! defined $objectType	)
				{
					for (0..1)
					{
						$line .= <$fh>;
						$line = clean($line);
					} 
					$line =~ /^\s*(create)|(create\sor\sreplace)\s.*?(package\sbody|table|view|function|package)/i; 
					$objectType = $+;
					if (! defined $objectType)
					{
						warn "   WARNING: The Database Object Created by the following file could not be determined:\n   $file \n   ACTION: Manually open/view the file to determine if there are \n   database objects created, then drop those objects manually.\n"; 
						print "   Press [Enter] to Continue:"; 
						my $g = <STDIN>; 
					}
				}
				#keep appending the next line until we have the object name. 
				until (defined $objectName && defined $objectType) 
					{
						$line =~ s/\s{2,}/ /g;
						$line =~ s/apps\.//ig; 
						$objectName = $+ if $line =~ /$objectType\s(\w*)/i;
						$line .= <$fh>;
						$line = clean($line);
						last if eof($fh); 
					}
				
				if (defined $objectName && defined $objectType) 
					{
						next if $objectType eq 'PACKAGE BODY'; 
						$id++; 
						my $statement = "drop " . $objectType . " $appsUser\." . uc($objectName) . ';'; 
						$objectName=uc($objectName); 
						my $dup = 'N'; 
						for my $ids (keys %instAnalyzers)
						{
							$dup = 'Y' if ($instAnalyzers{$ids}->{'NAME'} eq $objectName && $instAnalyzers{$ids}->{'TYPE'} eq $objectType); 
						}
						if ($dup ne 'Y') 
						{
							$instAnalyzers{$id}->{'FILE'}=$file; #file where the create statement was found 
							$instAnalyzers{$id}->{'DROP'}=$statement;
							$instAnalyzers{$id}->{'NAME'}=$objectName;
							$instAnalyzers{$id}->{'TYPE'}=$objectType;
							$instAnalyzers{$id}->{'SELECTED'}='+';
						}
					}
				}
		}
		close $fh; 
	}
my $i=0; 
my $in = qq(\(\');
	for my $id (keys %instAnalyzers)
	{
		$i++; 
		$in .= $instAnalyzers{$id}->{'NAME'} . "\'," if $i == 1; ; 
		$in .= "\'" . $instAnalyzers{$id}->{'NAME'} . "\'," if $i > 1;
	} 
	$in =~ s/,$//; 
	$in .= qq(\)\;); 

@sql = qq(
set serveroutput off
set term off 
set verify off 
SET PAGESIZE 0

set head off\n\n
spool "sql/installed_objs.lst" 

SELECT object_name ||':'|| object_type
FROM user_objects
WHERE upper(object_name) in 
$in
spool off; 
exit); 

open (my $fh, '>', 'sql/checkObjs.sql' ) || die "Cannot open sql/checkObjs.sql: $! \n"; 
print $fh @sql;  
close $fh;
my $status = system("sqlplus -l -s $cs \@sql\/checkObjs.sql"); 

	open (my $fh1, '<', "sql/installed_objs.lst" ) || die "Cannot open sql/installed_objs.lst: $! \n"; 
	while (<$fh1>)
	{
		my $line = $_; 
		last if $line =~ /selected/; 
		$line = clean($line); 
		$line =~ s/\s{2,}//g; 
		push @DBObjs, $line if length($line) > 1; 
	}
	close $fh1;
	
	#filter the list of instAnalyzers with what's in the DB from installed_objs.lst 
	#object_name ||':'|| object_type 
	for my $ids (keys %instAnalyzers)
	{
		#grep to see if the NAME is in @DBObjs;
		if (! grep /$instAnalyzers{$ids}->{'NAME'}\:/, @DBObjs )
		{
			#delete $instAnalyzers{$ids}->{'DROP'};
			delete $instAnalyzers{$ids}; 
		}
	}

	unlink 'sql/checkObjs.sql' if -e 'sql/checkObjs.sql'; 
	unlink 'sql/installed_objs.lst' if -e 'sql/installed_objs.lst'; 
	
	return (\%instAnalyzers); 
} #end Sub getInstalledDBobjs
	
# +---------------------------
#| sub linkObjToAnalyzer
#| Links a DB object (probably a dependency) back to an analyzer Title  
#| 
# +---------------------------
sub linkObjToAnalyzer
{
	my ($objectName, $objectType, $file) = @_; 
	my $title; 
	#check if file is an analyzer SQL 
	open (my $fh, '<', $file ) || warn "Cannot open $file $! \n"; 
	my @a = <$fh>; 
	close ($fh); 
	if (grep(/ANALYZER_BUNDLE_START/, @a))
	{
		#This is an analyzer. get the title
		($title) = grep(/MENU_TITLE:/, @a); 
		$title =~ s/^REM\s+MENU_TITLE:\s*//g; 
		chomp($title);
		return ($title); 
	}
	else 
	{
	my $dir = dirname($file);
	my $fileOnly = basename($file); 
	my @files; 
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @files, $File::Find::name if grep (/ANALYZER_BUNDLE_START/i, @file) &&  grep (/$fileOnly/i,@file); }, $dir );
	
	my $elems = scalar(grep {defined $_} @files); 
	if ($elems >= 1)
	{
		for (0 .. 1) 
		{
			my $analyzerFile = shift @files;
			open (my $fh, '<', $analyzerFile ) || die "Cannot open $analyzerFile $! \n"; 
			my @a = <$fh>; 
			close $fh; 
			($title) = grep(/MENU_TITLE:/, @a); 
			$title =~ s/^REM\s+MENU_TITLE:\s*//g; 
			chomp($title);
			return ($title); 
		}
	}
	else 
	{
		print "   ERROR: Unable to trace origins of object: $objectName Type: $objectType, to a file\n   Press [Enter] to Continue:"; 
		<STDIN>; 
		return("Analyzer UNKNOWN, Object: $objectName($objectType)"); 
	}
}	

}#END linkObjToAnalyzer 



# +---------------------------+
# | sub:  getAnalyzersNoCCP
# +---------------------------+
# | Desc: locates analyzer packages 
# | which have no associated CPP and 
# | provides a menu interface to drop 
# | those packages 
# +---------------------------+
# | Args: none 
# +---------------------------+
# | Returns: none 
# +---------------------------+
sub getAnalyzersNoCCP 
{
	my $cs = $main::connStrg->getConnStrg();
	my @allDBObjs; 
	my $analyzerDBObjs=getInstalledDBobjs();
	
	for my $id (keys %$analyzerDBObjs)
		{
			if (defined($$analyzerDBObjs{$id}->{'NAME'})) 
			{
				push @allDBObjs, $$analyzerDBObjs{$id}->{'NAME'}; 
			}
		} 
		
	#get all the CCP DB objects from my $analyzers = getInstalledCCPs(); 
	my $CCPs = getInstalledCCPs();  

	#@CCPDBObjs the list of analyzer DB objects tied to CCPs 
	my @CCPDBObjs; 
	for my $id (keys %$CCPs)
		{
			if (defined($$CCPs{$id}->{'CCP'}) && $$CCPs{$id}->{'EXECUTABLE'} !~ /^\$/) 
			{
				push @CCPDBObjs, $$CCPs{$id}->{'EXECUTABLE'}; 
			}
		}

	#if the object exists in @allDBObjs, but not in CCPDBObjs, add to @delta array 
	my $match; 
	my %delta; 
	my $i = 0; 
	foreach my $obj (@allDBObjs) 
	{
		#if (($match) = grep (/$obj/, @CCPDBObjs))
		if (! grep (/$obj/, @CCPDBObjs))
		{
			$i++; 
			$delta{$i}->{'OBJNAME'} = $obj;
			$delta{$i}->{'SELECTED'} = ' ';
			$delta{$i}->{'DROP'} = "drop package $obj;";
		}
	}
	
	my $invSel; 
	my $userSel; 
	until (1 == 2) 
	{
		my ($spc1, $spc2, $verLgth); 
		system("clear"); 
		print "          "; 
		print BOLD WHITE ON_BLUE "Analyzer Database Objects Without Concurrent Programs", RESET;
		print BOLD WHITE ON_GREEN "\n\n  Legend: [+] = Selected To be Dropped"; 
		print BOLD WHITE ON_BLUE "\n  \#  SELECTED  OBJECT NAME                  ", RESET; 
		print "\n"; 
		
		$| = 1;
		foreach my $ID (sort { $a <=> $b } keys %delta) 
		{
			$spc1 = "  " if $ID > 9; 
			$spc1 = "   " if $ID <= 9; 
			my $tabs; 
			my $length=((length($delta{$ID}->{'OBJNAME'}) + length("[$ID]"))); 
			$tabs = "\t\t\t\t" if $length > 12 && $length <= 18; 
			$tabs = "\t\t\t" if $length >= 19 && $length <= 28; 
			$tabs = "\t\t" if $length >= 28 && $length <= 34; 

			$tabs = "\t" if $length > 35;  
			print " [$ID]", $spc1, "[$delta{$ID}->{'SELECTED'}]","     $delta{$ID}->{'OBJNAME'} \n";  
		
		}
		
		print BOLD WHITE ON_BLUE "\n   [D]rop Selected | [B]ack | [H]elp | E[x]it", RESET; 
		print BOLD WHITE ON_YELLOW "Invalid Selection", RESET if $invSel != 0; 
		print "   \n   ...\n   Toggle Selections by Number\n";
		print "   Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 

	if ($delta{$userSel} =~ /\d{1,3}/) 
	{
		if ($delta{$userSel}->{'SELECTED'} =~ /\+/) 
		{$delta{$userSel}->{'SELECTED'} = ' ';}
		elsif ($delta{$userSel}->{'SELECTED'} =~ /\s{1}/)
		{$delta{$userSel}->{'SELECTED'} = '+';}
		else
		{$invSel = 1}
	}
	elsif ( $userSel =~ /^b$/i )
	{return;}
	elsif ($userSel =~ /^d$/i)
	{
		if (! grep { $delta{$_}->{'SELECTED'} eq '+' } keys %delta)
		{
			print "   INFO: No Objects Selected. Press [Enter] to continue:" ;
			<STDIN>; 
		}
		else
		{
			dropObjects(\%delta); 
			return(); 
		}
	}
	elsif ($userSel =~ /^h$/i) 
	{
			system("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "   Drop Analyzer Objects Help", RESET, "\n"; 
			print qq (
 o This menu displays Analyzer objects that are not associated with a Concurrent Program  
 o These objects may have been loaded via a Menu option or outside the bundle by a 
    stand alone (non-bundled) download 
 o Whenever an analyzer which uses a database object is run, the Bundle Menu loads
   the object 

Press [Enter] to continue:); 
			my $w = <STDIN>;
	}
	elsif ($userSel =~ /^x$/i)
	{
		exitLog(); 
	} 
	else
	{
		$invSel = 1; 
		#repeat the menu again 
		#need to write a loop around the line 146 foreach menu to redisplay it 
	}

	}#end until (1 == 2)

}
#end Sub getAnalyzersNoCCP



# +---------------------------
#| sub removeConcProgs
#| Removes Conc Program and Executables 
#| 
# +---------------------------
sub removeConcProgs
{
	my ($analyzers) = @_;
	print "   INFO: Running removeConcProgs() to remove Concurrent Programs \n"; 
	my $in = qq(\(\');
	my $i = 0; 
	my $cs = $main::connStrg->getConnStrg();
	for my $id (keys %$analyzers)
	{
		if ($$analyzers{$id}->{'SELECTED'} =~ /\+/ && defined($$analyzers{$id}->{'CCP'})) 
		{
			$i++; 
			$in .= $$analyzers{$id}->{'CCP'} . "\'," if $i == 1; ; 
			$in .= "\'" . $$analyzers{$id}->{'CCP'} . "\'," if $i > 1;
		}
	} 
	$in =~ s/,$//; 
	$in .= qq(\)\;); 

	if ($i == 0) 
		{
		#print "   INFO: No Analyzer Concurrent Program Defintions to Remove \n   Press [Enter] to continue:"; 
		#<STDIN>; 
		return(); 
		}

unlink('sql/get_installed_ccps.sql') if -f 'sql/get_installed_ccps.sql';
unlink('sql/installed_ccps.lst') if -f 'sql/installed_ccps.lst'; 

my @sql = qq(
set serveroutput on
set term off 
set verify off 
set head off\n\n
spool "sql/installed_ccps.lst" 

SELECT fcp.concurrent_program_name ||':'|| fav.application_short_name ||':'|| fe.executable_name
FROM fnd_application_vl fav, fnd_executables fe, fnd_concurrent_programs fcp
WHERE fcp.application_id = fav.application_id 
AND fe.application_id = fav.application_id 
AND fe.executable_id = fcp.executable_id 
AND fcp.concurrent_program_name in 
$in
; 

spool off; 
exit; );

	open (my $fh, '>', 'sql/get_installed_ccps.sql' ) || die "Cannot open sql/get_installed_ccps.sql $! \n"; 
	print $fh @sql;  
	close $fh; 	
	my $status = system("sqlplus -l -s $cs \@sql\/get_installed_ccps.sql");
	open (my $fh1, '<', 'sql/installed_ccps.lst' ) || die "Cannot open sql/installed_ccps.lst: $! \n"; 

	my @a; 
	while (<$fh1>) 
	{
		my $ln = $_; 
		$ln=clean($ln); 
		push @a, $ln if $ln =~ /^\w+\:/; 
	}
	close $fh1; 

	my @sql2;
	my $elems = scalar(grep {defined $_} @a);
	if ($elems > 0)
	{
		foreach (@a)
		{
			last if $_ =~ /selected\./;
			my ($CCP, $appShortName, $exeName) = split(':',$_);
			$exeName =~ s/\s//g; #clean($appShortName) 
			my $statement=qq(exec fnd_program.delete_program(program_short_name => '$CCP', application => '$appShortName');\nexec fnd_program.delete_executable(executable_short_name => '$exeName', application => '$appShortName');); 
			push @sql2, "$statement\n\n"; 
		}
		push @sql2, "\nCOMMIT; \n \/ \n exit;\n\n";
	} 

	unlink "sql/run_fnd_program_del_prog.sql" if -f "sql/run_fnd_program_del_prog.sql"; 
	open (my $fh, '>', 'sql/run_fnd_program_del_prog.sql' ) || die "Cannot open sql/run_fnd_program_del_prog.sql $! \n"; 
	print $fh @sql2;  
	close $fh;
	my $elems = scalar(grep {defined $_} @sql2);
	if ($elems > 0) 
	{	
		my $status = system("sqlplus -l -s $cs \@sql\/run_fnd_program_del_prog.sql");
		#print "   INFO: removeConcProgs(): SQLPLUS command exited with status: $status \n"; 
		#print "   Press [Enter] to continue:";
		#<STDIN>; 
	} 
	else 
	{
		print "   INFO: removeConcProgs: No Concurrent Programs to Remove \n\n"; 
	}
	
	unlink "sql/run_fnd_program_del_prog.sql" if -f "sql/run_fnd_program_del_prog.sql"; 
	unlink('sql/get_installed_ccps.sql') if -f 'sql/get_installed_ccps.sql';
	unlink('sql/installed_ccps.lst') if -f 'sql/installed_ccps.lst'; 
	return(); 
}#end removeConcProgs
	
# +---------------------------
#| sub removeReqGroupEntries
#| 
#| Uses fnd_program.remove_from_group to delete Concurrent Programs from any request groups 
#| they are associated with
# +---------------------------
sub removeReqGroupEntries
{
	my ($analyzers) = @_; 
	my $in = qq(\(\');
	my $i = 0; 
	my $cs = $main::connStrg->getConnStrg();
	print "\n   INFO: Running removeReqGroupEntries() to remove Request Group Entries. \n";
	
	for my $id (keys %$analyzers)
	{
	if ($$analyzers{$id}->{'SELECTED'} =~ /\+/ && defined($$analyzers{$id}->{'CCP'})) 
		{
			$i++; 
			$in .= $$analyzers{$id}->{'CCP'} . "\'," if $i == 1; ; 
			$in .= "\'" . $$analyzers{$id}->{'CCP'} . "\'," if $i > 1;
		}
	} 
	$in =~ s/,$//; 
	$in .= qq(\)\;); 
	
	if ($i == 0) 
		{
			#print "   INFO: No Analyzer Request Group Entries to Remove \n   Press [Enter] to continue:"; 
			#<STDIN>; 
			return(); 
		}
		
unlink('sql/get_req_groups.sql') if -f 'sql/get_req_groups.sql';
unlink('sql/installed_req_groups.lst') if -f 'sql/installed_req_groups.lst'; 

my @sql = qq(
set serveroutput on
set term off 
set verify off
set head off\n\n
spool "sql/installed_req_groups.lst" 

SELECT 
cp.concurrent_program_name ||':'|| fav.application_name ||':'|| rg.request_group_name ||':'|| fav.application_short_name
FROM 
FND_APPLICATION_VL fav, 
fnd_request_groups rg,
fnd_request_group_units rgu,
fnd_concurrent_programs cp,
fnd_concurrent_programs_tl cpt
WHERE fav.application_id = rg.application_id
AND rg.request_group_id = rgu.request_group_id
AND rgu.Request_Unit_Id = cp.concurrent_program_id
AND cp.concurrent_program_id = cpt.concurrent_program_id
AND cpt.language = USERENV('LANG')
AND cp.Concurrent_Program_Name in 
$in
; 

spool off; 
exit; );

	open (my $fh, '>', 'sql/get_req_groups.sql' ) || die "Cannot open sql/get_req_groups.sql $! \n"; 
	print $fh @sql;  
	close $fh; 
	my $status = system("sqlplus -l -s $cs \@sql\/get_req_groups.sql");
	print "   ERROR: Unable to run SQL*PLUS for \"sql\get_req_groups.sql\" " if $status != 0; 
	open (my $fh1, '<', 'sql/installed_req_groups.lst' ) || die "Cannot open sql/installed_req_groups.lst: $! \n"; 
	my @a; 
	while (<$fh1>) 
	{
		my $ln = $_; 
		$ln=clean($ln); 
		push @a, $ln if $ln =~ /^\w+\:/; 
	}
	close $fh1; 

	my @sql2;
	my $elems = scalar(grep {defined $_} @a);
	if ($elems > 0)
	{
		push @sql2, "SET ESCAPE ON\n"; 
		foreach (@a)
		{
			my ($CCP, $appName, $reqGrp, $appShortName) = split(':',$_);
			$appShortName =~ s/\s//g; #clean($appShortName) 
			$reqGrp =~ s/&/\\\&/g; 	
			my $statement=qq(exec fnd_program.remove_from_group (program_short_name => '$CCP', program_application => '$appName', request_group => '$reqGrp', group_application =>'$appShortName');); 
			#print "\n****\nCCP: $CCP\nAppName: $appName\nReqGrp: $reqGrp\nShortName: $appShortName\n****\n";
			push @sql2, "$statement\n\n"; 
		}
		push @sql2, "\nCOMMIT; \n \/ \n exit;\n\n";
	} 

	unlink "sql/run_fnd_program_remove_group.sql" if -f "sql/run_fnd_program_remove_group.sql"; 
	open (my $fh, '>', 'sql/run_fnd_program_remove_group.sql' ) || die "Cannot open sql/run_fnd_program_remove_group.sql $! \n"; 
	print $fh @sql2;  
	close $fh;
	my $elems = scalar(grep {defined $_} @sql2);

	if ($elems > 0) 
	{
		my $status = system("sqlplus -l -s $cs \@sql\/run_fnd_program_remove_group.sql");
	} 
	else 
	{
		print "   INFO: No Request Groups to Remove \n\n"; 
	}
	unlink 'sql/run_fnd_program_remove_group.sql' if -f 'sql/run_fnd_program_remove_group.sql';
	unlink('sql/get_req_groups.sql') if -f 'sql/get_req_groups.sql';
	unlink('sql/installed_req_groups.lst') if -f 'sql/installed_req_groups.lst'; 
	return(); 

}#end removeReqGroupEntries sub	

# +---------------------------
# | sub clean 
# | cleans carriage returns off a var 
# +---------------------------
sub clean 
	{
		my ($var) = @_; 
		chomp($var);
		$var =~ s/\n//g;
		$var =~ s/\r//g;
		return($var); 
	}

	
# +---------------------------
# | sub getLargestHashKey
# | 
# | returns the largest key from a given hash. 
# +---------------------------
sub getLargestHashKey
{
	my $hash = shift;
	keys %$hash;
	my ($large_key, $large_val) = each %$hash;
	while (my ($key, $val) = each %$hash) 
	{
		if ($key > $large_key) 
		{
			$large_key = $key;
			$large_key = $key;
		}
	}
	return $large_key; 
}

# +---------------------------+
# | sub:  getNewAnalyzers
# +---------------------------+
# | Desc: searches for the 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: none - but modifies a hash ref of analyzers 
# +---------------------------+
sub getNewAnalyzers
{
	my ($analyzers) = @_; 

	#find all the analyzers_<date> dirs and locate the one created most recently.. 
	my %dirs; 
	# find( sub {return unless -d && $_ =~ /analyzers_/ ; $dirs{(stat($File::Find::name))[9]}->{'DIR'}=$File::Find::name}, cwd() );
	find( sub {return unless -d && $_ =~ /analyzers_/ ; $dirs{$File::Find::name}->{'TIME'}=(stat($File::Find::name))[9]}, cwd() );

	my $mostRecentDir = _getMax(); 
	
	my @old;
	my @new; 
	#get all the SQL files in the most recent analyzers_ dir 
	find( sub {return unless /\.sql$/; push @old, basename($File::Find::name)}, $mostRecentDir);
	#get all the SQL files in the new "analyzers" dir 
	find( sub {return unless /\.sql$/; push @new, basename($File::Find::name)}, 'analyzers/SQL');

	#create a hash with the deltas for what's diff in the 2 dirs 
	
	# my %delta; 

	#show what's new (in the new dir, not in the old) 
	
	#Get the largest ID from $analyzers hash and set ID to it. 
	my $ID = getLargestHashKey(\%$analyzers); 
	foreach my $new (@new) 
	{
		if (! grep(/$new/, @old))
		{
			#check that the newly found SQL is an analyzer 
			my ($compat, $valid) = checkCompat($new);
			if ($valid > 0) 
			{
				$ID++;
				$$analyzers{$ID}->{'ID'}=$ID;
				find( sub {return unless /$new/; $$analyzers{$ID}->{'FILE'}=$File::Find::name}, 'analyzers/SQL');
				$$analyzers{$ID}->{'CURRFILEVER'}='NONE  '; 
				my $analyzer = analyzer MENU::Analyzer($$analyzers{$ID}->{'FILE'});
				$$analyzers{$ID}->{'CCP'}=$analyzer->getCCPName();   
				# $$analyzers{$ID}->{'CCPTITLE'}=
				# $$analyzers{$ID}->{'EXECUTABLE'}=  
				$$analyzers{$ID}->{'NEWFILEVER'}=$analyzer->getFileVer();
				$$analyzers{$ID}->{'CCPTITLE'}=$analyzer->getTitle();
			}
		}
	}
		
	#show what's been removed.. 
	# foreach my $old (@old) 
	# {
		# push @notInNew, $old if ! grep(/$old/, @new); 
	# }
	
	
	#show what's removed (in the old dir, not in the new) 
	
	sub _getMax
	{
		my $max = 0; 
		my $maxDir; 
		for my $dir (keys %dirs)
		{
			if ($dirs{$dir}->{'TIME'} > $max)
			{
				$max = $dirs{$dir}->{'TIME'}; 
				$maxDir = $dir
			}
		}
		return ($maxDir);  
	}

}



	
return (1); 

__END__ 
