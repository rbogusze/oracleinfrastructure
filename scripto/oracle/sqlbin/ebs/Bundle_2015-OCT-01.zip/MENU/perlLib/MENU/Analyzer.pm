# $Id: Analyzer.pm 200.0 2014/11/20 kjharris $
# +===========================================================================+
# |  Copyright (c) 2014 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services
# +===========================================================================+
# |
# | FILENAME: Analyzer.pm
# |
# | Creates an analyzer object out of an analyzer SQL so that the attribs of 
# | the analyzer can be easily accessed 
# | 
# | PLATFORM
# |   Unix Generic
# |
# | NOTES
# |
# | HISTORY
# | 200.0 Creation (Nov-5-2014) 
# +===========================================================================+

package MENU::Analyzer; 
use File::Find;
use Cwd;
use File::Basename;

sub analyzer
{
	my $class = shift;
	my ($file) = @_; 
	my $analyzer = {@help, @menu, @fload, @deps ,@runOpts, $compat, $title, $outputType, $defReqGrp, $prodTop, $prodShortName, $progTemplate, $CCPName, $fileVer, $CPFile, $appName}; 

	#because the user may toggle in & out of a menu, we need to undefine these vars 
	undef @menu;
	undef @fload;
	undef @help;
	undef @deps;
	undef @runOpts;
	#undef this otherwise the class holds the previous value of the last file where it was defined. 
	undef $CPFile; 

	my $countDepth = $file =~ tr/\///;
	#if the file passed was simply a file not a full path 
	
	if ($countDepth == 0 ) 
	{
		
		find( sub {return unless /\.sql$/; $file = $File::Find::name if "$file" eq "$_" }, 'analyzers/SQL' );
	
	}
	open (my $fh, '<', $file ) || die "Analyzer.pm: Cannot open \'$file\' $! \n"; 
	my @a = <$fh>; 
	close $fh; 
	
	#version 
	($fileVer) = grep(/\$Id:/,@a); 
	($fileVer) = grep(/\$Header:/,@a) if ! $fileVer; 
	$fileVer = $+ if $fileVer =~ /(\d{1,3}\.\d{1,3})/;
	chomp($fileVer); 
	
	#Compat
	($compat) = grep(/COMPAT:/, @a);
	$compat =~ s/^REM\s+COMPAT:\s*//g; 
	chomp($compat); 
	
	#title
	($title) = grep(/MENU_TITLE:/, @a); 
	$title =~ s/^REM\s+MENU_TITLE:\s*//g; 
	chomp($title); 
	
	#Output Type
	($outputType) = grep(/OUTPUT_TYPE:/, @a);
	$outputType =~ s/^REM\s+OUTPUT_TYPE:\s*//g; 
	chomp($outputType);

	#help #FNDLOAD Opts #Dependencies #Run Opts
	for my $i (0 ..$#a) 
	{	
		if ($a[$i] =~ /MENU_START/) 
		{ $i++;
			my $done = 'n';
			until ( $a[$i] =~ /MENU_END/ )
			{
				$a[$i] = trim($a[$i]); 
				($i++, next) if length $a[$i] < 3;  
				chomp($a[$i]); 
				
				#if the length of the line is greater than 60 chars, insert a newline \n in the next space after 50 chars
				my $count = 0;
				my $string2; 
				 
				my @words; 
				if (length($a[$i]) > 65) 
				{
					@words = split / /, $a[$i];
					foreach my $word(@words)
					{
						$count += length($word);
						$word .= " ";
						if ($count > 55 && $done eq 'n')
						{
							$done = 'y';
							$word .= "\n";
							next;
						}
						if ($done eq 'y')
						{
							$word = '      ' . $word;
							$done = 'DONE';
						}
					}
					foreach (@words)
					{
						$string2 .= $_; 
					} 
					push @menu, $string2;
				}
				push @menu, $a[$i] if (length($a[$i]) <= 65); 
				$i++; 
			}
		}
		
		if ($a[$i] =~ /HELP_START/) 
		{ $i++;
			until ( $a[$i] =~ /HELP_END/ )
			{
				$a[$i] = trim($a[$i]); 
				($i++, next) if length $a[$i] < 3; 
				chomp($a[$i]); 
				push @help, $a[$i]; 
				$i++; 
			}
		}
		
		if ($a[$i] =~ /FNDLOAD_START/) 
		{ $i++;
			until ( $a[$i] =~ /FNDLOAD_END/ )
			{
				$a[$i] = trim($a[$i]); 
				($i++, next) if length $a[$i] < 3;
				chomp($a[$i]); 
				push @fload, $a[$i]; 
				$i++; 
			}
		}
			
		if ($a[$i] =~ /DEPENDENCIES_START/) 
		{ $i++;
			until ( $a[$i] =~ /DEPENDENCIES_END/ )
			{
				$a[$i] = trim($a[$i]); 
				($i++, next) if length $a[$i] < 3;
				chomp($a[$i]);
				#strip the filename off the full path to use the full path for the dep file 
				$a[$i] = dirname($file) . '/' . $a[$i];  
				push @deps, $a[$i]; 
				$i++; 
			}
		}
			
		if ($a[$i] =~ /RUN_OPTS_START/) 
		{ $i++;
			until ( $a[$i] =~ /RUN_OPTS_END/ )
			{
			$a[$i] = trim($a[$i]); 
			($i++, next) if length $a[$i] < 3;
			chomp($a[$i]);
			push @runOpts, $a[$i]; 
			$i++; 
			}
		}
	}

	foreach my $line (@fload)
		{
			my ($param, $value)= split /:/, $line; 
			$param=trim($param); 
			$value=trim($value); 
			$defReqGrp = $value if $param =~ /DEF_REQ_GROUP/; 
			$prodTop = $value if $param =~ /PROD_TOP/; 
			$prodShortName = $value if $param =~ /PROD_SHORT_NAME/; 
			$progTemplate = $value if $param =~ /PROG_TEMPLATE/; 
			$CCPName = $value if $param =~ /PROG_NAME/; 
			$CPFile = $value if $param =~ /CP_FILE/; 
			$appName = $value if $param =~ /APP_NAME/; 
		}
	bless $analyzer, $class; 
	return $analyzer; 
}

# +------------
# | sub getFileVer
# | 
# + ------------
sub getFileVer 
	{
		my( $analyzer ) = @_;
		return $fileVer; 
	}

# +------------
# | sub getFNDLOADOpts 
# | 
# + ------------
sub getFNDLOADOpts 
	{
		my( $analyzer ) = @_;
		return \@fload; 
	}

# +------------
# | sub getCCPName
# | 
# + ------------
sub getCCPName
	{
	  my( $analyzer ) = @_;
	  return $CCPName;
	}
	
# +------------
# | sub getReqGroup
# | 
# + ------------
sub getReqGroup 
	{
	  my( $analyzer ) = @_;
	  return $defReqGrp;
	}
	
# +------------
# | sub getProdTop
# | 
# + ------------
sub getProdTop
	{
	  my( $analyzer ) = @_;
	  return $prodTop; 
	}
	
# +------------
# | sub getCCPName
# | 
# + ------------
sub getCCPName
	{
	  my( $analyzer ) = @_;
	  return $CCPName; 
	}
	
# +------------
# | sub getProgTemplate
# | 
# + ------------
sub getProgTemplate
	{
	  my( $analyzer ) = @_;
	  return $progTemplate; 
	}
	
# +------------
# | sub getProdShortName
# | 
# + ------------
sub getProdShortName
	{
	  my( $analyzer ) = @_;
	  return $prodShortName; 
	}
	
# +------------
# | sub getMenu
# | 
# + ------------
sub getMenu
	{
	  my( $analyzer ) = @_;
	  return \@menu;
	}

# +------------
# | sub getTitle
# | 
# + ------------
sub getTitle
	{
	  my( $analyzer ) = @_;
	  return $title;
	}
	
# +------------
# | sub getOutputType
# | 
# + ------------
sub getOutputType
	{
	  my( $analyzer ) = @_;
	  return $outputType;
	}
	
# +------------
# | sub getCompat
# | 
# + ------------
sub getCompat
	{
	  my( $analyzer ) = @_;
		return $compat;
	}
	
# +------------
# | sub getHelp
# | 
# + ------------
sub getHelp
	{
	  my( $analyzer ) = @_;
	  return \@help; 
	}
	
# +------------
# | sub getDeps
# | 
# + ------------
sub getDeps
	{
	  my( $analyzer ) = @_;
	  return \@deps;	
	}
	
# +------------
# | sub getRunOpts
# | 
# + ------------
sub getRunOpts
	{
	  my( $analyzer ) = @_;
	  return \@runOpts; 
	}

# +------------
# | sub getCPFile
# | 
# + ------------
sub getCPFile
	{
	  my( $analyzer ) = @_;
	  return $CPFile; 
	}

# +------------
# | sub getAppName
# | 
# + ------------
sub getAppName 
	{
		my( $analyzer ) = @_;
		return $appName; 
	}	
	
	
# +------------
# | sub trim
# | 
# + ------------
sub trim
{
	my ($v) = @_; 
	chomp($v); 
	$v =~ s/REM//ig; 
	$v =~ s/^\s+//g; 
	$v =~ s/\s+$//g;
	return $v; 
}

1;

__END__ 
