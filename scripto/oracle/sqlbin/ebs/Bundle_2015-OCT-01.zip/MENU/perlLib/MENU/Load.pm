# $Id: Load.pm 200.0 2014/11/20 kjharris $
# *===========================================================================+
# |  Copyright (c) 2014 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# |
# | FILENAME: Load.pm
# |
# | 
# | PLATFORM
# |   Unix Generic
# |
# | NOTES
# |
# | HISTORY
# | 200.0 Creation (OCT-16-2014) 
# +===========================================================================+

use File::Copy qw(move);

# +---------------------------
# | Subs 
# +---------------------------


# +---------------------------+
# | sub:  floadBulkUpdates
# +---------------------------+
# | Desc: Loads all analyzers provided in a flat array WITHOUT any request groups
# +---------------------------+
# | Args: array of analyzers to load 
# +---------------------------+
# | Returns: 
# +---------------------------+

sub floadBulkUpdates 
{
	my ($analyzers)=@_; 
	my $check;
	my $status; 
	my $ans; 
	foreach my $file (@$analyzers)
		{
		  # my $file = $_ ; 
			$check = verChkBeforeLoad($file); 
			
			if ($check == 2) 
			{
				print "   INFO: Unable to version check file: \n   $file\n   Do you wish to load the file without version checking?\n";
				until ($ans =~ /^y|^n/i)
				{
					print "[Y|N]:"; 
					<STDIN>;
				}
				if ($ans =~ /^y/i) 
				{
					$check = 0; 
				}
				else
				{
					print "   INFO: User decided to not proceed with the load of $file \n\n"; 
				}
			}

			if ($check == 0) 
			{
				my $status = runDepen($file); 
				next if $status > 0;
				createProgLDT($file); 
				copySQL($file);
			}
			elsif ($check == 1) 
			{
				print "   INFO: No FNDLOAD actions for $file because the system already contains a higher version\n"; 
			}
		}#end foreach 
		
	if (scalar @$analyzers > 0)
		{
			runFNDLOAD();
		
			foreach my $file (@$analyzers)
			{
				addToGroup($file); 
			} 
			
		}
}#End floadBulkUpdates 

# +---------------------------+
# | sub:  floadBulk
# +---------------------------+
# | Desc: Loads all analyzers provided in a flat array 
# +---------------------------+
# | Args: array ref 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub floadBulk 
{
	my ($analyzers)=@_; 
	
	my $ans = printWarning(); 
	displayDirs('analyzers/SQL') if $ans == 2;  
	#printReqGroups will optionally print 
	#all the CCP info into a text file / log 
	printReqGroups($analyzers); 
	
	
	return() if $ans == 1; 
	
	foreach my $file (@$analyzers)
	{
		my $check = verChkBeforeLoad($file); 
		
		if ($check == 2) 
		{
			print "   INFO: Unable to version check file: \n   $file\n   Do you wish to load the file without version checking?\n";
			until ($ans =~ /^y|^n/i)
			{
				print "[Y|N]:"; 
				<STDIN>;
			}
			if ($ans =~ /^y/i) 
			{
				$check = 0; 
			}
			else
			{
				print "   INFO: User decided to not proceed with the load of $file \n\n"; 
			}
		}

		if ($check == 0) 
		{
			my $analyzer = analyzer MENU::Analyzer($file);
			my $title = $analyzer->getTitle();
			my $CCPName = $analyzer->getCCPName(); 
			my $defReqGrp = $analyzer->getReqGroup(); 
			my $prodShortName = $analyzer->getProdShortName(); 
		
			prnt2Log("\nINFO: About to load $file as a Concurrent Program\n*** *** ***"); 
			prnt2Log("\nTITLE: $title\nPROGRAM: $CCPName\nPRODUCT: $prodShortName\nREQUEST GROUP: $defReqGrp\n*** *** ***\n\n");
		
			my $status = runDepen($file); 
			next if $status > 0; 
			createProgLDT($file); 
			copySQL($file);
		}
		elsif ($check == 1) 
		{
			print "   INFO: No FNDLOAD actions for $file because the system already contains a higher version\n"; 
		}
	}
	
	# foreach (@$analyzers)
	# {
		# my $file = $_ ; 
		# runDepen($file); 
		# createProgLDT($file); 
		# createReqGroupLDT($file); 
		# copySQL($file);
	# }
	if (scalar @$analyzers > 0)
	{
		runFNDLOAD();
		foreach my $file (@$analyzers)
		{
			addToGroup($file); 
		} 
	}

}
# # #End floadBulk# # # 

# +---------------------------+
# | sub:  
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub printWarning
{

system("clear"); 

print qq(

  +-----------------------------------------------------------------+  
                             Attention                               
  +-----------------------------------------------------------------+  
    
   You are about to bulk load Analyzers as Concurrent Programs and 
   register those Concurrent Programs with default Request Groups.  
   Those default Request Groups are: 
    o Seeded into all E-Business Suite Installations 
    o Available to specific Responsibilities
    o In the same Product Area (FND, AP, MFG, etc.) as the Analyzer 
      being loaded 

   Select [C]ontinue to see the list of analyzers included in this 
   bulk load and the default Request Group for each.

   Select [M]ain Menu if you wish to register an Analyzer with a 
   specific Request Group, navigate to the Product, then the Analyzer
   to find single FNDLOAD option where you can optionally change
   the Request Group. 
	 
  +-----------------------------------------------------------------+ 

	
   ); 

	my $ans; 
	until ($ans =~ /^c{1}|^m{1}|^b{1}/i)  
	{
		print BOLD WHITE ON_BLUE "  [C]ontinue  [B]ack  [M]ain Menu "; 
		print "\n   Selection: "; 
		$ans = <STDIN>; 
		chomp($ans); 
	}
	return (0) if $ans =~ /^c{1}/i; 
	return (1) if $ans =~ /^b{1}/i; 
	return (2) if $ans =~ /^m{1}/i; 
}

# +---------------------------+
# | sub: printReqGroups
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub printReqGroups 
{
	my ($analyzers) = @_; 

	my $ans; 
	
	until ($ans =~ /^y{1,3}|^n{1,2}/i) 
	{
		system("clear"); 
		print "   Would you like a log of each Concurrent Program Created? \n   (Includes Request Group Information)\n   [Y|N]:"; 
		chomp($ans = <STDIN>); 
	}
		#getReqGroup 
	if ($ans =~ /^y/i)
	{
		$log = 'logs/' . "ConcurrentInfo_" . (strftime "%Y-%m-%d_%H%M%S", localtime) . ".log"; 
		print "   INFO: The Concurrent Program Information Log is: \n $log \n\n";
		print "   Press [Enter] to Continue: "; 
		open (my $fh, '>', "$log" ) || die "printReqGroups(): Cannot open $log: $! \n"; 
		print $fh "+--------------------------------+\n Generated on ", (strftime "%d %h %Y %H:%M:%S", localtime)," \n+--------------------------------+\n"; 
		foreach my $file (@$analyzers) 
		{
			my $analyzer = analyzer MENU::Analyzer($file);
			print $fh "\n\n"; 
			my $dash = '+'; 
			my $cnt = length($analyzer->getTitle());
			for (my $i = 0; $i < $cnt; $i++)
			{
				$dash .= '-'; 
			}
			$dash .= "+\n"; 
			print $fh " ", $analyzer->getTitle(), "\n", $dash; 
			print $fh " -Concurrent Program Name: ", $analyzer->getCCPName(), "\n";
			print $fh " -Product Short Name: ", $analyzer->getProdShortName(), "\n";  
			print $fh " -Request Group: ", $analyzer->getReqGroup(), "\n"; 
			print $fh "$dash\n"; 
		}
		close $fh;
	}
}


# +---------------------------+
# | sub: floadSingle 
# +---------------------------+
# | Desc: Loads a single analyzer as a concurrent program
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub floadSingle
{
my ($file, $floadRef) = @_;
my $cs = $main::connStrg->getConnStrg(); 
my $prodTop;
my $reqGroup;
my $progName;
my $progTemplate;
my $relVer = getRelVer();

if (! -e $file) 
	{
		find( sub {return unless /\.sql$/; $file = $File::Find::name if "$file" eq "$_" }, 'analyzers/SQL' );
	}

my $check = verChkBeforeLoad($file); 
		
	if ($check == 2) 
	{
		print "   INFO: Unable to version check file: \n   $file\n   Do you wish to load the file without version checking?\n";
		until ($ans =~ /^y|^n/i)
		{
			print "[Y|N]:"; 
			<STDIN>;
		}
		if ($ans =~ /^y/i) 
		{
			$check = 0; 
		}
		else
		{
			print "   INFO: User decided to not proceed with the load of $file\n   Press [Enter] to continue:";
			<STDIN>; 
			return();
		}
	}
	elsif ($check == 1) 
	{
		print "   INFO: No FNDLOAD actions for $file because the system already contains a higher version\n   Press [Enter] to continue:"; 
		<STDIN>; 
		return(); 
	}
	
#if the check == 0, we did not return yet.. and the following code executes: 	

#####
#Check for compat
###
my ($compat, $valid) = checkCompat($file,$relVer); 

if ($valid != 1)
	{
		printf "   ERROR: This Analyzer is not compatible with your E-Business Suite Release ($relVer) \n   Compatible Releases: $compat\n\n   Press [Enter] to Continue: "; 
		my $wait = <STDIN>;
		return 1;
	}

#####
#Check if the user wants to use a diff request group other than the default and tell them what they are about to do. 
###
my $analyzer = analyzer MENU::Analyzer($file);
my $title = $analyzer->getTitle();
#my $fload = $analyzer->getFNDLOADOpts();
my $deps = $analyzer->getDeps();
my $def_req_group = $analyzer->getReqGroup();
my $prod_top = $analyzer->getProdTop();
my $prog_name = $analyzer->getCCPName() ;
my $prod_short_name = $analyzer->getProdShortName();

my $userSel; 
my $loop = 'Y'; 
#system("clear"); 

until ($loop eq 'N')
 {
		system("clear");
		my $filename = basename($file);
		#just in case 
		chomp($title); 
		chomp($filename); 
	  print "\n   INFO: About to FNDLOAD the following analyzer as a Concurrent Program\n   The following parameters will be used. Only the request group is optional \n   and configurable:\n\n"; 
	  print BOLD WHITE ON_BLUE "   $title \[$filename\]", RESET, "\n\n   ->Request Group: \"$def_req_group\"\n   ->Concurrent Program Executable Name: $prog_name \n   ->Product Top: $prod_top \n   ->Product Short Name: $prod_short_name\n\n";
	  printf BOLD WHITE ON_BLUE "\n   [L]oad | [B]ack | [C]hange Request Group | [N]o Request Group\n";
	  printf "\n   Selection:";
	  chomp($userSel = <STDIN>);

if ($userSel =~ /^b$/i)
	{
		my $dir = dirname($file);
		my $file = basename($file);
		fileMenu($dir, $file);
	}
elsif ($userSel =~ /^n$/i) #no Req Group Load 
	{
		print "\n   Load this Analyzer with no request group?\n   [A request group is required before the Concurrent Program may be run]\n   [Y|N]:";
		chomp(my $resp = <STDIN>);
		
		if ($resp =~ /^y/i) 
		{
			my $status = runDepen($file); 
			next if $status > 0; 
			createProgLDT($file);
			copySQL($file);
			runFNDLOAD($cs);
			return; 
		}
	} 
elsif ($userSel =~ /^c$/i)
	{
		my $i;
		until ( $i == 3 )
		{
			my $valid;
			last if $valid eq 'yes';
			$i++; #failed attempt counter 
			print "   \n\n   Enter a valid request group or \'B\' to return to the previous menu\n   Request Group (Case Senstive): "; 
			my $newReqGrp; 
			chomp ($newReqGrp = <STDIN>); 
			return if $newReqGrp =~ /^b$/i ; 
			#get a hash with the PROD (key) and Req Group (value) from validateReqGrp 
			my $validate=validateReqGrp($newReqGrp); 
			system("clear"); 
			#more than 1 possible combination of PROD Short Name + Req Group.. let user select 
			
			if ((scalar keys %$validate) > 1)
				{
					print "   \n\n   SUCCESS: Request Group validated\n\n   INFO: This Request Group exists in multiple Applications.\n\n   Choose a Request Group/Application Combination:  \n"; 
					my $i = 0; 
					my %menu; 
					until (my $nverExit == 1) 
					{
						for my $key (keys %$validate)
						{ 
							$i++; 
							print "   [$i] Request Group: $$validate{$key} [Product: $key]\n"; 
							print "    *\ WARNING: This is a 'Forms Level\' Request Group *\n" if $$validate{$key}->{'REQ_GRP_CODE'}; 
							$menu{$i}{$key}=$$validate{$key}; 
						}
						print "   ... \n"; 
						print BOLD WHITE ON_BLUE "\n   [B]ack",RESET; print "\n"; 
						print "   Select the Request Group-Application Combination: "; 
						my $selectGrp; 
						chomp($selectGrp = <STDIN>);
						
					if (exists $menu{$selectGrp})
					{
						#print $menu{$selectGrp}; 
						foreach my $x (keys %{$menu{$selectGrp}})
						{
							$prod_short_name = $x; 
							$def_req_group = $menu{$selectGrp}{$x};
							system("clear"); 
							$valid = 'yes'; 
							last; 
						}
					}
					elsif ($selectGrp =~ /^b$/i) 
					{
						return; 
					}
					last if $valid eq 'yes'; 
					}
				}
		elsif ((scalar keys %$validate) == 1)
		{
			for my $key (keys %$validate)
			{ 
			
				print "\n[$i] Product Short Name: $key Request Group: $$validate{$key} \n";
				print "    *\ WARNING: This is a 'Forms Level\' Request Group *\n" if $$validate{$key}->{'REQ_GRP_CODE'}; 
				$prod_short_name = $key; 
				$def_req_group = $$validate{$key};
				$valid = 'yes'; 
				print "Press [Enter] to continue:";
				my $wait = <STDIN>; 
				system("clear"); 
				last; 
			}
		}
			elsif ((scalar keys %$validate) == 0)
			{
				print "   ERROR: Invalid Request Group: \'$newReqGrp\'\n   ERROR: User failed to enter a valid request group after $i attempt(s) \n\n";
			}
		last if $valid eq 'yes'; 
	}#end UNTIL 
		if ($i == 3) 
			{
				print "\n\n   Failed to get a valid request group. Verify your request group (FND_REQUEST_GROUPS) exists and try again.  Press [Enter] to continue.. \n    "; 
						my $wait = <STDIN>; 
			}
			
	}#elsif ($userSel =~ /^c$/i)
elsif ($userSel =~ /^l$/i)
	{	
		prnt2Log("\nINFO: About to load $file as a Concurrent Program\n*** *** ***"); 
		prnt2Log("\nTITLE: $title\nPROGRAM: $prog_name\nPRODUCT: $prod_short_name\nREQUEST GROUP: $def_req_group\n*** *** ***\n\n");
		
		my $status = runDepen($file); 
		next if $status > 0;
	  createProgLDT($file);
	  runFNDLOAD($cs);
		addToGroup($file);
	  copySQL($file);
	  return; 
	}
else
	{
		printf "   \"$userSel\" is invalid, Press [Enter] to continue:"; 
		my $wait = <STDIN>; 
		system("clear"); 
	}
}#end UNTIL loop; 
	
}	#END floadSingle 


# +---------------------------+
# | sub:  validateReqGrp
# +---------------------------+
# | Desc: checks to see if a request group 
# | exists and is valid for a given product 
# +---------------------------+
# | Args: a request group to be validated 
# +---------------------------+
# | Returns: hash:  $h{$prod}=$grp;
# +---------------------------+
sub validateReqGrp
	{
		unlink 'sql/req_groups.lst' if -e 'sql/req_groups.lst'; 
		#unlink 'sql/check_req_group.sql' if -e 'sql/check_req_group.sql'; 
		my ($wantedReqGrp) = @_; 
		#my $cs = $main::connStrg->getConnStrg();
		my $cs = $main::connStrg->getConnStrg(); 
		my %h; 
		
		if (! -f "sql/check_req_group.sql") 
			{
				open(my $fh, '>', 'sql/check_req_group.sql' ) || die "Cannot open 'sql/check_req_group.sql': $! \n"; 
				print $fh qq(
SET SERVEROUTPUT ON
SET TERM OFF
SET VERIFY OFF
SET HEAD OFF

SPOOL "sql/req_groups.lst";

SELECT fa.application_short_name || ':' || frg.request_group_name || ':' || frg.request_group_code
FROM FND_APPLICATION FA, FND_REQUEST_GROUPS FRG
WHERE frg.application_id = fa.application_id
AND frg.request_group_name = '&1';
SPOOL OFF;
EXIT;);
close $fh;  
			}
		
		my $status = system("sqlplus -L -S $cs \@sql/check_req_group.sql \"$wantedReqGrp\""); 
		warn "sqlplus failed while checking for a valid request group" if $status != 0; 
		
		if (-f 'sql/req_groups.lst')
		{
		open (my $fh, '<', 'sql/req_groups.lst' ) || die "Cannot open 'sql/req_groups.lst': $! \n"; 
		while (my $line = <$fh>) 
			{
				next unless $line =~ /$wantedReqGrp/; 
				chomp($line); 
				my ($prod, $grp, $rgCode) = split(':', $line); 
				$prod = trim($prod); 
				$grp = trim($grp); 
				$rgCode = trim($rgCode); 
				
				$h{$prod}=$grp;
				$h{$prod}->{'REQ_GRP_CODE'}=$rgCode; 
			}
		close $fh; 
		}
		else
		{
			print "   WARNING: Unable to run SQL*PLUS to check the Request Group \n   A spool file was not created from the command: \n  sqlplus -L -S <connect string> \@sql/check_req_group.sql \"$wantedReqGrp\" "; 
			print "   Press [Enter] to Continue: "; 
			<STDIN>; 
		}
		unlink 'sql/req_groups.lst' if -e 'sql/req_groups.lst'; 
		return(\%h); 
	}

# +---------------------------
# | sub getRelVer() 
# | Determine Release from Context File 
# +---------------------------
sub getRelVer
{
	my $contextFile = $ENV{"CONTEXT_FILE"}; 
	my $relVer; 
	open my $fh, '<', $contextFile or die "   ERROR: Could not open $contextFile: $!";

	while (<$fh>) 
		{
			$relVer = $1 if $_ =~ /s_apps_version\">(\d{2}.+)<\/config_option\>/;
			last if defined $relVer; 
		}
	close $fh; 

	#Validate Release Version 
	die "   ERROR: Unable to determine Release Version from Context File\n" if $relVer !~ /^11\.5|^12\.0|^12\.1|^12.2/;  
	return ($relVer); 
}
#END getRelVer 


# +---------------------------+
# | sub:copySQL  
# +---------------------------+
# | Desc: Checks the EXECUTION_METHOD_CODE of the analyzer's 
# | LDT and if EXECUTION_METHOD_CODE = I, copy the file to PROD_TOP
# +---------------------------+
# | Args: the file to be cp'd
# +---------------------------+
# | Returns: 
# +---------------------------+

sub copySQL
{
	my $relVer = getRelVer(); 
	#get relVer .. 12.2 has special copy considerations 
	my ($file) = @_; 
	my $replace = versionCheckFiles($file);
	find( sub {return unless /$file/; $file = $File::Find::name;}, "analyzers/SQL" ) if (my $i = $file =~ tr/\///) == 0; 
	my $analyzer = analyzer MENU::Analyzer($file);
	my $progTemplate = 'analyzers/template/' . $analyzer->getProgTemplate;  
	open (my $fh, '<', $progTemplate ) || die "copySQL(): Cannot open $progTemplate $! \n"; 
	my @a=<$fh>; 
	close $fh; 
	my $prodTop; 
	my $ans; 
	
	if ($analyzer->getCPFile)
	{
		$file = $analyzer->getCPFile; 
		find( sub {return unless /$file/; $file = $File::Find::name;}, "analyzers/SQL" );
	}

	if (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a) && $replace == 0)
	{
		$prodTop = $ENV{$analyzer->getProdTop} . '/sql/';
		prnt2LogSTDOUT("\n   INFO: Copying file: $file to $prodTop ..\n"); 
		copy($file, $prodTop) or prnt2LogSTDOUT("Unable to copy $file to $prodTop: $!"); 
	}
	elsif (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a) && $replace == 2)
	{
		print "\n\n   WARNING: Unable to version check: ",basename($file)," \n";
		until ($ans =~ /^y|^n/i) 
		{
			print "   Copy the file without version checking? [Y|N]:"; 
			$ans = <STDIN>; 
			chomp($ans); 
			print "   Invalid answer. \n" if $ans !~ /^y|^n/i; 
		}
		if ($ans =~ /^y/i)
		{
			$prodTop = $ENV{$analyzer->getProdTop} . '/sql/';
			prnt2LogSTDOUT("\n   INFO: Copying file: $file to $prodTop ..\n"); 
			copy($file, $prodTop) or prnt2LogSTDOUT("Unable to copy $file to $prodTop: $!");
		}
		else
		{
			prnt2LogSTDOUT("   INFO: Did not copy $file to $prodTop \n"); 
		}
	}
	
	#in all releases, even 12.2, the above "copy"
	#got the file to the primary/current file system
	#But in 12.2, we need to do another copy 
	if ($relVer =~ /^12\.2/i && ($replace == 0 || $ans =~ /^y/i)) 
	{
		my $otherFS = getFSVars(); #/oracle/VISION/12.2/fs2 
		#append PROD_TOP/sql 
		my $prod = $analyzer->getProdTop; 
		$prod =~ s/_TOP//;
		$prod = lc($prod); 
		$prodTop = $otherFS . '/EBSapps/appl/' . $prod . '/12.0.0/sql/';
		copy($file, $prodTop) or warn "Unable to copy $file to $prodTop: $!"; 
	}

}
#END copySQL

# +---------------------------
# | sub getFSVars() 
# | gets both FS vars from the CONTEXT_FILE for 12.2 so
# | both file systems are updated when copying SQL to PROD_TOP/sql 
# +---------------------------
sub getFSVars
	{
		my $contextFile = $ENV{"CONTEXT_FILE"}; 
		my $otherBase; 
		open my $fh, '<', $contextFile or die "   ERROR: Could not open $contextFile: $!";

		while (<$fh>) 
		{
			$otherBase = $1 if $_ =~ /s_other_base\">(.+?)<\/OTHER_BASE\>/;
			last if defined $otherBase; 
		}
		close $fh; 

	#Validate Release Version 
	warn "   ERROR: Unable to determine secondary 12.2 File System from Context File (s_other_base)\n" if ! -d $otherBase;  
	return ($otherBase); 
	
	}

# +---------------------------+
# | sub:  runFNDLOAD() 
# +---------------------------+
# | Desc: runs FNDLOAD for any files in the LDT/run dir 
# +---------------------------+
# | Args: nada 
# +---------------------------+
# | Returns: nada 
# +---------------------------+

sub runFNDLOAD
{
# +=============================================================+ 
# | afcpprog.lct is for loading the program
# | afcpreqg.lct is for registering the program
# | FNDLOAD %%SQL_USER%%/%%SQL_PASS%% O Y UPLOAD $FND_TOP/patch/115/import/afcpreqg.lct <REQ_LDT>
# | FNDLOAD %%SQL_USER%%/%%SQL_PASS%% O Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct <PROG_LDT>
# +=============================================================+ 
my $cs = $main::connStrg->getConnStrg();
my $status; 
my $runDir = 'analyzers/LDT/run'; 
my @progList; 
#my @reqGrpList; 
#find( sub {return unless $_ =~ /_REQGRP.ldt/; push @reqGrpList, $File::Find::name;}, $runDir );
find( sub {return unless $_ =~ /\.ldt/; push @progList, $File::Find::name if -f $_;}, $runDir );

return if (scalar @progList) == 0; # we may not always have a reqgrp ldt, but should always have a proggrp ldt.  

#load the prog LDTs first
while ((scalar @progList) > 0) 
	{
		my $file = shift @progList; 
		prnt2Log("\nINFO: running FNDLOAD: \"FNDLOAD ****\/**** O Y UPLOAD \$FND_TOP/patch/115/import/afcpprog.lct $file \"\n\n"); 
		$status=system("FNDLOAD $cs O Y UPLOAD \$FND_TOP/patch/115/import/afcpprog.lct $file"); 
		#Check status 
		if ($status == 0) 
		{
			prnt2LogSTDOUT ("\n   INFO: FNDLOAD for $file successful \n\n"); 
		}
		else
		{
			prnt2LogSTDOUT ("\n   ERROR: FNDLOAD failed for $file\n\n");
		}
		my $filename = basename($file);
		#move $file, "analyzers/LDT/$filename";
		system("mv $file \"analyzers/LDT/$filename\""); 
	}

# while ((scalar @reqGrpList) > 0) 
	# {
		# my $file = shift @reqGrpList;
		# prnt2Log("\nINFO: running FNDLOAD: \n\"FNDLOAD ****\/**** O Y UPLOAD \$FND_TOP/patch/115/import/afcpreqg.lct $file \"\n\n"); 
		# $status=system("FNDLOAD $cs O Y UPLOAD \$FND_TOP/patch/115/import/afcpreqg.lct $file"); 
		#Check status 
		# if ($status == 0) 
		# {
			# prnt2LogSTDOUT ("\n   INFO: FNDLOAD for $file successful \n\n"); 
		# }
		# else
		# {
			# prnt2LogSTDOUT ("\n   ERROR: FNDLOAD failed for $file\n\n");
		# }
		# my $filename = basename($file);
		#move $file, "analyzers/LDT/$filename";
		# system("mv $file \"analyzers/LDT/$filename\""); 
	# }

		printf BOLD WHITE ON_BLUE "   INFO: Logs for FNDLOAD:" . cwd() . '/logs/' . RESET "\n"; 
		prnt2Log("INFO: Logs for FNDLOAD: ", cwd(),"/logs/"); 
		print "   \n\nPress [Enter] to Continue:"; 
		my $continue = <STDIN>;
		my $s=system("ls *.log > /dev/null 2>&1;");
		system("mv *.log logs/") if $s == 0; 
	
	return(); 
}
#END runFNDLOAD() 

###	
## createProgLDT: takes Release Version / Load.pl mode (single=script/family=<fam>/family=<all>)
## Determines which analyzers need to be processed, then creates the request group LDT for that list. 
## There are no customizations or off-standard changes needed or possible to the program group LDT
## There is no variable instantiation done, we simply match the top part of the template, which is release-specific to
## the bottom, generic part of the template which is generic. 
###

# +---------------------------
# |
# | createProgLDT($relVer, $mode, $analyzers); 
# +---------------------------
sub createProgLDT
	{
	my ($file) = @_;  
	my $relVer = getRelVer();
	my $analyzer = analyzer MENU::Analyzer($file);
	my $progTemplate = $analyzer->getProgTemplate();
	my $CCPName = $analyzer->getCCPName();
	my @newFile; 
	my @newFile1; 
	my $topTemplate; 
	
	$CCPName.="\.ldt"; 
	#printf "REL VER: $relVer \n"; 
	$relVer =~ /^11\.5.?/ ? $topTemplate = '11iProg.ldt' : 
	$relVer =~ /^12\.0.?/ ? $topTemplate = '120Prog.ldt' : 
	$relVer =~ /^12\.1.?/ ? $topTemplate = '121Prog.ldt' : 
	$relVer =~ /^12\.2.?/ ? $topTemplate = '122Prog.ldt' : die "   ERROR: Unable to determine release from context file. \n"; 
	#Copy top 1/2 (release-specific data definition) into an Array 
	open(my $FH1, "<", "analyzers/template/$topTemplate") || die "   Cannot open3: analyzers/template/$topTemplate\": $!";
	@newFile=<$FH1>; 
	close $FH1; 
	#Copy bottom 1/2 (program data, analyzer-specific) into the same array 
	open(my $FH2, "<", "analyzers/template/$progTemplate") || die "   Cannot open4: analyzers/template/$progTemplate\": $!";
	@newFile1=<$FH2>;
	close $FH2; 
	
	 my $time = (strftime "%Y-%m-%d_%H%M%S\n\n", localtime); 
	 $time=trim($time); 
	 #$time =~ s/\n//g; 
	 rename("analyzers/LDT/$CCPName", "analyzers/LDT/" . $CCPName . "\." . $time) if -e "analyzers/LDT/$CCPName"; 
	
	open(my $FH3, ">", "analyzers/LDT/run/$CCPName") || die "   Cannot open5: analyzers/LDT/run/$CCPName\": $!";
	print $FH3 @newFile;
	print $FH3 @newFile1; 
	close $FH3; 
	return (); 	

}#end  createProgLDT()


# +---------------------------
# | createReqGroupLDT: takes Release Version / Load.pl mode (single=script/family=<fam>/family=<all>) / Request Group Name 
# | 
# | Determines which analyzers need to be processed, then creates the request group LDT for that list.
# +---------------------------
sub createReqGroupLDT
{
	my ($file, $defReqGrp, $prodShortName) = @_;
	my $relVer = getRelVer();   
	my $analyzer = analyzer MENU::Analyzer($file);
	$defReqGrp = $analyzer->getReqGroup() unless defined ($defReqGrp); 
	$prodShortName = $analyzer->getProdShortName() unless defined ($prodShortName); 
	my $CCPName = $analyzer->getCCPName(); 
	my $template; 
	$template = '11iReqGrp.ldt' if $relVer =~ /^11\.5/; 
	$template = '120ReqGrp.ldt' if $relVer =~ /^12\.0/; 
	$template = '121ReqGrp.ldt' if $relVer =~ /^12\.1/; 
	$template = '122ReqGrp.ldt' if $relVer =~ /^12\.2/; 
	
	return if length($defReqGrp) < 5; 
	
	open(my $FH1, "<", "analyzers/template/$template" ) || die "   Can't open \"analyzers/template/$template \": $!";
	my @template = <$FH1>; 
	close $FH1; 	
	my @newFile; 
	foreach (@template) 
		{
		  $_ =~ s/%REQ_GROUP%/$defReqGrp/; 
		  $_ =~ s/%PROD%/$prodShortName/; 
		  $_ =~ s/%PROG_NAME%/$CCPName/; 
		  push(@newFile,$_); 
		}
	
	my $time = (strftime "%Y-%m-%d_%H%M%S\n\n", localtime); 
	$time =~ s/\n//g; 
	rename("analyzers/LDT/$CCPName" . "_REQGRP.ldt", "analyzers/LDT/" . $CCPName . "_REQGRP.ldt" . $time) if -e "analyzers/LDT/$CCPName" . "_REQGRP.ldt"; 
	open( my $FH, ">", "analyzers/LDT/run/$CCPName" . "_REQGRP.ldt" ) || die "   Can't open \"analyzers/LDT/run/$CCPName" . "_REQGRP.ldt\": $!";	
	print $FH @newFile; 
	close $FH; 
	return (); 
}

# +---------------------------+
# | sub: addToGroup
# +---------------------------+
# | Desc: adds a file's concurrent program to a request group 
# +---------------------------+
# | Args: analyzer file with a bundle header 
# +---------------------------+
# | Returns: int (status )
# +---------------------------+
sub addToGroup
{
	my ($file) = @_; 
	my $cs = $main::connStrg->getConnStrg(); 
	my $analyzer = analyzer MENU::Analyzer($file);

	my $appName = $analyzer->getAppName(); 
	my $reqGroup = $analyzer->getReqGroup(); 
	my $prodShortName = $analyzer->getProdShortName(); 
	my $ccpName = $analyzer->getCCPName(); 

if (length $appName < 1 || length $reqGroup < 1 || length $prodShortName < 1 || length $ccpName < 1) 
	{
		print "   ERROR: addToGroup(): unable to get all parameters from $file. \n"; 
		print "   ERROR: Unable to add request group entry for $file \n   Press [Enter] to Continue:"; 
		<STDIN>; 
		return(1); 
	}
	
	unlink('sql/add_to_group.sql') if -f 'sql/add_to_group.sql';

	my @sql = qq(

SET DEFINE OFF;
SET SERVEROUTPUT ON;

BEGIN

fnd_program.add_to_group(program_short_name => '$ccpName', program_application => '$appName', request_group => '$reqGroup', group_application =>'$prodShortName'); 

EXCEPTION
   WHEN DUP_VAL_ON_INDEX THEN
   dbms_output.put_line('\n   INFO: Program: $ccpName already included in Request Group: $reqGroup'); 

END; 
/
exit); 
		open (my $fh, '>', 'sql/add_to_group.sql' ) || die "addToGroup(): Cannot open sql/add_to_group.sql \n"; 
		print $fh @sql;
		close $fh;
	
	my $status = system("sqlplus -l -s $cs \@sql/add_to_group.sql"); 
	print "   INFO: addToGroup(): SQLPLUS exited with status: $status \n"; 
	unlink('sql/add_to_group.sql') if -e 'sql/add_to_group.sql';
	return($status); 
}#end Sub addToGroup(); 


# +---------------------------
# | floadUsage
# |
# |
# +---------------------------
sub floadUsage
{
	print "\n    Usage Information for Load.pm \n"; 
	print "   ... \n"; 
	exit 1 if defined $_[0]; 
	exit 0; 
}

return 1; 
__END__


