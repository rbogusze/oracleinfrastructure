SET DEFINE '~'

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.27                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    po_encumbrance_analyzer.sql                                          |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Script automating knowledge for on-site analysis of PO encumbrance   |
REM |    accounting issues and other recurrent accounting related issues      |
REM |                                                                         |
REM | HISTORY                                                                 |
REM |  03-APR-2015 VHLE     First version created                             | 
REM |                                                                         |
REM +=========================================================================+

-- PSD #27A.1
WHENEVER SQLERROR EXIT

declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,2);
    
-- Validation to verify analyzer is run on proper e-Business application version
-- So will fail before package is created
 if apps_version < '12' then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'             ***');
    dbms_output.put_line('*** This Analyzer script must run in version 12 or above    ***');
    dbms_output.put_line('*** Note: the error below is intentional                    ***');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness Version 12 or higher');
 end if;

END;
/


-- PSD #1
CREATE OR REPLACE PACKAGE po_enc_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

PROCEDURE main (
	p_org_id			IN NUMBER   DEFAULT null,
	p_doc_type			IN VARCHAR2 DEFAULT null,
	p_doc_num			IN VARCHAR2 DEFAULT null,
	p_line_num			IN VARCHAR2 DEFAULT null,
	p_from_date			IN DATE     DEFAULT sysdate - 90,
	p_max_output_rows	IN NUMBER   DEFAULT 50,
	p_debug_mode		IN VARCHAR2 DEFAULT 'Y');

PROCEDURE main_cp (
	errbuf            OUT VARCHAR2,
	retcode           OUT VARCHAR2,
	p_org_id			IN NUMBER 	DEFAULT null,
	p_doc_type			IN VARCHAR2 DEFAULT null,
	p_dummy_po			IN VARCHAR2 DEFAULT null,
	p_po_num			IN VARCHAR2 DEFAULT null,
	p_po_line_num		IN VARCHAR2 DEFAULT null,
	p_dummy_req			IN VARCHAR2 DEFAULT null,
	p_req_num			IN VARCHAR2 DEFAULT null,
	p_req_line_num		IN VARCHAR2 DEFAULT null,
	p_from_date			IN VARCHAR2 DEFAULT null,
	p_max_output_rows	IN NUMBER DEFAULT 50,
	p_debug_mode		IN VARCHAR2 DEFAULT 'Y');

-- PSD #1
END po_enc_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY po_enc_analyzer_pkg AS
-- $Id: po_encumbrance_analyzer.sql, 200.2 2015/21/08 vhle Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_parent_sig_count NUMBER; --PSD change #22
g_family_result    VARCHAR2(1); -- PSD change #23

g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1970384.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;

g_preserve_trailing_blanks BOOLEAN := false; -- PSD# 26C.1



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'POENC_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'POENC_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host); -- PSD change #25
    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show","Hide");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show","Hide");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  -- POENC -- change version logo and attachment file here for every new version
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1970384.1:SQL_PKG">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/po_encumbrance_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show","Hide"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  -- PSD change #24
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
  END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  -- PSD change #21
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- DBMS_SQL.DESCRIBE_COLUMNS(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;

		 -- PSD# 26C.3
		 -- Rtrim the column value if blanks are not to be preserved
		 IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
		 END IF;
         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);  -- PSD change #23

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  -- PSD change #23
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>'; -- PSD #27ER113
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
			-- PSD# 26C.2
			-- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
			-- this ensures trailing blanks added for padding are honored by browsers
			-- affects only printing, DX summary handled separately
          IF g_preserve_trailing_blanks THEN
			l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
			-- pad length is the number of spaces existing times the length of &nbsp; => 6
			(length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')), '&nbsp;');
          ELSE
			l_curr_Val := RTRIM(l_curr_Val, ' ');
          END IF;

          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1.'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2.'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4.'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
			
            -- PSD# 26C.2
			-- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
			-- this ensures trailing blanks added for padding are honored by browsers
			-- affects only printing, DX summary handled separately
            IF g_preserve_trailing_blanks THEN
				l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
				-- pad length is the number of spaces existing times the length of &nbsp; => 6
				(length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')), '&nbsp;');
            ELSE
				l_curr_Val := RTRIM(l_curr_Val, ' ');
            END IF;
			
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

         -- show parent signature failure based on result from child signature(s)
		 -- PSD change #23
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      -- l_sig_fail := (l_sig_fail OR l_fail_flag); -- PSD change #23

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -- Print actions
  IF l_sig_fail THEN
    l_step := '230';
	-- PSD change #23
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -- Print solution only if passed
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;
  
 -- PSD change #23
 -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;

  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   --Code for Table of Contents of each section  
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1; -- PSD change #22
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';

   	  -- PSD change #23, #24
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
   	  ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
   	  END IF; 
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';

   -- PSD change #23, #24
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
   	  ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
   	  END IF; 
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0; -- PSD change #22
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
-- PSD #4
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;

  CURSOR get_app_date(p_ptch VARCHAR2) IS
  SELECT max(pr.start_date) app_date
  FROM ad_patch_runs pr
  WHERE pr.patch_run_id in (
          SELECT prb.patch_run_id
          FROM   ad_bugs b,
                 ad_patch_run_bugs prb
          WHERE  b.bug_number = p_ptch
          AND    prb.bug_id = b.bug_id
          UNION
          SELECT pr2.patch_run_id
          FROM ad_applied_patches ap,
               ad_patch_drivers pd,
               ad_patch_runs pr2
          WHERE ap.patch_name = p_ptch
          AND   pd.applied_patch_id = ap.applied_patch_id
          AND   pr2.patch_driver_id = pd.patch_driver_id);
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #4a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '20';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := 'N/A';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.0 Oracle Financials Critical & Recommended Patches';
    l_col_rows(5)(1) := '[557869.1]';
 -- If want to go based on more e-Business Application version, just add for example:
 -- ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
  ELSE
    l_step := '30';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '17167654';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.1: Payments Recommended Patch Collection (IBY RPC), Sep 2013';
    l_col_rows(5)(1) := '[1481221.1]';

    l_col_rows(1)(2) := '17176017';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'R12.1: Payables Recommended Patch (Core AP) Collection (AP RPC), Sep 2013';
    l_col_rows(5)(2) := '[1397581.1]';

    l_col_rows(1)(3) := '17176034';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'R12.1: Payables Recommended Patch Collection (ISP) (AP RPC), Sep 2013';
    l_col_rows(5)(3) := '[1397581.1]';

    l_col_rows(1)(4) := '17176060';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'R12.1: Payables Recommended Patch Collection (WF/PCARD) (AP RPC), Sep 2013';
    l_col_rows(5)(4) := '[1397581.1]';

    l_col_rows(1)(5) := '16060007';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'R12.1: Subledger Accounting Recommended Patch Collection (SLA RPC), March 2013';
    l_col_rows(5)(5) := '[1481222.1]';

    l_col_rows(1)(6) := '17202262';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.1: EBusiness Tax Recommended Patch Collection (ZX RPC), Sep 2013';
    l_col_rows(5)(6) := '[1481235.1]';

    l_col_rows(1)(7) := '18234875';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'R12.1: EBusiness Tax Calculation Cumulative Patch';
    l_col_rows(5)(7) := '[1481235.1]';

    l_col_rows(1)(8) := '16234039';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'Oracle Payments PPR Termination Enhancement Patch';
    l_col_rows(5)(8) := '[1543611.1]';

    l_col_rows(1)(9) := '16804401';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Oracle Payments Enhanced Error Message Patch';
    l_col_rows(5)(9) := '';
  -- PSD #4a-end


  END IF;
  -- Check if applied
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i));
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RSGT1 (RS greater than 1), RS (row selected), NRS (no row selected)
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') --should signature be included in DX Summary
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters (
  p_org_id          IN NUMBER,
  p_doc_type        IN VARCHAR2,
  p_doc_num         IN VARCHAR2,
  p_line_num        IN VARCHAR2,
  p_from_date       IN DATE,
  p_max_output_rows IN NUMBER,
  p_debug_mode      IN VARCHAR2) IS


  l_from_date    VARCHAR2(25);
  l_to_date      VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;

  l_header_id     NUMBER := NULL;
  l_doc_type      VARCHAR2(30) := NULL;
  l_line_id       NUMBER := NULL;
  l_ledger_id     NUMBER := NULL;
  l_enc_year      NUMBER := NULL;
  l_backing_req   VARCHAR2(1) := NULL;
  l_assoc_po      VARCHAR2(1) := NULL;
  l_cur_precision NUMBER := 2;
  l_r12_upd_date  DATE;
  l_r12_upd_char  VARCHAR2(30) := NULL;
  l_enc_env		  VARCHAR2(1) := NULL;
  
  l_federal       VARCHAR2(30);
  l_ss            VARCHAR2(255);
  l_key           VARCHAR2(255);
  
  -------------------------------------
  -- POENC - calc_funds parameters
  -- use po_session_gt
  -------------------------------------
  /*
  l_amount_type              VARCHAR2(30); -- char1
  l_code_combination_id      NUMBER;       -- key
  l_account_type             VARCHAR2(1);  -- 'E'
  l_template_id              NUMBER;       -- index_num2
  l_ledger_id                NUMBER;       -- num4
  l_currency_code            VARCHAR2(30); -- char2
  l_po_install_flag          VARCHAR2(1);  -- 'Y'
  l_accounted_period_type    VARCHAR2(30); -- char3
  l_period_set_name          VARCHAR2(30); -- char4
  l_period_name              VARCHAR2(30); -- index_char2
  l_period_num               NUMBER;       -- num5
  l_quarter_num              NUMBER;       -- num6
  l_period_year              NUMBER;       -- num7
  l_closing_status           VARCHAR2(1);  -- 'O' -- will need to consider other types as well -- char5
  l_budget_version_id        NUMBER;       -- num8
  l_encumbrance_type_id      NUMBER;       -- -1
  l_req_encumbrance_id       NUMBER;       -- num9
  l_po_encumbrance_id        NUMBER;       -- num10
  */
  l_budget                   NUMBER;       -- NUM1
  l_encumbrance              NUMBER;       -- NUM2
  l_actual                   NUMBER;       -- NUM3
  l_funds_available          NUMBER;       -- INDEXl_NUM1
  l_req_encumbrance_amount   NUMBER;
  l_po_encumbrance_amount    NUMBER;
  l_other_encumbrance_amount NUMBER;
  
  l_vldebug_text varchar2(100) := null;
  l_vldebug_number number := null;

  invalid_parameters EXCEPTION;

BEGIN
  -- USE NOTE: This procedure needs to be modified 
  -- to correspond to the parameters of your diagnostic
  -- It should do all required validations,  and populate the
  -- g_rep_info, g_parameters, and g_sql_tokens hash tables
  
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  
  -- PSD #7a
  -- PSD #15

  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');
  
  -- POENC verify encumbrance enc, by fsp.PURCH_ENCUMBRANCE_FLAG must be yes at org_level
  if p_org_id is not null then
    begin
		SELECT nvl(fsp.PURCH_ENCUMBRANCE_FLAG,'N')
		INTO l_enc_env
		FROM financials_system_params_all fsp,
		  hr_operating_units hr
		WHERE fsp.ORG_ID = hr.ORGANIZATION_ID
		AND org_id       = p_org_id;
    exception
      when others then
        print_log('Operating Unit is not encumbrance enabled. Exit.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;
 
  IF l_enc_env <> 'Y' THEN
    print_log('Operating Unit is not encumbrance enabled. ');
    raise invalid_parameters;
  END IF;
  
  IF p_org_id is not null THEN
	-- set org context here
	mo_global.set_policy_context('S',p_org_id);
	ELSE
    print_log('No operating unit organization ID specified. '||
      'The org_id parameter is mandatory.');
    raise invalid_parameters;
  END IF;
  

  -- POENC set org_id context
  IF p_org_id is not null THEN
	-- set org context here
	mo_global.set_policy_context('S',p_org_id);
	ELSE
    print_log('No operating unit organization ID specified. '||
      'The org_id parameter is mandatory.');
    raise invalid_parameters;
  END IF;

  IF (p_doc_type in ('PO', 'REQ')) THEN
	l_doc_type := p_doc_type;
  ELSIF p_doc_type is null THEN
    print_log('No document type specified. '||
      'The document type parameter is mandatory.');
    raise invalid_parameters;
  ELSE
    print_log('Invalid document type specified. '||
      'The document type parameter is mandatory.');
    raise invalid_parameters;
  END IF;

  IF p_doc_num is null THEN
    print_log('No document number specified. '||
      'The document number parameter is mandatory.');
    raise invalid_parameters;
  END IF;
  
  l_from_date := to_char(nvl(p_from_date,sysdate-90),'DD-MON-YYYY');

  l_to_date  := to_char((sysdate),'DD-MON-YYYY');
  
  -- POECN get R12 update date
  SELECT v.profile_option_value
    INTO l_r12_upd_char
	FROM fnd_profile_options p,
	  fnd_profile_option_values v,
	  fnd_profile_options_tl n
	WHERE p.profile_option_id  = v.profile_option_id (+)
	AND p.profile_option_name  = n.profile_option_name
	AND v.LEVEL_ID             = 10001
	AND n.language             = 'US'
	AND p.profile_option_name IN ('PSA_R12_UPGRADE_DATE');
	
    print_log('VLDEBUG R12 update char= '||l_r12_upd_char);
	
	-- POENC set R12 update date
	IF l_r12_upd_char is not null THEN
		l_r12_upd_date := to_date(l_r12_upd_char,'MM/DD/YYYY HH24:MI:SS');
	ELSE
		l_r12_upd_date := SysDate-3000;
		print_log('PSA_R12_UPGRADE_DATE profile option is not set. ');
	END IF;
	
  -- POENC Get ledger_id
  select set_of_books_id 
  into l_ledger_id
  from hr_operating_units 
  where organization_id = p_org_id;
  
  -- POENC Get latest encumbrance year
  select gl.latest_encumbrance_year
  into l_enc_year
  from gl_ledgers gl, hr_operating_units hr
  where gl.LEDGER_ID = hr.set_of_books_id
  and hr.organization_id = p_org_id;
  
  -- POENC Get precision
	SELECT fc.precision
	INTO l_cur_precision
	FROM financials_system_params_all fsp,
	  gl_sets_of_books sob,
	  fnd_currencies fc
	WHERE fsp.set_of_books_id = sob.set_of_books_id
	AND sob.currency_code     = fc.currency_code
	AND fsp.org_id            = p_org_id;
  
  -- POENC Get po_header_id
  if p_doc_type = 'PO' then
    begin
      select po_header_id 
	  into l_header_id
	  from po_headers_all
	  where segment1 = p_doc_num
	  and org_id = p_org_id
	  and type_lookup_code = 'STANDARD';
    exception
      when others then
        print_log('Invalid PO number specified. Only standard PO is accepted.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;

  -- Get po_line_id
  if (p_doc_type = 'PO' and p_line_num is not null) then
    begin
      select l.po_line_id 
	  into l_line_id
	  from po_headers_all h, po_lines_all l
	  where h.po_header_id = l.po_header_id
	  and h.segment1 = p_doc_num
	  and h.org_id = p_org_id
	  and l.line_num = p_line_num;
    exception
      when others then
        print_log('Invalid line number, PO number, org_id specified.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;

  -- Get status of backing req for the PO/line
  if p_doc_type = 'PO' then
    begin
		select decode(count(*),0,'N','Y')
		into l_backing_req from dual
		where exists
		(select 1
		from po_distributions_all
		where po_header_id = l_header_id
		and org_id         = p_org_id
		and to_char(po_line_id) like nvl(to_char(l_line_id),'%')
		and req_distribution_id is not null);
    exception
      when others then
        print_log('Invalid backing requisition status.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;  

  -- Get requisition_header_id
  if p_doc_type = 'REQ' then
    begin
      select requisition_header_id 
	  into l_header_id
	  from po_requisition_headers_all
	  where segment1 = p_doc_num
	  and org_id = p_org_id;
    exception
      when others then
        print_log('Invalid Requisition number specified.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;

  -- Get requisition_line_id
  if (p_doc_type = 'REQ' and p_line_num is not null) then
    begin
      select rl.requisition_line_id 
	  into l_line_id
	  from po_requisition_headers_all rh, po_requisition_lines_all rl
	  where rh.requisition_header_id = rl.requisition_header_id
	  and rh.segment1 = p_doc_num
	  and rh.org_id = p_org_id
	  and rl.line_num = p_line_num;
    exception
      when others then
        print_log('Invalid line number, requisition number, org_id specified.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;
  
  -- Get status of associated PO for the requisition/line
  if (p_doc_type = 'REQ' and l_header_id is not null) then
    begin
		select decode(count(line_location_id),0,'N','Y')
		into l_assoc_po
		from po_requisition_lines_all
		where requisition_header_id = l_header_id
		and org_id         = p_org_id
		and line_num like nvl('p_line_num','%');
    exception
      when others then
        print_log('Invalid associcated PO status found for the requisition.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;  

  ----------------------------------------------
  -- POENC - calc_funds calculation
  -- use po_session_gt to derive funds balance
  -- also keep temp records of all dist in PSG
  -----------------------------------------------

	-- PO_CALC_FUNDS
  
	if p_doc_type = 'PO' then
	begin
		
	  DELETE FROM po_session_gt WHERE index_char1 IN ('PO_CALC_FUNDS');
	  
	  INSERT
	  INTO po_session_gt
		(
		  INDEX_CHAR1,
		  INDEX_CHAR2,
		  char1,
		  KEY,
		  index_num2,
		  num4,
		  char2,
		  char6,
		  char4,
		  char5,
		  char3,
		  num5,
		  num6,
		  num7,
		  num8,
		  num9,
		  num10
		)
	  SELECT 'PO_CALC_FUNDS',
		to_char(po_distribution_id),
		NVL(bco.show_amount_type,'PTD'),
		ccv.code_combination_id,
		ccv.template_id,
		gl.ledger_id,
		gl.currency_code,
		ps.period_type,
		gl.period_set_name,
		nvl(bco.funds_check_level_code, 'Z'),
		ps.period_name,
		ps.PERIOD_NUM,
		ps.QUARTER_NUM,
		ps.PERIOD_YEAR,
		gb.BUDGET_VERSION_ID,
		fsp.REQ_ENCUMBRANCE_TYPE_ID,
		fsp.PURCH_ENCUMBRANCE_TYPE_ID
	  FROM GL_BUDGET_ASSIGNMENTS_V ba,    
		gl_budgets_v gb,                  
		GL_BUDORG_BC_OPTIONS_V bco,       
		GL_SUMMARY_COMBINATIONS_V ccv,    
		gl_ledgers gl,                    
		gl_period_statuses ps,            
		financials_system_params_all fsp, 
		po_distributions_all pod
	  WHERE ba.LEDGER_ID         = gl.LEDGER_ID
	  AND ba.LEDGER_ID           = gb.LEDGER_ID
	  AND gb.status              = 'C'
	  AND ba.RANGE_ID            = bco.RANGE_ID (+)
	  AND ba.CODE_COMBINATION_ID = ccv.CODE_COMBINATION_ID
	  AND ba.LEDGER_ID           = ps.LEDGER_ID
	  AND ba.LEDGER_ID           = fsp.SET_OF_BOOKS_ID
	  AND fsp.org_id             = pod.org_id
	  AND ba.CODE_COMBINATION_ID = pod.budget_account_id
	  AND ps.period_name         = pod.gl_encumbered_period_name
	  AND ps.APPLICATION_ID      = 101
	  AND ba.LEDGER_ID           = l_ledger_id
	  AND fsp.ORG_ID             = p_org_id
	  AND pod.po_header_id       = l_header_id;
	  --AND pod.po_line_id like nvl('l_line_id','%');
	  

	  FOR rec_calc_funds IN
	  (SELECT char1,
		KEY,
		index_num2,
		num4,
		char2,
		char6,
		char4,
		char3,
		num5,
		num6,
		num7,
		num8,
		num9,
		num10
	  FROM po_session_gt
	  WHERE index_char1 = 'PO_CALC_FUNDS'
	  )
	  LOOP
		gl_funds_available_pkg.calc_funds 
		( 
		rec_calc_funds.char1, 
		rec_calc_funds.key, 
		'E', 
		rec_calc_funds.index_num2,
		rec_calc_funds.num4, 
		rec_calc_funds.char2, 
		'Y', 
		rec_calc_funds.char6,
		rec_calc_funds.char4, 
		rec_calc_funds.char3,
		rec_calc_funds.num5, 
		rec_calc_funds.num6, 
		rec_calc_funds.num7, 
		'O', 
		rec_calc_funds.num8, 
		-1, 
		rec_calc_funds.num9, 
		rec_calc_funds.num10,
		l_budget, 
		l_encumbrance, 
		l_actual, 
		l_funds_available, 
		l_req_encumbrance_amount, 
		l_po_encumbrance_amount, 
		l_other_encumbrance_amount);
		

		UPDATE po_session_gt
		SET num1        = l_budget,
		  num2          = l_encumbrance,
		  num3          = l_actual,
		  index_num1    = l_funds_available
		WHERE KEY       = rec_calc_funds.key
		AND index_char1 = 'PO_CALC_FUNDS';


	  END LOOP;	
	end;  
	END IF;

	-- REQ_CALC_FUNDS
  
	IF l_doc_type = 'REQ' THEN
	begin
  
	  DELETE FROM po_session_gt WHERE index_char1 IN ('REQ_CALC_FUNDS');
	  
	  INSERT
	  INTO po_session_gt
		(
		  INDEX_CHAR1,
		  INDEX_CHAR2,
		  char1,
		  KEY,
		  index_num2,
		  num4,
		  char2,
		  char6,
		  char4,
		  char5,
		  char3,
		  num5,
		  num6,
		  num7,
		  num8,
		  num9,
		  num10
		)
	  SELECT 'REQ_CALC_FUNDS',
		to_char(distribution_id),
		NVL(bco.show_amount_type,'PTD'),
		ccv.code_combination_id,
		ccv.template_id,
		gl.ledger_id,
		gl.currency_code,
		ps.period_type,
		gl.period_set_name,
		nvl(bco.funds_check_level_code, 'Z'),
		ps.period_name,
		ps.PERIOD_NUM,
		ps.QUARTER_NUM,
		ps.PERIOD_YEAR,
		gb.BUDGET_VERSION_ID,
		fsp.REQ_ENCUMBRANCE_TYPE_ID,
		fsp.PURCH_ENCUMBRANCE_TYPE_ID
	  FROM GL_BUDGET_ASSIGNMENTS_V ba,    
		gl_budgets_v gb,                  
		GL_BUDORG_BC_OPTIONS_V bco,       
		GL_SUMMARY_COMBINATIONS_V ccv,    
		gl_ledgers gl,                    
		gl_period_statuses ps,            
		financials_system_params_all fsp, 
		po_req_distributions_all prd,
		po_requisition_lines_all prl
	  WHERE ba.LEDGER_ID         = gl.LEDGER_ID
	  AND ba.LEDGER_ID           = gb.LEDGER_ID
	  AND gb.status              = 'C'
	  AND ba.RANGE_ID            = bco.RANGE_ID (+)
	  AND ba.CODE_COMBINATION_ID = ccv.CODE_COMBINATION_ID
	  AND ba.LEDGER_ID           = ps.LEDGER_ID
	  AND ba.LEDGER_ID           = fsp.SET_OF_BOOKS_ID
	  AND fsp.org_id             = prl.org_id
	  AND prl.requisition_line_id = prd.requisition_line_id
	  AND ba.CODE_COMBINATION_ID = prd.budget_account_id
	  AND ps.period_name         = prd.gl_encumbered_period_name
	  AND ps.APPLICATION_ID      = 101
	  AND ba.LEDGER_ID           = l_ledger_id
	  AND fsp.ORG_ID             = p_org_id
	  AND prl.requisition_header_id       = l_header_id;
	  -- AND prl.requisition_line_id like nvl('l_line_id','%');
	  
	  FOR rec_cfunds_req IN
	  (SELECT char1,
		KEY,
		index_num2,
		num4,
		char2,
		char6,
		char4,
		char3,
		num5,
		num6,
		num7,
		num8,
		num9,
		num10
	  FROM po_session_gt
	  WHERE index_char1 = 'REQ_CALC_FUNDS'
	  )
	  LOOP
		gl_funds_available_pkg.calc_funds 
		( 
		rec_cfunds_req.char1, 
		rec_cfunds_req.key, 
		'E', 
		rec_cfunds_req.index_num2,
		rec_cfunds_req.num4, 
		rec_cfunds_req.char2, 
		'Y', 
		rec_cfunds_req.char6,
		rec_cfunds_req.char4, 
		rec_cfunds_req.char3,
		rec_cfunds_req.num5, 
		rec_cfunds_req.num6, 
		rec_cfunds_req.num7, 
		'O', 
		rec_cfunds_req.num8, 
		-1, 
		rec_cfunds_req.num9, 
		rec_cfunds_req.num10,
		l_budget, 
		l_encumbrance, 
		l_actual, 
		l_funds_available, 
		l_req_encumbrance_amount, 
		l_po_encumbrance_amount, 
		l_other_encumbrance_amount);

		UPDATE po_session_gt
		SET num1        = l_budget,
		  num2          = l_encumbrance,
		  num3          = l_actual,
		  index_num1    = l_funds_available
		WHERE KEY       = rec_cfunds_req.key
		AND index_char1 = 'REQ_CALC_FUNDS';
		
	  END LOOP;
	end;  
	END IF;
	
-- Check if FEDERAL is enabled

	if (p_org_id is not null) then
  		begin
		mo_global.set_policy_context('S',p_org_id);
		  if (FV_INSTALL.ENABLED) then
			l_federal := 'Enabled';
	    	  else
			l_federal := 'Not Enabled';
		  end if;
     	print_log('FEDERAL is: '||l_federal);
		end;
    end if;

-- Revision and date values populated by RCS
-- PSD #6  
  l_revision := rtrim(replace('$Revision: 200.2 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/08/21 22:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #7
  g_rep_info('File Name') := 'po_encumbrance_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1970384.1" target="_blank">(Note 1970384.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

-- PSD #27A.2
-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  IF substr(l_apps_version,1,2) < '12' THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script must run in version 12 or above.');
	raise invalid_parameters;
  END IF;

  -- PSD #8
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Operating Unit') := p_org_id;
  g_parameters('2. Document Type') := p_doc_type;
  g_parameters('3. Document Number') := p_doc_num;
  g_parameters('4. Line Number') := p_line_num;
  g_parameters('5. Validation From Date') := l_from_date;
  g_parameters('6. Max Rows') := g_max_output_rows;
  g_parameters('7. Debug Mode') := p_debug_mode;
  
  -- Create global hash of SQL token values
  g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');
  g_sql_tokens('##$$ORGID$$##') := to_char(p_org_id);
  g_sql_tokens('##$$LEDGERID$$##') := l_ledger_id;
  g_sql_tokens('##$$ENCYEAR$$##') := l_enc_year;
  g_sql_tokens('##$$BREQ$$##') := l_backing_req;
  g_sql_tokens('##$$ASSOCPO$$##') := l_assoc_po;
  g_sql_tokens('##$$FDATE$$##') := l_from_date;
  g_sql_tokens('##$$HEADERID$$##') := l_header_id;
  g_sql_tokens('##$$LINEID$$##') := l_line_id;
  g_sql_tokens('##$$DOCTYPE$$##') := l_doc_type;
  g_sql_tokens('##$$CURRPRE$$##') := l_cur_precision;
  g_sql_tokens('##$$R12UDATE$$##') := l_r12_upd_char; -- date in MM/DD/YYYY HH24:MI:SS format
  


  l_ss := null;
  if (l_header_id is not null) then
    l_ss := to_char(l_header_id);
  end if;

  g_sql_tokens('##$$HEADERID$$##') := l_ss;
  print_log('PO_HEADER_ID = '||l_ss);

  g_sql_tokens('##$$FEDERAL$$##') := l_federal;
  print_log('Federal is '||l_federal);

  g_sql_tokens('##$$TDATE$$##') := l_to_date;
  print_log('To Date is '||l_to_date);
  

  l_key := g_sql_tokens.first;
  -- Print token values to the log
 
  print_log('SQL Token Values');


  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;

  -- PSD #15-end
  
EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN
-- PSD 9
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------
  
  -------------------------------------------
  -- POENC Invalids
  -------------------------------------------
  
  -- PO Invalids
  add_signature(
   'PO_INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND a.object_name like ''PO_%'' 
    AND a.status = ''INVALID''',
   'Purchasing Invalid Objects',
   'RS',
   'There exist invalid Purchasing objects',
   '<ul>
      <li>Recompile the individual objects manually or recompile the
          entire APPS schema with adadmin utility</li>
      <li>Review any error messages provided</li>
   </ul>',
   '<ul>
      <li>No Purchasing related invalid objects exists in the database</li>
    </ul>',
   'ALWAYS',
   'E');
  
  -- XLA Invalids
  l_info.delete;
  l_info('Doc ID') := '1406203.1';
  l_info('Bug Number') := '13344804';
  add_signature(
   'XLA_INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
		a.status
    FROM dba_objects a
    WHERE a.owner = ''APPS''
    AND (a.object_name like ''XLA_%201%'' or a.object_name like ''XLA_%707%'')
    AND a.status = ''INVALID''',
   'Subledger Accounting Invalid Objects',
   'RS',
   'There exist invalid Subledger Accounting invalid objects',
   '<ul>
      <li>Run Validate Application Accounting Definition concurrent program to compile the invalid XLA objects</li>
	  <li>Follow instructions in [1406203.1] for detail how to run the concurrent program</li>
      <li>Review any error messages in the concurrent program output file</li>
   </ul>',
   '<ul>
      <li>No XLA related invalid objects exists in the database</li>
    </ul>',
   'ALWAYS',
   'E',
   'Y',
   'Y',
   l_info);
  
  -------------------------------------------
  -- POENC patch level
  -------------------------------------------
  
  -- PRC patchset 12.2
  l_info.delete;
  add_signature(
   'PRC_CODE_LEVEL_12_2',
   'select  b.bug_number, b.bug_description, 
   decode((count(a.bug_number)),0,''NOT APPLIED'',''APPLIED'') status, 
   a.creation_date applied_date
   from ad_bugs a,
   (     select ''16910001'' bug_number, ''Release 12.2.2 - provides R12.2 baseline code for PRC_PFR'' bug_description from dual
   union select ''17036666'' bug_number, ''Release 12.2.3 - provides R12.PRC_PF.B.delta.3'' bug_description from dual
   union select ''17947999'' bug_number, ''Release 12.2.3 - provides R12.PRC_PF.B.delta.4'' bug_description from dual
   union select ''17919161'' bug_number, ''12.2.4 - ORACLE E-BUSINESS SUITE 12.2.4 RELEASE UPDATE PACK'' bug_description from dual
   union select ''12359561'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), Apr 2011'' bug_description from dual
   union select ''14563642'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), May 2013'' bug_description from dual
   union select ''19266556'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), Aug 2014'' bug_description from dual
   ) b
   where a.bug_number (+) = b.bug_number
   group by b.bug_number, b.bug_description, a.creation_date
   	order by to_number(b.bug_number)',
	'EBS/Procurement/PSA/SLA Level for 12.2',
   'RS',
   'Review the list for Procurement Family Pack status',
   '<ul>
	  <li>Review Procurement Family Patch Release History (Including Latest Available Rollups) [222339.1]</li>
      <li>Apply the latest Patch Collection or Family Pack</li>
   </ul>',
   'Found no patch collection applied for Code level 12.2',
   'ALWAYS',
   'I');
	
  -- PRC patchset 12.1
  l_info.delete;  
  add_signature(
   'PRC_CODE_LEVEL_12_1',
   'select  b.bug_number, b.bug_description, 
	decode(count(a.bug_number),0,''NOT APPLIED'', ''APPLIED'') status, 
	a.creation_date applied_date
	from ad_bugs a,
	(    select ''7303030'' bug_number, ''Release 12.1.1 - provides R12.1 baseline code for PRC_PF'' bug_description from dual
	union select ''7303033'' bug_number, ''Release 12.1.2 - provides R12.PRC_PF.B.delta.2'' bug_description from dual
	union select ''9239090'' bug_number, ''Release 12.1.3 - provides R12.PRC_PF.B.delta.3'' bug_description from dual
	union select ''8522002'' bug_number, ''R12.PRC_PF.B.delta.2'' bug_description from dual
	union select ''9249354'' bug_number, ''R12.PRC_PF.B.delta.3'' bug_description from dual
	union select ''10417963'' bug_number, ''Procurement R12.1.3 Update 2011/02 February 2011'' bug_description from dual
	union select ''11817843'' bug_number, ''Procurement R12.1.3 Update 2011/04 April 2011'' bug_description from dual
	union select ''12661793'' bug_number, ''Procurement R12.1.3 Update 2011/11 November 2011'' bug_description from dual
	union select ''13984450'' bug_number, ''Procurement R12.1.3 Update 2012/06 June 2012'' bug_description from dual
	union select ''14254641'' bug_number, ''Procurement R12.1.3 Update 2012/09 September 2012'' bug_description from dual
	union select ''15843459'' bug_number, ''Procurement R12.1.3 Update 2013/03 March 2013'' bug_description from dual
	union select ''17525552'' bug_number, ''Consolidated RUP covering iSupplier Portal Bug Fixes, Sourcing Bug Fixes post 12.1.3 and SLM new features'' bug_description from dual
	union select ''18911810'' bug_number, ''Oracle Procurement Recommended Patch Collection (July 2014)'' bug_description from dual
	union select ''18120913'' bug_number, ''Procurement R12.1.3 Update 2014/01 January 2014'' bug_description from dual
	union select ''17774755'' bug_number, ''Oracle E-Business Suite Release 12.1.3+ Recommended Patch Collection 1 [RPC1]'' bug_description from dual
	union select ''18911810'' bug_number, ''Procurement R12.1.3 Update 2014/07 July 2014'' bug_description from dual
	union select ''19030202'' bug_number, ''Oracle E-Business Suite Release 12.1.3+ Recommended Patch Collection 2 [RPC2]'' bug_description from dual
   union select ''12359561'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), Apr 2011'' bug_description from dual
   union select ''14563642'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), May 2013'' bug_description from dual
   union select ''19266556'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), Aug 2014'' bug_description from dual
   union select ''14284509'' bug_number, ''Subledger Accounting Recommended Patch Collection (SLA), August 2012'' bug_description from dual
   union select ''19034020'' bug_number, ''Subledger Accounting (SLA) Recommended Patch Collection - August 2014'' bug_description from dual
	) b
	where a.bug_number (+) = b.bug_number
	group by b.bug_number, b.bug_description, a.creation_date
	order by to_number(b.bug_number)',
	'EBS/Procurement/PSA/SLA Code Level for 12.1',
   'RS',
   'Review the list for Procurement Family Pack status',
   '<ul>
	  <li>Review Procurement Family Patch Release History (Including Latest Available Rollups) [222339.1]</li>
	  <li>Review EBS: R12.1 Oracle Financials Recommended Patch Collection (RPC), Aug 2014 [954704.1]</li>
      <li>Apply the latest Patch Collection or Family Pack</li>
	  </ul>',
   'Found no patch collection applied for Code level 12.1',
   'ALWAYS',
   'I');
  
  
  -- PRC patchset 12.0
  l_info.delete;  
  add_signature(
   'PRC_CODE_LEVEL_12_0',
   'select  b.bug_number, b.bug_description, 
	decode(count(a.bug_number), 0, ''NOT APPLIED'', ''APPLIED'') status, 
	a.creation_date applied_date
	from ad_bugs a,
	(     select ''4440000'' bug_number, ''Release 12.0.0 - provides R12 baseline code for PRC_PF'' bug_description from dual
	union select ''5082400'' bug_number, ''Release 12.0.1'' bug_description from dual
	union select ''5484000'' bug_number, ''Release 12.0.2 - provides R12.PRC_PF.A.delta.2'' bug_description from dual
	union select ''6141000'' bug_number, ''Release 12.0.3 - provides R12.PRC_PF.A.delta.3'' bug_description from dual
	union select ''6435000'' bug_number, ''Release 12.0.4 - provides R12.PRC_PF.A.delta.4'' bug_description from dual
	union select ''6728000'' bug_number, ''Release 12.0.6 - provides R12.PRC_PF.A.delta.6'' bug_description from dual
	union select ''7015582'' bug_number, ''Procurement Release 12.0 Rollup Patch 5'' bug_description from dual
	union select ''7218243'' bug_number, ''Procurement R12.0 Update July 2008'' bug_description from dual
	union select ''7291462'' bug_number, ''Procurement R12.0 Update August 2008'' bug_description from dual
	union select ''7355145'' bug_number, ''Procurement R12.0 Update Sept 2008'' bug_description from dual
	union select ''7433336'' bug_number, ''Procurement R12.0 Update Oct 2008'' bug_description from dual
	union select ''7505241'' bug_number, ''Procurement R12.0 Update Nov 2008'' bug_description from dual
	union select ''7600636'' bug_number, ''Procurement R12.0 Update Dec 2008'' bug_description from dual
	union select ''7691702'' bug_number, ''Procurement R12.0 Update Jan 2009'' bug_description from dual
	union select ''8298073'' bug_number, ''Procurement R12.0 Update Mar 2009'' bug_description from dual
	union select ''8392570'' bug_number, ''Procurement R12.0 Update Apr 2009'' bug_description from dual
	union select ''8474052'' bug_number, ''Procurement R12.0 Update May 2009'' bug_description from dual
	union select ''8555479'' bug_number, ''Procurement R12.0 Update Jun 2009'' bug_description from dual
	union select ''8658242'' bug_number, ''Procurement R12.0 Update Jul 2009'' bug_description from dual
	union select ''8781255'' bug_number, ''Procurement R12.0 Update Aug 2009'' bug_description from dual
   union select ''12359561'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), Apr 2011'' bug_description from dual
   union select ''14563642'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), May 2013'' bug_description from dual
   union select ''19266556'' bug_number, ''Public Sector Financials Recommended Patch Collection (RPC), Aug 2014'' bug_description from dual
	 ) b
	where a.bug_number (+) = b.bug_number
	group by b.bug_number, b.bug_description, a.creation_date
	order by to_number(b.bug_number)',
	'EBS/Procurement/PSA/SLA Code Level for 12.0',
   'RS',
   'Review the list for Procurement Family Pack status',
   '<ul>
	  <li>Review Procurement Family Patch Release History (Including Latest Available Rollups) [222339.1]</li>
      <li>Apply the latest Patch Collection or Family Pack</li>
	  </ul>',
   'Found no patch collection applied for Code level 12.0',
   'ALWAYS',
   'I');

	
  ------------------------------------
  -- POENC All Setup Details
  ------------------------------------
  
  -- Profile Options setup.
  -- Display only site level setting for now.
  -- Will ADD code TO VALIDATE profile OPTIONS AND BCG at a later revision.  
  l_info.delete;  
  add_signature(
   'PROFILE_OPTIONS_SETUP',
   'SELECT p.profile_option_name SHORT_NAME,
	  n.user_profile_option_name NAME,
	  v.profile_option_value "SITE VALUE"
	FROM fnd_profile_options p,
	  fnd_profile_option_values v,
	  fnd_profile_options_tl n
	WHERE p.profile_option_id  = v.profile_option_id (+)
	AND p.profile_option_name  = n.profile_option_name
	AND v.LEVEL_ID             = 10001
	AND n.language             = ''US''
	AND p.profile_option_name IN (''PO_VALIDATE_GL_PERIOD'', ''PO_REQAPPR_OVERRIDE_FUNDS'', ''PO_AUTOCREATE_DATE'', ''PO_GL_DATE'', ''FV_ENABLED'', ''BUDGETARY_CONTROL_OPTION'', ''PSA_R12_UPGRADE_DATE'')
	ORDER BY n.user_profile_option_name',
	'Profile Options Setup at Site level',
	'RS',
	'Profile Options setup at Site level',
	'<ul>
		<li>Review [1497200.1] for profile option PO:Validate GL Period for additional information</li>
		<li>Review [460999.1] for profile option PO:Override Funds Reservation for additional information</li>
		<li>Review [144960.1] for profile option PO: AutoCreate GL Date Option for additional information</li>
		<li>Review [297949.1] for profile option Budgetary Control Groups for additional information</li>
		<li>In a US Federal enabled environment, profile option FV: Federal Enabled must be set to Yes. Otherwise, set it to No</li>
	</ul>',
   '<ul>
      <li>No Data Found for Profile Option Setup</li>
    </ul>',
	'ALWAYS',
	'I'); 

  -- Ledger setup 
  l_info.delete;  
  add_signature(
   'LEDGER_SETUP',
   'SELECT gl.ledger_id,
	  gl.name ledger_name,
	  gl.description,
	  gl.ledger_category_code,
	  gl.sla_accounting_method_code "SLAM",
	  gl.currency_code,
	  id_flex_structure_name chart_of_accounts,
	  gl.period_set_name accounting_calendar,
	  gl.future_enterable_periods_limit future_enterable_periods,
	  gl.enable_budgetary_control_flag enable_budgetary_control,
	  gl.res_encumb_code_combination_id RFE_CCID,
	  gl.require_budget_journals_flag require_budget_journal,
	  gl.bal_seg_column_name balance_segment,
	  gl.latest_encumbrance_year latest_enc_year
	FROM gl_ledgers gl,
	  fnd_id_flex_structures_vl fnd_flex
	WHERE gl.CHART_OF_ACCOUNTS_ID = fnd_flex.ID_FLEX_NUM
	AND fnd_flex.ID_FLEX_CODE     = ''GL#''
	AND fnd_flex.APPLICATION_ID   = 101
	AND gl.LEDGER_ID              = ##$$LEDGERID$$##',
	'Primary Ledger Setup',
	'RS',
	'Review data for detail setup of the primary ledger',
	'<ul>
		<li>Review - R12: Accounting Setup Manager Concepts [462088.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for Primary Ledger Setup</li>
    </ul>',
	'ALWAYS',
	'I'); 

	-- Subledger Accounting Setup
	l_info.delete;  
	add_signature(
   'SUBLEDGER_ACCOUNTING_SETUP',
   'SELECT xamr.accounting_method_code SLAM,
	  DECODE (xamr.accounting_method_type_code,''S'', ''S-Oracle'',''C'', ''C-Custom'',xamr.accounting_method_type_code) "SLAM owner",
	  xamr.PRODUCT_RULE_CODE "Purchasing Product AAD",
	  DECODE(xamr.PRODUCT_RULE_TYPE_CODE ,''S'', ''S-Oracle'',''C'', ''C-Custom'',xamr.PRODUCT_RULE_TYPE_CODE) "AAD owner",
	  xpah.ENTITY_CODE entity_code,
	  xpah.EVENT_CLASS_CODE event_class_code,
	  xpah.EVENT_TYPE_CODE event_type_code,
	  DECODE( xpah.VALIDATION_STATUS_CODE,''Y'', ''Y-Valid'', ''R'', ''R-Validating'', ''N'', ''N-Invalid'', xpah.VALIDATION_STATUS_CODE) "Validation Status"
	FROM xla_acctg_method_rules xamr,
	  gl_ledgers gl,
	  xla_prod_acct_headers xpah
	WHERE xamr.accounting_method_code = gl.sla_accounting_method_code
	AND xamr.PRODUCT_RULE_CODE        = xpah.product_rule_code
	AND xamr.AMB_CONTEXT_CODE         = xpah.AMB_CONTEXT_CODE
	AND gl.LEDGER_ID                  = ##$$LEDGERID$$##
	AND xamr.application_id           = 201
	AND xamr.AMB_CONTEXT_CODE         = ''DEFAULT''',
	'Subledger Accounting Setup',
	'RS',
	'Review data for detail setup of the Purchasing Subledger Accounting',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for Subledger Accounting Setup</li>
    </ul>',
	'ALWAYS',
	'I'); 
	
	
	-- Current Budget for the Ledger
	l_info.delete;  
	add_signature(
   'GL_CURRENT_BUDGET',
   'SELECT * FROM GL_BUDGETS_V 
    WHERE LEDGER_ID = ##$$LEDGERID$$## 
    AND status = ''C''',
	'Current Budget Setup',
	'RS',
	'Found data for detail setup of the current budget',
	'<ul>
		<li>Review - Information Center: Using Oracle General Ledger [1489534.2] for more information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for Current Budget Setup</li>
    </ul>',
	'ALWAYS',
	'I'); 
	
	
	-- GL and PO period setup for 2 years
	-- including latest encumbrance year and the year before
	l_info.delete;  
  add_signature(
   'GL_PO_PERIODS_SETUP',
   'SELECT DECODE (application_id,101,''GL'',201,''PO'',application_id) application,
	  period_name "Period Name",
	  period_num "Period Number",
	  period_year "Fiscal Year",
	  start_date "Start Date",
	  end_date "End Date",
	  DECODE(closing_status,''O'', ''Open'', 
	  ''N'', ''Never Opened'', ''C'', ''Closed'', 
	  ''F'', ''Future Entry'', ''P'', ''Permanently Closed'', closing_status) "Period Status"
	FROM GL_PERIOD_STATUSES
	WHERE application_id IN ( 201,101)
	AND ledger_id         = ##$$LEDGERID$$##
	AND period_year      IN ( ##$$ENCYEAR$$##, ##$$ENCYEAR$$##-1)
	ORDER BY application_id ASC,
	  period_year DESC,
	  period_num ASC',
	'GL and PO periods for latest two encumbrance years.',
	'RS',
	'Review data for detail status of the PO and GL periods.',
	'<ul>
		<li>PO period must be opened for the encumbrance period</li>
		<li>GL period must also be opened if Profile Option PO: Validate GL Period = Yes.</li>
	</ul>',
   '<ul>
      <li>No Data Found for GL and PO period setup</li>
    </ul>',
	'ALWAYS',
	'I'); 
	
	-- Financials Options Setup
	l_info.delete;  
	add_signature(
   'FINANCIAL_OPTIONS_SETUP',
   'SELECT hr.name,
	  fsp.ORG_ID org_id,
	  fsp.SET_OF_BOOKS_ID SOB_ID,
	  fsp.INVENTORY_ORGANIZATION_ID,
	  fsp.REQ_ENCUMBRANCE_FLAG "Use Requisition Encumbrance",
	  fsp.RESERVE_AT_COMPLETION_FLAG "Reserve at Completion",
	  fsp.PURCH_ENCUMBRANCE_FLAG "Use PO Encumbrance",
	  fsp.REQ_ENCUMBRANCE_TYPE_ID req_encumbrance_type_id,
	  fsp.PURCH_ENCUMBRANCE_TYPE_ID po_encumbrance_type_id,
	  fsp.INV_ENCUMBRANCE_TYPE_ID
	FROM financials_system_params_all fsp,
	  hr_operating_units hr
	WHERE fsp.ORG_ID = hr.ORGANIZATION_ID
	AND org_id       = ##$$ORGID$$##',
	'Financial Options Setup',
	'RS',
	'Review data for detail setup of the Financial Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for financials options setup</li>
    </ul>',
	'ALWAYS',
	'I'); 
	
	-- Purchasing Options Setup
	l_info.delete;  
	add_signature(
   'PURCHASING_OPTIONS_SETUP',
   'SELECT hr.name,
	  psp.org_id,
	  psp.expense_accrual_code "Accrue Expense Items",
	  psp.inventory_accrual_code "Accrue Inventory Items",
	  psp.USER_DEFINED_PO_NUM_CODE "PO Number Entry Mode",
	  psp.MANUAL_PO_NUM_TYPE "PO Number Type",
	  psp.USER_DEFINED_REQ_NUM_CODE "Req Number Entry Mode",
	  psp.MANUAL_REQ_NUM_TYPE "Req Number Type"
	FROM po_system_parameters_all psp,
	  hr_operating_units hr
	WHERE psp.ORG_ID = hr.ORGANIZATION_ID
	AND psp.org_id   = ##$$ORGID$$##',
	'Purchasing Options Setup',
	'RS',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for purchasing options setup</li>
    </ul>',
	'ALWAYS',
	'I'); 
	
  ------------------------------------
  -- POENC Display PO Data
  ------------------------------------

  -- PO Header
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_HEADER',
   'SELECT *
    FROM po_headers_all
    WHERE po_header_id = ##$$HEADERID$$##',
   'PO Header Details',
   'NRS',
   'No document header found for this document',
	'<ul>
		<li>Verify that the document exists in this operating unit</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO Line
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_LINE',
   'SELECT *
    FROM po_lines_all
    WHERE po_header_id = ##$$HEADERID$$##
	AND po_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'PO Lines Details',
   'NRS',
   'No line found for this document',
	'<ul>
		<li>Verify that the document exists in this operating unit</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO Shipment
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_SHIPMENT',
   'SELECT *
    FROM po_line_locations_all
    WHERE po_header_id = ##$$HEADERID$$##
	AND po_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'PO Shipments Details',
   'NRS',
   'No shipment found for this document',
	'<ul>
		<li>Verify that the document exists in this operating unit</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO Distribution
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_DISTRIBUTION',
   'SELECT *
    FROM po_distributions_all
    WHERE po_header_id = ##$$HEADERID$$##
	AND po_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'PO Distribution Details',
   'NRS',
   'No distribution found for this document',
	'<ul>
		<li>Verify that the document exists in this operating unit</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   

  -- PO Action History
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_ACTION_HISTORY',
   'SELECT *
	FROM PO_ACTION_HISTORY
	WHERE OBJECT_ID          = ##$$HEADERID$$##
	AND OBJECT_TYPE_CODE     = ''PO''
	AND OBJECT_SUB_TYPE_CODE = ''STANDARD''
	ORDER BY sequence_num',
   'PO Action History Details',
   'NRS',
   'No Action History found for this document',
	'<ul>
		<li>Verify that the document has been approved or reserved at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
      

  -- PO Header Archive
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_HEADER_ARC',
   'SELECT *
    FROM po_headers_archive_all
    WHERE po_header_id = ##$$HEADERID$$##',
   'PO Header Archive Details',
   'NRS',
   'No document archive header found for this document',
	'<ul>
		<li>Verify that the document has been approved or communicated at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO Line Archive
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_LINE_ARC',
   'SELECT *
    FROM po_lines_archive_all
    WHERE po_header_id = ##$$HEADERID$$##
	AND po_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'PO Lines Archive Details',
   'NRS',
   'No line archive found for this document',
	'<ul>
		<li>Verify that the document has been approved or communicated at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO Shipment Archive
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_SHIPMENT_ARC',
   'SELECT *
    FROM po_line_locations_all
    WHERE po_header_id = ##$$HEADERID$$##
	AND po_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'PO Shipments Archive Details',
   'NRS',
   'No shipment archive found for this document',
	'<ul>
		<li>Verify that the document has been approved or communicated at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO Distribution Archive
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_DISTRIBUTION_ARC',
   'SELECT *
    FROM po_distributions_all
    WHERE po_header_id = ##$$HEADERID$$##
	AND po_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'PO Distribution Archive Details',
   'NRS',
   'No distribution archive found for this document',
	'<ul>
		<li>Verify that the document has been approved or communicated at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO - Backing Requisition Header
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_BREQ_HEADER',
   'SELECT prh.*
	FROM po_requisition_headers_all prh,
	  po_requisition_lines_all prl,
	  po_req_distributions_all prd,
	  po_distributions_all pod
	WHERE prh.requisition_header_id = prl.requisition_header_id
	AND prl.requisition_line_id     = prd.requisition_line_id
	AND prl.line_location_id        = pod.line_location_id
	AND pod.req_distribution_id     = prd.distribution_id 
	AND pod.po_line_id LIKE NVL(''##$$LINEID$$##'',''%'')
	AND pod.po_header_id = ##$$HEADERID$$##',
   'Backing Requisition Header Details',
   'NRS',
   'No backing requisition found for this document',
	'<ul>
		<li>Check if backing requisition exist for this document</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO - Backing Requisition Line
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_BREQ_LINE',
   'SELECT prh.segment1,
	  prl.line_num,
	  prl.*
	FROM po_requisition_headers_all prh,
	  po_requisition_lines_all prl,
	  po_req_distributions_all prd,
	  po_distributions_all pod
	WHERE prh.requisition_header_id = prl.requisition_header_id
	AND prl.requisition_line_id     = prd.requisition_line_id
	AND prl.line_location_id        = pod.line_location_id
	AND pod.req_distribution_id     = prd.distribution_id
	AND pod.po_line_id LIKE NVL(''##$$LINEID$$##'',''%'')
	AND pod.po_header_id = ##$$HEADERID$$##',
   'Backing Requisition Line Details',
   'NRS',
   'No backing requisition found for this document',
	'<ul>
		<li>Check if backing requisition exist for this document</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO - Backing Requisition Distribution
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_BREQ_DISTRIBUTION',
   'SELECT prh.segment1,
	  prl.line_num,
	  prd.distribution_num,
	  prd.*
	FROM po_requisition_headers_all prh,
	  po_requisition_lines_all prl,
	  po_req_distributions_all prd,
	  po_distributions_all pod
	WHERE prh.requisition_header_id = prl.requisition_header_id
	AND prl.requisition_line_id     = prd.requisition_line_id
	AND prl.line_location_id        = pod.line_location_id
	AND pod.req_distribution_id     = prd.distribution_id
	AND pod.po_line_id LIKE NVL(''##$$LINEID$$##'',''%'')
	AND pod.po_header_id = ##$$HEADERID$$##',
   'Backing Requisition Distribution Details',
   'NRS',
   'No backing requisition found for this document',
	'<ul>
		<li>Check if backing requisition exist for this document</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
  
  -- GL BC Packets
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_GL_BC_PACKETS',
   'SELECT *
	FROM GL_BC_PACKETS
	WHERE AE_HEADER_ID IN
	  (SELECT AE_HEADER_ID
	  FROM XLA_AE_HEADERS
	  WHERE EVENT_ID IN
		(SELECT DISTINCT AE_EVENT_ID
		FROM PO_BC_DISTRIBUTIONS
		WHERE JE_SOURCE_NAME = ''Purchasing''
		AND JE_CATEGORY_NAME = ''Purchases''
		AND HEADER_ID        = ##$$HEADERID$$##
		)
	  )',
   'PO GL BC Packets Details',
   'NRS',
   'Found no GL BC Packets detail found for this document',
	'<ul>
		<li>This is a normal condition. The data is for display purpose only</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');

  
  -- PO BC Distributions
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_BC_DISTRIBUTIONS',
   'SELECT *
	FROM PO_BC_DISTRIBUTIONS
	WHERE JE_SOURCE_NAME = ''Purchasing''
	AND JE_CATEGORY_NAME = ''Purchases''
	AND HEADER_ID        = ##$$HEADERID$$##',
   'PO BC Distributions Details',
   'NRS',
   'Found no budgetary control distribution for this document',
	'<ul>
		<li>Verify that the document is created after upgrade date, or the document has been reserved at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'W',
   'RS');
   
  -- Backing Req PO BC Distributions
  l_info.delete;
  add_signature(
   'DOC_DETAIL_BREQ_PO_BC_DISTRIBUTIONS',
   'SELECT *
	FROM PO_BC_DISTRIBUTIONS
	WHERE JE_SOURCE_NAME = ''Purchasing''
	AND JE_CATEGORY_NAME = ''Requisitions''
	AND HEADER_ID       IN
	  (SELECT distinct(prl.requisition_header_id)
	  FROM po_requisition_lines_all prl,
		po_req_distributions_all prd,
		po_distributions_all pod
	  WHERE prl.requisition_line_id = prd.requisition_line_id
	  AND prl.line_location_id      = pod.line_location_id
	  AND pod.req_distribution_id   = prd.distribution_id
	  AND pod.po_line_id LIKE NVL(''##$$LINEID$$##'',''%'')
	  AND pod.po_header_id = ##$$HEADERID$$##
	  )',
   'Backing Requisition PO BC Distributions Details',
   'NRS',
   'Found no backing requisition budgetary control distributions for this document',
	'<ul>
		<li>Verify that the document has a backing requisition</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO XLA Events
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_XLA_EVENTS',
   'SELECT *
	FROM XLA_EVENTS
	WHERE EVENT_ID IN
	  (SELECT DISTINCT AE_EVENT_ID
	  FROM PO_BC_DISTRIBUTIONS
	  WHERE JE_SOURCE_NAME = ''Purchasing''
	  AND JE_CATEGORY_NAME = ''Purchases''
	  AND HEADER_ID        = ##$$HEADERID$$##
	  )',
   'XLA Events Details for PO',
   'NRS',
   'No Encumbrance events found for this document',
	'<ul>
		<li>Verify that the document is created after upgrade date, or the document has been reserved at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO XLA_AE_HEADERS
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_XLA_AE_HEADERS',
   'SELECT *
	FROM XLA_AE_HEADERS
	WHERE EVENT_ID IN
	  (SELECT DISTINCT AE_EVENT_ID
	  FROM PO_BC_DISTRIBUTIONS
	  WHERE JE_SOURCE_NAME = ''Purchasing''
	  AND JE_CATEGORY_NAME = ''Purchases''
	  AND HEADER_ID        = ##$$HEADERID$$##
	  )',
   'XLA AE Headers Details for PO',

   'NRS',
   'No XLA AE Headers data found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');

  -- PO XLA_AE_LINES
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_XLA_AE_LINES',
   'SELECT *
	FROM XLA_AE_LINES
	WHERE AE_HEADER_ID IN
	  (SELECT AE_HEADER_ID
	  FROM XLA_AE_HEADERS
	  WHERE EVENT_ID IN
		(SELECT DISTINCT AE_EVENT_ID
		FROM PO_BC_DISTRIBUTIONS
		WHERE JE_SOURCE_NAME = ''Purchasing''
		AND JE_CATEGORY_NAME = ''Purchases''
		AND HEADER_ID        = ##$$HEADERID$$##
		)
	  )',
   'XLA AE Lines Details for PO',
   'NRS',
   'No XLA AE Lines data found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO XLA_TRANSACTION_ENTITIES_UPG
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_XLA_TRXN_ENT_UPG',
   'SELECT *
	FROM XLA_TRANSACTION_ENTITIES_UPG
	WHERE ENTITY_ID IN
	  (SELECT DISTINCT ENTITY_ID
	  FROM XLA_EVENTS
	  WHERE EVENT_ID IN
		(SELECT DISTINCT AE_EVENT_ID
		FROM PO_BC_DISTRIBUTIONS
		WHERE JE_SOURCE_NAME = ''Purchasing''
		AND JE_CATEGORY_NAME = ''Purchases''
		AND HEADER_ID        = ##$$HEADERID$$##
		)
	  )',
   'XLA Transaction Entities Upg Details for PO',
   'NRS',
   'No XLA Transaction Entities Upg details found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO XLA_DISTRIBUTION_LINKS
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_XLA_DIST_LINKS',
   'SELECT *
	FROM XLA_DISTRIBUTION_LINKS
	WHERE EVENT_ID IN
	  (SELECT DISTINCT AE_EVENT_ID
	  FROM PO_BC_DISTRIBUTIONS
	  WHERE JE_SOURCE_NAME = ''Purchasing''
	  AND JE_CATEGORY_NAME = ''Purchases''
	  AND HEADER_ID        = ##$$HEADERID$$##
	  )',
   'XLA Distribution Links Details for PO',
   'NRS',
   'No XLA Distribution Links details found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- PO PSA_XLA_ACCOUNTING_ERRORS
  l_info.delete;
  add_signature(
   'DOC_DETAIL_PO_PSA_XLA_ACCT_ERRORS',
   'SELECT *
	FROM PSA_XLA_ACCOUNTING_ERRORS
	WHERE APPLICATION_ID = 201
	AND ENTITY_CODE      = ''PURCHASE_ORDER''
	AND SOURCE_ID_INT_1  = ##$$HEADERID$$##',
   'PSA XLA Accounting Errors Details for PO',
   'RS',
   'PSA XLA Accounting Errors details found for this document',
	'<ul>
		<li>Review the errors and encumbrance accounting detail section for more information</li>
	</ul>',
	'<ul>
		<li>No error found</li>
	</ul>',
   'ALWAYS',
   'W',
   'RS');
   
  ------------------------------------
  -- POENC Display REQ Data
  ------------------------------------

  -- REQ Header
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_HEADER',
   'SELECT *
    FROM po_requisition_headers_all
    WHERE requisition_header_id = ##$$HEADERID$$##',
   'Requisition Header Details',
   'NRS',
   'No document header found for this document',
	'<ul>
		<li>Verify that the document exists in this operating unit</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- REQ Line
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_LINE',
   'SELECT *
    FROM po_requisition_lines_all
    WHERE requisition_header_id = ##$$HEADERID$$##
	AND requisition_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'Requisition Lines Details',
   'NRS',
   'No line found for this document',
	'<ul>
		<li>Verify that the document exists in this operating unit</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  
  -- REQ Distribution
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_DISTRIBUTION',
   'SELECT *
	FROM po_req_distributions_all
	WHERE requisition_line_id IN
	  (SELECT requisition_line_id
	  FROM po_requisition_lines_all
	  WHERE requisition_header_id = ##$$HEADERID$$##)
	AND requisition_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'Requisition Distribution Details',
   'NRS',
   'No distribution found for this document',
	'<ul>
		<li>Verify that the document exists in this operating unit</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   

  -- REQ Action History
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_ACTION_HISTORY',
   'SELECT *
	FROM PO_ACTION_HISTORY
	WHERE OBJECT_ID          = ##$$HEADERID$$##
	AND OBJECT_TYPE_CODE     = ''REQUISITION''
	ORDER BY sequence_num',
   'Requisition Action History Details',
   'NRS',
   'No Action History found for this document',
	'<ul>
		<li>Verify that the document has been approved or reserved at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');

   -- Associated PO Header
  l_info.delete;
  add_signature(
   'DOC_DETAIL_ASSOC_PO_HEADER',
   'SELECT poh.*
	FROM po_headers_all poh,
	  po_lines_all pol,
	  po_line_locations_all poll,
	  po_requisition_headers_all porh,
	  po_requisition_lines_all porl
	WHERE porh.requisition_header_id = porl.requisition_header_id
	AND porl.line_location_id        = poll.line_location_id
	AND poh.po_header_id             = pol.po_header_id
	AND pol.po_line_id               = poll.po_line_id
	AND porh.requisition_header_id   = ##$$HEADERID$$##
	AND porl.requisition_line_id LIKE NVL(''##$$LINEID$$##'',''%'')',
   'Associated PO Header Details',
   'NRS',
   'Associated PO header not found for this document',
	'<ul>
		<li>Verify that this requisition does not have an associated Purchase Order</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
   
   -- Associated PO Line
  l_info.delete;
  add_signature(
   'DOC_DETAIL_ASSOC_PO_LINE',
   'SELECT pol.*
	FROM po_headers_all poh,
	  po_lines_all pol,
	  po_line_locations_all poll,
	  po_requisition_headers_all porh,
	  po_requisition_lines_all porl
	WHERE porh.requisition_header_id = porl.requisition_header_id
	AND porl.line_location_id        = poll.line_location_id
	AND poh.po_header_id             = pol.po_header_id
	AND pol.po_line_id               = poll.po_line_id
	AND porh.requisition_header_id   = ##$$HEADERID$$##
		AND porl.requisition_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'Assoicated PO Lines Details',
   'NRS',
   'Associated PO line not found for this documentt',
	'<ul>
		<li>Verify that this requisition does not have an associated Purchase Order</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
   -- Associated PO Shipment
  l_info.delete;
  add_signature(
   'DOC_DETAIL_ASSOC_PO_SHIPMENT',
   'SELECT poll.*
	FROM po_headers_all poh,
	  po_lines_all pol,
	  po_line_locations_all poll,
	  po_requisition_headers_all porh,
	  po_requisition_lines_all porl
	WHERE porh.requisition_header_id = porl.requisition_header_id
	AND porl.line_location_id        = poll.line_location_id
	AND poh.po_header_id             = pol.po_header_id
	AND pol.po_line_id               = poll.po_line_id
	AND porh.requisition_header_id   = ##$$HEADERID$$##
	AND porl.requisition_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'Assoicated PO Shipment Details',
   'NRS',
   'Associated PO shipment not found for this documentt',
	'<ul>
		<li>Verify that this requisition does not have an associated Purchase Order</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');

   
   -- Associated PO Distribution
  l_info.delete;
  add_signature(
   'DOC_DETAIL_ASSOC_PO_DIST',
   'SELECT pod.*
	FROM po_headers_all poh,
	  po_lines_all pol,
	  po_line_locations_all poll,
	  po_requisition_headers_all porh,
	  po_requisition_lines_all porl,
	  po_req_distributions_all pord,
	  po_distributions_all pod
	WHERE porh.requisition_header_id = porl.requisition_header_id
	AND porl.line_location_id        = poll.line_location_id
	AND porl.requisition_line_id     = pord.requisition_line_id
	AND poh.po_header_id             = pol.po_header_id
	AND pol.po_line_id               = poll.po_line_id
	AND poll.line_location_id        = pod.line_location_id
	AND porh.requisition_header_id   = ##$$HEADERID$$##
	AND porl.requisition_line_id    like NVL(''##$$LINEID$$##'',''%'')',
   'Assoicated PO Distribution Details',
   'NRS',
   'Associated PO distribution not found for this documentt',
	'<ul>
		<li>Verify that this requisition does not have an associated Purchase Order</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- REQ GL BC Packets
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_GL_BC_PACKETS',
   'SELECT *
	FROM GL_BC_PACKETS
	WHERE AE_HEADER_ID IN
	  (SELECT AE_HEADER_ID
	  FROM XLA_AE_HEADERS
	  WHERE EVENT_ID IN
		(SELECT DISTINCT AE_EVENT_ID
		FROM PO_BC_DISTRIBUTIONS
		WHERE JE_SOURCE_NAME = ''Purchasing''
		AND JE_CATEGORY_NAME = ''Requisitions''
		AND HEADER_ID        = ##$$HEADERID$$##
		)
	  )',
   'Requisition GL BC Packets Details',
   'NRS',
   'No GL BC Packets found for this document',
	'<ul>
		<li>This is a normal condition. The data is for display purpose only</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');      
  
  -- REQ BC Distributions
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_PO_BC_DISTRIBUTIONS',
   'SELECT *
	FROM PO_BC_DISTRIBUTIONS
	WHERE JE_SOURCE_NAME = ''Purchasing''
	AND JE_CATEGORY_NAME = ''Requisitions''
	AND HEADER_ID        = ##$$HEADERID$$##',
   'Requisition PO BC Distributions Details',
   'NRS',
   'No budgetary control distribution found for this document',
	'<ul>
		<li>Verify that the document is created after upgrade date, or the document has been reserved at least once</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'W',
   'RS');
   
  -- REQ XLA Events
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_XLA_EVENTS',
   'SELECT *
	FROM XLA_EVENTS
	WHERE EVENT_ID IN
	  (SELECT DISTINCT AE_EVENT_ID
	  FROM PO_BC_DISTRIBUTIONS
	  WHERE JE_SOURCE_NAME = ''Purchasing''
	  AND JE_CATEGORY_NAME = ''Requisitions''
	  AND HEADER_ID        = ##$$HEADERID$$##
	  )',
   'XLA Events Details',
   'NRS',
   'No Encumbrance events found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- REQ XLA_AE_HEADERS
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_XLA_AE_HEADERS',
   'SELECT *
	FROM XLA_AE_HEADERS
	WHERE EVENT_ID IN
	  (SELECT DISTINCT AE_EVENT_ID
	  FROM PO_BC_DISTRIBUTIONS
	  WHERE JE_SOURCE_NAME = ''Purchasing''
	  AND JE_CATEGORY_NAME = ''Requisitions''
	  AND HEADER_ID        = ##$$HEADERID$$##
	  )',
   'XLA AE Headers Details',
   'NRS',
   'No XLA AE Headers data found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');

  -- REQ XLA_AE_LINES
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_XLA_AE_LINES',
   'SELECT *
	FROM XLA_AE_LINES
	WHERE AE_HEADER_ID IN
	  (SELECT AE_HEADER_ID
	  FROM XLA_AE_HEADERS
	  WHERE EVENT_ID IN
		(SELECT DISTINCT AE_EVENT_ID
		FROM PO_BC_DISTRIBUTIONS
		WHERE JE_SOURCE_NAME = ''Purchasing''
		AND JE_CATEGORY_NAME = ''Requisitions''
		AND HEADER_ID        = ##$$HEADERID$$##
		)
	  )',
   'XLA AE Lines Details',
   'NRS',
   'No XLA AE Lines data found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- REQ XLA_TRANSACTION_ENTITIES_UPG
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_XLA_TRXN_ENT_UPG',
   'SELECT *
	FROM XLA_TRANSACTION_ENTITIES_UPG
	WHERE ENTITY_ID IN
	  (SELECT DISTINCT ENTITY_ID
	  FROM XLA_EVENTS
	  WHERE EVENT_ID IN
		(SELECT DISTINCT AE_EVENT_ID
		FROM PO_BC_DISTRIBUTIONS
		WHERE JE_SOURCE_NAME = ''Purchasing''
		AND JE_CATEGORY_NAME = ''Requisitions''
		AND HEADER_ID        = ##$$HEADERID$$##
		)
	  )',
   'XLA Transaction Entities Upg Details',
   'NRS',
   'No XLA Transaction Entities Upg details found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- REQ XLA_DISTRIBUTION_LINKS
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_XLA_DIST_LINKS',
   'SELECT *
	FROM XLA_DISTRIBUTION_LINKS
	WHERE EVENT_ID IN
	  (SELECT DISTINCT AE_EVENT_ID
	  FROM PO_BC_DISTRIBUTIONS
	  WHERE JE_SOURCE_NAME = ''Purchasing''
	  AND JE_CATEGORY_NAME = ''Requisitions''
	  AND HEADER_ID        = ##$$HEADERID$$##
	  )',
   'XLA Distribution Links Details for PO',
   'NRS',
   'No XLA Distribution Links details found for this document',
	'<ul>
		<li>Verify that Create Accounting concurrent program has been run after encumbrance activity</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'I',
   'RS');
   
  -- REQ PSA_XLA_ACCOUNTING_ERRORS
  l_info.delete;
  add_signature(
   'DOC_DETAIL_REQ_PSA_XLA_ACCT_ERRORS',
   'SELECT *
	FROM PSA_XLA_ACCOUNTING_ERRORS
	WHERE APPLICATION_ID = 201
	AND ENTITY_CODE      = ''REQUISITION''
	AND SOURCE_ID_INT_1  = ##$$HEADERID$$##',
   'PSA XLA Accounting Errors Details',
   'RS',
   'PSA XLA Accounting Errors details found for this document',
	'<ul>
		<li>Review the errors and health check detail section for the document</li>
	</ul>',
	'<ul>
		<li>Found record for the document</li>
	</ul>',
   'ALWAYS',
   'W',
   'RS');

	-------------------------------------------
	-- POENC Encumbrance Accounting 
	-------------------------------------------
  
	-------------------------------------
	-- POENC PO specific checks
	-------------------------------------

  -- PO pre-approved or In Process
  l_info.delete;
  add_signature(
   'PO_PRE_APPROVED_OR_IN_PROCESS',
   'SELECT DECODE(NVL(h.segment1,''$$$''),''$$$'', ''Purchase Order'') "Document Type",
	  h.segment1 "Document Number",
	  h.org_id "Org_Id",
	  h.authorization_status "Authorization Status"
	FROM po_headers_all h
	WHERE h.authorization_status IN ( ''IN PROCESS'', ''PRE-APPROVED'')
	AND po_header_id  = ##$$HEADERID$$##',
   'Pre-Approved or In Process Document Status Check',
   'RS',
   'Found the document is in Pre-Approved or In Process status',
   '<ul>
		<li>First, try to the following steps as detailed in [461104.1]:</li>
		<ol>
		<li>Navigate to PO Summary form and query PO.</li>
		<li>Go to Inquire/View Action History. The last action sequence should show a blank action. Note the employee name next to this blank action.</li>
		<li>Employee from #2 should log into application and go to Notification Summary screen.</li>
		<li>There should be an Unable to Reserve notification. Open this and select Return to Preparer.</li>
		<li>PO status is set to Rejected and system should allow the needed changes to be made.</li>
		</ol>
		<li>Alternatively, locate [390023.1] and follow reset script instruction.</li>
	</ul>',
   '<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
  
  -- PO pre-approved not enough funds
  l_info.delete;
  add_signature(
   'PO_PRE_APPROVED_NO_FUNDS',
   'SELECT d.po_header_id,
	  d.po_line_id,
	  d.line_location_id,
	  d.po_Distribution_Id,
	  h.segment1 "PO number",
	  pll.line_num,
	  l.shipment_num,
	  d.distribution_num,
	  h.authorization_status,
  	  DECODE( pll.matching_basis, 
		''AMOUNT'', ROUND((NVL(d.amount_ordered,0)+NVL(D.NONRECOVERABLE_TAX,0)) * NVL(D.RATE,1), ##$$CURRPRE$$##), 
		ROUND(L.PRICE_OVERRIDE * D.QUANTITY_ORDERED * NVL(D.RATE,1) +(NVL(D.NONRECOVERABLE_TAX,0)*NVL(D.rate,1)), ##$$CURRPRE$$##) 
		) "Amount To Reserve",
	  psg.INDEX_NUM1 "Funds Available",
	  d.Budget_Account_Id,
	  SUBSTR(gcc.concatenated_segments,1,50) budget_account,
	  d.Encumbered_Amount,
	  psg.char1 amount_type,
	  DECODE(psg.char5, ''D'', ''D-Advisory'', ''B'', ''B-Absolute'', ''N'', ''N-None'', ''Z'',''Z-Not-Specified'',psg.char5) "Funds Check Level",
	  pll.matching_basis,
	  l.closed_code,
	  L.PRICE_OVERRIDE,
	  d.quantity_ordered,
	  d.amount_ordered,
	  d.quantity_cancelled,
	  d.amount_cancelled,
	  d.quantity_billed,
	  d.amount_billed,	  
	  h.org_id,
	  l.Shipment_Type,
	  l.Cancel_Flag,
	  d.Accrue_On_Receipt_Flag,
	  d.gl_Encumbered_Date,
	  d.gl_encumbered_period_name,
	  D.NONRECOVERABLE_TAX,
	  D.rate,
	  d.encumbered_flag,
	  d.Prevent_Encumbrance_Flag
	FROM PO_lINE_lOCATIONS_ALL l,
	  PO_DISTRIBUTIONS_ALL d,
	  PO_HEADERS_ALL h,
	  PO_LINES_ALL pll,
	  gl_code_combinations_kfv gcc,
	  po_session_gt psg
	WHERE l.Line_Location_Id                = d.Line_Location_Id
	AND h.po_header_id                      = d.po_header_id
	AND pll.po_line_id                      = l.po_line_id
	AND TO_CHAR(d.PO_DISTRIBUTION_ID)       = psg.index_char2
	AND psg.INDEX_CHAR1                     = ''PO_CALC_FUNDS''
	AND NVL(l.approved_flag, ''N'')          <> ''Y''
	AND NVL(l.Cancel_Flag,''N'')              = ''N''
	AND NVL(l.Closed_Code,''OPEN'')          <> ''FINALLY CLOSED''
	AND NVL(d.Prevent_Encumbrance_Flag,''N'') = ''N''
	AND d.Ussgl_Transaction_Code           IS NULL
	AND d.Budget_Account_id                IS NOT NULL
	AND gcc.code_combination_id             = d.budget_account_id
	AND h.AUTHORIZATION_STATUS              = ''PRE-APPROVED''
	AND h.po_Header_Id                      = ##$$HEADERID$$##
	AND h.org_id                            = ##$$ORGID$$##
	AND l.Shipment_Type                     IN (''SCHEDULED'', ''STANDARD'', ''BLANKET'')
	AND DECODE( pll.matching_basis, 
		''AMOUNT'', ROUND((NVL(d.amount_ordered,0)+NVL(D.NONRECOVERABLE_TAX,0)) * NVL(D.RATE,1), ##$$CURRPRE$$##), 
		ROUND(L.PRICE_OVERRIDE * D.QUANTITY_ORDERED * NVL(D.RATE,1) +(NVL(D.NONRECOVERABLE_TAX,0)*NVL(D.rate,1)), ##$$CURRPRE$$##) 
		) > psg.INDEX_NUM1',
   'Pre-Approved Status - Not Sufficient Funds Check',
   'RS',
   'Found that the document is in Pre-Approved because there is not enough funds',
   '<ul>
		<ol>
		<li>Ensure there is enough funds for the account for the period</li>
		<li>Check the account Funds Check Level. There must be sufficient funds when the level is set to Absolute</li>
		<li>Enter a manual journal account in GL to see if the funds check is passed</li>
		</ol>
	</ul>',
   '<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
  -- PO Incorrect Encumbered Value
  l_info.delete;
  add_signature(
   'PO_ACTIVE_ENC_WRONG_ENC_AMOUNT',
   '/* Finally Closed PO */
	SELECT d.po_header_id,
	  d.po_line_id,
	  d.line_location_id,
	  d.po_Distribution_Id,
	  h.authorization_status,
	  pll.matching_basis,
	  l.closed_code,
	  d.quantity_ordered,
	  d.amount_ordered,
	  d.quantity_cancelled,
	  d.amount_cancelled,
	  d.quantity_billed,
	  d.amount_billed,
	  d.Budget_Account_Id,
	  DECODE( pll.matching_basis, 
		''AMOUNT'',
		/*CALCULATION OF ENC AMOUNT FOR AMOUNT BASED LINES--------START*/
		ROUND( 
		  DECODE( 
			d.Accrue_On_Receipt_Flag,
			''N'',Least((NVL(d.amount_Ordered,0)-NVL(d.amount_cancelled,0)),NVL(d.amount_Billed,0)),
			''Y'',Least(NVL(d.Amount_Ordered,0),NVL(d.Amount_Delivered,0)) 
			) * NVL(d.Rate,1) 
			+ 
		  NVL(d.NonRecoverable_Tax,0) * NVL(d.Rate,1) * 
		  DECODE(d.Accrue_On_Receipt_Flag, 
			''N'',Least( (NVL(d.Amount_Ordered,0)-NVL(d.amount_cancelled,0)),NVL(d.Amount_Billed,0)), 
			''Y'',Least(NVL(d.Amount_Ordered,0),NVL(d.Amount_Delivered,0)) 
			) / DECODE (d.Amount_Ordered,0,1,d.Amount_Ordered), ##$$CURRPRE$$##
		  ) ,
		/*CALCULATION OF ENC AMOUNT FOR AMOUNT BASED LINES--------END*/  
		/*CALCULATION OF ENC AMOUNT FOR non AMOUNT BASED LINES--------START*/
		ROUND( 
		  l.Price_Override * 
		  DECODE( 
			d.Accrue_On_Receipt_Flag, 
			''N'',Least((d.Quantity_Ordered-d.quantity_cancelled),NVL(d.Quantity_Billed,0)), 
			''Y'',Least(d.Quantity_Ordered,NVL(d.Quantity_Delivered,0)) 
			) * NVL(d.Rate,1) 
			+ 
		  NVL(d.NonRecoverable_Tax,0) * NVL(d.Rate,1) * 
		  DECODE(
			d.Accrue_On_Receipt_Flag, 
			''N'',Least((d.Quantity_Ordered-d.quantity_cancelled),NVL(d.Quantity_Billed,0)), 
			''Y'',Least(d.Quantity_Ordered,NVL(d.Quantity_Delivered,0)) 
			) / DECODE(d.Quantity_Ordered,0,1,d.Quantity_Ordered), ##$$CURRPRE$$##)
		 /*CALCULATION OF ENC AMOUNT FOR non AMOUNT BASED LINES--------END*/
	  ) correct_encumbered_amount,
	  d.Encumbered_Amount,
	  po_inq_sv.get_active_enc_amount(NVL(d.rate,1),NVL(d.encumbered_amount,0),l.shipment_type,d.po_distribution_id) AS active_encumbrance,
	  h.org_id,
	  h.segment1,
	  l.Shipment_Type,
	  l.Cancel_Flag,
	  d.Accrue_On_Receipt_Flag,
	  d.gl_Encumbered_Date
	FROM PO_lINE_lOCATIONS_ALL l,
	  PO_DISTRIBUTIONS_ALL d,
	  PO_HEADERS_ALL h,
	  PO_LINES_ALL pll
	WHERE l.Line_Location_Id                = d.Line_Location_Id
	AND h.po_Header_Id                      = d.po_Header_Id
	AND pll.po_line_id                      = l.po_line_id
	AND NVL(l.Approved_Flag,''N'')            = ''Y''
	AND NVL(l.Closed_Code,''OPEN'')           = ''FINALLY CLOSED''
	AND NVL(d.Prevent_Encumbrance_Flag,''N'') = ''N''
	AND d.Ussgl_Transaction_Code           IS NULL
	AND d.Budget_Account_id                IS NOT NULL
	AND h.po_Header_Id                      = ##$$HEADERID$$##
	AND h.org_id                            = ##$$ORGID$$##
	AND l.Shipment_Type IN (''SCHEDULED'', ''STANDARD'', ''BLANKET'')
	AND
	  DECODE( pll.matching_basis, 
		''AMOUNT'',
		/*CALCULATION OF ENC AMOUNT FOR AMOUNT BASED LINES--------START*/
		ROUND( 
		  DECODE( 
			d.Accrue_On_Receipt_Flag,
			''N'',Least((NVL(d.amount_Ordered,0)-NVL(d.amount_cancelled,0)),NVL(d.amount_Billed,0)),
			''Y'',Least(NVL(d.Amount_Ordered,0),NVL(d.Amount_Delivered,0)) 
			) * NVL(d.Rate,1) 
			+ 
		  NVL(d.NonRecoverable_Tax,0) * NVL(d.Rate,1) * 
		  DECODE(d.Accrue_On_Receipt_Flag, 
			''N'',Least( (NVL(d.Amount_Ordered,0)-NVL(d.amount_cancelled,0)),NVL(d.Amount_Billed,0)), 
			''Y'',Least(NVL(d.Amount_Ordered,0),NVL(d.Amount_Delivered,0)) 
			) / DECODE (d.Amount_Ordered,0,1,d.Amount_Ordered), ##$$CURRPRE$$##
		  ) ,
		/*CALCULATION OF ENC AMOUNT FOR AMOUNT BASED LINES--------END*/  
		/*CALCULATION OF ENC AMOUNT FOR non AMOUNT BASED LINES--------START*/
		ROUND( 
		  l.Price_Override * 
		  DECODE( 
			d.Accrue_On_Receipt_Flag, 
			''N'',Least((d.Quantity_Ordered-d.quantity_cancelled),NVL(d.Quantity_Billed,0)), 
			''Y'',Least(d.Quantity_Ordered,NVL(d.Quantity_Delivered,0)) 
			) * NVL(d.Rate,1) 
			+ 
		  NVL(d.NonRecoverable_Tax,0) * NVL(d.Rate,1) * 
		  DECODE(
			d.Accrue_On_Receipt_Flag, 
			''N'',Least((d.Quantity_Ordered-d.quantity_cancelled),NVL(d.Quantity_Billed,0)), 
			''Y'',Least(d.Quantity_Ordered,NVL(d.Quantity_Delivered,0)) 
			) / DECODE(d.Quantity_Ordered,0,1,d.Quantity_Ordered), ##$$CURRPRE$$##)
		 /*CALCULATION OF ENC AMOUNT FOR non AMOUNT BASED LINES--------END*/
	  ) <> d.Encumbered_Amount

	UNION

	/* Canceled PO */
	SELECT d.po_header_id,
	  d.po_line_id,
	  d.line_location_id,
	  d.po_Distribution_Id,
	  h.authorization_status,
	  pll.matching_basis,
	  l.closed_code,
	  d.quantity_ordered,
	  d.amount_ordered,
	  d.quantity_cancelled,
	  d.amount_cancelled,
	  d.quantity_billed,
	  d.amount_billed,
	  d.Budget_Account_Id,
	  DECODE( pll.matching_basis, 
		''AMOUNT'',
		/***********ENC CALCULATION FOR AMOUNT BASED LINES***************/
		ROUND( 
		  Least( 
			d.amount_Ordered, 
			DECODE(d.accrue_on_receipt_flag, 
			  ''Y'',NVL(d.amount_delivered,0), 
			  (NVL(d.amount_Ordered,0) - NVL(d.amount_cancelled,0)))) 
		  * NVL(d.rate,1) 
		  * (1 + (NVL(d.nonrecoverable_tax,0) / DECODE(d.amount_Ordered,0,1,d.amount_ordered))), 
		##$$CURRPRE$$##) ,
		/*************ENC CALCULATION FOR AMOUNT BASED LINES END************/
		/********ENC CALCULATION FOR NON AMOUNT BASED LINES**************/
		ROUND( 
		  Least(d.quantity_ordered, 
		  DECODE(d.accrue_on_receipt_flag, 
			''Y'',NVL(d.quantity_delivered,0), 
			(NVL(d.quantity_ordered,0) - NVL(d.quantity_cancelled,0))) ) 
		  * NVL(d.rate,1) 
		  * (l.price_override + (NVL(d.nonrecoverable_tax,0) 
			/ DECODE (d.Quantity_Ordered,0,1,d.Quantity_Ordered))), 
		##$$CURRPRE$$##)
		/********ENC CALCULATION FOR NON AMOUNT BASED LINES END**************/
	  ) Correct_Encumbered_amount,
	  d.Encumbered_Amount,
	  po_inq_sv.get_active_enc_amount(NVL(d.rate,1),NVL(d.encumbered_amount,0),l.shipment_type,d.po_distribution_id) AS active_encumbrance,
	  h.org_id,
	  h.segment1,
	  l.Shipment_Type,
	  l.Cancel_Flag,
	  d.Accrue_On_Receipt_Flag,
	  d.gl_Encumbered_Date
	FROM PO_lINE_lOCATIONS_ALL l,
	  PO_DISTRIBUTIONS_ALL d,
	  PO_HEADERS_ALL h,
	  PO_LINES_ALL pll
	WHERE l.Line_Location_Id                = d.Line_Location_Id
	AND h.po_Header_Id                      = d.po_Header_Id
	AND pll.po_line_id                      = l.po_line_id
	AND NVL(l.Approved_Flag,''N'')            = ''Y''
	AND NVL(l.Cancel_Flag,''N'')              = ''Y''
	AND NVL(l.Closed_Code,''OPEN'')          <> ''FINALLY CLOSED''
	AND NVL(d.Prevent_Encumbrance_Flag,''N'') = ''N''
	AND d.Ussgl_Transaction_Code           IS NULL
	AND d.Budget_Account_id                IS NOT NULL
	AND h.po_Header_Id                      = ##$$HEADERID$$##
	AND h.Org_Id                            = ##$$ORGID$$##
	AND l.Shipment_Type IN (''SCHEDULED'', ''STANDARD'', ''BLANKET'')
	AND DECODE( pll.matching_basis, 
		''AMOUNT'',
		/***********ENC CALCULATION FOR AMOUNT BASED LINES***************/
		ROUND( 
		  Least( 
			d.amount_Ordered, 
			DECODE(d.accrue_on_receipt_flag, 
			  ''Y'',NVL(d.amount_delivered,0), 
			  (NVL(d.amount_Ordered,0) - NVL(d.amount_cancelled,0)))) 
		  * NVL(d.rate,1) 
		  * (1 + (NVL(d.nonrecoverable_tax,0) / DECODE(d.amount_Ordered,0,1,d.amount_ordered))), 
		##$$CURRPRE$$##) ,
		/*************ENC CALCULATION FOR AMOUNT BASED LINES END************/
		/********ENC CALCULATION FOR NON AMOUNT BASED LINES**************/
		ROUND( 
		  Least(d.quantity_ordered, 
		  DECODE(d.accrue_on_receipt_flag, 
			''Y'',NVL(d.quantity_delivered,0), 
			(NVL(d.quantity_ordered,0) - NVL(d.quantity_cancelled,0))) ) 
		  * NVL(d.rate,1) 
		  * (l.price_override + (NVL(d.nonrecoverable_tax,0) 
			/ DECODE (d.Quantity_Ordered,0,1,d.Quantity_Ordered))), 
		##$$CURRPRE$$##)
		/********ENC CALCULATION FOR NON AMOUNT BASED LINES END**************/
	  ) <> d.Encumbered_Amount

	UNION

	/* Opened PO */
	SELECT d.po_header_id,
	  d.po_line_id,
	  d.line_location_id,
	  d.po_Distribution_Id,
	  h.authorization_status,
	  pll.matching_basis,
	  l.closed_code,
	  d.quantity_ordered,
	  d.amount_ordered,
	  d.quantity_cancelled,
	  d.amount_cancelled,
	  d.quantity_billed,
	  d.amount_billed,
	  d.Budget_Account_Id,
	  DECODE( pll.matching_basis, 
		''AMOUNT'', 
		ROUND((NVL(d.amount_ordered,0)+NVL(D.NONRECOVERABLE_TAX,0)) * NVL(D.RATE,1), ##$$CURRPRE$$##), 
		ROUND(L.PRICE_OVERRIDE * D.QUANTITY_ORDERED * NVL(D.RATE,1) +(NVL(D.NONRECOVERABLE_TAX,0)*NVL(D.rate,1)), ##$$CURRPRE$$##) 
	  ) AS CORRECT_ENCUMBERED_AMOUNT,
	  d.Encumbered_Amount,
	  po_inq_sv.get_active_enc_amount(NVL(d.rate,1),NVL(d.encumbered_amount,0),l.shipment_type,d.po_distribution_id) AS active_encumbrance,
	  h.org_id,
	  h.segment1,
	  l.Shipment_Type,
	  l.Cancel_Flag,
	  d.Accrue_On_Receipt_Flag,
	  d.gl_Encumbered_Date
	FROM PO_lINE_lOCATIONS_ALL l,
	  PO_DISTRIBUTIONS_ALL d,
	  PO_HEADERS_ALL h,
	  PO_LINES_ALL pll
	WHERE l.Line_Location_Id                = d.Line_Location_Id
	AND h.po_header_id                      = d.po_header_id
	AND pll.po_line_id                      = l.po_line_id
	AND NVL(l.Cancel_Flag,''N'')              = ''N''
	AND NVL(l.Closed_Code,''OPEN'')          <> ''FINALLY CLOSED''
	AND NVL(d.Prevent_Encumbrance_Flag,''N'') = ''N''
	AND d.Ussgl_Transaction_Code           IS NULL
	AND d.Budget_Account_id                IS NOT NULL
	AND h.po_Header_Id                      = ##$$HEADERID$$##
	AND h.org_id                            = ##$$ORGID$$##
	AND l.Shipment_Type                    IN (''SCHEDULED'', ''STANDARD'', ''BLANKET'')
	  -- Bug#20641580: Consider only approved shipments distributions as part of OPEN collection.
	AND NVL(l.approved_flag,''N'') = ''Y''
	AND 
	  DECODE( pll.matching_basis, 
		''AMOUNT'', 
		ROUND((NVL(d.amount_ordered,0)+NVL(D.NONRECOVERABLE_TAX,0)) * NVL(D.RATE,1), ##$$CURRPRE$$##), 
		ROUND(L.PRICE_OVERRIDE * D.QUANTITY_ORDERED * NVL(D.RATE,1) +(NVL(D.NONRECOVERABLE_TAX,0)*NVL(D.rate,1)), ##$$CURRPRE$$##) 
	  ) <> d.Encumbered_Amount
	',
   'Incorrect Encumbered Amount Check',
   'RS',
   'Found that the encumbered amount is incorrect for the document',
   '<ul>
		<li>Locate and apply Generic Datafix GDF in [1581836.1]</li>
	</ul>',
   '<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
   -- PO Incorrect Encumbrance reversal
  l_info.delete;
  add_signature(
   'PO_ACTIVE_ENC_WRONG_REVERSAL',
   '/* Finally Closed PO */
	SELECT d.po_header_id,
	  d.po_line_id,
	  d.line_location_id,
	  d.po_Distribution_Id,
	  h.authorization_status,
	  pll.matching_basis,
	  l.closed_code,
	  d.quantity_ordered,
	  d.amount_ordered,
	  d.quantity_cancelled,
	  d.amount_cancelled,
	  d.quantity_billed,
	  d.amount_billed,
	  d.Budget_Account_Id,
	  DECODE( pll.matching_basis, 
		''AMOUNT'',
		/*CALCULATION OF ENC AMOUNT FOR AMOUNT BASED LINES--------START*/
		ROUND( 
		  DECODE( 
			d.Accrue_On_Receipt_Flag,
			''N'',Least((NVL(d.amount_Ordered,0)-NVL(d.amount_cancelled,0)),NVL(d.amount_Billed,0)),
			''Y'',Least(NVL(d.Amount_Ordered,0),NVL(d.Amount_Delivered,0)) 
			) * NVL(d.Rate,1) 
			+ 
		  NVL(d.NonRecoverable_Tax,0) * NVL(d.Rate,1) * 
		  DECODE(d.Accrue_On_Receipt_Flag, 
			''N'',Least( (NVL(d.Amount_Ordered,0)-NVL(d.amount_cancelled,0)),NVL(d.Amount_Billed,0)), 
			''Y'',Least(NVL(d.Amount_Ordered,0),NVL(d.Amount_Delivered,0)) 
			) / DECODE (d.Amount_Ordered,0,1,d.Amount_Ordered), ##$$CURRPRE$$##
		  ) ,
		/*CALCULATION OF ENC AMOUNT FOR AMOUNT BASED LINES--------END*/  
		/*CALCULATION OF ENC AMOUNT FOR non AMOUNT BASED LINES--------START*/
		ROUND( 
		  l.Price_Override * 
		  DECODE( 
			d.Accrue_On_Receipt_Flag, 
			''N'',Least((d.Quantity_Ordered-d.quantity_cancelled),NVL(d.Quantity_Billed,0)), 
			''Y'',Least(d.Quantity_Ordered,NVL(d.Quantity_Delivered,0)) 
			) * NVL(d.Rate,1) 
			+ 
		  NVL(d.NonRecoverable_Tax,0) * NVL(d.Rate,1) * 
		  DECODE(
			d.Accrue_On_Receipt_Flag, 
			''N'',Least((d.Quantity_Ordered-d.quantity_cancelled),NVL(d.Quantity_Billed,0)), 
			''Y'',Least(d.Quantity_Ordered,NVL(d.Quantity_Delivered,0)) 
			) / DECODE(d.Quantity_Ordered,0,1,d.Quantity_Ordered), ##$$CURRPRE$$##)
		 /*CALCULATION OF ENC AMOUNT FOR non AMOUNT BASED LINES--------END*/
	  ) correct_encumbered_amount,
	  d.Encumbered_Amount,
	  po_inq_sv.get_active_enc_amount(NVL(d.rate,1),NVL(d.encumbered_amount,0),l.shipment_type,d.po_distribution_id) AS active_encumbrance,
	  h.org_id,
	  h.segment1,
	  l.Shipment_Type,
	  l.Cancel_Flag,
	  d.Accrue_On_Receipt_Flag,
	  d.gl_Encumbered_Date
	FROM PO_lINE_lOCATIONS_ALL l,
	  PO_DISTRIBUTIONS_ALL d,
	  PO_HEADERS_ALL h,
	  PO_LINES_ALL pll
	WHERE l.Line_Location_Id                = d.Line_Location_Id
	AND h.po_Header_Id                      = d.po_Header_Id
	AND pll.po_line_id                      = l.po_line_id
	AND NVL(l.Approved_Flag,''N'')            = ''Y''
	AND NVL(l.Closed_Code,''OPEN'')           = ''FINALLY CLOSED''
	AND NVL(d.Prevent_Encumbrance_Flag,''N'') = ''N''
	AND d.Ussgl_Transaction_Code           IS NULL
	AND d.Budget_Account_id                IS NOT NULL
	AND h.po_Header_Id                      = ##$$HEADERID$$##
	AND h.org_id                            = ##$$ORGID$$##
	AND l.Shipment_Type IN (''SCHEDULED'', ''STANDARD'', ''BLANKET'')
	AND
	  DECODE( pll.matching_basis, 
		''AMOUNT'',
		/*CALCULATION OF ENC AMOUNT FOR AMOUNT BASED LINES--------START*/
		ROUND( 
		  DECODE( 
			d.Accrue_On_Receipt_Flag,
			''N'',Least((NVL(d.amount_Ordered,0)-NVL(d.amount_cancelled,0)),NVL(d.amount_Billed,0)),
			''Y'',Least(NVL(d.Amount_Ordered,0),NVL(d.Amount_Delivered,0)) 
			) * NVL(d.Rate,1) 
			+ 
		  NVL(d.NonRecoverable_Tax,0) * NVL(d.Rate,1) * 
		  DECODE(d.Accrue_On_Receipt_Flag, 
			''N'',Least( (NVL(d.Amount_Ordered,0)-NVL(d.amount_cancelled,0)),NVL(d.Amount_Billed,0)), 
			''Y'',Least(NVL(d.Amount_Ordered,0),NVL(d.Amount_Delivered,0)) 
			) / DECODE (d.Amount_Ordered,0,1,d.Amount_Ordered), ##$$CURRPRE$$##
		  ) ,
		/*CALCULATION OF ENC AMOUNT FOR AMOUNT BASED LINES--------END*/  
		/*CALCULATION OF ENC AMOUNT FOR non AMOUNT BASED LINES--------START*/
		ROUND( 
		  l.Price_Override * 
		  DECODE( 
			d.Accrue_On_Receipt_Flag, 
			''N'',Least((d.Quantity_Ordered-d.quantity_cancelled),NVL(d.Quantity_Billed,0)), 
			''Y'',Least(d.Quantity_Ordered,NVL(d.Quantity_Delivered,0)) 
			) * NVL(d.Rate,1) 
			+ 
		  NVL(d.NonRecoverable_Tax,0) * NVL(d.Rate,1) * 
		  DECODE(
			d.Accrue_On_Receipt_Flag, 
			''N'',Least((d.Quantity_Ordered-d.quantity_cancelled),NVL(d.Quantity_Billed,0)), 
			''Y'',Least(d.Quantity_Ordered,NVL(d.Quantity_Delivered,0)) 
			) / DECODE(d.Quantity_Ordered,0,1,d.Quantity_Ordered), ##$$CURRPRE$$##)
		 /*CALCULATION OF ENC AMOUNT FOR non AMOUNT BASED LINES--------END*/
	  ) = round(d.Encumbered_Amount,##$$CURRPRE$$##)
	AND po_inq_sv.get_active_enc_amount(NVL(d.rate,1),NVL(d.encumbered_amount,0),l.shipment_type,d.po_distribution_id) > 0
	',
   'Incorrect Encumbrance Reversal Check',
   'RS',
   'Found that there exist active encumbrance due to due to incorrect reversals',
   '<ul>
		<li>Check that the matched invoice is fully validated</li>
		<li>Check that amount invoiced in Payables matches amount billed in Purchasing distribution</li>
		<li>Alternatively, engage Payables support to review the encumbrance reversal</li>
	</ul>',
   '<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
	-- 0$ missing Encumbrance entries for approved POs
	  l_info.delete;
	  add_signature(
	   'PO_MISSING_0$_BC_DIS_ENTRIES',
	   'SELECT DISTINCT h.po_header_id KEY,
		  h.org_id org_id,
		  h.segment1 "PO Number",
		  l.line_num "Line Number",
		  s.shipment_num "Shipment Number",
		  s.APPROVED_FLAG,
		  s.price_override,
		  s.quantity,
		  d.*
		FROM po_headers_All h,
		  po_lines_all l,
		  po_line_locations_all s,
		  po_distributions_all d
		WHERE h.po_header_id                                        = l.po_header_id
		AND l.po_line_id                                            = s.po_line_id
		AND s.line_location_id                                      = d.line_location_id
		AND h.type_lookup_code                                      = ''STANDARD''
		AND NVL(s.cancel_flag, ''N'')                                 = ''N''
		AND NVL(s.closed_code, ''OPEN'')                             <> ''FINALLY CLOSED''
		AND ( s.price_override                                      = 0
		OR s.quantity                                               = 0)
		AND NVL(d.encumbered_amount, 0)                             = 0
		AND d.budget_account_id                                    IS NOT NULL
		AND d.gl_encumbered_date                                   IS NOT NULL
		AND NVL(s.APPROVED_FLAG, ''N'')                               = ''Y''
		AND h.po_header_id                                          = ##$$HEADERID$$##
		AND to_date(''##$$R12UDATE$$##'', ''MM/DD/YYYY HH24:MI:SS'') <
		  (SELECT TRUNC(MAX(LAST_UPDATE_DATE))
		  FROM po_action_history
		  WHERE OBJECT_TYPE_CODE IN (''PO'', ''PA'')
		  AND ACTION_CODE         = ''RESERVE''
		  AND object_id           = h.po_header_id
		  )
		AND NOT EXISTS
		  (SELECT ''0$entry in PO_BC''
		  FROM po_bc_distributions pbd
		  WHERE pbd.JE_SOURCE_NAME = ''Purchasing''
		  AND pbd.JE_CATEGORY_NAME = ''Purchases''
		  AND pbd.ENTERED_AMT      = 0
		  AND pbd.HEADER_ID        = h.po_header_id
		  AND pbd.DISTRIBUTION_ID  = d.po_distribution_id
		  AND pbd.EVENT_TYPE_CODE  = ''PO_PA_RESERVED''
		  )',
	   'Missing Encumbrance 0$ Entries for Approved POs Check',
	   'RS',
	   'Found missing Encumbrance 0$ entries for approved POs',
		'<ul>
			<ol>
			<li>Review [1364395.1] to obtain codefix</li>			
			<li>Locate datafix script posting_zero_dollar_entries.sql from [1982134.1]</li>
			</ol>
		</ul>',
		'<ul>
			<li>No issue found</li>
		</ul>',
	   'ALWAYS',
	   'E',
	   'RS');

   
  -- Wrong GL Encumbered Period Name
  l_info.delete;
  add_signature(
   'PO_WRONG_GL_ENC_PERIOD_NAME',
   'SELECT temp.*
	FROM
	  (SELECT pod.po_distribution_id,
		pod.gl_encumbered_period_name,
		GL_PS.period_name,
		pod.gl_encumbered_date,
		pod.set_of_books_id
	  FROM po_distributions_all pod,
		gl_period_statuses GL_PS,
		gl_period_statuses PO_PS,
		gl_sets_of_books SOB
	  WHERE pod.gl_encumbered_date    IS NOT NULL
	  AND SOB.set_of_books_id          = pod.set_of_books_id
	  AND GL_PS.application_id         = 101
	  AND gl_PS.adjustment_period_FLAG = ''N''
	  AND PO_PS.application_id         = 201
	  AND GL_PS.set_of_books_id        = SOB.set_of_books_id
	  AND PO_PS.set_of_books_id        = SOB.set_of_books_id
	  AND GL_PS.period_name            = PO_PS.period_name
	  AND TRUNC(pod.gl_encumbered_date) BETWEEN TRUNC(GL_PS.start_date) AND TRUNC(GL_PS.end_date)
	  AND pod.set_of_books_id = ##$$LEDGERID$$##
	  AND pod.po_header_id    = ##$$HEADERID$$##
	  ) temp
	WHERE NVL(gl_encumbered_period_name, ''TEST'') <> period_name',
   'Wrong GL Encumbered Period Name Check',
   'RS',
   'Found wrong GL encumbered period name on document distribution',
	'<ul>
		<ol>
		<li>Apply patch {11826974} to obtain codefix</li>
		<li>Log SR with support to obtain datafix</li>
		</ol>
	</ul>',
	'<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
  -- Budget Accounts validation
  l_info.delete;
  add_signature(
   'PO_BUDGET_ACCT_VALIDATION',
   'SELECT gcc.code_combination_id,
	  gcc.concatenated_segments,
	  gcc.enabled_flag,
	  gcc.detail_budgeting_allowed "allow budgeting",
	  gcc.detail_posting_allowed "allow posting",
	  gcc.start_date_active,
	  gcc.end_date_active
	FROM gl_code_combinations_kfv gcc,
	  po_distributions_all pod
	WHERE gcc.code_combination_id    = pod.budget_account_id
	AND pod.po_header_id             = ##$$HEADERID$$##
	AND (gcc.enabled_flag           <> ''Y''
	OR gcc.detail_budgeting_allowed <> ''Y''
	OR gcc.detail_posting_allowed   <> ''Y''
	OR gcc.start_date_active         > sysdate
	OR gcc.end_date_active           < sysdate )',
   'Budget Account Validation Check',
   'RS',
   'Found invalid budget account',
	'<ul>
		<ol>
		<li>The account must be enabled, allow posting, allow budgeting</li>
		<li>Please check the account setup in General Ledger</li>
		</ol>
	</ul>',
	'<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
  -- PO canceled before approved
  l_info.delete;
  add_signature(
   'PO_CANCELED_BEFORE_APPROVED',
   'SELECT pod.po_distribution_id,
	  pod.line_location_id,
	  pod.gl_encumbered_date,
	  pod.budget_account_id,
	  pod.prevent_encumbrance_flag,
	  poll.approved_date,
	  poll.approved_flag,
	  poll.cancel_date,
	  poll.cancel_flag
	FROM po_line_locations_all poll,
	  po_distributions_all pod
	WHERE poll.line_location_id                = pod.line_location_id
	AND NVL(poll.cancel_flag, ''N'')             = ''Y''
	AND ( NVL(poll.approved_flag, ''N'')         = ''N''
	OR ( NVL(poll.approved_flag, ''N'')          = ''Y''
	AND poll.cancel_date                       < poll.approved_date ) )
	AND pod.gl_encumbered_date                IS NOT NULL
	AND pod.budget_account_id                 IS NOT NULL
	AND NVL(pod.prevent_encumbrance_flag, ''N'') = ''N''
	AND pod.org_id                             = ##$$ORGID$$##
	AND pod.po_header_id                       = ##$$HEADERID$$##
	AND EXISTS
	  (SELECT 1
	  FROM po_action_history
	  WHERE object_id = poll.po_header_id
	  AND action_code = ''REJECT''
	  )
	AND NOT EXISTS
	  (SELECT 1
	  FROM po_bc_distributions
	  WHERE distribution_id = pod.po_distribution_id
	  )',
   'PO Canceled Before Approved Check',
   'RS',
   'Found Document canceled before approved',
	'<ul>
		<ol>
		<li>Log SR with support to obtain datafix from bug 12347143</li>
		</ol>
	</ul>',
	'<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
  -- Invalid, Draft, or Unprocessed Purchasing Events
  l_info.delete;
  add_signature(
   'DRAFT_EVENTS',
   'SELECT DISTINCT xe.event_id,    
		 xe.event_type_code,	  
		 xe.event_date,	  
		 xe.event_status_code,  
		 xe.process_status_code,    
		 xte.entity_id,	  
		 xte.legal_entity_id,	  
		 xte.entity_code,	  
		 xte.source_id_int_1,	  
		 xte.source_id_int_2,	  
		 xte.source_id_int_3,	  
		 xte.source_id_int_4,	  
		 xte.source_id_char_1
	 FROM xla_transaction_entities_upg xte,          
		  xla_events  xe			                              			               
	 WHERE NVL(xe.budgetary_control_flag, ''N'') =''Y''       
	   AND xte.entity_code IN (''REQUISITION'',''PURCHASE_ORDER'',''RELEASE'') 	  
	   AND xte.application_id = 201	
	   AND xe.application_id =xte.application_id
	   AND xte.entity_id =  xe.entity_id	            
	   AND xe.EVENT_STATUS_CODE  in (''U'' ,''I'')	                     
	   AND xe.PROCESS_STATUS_CODE  IN (''I'',''D'',''U'')
	   AND xte.ledger_id =  ##$$LEDGERID$$##',
   'Invalid, Draft, or Unprocessed Purchasing Events Check',
   'RS',
   'Found Invalid, Draft, or Unprocessed Purchasing Events',
	'<ul>
		<li>Locate [1264605.1]. Apply the suggested patches and datafix</li>
	</ul>',
   '<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
   -------------------------------------
   -- POENC Requisition specific checks
   -------------------------------------
   
   
	-- REQ pre-approved or In Process
	l_info.delete;
	add_signature(
   'REQ_PRE_APPROVED_OR_IN_PROCESS',
   'SELECT DECODE(NVL(h.segment1,''$$$''),''$$$'', ''Requisition'') "Document Type",
	  h.segment1 "Document Number",
	  h.org_id "Org_Id",
	  h.authorization_status "Authorization Status"
	FROM po_requisition_headers_all h
	WHERE h.authorization_status IN ( ''IN PROCESS'', ''PRE-APPROVED'')
	AND requisition_header_id  = ##$$HEADERID$$##',
   'Pre-Approved or In Process Document Status Check',
   'RS',
   'Found the document is in Pre-Approved or In Process status',
   '<ul>
		<li>First, try to the following steps in [461104.1]:</li>
		<ol>
		<li>Navigate to Requisition Summary form and query the requisition</li>
		<li>Go to Inquire/View Action History. The last action sequence should show a blank action. Note the employee name next to this blank action</li>
		<li>Employee from #2 should log into application and go to Notification Summary screen</li>
		<li>There should be an Unable to Reserve notification. Open this and select Return to Preparer</li>
		<li>Requisition status is set to Rejected and system should allow the needed changes to be made</li>
		</ol>
		<li>If the steps does not work, locate [390023.1] and follow reset script instruction</li>
	</ul>',
   '<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
   
	l_info.delete;
	add_signature(
   'REQ_BUDGET_ACCT_VALIDATION',
   'SELECT gcc.code_combination_id,
	  gcc.concatenated_segments,
	  gcc.enabled_flag,
	  gcc.detail_budgeting_allowed "allow budgeting",
	  gcc.detail_posting_allowed "allow posting",
	  gcc.start_date_active,
	  gcc.end_date_active
	FROM gl_code_combinations_kfv gcc,
	  po_req_distributions_all prd,
	  po_requisition_lines_all prl
	WHERE gcc.code_combination_id    = prd.budget_account_id
	AND prd.requisition_line_id      = prl.requisition_line_id
	AND prl.requisition_header_id    = ##$$HEADERID$$##
	AND (gcc.enabled_flag           <> ''Y''
	OR gcc.detail_budgeting_allowed <> ''Y''
	OR gcc.detail_posting_allowed   <> ''Y''
	OR gcc.start_date_active         > sysdate
	OR gcc.end_date_active           < sysdate)',
   'Budget Account Validation Check',
   'RS',
   'Found invalid budget account',
	'<ul>
		<ol>
		<li>The account must be enabled, allow posting, allow budgeting</li>
		<li>Please check the account setup in General Ledger</li>
		</ol>
	</ul>',
	'<ul>
		<li>No issue found</li>
	</ul>',
   'ALWAYS',
   'E',
   'RS');
   
	-- Requisition Reserved missing in po_bc_distributions--Root cause 7529281
	l_info.delete;
	add_signature(
	   'REQ_RESERVED_NO_BC_DIST',
	   'SELECT requisition_header_id,
		  requisition_line_id,
		  distribution_id ,
		  Requisition_Number,
		  line_num,
		  distribution_num,
		  apps_source_code,
		  creation_date,
		  authorization_status,
		  cancel_flag,
		  line_location_id,
		  budget_account_id,
		  prevent_encumbrance_flag,
		  encumbered_amount,
		  encumbered_flag
		FROM
		  (SELECT h.requisition_header_id,
			l.requisition_line_id,
			d.distribution_id ,
			h.segment1 Requisition_Number,
			l.line_num ,
			d.distribution_num ,
			h.apps_source_code,
			h.CREATION_DATE,
			h.AUTHORIZATION_STATUS,
			l.cancel_flag,
			l.line_location_id,
			d.budget_account_id,
			d.prevent_encumbrance_flag,
			d.encumbered_amount,
			d.encumbered_flag
		  FROM po_req_distributions_all d,
			po_requisition_headers_All h,
			po_requisition_lines_All l
		  WHERE h.requisition_header_id = l.requisition_header_id
			--and h.apps_source_code = ''POR'' commented this condition for more generic use.
			--AND h.AUTHORIZATION_STATUS = ''APPROVED'' Commented for BUG#20103895
			--AND Nvl(l.ENCUMBERED_FLAG, ''N'') = ''Y'' Commented for bug 18646242
			--As there were some encumbered dists whose lines have encumbered_flag as N
		  AND NVL(l.cancel_flag, ''N'')    <> ''Y''
		  AND NVL(d.encumbered_flag, ''N'') = ''Y''
		  AND l.requisition_line_id         = d.requisition_line_id
		  AND d.budget_account_id          IS NOT NULL
		  AND h.requisition_header_id       = l.requisition_header_id
		  AND d.prevent_encumbrance_flag    = ''N''
		  AND h.CREATION_DATE               > to_date(''##$$R12UDATE$$##'', ''MM/DD/YYYY HH24:MI:SS'')
		  AND h.requisition_header_id       = ##$$HEADERID$$##
		  AND l.line_location_id           IS NULL
		  UNION
		  SELECT h.requisition_header_id,
			l.requisition_line_id,
			d.distribution_id ,
			h.segment1 Requisition_Number,
			l.line_num ,
			d.distribution_num ,
			h.apps_source_code,
			h.CREATION_DATE,
			h.AUTHORIZATION_STATUS,
			l.cancel_flag,
			l.line_location_id,
			d.budget_account_id,
			d.prevent_encumbrance_flag,
			d.encumbered_amount,
			d.encumbered_flag
		  FROM po_req_distributions_all d,
			po_requisition_headers_All h,
			po_requisition_lines_All l,
			po_distributions_all pod
		  WHERE h.requisition_header_id = l.requisition_header_id
			--and h.apps_source_code = ''POR'' commented this condition for more generic use
			--AND h.AUTHORIZATION_STATUS = ''APPROVED'' Commented for BUG#20103895
			--AND Nvl(l.ENCUMBERED_FLAG, ''N'') = ''Y'' Commented for bug 18646242
			--As there were some encumbered dists whose lines have encumbered_flag as N
		  AND NVL(l.cancel_flag, ''N'')       = ''N''
		  AND NVL(d.encumbered_flag, ''N'')   = ''Y''
		  AND l.requisition_line_id           = d.requisition_line_id
		  AND d.budget_account_id            IS NOT NULL
		  AND h.requisition_header_id         = l.requisition_header_id
		  AND NVL(d.encumbered_amount,0)      > 0
		  AND d.prevent_encumbrance_flag      = ''N''
		  AND l.line_location_id             IS NOT NULL
		  AND d.distribution_id               = pod.req_distribution_id
		  AND h.CREATION_DATE                 > to_date(''##$$R12UDATE$$##'', ''MM/DD/YYYY HH24:MI:SS'')
		  AND h.requisition_header_id         = ##$$HEADERID$$##
		  AND NVL(pod.encumbered_flag, ''N'') = ''N''
		  AND NVL(pod.encumbered_amount,0)    = 0
		  ) dist
		WHERE NOT EXISTS
		  (SELECT ''po_bc_record''
		  FROM po_bc_distributions pbd
		  WHERE pbd.je_source_name = ''Purchasing''
		  AND pbd.je_category_name = ''Requisitions''
		  AND pbd.distribution_id  = dist.distribution_id
		  AND pbd.STATUS_CODE      = ''P''
		  )',
   'Reserved Requisition Missing PO BC Distribution Check',
   'RS',
   'Found Reserved requisition missing PO BC distributions',
	'<ul>
		<ol>
		<li>Locate [1982134.1]</li>			
		<li>Apply codefix and datafix titled Requisition reserved missing in po_bc_distributions</li>
		</ol>
	</ul>',
	'<ul>
		<li>No issue found</li>
	</ul>',
	'ALWAYS',
	'E',
	'RS');
   
	-- R12 Returned Req
	l_info.delete;
	add_signature(
	   'REQ_RETURNED_WRONG_ENC',
	   'SELECT prh.requisition_header_id,
		  prl.requisition_line_id,
		  prd.distribution_id,
		  prh.segment1 Requisition_Number,
		  prl.line_num,
		  prd.distribution_num,
		  prd.encumbered_flag,
		  ROUND(NVL(prd.Encumbered_Amount,0),##$$CURRPRE$$##) Encumbered_Amount,
		  ''N'' Correct_enc_Flag,
		  0 Correct_enc_Amount,
		  prd.Set_Of_Books_Id,
		  prd.Budget_Account_Id,
		  prh.Org_Id,
		  prh.apps_source_code,
		  prh.creation_date,
		  prh.authorization_status,
		  prl.cancel_flag,
		  prl.line_location_id,
		  prd.prevent_encumbrance_flag
		FROM po_req_Distributions_All prd,
		  po_Requisition_Lines_All prl,
		  po_Requisition_Headers_All prh
		WHERE prh.Requisition_Header_Id                = prl.Requisition_Header_Id
		AND prl.Requisition_Line_Id                    = prd.Requisition_Line_Id
		AND prd.Budget_Account_Id                     IS NOT NULL
		AND NVL(prl.Closed_Code,''OPEN'')               <> ''FINALLY CLOSED''
		AND NVL(prl.Cancel_Flag,''N'')                   = ''N''
		AND NVL(prh.authorization_status,''INCOMPLETE'') = ''RETURNED''
		AND prl.line_location_id                      IS NULL
		AND prd.Ussgl_Transaction_Code                IS NULL
		AND NVL(prd.Prevent_Encumbrance_Flag,''N'')      = ''N''
		AND prd.encumbered_flag                        = ''Y''
		AND prh.Requisition_Header_Id                  = ##$$HEADERID$$##',
   'Returned Requisition Having Encumbrance Check',
   'RS',
   'Found returned requisition with active encumbrance',
	'<ul>
		<ol>
		<li>Locate [1982134.1]</li>			
		<li>Apply datafix titled "Returned requisition having encumbrance"</li>
		</ol>
	</ul>',
	'<ul>
		<li>No issue found</li>
	</ul>',
	'ALWAYS',
	'E',
	'RS');   
	
	-- R12 Rejected Requisition having encumbrance -Root cause 18672709
	l_info.delete;
	add_signature(
	   'REQ_REJECTED_WRONG_ENC',
	   'SELECT 
		  prh.requisition_header_id,
		  prl.requisition_line_id,
		  prd.distribution_id,
		  prh.segment1 Requisition_Number,
		  prl.line_num,
		  prd.distribution_num,
		  prd.encumbered_flag,
		  ROUND(NVL(prd.Encumbered_Amount,0),##$$CURRPRE$$##) Encumbered_Amount,
		  ''N'' Correct_enc_Flag,
		  0 Correct_enc_Amount,
		  prd.Set_Of_Books_Id,
		  prd.Budget_Account_Id,
		  prh.Org_Id,
		  prh.apps_source_code,
		  prh.creation_date,
		  prh.authorization_status,
		  prl.cancel_flag,
		  prl.line_location_id,
		  prd.prevent_encumbrance_flag
		FROM po_req_distributions_all prd,
		  po_requisition_lines_all prl,
		  po_requisition_headers_all prh
		WHERE prd.requisition_line_id                  = prl.requisition_line_id
		AND prh.requisition_header_id                  = prl.requisition_header_id
		AND NVL(prl.closed_code,''OPEN'')               <> ''FINALLY CLOSED''
		AND NVL(prl.CANCEL_FLAG,''N'')                   = ''N''
		AND prd.Budget_Account_Id                     IS NOT NULL
		AND prd.Ussgl_Transaction_Code                IS NULL
		AND NVL(prd.Prevent_Encumbrance_Flag,''N'')      = ''N''
		AND NVL(prh.Authorization_status,''INCOMPLETE'') = ''REJECTED''
		AND prl.line_location_id                      IS NULL
		AND (ROUND(NVL(prd.Encumbered_Amount,0),##$$CURRPRE$$##)    <> 0
		OR NVL(prd.Encumbered_Flag,''N'')               <> ''N'' )
		AND prh.Requisition_Header_Id                  = ##$$HEADERID$$##',
   'Rejected Requisition Having Encumbrance Check',
   'RS',
   'Found rejected requisition with active encumbrance',
	'<ul>
		<ol>
		<li>Locate [1982134.1]</li>			
		<li>Apply datafix titled "Rejected requisition having encumbrance"</li>
		</ol>
	</ul>',
	'<ul>
		<li>No issue found</li>
	</ul>',
	'ALWAYS',
	'E',
	'RS');   
	
	-- R12 Req autocreated script
	l_info.delete;
	add_signature(
	   'REQ_AUTOCREATED_WRONG_ENC',
	   'SELECT prh.requisition_header_id,
		  prl.requisition_line_id,
		  prd.distribution_id,
		  prh.segment1 Requisition_Number,
		  prl.line_num,
		  prd.distribution_num,
		  prd.encumbered_flag,
		  ROUND(NVL(prd.Encumbered_Amount,0),##$$CURRPRE$$##) Encumbered_Amount,
		  ''N'' Correct_enc_Flag,
		  0 Correct_enc_Amount,
		  prd.Set_Of_Books_Id,
		  prd.Budget_Account_Id,
		  prh.Org_Id,
		  prh.apps_source_code,
		  prl.Source_Type_Code,
		  prh.creation_date,
		  prh.authorization_status,
		  prl.cancel_flag,
		  prd.prevent_encumbrance_flag,
		  pll.po_header_id,
		  pll.po_line_id,
		  pll.line_location_id,
		  pod.po_distribution_id,
		  poh.segment1 po_number,
		  pol.line_num po_line_number,
		  pll.shipment_num po_shipment_number,
		  pod.distribution_num po_dist_number,
		  Pod.Encumbered_Flag pod_encumbered_flag,
		  pod.Budget_Account_Id pod_Budget_Account_Id,
		  Pll.Cancel_Flag pll_cancel_flag,
		  Pll.Closed_Code pll_closed_code
		FROM po_req_Distributions_All prd,
		  po_Requisition_Lines_All prl,
		  po_Requisition_Headers_All prh,
		  po_Line_Locations_All Pll,
		  po_Distributions_All Pod,
		  po_headers_all poh,
		  po_lines_all pol
		WHERE prl.Source_Type_Code                   = ''VENDOR''
		AND prl.Line_Location_Id                    IS NOT NULL
		AND prd.Budget_Account_Id                   IS NOT NULL
		AND pod.Budget_Account_Id                   IS NOT NULL
		AND prl.Parent_req_Line_Id                  IS NULL
		AND NVL(prd.Prevent_Encumbrance_Flag,''N'')    = ''N''
		AND prd.Ussgl_Transaction_Code              IS NULL
		AND prd.Requisition_Line_Id                  = prl.Requisition_Line_Id
		AND prl.Requisition_Header_Id                = prh.Requisition_Header_Id
		AND prl.Line_Location_Id                     = Pll.Line_Location_Id
		AND Pll.Line_Location_Id                     = Pod.Line_Location_Id
		AND pll.po_line_id                           = pol.po_line_id
		AND pll.po_header_id                         = poh.po_header_id
		AND prd.Distribution_Id                      = Pod.req_Distribution_Id
		AND prh.Requisition_Header_Id                = ##$$HEADERID$$##
		AND Pll.Shipment_Type                       <> ''SCHEDULED''
		AND ( NVL(Pod.Encumbered_Flag,''N'')           = ''Y''
			OR NVL(Pll.Cancel_Flag,''N'')                  = ''Y''
			OR NVL(Pll.Closed_Code,''OPEN'')               = ''FINALLY CLOSED'' )
		AND ( ROUND(NVL(prd.Encumbered_Amount,0),##$$CURRPRE$$##) <> 0
			OR NVL(Prd.Encumbered_Flag,''N'')             <> ''N'' )',
   'Autocreated Requisition Having Encumbrance Check',
   'RS',
   'Found autocreated requisition with active encumbrance',
	'<ul>
		<ol>
		<li>Locate [1982134.1]</li>			
		<li>Apply datafix titled "Autocreated requisition having encumbrance"</li>
		</ol>
	</ul>',
	'<ul>
		<li>No issue found</li>
	</ul>',
	'ALWAYS',
	'E',
	'RS');   


EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;





---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main (
      p_org_id			IN NUMBER   DEFAULT null,
      p_doc_type		IN VARCHAR2 DEFAULT null,
      p_doc_num			IN VARCHAR2 DEFAULT null,
	  p_line_num		IN VARCHAR2 DEFAULT null,
      p_from_date		IN DATE     DEFAULT sysdate - 90,
      p_max_output_rows	IN NUMBER   DEFAULT 50,
      p_debug_mode		IN VARCHAR2 DEFAULT 'Y') IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
  
  -- PSD #11
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Procurement Encumbrance Accounting';

  l_step := '20';
 -- PSD #12
  validate_parameters(
      p_org_id,
      p_doc_type,
      p_doc_num,
	  p_line_num,
      p_from_date,
      p_max_output_rows,
      p_debug_mode);
	  
  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');

  -- PSD #13

  start_section('Proactive Recommendations');
    -- set_item_result(check_rec_patches);
    set_item_result(run_stored_sig('PO_INVALIDS'));
    set_item_result(run_stored_sig('XLA_INVALIDS'));
	IF (g_sql_tokens('##$$REL$$##') IS NOT NULL) THEN
       IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN
          set_item_result(run_stored_sig('PRC_CODE_LEVEL_12_1'));
       ELSIF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.2') THEN
          set_item_result(run_stored_sig('PRC_CODE_LEVEL_12_2'));    
       ELSIF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.0') THEN	
          set_item_result(run_stored_sig('PRC_CODE_LEVEL_12_0')); 
       END IF;
    END IF;   
  end_section;	 

  start_section('Setup');
	set_item_result(run_stored_sig('PROFILE_OPTIONS_SETUP'));
	set_item_result(run_stored_sig('LEDGER_SETUP'));
	set_item_result(run_stored_sig('SUBLEDGER_ACCOUNTING_SETUP'));
	set_item_result(run_stored_sig('GL_PO_PERIODS_SETUP'));
	set_item_result(run_stored_sig('GL_CURRENT_BUDGET'));
	set_item_result(run_stored_sig('FINANCIAL_OPTIONS_SETUP'));
	set_item_result(run_stored_sig('PURCHASING_OPTIONS_SETUP'));
  end_section;
  
  start_section('Document Data');
	IF p_doc_type = 'PO' THEN
		set_item_result(run_stored_sig('DOC_DETAIL_PO_HEADER'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_LINE'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_SHIPMENT'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_DISTRIBUTION'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_HEADER_ARC'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_LINE_ARC'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_SHIPMENT_ARC'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_DISTRIBUTION_ARC'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_ACTION_HISTORY'));
		--IF g_sql_tokens('##$$BREQ$$##') = 'Y' THEN
			set_item_result(run_stored_sig('DOC_DETAIL_PO_BREQ_HEADER'));
			set_item_result(run_stored_sig('DOC_DETAIL_PO_BREQ_LINE'));			
			set_item_result(run_stored_sig('DOC_DETAIL_PO_BREQ_DISTRIBUTION'));
		--END IF;
		set_item_result(run_stored_sig('DOC_DETAIL_PO_GL_BC_PACKETS'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_BC_DISTRIBUTIONS'));
		set_item_result(run_stored_sig('DOC_DETAIL_BREQ_PO_BC_DISTRIBUTIONS'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_XLA_EVENTS'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_XLA_AE_HEADERS'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_XLA_AE_LINES'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_XLA_TRXN_ENT_UPG'));
		set_item_result(run_stored_sig('DOC_DETAIL_PO_PSA_XLA_ACCT_ERRORS'));
	ELSIF p_doc_type = 'REQ' THEN
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_HEADER'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_LINE'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_DISTRIBUTION'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_ACTION_HISTORY'));
		set_item_result(run_stored_sig('DOC_DETAIL_ASSOC_PO_HEADER'));
		set_item_result(run_stored_sig('DOC_DETAIL_ASSOC_PO_LINE'));
		set_item_result(run_stored_sig('DOC_DETAIL_ASSOC_PO_SHIPMENT'));
		set_item_result(run_stored_sig('DOC_DETAIL_ASSOC_PO_DIST'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_GL_BC_PACKETS'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_PO_BC_DISTRIBUTIONS'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_XLA_EVENTS'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_XLA_AE_HEADERS'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_XLA_AE_LINES'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_XLA_TRXN_ENT_UPG'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_XLA_DIST_LINKS'));
		set_item_result(run_stored_sig('DOC_DETAIL_REQ_PSA_XLA_ACCT_ERRORS'));	
	END IF; 
  end_section;
  
  start_section('Encumbrance Accounting');
	IF p_doc_type = 'PO' THEN
		set_item_result(run_stored_sig('PO_PRE_APPROVED_OR_IN_PROCESS')); 
		set_item_result(run_stored_sig('PO_ACTIVE_ENC_WRONG_ENC_AMOUNT'));
		set_item_result(run_stored_sig('PO_ACTIVE_ENC_WRONG_REVERSAL'));
		set_item_result(run_stored_sig('PO_PRE_APPROVED_NO_FUNDS'));
		set_item_result(run_stored_sig('PO_WRONG_GL_ENC_PERIOD_NAME'));
		set_item_result(run_stored_sig('PO_BUDGET_ACCT_VALIDATION'));
		set_item_result(run_stored_sig('PO_CANCELED_BEFORE_APPROVED'));
		set_item_result(run_stored_sig('PO_MISSING_0$_BC_DIS_ENTRIES'));
		set_item_result(run_stored_sig('DRAFT_EVENTS'));
	ELSIF p_doc_type = 'REQ' THEN
		set_item_result(run_stored_sig('REQ_PRE_APPROVED_OR_IN_PROCESS'));
		set_item_result(run_stored_sig('REQ_BUDGET_ACCT_VALIDATION'));
		set_item_result(run_stored_sig('REQ_RESERVED_NO_BC_DIST'));
		set_item_result(run_stored_sig('REQ_RETURNED_WRONG_ENC'));
		set_item_result(run_stored_sig('REQ_REJECTED_WRONG_ENC'));
		set_item_result(run_stored_sig('REQ_AUTOCREATED_WRONG_ENC'));
		set_item_result(run_stored_sig('DRAFT_EVENTS'));
	END IF; 
  end_section;
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/thread/3675874" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');


  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

---------------------------------
-- MAIN ENTRY POINT FOR CONC PROC
-- uncomment to run from concurrent program
-- edit list of variables to match MAIN
-- <package>.main_cp will be what you define program to call
---------------------------------
PROCEDURE main_cp(
	errbuf            OUT VARCHAR2,
	retcode           OUT VARCHAR2,
      p_org_id          IN NUMBER,-- DEFAULT null,
      p_doc_type        IN VARCHAR2,-- DEFAULT null,
	  p_dummy_po        IN VARCHAR2,-- DEFAULT null,
      p_po_num          IN VARCHAR2,-- DEFAULT null,
	  p_po_line_num     IN VARCHAR2,-- DEFAULT null,
	  p_dummy_req       IN VARCHAR2,-- DEFAULT null,
      p_req_num         IN VARCHAR2,-- DEFAULT null,
	  p_req_line_num    IN VARCHAR2,-- DEFAULT null,
      p_from_date       IN VARCHAR2,-- DEFAULT null,
      p_max_output_rows IN NUMBER,--   DEFAULT 50,
      p_debug_mode      IN VARCHAR2) -- DEFAULT 'Y') 
IS

l_doc_num VARCHAR2(30);
l_line_num  VARCHAR2(20);

BEGIN
	g_retcode := 0;
	g_errbuf := null;
 
	l_doc_num := nvl(p_po_num, p_req_num);
  
	if p_po_num is not null then
		l_line_num := p_po_line_num;
	else 
		l_line_num := p_req_line_num;
	end if;

  main(
      p_org_id => p_org_id,
      p_doc_type => p_doc_type,
      p_doc_num => l_doc_num,
	  p_line_num => l_line_num,
	  p_from_date => p_from_date,
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode);

	retcode := g_retcode;
	errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
	retcode := '2';
	errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
  dbms_output.put_line('Error encountered in main_cp: '||sqlerrm);
END main_cp;


-- PSD #1
END po_enc_analyzer_pkg;
/
show errors
exit;