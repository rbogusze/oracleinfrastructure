REM $Id: ascp_performance_analyzer.sql 200.5 JJG $
REM   
REM MODIFICATION LOG:
REM	
REM	MN 
REM	
REM	Consolidated script to diagnose the current status and footprint of Performance on an environment.
REM     This script can be run on 11.5.x or higher.
REM
REM   ascp_performance_analyzer.sql
REM     
REM   	This script was created to collect all the required information to understand what performance impact 
REM   	embedded in Oracle Applications has on an VCP instance.
REM
REM
REM   How to run it? Follow the directions found in the Master Note XXXX1369938.1
REM   
REM   	sqlplus apps/<password>	@ascp_performance_analyzer.sql
REM
REM   
REM   Output file format found in the same directory if run manually
REM   
REM	ascp_performance_analyzer_<HOST_NAME>_<SID>_<DATE>.html
REM
REM
REM     Created: March 25th, 2013
REM     Last Updated: August 13th, 2014
REM
REM
REM  CHANGE HISTORY:
REM   1.00  25-MARCH-2013 MN Creation from design
REM   1.01  24-JUNE-2013  MN Updated for summary calculation logic
REM   1.02  10-OCT-2013  MN  Added DRP, IO Plan,ATP Data Pull,Legacy collections run trends
REM   1.5   13-Aug-2014 JJG Fixed bug, added graphs and reports
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2 
REM 
REM MENU_TITLE: ASCP Performance Analyzer
REM
REM MENU_START
REM
REM SQL: Run ASCP Performance Analyzer
REM FNDLOAD: ASCP Performance Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM
REM HELP_START  
REM  
REM  Compatible: 11i|12.0|12.1|12.2 
REM  
REM  Run ASCP Performance Analyzer script Help [Doc ID: 1554183.1] 
REM
REM  Explanation of available options:
REM
REM    (1) Run ASCP Performance Analyzer
REM        o Runs ascp_performance_analyzer.sql as APPS
REM        o Creates an HTML report file under MENU/output/ 
REM
REM    (2) Install ASCP Performance Analyzer as a Concurrent Program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "All MSC Reports" 
REM
REM 
REM HELP_END 
REM
REM FNDLOAD_START 
REM
REM PROD_TOP: MSC_TOP
REM PROG_NAME: MSCAPA_SQL
REM APP_NAME: Advanced Supply Chain Planning
REM DEF_REQ_GROUP: All MSC Reports
REM PROG_TEMPLATE: MSCAPA_SQL_prog.ldt
REM PROD_SHORT_NAME: MSC 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END

set arraysize 1
set heading off
set feedback off  
set echo off
set verify off
SET CONCAT ON
SET CONCAT .
SET ESCAPE OFF
SET ESCAPE '\'

set lines 120
set pages 9999
set serveroutput on size 100000

VARIABLE gv_schema     varchar2(30);
VARIABLE my_schema     varchar2(30);
VARIABLE TEST		VARCHAR2(240);
variable st_time 	varchar2(100);
variable et_time 	varchar2(100);
VARIABLE SID         	VARCHAR2(20);
VARIABLE HOST        	VARCHAR2(30);
VARIABLE INSTANCE_NAME 	VARCHAR2(16);
VARIABLE APPS_REL    	VARCHAR2(10);
VARIABLE SYSDATE        varchar2(12);
VARIABLE n		NUMBER;
VARIABLE cluster_db     VARCHAR2(10);
VARIABLE cluster_db_ins NUMBER;
VARIABLE DB_VER    	VARCHAR2(10);
VARIABLE v_ins          NUMBER;
VARIABLE v_cfc          NUMBER;
VARIABLE v_tot_time     NUMBER;
VARIABLE v_snap_time    NUMBER;
VARIABLE v_worker_time  NUMBER;
VARIABLE ecphy          NUMBER;
VARIABLE eclog          NUMBER;
VARIABLE ecphy1         NUMBER;
VARIABLE eclog1         NUMBER;
VARIABLE ecphy2         NUMBER;
VARIABLE eclog2         NUMBER;
VARIABLE ecphy3         NUMBER;
VARIABLE eclog3         NUMBER;
VARIABLE ecphy4         NUMBER;
VARIABLE eclog4         NUMBER;
VARIABLE ecphy5         NUMBER;
VARIABLE eclog5         NUMBER;
VARIABLE ecphy6         NUMBER;
VARIABLE eclog6         NUMBER;
VARIABLE numschemas	NUMBER;
VARIABLE chk		NUMBER;
VARIABLE ratio          NUMBER;
VARIABLE blk_size       NUMBER;
VARIABLE GB_Free        NUMBER;
VARIABLE Largest_GB     NUMBER;
VARIABLE GB_alloc       NUMBER;
VARIABLE GB_max         NUMBER;


Declare
  gv_schema		varchar2(30);
  my_schema		varchar2(30);
  test			varchar2(240);
  sid         		varchar2(20);
  host        		varchar2(30);
  instance_name 	varchar2(16);
  sysdate               varchar2(12);
st_time 	varchar2(100);
  apps_rel    		varchar2(10);
  n 			number;
  cluster_db            varchar2(10);
  cluster_db_ins        number;
  db_ver		varchar2(10); 
  ecphy                 number;
  eclog                 number;
  ecphy1                number;
  eclog1                number;
  ecphy2                number;
  eclog2                number;
  ecphy3                number;
  eclog3                number;
  ecphy4                number;
  eclog4                number;
  ecphy5                number;
  eclog5                number;
  ecphy6                number;
  eclog6                number;
  numschemas		number;
  chk			number;
  blk_size              number;
  ratio                 number;
  GB_Free               NUMBER;
  Largest_GB            NUMBER;
  GB_alloc              NUMBER;
  GB_max                NUMBER;
  
begin
select to_char(sysdate,'hh24:mi:ss') into :st_time from dual;

select to_char(sysdate, 'YYYY-Mon-DD') into :sysdate from dual;

end;
/

COLUMN host_name NOPRINT NEW_VALUE hostname
SELECT host_name from v$instance;
COLUMN instance_name NOPRINT NEW_VALUE instancename
SELECT instance_name from v$instance;
COLUMN sysdate NOPRINT NEW_VALUE when
select to_char(sysdate, 'YYYY-Mon-DD') "sysdate" from dual;
--SPOOL ascp_performance_analyzer_&&hostname._&&instancename._&&when..html


alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

prompt <HTML>
prompt <HEAD>
prompt <TITLE>ASCP Performance Analyzer</TITLE>
prompt <STYLE TYPE="text/css">
prompt <!-- TD {font-size: 10pt; font-family: calibri; font-style: normal} -->
prompt </STYLE>
prompt </HEAD>
prompt <BODY>

prompt <TABLE border="1" cellspacing="0" cellpadding="10">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD bordercolor="#DEE6EF"><font face="Calibri">
prompt <B><font size="+2">ASCP Performance Analyzer for 
select UPPER(instance_name) from v$instance;
prompt <B><font size="+2"> on 
select UPPER(host_name) from v$instance;
prompt </font></B></TD></TR>
prompt </TABLE><BR>

prompt <a href="https://support.oracle.com/rs?type=doc\&id=432.1" target="_blank">
prompt <img src="https://blogs.oracle.com/ebs/resource/Proactive/banner4.jpg" title="Click here to see other helpful Oracle Proactive Tools" width="758" height="81" border="0" alt="Proactive Services Banner" /></a></a>
prompt <br>

prompt <font size="-1"><i><b>ASCP Performance Analyzer v1.5 compiled on : 
select to_char(sysdate, 'Dy Month DD, YYYY') from dual;
prompt at 
select to_char(sysdate, ' hh24:mi:ss') from dual;
prompt </b></i></font><BR><BR>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td><font size="+1">
prompt This ASCP Performance Analyzer script reviews the current environment Footprint, analyzes runtime tables, profiles, settings, 
prompt and configurations for the overall environment, providing helpful feedback and recommendations on Best Practices for any areas for concern on your system.</font><BR>
Prompt <p><font size="+2">The analyzer results are influenced by statistics.  Please ensure that your statistics are recent before depending on the output.</font></p><BR>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

prompt <table width="95%" border="0">
prompt   <tr> 
prompt     <td colspan="2" height="46"> 
prompt       <p><a name="top"><b><font size="+2">Table of Contents</font></b></a> </p>
prompt     </td>
prompt   </tr>
prompt   <tr> 
prompt     <td width="50%"> 
prompt       <p><a href="#section1"><b><font size="+1">ASCP Performance Analyzer Overview</font></b></a> 
prompt         <br>
prompt       <blockquote> <a href="#adv111"> - E-Business Suite Version</a><br>
prompt         <a href="#adv112"> - Database Parameter Settings</a></br>
prompt         <a href="#adv113"> - ASCP Performance Related Profiles</a></blockquote>
prompt       <blockquote> 
prompt      <p><a href="#section2"><b><font size="+1">Verify ASCP Entity Data Volume</font></b></a><br><br>
prompt         <a href="#adv121"> - Value Chain Planning Segments Where Next Size is Larger Than Free Space Available Summary</a><br>
prompt         <a href="#adv122"> - Value Chain Planning Freespace by Tablespace in GB</a><br>
prompt         <a href="#adv123"> - Entity Data Volume for Collected Data (size in Megabytes)</a><br>
prompt       </blockquote>

prompt       <blockquote> 
prompt      <p><a href="#perfsection"><b><font size="+1">RDBMS Performance Indicators</font></b></a><br><br>
prompt         <a href="#perf1"> - Buffer Cache Hit Ratio Percent</a><br>
prompt         <a href="#perf2"> - Dictionary Cache Hit Ratio</a><br>
prompt         <a href="#perf3"> - Sorts in Memory</a><br>
prompt         <a href="#perf4"> - The percentage of FREE shared pool</a><br>
prompt         <a href="#perf5"> - Shared Pool Reloads</a><br>
prompt         <a href="#perf6"> - Freelist Performance Impact</a><br>
prompt       </blockquote>

prompt     </td>
prompt     <td width="50%"><a href="#section4"><b><font size="+1"> ASCP Concurrent Programs</font></b></a> <br>
prompt       <blockquote> 
prompt <a href="#adv141"><b><font size="+1">  ASCP Collection Programs</font></b></a> <br>
prompt <a href="#adv1422"> - Legacy Collections - Summary of Legacy Flat File Programs Run Time - 30 Days</a><br>
prompt <a href="#adv1423"> - Legacy Collections - Details of Legacy Collections Flat File Programs Runtime - 30 Days</a><br><br>
prompt <a href="#adv1424"> - Summary of Launch Supply Chain Planning Process Run Time - 30 Days</a><br>
prompt <a href="#adv1425"> - Details of Launch Supply Chain Planning Process Concurrent Programs Runtime - 15 Days</a> <br><br>
prompt <a href="#adv1427"> - Distribution Planning Process (DRP) - Summary of Launch Distribution  Planning Process Run Time - 30 Days</a><br>
prompt <a href="#adv1428"> - Distribution Planning Process (DRP) - Details of Launch Distribution  Planning Process Concurrent Programs Runtime - 30 Days</a><br><br>
prompt <a href="#adv1429"> - Inventory Planning Process(IO) - Summary of Launch Inventory Planning Process Run Time - 30 Days</a><br>
prompt <a href="#adv1430"> - Inventory Planning Process(IO) - Details of Launch Inventory Planning Process Concurrent Programs Runtime - 30 Days</a><br><br>
Prompt <a href="#adv1431"> - Advanced Planning Control Center (APCC) - Details of APCC Process Concurrent Programs Runtime - 30 Days</a><br>
prompt      </blockquote>   
prompt       <a href="#section8"><b><font size="+1">References</font></b></a> 
prompt       <blockquote></blockquote>
prompt     </td>
prompt   </tr>
prompt </table>

REM **************************************************************************************** 
REM *******                   Section 1 : ASCP Performance Analyzer Overview                 *******
REM ****************************************************************************************

prompt <a name="section1"></a><B><font size="+2">ASCP Performance Analyzer Overview</font></B><BR><BR>

begin

select upper(instance_name) into :sid from v$instance;

select substr(host_name,1,30) into :host from fnd_product_groups, v$instance;

select substr(release_name,1,10) into :apps_rel from fnd_product_groups, v$instance;

select value into :blk_size from v$parameter where name= 'db_block_size';

end;
/

REM **************************************************************************************** 
REM *******                   Section 1 : ASCP Performance Analyzer RDBMS Statistics *******
REM ****************************************************************************************


REM
REM ******* Ebusiness Suite Version *******
REM

prompt <script type="text/javascript">    function displayRows1sql1(){var row = document.getElementById("s1sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF">
prompt     <font face="Calibri"><a name="adv111"></a>
prompt      <B>E-Business Suite Version</B>
prompt     </font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql1()" >SQL Script</button></div>
prompt     </TD>
prompt </TR>
prompt <TR id="s1sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          select vi.instance_name, fpg.release_name, vi.host_name, vi.startup_time, vi.version <br>
prompt          from fnd_product_groups fpg, v$instance vi<br>
prompt          where upper(substr(fpg.APPLICATIONS_SYSTEM_NAME,1,4)) = upper(substr(vi.INSTANCE_NAME,1,4));</p>
prompt       </blockquote>
prompt     </TD>
prompt </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RELEASE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>HOSTNAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>STARTED</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DATABASE</B></TD>
prompt </TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||vi.instance_name||'</TD>'||chr(10)|| 
'<TD>'||fpg.release_name||'</TD>'||chr(10)|| 
'<TD>'||vi.host_name||'</TD>'||chr(10)|| 
'<TD>'||vi.startup_time||'</TD>'||chr(10)|| 
'<TD>'||vi.version||'</TD></TR>'
from fnd_product_groups fpg, v$instance vi
where upper(substr(fpg.APPLICATIONS_SYSTEM_NAME,1,4)) = upper(substr(vi.INSTANCE_NAME,1,4));
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>




REM
REM ******* Database Parameter Settings *******
REM

prompt <script type="text/javascript">    function displayRows1sql2(){var row = document.getElementById("s1sql2");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF">
prompt    <font face="Calibri"><a name="adv112"></a>
prompt     <B>Database Parameter Settings</B></font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql2()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql2" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="2" height="45">
prompt       <blockquote><p align="left">
prompt          select name, value<br>
prompt          from v$parameter<br>
prompt            ;</p>  
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>VALUE</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||name||'</TD>'||chr(10)|| 
'<TD>'||value||'</TD></TR>'
from v$parameter
where name not in ('control_files', 'db_block_size','_system_trig_enabled','O7_DICTIONARY_ACCESSIBILITY','nls_sort','nls_comp','nls_length_semantics','audit_trail','max_dump_file_size',
          'timed_statistics','processes','sessions','db_files','dml_locks','cursor_sharing','open_cursors','session_cached_cursors','sga_target','db_block_checking',
          'db_block_checksum','log_checkpoint_timeout','log_checkpoint_interval','log_buffer','log_checkpoints_to_alert','shared_pool_size','shared_pool_reserved_size','_shared_pool_reserved_min_alloc',
          'cursor_space_for_time','aq_tm_processes','job_queue_processes','parallel_max_servers','_sort_elimination_cost_ratio','_like_with_bind_as_equality','_fast_full_scan_enabled',
          '_b_tree_bitmap_plans','optimizer_secure_view_merging','_sqlexec_progression_cost','cluster_database','pga_aggregate_target','workarea_size_policy','olap_page_pool_size','sga_max_size',
          'compatible','undo_management','db_file_multiblock_read_count','max_enabled_roles','sec_case_sensitive_logon','distributed_lock_timeout','plsql_code_type','open_links',
          'optimizer_features_enable','sql_trace');
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

begin

select version into :db_ver from v$instance;

select value into :cluster_db from v$parameter where upper(name) = 'CLUSTER_DATABASE';

select value into :cluster_db_ins from v$parameter where upper(name) = 'CLUSTER_DATABASE_INSTANCES';

if (:db_ver like '8.%') or (:db_ver like '9.%') then 

    :db_ver := '0'||:db_ver;

end if;
    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">');
    dbms_output.put_line('<tbody><tr><td> ');
    dbms_output.put_line('      <p><B>Your ASCP Database Version is ('||:db_ver||') </B><BR>');
    dbms_output.put_line('RDBMS Settings for Oracle Apps can be checked for each RDBMS release:<BR>');
    dbms_output.put_line('<B>For 11i see <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=216205.1" target="_blank">Note 216205.1</a> Database Initialization Parameters for Oracle Applications 11i<BR> ');
    dbms_output.put_line('For R12 see <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=396009.1" target="_blank">Note 396009.1</a> Database Initialization Parameters for Oracle Applications Release 12.</B><BR>');
    dbms_output.put_line('</td></tr></tbody></table><BR>');
 
 if :cluster_db ='FALSE' then
    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">');
    dbms_output.put_line('<tbody><tr><td> ');
    dbms_output.put_line('      <p><B>Your RDBMS is not RAC install as your cluster_database is set to '||:cluster_db||' </B><BR>');
    dbms_output.put_line('</td></tr></tbody></table><BR>');
  else
       dbms_output.put_line('<table border="1" name="Warning" cellpadding="10" bgcolor="#DEE6EF" cellspacing="0">');
       dbms_output.put_line('<tbody><tr><td> ');
       dbms_output.put_line('<p><B>Warning</B><BR>');
       dbms_output.put_line('Your RDBMS is RAC install as your cluster_database is set to '||:cluster_db||' and you have '||:cluster_db_ins||' nodes on your RDBMS.<BR><BR>' );
       dbms_output.put_line('RAC install can cause ATP failures (ATP Processing Error) and require setup by DBA.<BR><BR>');
       dbms_output.put_line('Refer <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=266125.1" target="_blank">Note 266125.1</a> and see Section 24.3 for setup information.<BR><BR>');
       dbms_output.put_line('RAC install can cause failures in Planning and Data Collections, refer <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=279156.1" target="_blank">Note 279156.1</a> <BR><BR>');
       dbms_output.put_line('</p></td></tr></tbody></table><BR><BR>');
end if;
 
end;
/

exec :n := dbms_utility.get_time;
Declare
Cursor cdp1 is select name, value
              from v$parameter
              where name in ('control_files', 'db_block_size','_system_trig_enabled','O7_DICTIONARY_ACCESSIBILITY','nls_sort','nls_comp','nls_length_semantics','audit_trail','max_dump_file_size',
          'timed_statistics','processes','sessions','db_files','dml_locks','cursor_sharing','open_cursors','session_cached_cursors','sga_target','db_block_checking',
          'db_block_checksum','log_checkpoint_timeout','log_checkpoint_interval','log_buffer','log_checkpoints_to_alert','shared_pool_size','shared_pool_reserved_size','_shared_pool_reserved_min_alloc',
          'cursor_space_for_time','aq_tm_processes','job_queue_processes','parallel_max_servers','_sort_elimination_cost_ratio','_like_with_bind_as_equality','_fast_full_scan_enabled',
          '_b_tree_bitmap_plans','optimizer_secure_view_merging','_sqlexec_progression_cost','cluster_database','pga_aggregate_target','workarea_size_policy','olap_page_pool_size','sga_max_size',
          'compatible','undo_management','db_file_multiblock_read_count','max_enabled_roles','sec_case_sensitive_logon','distributed_lock_timeout','plsql_code_type','open_links',
          'optimizer_features_enable','sql_trace');
              
v_max_dump_file_size number;
v_ins   number;
v_cfc   number;

Begin
       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Recommendations for Database Parameters</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NAME</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>VALUE</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RECOMMENDATIONS</B></font></TD>');
       
For dp in cdp1
          LOOP

                
                dbms_output.put_line('<TR><TD>'||dp.name||'</TD>');                                                                                                     
		dbms_output.put_line('<TD>'||dp.value||'</TD>');   
                
         IF :apps_rel like '12%' THEN
         
                IF dp.name='control_files' THEN
                 v_cfc:=0;
                  select length(value)-length(replace(value,',',''))+1 fileCount into v_cfc
                  from v$parameter
                  where name ='control_files';
                  IF v_cfc >2 THEN
                    --dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('<TD>You have recommended value of atleast 3 control files'||'</TD></TR>');
                  ELSE
                  dbms_output.put_line('<TD>'||'<B>Warning</B>');
                  dbms_output.put_line('There should be at least two control files, preferably three,located on different volumes in case one of the volumes fails.');
                  dbms_output.put_line('Control files can expand, hence you should allow at least 20M per file for growth.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='db_block_size' THEN
                  IF dp.value= '8192' THEN
                    dbms_output.put_line('<TD>'||'You have recommended value of 8K'||'</TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'<B>Warning</B><BR>');
                    dbms_output.put_line('The required block size for Oracle E-Business Suite is 8K. No other value may be used'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='_system_trig_enabled' THEN
                  IF dp.value='TRUE' THEN
                   dbms_output.put_line('<TD>'||'You have recommended value of TRUE'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('The _system_trig_enabled parameter must be set to TRUE.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='O7_DICTIONARY_ACCESSIBILITY' THEN
                  IF dp.value='FALSE' THEN
                   dbms_output.put_line('<TD>'||'You have recommended value of FALSE'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('This parameter must be set to FALSE for Oracle E-Business Suite Release 12.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='nls_sort' THEN
                  IF lower(dp.value)='binary'  THEN
                   dbms_output.put_line('<TD>'||'You have recommended value of binary'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('This parameter must be set to binary'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='nls_comp' THEN
                  IF lower(dp.value)='binary' THEN
                   dbms_output.put_line('<TD>'||'You have recommended value of binary'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('This parameter must be set to binary'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='nls_length_semantics' THEN
                  IF dp.value='BYTE' THEN
                   dbms_output.put_line('<TD>'||'You have recommended value of BYTE'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('This parameter must be set to BYTE'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='audit_trail' THEN
                  IF dp.value='TRUE' THEN
                   dbms_output.put_line('<TD>'||'<B>Note!</B>');
                   dbms_output.put_line('You have recommended value of TRUE');
                   dbms_output.put_line('There is a performance overhead for enabling the audit_trail'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('This parameter must be set to TRUE, if you want audit_trail'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='max_dump_file_size' THEN
                  IF dp.value<>'unlimited' THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('It is recommended to set this to unlimited'||'</TD></TR>');
                  ELSIF dp.value='unlimited' THEN
                  dbms_output.put_line('<TD>'||'You have recommended value of unlimited'||'</TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('Check Value for this parameter'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='timed_statistics' THEN
                  IF dp.value='TRUE' THEN
                   dbms_output.put_line('<TD>'||'<B>Note!</B>');
                   dbms_output.put_line('You have recommended value of TRUE.');
                   dbms_output.put_line('On most platforms, enabling timed statistics has minimal effect on performance'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('This parameter must be set to TRUE, if you want use of SQL Trace and Statspack'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='processes' THEN
                  IF dp.value='200' THEN
                   dbms_output.put_line('<TD>'||'<B>Note!</B>');
                   dbms_output.put_line('The sessions parameter should be set to twice the value of the ');
                   dbms_output.put_line('processes parameter'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('The sessions parameter should be set to twice the value of the processes parameter'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='sessions' THEN
                  IF dp.value='400' THEN
                   dbms_output.put_line('<TD>'||'<B>Note!</B>');
                   dbms_output.put_line('The sessions parameter should be set to twice the value of the ');
                   dbms_output.put_line('processes parameter'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('The sessions parameter should be set to twice the value of the processes parameter'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='db_files' THEN
                  IF dp.value='512' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('512'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Max. no. of database files should be 512'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='dml_locks' THEN
                  IF dp.value='10000' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('10000'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('The number of dml_locks should be 10000'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='cursor_sharing' THEN
                  IF dp.value='EXACT' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('EXACT'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('The value should be EXACT'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='open_cursors' THEN
                  IF dp.value='600' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('600'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 600'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='session_cached_cursors' THEN
                  IF dp.value='500' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('500'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 500'||'</TD></TR>');
                  END IF;
                END IF;
                
                 IF dp.name='sga_target' THEN
                  IF dp.value>='1073741824' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('1G. For Oracle 10g and 11g, the automatic SGA tuning option (sga_target) is required'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 1G.'||'</TD></TR>');
                  END IF;
                END IF;
                
                 IF dp.name='db_block_checking' THEN
                  IF dp.value='FALSE' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('FALSE.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is FALSE.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='db_block_checksum' THEN
                  IF dp.value='TRUE' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('TRUE.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is TRUE.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='log_checkpoint_timeout' THEN
                  IF dp.value>='1200' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('atleast 20 mins.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 1200.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='log_checkpoint_interval' THEN
                  IF dp.value='100000' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('100000.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 100000.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='log_buffer' THEN
                  IF dp.value='10485760' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('10485760.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 10485760.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='log_checkpoints_to_alert' THEN
                  IF dp.value='TRUE' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('TRUE.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is TRUE.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='shared_pool_size' THEN
                  IF dp.value>='614400000' THEN
                    dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('600M.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 600M.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='shared_pool_reserved_size' THEN
                  IF dp.value>='61440000' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('60M.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 60M.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='_shared_pool_reserved_min_alloc' THEN
                  IF dp.value='4100' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of ' );
                   dbms_output.put_line('4100.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Recommended value for this is 4100.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='cursor_space_for_time' THEN
                  IF dp.value='FALSE' THEN 
                    dbms_output.put_line('<TD>'||'You have the default value of ' );
                   dbms_output.put_line('FALE.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('Cursor space for time requires at least a 50% increase in the size of the shared pool.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='aq_tm_processes' THEN
                  IF dp.value>='1' THEN 
                    dbms_output.put_line('<TD>'||'You have the minimum required value of' );
                   dbms_output.put_line('1.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='job_queue_processes' THEN
                  IF dp.value>='2' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('2.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='parallel_max_servers' THEN
                  IF dp.value>='8' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('8. Max. value should be 2 x no. of CPUs'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value.'||'</TD></TR>');
                  END IF;
                END IF;
                
                 IF dp.name='_sort_elimination_cost_ratio' THEN
                  IF dp.value='5' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('5.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value of 5.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='_like_with_bind_as_equality' THEN
                  IF dp.value='TRUE' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('TRUE.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value of TRUE.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='_fast_full_scan_enabled' THEN
                  IF dp.value='FALSE' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('FALSE.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value of FALSE.'||'</TD></TR>');
                  END IF;
                END IF;
                
                 IF dp.name='_b_tree_bitmap_plans' THEN
                  IF dp.value='FALSE' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('FALSE.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value of FALSE.'||'</TD></TR>');
                  END IF;
                END IF;
                
                 IF dp.name='optimizer_secure_view_merging' THEN
                  IF dp.value='FALSE' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('FALSE.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value of FALSE.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='_sqlexec_progression_cost' THEN
                  IF dp.value='2147483647' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('2147483647.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='cluster_database' THEN
                  IF dp.value='TRUE' THEN 
                    dbms_output.put_line('<TD>'||'You have the Oracle RAC environment' );
                   dbms_output.put_line('.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have Oracle RAC environment.'||'</TD></TR>');
                  END IF;
                END IF;
                
                 IF dp.name='pga_aggregate_target' THEN
                  IF dp.value>='1073741824' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('1G. '||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='workarea_size_policy' THEN
                  IF dp.value='AUTO' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('AUTO. The automatic memory manager is used to manage the PGA memory.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value.The automatic memory manager is used to manage the PGA memory.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='olap_page_pool_size' THEN
                  IF dp.value>='4194304' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='sga_max_size' THEN
                  IF dp.value< 3000000000 THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('It is recommended to set atleast 3GB'||'</TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'You have recommended value, but this may depend on your data volume'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name = 'compatible' THEN
                  IF dp.value<>:db_ver THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('Set this value to '||:db_ver||', which is your database version </TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'You have recommended value'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='undo_management' THEN
                  IF dp.value='AUTO' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('AUTO.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('You do not have the recommended value.'||'</TD></TR>');
                  END IF;
                END IF;
                
                 IF dp.name = 'db_file_multiblock_read_count' THEN
                  --IF dp.value<>:db_ver THEN
                  IF :db_ver like '10%' THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('You have database version '||:db_ver||', you should remove this parameter from your database initialization parameters file for Oracle Database 10g Release 2 </TD></TR>');
                  ELSIF :db_ver like '11%' THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('You have database version '||:db_ver||', you should remove this parameter from your database initialization parameters file for Oracle Database 11g Release X </TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'Check your value'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name = 'max_enabled_roles' THEN
                  --IF dp.value<>:db_ver THEN
                  IF :db_ver like '10%' THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('You have database version '||:db_ver||', you should remove this parameter from your database initialization parameters file for Oracle Database 10g Release 2 </TD></TR>');
                  ELSIF :db_ver like '11%' THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('You have database version '||:db_ver||', you should remove this parameter from your database initialization parameters file for Oracle Database 11g Release X </TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'Check your value'||'</TD></TR>');
                  END IF;
                END IF;
                
                 IF dp.name='sec_case_sensitive_logon' THEN
                  IF dp.value='FALSE' THEN 
                    dbms_output.put_line('<TD>'||'You have the recommended value of' );
                   dbms_output.put_line('FALSE.Oracle E-Business Suite now supports Oracle Database 11g case-sensitive database passwords');
                   dbms_output.put_line('This feature is available on E-Business Suite Rel 12.1.1 or higher'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('To enable this feature apply patch 12964564.'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name='distributed_lock_timeout' THEN
                  IF dp.value<300 THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('Set this value to 300'||'</TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'You have recommended value'||'</TD></TR>');
                  END IF;
                END IF;
                
                
                
                IF dp.name='plsql_code_type' THEN
                  IF (upper(dp.value) ='NATIVE' or upper(dp.value)='INTERPRETED') THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('You have recommended value, but this may depend on your data volume'||'</TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('Please review <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=396009.1#mozTocId991385"');
                    dbms_output.put_line('target="_blank">Note 396009.1</a> - for setting this value.</TD></TR><BR>');
                  END IF;
                END IF;
                
                select count(*) into :v_ins from MSC_APPS_INSTANCES;
                
                IF dp.name='open_links' THEN
                  IF dp.value<=:v_ins THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('You have '||:v_ins||' instances and open links should be equal to number of instances'||'</TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'You have recommended value'||'</TD></TR>');
                  END IF;
                END IF;
                
                IF dp.name = 'sql_trace' THEN
                  --IF dp.value<>:db_ver THEN
                  IF :db_ver like '11%' THEN
                    dbms_output.put_line('<TD>'||'<B>Warning</B>');
                    dbms_output.put_line('You have database version '||:db_ver||', you should remove this parameter from your database initialization parameters file for Oracle Database 10g Release 2 </TD></TR>');
                  ELSE
                    dbms_output.put_line('<TD>'||'Check your value'||'</TD></TR>');
                  END IF;
                END IF;
            
	   END IF;	          
          END LOOP;
        dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at DB Parameters'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* A Note on Database Initialization Parameters *******
REM    
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> 
prompt   <tr>     
prompt     <td> 
prompt       <p>Please refer to the following documents on Database Initialization Parameters for Oracle E-Business Suite.<br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=396009.1" target="_blank">
prompt Database Initialization Parameters for Oracle E-Business Suite Release 12(Doc ID 396009.1)</a><br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=216205.1" target="_blank">
prompt Database Initialization Parameters for Oracle E-Business Suite Release 11(Doc ID 216205.1)</a><br>
prompt </p>
prompt       </td>
prompt    </tr>
prompt    </tbody> 
prompt </table><BR><BR>

REM
REM ******* ASCP Performance Related Profiles *******
REM

prompt <script type="text/javascript">    function displayRows1sql3(){var row = document.getElementById("s1sql3");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF">
prompt    <font face="Calibri"><a name="adv113"></a>
prompt     <B>ASCP Performance Related Profiles</B></font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql3()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql3" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="2" height="45">
prompt       <blockquote><p align="left">
prompt          select fav.application_name, fpo1.user_profile_option_name profileName,<br>
prompt    substr(fpov.profile_option_value, 1, 52) pov,decode(fpov.level_id, 10001, 'Site', 10002, 'Appl', 10003, 'Resp', 10004, 'User', 'None') lvl,<br>
prompt      from   fnd_application_vl fav,,fnd_profile_options_vl fpo1,,fnd_profile_option_values fpov
prompt      where  fav.application_id=fpo1.application_id and fpo1.profile_option_id=fpov.profile_option_id <br>
prompt      and fpov.application_id    in fpo1.application_id and    fpov.profile_option_id =c_poi<br>
prompt and    ((fpov.level_id = 10001 and fpov.level_value = 0) or    (fpov.level_id = 10002 and fpov.level_value = fpo1.application_id)<br>
prompt or    (fpov.level_id = 10003 and fpov.level_value_application_id = fpo1.application_id <br>
prompt and    fpov.level_value = (select fnd_profile.value('RESP_ID') from dual)) or    (fpov.level_id = 10004 and fpov.level_value = (select fnd_profile.value('USER_ID') from dual))) <br>
prompt order  by fpov.level_id desc
prompt            ;</p>  
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ApplicationName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>UserProfileOptionName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProfileOptionValue</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SetAt</B></TD></TR>
exec :n := dbms_utility.get_time;
select 
'<TR><TD>'||fav.application_name||'</TD>'||chr(10)|| 
'<TD>'||fpo1.user_profile_option_name||'</TD>'||chr(10)||
'<TD>'||fpov.profile_option_value||'</TD>'||chr(10)||
'<TD>'||decode(fpov.level_id, 10001, 'Site', 10002, 'Appl', 10003, 'Resp', 10004, 'User', 'None')||'</TD></TR>'
  from   fnd_application_vl fav
        ,fnd_profile_options_vl fpo1
        ,fnd_profile_option_values fpov
  where  fav.application_id=fpo1.application_id
  and fpo1.profile_option_id=fpov.profile_option_id
  and fpov.application_id    in fpo1.application_id
  and    fpov.profile_option_id in (select fpo.profile_option_id poi from fnd_profile_options_vl fpo
                                    where fpo.user_profile_option_name in ('MRP:Debug Mode','MRP:Trace Mode','MRP:Planning Manager Batch Size','MRP:Planning Manager Max Workers',
                                    'MRP:Planner Batch Size','MRP:Snapshot Workers','MRP:Purge Batch Size','MRP:Snapshot Pause for Lock (Minutes)','MRP:Use Direct Load Option',
                                    'MRP:Plan Revenue price','MSC: Purge Staging and Entity Key Translation Tables','MSC: Share Plan Partitions',
                                    'MSC: Collection Window for Trading Partner Changes (Days)','MSO: Maximum Demands per Slice','MSO: Maximum Number of Pull for Operation',
                                    'MSO: Maximum Number of Prepones','MSC: Sequence Cache Size','MSC: Sales Orders Offset Days','MSC: Launch Analyze Plan Partition')
                                    and    fpo.start_date_active <= sysdate
                                    and    (nvl(fpo.end_date_active,sysdate) >= sysdate)
                                    )
  and    ((fpov.level_id = 10001 and fpov.level_value = 0)
   or    (fpov.level_id = 10002 and fpov.level_value = fpo1.application_id)
   or    (fpov.level_id = 10003 and fpov.level_value_application_id = fpo1.application_id 
  and    fpov.level_value = (select fnd_profile.value('RESP_ID') from dual)) 
   or    (fpov.level_id = 10004 and fpov.level_value = (select fnd_profile.value('USER_ID') from dual)))
  order  by fpov.level_id desc ;
  prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

    prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
    prompt <tbody><tr><td> 
    prompt Please review performance related profile documents:<BR>
    prompt <B>MRP and ASCP Performance Profile Setup <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=111955.1" target="_blank">Note 111955.1</a><BR> 
    prompt <B>Advanced Supply Chain Planning ASCP Performance TIPS Profile Options <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=209996.1" target="_blank">Note 209996.1</a></B><BR>
    prompt <B>Advanced Supply Chain Planning (ASCP) Profile Plan Option Matrix <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=803583.1" target="_blank">Note 803583.1</a> Performance Profiles </B><BR> 
    prompt </td></tr></tbody></table><BR>


REM **************************************************************************************** 
REM *******                   Section 2 : ASCP Entity Data Volume                    *******
REM ****************************************************************************************

prompt <a name="section2"></a><B><font size="+2">ASCP Database Objects Monitoring and RDBMS Overall Health</font></B><BR><BR>

REM
REM ******* Verify Entity Size in MB and Percent Fragmentation  *******
REM
begin

select round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2),
round((round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024/1024) - ((num_rows * avg_row_len) /1024/1024), 2) / round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2)), 2) * 100 into :ecphy,:eclog 
from dba_tables
where owner=upper('MSC')
and table_name=upper('MSC_SYSTEM_ITEMS');

select round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2),
round((round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024/1024) - ((num_rows * avg_row_len) /1024/1024), 2) / round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2)), 2) * 100 into :ecphy1,:eclog1 
from dba_tables
where owner=upper('MSC')
and table_name=upper('MSC_ITEM_CATEGORIES');

select round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2),
round((round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024/1024) - ((num_rows * avg_row_len) /1024/1024), 2) / round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2)), 2) * 100 into :ecphy2,:eclog2
	from dba_tables 
	where table_name = 'MSC_BOMS'
	and owner = 'MSC';
        
select round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2),
round((round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024/1024) - ((num_rows * avg_row_len) /1024/1024), 2) / round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2)), 2) * 100 into :ecphy3,:eclog3
	from dba_tables 
	where table_name = 'MSC_BOM_COMPONENTS'
	and owner = 'MSC';
        
select round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2),
round((round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024/1024) - ((num_rows * avg_row_len) /1024/1024), 2) / round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2)), 2) * 100 into :ecphy4,:eclog4
	from dba_tables 
	where table_name = 'MSC_DEMANDS'
	and owner = 'MSC';
        
select round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2),
round((round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024/1024) - ((num_rows * avg_row_len) /1024/1024), 2) / round(((blocks * (select value from v$parameter where name= 'db_block_size')) /1024 /1024), 2)), 2) * 100 into :ecphy5,:eclog5
	from dba_tables 
	where table_name = 'MSC_SUPPLIES'
	and owner = 'MSC';

end;
/
prompt <a name="adv120"></a><BR>
prompt <img src="http://chart.googleapis.com/chart?chxl=0:|MSC_SYSTEM_ITEMS|MSC_ITEM_CATEGORIES|MSC_BOMS|MSC_BOM_COMPONENTS|MSC_DEMANDS|MSC_SUPPLIES\&chdl=Entity Size MB|Fragmentation Percent\&chxs=0,676767,11.5,0,lt,676767\&chxtc=0,5\&chxt=y,x\&chds=a\&chs=600x425\&chma=0,0,0,5\&chbh=20,5,10\&cht=bhg
begin
  select '\&chd=t:'||:ecphy||','||:ecphy1||','||:ecphy2||','||:ecphy3||','||:ecphy4||','||:ecphy5||'\|'||:eclog||','||:eclog1||','||:eclog2||','||:eclog3||','||:eclog4||','||:eclog5 into :test from dual;
  dbms_output.put('\&chco=A2C180,3D7930');
  dbms_output.put(''||:test||'');
  dbms_output.put('\&chtt=ASCP Entity Size and Fragmentation Chart (size in Megabytes)" />');
  dbms_output.put_line('<br><br>');
end;
/
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

prompt <a name="section2"></a><B><font size="+2">Value Chain Planning count of segments that will not be able to allocate another extent.</font></B><BR>
prompt <a name="section2.1"></a><font size="+1">Not applicable to LMT (Locally Managed Tablespaces)</font><BR><BR>

prompt <script type="text/javascript">    function displayRows2sql50(){var row = document.getElementById("s2sql50");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv121"></a>
prompt     <B>Segments Where Free Space <= Next Extent</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows2sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s2sql50" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt          select substr(a.owner,1,12),<BR>
prompt          segment_type,<BR>
prompt          count(2) AS "Number of Segments"<BR>
prompt          from dba_segments a<BR>
prompt          where a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)<BR>
prompt          OR a.EXTENTS = a.MAX_EXTENTS<BR>
prompt          group by owner, segment_type<BR></p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR id="s2sql51" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="right">
prompt          select substr(a.tablespace_name,1,30) "TName",<BR>
prompt          substr(a.owner,1,12) "Owner",<BR>
prompt          substr(a.segment_name,1,30) "SegName",<BR>
prompt          a.next_extent "NextExt",<BR>
prompt          a.segment_type "SegType" <BR>
prompt          from dba_segments a<BR>
prompt          where a.owner = 'MSC' 
prompt          and a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)<BR>
prompt          OR a.EXTENTS = a.MAX_EXTENTS<BR>
prompt          order by a.next_extent;</p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Segment Extent Alert Count</B></TD> 
exec :n := dbms_utility.get_time;

Select '<TR><TD>'||count (*)||'</TD></TR>'
from (
SELECT a.SEGMENT_NAME, a.SEGMENT_TYPE, a.TABLESPACE_NAME, a.OWNER 
    FROM DBA_SEGMENTS a
    WHERE a.NEXT_EXTENT >= (SELECT MAX(b.BYTES)
        FROM DBA_FREE_SPACE b
        WHERE b.TABLESPACE_NAME = a.TABLESPACE_NAME)
    OR a.EXTENTS = a.MAX_EXTENTS
    OR a.EXTENTS = :blk_size);

prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


prompt <a name="section4"></a><B><font size="+2">Repair Segments that cannot allocate additional extents, from the count above.</font></B><BR><BR>

REM
REM ******* Discover and address segments that cannot allocate a next extent, if the count above is greater than zero. *******
REM
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt <p> There are three main reasons why an extent cannot be allocated to a segment:<br>
prompt The tablespace containing the segment does not have enough room for the next extent.<br>
prompt The segment has the maximum number of extents.<br>
prompt The segment has the maximum number of extents allowed by the data block size, which is operating system specific.<br><br>
prompt Once you have identified a segment that cannot allocate additional extents, you can solve the problem in either of two ways, depending on its cause:<br>
prompt If the tablespace is full, add a datafile to the tablespace or extend the existing datafile.<br>
prompt If the segment has too many extents, and you cannot increase MAXEXTENTS for the segment, perform the following steps.<br><br>
prompt Export the data in the segment<br><br>
prompt Drop and re-create the segment, giving it a larger INITIAL storage parameter setting so that it does not need to allocate so many extents. Alternatively, <br>
prompt you can adjust the PCTINCREASE and NEXT storage parameters to allow for more space in the segment.<br><br>
prompt Import the data back into the segment.<br><br>
prompt You can use the following SQL for a count by owner and segment type.  Then drill into the segments to discover the critical segment.<br><br>
prompt select substr(a.owner,1,12),<br>
prompt a.segment_type,<br>
prompt count(2)<br>
prompt from dba_segments a<br>
prompt where a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)<br>
prompt OR a.EXTENTS = a.MAX_EXTENTS<br>
prompt group by owner, segment_type;</p>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

REM **************   Space used

prompt <a name="section2"></a><B><font size="+2">Value Chain Planning Freespace by Tablespace in GB</font></B><BR>
prompt <a name="section2.1"></a><font size="+1">Reports ASSM or manually managed segments.</font><BR><BR>

prompt <script type="text/javascript">    function displayRows2sql1(){var row = document.getElementById("s2sql7");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv122"></a>
prompt     <B>Free Space by Tablespace</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows2sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s2sql7" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt        select extent_management Ext_Manage,<BR>
prompt         allocation_type Alloc_Type,<BR>
prompt         segment_space_management SPC_Manage,<BR>
prompt         substr(c.tablespace_name,1,25),<BR>
prompt        GB_alloc Gbytes, <BR>
prompt        GB_alloc-nvl(GB_free,0) used,<BR>
prompt        nvl(GB_free,0) free, <BR>
prompt        round(((GB_alloc-nvl(GB_free,0))/ GB_alloc)*100, 2) pct_used,<BR>
prompt        nvl(largest_GB,0) largest,<BR>
prompt        nvl(GB_max, GB_alloc) Max_Size,<BR>
prompt        from (select round(sum(bytes)/1024/1024,2) GB_free, <BR>
prompt         round(max(bytes)/1024/1024,2) largest_GB,<BR>
prompt         tablespace_name<BR>
prompt         from  sys.dba_free_space<BR> 
prompt         group by tablespace_name ) a,<BR>
prompt        ( select round(sum(bytes)/1024/1024,2) GB_alloc,<BR> 
prompt            round(sum(maxbytes)/1024/1024,2) GB_max,<BR>
prompt            tablespace_name <BR>
prompt            from sys.dba_data_files<BR> 
prompt            group by tablespace_name <BR>
prompt            union all<BR>
prompt            select round(sum(bytes)/1024/1024,2) GB_alloc,<BR> 
prompt            round(sum(maxbytes)/1024/1024,2) BB_max,<BR>
prompt            tablespace_name <BR>
prompt            from sys.dba_temp_files<BR> 
prompt            group by tablespace_name ) b,<BR>
prompt            dba_tablespaces c<BR>
prompt        where a.tablespace_name (+) = b.tablespace_name<BR>
prompt        and c.tablespace_name = b.tablespace_name<BR>
prompt        order by 1; </p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Ext_Manage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Alloc_Type</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SPC_Manage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Gbytes</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Used</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Free</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Used</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Largest</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Max_Size</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||extent_management||'</TD>'||chr(10)||
'<TD>'||allocation_type||'</TD>'||chr(10)||
'<TD>'||segment_space_management||'</TD>'||chr(10)||
'<TD>'||substr(c.tablespace_name,1,25)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_alloc,0)||'</TD>'||chr(10)||
'<TD>'||round((nvl(GB_alloc,0) - nvl(GB_free,0)),2)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_free,0)||'</TD>'||chr(10)||
'<TD>'||round(((nvl(GB_alloc,0) - nvl(GB_free,0))/ nvl(GB_alloc,0))*100, 2)||'</TD>'||chr(10)||
'<TD>'||nvl(largest_GB,0)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_max, nvl(GB_alloc,0))||'</TD></TR>'
from ( select tablespace_name,
nvl(round(sum(bytes)/1024/1024,2),0) GB_Free,
nvl(round(max(bytes)/1024/1024,2),0) Largest_GB
from  sys.dba_free_space
group by tablespace_name ) a,
( select tablespace_name,
  nvl(round(sum(bytes)/1024/1024,2),0) GB_alloc,
  nvl(round(sum(maxbytes)/1024/1024,2),0) GB_max
  from sys.dba_data_files
  group by tablespace_name
  union all
  select tablespace_name,
  nvl(round(sum(bytes)/1024/1024,2),0) GB_alloc,
  nvl(round(sum(maxbytes)/1024/1024,2),0) GB_max
  from sys.dba_temp_files
  group by tablespace_name )b,
  dba_tablespaces c
where a.tablespace_name (+) = b.tablespace_name
and c.tablespace_name = b.tablespace_name
order by 1;
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM **************    Fragmentation

prompt <a name="section2"></a><B><font size="+2">Oracle ASCP collected the entities as per data collection parameters.</FONT></B><BR>
prompt <a name="section2.1"></a><font size="+1">Large volume of data with high fragmentation percent affects performance of data collection and planning processes.</FONT><BR><BR>
prompt    </p>

prompt <script type="text/javascript">    function displayRows2sql1(){var row = document.getElementById("s2sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv123"></a>
prompt     <B>Entity Data Volume for Collected Data (size in Megabytes)</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows2sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s2sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt          select 1, 'Items' Entity, count(distinct inventory_item_id) EntityCount,'MSC_SYSTEM_ITEMS' TableName<br>
prompt          ,NUM_ROWS,to_char(round(blocks*8192/1024/1024),'999,999,999,999') LogicalTableSize
prompt          ,to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999') PhysicalTableSize
prompt          from msc_system_items   <br>
prompt          where plan_id=-1 GROUP BY 1, 'Items'<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SR No</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Entity</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EntityCount</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TableName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NumRows</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>LogicalTableSize</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PhysicalTableSize</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>LastAnalyzed</B></TD></TR>
exec :n := dbms_utility.get_time;
select a FROM
(select  
'<TR><TD>'||1||'</TD>'||chr(10)||
'<TD>'||'Items' ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(distinct inventory_item_id),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_SYSTEM_ITEMS'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>' a 
, 1 ordinal
from msc_system_items 
,dba_tables dt
where plan_id=-1 
and dt.table_name='MSC_SYSTEM_ITEMS'
GROUP BY 1, 'Items',num_rows,last_analyzed,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||2||'</TD>'||chr(10)||
'<TD>'||'Item Categories'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_ITEM_CATEGORIES'||'</TD>'||chr(10)|| 
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>' a , 2  
from MSC_ITEM_CATEGORIES 
,dba_tables dt
where dt.table_name='MSC_ITEM_CATEGORIES'
GROUP BY 2,'Item Categories',num_rows,last_analyzed,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||3||'</TD>'||chr(10)||
'<TD>'||'Component Substitutes'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_COMPONENT_SUBSTITUTES'||'</TD>'||chr(10)|| 
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
, 3 
from MSC_COMPONENT_SUBSTITUTES
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_COMPONENT_SUBSTITUTES'
GROUP BY 'Component Substitutes' ,num_rows ,last_analyzed,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||4||'</TD>'||chr(10)||
'<TD>'||'BOMs'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_BOMS'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,4
from MSC_BOMS
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_BOMS'
GROUP BY 4,'BOMs' ,num_rows,last_analyzed,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||5||'</TD>'||chr(10)||
'<TD>'||'BOM Components'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_BOM_COMPONENTS'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
, 5
from MSC_BOM_COMPONENTS 
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_BOM_COMPONENTS'
GROUP BY 5,'BOM Components' ,num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||6||'</TD>'||chr(10)||
'<TD>'||'Routings'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_ROUTINGS'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,6
from MSC_ROUTINGS
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_ROUTINGS'
GROUP BY 'Routings',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||7||'</TD>'||chr(10)||
'<TD>'||'Operations Components'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_OPERATION_COMPONENTS'||'</TD>'||chr(10)|| 
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,7
from MSC_OPERATION_COMPONENTS
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_OPERATION_COMPONENTS'
GROUP BY '7', 'Operations Components' ,num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||8||'</TD>'||chr(10)||
'<TD>'||'Routing Operations'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_ROUTING_OPERATIONS'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,8
from MSC_ROUTING_OPERATIONS
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_ROUTING_OPERATIONS'
GROUP BY '8', 'Routing Operations',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||9||'</TD>'||chr(10)||
'<TD>'||'Process Activity'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_PROCESS_EFFECTIVITY'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,9
from MSC_PROCESS_EFFECTIVITY
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_PROCESS_EFFECTIVITY'
GROUP BY '9', 'Process Activity',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||10||'</TD>'||chr(10)||
'<TD>'||'Operation Resources'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_OPERATION_RESOURCES'||'</TD>'||chr(10)|| 
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,10
from MSC_OPERATION_RESOURCES
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_OPERATION_RESOURCES'
GROUP BY '10', 'Operation Resources' ,num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||11||'</TD>'||chr(10)||
'<TD>'||'Demands'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_DEMANDS'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,11
from MSC_DEMANDS
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_DEMANDS'
GROUP BY '11', 'Demands',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||12||'</TD>'||chr(10)||
'<TD>'||'Supplies'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_SUPPLIES'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,12
from MSC_SUPPLIES
,dba_tables dt
where  plan_id=-1 
and dt.table_name='MSC_SUPPLIES'
GROUP BY '12', 'Supplies',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||13||'</TD>'||chr(10)||
'<TD>'||'Additional Sales orders'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_SALES_ORDERS'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,13 
from MSC_SALES_ORDERS 
,dba_tables dt
where dt.table_name='MSC_SALES_ORDERS'
GROUP BY '13', 'Additional Sales orders',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||14||'</TD>'||chr(10)||
'<TD>'||'Sourcing Rules'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_SOURCING_RULES'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,14
from MSC_SOURCING_RULES 
,dba_tables dt
where dt.table_name='MSC_SOURCING_RULES'
GROUP BY '14', 'Sourcing Rules',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||15||'</TD>'||chr(10)||
'<TD>'||'Assignment Sets'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_ASSIGNMENT_SETS'||'</TD>'||chr(10)|| 
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,15
from MSC_ASSIGNMENT_SETS 
,dba_tables dt
where dt.table_name='MSC_ASSIGNMENT_SETS'
GROUP BY '15', 'Assignment Sets',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||16||'</TD>'||chr(10)||
'<TD>'||'Trading Partners'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_TRADING_PARTNERS'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,16
from MSC_TRADING_PARTNERS 
,dba_tables dt
where dt.table_name='MSC_TRADING_PARTNERS'
GROUP BY '16', 'Trading Partners',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||17||'</TD>'||chr(10)||
'<TD>'||'Trading Partner Sites'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_TRADING_PARTNER_SITES'||'</TD>'||chr(10)||
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,17 
from MSC_TRADING_PARTNER_SITES 
,dba_tables dt
where dt.table_name='MSC_TRADING_PARTNER_SITES'
GROUP BY '17', 'Trading Partner Sites',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
union
select
'<TR><TD>'||18||'</TD>'||chr(10)||
'<TD>'||'Orgs Planned'  ||'</TD>'||chr(10)|| 
'<TD>'||to_char(count(*),'999,999,999,999') ||'</TD>'||chr(10)||
'<TD>'||'MSC_INSTANCE_ORGS'||'</TD>'||chr(10)|| 
'<TD>'||to_char(NUM_ROWS,'999,999,999,999')||'</TD>'||chr(10)||
'<TD><div align="right">'||to_char(round(blocks*8192/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)|| 
'<TD><div align="right">'||to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')||'</div></TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD></TR>'
,18
from MSC_INSTANCE_ORGS 
,dba_tables dt
where dt.table_name='MSC_INSTANCE_ORGS'
GROUP BY 18, 'Orgs Planned',num_rows,last_analyzed ,to_char(round(blocks*8192/1024/1024),'999,999,999,999'),to_char(round((num_rows*AVG_ROW_LEN)/1024/1024),'999,999,999,999')
)
order by ordinal;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *******                   Section 4 : ASCP Concurrent Programs               *******
REM ****************************************************************************************

prompt <a name="section4"></a><B><font size="+2">ASCP Concurrent Programs runtime for last 30 days</font></B><BR><BR>

REM
REM ******* Verify Planning Data Pull Process Concurrent Programs runtime *******
REM

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt <p>Oracle ASCP requires several Concurrent Programs to be run to process, progress, cleanup, and purge related information during planning stage.<BR>
prompt    This section displays these required Concurrent Programs.  <BR>
prompt    Note: This section is only looking at runtime concurrent request in FND_CONCURRENT_REQUESTS table.  <BR>
prompt    Jobs scheduled using other tools (DBMS_JOBS, CONSUB, or PL/SQL, etc) are not reflected here, so keep this in mind.<br>
prompt    The following table displays Concurrent requests that HAVE run, regardless of how they were scheduled (DBMS_JOBS, CONSUB, or PL/SQL, etc)<BR>
prompt    Keep in mind how often the Concurrent Requests Data is being purged.</p>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt  <tbody> 
prompt   <tr>     
prompt     <td> 
prompt       <p>Hyperlink of the request_id will take you to the table where you can see all the child requests and run times for the request_id.<br></p>
prompt     </td>
prompt   </tr>
prompt  </tbody> 
prompt </table><BR><BR>

exec :n := dbms_utility.get_time;
Declare
Cursor pdp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI:SS') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='Planning Data Pull'
              order by 1;

v_tot_time     NUMBER;
v_snap_time    NUMBER;
v_worker_time  NUMBER;

v_min_date date;
v_max_date date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv141">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of Planning Data Pull Run Time Past 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Snapshopt Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PullWorkerTime</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in pdp1
  LOOP
     v_tot_time:=null;
     v_snap_time:=null;
     v_worker_time:=null;
     
     v_min_date:=null;
     v_max_date:=null;
     
        select min(fcr.actual_start_date), max(fcr.actual_completion_date)
        --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        --into v_tot_time
        into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
    v_min_date:=null;
    v_max_date:=null;
     
   select min(fcr.actual_start_date), max(fcr.actual_completion_date)
   --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
     --   into v_snap_time
     into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcptl.user_concurrent_program_name like '%Refresh%Snapshot%'
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_snap_time:=round((v_max_date - v_min_date)*1440,2);
   
    v_min_date:=null;
    v_max_date:=null;
    
     select min(fcr.actual_start_date), max(fcr.actual_completion_date)
     --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
       -- into v_worker_time
       into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcptl.user_concurrent_program_name like '%Data Pull%Worker%'
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_worker_time:=round((v_max_date - v_min_date)*1440,2);
   
   IF nvl(v_snap_time,0) = 0 THEN
   v_snap_time:=v_tot_time-v_worker_time;
   END IF;
   
       -- dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');    
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');   
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||v_snap_time||'</TD>');
        dbms_output.put_line('<TD>'||v_worker_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at PDP Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     

REM
REM ******* A Note on Refresh snapshots in distributed environment *******
REM    
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> 
prompt   <tr>     
prompt     <td> 
prompt       <p>If Refresh Collection Snapshots does not appear in the below output, then this is a distributed install.
prompt To calculate the time for Refresh Snapshots,take time for the Planning Data Pull and subtract time for the Planning Data Pull workers.<br>
prompt For example, IF planning Data Pull took 60 minutes and the Planning Data Pull workers took 25 mins, then Refresh Snapshots took 35 mins to run.<br>
prompt </p>
prompt       </td>
prompt    </tr>
prompt    </tbody> 
prompt </table><BR><BR>


prompt <script type="text/javascript">    function displayRows4sql1(){var row = document.getElementById("s4sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv141"></a>
prompt     <B>Details of Planning Data Pull Concurrent Programs Runtime - 30 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-30
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='Planning Data Pull')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>
  
REM
REM ******* A Note on Refresh snapshots in distributed environment *******
REM    
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> 
prompt   <tr>     
prompt     <td> 
prompt       <p>If Refresh Collection Snapshots does not appear in the above output, then this is a distributed install.
prompt To calculate the time for Refresh Snapshots,take time for the Planning Data Pull and subtract time for the Planning Data Pull workers.<br>
prompt For example, IF planning Data Pull took 60 minutes and the Planning Data Pull workers took 25 mins, then Refresh Snapshots took 35 mins to run.<br>
prompt </p>
prompt       </td>
prompt    </tr>
prompt    </tbody> 
prompt </table><BR><BR>

REM
REM ******* Verify ATP Data Pull Process Concurrent Programs runtime *******
REM

exec :n := dbms_utility.get_time;
Declare
Cursor pdp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI:SS') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='ATP Data Pull'
              order by 1;

v_tot_time     NUMBER;
v_snap_time    NUMBER;
v_worker_time  NUMBER;

v_min_date date;
v_max_date date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1401">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of ATP Data Pull Run Time - 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Snapshopt Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PullWorkerTime</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in pdp1
  LOOP
     v_tot_time:=null;
     v_snap_time:=null;
     v_worker_time:=null;
     
     v_min_date:=null;
     v_max_date:=null;
     
        select min(fcr.actual_start_date), max(fcr.actual_completion_date)
        --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        --into v_tot_time
        into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
    v_min_date:=null;
    v_max_date:=null;
     
   select min(fcr.actual_start_date), max(fcr.actual_completion_date)
   --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
     --   into v_snap_time
     into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcptl.user_concurrent_program_name like '%Refresh%Snapshot%'
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_snap_time:=round((v_max_date - v_min_date)*1440,2);
   
    v_min_date:=null;
    v_max_date:=null;
    
     select min(fcr.actual_start_date), max(fcr.actual_completion_date)
     --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
       -- into v_worker_time
       into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcptl.user_concurrent_program_name like '%Data Pull%Worker%'
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_worker_time:=round((v_max_date - v_min_date)*1440,2);
   
   IF nvl(v_snap_time,0) = 0 THEN
   v_snap_time:=v_tot_time-v_worker_time;
   END IF;
   
       -- dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');    
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');   
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||v_snap_time||'</TD>');
        dbms_output.put_line('<TD>'||v_worker_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at ATP Data Pull Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     

prompt <script type="text/javascript">    function displayRows4sql11(){var row = document.getElementById("s4sql11");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1401"></a>
prompt     <B>Details of ATP Data Pull Concurrent Programs Runtime - 30 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql11()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql11" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-30
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='ATP Data Pull')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* Verify Planning ODS Load Process Concurrent Programs runtime *******
REM

exec :n := dbms_utility.get_time;
Declare
Cursor pdp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='Planning ODS Load'
              order by 1;

cursor odsw (p_request_id number) is select fcr.request_id, round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2) TimeTaken
                ,to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS') Submitted
            from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
                           fcr1.request_id 
                      from fnd_concurrent_requests fcr1
                     where 1=1          start with fcr1.request_id = p_request_id
                  connect by prior fcr1.request_id = fcr1.parent_request_id) x,
                   fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
             where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
               and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
               and fcptl.USER_CONCURRENT_PROGRAM_NAME like '%Load Worker'
               and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';

v_tot_time     NUMBER;
v_worker_time NUMBER;

v_min_date  date;
v_max_date date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv142">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of Planning ODS Load Run time - 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in pdp1
  LOOP
     v_tot_time:=null;
     v_worker_time:=null;
     v_min_date :=null;
     v_max_date :=null;
     
        select round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        into v_tot_time
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcptl.USER_CONCURRENT_PROGRAM_NAME not like '%Load Worker'
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
  /* 
   For odsw1 in odsw (pdp.request_id)
    LOOP
      IF v_worker_time is null THEN
            v_worker_time:=odsw1.timetaken;
            v_worker_date:=odsw1.submitted;
      END IF;
      
      IF v_worker_time < odsw1.timetaken THEN
          v_worker_time:=odsw1.timetaken;
      END IF;
     END LOOP;
    v_tot_time:=v_tot_time+v_worker_time;
   */
   
    select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               min(fcr1.actual_start_date),max(fcr1.actual_completion_date)
               into v_min_date,v_max_date
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id ;
   
       v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
        --dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');  
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at ODS Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     


prompt <script type="text/javascript">    function displayRows4sql2(){var row = document.getElementById("s4sql2");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv142"></a>
prompt     <B>Details of Planning ODS Load Concurrent Programs Runtime - 30 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql2()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql2" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)||  
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-30
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='Planning ODS Load')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>  

REM
REM ******* Verify Legacy Collections Self Service Process Concurrent Programs runtime *******
REM

exec :n := dbms_utility.get_time;
Declare
Cursor pdp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='User File Upload'
              order by 1;

cursor odsw (p_request_id number) is select fcr.request_id, round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2) TimeTaken
                ,to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS') Submitted
            from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
                           fcr1.request_id 
                      from fnd_concurrent_requests fcr1
                     where 1=1          start with fcr1.request_id = p_request_id
                  connect by prior fcr1.request_id = fcr1.parent_request_id) x,
                   fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
             where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
               and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
               and fcptl.USER_CONCURRENT_PROGRAM_NAME like '%Load Worker'
               and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';

v_tot_time     NUMBER;
v_worker_time NUMBER;

v_min_date  date;
v_max_date date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1421">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of Legacy Self Service Programs Run Time - 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in pdp1
  LOOP
     v_tot_time:=null;
     v_worker_time:=null;
     v_min_date :=null;
     v_max_date :=null;
     
        select round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        into v_tot_time
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcptl.USER_CONCURRENT_PROGRAM_NAME not like '%Load Worker'
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
  /* 
   For odsw1 in odsw (pdp.request_id)
    LOOP
      IF v_worker_time is null THEN
            v_worker_time:=odsw1.timetaken;
            v_worker_date:=odsw1.submitted;
      END IF;
      
      IF v_worker_time < odsw1.timetaken THEN
          v_worker_time:=odsw1.timetaken;
      END IF;
     END LOOP;
    v_tot_time:=v_tot_time+v_worker_time;
   */
   
    select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               min(fcr1.actual_start_date),max(fcr1.actual_completion_date)
               into v_min_date,v_max_date
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id ;
   
       v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
        --dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');  
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at Legacy Self Service Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     


prompt <script type="text/javascript">    function displayRows4sql201(){var row = document.getElementById("s4sql201");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1421"></a>
prompt     <B>Details of Legacy Collections Self Service Programs Runtime - 30 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql201()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql201" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)||  
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-30
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='User File Upload')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>  

REM
REM ******* Verify Legacy Collections Flat File Process Concurrent Programs runtime *******
REM

exec :n := dbms_utility.get_time;
Declare
Cursor pdp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='Report Set'
                and cr.description='Legacy Collections'
              order by 1;

cursor odsw (p_request_id number) is select fcr.request_id, round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2) TimeTaken
                ,to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS') Submitted
            from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
                           fcr1.request_id 
                      from fnd_concurrent_requests fcr1
                     where 1=1          start with fcr1.request_id = p_request_id
                  connect by prior fcr1.request_id = fcr1.parent_request_id) x,
                   fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
             where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
               and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
               and fcptl.USER_CONCURRENT_PROGRAM_NAME like '%Load Worker'
               and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';

v_tot_time     NUMBER;
v_worker_time NUMBER;

v_min_date  date;
v_max_date date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1422">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of Legacy Flat File Programs Run Time - 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in pdp1
  LOOP
     v_tot_time:=null;
     v_worker_time:=null;
     v_min_date :=null;
     v_max_date :=null;
     
        select round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        into v_tot_time
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcptl.USER_CONCURRENT_PROGRAM_NAME not like '%Load Worker'
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
  /* 
   For odsw1 in odsw (pdp.request_id)
    LOOP
      IF v_worker_time is null THEN
            v_worker_time:=odsw1.timetaken;
            v_worker_date:=odsw1.submitted;
      END IF;
      
      IF v_worker_time < odsw1.timetaken THEN
          v_worker_time:=odsw1.timetaken;
      END IF;
     END LOOP;
    v_tot_time:=v_tot_time+v_worker_time;
   */
   
    select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               min(fcr1.actual_start_date),max(fcr1.actual_completion_date)
               into v_min_date,v_max_date
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id ;
   
       v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
        --dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');  
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at Legacy Flat File Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     


prompt <script type="text/javascript">    function displayRows4sql202(){var row = document.getElementById("s4sql202");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1423"></a>
prompt     <B>Details of Legacy Collections Flat File Programs Runtime - 30 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql202()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql202" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)||  
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-30
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='Report Set'
                                        and cr.description='Legacy Collections')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>  

REM
REM ******* Verify Launch Supply Chain Planning Process Concurrent Programs runtime *******
REM

exec :n := dbms_utility.get_time;
prompt <a name="adv1424"></a>
Declare
Cursor pdp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI:SS') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='Launch Supply Chain Planning Process'
              order by 1;

v_tot_time     NUMBER;
v_min_date    date;
v_max_date    date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1424">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of Launch Supply Chain Planning Process Run Time - 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in pdp1
  LOOP
     v_tot_time:=null;
     v_min_date:=null;
     v_max_date:=null;
     
        select min(fcr.actual_start_date), max(fcr.actual_completion_date)
        --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        --into v_tot_time
        into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
        --dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');                                                                                                     
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at Launch Plan Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     

prompt <a name="adv1425"></a>
prompt <script type="text/javascript">    function displayRows4sql3(){var row = document.getElementById("s4sql3");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1425"></a>
prompt     <B>Details of Launch Supply Chain Planning Process Concurrent Programs Runtime - 15 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql3()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql3" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-15
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='Launch Supply Chain Planning Process')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* Verify Launch Distribution  Planning Process Concurrent Programs runtime *******
REM

exec :n := dbms_utility.get_time;
Declare
Cursor drp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI:SS') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='Launch Distribution  Planning Process'
              order by 1;

v_tot_time     NUMBER;
v_min_date    date;
v_max_date    date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1427">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of Launch Distribution  Planning Process Run Time - 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in drp1
  LOOP
     v_tot_time:=null;
     v_min_date:=null;
     v_max_date:=null;
     
        select min(fcr.actual_start_date), max(fcr.actual_completion_date)
        --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        --into v_tot_time
        into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
        --dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');                                                                                                     
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at DRP Launch Plan Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     


prompt <script type="text/javascript">    function displayRows4sql4(){var row = document.getElementById("s4sql4");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1428"></a>
prompt     <B>Details of Launch Distribution  Planning Process Concurrent Programs Runtime - 30 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql4()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql4" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-30
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='Launch Distribution  Planning Process')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* Verify Launch Inventory Planning Process Concurrent Programs runtime *******
REM

exec :n := dbms_utility.get_time;
Declare
Cursor drp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI:SS') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='Launch Inventory Planning Process'
              order by 1;

v_tot_time     NUMBER;
v_min_date    date;
v_max_date    date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1429">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of Launch Inventory Planning Process Run Time - 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in drp1
  LOOP
     v_tot_time:=null;
     v_min_date:=null;
     v_max_date:=null;
     
        select min(fcr.actual_start_date), max(fcr.actual_completion_date)
        --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        --into v_tot_time
        into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
        --dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');                                                                                                     
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at IO Launch Plan Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     


prompt <script type="text/javascript">    function displayRows4sql5(){var row = document.getElementById("s4sql5");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1430"></a>
prompt     <B>Details of Launch Inventory Planning Process Concurrent Programs Runtime - 30 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql5()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql5" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-30
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='Launch Inventory Planning Process')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* Verify APCC Process Concurrent Programs runtime *******
REM

exec :n := dbms_utility.get_time;
Declare
Cursor drp1 is select request_id,
                  substr(DECODE (CR.DESCRIPTION,  NULL,  FCPT.USER_CONCURRENT_PROGRAM_NAME, CR.DESCRIPTION||' ('||FCPT.USER_CONCURRENT_PROGRAM_NAME||')'),1,80) Program_Name,
                  to_char(cr.actual_start_date,'DD-MON-YYYY HH24:MI:SS') start_time,
                  cr.argument_text
              from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-30
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='Archive Plan Summary'
              order by 1;

v_tot_time     NUMBER;
v_min_date    date;
v_max_date    date;

Begin

       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv150">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Summary of APCC Process Run Time - 30 Days</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RequestId</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total Time</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></font></TD>');
       
For pdp in drp1
  LOOP
     v_tot_time:=null;
     v_min_date:=null;
     v_max_date:=null;
     
        select min(fcr.actual_start_date), max(fcr.actual_completion_date)
        --round(sum((fcr.actual_completion_date - fcr.actual_start_date)*1440),2) Tot_Time
        --into v_tot_time
        into v_min_date, v_max_date
        from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id = pdp.request_id
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';
   
   v_tot_time:= round((v_max_date - v_min_date)*1440,2);
   
        --dbms_output.put_line('<TR><TD>'||pdp.request_id||'</TD>');                                                                                                     
        dbms_output.put_line('<TR><TD> <a href="#'||pdp.request_id||'"</a>'||pdp.request_id||'</TD>');
        dbms_output.put_line('<TD>'||pdp.program_name||'</TD>');
        dbms_output.put_line('<TD>'||pdp.start_time||'</TD>');
        dbms_output.put_line('<TD>'||v_tot_time||'</TD>');
        dbms_output.put_line('<TD>'||pdp.argument_text||'</TD>');
  
  END LOOP;
  dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at APCC Total Time'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>     


prompt <script type="text/javascript">    function displayRows4sql61(){var row = document.getElementById("s4sql61");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv1431"></a>
prompt     <B>Details of APCC Process Concurrent Programs Runtime - 30 Days</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql61()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql61" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select /*+ ORDERED USE_NL(x fcr fcp fcptl)*/<br>
prompt          fcr.request_id    "Request ID", fcr.requested_by "User",  <br>
prompt          substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)"Program Name",<br>
prompt      (fcr.actual_completion_date - fcr.actual_start_date)*1440 "Elapsed Time",  oracle_process_id "Trace File ID" , <br>
prompt    fcr.phase_code "Phase",  fcr.status_code "Status", to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')   "Submitted", <br>
prompt  (fcr.actual_start_date - fcr.request_date)*1440 "Delay", to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')  "Start Time", <br>
prompt   to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') "End Time", fcr.argument_text "Parameters" <br>
prompt          from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */ <br>
prompt            fcr1.request_id <br>
prompt         where 1=1          start with fcr1.request_id=p_request_id <br>
prompt          connect by prior fcr1.request_id = fcr1.parent_request_id) x, <br>
prompt          fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl <br>
prompt          where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id <br>
prompt          and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id <br>
prompt          and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US';<br>
prompt          order by 1;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>REQUEST_ID</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>User</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProgramName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ElaspsedTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TraceFileId</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phase</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Submitted</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Delay</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>StartTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>EndTime</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Parameters</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD><a name="#'||fcr.request_id||'"</a>'||fcr.request_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.requested_by||'</TD>'||chr(10)|| 
'<TD>'||substr(DECODE (FCR.DESCRIPTION,  NULL,  FCPTL.USER_CONCURRENT_PROGRAM_NAME, FCR.DESCRIPTION||' ('||FCPTL.USER_CONCURRENT_PROGRAM_NAME||')'),1,80)||'</TD>'||chr(10)|| 
'<TD>'||round((fcr.actual_completion_date - fcr.actual_start_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||oracle_process_id||'</TD>'||chr(10)|| 
'<TD>'||fcr.phase_code||'</TD>'||chr(10)||
'<TD>'||fcr.status_code||'</TD>'||chr(10)|| 
'<TD>'||to_char(fcr.request_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||  
'<TD>'||round((fcr.actual_start_date - fcr.request_date)*1440,2)||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_start_date,'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||to_char(fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS')||'</TD>'||chr(10)||
'<TD>'||fcr.argument_text||'</TD>'
from (select /*+ index (fcr1 FND_CONCURRENT_REQUESTS_N3) */
               fcr1.request_id 
          from fnd_concurrent_requests fcr1
         where 1=1          start with fcr1.request_id in (select request_id 
                                        from fnd_concurrent_requests cr
                                            ,fnd_concurrent_programs cp
                                            ,fnd_concurrent_programs_tl fcpt
                                      where trunc(cr.request_date) >=trunc(sysdate)-30
                                         and cr.concurrent_program_id=cp.concurrent_program_id
                                        and cp.concurrent_program_id=fcpt.concurrent_program_id
                                        and  fcpt.user_concurrent_program_name ='Archive Plan Summary')
      connect by prior fcr1.request_id = fcr1.parent_request_id) x,
       fnd_concurrent_requests fcr, fnd_concurrent_programs fcp,fnd_concurrent_programs_tl fcptl
 where fcr.request_id = x.request_id    and fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id  and fcp.application_id = fcptl.application_id
   and fcp.concurrent_program_id = fcptl.concurrent_program_id and fcptl.language = 'US'
   Order by 1;
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM **************************************************************************************** 
REM *******                   Section 1 : ASCP Performance Analyzer RDBMS Statistics *******
REM ****************************************************************************************

prompt <a name="perfsection"></a><B><font size="+2">RDBMS Performance Indicators</font></B><BR><BR>

REM *************  Buffer Cache Hit Ratio Percent

prompt <a name="perf1"></a><B><font size="+2">Buffer Cache Hit Ratio Percent</font></B><BR><BR>

begin

select round((1-(pr.value/(bg.value+cg.value)))*100,2) into :ratio
from v$sysstat pr, v$sysstat bg, v$sysstat cg
where pr.name='physical reads'
and bg.name='db block gets'
and cg.name='consistent gets';

dbms_output.put_line('<b>Buffer Cache Hit Percent Gauge</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

if (:ratio < 80) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 80 percent.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

  else   if (:ratio between 81 and 95) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:90');
  dbms_output.put('\&chl=fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 95 percent.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put_line('<b>Workflow Runtime Data Table Gauge</b><BR>');
  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your cache hit percent is good.  No performance impact.</font><BR><BR> ');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM *************  Dictionary Cache Hit Ratio

prompt <a name="perf2"></a><B><font size="+2">Dictionary Cache Hit Ratio</font></B><BR><BR>

begin

select round(sum(gets-getmisses)*100/sum(gets),2) into :ratio
from v$rowcache;

dbms_output.put_line('<b>Data Dictionary Hit Percent Gauge</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

if (:ratio < 70) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR>');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

  else if (:ratio between 70 and 90) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:80');
  dbms_output.put('\&chl=fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR> ');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR> ');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('<p><B>Note:</B> The dictionary cache hit ratio is a measure of the proportion of requests for information from the data dictionary, the collection of database tables and views containing reference.<BR>');
    dbms_output.put_line('information about the database, its structures and its users. On instance startup, the data dictionary cache contains no data, so any SQL statement issued is likely to result in cache<br>');
    dbms_output.put_line('misses. As more data is read into the cache, the likelihood of cache misses should decrease. Eventually the database should reach a steady state in which the most frequently used');
    dbms_output.put_line('dictionary data is in the cache.</p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM *************  Sorts in Memory

prompt <a name="perf3"></a><B><font size="+2">Sorts in Memory</font></B><BR><BR>

begin

select round((mem.value/(mem.value+dsk.value))*100,2) into :ratio
from v$sysstat mem, v$sysstat dsk
where mem.name='sorts (memory)'
and dsk.name='sorts (disk)';

dbms_output.put_line('<b>Sorts in Memory Percent Gauge</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

if (:ratio < 70) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">This is a measure of the proportion of data sorts which occur within memory rather than on disk.</p><BR><BR>');
    dbms_output.put_line('<p>Sorts on disk make use of the users tempoary table space.  The maximum size of sort which will occur in memory is defined by the sort area size, </p><BR>');
    dbms_output.put_line('<p>which is the size within the PGA which will be used. Each Oracle process which sorts will allocate this much memory, though it may not use all of it.</p><BR>');
    dbms_output.put_line('<p>Use of memory for this purpose reduces that available to the SGA.</p><BR>');
    dbms_output.put_line('<p>The sorts are too large to fit in memory and some of the sort data is written out directly to disk. This data is later read back in, using direct reads.</p><BR>');
dbms_output.put_line('<p>With larger Sort Areas in memory, the likelihood of them being exhausted during a sorting operation and having to use a temporary tablespace on disk is reduced.</font></p><BR>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Normally, if expensive sorts are hurting your SQL performance, you will notice it elsewhere first.</font></p>');
    dbms_output.put_line('<p>Your sort in memory percent seems healthy.</p><BR><BR>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
end if;
end;
/

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM *************  Free Shared Pool %

prompt <a name="perf4"></a><B><font size="+2">The percentage of FREE shared pool</font></B><BR><BR>

begin

select round((sum(decode(name,'free memory',bytes,0))/sum(bytes))*100,2) into :ratio from v$sgastat where pool = 'shared pool';

dbms_output.put_line('<b>The percentage of FREE shared pool</b>'||'<font size="+1"> Your Free Percent is: '||:ratio||'</font><BR><BR>');

if (:ratio > 10) THEN

    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+2">This percentage has greater value when the collection process is runnging.  Afterwards the shared pool will be released.</font></p><BR> ');
    dbms_output.put_line('<p><font size="+1">The percentage of shared pool free, not in use.  This statistic is valuable as you notice a trend.  For example, if a large percentage of the shared pool,<BR></p>');
    dbms_output.put_line('<p>is consistenly free, it is likely that the size of the shared pool can be reduced.  However, lower free values are not necessarily a problem unless other<BR></p>');
    dbms_output.put_line('<p>factors point to problems.  For example, poor dictionary cache hit ratio or a large proportion of reloads.</p></font><BR>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

else

    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">This percentage has greater importance when the collection process is runnging.  Afterwards, the shared pool will be released.</font></p>');
    dbms_output.put_line('<p>The percentage of free shared pool is less than 10 %.  It is recommended that that the pool is reviewed if you desire additional space.</p><BR>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
end if;
end;
/

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM ****************    Shared Pool Reloads

prompt <a name="perf5"></a><B><font size="+2">Shared Pool Reloads</font></B><BR><BR>

begin

select round(sum(reloads)/sum(pins)*100,2) into :ratio
from v$librarycache
where namespace in ('SQL AREA','TABLE/PROCEDURE','BODY','TRIGGER');

dbms_output.put_line('<b>Shared Pool Reloads Percent</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">It is best if the percentage is low.  We recommend reviewing the following should the percentage be 65% or greater.</font><BR>');
    dbms_output.put_line('<p>Shared pool reloads occur when Oracle has to implicitly reparse SQL or PL/SQL at execution.  A larger shared pool will reduce implicit reparsing.');
    dbms_output.put_line('<p>Ensuring that similar pieces of SQL are written identically will increase sharing of code.  Review the parameter CURSOR_SHARING.  To make use of additional');
    dbms_output.put_line('<p>shared SQL  memory that is available for shared SQL areas, review the parameter OPEN_CURSORS permitted for a session.  Review the parameters open_cursors');
    dbms_output.put_line('<p>and CURSOR_SHARING.<BR>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

end;
/

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM ****************  FREELIST

prompt <a name="perf6"></a><B><font size="+2">Freelist Performance Impact</font></B><BR><BR>

begin

select round((sum(decode(w.class,'free list',count,0))/
(sum(decode(name,'db block gets',value,0))
+ sum(decode(name,'consistent gets',value,0))))*100,2) into :ratio
from v$waitstat w, v$sysstat;

dbms_output.put_line('<b>Free List Contention Performance Impact Gauge</b>'||'<font size="+1"> Your impact is: '||:ratio||'</font><BR><BR>');

if (:ratio < 20) THEN

    dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
    dbms_output.put('\&chxt=y');
    dbms_output.put('\&chs=500x250');
    dbms_output.put('\&cht=gm');
    dbms_output.put('\&chco=000000,05FA00|FF0000');
    dbms_output.put('\&chd=t:5');
    dbms_output.put('\&chl=Low" width="500" height="250" alt="" />');
    dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your Freelist contention is LOW performance impact.</font><BR> ');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

  else if (:ratio between 21 and 40) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:40');
  dbms_output.put('\&chl=Fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">In tablespaces with manual segment-space management, Oracle Database uses the FREELISTS storage parameter to improve performance of space management in</p><BR> ');
    dbms_output.put_line('<p>OLTP systems by increasing the number of insert points in the segment. In tablespaces with automatic segment-space management, this parameter is ignored,</p><BR> ');
    dbms_output.put_line('<p>because the database adapts to varying workload.  If more processes are attempting to make inserts than there are free lists some processes will have to</p><BR> ');
    dbms_output.put_line('<p>wait for access to a free list.  Increasing the wait count and the performance impact.</font><BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=HIGH" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">In tablespaces with manual segment-space management, Oracle Database uses the FREELISTS storage parameter to improve performance of space management in</p><BR> ');
    dbms_output.put_line('<p>OLTP systems by increasing the number of insert points in the segment. In tablespaces with automatic segment-space management, this parameter is ignored,</p><BR> ');
    dbms_output.put_line('<p>because the database adapts to varying workload.  If more processes are attempting to make inserts than there are free lists some processes will have to</p><BR> ');
    dbms_output.put_line('<p>wait for access to a free list.  Increasing the wait count and the performance impact.</font><BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM *************  Cannot Extend


REM **************************************************************************************** 
REM *******                   Section 8  : References                                 *******
REM ****************************************************************************************

prompt <a name="section8"></a><B><font size="+2">References</font></B><BR><BR>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody><font size="-1" face="Calibri"><tr><td><p>   

prompt <a href="https://communities.oracle.com/portal/server.pt/community/value_chain_planning/321" target="_blank">
prompt My Oracle Support - Value Chain Planning Community</a><br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=1389560.2" target="_blank">
prompt Information Center: Advanced Supply Chain Planning (Doc ID 1389560.2)</a><br>
prompt </p></font></td></tr></tbody>
prompt </table><BR><BR>

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *******                   Section 9 : Feedback                                   *******
REM ****************************************************************************************

prompt <a name="section8"></a><B><font size="+2">Feedback</font></B><BR><BR>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody><font size="-1" face="Calibri"><tr><td><p>
prompt Still have questions? Use the <em><font color="#FF0000"><b><font size="+1"> live</font></b></font></em> My Oracle Support EBS - Value Chain Planning Community,
prompt to search for similar discussions or start a new discussion about the ASCP Performance Analyzer.<br>
prompt <a href="https://communities.oracle.com/portal/server.pt/community/value_chain_planning/321" target="_blank">
prompt Click here to visit Value Chain Planning Community</a><br>
prompt </p></font></td></tr></tbody>
prompt </table><BR><BR>

REM
REM ******************** End of the Report *************************
REM

begin
select to_char(sysdate,'hh24:mi:ss') into :et_time from dual;
end;
/

declare
	st_hr1 varchar2(10);
	st_mi1 varchar2(10);
	st_ss1 varchar2(10);
	et_hr1 varchar2(10);
	et_mi1 varchar2(10);
	et_ss1 varchar2(10);
	hr_fact varchar2(10);
	mi_fact varchar2(10);
	ss_fact varchar2(10);
begin
	dbms_output.put_line('<br>PL/SQL Script was started at:'||:st_time);
	dbms_output.put_line('<br>PL/SQL Script is complete at:'||:et_time);
	st_hr1 := substr(:st_time,1,2);
	st_mi1 := substr(:st_time,4,2);
	st_ss1 := substr(:st_time,7,2);
	et_hr1 := substr(:et_time,1,2);
	et_mi1 := substr(:et_time,4,2);
	et_ss1 := substr(:et_time,7,2);

	if et_hr1 >= st_hr1 then
		hr_fact := to_number(et_hr1) - to_number(st_hr1);
	else
		hr_fact := to_number(et_hr1+24) - to_number(st_hr1);
	end if;
	if et_ss1 >= st_ss1 then
		mi_fact := to_number(et_mi1) - to_number(st_mi1);
		ss_fact := to_number(et_ss1) - to_number(st_ss1);
	else
		mi_fact := (to_number(et_mi1) - to_number(st_mi1))-1;
		ss_fact := (to_number(et_ss1)+60) - to_number(st_ss1);
	end if;
	dbms_output.put_line('<br><br>Total time taken to complete the script: '||hr_fact||' Hrs '||mi_fact||' Mins '||ss_fact||' Secs');
end;
/

prompt </HTML>

spool off
set heading on
set feedback on  
set verify on
exit
;

