REM $Id: pay_analyzer.sql 200.27 2015/19/08 05:11:16 pkm ship $
REM   
REM  Consolidated script to diagnose issues that can cause problems in your Payroll on an environment.
REM
REM   How to run it? Follow the directions found in the Note 1631780.1 
REM   
REM   	sqlplus apps/<password>	@pay_analyzer.sql 
REM
REM   
REM   Output file format found in the same directory if run manually in the file you spooled

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2
REM 
REM MENU_TITLE: HCM: Payroll Analyzer for R12
REM
REM MENU_START
REM
REM SQL: Run (HCM) Payroll Analyzer for R12
REM FNDLOAD: Load (HCM) Person Analyzer for R12 as a Concurrent Program 
REM 
REM MENU_END 
REM
REM HELP_START  
REM 
REM  EBS Payroll Analyzer (Doc ID 1631780.1)
REM
REM  Compatible: 12.0 12.1 12.2
REM 
REM  Explanation of available options:
REM  
REM    (1) Run EBS Payroll Analyzer for R12
REM        o Runs pay_analyzer.sql as APPS
REM        o Creates an HTML report file in MENU/output/ 
REM
REM    (2) Install EBS Payroll Analyzer for R12 as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: 
REM          "Global HRMS Reports & Process"
REM
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: PAY_TOP
REM PROG_NAME: PAY_ANALYZER_SQL
REM DEF_REQ_GROUP: Global SLA/Payroll Processes
REM PROG_TEMPLATE: pay12_prog.ldt
REM APP_NAME: Payroll
REM PROD_SHORT_NAME: PAY
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT 
REM
REM ANALYZER_BUNDLE_END

set echo off
undefine v_headerinfo
Define   v_headerinfo     = '$Header: PAY_analyzer.sql 200.27'
undefine v_queries_ver
Define   v_queries_ver    = '01-Sep-2013'
undefine v_scriptlongname
Define   v_scriptlongname = 'PAY Analyzer'

undefine v_nls
undefine v_version
clear columns
variable v_nls		varchar2(50);
variable v_version	varchar2(17);
VARIABLE rup_level_n varchar2(50);

set arraysize 1
set heading off
set feedback off  
set echo off
set verify off
SET CONCAT ON
SET CONCAT .
SET ESCAPE OFF
SET ESCAPE '\'

set lines 120
set pages 9999
set serveroutput on size 1000000

set head off feedback off
set serveroutput on size 1000000
set feedback off
set verify off
set echo off
set long 2000000000
set linesize 32767
set longchunksize 32767
--set wrap off
set pagesize 0
set timing off
set trimout on
set trimspool on
set heading off
set autoprint off

--Verify RDBMS version

DECLARE

BEGIN
				
	select max(version)
	into :v_version
	from v$instance;

	:v_version := substr(:v_version,1,9);

	if :v_version < '10.2.0.5.0' and :v_version > '4' then
	  dbms_output.put_line(chr(10));
	  dbms_output.put_line('RDBMS Version = '||:v_version);
	  dbms_output.put_line('ERROR - The Script requires RDBMS version 10.2.0 or higher');
	  dbms_output.put_line('ACTION - Type Ctrl-C <Enter> to exit the script.');
	  dbms_output.put_line(chr(10));
	end if;

	null;

	exception
	  when others then
		dbms_output.put_line(chr(10));
		dbms_output.put_line('ERROR  - RDBMS Version error: '|| sqlerrm);
		dbms_output.put_line('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
							 '         Type Ctrl-C <Enter> to exit the script.');
		dbms_output.put_line(chr(10));
END;
/

--Verify NLS Character Set

DECLARE

BEGIN

	select value
	into :v_nls
	from v$nls_parameters
	where parameter = 'NLS_CHARACTERSET';

	if :v_version < '8.1.7.4.0' and :v_version > '4' and :v_nls = 'UTF8' then
	  dbms_output.put_line(chr(10));
	  dbms_output.put_line('RDBMS Version = '||:v_version);
	  dbms_output.put_line('NLS Character Set = '||:v_nls);
	  dbms_output.put_line('ERROR - The HTML functionality of this script is incompatible with this Character Set for RDBMS version 8.1.7.3 and lower');
	  dbms_output.put_line('ACTION - Please report the above error to Oracle Support Services.');
	  dbms_output.put_line(chr(10));
	end if;

	exception
	  when others then
		dbms_output.put_line(chr(10));
		dbms_output.put_line('ERROR  - NLS Character Set error: '|| sqlerrm);
		dbms_output.put_line('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
							 '         Type Ctrl-C <Enter> to exit the script.'  || chr(10) );
		dbms_output.put_line(chr(10));
END;
/



variable st_time 	varchar2(100);
variable et_time 	varchar2(100);



begin
select to_char(sysdate,'hh24:mi:ss') into :st_time from dual;
end;
/

/*
COLUMN host_name NOPRINT NEW_VALUE hostname
SELECT host_name from v$instance;
COLUMN instance_name NOPRINT NEW_VALUE instancename
SELECT instance_name from v$instance;
COLUMN sysdate NOPRINT NEW_VALUE when
select to_char(sysdate, 'YYYY-Mon-DD') "sysdate" from dual;
SPOOL pay_&&hostname._&&instancename._&&when..html
*/

VARIABLE n		        NUMBER;
VARIABLE HOST        	VARCHAR2(80);
VARIABLE SID         	VARCHAR2(20);
VARIABLE apps_rel  varchar2(50);
VARIABLE hr_status varchar2(20);
VARIABLE pay_status varchar2(20);
VARIABLE v_rup_date varchar2(20);
VARIABLE rup_level varchar2(20);
VARIABLE w1 number;
VARIABLE w2 number;
VARIABLE w3 number;
VARIABLE w4 number;
VARIABLE w5 number;
VARIABLE w6 number;
VARIABLE w7 number;
VARIABLE w8 number;
VARIABLE w9 number;
VARIABLE w10 number;
VARIABLE w11 number;
VARIABLE w12 number;
VARIABLE w13 number;
VARIABLE w14 number;
VARIABLE w15 number;
VARIABLE w16 number;
VARIABLE w17 number;
VARIABLE w18 number;
VARIABLE w19 number;
VARIABLE w20 number;
VARIABLE w21 number;
VARIABLE w22 number;
VARIABLE w23 number;
VARIABLE w24 number;
VARIABLE w25 number;
VARIABLE w26 number;
VARIABLE w27 number;
VARIABLE w28 number;
VARIABLE w29 number;
VARIABLE w30 number;
VARIABLE w31 number;
VARIABLE e1 number;
VARIABLE e2 number;
VARIABLE e3 number;
VARIABLE e4 number;
VARIABLE e5 number;
VARIABLE e6 number;
VARIABLE e7 number;
VARIABLE e8 number;
VARIABLE e9 number;
VARIABLE e10 number;
VARIABLE e11 number;
VARIABLE e12 number;
VARIABLE e13 number;
VARIABLE e14 number;
VARIABLE e15 number;
VARIABLE e16 number;
VARIABLE e17 number;
VARIABLE e18 number;
VARIABLE e19 number;
VARIABLE e20 number;
VARIABLE e21 number;
VARIABLE e22 number;
VARIABLE e23 number;
VARIABLE e24 number;
VARIABLE e25 number;
VARIABLE e26 number;
VARIABLE e27 number;
VARIABLE e28 number;
VARIABLE e29 number;
VARIABLE e30 number;
VARIABLE e31 number;
VARIABLE v_link_no number;
VARIABLE p1 varchar2(50);
VARIABLE p2 varchar2(50);

alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';





REM ================= Pl/SQL api start ========================================
set termout on
prompt <html lang="en,us"><head><!--


undefine nbsp
define nbsp = ''
column lnbsp new_value nbsp noprint
select chr(38) || 'nbsp' lnbsp from dual;

undefine p_id
define p_id = ''
column lp_id new_value p_id noprint
select chr(38) || 'p_id' lp_id from dual;

undefine lt
define lt = ''
column llt new_value lt noprint
select chr(38) || 'lt' llt from dual;

undefine gt
define gt = ''
column lgt new_value gt noprint
select chr(38) || 'gt' lgt from dual;

undefine AMPER
define AMPER = ''
column lAMPER new_value AMPER noprint
select chr(38) lAMPER from dual;

undefine T_VARCHAR2
undefine T_ROWID
undefine T_NUMBER
undefine T_LONG
undefine T_DATE
undefine T_CHAR
undefine T_CLOB

variable g_hold_output clob;
variable g_curr_loc number;


declare

-- Procedure to output html content
procedure l_o (text varchar2) is
   l_ptext      varchar2(32767);
   l_hold_num   number;
   l_ptext2      varchar2(32767);
   l_hold_num2   number;
begin
   l_hold_num := mod(:g_curr_loc, 32767);
   
   l_hold_num2 := mod(:g_curr_loc, 14336);
   if l_hold_num2 + length(text) > 14000 then
      l_ptext2 := '                                                                                                                                                                                                    ';
      dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
   end if;
   
   l_hold_num2 := mod(:g_curr_loc, 18204);
   if l_hold_num2 + length(text) > 17900 then
      l_ptext2 := '                                                                                                                                                                                              ';
      dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	 
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	  
   end if;
   
   if l_hold_num + length(text) > 32759 then
      l_ptext := '<!--' || rpad('*', 32761-l_hold_num,'*') || '-->';
      dbms_lob.write(:g_hold_output, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
   end if;
   dbms_lob.write(:g_hold_output, length(text)+1, :g_curr_loc, text || chr(10));
   :g_curr_loc := :g_curr_loc + length(text)+1;
   
   --dbms_lob.write(:g_hold_output, length(text), :g_curr_loc, text );
   --g_curr_loc := g_curr_loc + length(text);
   
end l_o;


-- Procedure Name: Insert_Style_Sheet
-- Output: Inserts a Style Sheet into the output
procedure Insert_Style_Sheet is
begin
   l_o('<TITLE>Payroll Analyzer</TITLE>');
   l_o('<STYLE TYPE="text/css">');
   l_o('<!--');
    l_o('.divTitle {');
  l_o('-moz-border-radius: 6px;');
  l_o('-webkit-border-radius: 6px;');
  l_o('border-radius: 6px;');
  l_o('font-family: Calibri;');
  l_o('background-color: #152B40;');
  l_o('border: 1px solid #003399;');
  l_o('padding: 9px;');
  l_o('margin: 0px;');
  l_o('box-shadow: 3px 3px 3px #AAAAAA;');
  l_o('color: #F4F4F4;');
  l_o('font-size: x-large;');
  l_o('font-weight: bold;}');
  l_o('.divTitle1 {');
  l_o('font-family: Calibri;');
  l_o('font-size: large; font-weight: bold;}');
  l_o('.divSectionTitle {');
	l_o('width: 98.5%;font-family: Calibri;font-size: x-large;font-weight: bold;background-color: #152B40;color: #FFFFFF;padding: 9px;margin: 0px;');
	l_o('box-shadow: 3px 3px 3px #AAAAAA;-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;height: 30px;overflow:hidden;}');
  l_o('.columns       { ');
	l_o('width: 98.5%; font-family: Calibri;font-weight: bold;background-color: #254B72;color: #FFFFFF;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;');
	l_o('-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;height: 30px;}');
	l_o('div.divSectionTitle div   { height: 30px; float: left; }');
	l_o('div.left          { width: 80%; background-color: #152B40; font-size: x-large; border-radius: 6px; }');
	l_o('div.right         { width: 20%; background-color: #152B40; font-size: medium; border-radius: 6px;}');
	l_o('div.clear         { clear: both; }');
  l_o('.divSection {');
  l_o('-moz-border-radius: 6px;');
  l_o('-webkit-border-radius: 6px;');
  l_o('border-radius: 6px;');
  l_o('font-family: Calibri;');
  l_o('background-color: #CCCCCC;');
  l_o('border: 1px solid #DADADA;');
  l_o('padding: 9px;');
  l_o('margin: 0px;');
  l_o('box-shadow: 3px 3px 3px #AAAAAA;');
	l_o('}');
  l_o('.divSum {font-family: Calibri;background-color: #F4F4F4;}');
  l_o('.divSumTitle {font-family: Calibri;font-size: medium;color: #336699;}');
  l_o('.divItem {');
  l_o('-moz-border-radius: 6px;');
  l_o('-webkit-border-radius: 6px;');
  l_o('border-radius: 6px;');
  l_o('font-family: Calibri;');
  l_o('background-color: #F4F4F4;');
  l_o('border: 1px solid #EAEAEA;');
  l_o('padding: 9px;');
  l_o('margin: 0px;');
  l_o('box-shadow: 3px 3px 3px #AAAAAA;');
l_o('}');
l_o('.divItemTitle {');
  l_o('font-family: Calibri;');
  l_o('font-size: medium;');
  l_o('font-weight: bold;');
  l_o('color: #336699;');
  l_o('border-bottom-style: solid;');
  l_o('border-bottom-width: medium;');
  l_o('border-bottom-color: #3973AC;');
  l_o('margin-bottom: 9px;');
  l_o('padding-bottom: 2px;');
  l_o('margin-left: 3px;');
  l_o('margin-right: 3px;');
	l_o('}');
	l_o('.divwarn {');
	l_o('  -moz-border-radius: 6px;');
	l_o('  -webkit-border-radius: 6px;');
	l_o('  border-radius: 6px;');
	l_o('  font-family: Calibri;');
	l_o('  color: #333333;');
	l_o('  background-color: #FFEF95;');
	l_o('  border: 0px solid #FDC400;');
	l_o('  padding: 9px;');
	l_o('  margin: 0px;');
	l_o('  box-shadow: 3px 3px 3px #AAAAAA;');
	l_o('   font-size: 11pt;');
	l_o('}');
	l_o('.diverr {font-family: Calibri;font-size: 11pt;font-weight: bold;color: #333333; background-color: #ffd8d8;');
	l_o('  box-shadow: 3px 3px 3px #AAAAAA; -moz-border-radius: 6px; -webkit-border-radius: 6px;border-radius: 6px;padding: 9px;margin: 0px;}');
	l_o('.graph {font-family: Arial, Helvetica, sans-serif;font-size: small;}');
	l_o('.graph tr {font-family: Arial, Helvetica, sans-serif;font-size: small;background-color: transparent;}');
	l_o('.graph td {font-family: Arial, Helvetica, sans-serif;font-size: small;background-color: transparent;border: 0px transparent;}');
	l_o('.TitleBar, .TitleImg{display:table-cell;width:95%;vertical-align: middle;--border-radius: 6px;font-family: Calibri;background-color: #152B40;');
	l_o('padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;color: #F4F4F4;font-size: xx-large;font-size: 4 vw;font-weight: bold;overflow:hidden;}');
	l_o('.TitleImg{}');
	l_o('.TitleBar > div{height:25px;}');
	l_o('.TitleBar .Title2{font-family: Calibri;background-color: #152B40;padding: 9px;margin: 0px;color: #F4F4F4;font-size: medium;font-size: 4 vw;}');
	l_o('.divok {border: 1px none #00CC99;font-family: Calibri;font-size: 11pt;font-weight: normal;');
	l_o('  background-color: #ECFFFF;color: #333333;padding: 9px;margin: 0px; box-shadow: 3px 3px 3px #AAAAAA;-moz-border-radius: 6px;');
	l_o('  -webkit-border-radius: 6px;border-radius: 6px;}');
	l_o('A {	COLOR: #0066cc}');
	l_o('A:visited {	COLOR: #0066cc}');
	l_o('A:hover {	COLOR: #0099cc}');
	l_o('A:active {	COLOR: #0066cc}');
	l_o('.detail {	TEXT-DECORATION: none}');
   l_o('.ind1 {margin-left: .25in}');
   l_o('.ind2 {margin-left: .50in}');
   l_o('.ind3 {margin-left: .75in}');
   l_o('.tab0 {font-size: 10pt; font-weight: normal}');
   l_o('.tab1 {text-indent: .25in; font-size: 10pt; font-weight: normal}');
   l_o('.tab2 {text-indent: .5in; font-size: 10pt; font-weight: normal}');
   l_o('.tab3 {text-indent: .75in; font-size: 10pt; font-weight: normal}');
   l_o('.error {color: #cc0000; font-size: 10pt; font-weight: normal}');
   l_o('.errorbold {font-weight: bold; color: #cc0000; font-size: 10pt}');
   l_o('.warning {font-weight: normal; color: #336699; font-size: 10pt}');
   l_o('.warningbold {font-weight: bold; color: #336699; font-size: 10pt}');
   l_o('.notice {font-weight: normal; font-style: italic; color: #663366; font-size: 10pt}');
   l_o('.noticebold {font-weight: bold; font-style: italic; color: #663366; font-size: 10pt}');
   l_o('.section {font-weight: normal; font-size: 10pt}');  
   l_o('.sectionred {font-weight: normal; font-size: 11pt; font-weight: bold}');
   l_o('.sectionblue {font-weight: normal; color: #0000FF; font-size: 11pt; font-weight: bold}');
   l_o('.sectionblue1 {font-weight: normal; color: #0000FF; font-size: 11pt; font-weight: bold}');
   l_o('.sectionorange {font-weight: normal; color: #AA4422; font-size: 11pt; font-weight: bold}');
   l_o('.sectionbold {font-weight: bold; font-size: 14pt}');
   l_o('.sectiondb {font-weight: normal; color: #884400; font-size: 11pt; font-weight: bold}');
   l_o('.toctable {background-color: #F4F4F4;}');
   l_o('.sectionb {font-weight: normal; color: #000000; font-size: 11pt;  font-family: Calibri}');
   l_o('.BigPrint {font-weight: bold; font-size: 14pt}');
   l_o('.SmallPrint {font-weight: normal; font-size: 8pt}');
   l_o('.BigError {color: #cc0000; font-size: 12pt; font-weight: bold}');
   l_o('.code {font-weight: normal; font-size: 8pt; font-family: Courier New}');
   l_o('span.errbul {color: #EE0000;font-size: large;font-weight: bold;text-shadow: 1px 1px #AAAAAA;}');
   l_o('.legend {font-weight: normal;color: #0000FF;font-size: 9pt; font-weight: bold}');
   l_o('.btn {border: #000000;border-style: solid;border-width: 2px;width:190;height:50;border-radius: 6px;background: linear-gradient(#FFFFFF, #B0B0B0);font-weight: bold;color: blue;margin-top: 5px;margin-bottom: 5px;margin-right: 5px;margin-left: 5px;vertical-align: middle;}');  
   l_o('body {background-color: white; font: normal 12pt Ariel;}');
   l_o('table {background-color: #000000 color:#000000; font-size: 10pt; font-weight: bold; padding:2px; text-align:left}');
   l_o('h1, h2, h3, h4 {color: #00000}');
   l_o('h3 {font-size: 16pt}');
   l_o('td {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt; border-style: solid; border-width: 1; border-color: #DEE6EF}');
   l_o('tr {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt}');
   l_o('th {background-color: #DEE6EF; color: #000000; height: 20; border-style: solid; border-width: 2; border-color: #f7f7e7}');
   l_o('th.rowh {background-color: #CCCC99; color: #336699; height: 20; border-style: solid; border-width: 1; border-top-color: #f7f7e7; border-bottom-color: #f7f7e7; border-left-width: 0; border-right-width: 0}');
   l_o('-->');
   l_o('</style>');
end;


-- Display tab for every legislation
procedure leg_tabs (v_leg varchar2, v_leg_name varchar2, v_page varchar2) is
  v_exists number;  
Begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = v_leg  and status='I';     
     if v_exists>0 then
               l_o('<button onclick="activateTab('''||v_page||''')" style="width:190;height:50" >');
			   l_o('<font color="blue" ><b>'||v_leg_name||'</b> </font></button> '); 			
	 end if;
end;


-- Procedure Name: Show_Header
-- Output: Displays Standard Header Information
-- Examples: Show_Header('139684.1', 'Oracle Applications Current Patchsets Comparison to applptch.txt', 'Version 1.0');

procedure Show_Header(p_note varchar2, p_title varchar2, p_ver varchar2, p_queries_ver varchar2) is
   l_instance_name   varchar2(16) := null;
   l_host_name   varchar2(64) := null;
   l_version   varchar2(17) := null;
   l_multiorg   varchar2(4) := null;
   l_user   varchar2(100) := null;
   v_date varchar2(200);
begin
   DBMS_LOB.CREATETEMPORARY(:g_hold_output,TRUE,DBMS_LOB.SESSION);
   select instance_name
        , host_name
        , version
     into l_instance_name
        , l_host_name
        , l_version
     from v$instance;

   select decode (multi_org_flag, 'Y', 'Yes', 'No') into l_multiorg from fnd_product_groups;

   select user
     into l_user
     from dual;

	  l_o('-->');
	-- Add the ability to display a popup text window
	  l_o('<script language="JavaScript" type="text/javascript">');
	  l_o('function popupText(pText){');
	  l_o('var frog = window.open("","SQL","width=800,height=500,top=100,left=300,location=0,status=0,scrollbars=1,resizable=1")');
	  l_o('var html = "<html><head><"+"/head><body>"+ pText +"<"+"/body><"+"/html>";');
	  l_o('frog.document.open();');
	  l_o('frog.document.write(html);');
	  l_o('frog.document.close();');
	  l_o('}');
     l_o('function activateTab(pageId) {');
	l_o('     var tabCtrl = document.getElementById(''tabCtrl'');');
	l_o('       var pageToActivate = document.getElementById(pageId);');
	l_o('       for (var i = 0; i < tabCtrl.childNodes.length; i++) {');
	l_o('           var node = tabCtrl.childNodes[i];');
	l_o('           if (node.nodeType == 1) { /* Element */');
	l_o('               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';');
	l_o('           }');
	l_o('        }');
	l_o('   }');
	l_o('function opentabs() {');
    l_o(' var tabCtrl = document.getElementById(''tabCtrl''); ');      
    l_o('   for (var i = 0; i < tabCtrl.childNodes.length; i++) {');
    l_o('       var node = tabCtrl.childNodes[i];');
	l_o(' if (node.nodeType == 1)  {');
	l_o('	   if (node.toString() != ''[object HTMLScriptElement]'') { node.style.display =  ''block'' ; ');
     l_o('      }  }   }  }');
   
    l_o('function closetabs() {');
    l_o(' var tabCtrl = document.getElementById(''tabCtrl'');  ');     
    l_o('   for (var i = 0; i < tabCtrl.childNodes.length; i++) {');
    l_o('       var node = tabCtrl.childNodes[i];');
    l_o('       if (node.nodeType == 1) { /* Element */');
    l_o('           node.style.display =  ''none'' ;  }    }   }');
	l_o('function activateTab2(pageId) {');
	l_o('     var tabCtrl = document.getElementById(''tabCtrl'');');
	l_o('       var pageToActivate = document.getElementById(pageId);');
	l_o('       for (var i = 0; i < tabCtrl.childNodes.length; i++) {');
	l_o('           var node = tabCtrl.childNodes[i];');
	l_o('           if (node.nodeType == 1) { /* Element */');
	l_o('               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';');
	l_o('           } }');
	l_o('        tabCtrl = document.getElementById(''ExecutionSummary2'');');
	l_o('        tabCtrl.style.display = "none";');
	l_o('        tabCtrl = document.getElementById(''ExecutionSummary1'');');
    l_o('        tabCtrl.innerHTML = tabCtrl.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('   }');
	l_o(' function displayItem(e, itm_id) {');
    l_o(' var tbl = document.getElementById(itm_id);');
    l_o(' if (tbl.style.display == ""){');
    l_o('    e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));    ');    
    l_o('    tbl.style.display = "none"; }');
    l_o(' else {');
    l_o('     e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660)); ');        
    l_o('     tbl.style.display = ""; }');
    l_o('}');
	
	l_o('function displayItem2(e, itm_id) {');
    l_o(' var tbl = document.getElementById(itm_id);');
    l_o(' if (tbl.style.display == ""){');
    l_o('    e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
    l_o('    e.innerHTML = e.innerHTML.replace("Hide","Show");');
    l_o('    tbl.style.display = "none"; }');
    l_o(' else {');
    l_o('     e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
    l_o('     e.innerHTML = e.innerHTML.replace("Show","Hide");');
    l_o('     tbl.style.display = ""; }');
    l_o('}');
	
	l_o('function closeall()');
	l_o('{var txt = "s1sql";');
	l_o('var i;                                                                    ');
	l_o('var x=document.getElementById(''s1sql0'');                                      ');
	l_o('for (i=0;i<102;i++)                                                               ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';   ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  ');
	l_o('              }  	}');	
	l_o('for (i=272;i<274;i++)                                                                                         ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';   ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  ');
	l_o('              }  	}');	
	l_o('for (i=472;i<475;i++)');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));     ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';   ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  ');
	l_o('              }  	}');	
	l_o('txt = "s1sql100";  ');
	l_o('for (i=1;i<300;i++) ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                      ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none''; ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  ');
	l_o('			}');
	l_o('		  }	    ');
	l_o('txt = "s1sql500"; ');
	l_o('for (i=1;i<3000;i++)                                                                                   ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                      ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none''; ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  ');
	l_o('			}');
	l_o('		  }	     '); 
	l_o('txt = "s1sql300"; ');
	l_o('for (i=1;i<35;i++)                                                                                   ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                      ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none''; ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  ');
	l_o('			}');
	l_o('		  }	}     ');

	
	l_o('function openall()');
	l_o('{var txt = "s1sql";');
	l_o('var i;                                                                    ');
	l_o('var x=document.getElementById(''s1sql0'');                                      ');
	l_o('for (i=0;i<102;i++)                                                               ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''''; 	');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  ');
	l_o('              }  	}');	
	l_o('for (i=272;i<274;i++)                                                                                         ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''''; ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  ');
	l_o('              }  	}');	
	l_o('for (i=472;i<475;i++)                                                                                         ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = '''';');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  ');
	l_o('              }  	}');
	l_o('txt = "s1sql500"; ');
	l_o('for (i=1;i<3000;i++)                                                                                   ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = '''';');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  ');
	l_o('              }  	}');
	l_o('txt = "s1sql300"; ');
	l_o('for (i=1;i<35;i++)                                                                                   ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = '''';');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  ');
	l_o('              }  	}');
	l_o('		  }   ');
	
	
	l_o('    function hideRow(target)');
    l_o('    {var row = document.getElementById(target);');
   	l_o('    row.style.display = ''none'';');
	l_o('    row = document.getElementById(target.concat(''b''));');
	l_o('    row.scrollIntoView();');
	l_o('    row.innerHTML = row.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
    l_o('     }');
	l_o('    function hideRow2(target)');
    l_o('    {var row = document.getElementById(target);');
   	l_o('    row.style.display = ''none'';');
	l_o('    row = document.getElementById(target.concat(''b''));');
	l_o('    row.scrollIntoView();');
	l_o('    row.innerHTML = row.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('    row.innerHTML = row.innerHTML.replace("Hide","Show");');
    l_o('     }');
	l_o('</script>');
	l_o('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>');
	l_o('<script>');
	l_o('$(document).ready(function(){');
	l_o('var src = $(''img#error_ico'').attr(''src'');');
	l_o('$(''img.error_ico'').attr(''src'', src);');
	l_o('var src = $(''img#warn_ico'').attr(''src'');');
	l_o('$(''img.warn_ico'').attr(''src'', src);');
	l_o('var src = $(''img#check_ico'').attr(''src'');');
	l_o('$(''img.check_ico'').attr(''src'', src);');
	l_o('});</script>');
	
	Insert_Style_Sheet;
	l_o('</head><body>');
	--error icon
	l_o('<div style="display: none;">');
	l_o('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAANYSURBVHjaYvz//z8DDBQwMor+ZWDw+8fA4PKHgcEUiOWB+CEQnwbiPb8ZGDat+///NQMSAAggRpgBQM3OQI25XiGe/jr2Ngwi6hoMbHz8DF/v3mR4dO4cw/HjZxjWHru4C2hQ3+7//3fCDAAIILABhUDNUnJS/UHZSbpKcuIMDCf3Mvy9fo7h7/OnDP+FxRj+i8sx/BOXZTh8+xnDosPnb936/L3yzP//60AGAAQQYwEDA8jZs/M7a/yVvz9n+LdxAcP/v38Z/gId9g/oJBD9F0wzAj2kzrDn43+G7pM3j7xkYEh5+P//TYAAYgL5GeRskM3/Ni1gYEyrZWCcsx9FM9fC/Qzs2fUMP4Heseb6z+AgzmfDycAQw8jIyAYQQExAP7mA/Axy9r8/QOOM7RmYTB0YWOfvBxsA0sxi5gDE9kDD/jP8e/2KQZeXlYGJgcEe6AMJgABiSGNguPN919r/v93l/v/UZfj/XYfh/59T+/+DwO+TEPrnif3/nygy/H8oz/D/niLr/yMawv+1GBieAw0wAgggkAvk2fgFGf6/eMrwD+rkb3GODH9OHQDb/OvkAYbXkY6QcADiP79+Mwj8/c0AVCoKNEAAIIBABjz8dvcGwz8hMbABIMwJdTZIM5u5A4Pwsv0Mf4Caf4Mw0PHPvv4C0gyg9MAFEEAgA04/PHeW4b+EHNgGzgUIzW+ANv88cYCBw8KBQXLlfrD8v/9MDFe//QEZcBtowDeAAAIZsOfEsTPguAZF1e+TB+Ga/wBd8yzMkeH78QMMX48dBBvwGyh25vtfhh8MDBeABnwACCDGQKBfgJwlBT42bmZ/3jL8unOD4S8w+EGaQZHyBxqdIPZfRmaGjV8ZGOZ+/nvyFQPDFKC+QwABxARK20Dn9C0EprC9n4BOVFBn+McvBFTMyvCHgZHhD1DTX0YWht/MrGDNG77+vfuFgWELUPNNoAteAAQQPC+YMjIGAdNaoZOkgI0eLxuDAhsDg9DfPwxPvv5kuPrlF8Ppb38ZDv/4dxKk+R0Dw0GglutAvW8AAogROTfKMzKqg1IYKJEADVMFRRUotEEBBvLzRwaGU1Cb74M0g/QABBCKAWABYPIEpzAGBhFQPIOiChTaoAADYpCmF0A9v2DqAQIMAAqQl7ObLOmtAAAAAElFTkSuQmCC" alt="error_ico">');
	 --warning icon
	l_o('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAJHSURBVHjaYvz//z8DNjAhlnHdv38MgUC8vmT5/yAGHAAggBhABqDj/hgG7+OLvP+DwJEF3v+jLRgKsKkDYYAAYsJiMzMDI0uHkV87A8NpRgYJ9q0MSqIMBQJcjFLYHAAQQBgGAJ2c7BaZpMP26ziYr6zMwGBhwiDvb8BQxAgE6OoBAgjFOb1RDDwTE3mf/v3+5H9nCvf/FEfG/51JjP+fb2T4X+3F8EZFlEEL3QsAAcSEZnuRX3KhFNO7uQxnL3xjuPuQgeHsJQYGCVEGBjtLBmFbFYZyoCNYkPUABBDcgJ5IRmluQZkyeZM0Bobn3QziohBxcRGQyQwMVsZANi9DmKk8gyWyAQABxIRke3VgZhU344tWIOcLg4c9JHo9bIH0XwYGHg4GBjcbBg49SbArOGD6AAKIEeSPrnBGLSFp7UsprauYGa7qAQ34C9YEshlMQ/G/PwwM5V0M/048YAg+fO//BpABAAHEBLW9KzS/k5nhSRlc88K1DAwxJYwMC9cjDGACGujvwMCkIcpQBXQFL0gvQAAxdYQy2hvb23vzC/EwMLzbCrd591FGhmevgPRxRoQrgC6w0WVg0FdkMHVSZogGGQAQQExA20stA0rBAcfwH+FsV4v/DFLAgHQ1+w/XDDPISpuBQU6AIRnoCmGAAGIBGmDCeNuHgYEDyc9AOt4biD3QNP+ByKlKMjCwMzGogNIZQACBDNjS08+QDKQZ8GFQnkOmP/5gOA00QAAggMCxAHSKPpAjx0A6eAQQQIy4sjOxACDAAOXOBcGE78mYAAAAAElFTkSuQmCC" alt="warn_ico">');
	  --check icon
	l_o('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAELSURBVHjaYvz//z8DJQAggJhIUcyYwNjAGMP4nzGcsQEmBhBADCAXEIMZ4hkaGKIZ/h//dvw/QyDDfwZnhskgcYAAIl3zKQYI9mIA+V0dIIDI12zOsAxogC9AAEEUpQIVpQIFgTSG5ig8moEuAAgguObjv4//RzYExeYL2DWD1AEEEANc82uG/1Ufq/4zJAMVBTNMhtt8EarZE1MzCAMEEML5rxkQhhBhMwwDBBAiDEA2PwXie0BDXlURtBmGAQIIwYA6m+E6A0KzF37NIAwQQKgcb6AhgcRrBmGAAMIUAKYwYjWDMEAAMWLLTIyMjOpASg2IbwHlb+LLHwABxEhpbgQIICYGCgFAgAEAGJx1TwQYs20AAAAASUVORK5CYII=" alt="check_ico">');
	l_o('</div>');
	
	l_o('<div class="TitleBar"><div class="Title1">Payroll Analyzer</div>');
	l_o('<div class="Title2">Compiled using version 200.27 / Latest version: ');
	l_o('<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1631780.1:PAY_ANALYZER">');
	l_o('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/hcm_pay_latest_version.gif" title="Click here to download the latest version of analyzer" alt="Latest Version Icon"></a></div></div>');
	l_o('<div class="TitleImg"><a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div><br>');	


	l_o('<div class="divSection">');
	l_o('<div class="divItem">');
	l_o('<div class="divItemTitle">Report Information</div>');
	l_o('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
 	
	 select upper(instance_name), host_name into :sid, :host 
	  from   v$instance;
	  SELECT RELEASE_NAME into :apps_rel from FND_PRODUCT_GROUPS; 
	  select to_char(sysdate, 'Dy Month DD, YYYY hh24:mi:ss') into v_date from dual;	
  
  l_o('<table width="100%" class="graph"><tbody><tr class="top"><td width="33%">');
  l_o('<A class=detail onclick="displayItem(this,''RunDetails'');" href="javascript:;">&#9654; Execution Details</A>') ; 
  l_o('<TABLE style="DISPLAY: none" id=RunDetails><TBODY>');
  l_o('<TR><TH>Host:</TH>');
  l_o('<TD>'||:host||'</TD></TR>');
  l_o('<TR><TH>Instance: </TH>');
  l_o('<TD>'||:sid||'</TD></TR>');
  l_o('<TR><TH>Applications Version: </TH>');
  l_o('<TD>'||:apps_rel||'</TD></TR>');
  l_o('<TR><TH>Execution Date: </TH>');
  l_o('<TD>'||v_date||'</TD></TR>');
  l_o('<TR><TH>Analyzer version: </TH>');
  l_o('<TD>200.27</TD></TR>');
  l_o('</TBODY></TABLE></td>');

	l_o('<td width="33%"><div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>');
    l_o('<div id="ExecutionSummary2" style="display:none"></div>');
    l_o('</td></tr></table>');
   l_o('</div><br>');   
	
	l_o('<div class="divItem" id="toccontent">');
	l_o('<div class="divItemTitle">Sections In This Report</div></div>');
	l_o('<div align="center">');
	l_o('<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> / ');
	l_o('<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a></div>');
	l_o('</div><br></div>');
	
  l_o('<div id="tabCtrl">');
  l_o('<div id="page1" style="display: block;">');
		

end Show_Header;

-- Display database and application details
procedure overview is
		db_ver		VARCHAR2(100); 		
		platform varchar2(100);
		db_charset V$NLS_PARAMETERS.value%type;
		db_lang V$NLS_PARAMETERS.value%type;
		multiOrg FND_PRODUCT_GROUPS.MULTI_ORG_FLAG%type;
		multiCurr FND_PRODUCT_GROUPS.MULTI_CURRENCY_FLAG%type;
		v_hxc_status 	FND_LOOKUPS.MEANING%type;
		v_hxt_status 	FND_LOOKUPS.MEANING%type;		
		v_date varchar2(200);
		v_exists number;
		v_code varchar2(50);
		v_appl varchar2(50);
		cursor legislations is
				SELECT DECODE(legislation_code
							   ,null,'Global'
							   ,legislation_code)   leg             
					   , DECODE(application_short_name
							   , 'PER', 'Human Resources'
							   , 'PAY', 'Payroll'
							   , 'GHR', 'Federal Human Resources'
							   , 'CM',  'College Data'
							   , application_short_name)  application        
				  FROM hr_legislation_installations
				  WHERE status = 'I'
				  ORDER BY legislation_code;
		v_wfVer WF_RESOURCES.TEXT%type:='';
		v_crtddt V$DATABASE.CREATED%type;
		cursor bg is
		SELECT o.business_group_id bgi,o.organization_id oi,otl.name name,o3.ORG_INFORMATION9 lc			
			,o3.ORG_INFORMATION10 cc,o4.ORG_INFORMATION2 ef ,to_char(o.date_from , 'DD-MON-YYYY') df,to_char(o.date_to, 'DD-MON-YYYY') dt
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;
Begin
  
  :n := dbms_utility.get_time;
  
    
  SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, 'TNS for '), ':' )||pcv2.status, 1, 80)
    INTO platform
        FROM product_component_version pcv1,
           product_component_version pcv2
     WHERE UPPER(pcv1.product) LIKE '%TNS%'
       AND UPPER(pcv2.product) LIKE '%ORACLE%'
       AND ROWNUM = 1;
       
 	select banner into db_ver from V$VERSION WHERE ROWNUM = 1;
	select VALUE into db_lang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
	select VALUE into db_charset FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';
  
      SELECT L.MEANING  into :hr_status
      FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '800')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'	AND l.language = 'US';
	  SELECT L.MEANING  into :pay_status
		  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '801')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'	AND l.language = 'US';
	     
   if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into :rup_level FROM ad_bugs adb
            WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646');			
			 SELECT DECODE(bug_number
                  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
                  ,'19193000', 'R12.HR_PF.C.Delta.6'				  
                   ) 
                , LAST_UPDATE_DATE  
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =:rup_level and rownum < 2;
			  
    elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into :rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');            
                 
           SELECT DECODE(BUG_NUMBER
                  ,'20000288','R12.HR_PF.B.delta.8'
				  ,'18004477', 'R12.HR_PF.B.delta.7'
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =:rup_level and rownum < 2;            

            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into :rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
            
           SELECT DECODE(BUG_NUMBER
                  , '16077077', 'R12.HR_PF.A.delta.11'
                  , '13774477', 'R12.HR_PF.A.delta.10'
                  , '10281209', 'R12.HR_PF.A.delta.9'
                  , '9301208', 'R12.HR_PF.A.delta.8'
                  , '7577660', 'R12.HR_PF.A.delta.7'
                  , '7004477', 'R12.HR_PF.A.delta.6'
                  , '6610000', 'R12.HR_PF.A.delta.5'
                  , '6494646', 'R12.HR_PF.A.delta.4'
                  , '6196269', 'R12.HR_PF.A.delta.3'
                  , '5997278', 'R12.HR_PF.A.delta.2'
                  , '5881943', 'R12.HR_PF.A.delta.1'
                  , '4719824', 'R12.HR_PF.A')
                  , LAST_UPDATE_DATE  
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =:rup_level and rownum < 2;
                 
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
            
            if v_exists>0 then        
				   select max(to_number(bug_number)) into :rup_level from ad_bugs 
							WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
						   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');                    
								 
				   SELECT DECODE(BUG_NUMBER
                           , '2803988', 'HRMS_PF.E'
                           , '2968701', 'HRMS_PF.F'
                           , '3116666', 'HRMS_PF.G'
                           , '3233333', 'HRMS_PF.H'
                           , '3127777', 'HRMS_PF.I'
                           , '3333633', 'HRMS_PF.J'
                           , '3500000', 'HRMS_PF.K'
                           , '5055050', 'HR_PF.K.RUP.1'
                           , '5337777', 'HR_PF.K.RUP.2'
                           , '6699770', 'HR_PF.K.RUP.3'
                           , '7666111', 'HR_PF.K.RUP.4'
                           , '9062727', 'HR_PF.K.RUP.5'
                           , '10015566', 'HR_PF.K.RUP.6'
                           , '12807777', 'HR_PF.K.RUP.7'
                           , '14488556', 'HR_PF.K.RUP.8'
						   ,'17774746', 'HR_PF.K.RUP.9'
                            )  
                        , LAST_UPDATE_DATE  
                          into :rup_level_n, :v_rup_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =:rup_level and rownum < 2;
						
				end if;   
      end if;
	
		  
    select count(1) into v_exists FROM V$DATABASE;
	if v_exists=1 then	
	SELECT CREATED into v_crtddt FROM V$DATABASE;
	end if;
	select count(1) into v_exists FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';
	if v_exists=1 then
	SELECT TEXT into v_wfVer  FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';	
	end if;	
	l_o('<DIV class=divItem><a name="sum"></a>');
	l_o('<DIV id="s1sql0b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql0'');" href="javascript:;">&#9654; Instance Summary</A></DIV>');

	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql0" style="display:none" >');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	l_o('     <B>Instance Summary</B></font></TD>');	
	l_o(' </TR>');
	l_o('<TR><TD>Instance Name = '||:sid||'<br>');
	l_o('Instance Creation Date = '||v_crtddt||'<br>');
	l_o('Server/Platform = '||platform||'<br>');
	l_o('Language/Characterset = '||db_lang||' / '||db_charset||'<br>');
	l_o('Database = '||db_ver||'<br>');
	l_o('Applications = '||:apps_rel||'<br>');
	l_o('Workflow = '||v_wfVer||'<br>');
	l_o('PER '||:hr_status||' - PAY '||:pay_status||'<br><br>');
		
	if  :apps_rel like '11.5%' and v_exists=0 then   
           l_o('no RUP');		
    else
			l_o(:rup_level_n|| ' applied on ' || :v_rup_date ||'<br>');
	end if;
	l_o('<br>Installed legislations<br>');
	l_o('Code   Application');
	l_o('<br>-------------------<br>');
	
	  
	open legislations;
    loop
          fetch legislations into v_code,v_appl;
          EXIT WHEN  legislations%NOTFOUND;
          l_o(v_code||'   '||v_appl||'<br>');
    end loop;
    close legislations;	
	
	l_o(' </TABLE> </div> ');
	
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	l_o('<div id="fordx" style="display:none">');
	l_o('Instance Name = '||:sid||chr(10)||'Instance Creation Date = '||v_crtddt||chr(10)||'Server/Platform = '||platform||chr(10)||'Language/Characterset = '||db_lang||' / '||db_charset);
	l_o('Database = '||db_ver||chr(10)||'Applications = '||:apps_rel||chr(10)||'Workflow = '||v_wfVer||chr(10)||'PER '||:hr_status||chr(10)||'PAY '||:pay_status||chr(10)||chr(10)||:rup_level_n|| ' applied on ' || :v_rup_date ||chr(10)||chr(10)||'Installed legislations');
	
	for l_rec in legislations loop
	l_o(l_rec.leg||'   '||l_rec.application);
	end loop;
	l_o(chr(10)||lpad('Bus Grp ID',10)||lpad('Org ID',10)||lpad('Organization Name',30)||lpad('Legis',6)||lpad('Curr',6)||lpad('Enabl',7)||' '||lpad('Date From',11) ||' '||lpad('Date To',11));
	for org_rec in bg loop
		l_o(lpad(org_rec.bgi,10)||lpad(org_rec.oi,10)||lpad(org_rec.name,30)||lpad(org_rec.lc,6)||lpad(org_rec.cc,6)||lpad(org_rec.ef,7)||' '||lpad(org_rec.df,11)||' '||lpad(org_rec.dt,11));
	end loop;
	l_o('</div>');
	
	l_o('<DIV class=divItem><a name="db"></a>');
	l_o('<DIV id="s1sql1b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql1'');" href="javascript:;">&#9654; Database Details</A></DIV>');

	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql1" style="display:none" >');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	l_o('     <B>Database details</B></font></TD>');
	l_o('     <TD bordercolor="#DEE6EF">');
	l_o('<A class=detail id="s1sql2b" style="width:220px" onclick="displayItem2(this,''s1sql2'');" href="javascript:;">&#9654; Show SQL Script</A>');
	l_o('   </TD>');
	l_o(' </TR>');
	l_o(' <TR id="s1sql2" style="display:none">');
	l_o('    <TD BGCOLOR=#DEE6EF colspan="5" height="60">');
	l_o('       <blockquote><p align="left">');
	l_o('          SELECT upper(instance_name), host_name<br>');
	l_o('          	FROM   fnd_product_groups, v$instance;<br>');
	l_o('        SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, ''TNS for ''), '':'' )||pcv2.status, 1, 80)<br>');
	l_o('            	FROM product_component_version pcv1,<br>');
	l_o('                   product_component_version pcv2<br>');
	l_o('             	WHERE UPPER(pcv1.product) LIKE ''%TNS%''<br>');
	l_o('               	AND UPPER(pcv2.product) LIKE ''%ORACLE%''<br>');
	l_o('               	AND ROWNUM = 1;<br>');
	l_o('        SELECT banner from V$VERSION WHERE ROWNUM = 1;<br>');
	l_o('        SELECT value FROM V$NLS_PARAMETERS WHERE parameter in (''NLS_LANGUAGE'',''NLS_CHARACTERSET'');');
	l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Hostname</B></TD>');
	l_o(' <TH><B>Platform</B></TD>');
	l_o(' <TH><B>Sid</B></TD>');
	l_o(' <TH><B>Database version</B></TD>');
	l_o(' <TH><B>Language</B></TD>');
	l_o(' <TH><B>Character set</B></TD>');
	l_o('<TR><TD>'||:host||'</TD>'||chr(10)||'<TD>'||platform||'</TD>'||chr(10));
	l_o('<TD>'||:sid||'</TD>'||chr(10)||'<TD>'||db_ver||'</TD>'||chr(10)||'<TD>'||db_lang||'</TD>'||chr(10)||'<TD>'||db_charset ||'</TD></TR>'||chr(10));	 	
	:n := (dbms_utility.get_time - :n)/100;
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE> </div> ');
	if :apps_rel like '11.5%' and (db_ver like '9.2%' or db_ver like '10.1%' or db_ver like '10.2.0.2%' or db_ver like '10.2.0.3%' or db_ver like '11.1.0.6%') then
		l_o('<div class="divwarn">');
		l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Minimum Requirements: Database 10.2.0.4 or 11.1.0.7!<br>');
		l_o('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=883202.1" target="_blank">Note 883202.1</a> Patch Requirements for Sustaining Support for Oracle E-Business Suite Release 11.5.10<br>');
		l_o('</div><br><br>');
		:w1:=:w1+1;
	elsif :apps_rel like '12.0%' and (db_ver like '9.2%' or db_ver like '10.1%' or db_ver like '10.2.0.2%' or db_ver like '10.2.0.3%' or db_ver like '10.2.0.4%' or db_ver like '11.1.0.6%' or db_ver like '11.2.0.1%') then
		l_o('<div class="divwarn">');
		l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Minimum Requirements: Oracle Database 10.2.0.5, 11.1.0.7, or 11.2.0.2!<br>');
		l_o('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1334562.1" target="_blank">Note 1334562.1</a> Minimum Patch Requirements for Extended Support of Oracle E-Business Suite Human Capital Management (HCM) Release 12.0<br>');
		l_o('</div><br><br>');
		:w1:=:w1+1;
	end if;
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

  
	 :n := dbms_utility.get_time;
	 
	 SELECT MULTI_ORG_FLAG,MULTI_CURRENCY_FLAG into multiOrg, multiCurr FROM FND_PRODUCT_GROUPS;	    

	
	l_o('<DIV class=divItem><a name="apps"></a>');
	l_o('<DIV id="s1sql3b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql3'');" href="javascript:;">&#9654; Application Details</A></DIV>');

		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql3" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Application Details</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql4b" style="width:220px" onclick="displayItem2(this,''s1sql4'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql4" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="5" height="60">');
	
	l_o('       <blockquote><p align="left">');
	l_o('          SELECT RELEASE_NAME from FND_PRODUCT_GROUPS;<br>');	
	l_o('          SELECT MULTI_ORG_FLAG,MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS;<br>');
	l_o('          SELECT V.APPLICATION_ID, L.MEANING  <br>');
	l_o('              FROM FND_APPLICATION_ALL_VIEW V, FND_PRODUCT_INSTALLATIONS I, FND_LOOKUPS L<br>');
	l_o('              WHERE (V.APPLICATION_ID = I.APPLICATION_ID)<br>');
  	l_o('                AND (V.APPLICATION_ID in (''800'',''801''))<br>'); 
	l_o('                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')<br>');
	l_o('               AND (L.LOOKUP_CODE = I.Status);<br>');
	l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Release</B></TD>');
	l_o(' <TH><B>HRMS RUP</B></TD>');
	l_o(' <TH><B>MultiOrg Flag</B></TD>');
	l_o(' <TH><B>MultiCurrency Flag</B></TD>');
	l_o(' <TH><B>HR Status</B></TD>');
	l_o(' <TH><B>PAY Status</B></TD>');

	l_o('<TR><TD>'||:apps_rel||'</TD>'||chr(10));
	
            
    if  :apps_rel like '11.5%'  and v_exists=0 then
					l_o('<TD>no RUP</TD>'||chr(10));			
    else
			l_o('<TD>'||:rup_level_n|| ' applied on ' || :v_rup_date ||'</TD>'||chr(10));
	end if;
	
	
	
	l_o('<TD>'||multiOrg||'</TD>'||chr(10));
	
	l_o('<TD>'||multiCurr||'</TD>'||chr(10)||'<TD>'||:hr_status||'</TD>'||chr(10)||'<TD>'||:pay_status||'</TD></TR>'||chr(10));	 	

	
	:n := (dbms_utility.get_time - :n)/100;
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE> </div> ');
	if :apps_rel like '11.5%' then
		l_o('<div class="divwarn">');
		l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span>Please note that statutory legislative support expired on November 30th 2013');
		l_o('<span class="sectionb">, please refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1384995.1" target="_blank">Note 1384995.1</a> ');
		l_o(' When Is Statutory Legislative Support for Payroll Going To End For Release 11i<br></div>');	
		:w1:=:w1+1;
	end if;
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');
end;

-- Display HCM Products status
procedure product_status is
	v_appl fnd_application_all_view.application_name%type; 
	v_appls fnd_application_all_view.application_short_name%type; 
	v_applid varchar2(20);
	v_status fnd_lookups.meaning%type;
	v_patch fnd_product_installations.patch_level%type;
	cursor products is
	select t.application_name , b.application_short_name
		, to_char(t.application_id)
		, l.meaning
		, decode(i.patch_level, null, '11i.' || b.application_short_name || '.?', i.patch_level)
		from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
		where (t.application_id = i.application_id)
		AND b.application_id = t.application_id
		 and (b.application_id in ('0', '50', '101','178', '203', '231', '275', '426', '453', '800', '801', '802', '803', '804', '805', '808', '809', '810', '821', '8301', '8302', '8303','8401','8403'))
		and (l.lookup_type = 'FND_PRODUCT_STATUS')
		and (l.lookup_code = i.status )
		AND t.language = 'US' AND l.language = 'US' order by upper(t.application_name);	

begin

	l_o('<DIV class=divItem><a name="products"></a>');
	l_o('<DIV id="s1sql5b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql5'');" href="javascript:;">&#9654; Products Status</A></DIV>');

	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql5" style="display:none" >');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
	l_o('     <B>Applications Status</B></font></TD>');
	l_o('     <TD bordercolor="#DEE6EF">');
	l_o('<A class=detail id="s1sql6b" style="width:220px" onclick="displayItem2(this,''s1sql6'');" href="javascript:;">&#9654; Show SQL Script</A>');
	l_o('   </TD>');
	l_o(' </TR>');
	l_o(' <TR id="s1sql6" style="display:none">');
	l_o('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
	l_o('       <blockquote><p align="left">');
	l_o('        select v.application_name , v.application_short_name  <br>');     
	l_o('        , to_char(v.application_id) <br>');
	l_o('        , l.meaning    <br>');             
	l_o('        , decode(i.patch_level, null, ''11i.'' || v.application_short_name || ''.?'', i.patch_level) <br>');
	l_o('        from fnd_application_all_view v, fnd_product_installations i, fnd_lookups l<br>');
	l_o('        where (v.application_id = i.application_id)<br>');
	l_o('        and (v.application_id in <br>');
	l_o('         (''0'', ''50'', ''178'', ''275'', ''426'', ''453'', ''800'', ''801'', ''802'', ''803'', ''804'', ''805'', ''808'', ''809'', ''810'', ''8301'', ''8302'', ''8303''))<br>');
	l_o('        and (l.lookup_type = ''FND_PRODUCT_STATUS'')<br>');
	l_o('        and (l.lookup_code = i.status )');
	l_o('        order by upper(v.application_name);');
    l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Application</B></TD>');
	l_o(' <TH><B>Short Name</B></TD>');
	l_o(' <TH><B>Code</B></TD>');
	l_o(' <TH><B>Status</B></TD>');
	l_o(' <TH><B>Patchset</B></TD>');
		
	:n := dbms_utility.get_time;
	open products;
    loop
          fetch products into v_appl,v_appls,v_applid,v_status,v_patch;
          EXIT WHEN  products%NOTFOUND;
          l_o('<TR><TD>'||v_appl||'</TD>'||chr(10)||'<TD>'||v_appls||'</TD>'||chr(10));
		  if v_appls='HXC' and :apps_rel like '12.%'  then
				l_o('<TD>'||v_applid||'</TD>'||chr(10)||'<TD>'||v_status||'</TD>'||chr(10)||'<TD>-</TD> </TR>'||chr(10));
		  else
				l_o('<TD>'||v_applid||'</TD>'||chr(10)||'<TD>'||v_status||'</TD>'||chr(10)||'<TD>'||v_patch||'</TD> </TR>'||chr(10));
		  end if;	  
    end loop;
    close products;
	
	:n := (dbms_utility.get_time - :n)/100;
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE> </div> ');
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');
end;

-- Display legislations and status
procedure legislations is
	v_code varchar2(20); 
	v_appl varchar2(50);
	v_appls varchar2(50);
	v_date varchar2(30);
	v_action varchar2(20);
	cursor legislations is
	select  decode(legislation_code,null,'global',legislation_code), 
	decode(application_short_name , 'PER', 'Human Resources' , 'PAY', 'Payroll' , 'GHR', 'Federal Human Resources' , 'CM',  'College Data' , application_short_name),
    application_short_name,
	decode(action,'F','Force Install','C','Clear','U','Upgrade','I','Install'),
	to_char(last_update_date, 'DD-MON-YYYY')
	from hr_legislation_installations
      where status = 'I' 
      order by legislation_code;
begin
l_o(' <a name="legislations"></a>');
	l_o('<DIV class=divItem>');
	l_o('<DIV id="s1sql7b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql7'');" href="javascript:;">&#9654; Legislations Installed</A></DIV>');	
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql7" style="display:none" >');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
	l_o('     <B>Legislations Installed</B></font></TD>');
	l_o('     <TD bordercolor="#DEE6EF">');
	l_o('<A class=detail  id="s1sql8b"  onclick="displayItem2(this,''s1sql8'');" href="javascript:;">&#9654; Show SQL Script</A>');
	l_o('   </TD></TR><TR id="s1sql8" style="display:none">');
	l_o('    <TD colspan="4" height="60">');
	l_o('       <blockquote><p align="left">');
	l_o('         select decode(legislation_code,null,''global'',legislation_code) <br>');
	l_o('          , decode(application_short_name<br>, ''PER'', ''Human Resources''<br>, ''PAY'', ''Payroll''<br>, ''GHR'', ''Federal Human Resources''<br>');
	l_o('          , ''CM'',  ''College Data''<br>, application_short_name) <br>, application_short_name <br>');
	l_o('          ,decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'')<br> , last_update_date  <br>');
	l_o('          from hr_legislation_installations <br> where status = ''I''<br> order by legislation_code;');
	l_o('          </blockquote><br>');
	l_o('     </TD></TR><TR>');
	l_o(' <TH><B>Legislation Code</B></TD><TH><B>Application Name</B></TD><TH><B>Application Code</B></TD><TH><B>Action</B></TD><TH><B>Applied Date</B></TD>');
	
	:n := dbms_utility.get_time;
	open legislations;
    loop
          fetch legislations into v_code,v_appl,v_appls,v_action,v_date;
          EXIT WHEN  legislations%NOTFOUND;
          l_o('<TR><TD>'||v_code||'</TD>'||chr(10)||'<TD>'||v_appl||'</TD>'||chr(10));
		  l_o('<TD>'||v_appls||'</TD>'||chr(10));
		  l_o('<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD> </TR>'||chr(10));          
    end loop;
    close legislations;
	
	:n := (dbms_utility.get_time - :n)/100;
	l_o('<tr><td><A class=detail onclick="hideRow(''s1sql7'');" href="javascript:;">Collapse section</a></td></tr>');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE>');
	l_o('</div>');
    	
    l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');
end;



-- Display installed languages (NLS)
procedure nls is
    lang number;
    v_lang_code FND_LANGUAGES.LANGUAGE_CODE%type;
    v_flag varchar2(25);
    v_language FND_LANGUAGES.NLS_LANGUAGE%type;
    cursor languages is
    SELECT LANGUAGE_CODE ,  
             decode(INSTALLED_FLAG ,'B','Base language','I','Installed language'),
             NLS_LANGUAGE
      FROM FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I')
      order by LANGUAGE_CODE;
begin
    select count(1) into lang from FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I') ;
    l_o(' <a name="nls"></a>');
			                       l_o('<DIV class=divItem>');
								 l_o('<DIV id="s1sql33b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql33'');" href="javascript:;">&#9654; Installed Languages</A></DIV>');
                                  
                                  l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql33" style="display:none" >');
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                                  l_o('     <B>Languages:</B></font></TD>');
                                  l_o('     <TD bordercolor="#DEE6EF">');
                                  l_o('<A class=detail id="s1sql34b" style="width:220px" onclick="displayItem2(this,''s1sql34'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  l_o('   </TD>');
                                  l_o(' </TR>');
                                  l_o(' <TR id="s1sql34" style="display:none">');
                                  l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
                                  l_o('       <blockquote><p align="left">');
                                  l_o('          SELECT LANGUAGE_CODE , <br>');                                   
                                  l_o('                 decode(INSTALLED_FLAG ,''B'',''Base language'',''I'',''Installed language''),<br>');  
                                  l_o('                 NLS_LANGUAGE<br>'); 
                                  l_o('                FROM FND_LANGUAGES <br>'); 
                                  l_o('                where INSTALLED_FLAG in (''B'',''I'')<br>'); 
                                  l_o('                order by LANGUAGE_CODE;<br>'); 
                                  l_o('          </blockquote><br>');
                                  l_o('     </TD>');
                                  l_o('   </TR>');
                                  l_o(' <TR>');
                                  l_o(' <TH><B>Code</B></TD>');
                                  l_o(' <TH><B>Flag</B></TD>');
                                  l_o(' <TH><B>Language</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open languages;
                                  loop
                                        fetch languages into v_lang_code, v_flag, v_language;
                                        EXIT WHEN  languages%NOTFOUND;
                                        l_o('<TR><TD>'||v_lang_code||'</TD>'||chr(10)||'<TD>'||v_flag||'</TD>'||chr(10)||'<TD>'||v_language||'</TD></TR>'||chr(10));
                                  end loop;
                                  close languages;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                                  l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  l_o(' </TABLE> </div> ');
                     if lang>1 then               
                                  l_o('<div class="divok">');    
								  l_o('<span class="sectionblue1">Advice: </span> Periodically check if you NLS level is in sync with US level:<br>');
                                  l_o('Follow <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=252422.1" target="_blank" >Note 252422.1</a> ');
								  l_o('Requesting Translation Synchronization Patches<br>');
                                  l_o('-> this will synchronize your languages with actual US level<br>');
                                  l_o('Note! This is just an advice. This does not mean your NLS is not synchronized! Follow this step ONLY if you have translation issues.<br>');								  
								  l_o('</div>');
					end if;
			l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');


EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');	
end;


-- Display database initialization parameters
procedure database is
	v_db_parameter v$parameter.name%type; 	
	v_db_value v$parameter.value%type;
	database_version	varchar2(100);
	apps_version	varchar2(50);
	issue1 varchar2(100) := '';
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	cursor db_init is
	select name, nvl(value,'null') from v$parameter 
      where name in ('max_dump_file_size','timed_statistics'
	  ,'user_dump_dest','compatible'
	  ,'sql_trace'
	  ,'utl_file_dir','_optimizer_autostats_job')
      order by name;
	cursor db_init2 is
			select name, nvl(value,'null') from v$parameter order by name;

begin

   	l_o(' <a name="db_init_ora"></a>');

	select banner into database_version from V$VERSION WHERE ROWNUM = 1;
	apps_version:=:apps_rel;
	
	open db_init;
	loop
          fetch db_init into v_db_parameter,v_db_value;
          EXIT WHEN  db_init%NOTFOUND;
		  CASE v_db_parameter
				when 'compatible' then 
					CASE
						when database_version like '%8.1%' then
							if v_db_value<>'8.1.7' then
								issue1:='Please set Compatible parameter to 8.1.7';
							end if;
						when database_version like '%9.2%' then
							if v_db_value<>'9.2.0' then
								issue1:='Please set Compatible parameter to 9.2.0';
							end if;
						when database_version like '%10.1%' then
							if v_db_value<>'10.1.0' then
								issue1:='Please set Compatible parameter to 10.1.0';
							end if;
						when database_version like '%10.2%' then
							if v_db_value<>'10.2.0' then
								issue1:='Please set Compatible parameter to 10.2.0';
							end if;
						when database_version like '%11.1%' then
							if v_db_value<>'11.1.0' then
								issue1:='Please set Compatible parameter to 11.1.0';
							end if;
						when database_version like '%11.2%' then
							if v_db_value<>'11.2.0' then
								issue1:='Please set Compatible parameter to 11.2.0';
							end if;
						when database_version like '%12.1%' then
							if v_db_value<>'12.1.0' then
								issue1:='Please set Compatible parameter to 12.1.0';
							end if;
						else
							null;
					end case;
				when 'max_dump_file_size' then
					if v_db_value <>'UNLIMITED' then
						issue2:=TRUE;
					end if;
				when '_optimizer_autostats_job' then
					begin
						if database_version like '%11.1%' or database_version like '%11.2%' then
							if v_db_value <>'FALSE' then
								issue3:=TRUE;
							end if;	
						end if;
					end;
				when 'timed_statistics' then
					begin
						if database_version like '%8.1%' or database_version like '%9.2%' or database_version like '%10.1%' or database_version like '%10.2%' then
							if v_db_value <> 'TRUE' then
								issue4:=TRUE;
							end if;	
						end if;
					end;			
				else
					null;
			END CASE;
			
          
    end loop;
    close db_init;	

		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql11b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql11'');" href="javascript:;">&#9654; Database Initialization Parameters</A></DIV>');		
		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql11" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Database parameters</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql12b" style="width:220px" onclick="displayItem2(this,''s1sql12'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql12" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         select name, value from v$parameter <br>');		
		l_o('         order by name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Parameter</B></TD>');
		l_o(' <TH><B>Value</B></TD>');
	
		:n := dbms_utility.get_time;
		open db_init2;
		loop
			fetch db_init2 into v_db_parameter,v_db_value;
			EXIT WHEN  db_init2%NOTFOUND;
			l_o('<TR><TD>'||v_db_parameter||'</TD>'||chr(10)||'<TD>');
			l_o(v_db_value);
			l_o('</TD></TR>'||chr(10));
          
		end loop;
		close db_init2;

		
		:n := (dbms_utility.get_time - :n)/100;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
		
		if issue1<>'' or issue3 or issue4 then
			l_o('<div class="divwarn">');		
			if issue1<>'' then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span>'||issue1||'<br>');
				:w1:=:w1+1;
			end if;
							
			if issue3 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set _optimizer_autostats_job to FALSE<br>');
				:w1:=:w1+1;
			end if;
			
			if issue4 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set timed_statistics to TRUE<br>');
				:w1:=:w1+1;
			end if;		
			l_o('</div>');
		end if;
		
		l_o('<div class="divok">');
		if issue2 then			
			l_o('<span class="sectionblue1">Advice:</span> If you need to run a trace please set Max_dump_file_size = UNLIMITED<br>');
		end if;
		l_o('<span class="sectionblue1">Advice:</span> If you have performance issue please ensure you have correct database initialization parameters as per ');
		if apps_version like '12.%' then
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=396009.1" target="_blank">Note 396009.1</a> Database Initialization Parameters for Oracle E-Business Suite Release 12<br>');
		else 
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=216205.1" target="_blank">Note 216205.1</a> Database Initialization Parameters for Oracle Applications Release 11i<br>');
		end if;
		l_o('Use <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=174605.1" target="_blank">Note 174605.1</a> bde_chk_cbo.sql - EBS initialization parameters - Healthcheck<br>');
		l_o('This will help you to identify the difference between actual values and required values. Verify that all Mandatory Parameters - MP are set correctly<br><br>');
		l_o('Review also <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
				
		
		if issue1='' and (not issue2) and (not issue3) and (not issue4) then
				l_o('Verified parameters are correctly set');
		end if;	
		l_o('</div>');
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');
end;


-- Display status, last run of gather schema statistics concurrent request
procedure gather is
  status_all varchar2(100);
  status_hr varchar2(100); 
  last_date_all date;
  last_date_hr date; 
  last_date_normal date;
  status2 varchar2(100);
  last_date2 date;
  need_run boolean:=FALSE;
  days number;
  no_rows number;
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  issue6 boolean:=FALSE;
  v_PROG_SCHEDULE_TYPE varchar2(100);
  v_PROG_SCHEDULE varchar2(400);
  v_USER_NAME fnd_user.user_name%type;
  v_START_DATE fnd_concurrent_requests.requested_start_date%type;
  v_ARGUMENT_TEXT FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_all FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_hr FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
begin
      select count(1) into no_rows
      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL');
        
      if no_rows=0 then
          issue1:=TRUE;
      else
         SELECT * 
          into status_all,last_date_all,v_ARGUMENT_TEXT_all
          FROM (
          SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
           ,ACTUAL_COMPLETION_DATE pEndDate,ARGUMENT_TEXT        
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
            AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
          ORDER BY 2 desc)
          where rownum < 2;
      
          if instr(upper(status_all),upper('Completed Normal'))=0 then 
              issue2:=TRUE;			  
          else
              select  sysdate-last_date_all into days from dual;
              if days>7 then
                    issue3:=TRUE;
              end if;
          end if;
        end if;
        
        
      select count(1) into no_rows
      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,');
        
      if no_rows=0 then
          issue4:=TRUE;
      else
          SELECT * 
          into status_hr,last_date_hr,v_ARGUMENT_TEXT_hr
          FROM (
          SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
           ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
            AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
          ORDER BY 2 desc)
          where rownum < 2;
      
          if instr(upper(status_hr),upper('Completed Normal'))=0 then 
              issue5:=TRUE;
          else
              select  sysdate-last_date_hr into days from dual;
              if days>7 then
                    issue6:=TRUE;
              end if;
          end if;
        end if;
                        
                    
                    l_o(' <a name="gather"></a>');
                    l_o('<DIV class=divItem>');
					l_o('<DIV id="s1sql13b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql13'');" href="javascript:;">&#9654; Gather Statistics</A></DIV>');                    

                    l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="4" id="s1sql13" style="display:none" >');
                    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                    l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                    l_o('     <B>Statistics</B></TD>');
                    l_o('     <TD bordercolor="#DEE6EF">');
                    l_o('<A class=detail id="s1sql14b" style="width:220px" onclick="displayItem2(this,''s1sql14'');" href="javascript:;">&#9654; Show SQL Script</A>');
                    l_o('   </TD>');
                    l_o(' </TR>');
                    l_o(' <TR id="s1sql14" style="display:none">');
                    l_o('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                    l_o('       <blockquote><p align="left">');
                    l_o('          SELECT PHAS.MEANING || '' '' || STAT.MEANING pStatus <br>');                        
                    l_o('                     ,ACTUAL_COMPLETION_DATE pEndDate      <br>');  
                    l_o('                      FROM FND_CONC_REQ_SUMMARY_V fcrs<br>');
                    l_o('                     , FND_LOOKUP_VALUES STAT<br>');
                    l_o('                     , FND_LOOKUP_VALUES PHAS<br>');
                    l_o('                      WHERE STAT.LOOKUP_CODE = FCRS.STATUS_CODE<br>');
                    l_o('                     AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE''<br>');
                    l_o('                     AND PHAS.LOOKUP_CODE = FCRS.PHASE_CODE<br>');
                    l_o('                      AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE''<br>');
                    l_o('                      AND (UPPER(program) LIKE ''GATHER SCHEMA%''<br>');
                    l_o('                      AND substr(UPPER(ARGUMENT_TEXT),1,3) in (''HR,'',''ALL''<br>');
                    l_o('                      ))<br>');
                    l_o('                      ORDER BY 2 desc<br>');

                    l_o('          </blockquote><br>');
                    l_o('     </TD>');
                    l_o('   </TR>');
                    l_o(' <TR>');
                    l_o(' <TH><B>Request</B></TD>');
                    l_o(' <TH><B>Status</B></TD>');
                    l_o(' <TH><B>Last run</B></TD>');
					l_o(' <TH><B>Last Time Completed Normal</B></TD>');
					l_o(' <TH><B>Scheduling</B></TD>');
                  
                    :n := dbms_utility.get_time;
                    begin
					 l_o('<TR><TD>'||'Gather Schema Statistics for ALL'||'</TD>'||chr(10));
                    if issue1 then
                          l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
                          :p1:='never';
                    elsif issue2 then
							if instr(upper(status_all),'ERROR')=0 then 
                                      issue2:=FALSE;
							end if;		  
							select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
							if no_rows>0 then
								SELECT * 
								  into last_date_normal,v_ARGUMENT_TEXT
								  FROM (
								  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
								  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
								  ORDER BY 1 desc)
								  where rownum < 2;
								  :p1:=last_date_normal;
								  l_o('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_normal||' with parameters:');
								  l_o(v_ARGUMENT_TEXT);
								  l_o('</TD>'||chr(10));
								  select  sysdate-last_date_normal into days from dual;
								  if days>7 then
										issue3:=TRUE;
										last_date_all:=last_date_normal;
								  else
										issue3:=FALSE;
								  end if;
							else
								l_o('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
								l_o('<TD>never</TD>'||chr(10));
								issue2:=TRUE;
								:p1:='never';
							end if;
					else
                          l_o('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
						  l_o('<TD>'||last_date_all||' with parameters:');
						  l_o(v_ARGUMENT_TEXT_all);
						  l_o('</TD>'||chr(10));
						  :p1:=last_date_all;
                    end if;
					select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL');
					if no_rows=0 then
								l_o('<TD>no scheduling</TD></TR>'||chr(10));
					else						  
								select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
								SELECT 
									 NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
									 DECODE(NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
									 'PERIODICALLY',
									 'EVERY ' || fcr.resubmit_interval || ' ' ||
									 fcr.resubmit_interval_unit_code || ' FROM ' ||
									 fcr.resubmit_interval_type_code || ' OF PREV RUN',
									 'ONCE',
									 'AT :' ||
									 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
									 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
									 fu.user_name USER_NAME,
									 requested_start_date START_DATE									
									 FROM fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									ORDER BY 2 desc)
									where rownum < 2;
								  
								  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
								  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
					end if;
                    
                    l_o('<TR><TD>'||'Gather Schema Statistics for HR'||'</TD>'||chr(10));
                    if issue4 then
                          l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
                          :p2:='never';
                    elsif issue5 then
							if instr(upper(status_hr),'ERROR')=0 then 
                                      issue5:=FALSE;
							end if;
							select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
							if no_rows>0 then
								SELECT * 
								  into last_date_normal,v_ARGUMENT_TEXT
								  FROM (
								  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
								  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
								  ORDER BY 1 desc)
								  where rownum < 2;
								  :p2:=last_date_normal;
								  l_o('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_normal||' with parameters:');
								  l_o(v_ARGUMENT_TEXT);
								  l_o('</TD>'||chr(10));
								  select  sysdate-last_date_normal into days from dual;
								  if days>7 then
										issue6:=TRUE;
										last_date_hr:=last_date_normal;
								  else
										issue6:=FALSE;
								  end if;
							else
								l_o('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
								l_o('<TD>never</TD>'||chr(10));
								:p2:='never';
							end if;
					else
                          l_o('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
						  l_o('<TD>'||last_date_hr||' with parameters:');
						  l_o(v_ARGUMENT_TEXT_hr);
						  l_o('</TD>'||chr(10));
						  :p2:=last_date_hr;
                    end if;
					select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,');
					
					if no_rows=0 then
								l_o('<TD>no scheduling</TD></TR>'||chr(10));
					else						  
								select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
								SELECT 
									 NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
									 DECODE(NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
									 'PERIODICALLY',
									 'EVERY ' || fcr.resubmit_interval || ' ' ||
									 fcr.resubmit_interval_unit_code || ' FROM ' ||
									 fcr.resubmit_interval_type_code || ' OF PREV RUN',
									 'ONCE',
									 'AT :' ||
									 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
									 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
									 fu.user_name USER_NAME,
									 requested_start_date START_DATE
									 FROM fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									ORDER BY 2 desc)
									where rownum < 2;
								  
								  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
								  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
					end if;
                                 
                    EXCEPTION
						when others then
						  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
						  dbms_output.put_line('<br>Please report in Note 1631780.1 <br>');
					end;
					
                    :n := (dbms_utility.get_time - :n)/100;
                    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                    l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                    l_o(' </TABLE> </div> ');



              l_o('<div class="divwarn">');
              if issue1 and issue4 then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You never performed Gather Schema Statistics for HR!<br> ');
					:w1:=:w1+1;
					     
              end if;
              
                    
              if issue2 then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL is not Completed Normal. ');
					:w1:=:w1+1;
					      
              end if;
              
              if issue5 then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for HR is not Completed Normal. ');
					:w1:=:w1+1;
					     
              end if;
              
			  if issue1 and issue6 then
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your never performed gather schema statistics for ALL, and for HR was on '||last_date_hr||'.');
                    l_o('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w1:=:w1+1;
			  end if;
			  
              if issue3 and (issue6 or issue5 or issue4) then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all);
                    l_o('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w1:=:w1+1;                         
              elsif issue3 and issue6 then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for HR was on '||last_date_hr||'.');
                    l_o('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w1:=:w1+1;                         
              end if;
  		
            if (issue1 and issue4) or issue2 or issue5 or (issue1 and issue6) or (issue3 and (issue6 or issue5 or issue4)) then
				 l_o('In order to schedule use <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=419728.1" target="_blank" >Note 419728.1</a> ');
				 l_o('Concurrent Processing - How To Gather Statistics On Oracle Applications Release 11i and/or Release 12 - Concurrent Process,Temp Tables, Manually <br>');
				 l_o('Note! You can ignore the warning if you are manually gathering statistics using FND_STATS.GATHER_SCHEMA_STATS.<br>');
			 end if;
                        
              l_o('</div>');
			  
			  if not issue1 and not issue2 and not issue3 then
					l_o('<div class="divok">');
					l_o('<img class="check_ico">OK! Gather Scema statistics was performed in last week without errors.<br><br>');
					l_o('</div>');
			  else
					 if issue2 or issue3 or issue4 or issue5 or issue6 then
                         l_o('<div class="divwarn">');
						 l_o('Please review also <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=226987.1" target="_blank" >Note 226987.1</a> ');
						 l_o('Oracle 11i and R12 Human Resources (HRMS) and Benefits (BEN) Tuning and System Health Checks <br>');                         
						 l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=246332.1" target="_blank" >Note 246332.1</a> FLOAUG Presentation: Working with Support on Payroll Performance Issues');
						 l_o('</div>');
					 else
							l_o('<div class="divok">');
							l_o('<img class="check_ico">OK! Gather Scema statistics was performed in last week without errors.<br><br>');
							l_o('</div>');
					 end if;
			  end if;
			  
			   
              l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');    
end;


-- Display hot PAY tables and indexes
procedure pay_tables is
  v_table_name dba_tables.table_name%type; 
  v_last_analyzed dba_tables.last_analyzed%type;
  v_pct_free dba_tables.pct_free%type;
  v_ini_trans dba_tables.ini_trans%type;
  v_max_trans dba_tables.max_trans%type;
  v_degree dba_tables.degree%type;
  v_sample varchar2(30);
  v_num_rows dba_tables.num_rows%type;
  v_index_name dba_indexes.index_name%type;
  v_i_ini_trans dba_indexes.ini_trans%type;
  v_thread pay_action_parameters.parameter_value%type;
  v_rows number;
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue1_el boolean := FALSE;
	issue2_el boolean := FALSE;
	issue3_el boolean := FALSE;
	issue4_el boolean := FALSE;
	issue5_el boolean := FALSE;
	issue6_el boolean := FALSE;
	issue7_el boolean := FALSE;  
  
	cursor hot is
	SELECT table_name, last_analyzed, pct_free, ini_trans, max_trans, ltrim(rtrim(degree))
           , round(((decode(sample_size,0,null,sample_size))/(decode(num_rows,0,null,num_rows)))*100,2) , num_rows
      FROM DBA_TABLES
      WHERE table_name IN ('FF_ARCHIVE_ITEMS'
                          ,'FF_ARCHIVE_ITEM_CONTEXTS'
                          ,'PAY_ACTION_INFORMATION'
                          ,'PAY_ASSIGNMENT_ACTIONS'
                          ,'PAY_ASSIGNMENT_LATEST_BALANCES'
                          ,'PAY_BALANCE_CONTEXT_VALUES'
                          ,'PAY_COSTS'
                          ,'PAY_DEFINED_BALANCES'
                          ,'PAY_ELEMENT_ENTRIES_F'
                          ,'PAY_ELEMENT_ENTRY_VALUES_F'
                          ,'PAY_INPUT_VALUES_F'
                          ,'PAY_PAYROLL_ACTIONS'
                          ,'PAY_PERIODS_OF_SERVICE'
                          ,'PAY_PERSON_LATEST_BALANCES'
                          ,'PAY_POPULATION_RANGES'
                          ,'PAY_PRE_PAYMENTS'
                          ,'PAY_RUN_BALANCES'
                          ,'PAY_RUN_RESULTS'
                          ,'PAY_RUN_RESULT_VALUES'
                          ,'PAY_US_RPT_TOTALS'
                          ,'PER_ALL_ASSIGNMENTS_F'
                          ,'PER_ALL_PEOPLE_F') order by table_name;
  cursor cindexes (t_name varchar2) is
  select index_name, last_analyzed, pct_free, ini_trans, max_trans, degree 
      	FROM dba_indexes
      	WHERE table_name = t_name
        order by index_name;

begin

l_o(' <a name="hot"></a>');

		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql17b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql17'');" href="javascript:;">&#9654; Hot PAY Tables</A></DIV>');
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql17" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=7 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Hot Tables</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql18b" style="width:220px" onclick="displayItem2(this,''s1sql18'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql18" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         SELECT table_name, last_analyzed, pct_free, ini_trans, max_trans, ltrim(rtrim(degree))<br>');
		l_o('                    , round(((decode(sample_size,0,null,sample_size))/(decode(num_rows,0,null,num_rows)))*100,2) , num_rows<br>');
		l_o('               FROM DBA_TABLES<br>');
		l_o('               WHERE table_name IN (''FF_ARCHIVE_ITEMS''<br>');
		l_o('                                   ,''FF_ARCHIVE_ITEM_CONTEXTS''<br>');
		l_o('                                   ,''PAY_ACTION_INFORMATION''<br>');
		l_o('                                   ,''PAY_ASSIGNMENT_ACTIONS''<br>');
		l_o('                                   ,''PAY_ASSIGNMENT_LATEST_BALANCES''<br>');
		l_o('                                   ,''PAY_BALANCE_CONTEXT_VALUES''<br>');
		l_o('                                   ,''PAY_COSTS''<br>');
		l_o('                                   ,''PAY_DEFINED_BALANCES''<br>');
		l_o('                                   ,''PAY_ELEMENT_ENTRIES_F''<br>');
		l_o('                                   ,''PAY_ELEMENT_ENTRY_VALUES_F''<br>');
		l_o('                                   ,''PAY_INPUT_VALUES_F''<br>');
		l_o('                                   ,''PAY_PAYROLL_ACTIONS''<br>');
		l_o('                                   ,''PAY_PERIODS_OF_SERVICE''<br>');
		l_o('                                   ,''PAY_PERSON_LATEST_BALANCES''<br>');
		l_o('                                   ,''PAY_POPULATION_RANGES''<br>');
		l_o('                                   ,''PAY_PRE_PAYMENTS''<br>');
		l_o('                                   ,''PAY_RUN_BALANCES''<br>');
		l_o('                                   ,''PAY_RUN_RESULTS''<br>');
		l_o('                                   ,''PAY_RUN_RESULT_VALUES''<br>');
		l_o('                                   ,''PAY_US_RPT_TOTALS''<br>');
		l_o('                                   ,''PER_ALL_ASSIGNMENTS_F''<br>');
		l_o('                                   ,''PER_ALL_PEOPLE_F'');<br>');
    
		l_o('        SELECT table_name, index_name, last_analyzed, pct_free, ini_trans, max_trans, degree<br>');
		l_o('                FROM dba_indexes<br>');
		l_o('                WHERE table_name IN (''FF_ARCHIVE_ITEMS''<br>');
		l_o('                                   ,''FF_ARCHIVE_ITEM_CONTEXTS''<br>');
		l_o('                                   ,''PAY_ACTION_INFORMATION''<br>');
		l_o('                                   ,''PAY_ASSIGNMENT_ACTIONS''<br>');
		l_o('                                   ,''PAY_ASSIGNMENT_LATEST_BALANCES''<br>');
		l_o('                                   ,''PAY_BALANCE_CONTEXT_VALUES''<br>');
		l_o('                                   ,''PAY_COSTS''<br>');
		l_o('                                   ,''PAY_DEFINED_BALANCES''<br>');
		l_o('                                   ,''PAY_ELEMENT_ENTRIES_F''<br>');
		l_o('                                   ,''PAY_ELEMENT_ENTRY_VALUES_F''<br>');
		l_o('                                   ,''PAY_INPUT_VALUES_F''<br>');
		l_o('                                   ,''PAY_PAYROLL_ACTIONS''<br>');
		l_o('                                   ,''PAY_PERIODS_OF_SERVICE''<br>');
		l_o('                                   ,''PAY_PERSON_LATEST_BALANCES''<br>');
		l_o('                                   ,''PAY_POPULATION_RANGES''<br>');
		l_o('                                   ,''PAY_PRE_PAYMENTS''<br>');
		l_o('                                   ,''PAY_RUN_BALANCES''<br>');
		l_o('                                   ,''PAY_RUN_RESULTS''<br>');
		l_o('                                   ,''PAY_RUN_RESULT_VALUES''<br>');
		l_o('                                   ,''PAY_US_RPT_TOTALS''<br>');
		l_o('                                   ,''PER_ALL_ASSIGNMENTS_F''<br>');
		l_o('                                   ,''PER_ALL_PEOPLE_F'');<br>');
		l_o('          </blockquote><br>');       

		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Table Name</B></TD>');
		l_o(' <TH><B>Last Analyzed</B></TD>');
		l_o(' <TH><B>Pct Free</B></TD>');
		l_o(' <TH><B>Ini trans</B></TD>');
		l_o(' <TH><B>Max trans</B></TD>');
		l_o(' <TH><B>Degree</B></TD>');
		l_o(' <TH><B>% Sample</B></TD>');
		l_o(' <TH><B>Number of Rows</B></TD>');
	
  
	:n := dbms_utility.get_time;
  
	select count(1) into v_rows from pay_action_parameters where parameter_name='THREADS';
	if v_rows=0 then
		v_thread:=1;
	else	
		select max(parameter_value) into v_thread
			  from pay_action_parameters where parameter_name='THREADS';
	end if;
      
	open hot;
	loop
	  fetch hot into v_table_name,v_last_analyzed,v_pct_free,v_ini_trans,v_max_trans,v_degree,v_sample,v_num_rows;
	  EXIT WHEN  hot%NOTFOUND;
      issue1_el:=FALSE;
      issue2_el:=FALSE;
      issue3_el:=FALSE;
      issue4_el:=FALSE;
      issue5_el:=FALSE;
      if v_last_analyzed-sysdate>7 then
           issue1:=TRUE;
           issue1_el:=TRUE;
      end if;
      if v_ini_trans<10 then
            issue2:=TRUE;
            issue2_el:=TRUE;
      end if;
      if v_ini_trans<v_thread then
            issue3:=TRUE;
            issue3_el:=TRUE;
      end if;
      if v_sample<10 then
            issue4:=TRUE;
            issue4_el:=TRUE;
      end if;
       if v_table_name='PAY_US_RPT_TOTALS'  then
            select count(1) into v_num_rows from PAY_US_RPT_TOTALS;
			if v_num_rows>1000 then
				issue5:=TRUE;
				issue5_el:=TRUE;
			end if;
      end if;
      if issue1_el or issue2_el or issue3_el or issue4_el or issue5_el then
          l_o('<TR><TD><font color="red">'||v_table_name||'</font></TD>'||chr(10));
      else
          l_o('<TR><TD>'||v_table_name||'</TD>'||chr(10));
      end if;
      if issue1_el then
          l_o('<TD><font color="red">Issue: '||v_last_analyzed||'</font></TD>'||chr(10));
      else
          l_o('<TD>'||v_last_analyzed||'</TD>'||chr(10));
      end if;
      l_o('<TD>'||v_pct_free||'</TD>'||chr(10));
      if issue2_el or issue3_el then
          l_o('<TD><font color="red">Issue: '||v_ini_trans||'</font></TD>'||chr(10));
      else
          l_o('<TD>'||v_ini_trans||'</TD>'||chr(10));
      end if;
      l_o('<TD>'||v_max_trans||'</TD>'||chr(10)||'<TD>'||v_degree||'</TD>'||chr(10));
      if issue4_el then
          l_o('<TD><font color="red">Issue: '||v_sample||'</font></TD>'||chr(10));
      else
          l_o('<TD>'||v_sample||'</TD>'||chr(10));
      end if;
      if issue5_el then
          l_o('<TD><font color="red">Issue: '||v_num_rows||'</font></TD>'||chr(10));
      else
          l_o('<TD>'||v_num_rows||'</TD>'||chr(10));
      end if;
      
	  l_o('</TD></TR>'||chr(10));
      
      l_o('<tr><td></td><TH COLSPAN=7>');
      
      l_o('<table><tr BGCOLOR=#DEE6E0><td>Index name</td><td>Last analyzed</td><td>Pct free</td><td>Ini trans</td><td>Max trans</td><td>Degree</td></tr>');
            
      open cindexes (v_table_name);
      loop
            fetch cindexes into v_index_name, v_last_analyzed,v_pct_free,v_i_ini_trans,v_max_trans,v_degree;
            EXIT WHEN  cindexes%NOTFOUND;
            issue6_el:=FALSE;
            issue7_el:=FALSE;
            
            if v_last_analyzed-sysdate>7 then                  
                  issue6:=TRUE;
                  issue6_el:=TRUE;
            end if;
            
            if v_i_ini_trans<v_ini_trans+1 then
                  issue7:=TRUE;
                  issue7_el:=TRUE;
            end if;
            
             if issue6_el or issue7_el then
                l_o('<tr><td><font color="red">'||v_index_name||'</font></td>');
            else
                l_o('<tr><td>'||v_index_name||'</td>');
            end if;
            if issue6_el then
                l_o('<td><font color="red">Issue: '||v_last_analyzed||'</font></TD>');
            else
                l_o('<td>'||v_last_analyzed||'</TD>');
            end if;
            l_o('<td>'||v_pct_free||'</td>');
            if issue7_el then
                l_o('<td><font color="red">Issue: '||v_i_ini_trans||'</font></TD>');
            else
                l_o('<td>'||v_i_ini_trans||'</TD>');
            end if;
            l_o('<td>'||v_max_trans||'</td><td>'||v_degree||'</td><tr>');
      end loop;
      close cindexes;   
	  
      l_o('</table> </td></tr>');
          
		end loop;
		close hot;

		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql17'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
		
		l_o('<div class="divwarn">');
		if issue1 then
			  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Last_Analyzed for tables is more than 1 week. This can be an issue or not depending on your pay period. ');
			  l_o('Last_analyzed should be within a time period associated with the customers pay periods ');
			  l_o(' ie.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc');
			  :w1:=:w1+1;
		end if;
		
		if issue2 then
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set  Ini_trans value to 10 or higher for tables with red!<br>');
			:w1:=:w1+1;
		end if;
		
		if issue3 then
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> The setting of the pay_action_parameters Threads setting ('||v_thread||') must be less then or equal to the Ini_trans setting.  ');
			l_o('If the Ini_trans setting is lower then the Threads setting this could cause system contention.<br>');
			:w1:=:w1+1;
		end if;
    
		if issue4 then
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Sample size should be at least 10% - if performance issue associated with one of these tables (as identified in a trace) may consider analyzing a larger sample.  <br>');
			:w1:=:w1+1;
		end if;
		
		if issue5 then
			  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Pay_US_RPT_Totals table should not contain a large number of records.  ');
			  l_o('This table temporarily stores records until a US Payroll reports completes successfully, then removes records. ');
			  l_o('<br>Records are retained only if a report fails. ');
			  l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=256143.1" target="_blank">Note 256143.1</a> How to remove obsolete data on PAY_US_RPT_TOTALS table<br>');
			  :w1:=:w1+1;
		end if;
		
		if issue6 then
			  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Last_Analyzed for indexes is more than 1 week. This can be an issue or not depending on your pay period. ');
			  l_o('Last_analyzed should be within a time period associated with the customers pay periods ');
			  l_o(' ie.  If payroll is run weekly, these indexes should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc');
			  :w1:=:w1+1;
		end if;
		
		if issue7 then
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set Ini_trans value for indexes to (Ini_trans of table)+1 <br>');
			:w1:=:w1+1;
		end if;
		
		l_o('<span class="sectionblue1">Advice:</span> Please review:<br> ');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=549367.1" target="_blank">Note 246332.1</a> FLOAUG Presentation: Working with Support on Payroll Performance Issues<br>');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=226987.1" target="_blank">Note 226987.1</a> Oracle 11i and R12 Human Resources and Benefits Tuning and System Health Checks<br>');
		l_o('</div>');
		
		if (not issue1) and (not issue2) and (not issue3) and (not issue4) and (not issue5) and (not issue6) then
				l_o('<div class="divok">');
				l_o('Verified values are correctly set<br>');
				l_o('</div>');
		end if;			
		
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');
end;


-- Display invalid objects
procedure invalids is
	v_name dba_objects.object_name%type; 
	v_type dba_objects.object_type%type;
	v_owner dba_objects.owner%type;
	no_invalids number;
	no_errors number;
	inv_error VARCHAR2(250);
	issue boolean := FALSE;

    cursor invalids_pay is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'PAY%' or object_name like 'FF%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/')
	  order by 2;
 	
	cursor invalid_errors (object varchar2, object_type varchar2, object_owner varchar2) is
	    select nvl(substr(text,1,240) ,'null')
      from   all_errors
		where  name = object
		and    type = object_type
		and    owner = object_owner;

begin

  select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'PAY%' or object_name like 'FF%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/');
  if no_invalids>0 then
                    issue:=TRUE;
  end if;

  l_o(' <a name="invalids"></a>');
		l_o('<DIV class=divItem><a name="sum"></a>');
		l_o('<DIV id="s1sql19b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql19'');" href="javascript:;">&#9654; Invalid Objects</A></DIV>');
		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql19" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Fix next invalid objects:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql20b" style="width:220px" onclick="displayItem2(this,''s1sql20'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql20" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         select owner, object_name, object_type <br>');
		l_o('               from dba_objects<br>');
		l_o('               where status != ''VALID'' and object_type != ''UNDEFINED'' <br>');
		l_o('                and (object_name like ''PAY%'' or object_name like ''FF%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		l_o('                order by 2;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Owner</B></TD>');
		l_o(' <TH><B>Object</B></TD>');
    	l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>Error</B></TD>');
	
		:n := dbms_utility.get_time;    
    
        open invalids_pay;
              loop
                    fetch invalids_pay into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_pay%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
        close invalids_pay;
                
	
		
		:n := (dbms_utility.get_time - :n)/100;
		if issue and no_invalids>10 then
			l_o('<tr><td><A class=detail onclick="hideRow(''s1sql19'');" href="javascript:;">Collapse section</a></td></tr>');
		end if;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
	
		
		if issue then
				l_o('<div class="divwarn">');
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You have '||no_invalids||' invalid object(s) related to Payroll');
				select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED';
				l_o('from a total of '||no_invalids||' invalid object(s) in database.<br>');
				:w1:=:w1+1;
				l_o('<span class="sectionblue1">Advice:</span> Please run adadmin -> Compile apps schema.<br>');
				l_o('If you still have invalids review steps from: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1325394.1" target="_blank">Note 1325394.1</a>');
				l_o(' Troubleshooting Guide - invalid objects in the E-Business Suite Environment 11i and 12');
				l_o('</div>');				
        else
				 l_o('<div class="divok">');
				 l_o('<span class="sectionb"><img class="check_ico">OK! No invalid object for Payroll.</span><br>');
				 l_o('</div>');
        end if;
		
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');		
end;



-- Display disabled triggers
procedure triggers is
	v_owner dba_triggers.owner%type; 
	v_table dba_triggers.table_name%type;
    v_trigger dba_triggers.trigger_name%type;
    no_triggers number;
	no_triggers2 number;
 	issue boolean := FALSE;
	issue_alr boolean := FALSE;
	issue_only_alr boolean := FALSE;
  cursor disabled_triggers_pay is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR')
      and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
      order by 1, 2, 3;   
begin

	  l_o(' <a name="triggers"></a>');
	  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
        
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql23b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql23'');" href="javascript:;">&#9654; Disabled Triggers</A></DIV>');		
		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql23" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Disabled triggers:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql24b" style="width:220px" onclick="displayItem2(this,''s1sql24'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql24" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select owner, table_name, trigger_name <br>');
		l_o('                from dba_triggers <br>');
		l_o('                where status = ''DISABLED'' <br>');
		l_o('                and table_owner in (''HR'',''HXT'',''HXC'',''HRI'',''BEN'') <br>');
		l_o('                and (table_name like ''PAY%'' or table_name like ''FF%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		l_o('                order by 1, 2, 3; <br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Owner</B></TD>');
		l_o(' <TH><B>Table name</B></TD>');
		l_o(' <TH><B>Trigger Name</B></TD>');
	
		:n := dbms_utility.get_time;
    
		open disabled_triggers_pay;
			  loop
				 fetch disabled_triggers_pay into v_owner,v_table,v_trigger;
				 EXIT WHEN  disabled_triggers_pay%NOTFOUND;
				 if v_trigger like 'ALR%' then
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					l_o('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			  end loop;
		close disabled_triggers_pay;
		
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
		
		if issue and (not issue_alr) then
			l_o('<div class="divwarn">');
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You have disabled trigger(s).<br>');
			l_o('In order to re-enable use command: alter trigger trigger_name enable<br>');
			l_o('</div>');
			:w1:=:w1+1;
		elsif issue_only_alr then
			l_o('<div class="divok">');
			l_o(' You have disabled trigger(s) only related to alert. These are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.<br>');
			l_o('</div>');
   		elsif issue_alr and (not issue_only_alr) then
			l_o('<div class="divwarn">');
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You have disabled trigger(s).<br>');
			l_o('In order to re-enable use command: alter trigger trigger_name enable<br>');
			l_o('You have disabled trigger(s) related to alert (ALR_). These are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.<br>');
			l_o('Please focus on not ALR_ disabled triggers.<br>');
			l_o('</div>');
			:w1:=:w1+1;
		elsif  (not issue) then             
            l_o('<div class="divok">');
			l_o('<img class="check_ico">OK! No disabled trigger.<br>');
            l_o('</div>');
        end if;
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');		
end;



-- Display desyncronization in database
procedure timestampd is	
 	issue boolean := FALSE;
    v_problems number:=0;
begin
     select count(1) into v_problems
     from sys.obj$ do, sys.dependency$ d, sys.obj$ po
     where p_obj#=po.obj#(+)
     and d_obj#=do.obj#
     and do.status=1 /*dependent is valid*/
     and po.status=1 /*parent is valid*/
     and po.stime!=p_timestamp /*parent timestamp does not match*/
     and do.type# not in (28,29,30) /*dependent type is not java*/
     and po.type# not in (28,29,30) /*parent type is not java*/;
     
	l_o(' <a name="timestamp"></a>');
                  l_o('<DIV class=divItem><a name="sum"></a>');
				 l_o('<DIV id="s1sql25b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql25'');" href="javascript:;">&#9654; Dependency timestamp discrepancies</A></DIV>');                  
                 
                  l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="0" id="s1sql25" style="display:none" >');
                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                  l_o('   <TH COLSPAN=0 bordercolor="#DEE6EF"><font face="Calibri">');
                  l_o('     <B>Dependency timestamp discrepancies between the database objects:</B></font></TD>');
                  l_o('     <TD bordercolor="#DEE6EF">');
                  l_o('<A class=detail id="s1sql26b" style="width:220px" onclick="displayItem2(this,''s1sql26'');" href="javascript:;">&#9654; Show SQL Script</A>');
                  l_o('   </TD>');
                  l_o(' </TR>');
                  l_o(' <TR id="s1sql26" style="display:none">');
                  l_o('    <TD BGCOLOR=#DEE6EF colspan="0" height="60">');
                  l_o('       <blockquote><p align="left">');
                  l_o('          select count(1)  <br>');
                  l_o('                from sys.obj$ do, sys.dependency$ d, sys.obj$ po <br>');
                  l_o('                     where p_obj#=po.obj#(+)<br>');
                  l_o('                     and d_obj#=do.obj#<br>');
                  l_o('                     and do.status=1 /*dependent is valid*/<br>');
                  l_o('                     and po.status=1 /*parent is valid*/<br>');
                  l_o('                     and po.stime!=p_timestamp /*parent timestamp does not match*/<br>');
                  l_o('                     and do.type# not in (28,29,30) /*dependent type is not java*/<br>');
                  l_o('                     and po.type# not in (28,29,30) /*parent type is not java*/;<br>');
                  l_o('          </blockquote><br>');
                  l_o('     </TD>');
                  l_o('   </TR>');
                  l_o(' <TR>');
                  l_o(' <TH><B>Number</B></TD>');
                
                  :n := dbms_utility.get_time;
                  
                  l_o('<TR><TD>'||v_problems||'</TD></TR>'||chr(10));
                   
                
                  
                  :n := (dbms_utility.get_time - :n)/100;
                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                  l_o(' <TH COLSPAN=0 bordercolor="#DEE6EF"><font face="Calibri">');
                  l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                  l_o(' </TABLE> </div> ');
                  
				  if v_problems>0 then
						l_o('<div class="diverr">');
                        l_o('<img class="error_ico"><font color="red">Error:</font> You have dependency timestamp discrepancies between the database objects.<br>');
                        l_o('Please follow <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=370137.1" target="_blank">Note 370137.1</a>' );
                        l_o('After Upgrade, Some Packages Intermittently Fail with ORA-04065');                     
                        l_o('</div>');
						:e1:=:e1+1;
                  else
                        l_o('<div class="divok">');
						l_o('<img class="check_ico">OK! No dependency timestamp discrepancies between the database objects found.');
                        l_o('</div>');
                  end if;
				  l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>'); 
end;


-- Display packages version
procedure packages is
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
  wtf_version ad_file_versions.version%type;
  
  cursor package_vers(prod varchar2) is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where name like  upper(prod)||'%' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and owner='APPS'  and type in('PACKAGE','PACKAGE BODY') 
  and line =2 
  order by Name;  
  
Begin
	l_o('<DIV class=divItem><a name="packages"></a>');
	l_o('<DIV id="s1sql27b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql27'');" href="javascript:;">');
	l_o('&#9654; PAY Packages version</A></DIV>');
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql27" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Packages version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql28b" style="width:220px" onclick="displayItem2(this,''s1sql28'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql28" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select Name as Package, <br>');
		l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		l_o('          from dba_source <br>');
        l_o('          where (name like  ''PAY%'' or name like  ''PY%'') <br>');   
    l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
	l_o('          order by Name;<br>');
	l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Name</B></TD>');
    l_o(' <TH><B>Type</B></TD>');
	l_o(' <TH><B>File</B></TD>');
    l_o(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
	open package_vers('PAY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
    close package_vers;
    open package_vers('PY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
    close package_vers;
    
	:n := (dbms_utility.get_time - :n)/100;
	l_o('<tr><td><A class=detail onclick="hideRow(''s1sql27'');" href="javascript:;">Collapse section</a></td></tr>');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE></div> ');    

	 l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>'); 
 

 
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql272b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql272'');" href="javascript:;">');
		l_o('&#9654; FF Packages version</A></DIV>');
			l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql272" style="display:none" >');
			l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
			l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
			l_o('     <B>Packages version:</B></font></TD>');
			l_o('     <TD bordercolor="#DEE6EF">');
			l_o('<A class=detail id="s1sql282b" style="width:220px" onclick="displayItem2(this,''s1sql282'');" href="javascript:;">&#9654; Show SQL Script</A>');
			l_o('   </TD>');
			l_o(' </TR>');
			l_o(' <TR id="s1sql282" style="display:none">');
			l_o('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
			l_o('       <blockquote><p align="left">');
			l_o('          select Name as Package, <br>');
			l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
			l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
			l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
			l_o('          from dba_source <br>');		
			l_o('          where name like ''FF%'' <br>');		
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
		l_o('          order by Name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Name</B></TD>');
		l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>File</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;
		
	   
		open package_vers('FF');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
		close package_vers;   
		  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql272'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql273b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql273'');" href="javascript:;">');
		l_o('&#9654; HR Packages version</A></div>');
	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql273" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Packages version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql283b"  onclick="displayItem2(this,''s1sql283'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql283" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select Name as Package, <br>');
		l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		l_o('          from dba_source <br>');
		l_o('          where (name like  ''HR%'' or name like ''PER%'') <br>');
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
		l_o('          order by Name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Name</B></TD>');
		l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>File</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;
		
	   
		open package_vers('PER');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						l_o(v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
		close package_vers;
		open package_vers('HR');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						l_o(v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
		close package_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql273'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');
end;



-- First main program (it is split in 2 because of "program too long" issue)
begin
  
begin  
  :g_curr_loc:=1;
  Show_Header('9999999.999', '&v_scriptlongname', '&v_headerinfo', '&v_queries_ver');
  -- l_o('<hr><table align="center" ><tr bgcolor="#DDDDDD" bordercolor="#FFFFFF">');
	:w1:=0; :w2:=0; :w3:=0; :w4:=0; :w5:=0;
	:w6:=0; :w7:=0; :w8:=0; :w9:=0; :w10:=0;
	:w11:=0; :w12:=0; :w13:=0; :w14:=0; :w15:=0;
	:w16:=0; :w17:=0; :w18:=0; :w19:=0; :w20:=0;
	:w21:=0; :w22:=0; :w23:=0; :w24:=0; :w25:=0;
	:w26:=0; :w27:=0; :w28:=0; :w29:=0; :w30:=0; :w31:=0;
	:e1:=0; :e2:=0; :e3:=0; :e4:=0; :e5:=0;
	:e6:=0; :e7:=0; :e8:=0; :e9:=0; :e10:=0;
	:e11:=0; :e12:=0; :e13:=0; :e14:=0; :e15:=0;
	:e16:=0; :e17:=0; :e18:=0; :e19:=0; :e20:=0;
	:e21:=0; :e22:=0; :e23:=0; :e24:=0; :e25:=0;
	:e26:=0; :e27:=0; :e28:=0; :e29:=0; :e30:=0; :e31:=0;
	
	l_o('<div class="divSection">');
	l_o('<div class="divSectionTitle">');
	l_o('<div class="left"  id="generic" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Generic'); 
	l_o('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    l_o('<a class="detail" onclick="openall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    l_o('</div><div class="clear"></div></div><br>');
	

	l_o('<div class="divItem" >');
	l_o('<div class="divItemTitle">In This Section</div>');

-- Display table of contents        
  l_o('<table width="95%" border="0"> <tr> <td width="50%" class="toctable">');
  
  l_o('<br><a href="#overview">Overview</a>');
  l_o('<blockquote><a href="#sum">- Instance Summary</a> <br>');
  l_o('<a href="#db">- Database Details</span><br>');
  l_o('<a href="#apps">- Application Details</a> <br>');
  l_o('<a href="#products">- Products Status</a> <br>');
  l_o('<a href="#legislations">- Legislations Installed</a> <br>');
  l_o('<a href="#nls">- Languages Installed</a> <br>');
  l_o('</blockquote>');
    
  l_o('<br><a href="#performance">Performance Details</a>'); 
      l_o('<blockquote><a href="#db_init_ora">- Database Initialization Parameters</a> <br>');
      l_o('<a href="#gather">- Gather Schema Statistics</a> <br>');     
      l_o('<a href="#hot">- Hot Payroll Tables</a><br>');      
      l_o('</blockquote>');
    
	l_o('<br><a href="#database">Database Objects</a>');  
      l_o('<blockquote><a href="#invalids">- Invalid Objects</a> <br>');    
      l_o('<a href="#triggers">- Disabled Triggers</a> <br>');
      l_o('<a href="#timestamp">- Dependency timestamp discrepancies between the database objects</a> </blockquote>');
     	  
	  
  
  l_o('</td><td width="50%" class="toctable">');
   
	l_o('<br><a href="#versions">Versions</a>');
	  l_o('<blockquote><a href="#packages">- Packages versions</a> <br>');
      l_o('<a href="#java">- Java Classes Versions</a><br> '); 
	  l_o('<a href="#forms">- Forms versions</a> <br>');
      l_o('<a href="#reports">- Reports Versions</a><br> ');
	  l_o('<a href="#ccode">- C Code Versions</a> </blockquote>');
	  
   l_o('<br><a href="#settings">Settings</span></a>');
		l_o('<blockquote><a href="#profiles">- Profiles Settings</a> <br>');
		l_o('<a href="#security">- Security Profile Details</a> <br>');
		l_o('<a href="#international">- International Payroll Usage</a> <br>');
		l_o('<a href="#pay_trigger_events">- Pay Triggers Events</a> <br>');
		l_o('<a href="#pay_action">- Pay Action Parameters</a> <br>');
		l_o('<a href="#ssp">- Ssp_temp_affected_rows rows</a> <br>'); 		
		l_o('</blockquote>');
 
  
  l_o('<a href="#patching">Patching</a>');
      l_o('<blockquote><a href="#rup">- HRMS RUP</a> <br>');
	  l_o('<a href="#hrglobal">- Hrglobal</a> <br>');
	  l_o('<a href="#atg">- ATG</span></a> <br>');      
      l_o('<a href="#perf">- Performance patches</a> <br>');      
      l_o('</blockquote>');
	
	l_o('</td></tr></table>');
	l_o('</td> </tr> </table><br><br>');
	
	l_o('</div><br/>');	
	
	l_o('</div><br><br>');
	
	l_o('<a name="overview"></a>');
	l_o('<div class="divSection">');
	l_o('<div class="divSectionTitle">Instance Overview</div><br>');
	overview();
	product_status();
	legislations();	
	nls();
	l_o('</div>');
	
	l_o('<br><br><a name="performance"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">Performance Details</div><br>');
	database();
	gather();
	pay_tables();
	l_o('</div>');
	l_o('<br><br><a name="database"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">Database Objects</div><br>');
	invalids();	
	triggers();
	timestampd();
	l_o('</div>');
	
	l_o('<br><br><a name="versions"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">Versions</div><br>');
	packages();
	
	l_o('<!-');

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');
	
	
end;	
end;
/

-- Print CLOB
print :g_hold_output


variable g_hold_output2 clob;
declare
   counter      number       := 0;
   failures     number       := 0;   
   
   issuep boolean := FALSE;

/* Global defaults for SQL output formatting */
   g_sql_date_format   varchar2(100) := 'DD-MON-YYYY HH24:MI';

/* Global variables set by Set_Client which can be used throughout a script */
   g_user_id      number;
   g_resp_id      number;
   g_appl_id      number;
   g_org_id       number;

/* Global variable set by Set_Client or Get_DB_Apps_Version which can
   be referenced in scripts which branch based on applications release */

   g_appl_version varchar2(10);

   type V2T is table of varchar2(32767);
   

-- Write html format
procedure l_o (text varchar2) is
   l_ptext      varchar2(32767);
   l_hold_num   number;
   l_ptext2      varchar2(32767);
   l_hold_num2   number;
begin
   l_hold_num := mod(:g_curr_loc, 32767);
   
   l_hold_num2 := mod(:g_curr_loc, 14336);
   if l_hold_num2 + length(text) > 14000 then
      l_ptext2 := '                                                                                                                                                                                               ';
      dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	   dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  
   end if;
   
   l_hold_num2 := mod(:g_curr_loc, 18204);
   if l_hold_num2 + length(text) > 17900 then
      l_ptext2 := '                                                                                                                                                                                              ';
      dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	 
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
		dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	  
   end if;
   
   if l_hold_num + length(text) > 32759 then
      l_ptext := '<!--' || rpad('*', 32761-l_hold_num,'*') || '-->';
      dbms_lob.write(:g_hold_output2, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output2, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output2, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output2, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
   end if;
   dbms_lob.write(:g_hold_output2, length(text)+1, :g_curr_loc, text || chr(10));
   :g_curr_loc := :g_curr_loc + length(text)+1;
   
  -- dbms_lob.write(:g_hold_output2, length(text), :g_curr_loc, text );
  -- :g_curr_loc := :g_curr_loc + length(text);
   
end l_o;


-- Display java classes version
procedure javacl is
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;
  
  


Begin
 
    l_o('<a name="java"></a>');
	l_o('<DIV class=divItem>');
	l_o('<DIV id="s1sql47b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql47'');" href="javascript:;">');
	l_o('&#9654; PAY Java Classes Version</A></DIV>');	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql47" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql48b" style="width:220px" onclick="displayItem2(this,''s1sql48'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql48" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select sub.subdir,sub.filename, sub.version <br> from (<br> select que.subdir,que.filename, que.version <br> from (<br>');
		l_o('               select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br>');
		l_o('               rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br> (<br> select filename, app_short_name, subdir, file_id<br>');
		l_o('                 from ad_files<br>where app_short_name=''PAY'' and upper(filename) like upper(''%.class'')<br> ) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>) que<br> where rank1 = 1<br> order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD></TR><TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;    
   
		open java_vers('PAY');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
        close java_vers;
      
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql47'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');


   	l_o('<DIV class=divItem>');
	l_o('<DIV id="s1sql472b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql472'');" href="javascript:;">');
	l_o('&#9654; FF Java Classes Version</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql472" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql482b" style="width:220px" onclick="displayItem2(this,''s1sql482'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql482" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select sub.subdir,sub.filename, sub.version <br> from (<br>select que.subdir,que.filename, que.version <br>from (<br>');
		l_o('               select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br>');
		l_o('               rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br>(<br> select filename, app_short_name, subdir, file_id<br> from ad_files<br>');
		l_o('                 where app_short_name=''FF'' and upper(filename) like upper(''%.class'')<br> ) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>');
		l_o('            ) que<br> where rank1 = 1<br> order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD> </TR> <TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
	   open java_vers('FF');
				  v_dir_old:='';
				  loop
						fetch java_vers into v_dir,v_file,v_version;
						EXIT WHEN  java_vers%NOTFOUND;
						if v_dir_old=v_dir then
							l_o('<TR><TD></TD>'||chr(10)||'<TD>');
						else
							l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
						end if;
						v_dir_old:=v_dir;
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
							l_o('</TD></TR>'||chr(10));
					end loop;
		close java_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql472'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>'); 
		
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql473b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql473'');" href="javascript:;">');
		
		l_o('&#9654; PER Java Classes Version</A></DIV>');	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql473" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql483b"  onclick="displayItem2(this,''s1sql483'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql483" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select sub.subdir,sub.filename, sub.version <br>');  
		l_o('            from (<br> select que.subdir,que.filename, que.version <br> from (<br> select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br> rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br> (<br> select filename, app_short_name, subdir, file_id<br>');
		l_o('                 from ad_files<br> where app_short_name=''PER'' and upper(filename) like upper(''%.class'')<br>) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>) que<br> where rank1 = 1<br> order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD> </TR><TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
              open java_vers('PER');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql473'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

	  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');


EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


-- Display forms version				  
procedure forms_version is
				 v_dir ad_files.subdir%type;
				  v_dir_old ad_files.subdir%type;
				  v_file ad_files.filename%type;
				  v_version ad_file_versions.version%type;
				   
				  cursor forms_vers is
				  select que.subdir,que.filename, que.version
				  from (
					 select files.filename filename,files.subdir subdir,
					 file_version.version version,
					 rank()over(partition by files.filename
					   order by file_version.version_segment1 desc,
					   file_version.version_segment2 desc,file_version.version_segment3 desc,
					   file_version.version_segment4 desc,file_version.version_segment5 desc,
					   file_version.version_segment6 desc,file_version.version_segment7 desc,
					   file_version.version_segment8 desc,file_version.version_segment9 desc,
					   file_version.version_segment10 desc,
					   file_version.translation_level desc) as rank1
					 from ad_file_versions file_version,
					   (
					   select filename, app_short_name, subdir, file_id
					   from ad_files
					   where app_short_name in ('PAY') and upper(filename) like upper('%.fmb') and subdir like 'forms%US'
					   ) files
					 where files.file_id = file_version.file_id
				  ) que
				  where rank1 = 1
				  order by 1,2;
				  begin
							l_o('<DIV class=divItem><a name="forms"></a>');
							l_o('<DIV id="s1sql79b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql79'');" href="javascript:;">&#9654; Forms Version</A></DIV>');
							l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql79" style="display:none" >');
							l_o('  <TR> <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							l_o('     <B>Forms version:</B></font></TD>');
							l_o('     <TH bordercolor="#DEE6EF">');
							l_o('<A class=detail id="s1sql80b" onclick="displayItem2(this,''s1sql80'');" href="javascript:;">&#9654; Show SQL Script</A>');
							l_o('   </TD>');
							l_o(' </TR>');
							l_o(' <TR id="s1sql80" style="display:none">');
							l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
							l_o('       <blockquote><p align="left">');
							l_o('          select que.subdir,que.filename, que.version <br> from (<br> select files.filename filename,files.subdir subdir,<br>');
							l_o('               file_version.version version,<br> rank()over(partition by files.filename<br>');
							l_o('                 order by file_version.version_segment1 desc,<br>');
							l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
							l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
							l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
							l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
							l_o('                 file_version.version_segment10 desc,<br>');
							l_o('                 file_version.translation_level desc) as rank1<br>');
							l_o('               from ad_file_versions file_version,<br>');
							l_o('                 (<br>select filename, app_short_name, subdir, file_id<br> from ad_files<br>');
						l_o('                 where app_short_name in (''PAY'') and upper(filename) like upper(''%.fmb'') and subdir like ''forms%US''<br>');  
							l_o('                 ) files<br> where files.file_id = file_version.file_id<br> ) que<br>');
							l_o('            where rank1 = 1<br> order by 1,2;<br>');  
							l_o('          </blockquote><br>');
							l_o('     </TD></TR><TR>');
							l_o(' <TH><B>File directory</B></TD>');
						l_o(' <TH><B>Filename</B></TD>');
						l_o(' <TH><B>Version</B></TD>');
							:n := dbms_utility.get_time;			
					   
								  open forms_vers;
								  v_dir_old:='';
								  loop
										fetch forms_vers into v_dir,v_file,v_version;
										EXIT WHEN  forms_vers%NOTFOUND;
										if v_dir_old=v_dir then
											l_o('<TR><TD></TD>'||chr(10)||'<TD>');
										else
											l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
										end if;
										v_dir_old:=v_dir;
										l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
											l_o('</TD></TR>'||chr(10));
									end loop;
								  close forms_vers;
					 
					  
						
							:n := (dbms_utility.get_time - :n)/100;
							l_o('<tr><td><A class=detail onclick="hideRow(''s1sql79'');" href="javascript:;">Collapse section</a></td></tr>');
							l_o(' <TR><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							l_o(' </TABLE></div> ');
						

						  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
				  EXCEPTION
			when others then			  
			  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report the above error as comment in PAY Analyzer Note 1631780.1<br>');
				  end;

-- Display reports version				  
procedure reports_version is
				  v_dir ad_files.subdir%type;
				  v_dir_old ad_files.subdir%type;
				  v_file ad_files.filename%type;
				  v_version ad_file_versions.version%type;
				   
				  cursor Reports_vers is
				  select que.subdir,que.filename, que.version
				  from (
					 select files.filename filename,files.subdir subdir,
					 file_version.version version,
					 rank()over(partition by files.filename
					   order by file_version.version_segment1 desc,
					   file_version.version_segment2 desc,file_version.version_segment3 desc,
					   file_version.version_segment4 desc,file_version.version_segment5 desc,
					   file_version.version_segment6 desc,file_version.version_segment7 desc,
					   file_version.version_segment8 desc,file_version.version_segment9 desc,
					   file_version.version_segment10 desc,
					   file_version.translation_level desc) as rank1
					 from ad_file_versions file_version,
					   (
					   select filename, app_short_name, subdir, file_id
					   from ad_files
					   where (app_short_name like 'PAY') and upper(filename) like upper('%.rdf') and subdir like 'rep%US'
					   ) files
					 where files.file_id = file_version.file_id
				  ) que
				  where rank1 = 1
				  order by 1,2;
				  begin
							l_o('<DIV class=divItem><a name="reports"></a>');
							l_o('<DIV id="s1sql77b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql77'');" href="javascript:;">&#9654; Reports Version</A></DIV>');		
							l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql77" style="display:none" >');
							l_o('   <TR><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							l_o('     <B>Reports version:</B></font></TD>');
							l_o('     <TH bordercolor="#DEE6EF">');
							l_o('<A class=detail id="s1sql78b"  onclick="displayItem2(this,''s1sql78'');" href="javascript:;">&#9654; Show SQL Script</A>');
							l_o('   </TD>');
							l_o(' </TR>');
							l_o(' <TR id="s1sql78" style="display:none">');
							l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
							l_o('       <blockquote><p align="left">');
							l_o('          select que.subdir,que.filename, que.version <br>  from (<br>');
							l_o('               select files.filename filename,files.subdir subdir,<br>');
							l_o('               file_version.version version,<br>  rank()over(partition by files.filename<br>');
							l_o('                 order by file_version.version_segment1 desc,<br>');
							l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
							l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
							l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
							l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
							l_o('                 file_version.version_segment10 desc,<br>');
							l_o('                 file_version.translation_level desc) as rank1<br>');
							l_o('               from ad_file_versions file_version,<br>  (<br> select filename, app_short_name, subdir, file_id<br>   from ad_files<br>');
						l_o('                 where (app_short_name like ''PAY'') and upper(filename) like upper(''%.rdf'') and subdir like ''rep%US''<br>');  
							l_o('                 ) files<br>   where files.file_id = file_version.file_id<br>');
							l_o('            ) que<br>  where rank1 = 1<br>  order by 1,2;<br>');  
							l_o('          </blockquote><br>');
							l_o('     </TD> </TR> <TR>');
							l_o(' <TH><B>File directory</B></TD>');
							l_o(' <TH><B>Filename</B></TD>');
							l_o(' <TH><B>Version</B></TD>');

						
							:n := dbms_utility.get_time;
						
					   
										 
								  open Reports_vers;
								  v_dir_old:='';
								  loop
										fetch Reports_vers into v_dir,v_file,v_version;
										EXIT WHEN  Reports_vers%NOTFOUND;
										if v_dir_old=v_dir then
											l_o('<TR><TD></TD>'||chr(10)||'<TD>');
										else
											l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
										end if;
										v_dir_old:=v_dir;									
										
										l_o(v_file||'</TD>'||chr(10));
										
										l_o('<TD>'||v_version);
										l_o('</TD></TR>'||chr(10));
									end loop;
								  close Reports_vers;
					 
					  
						
							:n := (dbms_utility.get_time - :n)/100;
							l_o('<tr><td><A class=detail onclick="hideRow(''s1sql77'');" href="javascript:;">Collapse section</a></td></tr>');
							l_o(' <TR><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							l_o(' </TABLE></div> ');
						

						  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		EXCEPTION
			when others then			  
			  l_o('<br>'||sqlerrm ||' occurred in test');
			  l_o('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1<br>');
		end;

-- Display c-code version				  
procedure c_version is
				  v_file ad_files.filename%type;
				  v_version ad_file_versions.version%type;
				   
				  cursor c_vers is
				  select substr(que.filename,1,instr(que.filename,'.')-1), que.version
				  from (
					 select files.filename filename,files.subdir subdir,
					 file_version.version version,
					 rank()over(partition by files.filename
					   order by file_version.version_segment1 desc,
					   file_version.version_segment2 desc,file_version.version_segment3 desc,
					   file_version.version_segment4 desc,file_version.version_segment5 desc,
					   file_version.version_segment6 desc,file_version.version_segment7 desc,
					   file_version.version_segment8 desc,file_version.version_segment9 desc,
					   file_version.version_segment10 desc,
					   file_version.translation_level desc) as rank1
					 from ad_file_versions file_version,
					   (
					   select filename, app_short_name, subdir, file_id
					   from ad_files
					   where app_short_name in ('PAY','FF') and lower(filename) like '%.o'
					   ) files
					 where files.file_id = file_version.file_id
				  ) que
				  where rank1 = 1
				  order by 1,2;
				  begin
							l_o('<DIV class=divItem><a name="ccode"></a>');
							l_o('<DIV id="s1sql55b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql55'');" href="javascript:;">&#9654; C Code Version</A></DIV>');		
							l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="1" id="s1sql55" style="display:none" >');
							l_o('   <TR><TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
							l_o('     <B>C code version:</B></font></TD>');
							l_o('     <TH bordercolor="#DEE6EF">');
							l_o('<A class=detail id="s1sql56b"  onclick="displayItem2(this,''s1sql56'');" href="javascript:;">&#9654; Show SQL Script</A>');
							l_o('   </TD>');
							l_o(' </TR>');
							l_o(' <TR id="s1sql56" style="display:none">');
							l_o('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
							l_o('       <blockquote><p align="left">');
							l_o('          select substr(que.filename,1,instr(que.filename,''.'')-1), que.version <br>  from (<br>');
							l_o('               select files.filename filename,files.subdir subdir,<br>');
							l_o('               file_version.version version,<br>  rank()over(partition by files.filename<br>');
							l_o('                 order by file_version.version_segment1 desc,<br>');
							l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
							l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
							l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
							l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
							l_o('                 file_version.version_segment10 desc,<br>');
							l_o('                 file_version.translation_level desc) as rank1<br>');
							l_o('               from ad_file_versions file_version,<br>  (<br> select filename, app_short_name, subdir, file_id<br>   from ad_files<br>');
						    l_o('                 where app_short_name in (''PAY'',''FF'') and lower(filename) like ''%.o''<br>');  
							l_o('                 ) files<br>   where files.file_id = file_version.file_id<br>');
							l_o('            ) que<br>  where rank1 = 1<br>  order by 1,2;<br>');  
							l_o('          </blockquote><br>');
							l_o('     </TD> </TR> <TR>');
							l_o(' <TH><B>Filename</B></TD><TH><B>Version</B></TD>');

							:n := dbms_utility.get_time;						
								  open c_vers;								 
								  loop
										fetch c_vers into v_file,v_version;
										EXIT WHEN  c_vers%NOTFOUND;	
										l_o('<TR><TD>'||v_file||'</TD>'||chr(10));										
										l_o('<TD>'||v_version);
										l_o('</TD></TR>'||chr(10));
									end loop;
								  close c_vers;	 
							:n := (dbms_utility.get_time - :n)/100;
							l_o('<tr><td><A class=detail onclick="hideRow(''s1sql55'');" href="javascript:;">Collapse section</a></td></tr>');
							l_o(' <TR><TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
							l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							l_o(' </TABLE></div> ');						

						  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		EXCEPTION
			when others then			  
			  l_o('<br>'||sqlerrm ||' occurred in test');
			  l_o('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1<br>');
		end;	

-- Display HR profiles settings
procedure profiles is	 
	  v_name fnd_profile_options_tl.user_profile_option_name%type; 
	  v_short_name fnd_profile_options.profile_option_name%type;
	  v_short_name_old fnd_profile_options.profile_option_name%type;
	  v_level varchar2(50);
	  v_level_old varchar2(50);
	  v_context varchar2(300);
	  v_value fnd_profile_option_values.profile_option_value%type;
	  v_id fnd_profile_options.PROFILE_OPTION_ID%type; 
	  v_big_no number :=1;
	  v_big_no2 number :=1;
	
		cursor big_profiles  is
		select n.user_profile_option_name,
		  po.profile_option_name ,
		   decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
		(
				'PER_SECURITY_PROFILE_ID',
				'PER_BUSINESS_GROUP_ID',
				'HR_CROSS_BUSINESS_GROUP',
				'HR_USER_TYPE',
				'ORG_ID'   
				)
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
		v_security	varchar2(42);
		v_rows number;
		v_org_name HR_ALL_ORGANIZATION_UNITS.NAME%type;
        
begin

				
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql40b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql40'');" href="javascript:;">&#9654; Profile Settings</A></DIV>');
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql40" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Profile Settings</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql41b" style="width:220px" onclick="displayItem2(this,''s1sql41'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql41" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
		l_o('       <blockquote><p align="left">');
    
		l_o('         select n.user_profile_option_name, <br>');    	
		l_o('               po.profile_option_name ,<br>');
		l_o('         decode(to_char(pov.level_id),<br>');
		l_o('         ''10001'', ''Site'',<br>');
		l_o('         ''10002'', ''Application'',<br>');
		l_o('         ''10003'', ''Responsibility'',<br>');
		l_o('         ''10005'', ''Server'',<br>');
		l_o('         ''10006'', ''Org'',<br>');
		l_o('         ''10007'', ''Servresp'',<br>');
		l_o('          ''10004'', ''User'', ''???'') ,<br>');
		l_o('         decode(to_char(pov.level_id),<br>');
		l_o('          ''10001'', ''Site'',<br>');
		l_o('         ''10002'', nvl(app.application_short_name,to_char(pov.level_value)),<br>');
		l_o('         ''10003'', nvl(rsp.responsibility_name,to_char(pov.level_value)),<br>');
		l_o('          ''10005'', svr.node_name,<br>');
		l_o('         ''10006'', org.name,<br>');
		l_o('         ''10007'', pov.level_value ||'', ''|| pov.level_value_application_id ||'', ''|| pov.level_value2,<br>');
		l_o('          ''10004'', nvl(usr.user_name,to_char(pov.level_value)),<br>');
		l_o('          ''???'') ,<br>');
		l_o('          pov.profile_option_value<br> from   fnd_profile_options po,<br>  fnd_profile_option_values pov,<br>');
		l_o('         fnd_profile_options_tl n,<br> fnd_user usr,<br>  fnd_application app,<br>  fnd_responsibility_vl rsp,<br>  fnd_nodes svr,<br>  hr_operating_units org<br>');
		
		l_o('         where po.profile_option_name in (<br>');
							l_o(' ''HR_PAYROLL_CURRENCY_RATES'',<br>''HR_PAYROLL_CONTACT_SOURCE'',<br>''HR_VIEW_PAYSLIP_FROM_DATE'',<br>''HR_MV_HIRE_SKIP_ACT_VALIDATION'',<br>');
							l_o('''PAY_PPM_MULTI_ASSIGNMENT_ENABLE'',<br>''PAY_PSS_PAYMENTS_LIST'',<br>''PAY_PSS_PAYMENT_FUNCTION'',<br>''PAY_SIMULATION_ENABLE_FLAG'',<br>');
							l_o('''PAY_SIM_MULTI_ASSIGNMENT_ENABLE'',<br>''PAY_KEEP_ENBL_HRACES'',<br>''PAY_PSS_RUN_TYPE_DISPLAY'',<br>''PAY_USE_FF_PTO'',<br>');
							l_o('''PER_ENABLE_DTW4'',<br>''GB PAYROLL PENSIONS ENROLL CHECK'',<br>''GB_PAYE_NI_AGGREGATION'',<br>''GB_OVERRIDE_SOY'',<br>');
							l_o('''GB_DEFAULT_AGG_FLAG'',<br>''GB RTI UPTAKE'',<br>''PAY_IE_P35_REPORTING_YEAR'',<br>''PER_ENABLE_DTW4'',<br>''DATETRACK:ENABLED'',<br>');
							l_o('''FND_DISABLE_OA_CUSTOMIZATIONS'',<br>''FND_OA_ENABLE_DEFAULTS'')<br>');			
		l_o('          and    pov.application_id = po.application_id<br>');
		l_o('          and    po.profile_option_name = n.profile_option_name<br>');
		l_o('          and    pov.profile_option_id = po.profile_option_id<br>');
		l_o('          and    usr.user_id (+) = pov.level_value<br>');
		l_o('          and    rsp.application_id (+) = pov.level_value_application_id<br>');
		l_o('          and    rsp.responsibility_id (+) = pov.level_value<br>');
		l_o('          and    app.application_id (+) = pov.level_value<br>');
		l_o('          and    svr.node_id (+) = pov.level_value<br>');
		l_o('          and    svr.node_id (+) = pov.level_value2<br>');
		l_o('         and    org.organization_id (+) = pov.level_value<br>');
		l_o('         and    n.language=''US''<br>');
		l_o('         order by n.user_profile_option_name,pov.level_id;<br>');
    
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
		l_o(' <TH width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
		l_o(' <TH width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
		l_o(' <TH width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
		l_o(' <TH width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD>');
    
    
	:n := dbms_utility.get_time;
	
    v_short_name_old:='x';
    v_level_old:='x';
   	
	 open big_profiles;
          loop
            fetch big_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  big_profiles%NOTFOUND;
                    if v_short_name<>v_short_name_old then
							  if v_big_no>1 then
									v_big_no2 :=v_big_no-1;
									l_o('<tr><td><A class=detail onclick="hideRow2(''s1sql100'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
									l_o('</TABLE></td></TR>');
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  l_o(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  l_o(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                        l_o('</TD>'||chr(10)||'<TD>' );
                        l_o('</TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        l_o(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        l_o('-');
                    else
                        l_o(v_context );
                    end if;
					begin
					case v_short_name
					when 'PER_SECURITY_PROFILE_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from PER_SECURITY_PROFILES 
									where SECURITY_PROFILE_ID = v_value;
								if v_rows=1 then
										select substr(SECURITY_PROFILE_NAME,1,40) into v_security from PER_SECURITY_PROFILES 
											where SECURITY_PROFILE_ID = v_value;							
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_security);
								else
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					when 'HR_USER_TYPE' then
							case v_value
							when 'INT' then
								l_o('</TD>'||chr(10)||'<TD>INT - HR with Payroll User' );
							when 'PAY' then
								l_o('</TD>'||chr(10)||'<TD>PAY - Payroll User' );
							when 'PER' then
								l_o('</TD>'||chr(10)||'<TD>PER - HR User' );
							else
								l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
							end case;
					when 'ORG_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;
								if v_rows=1 then									
										select NAME into v_org_name from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;										
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_org_name);									
								else
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					when 'PER_BUSINESS_GROUP_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;
								if v_rows=1 then									
										select NAME into v_org_name from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;										
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_org_name);									
								else
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					else
							l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
					end case;
                    EXCEPTION
					when others then
					  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
					  dbms_output.put_line('<br>Please report in Note 1631780.1 <br>');
					end;
                    l_o('</TD></TR>'||chr(10));              
          end loop;
          close big_profiles;
		  
		  
		  v_big_no2 :=v_big_no-1;
		  l_o('<tr><td><A class=detail onclick="hideRow2(''s1sql100'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
									
		  l_o(' </TABLE>');  
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');	
end;


-- Display profiles settings
procedure profiles2 is
  v_name fnd_profile_options_tl.user_profile_option_name%type; 
  v_short_name fnd_profile_options.profile_option_name%type;
  v_short_name_old fnd_profile_options.profile_option_name%type;
  v_level varchar2(30);
  v_level_old varchar2(30);
  v_context varchar2(300);
  v_value fnd_profile_option_values.profile_option_value%type;
  v_id fnd_profile_options.PROFILE_OPTION_ID%type;
  issue0 boolean := FALSE;	
  issue1 boolean := FALSE;
  issue2 boolean := FALSE;
  issue3 boolean := FALSE;
  issue20 boolean := FALSE; 
  issue26 boolean := FALSE;
  v_rows number;
  v_begin_table number;
  v_end_table number;
  v_big_no_old number;
  v_big_no number;
	
	cursor pay_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
       where po.profile_option_name in
             (
              'HR_PAYROLL_CURRENCY_RATES',
				'HR_PAYROLL_CONTACT_SOURCE',
				'HR_VIEW_PAYSLIP_FROM_DATE',
				'HR_MV_HIRE_SKIP_ACT_VALIDATION',
				'PAY_PPM_MULTI_ASSIGNMENT_ENABLE',
				'PAY_PSS_PAYMENTS_LIST',
				'PAY_PSS_PAYMENT_FUNCTION',
				'PAY_SIMULATION_ENABLE_FLAG',
				'PAY_SIM_MULTI_ASSIGNMENT_ENABLE',
				'PAY_KEEP_ENBL_HRACES',
                'PAY_PSS_RUN_TYPE_DISPLAY',
                'PAY_USE_FF_PTO',
			    'PER_ENABLE_DTW4',
				'GB PAYROLL PENSIONS ENROLL CHECK',
				'GB_PAYE_NI_AGGREGATION',
				'PAY_IE_P35_REPORTING_YEAR',
				'GB_OVERRIDE_SOY',
				'GB_DEFAULT_AGG_FLAG',
				'GB RTI UPTAKE',
				'ENABLE_SECURITY_GROUPS'
			  )
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
        
begin

  
	select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
	where  po.profile_option_name ='FND_DISABLE_OA_CUSTOMIZATIONS'   and pov.profile_option_value='N'
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
	if v_rows > 0 then
		issue0:=TRUE;
	end if;
	
	select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
	where  po.profile_option_name ='FND_OA_ENABLE_DEFAULTS'   and pov.profile_option_value='N'
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
	if v_rows > 0 then
		issue20:=TRUE;
	end if;
	SELECT  count(1) into v_rows
         FROM    fnd_profile_options po
                ,fnd_profile_option_values pov
         WHERE   po.profile_option_name = 'ENABLE_SECURITY_GROUPS'
         AND     po.application_id = 0
         AND     po.profile_option_id = pov.profile_option_id
         AND     po.application_id = pov.application_id
         AND     (pov.level_id = 10002  AND  hr_general.chk_application_id (pov.level_value) = 'TRUE')
         AND     pov.profile_option_value = 'Y';
	if v_rows > 0 then
		issue26:=TRUE;
	end if;
	
	select count(1) 
     into v_rows
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';     
     if v_rows>0 then
		select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
			where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'   and pov.level_id='10001'
			and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
			if v_rows = 0 then
				issue1:=TRUE;
			else
				select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
					where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'   and pov.level_id='10001' and pov.profile_option_value='2014'
					and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
					if v_rows = 0 then
						issue2:=TRUE;
					end if;				
			end if;
		select   count(distinct pov.profile_option_value)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
					where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'  
					and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
			if v_rows >1 then
				issue3:=TRUE;
			end if;
	 end if;
	
              
			
	v_short_name_old:='x';
    v_level_old:='x';
	v_big_no:=6;
	v_begin_table:=0;
	v_end_table:=0;	
	v_big_no_old:=v_big_no;	
	open pay_profiles;
          loop
            fetch pay_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  pay_profiles%NOTFOUND;
			if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									l_o('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A  style="white-space:nowrap"class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  l_o(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  l_o(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
			end if;
            if v_short_name=v_short_name_old and v_level=v_level_old then
                l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                l_o('</TD>'||chr(10)||'<TD>' );
                l_o('</TD>'||chr(10)||'<TD>');
            else
                l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                l_o(v_level ||'</TD>'||chr(10)||'<TD>');
            end if;
            v_short_name_old:=v_short_name;
            v_level_old:=v_level;
            
            if v_context is null then
                l_o('-');
            else
                l_o(v_context );
            end if;
            l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
            l_o('</TD></TR>'||chr(10));
                
          end loop;
          close pay_profiles;
	if v_begin_table<>v_end_table then
				l_o(' </TABLE>');
	end if;

		  
    
    :n := (dbms_utility.get_time - :n)/100;
	l_o('<tr><td><A class=detail onclick="hideRow(''s1sql40'');" href="javascript:;">Collapse section</a></td></tr>');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> </div> ');
    
	l_o('<div class="divok">');
	if issue26 then				
				l_o('<span class="sectionblue1">Information:</span> Multiple Security Group is enabled.<br></div>');
	else
				l_o('<span class="sectionblue1">Information:</span> Multiple Security Group is NOT enabled.<br></div>');
	end if;
    if issue0 then
				l_o('<div class="divok">');
				l_o('<span class="sectionblue1">Advice:</span> Profile "Disable Self-Service Personal" is set to N at one/several levels, ');
				l_o('so personalization/OA page customization is used. This can cause issues in system behavior (caused by custom personalization).<br> ');
				l_o('If you have issues in web pages, before raising an Service Request, please turn this profile to Y (to disable all personalizations) and retest. ');
				l_o('If the issue is not reproducible, then it is caused by customization.<br>');
				l_o('</div>');
			end if;
	if issue20 then
				l_o('<div class="divwarn">');
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "FND:OA:Enable Defaults" is set to N at one/several levels, ');
				l_o('so default values specified in personalizations and base meta data applied to your pages will not be displayed.<br> ');
				l_o('</div>');
				:w1:=:w1+1;
	end if;
	if issue1 then
				l_o('<div class="divwarn">');
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "HR: IE P35 Reporting Year" is not set at Site Level.<br> ');
				l_o('</div>');
				:w1:=:w1+1;
	end if;
	if issue2 then
				l_o('<div class="divwarn">');
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "HR: IE P35 Reporting Year" is not set to current tax year 2014.<br> ');
				l_o('</div>');
				:w1:=:w1+1;
	end if;
	if issue3 then
				l_o('<div class="divwarn">');
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "HR: IE P35 Reporting Year" is set to different values at different levels.<br> ');
				l_o('</div>');
				:w1:=:w1+1;
	end if;
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br><br>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');	
end;


-- Display Security profile details
procedure security is
    cursor security is
    select security_profile_id, nvl(security_profile_name,'null') from PER_SECURITY_PROFILES 
	order by upper(security_profile_name);
    v_sec_id PER_SECURITY_PROFILES.security_profile_id%type;
	v_sec_name PER_SECURITY_PROFILES.security_profile_name%type;
begin
      	
   l_o('<a name="security"></a>');						
						l_o('<DIV class=divItem>');
						l_o('<DIV id="s1sql49b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql49'');" href="javascript:;">&#9654; Security Profile Details</A></DIV>');
                                              
                        l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql49" style="display:none" >');
                        l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        l_o('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                        l_o('     <B>Security Profile Details</B></font></TD>');
                        l_o('     <TD bordercolor="#DEE6EF">');
                        l_o('<A class=detail id="s1sql50b" style="width:220px" onclick="displayItem2(this,''s1sql50'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        l_o('   </TD>');
                        l_o(' </TR>');
                        l_o(' <TR id="s1sql50" style="display:none">');
                        l_o('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
                        l_o('       <blockquote><p align="left">');
                        l_o('        select security_profile_id, security_profile_name from PER_SECURITY_PROFILES  <br>');   
                        l_o('        order by upper(security_profile_name);<br>');  
    
                        l_o('          </blockquote><br>');
                        l_o('     </TD>');
                        l_o('   </TR>');
                        l_o(' <TR>');
                        l_o(' <TH><B>ID</B></TD>');                        
                        l_o(' <TH><B>Security Profile Name</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open security;
                          loop
                                fetch security into v_sec_id ,  v_sec_name;
                                EXIT WHEN  security%NOTFOUND;
                                l_o('<TR><TD>'||v_sec_id||'</TD>'||chr(10)||'<TD>'||v_sec_name||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close security;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       

						l_o('<tr><td><A class=detail onclick="hideRow(''s1sql49'');" href="javascript:;">Collapse section</a></td></tr>');
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
						l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						l_o(' </TABLE> </div> ');
						l_o('<div class="divok">');
						 l_o('<span class="sectionblue1">Advice:</span> Please review ');
						 l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=394083.1" target="_blank">Note 394083.1</a> ');
						 l_o('Understanding and Using HRMS Security in Oracle HRMS<br>');
						 l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1266051.1" target="_blank">Note 1266051.1</a> ');
						 l_o('Troubleshooting eBusiness Suite HRMS Security Issues<br>');
						 l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1385633.1" target="_blank">Note 1385633.1</a> ');
						 l_o('Security, MultiOrg, and Multi Org Access Control(MOAC) support in relation to Oracle Human Resources applications<br>');		
						l_o('</div>');
						l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

-- Display International Payroll usage
procedure international is
    cursor c_international is
    SELECT   fcr.argument1 international_legislation_code
				,ftv.territory_short_name, fcr.request_date
		FROM     fnd_concurrent_requests fcr
				,fnd_concurrent_programs fcp
				,fnd_territories_tl ftv
		WHERE    fcr.concurrent_program_id = fcp.concurrent_program_id
			 AND ftv.territory_code = fcr.argument1
			 AND ftv.LANGUAGE='US'
			 AND fcp.concurrent_program_name = 'PYINTSTU'; 
	
    v_code fnd_concurrent_requests.argument1%type;
	v_name fnd_territories_tl.territory_short_name%type;
	v_date fnd_concurrent_requests.request_date%type;
begin
	
			l_o('<a name="international"></a>');						
						l_o('<DIV class=divItem>');
						l_o('<DIV id="s1sql53b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql53'');" href="javascript:;">&#9654; International Payroll Usage</A></DIV>');
                        l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql53" style="display:none" >');
                        l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                        l_o('     <B>Concurrent process International HRMS Setup</B></font></TD>');
                        l_o('     <TD bordercolor="#DEE6EF">');
                        l_o('<A class=detail  id="s1sql54b"  onclick="displayItem2(this,''s1sql54'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        l_o('   </TD>');
                        l_o(' </TR>');
                        l_o(' <TR id="s1sql54" style="display:none">');
                        l_o('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
                        l_o('       <blockquote><p align="left">');
                        l_o('        SELECT   fcr.argument1 international_legislation_code<br>');
						l_o('        ,ftv.territory_short_name, fcr.request_date<br>');
						l_o('        FROM     fnd_concurrent_requests fcr<br>');
						l_o('        ,fnd_concurrent_programs fcp<br>');
						l_o('        ,fnd_territories_tl ftv<br>');
						l_o('        WHERE    fcr.concurrent_program_id = fcp.concurrent_program_id<br>');
						l_o('        AND ftv.territory_code = fcr.argument1<br>');
						l_o('        AND ftv.LANGUAGE=''US''<br>');
						l_o('        AND fcp.concurrent_program_name = ''PYINTSTU'';	<br>');		   
                        l_o('          </blockquote><br>');
                        l_o('     </TD>');
                        l_o('   </TR>');
                        l_o(' <TR>');
                        l_o(' <TH><B>Country code</B></TD>');                        
                        l_o(' <TH><B>Country Name</B></TD>');
						l_o(' <TH><B>Date when concurrent request was performed</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open c_international;
                          loop
                                fetch c_international into v_code, v_name, v_date;
                                EXIT WHEN  c_international%NOTFOUND;
                                l_o('<TR><TD>'||v_code||'</TD>'||chr(10)||'<TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_date||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close c_international;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
						l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						l_o(' </TABLE> </div> ');
						l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report the above error as comment in PAY Analyzer Note 1631780.1<br>');
end;



-- Display pay_trigger_events
procedure pay_trigger is	
	v_table pay_trigger_events.table_name%type;
    v_trigger pay_trigger_events.short_name%type;
	v1 pay_trigger_events.generated_flag%type;
	v2 pay_trigger_events.enabled_flag%type;
	v3 pay_trigger_components.enabled_flag%type;
    no_triggers number;
 	issue boolean := FALSE;
  cursor flag_triggers is
	  select pte.table_name, pte.short_name, pte.generated_flag,pte.enabled_flag, ptc.enabled_flag 
		from pay_trigger_events pte,
		pay_trigger_components ptc
		where (short_name like 'PER_%'
			 OR short_name like 'PAY_%')
		and pte.event_id = ptc.event_id(+)
		and (pte.generated_flag<>'Y' or pte.enabled_flag<>'Y' or ptc.enabled_flag<>'Y')
		order by pte.table_name;  

begin
	
	  select count(1) into no_triggers from pay_trigger_events pte,
		pay_trigger_components ptc
		where (short_name like 'PER_%'
			 OR short_name like 'PAY_%')
		and pte.event_id = ptc.event_id(+)
		and (pte.generated_flag<>'Y' or pte.enabled_flag<>'Y' or ptc.enabled_flag<>'Y');
		if no_triggers>0 then
						issue:=TRUE;
		end if;
        
		
				l_o(' <a name="pay_trigger_events"></a>');
				l_o('<DIV class=divItem>');
				l_o('<DIV id="s1sql51b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql51'');" href="javascript:;">&#9654; Pay Triggers Events</A></DIV>');		
				l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql51" style="display:none" >');
				l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
				l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
				l_o('     <B>Triggers with one of the flags not set to Y:</B></font></TD>');
				l_o('     <TD bordercolor="#DEE6EF">');
				l_o('<A class=detail  id="s1sql52b"  onclick="displayItem2(this,''s1sql52'');" href="javascript:;">&#9654; Show SQL Script</A>');
				l_o('   </TD>');
				l_o(' </TR>');
				l_o(' <TR id="s1sql52" style="display:none">');
				l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
				l_o('       <blockquote><p align="left">');
				
				l_o('          select pte.table_name, pte.short_name, pte.generated_flag,pte.enabled_flag, ptc.enabled_flag <br>');
				l_o('          from pay_trigger_events pte,<br>pay_trigger_components ptc<br> where short_name like ''PER_%''<br>');
				l_o('          	 OR short_name like ''PAY_%'')<br>   and pte.event_id = ptc.event_id(+)<br> and (pte.generated_flag<>''Y'' or pte.enabled_flag<>''Y'' or ptc.enabled_flag<>''Y'')<br>');
				l_o('          order by pte.table_name; <br>');
				l_o('          </blockquote><br>');
				l_o('     </TD></TR><TR>');
				l_o(' <TH><B>Table name</B></TD>');		
				l_o(' <TH><B>Trigger Name</B></TD>');
				l_o(' <TH><B>Generated flag</B></TD>');
				l_o(' <TH><B>Enabled flag - events</B></TD>');
				l_o(' <TH><B>Enabled flag - components</B></TD>');
			
				:n := dbms_utility.get_time;
			
				open flag_triggers;
					  loop
						 fetch flag_triggers into v_table,v_trigger,v1,v2,v3;
						 EXIT WHEN  flag_triggers%NOTFOUND;
						 l_o('<TR><TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD>'||chr(10));
						 if v1<>'Y' then
							l_o('<TD><font color="red"'||v1||'</font></TD>'||chr(10));
						 else
							l_o('<TD>'||v1||'</TD>'||chr(10));
						 end if;
						 if v2<>'Y' then
							l_o('<TD><font color="red"'||v2||'</font></TD>'||chr(10));
						 else
							l_o('<TD>'||v2||'</TD>'||chr(10));
						 end if;
						 if v3<>'Y' then
							l_o('<TD><font color="red"'||v3||'</font></TD></TR>'||chr(10));
						 else
							l_o('<TD>'||v3||'</TD>'||chr(10));
						 end if;								 
					  end loop;
				close flag_triggers;    
			 
				:n := (dbms_utility.get_time - :n)/100;
				l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
				l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
				l_o(' </TABLE> </div> ');
				
				
				if issue  then
					l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning:</span> You have trigger(s) with flag not set to Y (not set or set to N).<br></div>');
					:w1:=:w1+1;
				else             
					l_o('<div class="divok"><img class="check_ico">OK! All triggers have flag set on Y.<br></div>');
				end if;
				
				
				l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 1562530.1<br>');	
end;




-- Display PAY_ACTION parameters
procedure pay_action is
	
	v_pay_name pay_action_parameters.parameter_name%type; 
	v_pay_value pay_action_parameters.parameter_value%type;
	v_min_ini_trans number;
	v_cpu number;
	v_rows number;
	status_leg varchar2(2);
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue8 boolean := FALSE;
	issue9 boolean := FALSE;
	issue10 boolean := FALSE;
	cursor pay_action is
	select parameter_name, nvl(parameter_value,'null') 
      from pay_action_parameters
	  order by parameter_name;

begin

l_o(' <a name="pay_action"></a>');

	
	SELECT SUBSTR(value, 1, 10)
						into v_cpu
						FROM v$parameter
						WHERE name = 'cpu_count';
	select decode(status, null,'N','I')
						into status_leg
						from hr_legislation_installations
						where substr(application_short_name,1,4)='PAY'
						and  Legislation_code = 'US';
						
	select count(1) into v_rows from pay_action_parameters where parameter_name='RANGE_PERSON_ID';
	if v_rows=0 then
		issue1:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='RANGE_PERSON_ID';
		if v_pay_value <>'Y' then
			issue1:=TRUE;
		end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name='LOW_VOLUME';
	if v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='LOW_VOLUME';
		if v_pay_value <>'N' then
			issue2:=TRUE;
		end if;
	end if;
	
	if status_leg='I' then
			select count(1) into v_rows from pay_action_parameters where parameter_name='TAX_LIBRARIES';
			if v_rows=0 then
				issue3:=TRUE;
			elsif v_rows=1 then
				select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='TAX_LIBRARIES';
				if v_pay_value is NULL then
					issue3:=TRUE;
				end if;
			end if;
			select count(1) into v_rows from pay_action_parameters where parameter_name='TAX_DATA';
			if v_rows=0 then
				issue3:=TRUE;
			elsif v_rows=1 then
				select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='TAX_DATA';
				if v_pay_value is NULL then
					issue3:=TRUE;
				end if;
			end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name='THREADS';
	v_pay_value:=1;
	if v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='THREADS';
	elsif v_rows=0 then
		v_pay_value:=1;
	end if;
	if v_pay_value<1.5*v_cpu or v_pay_value>2*v_cpu then
		issue5:=TRUE;
	end if;						
	SELECT min(ini_trans)
						into v_min_ini_trans
						FROM DBA_TABLES
						WHERE table_name IN ('FF_ARCHIVE_ITEMS'
                          ,'FF_ARCHIVE_ITEM_CONTEXTS'
                          ,'PAY_ACTION_INFORMATION'
                          ,'PAY_ASSIGNMENT_ACTIONS'
                          ,'PAY_ASSIGNMENT_LATEST_BALANCES'
                          ,'PAY_BALANCE_CONTEXT_VALUES'
                          ,'PAY_COSTS'
                          ,'PAY_DEFINED_BALANCES'
                          ,'PAY_ELEMENT_ENTRIES_F'
                          ,'PAY_ELEMENT_ENTRY_VALUES_F'
                          ,'PAY_INPUT_VALUES_F'
                          ,'PAY_PAYROLL_ACTIONS'
                          ,'PAY_PERIODS_OF_SERVICE'
                          ,'PAY_PERSON_LATEST_BALANCES'
                          ,'PAY_POPULATION_RANGES'
                          ,'PAY_PRE_PAYMENTS'
                          ,'PAY_RUN_BALANCES'
                          ,'PAY_RUN_RESULTS'
                          ,'PAY_RUN_RESULT_VALUES'
                          ,'PAY_US_RPT_TOTALS'
                          ,'PER_ALL_ASSIGNMENTS_F'
                          ,'PER_ALL_PEOPLE_F');
	if v_pay_value>v_min_ini_trans then
		issue6:=TRUE;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'RR%BUFFER%SIZE';
	if v_rows=0 then
		issue7:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'RR%BUFFER%SIZE';
		if v_pay_value <100 then
			issue7:=TRUE;
		end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'RRV%BUFFER%SIZE';
	if v_rows=0 then
		issue8:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'RRV%BUFFER%SIZE';
		if v_pay_value <100 then
			issue8:=TRUE;
		end if;
	end if;	
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'BAL%BUFFER%SIZE';
	if v_rows=0 then
		issue9:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'BAL%BUFFER%SIZE';
		if v_pay_value <100 then
			issue9:=TRUE;
		end if;
	end if;	
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'EE%BUFFER%SIZE';
	if v_rows=0 then
		issue10:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like'EE%BUFFER%SIZE';
		if v_pay_value <100 then
			issue10:=TRUE;
		end if;
	end if;	
	
	l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql9b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql9'');" href="javascript:;">&#9654; PAY Action Parameters</A></DIV>');
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql9" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>PAY action parameters</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql10b"  onclick="displayItem2(this,''s1sql10'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql10" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         select parameter_name, parameter_value <br> from pay_action_parameters<br>order by parameter_name');
		l_o('          </blockquote><br>');
		l_o('     </TD></TR><TR>');
		l_o(' <TH><B>Name</B></TD>');
		l_o(' <TH><B>Value</B></TD>');
	
		:n := dbms_utility.get_time;
		
		open pay_action;
		loop
			fetch pay_action into v_pay_name,v_pay_value;
			EXIT WHEN  pay_action%NOTFOUND;
			l_o('<TR><TD>'||v_pay_name||'</TD>'||chr(10)||'<TD>');
			l_o(v_pay_value);
			l_o('</TD></TR>'||chr(10));
          
		end loop;
		close pay_action;

		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql9'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
	
		if issue1 or issue2 or issue3 or issue4 then
			l_o('<div class="diverr">');
			if issue1 then
				l_o('<img class="error_ico"><font color="red">Error:</font> Please set RANGE_PERSON_ID to Y<br>');
				:e1:=:e1+1;
			end if;
			
			if issue2 then
				l_o('<img class="error_ico"><font color="red">Error:</font> Please set LOW_VOLUME to N<br>');
				:e1:=:e1+1;
			end if;
			
			if issue3 then
				l_o('<img class="error_ico"><font color="red">Error:</font> Please set TAX_LIBRARIES<br>');
				:e1:=:e1+1;
			end if;
			
			if issue4 then
				l_o('<img class="error_ico"><font color="red">Error:</font> Please set TAX_DATA<br>');
				:e1:=:e1+1;
			end if;
			l_o('</div>');
		end if;
		
		if issue5 or issue6 or issue7 or issue8 or issue9 or issue10 then
			l_o('<div class="divwarn">');
			if issue5 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set Threads to 1.5 to 2 times the number of processors, ');
				l_o('meaning between '||ceil(1.5*v_cpu)||' and '||ceil(2*v_cpu)||' <br>');
				l_o('<span class="sectionblue1">Advice:</span> Check <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=359354.1" target="_blank">Note 359354.1</a> ');
				l_o('How to Determine the Best Setting for the THREADS Parameter in the Pay_Action_Parameters Table<br>');
				:w1:=:w1+1;
			end if;
			
			if issue6 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please ensure the number of threads set in PAY_ACTION_PARAMETERS is the same ');
				l_o('or lower than the ini_trans on hot PAY tables <br>');
				:w1:=:w1+1;
			end if;
			
			if issue7 or issue8 or issue9 or issue10 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> If trace files show differences between execute and fetch timings, then worth having a look at buffer sizes:<br>');
				if issue7 then
					l_o(' - Try setting RR BUFFER SIZE to 100.<br>');
				end if;
				if issue8 then
					l_o(' - Try setting RRV buffer SIZE to 100.<br>');
				end if;
				if issue9 then
					l_o(' - Try setting BAL BUFFER SIZE to 100.<br>');
				end if;
				if issue10 then
					l_o(' - Try setting EE BUFFER SIZE to 100.<br>');
				end if;
				:w1:=:w1+1;
			end if;
			
			l_o('</div>');
		end if;
		
		l_o('<div class="divok">');
		l_o('<span class="sectionblue1">Advice:</span> Please review:<br> ');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=549367.1" target="_blank">Note 549367.1</a> ');
		l_o('Oracle Human Resources Payroll PAY_ACTION_PARAMETERS Comprehensive Overview<br>');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=226987.1" target="_blank">Note 226987.1</a> ');
		l_o('Oracle 11i and R12 Human Resources and Benefits Tuning and System Health Checks<br>');
		l_o('</div>');
		
		if (not issue1) and (not issue2) and (not issue3) and (not issue4) and (not issue5) and (not issue6) and (not issue7) and (not issue8) and (not issue9) and (not issue10) then
				l_o('<div class="divok">Verified parameters are correctly set<br></div>');
		end if;	
		
		
		
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
l_o(' <a name="ssp"></a>');
l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql21b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql21'');" href="javascript:;">&#9654; SSP_TEMP_AFFECTED_ROWS</A></DIV>');
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql21" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('     <B>SSP_TEMP_AFFECTED_ROWS rows</B></font></TD><TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql10b"  onclick="displayItem2(this,''s1sql22'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD></TR><TR id="s1sql22" style="display:none"><TD colspan="1" height="60">');
		l_o(' <blockquote><p align="left">select count(1) from SSP_TEMP_AFFECTED_ROWS</blockquote><br></TD></TR><TR>');
		l_o(' <TH><B>Count of rows</B></TD>');	
		:n := dbms_utility.get_time;
		l_o('<TR><TD>'||v_rows||'</TD></TR>'||chr(10));			
		:n := (dbms_utility.get_time - :n)/100;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
	
		if v_rows>0 then
			l_o('<div class="divwarn">');
			l_o('<img class="warn_ico">For Oracle Support: SSP_TEMP_AFFECTED_ROWS table has rows.</div>');
			:w1:=:w1+1;
		else
				l_o('<div class="divok">');
				l_o('OK! No rows in SSP_TEMP_AFFECTED_ROWS<br>');
				l_o('</div>');
		end if;			
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report the above error as comment in PAY Analyzer Note 1631780.1<br>');
end;



-- Display HRMS RUP level
procedure rup is
    rup_level varchar2(20);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_rows number;
	v_exists number;
	issue boolean:=FALSE;
	rup_n varchar2(50);
	cursor c_patching_122 is
		SELECT distinct PATCH_NAME, DECODE(PATCH_NAME
                  ,'19193000', 'R12.HR_PF.C.Delta.6'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
                   ) 
                , trunc(LAST_UPDATE_DATE)                     
                  FROM ad_applied_patches
		WHERE PATCH_NAME IN ('19193000','17909898','17050005','17001123','16169935','14040707','10124646')
		order by trunc(LAST_UPDATE_DATE) desc;
	cursor c_patching_121 is
		SELECT distinct PATCH_NAME, DECODE(PATCH_NAME
                  ,'20000288','R12.HR_PF.B.delta.8'
				  ,'18004477', 'R12.HR_PF.B.delta.7'
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , trunc(LAST_UPDATE_DATE)                     
                  FROM ad_applied_patches
		WHERE PATCH_NAME IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330')
		order by trunc(LAST_UPDATE_DATE) desc;

	cursor c_patching_120 is
		SELECT distinct PATCH_NAME, DECODE(PATCH_NAME
						  , '16077077', 'R12.HR_PF.A.delta.11'
						  , '13774477', 'R12.HR_PF.A.delta.10'
						  , '10281209', 'R12.HR_PF.A.delta.9'
						  , '9301208', 'R12.HR_PF.A.delta.8'
						  , '7577660', 'R12.HR_PF.A.delta.7'
						  , '7004477', 'R12.HR_PF.A.delta.6'
						  , '6610000', 'R12.HR_PF.A.delta.5'
						  , '6494646', 'R12.HR_PF.A.delta.4'
						  , '6196269', 'R12.HR_PF.A.delta.3'
						  , '5997278', 'R12.HR_PF.A.delta.2'
						  , '5881943', 'R12.HR_PF.A.delta.1'
						  , '4719824', 'R12.HR_PF.A')
						, trunc(LAST_UPDATE_DATE)                     
						  FROM ad_applied_patches
		WHERE PATCH_NAME IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824')
		order by trunc(LAST_UPDATE_DATE) desc;

	cursor c_patching_11 is
		SELECT distinct PATCH_NAME, DECODE(PATCH_NAME
								   , '2803988', 'HRMS_PF.E'
								   , '2968701', 'HRMS_PF.F'
								   , '3116666', 'HRMS_PF.G'
								   , '3233333', 'HRMS_PF.H'
								   , '3127777', 'HRMS_PF.I'
								   , '3333633', 'HRMS_PF.J'
								   , '3500000', 'HRMS_PF.K'
								   , '5055050', 'HR_PF.K.RUP.1'
								   , '5337777', 'HR_PF.K.RUP.2'
								   , '6699770', 'HR_PF.K.RUP.3'
								   , '7666111', 'HR_PF.K.RUP.4'
								   , '9062727', 'HR_PF.K.RUP.5'
								   , '10015566', 'HR_PF.K.RUP.6'
								   , '12807777', 'HR_PF.K.RUP.7'
								   , '14488556', 'HR_PF.K.RUP.8'
								   , '17774746', 'HR_PF.K.RUP.9'
									)  
						, trunc(LAST_UPDATE_DATE)                     
						  FROM ad_applied_patches
		WHERE PATCH_NAME IN ('2803988','2968701','3116666','3233333','3127777','3333633',
						   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746')
		order by trunc(LAST_UPDATE_DATE) desc;
    
	

begin
     

      l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" >');      
      l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><th><b>Section</b></td><th><b>Status and advices</b></td></tr>');     
      
      l_o(' <TR><td>HRMS RUP</td><td>');
      
	  if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into rup_level FROM ad_bugs adb
			WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646');
                 
            if rup_level='19193000' then
                  
                   l_o('<span class="sectionb"><b>Actual level:</b> Patch 19193000 R12.HR_PF.C.delta.6 applied on '||:v_rup_date||'</span><br><br>');                  
                  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1992028.1" target="_blank"> Note 1992028.1</a> ');
                  l_o('Known Issues on Top of Patch 19193000 - R12.HR_PF.C.DELTA.6 (HRMS 12.2 RUP6)<br><br>');  
				
				l_o('</span>');
            else
                  SELECT DECODE(bug_number
                   ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                 l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '</span><br><br>');
				  l_o('<div class="divwarn">');
                  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19193000">');
				  l_o('Patch 19193000</a> R12.HR_PF.C.DELTA.6</div><br><br>');
				  :w1:=:w1+1;
				  issuep:=TRUE;
							  
				  
            end if; 
			SELECT count(1) into v_rows FROM ad_applied_patches
						WHERE PATCH_NAME IN ('19193000','17909898','17050005','17001123','16169935','14040707','10124646');
				if v_rows>0 then
					l_o('<span class="sectionb"><br>HRMS Patching history:<br>');
						open c_patching_122;
						loop
							  fetch c_patching_122 into rup_level,rup_n,v_date;
							  EXIT WHEN  c_patching_122%NOTFOUND;
							  l_o('Patch '||rup_level || ' ' || rup_n || ' applied on ' || to_char(v_date,'DD-MON-YYYY') || '<br>');	  
						end loop;
						close c_patching_122;					
					l_o('</span><br>');
				end if;
       
            
      elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');            
                 
            if rup_level='20000288' then
                  
                  l_o('<span class="sectionb">Actual level: Patch 20000288 R12.HR_PF.B.delta.8 applied on '||:v_rup_date||'</span><br><br>');
                  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1992029.1" target="_blank"> Note 1992029.1</a> ');
                  l_o('Known Issues on Top of Patch 20000288 - R12.HR_PF.B.DELTA.8 (HRMS 12.1 RUP8)<br><br>');
				  
 
            else
                  SELECT DECODE(BUG_NUMBER
                  ,'18004477', 'R12.HR_PF.B.delta.7' 
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  l_o('<span class="sectionb">Actual level: Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '</span><br><br>');
                   l_o('<div class="divwarn">');
                  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=20000288">');
				  l_o('Patch 20000288</a> R12.HR_PF.B.delta.8</div><br><br>');
				  issuep:=TRUE;				  				  
				  :w1:=:w1+1;
            end if; 
			
                SELECT count(1) into v_rows FROM ad_applied_patches
						WHERE PATCH_NAME IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');
				if v_rows>0 then
					l_o('<span class="sectionb"><br>HRMS Patching history:<br>');
						open c_patching_121;
						loop
							  fetch c_patching_121 into rup_level,rup_n,v_date;
							  EXIT WHEN  c_patching_121%NOTFOUND;
							  l_o('Patch '||rup_level || ' ' || rup_n || ' applied on ' || to_char(v_date,'DD-MON-YYYY') || '<br>');	  
						end loop;
						close c_patching_121;					
					l_o('</span><br>');
				end if;
            
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
            
            if rup_level='16077077' then
                 
                  l_o('<span class="sectionb">Actual level: Patch 16077077 R12.HR_PF.A.delta.11</span><br><br>');                  
                  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1538635.1" target="_blank"> Note 1538635.1</a> ');
                  l_o('Known Issues on Top of Patch 16077077 - r12.hr_pf.a.delta.11</span><br><br>');				  
				 
            else
                  SELECT DECODE(BUG_NUMBER
                  , '16077077', 'R12.HR_PF.A.delta.11'
                  , '13774477', 'R12.HR_PF.A.delta.10'
                  , '10281209', 'R12.HR_PF.A.delta.9'
                  , '9301208', 'R12.HR_PF.A.delta.8'
                  , '7577660', 'R12.HR_PF.A.delta.7'
                  , '7004477', 'R12.HR_PF.A.delta.6'
                  , '6610000', 'R12.HR_PF.A.delta.5'
                  , '6494646', 'R12.HR_PF.A.delta.4'
                  , '6196269', 'R12.HR_PF.A.delta.3'
                  , '5997278', 'R12.HR_PF.A.delta.2'
                  , '5881943', 'R12.HR_PF.A.delta.1'
                  , '4719824', 'R12.HR_PF.A')
                  , LAST_UPDATE_DATE  
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  l_o('<span class="sectionb">Actual level: Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '</span><br><br>');
                  l_o('<div class="divwarn">');
                  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=16077077">');
				  l_o('Patch 16077077</a> R12.HR_PF.A.delta.11</div><br><br>');
				  issuep:=TRUE;		  
				  :w1:=:w1+1;
				  
            end if;  
			
                SELECT count(1) into v_rows FROM ad_applied_patches
						WHERE PATCH_NAME IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
				if v_rows>0 then
					l_o('<span class="sectionb"><br>HRMS Patching history:<br>');
						open c_patching_120;
						loop
							  fetch c_patching_120 into rup_level,rup_n,v_date;
							  EXIT WHEN  c_patching_120%NOTFOUND;
							  l_o('Patch '|| rup_level || ' ' || rup_n || ' applied on ' || to_char(v_date,'DD-MON-YYYY') || '<br>');	  
						end loop;
						close c_patching_120;					
					l_o('</span><br>');
				end if;           
			
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_rows from ad_bugs 
            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
            
            if v_rows=0 then
                     l_o('<div class="diverr">');
					l_o('<img class="error_ico"><font color="red">Error:</font> No RUP patch applied!<br><br>');
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17774746">');
					l_o('Patch 17774746</a> HR_PF.K.RUP.9</div><br>');
					issuep:=TRUE;
					:e1:=:e1+1;
            else        
                    select max(to_number(bug_number)) into rup_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
                   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
                    if rup_level='17774746' then
                         
                          l_o('<span class="sectionb">Actual level: Patch 17774746 HR_PF.K.RUP.9 applied on '||:v_rup_date||'</span><br><br>');
                          l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                          l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1636768.1" target="_blank"> Note 1636768.1</a> ');
                          l_o('Known Issues on Top of Patch 17774746 - 11i.hr_pf.k.delta.9 (HRMS 11i RUP9)</span><br><br>');				  
				   
                          
                    else
                          SELECT DECODE(BUG_NUMBER
                           , '2803988', 'HRMS_PF.E'
                           , '2968701', 'HRMS_PF.F'
                           , '3116666', 'HRMS_PF.G'
                           , '3233333', 'HRMS_PF.H'
                           , '3127777', 'HRMS_PF.I'
                           , '3333633', 'HRMS_PF.J'
                           , '3500000', 'HRMS_PF.K'
                           , '5055050', 'HR_PF.K.RUP.1'
                           , '5337777', 'HR_PF.K.RUP.2'
                           , '6699770', 'HR_PF.K.RUP.3'
                           , '7666111', 'HR_PF.K.RUP.4'
                           , '9062727', 'HR_PF.K.RUP.5'
                           , '10015566', 'HR_PF.K.RUP.6'
                           , '12807777', 'HR_PF.K.RUP.7'
                           , '14488556', 'HR_PF.K.RUP.8'
						   ,'17774746', 'HR_PF.K.RUP.9'
                            )  
                        , LAST_UPDATE_DATE  
                          into :rup_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =rup_level and rownum < 2;
                          
                          l_o('<span class="sectionb">Actual level: Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '</span><br><br>');
                          l_o('<div class="divwarn">');
						   l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17774746">');
						  l_o('Patch 17774746</a> HR_PF.K.RUP.9</div><br><br>');
						  issuep:=TRUE;						  
						  :w1:=:w1+1;
                    end if;
					
						SELECT count(1) into v_rows FROM ad_applied_patches
						WHERE PATCH_NAME IN ('2803988','2968701','3116666','3233333','3127777','3333633',
							'3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
						if v_rows>0 then
							l_o('<span class="sectionb"><br>HRMS Patching history:<br>');
								open c_patching_11;
								loop
									  fetch c_patching_11 into rup_level,rup_n,v_date;
									  EXIT WHEN  c_patching_11%NOTFOUND;
									  l_o('Patch '||rup_level || ' ' || rup_n || ' applied on ' || to_char(v_date,'DD-MON-YYYY') || '<br>');	  
								end loop;
								close c_patching_11;					
							l_o('</span><br>');
						
					end if;					
            end if;   
      end if;
      --l_o('</td></tr>');
	 
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');      
end;


-- Display ATG level
procedure atg is
    atg_level varchar2(20);
    atg_level_n varchar2(50);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_exists number;
begin

      
      l_o(' <TR><td><a name="atg"></a>ATG</td><td>');
       
	   if  :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into atg_level FROM ad_bugs adb
			WHERE adb.bug_number in ('10110982','14222219','15890638','17007206','17909318');
			SELECT DECODE(BUG_NUMBER
             , '10110982', 'R12.ATG_PF.C'
             , '14222219', 'R12.ATG_PF.C.delta.1'
             , '15890638', 'R12.ATG_PF.C.delta.2'
             , '17007206', 'R12.ATG_PF.C.delta.3','17909318', 'R12.ATG_PF.C.delta.4')
                , LAST_UPDATE_DATE   
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
			if atg_level='17909318' then                  
                  l_o('<span class="sectionb"><b>Actual level:</b> Patch 17909318 R12.ATG_PF.C.delta.4</span><br><br>'); 
            else
				SELECT DECODE(BUG_NUMBER
				 , '10110982', 'R12.ATG_PF.C'
				 , '14222219', 'R12.ATG_PF.C.delta.1'
				 , '15890638', 'R12.ATG_PF.C.delta.2'
				 , '17007206', 'R12.ATG_PF.C.delta.3','17909318', 'R12.ATG_PF.C.delta.4')
					, LAST_UPDATE_DATE   
					  into atg_level_n, v_date
					  FROM ad_bugs 
					  WHERE BUG_NUMBER =atg_level and rownum < 2;
				 l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '</span><br><br>');
                  l_o('<div class="divwarn">');
				  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17909318">Patch 17909318</a> ');
				  l_o('R12.ATG_PF.C.delta.4<br></div>');
				  issuep:=TRUE;
				  :w1:=:w1+1;
			end if;	  
        
				
	  elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into atg_level from ad_bugs 
            WHERE BUG_NUMBER IN ('6430106','7307198','7651091','8919491');            
                 
            if atg_level='8919491' then
                  l_o('<span class="sectionb">Actual level: Patch 8919491 R12.ATG_PF.B.delta.3</span><br><br>');                  
                  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1273640.1" target="_blank"> Note 1273640.1</a> ');
                  l_o('Known ATG issues on Top of 12.1.3 - r12.atg_pf.b.delta.3, Patch 8919491</span>');
                  
            else
                  SELECT DECODE(BUG_NUMBER
                 , '6430106', 'R12.ATG_PF.B'
                 , '7307198', 'R12.ATG_PF.B.delta.1'
                 , '7651091', 'R12.ATG_PF.B.delta.2'
                 , '8919491', 'R12.ATG_PF.B.delta.3')
                , LAST_UPDATE_DATE   
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
                  
                  l_o('<span class="sectionb">Actual level: Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '</span><br><br>');
                  l_o('<div class="divwarn">');
				  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=8919491">Patch 8919491</a> ');
				  l_o('R12.ATG_PF.B.delta.3<br></div>');
				  issuep:=TRUE;
				  :w1:=:w1+1;
            end if; 
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into atg_level from ad_bugs 
            WHERE BUG_NUMBER IN ('4461237','5907545','5917344','6077669','6272680','6594849','7237006');
            
            if atg_level='7237006' then                  
                  l_o('<span class="sectionb"><img class="check_ico">OK! You are at latest level available: Patch 7237006 R12.ATG_PF.A.delta.6.</span><br>');                  
            else
                  SELECT DECODE(BUG_NUMBER
                 , '4461237', 'R12.ATG_PF.A'
                 , '5907545', 'R12.ATG_PF.A.delta.1'
                 , '5917344', 'R12.ATG_PF.A.delta.2'
                 , '6077669', 'R12.ATG_PF.A.delta.3'
                 , '6272680', 'R12.ATG_PF.A.delta.4'
                 , '6594849', 'R12.ATG_PF.A.delta.5'
                 , '7237006', 'R12.ATG_PF.A.delta.6')
                  , LAST_UPDATE_DATE  
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
                  
                  l_o('<span class="sectionb">Actual level: Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '</span><br><br>');
                  l_o('<div class="divwarn">');
                  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=7237006">Patch 7237006</a>');
				  l_o('				  R12.ATG_PF.A.delta.6<br></div>');
				  issuep:=TRUE;
				  :w1:=:w1+1;
            end if;   
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
            
            if v_exists=0 then
                    l_o('<div class="diverr">');
					l_o('<img class="error_ico"><font color="red">Error:</font> No ATG RUP patch applied!</span><br><br>');
                    l_o('Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=6241631">Patch 6241631</a> ');
					l_o('11i.ATG_PF.H RUP7</div><br>');
					issuep:=TRUE;
					:e1:=:e1+1;
            else        
                    select max(to_number(bug_number)) into atg_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
                    if atg_level='6241631' then
                          
                          l_o('<span class="sectionb">Actual level: Patch 6241631 11i.ATG_PF.H RUP7<span><br><br>');                          
                          l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                          l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=858801.1" target="_blank"> Note 858801.1</a> ');
                          l_o('Known Issues On Top of 11i.atg_pf.h.delta.7 (RUP7) - 6241631</span>');                    
                          
                    else
                          SELECT DECODE(BUG_NUMBER
                         , '3438354', '11i.ATG_PF.H'
                         , '4017300', '11i.ATG_PF.H RUP1'
                         , '4125550', '11i.ATG_PF.H RUP2'
                         , '4334965', '11i.ATG_PF.H RUP3'
                         , '4676589', '11i.ATG_PF.H RUP4'
                         , '5473858', '11i.ATG_PF.H RUP5'
                         , '5903765', '11i.ATG_PF.H RUP6'
                         , '6241631', '11i.ATG_PF.H RUP7')
                        , LAST_UPDATE_DATE  
                          into atg_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =atg_level and rownum < 2;
                          
                          l_o('<span class="sectionb">Actual level: Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '</span><br><br>');
                          l_o('<div class="divwarn">');
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=6241631">');
						  l_o('Patch 6241631</a> 11i.ATG_PF.H RUP7<br></div>');
						  issuep:=TRUE;
						  :w1:=:w1+1;
       
                    end if;                   
            end if;   
      end if;
      l_o('</td></tr>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


-- Display hrglobal information
procedure hrglobal is
    v_exists number;
    v_hrglobal_date ad_patch_runs.end_date%type;
	v_action ad_patch_runs.end_date%type;
    v_hrglobal_patch_opt ad_patch_runs.PATCH_ACTION_OPTIONS%type;
    v_hrglobal_patch ad_applied_patches.patch_name%type;
begin
      
      l_o(' <TR><td><a name="hrglobal"></a>Hrglobal</td><td>');
      
      if   :apps_rel like '12%' then
            SELECT count(1) into v_exists
            FROM ad_patch_runs pr
            WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
              AND pr.SUCCESS_FLAG = 'Y'
              AND pr.end_date =(
               SELECT MAX(pr.end_date)
               FROM ad_patch_runs pr
               WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
                 AND pr.SUCCESS_FLAG = 'Y');
      else
            SELECT count(1) into v_exists
            FROM ad_patch_runs pr
            WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
              AND pr.SUCCESS_FLAG = 'Y'
              AND pr.end_date =(
               SELECT MAX(pr.end_date)
               FROM ad_patch_runs pr
               WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
                 AND pr.SUCCESS_FLAG = 'Y');
      end if;
      
      if v_exists>0 then
              if   :apps_rel like '12%' then
					  SELECT pr.end_date 
						   , pr.PATCH_ACTION_OPTIONS 
					  into v_hrglobal_date, v_hrglobal_patch_opt 
					  FROM ad_patch_runs pr
					  WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
						AND pr.SUCCESS_FLAG = 'Y'
						AND pr.end_date =(
						 SELECT MAX(pr.end_date)
						 FROM ad_patch_runs pr
						 WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
						   AND pr.SUCCESS_FLAG = 'Y');
			else
						SELECT pr.end_date 
						   , pr.PATCH_ACTION_OPTIONS 
					  into v_hrglobal_date, v_hrglobal_patch_opt 
						FROM ad_patch_runs pr
						WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
						  AND pr.SUCCESS_FLAG = 'Y'
						  AND pr.end_date =(
						   SELECT MAX(pr.end_date)
						   FROM ad_patch_runs pr
						   WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
							 AND pr.SUCCESS_FLAG = 'Y');
			end if;	 
				 
              select ap.patch_name  patchnumber into v_hrglobal_patch
                    from ad_applied_patches ap
                       , ad_patch_drivers pd
                       , ad_patch_runs pr
                       , ad_patch_run_bugs prb
                       , ad_patch_run_bug_actions prba
                       , ad_files f
                    where f.file_id                  = prba.file_id
                      and prba.executed_flag         = 'Y'
                      and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                      and prb.patch_run_id           = pr.patch_run_id
                      and pr.patch_driver_id         = pd.patch_driver_id
                      and pd.applied_patch_id        = ap.applied_patch_id
                      and f.filename = 'hrglobal.drv'
                      and pr.end_date = (select max(pr.end_date)
                                                 from ad_applied_patches ap
                                                    , ad_patch_drivers pd
                                                    , ad_patch_runs pr
                                                    , ad_patch_run_bugs prb
                                                    , ad_patch_run_bug_actions prba
                                                    , ad_files f
                                                  where f.file_id                  = prba.file_id
                                                    and prba.executed_flag         = 'Y'
                                                    and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                    and prb.patch_run_id           = pr.patch_run_id
                                                    and pr.patch_driver_id         = pd.patch_driver_id
                                                    and pd.applied_patch_id        = ap.applied_patch_id
                                                    and f.filename = 'hrglobal.drv');

                l_o('<br><span class="sectionb">Your date of last successful run of hrglobal.drv was with patch '||v_hrglobal_patch|| ' ' || v_hrglobal_patch_opt);
				l_o(' on ' || v_hrglobal_date   ||'<br><br>' );
				
				if v_hrglobal_date<:v_rup_date then
					l_o('<div class="divwarn">');
					l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You did not performed hrglobal after last HRMS RUP applied!</div><br><br>');
					issuep:=TRUE;
					:w1:=:w1+1;
				else
					l_o('<img class="check_ico">OK! You performed hrglobal after HRMS RUP.<br><br>');
				end if;
				
				select  max( last_update_date) into v_action  from hr_legislation_installations  where (status is not null or action is not null) ;
				l_o('Last time performed DataInstal on ' || v_action   ||'<br><br>' );
				if v_hrglobal_date<v_action then
					l_o('<div class="divwarn">');
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You did not performed hrglobal after running DataInstall!</div><br><br>');
					issuep:=TRUE;
					:w1:=:w1+1;
				else
					l_o('<img class="check_ico">OK! You performed hrglobal after running DataInstall.<br><br>');
				end if;
				
                l_o(' To identify the version please run: strings -a $PER_TOP/patch/115/driver/hrglobal.drv | grep Header </span><br><br>');
                l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Please periodically review (note periodically updated): ');
				if   :apps_rel like '12.2%' then
					l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1469456.1" target="_blank"> Note 1469456.1</a> ');
					l_o('DATAINSTALL AND HRGLOBAL APPLICATION: 12.2 SPECIFICS<br>'); 
				else
					l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=145837.1" target="_blank"> Note 145837.1</a> ');
					l_o('Latest Oracle HRMS Legislative Data Patch Available (HR Global / hrglobal)<br>');
				end if;
				l_o('</span>');
      end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


-- Display Data Installed issues
procedure DataInstalled is

    v_exists number;
    v_leg_code varchar2(7);
    v_apps hr_legislation_installations.application_short_name%type;
    v_action hr_legislation_installations.action%type;
    cursor datainstaller_actions is
          select decode(hli.legislation_code
                   ,null,'global'
                   ,hli.legislation_code) 
           , hli.application_short_name                  
           , hli.action                                 
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name
      order by legislation_code desc, application_short_name asc;

begin      
      
      select count(1) into v_exists
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name;
      
      if v_exists>0 then
                                  :w1:=:w1+1;
								  l_o('<br><A class=detail onclick="displayItem(this,''s1sql36'');" href="javascript:;"><font size="+0.5">&#9654; DataInstaller Actions</font></A>');
                                  l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql36" style="display:none" >');
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                                  l_o('     <B>DataInstaller actions:</B></font></TD>');
                                  l_o('     <TD bordercolor="#DEE6EF">');
                                  l_o('<A class=detail id="s1sql37b" style="width:220px" onclick="displayItem2(this,''s1sql37'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  l_o('   </TD></TR>');
                                  l_o(' <TR id="s1sql37" style="display:none">');
                                  l_o('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                                  l_o('       <blockquote><p align="left">');
                                  l_o('          select decode(hli.legislation_code <br> ,null,''global''<br>,hli.legislation_code) <br> , hli.application_short_name <br>');   
                                  l_o('           , hli.action<br>from user_views uv<br>, hr_legislation_installations hli<br>');
                                  l_o('      where uv.view_name in (select view_name from hr_legislation_installations)<br>');
                                  l_o('      and uv.view_name = hli.view_name<br>');
                                  l_o('      order by legislation_code desc, application_short_name asc;<br>');
                                  l_o('          </blockquote><br>');
                                  l_o('     </TD></TR><TR>');
                                  l_o(' <TH><B>Legislation Code</B></TD>');
                                  l_o(' <TH><B>Application Name</B></TD>');
                                  l_o(' <TH><B>Action</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open datainstaller_actions;
                                  loop
                                        fetch datainstaller_actions into  v_leg_code,v_apps ,v_action;
                                        EXIT WHEN  datainstaller_actions%NOTFOUND;
                                        l_o('<TR><TD>'||v_leg_code||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD></TR>'||chr(10));
                                  end loop;
                                  close datainstaller_actions;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                                  l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                   l_o(' </TABLE> ');
                                  
								  l_o('<div class="diverr">');
								  l_o('<img class="error_ico"><font color="red">Error:</font> You have legislations currently selected for install by the DataInstall.');
                                  l_o(' Please resolve hrglobal issues in order to install/upgrade all legislative data selected during DataInstaller.<br>');
                                  l_o('Please review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=140511.1" target="_blank" >Note 140511.1</a> ');
								  l_o('How to Install HRMS Legislative Data Using Data Installer and hrglobal.drv</div><br><br>');
								  :e1:=:e1+1;
								  issuep:=TRUE;
								 
         end if;   
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');		 
end;


-- Display Statutory Exceptions
procedure Statutory is

    cursor statutory is
    select table_name
           , surrogate_id 
           , true_key
           , exception_text
      from hr_stu_exceptions;
    v_table_name hr_stu_exceptions.table_name%type;
    v_surrogate_id hr_stu_exceptions.surrogate_id%type;
    v_true_key hr_stu_exceptions.true_key%type;
    v_exception_text hr_stu_exceptions.exception_text%type;
    v_exists number;
    
begin    
      select count(1) into v_exists
					  from hr_stu_exceptions;        
     
      if v_exists>0 then
                                :w1:=:w1+1;
								l_o('<A class=detail onclick="displayItem(this,''s1sql38'');" href="javascript:;"><font size="+0.5">&#9654; Statutory Exceptions</font></A>');
                                  l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql38" style="display:none" >');
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                                  l_o('     <B>Statutory exceptions:</B></font></TD>');
                                  l_o('     <TD bordercolor="#DEE6EF">');
                                  l_o('<A class=detail id="s1sql39b" style="width:220px" onclick="displayItem2(this,''s1sql39'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  l_o('   </TD></TR>');
                                  l_o(' <TR id="s1sql39" style="display:none">');
                                  l_o('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                                  l_o('       <blockquote><p align="left">');
                                  l_o('          select table_name <br> to_char(surrogate_id) surrogate_id<br> true_key<br> , exception_text<br>  from hr_stu_exceptions;<br>'); 
                                  l_o('          </blockquote><br>');
                                  l_o('     </TD></TR> <TR>');
                                  l_o(' <TH><B>Table name</B></TD>');
                                  l_o(' <TH><B>Surrogate ID</B></TD>');
                                  l_o(' <TH><B>True key</B></TD>');
                                  l_o(' <TH><B>Exception</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open statutory;
                                  loop
                                        fetch statutory into  v_table_name , v_surrogate_id , v_true_key , v_exception_text;
                                        EXIT WHEN  statutory%NOTFOUND;
                                        l_o('<TR><TD>'||v_table_name||'</TD>'||chr(10)||'<TD>'||v_surrogate_id||'</TD>'||chr(10)||'<TD>');
										l_o(v_true_key||'</TD>'||chr(10)||'<TD>');
                                        l_o(v_exception_text);
                                        l_o('</TD></TR>'||chr(10));
                                  end loop;
                                  close statutory;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                                  l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                   l_o(' </TABLE> ');
                                  
								  l_o('<div class="diverr">');
								  l_o('<img class="error_ico"><font color="red">Error:</font> You have statutory exceptions. ');
                                  l_o('In order to solve please review:<br>');
                                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=101351.1" target="_blank" >Note 101351.1</a> ');
								  l_o('HRGLOBAL.DRV:DIAGNOSING PROBLEMS WITH LEGISLATIVE UPDATES - HR_LEGISLATION.INSTALL</div>');
								  :e1:=:e1+1;
								  issuep:=TRUE;                               
                                 
         end if;  

      l_o('</td></tr>');
      
      
      
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');          
end;

 -- Display patch
procedure dpatch (v_leg varchar2, v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;	  
	  v_exists number;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								issuep:=TRUE;
								 l_o('<div class="diverr">');
								 l_o('<img class="error_ico"><font color="red">Error: </font>Please plan to install ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');	
								 l_o('</div>');
								 :e1:=:e1+1;
							else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							l_o('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
						EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
	end; 
	
	
-- Display baseline patching status
procedure baseline is
  v_status varchar2(5);
  no_rows number;
  v_exists number;
  issue boolean:=FALSE;
begin
    
    if :apps_rel like '11.5%' or :apps_rel like '12.0%' then
		l_o(' <TR><td>Baseline patches</td><td>');
		if :apps_rel like '11.5%' then		  
          dpatch('not','5903765','11i.ATG_PF.H.delta.6');         
		  dpatch('not','6699770',' - baseline patch for PER, BEN, PSP, IRC, Self Service');
          select count(1) into no_rows from fnd_product_installations where status='I' and application_id in (801, 8301) ;
          if no_rows>0 then
                dpatch('not','7666111',' - baseline patch for PAY, GHR');				
          end if;    
		  
         
              l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Please review ');
              l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1199724.1" target="_blank">Note 1199724.1</a> ');
			  l_o('- E-Business Suite 11.5.10 Minimum Patch Level and Extended Support Information Center</span><br>');
          
		elsif :apps_rel like '12.0%' then
			  dpatch('not','7004477','R12.HR_PF.A.delta.6 (Minimum baseline)');
			  dpatch('not','9301208','R12.HR_PF.A.delta.8 (Minimum baseline for those customers whose legislation tax year end / tax year begin schedule must be applied as a prerequisite before processing the legislative Year End (Note 135266.1))');
			 
			  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Please review ');
              l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1334562.1" target="_blank">Note 1334562.1</a> ');
			  l_o('- Minimum Patch Requirements for Extended Support of Oracle E-Business Suite Human Capital Management (HCM) Release 12.0</span><br>');
		end if;
		
	l_o('</td></tr>');
	end if;    
end;


-- Display performance patches advices
procedure performance is
begin
     l_o(' <TR><td><a name="perf"></a>Performance</td><td>');
    l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> For performance patches please periodically review: ');
    l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=244040.1" target="_blank">Note 244040.1</a> - ');
	l_o('Oracle E-Business Suite Recommended Performance Patches</span><br>');

    l_o('<DIV align="center"><A class=detail onclick="displayItem(this,''s1sql45'');" href="javascript:;">&#9654; How to check database patches</A></DIV>');
    l_o(' <TABLE align="center" border="1" cellspacing="0" cellpadding="2" id="s1sql45" style="display:none" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o(' <blockquote><span class="sectionb">-	cd RDBMS_ORACLE_HOME<br>');
    l_o('-	. ./SID_hostname.env<br>');
    l_o('-	export PATH=$ORACLE_HOME/OPatch:$PATH<br>');
    l_o('-	opatch lsinventory<br>');
    l_o('-	Compare results with the patches from ');
	l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=244040.1" target="_blank">Note 244040.1</a> - ');
	l_o('Oracle E-Business Suite Recommended Performance Patches<br>');
	l_o('</span></blockquote>');
    l_o(' </TD><TR></TABLE>'); 
                                  
    
   l_o('</td></tr>');   
  
  l_o(' </TABLE> <br> ');
  
 if issuep then
		l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning:</span> Please review patching section as you have warning(s) reported.</div>');
  end if; 
  
  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

end;

-- Second main program (split because "program too long" error)
begin  -- begin1

  begin -- begin MAIN
	:g_curr_loc:=1;
	DBMS_LOB.CREATETEMPORARY(:g_hold_output2,TRUE,DBMS_LOB.SESSION);
        l_o('<BR>'); 	
	
	javacl();
	forms_version();
	reports_version();
	c_version();
	l_o('</div>');
	l_o('<br><br><a name="settings"></a><a name="profiles"><div class="divSection">');
	l_o('<div class="divSectionTitle">Settings</div><br>');
	profiles();
	profiles2();
	security();
	international();
	pay_trigger();
	pay_action();
	l_o('</div>');
	
	l_o('<br><br><a name="rup"></a><a name="patching"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">Patching</div>');	
	rup();
	hrglobal();
	DataInstalled();
	Statutory();
	atg();
	baseline();	
	performance();
	l_o('</div>');
	
	l_o('<!-');	
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');

end;
end;
/

-- Print output
print :g_hold_output2


variable g_hold_output3 clob;
declare
   counter      number       := 0;
   failures     number       := 0;
   issuep boolean := FALSE;
   g_sql_date_format   varchar2(100) := 'DD-MON-YYYY HH24:MI';

   g_user_id      number;
   g_resp_id      number;
   g_appl_id      number;
   g_org_id       number;
   g_appl_version varchar2(10);

   type V2T is table of varchar2(32767);
   

-- Write html format
procedure l_o (text varchar2) is
   l_ptext      varchar2(32767);
   l_hold_num   number;
   l_ptext2      varchar2(32767);
   l_hold_num2   number;
begin
   l_hold_num := mod(:g_curr_loc, 32767);
   
   l_hold_num2 := mod(:g_curr_loc, 14336);
   if l_hold_num2 + length(text) > 14000 then
      l_ptext2 := '                                                                                                                                                                                               ';
      dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	   dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  
   end if;
   
   l_hold_num2 := mod(:g_curr_loc, 18204);
   if l_hold_num2 + length(text) > 17900 then
      l_ptext2 := '                                                                                                                                                                                              ';
      dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	 
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
		dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	  
   end if;
   
   if l_hold_num + length(text) > 32759 then
      l_ptext := '<!--' || rpad('*', 32761-l_hold_num,'*') || '-->';
      dbms_lob.write(:g_hold_output3, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output3, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output3, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output3, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
   end if;
   dbms_lob.write(:g_hold_output3, length(text)+1, :g_curr_loc, text || chr(10));
   :g_curr_loc := :g_curr_loc + length(text)+1;
 
end l_o;

-- Display Setup for PDF Reports
procedure pdf_reports (v_leg varchar2) is
	v_database_id varchar2(100);
	v_output fnd_concurrent_programs.OUTPUT_FILE_TYPE%type;
	v_rows number;
	v_patch number;
	v number;
	status_leg varchar2(2);
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue8 boolean := FALSE;
	v_variable FND_ENV_CONTEXT.VARIABLE_NAME%type;
	v_value FND_ENV_CONTEXT.VALUE%type;
	cursor c_env is select VARIABLE_NAME , nvl(VALUE,'null') 
			from FND_ENV_CONTEXT
			where CONCURRENT_PROCESS_ID in
				  (select max(CONCURRENT_PROCESS_ID) from FND_CONCURRENT_PROCESSES
				   where CONCURRENT_QUEUE_ID in (select CONCURRENT_QUEUE_ID from FND_CONCURRENT_QUEUES where CONCURRENT_QUEUE_NAME = 'WFMLRSVC')
					 and QUEUE_APPLICATION_ID in (select APPLICATION_ID from FND_APPLICATION where APPLICATION_SHORT_NAME = 'FND'))
			  and VARIABLE_NAME in ('APPL_TOP', 'AF_JRE_TOP', 'FND_SECURE', 'APPLPTMP', 'PY_LIB_PATH', 'PY_PRELOAD')
			order by VARIABLE_NAME;
begin
	
	l_o('<br><div class="divSection"><div class="divSectionTitle">Setup for PDF Reports</div><br>');			
	
	case v_leg
		when 'US' then
			v:=1;
		when 'CA' then
			v:=2;
		when 'MX' then
			v:=3;
		else
			null;
	end case;
	
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2">');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Variable Settings</B></font></TD>');
	l_o('   </TR><TR><TH><B>Variable</B></TD><TH><B>Value</B></TD>');
	:n := dbms_utility.get_time;	
	open c_env;
    loop
          fetch c_env into v_variable,v_value;
          EXIT WHEN  c_env%NOTFOUND;
          l_o('<TR><TD>'||v_variable||'</TD>'||chr(10)||'<TD>');
			l_o(v_value);
			l_o('</TD></TR>'||chr(10));         
    end loop;
    close c_env;
	
	:n := (dbms_utility.get_time - :n)/100;
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR></TABLE><br> ');


	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2">');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('     <B>Concurrent Programs</B></font></TD><TD bordercolor="#DEE6EF">');
		l_o('<A class=detail id="s1sql6'||v||'b" style="width:220px" onclick="displayItem2(this,''s1sql6'||v||''');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD></TR><TR id="s1sql6'||v||'" style="display:none">');
		l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         select CONCURRENT_PROGRAM_NAME, OUTPUT_FILE_TYPE from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) in ( <br>');
		case v_leg
		when 'US' then
			l_o('''PAYARCHCHQW'',''PYCADEPADVXML'', ''PYUSDEPADVXML'',''PAYUSW2PDF'', ''PYUS941T'',''EMP_1099R_PDF''');
		when 'CA' then
			l_o('''PYXMLRL1'',''PYCARL2PXML'',''PAYCAT4PDF'',''PAYCAT4APDF''');
		when 'MX' then
			l_o('''PAYMXDD''');
		else
			null;
		end case;
		l_o(')</blockquote><br></TD></TR><TR>');
		l_o(' <TH><B>Program Name</B></TD><TH><B>Program Code</B></TD><TH><B>Output Type</B></TD>');
	
		:n := dbms_utility.get_time;
		
		if :apps_rel like '12.2%' then
			v_patch:=1;
		elsif (:apps_rel like '12.1%') or (:apps_rel like '12.0%') then
			select count(1) into v_patch from ad_bugs where bug_number='15832452';
		elsif :apps_rel like '11.5%' then
			select count(1) into v_patch from ad_bugs where bug_number='16090736';
		end if;

		case v_leg
		when 'US' then
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYARCHCHQW';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYARCHCHQW' and rownum < 2;
			l_o('<TR><TD>Checkwriter (XML)</TD><TD>PAYARCHCHQW</TD>'||chr(10)||'<TD>');
			if v_patch=0 then
				if upper(v_output)<>'TEXT' then
					l_o('<font color="red">'||v_output||'</font>');
					issue1:=TRUE;
				else
					l_o(v_output);
				end if;
			else
				if upper(v_output)<>'XML' then
					l_o('<font color="red">'||v_output||'</font>');
					issue1:=TRUE;
				else
					l_o(v_output);
				end if;
			end if;			
			l_o('</TD></TR>'||chr(10));
			end if;
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUSDEPADVXML';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) ='PYUSDEPADVXML' and rownum < 2;
			l_o('<TR><TD>Deposit Advice (XML)</TD><TD>PYUSDEPADVXML</TD>'||chr(10)||'<TD>');
			if v_patch=0 then
				if upper(v_output)<>'TEXT' then
					l_o('<font color="red">'||v_output||'</font>');
					issue2:=TRUE;
				else
					l_o(v_output);
				end if;
			else
				if upper(v_output)<>'XML' then
					l_o('<font color="red">'||v_output||'</font>');
					issue2:=TRUE;
				else
					l_o(v_output);
				end if;
			end if;	
			l_o('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYUSW2PDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYUSW2PDF' and rownum < 2;
			l_o('<TR><TD>Employee W-2 PDF</TD><TD>PAYUSW2PDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue3:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUS941T';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUS941T' and rownum < 2;
			l_o('<TR><TD>Quarterly Tax Return Worksheet (Form 941 - PDF)</TD><TD>PYUS941T</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue4:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='EMP_1099R_PDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='EMP_1099R_PDF' and rownum < 2;
			l_o('<TR><TD>1099R Information Return - PDF</TD><TD>EMP_1099R_PDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'TEXT' then
				l_o('<font color="red">'||v_output||'</font>');
				issue5:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;
		when 'CA' then
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYXMLRL1';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYXMLRL1' and rownum < 2;
			l_o('<TR><TD>RL1 PDF</TD><TD>PYXMLRL1</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'HTML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue1:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYCARL2PXML';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYCARL2PXML' and rownum < 2;
			l_o('<TR><TD>RL2 PDF</TD><TD>PYCARL2PXML</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'HTML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue2:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;
	
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAT4PDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAT4PDF' and rownum < 2;
			l_o('<TR><TD>T4 PDF</TD><TD>PAYCAT4PDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'PDF' then
				l_o('<font color="red">'||v_output||'</font>');
				issue3:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAT4APDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAT4APDF' and rownum < 2;
			l_o('<TR><TD>T4a PDF</TD><TD>PAYCAT4APDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'HTML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue4:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAARCHCHQW';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAARCHCHQW' and rownum < 2;
			l_o('<TR><TD>Canadian Cheque Writer (XML)</TD><TD>PAYCAARCHCHQW</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
					l_o('<font color="red">'||v_output||'</font>');
					issue5:=TRUE;
				else
					l_o(v_output);				
			end if;	
			l_o('</TD></TR>'||chr(10));
			end if;
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYCADEPADVXML';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) ='PYCADEPADVXML' and rownum < 2;
			l_o('<TR><TD>Canadian Deposit Advice (XML)</TD><TD>PYCADEPADVXML</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
					l_o('<font color="red">'||v_output||'</font>');
					issue6:=TRUE;
				else
					l_o(v_output);				
			end if;	
			l_o('</TD></TR>'||chr(10));
			end if;
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCATPCHQW';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCATPCHQW' and rownum < 2;
			l_o('<TR><TD>Canadian Third Party Cheque Writer (XML)</TD><TD>PAYCATPCHQW</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
					l_o('<font color="red">'||v_output||'</font>');
					issue7:=TRUE;
				else
					l_o(v_output);				
			end if;	
			l_o('</TD></TR>'||chr(10));
			end if;
			
		when 'MX' then
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDD';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDD' and rownum < 2;
			l_o('<TR><TD>Direct Deposit (Mexico)</TD><TD>PAYMXDD</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue1:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_SS_AFFL';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_SS_AFFL' and rownum < 2;
			l_o('<TR><TD>Social Security Affiliation Report</TD><TD>MX_SS_AFFL</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue2:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXXMLPSLP';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXXMLPSLP' and rownum < 2;
			l_o('<TR><TD>CFDI Payroll Payslip XML Extract</TD><TD>PYMXXMLPSLP</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue3:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_ISR_FORMAT37';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_ISR_FORMAT37' and rownum < 2;
			l_o('<TR><TD>ISR Tax Format 37 (XML)</TD><TD>MX_ISR_FORMAT37</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue4:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDIMMAG';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDIMMAG' and rownum < 2;
			l_o('<TR><TD>Information Declaration Report (DIM)</TD><TD>PAYMXDIMMAG</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue5:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXTRR';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXTRR' and rownum < 2;
			l_o('<TR><TD>Payroll Tax Remittance Report</TD><TD>PYMXTRR</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				l_o('<font color="red">'||v_output||'</font>');
				issue6:=TRUE;
			else
				l_o(v_output);
			end if;
			l_o('</TD></TR>'||chr(10));
			end if;		
		else
			null;
		end case;
		
		
		:n := (dbms_utility.get_time - :n)/100;
		
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR></TABLE> ');
		
		case v_leg
		when 'US' then
			if issue1 or issue2 or issue3 or issue4 or issue5 then
				l_o('<div class="divwarn">If you are using PDF Reports:<br>');
				if issue1 then
					:w30:=:w30+1;
					if v_patch=0 then
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Checkwriter (XML) should be set to Text<br> ');						
					else
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Checkwriter (XML) should be set to XML<br> ');						
					end if;
				end if;
				if issue2 then
					:w30:=:w30+1;
					if v_patch=0 then
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Deposit Advice (XML) should be set to Text<br> ');						
					else
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Deposit Advice (XML) should be set to XML<br> ');
					end if;
				end if;
				if issue3 then
					:w30:=:w30+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Employee W-2 PDF should be set to XML<br> ');
				end if;
				if issue4 then
					:w30:=:w30+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Quarterly Tax Return Worksheet (Form 941 - PDF) should be set to XML<br> ');
				end if;
				if issue5 then
					:w30:=:w30+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of 1099R Information Return - PDF should be set to Text<br> ');
				end if;
				
				l_o('</div>');
			end if;
		when 'CA' then
			if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 then
				l_o('<div class="divwarn">If you are using PDF Reports:<br>');
				if issue1 then
					:w4:=:w4+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of RL1 PDF should be set to HTML<br> ');
				end if;
				if issue2 then
					:w4:=:w4+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of RL2 PDF should be set to HTML<br> ');
				end if;
				if issue3 then
					:w4:=:w4+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of T4 PDF should be set to PDF<br> ');
				end if;
				if issue4 then
					:w4:=:w4+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of T4a PDF should be set to HTML<br> ');
				end if;
				if issue5 then
					:w4:=:w4+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Canadian Cheque Writer (XML) should be set to XML<br> ');
					
				end if;
				if issue6 then
					:w4:=:w4+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Canadian Deposit Advice (XML) should be set to XML<br> ');
					
				end if;
				if issue7 then
					:w4:=:w4+1;
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Canadian Third Party Cheque Writer (XML) should be set to XML<br> ');
					
				end if;	
				l_o('</div>');
			end if;
		when 'MX' then
			if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 then
				l_o('<div class="divwarn">If you are using PDF Reports:<br>');
				if issue1 then					
						:w19:=:w19+1;
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Direct Deposit (Mexico) should be set to XML<br> ');					
				end if;
				if issue2 then
						:w19:=:w19+1;
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Social Security Affiliation Report should be set to XML<br> ');
				end if;
				if issue3 then
						:w19:=:w19+1;
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of CFDI Payroll Payslip XML Extract should be set to XML<br> ');
				end if;
				if issue4 then
						:w19:=:w19+1;
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of ISR Tax Format 37 (XML) should be set to XML<br> ');
				end if;
				if issue5 then
						:w19:=:w19+1;
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Information Declaration Report (DIM) should be set to XML<br> ');
				end if;
				if issue6 then
						:w19:=:w19+1;
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Output of Payroll Tax Remittance Report should be set to XML<br> ');
				end if;
				l_o('</div>');
			end if;
		else
			null;
		end case;
	
		if :apps_rel like '12.1%' then
			select count(1) into v_rows from ad_bugs where bug_number in ('10281212','12599994');
			if v_rows=0 then
				issue8:=TRUE;
			end if;
		end if;
		
		if (:apps_rel not like '12.1%') or issue8 then
			select fnd_web_config.database_id into v_database_id from dual;
			select count(1) into v_rows from pay_action_parameters where upper(PARAMETER_NAME)='DBC_FILE' and upper(PARAMETER_VALUE) like upper('%'||v_database_id||'.dbc');
			if v_rows=0 then
				issue8:=TRUE;
			end if;
		end if;
		if issue8 then
					:w4:=:w4+1;
					:w19:=:w19+1;
					:w30:=:w30+1;
					l_o('<div class="divwarn">If you are using PDF Reports:<br>');
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You have DBC_FILE incorect in pay_action_parameters table. '); 
					l_o('This should be set to <your path>'||v_database_id||'.dbc<br> ');
					l_o('</div>');
		end if;

		if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 then
		l_o('<div class="divwarn"><span class="sectionblue1">Advice:</span> Please review:<br> ');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=562882.1" target="_blank">Note 562882.1</a> Oracle Human Resources (HRMS) Setup For US, CA and MX Legislations Payroll PDF Reports<br>');
		l_o('</div>');
		else
				l_o('<div class="divok">Verified parameters are correctly set<br></div>');
		end if;		
		l_o('</div> <br>');


EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;



-- Display geocode patching level
procedure geocode(v_leg varchar2) is
 
  v_exists number:=0;
  v_patch_date ad_bugs.LAST_UPDATE_DATE%type;
  v_status varchar2(100);
  v_last_date date;
  v_geocode_date date;
  patch varchar2(20);
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin
        
                if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
                      SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='21276246' ;
                      patch:='21276246';
                elsif :apps_rel like '12.0%' then
					select count(1) into v_exists from ad_bugs where bug_number='19139617';
                      patch:='19139617';
				elsif :apps_rel like '11.5%' then
                      select count(1) into v_exists from ad_bugs where bug_number='21276241';
                      patch:='21276241';
                end if;
                
                if (v_exists=0) then             
                         issue1:=TRUE;
                else
                          select LAST_UPDATE_DATE  
                          into v_patch_date
                          FROM ad_bugs 
                          where bug_number=patch and rownum < 2;
                          
                          select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%';
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),upper('Completed Normal'))=0 then								 
                                      issue3:=TRUE;
                                  else
                                         if v_last_date<v_patch_date then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
							
							
							SELECT count(1) into v_exists
							FROM pay_patch_status
							WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
							AND status        = 'C';
							
							if v_exists=0 then
								issue5:=TRUE;
							else
								SELECT max(applied_date) into v_geocode_date
								FROM pay_patch_status
								WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
								AND status        = 'C';
							end if;
              end if;                             
            l_o('<div class="divSection"><div class="divSectionTitle">Geocode</div><br>');  
            
                        if issue1 then
                                if v_leg='CA' then
									:w4:=:w4+1;
								else								
									:w30:=:w30+1;
								end if;
								if (:pay_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										elsif :apps_rel like '12.0%' then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ANNUAL GEOCODE UPDATE - 2014<br>');
										elsif :apps_rel like '11.5%' then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										end if;	
										l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span><span class="sectionb">Ensure you perform Geocode Upgrade Manager process after the patch.</span></div>');
								elsif (:pay_status='Shared') and (:hr_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ANNUAL GEOCODE UPDATE - 2015</div><br>');
										elsif :apps_rel like '12.0%' then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ');
											l_o('ANNUAL GEOCODE UPDATE - 2014</div><br>');
										elsif :apps_rel like '11.5%' then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015</div><br>');
										end if;
										l_o('<div class="divwarn">');
										l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records ensure you perform Geocode Upgrade Manager process after the patch.<br>');
										l_o('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=745638.1" target="_blank">Note 745638.1</a> ');
										l_o('Requirements for Address Validation with HR Only Installation</div><br>');
								end if;									
                        else
							l_o('<span class="sectionb">Patch '||patch||' Oracle US and Canada Payroll Annual Geocode applied on '||v_patch_date||'</span><br>');
                        end if;
                        
                        if issue2 then
                            if v_leg='CA' then
									:w4:=:w4+1;
								else								
									:w30:=:w30+1;
								end if;
							if (:pay_status='Installed') then
								l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>You never performed Geocode Upgrade Manager process!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records be aware you never performed Geocode Upgrade Manager process!</div><br>');
							end if;
                        end if;
                        
                        if issue3 then
                            if v_leg='CA' then
									:w4:=:w4+1;
								else								
									:w30:=:w30+1;
								end if;
							if (:pay_status='Installed') then
								l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Your last run of Geocode Upgrade Manager process is not Completed Normal. Please review!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');								
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records be aware your last run of Geocode Upgrade Manager process completed in error. Please review!</div><br>');
							end if;
                        end if;
                        if issue4 then
                            if v_leg='CA' then
									:w4:=:w4+1;
								else								
									:w30:=:w30+1;
								end if;
							if (:pay_status='Installed') then
								l_o('<span class="sectionb">Geocode Upgrade Manager process Completed Normal on '||v_last_date||'</span><br>');
								l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>You did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								l_o('<span class="sectionb">Geocode Upgrade Manager process Completed Normal on '||v_last_date||'</span><br>');
								l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records be aware you did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							end if;
                        end if;
                        
						if (:apps_rel not like '12.0%') then 
						if issue5  then
                            if v_leg='CA' then
									:w4:=:w4+1;
								else								
									:w30:=:w30+1;
								end if;
							if (:pay_status='Installed') then								
								l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>GEOCODE_ANNUAL_2015 information not applied!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then								
								l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records be aware GEOCODE_ANNUAL_2015 information are not applied!</div><br>');
							end if;
                        elsif not issue1 then
							l_o('<span class="sectionb">GEOCODE_ANNUAL_2015 information applied on '||v_geocode_date||'</span><br>');
                        end if;
						end if;
						
						if not issue1 and not issue2 and not issue3 and not issue4 then
							l_o('<span class="sectionb">Geocode Upgrade Manager process Completed Normal on '||v_last_date||'</span><br>');
						end if;
						
                        if issue1 or issue2 or issue3 or issue4 or (issue5 and :apps_rel not like '12.0%') then
                                issuep:=TRUE;
								l_o('<div class="divwarn">');
								if :apps_rel like '12.2%' then
                                    l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038283.1" target="_blank">Note 2038283.1</a> ');
                                    l_o('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.2.x');
								elsif :apps_rel like '12.1%' then
                                    l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038282.1" target="_blank">Note 2038282.1</a> ');
                                    l_o('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.1.x');
                                elsif :apps_rel like '12.0%' then
                                    l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1912683.1" target="_blank">Note 1912683.1</a> ');
                                    l_o('Oracle US and Canada Payroll - 2014 Annual Geocode Readme - Release 12.0.x');
                                else
                                    l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038281.1" target="_blank">Note 2038281.1</a> ');
                                    l_o('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 11i');
                                end if;
                                l_o('</div>');         
						else
                                l_o('<span class="sectionb"><img class="check_ico">OK! All checks are OK!</span><br>');                               
                        end if;						
            l_o('</div>');            
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');      
end;


-- Display Quantum level
procedure Quantum(v_leg varchar2) is
  v_exists number:=0;
  v_status varchar2(100);
  v_last_date date;
  patch varchar2(20);
  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type;	
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin

                select count(1) into v_exists
                from ad_applied_patches ap
                   , ad_patch_drivers pd
                   , ad_patch_runs pr
                   , ad_patch_run_bugs prb
                   , ad_patch_run_bug_actions prba
                   , ad_files f
                where f.file_id                  = prba.file_id
                  and prba.executed_flag         = 'Y'
                  and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                  and prb.patch_run_id           = pr.patch_run_id
                  and pr.patch_driver_id         = pd.patch_driver_id
                  and pd.applied_patch_id        = ap.applied_patch_id
                  and f.filename = 'pyvendor.zip'
                  and pr.end_date = (select max(pr.end_date)
                                             from ad_applied_patches ap
                                                , ad_patch_drivers pd
                                                , ad_patch_runs pr
                                                , ad_patch_run_bugs prb
                                                , ad_patch_run_bug_actions prba
                                                , ad_files f
                                              where f.file_id                  = prba.file_id
                                                and prba.executed_flag         = 'Y'
                                                and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                and prb.patch_run_id           = pr.patch_run_id
                                                and pr.patch_driver_id         = pd.patch_driver_id
                                                and pd.applied_patch_id        = ap.applied_patch_id
                                                and f.filename = 'pyvendor.zip');      

                
               if (v_exists=0) then             
                         issue1:=TRUE;
                else
                           if :apps_rel like '12.%' then
								SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='19701971' ;
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701971' and rownum < 2;
								end if;						 
						   elsif :apps_rel like '11.5%'	then
								select count(1) into v_exists from ad_bugs where bug_number='19701970';
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701970' and rownum < 2;
								end if;
						   end if;						
						   select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
							, FND_LOOKUP_VALUES STAT
							, FND_LOOKUP_VALUES PHAS 
							WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
							AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
							AND PT.LANGUAGE = 'US' and
							STAT.LOOKUP_CODE = R.STATUS_CODE
										AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
										AND PHAS.LOOKUP_CODE = R.PHASE_CODE
										AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
										AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%' ;
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),'ERROR')<>0 then 
                                      issue3:=TRUE;
                                  else
                                         if SYSDATE-v_last_date>30 then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
              end if;
              
               
            l_o('<br><div class="divSection"><div class="divSectionTitle">Quantum</div><br>');
                        if issue1 or issue2 or issue3 or issue4 or issue5 then
								l_o('<div class="diverr">');
								if issue5 then
										  l_o('<img class="error_ico"><font color="red">Error: </font>You don''t have the patch delivering latest Quantum version 4.0.<br>');
										  l_o('Please install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=');
										  if :apps_rel like '12.%'  then
											l_o('19701971">Patch 19701971</a><br>');										 
										  elsif :apps_rel like '11.5%' then
										     l_o('19701970">Patch 19701970</a><br>');
										  end if;
										  if v_leg='CA' then
												:e4:=:e4+1;
											else								
												:e30:=:e30+1;
											end if;
								end if;
								if issue1 then
										  if v_leg='CA' then
												:e4:=:e4+1;
											else								
												:e30:=:e30+1;
											end if;
											l_o('<img class="error_ico"><font color="red">Error: </font>No Quantum patch applied<br>');
										  l_o('Ensure you also perform Quantum Data Update Installer.<br>');
								end if;
								
								if issue2 then
										  l_o('<img class="error_ico"><font color="red">Error: </font>You never performed Quantum Data Update Installer ! <br>');
										    if v_leg='CA' then
												:e4:=:e4+1;
											else								
												:e30:=:e30+1;
											end if;
								end if;
								
								if issue3 then
										  l_o('<img class="error_ico"><font color="red">Error: </font>Your last run of Quantum Data Update Installer process completed in error. <br>');
										  if v_leg='CA' then
												:e4:=:e4+1;
											else								
												:e30:=:e30+1;
											end if;
								end if;
								if issue4 then
										  l_o('Your last run of Quantum Data Update Installer was on ');
										  l_o(v_last_date||' more than 30 days ago. <br>');
										                                
										 if v_leg='CA' then
												:e4:=:e4+1;
											else								
												:e30:=:e30+1;
											end if;
								end if;
                                               
                                issuep:=TRUE;
								l_o('Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this error. Please verify with System Administrator.<br>');
								l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                                l_o('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations<br>');
								l_o('</div>');
                                                      
                        end if;
                        l_o('<span class="sectionb">');
						if not issue1 and not issue5 then
							if :apps_rel like '12.%' then
								l_o('Patch 19701971 applied on '||v_patch_date||'<br>');
							elsif :apps_rel like '11.5%' then
								l_o('Patch 19701970 applied on '||v_patch_date||'<br>');
							end if;
						end if;
						if not issue1 and not issue2 and not issue3 and not issue4 then
							l_o('Your last run of Quantum Data Update Installer was on '||v_last_date||'<br>');                                                           
                        end if;
						l_o('</span><br>'); 
                        l_o('<span class="sectionblue1">Advice: </span><span class="sectionb">Please periodically review: ');
						l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                        l_o('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations</span><br>');
						
			l_o('</div>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


 -- Display patch
procedure dpatch (v_leg varchar2, v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;	  
	  v_exists number;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								 case v_leg
									when  'AU' then
										:e2:=:e2+1;
									when 'BE' then 
										:e3:=:e3+1;
									when 'CA' then 	
										:e4:=:e4+1;
									when 'CN' then 
										:e5:=:e5+1;
									when 'ES' then
										:e6:=:e6+1;
									when 'DE' then 
										:e7:=:e7+1;
									when 'DK' then
										:e8:=:e8+1;
									when 'FI' then 
										:e9:=:e9+1;
									when 'FR' then 
										:e10:=:e10+1;
									when 'HK' then 	
										:e11:=:e11+1;
									when 'HU' then 
										:e12:=:e12+1;
									when 'IE' then 
										:e13:=:e13+1;
									when 'IN' then 
										:e14:=:e14+1;
									when 'IT' then 
										:e15:=:e15+1;
									when 'JP' then
										:e16:=:e16+1;
									when 'KR' then
										:e17:=:e17+1;
									when 'KW' then
										:e18:=:e18+1;
									when 'MX' then 
										:e19:=:e19+1;
									when 'NL' then 
										:e20:=:e20+1;
									when 'NO' then 
										:e21:=:e21+1;
									when 'NZ' then
										:e22:=:e22+1;
									when 'PL' then 
										:e23:=:e23+1;
									when 'RU' then
										:e24:=:e24+1;
									when 'SA' then 
										:e25:=:e25+1;									
									when 'SE' then 
										:e26:=:e26+1;
									when 'SG' then
										:e27:=:e27+1;
									when 'AE' then 	
										:e28:=:e28+1;
									when 'GB' then 
										:e29:=:e29+1;
									when 'US' then
										:e30:=:e30+1;
									when 'ZA' then
										:e31:=:e31+1;
									else
									null;
								end case;
								 issuep:=TRUE;
								 l_o('<div class="diverr"><img class="error_ico"><font color="red">Error: </font>Please plan to install ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');	
								 l_o('</div>');
							else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							l_o('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
						EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end; 
	
	
-- Display JIT patching
procedure jit(v_leg varchar2) is
  v_exists number:=0;
  v_status varchar2(100);
  v_last_date date;
  patch varchar2(20);
  v_month varchar2(4);
  v_year varchar2(4);
  v_quarter varchar2(4);
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  v_patch varchar2(20);
  v_patch_name varchar2(50);
  v_date date;
  
begin
     l_o('<br><div class="divSection">' );
	 l_o('<div class="divSectionTitle">JIT</div><br>');	 
        if (:apps_rel like '12.2%') then
							dpatch('US','21142484','Q2 2015 Statutory and JIT Update');
						elsif (:apps_rel like '12.1%') then
							dpatch('US','21142484','Q2 2015 Statutory and JIT Update');
						elsif (:apps_rel like '12.0%') then		
							dpatch('US','19507770','Q3 2014 Statutory and JIT Update');
						elsif :apps_rel like '11.5%' then					
							dpatch('US','21142464','Q2 2015 Statutory and JIT Update'); 
				end if;      
            
              
    l_o('</div>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;



procedure documents (v_no1 varchar2, v_note1 varchar2, v_no2 varchar2, v_note2 varchar2) is
begin
			l_o('<br><div class="divok">Useful documentation:<br><a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');			
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no2||'" target="_blank">Note '||v_no2||'</a> '||v_note2||'<br></div>');
end;
procedure documents (v_no1 varchar2, v_note1 varchar2) is
begin
			l_o('<br><div class="divok">Useful documentation:<br>');
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br></div>');
end;

procedure datainstall (v_leg varchar2, v_no number) is
	v_exists number;
    v_apps hr_legislation_installations.application_short_name%type;
    v_action varchar2(20);
	v_date hr_legislation_installations.last_update_date%type; v_legislation hr_legislation_installations.legislation_code%type;	
    cursor di_actions is
        select 
		   legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION,   
		   decode(action,'F','Force Install'
						 ,'C','Clear'
						 ,'U','Upgrade'
						 ,'I','Install') ACTION,
		   last_update_date
		from hr_legislation_installations
		where (status is not null or action is not null)
		and legislation_code = v_leg;
	cursor rules is
		select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules
		where legislation_code = v_leg
		order by legislation_code;
	V_RULE_TYPE pay_legislation_rules.RULE_TYPE%type;
	V_RULE_MODE pay_legislation_rules.RULE_MODE%type;
begin
	l_o('<div class="divSection">' );
	l_o('<div class="divSectionTitle">Data install status</div><br>');			
	
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>DataInstaller actions:</B></font></TD><TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql200'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD></TR><TR id="s1sql200'||v_no||'" style="display:none">');
    l_o('    <TD BGCOLOR=#DEE6EF colspan="3" height="60"><blockquote><p align="left">');
    l_o('          select legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION, <br>');
    l_o('          decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'') ACTION,<br>');
    l_o('           last_update_date <br>from hr_legislation_installations <br>where (status is not null or action is not null)<br>');                  
    l_o('            and legislation_code = '''||v_leg||''';<br>');
    l_o('          </blockquote><br></TD></TR><TR>');
    l_o(' <TH><B>Legislation</B></TD><TH><B>Application Name</B></TD>');
    l_o(' <TH><B>Action</B></TD><TH><B>Last Update Date</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open di_actions;
        loop
            fetch di_actions into  v_legislation , v_apps, v_action, v_date;
            EXIT WHEN  di_actions%NOTFOUND;
            l_o('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD></TR>'||chr(10));
        end loop;
    close di_actions;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> <br> ');
	l_o('</div>');
	
	l_o('<br><div class="divSection"><div class="divSectionTitle">Settings</div><br><DIV class=divItem>');
	l_o('<DIV id="s1sql300'||v_no||'b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql300'||v_no||''');" href="javascript:;">&#9654; Pay Legislation Rules</A></DIV>');			
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql300'||v_no||'" style="display:none" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Pay Legislation Rules:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql301'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD></TR><TR id="s1sql301'||v_no||'" style="display:none">');
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
    l_o('        select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules  <br>');   
    l_o('        order by LEGISLATION_CODE;<br>');   
    l_o('           where legislation_code ='''||v_leg||''';<br>');
    l_o('          </blockquote><br></TD></TR><TR>');    
	l_o(' <TH><B>Legislation</B></TD><TH><B>Rule Type</B></TD>');
	l_o(' <TH><B>Rule Mode</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open rules;
        loop
            fetch rules into v_legislation, v_rule_type, v_rule_mode;
            EXIT WHEN  rules%NOTFOUND;
            l_o('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_rule_type||'</TD>'||chr(10)||'<TD>'||v_rule_mode||'</TD></TR>'||chr(10));
        end loop;
    close rules;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR></TABLE> ');
	l_o('</div>');
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure profit_sharing (v_leg varchar2, v_no number) is
	v_legal_emp pay_user_rows_f.row_low_range_or_name%type;
	v_user_name pay_user_columns.user_column_name%type;
	v_esd pay_user_column_instances_f.effective_start_date%type;
	v_eed pay_user_column_instances_f.effective_start_date%type;
	v_value pay_user_column_instances_f.value%type;
    cursor c_profit is
        select pur.row_low_range_or_name Legal_Employer_Name
			,puc.user_column_name
			,puci.effective_start_date
			,puci.effective_end_date
			,puci.value
			from pay_user_tables put
			,pay_user_columns puc
			,pay_user_rows_f pur
			,pay_user_column_instances_f puci
			where put.legislation_code = 'MX'
			and put.user_table_name = 'PTU Factors'
			and puc.user_table_id = put.user_table_id
			and pur.user_table_id = put.user_table_id
			and puci.user_column_id = puc.user_column_id
			and puci.user_row_id = pur.user_row_id
			ORDER BY pur.row_low_range_or_name
			,puc.user_column_id
			,puci.effective_start_date; 

begin
			
	l_o('<br><DIV class=divItem>');
	l_o('<DIV id="s1sql302'||v_no||'b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql302'||v_no||''');" href="javascript:;">&#9654; Profit Sharing PTU Factor</A></DIV>');		
			
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql302'||v_no||'" style="display:none" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Profit Sharing PTU Factor:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql303'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD></TR>');
    l_o(' <TR id="s1sql303'||v_no||'" style="display:none">');
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
	l_o('        select pur.row_low_range_or_name Legal_Employer_Name<br>,puc.user_column_name<br>');
	l_o('        		,puci.effective_start_date<br>,puci.effective_end_date<br>,puci.value<br>from pay_user_tables put<br>,pay_user_columns puc<br>');
	l_o('        		,pay_user_rows_f pur<br>,pay_user_column_instances_f puci<br>where put.legislation_code = ''MX''<br>and put.user_table_name = ''PTU Factors''<br>');
	l_o('        		and puc.user_table_id = put.user_table_id<br>and pur.user_table_id = put.user_table_id<br>and puci.user_column_id = puc.user_column_id<br>');
	l_o('        		and puci.user_row_id = pur.user_row_id<br>ORDER BY pur.row_low_range_or_name<br>,puc.user_column_id<br>,puci.effective_start_date;<br>');
    l_o('          </blockquote><br>');
    l_o('     </TD></TR><TR>');    
	l_o(' <TH><B>Legal Employer Name</B></TD><TH><B>User Column Name</B></TD>');
	l_o(' <TH><B>Effective Start Date</B></TD><TH><B>Effective End Date</B></TD>');
	l_o(' <TH><B>Value</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open c_profit;
        loop
            fetch c_profit into v_legal_emp,v_user_name,v_esd,v_eed,v_value;
            EXIT WHEN  c_profit%NOTFOUND;
            l_o('<TR><TD>'||v_legal_emp||'</TD>'||chr(10)||'<TD>'||v_user_name||'</TD>'||chr(10)||'<TD>'||v_esd||'</TD>'||chr(10));
			l_o('<TD>'||v_eed||'</TD>'||chr(10)||'<TD>'||v_value||'</TD></TR>'||chr(10));
        end loop;
    close c_profit;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR></TABLE> ');
	l_o('</div>');
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure bg_generic (v_leg varchar2, v_no number) is
	  v_bg hr_all_organization_units.organization_id%type;
	  v_name HR_ALL_ORGANIZATION_UNITS.NAME%type;	  
	  v_cur PER_BUSINESS_GROUPS.CURRENCY_CODE%type;
	  v_enabled PER_BUSINESS_GROUPS.ENABLED_FLAG%type;
	  v_date_from varchar2(15);
	  v_date_to varchar2(15);
	  v_hr varchar2(3);
	cursor c_bg (v_legislation varchar2)  is
			SELECT otl.name,o.organization_id,o3.ORG_INFORMATION10 currency_code,o4.ORG_INFORMATION2 enabled_flag ,to_char(o.date_from, 'DD-MON-YYYY') ,to_char(o.date_to, 'DD-MON-YYYY')
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			and o3.ORG_INFORMATION9=v_legislation
			order by o.organization_id;
	v_short_name hr_organization_information.org_information1%type;			
			v_employee_number_generation fnd_lookups.meaning%type;
			v_applicant_number_generation fnd_lookups.meaning%type;
			v_contingent_worker_numb_gen fnd_lookups.meaning%type;
			v_grade_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_group_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_job_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_costing_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_position_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_competence_flex fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_currency hr_organization_information.org_information1%type;
			v_fiscal_year_start hr_organization_information.org_information1%type;
			v_minimum_working_age hr_organization_information.org_information1%type;
			v_maximum_working_age hr_organization_information.org_information1%type;
					
	
	v_lookup1 fnd_lookups.meaning%type;
	v_lookup2 fnd_lookups.meaning%type;
	v_lookup3 fnd_lookups.meaning%type;
	v_lookup4 fnd_lookups.meaning%type;	
	v_lookup9 fnd_lookups.meaning%type;
	v_lookup5 fnd_lookups.meaning%type;	
	v_lookup6 fnd_lookups.meaning%type;	
	v_lookup7 fnd_lookups.meaning%type;
	v_lookup8 fnd_lookups.meaning%type;
		
	
	cursor c_payroll (t_bg  NUMBER) is
				SELECT   prl.payroll_name
				,prl.period_type
				,prl.first_period_end_date
				,prl.number_of_years
				,prl.period_reset_years
				,prl.pay_date_offset
				,prl.direct_deposit_date_offset
				,prl.pay_advice_date_offset
				,prl.cut_off_date_offset
				,prl.payslip_view_date_offset
				,nvl (opm.org_payment_method_name, 'No Default Payment Method Set') default_payment_method
				,con.consolidation_set_name consolidation_set
				,prl.workload_shifting_level
				,prl.arrears_flag
				,prl.negative_pay_allowed_flag
				,prl.multi_assignments_flag
				,prl.prl_information1				
				,prl.prl_information21 days_after_period_start
				,prl.prl_information22 days_after_period_end
				,hr_general_utilities.get_lookup_meaning('MODELER_AVAILABLITY',prl.prl_information20)  modeling_availability_rule
				,prl.payroll_id
				,prl.default_payment_method_id default_payment_method_id				
		FROM     pay_all_payrolls_f prl
				,pay_org_payment_methods_f opm
				,pay_consolidation_sets con
				,hr_all_organization_units org				
				,per_time_period_types tpt
				,per_time_period_rules tpr
		WHERE    1 = 1
			 AND con.consolidation_set_id = prl.consolidation_set_id
			 AND opm.org_payment_method_id(+) = prl.default_payment_method_id
			 AND org.organization_id(+) = prl.organization_id			
			 AND tpt.period_type = prl.period_type
			 AND tpr.number_per_fiscal_year = tpt.number_per_fiscal_year
			 AND sysdate BETWEEN prl.effective_start_date AND prl.effective_end_date
			 AND prl.business_group_id = t_bg
			 order by 1;
	v_payroll_name pay_all_payrolls_f.payroll_name%type;
	v_period_type pay_all_payrolls_f.period_type%type;
	v_first_date pay_all_payrolls_f.first_period_end_date%type;
	v_number_of_years pay_all_payrolls_f.number_of_years%type;
	v_period_reset_years pay_all_payrolls_f.period_reset_years%type;
	v_pay_date_offset pay_all_payrolls_f.pay_date_offset%type;
	v_direct_deposit pay_all_payrolls_f.direct_deposit_date_offset%type;
	v_pay_advice_date_offset pay_all_payrolls_f.pay_advice_date_offset%type;
	v_cut_off_date pay_all_payrolls_f.cut_off_date_offset%type;
	v_payslip_view pay_all_payrolls_f.payslip_view_date_offset%type;
	v_default_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_consolidation pay_consolidation_sets.consolidation_set_name%type;
	v_workload_shifting pay_all_payrolls_f.workload_shifting_level%type;
	v_arrears_flag pay_all_payrolls_f.arrears_flag%type;
	v_negative_pay pay_all_payrolls_f.negative_pay_allowed_flag%type;
	v_multi_assignments pay_all_payrolls_f.multi_assignments_flag%type;
	v_legal_employer hr_all_organization_units.name%type;
	v_prl_information21 pay_all_payrolls_f.prl_information21%type;
	v_prl_information22 pay_all_payrolls_f.prl_information22%type;
	v_modeling_availability fnd_lookups.meaning%type;
	
	v_seg2 pay_external_accounts.segment2%type;
	v_seg3 pay_external_accounts.segment3%type;
	v_seg5 pay_external_accounts.segment5%type;
	v_seg6 pay_external_accounts.segment6%type;
	v_seg7 pay_external_accounts.segment7%type;
	v_seg10 pay_external_accounts.segment10%type;
	
	cursor c_org_pay (t_id  NUMBER) is
		SELECT   hr_general_utilities.get_lookup_meaning('PER_EU_COUNTRIES',pea.territory_code) country
				,hr_general_utilities.get_lookup_meaning ('HR_NL_BANK', pea.segment1)  bank_name
				,segment2 account_number
				,segment3 postal_code
				,hr_general_utilities.get_lookup_meaning ('HR_NL_CITY', pea.segment4)  city
				,segment5 street
				,segment6 telephone_number
				,segment7 telephone_extension
				,hr_general_utilities.get_lookup_meaning('HR_NL_BIC_CODES',pea.segment9) bank_identifier_code
				,segment10 iban_number
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_payment) cost_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_payment) cost_cleared_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_void_payment) cost_cleared_void_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.exclude_manual_payment) exclude_manual_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.transfer_to_gl_flag) transfer_to_gl_flag
		FROM     pay_external_accounts pea, (SELECT   org_payment_method_id
													 ,external_account_id
													 ,business_group_id
													 ,cost_payment
													 ,cost_cleared_payment
													 ,cost_cleared_void_payment
													 ,exclude_manual_payment
													 ,transfer_to_gl_flag
													 ,effective_start_date
													 ,effective_end_date
											 FROM     pay_org_payment_methods_f) popm
		WHERE    1 = 1
			 AND pea.external_account_id = popm.external_account_id
			 AND popm.org_payment_method_id = t_id
			 AND sysdate BETWEEN effective_start_date AND effective_end_date;
			 
	cursor c_Organizational (t_pid  NUMBER, t_dpmid NUMBER) is
			SELECT   opm.org_payment_method_name org_paymentmethod_name
				,pt.payment_type_name payment_type
				,CASE
				   WHEN opu.org_payment_method_id = t_dpmid
				   THEN
					 'Yes'
				   ELSE
					 'No'
				 END default_payment_method
				,opu.effective_start_date
				,opu.effective_end_date
				,opu.org_payment_method_id
				,pt.payment_type_id
		FROM     pay_org_pay_method_usages_f opu
				,pay_org_payment_methods_f opm
				,pay_payment_types pt
		WHERE    1 = 1
			 AND opm.org_payment_method_id = opu.org_payment_method_id
			 AND pt.payment_type_id = opm.payment_type_id
			 AND sysdate between opm.effective_start_date and opm.effective_end_date
			 AND sysdate between opu.effective_start_date and opu.effective_end_date
			 AND opu.payroll_id = t_pid
			 order by 1;
	
	v_payroll_id pay_org_pay_method_usages_f.payroll_id%type;
	v_org_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_payment_type_name pay_payment_types.payment_type_name%type;
	v_default_payment_method_id pay_all_payrolls_f.default_payment_method_id%type;
	v_default_payment_method varchar2(10);
	v_effective_start_date pay_org_pay_method_usages_f.effective_start_date%type;
	v_effective_end_date pay_org_pay_method_usages_f.effective_end_date%type;
	v_org_payment_method_id pay_org_pay_method_usages_f.org_payment_method_id%type;
	v_payment_type_id pay_payment_types.payment_type_id%type;
	
	v_id_flex FND_ID_FLEX_STRUCTURES_TL.ID_FLEX_NUM%type;
	v_code varchar2(30);
	v_cos_name varchar2(30);
	v_description varchar2(30);
	v_freeze varchar2(10);
	v_cos_enabled varchar2(10);
	v_dynamic varchar2(10);
	cursor c_costing (t_bg  NUMBER) is
		SELECT t.ID_FLEX_NUM,substrb(b.ID_FLEX_STRUCTURE_CODE,1,25) Code,
		   substrb(t.ID_FLEX_STRUCTURE_NAME,1,25) Name,
		   substrb(t.DESCRIPTION,1,25) Description,
		   lpad(substr(FREEZE_FLEX_DEFINITION_FLAG,1,8),8) Frz,
		   lpad(substr(ENABLED_FLAG,1,8),8) Enable,
		   lpad(substr(DYNAMIC_INSERTS_ALLOWED_FLAG,1,9),9) Dynamic
	FROM FND_ID_FLEX_STRUCTURES b, FND_ID_FLEX_STRUCTURES_TL t
	WHERE (t.APPLICATION_ID=801) 
		and t.language='US'
		and b.ID_FLEX_CODE=t.ID_FLEX_CODE and b.ID_FLEX_NUM=t.ID_FLEX_NUM and
		  (t.ID_FLEX_CODE='COST')
		  and
		  (t.ID_FLEX_NUM = (select cost_allocation_structure
				  from per_business_groups
				  where business_group_id = t_bg))
	order by t.application_id, t.id_flex_code, t.id_flex_structure_name;

	v_segment varchar2(30);
	v_column varchar2(15);
	v_seg_number FND_ID_FLEX_SEGMENTS.SEGMENT_NUM%type;
	v_display varchar2(10);
	v_required varchar2(10);
	v_security varchar2(10);
	v_cos_enabled2 varchar2(10);
	
	
	cursor c_costing_segments (t_flex  NUMBER) is
	SELECT substrb(SEGMENT_NAME,1,25) Name,
		   substrb(DESCRIPTION,1,25) Description,
		   substr(ENABLED_FLAG,1,3) Enabled,
		   substr(t.APPLICATION_COLUMN_NAME,1,10) Col_Name,
		   SEGMENT_NUM Seg_No,
		   lpad(substr(DISPLAY_FLAG,1,5),5) Disp,
		   lpad(substr(REQUIRED_FLAG,1,5),5) Reqd,
		   lpad(substr(SECURITY_ENABLED_FLAG,1,5),5) Secr
	FROM FND_ID_FLEX_SEGMENTS_TL T, FND_ID_FLEX_SEGMENTS B
	WHERE (t.APPLICATION_ID=801) 
		and t.language='US' 
	   and b.ID_FLEX_NUM = t_flex 
	   and b.ID_FLEX_CODE=t.ID_FLEX_CODE and b.ID_FLEX_NUM=t.ID_FLEX_NUM and  B.APPLICATION_COLUMN_NAME = T.APPLICATION_COLUMN_NAME and
		   (b.ID_FLEX_CODE='COST') and 
		   (b.APPLICATION_ID=801) 
	order by t.application_id, t.id_flex_code, t.id_flex_num, decode(b.enabled_flag, 'Y', 1, 'N', 2), b.segment_num;

	
	
	v_cost varchar2(30);
	v_atr varchar2(15);
	cursor c_costing_qualifiers (t_flex  NUMBER, t_seg NUMBER) is	
	SELECT substrb(FSAV.SEGMENT_ATTRIBUTE_TYPE,1,20) Cost_Level,
		   lpad(substr(FSAV.ATTRIBUTE_VALUE,1,10),10) Visible
	FROM FND_SEGMENT_ATTRIBUTE_VALUES FSAV, FND_ID_FLEX_SEGMENTS FIFS, FND_ID_FLEX_SEGMENTS_TL T
	WHERE 
	FIFS.APPLICATION_ID = T.APPLICATION_ID and FIFS.ID_FLEX_CODE = T.ID_FLEX_CODE and
	FIFS.ID_FLEX_NUM = T.ID_FLEX_NUM and FIFS.APPLICATION_COLUMN_NAME = T.APPLICATION_COLUMN_NAME and T.LANGUAGE = 'US' and
	EXISTS (SELECT NULL 
				  FROM FND_SEGMENT_ATTRIBUTE_TYPES T 
				  WHERE T.APPLICATION_ID =  FSAV.APPLICATION_ID AND 
						T.ID_FLEX_CODE =  FSAV.ID_FLEX_CODE AND 
						T.SEGMENT_ATTRIBUTE_TYPE =  FSAV.SEGMENT_ATTRIBUTE_TYPE AND 
						GLOBAL_FLAG = 'N') and
		   (FSAV.ID_FLEX_NUM = t_flex) and (FIFS.SEGMENT_NUM = t_seg) and
		   (FSAV.APPLICATION_COLUMN_NAME = FIFS.APPLICATION_COLUMN_NAME) and
		   (FSAV.ID_FLEX_CODE='COST') and 
		   (FSAV.APPLICATION_ID=801) and
		   (FSAV.ID_FLEX_NUM = FIFS.ID_FLEX_NUM)
	order by FSAV.segment_attribute_type, FIFS.APPLICATION_COLUMN_NAME, FIFS.SEGMENT_NAME;
	
	v_parent_id hr_all_organization_units.organization_id%type;
	  v_old number;
	  v_parent_name hr_all_organization_units.name%type;
	  v_child_id hr_all_organization_units.organization_id%type;
	  v_child_name hr_all_organization_units.name%type;
	
	cursor c_hierarchy (t_bg  NUMBER) is
	SELECT   organization_id_parent
        ,hou_parent.name
        ,organization_id_child
        ,hou_child.name
			FROM     (SELECT       pose.business_group_id
								  ,pose.organization_id_parent
								  ,organization_id_child
					  FROM         per_org_structure_elements pose
					  CONNECT BY   pose.organization_id_parent =
									 PRIOR pose.organization_id_child
							   AND pose.org_structure_version_id =
									 (SELECT   posv.org_structure_version_id
									  FROM     per_organization_structures pos
											  ,per_org_structure_versions posv
									  WHERE    pos.organization_structure_id =
												 posv.organization_structure_id
										   AND to_char (pos.organization_structure_id) IN
												   (SELECT   org_information1
													FROM     hr_organization_information hoi
													WHERE    hoi.org_information_context IN
																 'Project Burdening Hierarchy'
														 AND hoi.organization_id =
															   t_bg)
										   AND sysdate BETWEEN posv.date_from
														   AND  nvl
																(
																  posv.date_to
																 ,hr_general.end_of_time
																))
					  START WITH   pose.organization_id_parent = t_bg
							   AND pose.org_structure_version_id =
									 (SELECT   posv.org_structure_version_id
									  FROM     per_organization_structures pos
											  ,per_org_structure_versions posv
									  WHERE    pos.organization_structure_id =
												 posv.organization_structure_id
										   AND to_char (pos.organization_structure_id) IN
												   (SELECT   org_information1
													FROM     hr_organization_information hoi
													WHERE    hoi.org_information_context =
															   'Project Burdening Hierarchy'
														 AND hoi.organization_id =
															   t_bg)
										   AND sysdate BETWEEN posv.date_from
														   AND  nvl
																(
																  posv.date_to
																 ,hr_general.end_of_time
																))
					  ORDER BY     pose.organization_id_parent) org_struc
					, (SELECT   name
							   ,organization_id
							   ,date_to
							   ,date_from
					   FROM     hr_all_organization_units) hou_parent
					, (SELECT   name
							   ,organization_id
							   ,date_to
							   ,date_from
					   FROM     hr_all_organization_units) hou_child
			WHERE    org_struc.organization_id_parent = hou_parent.organization_id
				 AND org_struc.organization_id_child = hou_child.organization_id
				 AND sysdate BETWEEN hou_parent.date_from
								 AND  nvl (hou_parent.date_to, hr_general.end_of_time)
				 AND sysdate BETWEEN hou_child.date_from
								 AND  nvl (hou_child.date_to, hr_general.end_of_time);
	
begin
		
	l_o('<br><DIV class=divItem>');
	l_o('<DIV  class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b"  onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Business Group Information</A></DIV>');					
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql500'||:v_link_no||'" style="display:none" >');
	:v_link_no:=:v_link_no+1;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Business Group Information:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD></TR><TR id="s1sql500'||:v_link_no||'" style="display:none">');
	:v_link_no:=:v_link_no+1;
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
	l_o('SELECT    haou.name,hoi.organization_id,pbg.currency_code ,pbg.enabled_flag ,pbg.date_from ,pbg.date_to	  <br>');
						l_o('FROM       hr_organization_information hoi,hr_all_organization_units haou,per_business_groups pbg<br>');
						l_o('WHERE      hoi.organization_id = haou.organization_id<br>');
						l_o('AND pbg.organization_id = haou.organization_id<br>');
						l_o('AND hoi.org_information_context = ''Business Group Information''<br>');
						l_o('and pbg.legislation_code='''||v_leg||'''<br>');							
						l_o(' </blockquote><br></TD></TR>');
       
		
    :n := dbms_utility.get_time;
    l_o(' <TR><TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	
		
    open c_bg(v_leg);
        loop
           fetch c_bg into v_name,v_bg,v_cur,v_enabled,v_date_from,v_date_to;					
			EXIT WHEN  c_bg%NOTFOUND;			
			l_o('<DIV class=divItem>');
			l_o('<DIV class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_bg||' - '||v_name||'</A></DIV>');
			l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
							
			l_o('Currency: '|| v_cur||'<br>Enabled Flag: '|| v_enabled||'<br>Date From: '|| v_date_from||'<br>Date To: '|| v_date_to||'<br>');
		
			SELECT   org_information1 short_name					
					,hr_general_utilities.get_lookup_meaning('EMP_NUM_GEN_METHOD',org_information2) employee_number_generation
					,hr_general_utilities.get_lookup_meaning('APL_NUM_GEN_METHOD',org_information3) applicant_number_generation
					,hr_general_utilities.get_lookup_meaning('CWK_NUM_GEN_METHOD',org_information16) contingent_worker_numb_gen
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information4
							AND id_flex_code = 'GRD')       grade_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information5
							AND id_flex_code = 'GRP')        group_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information6
							AND id_flex_code = 'JOB')        job_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information7
							AND id_flex_code = 'COST')       costing_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information8
							AND id_flex_code = 'POS')        position_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information15
							AND id_flex_code = 'CMP')        competence_flexfield_structure
					,org_information10 currency
					,org_information11 fiscal_year_start
					,org_information12 minimum_working_age
					,org_information13 maximum_working_age
					into v_short_name,v_employee_number_generation,v_applicant_number_generation,v_contingent_worker_numb_gen, v_grade_flexfield_structure,v_group_flexfield_structure,v_job_flexfield_structure,v_costing_flexfield_structure,v_position_flexfield_structure,v_competence_flex,v_currency,v_fiscal_year_start,v_minimum_working_age,v_maximum_working_age
					FROM     hr_organization_information hoi
							, (SELECT   name, organization_id FROM hr_all_organization_units)
							 hou_bg
					WHERE    1 = 1
						 AND hoi.organization_id = hou_bg.organization_id
						 AND hoi.org_information_context LIKE 'Business Group Information'
						 AND hoi.org_information9 = v_leg
						 AND hou_bg.organization_id = v_bg 
						 AND	 rownum < 2;
						 
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Business Group Info Setup</A>');
			l_o('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;
			l_o('<tr><th>Organization Short Name</th><th>Employee Number Generation</th><th>Applicant Number Generation</th>');
			l_o('<th>Contingent Worker Numb Gen</th><th>Grade Flexfield Structure</th><th>Group Flexfield Structure</th>');
			l_o('<th>Job Flexfield Structure</th><th>Costing Flexfield Structure</th><th>Position Flexfield Structure</th><th>Competence Flexfield Structure</th>');
			l_o('<th>Currency</th><th>Fiscal Year Start</th><th>Minimum Working Age</th>');
			l_o('<th>Maximum Working Age</th></tr>');
		
			l_o('<TR><TD>'||v_short_name||'</TD>'||chr(10)||'<TD>'||v_employee_number_generation||'</TD>'||chr(10)||'<TD>'||v_applicant_number_generation||'</TD>'||chr(10));
			l_o('<TD>'||v_contingent_worker_numb_gen||'</TD>'||chr(10)||'<TD>'||v_grade_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_group_flexfield_structure||'</TD>'||chr(10));
			l_o('<TD>'||v_job_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_costing_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_position_flexfield_structure||'</TD>'||chr(10));
			l_o('<TD>'||v_competence_flex||'</TD>'||chr(10)||'<TD>'||v_currency||'</TD>'||chr(10)||'<TD>'||v_fiscal_year_start||'</TD>'||chr(10));
			l_o('<TD>'||v_minimum_working_age||'</TD>'||chr(10)||'<TD>'||v_maximum_working_age||'</TD></TR>'||chr(10));
			l_o('</table><br>');					  
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;General Payroll Information</A>');
			l_o('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			l_o('<tr><th>Payroll Name</th><th>Period Type</th><th>First Period End Date</th><th>Number of Years</th><th>Period Reset Years</th>');
			l_o('<th>Pay Date Offset</th><th>Direct Deposit Date Offset</th>');
			l_o('<th>Pay advice date offset</th><th>Cut off date offset</th><th>Payslip view date offset</th><th>Default Payment Method</th><th>Consolidation Set</th>');
			l_o('<th>Workload Shifting Level</th><th>Arrears Flag</th><th>Negative pay allowed flag</th><th>Multi assignments flag</th><th>Legal Employer ID</th>');
			l_o('<th>Modeling Availability Rule</th><th>Days after period start</th><th>Days after period end</th></tr>');
			
			
			open c_payroll(v_bg);
			loop
				  fetch c_payroll into v_payroll_name,v_period_type,v_first_date,v_number_of_years,v_period_reset_years,v_pay_date_offset,v_direct_deposit,v_pay_advice_date_offset,v_cut_off_date,v_payslip_view,v_default_payment,v_consolidation,v_workload_shifting,v_arrears_flag,v_negative_pay,v_multi_assignments,v_legal_employer,v_prl_information21,v_prl_information22,v_modeling_availability,v_payroll_id,v_default_payment_method_id;
				  EXIT WHEN  c_payroll%NOTFOUND;
				  l_o('<TR><TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_payroll_name||'</A>');
					l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						l_o('<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Valid Organizational Payment Methods</b>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table>');
							if v_default_payment_method_id is null then
							l_o('<tr><td>Default Payment Method is null</th></tr>');
							else
							l_o('<tr><th>Org Payment Method</th><th>Payment Type</th><th>Default Payment Method</th>');
							l_o('<th>Effective Start Date</th><th>Effective End Date</th><th>Org Payment Method ID</th><th>Payment Type ID</th></tr>');
							open c_Organizational(v_payroll_id,v_default_payment_method_id);
							loop
								  fetch c_Organizational into v_org_payment,v_payment_type_name,v_default_payment_method,v_effective_start_date,v_effective_end_date,v_org_payment_method_id,v_payment_type_id;
								  EXIT WHEN  c_Organizational%NOTFOUND;				  
								  l_o('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; '||v_org_payment||'</A>');
								  l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  l_o('<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Organizational payment method information</b>');
								  l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table >');								 							  
								  l_o('<tr><th>Country</th><th>Bank name</th><th>Account number</th><th>Postal code</th><th>City</th><th>Street</th><th>Telephone number</th><th>');
								  l_o('Telephone extension</th><th>Bank identifier code</th><th>IBAN</th><th>Cost payment</th><th>Cost cleared payment</th><th>Cost cleared void payment</th><th>');
								  l_o('Exclude manual payment</th><th>Transfer to GL flag</th></tr>');
								  open c_org_pay(v_org_payment_method_id);
									loop
										  fetch c_org_pay into v_lookup1,v_lookup2,v_seg2,v_seg3, v_lookup3,v_seg5,v_seg6,v_seg7,v_lookup4,v_seg10,v_lookup9,v_lookup5,v_lookup6,v_lookup7,v_lookup8;
										  EXIT WHEN  c_org_pay%NOTFOUND;				  
										      l_o('<TR><TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10)||'<TD>'||v_seg2||'</TD>'||chr(10));
											  l_o('<TD>'||v_seg3||'</TD>'||chr(10)||'<TD>'||v_lookup3||'</TD>'||chr(10));
											  l_o('<TD>'||v_seg5||'</TD>'||chr(10)||'<TD>'||v_seg6||'</TD>'||chr(10));
											  l_o('<TD>'||v_seg7||'</TD>'||chr(10)||'<TD>'||v_lookup4||'</TD>'||chr(10));
											  l_o('<TD>'||v_seg10||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
											  l_o('<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10));											 
											  l_o('<TD>'||v_lookup7||'</TD>'||chr(10)||'<TD>'||v_lookup8||'</TD></TR>'||chr(10));     
									end loop;
									close c_org_pay;
								l_o('</table><br></div>');							  
								  
								  l_o('</TD>'||chr(10)||'<TD>'||v_payment_type_name||'</TD>'||chr(10)||'<TD>'||v_default_payment_method||'</TD>'||chr(10));
								  l_o('<TD>'||v_effective_start_date||'</TD>'||chr(10));
								  l_o('<TD>'||v_effective_end_date||'</TD>'||chr(10)||'<TD>'||v_org_payment_method_id||'</TD>'||chr(10));								 
								  l_o('<TD>'||v_payment_type_id||'</TD></TR>'||chr(10));         
							end loop;
							close c_Organizational;
							end if;
						l_o('</table><br>');						
				  l_o('</TD>');		 
				  
				  l_o('<TD>'||v_period_type||'</TD>'||chr(10)||'<TD>'||v_first_date||'</TD>'||chr(10)||'<TD>'||v_number_of_years||'</TD>'||chr(10));
				  l_o('<TD>'||v_period_reset_years||'</TD>'||chr(10)||'<TD>'||v_pay_date_offset||'</TD>'||chr(10)||'<TD>'||v_direct_deposit||'</TD>'||chr(10));
				  l_o('<TD>'||v_pay_advice_date_offset||'</TD>'||chr(10)||'<TD>'||v_cut_off_date||'</TD>'||chr(10)||'<TD>'||v_payslip_view||'</TD>'||chr(10));
					l_o('<TD>'||v_default_payment||'</TD>'||chr(10)||'<TD>'||v_consolidation||'</TD>'||chr(10)||'<TD>'||v_workload_shifting||'</TD>'||chr(10));
					l_o('<TD>'||v_arrears_flag||'</TD>'||chr(10)||'<TD>'||v_negative_pay||'</TD>'||chr(10)||'<TD>'||v_multi_assignments||'</TD>'||chr(10));
					l_o('<TD>'||v_legal_employer||'</TD>'||chr(10)||'<TD>'||v_modeling_availability||'</TD>'||chr(10)||'<TD>'||v_prl_information21||'</TD>'||chr(10));
					l_o('<TD>'||v_prl_information22||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_payroll;
			l_o('</table><br>');			
			
			
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Cost Flexfield Structure and Values</A>');
			l_o('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			l_o('<tr><th>Name</th><th>ID Flex Number</th><th>Code</th><th>Description</th><th>Freeze</th>');
			l_o('<th>Enable</th><th>Dynamic</th></tr>');
			                       
			
			open c_costing(v_bg);
			loop
				  fetch c_costing into v_id_flex,v_code,v_cos_name,v_description,v_freeze,v_cos_enabled,v_dynamic;
				  EXIT WHEN  c_costing%NOTFOUND;
				  l_o('<TR><TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_cos_name||'</A>');
					l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						l_o('<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Flexfield Segments Setup</b>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table>');
               						
							l_o('<tr><th>Segment Name</th><th>Description</th><th>Enabled</th>');
							l_o('<th>Application Column Name</th><th>Display</th><th>Required</th><th>Security</th></tr>');
							 
							open c_costing_segments(v_id_flex);
							loop
								  fetch c_costing_segments into v_segment,v_description,v_cos_enabled2,v_column,v_seg_number,v_display,v_required,v_security;
								  EXIT WHEN  c_costing_segments%NOTFOUND;				  
								  l_o('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; '||v_segment||'</A>');
								  l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  l_o('<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Flexfield Qualifiers</b>');
								  l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table >');	   							 							  
								  l_o('<tr><th>Cost Level</th><th>Visible</th></tr>');
								  open c_costing_qualifiers(v_id_flex,v_seg_number);
									loop
										  fetch c_costing_qualifiers into v_cost,v_atr;
										  EXIT WHEN  c_costing_qualifiers%NOTFOUND;				  
										      l_o('<TR><TD>'||v_cost||'</TD>'||chr(10)||'<TD>'||v_atr||'</TD></TR>'||chr(10));     
									end loop;
									close c_costing_qualifiers;
								l_o('</table><br></div>');							  
								  
								  l_o('</TD>'||chr(10)||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_cos_enabled2||'</TD>'||chr(10));
								  l_o('<TD>'||v_column||'</TD>'||chr(10));
								  l_o('<TD>'||v_display||'</TD>'||chr(10)||'<TD>'||v_required||'</TD>'||chr(10));								 
								  l_o('<TD>'||v_security||'</TD></TR>'||chr(10));         
							end loop;
							close c_costing_segments;
							
						l_o('</table><br>');
						
				  l_o('</TD>');
				 
				  l_o('<TD>'||v_id_flex||'</TD><TD>'||v_code||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_freeze||'</TD>'||chr(10)||'<TD>'||v_cos_enabled||'</TD>'||chr(10));				 
				  l_o('<TD>'||v_dynamic||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_costing;
			l_o('</table><br><br>');				
			
			l_o('</DIV></DIV>');        
			
        end loop;
    close c_bg;
                            
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o('</TD></TR> <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> ');
	l_o('</div>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;
procedure header (v_leg varchar2) is
begin
			l_o('<div class="divSection"><div class="divSectionTitle">');		
			l_o('<div class="left"  id="'||replace(v_leg,' ','')||'" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">'||v_leg); 
			l_o('</div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
			l_o('<a class="detail" onclick="openall();" href="javascript:;"><font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
			l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
			l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a></div><div class="clear"></div></div><br>');
			l_o('<div class="divItem"><div class="divItemTitle">In This Section</div>');
			l_o('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
			case v_leg 
			when 'Canada' then
			l_o('<a href="#'||replace(v_leg,' ','')||'g">Geocode</a> <br>');	  
			l_o('<a href="#'||replace(v_leg,' ','')||'q">Quantum</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br></td><td class="toctable">');
			l_o('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'pdf">Setup for PDF Reports</a> <br>');
			when 'United States' then
			l_o('<a href="#'||replace(v_leg,' ','')||'g">Geocode</a> <br>');	  
			l_o('<a href="#'||replace(v_leg,' ','')||'q">Quantum</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'j">JIT</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br></td><td class="toctable">');
			l_o('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'pdf">Setup for PDF Reports</a> <br>');
			when 'Mexico' then			
			l_o('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br></td><td class="toctable">');
			l_o('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'pdf">Setup for PDF Reports</a> <br>');
			when 'United Kingdom' then
			l_o('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br></td><td class="toctable">');
			l_o('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'v">Versions</a> <br>');
			else
			l_o('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');	  
			l_o('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			end case;
			l_o('</td></tr></table>');
			l_o('</div></div><br>');
end;
procedure au is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AU'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page2" style="display: none;">');
			header('Australia');	
			l_o('<div class="divSection"><div class="divSectionTitle">Patching</div><br><div class="divItem">');
			l_o('<a name="Australiap"></a><div class="divItemTitle">Mandatory Patches</div>');			
			if (:apps_rel like '12.2%') then					
					dpatch('AU','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('AU','21238399', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('AU','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('AU','21267565', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');	
				elsif (:apps_rel like '12.0%') then					
					dpatch('AU','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('AU','19764591', 'AU.22 AUSTRALIA CONSOLIDATED PATCH');
				elsif :apps_rel like '11.5%' then					
					dpatch('AU','14488556', 'HR_PF.K.RUP.8');
					dpatch('AU','17314780','11I.AU.21 AUSTRALIA CUMULATIVE RELEASE');					
			end if;
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');								
								dpatch('AU','21238399', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
								l_o('</div>');
						elsif (:apps_rel like '12.1%') then					
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');								
								dpatch('AU','21267565', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
								l_o('</div>');								
						elsif (:apps_rel like '12.0%') then			
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('AU','19764591', 'AU.22 AUSTRALIA CONSOLIDATED PATCH');
								l_o('</div>');
						elsif :apps_rel like '11.5%' then					
							if :rup_level='14488556' or :rup_level='12807777'   then		
								l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('AU','16365150','R121.AU.20 AUSTRALIA CUMULATIVE RELEASE');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br><a name="Australiad"></a>'); datainstall('AU',2);
			l_o('<a name="Australias"></a>');bg_generic('AU',2);
			l_o('</div>');
			documents('1504358.2','Information Center: Oracle HRMS (Australia)'); 
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure be is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'BE'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page3" style="display: none;">');header('Belgium');
			datainstall('BE',3);
			bg_generic('BE',3);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure de is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'DE'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page7" style="display: none;">');
			datainstall('DE',7);
			bg_generic('DE',7);
			l_o('</div></div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure ca is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'CA'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page4" style="display: none;">');header('Canada');
				
			l_o('<a name="Canadag"></a>');geocode('CA');	
			l_o('<a name="Canadaq"></a>');Quantum('CA');
			--jit('CA');
			l_o('<br><div class="divSection">');l_o('<a name="Canadap"></a>');
			l_o('<div class="divSectionTitle">Patching</div><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');
			if (:apps_rel like '12.2%') then							
					dpatch('CA','19193000', 'R12.HR_PF.C.Delta.6');					
					dpatch('CA','20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.1%') then							
					dpatch('CA','20000288', 'R12.HR_PF.B.delta.8');					 
					dpatch('CA','20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.0%') then					
					dpatch('CA','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('CA','19701971','End of Year 2014 Phase 1');
					dpatch('CA','20212223','End of Year 2014 Phase 2');
					dpatch('CA','20365000','End of Year 2014 Phase 3');
				elsif :apps_rel like '11.5%' then				
					dpatch('CA','17774746', 'HR_PF.K.RUP.9');	
					dpatch('CA','20364999','End of Year 2014 Phase 3');
					dpatch('CA','20301513','Year Begin 2015 Statutory Update 2');
					dpatch('CA','20212121','Year Begin 2015 Statutory Update');
				end if;	
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.%') then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('CA','20365000','End of Year 2014 Phase 3');
								l_o('</div>');
						elsif :apps_rel like '11.5%' then	
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('CA','20364999','End of Year 2014 Phase 3');	
								l_o('</div>');		
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="Canadad"></a>');datainstall('CA',4);
			l_o('<a name="Canadas"></a>');bg_generic('CA',2);
			l_o('</div>');
			l_o('<a name="Canadapdf"></a>');pdf_reports('CA');
			documents('1504134.2','Information Center: Oracle HRMS (Canada)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure cn is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'CN'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page5" style="display: none;">');header('China');
			l_o('<div class="divSection">');l_o('<a name="Chinap"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('CN','19193000', 'R12.HR_PF.C.Delta.6');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('CN','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('CN','13715802','R12.PER.B - TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');
					dpatch('CN','16741703','R12.PER.B - Prevent Tax payable when under One Yuan (RMB)');									
				elsif (:apps_rel like '12.0%') then					
					dpatch('CN','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('CN','13715802','R12.PER.A - TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');				
				elsif :apps_rel like '11.5%' then					
					dpatch('CN','12807777', 'HR_PF.K.RUP.7');
					dpatch('CN','13717027','TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');
					dpatch('CN','14625844','Prevent Tax Payable when under One YUAN (RMB)');					
				end if;		
			l_o('</div>');			
			l_o('</div><br>'); l_o('<a name="Chinad"></a>');datainstall('CN',5);
			l_o('<a name="Chinas"></a>');bg_generic('CN',5);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure es is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'ES'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page6" style="display: none;">');header('Spain');
			datainstall('ES',6);
			bg_generic('ES',6);
			l_o('</div>');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure dk is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'DK'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page8" style="display: none;">');header('Denmark');
			l_o('<div class="divSection">');l_o('<a name="Denmarkp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('DK','19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('DK','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('DK','20218977', 'ABP PGGM Calculation Changes 2015');
					dpatch('DK','20107803', 'Danish Legislative Changes 2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('DK','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('DK','20218977', 'ABP PGGM Calculation Changes 2015');
					dpatch('DK','20107803', 'Danish Legislative Changes 2015');	
				elsif :apps_rel like '11.5%' then					
					dpatch('DK','12807777', 'HR_PF.K.RUP.7');
					dpatch('DK','16002352', 'Danish Legislative Changes 2013 Part-3');
					dpatch('DK','15945507', 'Danish Legislative Changes 2013 Part 1, 2');
					dpatch('DK','13500283', 'Danish Legislative Changes 2012');					
				end if;		
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('DK','20107803', 'Danish Legislative Changes 2015');
								l_o('</div>');								
							
						elsif (:apps_rel like '12.0%') then					
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('DK','20107803', 'Danish Legislative Changes 2015');
								l_o('</div>');
							
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777' then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('DK','16002352','DANISH LEGISLATIVE CHANGES 2013 PART-3');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="Denmarkd"></a>');datainstall('DK',8);
			l_o('<a name="Denmarks"></a>');bg_generic('DK',8);
			l_o('</div>');
			documents('1509934.2','Information Center: Oracle HRMS (Denmark)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure fi is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'FI'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page9" style="display: none;">');header('Finland');
			l_o('<div class="divSection">');l_o('<a name="Finlandp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('FI','19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('FI','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('FI','12793751', 'Delivers the Finland legislative changes for 2011 Part-I');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('FI','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('FI','12793751', 'Delivers the Finland legislative changes for 2011 Part-I');				
				elsif :apps_rel like '11.5%' then					
					dpatch('FI','12807777', 'HR_PF.K.RUP.7');
					dpatch('FI','10393363', 'Delivers the Finland legislative changes for 2011 Part-I');				
				end if;			
			l_o('</div>');			
			l_o('</div><br>'); l_o('<a name="Finlandd"></a>');datainstall('FI',9);
			l_o('<a name="Finlands"></a>');bg_generic('FI',9);
			l_o('</div>');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure fr is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'FR'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page10" style="display: none;">');header('France');
			datainstall('FR',10);
			bg_generic('FR',10);
			l_o('</div>');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure hk is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'HK'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page11" style="display: none;">');header('Hong Kong');
			l_o('<div class="divSection">');l_o('<a name="HongKongp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('HK','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('HK','20768287','TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('HK','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('HK','20768287','TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('HK','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('HK','17385401','R12.PER.A - R12.HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013 1 JUN 2014');										
				elsif :apps_rel like '11.5%' then					
					dpatch('HK','12807777', 'HR_PF.K.RUP.7');
					dpatch('HK','17539543','HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');				
				end if;			
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('HK','17385401','R121 HK.15 HK STATUTORY MPF MIN/MAX RI CHANGES FOR 1 NOV 2013/1 JUNE 2014');
								l_o('</div>');	
							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('HK','17385401','R12.HK.15 HK STATUTORY MPF MIN/MAX RI CHANGES FOR 1 NOV 2013/1 JUNE 2014');
								l_o('</div>');		
							elsif :rup_level='13774477' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('HK','16457605','R12.HK.14 HK STATUTORY MINIMUM WAGE RATE CHANGE 1ST MAY 2013');
								l_o('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777' or :rup_level='14488556' then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('HK','17539543','HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="HongKongd"></a>');datainstall('HK',11);
			l_o('<a name="HongKongs"></a>');bg_generic('HK',11);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure hu is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'HU'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page12" style="display: none;">');header('Hungary');
			datainstall('HU',12);
			bg_generic('HU',12);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure ind is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IN'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page14" style="display: none;">');header('India');
			l_o('<div class="divSection">');l_o('<a name="Indiap"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('IN','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('IN','21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
				elsif (:apps_rel like '12.1%') then					
					dpatch('IN','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('IN','21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
				elsif (:apps_rel like '12.0%') then					
					dpatch('IN','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('IN','19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
				elsif :apps_rel like '11.5%' then					
					dpatch('IN','12807777', 'HR_PF.K.RUP.7');
					dpatch('IN','13914662','INDIA HRMS CONSOLIDATED UPDATE 11i.IN.08');	
					dpatch('IN','13870875','Form 24Q E-TDS Regular Changes');
					dpatch('IN','14351973','India Budget Changes for Section 80CCG and Section 80TTA');
					dpatch('IN','16359871','Andhra Pradesh professional Tax changes Effective 06-FEB-2013');
					dpatch('IN','16520998','India Budget Changes Gujarat Professional Tax Changes Effective 01-APR-2013');
					dpatch('IN','16669518','Madhya Pradesh Professional Tax Changes Effective 01-APR-2013	');				
				end if;					
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','20733388','R121 TRACKING BUG FOR INDIA 2015-16 BUDGET CHANGES');
								l_o('</div>');
					elsif (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
								l_o('</div>');	
							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
								l_o('</div>');		
							elsif :rup_level='13774477' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','17579687','12.0BL: INDIA CONSOLIDATED UPDATE IN.09 ');
								l_o('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777'  then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','17578798','INDIA CONSOLIDATED UPDATE IN.09 ');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="Indiad"></a>');datainstall('IN',14);
			l_o('<a name="Indias"></a>');bg_generic('IN',14);
			l_o('</div>');	
			documents('1504684.2',	'Information Center: Oracle HRMS (India)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure it is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IT'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page15" style="display: none;">');header('Italy');
			datainstall('IT',15);
			bg_generic('IT',15);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure jp is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'JP'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page16" style="display: none;">');header('Japan');
			l_o('<div class="divSection">');l_o('<a name="Japanp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('JP','19193000', 'R12.HR_PF.C.Delta.6');					
				elsif (:apps_rel like '12.1%') then	
					dpatch('JP','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('JP','17015507','R12.PER.B - JAPANESE HRMS CONSOLIDATED PATCH R121.JP.13');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('JP','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('JP','13330458','R12.PER.A - JAPANESE HRMS CONSOLIDATED PATCH R12.JP.12');	
					dpatch('JP','13743712','R12.PER.A - H24 UNEMPLOYMENT INSURANCE RATE');					
				elsif :apps_rel like '11.5%' then					
					dpatch('JP','12807777', 'HR_PF.K.RUP.7');
					dpatch('JP','17015482','JAPANESE HRMS CONSOLIDATED UPDATE R115.JP.13');					
				end if;					
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							if :rup_level='18004477' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('JP','19862190','H27 TERMINATION TAX RATE CHANGES EFFECTIVE 01-JAN-2015');
								l_o('</div>');								
							elsif :rup_level='13418800' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('JP','17015507','JAPANESE HRMS CONSOLIDATED PATCH R121.JP.13');
								l_o('</div>');		
							end if;						
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777'  then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('JP','17015482', 'JAPANESE HRMS CONSOLIDATED PATCH R115.JP.13');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="Japand"></a>');datainstall('JP',16);
			l_o('<a name="Japans"></a>');bg_generic('JP',16);
			l_o('</div>');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure kr is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KR'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page17" style="display: none;">');header('Korea');
			l_o('<div class="divSection">');l_o('<a name="Koreap"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then
					dpatch('KR','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
				elsif (:apps_rel like '12.1%') then					
					dpatch('KR','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');						
				elsif (:apps_rel like '12.0%') then					
					dpatch('KR','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');					
				elsif :apps_rel like '11.5%' then					
					dpatch('KR','12807777', 'HR_PF.K.RUP.7');
					dpatch('KR','16518233','KOREA CUMULATIVE RELEASE PATCH - 11i.KR.69');
					dpatch('KR','17446056','KOREA 2013 YEA CHANGES: RENT EXEMPTION,MAXIMUM SPECIAL EXEMPTION LIMIT');
					dpatch('KR','18107426','KOREA 2013 YEA CHANGES: SINGLE PARENT EXEMPTION');
				end if;						
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
								l_o('</div>');								
					elsif (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
								l_o('</div>');								
						elsif (:apps_rel like '12.0%') then					
							if  :rup_level='16077077' or :rup_level='13774477' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
								l_o('</div>');	
							end if;								
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="Koread"></a>');datainstall('KR',17);
			l_o('<a name="Koreas"></a>');bg_generic('KR',17);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure kw is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KW'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page18" style="display: none;">');header('Kuwait');
			l_o('<div class="divSection">');l_o('<a name="Kuwaitp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('KW','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('KW','20331815', 'Change in employee social insurance contributions for Kuwait');
				elsif (:apps_rel like '12.1%') then					
					dpatch('KW','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('KW','20331815', 'Change in employee social insurance contributions for Kuwait');											
				elsif (:apps_rel like '12.0%') then					
					dpatch('KW','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('KW','19009589', 'R12.PAY.A - KW Unemployment Insurance');
					dpatch('KW','16787133', 'R12.PAY.A - Kuwait SI changes 2013');
					dpatch('KW','15934773', 'R12.PAY.A - KUWAIT Report changes');					
				elsif :apps_rel like '11.5%' then					
					dpatch('KW','12807777', 'HR_PF.K.RUP.7');
					dpatch('KW','16806105', 'Kuwait SI changes 2013');
					dpatch('KW','15934061', 'KUWAIT Report changes');					
				end if;								
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
						l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','20331815', 'Change in employee social insurance contributions for Kuwait');
								l_o('</div>');		
					elsif (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','20331815', 'Change in employee social insurance contributions for Kuwait');
								l_o('</div>');	
							
						elsif (:apps_rel like '12.0%') then					
							if  :rup_level='13774477' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','16787133', 'TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');
								l_o('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='14488556' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','16806105','TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');	
								l_o('</div>');
							elsif :rup_level='12807777'  then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','16806105','TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="Kuwaitd"></a>');datainstall('KW',18);
			l_o('<a name="Kuwaits"></a>');bg_generic('KW',18);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure mx is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'MX'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page19" style="display: none;">');header('Mexico');
			l_o('<div class="divSection">');l_o('<a name="Mexicop"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('MX','17050005', 'HRMS RUP4');
					dpatch('MX','20259629','2014 EOY Phase 1');
					dpatch('MX','20794928','Economic Zone B Minimum Wage');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('MX','20000288', 'R12.HR_PF.B.delta.8');					
					dpatch('MX','20259629','2014 EOY Phase 1');
					dpatch('MX','20794928','Economic Zone B Minimum Wage');
				elsif (:apps_rel like '12.0%') then
					dpatch('MX','16077077', 'R12.HR_PF.A.delta.11');					
					dpatch('MX','20259629','2014 EOY Phase 1');
				elsif :apps_rel like '11.5%' then					
					dpatch('MX','12807777', 'HR_PF.K.RUP.7');
					dpatch('MX','15919087','NOV 2012 MINIMUM WAGE UPDATES');
					dpatch('MX','14776810','2012 Year End Phase 1');
					dpatch('MX','16034967','2013 Year Begin');
					dpatch('MX','16023541','GETTING WRONG VALUES WITH SS QUOTA PRORATED WHEN SENIORITY CHANGES IN MID');
					dpatch('MX','16090552','2012 Year End Phase 2');
					dpatch('MX','16270938','NO ANNUAL TAX ADJUST, ISR IS STILL ZERO FOR THE ISR WITHHELD');
					dpatch('MX','16607347','11I: MEXICO STATE TAX UPDATES 2013');
					dpatch('MX','17500878','11I:MX SEP13: QUINTANA ROO STATE TAX RATE UPDATE');
				end if;														
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then	
						l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('MX','20259629','2014 EOY Phase 1');
								l_o('</div>');		
					elsif (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('MX','20259629','2014 EOY Phase 1');
								l_o('</div>');	
						elsif (:apps_rel like '12.0%') then					
							if  :rup_level='16077077' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('MX','20259629','2014 EOY Phase 1');
								l_o('</div>');	
							end if;									
					end if;	
			end if;
			l_o('</div><br>'); 
			l_o('<a name="Mexicod"></a>');datainstall('MX',19);
			l_o('<a name="Mexicos"></a>');bg_generic('MX',19);
			profit_sharing('MX',19);
			l_o('</div>');	
			l_o('<a name="Mexicopdf"></a>');pdf_reports('MX');
			documents('1507499.2','Information Center: Oracle HRMS (Mexico)'); 
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure file_version_uk is
	v_exists number;
    v_filename ad_files.filename%type;
	v_version ad_file_versions.version%type;
    v_update ad_file_versions.last_update_date%type;		
    cursor c_files is
        SELECT files.filename,ver2.version,ver2.last_update_date
			FROM ad_file_versions ver2,ad_files f2
			, (SELECT MAX (ver.file_version_id) file_version_id, f.filename
			FROM ad_file_versions ver, ad_files f
			WHERE f.file_id = ver.file_id
			AND (lower(f.filename) like ('pygbrti%') or lower(f.filename) like ('pygbfps%'))
			GROUP BY f.filename) files
			WHERE files.filename = f2.filename AND f2.file_id = ver2.file_id
			AND files.file_version_id = ver2.file_version_id and f2.app_short_name = 'PAY'
			order by files.filename desc;	

begin
			
	l_o('<br><DIV class=divItem>');
	l_o('<DIV id="s1sql89b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql89'');" href="javascript:;">&#9654; RTI files</A></DIV>');		
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql89" style="display:none" >');	
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Pension functionality files:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql90'');" href="javascript:;">&#9654; Show SQL Script</A>');
	l_o('   </TD></TR><TR id="s1sql90" style="display:none">');	 
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
    l_o('        SELECT files.filename,ver2.version,ver2.last_update_date  <br>');
	l_o('        FROM   ad_file_versions ver2,ad_files f2<br>');
	l_o('        	  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename<br> FROM     ad_file_versions ver, ad_files f<br>');
	l_o('        		 WHERE    f.file_id = ver.file_id<br> AND       (lower(f.filename) like (''pygbrti%'') or lower(f.filename) like (''pygbfps%''))<br>');
	l_o('        		 GROUP BY f.filename) files<br>  WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id<br>');
	l_o('       AND files.file_version_id = ver2.file_version_id and f2.app_short_name = ''PAY''<br>'); 	
	l_o('        order by files.filename desc;<br>');
    l_o('          </blockquote><br></TD></TR><TR>');    
	l_o(' <TH><B>Filename</B></TD><TH><B>Version</B></TD><TH><B>Last update</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open c_files;
			loop
				fetch c_files into v_filename, v_version, v_update;
				EXIT WHEN  c_files%NOTFOUND;
				l_o('<TR><TD>'||v_filename||'</TD>'||chr(10)||'<TD>'||v_version||'</TD>'||chr(10)||'<TD>'||v_update||'</TD></TR>'||chr(10));
			end loop;
		close c_files;   
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR></TABLE> ');
	l_o('</div>');
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure file_version (v_leg varchar2) is
	v_exists number;
    v_filename ad_files.filename%type;
	v_version ad_file_versions.version%type;
    v_update ad_file_versions.last_update_date%type;		
    cursor c_pension is
        SELECT files.filename,ver2.version,ver2.last_update_date
			FROM   ad_file_versions ver2,ad_files f2
				  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename
					 FROM     ad_file_versions ver, ad_files f
					 WHERE    f.file_id = ver.file_id
					 AND      (lower(f.filename) like
								('pqp'||v_leg||'%')) 
					AND (lower(f.filename) not like '%.pk_')
					 GROUP BY f.filename) files
			WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id
			AND    files.file_version_id = ver2.file_version_id	and f2.app_short_name = 'PQP'
			order by files.filename desc;
	
	cursor package_vers is
		  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type) v_type,
		  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 ) v_file , 
		  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4) v_ver
		  from dba_source 
		  where (upper(name) like ('%PQP_'||upper(v_leg)||'%')) and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and owner='APPS'  and type in('PACKAGE','PACKAGE BODY') 
		  and line =2 
		  order by Name; 

begin
	
	l_o('<br><div class="divSection">' );
	l_o('<div class="divSectionTitle">Versions</div><br>');
l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql104b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql104'');" href="javascript:;">&#9654; Pension packages</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql104" style="display:none" >');	
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Packages versions:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF"><A class=detail  onclick="displayItem2(this,''s1sql107'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD></TR><TR id="s1sql107" style="display:none">');	
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
			l_o('          select Name as Package, <br>');
			l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
			l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
			l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
			l_o('          from dba_source <br>');		
			l_o('          where (upper(name) like (''%PQP_'||v_leg||'%'')) <br>');		
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br> order by Name;<br></TD></TR><TR>');    
	l_o(' <TH><B>Package name</B></TD><TH><B>Type</B></TD><TH><B>Filename</B></TD><TH><B>Version</B></TD>');
	
    :n := dbms_utility.get_time;
    
	for pack_rec in package_vers loop   
						l_o('<TR><TD>'||pack_rec.name||'</TD>'||chr(10)||'<TD>'||pack_rec.v_type||'</TD>'||chr(10)||'<TD>');
						l_o(pack_rec.v_file||'</TD>'||chr(10)||'<TD>'||pack_rec.v_ver);
						l_o('</TD></TR>'||chr(10));
					end loop;	 
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> </TABLE> ');
	l_o('</div><br>');
	
	l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql83b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql83'');" href="javascript:;">&#9654; Pension functionality files</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql83" style="display:none" >');	
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Pension functionality files:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
		l_o(' <A class=detail  onclick="displayItem2(this,''s1sql86'');" href="javascript:;">&#9654; Show SQL Script</A></TD></TR>');
		l_o(' <TR id="s1sql86" style="display:none">');	
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
    l_o('        SELECT files.filename,ver2.version,ver2.last_update_date  <br>');
	l_o('        FROM   ad_file_versions ver2,ad_files f2<br>');
	l_o('        	  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename<br> FROM     ad_file_versions ver, ad_files f<br>');
	l_o('        		 WHERE    f.file_id = ver.file_id<br> AND      (lower(f.filename) like<br>(''pqp'||v_leg||'%'')) <br>');
	l_o('        		 GROUP BY f.filename) files<br>');
	l_o('        WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id<br>');	
		l_o('        AND    files.file_version_id = ver2.file_version_id	and f2.app_short_name = ''PQP''<br>');
	l_o('        order by files.filename desc;<br>');
    l_o('          </blockquote><br></TD></TR><TR>');    
	l_o(' <TH><B>Filename</B></TD><TH><B>Version</B></TD><TH><B>Last update</B></TD>');
	
    :n := dbms_utility.get_time;
     open c_pension;
			loop
				fetch c_pension into v_filename, v_version, v_update;
				EXIT WHEN  c_pension%NOTFOUND;
				l_o('<TR><TD>'||v_filename||'</TD>'||chr(10)||'<TD>'||v_version||'</TD>'||chr(10)||'<TD>'||v_update||'</TD></TR>'||chr(10));
			end loop;
		close c_pension;
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> ');
	l_o('</div>');
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure rti is		
    cursor c_assignment is
        select information_type
			,      decode(active_inactive_flag,'Y','Active','N','Inactive')
			,      multiple_occurences_flag
			,      creation_date
			,      last_update_date
			from PER_ASSIGNMENT_INFO_TYPES
			where information_type like 'GB%RTI%';
	v_info_type PER_ASSIGNMENT_INFO_TYPES.information_type%type;
	v_flag varchar2(10);
	v_m_flag PER_ASSIGNMENT_INFO_TYPES.multiple_occurences_flag%type;
	v_date PER_ASSIGNMENT_INFO_TYPES.creation_date%type;
	v_date2 PER_ASSIGNMENT_INFO_TYPES.last_update_date%type;
	cursor c_modules is
		select module_id, module_name, description, application_id from PQP_CONFIGURATION_MODULES where LEGISLATION_CODE='GB' and MODULE_NAME like 'Real Time Information';     
	v_id PQP_CONFIGURATION_MODULES.module_id%type;
	v_name PQP_CONFIGURATION_MODULES.module_name%type;
	v_desc PQP_CONFIGURATION_MODULES.description%type;
	v_appl_id PQP_CONFIGURATION_MODULES.application_id%type;
	cursor c_types is
		select configuration_type, module_id, decode(active_inactive_flag,'Y','Active','Inactive'), 
		Description, multiple_occurences_flag, protected_flag, creation_date from PQP_CONFIGURATION_TYPES 
		where MODULE_ID in (select MODULE_ID from PQP_CONFIGURATION_MODULES where LEGISLATION_CODE='GB' and MODULE_NAME like 'Real Time Information') 
		and CONFIGURATION_TYPE ='PAY_GB_RTI_FPS_BACS' ;   
	v_type PQP_CONFIGURATION_TYPES.configuration_type%type;
	v_descr2 PQP_CONFIGURATION_TYPES.Description%type;
	v_flag2 PQP_CONFIGURATION_TYPES.protected_flag%type;
	
	cursor c_values is
		select configuration_value_id, business_group_id, pcv_information_category, pcv_information1, pcv_information2, creation_date, configuration_name 
		from pqp_configuration_values where PCV_INFORMATION_CATEGORY like 'PAY_GB_RTI%';
	v_conf_id pqp_configuration_values.configuration_value_id%type;
	v_bg pqp_configuration_values.business_group_id%type;
	v_pcv pqp_configuration_values.pcv_information_category%type;
	v_pcv1 pqp_configuration_values.pcv_information1%type;
	v_pcv2 pqp_configuration_values.pcv_information2%type;
	v_config pqp_configuration_values.configuration_name%type;
	v_column1	VARCHAR2(50);
	v_column2	VARCHAR2(50);
	v_column3	VARCHAR2(50);
	v_rows number;
	issue boolean:=false;
	v_sql varchar2(1000);
	v_cursorid number;
	v_dummy	INTEGER;
begin
			
	l_o('<br><DIV class=divItem>');
	l_o('<DIV id="s1sql91b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql91'');" href="javascript:;">&#9654; Assignment extra information setup</A></DIV>');		
			
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql91" style="display:none" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>PER_ASSIGNMENT_INFO_TYPES:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql92'');" href="javascript:;">&#9654; Show SQL Script</A></TD></TR>');
    l_o(' <TR id="s1sql92" style="display:none">');
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
	l_o('        select information_type<br>');
	l_o(',decode(active_inactive_flag,''Y'',''Active'',''N'',''Inactive'')<br>');
	l_o(',multiple_occurences_flag,creation_date,last_update_date<br>');
	l_o('from PER_ASSIGNMENT_INFO_TYPES<br>');
	l_o('where information_type like ''GB%RTI%'';<br>');
    l_o('          </blockquote><br></TD></TR><TR>');    
	l_o(' <TH><B>Information Type</B></TD><TH><B>Active/Inactive Flag</B></TD>');
	l_o(' <TH><B>Multiple Occurences Flag</B></TD><TH><B>Cration date</B></TD>');
	l_o(' <TH><B>Last update date</B></TD>');
	
    :n := dbms_utility.get_time;
    
		
    open c_assignment;
        loop
            fetch c_assignment into v_info_type,v_flag,v_m_flag,v_date,v_date2;
            EXIT WHEN  c_assignment%NOTFOUND;
            l_o('<TR><TD>'||v_info_type||'</TD>'||chr(10)||'<TD>'||v_flag||'</TD>'||chr(10)||'<TD>'||v_m_flag||'</TD>'||chr(10));
			l_o('<TD>'||v_date||'</TD>'||chr(10)||'<TD>'||v_date2||'</TD></TR>'||chr(10));
        end loop;
    close c_assignment;                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> ');
	l_o('</div>');	
	
	l_o('<br><DIV class=divItem>');
						l_o('<DIV id="s1sql93b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql93'');" href="javascript:;">&#9654; RTI Configuration performed</A></DIV>');		
						l_o('<DIV id="s1sql93" style="display: none;">');
											
						l_o('<A class=detail onclick="displayItem(this,''s1sql94'');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; PQP CONFIGURATION MODULES</A>');
						l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql94" style="display:none" >');
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
						l_o('     <B>PQP CONFIGURATION MODULES:</B></font></TD>');
						l_o('     <TD bordercolor="#DEE6EF">');
						l_o('<A class=detail  id="s1sql95b"  onclick="displayItem2(this,''s1sql95'');" href="javascript:;">&#9654; Show SQL Script</A>');
						l_o('   </TD></TR><TR id="s1sql95" style="display:none">');
						l_o('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
						l_o('       <blockquote><p align="left">');			
						l_o('               select module_id, module_name, description, application_id from PQP_CONFIGURATION_MODULES<br>');
					    l_o('               where LEGISLATION_CODE=''GB'' and MODULE_NAME like ''Real Time Information''<br>');					   
						l_o('          </blockquote><br></TD></TR><TR>');
						l_o(' <TH><B>Module ID</B></TD><TH><B>Module Name</B></TD>');
						l_o(' <TH><B>Description</B></TD><TH><B>Application ID</B></TD>');
					  
	
						:n := dbms_utility.get_time;
						 open c_modules;
						  loop
							fetch c_modules into v_id ,v_name ,v_desc, v_appl_id;
							EXIT WHEN  c_modules%NOTFOUND;
							l_o('<TR><TD>'||v_id||'</TD>'||chr(10)||'<TD>'||v_name||'</TD>'||chr(10));							
							l_o('<TD>'||v_desc||'</TD>'||chr(10)||'<TD>'||v_appl_id||'</TD></TR>'||chr(10));	
						  end loop;
						  close c_modules;
						  
						:n := (dbms_utility.get_time - :n)/100;
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
						l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						l_o(' </TABLE>  ');	
						
		
						l_o('<br><br><A class=detail onclick="displayItem(this,''s1sql96'');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; PQP CONFIGURATION TYPES</A>');
						l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql96" style="display:none" >');
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o('   <TH COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri">');
						l_o('     <B>PQP CONFIGURATION TYPES:</B></font></TD>');
						l_o('     <TD bordercolor="#DEE6EF">');
						l_o('<A class=detail  id="s1sql97b"  onclick="displayItem2(this,''s1sql97'');" href="javascript:;">&#9654; Show SQL Script</A>');
						l_o('   </TD></TR>');
						l_o(' <TR id="s1sql97" style="display:none">');
						l_o('    <TD BGCOLOR=#DEE6EF colspan="6" height="60">');
						l_o('       <blockquote><p align="left">');
						l_o('select configuration_type, module_id, decode(active_inactive_flag,''Y'',''Active'',''Inactive''),<br>'); 
						l_o('Description, multiple_occurences_flag, protected_flag, creation_date from PQP_CONFIGURATION_TYPES <br>'); 
						l_o('where MODULE_ID in (select MODULE_ID from PQP_CONFIGURATION_MODULES where LEGISLATION_CODE=''GB'' and MODULE_NAME like ''Real Time Information'')  <br>');
						l_o('and CONFIGURATION_TYPE =''PAY_GB_RTI_FPS_BACS'' <br>');					
						l_o(' </blockquote><br> </TD></TR><TR>');
						l_o(' <TH><B>Configuration Type</B></TD><TH><B>Module ID</B></TD>');
						l_o(' <TH><B>Active Inactive flag</B></TD><TH><B>Description</B></TD>');
						l_o(' <TH><B>Multiple occurences flag</B></TD><TH><B>Protected flag</B></TD>');
						l_o(' <TH><B>Creation date</B></TD>');				
						
						:n := dbms_utility.get_time;
						 open c_types;
						  loop
							fetch c_types into v_type,v_id,v_flag,v_descr2,v_m_flag,v_flag2,v_date;
							EXIT WHEN  c_types%NOTFOUND;
							l_o('<TR><TD>'||v_type||'</TD>'||chr(10)||'<TD>'||v_id||'</TD>'||chr(10));							
							l_o('<TD>'||v_flag||'</TD>'||chr(10)||'<TD>'||v_descr2||'</TD>'||chr(10));
							l_o('<TD>'||v_m_flag||'</TD>'||chr(10)||'<TD>'||v_flag2||'</TD>'||chr(10)||'<TD>'||v_date||'</TD></TR>'||chr(10));	
						  end loop;
						  close c_types;
						  
						:n := (dbms_utility.get_time - :n)/100;
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o(' <TH COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri">');
						l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						l_o(' </TABLE>  ');								
	
						l_o('<br><br><A class=detail onclick="displayItem(this,''s1sql98'');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; PCV INFORMATION CATEGORY</A>');
						l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql98" style="display:none" >');
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o('   <TH COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri">');
						l_o('     <B>PCV INFORMATION CATEGORY:</B></font></TD>');
						l_o('     <TD bordercolor="#DEE6EF">');
						l_o('<A class=detail  id="s1sql99b"  onclick="displayItem2(this,''s1sql99'');" href="javascript:;">&#9654; Show SQL Script</A>');
						l_o('   </TD></TR>');
						l_o(' <TR id="s1sql99" style="display:none">');
						l_o('    <TD BGCOLOR=#DEE6EF colspan="6" height="60">');
						l_o('       <blockquote><p align="left">');
						l_o('select configuration_value_id, business_group_id, pcv_information_category,<br>'); 
					    l_o('pcv_information1, pcv_information2, creation_date, configuration_name<br>');
					    l_o('from pqp_configuration_values where PCV_INFORMATION_CATEGORY like ''PAY_GB_RTI%''<br>');					   						
						l_o(' </blockquote><br></TD></TR><TR>');
						l_o(' <TH><B>Configuration Value ID</B></TD><TH><B>Business Group ID</B></TD>');
						l_o(' <TH><B>PCV information category</B></TD><TH><B>PCV information 1</B></TD>');	
						l_o(' <TH><B>PCV information 2</B></TD><TH><B>Creation date</B></TD>');	
						l_o(' <TH><B>Configuration Name</B></TD>');	
												
						:n := dbms_utility.get_time;
						 open c_values;
						  loop
							fetch c_values into v_conf_id,v_bg,v_pcv,v_pcv1,v_pcv2,v_date,v_config;
							EXIT WHEN  c_values%NOTFOUND;
							l_o('<TR><TD>'||v_conf_id||'</TD>'||chr(10)||'<TD>'||v_bg||'</TD>'||chr(10));							
							l_o('<TD>'||v_pcv||'</TD>'||chr(10)||'<TD>'||v_pcv1||'</TD>'||chr(10));
							l_o('<TD>'||v_pcv2||'</TD>'||chr(10)||'<TD>'||v_date||'</TD>'||chr(10)||'<TD>'||v_config||'</TD></TR>'||chr(10));						
						  end loop;
						  close c_values;
						  
						  :n := (dbms_utility.get_time - :n)/100;					
					l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
					l_o(' <TH COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri">');
					l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
					l_o(' </TABLE>  ');					
					l_o('</div></div>');
	select count(1) into v_rows from dba_tables where table_name='PAY_GB_FPS_DETAILS';
	if v_rows>0 then
	l_o('<br><DIV class=divItem>');
	l_o('<DIV id="s1sql101b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql101'');" href="javascript:;">&#9654; Orphan FPS Records</A></DIV>');		
			
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql101" style="display:none" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Orphan FPS Records:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql102'');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD></TR>');
    l_o(' <TR id="s1sql102" style="display:none">');
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
	l_o('        SELECT fps_pay_act_id,fps_effective_date,count(fps_asg_act_id) FROM pay_gb_fps_details<br>');
	l_o(' WHERE fps_pay_act_id NOT IN (SELECT ppa.payroll_action_id FROM pay_payroll_actions ppa) group by fps_pay_act_id,fps_effective_date');
    l_o('          </blockquote><br>');
    l_o('     </TD></TR>');
    l_o(' <TR><TH><B>FPS Pay Act ID</B></TD><TH><B>FPS Effective Date</B></TD>');
	l_o(' <TH><B>Count (FPS Asg Act ID)</B></TD>');
    :n := dbms_utility.get_time;
	
								v_cursorid := DBMS_SQL.OPEN_CURSOR;

								v_sql := 'SELECT   fps_pay_act_id,fps_effective_date,count(fps_asg_act_id) FROM  pay_gb_fps_details WHERE  fps_pay_act_id NOT IN (SELECT   ppa.payroll_action_id FROM  pay_payroll_actions ppa) group by fps_pay_act_id,fps_effective_date';
										 
										 DBMS_SQL.PARSE(v_cursorid, v_sql, dbms_sql.native);										 
										 DBMS_SQL.DEFINE_COLUMN(v_cursorid, 1, v_column1, 50);
										 DBMS_SQL.DEFINE_COLUMN(v_cursorid, 2, v_column2, 50);
										 DBMS_SQL.DEFINE_COLUMN(v_cursorid, 3, v_column3, 50);
										 v_dummy := DBMS_SQL.EXECUTE(v_cursorid);
										 LOOP
											  IF DBMS_SQL.FETCH_ROWS(v_cursorid) = 0 then
												   exit;
											  END IF;								
											  DBMS_SQL.COLUMN_VALUE(v_cursorid,1,v_column1);
											  DBMS_SQL.COLUMN_VALUE(v_cursorid,2,v_column2);
											  DBMS_SQL.COLUMN_VALUE(v_cursorid,3,v_column3);
											  l_o('<TR><TD>'||v_column1||'</TD>'||chr(10)||'<TD>'||v_column2||'</TD>'||chr(10)||'<TD>'||v_column3||'</TD></TR>'||chr(10));
												issue:=TRUE;											  
										 END LOOP;
										 

										 DBMS_SQL.CLOSE_CURSOR(v_cursorid);
								
								:n := (dbms_utility.get_time - :n)/100; 
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> ');
	l_o('</div>');	
	if issue then
		:w29:=:w29+1;
		l_o('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning:</span> Rollback has been used recently or in the past for the FPS Process. For the FPS process GB Rollback has to be used, as datafix might be required.<br>');
		l_o('Refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1589654.1" target="_blank">Note 1589654.1</a> FPS Rolled Back Using ROLLBACK Not GB ROLLBACK - Datafix Required<br></div>');
	else
		l_o('<div class="divok"><img class="check_ico">OK! No orphan FPS record.</div>');
	end if;	
	end if;

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;




procedure uk is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'GB'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page29" style="display: none;">');header('United Kingdom');
			l_o('<div class="divSection">');l_o('<a name="UnitedKingdomp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
				if (:apps_rel like '12.2%') then
					dpatch('GB','19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then
					dpatch('GB','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('GB','20513833','RTI GB UPDATE NI CATEGORY ERRORS');
					dpatch('GB','20066028','PENSERVER LEGISLATIVE CHANGES');
					dpatch('GB','20314902','YEAR END 2014-15 / START OF YEAR 2015-16');
					dpatch('GB','20201659','UK YEAR END 2014-15 / START OF YEAR 2015-16');	
					dpatch('GB','19223877','P11D LEGISLATIVE CHANGES for 2014-15');
					dpatch('GB','20591016','SHARED PARENTAL LEAVE AND PAY CHANGES');
					dpatch('GB','20692428','TAX YEAR END BUG FIXES');
					dpatch('GB','20888184','TAX YEAR END BUG FIXES');
					dpatch('GB','21033080','PENSIONS AUTOMATIC ENROLMENT/RE-ENROLMENT LEGISLATIVE CHANGES');
				elsif (:apps_rel like '12.0%') then
					dpatch('GB','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('GB','18776254','RTI CONSOLIDATED PATCH: SEPTEMBER 2014');
					dpatch('GB','18972503','RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES');
					dpatch('GB','18693666','DIRECT EARNINGS ATTACHMENT CHANGES: PHASE2');		
					dpatch('GB','18453569','LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme');
					dpatch('GB','18333366','DIRECT EARNINGS ATTACHMENT CHANGES');
					dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
					dpatch('GB','18285764', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/LGPS CHANGES');					
					dpatch('GB','18100149','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014');
					dpatch('GB','17274247','RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH');
				elsif :apps_rel like '11.5%' then
					dpatch('GB','17774746', 'HR_PF.K.RUP.9');
					l_o('<div class="divok">');
					l_o('Note: These patches are only available with ACS Service, please refer ');
					l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1597416.1" target="_blank">Note 1597416.1</a> Payroll Legislative Updates for Oracle E-Business Suite 11.5.10:<br>');
					l_o('</div');
					dpatch('GB','18776031','RTI CONSOLIDATED PATCH: SEPTEMBER 2014');
					dpatch('GB','18972450','RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES');
					dpatch('GB','18449320','LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme');
					dpatch('GB','18333164','DIRECT EARNINGS ATTACHMENT CHANGES');
					dpatch('GB','18305045','UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014');
					dpatch('GB','18293579','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /P11D/LGPS CHANGES');
					dpatch('GB','18285780','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /LGPS CHANGES');
					dpatch('GB','18100105','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014');					
					dpatch('GB','18032762','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014:PHASE2 PATCH');					
					dpatch('GB','17964873','UK TAX YEAR END CHANGES 2013 - 2014');
					dpatch('GB','17274234','RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH');		
				end if;							
			l_o('</div>');
				if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
								l_o('</div>');							
							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
								l_o('</div>');								
							elsif :rup_level='13774477' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('GB','16373594','TYE13 P11D LEGISLATIVE CHANGES FOR 2012-2013');
								l_o('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then
							if :rup_level='14488556' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('GB','18305045','UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014');	
								l_o('</div>');							
							
							end if;				
					end if;	
			end if;
						
			l_o('</div><br>'); 
			l_o('<a name="UnitedKingdomd"></a>');datainstall('GB',29);
			l_o('<a name="UnitedKingdoms"></a>');bg_generic('GB',29);
			rti();
			l_o('</div>');
			l_o('<a name="UnitedKingdomv"></a>');file_version('gb');
			file_version_uk();
			l_o('</div>');
			documents('1499667.1','UK Real Time Information, RTI, Known Issues','1324671.1','EBS UK Payroll : Real Time Information (RTI) White Paper and Patch Information');
			documents('1504309.2','Information Center: Oracle HRMS (UK)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure nor is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NO'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page21" style="display: none;">');header('Norway');
			l_o('<div class="divSection">');l_o('<a name="Norwayp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('NO','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('NO','21327657', 'NO: Half tax calculation');
				elsif (:apps_rel like '12.1%') then					
					dpatch('NO','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('NO','21327657', 'NO: Half tax calculation');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('NO','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('NO','14177955', 'Delivers the K27 reimbursement file upload');			
				elsif :apps_rel like '11.5%' then					
					dpatch('NO','12807777', 'HR_PF.K.RUP.7');
					dpatch('NO','14171993', 'Delivers the K27 reimbursement file upload');				
				end if;												
			l_o('</div>');
			l_o('</div><br>'); l_o('<a name="Norwayd"></a>');datainstall('NO',21);
			l_o('<a name="Norways"></a>');bg_generic('NO',21);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure nz is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NZ'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page22" style="display: none;">');header('New Zealand');
			l_o('<div class="divSection">');l_o('<a name="NewZealandp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('NZ','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('NZ','20699005', 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('NZ','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('NZ','20699005', 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('NZ','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('NZ','11867792','R12.PER.A - NEW ZEALAND CUMULATIVE RELEASE R12.NZ.08');	
					dpatch('NZ','13697009','R12.PER.A - NZ STATUTORY UPDATES 2012');					
				elsif :apps_rel like '11.5%' then					
					dpatch('NZ','12807777', 'HR_PF.K.RUP.7');
					dpatch('NZ','11867781','NEW ZEALAND CUMULATIVE RELEASE 11i.NZ.08');
					dpatch('NZ','13627558','NZ STATUTORY UPDATES 2012');					
				end if;													
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if :apps_rel like '12.2%' then
						l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NZ','19245681', 'NEW ZEALAND CONSOLIDATED PATCH ABOVE- 12.2.3');	
								l_o('</div>');
					elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777'  then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NZ','13627558', ' 11I - NZ STATUTORY UPDATES - 2012 ');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="NewZealandd"></a>');datainstall('NZ',22);
			l_o('<a name="NewZealands"></a>');bg_generic('NZ',22);
			l_o('</div>');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure pl is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'PL'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page23" style="display: none;">');header('Poland');
			datainstall('PL',23);
			bg_generic('PL',23);
			l_o('</div>');	
			documents('1527959.2','Information Center: Oracle HRMS (Poland)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure ru is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'RU'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page24" style="display: none;">');header('Rusia');
			datainstall('RU',24);
			bg_generic('RU',24);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure sa is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SA'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page25" style="display: none;">');header('Saudi Arabia');
			l_o('<div class="divSection">');l_o('<a name="SaudiArabiap"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('SA','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('SA','18723486', 'SA Unemployment insurance changes');
				elsif (:apps_rel like '12.1%') then					
					dpatch('SA','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('SA','18723486', 'SA Unemployment insurance changes');
					dpatch('SA','19054295', 'Can not create absence');
				elsif (:apps_rel like '12.0%') then					
					dpatch('SA','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('SA','18760981', 'SA Unemployment insurance changes');
				elsif :apps_rel like '11.5%' then					
					dpatch('SA','12807777', 'HR_PF.K.RUP.7');				
				end if;												
			l_o('</div></div><br>'); l_o('<a name="SaudiArabiad"></a>');datainstall('SA',25);
			l_o('<a name="SaudiArabias"></a>');bg_generic('SA',25);
			l_o('</div></div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure se is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SE'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page26" style="display: none;">');header('Sweden');
			l_o('<div class="divSection">');l_o('<a name="Swedenp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('SE','19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('SE','20000288', 'R12.HR_PF.B.delta.8');										
				elsif (:apps_rel like '12.0%') then					
					dpatch('SE','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('SE','12589129', 'Delivers the Sweden legislative changes for 2011');				
				elsif :apps_rel like '11.5%' then					
					dpatch('SE','12807777', 'HR_PF.K.RUP.7');
					dpatch('SE','10393370', 'Delivers the Sweden legislative changes for 2011');
				end if;												
			l_o('</div>');
			l_o('</div><br>'); l_o('<a name="Swedend"></a>');datainstall('SE',26);
			l_o('<a name="Swedens"></a>');bg_generic('SE',26);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure sg is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SG'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page27" style="display: none;">');header('Singapore');
			l_o('<div class="divSection">');l_o('<a name="Singaporep"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			 if (:apps_rel like '12.2%') then					
					dpatch('SG','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('SG','20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');	
				elsif (:apps_rel like '12.1%') then					
					dpatch('SG','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('SG','20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('SG','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('SG','20055967','IRAS and IR21 CHANGES EOY 2014');										
				elsif :apps_rel like '11.5%' then					
					dpatch('SG','12807777', 'HR_PF.K.RUP.7');
					dpatch('SG','17188127','SG.35 SINGAPORE CONSOLIDATED PATCH');				
				end if;													
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then	
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');
								l_o('</div>');
					elsif (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','17651515','R121.SG.36 - SINGAPORE HRMS CONSOLIDATED PATCH');
								l_o('</div>');							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','17651515','R12.SG.36 - SINGAPORE HRMS CONSOLIDATED PATCH');
								l_o('</div>');	
							elsif  :rup_level='13774477' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','17173295','R12.SG.35 - SINGAPORE HRMS CONSOLIDATED PATCH');
								l_o('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777'  then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','17188127','SINGAPORE CUMULATIVE RELEASE SG.35');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="Singapored"></a>');datainstall('SG',27);
			l_o('<a name="Singapores"></a>');bg_generic('SG',27);
			l_o('</div>');	
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

procedure ae is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AE'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page28" style="display: none;">'); header('United Arab Emirates');
			l_o('<div class="divSection">');l_o('<a name="UnitedArabEmiratesp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('AE','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('AE','19900524','UAE National identifier validation changes');
					dpatch('AE','20075576','UAE National identifier validation changes and Formula Result rule for KW SI');
				elsif (:apps_rel like '12.1%') then					
					dpatch('AE','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('AE','19900524','UAE National identifier validation changes');
					dpatch('AE','19819953','ROUTING NUMBER IN UAE LEGISLATION');
				elsif (:apps_rel like '12.0%') then					
					dpatch('AE','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('AE','19900524','UAE National identifier validation changes');
					dpatch('AE','19819953','ROUTING NUMBER IN UAE LEGISLATION');
				elsif :apps_rel like '11.5%' then					
					dpatch('AE','12807777', 'HR_PF.K.RUP.7');					
				end if;											
			l_o('</div>');
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('AE','17449352', 'AFTER UPGRADE 12.1.3,ORA-00904:"U1": INVALID IDENTIFIER WHEN VIEW ITD BALANCE');
								l_o('</div>');
					end if;		
			end if;
			l_o('</div><br>');l_o('<a name="UnitedArabEmiratesd"></a>'); datainstall('AE',28);
			l_o('<a name="UnitedArabEmiratess"></a>');bg_generic('AE',28);
			l_o('</div>');	
			documents('1506985.2','Information Center: Oracle HRMS (United Arab Emirates)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure za is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'ZA'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page31" style="display: none;">');header('South Africa');
			l_o('<div class="divSection">');l_o('<a name="SouthAfricap"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('ZA','19193000', 'R12.HR_PF.C.Delta.6');	
					dpatch('ZA','21499164', 'INTEREST RATE GLOBAL VALUE CHANGE EEFECTIVE FROM 01-AUG-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('ZA','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('ZA','21499164', 'INTEREST RATE GLOBAL VALUE CHANGE EEFECTIVE FROM 01-AUG-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('ZA','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('ZA','19544341', 'ZA: AUGTYE14 REPORTING CHANGES');
				elsif :apps_rel like '11.5%' then					
					dpatch('ZA','12807777', 'HR_PF.K.RUP.7');	
					dpatch('ZA','17366859', 'ZA : Tax Audit report');					
				end if;													
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
						l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','20812316', 'ZA: COIDA LIMIT CHANGED EFFECTIVE FROM 1 APRIL 2015');
								l_o('</div>');
					elsif (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','20812316', 'ZA: COIDA LIMIT CHANGED EFFECTIVE FROM 1 APRIL 2015');
								l_o('</div>');							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','19544341', 'ZA: AUGTYE14 REPORTING CHANGES');
								l_o('</div>');
							elsif  :rup_level='13774477' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','16543654','ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013 TO R312 480');
								dpatch('ZA','16654857','SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');
								l_o('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='14488556' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','16543639', 'ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013');
								dpatch('ZA','16654854', 'SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');	
								l_o('</div>');
							elsif :rup_level='12807777'  then		
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','16543639', 'ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013');
								dpatch('ZA','16654854', 'SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="SouthAfricad"></a>');datainstall('ZA',31);
			l_o('<a name="SouthAfricas"></a>');bg_generic('ZA',31);
			l_o('</div>');	
			documents('1514993.2','Information Center: Oracle HRMS (South African)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
	end;

procedure us is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'US'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page30" style="display: none;">');header('United States');
			
			l_o('<a name="UnitedStatesg"></a>');geocode('US');	
			l_o('<a name="UnitedStatesq"></a>');Quantum('US');
			l_o('<a name="UnitedStatesj"></a>');jit('US');
			l_o('<br><div class="divSection">');l_o('<a name="UnitedStatesp"></a>');
			l_o('<div class="divSectionTitle">Patching</div><br><div class="divItem"><div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then							
					dpatch('US','19193000', 'R12.HR_PF.C.Delta.6');					
					dpatch('US','21142484','Q2 2015 Statutory and JIT Update');
					dpatch('US','20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.1%') then								
					dpatch('US','20000288', 'R12.HR_PF.B.delta.8');					 
					dpatch('US','21142484','Q2 2015 Statutory and JIT Update');
					dpatch('US','20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.0%') then					
					dpatch('US','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('US','19507770','Q3 2014 Statutory and JIT Update');
					dpatch('US','19701971','End of Year 2014 Phase 1');
					dpatch('US','20212223','End of Year 2014 Phase 2');
					dpatch('US','20365000','End of Year 2014 Phase 3');
				elsif :apps_rel like '11.5%' then					
					dpatch('US','17774746', 'HR_PF.K.RUP.9');					
					dpatch('US','21142464','Q2 2015 Statutory and JIT Update');
					dpatch('US','20364999','End of Year 2014 Phase 3');
					dpatch('US','20301513','Year Begin 2015 Statutory Update 2');
					dpatch('US','20212121','Year Begin 2015 Statutory Update');
				end if;	
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.%') then							
							l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
							dpatch('US','20365000','End of Year 2014 Phase 3');
							l_o('</div>');						
						elsif :apps_rel like '11.5%' then
								l_o('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('US','20364999','End of Year 2014 Phase 3');	
								l_o('</div>');				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="UnitedStatesd"></a>');datainstall('US',30);
			l_o('<a name="UnitedStatess"></a>');bg_generic('US',30);
			l_o('</div>');	
			l_o('<a name="UnitedStatespdf"></a>');pdf_reports('US');
			documents('1527958.2','Information Center: Oracle HRMS (US)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

-- 3rd program (split because "program too long" error)
begin  -- begin1

  begin -- begin MAIN
	:g_curr_loc:=1;
	:v_link_no:=1;
	DBMS_LOB.CREATETEMPORARY(:g_hold_output3,TRUE,DBMS_LOB.SESSION);
        l_o('<BR>'); 	
		
	l_o('</div>');
	au();
	be();
	ca();	
	cn();
	es();
	de();
	dk();
	fi();
	fr();
	hk();
	hu();
	ind();
	it();
	jp();
	kr();
	kw();
	mx();
	nor();
	nz();
	pl();
	ru();
	sa();
	se();
	sg();
	ae();

	za();	
	uk();	
	us();		

	l_o('<!-');
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');

end;
end;
/

-- Print output
print :g_hold_output3


variable g_hold_output4 clob;
declare
   counter      number       := 0;
   failures     number       := 0;   
   issuep boolean := FALSE;

/* Global defaults for SQL output formatting */
   g_sql_date_format   varchar2(100) := 'DD-MON-YYYY HH24:MI';

/* Global variables set by Set_Client which can be used throughout a script */
   g_user_id      number;
   g_resp_id      number;
   g_appl_id      number;
   g_org_id       number;

/* Global variable set by Set_Client or Get_DB_Apps_Version which can
   be referenced in scripts which branch based on applications release */

   g_appl_version varchar2(10);

   type V2T is table of varchar2(32767);
   

-- Write html format
procedure l_o (text varchar2) is
   l_ptext      varchar2(32767);
   l_hold_num   number;
   l_ptext2      varchar2(32767);
   l_hold_num2   number;
begin
   l_hold_num := mod(:g_curr_loc, 32767);
   
   l_hold_num2 := mod(:g_curr_loc, 14336);
   if l_hold_num2 + length(text) > 14000 then
      l_ptext2 := '                                                                                                                                                                                               ';
      dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	   dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  
   end if;
   
   l_hold_num2 := mod(:g_curr_loc, 18204);
   if l_hold_num2 + length(text) > 17900 then
      l_ptext2 := '                                                                                                                                                                                              ';
      dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	 
	  dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
		dbms_lob.write(:g_hold_output4, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	  
   end if;
   
   if l_hold_num + length(text) > 32759 then
      l_ptext := '<!--' || rpad('*', 32761-l_hold_num,'*') || '-->';
      dbms_lob.write(:g_hold_output4, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output4, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output4, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output4, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
   end if;
   dbms_lob.write(:g_hold_output4, length(text)+1, :g_curr_loc, text || chr(10));
   :g_curr_loc := :g_curr_loc + length(text)+1;
   
  -- dbms_lob.write(:g_hold_output4, length(text), :g_curr_loc, text );
  -- :g_curr_loc := :g_curr_loc + length(text);
   
end l_o;	
	

	
	
procedure header (v_leg varchar2) is
begin
			l_o('<div class="divSection"><div class="divSectionTitle">');		
			l_o('<div class="left"  id="'||replace(v_leg,' ','')||'" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">'||v_leg); 
			l_o('</div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
			l_o('<a class="detail" onclick="openall();" href="javascript:;"><font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
			l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
			l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a></div><div class="clear"></div></div><br>');
			l_o('<div class="divItem"><div class="divItemTitle">In This Section</div>');
			l_o('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
			l_o('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');	  
			l_o('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br></td><td class="toctable">');
			l_o('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			l_o('<a href="#'||replace(v_leg,' ','')||'v">Versions</a> <br>');			
			l_o('</td></tr></table>');
			l_o('</div></div><br>');
end;
procedure file_version (v_leg varchar2) is
	v_exists number;
    v_filename ad_files.filename%type;
	v_version ad_file_versions.version%type;
    v_update ad_file_versions.last_update_date%type;		
    cursor c_pension is
        SELECT files.filename,ver2.version,ver2.last_update_date
			FROM   ad_file_versions ver2,ad_files f2
				  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename
					 FROM     ad_file_versions ver, ad_files f
					 WHERE    f.file_id = ver.file_id
					 AND      (lower(f.filename) like
								('pqp'||v_leg||'%')) 
					AND (lower(f.filename) not like '%.pk_')
					 GROUP BY f.filename) files
			WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id
			AND    files.file_version_id = ver2.file_version_id	and f2.app_short_name = 'PQP'
			order by files.filename desc;
	
	cursor package_vers is
		  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type) v_type,
		  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 ) v_file , 
		  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4) v_ver
		  from dba_source 
		  where (upper(name) like ('%PQP_'||upper(v_leg)||'%')) and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and owner='APPS'  and type in('PACKAGE','PACKAGE BODY') 
		  and line =2 
		  order by Name; 
    cursor package_vers_ie is
		  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type) v_type,
		  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 ) v_file , 
		  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4) v_ver
		  from dba_source 
		  where (lower(name) like ('p%yie%')) and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and owner='APPS'  and type in('PACKAGE','PACKAGE BODY') 
		  and line =2 
		  order by Name;
		  
	cursor c_ie is
		SELECT files.filename,ver2.version,ver2.last_update_date 
			FROM ad_file_versions ver2,ad_files f2
			, (SELECT MAX (ver.file_version_id) file_version_id, f.filename
			FROM ad_file_versions ver, ad_files f
			WHERE f.file_id = ver.file_id
			AND (lower(f.filename) like
			('p%yie%')) 
			AND (lower(f.filename) not like '%.pk_')
			GROUP BY f.filename) files
			WHERE files.filename = f2.filename AND f2.file_id = ver2.file_id
			AND files.file_version_id = ver2.file_version_id and f2.app_short_name = 'PAY'
			order by files.filename desc;

begin
	
	l_o('<br><div class="divSection">' );
	l_o('<div class="divSectionTitle">Versions</div><br>');
l_o('<DIV class=divItem>');
	CASE v_leg
	when 'nl' then
		l_o('<DIV id="s1sql103b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql103'');" href="javascript:;">&#9654; Pension packages</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql103" style="display:none" >');
	when 'gb' then
		l_o('<DIV id="s1sql104b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql104'');" href="javascript:;">&#9654; Pension packages</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql104" style="display:none" >');
	when 'ie' then
		l_o('<DIV id="s1sql105b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql105'');" href="javascript:;">&#9654; Ireland packages</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql105" style="display:none" >');
	else
	null;
	end case;	
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Packages versions:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    CASE v_leg
	when 'nl' then
		l_o('       <A class=detail  onclick="displayItem2(this,''s1sql106'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql106" style="display:none">');
	when 'gb' then
		l_o('       <A class=detail  onclick="displayItem2(this,''s1sql107'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql107" style="display:none">');
	when 'ie' then
		l_o('       <A class=detail  onclick="displayItem2(this,''s1sql108'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql108" style="display:none">');
	else
	null;
	end case;    
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
			l_o('          select Name as Package, <br>');
			l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
			l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
			l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
			l_o('          from dba_source <br>');		
			if v_leg in ('gb','nl') then
			l_o('          where (upper(name) like (''%PQP_'||v_leg||'%'')) <br>');
			elsif v_leg='ie' then	
			l_o('          where (lower(name) like (''p%yie%'')) <br>');
			end if;
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
		l_o('          order by Name;<br>');
		l_o('     </TD>');
    l_o('   </TR>');
    l_o(' <TR>');    
	l_o(' <TH><B>Package name</B></TD>'); 
	l_o(' <TH><B>Type</B></TD>');                        
    l_o(' <TH><B>Filename</B></TD>');
	l_o(' <TH><B>Version</B></TD>');
	
    :n := dbms_utility.get_time;
    
	if v_leg in ('gb','nl') then
	for pack_rec in package_vers loop   
						l_o('<TR><TD>'||pack_rec.name||'</TD>'||chr(10)||'<TD>'||pack_rec.v_type||'</TD>'||chr(10)||'<TD>');
						l_o(pack_rec.v_file||'</TD>'||chr(10)||'<TD>'||pack_rec.v_ver);
						l_o('</TD></TR>'||chr(10));
					end loop;
	 elsif v_leg='ie' then
	 for pack_rec in package_vers_ie loop   
						l_o('<TR><TD>'||pack_rec.name||'</TD>'||chr(10)||'<TD>'||pack_rec.v_type||'</TD>'||chr(10)||'<TD>');
						l_o(pack_rec.v_file||'</TD>'||chr(10)||'<TD>'||pack_rec.v_ver);
						l_o('</TD></TR>'||chr(10));
					end loop;
	 end if;
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> ');
	l_o('</div><br>');
	
	l_o('<DIV class=divItem>');
	CASE v_leg
	when 'nl' then
		l_o('<DIV id="s1sql82b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql82'');" href="javascript:;">&#9654; Pension functionality files</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql82" style="display:none" >');
	when 'gb' then
		l_o('<DIV id="s1sql83b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql83'');" href="javascript:;">&#9654; Pension functionality files</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql83" style="display:none" >');
	when 'ie' then
		l_o('<DIV id="s1sql84b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql84'');" href="javascript:;">&#9654; Ireland code file versions</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql84" style="display:none" >');
	else
	null;
	end case;	
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Pension functionality files:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    CASE v_leg
	when 'nl' then
		l_o('       <A class=detail  onclick="displayItem2(this,''s1sql85'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql85" style="display:none">');
	when 'gb' then
		l_o('       <A class=detail  onclick="displayItem2(this,''s1sql86'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql86" style="display:none">');
	when 'ie' then
		l_o('       <A class=detail  onclick="displayItem2(this,''s1sql87'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql87" style="display:none">');
	else
	null;
	end case;    
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
    l_o('        SELECT files.filename,ver2.version,ver2.last_update_date  <br>');

	l_o('        FROM   ad_file_versions ver2,ad_files f2<br>');
	l_o('        	  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename<br>');
	l_o('        		 FROM     ad_file_versions ver, ad_files f<br>');
	l_o('        		 WHERE    f.file_id = ver.file_id<br>');
	l_o('        		 AND      (lower(f.filename) like<br>');
	if v_leg in ('nl','gb') then
		l_o('        					(''pqp'||v_leg||'%'')) <br>'); 
	elsif v_leg='ie' then
		l_o('        					(''p%yie%'')) <br>'); 
	end if;
	l_o('        		 GROUP BY f.filename) files<br>');
	l_o('        WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id<br>');
	if v_leg in ('nl','gb') then
		l_o('        AND    files.file_version_id = ver2.file_version_id	and f2.app_short_name = ''PQP''<br>');
	elsif v_leg='ie' then
		l_o('       AND files.file_version_id = ver2.file_version_id and f2.app_short_name = ''PAY''<br>'); 
	end if;
	l_o('        order by files.filename desc;<br>');
    l_o('          </blockquote><br>');
    l_o('     </TD>');
    l_o('   </TR>');
    l_o(' <TR>');    
	l_o(' <TH><B>Filename</B></TD>');                        
    l_o(' <TH><B>Version</B></TD>');
	l_o(' <TH><B>Last update</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    if v_leg in ('nl','gb') then
		open c_pension;
			loop
				fetch c_pension into v_filename, v_version, v_update;
				EXIT WHEN  c_pension%NOTFOUND;
				l_o('<TR><TD>'||v_filename||'</TD>'||chr(10)||'<TD>'||v_version||'</TD>'||chr(10)||'<TD>'||v_update||'</TD></TR>'||chr(10));
			end loop;
		close c_pension;
    elsif v_leg='ie' then
		open c_ie;
			loop
				fetch c_ie into v_filename, v_version, v_update;
				EXIT WHEN  c_ie%NOTFOUND;
				l_o('<TR><TD>'||v_filename||'</TD>'||chr(10)||'<TD>'||v_version||'</TD>'||chr(10)||'<TD>'||v_update||'</TD></TR>'||chr(10));
			end loop;
		close c_ie;
	end if;	
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> ');
	l_o('</div>');
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;

 -- Display patch
procedure dpatch (v_leg varchar2, v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;	  
	  v_exists number;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								 case v_leg
									when  'AU' then
										:e2:=:e2+1;
									when 'BE' then 
										:e3:=:e3+1;
									when 'CA' then 	
										:e4:=:e4+1;
									when 'CN' then 
										:e5:=:e5+1;
									when 'ES' then
										:e6:=:e6+1;
									when 'DE' then 
										:e7:=:e7+1;
									when 'DK' then
										:e8:=:e8+1;
									when 'FI' then 
										:e9:=:e9+1;
									when 'FR' then 
										:e10:=:e10+1;
									when 'HK' then 	
										:e11:=:e11+1;
									when 'HU' then 
										:e12:=:e12+1;
									when 'IE' then 
										:e13:=:e13+1;
									when 'IN' then 
										:e14:=:e14+1;
									when 'IT' then 
										:e15:=:e15+1;
									when 'JP' then
										:e16:=:e16+1;
									when 'KR' then
										:e17:=:e17+1;
									when 'KW' then
										:e18:=:e18+1;
									when 'MX' then 
										:e19:=:e19+1;
									when 'NL' then 
										:e20:=:e20+1;
									when 'NO' then 
										:e21:=:e21+1;
									when 'NZ' then
										:e22:=:e22+1;
									when 'PL' then 
										:e23:=:e23+1;
									when 'RU' then
										:e24:=:e24+1;
									when 'SA' then 
										:e25:=:e25+1;									
									when 'SE' then 
										:e26:=:e26+1;
									when 'SG' then
										:e27:=:e27+1;
									when 'AE' then 	
										:e28:=:e28+1;
									when 'GB' then 
										:e29:=:e29+1;
									when 'US' then
										:e30:=:e30+1;
									when 'ZA' then
										:e31:=:e31+1;
									else
									null;
								end case;
								 issuep:=TRUE;
								 l_o('<div class="diverr">');
								 l_o('<img class="error_ico"><font color="red">Error: </font>Please plan to install ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');	
								 l_o('</div>');
							else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							l_o('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
						EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report in Note 1631780.1 <br>');
	end; 
	

procedure documents (v_no1 varchar2, v_note1 varchar2, v_no2 varchar2, v_note2 varchar2) is
begin
			l_o('<br><div class="divok">');
			l_o('Useful documentation:<br>');
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');			
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no2||'" target="_blank">Note '||v_no2||'</a> '||v_note2||'<br>');
			l_o('</div>');
end;
procedure documents (v_no1 varchar2, v_note1 varchar2) is
begin
			l_o('<br><div class="divok">');
			l_o('Useful documentation:<br>');
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');
			l_o('</div>');
end;

procedure datainstall (v_leg varchar2, v_no number) is
	v_exists number;
    v_apps hr_legislation_installations.application_short_name%type;
    v_action varchar2(20);
	v_date hr_legislation_installations.last_update_date%type; v_legislation hr_legislation_installations.legislation_code%type;	
    cursor di_actions is
        select 
		   legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION,   
		   decode(action,'F','Force Install'
						 ,'C','Clear'
						 ,'U','Upgrade'
						 ,'I','Install') ACTION,
		   last_update_date
		from hr_legislation_installations
		where (status is not null or action is not null)
		and legislation_code = v_leg;
	cursor rules is
		select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules
		where legislation_code = v_leg
		order by legislation_code;
	V_RULE_TYPE pay_legislation_rules.RULE_TYPE%type;
	V_RULE_MODE pay_legislation_rules.RULE_MODE%type;
begin
	l_o('<div class="divSection">' );
	l_o('<div class="divSectionTitle">Data install status</div><br>');			
	
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>DataInstaller actions:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql200'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD>');
    l_o(' </TR>');
    l_o(' <TR id="s1sql200'||v_no||'" style="display:none">');
    l_o('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
    l_o('       <blockquote><p align="left">');
    l_o('          select legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION, <br>');
    l_o('          decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'') ACTION,<br>');
    l_o('           last_update_date <br>');           
    l_o('           from hr_legislation_installations <br>');   
    l_o('           where (status is not null or action is not null)<br>');                  
    l_o('            and legislation_code = '''||v_leg||''';<br>');
    l_o('          </blockquote><br>');
    l_o('     </TD>');
    l_o('   </TR>');
    l_o(' <TR>');
    l_o(' <TH><B>Legislation</B></TD>');
	l_o(' <TH><B>Application Name</B></TD>');
    l_o(' <TH><B>Action</B></TD>');
    l_o(' <TH><B>Last Update Date</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open di_actions;
        loop
            fetch di_actions into  v_legislation , v_apps, v_action, v_date;
            EXIT WHEN  di_actions%NOTFOUND;
            l_o('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD></TR>'||chr(10));
        end loop;
    close di_actions;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> <br> ');
	l_o('</div>');
	
	l_o('<br><div class="divSection">' );
	l_o('<div class="divSectionTitle">Settings</div><br>');			
	l_o('<DIV class=divItem>');
	l_o('<DIV id="s1sql300'||v_no||'b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql300'||v_no||''');" href="javascript:;">&#9654; Pay Legislation Rules</A></DIV>');		
			
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql300'||v_no||'" style="display:none" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Pay Legislation Rules:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql301'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD>');
    l_o(' </TR>');
    l_o(' <TR id="s1sql301'||v_no||'" style="display:none">');
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
    l_o('        select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules  <br>');   
    l_o('        order by LEGISLATION_CODE;<br>');   
    l_o('           where legislation_code ='''||v_leg||''';<br>');
    l_o('          </blockquote><br>');
    l_o('     </TD>');
    l_o('   </TR>');
    l_o(' <TR>');    
	l_o(' <TH><B>Legislation</B></TD>');                        
    l_o(' <TH><B>Rule Type</B></TD>');
	l_o(' <TH><B>Rule Mode</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open rules;
        loop
            fetch rules into v_legislation, v_rule_type, v_rule_mode;
            EXIT WHEN  rules%NOTFOUND;
            l_o('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_rule_type||'</TD>'||chr(10)||'<TD>'||v_rule_mode||'</TD></TR>'||chr(10));
        end loop;
    close rules;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> ');
	l_o('</div>');
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure bg_nl (v_leg varchar2, v_no number) is
	v_bg hr_all_organization_units.organization_id%type;
	v_bg_name hr_all_organization_units.name%type;
	v_organization_structure_id per_organization_structures.organization_structure_id%type;
	v_os_name per_organization_structures.name%type;
	v_override_repl fnd_lookups.meaning%type;
	v_sender_tax_reporting_name hr_organization_information.org_information3%type;
	v_sender_tax hr_organization_information.org_information4%type;
	v_new_retropay_start_date hr_organization_information.org_information5%type;
	v_assignment_progress_group fnd_lookups.meaning%type;
	v_allow_employer_change fnd_lookups.meaning%type;
	cursor c_bg is
			SELECT   hou_bg.organization_id business_group_id
			,hou_bg.name business_group_name
			,organization_structure_id Organization_Hier_struc_id
			,org_struc.name Organization_Hierarchy 
			,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',org_information2) override_replacement_retropay
			,hoi.org_information3 sender_tax_reporting_name
			,hoi.org_information4 sender_tax_registration_number
			,hoi.org_information5 new_retropay_start_date
			,hr_general_utilities.get_lookup_meaning ('NL_APG_LEVEL',hoi.org_information6) assignment_progress_group
			,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',org_information8) allow_employer_change
				FROM     hr_organization_information hoi
						, (SELECT   name, organization_id FROM hr_all_organization_units)
						 hou_bg
						, (SELECT   name, organization_structure_id
						   FROM     per_organization_structures) org_struc
				WHERE    1 = 1
					 AND hoi.organization_id = hou_bg.organization_id
					 AND org_struc.organization_structure_id = hoi.org_information1
					 AND hoi.org_information_context LIKE 'NL_BG_INFO';
	v_short_name hr_organization_information.org_information1%type;			
			v_employee_number_generation fnd_lookups.meaning%type;
			v_applicant_number_generation fnd_lookups.meaning%type;
			v_contingent_worker_numb_gen fnd_lookups.meaning%type;
			v_grade_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_group_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_job_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_costing_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_position_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_competence_flex fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_currency hr_organization_information.org_information1%type;
			v_fiscal_year_start hr_organization_information.org_information1%type;
			v_minimum_working_age hr_organization_information.org_information1%type;
			v_maximum_working_age hr_organization_information.org_information1%type;
				
  v_parent_id hr_all_organization_units.organization_id%type;
  v_old number;
  v_parent_name hr_all_organization_units.name%type;
  v_child_id hr_all_organization_units.organization_id%type;
  v_child_name hr_all_organization_units.name%type;
 
  cursor c_hierarchy (t_bg  NUMBER) is
  SELECT  organization_id_parent
        ,hou_parent.name
        ,organization_id_child
        ,hou_child.name
		FROM     (SELECT       pose.business_group_id
							  ,pose.organization_id_parent
							  ,organization_id_child
				  FROM         per_org_structure_elements pose
				  CONNECT BY   pose.organization_id_parent =
								 PRIOR pose.organization_id_child
						   AND pose.org_structure_version_id =
								 (SELECT   posv.org_structure_version_id
								  FROM     per_organization_structures pos
										  ,per_org_structure_versions posv
								  WHERE    pos.organization_structure_id =
											 posv.organization_structure_id
									   AND to_char (pos.organization_structure_id) IN
											   (SELECT   org_information1
												FROM     hr_organization_information hoi
												WHERE    hoi.org_information_context IN
															 'NL_BG_INFO'
													 AND hoi.organization_id = t_bg)
									   AND sysdate BETWEEN posv.date_from
													   AND  nvl
															(
															  posv.date_to
															 ,hr_general.end_of_time
															))
				  START WITH   pose.organization_id_parent = t_bg
						   AND pose.org_structure_version_id =
								 (SELECT   posv.org_structure_version_id
								  FROM     per_organization_structures pos
										  ,per_org_structure_versions posv
								  WHERE    pos.organization_structure_id =
											 posv.organization_structure_id
									   AND to_char (pos.organization_structure_id) IN
											   (SELECT   org_information1
												FROM     hr_organization_information hoi
												WHERE    hoi.org_information_context =
														   'NL_BG_INFO'
													 AND hoi.organization_id = t_bg)
									   AND sysdate BETWEEN posv.date_from
													   AND  nvl
															(
															  posv.date_to
															 ,hr_general.end_of_time
															))
				  ORDER BY     pose.organization_id_parent) org_struc
				, (SELECT   name, organization_id FROM hr_all_organization_units)
				 hou_parent
				, (SELECT   name, organization_id FROM hr_all_organization_units)
				 hou_child
		WHERE    org_struc.organization_id_parent = hou_parent.organization_id
			 AND org_struc.organization_id_child = hou_child.organization_id;
	
	cursor c_abp (t_bg  NUMBER) is
	SELECT  hr_general_utilities.get_lookup_meaning
			 (
			   'HR_NL_YES_NO'
			  ,org_information2
			 ) Test_Environment
			,hoi.org_information1 Registration_Number
			,hoi.org_information3 Name
	FROM      hr_organization_information hoi			
	WHERE    1 = 1
		 AND hoi.org_information_context LIKE 'NL_ABP_SENDER_DETAILS'
		 AND hoi.organization_id = t_bg;

	v_test fnd_lookups.meaning%type;
	v_Registration_Number hr_organization_information.org_information1%type;
	v_org_information3 hr_organization_information.org_information3%type;
	
	cursor c_abp_type (t_bg  NUMBER) is
		SELECT   fnd_date.canonical_to_date (hoi.org_information1) date_from
				,fnd_date.canonical_to_date (hoi.org_information2) date_to
				,ppt.pension_type_name
				,hoi.org_information4 employee_contribution_percent
				,hoi.org_information5 employer_contribution_percent
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information6
				 )
				   valid
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information7
				 )
				   applicable_to_all_employees
		FROM     hr_organization_information hoi				
				, (SELECT   pension_type_id
						   ,pension_type_name
						   ,effective_start_date
						   ,effective_end_date
				   FROM     pqp_pension_types_f) ppt
		WHERE    1 = 1
			 AND hoi.org_information_context LIKE 'PQP_NL_ABP_PT'
			 AND fnd_date.canonical_to_date (hoi.org_information1) BETWEEN ppt.effective_start_date
																	   AND  ppt.effective_end_date
			 AND hoi.org_information3 = ppt.pension_type_id
			 AND hoi.organization_id = t_bg;    
	v_date_from  date;
	v_date_to date;
	v_pension_type_name pqp_pension_types_f.pension_type_name%type;
	v_employee_percent hr_organization_information.org_information4%type;
	v_employer_percent hr_organization_information.org_information5%type;
	v_valid fnd_lookups.meaning%type;
	v_applicable fnd_lookups.meaning%type;
	
	cursor c_PGGM_type (t_bg  NUMBER) is
		SELECT   fnd_date.canonical_to_date (hoi.org_information1) date_from
				,fnd_date.canonical_to_date (hoi.org_information2) date_to
				,ppt.pension_type_name
				,hoi.org_information4 employee_contribution_percent
				,hoi.org_information5 total_contribution_percent
		FROM     hr_organization_information hoi
				, (SELECT   pension_type_id
						   ,pension_type_name
						   ,effective_start_date
						   ,effective_end_date
				   FROM     pqp_pension_types_f) ppt
		WHERE    1 = 1			 
			 AND hoi.org_information_context LIKE 'PQP_NL_PGGM_PT'
			 AND fnd_date.canonical_to_date (hoi.org_information1) BETWEEN ppt.effective_start_date
																	   AND  ppt.effective_end_date
			 AND hoi.org_information3 = ppt.pension_type_id
			 AND hoi.organization_id = t_bg; 
	
	cursor c_org_info (t_bg  NUMBER) is
		SELECT   hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_REGION'
				  ,org_information1
				 )
				   region
				,org_information2 organization_number
				,org_information3 tax_office_org_id
				,hou_tax.name tax_office_org_name
				,org_information4 tax_registration_number
				,org_information14 tax_reporting_name
				,org_information5 average_days_per_month
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_PART_TIME_PERCENTAGE_METHOD'
				  ,org_information8
				 )
				   part_time_percentage_method
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_LUNAR_5WEEK_MONTH_METHOD'
				  ,org_information9
				 )
				   lunar_5_week_month_wage_method
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_PRORATION_TAX_TABLE'
				  ,org_information10
				 )
				   proration_tax_table
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_CONTRIBUTION_INSURANCE'
				  ,org_information13
				 )
				   kind_wao_contribut_insurance
				,org_information11 parental_leave_wage_percentage
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_CBS_FREQUENCY'
				  ,org_information15
				 )
				   cbs_reporting_frequency
				,org_information16 customer_number
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information17
				 )
				   public_sector_organization
				,org_information18 company_unit
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information19
				 )
				   full_sickness_wage_paid
				,org_information20 iza_weekly_full_time_hours
				,org_information12 iza_monthly_full_time_hours
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information6
				 )
				   lhd_proration_override
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information7
				 )
				   beneficial_rule_separate_run
		FROM     hr_organization_information hoi
				, (SELECT   name, organization_id FROM hr_all_organization_units) hou_tax
		WHERE    1 = 1
			 AND hoi.org_information_context LIKE 'NL_ORG_INFORMATION'
			 AND hoi.org_information3 = hou_tax.organization_id
			 AND hoi.organization_id = t_bg; 
	v_region varchar2(100);
	v_o2 hr_organization_information.org_information1%type;
	v_o3 hr_organization_information.org_information1%type;
	v_tax_name hr_all_organization_units.name%type;
	v_o4 hr_organization_information.org_information1%type;
	v_o14 hr_organization_information.org_information1%type;
	v_o5 hr_organization_information.org_information1%type;
	v_o6 hr_organization_information.org_information1%type;
	v_o7 hr_organization_information.org_information1%type;
	v_o8 hr_organization_information.org_information1%type;
	v_lookup1 fnd_lookups.meaning%type;
	v_lookup2 fnd_lookups.meaning%type;
	v_lookup3 fnd_lookups.meaning%type;
	v_lookup4 fnd_lookups.meaning%type;
	v_o11 hr_organization_information.org_information1%type;
	v_lookup9 fnd_lookups.meaning%type;
	v_o16 hr_organization_information.org_information1%type;
	v_lookup5 fnd_lookups.meaning%type;
	v_o18 hr_organization_information.org_information1%type;
	v_lookup6 fnd_lookups.meaning%type;
	v_o20 hr_organization_information.org_information1%type;
	v_o12 hr_organization_information.org_information1%type;
	v_lookup7 fnd_lookups.meaning%type;
	v_lookup8 fnd_lookups.meaning%type;
	v_insurance_name fnd_lookups.meaning%type;
	v_insurance_name_old fnd_lookups.meaning%type;
	cursor c_abp_general (t_bg  NUMBER) is
			SELECT  hr_general_utilities.get_lookup_meaning
				 (
				   'PQP_NL_PT_PERCENT_METHODS'
				  ,org_information1
				 ) PTP_Calc_Non_Recurr_Bonus
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information2
				 ) Apply_OHT_Correction
				,hoi.org_information3 End_Of_Year_Bonus_Percentage
				,hoi.org_information4 Employee_Number_Override
				,hoi.org_information5 Starting_Position
		FROM      hr_organization_information hoi        
		WHERE    1 = 1
		 AND hoi.org_information_context LIKE 'PQP_NL_ABP_PTP_METHOD'
			 AND hoi.organization_id = t_bg;
	
	cursor c_NL_ABP_SENDER_DETAILS (t_bg  NUMBER) is
			SELECT  hoi.org_information1 Test_Environment
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information2
				 ) Registration_Number
				,hoi.org_information3 Name
		FROM      hr_organization_information hoi        
		WHERE    1 = 1
			AND hoi.org_information_context LIKE 'NL_ABP_SENDER_DETAILS'
			 AND hoi.organization_id = t_bg;
	
	cursor c_PQP_ABP_PROVIDER (t_bg  NUMBER) is
		SELECT  HOU_ABP.name ABP_Provider_name
				,hoi.org_information2 Registration_Number
				,hoi.org_information3 Old_registration_number
				,hoi.org_information4 Submitter_Identification
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_WR_PERIOD_TYPE'
				  ,org_information5
				 ) Period_type
				,hoi.org_information6 Employee_reference
		FROM      hr_organization_information hoi        
				, (SELECT   name, organization_id FROM hr_all_organization_units)
				 hou_abp 
		WHERE    1 = 1 
		 AND to_number(hoi.org_information1) = hou_abp.organization_id
			 AND hoi.org_information_context LIKE 'PQP_ABP_PROVIDER'
			 and hoi.organization_id = t_bg;
	v_abp_name hr_all_organization_units.name%type;
	cursor c_insurance (t_ins  NUMBER) is
		SELECT fnd_date.canonical_to_date(org_information1) Date_from
				,fnd_date.canonical_to_date(org_information2) Date_to
				,org_information3 Social_insurance_type_name
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_SI_TYPE'
				  ,org_information4
				 ) Social_insurance_type
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_BASIS_CALC_RULE'
				  ,org_information5
				 ) basic_calculation_rule
				,org_information6 employee_contribution_perc
				,org_information7 employer_contribution_perc
				  ,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_DAY_METHOD'
				  ,org_information12
				 ) Day_Method
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information15
				 ) day_adjustment
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information16
				 ) contribution_adjustment
		FROM     hr_organization_information hoi
		WHERE    1 = 1
			 AND org_information_context = 'NL_SIT'
			 AND organization_id = t_ins; 
	cursor c_insurance_org (t_ins  NUMBER) is
		SELECT  org_information1 Contact_number
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_PROVIDER_TYPE'
				  ,org_information2
				 ) provider_type
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_SECTOR'
				  ,org_information5
				 ) sector
				,org_information6 risk_group
				,org_information3 Branch_number 
				,org_information4 Branch_name 
		FROM     hr_organization_information hoi
		WHERE    1 = 1
			 AND org_information_context = 'NL_UWV'
			 AND organization_id = t_ins;
	cursor c_Dutch_SI_Provider (t_bg  NUMBER) is
		SELECT   fnd_date.canonical_to_date (hoi.org_information1) date_from
				,fnd_date.canonical_to_date (hoi.org_information2) date_to
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_SI_CLASSIFICATION'
				  ,org_information3
				 )
				   si_classification
				,hou_trd.name insurance_provider
				,org_information4 insurance_provider_id
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information7
				 )
				   primary_provider
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_TRANSFER_INDICATOR'
				  ,org_information6
				 )
				   transfer_indicator
				,hoi.org_information8 sender_reporting_name
				,hoi.org_information9 sender_registration_number
				,hoi.org_information10 employer_reporting_name
				,hoi.org_information11 employer_registration_number
		FROM     hr_organization_information hoi
				, (SELECT   name, organization_id FROM hr_all_organization_units)
				 hou_trd
		WHERE    1 = 1
			 AND (hoi.org_information4) = hou_trd.organization_id
			 AND hoi.org_information_context LIKE 'NL_SIP'
			 AND hoi.organization_id = t_bg
			 order by insurance_provider_id;
	cursor c_Flat_Rate (t_bg  NUMBER) is 
					SELECT  fnd_date.canonical_to_date(hoi.org_information1) Date_from
					,fnd_date.canonical_to_date(hoi.org_information2) Date_to
					,hr_general_utilities.get_lookup_meaning
					 (
					   'NL_WR_TAXATION_TYPE'
					  ,org_information3
					 ) Taxation_type
					,hoi.org_information4 Amount
					,hr_general_utilities.get_lookup_meaning
					 (
					   'NL_WR_PERIOD'
					  ,org_information5
					 ) Period_type
					,hr_general_utilities.get_lookup_meaning
					 (
					   'NL_WR_PERIOD_TYPE'
					  ,org_information6
					 ) Payroll_frequency
					,hr_general_utilities.get_lookup_meaning
					 (
					   'HR_NL_YES_NO'
					  ,org_information7
					 ) Correction
			FROM      hr_organization_information hoi        
			WHERE    1 = 1
				 AND hoi.org_information_context LIKE 'NL_ORG_FLAT_RATE_TAXATION'
				 and hoi.organization_id = t_bg;
	cursor c_PGGM_General (t_bg  NUMBER) is
			SELECT   fnd_date.canonical_to_date (hoi.org_information1) date_from
				,fnd_date.canonical_to_date (hoi.org_information2) date_to
				,hoi.org_information3 holiday_allowance_percentage
				,hoi.org_information4 end_of_year_bonus_percentage
				,hoi.org_information5 pggm_employee_number
				,hoi.org_information7 employer_registration_number
				,hoi.org_information8 life_savings_scheme_percentage
		FROM     hr_organization_information hoi       
		WHERE    1 = 1
			 AND hoi.org_information_context LIKE 'PQP_NL_PGGM_INFO'
			 AND hoi.organization_id = t_bg;
	
	cursor c_WR_Prev_Year (t_bg  NUMBER) is
		SELECT  fnd_date.canonical_to_date (hoi.org_information1) date_from
				,fnd_date.canonical_to_date (hoi.org_information2) date_to
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_FORM_LABELS'
				  ,org_information3
				 ) taxation_type
				,hoi.org_information4 Amount
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_WR_PERIOD'
				  ,org_information5
				 ) Period_type
				,hr_general_utilities.get_lookup_meaning
				 (
				   'NL_WR_PERIOD_TYPE'
				  ,org_information6
				 ) Payroll_frequency
		FROM      hr_organization_information hoi       
		WHERE    1 = 1
		 AND hoi.org_information_context LIKE 'NL_ORG_WR_PREV_YR_CORRECTION'
			 and hoi.organization_id = t_bg;
	
	cursor c_Wage_Report (t_bg  NUMBER) is
			SELECT  hoi.org_information1 sender_id
				,hoi.org_information2 contact_name
				,hoi.org_information3 contact_number
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information4
				 )
				   paid_assignments_only
				,hr_general_utilities.get_lookup_meaning
				 (
				   'HR_NL_YES_NO'
				  ,org_information5
				 )
				   own_risk_cover
				,hr_general_utilities.get_lookup_meaning('NL_WR_CONTRACT_CODE_MAPPING',org_information6
				 )
				   contact_code_mapping
		FROM     hr_organization_information hoi        
		WHERE    1 = 1
			 AND hoi.org_information_context LIKE 'NL_ORG_WR_INFO'
			 AND hoi.organization_id = t_bg;
	
	cursor c_payroll (t_bg  NUMBER) is
				SELECT   prl.payroll_name
				,prl.period_type
				,prl.first_period_end_date
				,prl.number_of_years
				,prl.period_reset_years
				,prl.pay_date_offset
				,prl.direct_deposit_date_offset
				,prl.pay_advice_date_offset
				,prl.cut_off_date_offset
				,prl.payslip_view_date_offset
				,nvl (opm.org_payment_method_name, 'No Default Payment Method Set') default_payment_method
				,con.consolidation_set_name consolidation_set
				,prl.workload_shifting_level
				,prl.arrears_flag
				,prl.negative_pay_allowed_flag
				,prl.multi_assignments_flag
				,leg_emp.name legal_employer_name				
				,prl.prl_information21 days_after_period_start
				,prl.prl_information22 days_after_period_end
				,hr_general_utilities.get_lookup_meaning('MODELER_AVAILABLITY',prl.prl_information20)  modeling_availability_rule
				,prl.payroll_id
				,prl.default_payment_method_id default_payment_method_id				
		FROM     pay_all_payrolls_f prl
				,pay_org_payment_methods_f opm
				,pay_consolidation_sets con
				,hr_all_organization_units org
				, (SELECT   organization_id, name FROM hr_all_organization_units)
				 leg_emp
				,per_time_period_types tpt
				,per_time_period_rules tpr
		WHERE    1 = 1
			 AND con.consolidation_set_id = prl.consolidation_set_id
			 AND opm.org_payment_method_id(+) = prl.default_payment_method_id
			 AND org.organization_id(+) = prl.organization_id
			 AND leg_emp.organization_id = prl.prl_information1
			 AND tpt.period_type = prl.period_type
			 AND tpr.number_per_fiscal_year = tpt.number_per_fiscal_year
			 AND sysdate BETWEEN prl.effective_start_date AND prl.effective_end_date
			 AND prl.business_group_id = t_bg
			 order by 1;
	v_payroll_name pay_all_payrolls_f.payroll_name%type;
	v_period_type pay_all_payrolls_f.period_type%type;
	v_first_date pay_all_payrolls_f.first_period_end_date%type;
	v_number_of_years pay_all_payrolls_f.number_of_years%type;
	v_period_reset_years pay_all_payrolls_f.period_reset_years%type;
	v_pay_date_offset pay_all_payrolls_f.pay_date_offset%type;
	v_direct_deposit pay_all_payrolls_f.direct_deposit_date_offset%type;
	v_pay_advice_date_offset pay_all_payrolls_f.pay_advice_date_offset%type;
	v_cut_off_date pay_all_payrolls_f.cut_off_date_offset%type;
	v_payslip_view pay_all_payrolls_f.payslip_view_date_offset%type;
	v_default_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_consolidation pay_consolidation_sets.consolidation_set_name%type;
	v_workload_shifting pay_all_payrolls_f.workload_shifting_level%type;
	v_arrears_flag pay_all_payrolls_f.arrears_flag%type;
	v_negative_pay pay_all_payrolls_f.negative_pay_allowed_flag%type;
	v_multi_assignments pay_all_payrolls_f.multi_assignments_flag%type;
	v_legal_employer hr_all_organization_units.name%type;
	v_prl_information21 pay_all_payrolls_f.prl_information21%type;
	v_prl_information22 pay_all_payrolls_f.prl_information22%type;
	v_modeling_availability fnd_lookups.meaning%type;
	
	cursor c_Organizational (t_pid  NUMBER, t_dpmid NUMBER) is
			SELECT   opm.org_payment_method_name org_paymentmethod_name
				,pt.payment_type_name payment_type
				,CASE
				   WHEN opu.org_payment_method_id = t_dpmid
				   THEN
					 'Yes'
				   ELSE
					 'No'
				 END default_payment_method
				,opu.effective_start_date
				,opu.effective_end_date
				,opu.org_payment_method_id
				,pt.payment_type_id
		FROM     pay_org_pay_method_usages_f opu
				,pay_org_payment_methods_f opm
				,pay_payment_types pt
		WHERE    1 = 1
			 AND opm.org_payment_method_id = opu.org_payment_method_id
			 AND pt.payment_type_id = opm.payment_type_id
			 AND sysdate between opm.effective_start_date and opm.effective_end_date
			 AND sysdate between opu.effective_start_date and opu.effective_end_date
			 AND opu.payroll_id = t_pid
			 order by 1;
	
	v_payroll_id pay_org_pay_method_usages_f.payroll_id%type;
	v_org_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_payment_type_name pay_payment_types.payment_type_name%type;
	v_default_payment_method_id pay_all_payrolls_f.default_payment_method_id%type;
	v_default_payment_method varchar2(10);
	v_effective_start_date pay_org_pay_method_usages_f.effective_start_date%type;
	v_effective_end_date pay_org_pay_method_usages_f.effective_end_date%type;
	v_org_payment_method_id pay_org_pay_method_usages_f.org_payment_method_id%type;
	v_payment_type_id pay_payment_types.payment_type_id%type;
	
	
	v_seg2 pay_external_accounts.segment2%type;
	v_seg3 pay_external_accounts.segment3%type;
	v_seg5 pay_external_accounts.segment5%type;
	v_seg6 pay_external_accounts.segment6%type;
	v_seg7 pay_external_accounts.segment7%type;
	v_seg10 pay_external_accounts.segment10%type;
	
	cursor c_org_pay (t_id  NUMBER) is
		SELECT   hr_general_utilities.get_lookup_meaning('PER_EU_COUNTRIES',pea.territory_code) country
				,hr_general_utilities.get_lookup_meaning ('HR_NL_BANK', pea.segment1)  bank_name
				,segment2 account_number
				,segment3 postal_code
				,hr_general_utilities.get_lookup_meaning ('HR_NL_CITY', pea.segment4)  city
				,segment5 street
				,segment6 telephone_number
				,segment7 telephone_extension
				,hr_general_utilities.get_lookup_meaning('HR_NL_BIC_CODES',pea.segment9) bank_identifier_code
				,segment10 iban_number
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_payment) cost_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_payment) cost_cleared_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_void_payment) cost_cleared_void_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.exclude_manual_payment) exclude_manual_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.transfer_to_gl_flag) transfer_to_gl_flag
		FROM     pay_external_accounts pea, (SELECT   org_payment_method_id
													 ,external_account_id
													 ,business_group_id
													 ,cost_payment
													 ,cost_cleared_payment
													 ,cost_cleared_void_payment
													 ,exclude_manual_payment
													 ,transfer_to_gl_flag
													 ,effective_start_date
													 ,effective_end_date
											 FROM     pay_org_payment_methods_f) popm
		WHERE    1 = 1
			 AND pea.external_account_id = popm.external_account_id
			 AND popm.org_payment_method_id = t_id
			 AND sysdate BETWEEN effective_start_date AND effective_end_date;
	
	cursor c_pension_prov (t_bg  NUMBER) is
			SELECT ou1.name				  
				  ,oi1.org_information1
		FROM       hr_organization_information oi1
				  ,hr_organization_information oi2
				  ,hr_all_organization_units ou1
		WHERE      ou1.organization_id = oi1.organization_id
			   AND oi1.organization_id = oi2.organization_id
			   AND oi1.org_information_context = 'PQP_NL_PENSION_TYPES'
			   AND oi2.org_information_context = 'CLASS'
			   AND oi2.org_information1 = 'FR_PENSION'
			   AND oi2.org_information2 = 'Y'
			   and OU1.business_group_id = t_bg
		ORDER BY   ou1.name;
	
	cursor c_pension_types (t_bg  NUMBER, t_pension_id number) is
	SELECT   pension_type_id
				,effective_start_date
				,effective_end_date
				,pension_type_name
				,hr_general_utilities.get_lookup_meaning
				 (
				   'PQP_NL_PENSION_CATEGORY'
				  ,pension_category
				 )
				   pension_category
				,hr_general_utilities.get_lookup_meaning
				 (
				   'PQP_NL_PENSION_PROVIDER_TYPE'
				  ,pension_provider_type
				 )
				   pension_provider_type
				,minimum_age
				,maximum_age
				,ee_contribution_percent employee_contribution_percent
				,er_contribution_percent employer_contribution_percent
				,description
				,special_pension_type_code special_pension_type
				, (SELECT   nvl (meaning, 'Not set')
				   FROM     fnd_lookup_values
				   WHERE    lookup_type = 'PQP_PENSION_BASIS_CALC_MTHD'
						AND language = 'US'
						AND lookup_code = pension_basis_calc_method)
				   pension_basis_calc_method
				,pension_sub_category
				,ee_annual_limit employee_annual_limit
				,er_annual_limit employer_annual_limit
				,ee_annual_salary_threshold employee_annual_salary_thres
				,er_annual_salary_threshold employer_annual_salary_thres
				,hr_general_utilities.get_lookup_meaning
				 (
				   'PQP_NL_SALARY_CALC_METHOD'
				  ,salary_calculation_method
				 )
				   salary_calculation_method
				,hr_general_utilities.get_lookup_meaning
				 (
				   'PQP_NL_CONVERSION_RULE'
				  ,contribution_conversion_rule
				 )
				   contribution_conversion_rule
				,pbt_ee.balance_name employee_contribution_balance
				,pbt_er.balance_name employer_contribution_balance
		FROM     pqp_pension_types_f ppt
				, (SELECT   balance_name, balance_type_id FROM pay_balance_types)
				 pbt_ee
				, (SELECT   balance_name, balance_type_id FROM pay_balance_types)
				 pbt_er
		WHERE    1 = 1
			  AND pbt_ee.balance_type_id (+) = ppt.ee_contribution_bal_type_id
			 AND pbt_er.balance_type_id (+) = ppt.er_contribution_bal_type_id
			 AND sysdate between ppt.effective_start_date and ppt.effective_end_date
			 AND business_group_id = t_bg
			 AND pension_type_id = t_pension_id;
	v_pension_type_id pqp_pension_types_f.pension_type_id%type;

	v_minimum_age pqp_pension_types_f.minimum_age%type;
	v_maximum_age pqp_pension_types_f.maximum_age%type;
	v_ee_contribution_percent pqp_pension_types_f.ee_contribution_percent%type;
	v_er_contribution_percent pqp_pension_types_f.er_contribution_percent%type;
	v_description pqp_pension_types_f.description%type;
	v_special_pension_type_code pqp_pension_types_f.special_pension_type_code%type;
	v_pens_calc fnd_lookup_values.meaning%type;
	v_pension_sub_category pqp_pension_types_f.pension_sub_category%type;
	v_ee_annual_limit pqp_pension_types_f.ee_annual_limit%type;
	v_er_annual_limit pqp_pension_types_f.er_annual_limit%type;
	v_ee_annual_salary_threshold pqp_pension_types_f.ee_annual_salary_threshold%type;
	v_er_annual_salary_threshold pqp_pension_types_f.er_annual_salary_threshold%type;
	v_bal1 pay_balance_types.balance_name%type;
	v_bal2 pay_balance_types.balance_name%type; 
begin
		
	l_o('<br><DIV class=divItem>');
	l_o('<DIV  class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b"  onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Business Group Information</A></DIV>');					
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql500'||:v_link_no||'" style="display:none" >');
	:v_link_no:=:v_link_no+1;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Business Group Information:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD></TR>');
    l_o(' <TR id="s1sql500'||:v_link_no||'" style="display:none">');
	:v_link_no:=:v_link_no+1;
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
	l_o('SELECT   hou_bg.organization_id business_group_id<br>'); 
    l_o('    ,hou_bg.name business_group_name<br>'); 
    l_o('    ,organization_structure_id Organization_Hier_struc_id<br>'); 
    l_o('    ,org_struc.name Organization_Hierarchy<br>'); 
    l_o('    ,hr_general_utilities.get_lookup_meaning(''HR_NL_YES_NO'',org_information2) override_replacement_retropay<br>'); 
    l_o('    ,hoi.org_information3 sender_tax_reporting_name<br>'); 
    l_o('    ,hoi.org_information4 sender_tax_registration_number<br>'); 
    l_o('    ,hoi.org_information5 new_retropay_start_date<br>'); 
    l_o('    ,hr_general_utilities.get_lookup_meaning(''NL_APG_LEVEL'',hoi.org_information6) assignment_progress_group<br>'); 
    l_o('    ,hr_general_utilities.get_lookup_meaning(''HR_NL_YES_NO'',org_information8) allow_employer_change<br>'); 
	l_o('	FROM     hr_organization_information hoi<br>'); 
    l_o('    , (SELECT   name, organization_id FROM hr_all_organization_units) hou_bg<br>'); 
    l_o('    , (SELECT   name, organization_structure_id FROM per_organization_structures) org_struc<br>'); 
	l_o('	 WHERE    1 = 1<br>'); 
	l_o('	 AND hoi.organization_id = hou_bg.organization_id<br>'); 
	l_o('	 AND org_struc.organization_structure_id = hoi.org_information1<br>'); 
	l_o('	 AND hoi.org_information_context LIKE ''NL_BG_INFO''<br>'); 
    l_o('          </blockquote><br></TD></TR>');
       
		
    :n := dbms_utility.get_time;
    l_o(' <TR><TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');		
    open c_bg;
        loop
            fetch c_bg into v_bg,v_bg_name,v_organization_structure_id,v_os_name,v_override_repl,v_sender_tax_reporting_name,v_sender_tax,v_new_retropay_start_date,v_assignment_progress_group,v_allow_employer_change;
            EXIT WHEN  c_bg%NOTFOUND;
			l_o('<DIV class=divItem>');
			l_o('<DIV class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_bg||' - '||v_bg_name||'</A></DIV>');
			l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;
			l_o('Organization Hier Structure Id: '|| v_organization_structure_id||'<br>');
			l_o('Organization Hierarchy: '|| v_os_name||'<br>');
			l_o('Override Replacement Retropay: '|| v_override_repl||'<br>');
			l_o('Sender Tax Reporting Name: '|| v_sender_tax_reporting_name||'<br>');
			l_o('Sender Tax Registration Number: '|| v_sender_tax||'<br>');
			l_o('New Retropay Start Date: '|| v_new_retropay_start_date||'<br>');
			l_o('Assignment Progress Group: '|| v_assignment_progress_group||'<br>');
			l_o('Allow Employer Change: '|| v_allow_employer_change||'<br>');
		
			SELECT   org_information1 short_name					
					,hr_general_utilities.get_lookup_meaning('EMP_NUM_GEN_METHOD',org_information2) employee_number_generation
					,hr_general_utilities.get_lookup_meaning('APL_NUM_GEN_METHOD',org_information3) applicant_number_generation
					,hr_general_utilities.get_lookup_meaning('CWK_NUM_GEN_METHOD',org_information16) contingent_worker_numb_gen
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information4
							AND id_flex_code = 'GRD')       grade_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information5
							AND id_flex_code = 'GRP')        group_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information6
							AND id_flex_code = 'JOB')        job_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information7
							AND id_flex_code = 'COST')       costing_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information8
							AND id_flex_code = 'POS')        position_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information15
							AND id_flex_code = 'CMP')        competence_flexfield_structure
					,org_information10 currency
					,org_information11 fiscal_year_start
					,org_information12 minimum_working_age
					,org_information13 maximum_working_age
					into v_short_name,v_employee_number_generation,v_applicant_number_generation,v_contingent_worker_numb_gen, v_grade_flexfield_structure,v_group_flexfield_structure,v_job_flexfield_structure,v_costing_flexfield_structure,v_position_flexfield_structure,v_competence_flex,v_currency,v_fiscal_year_start,v_minimum_working_age,v_maximum_working_age
					FROM     hr_organization_information hoi
							, (SELECT   name, organization_id FROM hr_all_organization_units)
							 hou_bg
					WHERE    1 = 1
						 AND hoi.organization_id = hou_bg.organization_id
						 AND hoi.org_information_context LIKE 'Business Group Information'
						 AND hoi.org_information9 = 'NL'
						 AND hou_bg.organization_id = v_bg 
						 AND	 rownum < 2;
						 
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Business Group Info Setup</A>');
			l_o('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;
			l_o('<tr><th>Organization Short Name</th><th>Employee Number Generation</th><th>Applicant Number Generation</th>');
			l_o('<th>Contingent Worker Numb Gen</th><th>Grade Flexfield Structure</th><th>Group Flexfield Structure</th>');
			l_o('<th>Job Flexfield Structure</th><th>Costing Flexfield Structure</th><th>Position Flexfield Structure</th><th>Competence Flexfield Structure</th>');
			l_o('<th>Currency</th><th>Fiscal Year Start</th><th>Minimum Working Age</th>');
			l_o('<th>Maximum Working Age</th></tr>');
		
			l_o('<TR><TD>'||v_short_name||'</TD>'||chr(10)||'<TD>'||v_employee_number_generation||'</TD>'||chr(10)||'<TD>'||v_applicant_number_generation||'</TD>'||chr(10));
			l_o('<TD>'||v_contingent_worker_numb_gen||'</TD>'||chr(10)||'<TD>'||v_grade_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_group_flexfield_structure||'</TD>'||chr(10));
			l_o('<TD>'||v_job_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_costing_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_position_flexfield_structure||'</TD>'||chr(10));
			l_o('<TD>'||v_competence_flex||'</TD>'||chr(10)||'<TD>'||v_currency||'</TD>'||chr(10)||'<TD>'||v_fiscal_year_start||'</TD>'||chr(10));
			l_o('<TD>'||v_minimum_working_age||'</TD>'||chr(10)||'<TD>'||v_maximum_working_age||'</TD></TR>'||chr(10));
			l_o('</table><br>');					  
								  
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Organization Hierarchy Structures information</A>');
			l_o('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			
			v_old:=-1;
			l_o('<tr><th width="50%">Parent Name</th><th width="50%">Child Name</th></tr>');
			open c_Hierarchy(v_bg);
			loop
				  fetch c_Hierarchy into v_parent_id,v_parent_name,v_child_id,v_child_name;
				  EXIT WHEN  c_Hierarchy%NOTFOUND;
				  if v_parent_id=v_old then
					l_o('<TR><TD>-''-</TD>'||chr(10));
				  else
					l_o('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_parent_name||'</A>');
					l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; ABP Pension Types</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
							:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Test environment</th><th>Registration number</th><th>Name</th></tr>');
							open c_abp(v_parent_id);
							loop
								  fetch c_abp into v_test,v_Registration_Number,v_org_information3;
								  EXIT WHEN  c_abp%NOTFOUND;				  
								  l_o('<TR><TD>'||v_test||'</TD>'||chr(10)||'<TD>'||v_Registration_Number||'</TD>'||chr(10)||'<TD>'||v_org_information3||'</TD></TR>'||chr(10));         
							end loop;
							close c_abp;
						l_o('</table><br>');
						
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; PGGM Pension Types</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Date from</th><th>Date to</th><th>Pension Type Name</th><th>Employee Contribution Percent</th><th>Employer Contribution Percent</th></tr>');
							open c_PGGM_type(v_parent_id);
							loop
								  fetch c_PGGM_type into v_date_from,v_date_to,v_pension_type_name,v_employee_percent,v_employer_percent;
								  EXIT WHEN  c_PGGM_type%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_pension_type_name||'</TD>'||chr(10));
								  l_o('<TD>'||v_employee_percent||'</TD>'||chr(10)||'<TD>'||v_employer_percent||'</TD></TR>'||chr(10));         
							end loop;
							close c_PGGM_type;
						l_o('</table><br>');
						
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Organization Information</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1; 
							l_o('<tr><th>Region</th><th>Organization Number</th><th>Tax Office Org Id</th><th>Tax Office Org Name</th><th>Tax Registration Number</th>');
							l_o('<th>Tax Reporting Name</th><th>Average Days Per Month</th><th>Part Time Percentage Method</th><th>Lunar 5 Week Month Wage Method</th><th>Proration Tax Table</th>');
							l_o('<th>Kind Wao Contribut Insurance</th><th>Parental Leave Wage Percentage</th><th>CBS Reporting Frequency</th><th>Customer Number</th><th>Public Sector Organization</th><th>Company Unit</th><th>Full Sickness Wage Paid</th>');
							l_o('<th>Weekly full time_hours</th><th>Monthly full time hours</th>');
							l_o('<th>LHD proration override</th><th>Beneficial rule separate run</th></tr>');
							open c_org_info(v_parent_id);
							loop
								  fetch c_org_info into v_region,v_o2,v_o3,v_tax_name,v_o4,v_o14,v_o5,v_lookup1,v_lookup2,v_lookup3,v_lookup4,v_o11,v_lookup9,v_o16,v_lookup5,v_o18,v_lookup6,v_o20,v_o12,v_lookup7,v_lookup8;
								  EXIT WHEN  c_org_info%NOTFOUND;				  
								  l_o('<TR><TD>'||v_region||'</TD>'||chr(10)||'<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10));
								  l_o('<TD>'||v_tax_name||'</TD>'||chr(10)||'<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_o14||'</TD>'||chr(10)||'<TD>'||v_o5||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup3||'</TD>'||chr(10)||'<TD>'||v_lookup4||'</TD>'||chr(10));
								  l_o('<TD>'||v_o11||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
								  l_o('<TD>'||v_o16||'</TD>'||chr(10)||'<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_o18||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup6||'</TD>'||chr(10)||'<TD>'||v_o20||'</TD>'||chr(10)||'<TD>'||v_o12||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup7||'</TD>'||chr(10)||'<TD>'||v_lookup8||'</TD></TR>'||chr(10));         
							end loop;
							close c_org_info;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; ABP Pensions General Info PQP_NL_ABP_PTP_METHOD</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>PTP Calc Non_Recurr Bonus</th><th>Apply OHT Correction</th><th>End Of Year Bonus Percentage</th><th>Employee Number Override</th><th>Starting Position</th></tr>');
							open c_abp_general(v_parent_id);
							loop
								  fetch c_abp_general into v_region,v_lookup1,v_o3,v_o4,v_o5;
								  EXIT WHEN  c_abp_general%NOTFOUND;				  
								  l_o('<TR><TD>'||v_region||'</TD>'||chr(10)||'<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10));
								  l_o('<TD>'||v_o4||'</TD>'||chr(10)||'<TD>'||v_o5||'</TD></TR>'||chr(10));         
							end loop;
							close c_abp_general;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; ABP Sender Details NL_ABP_SENDER_DETAILS</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
								l_o('<tr><th>Test_Environment</th><th>Registration number</th><th>Name</th></tr>');
								open c_NL_ABP_SENDER_DETAILS(v_parent_id);
								loop
									  fetch c_NL_ABP_SENDER_DETAILS into v_o2,v_region,v_o3;
									  EXIT WHEN  c_NL_ABP_SENDER_DETAILS%NOTFOUND;				  
									  l_o('<TR><TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_region||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD></TR>'||chr(10));         
								end loop;
								close c_NL_ABP_SENDER_DETAILS;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; ABP Provider PQP_ABP_PROVIDER</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>ABP_Provider_name</th><th>Registration_Number</th><th>Old_registration_number</th><th>Submitter_Identification</th><th>Period_type</th><th>Employee_reference</th></tr>');
							open c_PQP_ABP_PROVIDER(v_parent_id);
							loop
								  fetch c_PQP_ABP_PROVIDER into v_abp_name,v_o2,v_o3,v_o4,v_region,v_lookup1;
								  EXIT WHEN  c_PQP_ABP_PROVIDER%NOTFOUND;				  
								  l_o('<TR><TD>'||v_abp_name||'</TD>'||chr(10)||'<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_region||'</TD>'||chr(10)||'<TD>'||v_lookup1||'</TD></TR>'||chr(10));         
							end loop;
							close c_PQP_ABP_PROVIDER;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Dutch SI Provider</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1; 
							l_o('<tr><th>Date From</th><th>Date To</th><th>SI Classification</th><th>Insurance Provider</th><th>Insurance Provider ID</th>');
							l_o('<th>Primary Provider</th><th>Transfer Indicator</th><th>Sender Reporting Name</th><th>Sender Registration Number</th><th>Employer Reporting Name</th>');
							l_o('<th>Employer Registration Number</th></tr>');
							v_insurance_name_old:='';
							open c_Dutch_SI_Provider(v_parent_id);
							loop
								  fetch c_Dutch_SI_Provider into v_date_from,v_date_to,v_region,v_insurance_name,v_o4,v_lookup1,v_lookup2,v_o16,v_o18,v_o12,v_o20;
								  EXIT WHEN  c_Dutch_SI_Provider%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_region||'</TD>'||chr(10));
								  if v_insurance_name=v_insurance_name_old then
										l_o('<TD>'||v_insurance_name||'</TD>'||chr(10));
								  else
										l_o('<TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; '||v_insurance_name||'</A>');
										l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1;
										
										l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Social Ensurance Details UWV Provider</A>');
										l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1; 
										l_o('<tr><th>Date From</th><th>Date To</th><th>Social_insurance_type_name</th><th>basic_calculation_rule</th><th>employee_contribution_perc</th><th>employer_contribution_perc</th>');
										l_o('<th>Day_Method</th><th>day_adjustment</th><th>contribution_adjustment</th></tr>');
										open c_insurance(v_o4);
										loop
											  fetch c_insurance into v_date_from,v_date_to,v_o3,v_lookup9,v_lookup5,v_o6,v_o7,v_lookup6,v_lookup7,v_lookup8;
											  EXIT WHEN  c_insurance%NOTFOUND;				  
											  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
											  l_o('<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_o6||'</TD>'||chr(10)||'<TD>'||v_o7||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10)||'<TD>'||v_lookup7||'</TD>'||chr(10)||'<TD>'||v_lookup8||'</TD></TR>'||chr(10));         
										end loop;
										close c_insurance;
										l_o('</table><br>');
										
										l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Dutch UWV Organization</A>');
										l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1; 
										l_o('<tr><th>Contact Number</th><th>Provider Type</th><th>Sector</th><th>Risk Group</th><th>Branch Number</th><th>Branch Name</th></tr>');
										
										open c_insurance_org(v_o4);
										loop
											  fetch c_insurance_org into v_o12,v_lookup6,v_lookup7,v_o6,v_o3,v_o8;
											  EXIT WHEN  c_insurance_org%NOTFOUND;				  
											  l_o('<TR><TD>'||v_o12||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10)||'<TD>'||v_lookup7||'</TD>'||chr(10)||'<TD>'||v_o6||'</TD>'||chr(10));
											  l_o('<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_o8||'</TD></TR>'||chr(10));         
										end loop;
										close c_insurance_org;
										l_o('</table><br>');
										
										l_o('</DIV></TD>');
								  end if;
								  
								  v_insurance_name_old:=v_insurance_name;
								  l_o('<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10));
								  l_o('<TD>'||v_o16||'</TD>'||chr(10)||'<TD>'||v_o18||'</TD>'||chr(10));
								  l_o('<TD>'||v_o12||'</TD>'||chr(10)||'<TD>'||v_o20||'</TD></TR>'||chr(10));         
							end loop;
							close c_Dutch_SI_Provider;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Flat Rate Taxaction NL_ORG_FLAT_RATE_TAXATION</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1; 						       
							l_o('<tr><th>Date From</th><th>Date To</th><th>Taxation Type</th><th>Amount</th><th>Period Type</th>');
							l_o('<th>Payroll Frequency</th><th>Correction</th></tr>');
							open c_Flat_Rate(v_parent_id);
							loop
								  fetch c_Flat_Rate into v_date_from,v_date_to,v_region,v_o4,v_lookup1,v_lookup2,v_lookup4;
								  EXIT WHEN  c_Flat_Rate%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_region||'</TD>'||chr(10));
								  l_o('<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10));								 
								  l_o('<TD>'||v_lookup4||'</TD></TR>'||chr(10));         
							end loop;
							close c_Flat_Rate;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; PGGM General Info PQP_NL_PGGM_INFO</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Date From</th><th>Date To</th><th>Holiday Allowance Percentage</th><th>End of Year Bonus Percentage</th><th>PGGM Employee Number</th>');
							l_o('<th>Employer Registration Number</th><th>Life Savings Scheme Percentage</th></tr>');
							open c_PGGM_General(v_parent_id);
							loop
								  fetch c_PGGM_General into v_date_from,v_date_to,v_o3,v_o4,v_o5,v_o11,v_o12;
								  EXIT WHEN  c_PGGM_General%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10));
								  l_o('<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_o5||'</TD>'||chr(10)||'<TD>'||v_o11||'</TD>'||chr(10));								 
								  l_o('<TD>'||v_o12||'</TD></TR>'||chr(10));         
							end loop;
							close c_PGGM_General;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; WR Prev Year Correction NL_ORG_WR_PREV_YR_CORRECTION</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;							      
							l_o('<tr><th>Date From</th><th>Date To</th><th>Taxation Type</th><th>Amount</th><th>Period Type</th>');
							l_o('<th>Payroll Frequency</th></tr>');
							open c_WR_Prev_Year(v_parent_id);
							loop
								  fetch c_WR_Prev_Year into v_date_from,v_date_to,v_region,v_o4,v_lookup1,v_lookup2;
								  EXIT WHEN  c_WR_Prev_Year%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_region||'</TD>'||chr(10));
								  l_o('<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD></TR>'||chr(10));         
							end loop;
							close c_WR_Prev_Year;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Wage Report Information NL_ORG_WR_INFO</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;	
        						
							l_o('<tr><th>Sender Id</th><th>Contact Name</th><th>Contact Number</th><th>Paid Assignments Only</th><th>Own Risk Cover</th>');
							l_o('<th>Contact Code Mapping</th></tr>');
							open c_Wage_Report(v_parent_id);
							loop
								  fetch c_Wage_Report into v_o11,v_o2,v_o3,v_region,v_lookup1,v_lookup2;
								  EXIT WHEN  c_Wage_Report%NOTFOUND;				  
								  l_o('<TR><TD>'||v_o11||'</TD>'||chr(10)||'<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10));
								  l_o('<TD>'||v_region||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD></TR>'||chr(10));         
							end loop;
							close c_Wage_Report;
						l_o('</table><br>');

					l_o('</DIV></TD>'||chr(10));
				end if;
				
					l_o('<TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_child_name||'</A>');
					l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; ABP Pension Types</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
							:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Test environment</th><th>Registration number</th><th>Name</th></tr>');
							open c_abp(v_child_id);
							loop
								  fetch c_abp into v_test,v_Registration_Number,v_org_information3;
								  EXIT WHEN  c_abp%NOTFOUND;				  
								  l_o('<TR><TD>'||v_test||'</TD>'||chr(10)||'<TD>'||v_Registration_Number||'</TD>'||chr(10)||'<TD>'||v_org_information3||'</TD></TR>'||chr(10));         
							end loop;
							close c_abp;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; PGGM Pension Types</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Date from</th><th>Date to</th><th>Pension Type Name</th><th>Employee Contribution Percent</th><th>Employer Contribution Percent</th></tr>');
							open c_PGGM_type(v_child_id);
							loop
								  fetch c_PGGM_type into v_date_from,v_date_to,v_pension_type_name,v_employee_percent,v_employer_percent;
								  EXIT WHEN  c_PGGM_type%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_pension_type_name||'</TD>'||chr(10));
								  l_o('<TD>'||v_employee_percent||'</TD>'||chr(10)||'<TD>'||v_employer_percent||'</TD></TR>'||chr(10));         
							end loop;
							close c_PGGM_type;
						l_o('</table><br>');
						
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Organization Information</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1; 
							l_o('<tr><th>Region</th><th>Organization Number</th><th>Tax Office Org Id</th><th>Tax Office Org Name</th><th>Tax Registration Number</th>');
							l_o('<th>Tax Reporting Name</th><th>Average Days Per Month</th><th>Part Time Percentage Method</th><th>Lunar 5 Week Month Wage Method</th><th>Proration Tax Table</th>');
							l_o('<th>Kind Wao Contribut Insurance</th><th>Parental Leave Wage Percentage</th><th>CBS Reporting Frequency</th><th>Customer Number</th><th>Public Sector Organization</th><th>Company Unit</th><th>Full Sickness Wage Paid</th>');
							l_o('<th>Weekly full time_hours</th><th>Monthly full time hours</th>');
							l_o('<th>LHD proration override</th><th>Beneficial rule separate run</th></tr>');
							open c_org_info(v_child_id);
							loop
								  fetch c_org_info into v_region,v_o2,v_o3,v_tax_name,v_o4,v_o14,v_o5,v_lookup1,v_lookup2,v_lookup3,v_lookup4,v_o11,v_lookup9,v_o16,v_lookup5,v_o18,v_lookup6,v_o20,v_o12,v_lookup7,v_lookup8;
								  EXIT WHEN  c_org_info%NOTFOUND;				  
								  l_o('<TR><TD>'||v_region||'</TD>'||chr(10)||'<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10));
								  l_o('<TD>'||v_tax_name||'</TD>'||chr(10)||'<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_o14||'</TD>'||chr(10)||'<TD>'||v_o5||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup3||'</TD>'||chr(10)||'<TD>'||v_lookup4||'</TD>'||chr(10));
								  l_o('<TD>'||v_o11||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
								  l_o('<TD>'||v_o16||'</TD>'||chr(10)||'<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_o18||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup6||'</TD>'||chr(10)||'<TD>'||v_o20||'</TD>'||chr(10)||'<TD>'||v_o12||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup7||'</TD>'||chr(10)||'<TD>'||v_lookup8||'</TD></TR>'||chr(10));         
							end loop;
							close c_org_info;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; ABP Pension General Info</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>PTP Calc Non_Recurr Bonus</th><th>Apply OHT Correction</th><th>End Of Year Bonus Percentage</th><th>Employee Number Override</th><th>Starting Position</th></tr>');
							open c_abp_general(v_child_id);
							loop
								  fetch c_abp_general into v_region,v_lookup1,v_o3,v_o4,v_o5;
								  EXIT WHEN  c_abp_general%NOTFOUND;				  
								  l_o('<TR><TD>'||v_region||'</TD>'||chr(10)||'<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10));
								  l_o('<TD>'||v_o4||'</TD>'||chr(10)||'<TD>'||v_o5||'</TD></TR>'||chr(10));         
							end loop;
							close c_abp_general;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; ABP Sender Details NL_ABP_SENDER_DETAILS</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
								l_o('<tr><th>Test_Environment</th><th>Registration number</th><th>Name</th></tr>');
								open c_NL_ABP_SENDER_DETAILS(v_child_id);
								loop
									  fetch c_NL_ABP_SENDER_DETAILS into v_o2,v_region,v_o3;
									  EXIT WHEN  c_NL_ABP_SENDER_DETAILS%NOTFOUND;				  
									  l_o('<TR><TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_region||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD></TR>'||chr(10));         
								end loop;
								close c_NL_ABP_SENDER_DETAILS;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; ABP Provider PQP_ABP_PROVIDER</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>ABP_Provider_name</th><th>Registration_Number</th><th>Old_registration_number</th><th>Submitter_Identification</th><th>Period_type</th><th>Employee_reference</th></tr>');
							open c_PQP_ABP_PROVIDER(v_child_id);
							loop
								  fetch c_PQP_ABP_PROVIDER into v_abp_name,v_o2,v_o3,v_o4,v_region,v_lookup1;
								  EXIT WHEN  c_PQP_ABP_PROVIDER%NOTFOUND;				  
								  l_o('<TR><TD>'||v_abp_name||'</TD>'||chr(10)||'<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_region||'</TD>'||chr(10)||'<TD>'||v_lookup1||'</TD></TR>'||chr(10));         
							end loop;
							close c_PQP_ABP_PROVIDER;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Dutch SI Provider</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1; 
							l_o('<tr><th>Date From</th><th>Date To</th><th>SI Classification</th><th>Insurance Provider</th><th>Insurance Provider ID</th>');
							l_o('<th>Primary Provider</th><th>Transfer Indicator</th><th>Sender Reporting Name</th><th>Sender Registration Number</th><th>Employer Reporting Name</th>');
							l_o('<th>Employer Registration Number</th></tr>');
						
							v_insurance_name_old:='';
							open c_Dutch_SI_Provider(v_child_id);
							loop
								  fetch c_Dutch_SI_Provider into v_date_from,v_date_to,v_region,v_insurance_name,v_o4,v_lookup1,v_lookup2,v_o16,v_o18,v_o12,v_o20;
								  EXIT WHEN  c_Dutch_SI_Provider%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_region||'</TD>'||chr(10));
								  if v_insurance_name=v_insurance_name_old then
										l_o('<TD>'||v_insurance_name||'</TD>'||chr(10));
								  else
										l_o('<TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; '||v_insurance_name||'</A>');
										l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1;
										
										l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Social Ensurance Details UWV Provider</A>');
										l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1; 
										l_o('<tr><th>Date From</th><th>Date To</th><th>Social_insurance_type_name</th><th>basic_calculation_rule</th><th>employee_contribution_perc</th><th>employer_contribution_perc</th>');
										l_o('<th>Day_Method</th><th>day_adjustment</th><th>contribution_adjustment</th></tr>');
										open c_insurance(v_o4);
										loop
											  fetch c_insurance into v_date_from,v_date_to,v_o3,v_lookup9,v_lookup5,v_o6,v_o7,v_lookup6,v_lookup7,v_lookup8;
											  EXIT WHEN  c_insurance%NOTFOUND;				  
											  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
											  l_o('<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_o6||'</TD>'||chr(10)||'<TD>'||v_o7||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10)||'<TD>'||v_lookup7||'</TD>'||chr(10)||'<TD>'||v_lookup8||'</TD></TR>'||chr(10));         
										end loop;
										close c_insurance;
										l_o('</table><br>');
										
										l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Dutch UWV Organization</A>');
										l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1; 
										l_o('<tr><th>Contact Number</th><th>Provider Type</th><th>Sector</th><th>Risk Group</th><th>Branch Number</th><th>Branch Name</th></tr>');
										
										open c_insurance_org(v_o4);
										loop
											  fetch c_insurance_org into v_o12,v_lookup6,v_lookup7,v_o6,v_o3,v_o8;
											  EXIT WHEN  c_insurance_org%NOTFOUND;				  
											  l_o('<TR><TD>'||v_o12||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10)||'<TD>'||v_lookup7||'</TD>'||chr(10)||'<TD>'||v_o6||'</TD>'||chr(10));
											  l_o('<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_o8||'</TD></TR>'||chr(10));         
										end loop;
										close c_insurance_org;
										l_o('</table><br>');
										
										l_o('</DIV></TD>');
								  end if;
								  
								  v_insurance_name_old:=v_insurance_name;
								  l_o('<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10));
								  l_o('<TD>'||v_o16||'</TD>'||chr(10)||'<TD>'||v_o18||'</TD>'||chr(10));
								  l_o('<TD>'||v_o12||'</TD>'||chr(10)||'<TD>'||v_o20||'</TD></TR>'||chr(10));         
							end loop;
							close c_Dutch_SI_Provider;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Flat Rate Taxaction NL_ORG_FLAT_RATE_TAXATION</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1; 
							l_o('<tr><th>Date From</th><th>Date To</th><th>Taxation Type</th><th>Amount</th><th>Period Type</th>');
							l_o('<th>Payroll Frequency</th><th>Correction</th></tr>');
							open c_Flat_Rate(v_child_id);
							loop
								  fetch c_Flat_Rate into v_date_from,v_date_to,v_region,v_o4,v_lookup1,v_lookup2,v_lookup4;
								  EXIT WHEN  c_Flat_Rate%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_region||'</TD>'||chr(10));
								  l_o('<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10));								 
								  l_o('<TD>'||v_lookup4||'</TD></TR>'||chr(10));         
							end loop;
							close c_Flat_Rate;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; PGGM General Info PQP_NL_PGGM_INFO</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Date From</th><th>Date To</th><th>Holiday Allowance Percentage</th><th>End of Year Bonus Percentage</th><th>PGGM Employee Number</th>');
							l_o('<th>Employer Registration Number</th><th>Life Savings Scheme Percentage</th></tr>');
							open c_PGGM_General(v_child_id);
							loop
								  fetch c_PGGM_General into v_date_from,v_date_to,v_o3,v_o4,v_o5,v_o11,v_o12;
								  EXIT WHEN  c_PGGM_General%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10));
								  l_o('<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_o5||'</TD>'||chr(10)||'<TD>'||v_o11||'</TD>'||chr(10));								 
								  l_o('<TD>'||v_o12||'</TD></TR>'||chr(10));         
							end loop;
							close c_PGGM_General;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; WR Prev Year Correction NL_ORG_WR_PREV_YR_CORRECTION</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;							      
							l_o('<tr><th>Date From</th><th>Date To</th><th>Taxation Type</th><th>Amount</th><th>Period Type</th>');
							l_o('<th>Payroll Frequency</th></tr>');
							open c_WR_Prev_Year(v_child_id);
							loop
								  fetch c_WR_Prev_Year into v_date_from,v_date_to,v_region,v_o4,v_lookup1,v_lookup2;
								  EXIT WHEN  c_WR_Prev_Year%NOTFOUND;				  
								  l_o('<TR><TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_region||'</TD>'||chr(10));
								  l_o('<TD>'||v_o4||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD></TR>'||chr(10));         
							end loop;
							close c_WR_Prev_Year;
						l_o('</table><br>');
						
						l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Wage Report Information NL_ORG_WR_INFO</A>');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;	
        						
							l_o('<tr><th>Sender Id</th><th>Contact Name</th><th>Contact Number</th><th>Paid Assignments Only</th><th>Own Risk Cover</th>');
							l_o('<th>Contact Code Mapping</th></tr>');
							open c_Wage_Report(v_child_id);
							loop
								  fetch c_Wage_Report into v_o11,v_o2,v_o3,v_region,v_lookup1,v_lookup2;
								  EXIT WHEN  c_Wage_Report%NOTFOUND;				  
								  l_o('<TR><TD>'||v_o11||'</TD>'||chr(10)||'<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10));
								  l_o('<TD>'||v_region||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD></TR>'||chr(10));         
							end loop;
							close c_Wage_Report;
						l_o('</table><br>');
						
					l_o('</DIV></TD></TR>'||chr(10));
				  
					v_old:=v_parent_id;
			end loop;
			close c_Hierarchy;
			l_o('</table><br>');
	
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;General Payroll Information</A>');
			l_o('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			l_o('<tr><th>Payroll Name</th><th>Period Type</th><th>First Period End Date</th><th>Number of Years</th><th>Period Reset Years</th>');
			l_o('<th>Pay Date Offset</th><th>Direct Deposit Date Offset</th>');
			l_o('<th>Pay advice date offset</th><th>Cut off date offset</th><th>Payslip view date offset</th><th>Default Payment Method</th><th>Consolidation Set</th>');
			l_o('<th>Workload Shifting Level</th><th>Arrears Flag</th><th>Negative pay allowed flag</th><th>Multi assignments flag</th><th>Legal Employer Name</th>');
			l_o('<th>Modeling Availability Rule</th><th>Days after period start</th><th>Days after period end</th></tr>');
			
			
			open c_payroll(v_bg);
			loop
				  fetch c_payroll into v_payroll_name,v_period_type,v_first_date,v_number_of_years,v_period_reset_years,v_pay_date_offset,v_direct_deposit,v_pay_advice_date_offset,v_cut_off_date,v_payslip_view,v_default_payment,v_consolidation,v_workload_shifting,v_arrears_flag,v_negative_pay,v_multi_assignments,v_legal_employer,v_prl_information21,v_prl_information22,v_modeling_availability,v_payroll_id,v_default_payment_method_id;
				  EXIT WHEN  c_payroll%NOTFOUND;
				  l_o('<TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_payroll_name||'</A>');
					l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						l_o('<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Valid Organizational Payment Methods');
						l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table>');
							if v_default_payment_method_id is null then
							l_o('<tr><td>Default Payment Method is null</th></tr>');
							else
							l_o('<tr><th>Org Payment Method</th><th>Payment Type</th><th>Default Payment Method</th>');
							l_o('<th>Effective Start Date</th><th>Effective End Date</th><th>Org Payment Method ID</th><th>Payment Type ID</th></tr>');
							open c_Organizational(v_payroll_id,v_default_payment_method_id);
							loop
								  fetch c_Organizational into v_org_payment,v_payment_type_name,v_default_payment_method,v_effective_start_date,v_effective_end_date,v_org_payment_method_id,v_payment_type_id;
								  EXIT WHEN  c_Organizational%NOTFOUND;				  
								  l_o('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; '||v_org_payment||'</A>');
								  l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  l_o('<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organizational payment method information');
								  l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table >');
								  l_o('<tr><th>Country</th><th>Bank name</th><th>Account number</th><th>Postal code</th><th>City</th><th>Street</th><th>Telephone number</th><th>');
								  l_o('Telephone extension</th><th>Bank identifier code</th><th>IBAN</th><th>Cost payment</th><th>Cost cleared payment</th><th>Cost cleared void payment</th><th>');
								  l_o('Exclude manual payment</th><th>Transfer to GL flag</th></tr>');
								  open c_org_pay(v_org_payment_method_id);
									loop
										  fetch c_org_pay into v_lookup1,v_lookup2,v_seg2,v_seg3, v_lookup3,v_seg5,v_seg6,v_seg7,v_lookup4,v_seg10,v_lookup9,v_lookup5,v_lookup6,v_lookup7,v_lookup8;
										  EXIT WHEN  c_org_pay%NOTFOUND;				  
										      l_o('<TR><TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10)||'<TD>'||v_seg2||'</TD>'||chr(10));
											  l_o('<TD>'||v_seg3||'</TD>'||chr(10)||'<TD>'||v_lookup3||'</TD>'||chr(10));
											  l_o('<TD>'||v_seg5||'</TD>'||chr(10)||'<TD>'||v_seg6||'</TD>'||chr(10));
											  l_o('<TD>'||v_seg7||'</TD>'||chr(10)||'<TD>'||v_lookup4||'</TD>'||chr(10));
											  l_o('<TD>'||v_seg10||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
											  l_o('<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10));											 
											  l_o('<TD>'||v_lookup7||'</TD>'||chr(10)||'<TD>'||v_lookup8||'</TD></TR>'||chr(10));     
									end loop;
									close c_org_pay;
								l_o('</table><br></div>');							  
								  
								  l_o('</TD>'||chr(10)||'<TD>'||v_payment_type_name||'</TD>'||chr(10)||'<TD>'||v_default_payment_method||'</TD>'||chr(10));
								  l_o('<TD>'||v_effective_start_date||'</TD>'||chr(10));
								  l_o('<TD>'||v_effective_end_date||'</TD>'||chr(10)||'<TD>'||v_org_payment_method_id||'</TD>'||chr(10));								 
								  l_o('<TD>'||v_payment_type_id||'</TD></TR>'||chr(10));         
							end loop;
							close c_Organizational;
							end if;
						l_o('</table><br>');
						
				  l_o('</TD>');
				 
				  
				  l_o('<TD>'||v_period_type||'</TD>'||chr(10)||'<TD>'||v_first_date||'</TD>'||chr(10)||'<TD>'||v_number_of_years||'</TD>'||chr(10));
				  l_o('<TD>'||v_period_reset_years||'</TD>'||chr(10)||'<TD>'||v_pay_date_offset||'</TD>'||chr(10)||'<TD>'||v_direct_deposit||'</TD>'||chr(10));
				  l_o('<TD>'||v_pay_advice_date_offset||'</TD>'||chr(10)||'<TD>'||v_cut_off_date||'</TD>'||chr(10)||'<TD>'||v_payslip_view||'</TD>'||chr(10));
					l_o('<TD>'||v_default_payment||'</TD>'||chr(10)||'<TD>'||v_consolidation||'</TD>'||chr(10)||'<TD>'||v_workload_shifting||'</TD>'||chr(10));
					l_o('<TD>'||v_arrears_flag||'</TD>'||chr(10)||'<TD>'||v_negative_pay||'</TD>'||chr(10)||'<TD>'||v_multi_assignments||'</TD>'||chr(10));
					l_o('<TD>'||v_legal_employer||'</TD>'||chr(10)||'<TD>'||v_modeling_availability||'</TD>'||chr(10)||'<TD>'||v_prl_information21||'</TD>'||chr(10));
					l_o('<TD>'||v_prl_information22||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_payroll;
			l_o('</table><br><br>');			
			
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Pension Providers Information</A>');
			l_o('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			l_o('<tr><th>Organization Name</th></tr>');		
			
			open c_pension_prov(v_bg);
			loop
				  fetch c_pension_prov into v_parent_name,v_o2;
				  EXIT WHEN  c_pension_prov%NOTFOUND;
				   l_o('<TR><TD width="90%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_parent_name||'</A>');
							l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table id="s1sql500'||:v_link_no||'" style="display: none;">');
							:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Pension type id</th><th>Effective start date</th><th>Effective end date</th><th>Pension type name</th><th>Pension category</th>');
							l_o('<th>Pension provider type</th><th>Minimum age</th>');
							l_o('<th>Maximum age</th><th>Employee contribution percent</th><th>Employer contribution percent</th><th>Description</th><th>Special pension type</th>');
							l_o('<th>Pension basis calc method</th><th>Pension sub category</th><th>Employee annual limit</th><th>Employer annual limit</th><th>Employee annual salary thres</th>');
							l_o('<th>Employer annual salary thres</th><th>Salary calculation method</th><th>Contribution conversion rule</th>');
							l_o('<th>Employee contribution balance</th><th>Employer contribution balance</th></tr>');
							open c_pension_types(v_bg,v_o2);							
							loop
								  fetch c_pension_types into v_pension_type_id,v_effective_start_date ,v_effective_end_date,v_pension_type_name,v_lookup1,v_lookup2,
								  v_minimum_age,v_maximum_age,v_ee_contribution_percent,v_er_contribution_percent,v_description,v_special_pension_type_code,
								  v_pens_calc,v_pension_sub_category,v_ee_annual_limit,v_er_annual_limit,v_ee_annual_salary_threshold,v_er_annual_salary_threshold,
								  v_lookup3,v_lookup4,v_bal1,v_bal2;
								  EXIT WHEN  c_pension_types%NOTFOUND; 
								  l_o('<TD>'||v_pension_type_id||'</TD>'||chr(10)||'<TD>'||v_effective_start_date||'</TD>'||chr(10)||'<TD>'||v_effective_end_date||'</TD>'||chr(10));
								  l_o('<TD>'||v_pension_type_name||'</TD>'||chr(10)||'<TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10));
								  l_o('<TD>'||v_minimum_age||'</TD>'||chr(10)||'<TD>'||v_maximum_age||'</TD>'||chr(10)||'<TD>'||v_ee_contribution_percent||'</TD>'||chr(10));
								  l_o('<TD>'||v_er_contribution_percent||'</TD>'||chr(10)||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_special_pension_type_code||'</TD>'||chr(10));
								  l_o('<TD>'||v_pens_calc||'</TD>'||chr(10)||'<TD>'||v_pension_sub_category||'</TD>'||chr(10)||'<TD>'||v_ee_annual_limit||'</TD>'||chr(10));
								  l_o('<TD>'||v_er_annual_limit||'</TD>'||chr(10)||'<TD>'||v_ee_annual_salary_threshold||'</TD>'||chr(10)||'<TD>'||v_er_annual_salary_threshold||'</TD>'||chr(10));
								  l_o('<TD>'||v_lookup3||'</TD>'||chr(10)||'<TD>'||v_lookup4||'</TD>'||chr(10)||'<TD>'||v_bal1||'</TD>'||chr(10));					
								  l_o('<TD>'||v_bal2||'</TD></TR>'||chr(10));	  

							end loop;
							close c_pension_types;
							l_o('</table><br><br>');						
				  l_o('</TD></TR>');
			end loop;
			close c_pension_prov;
			l_o('</table><br><br>');			
			
			
			l_o('</DIV>');
			l_o('</DIV>');        
			
        end loop;
    close c_bg;
                            
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o('</TD></TR> <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri"><i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR></TABLE></div>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;


procedure bg_ie (v_leg varchar2, v_no number) is
cursor c_bg is
	SELECT organization_id,ho.business_group_id,name,type,date_from,date_to,location_code,internal_external_flag FROM hr_all_organization_units ho, hr_locations_all hl
		where ho.location_id=hl.location_id(+)
		and organization_id  in 
		(
		select organization_id from hr_organization_information 
		where org_information9 = 'IE'
		and org_information_context = 'Business Group Information'
		);
	v_bg hr_all_organization_units.organization_id%type;
	v_bg_id hr_all_organization_units.business_group_id%type;
	v_name hr_all_organization_units.name%type;
	v_type hr_all_organization_units.type%type;
	v_date_from hr_all_organization_units.date_from%type;
	v_date_to hr_all_organization_units.date_to%type;
	v_location hr_locations_all.location_code%type;
	v_internal_external_flag hr_all_organization_units.internal_external_flag%type;
	cursor c_info_setup (t_bg  NUMBER) is
		select org_information_id,org_information_context,org_information1 short_name,
			     hr_general_utilities.get_lookup_meaning('EMP_NUM_GEN_METHOD',org_information2) employee_number_generation
					,hr_general_utilities.get_lookup_meaning('APL_NUM_GEN_METHOD',org_information3) applicant_number_generation
					,hr_general_utilities.get_lookup_meaning('CWK_NUM_GEN_METHOD',org_information16) contingent_worker_numb_gen
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information4
							AND id_flex_code = 'GRD')       grade_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information5
							AND id_flex_code = 'GRP')        group_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information6
							AND id_flex_code = 'JOB')        job_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information7
							AND id_flex_code = 'COST')       costing_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information8
							AND id_flex_code = 'POS')        position_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information15
							AND id_flex_code = 'CMP')        competence_flexfield_structure
			,org_information9 Legislation_code,org_information10 currency,org_information11 fiscal_year_start ,org_information12 min_working_age,org_information13 max_working_age
			from hr_organization_information 
			where org_information9 = 'IE'
			and org_information_context = 'Business Group Information'
			and  organization_id = t_bg;
	v_en fnd_lookups.meaning%type;
	v_an fnd_lookups.meaning%type;
	v_cn fnd_lookups.meaning%type;
	v_org_info_id hr_organization_information.org_information_id%type;
	v_org_info_context hr_organization_information.org_information_context%type;
	v_o1 hr_organization_information.org_information1%type;
	v_o2 hr_organization_information.org_information2%type;
	v_o3 hr_organization_information.org_information3%type;
	v_o4 hr_organization_information.org_information4%type;
	v_o5 hr_organization_information.org_information5%type;
	v_o6 hr_organization_information.org_information6%type;
	v_o7 hr_organization_information.org_information7%type;
	v_o8 hr_organization_information.org_information8%type;
	v_o9 hr_organization_information.org_information9%type;
	v_o10 hr_organization_information.org_information10%type;
	v_o11 hr_organization_information.org_information11%type;
	v_o12 hr_organization_information.org_information12%type;
	v_o13 hr_organization_information.org_information13%type;
	v_o14 hr_organization_information.org_information14%type;
	v_o15 hr_organization_information.org_information15%type;
	v_o16 hr_organization_information.org_information16%type;
	v_o17 hr_organization_information.org_information17%type;
	v_o18 hr_organization_information.org_information18%type;
	v_o19 hr_organization_information.org_information19%type;
	v_o20 hr_organization_information.org_information20%type;
	v_grade_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_group_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_job_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_costing_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_position_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_competence_flex fnd_id_flex_structures_vl.id_flex_structure_name%type;
			
	cursor c_paypath_setup (t_bg  NUMBER) is		
			select org_information_id,
			org_information_context,
			org_information8 paypath_id,
			org_information9 receiver_id, 
			org_information10 users_narrative,
			org_information11 file_format  
			FROM hr_organization_information 
			where upper(org_information_context) like 'IE_PAYPATH_INFORMATION%'
			and  organization_id = t_bg;
	cursor c_le (t_bg  NUMBER) is
		SELECT organization_id,name,type,date_from,date_to,location_code,internal_external_flag FROM hr_all_organization_units ho, hr_locations_all hl
			where ho.location_id=hl.location_id(+)
			and organization_id  in 
			(
			select organization_id from hr_organization_information 
			where org_information_context = 'IE_EMPLOYER_INFO'
			)			
			and ho.business_group_id = t_bg;
	v_le_id hr_all_organization_units.organization_id%type;
	cursor c_le_details (t_bg  NUMBER) is
		select 	org_information_id, org_information_context,
			org_information1 type,
			org_information2 description, 
			org_information3  detail
			from hr_organization_information 
			where org_information_context = 'ORG_CONTACT_DETAILS'
			and  organization_id = t_bg;
	cursor c_le_EHECS (t_bg  NUMBER) is
		select 	org_information_id, org_information_context,
		org_information1 Year,
		org_information2 Quarter,
		org_information3 CBR_Number,
		org_information4 Managers_not_on_payroll,
		org_information5 Clerks_not_on_payroll,
		org_information6 Other_workers_not_on_payroll,
		org_information7 Vacancies_for_managers,
		org_information8 Vacancies_for_Clerks,
		org_information9 Vacanacies_for_other_workers,
		org_information10 employers_liability_insurance,
		org_information11 training_cost,
		org_information12 labor_related_exp,
		org_information13 declarant_contact_id, 
		org_information17 declarant_pos,
		org_information19 declarant_email,
		org_information20 declarant_phone,
		org_information14 training_subsidy,
		org_information15 other_subsidy,
		org_information16 refunds,
		org_information18 hours_per_day
		from hr_organization_information 
		where org_information_context = 'IE_EHECS'
		and  organization_id = t_bg;
	cursor c_le_EHECS_Override (t_bg  NUMBER) is
		select 	org_information_id, org_information_context,
		org_information13 Quarter_End_date,
		org_information1 Occuptional_Category, 
		org_information2  employment_type,
		org_information3  min_wage_rate_employee,
		org_information4  regular_earnings,
		org_information5  overtime_payments,
		org_information6  irregular_earnings,
		org_information12  normal_working_hours,
		org_information7  paid_overtime_hours,
		org_information8  annual_leave_hours,
		org_information9  paid_maternity_hours,
		org_information10  paid_sick_leave_hours,
		org_information11  paid_other_leave_hours,
		org_information14 income_continuous_insurance,
		org_information15 redundancy_payments,
		org_information16 other_employee_payments,
		org_information17 stocks_or_shares,
		org_information18 vol_sickness_insurance,
		org_information19 staff_housing_cost,
		org_information20 other_benefits_cost
		from hr_organization_information 
		where org_information_context = 'IE_EHECS_OVERRIDE'
		and  organization_id = t_bg;
	cursor c_le_info (t_bg  NUMBER) is
		select 	org_information_id, org_information_context,
		org_information1 tax_distict_reference,
		org_information2 employer_PAYE_reference,
		org_information3 employer_trading_name,
		org_information4 Employer_tax_ref_contact,
		org_information5 health_levy
		from hr_organization_information 
		where org_information_context = 'IE_EMPLOYER_INFO'
		and  organization_id = t_bg;
		
		cursor c_payroll (t_bg  NUMBER) is
				select prl.payroll_id,prl.payroll_name,
					prl.period_type
					,prl.first_period_end_date
					,prl.number_of_years
					,prl.period_reset_years
					,prl.pay_date_offset
					,prl.direct_deposit_date_offset
					,prl.pay_advice_date_offset
					,prl.cut_off_date_offset
					,prl.payslip_view_date_offset
					,nvl (opm.org_payment_method_name, 'No Default Payment Method Set')
					   default_payment_method
					,con.consolidation_set_name consolidation_set												
					,prl.default_payment_method_id default_payment_method_id
					,prl.SOFT_CODING_KEYFLEX_ID,pp.paypath_id Ireland_PayPath_Info, le.name Legal_Employer
					from pay_all_payrolls_f prl,
					pay_org_payment_methods_f opm,
					pay_consolidation_sets con, 
					(select * from hr_soft_coding_keyflex where 
					DECODE( TRANSLATE(segment2,'0123456789',' '), NULL, 'number','contains char') != 'contains char'
					AND
					DECODE( TRANSLATE(segment4,'0123456789',' '), NULL, 'number','contains char') != 'contains char'
					) flex ,
					(SELECT organization_id,name
					 FROM hr_all_organization_units
					 where organization_id  in 
					  (
					   select organization_id from hr_organization_information 
					   where org_information_context = 'IE_EMPLOYER_INFO'
					  )
					  ) LE,
					  (
					  select 
					org_information_id,
					org_information8 paypath_id
					FROM hr_organization_information 
					where upper(org_information_context) like 'IE_PAYPATH_INFORMATION%'
					) pp
					where 
					 con.consolidation_set_id = prl.consolidation_set_id
						 AND opm.org_payment_method_id(+) = prl.default_payment_method_id
					and flex.SOFT_CODING_KEYFLEX_ID =prl.SOFT_CODING_KEYFLEX_ID
					and flex.segment4 = le.organization_id(+)
					and flex.segment2 = pp.org_information_id(+)
					AND sysdate BETWEEN prl.effective_start_date AND prl.effective_end_date
					and prl.business_group_id = t_bg
					order by 2;
	v_payroll_id pay_all_payrolls_f.payroll_id%type;	
	v_payroll_name pay_all_payrolls_f.payroll_name%type;
	v_soft pay_all_payrolls_f.SOFT_CODING_KEYFLEX_ID%type;
	v_le_name hr_all_organization_units.name%type;
	
	v_period_type pay_all_payrolls_f.period_type%type;
	v_first_date pay_all_payrolls_f.first_period_end_date%type;
	v_number_of_years pay_all_payrolls_f.number_of_years%type;
	v_period_reset_years pay_all_payrolls_f.period_reset_years%type;
	v_pay_date_offset pay_all_payrolls_f.pay_date_offset%type;
	v_direct_deposit pay_all_payrolls_f.direct_deposit_date_offset%type;
	v_pay_advice_date_offset pay_all_payrolls_f.pay_advice_date_offset%type;
	v_cut_off_date pay_all_payrolls_f.cut_off_date_offset%type;
	v_payslip_view pay_all_payrolls_f.payslip_view_date_offset%type;
	v_default_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_consolidation pay_consolidation_sets.consolidation_set_name%type;	
	v_legal_employer hr_all_organization_units.name%type;
	
	
	cursor c_Organizational (t_pid  NUMBER, t_dpmid NUMBER) is
			SELECT   opm.org_payment_method_name org_paymentmethod_name
				,pt.payment_type_name payment_type
				,CASE
				   WHEN opu.org_payment_method_id = t_dpmid
				   THEN
					 'Yes'
				   ELSE
					 'No'
				 END default_payment_method
				,opu.effective_start_date
				,opu.effective_end_date
				,opu.org_payment_method_id
				,pt.payment_type_id
		FROM     pay_org_pay_method_usages_f opu
				,pay_org_payment_methods_f opm
				,pay_payment_types pt
		WHERE    1 = 1
			 AND opm.org_payment_method_id = opu.org_payment_method_id
			 AND pt.payment_type_id = opm.payment_type_id
			 AND sysdate between opm.effective_start_date and opm.effective_end_date
			 AND sysdate between opu.effective_start_date and opu.effective_end_date
			 AND opu.payroll_id = t_pid
			 order by 1;
	
	
	v_org_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_payment_type_name pay_payment_types.payment_type_name%type;
	v_default_payment_method_id pay_all_payrolls_f.default_payment_method_id%type;
	v_default_payment_method varchar2(10);
	v_effective_start_date pay_org_pay_method_usages_f.effective_start_date%type;
	v_effective_end_date pay_org_pay_method_usages_f.effective_end_date%type;
	v_org_payment_method_id pay_org_pay_method_usages_f.org_payment_method_id%type;
	v_payment_type_id pay_payment_types.payment_type_id%type;
		
begin
		
	l_o('<br><DIV class=divItem>');
	l_o('<DIV  class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b"  onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Business Group Information</A></DIV>');					
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql500'||:v_link_no||'" style="display:none" >');
	:v_link_no:=:v_link_no+1;
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('     <B>Business Group Information:</B></font></TD>');
    l_o('     <TD bordercolor="#DEE6EF">');
    l_o('       <A class=detail  onclick="displayItem2(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    l_o('   </TD></TR><TR id="s1sql500'||:v_link_no||'" style="display:none">');
	:v_link_no:=:v_link_no+1;
    l_o('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    l_o('       <blockquote><p align="left">');
	l_o('    SELECT organization_id,ho.business_group_id,name,type,date_from,date_to,location_code,internal_external_flag<br>');
	l_o('FROM hr_all_organization_units ho, hr_locations_all hl<br>');
	l_o('ho.location_id=hl.location_id<br>');
	l_o('    and organization_id  in (<br>');
	l_o('    select organization_id from hr_organization_information <br>');
	l_o('    where org_information9 = ''IE''<br>');
	l_o('    and org_information_context = ''Business Group Information'');<br>');	
    l_o('          </blockquote><br></TD></TR>');
       
		
    :n := dbms_utility.get_time;
    l_o(' <TR><TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	
		
    open c_bg;
        loop
            fetch c_bg into v_bg,v_bg_id,v_name,v_type,v_date_from,v_date_to,v_location,v_internal_external_flag;
            EXIT WHEN  c_bg%NOTFOUND;
			l_o('<DIV class=divItem>');
			l_o('<DIV class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_name||'</A></DIV>');
			l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;
			l_o('<br>Organisation ID: '|| v_bg||'<br>');
			l_o('Business Group ID: '|| v_bg_id||'<br>');
			l_o('Type: '|| v_type||'<br>');		
			l_o('Date from: '|| v_date_from||'<br>');
			l_o('Date to: '|| v_date_to||'<br>');
			l_o('Location: '|| v_location||'<br>');
			l_o('Internal External Flag: '|| v_internal_external_flag||'<br><br>');
			
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Business Group Info Setup</A>');
						l_o('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Org Information ID</th><th>Org Information Context</th><th>Short Name</th><th>Employee Number Generation</th><th>App Number Generation</th>');
							l_o('<th>Contingent Number Generation</th><th>Grade Flexfield Structure</th><th>Group Flexfield Structure</th>');
							l_o('<th>Job Flexfield Structure</th><th>Costing Flexfield Structure</th><th>Position Flexfield Structure</th><th>Competence Flexfield Structure</th>');
							l_o('<th>Legislation Code</th><th>Currency</th><th>Fiscal Year Start</th><th>Min Working Age</th><th>Max Working Age</th></tr>');
											    
							open c_info_setup(v_bg);
							loop
								  fetch c_info_setup into v_org_info_id,v_org_info_context,v_o1,v_en,v_an,v_cn,v_grade_flexfield_structure,v_group_flexfield_structure,v_job_flexfield_structure,v_costing_flexfield_structure,v_position_flexfield_structure,v_competence_flex,v_o9,v_o10,v_o11,v_o12,v_o13;
								  EXIT WHEN  c_info_setup%NOTFOUND;				  
								  l_o('<TR><TD>'||v_org_info_id||'</TD>'||chr(10)||'<TD>'||v_org_info_context||'</TD>'||chr(10)||'<TD>'||v_o1||'</TD>'||chr(10));
								  l_o('<TD>'||v_en||'</TD>'||chr(10)||'<TD>'||v_an||'</TD>'||chr(10));  
								  l_o('<TD>'||v_cn||'</TD>'||chr(10)||'<TD>'||v_grade_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_group_flexfield_structure||'</TD>'||chr(10));
								  l_o('<TD>'||v_job_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_costing_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_position_flexfield_structure||'</TD>'||chr(10));
								  l_o('<TD>'||v_competence_flex||'</TD>'||chr(10)||'<TD>'||v_o9||'</TD>'||chr(10));
								  l_o('<TD>'||v_o10||'</TD>'||chr(10)||'<TD>'||v_o11||'</TD>'||chr(10));  
								  l_o('<TD>'||v_o12||'</TD>'||chr(10)||'<TD>'||v_o13||'</TD></TR>'||chr(10));         
							end loop;
							close c_info_setup;
						l_o('</table><br>');
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Paypath Setup</A>');
						l_o('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Org Information ID</th><th>Org Information Context</th><th>Paypath ID</th><th>Receiver ID</th><th>Users Narrative</th>');
							l_o('<th>File Format</th></tr>');
											    
							open c_paypath_setup(v_bg);
							loop
								  fetch c_paypath_setup into v_org_info_id,v_org_info_context,v_o8,v_o9,v_o10,v_o11;
								  EXIT WHEN  c_paypath_setup%NOTFOUND;				  
								  l_o('<TR><TD>'||v_org_info_id||'</TD>'||chr(10)||'<TD>'||v_org_info_context||'</TD>'||chr(10)||'<TD>'||v_o8||'</TD>'||chr(10));
								  l_o('<TD>'||v_o9||'</TD>'||chr(10)||'<TD>'||v_o10||'</TD>'||chr(10));  
								  l_o('<TD>'||v_o11||'</TD></TR>'||chr(10));         
							end loop;
							close c_paypath_setup;
						l_o('</table><br>');
			--Legal Employers
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Legal Employers</A>');
						l_o('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
						:v_link_no:=:v_link_no+1;
							l_o('<tr><th>Legal Employers ID - Name</th><th>Type</th><th>Date From</th><th>Date To</th><th>Location</th><th>Internal External Flag</th></tr>');
											    
							open c_le(v_bg);
							loop
								  fetch c_le into v_le_id,v_name,v_type,v_date_from,v_date_to,v_location,v_internal_external_flag;
								  EXIT WHEN  c_le%NOTFOUND;				  
								  l_o('<TR><TD width="50%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_le_id||' - '||v_name||'</A>');
								  l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
										-- Legal Employer Classification , Contact Details
										l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Contact Details</A>');
										l_o('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1;
											l_o('<tr><th>Org Information ID</th><th>Org Information Context</th><th>Type</th><th>Description</th><th>Detail</th></tr>');
											open c_le_details(v_le_id);
											loop
												  fetch c_le_details into v_org_info_id,v_org_info_context,v_o1,v_o2,v_o3;
												  EXIT WHEN  c_le_details%NOTFOUND;				  
												  l_o('<TR><TD>'||v_org_info_id||'</TD>'||chr(10)||'<TD>'||v_org_info_context||'</TD>'||chr(10)||'<TD>'||v_o1||'</TD>'||chr(10));
												  l_o('<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD></TR>'||chr(10));         
											end loop;
											close c_le_details;
										l_o('</table><br>');
										
										-- Legal Employer Classification , IE_EHECS (EHECS Information)
										l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; IE_EHECS (EHECS Information)</A>');
										l_o('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1;
											l_o('<tr><th>Org Information ID</th><th>Org Information Context</th><th>Year</th><th>Quarter</th><th>CBR Number</th>');
											l_o('<th>Managers Not On Payroll</th><th>Clerks Not On Payroll</th>');
											l_o('<th>Vacancies for Managers</th><th>Vacancies for Clerks</th><th>Other Workers not on Payroll</th>');
											l_o('<th>Vacanacies for other workers</th><th>Employers Liability Insurance</th><th>Training cost</th><th>Labor Related Exp</th><th>Declarant Contact ID</th>');
											l_o('<th>Declarant Pos</th><th>Declarant Email</th><th>Declarant Phone</th><th>Training Subsidy</th><th>Other Subsidy</th>');
											l_o('<th>Refunds</th><th>Hours per day</th></tr>');
											open c_le_EHECS(v_le_id);
											loop
												  fetch c_le_EHECS into v_org_info_id,v_org_info_context,v_o1,v_o2,v_o3,v_o4,v_o5,v_o6,v_o7,v_o8,v_o9,v_o10,v_o11,v_o12,v_o13,v_o17,v_o19,v_o20,v_o14,v_o15,v_o16,v_o18;
												  EXIT WHEN  c_le_EHECS%NOTFOUND;				  
												  l_o('<TR><TD>'||v_org_info_id||'</TD>'||chr(10)||'<TD>'||v_org_info_context||'</TD>'||chr(10)||'<TD>'||v_o1||'</TD>'||chr(10));
												  l_o('<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_o4||'</TD>'||chr(10)||'<TD>'||v_o5||'</TD>');
												  l_o('<TD>'||v_o6||'</TD>'||chr(10)||'<TD>'||v_o7||'</TD>'||chr(10)||'<TD>'||v_o8||'</TD>'||chr(10)||'<TD>'||v_o9||'</TD>');
												  l_o('<TD>'||v_o10||'</TD>'||chr(10)||'<TD>'||v_o11||'</TD>'||chr(10)||'<TD>'||v_o12||'</TD>'||chr(10)||'<TD>'||v_o13||'</TD>');
												  l_o('<TD>'||v_o17||'</TD>'||chr(10)||'<TD>'||v_o19||'</TD>'||chr(10)||'<TD>'||v_o20||'</TD>'||chr(10)||'<TD>'||v_o14||'</TD>');
												  l_o('<TD>'||v_o15||'</TD>'||chr(10)||'<TD>'||v_o16||'</TD>'||chr(10)||'<TD>'||v_o18||'</TD></TR>'||chr(10));         
											end loop;
											close c_le_EHECS;
										l_o('</table><br>');
										
										-- Legal Employer Classification , IE_EHECS_OVERRIDE (EHECS Override Info)
										l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; IE_EHECS_OVERRIDE (EHECS Override Info)</A>');
										l_o('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1;
											l_o('<tr><th>Org Information ID</th><th>Org Information Context</th><th>Year</th><th>Quarter End date</th><th>Occuptional Category</th>');
											l_o('<th>Employment Type</th><th>Min Wage Rate Employee</th>');
											l_o('<th>Regular Earnings</th><th>Overtime Payments</th><th>Irregular Earnings</th>');
											l_o('<th>Normal Working Hours</th><th>Paid OvertimeHours</th><th>Annual Leave Hours</th><th>Paid Maternity Hours</th><th>Paid Sick Leave Hours</th>');
											l_o('<th>Paid Other Leave Hours</th><th>Income Continuous Insurance</th><th>Redundancy Payments</th><th>Other Employee Payments</th><th>Stocks or Shares</th>');
											l_o('<th>Vol Sickness Insurance</th><th>Staff Housing Cost</th><th>Other Benefits Cost</th></tr>');
											 
											open c_le_EHECS_Override(v_le_id);
											loop
												  fetch c_le_EHECS_Override into v_org_info_id,v_org_info_context,v_o13,v_o1,v_o2,v_o3,v_o4,v_o5,v_o6,v_o12,v_o7,v_o8,v_o9,v_o10,v_o11,v_o14,v_o15,v_o16,v_o17,v_o18,v_o19,v_o20;
												  EXIT WHEN  c_le_EHECS_Override%NOTFOUND;				  
												  l_o('<TR><TD>'||v_org_info_id||'</TD>'||chr(10)||'<TD>'||v_org_info_context||'</TD>'||chr(10)||'<TD>'||v_o13||'</TD>'||chr(10));
												  l_o('<TD>'||v_o1||'</TD>'||chr(10)||'<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_o4||'</TD>');
												  l_o('<TD>'||v_o5||'</TD>'||chr(10)||'<TD>'||v_o6||'</TD>'||chr(10)||'<TD>'||v_o12||'</TD>'||chr(10)||'<TD>'||v_o7||'</TD>');
												  l_o('<TD>'||v_o8||'</TD>'||chr(10)||'<TD>'||v_o9||'</TD>'||chr(10)||'<TD>'||v_o10||'</TD>'||chr(10)||'<TD>'||v_o11||'</TD>');
												  l_o('<TD>'||v_o14||'</TD>'||chr(10)||'<TD>'||v_o15||'</TD>'||chr(10)||'<TD>'||v_o16||'</TD>'||chr(10)||'<TD>'||v_o17||'</TD>');
												  l_o('<TD>'||v_o18||'</TD>'||chr(10)||'<TD>'||v_o19||'</TD>'||chr(10)||'<TD>'||v_o20||'</TD></TR>'||chr(10));         
											end loop;
											close c_le_EHECS_Override;
										l_o('</table><br>');
										
										
										-- Legal Employer Classification , Employer Information
										l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Employer Information</A>');
										l_o('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
										:v_link_no:=:v_link_no+1;
											l_o('<tr><th>Org Information ID</th><th>Org Information Context</th><th>Year</th><th>Tax Distict Reference</th><th>Employer PAYE Reference</th>');
											l_o('<th>Employer Trading Name</th><th>Employer Tax Ref Contact</th><th>Health Levy</th></tr>');
											      
											open c_le_info(v_le_id);
											loop
												  fetch c_le_info into v_org_info_id,v_org_info_context,v_o1,v_o2,v_o3,v_o4,v_o5;
												  EXIT WHEN  c_le_info%NOTFOUND;				  
												  l_o('<TR><TD>'||v_org_info_id||'</TD>'||chr(10)||'<TD>'||v_org_info_context||'</TD>'||chr(10)||'<TD>'||v_o1||'</TD>'||chr(10));
												  l_o('<TD>'||v_o2||'</TD>'||chr(10)||'<TD>'||v_o3||'</TD>'||chr(10)||'<TD>'||v_o4||'</TD>'||chr(10)||'<TD>'||v_o5||'</TD></TR>'||chr(10));         
											end loop;
											close c_le_info;
										l_o('</table><br>');
										
								  l_o('<br><br></TD>'||chr(10));
								  l_o('<TD>'||v_type||'</TD>'||chr(10)||'<TD>'||v_date_from||'</TD>'||chr(10));
								  l_o('<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_location||'</TD>'||chr(10));  
								  l_o('<TD>'||v_internal_external_flag||'</TD></TR>'||chr(10));         
							end loop;
							close c_le;
						l_o('</table><br>');
			
			--General Payroll Information
			l_o('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;General Payroll Information</A>');
			l_o('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;		
			l_o('<tr><th width="35%">Payroll ID - Name</th><th>Period Type</th><th>First Period End Date</th><th>Number of Years</th><th>Period Reset Years</th>');
			l_o('<th>Pay Date Offset</th><th>Direct Deposit Date Offset</th>');
			l_o('<th>Pay advice date offset</th><th>Cut off date offset</th><th>Payslip view date offset</th><th>Default Payment Method</th><th>Consolidation Set</th>');			
			l_o('<th>SOFT_CODING_KEYFLEX_ID</th><th>Ireland PayPath Info</th><th>Legal Employer</th></tr>');			
			
			open c_payroll(v_bg_id);
					loop
						  fetch c_payroll into v_payroll_id,v_payroll_name,v_period_type,v_first_date,v_number_of_years,v_period_reset_years,v_pay_date_offset,v_direct_deposit,v_pay_advice_date_offset,v_cut_off_date,v_payslip_view,v_default_payment,v_consolidation,v_default_payment_method_id,v_soft,v_o8,v_le_name;
						  EXIT WHEN  c_payroll%NOTFOUND;
						   l_o('<TD width="35%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_payroll_id||' - '||v_payroll_name||'</A>');
							l_o('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
							:v_link_no:=:v_link_no+1;	
								l_o('<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Valid Organizational Payment Methods');
								l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table>');
									if v_default_payment_method_id is null then
									l_o('<tr><td>Default Payment Method is null</th></tr>');
									else
									l_o('<tr><th>Org Payment Method</th><th>Payment Type</th><th>Default Payment Method</th>');
									l_o('<th>Effective Start Date</th><th>Effective End Date</th><th>Org Payment Method ID</th><th>Payment Type ID</th></tr>');
									open c_Organizational(v_payroll_id,v_default_payment_method_id);
									loop
										  fetch c_Organizational into v_org_payment,v_payment_type_name,v_default_payment_method,v_effective_start_date,v_effective_end_date,v_org_payment_method_id,v_payment_type_id;
										  EXIT WHEN  c_Organizational%NOTFOUND;				  
										  l_o('<TR><TD>'||v_org_payment||'</TD>'||chr(10)||'<TD>'||v_payment_type_name||'</TD>'||chr(10)||'<TD>'||v_default_payment_method||'</TD>'||chr(10));
										  l_o('<TD>'||v_effective_start_date||'</TD>'||chr(10));
										  l_o('<TD>'||v_effective_end_date||'</TD>'||chr(10)||'<TD>'||v_org_payment_method_id||'</TD>'||chr(10));								 
										  l_o('<TD>'||v_payment_type_id||'</TD></TR>'||chr(10));         
									end loop;
									close c_Organizational;
									end if;
								l_o('</table><br>');
								
						  l_o('<br><br></TD>');						 
						  
						  l_o('<TD>'||v_period_type||'</TD>'||chr(10)||'<TD>'||v_first_date||'</TD>'||chr(10)||'<TD>'||v_number_of_years||'</TD>'||chr(10));
						  l_o('<TD>'||v_period_reset_years||'</TD>'||chr(10)||'<TD>'||v_pay_date_offset||'</TD>'||chr(10)||'<TD>'||v_direct_deposit||'</TD>'||chr(10));
						  l_o('<TD>'||v_pay_advice_date_offset||'</TD>'||chr(10)||'<TD>'||v_cut_off_date||'</TD>'||chr(10)||'<TD>'||v_payslip_view||'</TD>'||chr(10));
						  l_o('<TD>'||v_default_payment||'</TD>'||chr(10)||'<TD>'||v_consolidation||'</TD>'||chr(10));						 
						  l_o('<TD>'||v_soft||'</TD>'||chr(10)||'<TD>'||v_o8||'</TD>'||chr(10)||'<TD>'||v_le_name||'</TD></TR>'||chr(10));
			end loop;
			close c_payroll;
			l_o('<br></table><br>');
			
			l_o('</DIV>');
			l_o('</DIV>');        
			
        end loop;
    close c_bg;
                            
    
    :n := (dbms_utility.get_time - :n)/100;
    l_o('</TD></TR> <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> ');
	l_o('</div>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;



procedure ie is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page13" style="display: none;">'); header('Ireland');
			l_o('<div class="divSection">');
			l_o('<a name="Irelandp"></a><div class="divSectionTitle">Patching</div>');
			l_o('<br><div class="divItem">');
			l_o('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('IE','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('IE','20460989', 'Ireland Cumulative Legislative Patch 2015');
					dpatch('IE','20210371', 'USC On Tax Information Screen');
					dpatch('IE','20073662', 'Ireland Budget Changes Effective 01-JAN-2015');
					dpatch('IE','19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif (:apps_rel like '12.1%') then					
					dpatch('IE','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('IE','20195113', 'Ireland Electronic P60 Changes');
					dpatch('IE','20255656', 'Employer PAYE Reference Reporting Changes');
					dpatch('IE','20235946', 'Employers PAYE Reference Increased To 9 Characters');
					dpatch('IE','20210371', 'USC On Tax Information Screen');
					dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
					dpatch('IE','20073662', 'Ireland Budget Changes Effective 01-JAN-2015');
					dpatch('IE','18510224','IE MEDICAL INSURANCE CHANGES 2014');
					dpatch('IE','19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					dpatch('IE','19060389', 'Ireland P35 Version 11 Reporting Changes');
					dpatch('IE','19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif (:apps_rel like '12.0%') then					
					dpatch('IE','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('IE','20255656', 'Employer PAYE Reference Reporting Changes');
					dpatch('IE','20235946', 'Employers PAYE Reference Increased To 9 Characters');
					dpatch('IE','20210371', 'USC On Tax Information Screen');
					dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
					dpatch('IE','20073662', 'Ireland Budget Changes Effective 01-JAN-2015');
					dpatch('IE','18510224','IE MEDICAL INSURANCE CHANGES 2014');
					dpatch('IE','19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					dpatch('IE','19060389', 'Ireland P35 Version 11 Reporting Changes');
					dpatch('IE','19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif :apps_rel like '11.5%' then					
					dpatch('IE','12807777', 'HR_PF.K.RUP.7');
					dpatch('IE','16811068', 'Ireland Local Property Tax And Report Changes');
					dpatch('IE','16905146', 'Ireland Local Property Tax P30 Paper Report Changes');
					dpatch('IE','16925013', 'LPT Deducting Over 5 Not 6 Months From July 2013');
					dpatch('IE','16976741', 'IE P30 Paper Report Not Reporting Non Zero USC/LPT');
					dpatch('IE','16999708', 'LPT Deducing From Statutory Redundancy');
					dpatch('IE','17180755', 'IE SEPA FURTHER CHANGES: AIB FORMAT'); 
					dpatch('IE','17542073', 'IE SEPA HSBC BANK CHANGES');
					dpatch('IE','17573671', 'IE SEPA ULSTER BANK CHANGES');
					dpatch('IE','17592973', 'Generating SEPA File For PayPath Payment Method, SEPA Danske Bank Format');
					dpatch('IE','17731547', 'EAP NOVEMBER 2013 ISSUES: P35 XML REPORT CHANGES');
					dpatch('IE','17775887', 'IRELAND SEPA CHANGES: HSBC FORMAT: FEEDBACK FROM HSBC');			
				end if;				
			l_o('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
								l_o('</div>');	
							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then		
								l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
								l_o('</div>');		
							elsif :rup_level='13774477' then
								l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IE','16811074','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');
								l_o('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777' or :rup_level='14488556' then		
								l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IE','16811068','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br><a name="Irelandd"></a>'); datainstall('IE',13);
			l_o('<a name="Irelands"></a>');bg_ie('IE',13);l_o('</div>');
			l_o('<a name="Irelandv"></a>');file_version('ie');
			l_o('</div>');
			documents('315825.1', 'Oracle HRMS for Ireland Supplement', '1609505.2','Information Center: Oracle HRMS (Ireland)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;




procedure nl is
v_exists number;
begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NL'  and status='I';     
     if v_exists>0 then
			l_o('<div id="page20" style="display: none;">');header('Netherlands');
			l_o('<div class="divSection">');
			l_o('<a name="Netherlandsp"></a><div class="divSectionTitle">Patching</div>');
			l_o('<br><div class="divItem">');
			l_o('<div class="divItemTitle">Mandatory Patches</div>');	
			 if (:apps_rel like '12.2%') then					
					dpatch('NL','19193000', 'R12.HR_PF.C.Delta.6');	
					dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
					dpatch('NL','20972577', 'Legislative Changes - Legal Minimum Wages effective from 01-Jul-2015');
				elsif (:apps_rel like '12.1%') then						
					dpatch('NL','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
					dpatch('NL','20972577', 'Legislative Changes - Legal Minimum Wages effective from 01-Jul-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('NL','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');				
				elsif :apps_rel like '11.5%' then					
					dpatch('NL','12807777', 'HR_PF.K.RUP.7');
					dpatch('NL','17558120', 'Delivers changes to Dutch Annual Tax Statement for the Employee Report effective 2013');				
				end if;												
			l_o('</div>');
			
			if (:hr_status='Installed') then
						if (:apps_rel like '12.2%') then
							l_o('<br><div class="divItem">');
							l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
							dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
							l_o('</div>');
						elsif (:apps_rel like '12.1%') then						
							l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');	
								l_o('</div>');						
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then
								l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');	
								l_o('</div>');	
							elsif  :rup_level='13774477' then
								l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','17309051','Dutch Labour Handicap Discount Calculation to use Full Time Salary');
								l_o('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='14488556' then
								l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','17309047','Dutch Labour Handicap Discount Calculation');	
								l_o('</div>');
							elsif :rup_level='12807777'  then		
								l_o('<br><div class="divItem">');
								l_o('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','17309047','Dutch Labour Handicap Discount Calculation');	
								l_o('</div>');
							end if;				
					end if;	
			end if;
			l_o('</div><br>'); l_o('<a name="Netherlandsd"></a>');datainstall('NL',20);
			l_o('<a name="Netherlandss"></a>');bg_nl('NL',20);
			l_o('</div>');
			l_o('<a name="Netherlandsv"></a>');file_version('nl');
			l_o('</div>');
			documents('1506687.2','Information Center: Oracle HRMS (Netherlands)');
			l_o('</div>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');
end;




-- 4rd program (split because "program too long" error)
begin  -- begin1

  begin -- begin MAIN
	:g_curr_loc:=1;
	
	DBMS_LOB.CREATETEMPORARY(:g_hold_output4,TRUE,DBMS_LOB.SESSION);
        l_o('<BR>'); 	
		
	
	ie();
	nl();

	
	l_o('</div>');
	
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test<br>Please report in Note 1631780.1 <br>');

end;
end;
/

-- Print output
print :g_hold_output4


-- Display overview of issues
declare
v_warnings number;
v_errors number;
procedure leg_tabs (v_leg varchar2, v_leg_name varchar2, v_page varchar2, v_e number, v_w number) is
  v_exists number;  
Begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = v_leg  and status='I';     
     if v_exists>0 then               
			   dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2('''||v_page||''');\\" href=\\"javascript:;\\">'||v_leg_name||'</A>"+');
				if v_e>0 then
							dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
						elsif v_w>0 then
							dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');	
						else
							dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
						end if;	
				dbms_output.put_line('"</TD><TD>'||v_e||'</TD><TD>'||v_w||'</TD> </TR>"+');
			   
	 end if;
end;
procedure leg_tabs2 (v_leg varchar2, v_leg_name varchar2, v_page varchar2, v_e number, v_w number) is
  v_exists number;  
Begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = v_leg  and status='I';     
     if v_exists>0 then               
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab('''||v_page||''')\\" >"+');
			dbms_output.put_line('"<b>'||v_leg_name||'</b> "+');
			if v_e>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif v_w>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	 
	 end if;
end;
procedure leg_tabs3 (v_leg varchar2, v_leg_name varchar2, v_page varchar2, v_e number, v_w number) is
  v_exists number;  
Begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = v_leg  and status='I';     
     if v_exists>0 then               
			dbms_output.put_line('auxs = document.getElementById("'||v_leg_name||'").innerHTML;');
			dbms_output.put_line('document.getElementById("'||v_leg_name||'").innerHTML = auxs + ');
			if v_e>0 and v_w>0 then
				dbms_output.put_line(' ":  '||v_e||' <img class=\\"error_ico\\">  '||v_w||' <img class=\\"warn_ico\\"> ";');
			elsif v_e>0 then
				dbms_output.put_line(' ":  '||v_e||' <img class=\\"error_ico\\"> ";');
			elsif v_w>0 then
				dbms_output.put_line(' ":  '||v_w||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' ": <img class=\\"check_ico\\"> ";');
			end if;	 
	 end if;
end;
begin
	
	v_warnings:=:w1+:w2+:w3+:w4+:w5+:w6+:w7+:w8+:w9+:w10+:w11+:w12+:w13+:w14+:w15+:w16+:w17+:w18+:w19+:w20+:w21+:w22+:w23+:w24+:w25+:w26+:w27+:w28+:w29+:w30+:w31;
	v_errors:=:e1+:e2+:e3+:e4+:e5+:e6+:e7+:e8+:e9+:e10+:e11+:e12+:e13+:e14+:e15+:e16+:e17+:e18+:e19+:e20+:e21+:e22+:e23+:e24+:e25+:e26+:e27+:e28+:e29+:e30+:e31;
	
	dbms_output.put_line('<script type="text/javascript">');
	dbms_output.put_line('var auxs;');
	dbms_output.put_line('auxs = document.getElementById("ExecutionSummary1").innerHTML;');
	dbms_output.put_line('document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if v_errors>0 and v_warnings>0 then
		dbms_output.put_line('"('||v_errors||'<img class=\\"error_ico\\"> '||v_warnings||'<img class=\\"warn_ico\\">)</A>";');
	elsif v_errors>0 and v_warnings=0 then
		dbms_output.put_line('"(<img class=\\"error_ico\\">'||v_errors||')</A>";');
	elsif v_errors=0 and v_warnings>0 then
		dbms_output.put_line('"(<img class=\\"warn_ico\\">'||v_warnings||')</A>";');
	elsif v_errors=0 and v_warnings=0 then
		dbms_output.put_line('"(<img class=\\"check_ico\\"> No issues reported)</A>";');
	end if;
	
	
	dbms_output.put_line('auxs = document.getElementById("ExecutionSummary2").innerHTML;');
	dbms_output.put_line('document.getElementById("ExecutionSummary2").innerHTML = auxs + ');			

	dbms_output.put_line(' "<TABLE width=\\"95%\\"><TR>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Section</B></TD>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Errors</B></TD>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Warnings</B></TD>"+');
	
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page1'');\\" href=\\"javascript:;\\">Generic</A>"+');
	if :e1>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w1>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');	
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e1||'</TD><TD>'||:w1||'</TD> </TR>"+');
	
	leg_tabs ('AU', 'Australia', 'page2',:e2 ,:w2);
	leg_tabs ('BE', 'Belgium', 'page3',:e3 ,:w3);  		 
	leg_tabs ('CA', 'Canada', 'page4',:e4 ,:w4); 		 
	leg_tabs ('CN', 'China', 'page5',:e5 ,:w5); 		 
	leg_tabs ('ES', 'Spain', 'page6',:e6 ,:w6); 	 	 
	leg_tabs ('DE', 'Germany', 'page7',:e7 ,:w7); 		 
	leg_tabs ('DK', 'Denmark', 'page8',:e8 ,:w8); 	 	 
	leg_tabs ('FI', 'Finland', 'page9',:e9 ,:w9); 	 	 
	leg_tabs ('FR', 'France', 'page10',:e10 ,:w10); 	 	 
	leg_tabs ('HK', 'Hong Kong', 'page11',:e11 ,:w11); 	 	 
	leg_tabs ('HU', 'Hungary', 'page12',:e12 ,:w12); 	 	 
	leg_tabs ('IE', 'Ireland', 'page13',:e13 ,:w13); 	 	 
	leg_tabs ('IN', 'India', 'page14',:e14 ,:w14); 		 
	leg_tabs ('IT', 'Italy', 'page15',:e15 ,:w15); 	 	 
	leg_tabs ('JP', 'Japan', 'page16',:e16 ,:w16); 	 	 
	leg_tabs ('KR', 'Korea', 'page17',:e17 ,:w17); 	 	 
	leg_tabs ('KW', 'Kuwait', 'page18',:e18 ,:w18); 	 	 
	leg_tabs ('MX', 'Mexico', 'page19',:e19 ,:w19); 		 
	leg_tabs ('NL', 'Netherlands', 'page20',:e20 ,:w20); 		 
	leg_tabs ('NO', 'Norway', 'page21',:e21 ,:w21); 		 
	leg_tabs ('NZ', 'New Zealand', 'page22',:e22 ,:w22); 		 
	leg_tabs ('PL', 'Poland', 'page23',:e23 ,:w23); 	 	 
	leg_tabs ('RU', 'Russia', 'page24',:e24 ,:w24); 	 	 
	leg_tabs ('SA', 'Saudi Arabia', 'page25',:e25 ,:w25); 	 	 
	leg_tabs ('SE', 'Sweden', 'page26',:e26 ,:w26); 	 
	leg_tabs ('SG', 'Singapore', 'page27',:e27 ,:w27); 	 	 
	leg_tabs ('AE', 'United Arab Emirates', 'page28',:e28 ,:w28); 	 	 
	leg_tabs ('GB', 'United Kingdom', 'page29',:e29 ,:w29); 	 	 
	leg_tabs ('US', 'United States', 'page30',:e30 ,:w30);  	 
	leg_tabs ('ZA', 'South Africa', 'page31',:e31 ,:w31); 	

	dbms_output.put_line(' "</TABLE></div>";');   
	
	dbms_output.put_line('auxs = document.getElementById("toccontent").innerHTML;');
	dbms_output.put_line('document.getElementById("toccontent").innerHTML = auxs + ');
	dbms_output.put_line('"<div align=\\"center\\">"+');
	-- Tabs 
	dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page1'')\\" >"+');
	dbms_output.put_line('"<b>Generic</b> "+');
	if :e1>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
	elsif :w1>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
	else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
	end if;	
	leg_tabs2 ('AU', 'Australia', 'page2',:e2 ,:w2);
	leg_tabs2 ('BE', 'Belgium', 'page3',:e3 ,:w3);  		 
	leg_tabs2 ('CA', 'Canada', 'page4',:e4 ,:w4); 		 
	leg_tabs2 ('CN', 'China', 'page5',:e5 ,:w5); 		 
	leg_tabs2 ('ES', 'Spain', 'page6',:e6 ,:w6); 	 	 
	leg_tabs2 ('DE', 'Germany', 'page7',:e7 ,:w7); 		 
	leg_tabs2 ('DK', 'Denmark', 'page8',:e8 ,:w8); 	 	 
	leg_tabs2 ('FI', 'Finland', 'page9',:e9 ,:w9); 	 	 
	leg_tabs2 ('FR', 'France', 'page10',:e10 ,:w10); 	 	 
	leg_tabs2 ('HK', 'Hong Kong', 'page11',:e11 ,:w11); 	 	 
	leg_tabs2 ('HU', 'Hungary', 'page12',:e12 ,:w12); 	 	 
	leg_tabs2 ('IE', 'Ireland', 'page13',:e13 ,:w13); 	 	 
	leg_tabs2 ('IN', 'India', 'page14',:e14 ,:w14); 		 
	leg_tabs2 ('IT', 'Italy', 'page15',:e15 ,:w15); 	 	 
	leg_tabs2 ('JP', 'Japan', 'page16',:e16 ,:w16); 	 	 
	leg_tabs2 ('KR', 'Korea', 'page17',:e17 ,:w17); 	 	 
	leg_tabs2 ('KW', 'Kuwait', 'page18',:e18 ,:w18); 	 	 
	leg_tabs2 ('MX', 'Mexico', 'page19',:e19 ,:w19); 		 
	leg_tabs2 ('NL', 'Netherlands', 'page20',:e20 ,:w20); 		 
	leg_tabs2 ('NO', 'Norway', 'page21',:e21 ,:w21); 		 
	leg_tabs2 ('NZ', 'New Zealand', 'page22',:e22 ,:w22); 		 
	leg_tabs2 ('PL', 'Poland', 'page23',:e23 ,:w23); 	 	 
	leg_tabs2 ('RU', 'Russia', 'page24',:e24 ,:w24); 	 	 
	leg_tabs2 ('SA', 'Saudi Arabia', 'page25',:e25 ,:w25); 	 	 
	leg_tabs2 ('SE', 'Sweden', 'page26',:e26 ,:w26); 	 
	leg_tabs2 ('SG', 'Singapore', 'page27',:e27 ,:w27); 	 	 
	leg_tabs2 ('AE', 'United Arab Emirates', 'page28',:e28 ,:w28); 	 	 
	leg_tabs2 ('GB', 'United Kingdom', 'page29',:e29 ,:w29); 	 	 
	leg_tabs2 ('US', 'United States', 'page30',:e30 ,:w30);  	 
	leg_tabs2 ('ZA', 'South Africa', 'page31',:e31 ,:w31);	 	 
  	dbms_output.put_line('"</div>";');

	dbms_output.put_line('auxs = document.getElementById("generic").innerHTML;');
			dbms_output.put_line('document.getElementById("generic").innerHTML = auxs + ');
			if :e1>0 and :w1>0 then
				dbms_output.put_line(' ": '||:e1||' <img class=\\"error_ico\\">  '||:w1||' <img class=\\"warn_ico\\"> ";');
			elsif :e1>0 then
				dbms_output.put_line(' ": '||:e1||' <img class=\\"error_ico\\"> ";');
			elsif :w1>0 then
				dbms_output.put_line(' ": '||:w1||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' ": <img class=\\"check_ico\\"> ";');
			end if;	
		leg_tabs3 ('AU', 'Australia', 'page2',:e2 ,:w2);
	leg_tabs3 ('BE', 'Belgium', 'page3',:e3 ,:w3);  		 
	leg_tabs3 ('CA', 'Canada', 'page4',:e4 ,:w4); 		 
	leg_tabs3 ('CN', 'China', 'page5',:e5 ,:w5); 		 
	leg_tabs3 ('ES', 'Spain', 'page6',:e6 ,:w6); 	 	 
	leg_tabs3 ('DE', 'Germany', 'page7',:e7 ,:w7); 		 
	leg_tabs3 ('DK', 'Denmark', 'page8',:e8 ,:w8); 	 	 
	leg_tabs3 ('FI', 'Finland', 'page9',:e9 ,:w9); 	 	 
	leg_tabs3 ('FR', 'France', 'page10',:e10 ,:w10); 	 	 
	leg_tabs3 ('HK', 'HongKong', 'page11',:e11 ,:w11); 	 	 
	leg_tabs3 ('HU', 'Hungary', 'page12',:e12 ,:w12); 	 	 
	leg_tabs3 ('IE', 'Ireland', 'page13',:e13 ,:w13); 	 	 
	leg_tabs3 ('IN', 'India', 'page14',:e14 ,:w14); 		 
	leg_tabs3 ('IT', 'Italy', 'page15',:e15 ,:w15); 	 	 
	leg_tabs3 ('JP', 'Japan', 'page16',:e16 ,:w16); 	 	 
	leg_tabs3 ('KR', 'Korea', 'page17',:e17 ,:w17); 	 	 
	leg_tabs3 ('KW', 'Kuwait', 'page18',:e18 ,:w18); 	 	 
	leg_tabs3 ('MX', 'Mexico', 'page19',:e19 ,:w19); 		 
	leg_tabs3 ('NL', 'Netherlands', 'page20',:e20 ,:w20); 		 
	leg_tabs3 ('NO', 'Norway', 'page21',:e21 ,:w21); 		 
	leg_tabs3 ('NZ', 'NewZealand', 'page22',:e22 ,:w22); 		 
	leg_tabs3 ('PL', 'Poland', 'page23',:e23 ,:w23); 	 	 
	leg_tabs3 ('RU', 'Russia', 'page24',:e24 ,:w24); 	 	 
	leg_tabs3 ('SA', 'SaudiArabia', 'page25',:e25 ,:w25); 	 	 
	leg_tabs3 ('SE', 'Sweden', 'page26',:e26 ,:w26); 	 
	leg_tabs3 ('SG', 'Singapore', 'page27',:e27 ,:w27); 	 	 
	leg_tabs3 ('AE', 'UnitedArabEmirates', 'page28',:e28 ,:w28); 	 	 
	leg_tabs3 ('GB', 'UnitedKingdom', 'page29',:e29 ,:w29); 	 	 
	leg_tabs3 ('US', 'UnitedStates', 'page30',:e30 ,:w30);  	 
	leg_tabs3 ('ZA', 'SouthAfrica', 'page31',:e31 ,:w31);
	
  	dbms_output.put_line('</script>');	
end;
/


-- Print duration of script

begin
select to_char(sysdate,'hh24:mi:ss') into :et_time from dual;
end;
/

declare
	st_hr1 varchar2(10);
	st_mi1 varchar2(10);
	st_ss1 varchar2(10);
	et_hr1 varchar2(10);
	et_mi1 varchar2(10);
	et_ss1 varchar2(10);
	hr_fact varchar2(10);
	mi_fact varchar2(10);
	ss_fact varchar2(10);
	vss number;
	vse number;
	vt number;
begin
	dbms_output.put_line('<br><br><hr><br><TABLE width="50%"><THEAD><STRONG>PAY Analyzer Performance Data</STRONG></THEAD>');
    dbms_output.put_line('<TBODY><TR><TH>Started at:</TH><TD>'||:st_time||'</TD></TR>');
    dbms_output.put_line('<TR><TH>Complete at:</TH><TD>'||:et_time||'</TD></TR>');
    	
	st_hr1 := substr(:st_time,1,2);
	st_mi1 := substr(:st_time,4,2);
	st_ss1 := substr(:st_time,7,2);
	et_hr1 := substr(:et_time,1,2);
	et_mi1 := substr(:et_time,4,2);
	et_ss1 := substr(:et_time,7,2);
	
	vss:=st_hr1*60*60 + st_mi1*60+st_ss1;
	vse:=et_hr1*60*60 + et_mi1*60+et_ss1;
	
	
	dbms_output.put_line('<TR><TH>Total time taken to complete the script:</TH>');
	if vse>vss then	
			vt:=vse-vss;			
	else
			vt:=24*60*60-vss +vse;
	end if;
	
		if (vt > 3600) then
								dbms_output.put_line('<TD>'||trunc(vt/3600)||' hours, '||trunc((vt-((trunc(vt/3600))*3600))/60)||' minutes, '||trunc(vt-((trunc(vt/60))*60))||' seconds</TD></TR>');
	elsif (vt > 60) then
								dbms_output.put_line('<TD>'||trunc(vt/60)||' minutes, '||trunc(vt-((trunc(vt/60))*60))||' seconds</TD></TR>');
	elsif (vt < 60) then
								dbms_output.put_line('<TD>'||trunc(vt)||' seconds</TD></TR>');
	end if;
			
	dbms_output.put_line('</TBODY></TABLE>');
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report in Note 1631780.1 <br>');	
end;
/


-- Display feedback and communities reference
declare
		db_ver    	  VARCHAR2(100);
		db_charset V$NLS_PARAMETERS.value%type;
		db_lang V$NLS_PARAMETERS.value%type;
		rup_level varchar2(20);
		v_exists number;
		platform varchar2(100);		
		cursor legislations is
				SELECT DECODE(legislation_code
							   ,null,'Global'
							   ,legislation_code)  leg              
					   , DECODE(application_short_name
							   , 'PER', 'Human Resources'
							   , 'PAY', 'Payroll'
							   , 'GHR', 'Federal Human Resources'
							   , 'CM',  'College Data'
							   , application_short_name) application         
				  FROM hr_legislation_installations
				  WHERE status = 'I'
				  ORDER BY legislation_code;
		v_wfVer WF_RESOURCES.TEXT%type:='';
		v_crtddt V$DATABASE.CREATED%type;
		irc_status varchar2(20);
		cursor bg is
		SELECT o.business_group_id bgi,o.organization_id oi,otl.name name,o3.ORG_INFORMATION9 lc			
			,o3.ORG_INFORMATION10 cc,o4.ORG_INFORMATION2 ef ,to_char(o.date_from , 'DD-MON-YYYY') df,to_char(o.date_to, 'DD-MON-YYYY') dt
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;
      cursor c_pay is select parameter_name, nvl(parameter_value,'null') param_value
      from pay_action_parameters
      where parameter_name in ('BAL BUFFER SIZE','EE_BUFFER_SIZE','RR_BUFFER_SIZE','RRV_BUFFER_SIZE','CHUNK SIZE','RANGE_PERSON_ID','THREADS','TRACE','LOW_VOLUME');
      max_dump v$parameter.value%type;
begin
	if :apps_rel like '11.5%'  then
		dbms_output.put_line('<br><table border="2" name="NoteBox" cellpadding="1" bordercolor="#C1A90D" bgcolor="#CCCCCC" cellspacing="1">');
		dbms_output.put_line('<tbody><tr><td> <font size="+1">Statutory Legislative Support Expired</font> </td></tr></tbody> </table> <BR>');
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><span class="sectionorange">Warning:</span>Please note that statutory legislative support expired on November 30th 2013');
		dbms_output.put_line('<span class="sectionb">, please refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1384995.1" target="_blank">Note 1384995.1</a> ');
		dbms_output.put_line(' When Is Statutory Legislative Support for Payroll Going To End For Release 11i<br></div>');
	end if;
	
	dbms_output.put_line('<br><hr><a name="feedback"></a><table border="2" name="NoteBox" cellpadding="1" bordercolor="#C1A90D" bgcolor="#CCCCCC" cellspacing="1"><br>');
	dbms_output.put_line('<b>Still have questions or suggestions?</b><br>  <A HREF="https://community.oracle.com/message/12646480"  target="_blank">');
	dbms_output.put_line('<img src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback.png" title="Click here to provide feedback"/></a><br>');
	dbms_output.put_line('Click the button above to ask questions about and/or provide feedback on the Payroll Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!<br>');
		
SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, 'TNS for '), ':' )||pcv2.status, 1, 80)
    INTO platform
        FROM product_component_version pcv1,
           product_component_version pcv2
     WHERE UPPER(pcv1.product) LIKE '%TNS%'
       AND UPPER(pcv2.product) LIKE '%ORACLE%'
       AND ROWNUM = 1;
	select VALUE into db_lang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
	select VALUE into db_charset FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';
	select banner into db_ver from V$VERSION WHERE ROWNUM = 1;
	select count(1) into v_exists FROM V$DATABASE;
	if v_exists=1 then	
	SELECT CREATED into v_crtddt FROM V$DATABASE;
	end if;
	select count(1) into v_exists FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';
	if v_exists=1 then
	SELECT TEXT into v_wfVer  FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';	
	end if;	
	if :apps_rel like '12.%' then
		select count(*) into v_exists from fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		if v_exists >0 then	
		SELECT L.MEANING  into irc_status  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		else
		  irc_status:='Not available';
		end if;
	else
	  irc_status:='Not available';
	 end if;  
	
	dbms_output.put_line('<!-- ######BEGIN DX SUMMARY######');
	dbms_output.put_line('<diagnostic><run_details>');
    dbms_output.put_line('<detail name="Instance">'||:sid||'</detail>');
    dbms_output.put_line('<detail name="Instance Date">'||v_crtddt||'</detail>');
    dbms_output.put_line('<detail name="Platform">'||platform||'</detail>');
    dbms_output.put_line('<detail name="File Version">200.27</detail>');
    dbms_output.put_line('<detail name="Language">'||db_lang||' / '||db_charset||'</detail>');
    dbms_output.put_line('<detail name="Database">'||db_ver||'</detail>');
	dbms_output.put_line('<detail name="Application">'||:apps_rel||'</detail>');
    dbms_output.put_line('<detail name="Workflow">'||v_wfVer||'</detail>');
    dbms_output.put_line('<detail name="PER">'||:hr_status||'</detail>');
    dbms_output.put_line('<detail name="PAY">'||:pay_status||'</detail>');
    dbms_output.put_line('<detail name="IRC">'||irc_status||'</detail>');	
	dbms_output.put_line('<detail name="RUP">'||:rup_level_n|| ' applied on ' || :v_rup_date||'</detail>');
  dbms_output.put_line('</run_details>');
  dbms_output.put_line('<parameters>');
    for l_rec in legislations loop
	dbms_output.put_line('<parameter name="Legislation">'||l_rec.leg||'   '||l_rec.application||'</parameter>');
	end loop;
	for org_rec in bg loop
		dbms_output.put_line('<parameter name="BG"><![CDATA['||lpad(org_rec.bgi,10)||' | '||lpad(org_rec.oi,10)||' | '||lpad(org_rec.name,30)||' | '||lpad(org_rec.lc,6)||' | '||lpad(org_rec.cc,6)||' | '||lpad(org_rec.ef,7)||' | '||lpad(org_rec.df,11)||' | '||lpad(org_rec.dt,11)||']]></parameter>');
	end loop;
	for c_rec in c_pay loop
		dbms_output.put_line('<parameter name="PERF">'||c_rec.parameter_name||': '||c_rec.param_value||'</parameter>');
	end loop;
	select nvl(value,'null') into max_dump from v$parameter  where lower(name) ='max_dump_file_size';
	dbms_output.put_line('<parameter name="PERF">Max_dump_file_sixe: '||max_dump||'</parameter>');
	dbms_output.put_line('<parameter name="PERF">Gather Schema Statistics for ALL - last time completed normally: '||:p1||'</parameter>');
	dbms_output.put_line('<parameter name="PERF">Gather Schema Statistics for HR - last time completed normally: '||:p2||'</parameter>');
  dbms_output.put_line('</parameters> <issues><signature id="INSTSUM"><failure row="1">d</failure></signature></issues></diagnostic>');
  dbms_output.put_line('######END DX SUMMARY######-->');
end;
/

REM  ==============SQL PLUS Environment setup===================

Spool off

set termout on

exit
;
