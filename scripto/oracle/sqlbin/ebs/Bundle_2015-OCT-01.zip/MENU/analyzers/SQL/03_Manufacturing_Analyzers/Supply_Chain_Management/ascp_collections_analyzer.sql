REM HEADER
REM   $Id: ascp_collections_analyzer.sql v2.00 JG $
REM   
REM MODIFICATION LOG:
REM	
REM	MN 
REM	
REM	Consolidated script to diagnose the current status and footprint of an environment.
REM     This script can be run on 11.5.x or higher.
REM
REM   ascp_collections_analyzer.sql
REM     
REM   	This script was created to collect all the required information to understand what impact 
REM   	embedded in Oracle Applications has on an VCP instance.
REM
REM
REM   How to run it? 
REM   
REM   	sqlplus apps/<password>	
REM     SQL>@ascp_collections_analyzer.sql
REM
REM     You will be asked to choose:
REM  
REM     S for Source, D for Destination and, C for Centralized.
REM
REM   
REM   Output file format found in the same directory if run manually
REM   
REM	ascp_collections_analyzer_<HOST_NAME>_<SID>_<DATE>.html
REM
REM
REM     Created: September 5th, 2013
REM     Last Updated: October 9th, 2014
REM
REM
REM  CHANGE HISTORY:
REM   1.00  5-SEPTEMBER-2013 MN Creation from design
REM   
REM   1.00 25-Jul-2014 JJG
REM
REM        Changed l_env_id varchar2(1) :=upper('&env_id'); to l_env_id varchar2(2) :=upper('&env_id');, to avoid ORA-6502.
REM
REM   2.00 Applied newest version
REM
REM Questions/Comments?   Please email jeffery.goulette@oracle.com
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2 
REM 
REM MENU_TITLE: ASCP Data Collections Analyzer
REM
REM MENU_START
REM
REM SQL: Run ASCP Data Collections Analyzer
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  ASCP Data Collections Analyzer Help [Doc ID: 1596457.1] 
REM
REM  Compatible: 11i|12.0|12.1|12.2 
REM
REM  Explanation of available options:
REM
REM    (1) Run ASCP Data Collections Analyzer
REM        o Runs ascp_collection_analyzer.sql as APPS 
REM        o Creates an HTML output 
REM
REM    (2)  Install ASCP Data Collections Analyzer as a Concurrent Program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "All MSC Reports" 
REM
REM 
REM HELP_END 
REM
REM FNDLOAD_START 
REM
REM PROD_TOP: MSC_TOP
REM PROG_NAME: MSCACA_SQL
REM APP_NAME: Advanced Supply Chain Planning
REM DEF_REQ_GROUP: All MSC Reports
REM PROD_SHORT_NAME: MSC 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END


prompt .
prompt .
prompt .
prompt .
prompt .
prompt Please enter a Character to identify the environment where you are running this script.
PROMPT
prompt S for Source, D for Destination, C for Centralized
PROMPT
PROMPT Default value is D which is for Destination.
PROMPT
PROMPT 
PROMPT
ACCEPT env_id CHAR DEFAULT D PROMPT 'Enter Your Environment Idenfifier (S/D/C)? : '
PROMPT 

prompt NLS Parameter Settings :
prompt =========================
select parameter, 
       value param_value 
from   nls_session_parameters;



set arraysize 1
set heading off
set feedback off  
set echo off
set verify off
SET CONCAT ON
SET CONCAT .
SET ESCAPE OFF
SET ESCAPE '\'

set long 200
set lines 120
set pages 9999
set serveroutput on size 100000
set DEFINE "&"

VARIABLE ratio          NUMBER;
variable env_id         varchar2(1);
VARIABLE n		NUMBER;
VARIABLE gv_schema      varchar2(20);

DECLARE
ratio                   number;
VARIABLE gv_schema      varchar2(20);
st_time                 date;

begin
select to_char(sysdate,'hh24:mi:ss') into :st_time from dual;

select fnd_profile.value('MSD_DEM_SCHEMA') into v_schema from dual;
:gv_schema:=v_schema;
end;
/

COLUMN host_name NOPRINT NEW_VALUE hostname
SELECT host_name from v$instance;
COLUMN instance_name NOPRINT NEW_VALUE instancename
SELECT instance_name from v$instance;
COLUMN sysdate NOPRINT NEW_VALUE when
select to_char(sysdate, 'YYYY-Mon-DD') "sysdate" from dual;
SPOOL ascp_collections_analyzer_&&hostname._&&instancename._&&when..html


alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

REM prompt <HTML>
REM prompt <HEAD>
REM PROMPT
REM prompt <TABLE border="1" cellspacing="0" cellpadding="10">
REM prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD bordercolor="#DEE6EF"><font face="Calibri">
REM prompt .
REM prompt .
REM prompt .
REM prompt .
REM prompt .
REM prompt Please enter a Character to identify the environment where you are running this script.
REM PROMPT
REM prompt S for Source, D for Destination, C for Centralized
REM PROMPT
REM PROMPT Default value is D which is for Destination.
REM PROMPT
REM PROMPT 
REM PROMPT
REM ACCEPT env_id CHAR DEFAULT D PROMPT 'Enter Your Environment Idenfifier (S/D/C)? : '
PROMPT 
prompt <HTML>
prompt <HEAD>
PROMPT
REM prompt <TABLE border="1" cellspacing="0" cellpadding="10">
REM prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD bordercolor="#DEE6EF"><font face="Calibri">
Declare
  l_env_id varchar2(2) :=upper('&env_id');
Begin
 
 IF upper(l_env_id) not in ('S','D','C') THEN
    l_env_id:='D';
  END IF;
 :env_id:=upper(l_env_id);
 
 
END;
/
REM prompt </font></B></TD></TR>
REM prompt </TABLE><BR>



prompt <TITLE>ASCP Collections Analyzer</TITLE>
prompt <STYLE TYPE="text/css">
prompt <!-- TD {font-size: 10pt; font-family: calibri; font-style: normal} -->
prompt </STYLE>
prompt </HEAD>
prompt <BODY>

prompt <TABLE border="1" cellspacing="0" cellpadding="10">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD bordercolor="#DEE6EF"><font face="Calibri">
prompt <B><font size="+2">ASCP Collections Analyzer for 
select UPPER(instance_name) from v$instance;
prompt <B><font size="+2"> Instance on 
select UPPER(host_name) from v$instance;
prompt <B><font size="+2"> which is 
select decode(:env_id,'S','Source','D','Destination','C','Centralized') from dual;
prompt <B><font size="+2"> Environment.
prompt </font></B></TD></TR>
prompt </TABLE><BR>

prompt <a href="https://support.oracle.com/rs?type=doc\&id=432.1" target="_blank">
prompt <img src="https://blogs.oracle.com/ebs/resource/Proactive/banner4.jpg" title="Click here to see other helpful Oracle Proactive Tools" width="758" height="81" border="0" alt="Proactive Services Banner" /></a></a>
prompt <br>

prompt <font size="-1"><i><b>ASCP Collections Analyzer v2.00 compiled on : 
select to_char(sysdate, 'Dy Month DD, YYYY') from dual;
prompt at 
select to_char(sysdate, ' hh24:mi:ss') from dual;
prompt </b></i></font><BR><BR>

prompt <font size="+2">This ASCP Collections Analyzer script reviews the current environment Footprint, analyzes runtime tables, profiles, settings and configurations for the<br>
prompt overall environment.  Providing feedback and recommendations on Best Practices for any areas for concern on your system.<BR><BR>
prompt The results of this analyzer are impacted by statistics.  For best results, please have your statistics up to date.</font>
prompt <BR>

prompt <BR>

prompt <table width="95%" border="0">
prompt   <tr> 
prompt     <td colspan="2" height="46"> 
prompt       <p><a name="top"><b><font size="+2">Table of Contents</font></b></a> </p>
prompt     </td>
prompt   </tr>
prompt   <tr> 
prompt     <td width="50%"> 
prompt       <a href="#section1"><b><font size="+1">ASCP Collections Analyzer Overview</font></b></a> 
prompt         <br>
prompt       <blockquote> <a href="#adv111"> - E-Business Suite Version</a><br></blockquote>
prompt <BR><BR><br>
prompt       <a href="#section1"><b><font size="+1">Performance Related Output</font></b></a><br>
prompt          <a href="#adv500">  - Buffer Cache Hit Ratio Percent </a><br>
prompt          <a href="#adv501">  - Dictionary Cache Hit Ratio </a><br>
prompt          <a href="#adv502">  - Sorts in Memory </a><br>
prompt          <a href="#adv503">  - The percentage of FREE shared pool </a><br>
prompt          <a href="#adv504">  - Shared Pool Reloads </a><br>
prompt          <a href="#adv505">  - Freelist Performance Impact </a><br>
prompt          <a href="#adv506">  - Library Reload Ratio Percent </a><br>
prompt          <a href="#adv507">  - Library Cache Constraint Activity and Shared Pool </a><br>
prompt          <a href="#adv508">  - Datafile Activity Constraints </a><br>
prompt          <a href="#adv509">  - IO Disbursement Across Datafiles for Tablespace </a><br>
prompt          <a href="#adv510">  - System Events </a><br>
prompt          <a href="#adv511">  - Network Wait Events </a><br>
prompt          <a href="#adv512">  - Network Wait Class Summary </a><br>
prompt          <a href="#adv513">  - Database Object Fragmentation </a><br>
prompt          <a href="#adv514">  - Segments Where Free Space <= Next Extent </a><br>
prompt          <a href="#adv515">  - Cluster Factor > 50% Rows vs Blocks and Related Storage Facts </a><br>
prompt          <a href="#adv516">  - Free Space by Tablespace </a><br>
prompt          <a href="#adv517">  - Wait Statistics </a><br>
prompt          <a href="#adv518">  - System Statistics </a>
prompt       </blockquote>
prompt     </td>
prompt     <td width="50%"><a href="#section2"><b><font size="+1"> ASCP Setups 
prompt       </font></b></a> <br>
prompt       <blockquote> 
prompt      <p><a href="#section21"><b><font size="+1">Source Side Setups</font></b></a><br><br>
prompt         <a href="#adv2111">  - Concurrent Program Checks for MRP Application Programs </a><br>
prompt         <a href="#adv2112">  - Invalid Database Objects </a><br>
prompt         <a href="#adv2113">  - Report Statistics - Last Analyzed on Tables</a><br>
prompt         <a href="#adv2114">  - Information on MLOG$</a><br>
prompt         <a href="#adv2115">  - Information on MRP_AP_APPS_INSTANCES_ALL</a><br>
prompt         <a href="#adv2116">  - Information on Source Profiles</a><br>
prompt         <a href="#adv2117">  - Sanity Checks for Known Issues</a><br>
prompt      <p><a href="#section22"><b><font size="+1">Destination Side Setups</font></b></a><br><br>
prompt         <a href="#adv2211">  - Concurrent Program Checks for ASCP Application Programs </a><br>
prompt         <a href="#adv2212">  - Report Statistics - Last Analyzed on Partitions</a><br>
prompt         <a href="#adv2213">  - Instance Setups (MSC_APPS_INSTANCES) and Organizations enabled for Collections</a><br>
prompt         <a href="#adv2214">  - MSC Staging Tables missing Partitions</a><br>
prompt         <a href="#adv22141">  -Exceptions on Instances and Partitions - Missing Information </a><br>
prompt         <a href="#adv221411">  -Information on ODS Tables - Instances and Partitions </a><br>
prompt         <a href="#adv22142">  -Missing Indexes Information </a><br>
prompt         <a href="#adv22143">  -Partioned Tables - Last Analyzed 7 or more days ago </a><br>
prompt         <a href="#adv2215">  - Information on Destination Profiles</a><br>
prompt         <a href="#adv2216">  - Sanity Checks for Known Issues</a><br>
prompt      </blockquote>   
prompt       <a href="#section8"><b><font size="+1">References</font></b></a> 
prompt       <blockquote></blockquote>
prompt     </td>
prompt   </tr>
prompt </table>

prompt <BR><BR>

REM **************************************************************************************** 
REM *******                   Section 1 : ASCP Collections Analyzer Overview                 *******
REM ****************************************************************************************

REM
REM ******* Ebusiness Suite Version *******
REM

prompt <script type="text/javascript">    function displayRows1sql1(){var row = document.getElementById("s1sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF">
prompt     <font face="Calibri"><a name="adv111"></a>
prompt      <B>E-Business Suite Version</B>
prompt     </font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql1()" >SQL Script</button></div>
prompt     </TD>
prompt </TR>
prompt <TR id="s1sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          select vi.instance_name, fpg.release_name, vi.host_name, vi.startup_time, vi.version <br>
prompt          from fnd_product_groups fpg, v$instance vi<br>
prompt          where upper(substr(fpg.APPLICATIONS_SYSTEM_NAME,1,4)) = upper(substr(vi.INSTANCE_NAME,1,4));</p>
prompt       </blockquote>
prompt     </TD>
prompt </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RELEASE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>HOSTNAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>STARTED</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DATABASE</B></TD>
prompt </TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||vi.instance_name||'</TD>'||chr(10)|| 
'<TD>'||fpg.release_name||'</TD>'||chr(10)|| 
'<TD>'||vi.host_name||'</TD>'||chr(10)|| 
'<TD>'||vi.startup_time||'</TD>'||chr(10)|| 
'<TD>'||vi.version||'</TD></TR>'
from fnd_product_groups fpg, v$instance vi
where upper(substr(fpg.APPLICATIONS_SYSTEM_NAME,1,4)) = upper(substr(vi.INSTANCE_NAME,1,4));
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM
REM ******* A Note on RDBMS Error *******
REM    
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> 
prompt   <tr>     
prompt     <td> 
prompt       <p> If you have an error during data collections, verify that RDBMS is functioning properly. Review entries in the RDBMS alert_log.<br>
prompt       Please refer to the following documents:<br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=438148.1" target="_blank">Doc ID 438148.1</a> Finding alert.log file in 11g.<br>
prompt </p>
prompt       </td>
prompt    </tr>
prompt    </tbody> 
prompt </table><BR>


REM **************************************************************************************** 
REM *******                   Section 2 : ASCP Collections Setups               *******
REM ****************************************************************************************

prompt <a name="section2"></a><B><h2 style="background-color:#CCCCCC;" align="center"><font size="+2" Color="blue">ASCP Collections Setups </font></h2></B><BR>

REM
REM ******* Verify ASCP Source Side Setups *******
REM

prompt <a name="section21"></a><B><h2 style="background-color:#CCCCCC;" align="center"><font size="+2" color="blue">Source Side Setups </font></h2></B><BR>

exec :n := dbms_utility.get_time;
Declare
Cursor cdp is select distinct a.USER_CONCURRENT_QUEUE_NAME name,d.max_processes value
		from FND_CONCURRENT_QUEUES_VL a
    			,FND_CONCURRENT_QUEUE_CONTENT b
    			,FND_CONCURRENT_QUEUE_SIZE d
		where d.queue_application_id=b.queue_application_id
  			and d.concurrent_queue_id=b.concurrent_queue_id
  			and b.queue_application_id=a.application_id
   			and b.concurrent_queue_id=a.concurrent_queue_id
   			and b.include_flag='I'
   			and exists(select null from fnd_concurrent_programs_vl c
              				where c.application_id=b.type_application_id
              					and c.concurrent_program_id=b.type_id
              		and (c.application_id=704 or c.concurrent_program_name like '%Collection%Snapshot%')
                                  );  
  
              
v_max_processes number;
v_sw   number;
v_cfc   number;
v_count number;

Begin
v_sw:=0;
v_count:=0;
       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2111">');
       dbms_output.put_line('<B>Concurrent Managers Check for MRP Application Programs</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Concurrent Manager Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Max Processes</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Recommendations</B></font></TD>');
       
For dp in cdp
        LOOP

                
                dbms_output.put_line('<TR><TD>'||dp.name||'</TD>');                                                                                                     
		dbms_output.put_line('<TD>'||dp.value||'</TD>');   
                
      --   IF :env_id ='C'  THEN
         
	    select nvl(fnd_profile.value('MRP_SNAPSHOT_WORKERS'),0) into v_sw from dual;

	  IF dp.value >=v_sw*2+6 THEN
		dbms_output.put_line('<TD>You have recommended value. Using 12.1 technology, and when running Data Collections with a Complete Refresh, you could benefit from having a very large number � 25 to 40 �  work shifts (processes).</TD></TR>');
          ELSE
                select count(*) into v_count
		from FND_CONCURRENT_QUEUES_VL a
    			,FND_CONCURRENT_QUEUE_CONTENT b
    			,FND_CONCURRENT_QUEUE_SIZE d
		where d.queue_application_id=b.queue_application_id
  			and d.concurrent_queue_id=b.concurrent_queue_id
  			and b.queue_application_id=a.application_id
   			and b.concurrent_queue_id=a.concurrent_queue_id
                        and a.user_concurrent_queue_name=dp.name
   			and b.include_flag='I'
   			and exists(select null from fnd_concurrent_programs_vl c
              				where c.application_id=b.type_application_id
              					and c.concurrent_program_id=b.type_id
              		and (c.concurrent_program_name like '%Collection%Snapshot%')
                                  );  
          
              IF v_count >1 THEN
                  dbms_output.put_line('<TD>'||'<B>Warning</B>');
                  dbms_output.put_line('Manager for ASCP Programs should have minimum of MRP: Snapshot Workers profile value * 2 + 6.');
		  dbms_output.put_line('Please review <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=145419.1#mozTocId991385"');
                  dbms_output.put_line('target="_blank">Note 145419.1</a> - for setting this value.</TD></TR><BR>');
              ELSE
                  dbms_output.put_line('<TD>'||'Concurrent Manager '||dp.name||' is not tied to Collection Snapshot programs. You have recommended value.');
		  dbms_output.put_line('Please review <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=145419.1#mozTocId991385"');
                  dbms_output.put_line('target="_blank">Note 145419.1</a> - for setting this value.</TD></TR><BR>');
              END IF;
          END IF;

       --END IF;	          
       END LOOP;
        dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at Concurrent Managers check'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows4sql1(){var row = document.getElementById("s4sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2112"></a>
prompt     <B>Invalid Data Base Objects</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select count(*) ,owner,object_type,status<br>
prompt          from dba_objects 
prompt          where status = 'INVALID'
prompt          and owner in ('MRP', 'APPS','MSC')group by owner, object_type, status;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Owner</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Object Type</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||count||'</TD>'||chr(10)|| 
'<TD>'||owner||'</TD>'||chr(10)|| 
'<TD>'||Object_Type||'</TD>'||chr(10)|| 
'<TD>'||Status||'</TD>'
from (select count(*) count,owner,object_type,status
      from dba_objects
      where status = 'INVALID'
      and owner in ('MRP', 'APPS', 'MSC') 
      group by owner, object_type, status
      );
prompt </TABLE><P><P>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt  <tbody> 
prompt   <tr>     
prompt     <td> 
prompt       <p>Review note Refresh Snapshot For First Data Collection Created Thousands Of Invalid Objects In Source Instance <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1358804.1" target="_blank">Note 1358804.1</a>.
prompt          Seeing an invalid snapshot(MATERIALIZED VIEW) is normal and of no concern.  The object will be rebuilt and validated when Collections is run. Source snapshots may have become invalid in either their status or in the data contained therein.  This could occur for many reasons.
prompt          If you encounter the following error:  ORA-12034: snapshot log on schema.snapshot_name younger than last refresh.
prompt          We recommend that you run refresh of that snapshot via the application, see section How to Run the Refresh Snapshot Concurrent Request from the Application and Run Complete Refresh of the snapshot. 
prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=211121.1" target="_blank">Note 211121.1</a>.</p>
prompt     </td>
prompt   </tr>
prompt  </tbody> 
prompt </table><BR><BR>

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql12(){var row = document.getElementById("s4sql12");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2113"></a>
prompt     <B> Report Statistics - Last_Analyzed on Tables seven or more days ago </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql12()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql12" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select owner,table_name, last_analyzed
prompt          from all_tables 
prompt          where owner in ('MRP', 'APPS', 'MSC')
prompt          and last_analyzed <sysdate-7 and rownum<=20;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Owner</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Analyzed</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||Owner||'</TD>'||chr(10)|| 
'<TD>'||Table_Name||'</TD>'||chr(10)|| 
'<TD>'||Last_Analyzed||'</TD>'
from all_tables
where owner in ('MRP', 'APPS', 'MSC')
and last_analyzed <sysdate-7 and rownum<=20;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count:=0;

    select count(*) into v_count
    from all_tables
    where owner in ('MRP', 'APPS', 'MSC')
    and last_analyzed <sysdate-7;
    dbms_output.put_line('You have total of '||v_count|| ' records for which Last_Analyzed date is more than 7 days ago. Sample list is provided above.<br>');

End;
/
Prompt Statistics are recalculated, optimally, after a complete refresh and upon completion of the ASCP planner.
prompt Run Gather Schema statistics on source for BOM, WIP, PO, MRP, ONT, INV, APPS, MSC and AP schemas.<br>
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=145419.1 ">DocId 145419.1 </a>
prompt for How to Setup and Run Data Collections.<br>
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql114(){var row = document.getElementById("s4sql114");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2114"></a>
prompt     <B> Information on MLOG$ and Materialized Views - Stalenss is not Fresh or Compile Status is not Valid</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql114()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql114" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select owner,mview_name,refresh_mode,refresh_method,last_refresh_type,last_refresh_date,staleness,compile_state
prompt          from user_mviews 
prompt          where staleness <> 'FRESH'
prompt          or compile_state <> 'VALID';<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Owner</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>MView Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Refresh Mode</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Refresh Method</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Refresh Type</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Refresh Date</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Staleness</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Compile State</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||Owner||'</TD>'||chr(10)|| 
'<TD>'||mview_name||'</TD>'||chr(10)|| 
'<TD>'||refresh_mode||'</TD>'||chr(10)||
'<TD>'||refresh_method||'</TD>'||chr(10)||
'<TD>'||last_refresh_type||'</TD>'||chr(10)||
'<TD>'||last_refresh_date||'</TD>'||chr(10)||
'<TD>'||staleness||'</TD>'||chr(10)||
'<TD>'||compile_state||'</TD>'
from user_mviews
where (staleness <> 'FRESH'
or compile_state <> 'VALID') and rownum<=20;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count:=0;

    select count(*) into v_count
    from user_mviews
    where staleness <> 'FRESH'
      or compile_state <> 'VALID';
    dbms_output.put_line('You have total of '||v_count|| ' records for which staleness <>FRESH or compile_state <> VALID. Sample list is provided above.<br>');

End;
/
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=580205.1  ">DocId 580205.1  </a>
prompt for Handling MLOGs and MRP_AD% Tables When Value Chain Planning Applications Are Not Used By The Business.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql1141(){var row = document.getElementById("s4sql1141");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2114"></a>
prompt     <B> Sample list of MLOG$ tables having greater than 10 MB of data </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql1141()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql1141" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          SELECT DBA.OWNER "Owner", dba.segment_name "MLOG$ Name",dba.bytes/1024/1024 "MLOG Size in MB",
prompt          log.master "Base Table Name",fav.application_name "Application Name"
prompt        FROM all_snapshot_logs log,dba_segments DBA,fnd_application_vl fav
prompt          WHERE dba.segment_name LIKE 'MLOG$%' AND dba.segment_name=log.log_table
prompt          AND dba.bytes>10000000 AND dba.owner='APPS'
prompt          ORDER BY bytes DESC;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Owner</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>MLOG$ Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>MLOG Size in MB</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Base Table Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Application Name</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||DBA.OWNER||'</TD>'||chr(10)|| 
'<TD>'||dba.segment_name||'</TD>'||chr(10)|| 
'<TD>'||dba.bytes/1024/1024||'</TD>'||chr(10)||
'<TD>'||log.master||'</TD>'||chr(10)||
'<TD>'||fav.application_name||'</TD>'
FROM all_snapshot_logs log,dba_segments DBA,fnd_application_vl fav
WHERE dba.segment_name LIKE 'MLOG$%' AND dba.segment_name=log.log_table
AND dba.bytes>10000000 AND dba.owner='APPS' and rownum<=20 ORDER BY bytes DESC;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count:=0;

    select count(*) into v_count
    FROM all_snapshot_logs log,dba_segments DBA,fnd_application_vl fav
    WHERE dba.segment_name LIKE 'MLOG$%' AND dba.segment_name=log.log_table
    AND dba.bytes>10000000 AND dba.owner='APPS';
    dbms_output.put_line('You have total of '||v_count|| ' records for which MLOG$ table has greater than 10 MB of data. Sample list is provided above.<br>');

End;
/
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=580205.1  ">DocId 580205.1  </a>
prompt for Handling MLOGs and MRP_AD% Tables When Value Chain Planning Applications Are Not Used By The Business.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql1142(){var row = document.getElementById("s4sql1142");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2114"></a>
prompt     <B> List of MLOG$ tables Collection Uses and its corresponding table and Materialized View - stats and counts </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql1142()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql1142" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select distinct dsl.log_owner   owner, DSL.LOG_TABLE name
prompt          ,detailobj_name,amdr.mview_name,to_number( extractvalue( xmltype( dbms_xmlgen.getxml('select count(*) c from '||log_owner||'.'||LOG_TABLE)) ,'/ROWSET/ROW/C')) count
prompt        ,dts.num_rows,dts.STATTYPE_LOCKED,dts.LAST_ANALYZED
prompt         from DBA_TAB_STATISTICS dts  ,all_mview_detail_relations amdr, dba_snapshot_logs dsl
prompt          where  dts.table_name= DSL.LOG_TABLE and dts.owner=dsl.log_owner  and detailobj_type = 'TABLE'
prompt   and detailobj_type = 'TABLE'
prompt    and ( detailobj_owner, detaiLobj_name ) not in                 (( 'MSC', 'MSC_COLLECTED_ORGS' ))
prompt    and amdr.detailobj_name = dsl.MASTER
prompt    and detailobj_name in ( 'AHL_SCHEDULE_MATERIALS','BOM_COMPONENTS_B','BOM_CTO_ORDER_DEMAND','BOM_DEPARTMENTS','BOM_OPERATIONAL_ROUTINGS','BOM_OPERATION_NETWORKS',
prompt                                     'BOM_OPERATION_SEQUENCES','BOM_OPERATION_RESOURCES','BOM_RESOURCE_CHANGES','BOM_RES_INSTANCE_CHANGES','BOM_STRUCTURES_B',
prompt                                     'BOM_SUBSTITUTE_COMPONENTS','BOM_SUB_OPERATION_RESOURCES','CSP_REPAIR_PO_HEADERS','EAM_WO_RELATIONSHIPS','MRP_FORECAST_DATES',
prompt                                     'MRP_FORECAST_DESIGNATORS','MRP_FORECAST_ITEMS','MRP_SCHEDULE_DATES','MTL_DEMAND','MTL_ITEM_CATEGORIES',
prompt                                     'MTL_MATERIAL_TRANSACTIONS_TEMP','MTL_ONHAND_QUANTITIES_DETAIL','MTL_RELATED_ITEMS','MTL_RESERVATIONS', 'MTL_SUPPLY',
prompt                                     'MTL_SYSTEM_ITEMS_B','MTL_TXN_REQUEST_LINES','MTL_USER_DEMAND', 'MTL_USER_SUPPLY','OE_ORDER_LINES_ALL',
prompt                                     'PO_ACCEPTANCES','PO_CHANGE_REQUESTS','PO_SUPPLIER_ITEM_CAPACITY','WIP_DISCRETE_JOBS','WIP_FLOW_SCHEDULES',
prompt                                     'WIP_LINES', 'WIP_MSC_OPEN_JOB_STATUSES','WIP_OPERATIONS','WIP_OPERATION_NETWORKS','WIP_OPERATION_RESOURCES',
prompt                                     'WIP_OP_RESOURCE_INSTANCES', 'WIP_REPETITIVE_ITEMS','WIP_REPETITIVE_SCHEDULES','WIP_REQUIREMENT_OPERATIONS','WIP_SUB_OPERATION_RESOURCES',
prompt                                     'WSH_DELIVERY_DETAILS','WSH_TRIPS','WSH_TRIP_STOPS', 'WSM_COPY_OPERATIONS','WSM_COPY_OP_NETWORKS',
prompt                                     'WSM_COPY_OP_RESOURCES','WSM_COPY_OP_RESOURCE_INSTANCES','WSM_COPY_REQUIREMENT_OPS'
prompt                                       )
prompt             and amdr.mview_name in (
prompt            'AHL_SCH_MTLS_SN', 'BOM_BOMS_SN','BOM_CTO_ORDER_DMD_SN','BOM_INV_COMPS_SN','BOM_OPR_NETWORKS_SN', 'BOM_OPR_RESS_SN',
prompt                 'BOM_OPR_RTNS_SN','BOM_OPR_SEQS_SN','BOM_RES_CHNGS_SN', 'BOM_RES_INST_CHNGS_SN','BOM_SUB_COMPS_SN','BOM_SUB_OPR_RESS_SN',
prompt                 'MRP_FORECAST_DATES_SN','MRP_FORECAST_DSGN_SN','MRP_FORECAST_ITEMS_SN','MRP_SCHD_DATES_SN','MTL_DEMAND_SN', 'MTL_ITEM_CATS_SN',
prompt                 'MTL_MTRX_TMP_SN','MTL_OH_QTYS_SN','MTL_RESERVATIONS_SN', 'MTL_SUPPLY_SN','MTL_SYS_ITEMS_SN','MTL_TXN_REQUEST_LINES_SN','MTL_U_DEMAND_SN', 'MTL_U_SUPPLY_SN',
prompt                 'OE_ODR_LINES_SN','PO_ACCEPTANCES_SN','PO_CHANGE_REQUESTS_SN', 'PO_SI_CAPA_SN','WIP_DSCR_JOBS_SN','WIP_FLOW_SCHDS_SN','WIP_OPR_RES_INSTS_SN', 'WIP_REPT_ITEMS_SN',
prompt                 'WIP_REPT_SCHDS_SN','WIP_WLINES_SN','WIP_WOPRS_SN', 'WIP_WOPR_RESS_SN','WIP_WOPR_SUB_RESS_SN', 'WIP_WREQ_OPRS_SN',
prompt                 'WSH_TRIP_SN', 'WSH_TRIP_STOP_SN','WSM_LJ_OPRS_SN','WSM_LJ_OPR_NWK_SN','WSM_LJ_OPR_RESS_INSTS_SN','WSM_LJ_OPR_RESS_SN',
prompt                 'WSM_LJ_REQ_OPRS_SN','MSC_ATP_PLAN_SN','CSP_REPAIR_PO_HEADERS_SN','EAM_WO_RELATIONSHIPS_SN','MTL_ITEM_RELATIONSHIPS_SN',
prompt                 'WIP_WOPR_NETWORKS_SN','WSH_DELIVERY_DETAILS_SN')
prompt            order by 5 desc;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Owner</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>MLOG$ Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Base Table Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>MView Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Num Rows</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Stat Type Locked</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Analyzed</B></TD></TR>
exec :n := dbms_utility.get_time;
select 
'<TR><TD>'||log_owner||'</TD>'||chr(10)|| 
'<TD>'||LOG_TABLE||'</TD>'||chr(10)|| 
'<TD>'||detailobj_name||'</TD>'||chr(10)||
'<TD>'||mview_name||'</TD>'||chr(10)||
'<TD>'||count||'</TD>'||chr(10)||
'<TD>'||num_rows||'</TD>'||chr(10)||
'<TD>'||STATTYPE_LOCKED||'</TD>'||chr(10)||
'<TD>'||LAST_ANALYZED||'</TD>'
from (
select  distinct
dsl.log_owner
,DSL.LOG_TABLE 
,detailobj_name
,amdr.mview_name
,to_number( extractvalue( xmltype( dbms_xmlgen.getxml('select count(*) c from '||log_owner||'.'||LOG_TABLE)) ,'/ROWSET/ROW/C')) count
,dts.num_rows
,dts.STATTYPE_LOCKED
,LAST_ANALYZED
     from DBA_TAB_STATISTICS dts  
            ,all_mview_detail_relations amdr
             , dba_snapshot_logs dsl
      where  dts.table_name= DSL.LOG_TABLE
      and dts.owner=dsl.log_owner
      and detailobj_type = 'TABLE'
            -- and ( detailobj_owner, detaiLobj_name ) not in                 (( 'MSC', 'MSC_COLLECTED_ORGS' ))
             and amdr.detailobj_name = dsl.MASTER
             and detailobj_name in ( 'AHL_SCHEDULE_MATERIALS',
                                     'BOM_COMPONENTS_B',
                                     'BOM_CTO_ORDER_DEMAND',
                                     'BOM_DEPARTMENTS',
                                     'BOM_OPERATIONAL_ROUTINGS',
                                     'BOM_OPERATION_NETWORKS',
                                     'BOM_OPERATION_SEQUENCES',
                                     'BOM_OPERATION_RESOURCES',
                                     'BOM_RESOURCE_CHANGES',
                                     'BOM_RES_INSTANCE_CHANGES',
                                     'BOM_STRUCTURES_B',
                                     'BOM_SUBSTITUTE_COMPONENTS',
                                     'BOM_SUB_OPERATION_RESOURCES',
                                     'CSP_REPAIR_PO_HEADERS',
                                     'EAM_WO_RELATIONSHIPS',
                                     'MRP_FORECAST_DATES',
                                     'MRP_FORECAST_DESIGNATORS',
                                     'MRP_FORECAST_ITEMS',
                                     'MRP_SCHEDULE_DATES',
                                     'MTL_DEMAND',
                                     'MTL_ITEM_CATEGORIES',
                                     'MTL_MATERIAL_TRANSACTIONS_TEMP',
                                     'MTL_ONHAND_QUANTITIES_DETAIL',
                                     'MTL_RELATED_ITEMS',
                                     'MTL_RESERVATIONS', 'MTL_SUPPLY',
                                     'MTL_SYSTEM_ITEMS_B',
                                     'MTL_TXN_REQUEST_LINES',
                                     'MTL_USER_DEMAND', 'MTL_USER_SUPPLY',
                                     'OE_ORDER_LINES_ALL',
                                     'PO_ACCEPTANCES',
                                     'PO_CHANGE_REQUESTS',
                                     'PO_SUPPLIER_ITEM_CAPACITY',
                                     'WIP_DISCRETE_JOBS',
                                     'WIP_FLOW_SCHEDULES',
                                     'WIP_LINES', 'WIP_MSC_OPEN_JOB_STATUSES',
                                     'WIP_OPERATIONS',
                                     'WIP_OPERATION_NETWORKS',
                                     'WIP_OPERATION_RESOURCES',
                                     'WIP_OP_RESOURCE_INSTANCES',
                                     'WIP_REPETITIVE_ITEMS',
                                     'WIP_REPETITIVE_SCHEDULES',
                                     'WIP_REQUIREMENT_OPERATIONS',
                                     'WIP_SUB_OPERATION_RESOURCES',
                                     'WSH_DELIVERY_DETAILS',
                                     'WSH_TRIPS',
                                     'WSH_TRIP_STOPS', 'WSM_COPY_OPERATIONS',
                                     'WSM_COPY_OP_NETWORKS',
                                     'WSM_COPY_OP_RESOURCES',
                                     'WSM_COPY_OP_RESOURCE_INSTANCES',
                                     'WSM_COPY_REQUIREMENT_OPS'
                                       )
             and amdr.mview_name in (
                 'AHL_SCH_MTLS_SN', 'BOM_BOMS_SN',
                 'BOM_CTO_ORDER_DMD_SN',
                 'BOM_INV_COMPS_SN',
                 'BOM_OPR_NETWORKS_SN', 'BOM_OPR_RESS_SN',
                 'BOM_OPR_RTNS_SN',
                 'BOM_OPR_SEQS_SN',
                 'BOM_RES_CHNGS_SN', 'BOM_RES_INST_CHNGS_SN',
                 'BOM_SUB_COMPS_SN',
                 'BOM_SUB_OPR_RESS_SN',
                 'MRP_FORECAST_DATES_SN',
                 'MRP_FORECAST_DSGN_SN',
                 'MRP_FORECAST_ITEMS_SN',
                 'MRP_SCHD_DATES_SN',
                 'MTL_DEMAND_SN', 'MTL_ITEM_CATS_SN',
                 'MTL_MTRX_TMP_SN',
                 'MTL_OH_QTYS_SN',
                 'MTL_RESERVATIONS_SN', 'MTL_SUPPLY_SN',
                 'MTL_SYS_ITEMS_SN',
                 'MTL_TXN_REQUEST_LINES_SN',
                 'MTL_U_DEMAND_SN', 'MTL_U_SUPPLY_SN',
                 'OE_ODR_LINES_SN',
                 'PO_ACCEPTANCES_SN',
                 'PO_CHANGE_REQUESTS_SN', 'PO_SI_CAPA_SN',
                 'WIP_DSCR_JOBS_SN',
                 'WIP_FLOW_SCHDS_SN',
                 'WIP_OPR_RES_INSTS_SN', 'WIP_REPT_ITEMS_SN',
                 'WIP_REPT_SCHDS_SN',
                 'WIP_WLINES_SN',
                 'WIP_WOPRS_SN', 'WIP_WOPR_RESS_SN',
                 'WIP_WOPR_SUB_RESS_SN',
                 'WIP_WREQ_OPRS_SN',
                 'WSH_TRIP_SN', 'WSH_TRIP_STOP_SN',
                 'WSM_LJ_OPRS_SN',
                 'WSM_LJ_OPR_NWK_SN',
                 'WSM_LJ_OPR_RESS_INSTS_SN',
                 'WSM_LJ_OPR_RESS_SN',
                 'WSM_LJ_REQ_OPRS_SN',
                 'MSC_ATP_PLAN_SN',
                 'CSP_REPAIR_PO_HEADERS_SN',
                 'EAM_WO_RELATIONSHIPS_SN',
                 'MTL_ITEM_RELATIONSHIPS_SN',
                 'WIP_WOPR_NETWORKS_SN',
                 'WSH_DELIVERY_DETAILS_SN'
                                    ))
order by count desc;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
v_oe_mlogcount number;
v_oe_ascp_count number;
Begin
v_count:=0;

    select count(*) into v_count
        from   fnd_application_vl fav, fnd_product_installations fpi 
        where fav.application_id = fpi.application_id and 
        fpi.APPLICATION_ID in (455)         -- Oracle Product Intelligence
        and fpi.status='I';
    IF v_count < 1 THEN
    dbms_output.put_line('You are NOT using DBI (Oracle Product Intelligence) you may truncate the table and drop the materialized view log on it by running the following commands:');
    dbms_output.put_line(' DROP SNAPSHOT LOG ON ENI.ENI_OLTP_ITEM_STAR; and TRUNCATE TABLE ENI.ENI_OLTP_ITEM_STAR; Then you can truncate the 2 associated materialized views');
    dbms_output.put_line('MLOG$_ISC_DBI_CFM_002_MV and MLOG$_ISC_DBI_CFM_000_MV. <br>');
    ELSE
      dbms_output.put_line('Oracle Product Intelligence (DBI) is installed in your environment.<br>');
    END IF;
    
    select count(*) into v_oe_mlogcount
    from MLOG$_OE_ORDER_LINES_ALL;
    
    select count(*) into v_oe_ascp_count
    from OE_ODR_LINES_SN 
    where open_flag='Y' and visible_demand_flag='Y';
    
    IF v_oe_mlogcount >=100000 or  v_oe_mlogcount < 1000000 THEN
     dbms_output.put_line('You have'||v_oe_mlogcount||' records in MLOG$_OE_ORDER_LINES_ALL. MLOG$_OE_ORDER_LINES_ALL is a snapshot on OE_ORDER_LINES_ALL table.');
     dbms_output.put_line('The MLOG is not truncated when you do a complete refresh.This happens only if you run Refresh collection snapshots in automatic mode and threshold = zero.<br>');
    END IF;
    
    IF v_oe_ascp_count >=0 THEN
      dbms_output.put_line('You have '||v_oe_ascp_count||' records in OE_ODR_LINES_SN.<br>');
    END IF;
    
End;
/
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1063953.1  ">DocId 1063953.1  </a>
prompt for Handling Refresh Collection Snapshots Performance - Managing MLOG$ Tables and Snapshots for Data Collections.<br>
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=211121.1  ">DocId 211121.1  </a>
prompt for How To Run MSRFWOR - Refresh Collections Snapshots Concurrent Request From The Application.<br>
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=550005.1  ">DocId 550005.1  </a>
prompt for How To Improve the Performance of the Refresh Collection Snapshots When Running Very High Volumes.<br>
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql1143(){var row = document.getElementById("s4sql1143");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2115"></a>
prompt     <B> Information on MRP_AP_APPS_INSTANCES_ALL </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql1143()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql1143" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select instance_id,instance_code,A2M_DBLINK  From_Source_To_APS,
prompt           M2A_DBLINK From_APS_to_Source, ALLOW_ATP_FLAG ,allow_release_flag , LAST_UPDATE_DATE
prompt       from mrp_ap_apps_instances_all;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Id</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Code</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>From_Source_To_APS</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>From_APS_to_Source</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ALLOW_ATP_FLAG</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ALLOW_RELEASE_FLAG</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>LAST_UPDATE_DATE</B></TD></TR>
exec :n := dbms_utility.get_time;
select 
'<TR><TD>'||instance_id||'</TD>'||chr(10)|| 
'<TD>'||instance_code||'</TD>'||chr(10)|| 
'<TD>'||A2M_DBLINK||'</TD>'||chr(10)||
'<TD>'||M2A_DBLINK||'</TD>'||chr(10)||
'<TD>'||decode(ALLOW_ATP_FLAG,1,'1-Yes',2,'2-No')||'</TD>'||chr(10)||
'<TD>'||decode(ALLOW_RELEASE_FLAG,1,'1-Yes',2,'2-No')||'</TD>'||chr(10)||
'<TD>'||LAST_UPDATE_DATE||'</TD>'
from mrp_ap_apps_instances_all
order by instance_id,instance_code;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
v_ins_count number;
v_tot_count number;
Begin
v_count:=0;
v_ins_count:=0;
v_tot_count:=0;

      SELECT count(*) into v_count
      FROM mrp_ap_apps_instances_all
      WHERE allow_atp_flag = 1;
   
   begin   
      select count into v_ins_count
      from
      (select count(*) count,instance_id,instance_code,m2a_dblink,a2m_dblink
      from mrp_ap_apps_instances_all 
      group by instance_id, instance_code, m2a_dblink, a2m_dblink
      having count(*) > 1
      );
    exception
      When others then
        v_ins_count:=0;
    end;
    
    SELECT count(*) into v_tot_count
      FROM mrp_ap_apps_instances_all;

    IF v_count > 1 THEN
    dbms_output.put_line('You can have only ONE ATP able instance in MRP_AP_APPS_INSTANCES table');
    END IF;
    
    IF v_ins_count >0 THEN
      dbms_output.put_line('The MRP_AP_APPS_INSTANCES table should NOT have same Instance Code and/or Instance ID listed more than once.');
    END IF;
    
    IF v_tot_count=0 THEN
      dbms_output.put_line('You should have atleast one record in MRP_AP_APPS_INSTANCES table at ERP Source.');
    END IF;
    
     
End;
/
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=137293.1  ">DocId 137293.1  </a>
prompt for How to Manage APS Partitions in the MSC Schema, section X .<br>
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql1144(){var row = document.getElementById("s4sql1144");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2116"></a>
prompt     <B> Information on Source Profile Setup </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql1144()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql1144" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select fav.application_name,fpo1.user_profile_option_name,fpov.profile_option_value
prompt           ,decode(fpov.level_id, 10001, 'Site', 10002, 'Appl', 10003, 'Resp', 10004, 'User', 'None')
prompt         from   fnd_application_vl fav ,fnd_profile_options_vl fpo1 ,fnd_profile_option_values fpov
prompt  where  fav.application_id=fpo1.application_id and fpo1.profile_option_id=fpov.profile_option_id
prompt and fpov.application_id    in fpo1.application_id
prompt and    fpov.profile_option_id in (select fpo.profile_option_id poi from fnd_profile_options_vl fpo
prompt                                  where fpo.user_profile_option_name in ('MSC: Source Setup Required') 
prompt                                      and    fpo.start_date_active <= sysdate and    (nvl(fpo.end_date_active,sysdate) >= sysdate))
prompt and    ((fpov.level_id = 10001 and fpov.level_value = 0) or    (fpov.level_id = 10002 and fpov.level_value = fpo1.application_id)
prompt or    (fpov.level_id = 10003 and fpov.level_value_application_id = fpo1.application_id 
prompt and    fpov.level_value = (select fnd_profile.value('RESP_ID') from dual)) 
prompt or    (fpov.level_id = 10004 and fpov.level_value = (select fnd_profile.value('USER_ID') from dual)))
prompt  order  by fpov.level_id desc ;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Application Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Option Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Option Value</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Set At</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;
Declare
Cursor sp is select fav.application_name,fpo1.user_profile_option_name profile_name,fpov.profile_option_value profile_value
                ,decode(fpov.level_id, 10001, 'Site', 10002, 'Appl', 10003, 'Resp', 10004, 'User', 'None') set_at
                  from fnd_profile_option_values fpov
                  ,fnd_application_vl fav 
                  ,fnd_profile_options_vl fpo1
                  where fpov.profile_option_id(+)=fpo1.profile_option_id 
                    and fpov.application_id  (+)  = fpo1.application_id
                  and fav.application_id=fpo1.application_id
                  and fpo1.profile_option_id in (select fpo.profile_option_id poi from fnd_profile_options_vl fpo
                                                      where fpo.user_profile_option_name in ('MSC: Source Setup Required','BOM: Hour UOM','INV:Capable to Promise','MRP:Purchasing By Revision'
                                                      ,'MRP: Compute Standard Mandatory Components for ATO Models','MRP:Consume MPS','MRP:Cutoff Date Offset Months'
                                                      ,'MRP:Purge Batch Size','MRP:Retain Dates Within Calendar Boundary','MRP:Use Ship Arrived Flag','MSC: Operator Company Name'
                                                      ,'MSC: Organization containing generic BOM for forecast explosion','MSC: Refresh Site to Region Mappings Event'
                                                      ,'MSC: Sales Orders Offset Days','MSC: Use Shipping/Receiving Calendar','MRP: Plan Revenue Discount Percent'
                                                      ,'MRP: Plan Revenue Price List','MRP:ATP Database Link','MSC: Cost Type','MSC: Inflate WIP Resource Requirements'
                                                      ,'MSC: Purchase Order Dock Date Calculation Preference','BIS: Primary Rate Type') 
                                                      and    fpo.start_date_active <= sysdate
                                                      and    (nvl(fpo.end_date_active,sysdate+1) >= sysdate)
                                                      )
                     and    ((fpov.level_id (+)= 10001 and fpov.level_value(+)  = 0)
                  --   or    (fpov.level_id = 10002 and fpov.level_value = fpo1.application_id)
                  --   or    (fpov.level_id = 10003 and fpov.level_value_application_id = fpo1.application_id 
                   -- and    fpov.level_value = (select fnd_profile.value('RESP_ID') from dual)) 
                    -- or    (fpov.level_id = 10004 and fpov.level_value = (select fnd_profile.value('USER_ID') from dual))
                    )
                  order  by fav.application_name,fpo1.user_profile_option_name ;
Begin
  For spc in sp
   LOOP
           dbms_output.put_line('<TR><TD>'||spc.application_name||'</TD>');                                                                                                     
	   dbms_output.put_line('<TD>'||spc.profile_name||'</TD>');  
           dbms_output.put_line('<TD>'||spc.profile_value||'</TD>');
           dbms_output.put_line('<TD>'||spc.set_at||'</TD>');
          
         IF spc.profile_name='MSC: Source Setup Required' THEN
            IF spc.profile_value='Y' THEN
              dbms_output.put_line('<TD>'||'The Setup Requests did not complete successfully when Refresh Snapshots was launched'||'</TD></TR>');
            ELSE 
            dbms_output.put_line('<TD>'||'If there are problems setting up the objects the first time, then set to Y and run Refresh Snapshots as a standalone request.'||'</TD></TR>');
            END IF;
         END IF;
   END LOOP;
END;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count:=0;      
End;
/
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=137293.1  ">DocId 137293.1  </a>
prompt for How to Manage APS Partitions in the MSC Schema, section X .<br>
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql1145(){var row = document.getElementById("s4sql1145");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2117"></a>
prompt     <B> Sanity Checks for known Issues </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql1145()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql1145" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          SELECT 'Category Id:'||Category_Id Column_Name1, 'Structure Id:'||Structure_Id Column_Name2,'MTL_CATEGORIES_B_KFV Checks for CONCATENATED_SEGMENTS is Null' Exception
prompt          FROM MTL_CATEGORIES_B_KFV
prompt          WHERE CONCATENATED_SEGMENTS IS NULL
prompt          and rownum<=5
prompt          union
prompt        SELECT  'PO Number:'||PO_NUMBER,'PO Line Location Id:'||PO_LINE_LOCATION_ID,'MRP_AP_PO_PO_SUPPLY_V checks for promise_date and Need_By_Date is null'
prompt        FROM     MRP_AP_PO_PO_SUPPLY_V
prompt        WHERE   PROMISED_DATE IS NULL
prompt        AND     NEED_BY_DATE IS NULL
prompt        and rownum<=5 
prompt        union    
prompt        select 'Organization Id:'||organization_id, 'Segment1:'||segment1 , 'MTL_SYSTEM_ITEMS_B check for duplicate records for Organization Id and Segment1 combination'
prompt          from ( select ORGANIZATION_ID, SEGMENT1, count(*)
prompt      from MTL_SYSTEM_ITEMS_B GROUP BY ORGANIZATION_ID, SEGMENT1
prompt      having count(*) > 1);<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Column Name1</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Column Name2</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Exception</B></TD></TR>
exec :n := dbms_utility.get_time;
select 
'<TR><TD>'||Column_name1||'</TD>'||chr(10)|| 
'<TD>'||column_name2||'</TD>'||chr(10)|| 
'<TD>'||exception||'</TD>'
from (
SELECT 'Category Id:'||Category_Id Column_Name1, 'Structure Id:'||Structure_Id Column_Name2,'MTL_CATEGORIES_B_KFV Checks for CONCATENATED_SEGMENTS is Null' Exception
FROM MTL_CATEGORIES_B_KFV
WHERE CONCATENATED_SEGMENTS IS NULL
and rownum<=5
union
SELECT  'PO Number:'||PO_NUMBER,'PO Line Location Id:'||PO_LINE_LOCATION_ID,'MRP_AP_PO_PO_SUPPLY_V checks for promise_date and Need_By_Date is null'
    FROM     MRP_AP_PO_PO_SUPPLY_V
    WHERE   PROMISED_DATE IS NULL
    AND     NEED_BY_DATE IS NULL
    and rownum<=5 
union    
select 'Organization Id:'||organization_id, 'Segment1:'||segment1 , 'MTL_SYSTEM_ITEMS_B check for duplicate records for Organization Id and Segment1 combination'
from (
select ORGANIZATION_ID, SEGMENT1, count(*)
from MTL_SYSTEM_ITEMS_B
GROUP BY ORGANIZATION_ID, SEGMENT1
having count(*) > 1)
where rownum<=5
union
select 'Inventory_Item_id:'||item_id,'Concatenated_Segments:'||item_name1,'Different Items having same inventory_item_id'
from (
 select m1.inventory_item_id item_id,
  m1.concatenated_segments item_name1, m1.organization_id org1,
  m2.concatenated_segments item_name2, m2.organization_id org2
 from
 mtl_system_items_kfv m1,
 mtl_system_items_kfv m2
 where
 m1.inventory_item_id = m2.inventory_item_id
 and m1.organization_id <> m2.organization_id
 and m1.concatenated_segments <> m2.concatenated_segments
 ) where rownum<=5
union
 select 'Inventory_Item_id:'||inventory_item_id,'Category_id:'||category_id,'Duplicate records in from mtl_item_categories'
from (
select inventory_item_id,
 organization_id,
 category_set_id,
 category_id
 , count(*)
 from mtl_item_categories
 group by
 inventory_item_id,
 organization_id,
 category_set_id,
 category_id
 having count(*) > 1
 ) where rownum<=5 
);
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_cat number;
v_po number;
v_item number;
v_item_id number;
v_item_cat number;
Begin
v_cat:=0;
v_po:=0;
v_item:=0;
v_item_id:=0;
v_item_cat:=0;
  select count(*) into v_cat 
  FROM MTL_CATEGORIES_B_KFV
  WHERE CONCATENATED_SEGMENTS IS NULL;
  
  select count(*) into v_po
  FROM     MRP_AP_PO_PO_SUPPLY_V
  WHERE   PROMISED_DATE IS NULL
    AND     NEED_BY_DATE IS NULL;
    
    select count(*) into v_item
    from (
    select ORGANIZATION_ID, SEGMENT1, count(*)
    from MTL_SYSTEM_ITEMS_B
    GROUP BY ORGANIZATION_ID, SEGMENT1
    having count(*) > 1);
  
    select count(*) into v_item_id
    from (
     select m1.inventory_item_id item_id,
      m1.concatenated_segments item_name1, m1.organization_id org1,
      m2.concatenated_segments item_name2, m2.organization_id org2
     from
     mtl_system_items_kfv m1,
     mtl_system_items_kfv m2
     where
     m1.inventory_item_id = m2.inventory_item_id
     and m1.organization_id <> m2.organization_id
     and m1.concatenated_segments <> m2.concatenated_segments
     ) ;
     
     select Count(*) into v_item_cat
      from (
      select inventory_item_id,
       organization_id,
       category_set_id,
       category_id
       , count(*)
       from mtl_item_categories
       group by
       inventory_item_id,
       organization_id,
       category_set_id,
       category_id
       having count(*) > 1
       );
  
  
  dbms_output.put_line('There are ' ||v_cat|| ' records for MTL_CATEGORIES_B_KFV Checks where CONCATENATED_SEGMENTS is Null.<br>');
  IF v_cat > 0 THEN
  dbms_output.put_line('<br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=340172.1  ">DocId 340172.1</a>');
  dbms_output.put_line(' for ASCP Collection Failed During Planning ODS Load: ORA-1400.');
  END IF;
  dbms_output.put_line('There are ' ||v_po|| ' records for MRP_AP_PO_PO_SUPPLY_V checks where promise_date and Need_By_Date is null.<br>');
  IF v_po > 0 THEN
  dbms_output.put_line('<br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=413816.1  ">DocId 413816.1  </a>');
  dbms_output.put_line(' for ODS Load Worker Completed with Warning with ORA-01400 in Procedure LOAD_SUPPLY For A Purchase Order.');
  END IF;
  dbms_output.put_line('There are ' ||v_item|| ' records for MTL_SYSTEM_ITEMS_B check for duplicate records for Organization Id and Segment1 combination.<br>');
  IF v_item > 0 THEN
  dbms_output.put_line('<br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=559998.1  ">DocId 559998.1  </a>');
  dbms_output.put_line(' for Planning ODS Load Worker Fails With Ora-01452: Cannot Create Unique Index.');
  END IF;
  dbms_output.put_line('There are ' ||v_item_id|| ' records for Different Items having same inventory_item_id.<br>');
  IF v_item_id > 0 THEN
  dbms_output.put_line('<br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=333758.1  ">DocId 333758.1</a>');
  dbms_output.put_line(' for Planning ODS Load Is Erroring ORA-01452: cannot CREATE UNIQUE INDEX OR ORA-00001.');
  END IF;
  dbms_output.put_line('There are ' ||v_item_cat|| ' records for Duplicate records in mtl_item_categories.<br>');
  IF v_item_id > 0 THEN
  dbms_output.put_line('<br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=333758.1  ">DocId 333758.1</a>');
  dbms_output.put_line(' for Planning ODS Load Is Erroring ORA-01452: cannot CREATE UNIQUE INDEX OR ORA-00001.');
  END IF;
END;
/
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 
REM
REM ******* Verify ASCP Destination Side Setups *******
REM

REM prompt <a name="adv141"></a><B><font size="+2" color="blue">Destination Side Setups </font></B><BR><BR>
prompt <a name="section22"></a><B><h2 style="background-color:#CCCCCC;" align="center"><font size="+2" color="blue">Destination Side Setups </font></B></h2><BR><BR>


exec :n := dbms_utility.get_time;
Declare
Cursor cdp is select distinct a.USER_CONCURRENT_QUEUE_NAME name,d.max_processes value
		from FND_CONCURRENT_QUEUES_VL a
    			,FND_CONCURRENT_QUEUE_CONTENT b
    			,FND_CONCURRENT_QUEUE_SIZE d
		where d.queue_application_id=b.queue_application_id
  			and d.concurrent_queue_id=b.concurrent_queue_id
  			and b.queue_application_id=a.application_id
   			and b.concurrent_queue_id=a.concurrent_queue_id
   			and b.include_flag='I'
   			and exists(select null from fnd_concurrent_programs_vl c
              				where c.application_id=b.type_application_id
              					and c.concurrent_program_id=b.type_id
              		and (c.user_concurrent_program_name in ('Planning Data Pull','Planning ODS Load') or c.application_id=724 )
                                )
                    union
                select distinct a.USER_CONCURRENT_QUEUE_NAME name,d.max_processes value
		from FND_CONCURRENT_QUEUES_VL a
    			,FND_CONCURRENT_QUEUE_CONTENT b
    			,FND_CONCURRENT_QUEUE_SIZE d
		where d.queue_application_id=b.queue_application_id
  			and d.concurrent_queue_id=b.concurrent_queue_id
  			and b.queue_application_id=a.application_id
   			and b.concurrent_queue_id=a.concurrent_queue_id
                        and a.user_concurrent_queue_name='Standard Manager'
                 	and not exists(select null from fnd_concurrent_programs_vl c
              				where c.application_id=b.type_application_id
              					and c.concurrent_program_id=b.type_id
              		and (c.user_concurrent_program_name in ('Planning Data Pull','Planning ODS Load') or c.application_id=724 or c.concurrent_program_name like '%Collection%Snapshot%')
                                  );  
  
              
v_max_processes number;
v_sw   number;
v_cfc   number;

Begin
v_sw:=0;
       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2211">');
       dbms_output.put_line('<a name="wfadmins"></a><B>Concurrent Managers Check for ASCP Application Programs</B></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Concurrent Manager Name</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Max Processes</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Recommendations</B></font></TD>');
       
For dp in cdp
        LOOP

                
                dbms_output.put_line('<TR><TD>'||dp.name||'</TD>');                                                                                                     
		dbms_output.put_line('<TD>'||dp.value||'</TD>');   
                
      --   IF :env_id ='C'  THEN
         
	    select nvl(fnd_profile.value('MRP_SNAPSHOT_WORKERS'),0) into v_sw from dual;

	  IF dp.value >=v_sw*2+6 THEN
dbms_output.put_line('<TD>You have recommended value. Using 12.1 technology, and when running Data Collections with a Complete Refresh, you could benefit from having a very large number � 25 to 40 �  work shifts (processes).</TD></TR>');
          ELSE
                  dbms_output.put_line('<TD>'||'<B>Warning</B>');
                  dbms_output.put_line('Manager for ASCP Programs should have minimum of MRP: Snapshot Workers profile value * 2 + 6.');
		  dbms_output.put_line('Please review <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=145419.1#mozTocId991385"');
                  dbms_output.put_line('target="_blank">Note 145419.1</a> - for setting this value.</TD></TR><BR>');
                  
          END IF;

       --END IF;	          
       END LOOP;
        dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at Concurrent Managers check'||sqlerrm);
          
end;
/



exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>




REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql21(){var row = document.getElementById("s4sql21");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2212"></a>
prompt     <B> Report Statistics - Last_Analyzed on Partitions seven or more days ago </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql21()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql21" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select table_owner,table_name,partition_name,last_analyzed
prompt          from dba_tab_partitions 
prompt          where table_owner = 'MSC'
prompt          and last_analyzed <sysdate-7 and rownum<=20;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Owner</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Partition Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Analyzed</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||Table_Owner||'</TD>'||chr(10)|| 
'<TD>'||Table_Name||'</TD>'||chr(10)|| 
'<TD>'||Partition_Name||'</TD>'||chr(10)|| 
'<TD>'||Last_Analyzed||'</TD>'
from dba_tab_partitions
where table_owner = 'MSC'
and last_analyzed <sysdate-7 and rownum<=20;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count:=0;

    select count(*) into v_count
    from dba_tab_partitions
    where table_owner = 'MSC'
    and last_analyzed <sysdate-7;
    dbms_output.put_line('You have total of '||v_count|| ' records for which Last_Analyzed date is more than 7 days ago. Sample list is provided above.<br>');

End;
/
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=137293.1 ">DocId 137293.1 </a>
prompt for How to Manage APS Partitions in the MSC Schema.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql22(){var row = document.getElementById("s4sql22");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2213"></a>
prompt     <B> Instance Setups (MSC_APPS_INSTANCES) and Organizations enabled for Collections </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql22()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql22" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select instance_id,instance_code,instance_type,apps_ver,a2m_dblink From_Source_To_APS,m2a_dblink From_APS_to_Source,enable_flag
prompt          ,st_status,(select count(*) from msc_instance_orgs where sr_instance_id=mai.instance_id and enabled_flag=1) Orgs_Enabled_Count
prompt          from MSC_APPS_INSTANCES mai;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Id</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Code</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Type</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Apps Ver</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>From Source to APS</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>From APS to Source</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Enabled Flag</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>St Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B> No. of Orgs Enabled</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||instance_id||'</TD>'||chr(10)|| 
'<TD>'||instance_code||'</TD>'||chr(10)|| 
'<TD>'||decode(instance_type, 1,'1-Discrete',2,'2-Process',3,'3-Others',4,'4-Discrete and Process',5,'5-Exchange')||'</TD>'||chr(10)|| 
'<TD>'||decode(apps_ver,1,'1- 10.7',2,'2- 11',3,'3- 11i',4,'4- 12.0',5,'5- 12.1',6,'6- 12.2',-1,'-1- Legacy')||'</TD>'||chr(10)|| 
'<TD>'||a2m_dblink||'</TD>'||chr(10)|| 
'<TD>'||m2a_dblink||'</TD>'||chr(10)|| 
'<TD>'||decode(enable_flag,1,'Enabled',2,'Disabled')||'</TD>'||chr(10)|| 
'<TD>'||decode(st_status,0,'0-No source pull or collection is in process',1,'1-No source pull or collection is in process'
,2,'2-Collection has ended and waiting for load to begin',3,'3-Load has begun',4,'4-Load has ended and staging tables are being purged')||'</TD>'||chr(10)|| 
'<TD>'||(select count(*) from msc_instance_orgs where sr_instance_id=mai.instance_id and enabled_flag=1)||'</TD>'
from MSC_APPS_INSTANCES mai;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_status varchar2(20);
v_request number;
Begin
v_request :=null;
v_status :=null;

    select  decode(status_code,'C','Normal','E','Error','D','Cancelled'),request_id into v_status,v_request
 from fnd_concurrent_requests 
 where request_id in (
            select max(request_id)
               from fnd_concurrent_requests cr
                    ,fnd_concurrent_programs cp
                    ,fnd_concurrent_programs_tl fcpt
              where trunc(cr.request_date) >=trunc(sysdate)-15
                 and cr.concurrent_program_id=cp.concurrent_program_id
                and cp.concurrent_program_id=fcpt.concurrent_program_id
                and  fcpt.user_concurrent_program_name ='Planning Data Pull');
                
    dbms_output.put_line('Your latest request id '||v_request|| ' of Planning Data Pull program completed with Status '||v_status||'.<br>');
    IF v_status <>'Normal' THEN
      dbms_output.put_line('Review logs produced by the Planning Data pull process and refer <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=146016.1 ">DocId 146016.1 </a>');
      dbms_output.put_line('for APS Data Collection Processing and the Importance of the ST_STATUS Column');
    END IF;
    
    
End;
/
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=145419.1 ">DocId 145419.1 </a>
prompt for How to Setup and Run Data Collections section Instance setup.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql221(){var row = document.getElementById("s4sql221");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2213"></a>
prompt     <B> MSC_INST_PARTITIONS - Instance Partition Setups </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql221()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql221" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select instance_id,(select instance_code from msc_apps_instances where instance_id=mip.instance_id) instance_code
prompt          ,decode(free_flag,1,'1-Free',2,'2-In Use') Free_Flag,creation_date,last_update_date
prompt          from msc_inst_partitions mip;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Id</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Code</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Free Flag</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Creation Date</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B> Last Update Date</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||instance_id||'</TD>'||chr(10)|| 
'<TD>'||(select instance_code from msc_apps_instances where instance_id=mip.instance_id)||'</TD>'||chr(10)|| 
'<TD>'||decode(free_flag,1,'1-Free',2,'2-In Use')||'</TD>'||chr(10)|| 
'<TD>'||creation_date||'</TD>'||chr(10)|| 
'<TD>'||last_update_date||'</TD>'
from msc_inst_partitions mip;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
prompt Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=145419.1 ">DocId 145419.1 </a>
prompt for How to Setup and Run Data Collections section Instance setup.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql23(){var row = document.getElementById("s4sql23");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2214"></a>
prompt     <B> MSC Staging Tables missing Partitions </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql23()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql23" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          SELECT flv.application_id,fav.application_name, flv.table_name, mai.instance_id instance_id
prompt          ,decode(mai.instance_type, 1,'Discrete',2,'Process',3,'Others',4,'Discrete and Process',5,'Exchange') instance_type, mai.instance_code
prompt          FROM   msc_staging_table_v flv, msc_apps_instances mai,fnd_application_vl fav
prompt WHERE  flv.application_id=fav.application_id
prompt  AND flv.PARTITION_TYPE = 'L'  AND ( mai.instance_type = 3 OR
prompt NOT EXISTS (select 1 FROM    all_tab_partitions atp
prompt WHERE   atp.table_name = flv.table_name AND
prompt   atp.table_owner = 'MSC'    AND
prompt  atp.partition_name = substr(flv.table_name, 8) || '_' || to_char(mai.instance_id)));<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Application Id</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Appplication Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance_id</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Type</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B> Instance Code</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||flv.application_id||'</TD>'||chr(10)|| 
'<TD>'||fav.application_name||'</TD>'||chr(10)|| 
'<TD>'||flv.table_name||'</TD>'||chr(10)|| 
'<TD>'||mai.instance_id||'</TD>'||chr(10)|| 
'<TD>'||decode(mai.instance_type, 1,'Discrete',2,'Process',3,'Others',4,'Discrete and Process',5,'Exchange')||'</TD>'||chr(10)|| 
'<TD>'||mai.instance_code||'</TD>'
   FROM   msc_staging_table_v flv, msc_apps_instances mai,fnd_application_vl fav
   WHERE  flv.application_id=fav.application_id
    AND flv.PARTITION_TYPE = 'L'  AND
          ( mai.instance_type = 3 OR 
          NOT EXISTS (select 1 FROM    all_tab_partitions atp
                      WHERE   atp.table_name = flv.table_name AND
                              atp.table_owner = 'MSC'    AND
                              atp.partition_name = substr(flv.table_name, 8) || '_' || to_char(mai.instance_id)))
    AND rownum<=10;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count := 0;

    SELECT count(*) into v_count
    FROM   msc_staging_table_v flv, msc_apps_instances mai,fnd_application_vl fav
    WHERE  flv.application_id=fav.application_id
    AND flv.PARTITION_TYPE = 'L'  AND
          ( mai.instance_type = 3 OR 
          NOT EXISTS (select 1 FROM    all_tab_partitions atp
                      WHERE   atp.table_name = flv.table_name AND
                              atp.table_owner = 'MSC'    AND
                              atp.partition_name = substr(flv.table_name, 8) || '_' || to_char(mai.instance_id)));
                
      dbms_output.put_line('You have total of '||v_count|| ' records for which MSC Staging Tables has missing partitions. Sample list is provided above.<br>');    
End;
/
prompt If there are empty partitions, please drop the empty partitions. A missing partition is a partition whos partition number is not used in a partition name in a table but is listed in the MSC_APPS_INSTANCES table. 
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=338432.1 ">DocId 338432.1 </a>
prompt for MSCPDC ODS Load Errors In create_temp_tab_pvt ORA-00922 Missing/Invalid Option.
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=137293.1 ">DocId 137293.1 </a>
prompt for How to Manage APS Partitions in the MSC Schema, section Cleanup Instance Partition Program section.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql231(){var row = document.getElementById("s4sql231");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv22141"></a>
prompt     <B> Exceptions on Instances and Partitions - Missing Information </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql231()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql231" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select instance_id, 'MSC_APPS_INSTANCES not present in MSC_INST_PARTITIONS' Exceptions
prompt          from msc_apps_instances mai
prompt          where not exists (select null from msc_inst_partitions where instance_id=mai.instance_id)
prompt        union
prompt      select instance_id, 'MSC_INST_PARTITIONS not present in MSC_APPS_INSTANCES'
prompt      from msc_inst_partitions mip
prompt      where not exists (select null from msc_apps_instances where instance_id=mip.instance_id);<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Instance Id</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Exception</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||Instance_id||'</TD>'||chr(10)|| 
'<TD>'||exceptions||'</TD>'
FROM (
  select instance_id, 'MSC_APPS_INSTANCES not present in MSC_INST_PARTITIONS' Exceptions
from msc_apps_instances mai
where not exists (select null from msc_inst_partitions where instance_id=mai.instance_id)
union
select instance_id, 'MSC_INST_PARTITIONS not present in MSC_APPS_INSTANCES'
from msc_inst_partitions mip
where not exists (select null from msc_apps_instances where instance_id=mip.instance_id));
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count := 0;
null;
End;
/
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=338432.1 ">DocId 338432.1 </a>
prompt for MSCPDC ODS Load Errors In create_temp_tab_pvt ORA-00922 Missing/Invalid Option.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql2311(){var row = document.getElementById("s4sql2311");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv221411"></a>
prompt     <B> Exceptions on Instances and Partitions - Missing Information </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql2311()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql2311" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select table_name from msc_ods_table_v where partition_type<>'U'; -- For ODS Tables
prompt          select instance_id from MSC_APPS_INSTANCES; -- For Instance Information
prompt        -- For exception check
prompt          select owner, segment_name, partition_name,segment_type, tablespace_name
prompt        from dba_segments ds where segment_name ='MSC_SYSTEM_ITEMS' and INSTR(partition_name,'__') >0
prompt      and not exists (select null from MSC_APPS_INSTANCES where instance_id=substr(partition_name,instr(partition_name,'_',-1,1)+1));<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B># of Instances</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B># of Template Partitions</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B># of Instance Partitions</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B># of Instance Partitions with No Instances</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;
Declare
cursor c1 is select table_name
            from msc_ods_table_v
            where partition_type<>'U';
            --and table_name='MSC_SYSTEM_ITEMS';
cursor c2 is select instance_id from MSC_APPS_INSTANCES;
cursor c3(p_table_name varchar2) is select
              owner,
              segment_name,
              partition_name,
              segment_type,
              tablespace_name,substr(partition_name,instr(partition_name,'_',-1,1)+1) instance_id
              from dba_segments ds
              where segment_name =p_table_name
              and INSTR(partition_name,'__') >0
              and not exists (select null from MSC_APPS_INSTANCES where instance_id=substr(partition_name,instr(partition_name,'_',-1,1)+1));
v_ins_count number;
v_ins_ex  number;
v_ins_present number;
v_ins_tot number;
v_template number;
v_comment varchar2(1000);
Begin
  v_ins_count:=0;
  v_ins_ex:=0;
  v_ins_present:=0;
  v_ins_tot:=0;
  v_template:=0;
  v_comment:=null;
  select count(*) into v_ins_tot
  from MSC_APPS_INSTANCES
  where enable_flag=1;
  
  For cc in c1
  LOOP
  v_ins_count:=0;
  v_ins_ex:=0;
  v_ins_present:=0;
  v_template:=0;
  v_comment:=null;
    -- Check for instance partition for all instances
     For ci in c2 
     LOOP
         select count(*) into v_ins_count 
        from dba_segments
      where segment_name =cc.table_name
      --and partition_name like '%SYSTEM_ITEMS__%'
      and substr(partition_name,instr(partition_name,'_',-1,1)+1)=ci.instance_id;
      
      IF v_ins_count=0 THEN
        --dbms_output.put_line('No Instance partition available for table name '||cc.table_name||' and instance '||ci.instance_id);
        null;
      ELSIF v_ins_count>1 THEN
        --dbms_output.put_line('There are more than one Instance partition available for table name '||cc.table_name||' and instance '||ci.instance_id);
        null;
      ELSIF v_ins_count=1 THEN
        v_ins_present:=v_ins_present+1;
      END IF;
     END LOOP;
     -- check if there are any table partitions for which instance is not available
     For cc3 in c3(cc.table_name)
     LOOP
     --    dbms_output.put_line('There is an exception for table ' ||cc.table_name||' for which instance is not present for partition name '||cc3.partition_name);
         v_ins_ex:=v_ins_ex+1;
     END LOOP;
     -- check for template partition
     select count(*) into v_template
     from dba_segments ds
    where segment_name ='MSC_SYSTEM_ITEMS'
    and INSTR(partition_name,'_0') >0;
    
    IF v_template =1 THEN
      --dbms_output.put_line('We have Template partition for table '||cc.table_name);
      v_comment:='We have Template partition for this table.';
    ELSIF v_template>1 THEN
     -- dbms_output.put_line('We have more than one Template partition for table '||cc.table_name);
      v_comment:='We have more than one Template partition for this table';
    ELSE
      --dbms_output.put_line('Warning! We do not have Template partition for table '||cc.table_name);
      v_comment:='Warning! We do not have Template partition for this table';
    END IF;

    -- dbms_output.put_line('For table '||cc.table_name||' No. instances partition present is '||v_ins_present||' out of ' ||v_ins_tot||' instances. Exception count:Partition with no Instance is '||v_ins_ex||' and we have '||v_template||' record for template partition.' );
     dbms_output.put_line('<TR><TD>'||cc.table_name||'</TD>'); 
     dbms_output.put_line('<TD>'||v_ins_tot||'</TD>'); 
     dbms_output.put_line('<TD>'||v_template||'</TD>'); 
     dbms_output.put_line('<TD>'||v_ins_present||'</TD>'); 
     dbms_output.put_line('<TD>'||v_ins_ex||'</TD>');
     
     IF v_ins_tot<v_ins_present THEN
          v_comment:=v_comment||'Warning! There are some instances for which Table partition is not present';
     END IF;
     IF v_ins_ex>0 THEN
       v_comment:=v_comment||' There are partitions for this table which has no corresponding instance present.';
     END IF;
    
    dbms_output.put_line('<TD>'||v_comment||'</TD></TR>');
  
  END LOOP;
  
end;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count := 0;
null;
End;
/
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=137293.1 ">DocId 137293.1 </a>
prompt for How to Manage APS Partitions in the MSC Schema.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql232(){var row = document.getElementById("s4sql232");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv22142"></a>
prompt     <B> Missing Indexes Information </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql232()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql232" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select ods.table_name, ai.index_name, substr(ods.table_name,5) || '__' || to_char(mip.instance_id) partition_name
prompt          from msc_ods_table_v ods, msc_inst_partitions mip, all_indexes ai
prompt          where ods.partition_type = 'R'
prompt          and ods.table_name = ai.table_name
prompt          MINUS
prompt          select ods.table_name, aip.index_name, aip.partition_name
prompt          from all_ind_partitions aip, all_indexes ai, msc_ods_table_v ods
prompt          where ods.partition_type = 'R'
prompt          and ods.table_name = ai.table_name
prompt          and ai.index_name = aip.index_name
prompt          and ai.owner = aip.index_owner;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Index Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Partition Name</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||Table_name||'</TD>'||chr(10)|| 
'<TD>'||Index_name||'</TD>'||chr(10)|| 
'<TD>'||Partition_name||'</TD>'
FROM (
select ods.table_name, ai.index_name, substr(ods.table_name,5) || '__' || to_char(mip.instance_id) partition_name
from msc_ods_table_v ods, msc_inst_partitions mip, all_indexes ai
where ods.partition_type = 'R'
and ods.table_name = ai.table_name
MINUS
select ods.table_name, aip.index_name, aip.partition_name
from all_ind_partitions aip, all_indexes ai, msc_ods_table_v ods
where ods.partition_type = 'R'
and ods.table_name = ai.table_name
and ai.index_name = aip.index_name
and ai.owner = aip.index_owner
) 
where rownum<=10;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count := 0;
          select count(*) into v_count
          from (
          select ods.table_name, ai.index_name, substr(ods.table_name,5) || '__' || to_char(mip.instance_id) partition_name
          from msc_ods_table_v ods, msc_inst_partitions mip, all_indexes ai
          where ods.partition_type = 'R'
          and ods.table_name = ai.table_name
          MINUS
          select ods.table_name, aip.index_name, aip.partition_name
          from all_ind_partitions aip, all_indexes ai, msc_ods_table_v ods
          where ods.partition_type = 'R'
          and ods.table_name = ai.table_name
          and ai.index_name = aip.index_name
          and ai.owner = aip.index_owner) ;
      dbms_output.put_line('You have total of '||v_count|| ' records for which Indexes are missing. Sample list is provided above.<br>');  
End;
/
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=340118.1">DocId 340118.1 </a>
prompt for ODS Load Fails with Errors: ORA-02478 ORA-14098 index mismatch for tables.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql233(){var row = document.getElementById("s4sql233");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv22143"></a>
prompt     <B> Partioned Tables - Last Analyzed 7 or more days ago </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql233()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql233" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select table_name,partition_name,num_rows,high_value,sample_size,last_analyzed,global_stats
prompt          from ( SELECT table_name, partition_name, num_rows, high_value, sample_size, last_analyzed, global_stats 
prompt          FROM all_tab_partitions WHERE table_name like 'MSC%' and last_analyzed<sysdate -7
prompt          order by substr(partition_name,instr(partition_name,'_',-1,1)+1) );<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Partition Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Num Rows</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Sample Size</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Analyzed</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Global Stats</B></TD></TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||table_name||'</TD>'||chr(10)|| 
'<TD>'||partition_name||'</TD>'||chr(10)|| 
'<TD>'||num_rows||'</TD>'||chr(10)|| 
'<TD>'||sample_size||'</TD>'||chr(10)|| 
'<TD>'||last_analyzed||'</TD>'||chr(10)|| 
'<TD>'||global_stats||'</TD>'
FROM ( SELECT table_name, partition_name, num_rows, high_value, sample_size, last_analyzed, global_stats 
  FROM all_tab_partitions WHERE table_name like 'MSC%' and last_analyzed<sysdate -7
  order by substr(partition_name,instr(partition_name,'_',-1,1)+1) ) where rownum<=10;
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count := 0;
          select count(*) into v_count
          FROM ( SELECT table_name, partition_name, num_rows, high_value, sample_size, last_analyzed, global_stats 
                FROM all_tab_partitions WHERE table_name like 'MSC%' and last_analyzed<sysdate -7
                order by substr(partition_name,instr(partition_name,'_',-1,1)+1) );
      dbms_output.put_line('You have total of '||v_count|| ' records of partitioned table last analyzed 7 or more days ago. Sample list is provided above.<br>');  
End;
/
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=137293.1">DocId 137293.1 </a>
prompt for How to Manage APS Partitions in the MSC Schema.
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql24(){var row = document.getElementById("s4sql24");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2215"></a>
prompt     <B> Information on Source Profile Setup </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql24()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql24" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select fav.application_name,fpo1.user_profile_option_name,fpov.profile_option_value
prompt           ,decode(fpov.level_id, 10001, 'Site', 10002, 'Appl', 10003, 'Resp', 10004, 'User', 'None')
prompt         from   fnd_application_vl fav ,fnd_profile_options_vl fpo1 ,fnd_profile_option_values fpov
prompt  where  fav.application_id=fpo1.application_id and fpo1.profile_option_id=fpov.profile_option_id
prompt and fpov.application_id    in fpo1.application_id
prompt and    fpov.profile_option_id in (select fpo.profile_option_id poi from fnd_profile_options_vl fpo
prompt                                  where fpo.user_profile_option_name in ('MSC: Source Setup Required') 
prompt                                      and    fpo.start_date_active <= sysdate and    (nvl(fpo.end_date_active,sysdate) >= sysdate))
prompt and    ((fpov.level_id = 10001 and fpov.level_value = 0) or    (fpov.level_id = 10002 and fpov.level_value = fpo1.application_id)
prompt or    (fpov.level_id = 10003 and fpov.level_value_application_id = fpo1.application_id 
prompt and    fpov.level_value = (select fnd_profile.value('RESP_ID') from dual)) 
prompt or    (fpov.level_id = 10004 and fpov.level_value = (select fnd_profile.value('USER_ID') from dual)))
prompt  order  by fpov.level_id desc ;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Application Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Option Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Option Value</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Set At</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;
Declare
Cursor sp is select fav.application_name,fpo1.user_profile_option_name profile_name,fpov.profile_option_value profile_value
                ,decode(fpov.level_id, 10001, 'Site', 10002, 'Appl', 10003, 'Resp', 10004, 'User', 'None') set_at
                  from fnd_profile_option_values fpov
                  ,fnd_application_vl fav 
                  ,fnd_profile_options_vl fpo1
                  where fpov.profile_option_id(+)=fpo1.profile_option_id 
                    and fpov.application_id  (+)  = fpo1.application_id
                  and fav.application_id=fpo1.application_id
                  and fpo1.profile_option_id in (select fpo.profile_option_id poi from fnd_profile_options_vl fpo
                                                      where fpo.user_profile_option_name in ('MSC: Share Plan Partitions','BOM: Hour UOM','INV:Capable to Promise'
                                                      ,'MRP:Purchasing By Revision','MRP:Cutoff Date Offset Months','MRP:Purge Batch Size','MSC:Collect Completed Jobs'
                                                      ,'MSC: Collect Item, Material and Resource Costs','MSC: Collect CMRO Work Order Demand for PS'
                                                      ,'MSC: Collection Window for Trading Partner Changes (Days)','MSC: Collections Snapshot Threshold','MSC: Configuration'
                                                      ,'MSC: Degree of Parallelism for Index Creation','MSC: Enable ATP Summary Mode','MSC: Operator Company Name'
                                                      ,'MSC: Project Task Collection Window Days','MSC: Refresh Snapshots Pending Timeout','MSC: Sales Orders Offset Days'
                                                      ,'MSC: Sourcing History Start Date Offset(in months)','MSC: Use Shipping/Receiving Calendar','MSC:Coll Error Debug Mode'
                                                      ,'MSC:Coll Performance Debug Mode','MRP: Plan Revenue Discount Percent','MSC: Inflate WIP Resource Requirements'
                                                      ,'MSC: Category for Jobs without an Item Reference','MSC: Category Set for Jobs without an Item Reference'
                                                      ,'MSC: Purchase Order Dock Date Calculation Preference','MSC: Future Days for Currency Conversion'
                                                      ,'MSC: History Days for Currency Conversion','MSC: Days of Resource Availability before sysdate'
                                                      ,'MSC: Service Planning Enabled','BIS: Primary Rate Type','MSC: Batch Size for Self Service Loads'
                                                      ,'MSC: Number of Workers for Self Service Loads','MSC: Self Service Loads Delimiter') 
                                                      and    fpo.start_date_active <= sysdate
                                                      and    (nvl(fpo.end_date_active,sysdate+1) >= sysdate)
                                                      )
                     and    ((fpov.level_id (+)= 10001 and fpov.level_value(+)  = 0)
                  --   or    (fpov.level_id = 10002 and fpov.level_value = fpo1.application_id)
                  --   or    (fpov.level_id = 10003 and fpov.level_value_application_id = fpo1.application_id 
                   -- and    fpov.level_value = (select fnd_profile.value('RESP_ID') from dual)) 
                    -- or    (fpov.level_id = 10004 and fpov.level_value = (select fnd_profile.value('USER_ID') from dual))
                    )
                  order  by fav.application_name,fpo1.user_profile_option_name ;
Begin
  For spc in sp
   LOOP
           dbms_output.put_line('<TR><TD>'||spc.application_name||'</TD>');                                                                                                     
	   dbms_output.put_line('<TD>'||spc.profile_name||'</TD>');  
           dbms_output.put_line('<TD>'||spc.profile_value||'</TD>');
           dbms_output.put_line('<TD>'||spc.set_at||'</TD>');
          
         IF spc.profile_name='MSC: Source Setup Required' THEN
            IF spc.profile_value='Y' THEN
              dbms_output.put_line('<TD>'||'The Setup Requests did not complete successfully when Refresh Snapshots was launched'||'</TD></TR>');
            ELSE 
            dbms_output.put_line('<TD>'||'If there are problems setting up the objects the first time, then set to Y and run Refresh Snapshots as a standalone request.'||'</TD></TR>');
            END IF;
         END IF;
   END LOOP;
END;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count:=0;      
End;
/
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=137293.1  ">DocId 137293.1  </a>
prompt for How to Manage APS Partitions in the MSC Schema, section X .<br>
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


prompt <script type="text/javascript">    function displayRows4sql25(){var row = document.getElementById("s4sql25");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv2216"></a>
prompt     <B> Sanity Checks for Known Issues </B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql25()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql25" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select 'Sr_Inventory_item_id:' sr_inventory_item_id,'sr_instance_id:'||sr_instance_id,'Duplicate Records in MSC_ITEM_ID_LID table.'
prompt          from (
prompt          SELECT sr_instance_id, 
prompt              sr_inventory_item_id, 
prompt              inventory_item_id,
prompt              count(*)
prompt          from msc_item_id_lid
prompt          group by sr_instance_id, 
prompt              sr_inventory_item_id, 
prompt              inventory_item_id
prompt          having count(*) > 1
prompt          );<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Column Name1</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Column Name2</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Exception</B></TD></TR>
exec :n := dbms_utility.get_time;
select 
'<TR><TD>'||Column_name1||'</TD>'||chr(10)|| 
'<TD>'||column_name2||'</TD>'||chr(10)|| 
'<TD>'||exception||'</TD>'
from
(
select 'Sr_Inventory_item_id:'||sr_inventory_item_id column_name1,'sr_instance_id:'||sr_instance_id column_name2,'Duplicate Records in MSC_ITEM_ID_LID table.' Exception
from (
SELECT sr_instance_id, 
              sr_inventory_item_id, 
              inventory_item_id,
              count(*)
from msc_item_id_lid
group by sr_instance_id, 
              sr_inventory_item_id, 
              inventory_item_id
having count(*) > 1) where rownum<=5
);
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody> <tr><td>
Declare
v_count number;
Begin
v_count:=0;     
          select count(*) into v_count
          from
            (
            SELECT sr_instance_id, 
                          sr_inventory_item_id, 
                          inventory_item_id,
                          count(*)
            from msc_item_id_lid
            group by sr_instance_id, 
                          sr_inventory_item_id, 
                          inventory_item_id
            having count(*) > 1
            );
            
            dbms_output.put_line('There are ' ||v_count|| ' duplicate Item records in MSC_ITEM_ID_LID table.<br>');
  
End;
/
prompt <br>Review <a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=960370.1  ">DocId 960370.1  </a>
prompt for Planning ODS Load fails with ORA-01452 in LOAD_ITEM - Also Shows ORA-12801 .<br>
prompt </td></tr></tbody></table>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM **************************************************************************************** 
REM **************************************************************************************** 
REM *******            ASCP Performance Analyzer RDBMS Statistics *******
REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 




REM **************************************************************************************** 
REM **************************************************************************************** 
REM **************************************************************************************** 
REM *******                   Section 1 : ASCP Performance Analyzer RDBMS Statistics *******
REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 




REM *******************************************************************
REM *************  Buffer Cache Hit Ratio Percent  ********************
REM *******************************************************************

prompt <a name="adv500"></a><font size="+2">Buffer Cache Hit Ratio Percent</font><BR><BR>

begin

select round((1-(pr.value/(bg.value+cg.value)))*100,2) into :ratio
from v$sysstat pr, v$sysstat bg, v$sysstat cg
where pr.name='physical reads'
and bg.name='db block gets'
and cg.name='consistent gets';

dbms_output.put_line('Buffer Cache Hit Percent Gauge'||'<font size="+1"> <b>Your ratio is: </b>'||:ratio||'</font><BR><BR>');

if (:ratio < 80) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=525x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 80 percent.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

  else   if (:ratio between 81 and 95) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:90');
  dbms_output.put('\&chl=Fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 95 percent.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put_line('<b>Workflow Runtime Data Table Gauge</b><BR>');
  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=Good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your cache hit percent is good.  No performance impact.</font><BR><BR> ');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *************  Dictionary Cache Hit Ratio
REM **************************************************************************************** 

prompt <a name="adv501"></a><B><font size="+2">Dictionary Cache Hit Ratio</font></B><BR><BR>

begin

select round(sum(gets-getmisses)*100/sum(gets),2) into :ratio
from v$rowcache;

dbms_output.put_line('Data Dictionary Hit Percent Gauge'||'<font size="+1"> <b>Your ratio is: </b>'||:ratio||'</font><BR><BR>');

if (:ratio < 70) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR>');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

  else if (:ratio between 70 and 90) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:80');
  dbms_output.put('\&chl=Fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR> ');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=Good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR> ');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *************  Sorts in Memory
REM **************************************************************************************** 

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Sorts in Memory</font></b></a></p><br>
prompt     <a name="top"><font size="+1">This metric represents the sort efficiency as measured by the percentage of times sorts were performed in memory as opposed to going to disk.<br>
prompt     For best performance, most sorts should occur in memory because sorts to disks are less efficient. If the sort area is too small, extra sort runs will be required during the sort<br>
prompt     operation. This increases CPU and I/O resource consumption.  This test checks the percentage of sorts performed in memory rather than to disk. If the value is less than or equal to the<br>
prompt     threshold values specified by the threshold arguments, and the number of occurrences exceeds the value specified in the "Number of Occurrences" parameter, then a warning or critical alert<br>
prompt     is generated.  For addtional information see Common Observations, Causes, and Solutions for Oracle Database Performance Issues (Doc ID 1453975.1), section <br>
prompt     Cause Identified: Incorrect manual workarea sizing</font></a>
prompt </td></tr></tbody> 
prompt </table><BR><BR>


prompt <a name="adv502"></a><B><font size="+2">Sorts in Memory</font></B><BR><BR>

begin

select round((mem.value/(mem.value+dsk.value))*100,2) into :ratio
from v$sysstat mem, v$sysstat dsk
where mem.name='sorts (memory)'
and dsk.name='sorts (disk)';

dbms_output.put_line('Sorts in Memory Percent Gauge'||'<font size="+1"> <b>Your ratio is: </b>'||:ratio||'</font><BR><BR>');

if (:ratio < 70) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">This is a measure of the proportion of data sorts which occur within memory rather than on disk.</p><BR><BR>');
    dbms_output.put_line('<p>Sorts on disk make use of the users tempoary table space.  The maximum size of sort which will occur in memory is defined by the sort area size, </p><BR>');
    dbms_output.put_line('<p>which is the size within the PGA which will be used. Each Oracle process which sorts will allocate this much memory, though it may not use all of it.</p><BR>');
    dbms_output.put_line('<p>Use of memory for this purpose reduces that available to the SGA.</p><BR>');
    dbms_output.put_line('<p>The sorts are too large to fit in memory and some of the sort data is written out directly to disk. This data is later read back in, using direct reads.</p><BR>');
dbms_output.put_line('<p>With larger Sort Areas in memory, the likelihood of them being exhausted during a sorting operation and having to use a temporary tablespace on disk is reduced.</p><br>');
dbms_output.put_line('<p>Please see Troubleshooting: Tuning the Shared Pool and Tuning Library Cache Latch Contention (Doc ID 62143.1)</font></p><BR>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=Good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Normally, if expensive sorts are hurting your SQL performance, you will notice it elsewhere first.</font></p>');
    dbms_output.put_line('<p>Your sort in memory percent seems healthy.</p><BR><BR>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *************  Free Shared Pool %
REM **************************************************************************************** 

prompt <a name="adv503"></a><B><font size="+2">The percentage of FREE shared pool</font></B><BR><BR>

begin

select round((sum(decode(name,'free memory',bytes,0))/sum(bytes))*100,2) into :ratio from v$sgastat where pool = 'shared pool';

dbms_output.put_line('The percentage of FREE shared pool'||'<font size="+1"> <b>Your Free Percent is: </b>'||:ratio||'</font><BR><BR>');

if (:ratio > 10) THEN

    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">This percentage has greater impact when your process is runnging.  Afterwards the shared pool will be released.</p><BR> ');
    dbms_output.put_line('<p>The percentage of shared pool free, not in use.  This statistic is valuable as you notice a trend.  For example, if a large percentage of the shared pool,</p>');
    dbms_output.put_line('<p>is consistenly free, it is likely that the size of the shared pool can be reduced.  However, lower free values are not necessarily a problem unless other</p>');
    dbms_output.put_line('<p>factors point to problems.  For example, poor dictionary cache hit ratio or a large proportion of reloads.</p><BR>');
    dbms_output.put_line('<p>See Troubleshooting: Tuning the Shared Pool and Tuning Library Cache Latch Contention (Doc ID 62143.1)</p></font><BR>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

else

    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+2">The percentage of free shared pool is less than 10 %.  It is recommended that that the pool is reviewed to determine if the RDBMS requires additional space.</font><BR> ');
    dbms_output.put_line('This percentage has greater importance when your process is running.  Afterwards, the shared pool will be released.<BR><BR>');
    dbms_output.put_line('For more information, see MyOracleSupport note 455179.1.</p><br>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');



    
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM ****************    Shared Pool Reloads
REM **************************************************************************************** 

prompt <a name="adv504"></a><B><font size="+2">Shared Pool Reloads</font></B><BR><BR>

begin

select round(sum(reloads)/sum(pins),2) into :ratio
from v$librarycache
where namespace in ('SQL AREA','TABLE/PROCEDURE','BODY','TRIGGER');

dbms_output.put_line('Shared Pool Reloads Percent'||'<font size="+1"><b> Your ratio is: </b>'||:ratio||'</font><BR><BR>');

    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">It is best if the percentage is low.  We recommend reviewing the following should the percentage be 65% or greater.</font></p><BR>');
    dbms_output.put_line('<p>Shared pool reloads occur when Oracle has to implicitly reparse SQL or PL/SQL at execution.  A larger shared pool will reduce implicit reparsing.</p>');
    dbms_output.put_line('<p>Ensuring that similar pieces of SQL are written identically will increase sharing of code.  Review the parameter CURSOR_SHARING.  To make use of additional</p>');
    dbms_output.put_line('<p>shared SQL  memory that is available for shared SQL areas, review the parameter OPEN_CURSORS permitted for a session.  Review the parameters open_cursors</p>');
    dbms_output.put_line('<p>and CURSOR_SHARING.</p><BR>');
    dbms_output.put_line('<p>cursor_sharing - The default value for cursor_sharing is EXACT; it should be changed to FORCE for better performance.</p>');
    dbms_output.put_line('<p>If the DB has both Demantra and ASCP on the same instance, it is recommended to keep cursor_sharing = EXCAT.  One of the reasons it is preferred to have separate installs.</p>');
    dbms_output.put_line('<p>Demantra system runs better when it has more memory in the Oracle Server Buffer Cache.  This change should decrease the number of physical I/O�s that are required</p>');
    dbms_output.put_line('<p>and hence results in better performance. Demantra recommends that at least 1 GB be dedicated to the buffer cache. This value is, of course, dependent on</p>');
    dbms_output.put_line('<p>the overall data volume. When using CTO, it is recommended to increase your SGA settings as well.</p><br>');
    dbms_output.put_line('<p>For more information see, Troubleshooting: Tuning the Shared Pool and Tuning Library Cache Latch Contention, Doc ID 62143.1.</p><br>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM ****************  FREELIST
REM **************************************************************************************** 

prompt <a name="adv505"></a><B><font size="+2">Freelist Performance Impact</font></B><BR><BR>

begin

select round((sum(decode(w.class,'free list',count,0))/
(sum(decode(name,'db block gets',value,0))
+ sum(decode(name,'consistent gets',value,0))))*100,2) into :ratio
from v$waitstat w, v$sysstat;

dbms_output.put_line('Free List Contention Performance Impact Gauge'||'<font size="+1"><b> Your impact is: </b>'||:ratio||'</font><BR><BR>');

if (:ratio < 20) THEN

    dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
    dbms_output.put('\&chxt=y');
    dbms_output.put('\&chs=500x250');
    dbms_output.put('\&cht=gm');
    dbms_output.put('\&chco=000000,05FA00|FF0000');
    dbms_output.put('\&chd=t:5');
    dbms_output.put('\&chl=Low" width="500" height="250" alt="" />');
    dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your Freelist contention is LOW performance impact.<BR> ');
    dbms_output.put_line('<p>For more information, see OPS/RAC: Using Free List Groups to reduce contention on free list descriptors, note 72384.1.</font><BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

  else if (:ratio between 21 and 40) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,05FA00|FF0000');
  dbms_output.put('\&chd=t:40');
  dbms_output.put('\&chl=Fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
 dbms_output.put_line('<p><font size="+1">In tablespaces with manual segment-space management, Oracle Database uses the FREELISTS storage parameter to improve performance of space management in</p><BR>');
    dbms_output.put_line('<p>OLTP systems by increasing the number of insert points in the segment. In tablespaces with automatic segment-space management, this parameter is ignored,</p><BR> ');
    dbms_output.put_line('<p>because the database adapts to varying workload.  If more processes are attempting to make inserts than there are free lists some processes will have to</p><BR> ');
    dbms_output.put_line('<p>wait for access to a free list.  Increasing the wait count and the performance impact.</p><br>');
    dbms_output.put_line('<p>For more information, see OPS/RAC: Using Free List Groups to reduce contention on free list descriptors, note 72384.1.</font><BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,05FA00|FF0000');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=HIGH" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">In tablespaces with manual segment-space management, Oracle Database uses the FREELISTS storage parameter to improve performance of space management in</p><BR> ');
    dbms_output.put_line('<p>OLTP systems by increasing the number of insert points in the segment. In tablespaces with automatic segment-space management, this parameter is ignored,</p><BR> ');
    dbms_output.put_line('<p>because the database adapts to varying workload.  If more processes are attempting to make inserts than there are free lists some processes will have to</p><BR> ');
    dbms_output.put_line('<p>wait for access to a free list.  Increasing the wait count and the performance impact.</p><br>;');
    dbms_output.put_line('<p>For more information, see OPS/RAC: Using Free List Groups to reduce contention on free list descriptors, note 72384.1.</font><BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *******************************************************************
REM *************  Library Cache Hit Ratio Percent  ********************
REM *******************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <p><a name="top"><b><font size="+2">Library Reload Ratio Percent</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> The proportion of requests for a lock on an object which were satisfied by finding that object's handle already in memory.<br>
prompt     If your reload ratio is greater than 90%-95% you most likely do not require any increase of the SHARED_POOL_SIZE parameter.<br>
prompt     The pin ratio, as found in the AWR report, is not as important as the reload ratio.  The reload ratio is directly related to specific SQL and PL/SQL blocks.  Shared pool reloads<br>
prompt     occur when Oracle has to implicitly reparse SQL or PL/SQL at the point when it attempts to execute it.  A larger shared pool wil reduce the number of times that code needs to be reloaded.<br>
prompt     Also, ensuring that similar pieces of SQL are written identically will increase sharing of code.<br><br>  
prompt     However, if your reload ratio is low, investigate the statistics 'parse time CPU', 'parse time elapsed' and to a lesser extent the "latch sleep" count from the library cache and<br>
prompt     shared pool latches.  If the amount of time in these two states is a high fraction of the total run time, you may want to investigate any objects that are not pinned in the shared pool<br>
prompt     but could be pinned.  Try pinning the objects, restart and continue monitoring.  If the reload rate still fails to diminish consider reviewing the size of the shared pool and possbily<br>
prompt     contacting Oracle Support.<br>
prompt     Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.</font></a><br><Br>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

prompt <a name="adv506"></a><B><font size="+2">Library Reload Ratio Percent</font></B><BR><BR>

begin

select round(((sum(reloads)/nvl(sum(pins),1))*100)*100, 2) into :ratio
from v$librarycache;

dbms_output.put_line('Library Reload Ratio Percent'||'<font size="+1"> <b>Your ratio is: </b>'||:ratio||'</font><BR><BR>');

if (:ratio >= 89) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:90');
  dbms_output.put('\&chl=GOOD" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 90 percent.</font><BR> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance is not impacted with your current ratio.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

  else if (:ratio between 65 and 89) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:75');
  dbms_output.put('\&chl=fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 95 percent.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:30');
  dbms_output.put('\&chl=Critical" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your cache hit percent is not good.  There is a performance impact.  Please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1</font><BR><BR> ');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************
REM ******* Library Cache Greater Details *******
REM *********************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Is the shared pool the hot object or performance constraint?</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> Report column definition.  This will help to interpret the contents of the V$LIBRARYCACHE view and the possible impact to the shared pool:<br><br>
prompt     namespace - is the object type.  The values SQL AREA, TABLE/PROCEDURE, BODY, and TRIGGER<br>
prompt     pins - times the item in the library cache was executed<br>
prompt     pinhits - total executions when the specific item was present in the library cache<br>
prompt     pinhitratio - ratio of pinhits to pins<br>
prompt     reloads - the number of times the code had to be reloaded into the library cache due to aging or invalidation<br><br>
prompt     The pin_ratio should be close to 100 percent.  This indicates the data required to process the request is already allocated and valid in the library cache.<br>
prompt     Keep in mind that it may not be possible to achieve and maintain 100%.  It is best to achieve a hit ratio of greater than 95 percent.  At startup, you most likely will not<br>
prompt     achieve your desired ratio.  However, if your reload ratio is low, investigate the statistics 'parse time CPU', 'parse time elapsed' and to a lesser extent the "latch sleep"<BR>
prompt     count from the library cache and shared pool latches.  If the amount of time in these two statistics is a high fraction of the total time, you may want to investigate any objects<BR>
prompt     that are not pinned in the shared pool but could be pinned, pinning the objects and continue monitoring.  If the reload rate still fails to diminish consider reviewing the size of<BR>
prompt     the shared pool and possbily contacting Oracle Support.<br>
prompt     See Troubleshooting: Tuning the Shared Pool and Tuning Library Cache Latch Contention (Doc ID 62143.1)</font></a><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql500(){var row = document.getElementById("s1sql500");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv507"></a>
prompt     <a name="top"><b><font size="+2"> Library Cache Constraint Activity and Shared Pool </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql500()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql500" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt       select namespace,<BR>
prompt       pins,<BR>
prompt       pinhits,<BR>
prompt       round(pinhitratio*100,2),<BR>
prompt       reloads,<BR>
prompt       reloads / decode(pins, 0, 1, pins)<BR>
prompt       from v$librarycache</p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Object_NameExt_Manage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pins</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pinhits</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pin_Ratio</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Reloads</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Reload_Ratio</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||namespace||'</TD>'||chr(10)||
'<TD>'||pins||'</TD>'||chr(10)||
'<TD>'||pinhits||'</TD>'||chr(10)||
'<TD>'||round(pinhitratio*100,2)||'</TD>'||chr(10)||
'<TD>'||reloads||'</TD>'||chr(10)||
'<TD>'||round((reloads / decode(pins, 0, 1, pins)) * 100,2)||'</TD></TR>'
from v$librarycache;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM *********************************************
REM ******* I/O Data Files Disbursement    *******
REM *********************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Data File I/O Load Disbursement</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> This report reveals the constraint placed on datafiles.  Should you see IO per data file that is unbalanced,
prompt     it is strongly advised that an investigation is conducted, discovering the segments in the datafile.  It is advised that the load be balanced across many
prompt     datafiles.  Perhaps you have too many active tablespaces in the datafile.<br>
prompt     Troubleshooting I/O Related Waits (Doc ID 223117.1)</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript"> function displayRows1sql501(){var row = document.getElementById("s1sql501");if (row.style.display == '') row.style.display = 'none';else row.style.display = ''; }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv508"></a>
prompt     <a name="top"><b><font size="+2"> Datafile Activity Constraints </font></B></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql501()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql501" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt       SELECT NAME,<BR>
prompt       PHYRDS,<BR>
Prompt       ROUND ((RATIO_TO_REPORT (PHYRDS) OVER ()) * 100, 2),<BR>
prompt       PHYWRTS,<BR>
prompt       ROUND ((RATIO_TO_REPORT (PHYWRTS) OVER ()) * 100, 2)<BR>
prompt       (nvl(PHYRDS,0) + nvl(PHYWRTS,0))<BR>
prompt       FROM V$DATAFILE F, V$FILESTAT S<BR>
prompt       WHERE F.FILE# = S.FILE#<BR>
prompt       and rownum < 20<BR>
prompt       ORDER BY PHYRDS DESC<BR></p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DBF_Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phys_Reads</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Reads</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phys_Writes</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Writes</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Reads_Writes</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||name||'</TD>'||chr(10)||
'<TD>'||phyrds||'</TD>'||chr(10)||
'<TD>'||ROUND ((RATIO_TO_REPORT (PHYRDS) OVER ()) * 100, 2)||'</TD>'||chr(10)||
'<TD>'||phywrts||'</TD>'||chr(10)||
'<TD>'||ROUND ((RATIO_TO_REPORT (PHYWRTS) OVER ()) * 100, 2)||'</TD>'||chr(10)||
'<TD>'||(nvl(PHYRDS,0) + nvl(PHYWRTS,0))||'</TD></TR>'
FROM V$DATAFILE DF, V$FILESTAT FS
WHERE DF.FILE# = FS.FILE#
and rownum < 20
ORDER BY PHYRDS DESC;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ***************************************************************
REM ******* IO Disbursement Across Datafiles for Tablespace *******
REM ***************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">IO Disbursement Across Datafiles for Tablespace</font></b></a></p><br>
prompt     <a name="top"><font size="+1">Drilling further into the datafile, revealing the tablespaces. Do you have data tables and indexes in the same tablespace?
prompt     Do you have large active segments in the same tablespace?  Do you have several active tablespaces within the out of balance datafile?  Oracle recommends separation
prompt     of active segments into multiple tablespaces.  Active tablespaces in individual datafiels.<br>
prompt     See Troubleshooting I/O Related Waits (Doc ID 223117.1)</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql502(){var row = document.getElementById("s1sql502");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv509"></a>
prompt     <a name="top"><b><font size="+2"> IO Disbursement Across Datafiles for Tablespace </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql502()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql501" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt       SELECT vts.name,<BR> 
prompt         DF.NAME,<BR>
prompt         PHYRDS,<BR>
prompt         ROUND ( (RATIO_TO_REPORT (PHYRDS) OVER ()) * 100, 2),<BR>
prompt         PHYWRTS, <BR>
prompt         ROUND ( (RATIO_TO_REPORT (PHYWRTS) OVER ()) * 100, 2),<BR>
prompt         (nvl(PHYRDS,0) + nvl(PHYWRTS,0))
prompt    FROM V$DATAFILE DF, V$FILESTAT FS, v$tablespace VTS
prompt   WHERE DF.FILE# = FS.FILE# 
prompt   AND DF.TS# = VTS.TS#
prompt       ORDER BY vts.name, PHYRDS DESC;</p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Tablespace_Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Data_File_Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Reads</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Read_Ratio</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Writes</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Write_ratio</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||vts.name||'</TD>'||chr(10)||
'<TD>'||df.name||'</TD>'||chr(10)||
'<TD>'||phyrds||'</TD>'||chr(10)||
'<TD>'||ROUND ( (RATIO_TO_REPORT (PHYRDS) OVER ()) * 100, 2)||'</TD>'||chr(10)||
'<TD>'||phywrts||'</TD>'||chr(10)||
'<TD>'||ROUND ( (RATIO_TO_REPORT (PHYWRTS) OVER ()) * 100, 2)||'</TD>'||chr(10)||
'<TD>'||(nvl(PHYRDS,0) + nvl(PHYWRTS,0))||'</TD></TR>'
FROM V$DATAFILE DF, V$FILESTAT FS, v$tablespace VTS
WHERE DF.FILE# = FS.FILE# 
AND DF.TS# = VTS.TS#
and rownum < 50
ORDER BY PHYRDS DESC;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* System Events *******************************
REM *********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">System Wait Events</font></b></a></p><br>
prompt <a name="top"><font size="+1">Oracle event wait analysis is an educated process when performing system tuning.  The v$system_event view is important.  We are looking at system events that are happening within your system.<br>
prompt  High waits on system events can point to disk I/O bottlenecks, network bottlenecks and environment bottlenecks.<br>
prompt  Below, we have eliminated the most commone idle wait events and include those waits that have average wait > 10 seconds.<br>
prompt  This report will give you insight into the causes of wait event impact.<br>
prompt  This is a good place to begin your investigation as to why the wait event is on this report.   Perhaps it is a critical clue to your performance improvement solution.<br>
prompt  See: Using the AWR to Analyze Demantra Performance (Doc ID 1450237.1)</font></a><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql503(){var row = document.getElementById("s1sql503");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv510"></a>
prompt     <a name="top"><b><font size="+2"> System Events</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql503()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql503" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt       SELECT event,<BR>
prompt       total_waits,<BR>
prompt       round(time_waited / 100, 0),<BR>
prompt       total_timeouts,<BR>
prompt       average_wait / 100<BR>
prompt       from sys.v_$system_event<BR>
prompt       where event not in <BR>
prompt    ('dispatcher timer',<BR>
prompt    'lock element cleanup',<BR>
prompt    'Null event',<BR>
prompt    'parallel query dequeue wait',<BR>
prompt    'parallel query idle wait - Slaves',<BR>
prompt    'pipe get',<BR>
prompt    'PL/SQL lock timer',<BR>
prompt    'pmon timer',<BR>
prompt    'rdbms ipc message',<BR>
prompt    'slave wait',<BR>
prompt    'smon timer',<BR>
prompt    'SQL*Net break/reset to client',<BR>
prompt    'SQL*Net message from client',<BR>
prompt    'SQL*Net message to client',<BR>
prompt    'SQL*Net more data to client',<BR>
prompt    'virtual circuit status',<BR>
prompt    'WMON goes to sleep')<BR>
prompt    and average_wait > 10<BR>
prompt    AND event not like 'DFS%'<BR>
prompt    and event not like '%done%'<BR>
prompt    and event not like '%Idle%'<BR>
prompt    AND event not like 'KXFX%'<BR>
prompt    order by 2 desc;<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Event</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Waits</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Seconds_Waited</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Timeouts</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Time_Waited</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Average_Wait_Seconds</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(event,1,50)||'</TD>'||chr(10)||
'<TD>'||total_waits||'</TD>'||chr(10)|| 
'<TD>'||round(time_waited / 100, 0)||'</TD>'||chr(10)||
'<TD>'||total_timeouts||'</TD>'||chr(10)|| 
'<TD>'||time_waited||'</TD>'||chr(10)||
'<TD>'||average_wait / 100||'</TD><TR>'
FROM v$system_event
where event not in
    ('dispatcher timer',
    'lock element cleanup',
    'Null event',
    'parallel query dequeue wait',
    'parallel query idle wait - Slaves',
    'pipe get',
    'PL/SQL lock timer',
    'pmon timer',
    'rdbms ipc message',
    'slave wait',
    'smon timer',
    'SQL*Net break/reset to client',
    'SQL*Net message from client',
    'SQL*Net message to client',
    'SQL*Net more data to client',
    'virtual circuit status',
    'WMON goes to sleep')
and average_wait > 10
AND event not like 'DFS%'
and event not like '%done%'
and event not like '%Idle%'
AND event not like 'KXFX%'
order by total_waits desc;

prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* Network V$System_Event Wait Events **************
REM *********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Network V$System_Event</font></b></a></p><br>
prompt <a name="top"><font size="+1">This report will give you an overview of your network waits.  By themselves, they may mean very little.  However, when reviewing your overall.<br>
prompt  system performance, these become part of your collected performance landscape.  Additional investigation will most likely be required to discover a bottleneck.<br><br>
prompt  For the next two data points, see the following notes:<br>
prompt  WAITEVENT: "SQL*Net message from client" Reference Note (Doc ID 34395.1)<br>
prompt  WAITEVENT: "SQL*Net message to client" Reference Note (Doc ID 34397.1)<br>
prompt  WAITEVENT: "SQL*Net message to dblink" Reference Note (Doc ID 34398.1)</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql504(){var row = document.getElementById("s1sql504");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv511"></a>
prompt     <a name="top"><b><font size="+2">Network Wait Events</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql504()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql504" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt       SELECT event,<BR>
prompt       total_waits,<BR>
prompt       round(time_waited / 100, 0),<BR>
prompt       total_timeouts,<BR>
prompt       average_wait / 100<BR>
prompt       from sys.v_$system_event<BR>
prompt       where event in ('SQL*Net break/reset to client','SQL*Net message from client', 'SQL*Net message to client', 'SQL*Net more data to client)
prompt       and event not like '%done%'
prompt       and event not like '%idle%'
prompt       order by 2 desc;<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Event</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Waits</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Seconds_Waited</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Timeouts</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Average_Wait_Seconds</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(event,1,30)||'</TD>'||chr(10)||
'<TD>'||total_waits||'</TD>'||chr(10)|| 
'<TD>'||round((time_waited / 100), 0)||'</TD>'||chr(10)||
'<TD>'||total_timeouts||'</TD>'||chr(10)|| 
'<TD>'||average_wait / 100||'</TD><TR>'
FROM v$system_event
where event in ('SQL*Net break/reset to client','SQL*Net message from client', 'SQL*Net message to client', 'SQL*Net more data to client')
and event not like '%done%'
and event not like '%Idle%'
order by total_waits desc;

prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* Network Wait Class Events **************
REM *********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Network V$System_Wait_Class Summary</font></b></a></p><br>
prompt <a name="top"><font size="+1">This report selects the network performance statistics from V$system_wait_class.  This is a good place to start if you suspect that there may be 
prompt and bottleneck issue in your network.  We eliminate the idle wait_class.</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql505(){var row = document.getElementById("s1sql505");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv512"></a>
prompt     <a name="top"><b><font size="+2">Network Wait Class Summary</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql505()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql505" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt       SELECT wait_class,<BR>
prompt       total_waits,<BR>
prompt       ROUND(100 * (total_waits / decode(sum_waits,0,1,sum_waits)),2),<BR>
prompt       time_waited,<BR>
prompt       ROUND(100 * (time_waited / decode(sum_time,0,1,sum_time)),2)<BR>
prompt       FROM (SELECT wait_class,<BR>
prompt       total_waits,<BR>
prompt       time_waited<BR>
prompt       FROM v$system_wait_class<BR>
prompt       WHERE wait_class = 'Network'<BR>
prompt       and wait_class != 'Idle'),<BR>
prompt       (SELECT SUM(total_waits) sum_waits,<BR>
prompt       SUM(time_waited) sum_time<BR>
prompt       FROM v$system_wait_class<BR>
prompt       WHERE wait_class != 'Idle')<BR>
prompt       ORDER BY 5 DESC<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Wait_Class</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Waits</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pct_Total_Waits</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Time_waited</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pct_Wait_Time</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(wait_class,1,30)||'</TD>'||chr(10)||
'<TD>'||total_waits||'</TD>'||chr(10)|| 
'<TD>'||ROUND(100 * (total_waits / decode(sum_waits,0,1,sum_waits)),2)||'</TD>'||chr(10)||
'<TD>'||time_waited||'</TD>'||chr(10)|| 
'<TD>'||ROUND(100 * (time_waited / decode(sum_time,0,1,sum_time)),2)||'</TD><TR>'
FROM (SELECT wait_class,
             total_waits,
             time_waited
      FROM v$system_wait_class
      WHERE wait_class = 'Network'
      and wait_class != 'Idle'),
(SELECT SUM(total_waits) sum_waits,
SUM(time_waited) sum_time
FROM v$system_wait_class
WHERE wait_class != 'Idle')
ORDER BY total_waits DESC;

prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM **************************************************************************************** 
REM *******                   Section 2 : ASCP Entity Data Volume                    *******
REM ****************************************************************************************
REM 
REM prompt <a name="section2"></a><B><font size="+2">ASCP Entity Size in MB and Percent Fragmentation </font></B><BR><BR>
REM 
REM
REM ******* Verify Entity Size in MB and Percent Fragmentation  *******
REM

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Database Object Fragmentation > 50% </font></b></a></p><br>
prompt <a name="top"><font size="+1">This report will give you a list of tables where the fragmentation is > 50%.  These objects should be rebuilt to reduce the fragmentation thus<br>
prompt  improving performance</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql506(){var row = document.getElementById("s1sql506");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv513"></a>
prompt     <a name="top"><b><font size="+2">Database Object Fragmentation</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql506()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql506" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt       select substr(table_name,1,30),
prompt       round((blocks*8),2) "size (kb)" , <BR>
prompt       round((num_rows*avg_row_len/1024),2) "actual_data (kb)",<BR>
prompt       (round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) "wasted_space (kb)",<BR>
prompt       round(((round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) / round((blocks*8),2)) * 100, 2) pct<BR>
prompt       from dba_tables<BR>
prompt       where (round((blocks*8),2) > round((num_rows*avg_row_len/1024),2))<BR>
prompt       and ((round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) / round((blocks*8),2)) * 100 > 50<BR>
prompt       order by 4 desc<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table_Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Size_KB</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Actual_Data_KB</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Wasted_KB</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Fragmentation_Percent</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(table_name,1,30)||'</TD>'||chr(10)||
'<TD>'||round((blocks*8),2)||'</TD>'||chr(10)|| 
'<TD>'||round((num_rows*avg_row_len/1024),2)||'</TD>'||chr(10)||
'<TD>'||(round((blocks*8),2) - round((num_rows*avg_row_len/1024),2))||'</TD>'||chr(10)|| 
'<TD>'||round(((round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) / round((blocks*8),2)) * 100, 2)||'</TD><TR>'
from dba_tables
where owner = :gv_schema 
and (round((blocks*8),2) > round((num_rows*avg_row_len/1024),2))
and ((round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) / round((blocks*8),2)) * 100 > 80
and rownum < 50
order by (round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) desc;
prompt </table><br>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* Segments Where Free Space <= Next Extent  *******
REM *********************************************************

prompt <a name="section2"></a><B><font size="+2">Value Chain Planning Segments Where Next Size is Larger Than Free Space Available Summary</font></B><BR>
prompt <a name="section2.1"></a><font size="+1">Not applicable to LMT (Locally Managed Tablespaces)<br><br>
prompt For additional information see the followionig myoraclesupport notes:<br>
prompt Reclaiming unused space in an E-Business Suite Instance tablespace (Doc ID 303709.1) or<br>
prompt How To Reclaim Wasted Space on The Segment (Table, Index and LOB) and Tablespace Levels (Doc ID 1682748.1)</font></a>BR><BR>

prompt <script type="text/javascript">    function displayRows1sql507(){var row = document.getElementById("s1sql507");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv514"></a>
prompt     <a name="top"><b><font size="+2"> Segments Where Free Space <= Next Extent </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql507()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql507" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt          select substr(a.owner,1,12),<BR>
prompt          segment_type,<BR>
prompt          count(2) AS "Number of Segments"<BR>
prompt          from dba_segments a<BR>
prompt          where a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)<BR>
prompt          OR a.EXTENTS = a.MAX_EXTENTS<BR>
prompt          group by owner, segment_type<BR></p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR id="s2sql51" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="right">
prompt          select substr(a.tablespace_name,1,30) "TName",<BR>
prompt          substr(a.owner,1,12) "Owner",<BR>
prompt          substr(a.segment_name,1,30) "SegName",<BR>
prompt          a.next_extent "NextExt",<BR>
prompt          a.segment_type "SegType" <BR>
prompt          from dba_segments a<BR>
prompt          where a.owner = 'MSC' 
prompt          and a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)<BR>
prompt          OR a.EXTENTS = a.MAX_EXTENTS<BR>
prompt          order by a.next_extent;</p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Owner</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Segment Type</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(a.owner,1,12)||'</TD>'||chr(10)||
'<TD>'||a.segment_type||'</TD>'||chr(10)||
'<TD>'||count(2)||' '||'</TD></TR>'
from dba_segments a
where a.owner = :gv_schema 
and a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)
OR a.EXTENTS = a.MAX_EXTENTS
group by owner, segment_type;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ******************************
REM ******* cluster factor *******
REM ******************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Cluster Factor > 50% and Related Data Points</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> The lower the CF, closer to the number of blocks in the table vs the number of rows, the more efficient it is to use the index as<br>
prompt     less table blocks would need to be accessed to retrieve the necessary data via the chosen index.<br><br>
prompt     So far so good.  However, what if part of the incoming row is stored in block one and the remainder in block 2?  When the row is <br>
prompt     required, block 1 and block 2 will be read into cache resulting in near zero waiting for the entire row.  OK, fast forward, what if<br>
prompt     the table has 100m rows and imagine that this situation occurs 30% of the time.  Your current CF method is most likely skewed<br>
prompt     and incorrect.<br><br>
prompt     Now for the good news, bug 13262857 - INDEX CLUSTERING FACTOR COMPUTATION IS PESSIMISTIC.  The computation of the index clustering<br>
prompt     factor in dbms_stats package is pessimistic about the caching ratio of the table blocks.  It assumes that at most one block from the<br>
prompt     table is cached. <br><br>
prompt     This is an enhancement to allow a user to specify the number of blocks that dbms_stats package will consider when gathering the index clustering <br>
prompt     factor statistics. Prior to this enhancement dbms_stats assumed 1 and it still does after the enhancement.  This enhancement allows the user to <br>
prompt     specify a value between 1 and 255.  There is also an AUTO option which if specified then dbms_stats will use 1% of the table blocks up to <br>
prompt     0.1% of the buffer cache size, in blocks.  <br><br>
prompt     The new CF approach is currently available with patches that can be applied on both Exadata databases and Oracle versions 11.1.0.7, 11.2.0.2 and 11.2.0.3.<br>
prompt     The Patch ID is 15830250.<br><br>
prompt     Regarding the table below.  Is your cluster factor closer to the number of blocks (good) or the number of rows (not as good)?<br><Br>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

prompt <a name="section2"></a><B><font size="+2">Cluster Factor Index - Table Health</font></B><BR>

prompt <script type="text/javascript">    function displayRows1sql508(){var row = document.getElementById("s1sql508");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv515"></a>
prompt     <a name="top"><b><font size="+2"> Cluster Factor > 50% Rows vs Blocks and Related Storage Facts</font></B></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql508()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql508" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt        select substr(a.table_name,1,10),<br>
prompt        substr(index_name,1,30),<br>
prompt        blevel,<br>
prompt        leaf_blocks,<br>
prompt        distinct_keys,<br>
prompt        AVG_LEAF_BLOCKS_PER_KEY,<br>
prompt        AVG_DATA_BLOCKS_PER_KEY,<br>
prompt        b.sample_size,<br>
prompt        b.last_analyzed,<br>
prompt        CLUSTERING_FACTOR,<br>
prompt        blocks,<br>
prompt        b.NUM_ROWS<br>
prompt        from all_indexes a, all_tables b<br>
prompt        where a.table_name in ('MDP_MATRIX', 'SALES_DATA')<br>
prompt        and b.table_name = a.table_name<br>
prompt        and table_owner = 'MSDEM'<br>
prompt        order by 1, 2; </p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Index Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>blevel</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>leaf_blocks</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Distinct Keys</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>AVG Leaf Blks</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Avg Data Blks</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Sample Size</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Analyzed</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Cluster Factor</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Blocks</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Nbr Rows</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(a.table_name,1,10)||'</TD>'||chr(10)||
'<TD>'||substr(index_name,1,30)||'</TD>'||chr(10)||
'<TD>'||blevel||'</TD>'||chr(10)||
'<TD>'||leaf_blocks||'</TD>'||chr(10)||
'<TD>'||distinct_keys||'</TD>'||chr(10)||
'<TD>'||AVG_LEAF_BLOCKS_PER_KEY||'</TD>'||chr(10)||
'<TD>'||AVG_DATA_BLOCKS_PER_KEY||'</TD>'||chr(10)||
'<TD>'||b.sample_size||'</TD>'||chr(10)||
'<TD>'||b.last_analyzed||'</TD>'||chr(10)||
'<TD>'||clustering_factor||'</TD>'||chr(10)||
'<TD>'||Blocks||'</TD>'||chr(10)||
'<TD>'||b.num_rows||'</TD></TR>'
from all_indexes a, all_tables b
where a.table_name in ('MDP_MATRIX', 'SALES_DATA')
and blocks / decode(b.num_rows,0,1,b.num_rows) > 50
and b.table_name = a.table_name
and table_owner = :gv_schema
order by a.table_name, index_name; 


prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ******************************************************************
REM **************   Space used
REM ******************************************************************

prompt <a name="section2"></a><B><font size="+2">Value Chain Planning Freespace by Tablespace in GB</font></B><BR>
prompt <a name="section2.1"></a><font size="+1">Reports ASSM or manually managed segments.</font><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql509(){var row = document.getElementById("s1sql509");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv516"></a>
prompt     <a name="top"><b><font size="+2"> Free Space by Tablespace </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql509()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql509" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt        select extent_management Ext_Manage,<BR>
prompt         allocation_type Alloc_Type,<BR>
prompt         segment_space_management SPC_Manage,<BR>
prompt         substr(c.tablespace_name,1,25),<BR>
prompt        GB_alloc Gbytes, <BR>
prompt        GB_alloc-nvl(GB_free,0) used,<BR>
prompt        nvl(GB_free,0) free, <BR>
prompt        round(((GB_alloc-nvl(GB_free,0))/ GB_alloc)*100, 2) pct_used,<BR>
prompt        nvl(largest_GB,0) largest,<BR>
prompt        nvl(GB_max, GB_alloc) Max_Size,<BR>
prompt        from (select round(sum(bytes)/1024/1024,2) GB_free, <BR>
prompt         round(max(bytes)/1024/1024,2) largest_GB,<BR>
prompt         tablespace_name<BR>
prompt         from  sys.dba_free_space<BR> 
prompt         group by tablespace_name ) a,<BR>
prompt        ( select round(sum(bytes)/1024/1024,2) GB_alloc,<BR> 
prompt            round(sum(maxbytes)/1024/1024,2) GB_max,<BR>
prompt            tablespace_name <BR>
prompt            from sys.dba_data_files<BR> 
prompt            group by tablespace_name <BR>
prompt            union all<BR>
prompt            select round(sum(bytes)/1024/1024,2) GB_alloc,<BR> 
prompt            round(sum(maxbytes)/1024/1024,2) BB_max,<BR>
prompt            tablespace_name <BR>
prompt            from sys.dba_temp_files<BR> 
prompt            group by tablespace_name ) b,<BR>
prompt            dba_tablespaces c<BR>
prompt        where a.tablespace_name (+) = b.tablespace_name<BR>
prompt        and c.tablespace_name = b.tablespace_name<BR>
prompt        order by 1; </p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Ext_Manage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Alloc_Type</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SPC_Manage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Gbytes</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Used</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Free</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Used</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Largest</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Max_Size</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||extent_management||'</TD>'||chr(10)||
'<TD>'||allocation_type||'</TD>'||chr(10)||
'<TD>'||segment_space_management||'</TD>'||chr(10)||
'<TD>'||substr(c.tablespace_name,1,25)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_alloc,0)||'</TD>'||chr(10)||
'<TD>'||round((nvl(GB_alloc,0) - nvl(GB_free,0)),2)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_free,0)||'</TD>'||chr(10)||
'<TD>'||round(((nvl(GB_alloc,0) - nvl(GB_free,0))/ nvl(GB_alloc,0))*100, 2)||'</TD>'||chr(10)||
'<TD>'||nvl(largest_GB,0)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_max, nvl(GB_alloc,0))||'</TD></TR>'
from ( select tablespace_name,
nvl(round(sum(bytes)/1024/1024,2),0) GB_Free,
nvl(round(max(bytes)/1024/1024,2),0) Largest_GB
from  sys.dba_free_space
group by tablespace_name ) a,
( select tablespace_name,
  nvl(round(sum(bytes)/1024/1024,2),0) GB_alloc,
  nvl(round(sum(maxbytes)/1024/1024,2),0) GB_max
  from sys.dba_data_files
  group by tablespace_name
  union all
  select tablespace_name,
  nvl(round(sum(bytes)/1024/1024,2),0) GB_alloc,
  nvl(round(sum(maxbytes)/1024/1024,2),0) GB_max
  from sys.dba_temp_files
  group by tablespace_name )b,
  dba_tablespaces c
where a.tablespace_name (+) = b.tablespace_name
and c.tablespace_name = b.tablespace_name
order by 1;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* All Wait Statistics ***************************
REM *********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Wait Statistics</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> WAIT STATISTIC:<br><br>
prompt     Class - Class of block affected by contention<br>
prompt     Count - Number of waits by class of block<br>
prompt     Time - Sum of all wait times for class/block<BR>
prompt     Data Blocks - Possibly too many modified blocks in the buffer cache.  Investigate adding DBWR processes.<br>
prompt     Free List - If there are parallel loading programs.  Review the freelist performance guage above.<br>
prompt     Segment Header - There may be if full table scans are contending with a data loading processes.  Parallel options can add to the wait.<br>
prompt     Sort Block - Parallel Query option.  Reducing the degree of parallelism or decreasing the SORT_AREA_SIZE init.ora parameter setting may have a positive impact.<br>
prompt     Undo Block - Multiple users updating records in the same data block at a very fast rate. Investigate freelist and increasing the PCTFREE of the tables involved.<br>
prompt     Undo Header - You may not have enough rollback segments to support the number of concurrent transactions.  Produce an AWR report and investigate further.<br><br>
prompt     See: Troubleshooting I/O Related Waits (Doc ID 223117.1)<br>
prompt          High temporary usage by queries against dictionary tables with wait 'direct path write temp' (Doc ID 1591156.1)</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql510(){var row = document.getElementById("s1sql510");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv517"></a>
prompt     <a name="top"><b><font size="+2"> Wait Statistics</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql510()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql510" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt      Select class,<BR>
prompt      count,<BR>
prompt      time<BR>
prompt      from v$waitstat<BR>
prompt      order by class<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Class</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Time</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||class||'</TD>'||chr(10)||
'<TD>'||count||'</TD>'||chr(10)|| 
'<TD>'||time||'</TD><TR>' 
FROM v$waitstat
order by class;

prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM
REM ******* System Statistics *******
REM

prompt <script type="text/javascript">    function displayRows1sql511(){var row = document.getElementById("s1sql511");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv518"></a>
prompt      <a name="top"><b><font size="+2"> System Statistics </font></B></a><br>
prompt      <a name="top"><font size="+1">Oracle recommends that you gather system statistics during peak load in order to give the optimizer the ability to choose the best plan based on<br>
prompt         system resource usage and throughput as well as the normal information about the database objects.<br>
prompt         System statistics are gathered to allow the optimizer to consider a system's I/O and CPU performance and utilization.<br><br>
prompt         They allow the optimizer to adjust access paths to allow for the actual performance of a particular system by recording actual system statistics.<br>
prompt         The statistics are collected using the DBMS_STATS.GATHER_SYSTEM_STATS procedure and are stored in SYS.AUX_STATS$.<br>
prompt         Do SREADTIM and MREADTIM have a value?  If not, run  DBMS_STATS.GATHER_SYSTEM_STATS<br><br>
prompt         Note: When new system statistics are gathered, unlike table, index or column statistics, Oracle does not invalidate existing parsed SQL statements <br>
prompt         which are already in the shared pool.  Only newly executed SQL statements will use the new system statistics.  You could run ALTER SYSTEM FLUSH shared_pool<br>
prompt         in order to make sure all new SQL statements are hard parsed and use the new system statistics, but this is probably not a good thing to do on a production <br>
prompt         system during times of high load.<br><br>
prompt         See: How to Collect and Display System Statistics (CPU and IO) for CBO use (Doc ID 149560.1)<br>
prompt              Statistics Gathering: Frequency and Strategy Guidelines (Doc ID 44961.1)</font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql511()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql511" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="2" height="185">
prompt       <blockquote><p align="left">
prompt       select pname, pval1 from sys.aux_stats$ where sname = 'SYSSTATS_MAIN';<br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param NAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(60);
v_val1 varchar2(60);

Begin

stmt_str:= 'select pname, pval1 from sys.aux_stats$ where sname = ''SYSSTATS_MAIN''';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname, v_val1;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val1, (null))||'</TD>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>









REM *************************************************************************
REM ******* Report Chained Row Count *******
REM where chain_cnt >0 and num_rows > 0
REM *************************************************************************

prompt <script type="text/javascript">    function displayRows1sql512(){var row = document.getElementById("s1sql512");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv165"></a>
prompt     <a name="top"><b><font size="+2"> Chained Row count </font></B></a></TD>
prompt     <a name="top"><b><font size="+1"> See: Row Chaining and Row Migration (Doc ID 122020.1)<br>
prompt      How to Identify, Avoid and Eliminate Chained and Migrated Rows ? (Doc ID 746778.1)</font></a><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql512()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql512" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="9" height="185">
prompt       <blockquote><p align="left">
prompt       select <br>
prompt       table_name,<br> 
prompt       pct_free, <br>
prompt       pct_used, <br>
prompt       avg_row_len, <br>
prompt       num_rows, <br>
prompt       chain_cnt,<br>
prompt       chain_cnt/decode(num_rows,0,1,num_rows) <br>
prompt       from dba_tables<br>
prompt       where owner = schema_owner <br>
prompt       and chain_cnt > 0 <br>
prompt       order by chain_cnt desc <br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Free</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Used</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>AVG_Row_Length</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Num_Rows</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Chain_CNT</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Chain_PCT</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||table_name||'</TD>'||chr(10)||
'<TD>'||pct_free||'</TD>'||chr(10)||
'<TD>'||pct_used||'</TD>'||chr(10)||
'<TD>'||avg_row_len||'</TD>'||chr(10)||
'<TD>'||num_rows||'</TD>'||chr(10)||
'<TD>'||chain_cnt||'</TD>'||chr(10)||
'<TD>'||chain_cnt/decode(num_rows,0,1,num_rows)||'</TD></TR>'
from dba_tables
where owner = :gv_schema
and chain_cnt > 0
order by chain_cnt desc;

prompt </TABLE>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM
REM ******* partitions *******
REM
REM Statistics on partitions, are you using incremental statistics?
REM Are there objects >5m rows?


prompt </HTML>
spool off
set heading on
set feedback on  
set verify on
exit
;


