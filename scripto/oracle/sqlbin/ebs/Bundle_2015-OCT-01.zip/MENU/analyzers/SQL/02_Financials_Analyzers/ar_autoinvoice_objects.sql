set serveroutput on size 1000000

REM +=======================================================================+
REM |    Copyright (c) 2011 Oracle Corporation, Redwood Shores, CA, USA     |
REM |                         All rights reserved.                          |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |  ar_autoinvoice_objects.sql                                           |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM |   Script to create the view                                           |
REM |                                                                       |
REM | HISTORY                                                               |
REM |   22-Feb-2013 VERAO Created draft version                             |
REM +=======================================================================+
-- $Id: ar_autoinvoice_objects.sql,v 200.1 2015/08/31 23:22:14 vcrisost Exp $ 

declare
   araipostpr     NUMBER := 0;
   rows_processed INTEGER;
   stmt           VARCHAR2(4000);
   c              INTEGER;
begin

   -- drop OLD objects
   --------------------------------------------------------------------------------------------------------------------------------------------
   select count(*) 
   into araipostpr
   from all_objects
   where object_name = 'RA_INTF_PP_CONFIG_V2_1';
   
   if araipostpr = 1 then
     c := dbms_sql.open_cursor;
     
     stmt := 'drop table RA_INTF_PP_CONFIG_V2_1';
     dbms_sql.parse(c, stmt, dbms_sql.native);
     rows_processed := dbms_sql.execute(c);
     dbms_sql.close_cursor(c);
   end if;
   
   select count(*) 
   into araipostpr
   from all_objects
   where object_name = 'RA_INTERFACE_POSTPROC_CONFIG';
   
   if araipostpr = 1 then
     c := dbms_sql.open_cursor;
     
     stmt := 'drop table RA_INTERFACE_POSTPROC_CONFIG';
     dbms_sql.parse(c, stmt, dbms_sql.native);
     rows_processed := dbms_sql.execute(c);
     dbms_sql.close_cursor(c);
     
     update fnd_concurrent_programs set enabled_flag = 'N' where concurrent_program_name = 'ARAIPOSTPR';
     
   end if;
   
   select count(*) 
   into araipostpr
   from all_objects
   where object_name = 'RA_INTERFACE_PP_PATCHES';
   
   if araipostpr = 1 then
     c := dbms_sql.open_cursor;
     
     stmt := 'drop table RA_INTERFACE_PP_PATCHES';
     dbms_sql.parse(c, stmt, dbms_sql.native);
     rows_processed := dbms_sql.execute(c);
     dbms_sql.close_cursor(c);
   end if;
   
   select count(*) 
   into araipostpr
   from all_objects
   where object_name = 'RA_INTF_POSTPROC_ORGID_V';
   
   if araipostpr = 1 then
     c := dbms_sql.open_cursor;
     
     stmt := 'drop view RA_INTF_POSTPROC_ORGID_V';
     dbms_sql.parse(c, stmt, dbms_sql.native);
     rows_processed := dbms_sql.execute(c);
     dbms_sql.close_cursor(c);
   end if;
   
   c := dbms_sql.open_cursor;
     
   -- create new view
   stmt := 'CREATE OR REPLACE VIEW ar_autoinvoice_orgid_v AS
    SELECT DISTINCT il.org_id, hr.name
    FROM hr_operating_units hr,
      ra_interface_lines_all il
    WHERE il.org_id = hr.organization_id
      AND il.interface_line_id IS NOT NULL
    UNION
    SELECT DISTINCT il.org_id, hr.name
    FROM hr_operating_units hr,
      ra_interface_errors_all il
    WHERE il.org_id = hr.organization_id
    UNION
    SELECT DISTINCT il.org_id, hr.name
    FROM hr_operating_units hr,
      ra_interface_salescredits_all il
    WHERE il.org_id = hr.organization_id
      AND il.interface_salescredit_id IS NOT NULL
    UNION
    SELECT DISTINCT il.org_id, hr.name
    FROM hr_operating_units hr,
      ra_interface_distributions_all il
    WHERE il.org_id = hr.organization_id 
      AND il.interface_distribution_id IS NOT NULL';
   
     dbms_sql.parse(c, stmt, dbms_sql.native);
     rows_processed := dbms_sql.execute(c);
     dbms_sql.close_cursor(c);
     
     
exception
when others then
  dbms_sql.close_cursor(c);
end;
/
exit;
   
 