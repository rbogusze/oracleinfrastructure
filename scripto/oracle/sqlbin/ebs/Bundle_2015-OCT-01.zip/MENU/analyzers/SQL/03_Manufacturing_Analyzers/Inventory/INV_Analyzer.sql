REM $Id: INV_analyzer.sql 200.5 2015/09/02 jphipps $
REM   
REM	SUMMARY
REM     From Doc ID 1499475.1 : 
REM     Consolidated script to diagnose the current status and footprint of Inventory on an environment.
REM   	This script was created to collect all the required information to understand what impact inventory
REM   	in Oracle Applications has on an EBS instance.
REM
REM USAGE NOTES
REM     1. This script can be run on 11.5.x or higher.
REM		2. To run: 
REM 			sqlplus apps/<password>	@inv_analyzer.sql
REM   		Output file 
REM				inv_analyzer_<SID>_<HOST_NAME>.html
REM
REM VALIDATIONS: CRITICAL SUCCESS : NOT yet in script...
REM		1. No move order data > 5 years.
REM 	2. No Open Period > 1 year in past
REM 	3. No MTI/MMTT for closed periods
REM 	4. Inventory/Costing managers running
REM
REM VALIDATIONS: LISTING
REM 	1. RUP Levels : Added
REM 	2. Top 20 Inventory datafixes : Added but some stubs.
REM		3. Data Age
REM			* Move Orders
REM			* Physical Inventory / Cycle Counts
REM			* Sales Orders
REM 	4. Orphans
REM 		* Reservations - Already in top 20
REM			* Move Orders - Already in top 20
REM		5. Prevention : Critical / Recommend Patches : Added just for mobile so far...
REM		6. Prevention : Root-Cause Data Issue Patches 
REM	    7. Setup : Profiles : Added very basic
REM 	8. Performance : Analyze, table size for purgable objects. : Added basic
REM
REM CHANGE HISTORY:
REM   	0.00  18-JUN-2012 jphipps	Based on WF Analyzer from Bill Burbage (note 1369938.1) : Version 4.05/ 28-FEB-2012
REM   	0.00  18-OCT-2012 jphipps	Worked with Bill Burbage to improve time stamps, column counts.
REM 								Change MISSING header to Installed? and YES to MISSING > Edgar suggestion
REM   	0.01  17-FEB-2014 jphipps	Updated to handle forums change to community similar to workflow_analyzer.sql 5.05.1 2014/02/10 16:47:23 bburbage. 
REM									Updated Rollups.
REM									List note where have on common datafixes. Also make notes as links.
REM									Updated header with feedback from Bill Burbage. 
REM 								Updated critical/recommended patches.
REM			  19-FEB-2014 jphipps	Corrected possible divisor by zero error if no rows in Performance results.
REM									Added more reference notes: Performance FAQ, Debug, and Period Close Advisor.
REM			  26-FEB-2014 jphipps	Corrected bug where serial mark data corruption row did not show if no rows. Removed group by.
REM			  03-MAR-2014 jphipps	Add Org information summary: WMS/PJM/Total
REM		0.02  11-MAR-2014 jphipps	Multiple improvements:
REM									- Start Analyzer off with a link to note.
REM									- For org information: Added Negative balances
REM									- Change Note to Doc ID.
REM									- Reorder references by DOC ID number. Also add 432.1 and Doc ID 1290983.1 for webcasts.
REM									- Minor change to NOPRINT moving to end. Avoids prompting when run SQL in SQLDEV. (Script still not SQLDEV compatible due to CHR(10).)
REM									- Corrected internal section numbering. Corrected expand SQL box numbering.
REM									- Changed WMS to INV in patch query column for RUP check.
REM									- Fixed type-o pointed out by Tim Carter on INV RUPs that said WMS... (Current INV Rollup:)
REM			  						- Add More data checks:
REM									1. Data issues > WIP Duplicate check from Note 1073279.1 - Duplicate WIP.
REM			  						2. Data issues > CST costing errors.
REM									3. INV Admin > Unprocessed transactions / MTI, MMTT, uncosted MMT - Added NVL on SUM to handle no rows.
REM									4. INV Admin > Profiles / Added INV/FND Debug check.
REM 		  						- For R12.x, add profile check for Material Status. Commonly missed. 
REM									  Note: Expand later to highlight if status defined but no profile: INV: Material Status Support / INV_MATERIAL_STATUS.
REM		0.03  20-OCT-2014 jphipps	Added INV and WMS rollups upto RUP9 and RUP10.
REM									Changed critical/recommended list from RUP8 to RUP9 plus updated Order management suggestion.
REM									Enhanced "included in RUP" list changing some N/A to Yes where appropriate.
REM									Left non-INV patches as N/A for "Included in RUP" if NOT included in an inventory rollup.
REM		0.04  15-DEC-2014 jphipps	Added INV 20187255 and WMS 20187263 rollup RUP11. 
REM									Removed 14570467, 19018023 replaced with ONT Rollup 17785966. 
REM		0.05  16-JUNC-2015 jphipps	Removed "APPS." from tables names per new analyzer standard.
REM                                 Added INV 21218468 and WMS 21220763 rollup RUP12. 
REM									Patch:17785966:R12.ONT.B      -> Patch:20390490:R12.ONT.B
REM									Patch:17898405:R12.ITM.C      -> Patch:20234886:R12.ITM.C
REM									Patch:18058537:R12.WSH.B      -> Patch:20976856:R12.WSH.B
REM									Patch:18064129:R12.INV.B      -> Patch:20230847:R12.INV.B
REM 
REM POSSIBLE FUTURE ENHANCEMENTS
REM		* Goal Centric Run? 
REM			>>> Daily vs. Monthly vs. Annual vs. ONE-TIME checks  - Goal: improve performance
REM			>>> Datafix oriented vs. general diagnostics
REM			>>> Specific fix check: ie., run just for serial mark ids
REM 	* Reuse within SQL instead of multiple SQL for same thing... ie., release, then use variable...
REM 	* Reuse common components across WF Analyzer like RUP check
REM 	* Concurrent program vs. SQL
REM		* Additional Receiving and WMS validations
REM     * For datafixes: 
REM 		>> Could expand space checks to validate related tables for lot / serials.
REM 		>> Could expand space checks for invalid characters.
REM 	* Add timings per SQL (have overall right now)
REM 	* Check for key invalids ex: /59e757d8_BaseTransaction JAVA CLASS
REM		* Check key flexfields being valid with proper values like item.
REM 	* Suggestions on transaction history purge (MTL_MATERIAL_TRANSACTIONS)?
REM 	* Integrate PIM Rollup patches R12.1.3.1, 2, 3... like 17795054 and latest R12.1.3 RPC like 19030202

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Inventory Analyzer
REM
REM MENU_START
REM
REM SQL: Run Inventory Analyzer 
REM FNDLOAD: Load Inventory Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM 
REM 
REM HELP_START  
REM 
REM  Inventory Analyzer Help [Doc ID: 1499475.1]
REM
REM  Compatible: 11i|12.0|12.1|12.2
REM
REM  Explanation of available options:
REM
REM    (1) Run Inventory Analyzer for Common Inventory Data Issues, 
REM        Critical Patches and Setups
REM        o Runs inventory_analyzer.sql as APPS user to create an HTML report 
REM
REM    (2) Install Analyzer as a Concurrent Program: 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "Setup Reports"
REM 
REM HELP_END  
REM 
REM FNDLOAD_START 
REM PROD_TOP: INV_TOP
REM PROG_NAME: INV_ANALYZER_SQL
REM DEF_REQ_GROUP: Setup Reports
REM APP_NAME: Inventory
REM PROG_TEMPLATE: INV_ANALYZER_SQL_prog.ldt
REM CP_FILE: 
REM PROD_SHORT_NAME: INV 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END

REM SQL SETTINGS
REM -----------------------------------------------------
REM Enable sql settings for proper output file creation

set arraysize 1
set heading off
set feedback off  
set echo off
set verify off
SET CONCAT ON
SET CONCAT .
SET ESCAPE OFF
SET ESCAPE '\'
set lines 150
set pages 9999
set serveroutput on size 100000

REM TIMING VARIABLES 
REM -----------------------------------------------------
REM Timing variables used in various sections
variable st_time 	varchar2(100);
variable et_time 	varchar2(100);
variable n number
REM Section 1: Inventory patch levels : 
VARIABLE SID         	VARCHAR2(20);
VARIABLE HOST        	VARCHAR2(30);
VARIABLE APPS_REL    	VARCHAR2(10);

REM Timing functions for various displays
REM -----------------------------------------------------

begin
select to_char(sysdate,'hh24:mi:ss') into :st_time from dual;
end;
/

COLUMN host_name NEW_VALUE hostname NOPRINT 
SELECT host_name from v$instance;
COLUMN instance_name NEW_VALUE instancename NOPRINT 
SELECT instance_name from v$instance;
COLUMN sysdate NEW_VALUE when NOPRINT 
select to_char(sysdate, 'YYYY-Mon-DD') "sysdate" from dual;
--SPOOL inv_analyzer_&&hostname._&&instancename._&&when..html
COLUMN sysdate PRINT
alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

REM TITLE
REM -----------------------------------------------------

prompt <HTML>
prompt <HEAD>
prompt <TITLE>Inventory Analyzer</TITLE>
prompt <STYLE TYPE="text/css">
prompt <!-- TD {font-size: 10pt; font-family: calibri; font-style: normal} -->
prompt </STYLE>
prompt </HEAD>
prompt <BODY>

prompt <TABLE border="1" cellspacing="0" cellpadding="10">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD bordercolor="#DEE6EF"><font face="Calibri">
prompt <B><font size="+2">Inventory Analyzer for 
select UPPER(instance_name) from v$instance;
prompt <B><font size="+2"> on 
select UPPER(host_name) from v$instance;
prompt </font></B></TD></TR>
prompt </TABLE><BR>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=432.1" target="_blank">
prompt <img src="https://blogs.oracle.com/ebs/resource/Proactive/banner4.jpg" title="Click here to see other helpful Oracle Proactive Tools" width="758" height="81" border="0" alt="Proactive Services Banner" /></a>
prompt <br>

prompt <font size="-1"><i><b>Inventory Analyzer v200.5 compiled on : 

select sysdate from dual;
prompt </b></i></font><BR><BR>

prompt This Inventory Analyzer script from Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1499475.1" target="_blank">1499475.1</A> 
prompt reviews your overall Inventory setup, patch levels, runtime tables, profiles, settings, and configurations. 
prompt The analyzer provides helpful feedback and recommendations on Best Practices for any areas of concern on your system.
prompt Included in the validations are checks for common inventory data corruptions as well as the patches to avoid them.
prompt <BR>

prompt ________________________________________________________________________________________________<BR>

prompt <table width="95%" border="0">
prompt   <tr> 
prompt     <td colspan="2" height="46"> 
prompt       <p><a name="top"><b><font size="+2">Table of Contents</font></b></a> </p>
prompt     </td>
prompt   </tr>
prompt   <tr> 
prompt     <td width="50%"> 
prompt       <p><a href="#section1"><b><font size="+1">Inventory Patch Levels</font></b></a><br>
prompt       <blockquote> <a href="#section1"> - E-Business Suite Version</a><br>
prompt         <a href="#inv101"> - Rollup Levels</a><br>
prompt         <a href="#inv102"> - Critical/Recommended Patches</a></blockquote><br>
prompt       <a href="#section2"><b><font size="+1">Inventory Administration</font></b></a><br> 
prompt       <blockquote> <a href="#section2"> - Profile Settings</a><br>
prompt          <a href="#inv201"> - Inventory Organizations</a><br>
prompt          <a href="#inv202"> - Unprocessed Transaction Summary</a></blockquote><br>
prompt     <a href="#section3"><b><font size="+1">Data Issues</font></b></a><br> 
prompt       <blockquote> <a href="#section3"> - Inventory Data Issues</a><br>
prompt          <a href="#inv301"> - WIP Data Issues</a><br>
prompt          <a href="#inv302"> - Costing Data Issues</a></blockquote><br>
prompt     <a href="#section4"><b><font size="+1">Performance</font></b></a><br> 
prompt     </td>
prompt     <td width="50%"><a href="#section5"><b><font size="+1">References</font></b></a><BR>
prompt       <a href="#section6"><b><font size="+1">Feedback</font></b></a> 
prompt       <blockquote></blockquote>
prompt     </td>
prompt   </tr>
prompt </table>

prompt ________________________________________________________________________________________________<BR><BR>


REM **************************************************************************************** 
REM *******                   Section 1 : Inventory Patch Levels                     *******
REM ****************************************************************************************

prompt <a name="section1"></a><B><font size="+2">Inventory Patch Levels</font></B><BR><BR>
begin
select upper(instance_name) into :sid from v$instance;
select host_name into :host from fnd_product_groups, v$instance;
select release_name into :apps_rel from fnd_product_groups, v$instance;
end;
/

REM
REM ******* Ebusiness Suite Version *******
REM

prompt <script type="text/javascript">    function displayRows1sql1(){var row = document.getElementById("s1sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv100"></a>
prompt     <B>E-Business Suite Version</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          select vi.instance_name, fpg.release_name, vi.host_name, vi.startup_time, vi.version <br>
prompt          from fnd_product_groups fpg, v$instance vi<br>
prompt          where fpg.APPLICATIONS_SYSTEM_NAME = vi.INSTANCE_NAME;</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RELEASE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>HOSTNAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>STARTED</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DATABASE</B></TD>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||instance_name||'</TD>'||chr(10)|| 
'<TD>'||release_name||'</TD>'||chr(10)|| 
'<TD>'||host_name||'</TD>'||chr(10)|| 
'<TD>'||startup_time||'</TD>'||chr(10)|| 
'<TD>'||version||'</TD></TR>'
from fnd_product_groups, v$instance
where APPLICATIONS_SYSTEM_NAME = INSTANCE_NAME;
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* Rollup Levels *******
REM
REM SQL from Doc ID 726226.1 Checking for Roll-up Levels
REM Last Modified: July 13, 2012

prompt <script type="text/javascript">    function displayRows1sql2(){var row = document.getElementById("s1sql2");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv101"></a>
prompt     <B>Rollup Levels</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql2()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql2" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
PROMPT          select 'Application Environment: '|| i.instance_name || ', Host: '|| i.host_name ||', Application Release: ' || f.release_name || ', DB Version: '|| i.version "Rollup Details"<BR>
PROMPT          from v$instance i,fnd_product_groups f<BR>
PROMPT          where upper(substr(i.instance_name,1,4)) =  upper(substr(f.applications_system_name,1,4))<BR>
PROMPT          UNION<BR>
PROMPT          select 'Current Application Release: '||ver||' ('||bug||')' "Description" from (<BR>
PROMPT          select x.* from<BR>
PROMPT          (select 1 seq, '1939818' bug,'11.5.0' pv,'11.5.6' ver from dual<BR>
PROMPT          union select 2,'2123967','11.5.0','11.5.7' from dual<BR>
PROMPT          union select 3,'2293243','11.5.0','11.5.8' from dual<BR>
PROMPT          union select 4,'2669606','11.5.0','11.5.9 MP' from dual<BR>
PROMPT          union select 5,'3126422','11.5.0','11.5.9 Update1' from dual<BR>
PROMPT          union select 6,'3171663','11.5.0','11.5.9 Update2' from dual<BR>
PROMPT          union select 7,'3714435','11.5.0','11.5.9 June Update' from dual<BR>
PROMPT          union select 8,'3140000','11.5.0','11.5.10' from dual<BR>
PROMPT          union select 9,'3240000','11.5.0','11.5.10.1' from dual<BR>
PROMPT          union select 10,'3460000','11.5.0','11.5.10.2' from dual<BR>
PROMPT          union select 11,'3480000','11.5.0','11.5.10.2' from dual<BR>
PROMPT          union select 12,'4440000','12.0.0','12.0' from dual<BR>
PROMPT          union select 12,'94440000','12.0.0','12.0*' from dual<BR>
PROMPT          union select 13,'5082400','12.0.0','12.0.1' from dual<BR>
PROMPT          union select 14,'5484000','12.0.0','12.0.2' from dual<BR>
PROMPT          union select 14,'95484000','12.0.0','12.0.2*' from dual<BR>
PROMPT          union select 15,'6141000','12.0.0','12.0.3' from dual<BR>
PROMPT          union select 15,'96141000','12.0.0','12.0.3*' from dual<BR>
PROMPT          union select 16,'6435000','12.0.0','12.0.4' from dual<BR>
PROMPT          union select 17,'7282993','12.0.0','12.0.5' from dual<BR>
PROMPT          union select 18,'6728000','12.0.0','12.0.6' from dual<BR>
PROMPT          union select 19,'6646600','12.0.0','12.1.0' from dual<BR>
PROMPT          union select 20,'7303030','12.0.0','12.1.1' from dual<BR>
PROMPT          union select 20,'97303030','12.0.0','12.1.1*' from dual<BR>
PROMPT          union select 21,'7303033','12.0.0','12.1.2' from dual<BR>
PROMPT          union select 22,'9239090','12.0.0','12.1.3' from dual<BR>
PROMPT          union select 23,'10079002','12.0.0','12.2.0' from dual<BR>
PROMPT          union select 24,'910079002','12.0.0','12.2.0' from dual<BR>
PROMPT          union select 25,'14222221','12.0.0','12.2.1' from dual<BR>
PROMPT          union select 26,'16207672','12.0.0','12.2.2' from dual<BR>
PROMPT          union select 27,'17020683','12.0.0','12.2.3' from dual<BR>
PROMPT          union select 28,'17919161','12.0.0','12.2.4' from dual<BR>
PROMPT          union select 29,'917919161','12.0.0','12.2.4' from dual<BR>
PROMPT          ) x,<BR>
PROMPT          (select product_version pv from fnd_product_installations<BR>
PROMPT          where application_id=401) i,<BR>
PROMPT          ad_bugs bugs<BR>
PROMPT          where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1<BR>
PROMPT          union<BR>
PROMPT          select 'Current INV Rollup: '||ver||' ('||bug||')' "Description" from (<BR>
PROMPT          select x.* from<BR>
PROMPT          (select 1 seq, '1426212' bug,'11.5.0' pv,'INV.C' ver from dual<BR>
PROMPT          union select 2,'1551167','11.5.0','MFG.D' from dual<BR>
PROMPT          union select 3, '1550583','11.5.0','OM.D' from dual<BR>
PROMPT          union select 4,'1538130','11.5.0','INV.D' from dual<BR>
PROMPT          union select 5, '1745355','11.5.0','MFG.E' from dual<BR>
PROMPT          union select 6,'1696652','11.5.0','INV.E' from dual<BR>
PROMPT          union select 7, '1891480','11.5.0','MFG.F' from dual<BR>
PROMPT          union select 8, '1942144','11.5.0','OM.F' from dual<BR>
PROMPT          union select 9,'1886015','11.5.0','INV.F' from dual<BR>
PROMPT          union select 10, '2133107','11.5.0','MFG.G' from dual<BR>
PROMPT          union select 11, '2118482','11.5.0','OM.G' from dual<BR>
PROMPT          union select 12,'2004922','11.5.0','INV.G' from dual<BR>
PROMPT          union select 13, '2248408','11.5.0','MFG.H' from dual<BR>
PROMPT          union select 14,'2250333','11.5.0','OM.H' from dual<BR>
PROMPT          union select 15,'2248490','11.5.0','INV.H' from dual<BR>
PROMPT          union select 16, '2697753','11.5.0','MFG.I' from dual<BR>
PROMPT          union select 17,'2698175','11.5.0','OM.I' from dual<BR>
PROMPT          union select 18,'2371213','11.5.0','INV.I' from dual<BR>
PROMPT          union select 19,'3384350','11.5.0','INV.J' from dual<BR>
PROMPT          union select 20,'4042499','11.5.0','INV.J RUP1' from dual<BR>
PROMPT          union select 21,'4231215','11.5.0','INV.J RUP2' from dual<BR>
PROMPT          union select 22,'4734840','11.5.0','INV.J RUP3' from dual<BR>
PROMPT          union select 23,'5739724','11.5.0','INV.J RUP4' from dual<BR>
PROMPT          union select 24,'6449139','11.5.0','INV.J RUP5' from dual<BR>
PROMPT          union select 25,'6461517','11.5.0','INV.J RUP6' from dual<BR>
PROMPT          union select 26,'6461519','11.5.0','INV.J RUP7' from dual<BR>
PROMPT          union select 27,'6461522','11.5.0','INV.J RUP8' from dual<BR>
PROMPT          union select 28,'6870030','11.5.0','INV.J RUP9' from dual<BR>
PROMPT          union select 29,'7258620','11.5.0','INV.J RUP10' from dual<BR>
PROMPT          union select 30,'7258624','11.5.0','INV.J RUP11' from dual<BR>
PROMPT          union select 31,'7258629','11.5.0','INV.J RUP12' from dual<BR>
PROMPT          union select 32,'7581431','11.5.0','INV.J RUP13' from dual<BR>
PROMPT          union select 33,'7666112','11.5.0','INV.J RUP14' from dual<BR>
PROMPT          union select 34,'8403245','11.5.0','INV.J RUP15' from dual<BR>
PROMPT          union select 35,'8403254','11.5.0','INV.J RUP16' from dual<BR>
PROMPT          union select 36,'8403258','11.5.0','INV.J RUP17' from dual<BR>
PROMPT          union select 37,'9063156','11.5.0','INV.J RUP18' from dual<BR>
PROMPT          union select 38,'9265857','11.5.0','INV.J RUP19' from dual<BR>
PROMPT          union select 39,'9466436','11.5.0','INV.J RUP20' from dual<BR>
PROMPT          union select 40,'9649124','11.5.0','INV.J RUP21' from dual<BR>
PROMPT          union select 41,'9878808','11.5.0','INV.J RUP22' from dual<BR>
PROMPT          union select 42,'10111967','11.5.0','INV.J RUP23' from dual<BR>
PROMPT          union select 43,'8478486','12.0.0','R12 INV/RCV RUP7' from dual<BR>
PROMPT          union select 44,'7587155','12.0.0','R12.1.1 OPM-INV Consolidated May-2009' from dual<BR>
PROMPT          union select 45,'12345554','12.0.0','R12.1.3 OPM-INV Consolidated Apr-2011' from dual<BR>
PROMPT          union select 46,'12916273','12.0.0','R12.1+ INV Dual UOM related fixes 3' from dual<BR>
PROMPT          union select 47,'13885374','12.0.0','R12.1+INV Dual UOM related fixes 4' from dual<BR>
PROMPT          union select 48,'14586882','12.0.0','R12.1+ INV RUP 5' from dual<BR>
PROMPT          union select 49,'16328540','12.0.0','R12.1+ INV RUP 6' from dual<BR>
PROMPT          union select 50,'16826285','12.0.0','R12.1+ INV RUP 7 (Requires RUP6)' from dual<BR>
PROMPT          union select 51,'17512558','12.0.0','R12.1+ INV RUP 7 Consolidated' from dual<BR>
PROMPT          union select 52,'18076740','12.0.0','R12.1+ INV RUP 8' from dual<BR>
PROMPT          union select 53,'18615837','12.0.0','R12.1+ INV RUP 9' from dual<BR>
PROMPT          union select 54,'19447776','12.0.0','R12.1+ INV RUP 10' from dual<BR>
PROMPT          union select 55,'20187255','12.0.0','R12.1+ INV RUP 11' from dual<BR>
PROMPT          union select 56,'21218468','12.0.0','R12.1+ INV RUP 12' from dual<BR>
PROMPT          ) x,<BR>
PROMPT          (select product_version pv from fnd_product_installations<BR>
PROMPT          where application_id = 401) i,<BR>
PROMPT          ad_bugs bugs<BR>
PROMPT          where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1<BR>
PROMPT          UNION<BR>
PROMPT          select 'Current WMS Rollup: '||ver||' ('||bug||')' "Description" from (<BR>
PROMPT          select x.* from<BR>
PROMPT          (select 1 seq, '4734840' bug, '11.5.0' pv,'RUP3' ver from dual<BR>
PROMPT          union select 2 seq, '5855276' bug,'11.5.0' pv,'WMS RUP4' ver from dual<BR>
PROMPT          union select 3 seq, '6957082' bug,'11.5.0' pv,'WMS RUP5' ver from dual<BR>
PROMPT          union select 4 seq, '7041845' bug,'11.5.0' pv,'WMS RUP6' ver from dual<BR>
PROMPT          union select 5 seq, '7219660' bug,'11.5.0' pv,'WMS RUP7' ver from dual<BR>
PROMPT          union select 6 seq, '7317230' bug,'11.5.0' pv,'WMS RUP8' ver from dual<BR>
PROMPT          union select 7 seq, '7453739' bug,'11.5.0' pv,'WMS RUP9' ver from dual<BR>
PROMPT          union select 8 seq, '7591071' bug,'11.5.0' pv,'WMS RUP10' ver from dual<BR>
PROMPT          union select 9 seq, '7644924' bug,'11.5.0' pv,'WMS RUP11' ver from dual<BR>
PROMPT          union select 10 seq,'7688739' bug,'11.5.0' pv,'WMS RUP12' ver from dual<BR>
PROMPT          union select 11 seq,'8337529' bug,'11.5.0' pv,'WMS RUP13' ver from dual<BR>
PROMPT          union select 12 seq,'8524873' bug,'11.5.0' pv,'WMS RUP14' ver from dual<BR>
PROMPT          union select 13 seq,'8785944' bug,'11.5.0' pv,'WMS RUP15' ver from dual<BR>
PROMPT          union select 13 seq,'8941985' bug,'11.5.0' pv,'WMS RUP16' ver from dual<BR>
PROMPT          union select 14 seq,'9127290' bug,'11.5.0' pv,'WMS RUP17' ver from dual<BR>
PROMPT          union select 15 seq,'9857061' bug,'11.5.0' pv,'WMS RUP18' ver from dual<BR>
PROMPT          union select 16 seq,'9951502' bug,'11.5.0' pv,'WMS RUP19' ver from dual<BR>
PROMPT          union select 17 seq,'10129740' bug,'11.5.0' pv,'WMS RUP20' ver from dual<BR>
PROMPT          union select 18 seq,'7716519','12.0.0','R12.1.1 OPM-WMS Consolidated May-2009' from dual<BR>
PROMPT          union select 19 seq,'12364985','12.0.0','R12.1.1 OPM-WMS Consolidated Apr-2011' from dual<BR>
PROMPT          union select 20 seq,'12916291','12.0.0','R12.1+ WMS Dual UOM fixes RUP 3' from dual<BR>
PROMPT          union select 21 seq,'13885396','12.0.0','R12.1+ WMS Dual UOM fixes RUP 4' from dual<BR>
PROMPT          union select 22 seq,'14611722','12.0.0','R12.1+ WMS RUP 5' from dual<BR>
PROMPT          union select 23 seq,'16272776','12.0.0','R12.1+ WMS RUP 6' from dual<BR>
PROMPT          union select 24 seq,'16812342','12.0.0','R12.1+ WMS RUP 7 (Requires RUP6)' from dual<BR>
PROMPT          union select 25 seq,'17442200','12.0.0','R12.1+ WMS RUP 7 Consolidated' from dual<BR>
PROMPT          union select 26 seq,'18081430','12.0.0','R12.1+ WMS RUP 8' from dual<BR>
PROMPT          union select 27 seq,'18618946','12.0.0','R12.1+ WMS RUP 9' from dual<BR>
PROMPT          union select 28 seq,'19447782','12.0.0','R12.1+ WMS RUP 10' from dual<BR>
PROMPT          union select 29 seq,'20187263','12.0.0','R12.1+ WMS RUP 11' from dual<BR>
PROMPT          union select 30 seq,'21220763','12.0.0','R12.1+ WMS RUP 12' from dual<BR>
PROMPT          ) x,<BR>
PROMPT          (select product_version pv from fnd_product_installations<BR>
PROMPT          where application_id=385) i,<BR>
PROMPT          ad_bugs bugs<BR>
PROMPT          where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1<BR>
PROMPT          union<BR>
PROMPT          select 'Product Installation List : ' from dual<BR>
PROMPT          union<BR>
PROMPT          select 'Product Installation: '||patch_level||': '||decode(status,<BR>
PROMPT          'I','Installed','S','Shared','Not Installed')<BR>
PROMPT          from fnd_product_installations<BR>
PROMPT          where application_id IN (401, 385, 201, 431, 702, 703)<BR>
PROMPT          order by 1; </P>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DESCRIPTION</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PATCH LEVEL</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>INSTALLED?</B></TD>
exec :n := dbms_utility.get_time;
select '<TR><TD>'||'Current Application Release: '||'</TD>'||chr(10)|| 
'<TD>'||ver||' ('||bug||')'||'</TD>'||chr(10)|| 
'<TD>Installed</TD></TR>' "Description" from (
select x.* from
(select 1 seq, '1939818' bug,'11.5.0' pv,'11.5.6' ver from dual
union select 2,'2123967','11.5.0','11.5.7' from dual
union select 3,'2293243','11.5.0','11.5.8' from dual
union select 4,'2669606','11.5.0','11.5.9 MP' from dual
union select 5,'3126422','11.5.0','11.5.9 Update1' from dual
union select 6,'3171663','11.5.0','11.5.9 Update2' from dual
union select 7,'3714435','11.5.0','11.5.9 June Update' from dual
union select 8,'3140000','11.5.0','11.5.10' from dual
union select 9,'3240000','11.5.0','11.5.10.1' from dual
union select 10,'3460000','11.5.0','11.5.10.2' from dual
union select 11,'3480000','11.5.0','11.5.10.2' from dual
union select 12,'4440000','12.0.0','12.0' from dual
union select 12,'94440000','12.0.0','12.0*' from dual
union select 13,'5082400','12.0.0','12.0.1' from dual
union select 14,'5484000','12.0.0','12.0.2' from dual
union select 14,'95484000','12.0.0','12.0.2*' from dual
union select 15,'6141000','12.0.0','12.0.3' from dual
union select 15,'96141000','12.0.0','12.0.3*' from dual
union select 16,'6435000','12.0.0','12.0.4' from dual
union select 17,'7282993','12.0.0','12.0.5' from dual
union select 18,'6728000','12.0.0','12.0.6' from dual
union select 19,'6646600','12.0.0','12.1.0' from dual
union select 20,'7303030','12.0.0','12.1.1' from dual
union select 20,'97303030','12.0.0','12.1.1*' from dual
union select 21,'7303033','12.0.0','12.1.2' from dual
union select 22,'9239090','12.0.0','12.1.3' from dual
union select 23,'10079002','12.0.0','12.2.0' from dual
union select 24,'910079002','12.0.0','12.2.0' from dual
union select 25,'14222221','12.0.0','12.2.1' from dual
union select 26,'16207672','12.0.0','12.2.2' from dual
union select 27,'17020683','12.0.0','12.2.3' from dual
union select 28,'17919161','12.0.0','12.2.4' from dual
union select 29,'917919161','12.0.0','12.2.4' from dual
) x,
(select product_version pv from fnd_product_installations
where application_id=401) i,
ad_bugs bugs
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1
union
select '<TR><TD>'||'Current INV Rollup: '||'</TD>'||chr(10)|| 
'<TD>'||ver||' ('||bug||')'||'</TD>'||chr(10)|| 
'<TD>Installed</TD></TR>' "Description" from (
select x.* from
(select 1 seq, '1426212' bug,'11.5.0' pv,'INV.C' ver from dual
union select 2,'1551167','11.5.0','MFG.D' from dual
union select 3, '1550583','11.5.0','OM.D' from dual
union select 4,'1538130','11.5.0','INV.D' from dual
union select 5, '1745355','11.5.0','MFG.E' from dual
union select 6,'1696652','11.5.0','INV.E' from dual
union select 7, '1891480','11.5.0','MFG.F' from dual
union select 8, '1942144','11.5.0','OM.F' from dual
union select 9,'1886015','11.5.0','INV.F' from dual
union select 10, '2133107','11.5.0','MFG.G' from dual
union select 11, '2118482','11.5.0','OM.G' from dual
union select 12,'2004922','11.5.0','INV.G' from dual
union select 13, '2248408','11.5.0','MFG.H' from dual
union select 14,'2250333','11.5.0','OM.H' from dual
union select 15,'2248490','11.5.0','INV.H' from dual
union select 16, '2697753','11.5.0','MFG.I' from dual
union select 17,'2698175','11.5.0','OM.I' from dual
union select 18,'2371213','11.5.0','INV.I' from dual
union select 19,'3384350','11.5.0','INV.J' from dual
union select 20,'4042499','11.5.0','INV.J RUP1' from dual
union select 21,'4231215','11.5.0','INV.J RUP2' from dual
union select 22,'4734840','11.5.0','INV.J RUP3' from dual
union select 23,'5739724','11.5.0','INV.J RUP4' from dual
union select 24,'6449139','11.5.0','INV.J RUP5' from dual
union select 25,'6461517','11.5.0','INV.J RUP6' from dual
union select 26,'6461519','11.5.0','INV.J RUP7' from dual
union select 27,'6461522','11.5.0','INV.J RUP8' from dual
union select 28,'6870030','11.5.0','INV.J RUP9' from dual
union select 29,'7258620','11.5.0','INV.J RUP10' from dual
union select 30,'7258624','11.5.0','INV.J RUP11' from dual
union select 31,'7258629','11.5.0','INV.J RUP12' from dual
union select 32,'7581431','11.5.0','INV.J RUP13' from dual
union select 33,'7666112','11.5.0','INV.J RUP14' from dual
union select 34,'8403245','11.5.0','INV.J RUP15' from dual
union select 35,'8403254','11.5.0','INV.J RUP16' from dual
union select 36,'8403258','11.5.0','INV.J RUP17' from dual
union select 37,'9063156','11.5.0','INV.J RUP18' from dual
union select 38,'9265857','11.5.0','INV.J RUP19' from dual
union select 39,'9466436','11.5.0','INV.J RUP20' from dual
union select 40,'9649124','11.5.0','INV.J RUP21' from dual
union select 41,'9878808','11.5.0','INV.J RUP22' from dual
union select 42,'10111967','11.5.0','INV.J RUP23' from dual
union select 43,'8478486','12.0.0','R12 INV/RCV RUP7' from dual
union select 44,'7587155','12.0.0','R12.1.1 OPM-INV Consolidated May-2009' from dual
union select 45,'12345554','12.0.0','R12.1.3 OPM-INV Consolidated Apr-2011' from dual
union select 46,'12916273','12.0.0','R12.1+ INV Dual UOM related fixes 3' from dual
union select 47,'13885374','12.0.0','R12.1+INV Dual UOM related fixes 4' from dual
union select 48,'14586882','12.0.0','R12.1+ INV RUP 5' from dual
union select 49,'16328540','12.0.0','R12.1+ INV RUP 6' from dual
union select 50,'16826285','12.0.0','R12.1+ INV RUP 7 (Requires RUP6)' from dual
union select 51,'17512558','12.0.0','R12.1+ INV RUP 7 Consolidated' from dual
union select 52,'18076740','12.0.0','R12.1+ INV RUP 8' from dual
union select 53,'18615837','12.0.0','R12.1+ INV RUP 9' from dual
union select 54,'19447776','12.0.0','R12.1+ INV RUP 10' from dual
union select 55,'20187255','12.0.0','R12.1+ INV RUP 11' from dual
union select 56,'21218468','12.0.0','R12.1+ INV RUP 12' from dual
) x,
(select product_version pv from fnd_product_installations
where application_id = 401) i,
ad_bugs bugs
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1
UNION
select '<TR><TD>'||'Current WMS Rollup: '||'</TD>'||chr(10)|| 
'<TD>'||ver||' ('||bug||')'||'</TD>'||chr(10)|| 
'<TD>Installed</TD></TR>' "Description" from (
select x.* from
(select 1 seq, '4734840' bug, '11.5.0' pv,'RUP3' ver from dual
union select 2 seq, '5855276' bug,'11.5.0' pv,'WMS RUP4' ver from dual
union select 3 seq, '6957082' bug,'11.5.0' pv,'WMS RUP5' ver from dual
union select 4 seq, '7041845' bug,'11.5.0' pv,'WMS RUP6' ver from dual
union select 5 seq, '7219660' bug,'11.5.0' pv,'WMS RUP7' ver from dual
union select 6 seq, '7317230' bug,'11.5.0' pv,'WMS RUP8' ver from dual
union select 7 seq, '7453739' bug,'11.5.0' pv,'WMS RUP9' ver from dual
union select 8 seq, '7591071' bug,'11.5.0' pv,'WMS RUP10' ver from dual
union select 9 seq, '7644924' bug,'11.5.0' pv,'WMS RUP11' ver from dual
union select 10 seq,'7688739' bug,'11.5.0' pv,'WMS RUP12' ver from dual
union select 11 seq,'8337529' bug,'11.5.0' pv,'WMS RUP13' ver from dual
union select 12 seq,'8524873' bug,'11.5.0' pv,'WMS RUP14' ver from dual
union select 13 seq,'8785944' bug,'11.5.0' pv,'WMS RUP15' ver from dual
union select 13 seq,'8941985' bug,'11.5.0' pv,'WMS RUP16' ver from dual
union select 14 seq,'9127290' bug,'11.5.0' pv,'WMS RUP17' ver from dual
union select 15 seq,'9857061' bug,'11.5.0' pv,'WMS RUP18' ver from dual
union select 16 seq,'9951502' bug,'11.5.0' pv,'WMS RUP19' ver from dual
union select 17 seq,'10129740' bug,'11.5.0' pv,'WMS RUP20' ver from dual
union select 18 seq,'7716519','12.0.0','R12.1.1 OPM-WMS Consolidated May-2009' from dual
union select 19 seq,'12364985','12.0.0','R12.1.1 OPM-WMS Consolidated Apr-2011' from dual
union select 20 seq,'12916291','12.0.0','R12.1+ WMS Dual UOM fixes RUP 3' from dual
union select 21 seq,'13885396','12.0.0','R12.1+ WMS Dual UOM fixes RUP 4' from dual
union select 22 seq,'14611722','12.0.0','R12.1+ WMS RUP 5' from dual
union select 23 seq,'16272776','12.0.0','R12.1+ WMS RUP 6' from dual
union select 24 seq,'16812342','12.0.0','R12.1+ WMS RUP 7 (Requires RUP6)' from dual
union select 25 seq,'17442200','12.0.0','R12.1+ WMS RUP 7 Consolidated' from dual
union select 26 seq,'18081430','12.0.0','R12.1+ WMS RUP 8' from dual
union select 27 seq,'18618946','12.0.0','R12.1+ WMS RUP 9' from dual
union select 28 seq,'19447782','12.0.0','R12.1+ WMS RUP 10' from dual
union select 29 seq,'20187263','12.0.0','R12.1+ WMS RUP 11' from dual
union select 30 seq,'21220763','12.0.0','R12.1+ WMS RUP 12' from dual
) x,
(select product_version pv from fnd_product_installations
where application_id=385) i,
ad_bugs bugs
where x.bug = bugs.bug_number and x.pv = i.pv order by 1 desc) where rownum = 1
union
select '<TR><TD>'||'Product Installation: '||'</TD>'||chr(10)|| 
'<TD>'||patch_level||' </TD>'||chr(10)|| 
'<TD>'|| decode(status, 'I','Installed','S','Shared','Not Installed') ||'</TD></TR>'
from fnd_product_installations
where application_id IN (401, 385, 201, 431, 702, 703)
order by 1;
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* Critical/Recommended Patches *******
REM

prompt <script type="text/javascript">    function displayRows1sql3(){var row = document.getElementById("s1sql3");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv102"></a>
prompt     <B>Critical/Recommended Patches</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql3()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql3" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          select 'RECOMMENDED', 'Patch 14240171', 'In Oracle Inventory,unmarked serial numbers in status 6 are being generated after mobile receiving and it prevent generating the same serial number', 'No', decode(count(*), 0, 'No', 'Installed')<br> 
prompt          from ad_bugs<br> 
prompt          where bug_number  = '14240171'<br> 
prompt          UNION<br> 
prompt          select 'RECOMMENDED', 'Patch 12596775', 'Receiving INV Intransit Shipments With Mobile Mwa Does not Commit When Transfer', 'No', decode(count(*), 0, 'No', 'Installed')<br> 
prompt          from ad_bugs<br> 
prompt          where bug_number  = '12596775'<br> 
prompt          UNION<br> 
prompt          select 'RECOMMENDED', 'Patch 12799914', 'Users get "Unexpected Error occurred" on the Mobile GUI application when pressing Next Item', 'No', decode(count(*), 0, 'No', 'Installed')<br> 
prompt          from ad_bugs<br> 
prompt          where bug_number  = '12799914'<br> 
prompt          UNION<br> 
prompt          select 'RECOMMENDED', 'Patch 11816806', 'Tasks intermittently not showing up in wms mobile', 'No', decode(count(*), 0, 'No', 'Installed')<br> 
prompt          from ad_bugs<br> 
prompt          where bug_number  = '11816806'<br> 
prompt          UNION<br> 
prompt          select 'RECOMMENDED', 'Patch 12666693', 'Mobile pick load page wrongly increases picked quantity', 'No', decode(count(*), 0, 'No', 'Installed')<br> 
prompt          from ad_bugs<br> 
prompt          where bug_number  = '12666693' . . . MORE . . . </P>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PRIORITY</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PATCH</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ABSTRACT</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>INCLUDED IN ROLLUP?</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>INSTALLED?</B></TD>
exec :n := dbms_utility.get_time;

REM R11.5.x Critical patches : MINIMUM SUPPORT LEVEL

select * from (
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>INV RUP 4 (Patch 5739724) </TD>'||chr(10)|| 
'<TD>See latest RUP Doc ID 726226.1. INV Rollup (RUP) 4 is critical for R11i. Apply the latest RUP as soon as possible. INV RUP4 is a minimum support requirement.</TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '5739724'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>INV Rollup 14+ (Patch 7666112, 8403245, 8403254, 8403258, 9063156, 9265857, 9466436, 9649124, 9878808, or 10111967) </TD>'||chr(10)|| 
'<TD>See latest RUP Doc ID 726226.1 to ensure you have the latest rollup. INV Rollup (RUP) 14 is critical for R11i. Apply the latest RUP as soon as possible. INV RUP4 is a minimum support requirement.</TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number IN ('7666112', '8403245', '8403254', '8403258', '9063156', '9265857', '9466436', '9649124', '9878808', '10111967')
) where :APPS_REL like '11.5.%';

REM R11.5.x Critical patches : OTHER PATCHES (Recommended)

select * from (
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 10354141 </TD>'||chr(10)|| 
'<TD>Wiptxmat - shows incorrect on-hand and available q</TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '10354141'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 12906600 </TD>'||chr(10)|| 
'<TD>This patch resolve the issue of po_distribution_id not being updated correctly for some records in the table mtl_consumption_transactions after consumption advice.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '10354141'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4395975	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of deadlocks when processing transactions.This patch is recommended for customers using inventory transaction manager</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '10354141'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 5200436	</TD>'||chr(10)|| 
'<TD>11.5.10, Consigned inv consolidated bugfix patch -- corrupt consumption advice releases created</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '5200436'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4867906	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of inventory transaction worker hanging which in certain cases also cause mmt and moqd mismatch.This patch is recommened for customers using oracle inventory and allowing negative balances.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4867906'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2831088	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of wip contents label not getting printed on wip pick drop. This patch is recommended for customers using wip pick drop in oracle wms</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2831088'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4030689	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of duplicate serial numbers allowed to be entered on ship confirm form.This patch is recommended for customers using oracle shipping for serialized items.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4030689'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4382142	</TD>'||chr(10)|| 
'<TD>This path fixes issue of sales order form allowing to create reservations for shipped sales orders.This patch is recommended for customers using oracle order managemet and reservable items.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4382142'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4963263	</TD>'||chr(10)|| 
'<TD>move order still exists though material has been staged.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4963263'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3296400	</TD>'||chr(10)|| 
'<TD>This patch fix the issue of mtl_material_transactions_s sequence reaching its max allowed value.This patch is recommended for customers using oracle inventory and perform transactions.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3296400'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 5005356	</TD>'||chr(10)|| 
'<TD>This patch is highly recommened for customers using direct ship. This patch fixes data corruption caused by overpicking of multiple lots, picking nested lpns or picking lpns with quantity in decimals.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '5005356'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4582052	</TD>'||chr(10)|| 
'<TD>This patch fixes errors thrown and data corruption occurs on transact move order form when transaction quantity is updated from view update allocations.This patch is recommended for customers using transact move orders form.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4582052'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4735030	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of physical inventory not allowing to enter duplicate serial numbers for different items it was throwing error.This patch is recommended for customers using pi and also serial uniqueness with inventory items .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4735030'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3588120	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of zero onhand quantity records inserted when processing subtransfer recors.This patch is recommended for customers using oracle inventory transactions</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3588120'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 2696562	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of zero onhand quantity records inserted into onhand table causing error in transaction manager.This patch is recommended for customers using oracle inventory transactions.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2696562'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4302704	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of serial numbers committed to database and unusable when receiving new serial numbers.This patch is recommended for customers using serial control items</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4302704'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4653347	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of serial numbers marked out of stores after running pick confirm.This patch is recommended for customers using lot/serial items and have profile inv, enable bulk serial validation" was set to "yes"</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4653347'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4110244	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of cursor leak on oracle inventory mobile pages.This patch is recommended for customers using oracle mobile.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4110244'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3961941	</TD>'||chr(10)|| 
'<TD>This patch fixes cursor leak issue on inventory mobile pages.This patch is recommended for customes using oracle mobile inventory</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3961941'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4330855	</TD>'||chr(10)|| 
'<TD>Handles deadlock and related high volume issues in 11i10 inventory transaction manager</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4330855'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3195332	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of pick release backorder even if sufficient quantity is available if number of delivery details are multiple.This patch is recommended for customers using oracle shipping and oracle inventory</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3195332'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4222457	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of wip pending transactions not processing in background mode.This patch is suggested for customers using oracle wip in background processing mode.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4222457'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4182913	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of incorrect transaction_source_id on material transactions which give eror when query material transactions.This is recommended for customers using interorders/interorg transfers.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4182913'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4221474	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of transactions getting created with null subinventory and thus causing data corruption between material transactions and onhand quantities.This patch is recommended for customers using oracle purchasing</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4221474'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 4145618	</TD>'||chr(10)|| 
'<TD>Duplicate consumption advice - create consumption advice report includes transactions processed previously</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4145618'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4170327	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of invalid subinventory and locator combination in onhand thus making it unusable.This patch is recommended for customers using oracle msca and locators.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4170327'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3462946	</TD>'||chr(10)|| 
'<TD>This patch fixes issues of 1) transaction open interface ignoring reservations for issue txns and 2) invalid subinventory and locator combinations in onhand.It is recommended for customers using oracle shipping or txn open interface</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3462946'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4113020	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of invalid subinventory and locator combination in onhand thus making it unusable.This patch is recommended for customers using oracle msca and locators.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4113020'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4147575	</TD>'||chr(10)|| 
'<TD>Transaction commit when the mwa client session is disconnected</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4147575'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 4031570	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of invalid locators created with locator_id of -1 from stock locators form.This patch is recommended for customers who are using stock locators in the inventory.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '4031570'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3824598	</TD>'||chr(10)|| 
'<TD>Tm consolidated patch (3) 08/10/04</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3824598'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3983371	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of invalid locators created with locator_id of -1 from stock locators form.This patch is recommended for customers who are using stock locators in the inventory.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3983371'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3855692	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of allocations not visible on transact move order form lines window when performing multiselect and also fix delivery stuck in release to warehouse status mo closed.This patch recommended for customers using tmo.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3855692'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3457143	</TD>'||chr(10)|| 
'<TD>This patch fixes two issues ,one serialized transactions failing with negative balances not allowed and other is serial generation failing when running for multiple orgs.This patch is recommended for customers using serial items.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3457143'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 2599360	</TD>'||chr(10)|| 
'<TD>This patch fixes the isssue of reservations not getting relieved after shipping the internal orders. This patch is recommended for clients using internal orders .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2599360'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3403255	</TD>'||chr(10)|| 
'<TD>This patch fix the issue of lost option on organization parameters form to choose serial uniqueness within inventory items.This patch is recommended for customers who were using serial uniqueness with in inventory items in prior releases .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3403255'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3559338	</TD>'||chr(10)|| 
'<TD>This patches fixes the issue of higher level reservations being ignored for issue transactions using open interface.This patch is recommended for customers using transaction open interface.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3559338'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3631263	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of physical inventory form allowing invalid locators on tags.This fix is recommended for customers who are using oracle physical inventory .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3631263'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3703919	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of physical inventory tags allowed to be created with invalid locators.This patch is recommended for customers who are using oracle physical inventory.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3703919'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3238012	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of users getting disconnected from applications when entering serial numbers from shipping transactions form.This patch is aplicable for customers using serialized items and oracle shipping.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3238012'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 2798157	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of internal sales order issue records getting stuck in mti with error "ex.. In insertrcvinterface".This patch is recommended for customers using intersalesorders .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2798157'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3720404	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of orphan allocations for a closed move order .This fix is recommended for customers who are using inventory move order functionality</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3720404'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3516959	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of orphan allocations for a closed move order.This fix is recommended for customers who are using inventory move order functionality.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3516959'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2546396	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of data corruption caused by lpn split transactions. This patch is recommended for client using the lpn split functionality in wms orgs.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2546396'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2583947	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of lot attributes not being visible during the receipt of internal shipment of a lot controlled item. This patch is recommended for clients using lot controlled items</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2583947'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2587275	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of being not able to complete the correction transaction for serial controlled items. This patch is recommended for client using correction transactions for serial controlled items.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2587275'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2566808	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of serial numbers being not available for transactions after being returned to stock in quick ship. This patch is recommended for clients using quick ship functionality for serial controlled items</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2566808'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2588171	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of manual request for lpn summary label not producing the label. This patch is recommended for the clients using the lpn summary label</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2588171'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2554136	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of cost group transfer process working incorrectly. This patch is recommended for clients using the cost group transfer functionality.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2554136'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2614016	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of not being able to receive po via the mobile interface. This patch is recommended for clients using the mobile interface for the receiving of po in wms orgs</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2614016'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2616741	</TD>'||chr(10)|| 
'<TD>This patch adds a check to validate if a user can unassign the delivery line from delivery for missing items . This patch is recommended for clients using the lpn ship functionality</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2616741'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2630992	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of a timeout during the process of receiving a large asn. This patch is recommended for clients using the asn functionality</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2630992'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2653285	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of msca ignoring the profile value for inv, restrict receipt of serials. This patch is recommended for clients using serial controlled items</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2653285'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3725441	</TD>'||chr(10)|| 
'<TD>Consumption advice created with multiple distributions</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3725441'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3544788	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of reservation form changing demand_source_type on internal sales order reservations causing orphan reservations.This patch is recommended for customers using internal orders</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3544788'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3238820	</TD>'||chr(10)|| 
'<TD>This patch is recommended for all users.If the fnd_user is not associated with an employee,the master item form fails without warning.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3238820'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2217071	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of inventory transaction worker erroring with signal 11 error.This patch is recommended for customers using inventory transaction manager.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2217071'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2321637	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of transact move order form allowing transaction of already transacted but pending records.This patch is recommended for customers using transact move orders form.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2321637'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2365360	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of menu entry for the movement statistics validation rules form missing.This patch is recommended for customers using oracle inventory and enter movement statistics for intrstat and extrastat declaration.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2365360'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2638248	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of delivery details not getting staged after pick confirm.This patch is recommended for customers using serial controlled items and enter serials in individual format.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2638248'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2600351	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of timeout error in po receipts .This patch is recommended for customers using lot controlled items and use po receipts.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2600351'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2523152	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of inventory suggestions being changed to pending transactions.This patch is recommended for customers using pick release with parameter auto pick confim as no.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2523152'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2452855	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of transactions failing with error ora-1476 (divisor equal to zero) .This patch is recommended for customers using inventory and profile inv, fifo for original receipt date set to yes.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2452855'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2458741	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of transactions form allowing issue of more than available quantity not considering availability across sessions.This patch is recommended for customers using inventory transactions form.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2458741'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2458547	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of reservations form allowing to create reservations without availabile quantity.This patch is recommended for customers using inventory reservations form .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2458547'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2115082	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of orphan reservations after pick confirmation.This fix is recommended for customers using pick release and inventory reservations.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2115082'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2535488	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of deadlocks when inventory workers are running in parallel.This patch is recommended for customers using inventory transaction manager.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2535488'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2757879	</TD>'||chr(10)|| 
'<TD>This patch fixes multiple issues in inventory transaction manager.This patch is recommended for customers using transaction manager.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2757879'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2177946	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of physical adjustments summary form allowing user to change status of approved adjustments causing multiple postings.This patch is recommended for customers using physical inventory.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2177946'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2500570	</TD>'||chr(10)|| 
'<TD>This patch fixes performance issue for pick release and also no_data_found error in pick release.This patch is recommended for customers using pick release.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2500570'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2427778	</TD>'||chr(10)|| 
'<TD>This patch fixes performance issues for pick release and pick confirm process.This patch is recommended for customers using pick release and pick confirm.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2427778'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3017704	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of a user not being able to do po receipt from mobile for serial controlled item. This patch is recommended for customers using serial controlled items in wms organizations</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3017704'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2538686	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of records getting deleted from mtl_transaction_lots_interface .This patch is recommended for customers using transaction open interface for lot controled items.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2538686'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2676507	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of pick release failing with error while creating reservations and delivered quantity not getting updated for internal reqs.This patch is recommended for customers using pick release or internal reqs.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2676507'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2638561	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of internal sales order transactions getting stuck in open interface with no manager error.This patch is recommended for customers using internal orders.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2638561'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2640488	</TD>'||chr(10)|| 
'<TD>This patch is a consolidation of arus for oracle inventory on release 11.5.8.This patch is recommended for customers who applied oracle applications release 11.5.8 Maintenance pack 2293243 or inv.11I h 2248490 .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2640488'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2775431	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of heavy enqueue waits/deadlocks occur when running pick release and inventory transactions form in parallel.This patch is recommended for customers using pick release and inventory transactions form .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2775431'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2706558	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of kits/pto models getting backordered and request hanging when running pick release.This patch is recommended for customers using kits/pto models.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2706558'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2755209	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of hard reservations not getting relieved for sales order issue transactions.This patch is recommended for customers using oracle order management and onhand reservations .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2755209'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2889964	</TD>'||chr(10)|| 
'<TD>This patch fixes multiple issues in inventory transaction manager .This patch is recommended for customers using inventory or wms.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2889964'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2599428	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of serial controlled items getting backordered when running pick release.This patch is recommended for customers using pick release and items are serial controlled.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2599428'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2785075	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of lot genealogy not getting created for workorderless completions.This patch is recommended for customers using workorderless completions and serial genealogy.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2785075'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2803302	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of duplicate physical adjustments getting posted due to profile inv transaction processing mode was set as immediate concurrent.This patch is recommended for customers using physical inventory.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2803302'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2956236	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of unable to receive user defined interorg transfer shipments and duplicate receipts for seeded intransit shipments.This patch is recommended for customers using inter org transfers .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2956236'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3132825	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of different serial numbers being allowed to receive intransit shipments other than those shipped.This patch is recommended for customers using internal orders and items are serial controlled.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3132825'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3173558	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of physical inventory adjustments getting stuck in pending transactions form with adjustments are updated as posted.This patch is recommended for customers using physical inventory and lot controlled items.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3173558'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3191880	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of move order lines attached to delivery details not allowed to get transacted from transact move order form.This patch is recommended for customers using oracle inventory/oracle wms picking.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3191880'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3034348	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of average cost of item set to zero by average cost update transaction.This patch is recommended for customers using average costing method.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3034348'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3557064	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of reservations being ignored when using transaction open interface.This patch is recommended for customers using transaction open interface for issue transactions.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3557064'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2958671	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of the user being unable to perform inter org transfer transactions for user defined transaction source types. This patch is recommended for customers using interorg transfers functionality</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2958671'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3024175	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of the supply/demand form not showing all intransit shipment lines as supply. This patch is recommended for customers using intransit shipments in wms enabled organizations</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3024175'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3044405	</TD>'||chr(10)|| 
'<TD>This patch fixes better online help for inventory profile options on old onhand quantities form.This patch is recommended for customers using project manufacturing .</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3044405'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2983903	</TD>'||chr(10)|| 
'<TD>This patch fixes revised text and illustrations for oracle applications for better online help.This patch is recommended for customers using oracle applications online help and this patch require no downtime.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2983903'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3126043	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of being unable to generate user defined serial numbers through api.This patch is recommended for customers who generate user defined serial numbers through user_pkg_serial api.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3126043'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2971607	</TD>'||chr(10)|| 
'<TD>This patch fixes issue of average cost of item set to zero by average cost update transaction.This patch is recommended for customers using average costing method.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2971607'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2878652	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of incorrect information on shipping labels. This patch is recommended for customers using shipping labels in wms organizations</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2878652'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2835547	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of crossdocking failing. This patch is recommended for customers using crossdocking in wms.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2835547'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2839386	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of data corruption caused by wip component issue transactions. This patch is recommended for customers performing wip transactions in wms organizations</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2839386'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2819040	</TD>'||chr(10)|| 
'<TD>This patches fixes multiple issues with label printing. This patch is recommended for customers using labels in oracle wms</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2819040'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2858824	</TD>'||chr(10)|| 
'<TD>This patch fixes the issue of slow performance of the locator list of values on different screens. This patch is recommended for all customers using oracle wms</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2858824'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2859988	</TD>'||chr(10)|| 
'<TD>This patch contains all the pre-requisite files for label printing. This patch is recommended for customers using label printing in oracle wms</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2859988'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2166329	</TD>'||chr(10)|| 
'<TD>When creating items in child org using item interface,item category assignments for master controlled category set will be created,if such an assignment exists for that item in master organization.Apply this patch,if you use item import.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2166329'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2336117	</TD>'||chr(10)|| 
'<TD>When creating/deleting item category assignments, the creation/deletion does not happen for in child organizations for master controlled category sets. Apply this patch if you use category open interface or item open interface.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2336117'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2623339	</TD>'||chr(10)|| 
'<TD>Item open interface is creating duplicate rows in costing details table,when creating item in average costing organization. Apply this patch, if you use item open interface to load item cost details for average costing organization.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2623339'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2810501	</TD>'||chr(10)|| 
'<TD>Fixes large number of item attribute validations in the folder tab of items form. This patch is recommended for all users.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2810501'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3097969	</TD>'||chr(10)|| 
'<TD>This patch recommended for customers using install base.Prevents updation of ib trackable flag when onhand qty exists for item. Also makes this attribute master controlled.Also enforces the rule serviceable item should be ib trackable</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3097969'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3083217	</TD>'||chr(10)|| 
'<TD>This patch recommended for customers using more than one segment for systems items key flexfield. The item name will be validated correctly to determine uniqueness of items. Also the time taken to validate the data will improve.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3083217'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3597816	</TD>'||chr(10)|| 
'<TD>Inv wrapper to pull in ego checkin 3581871</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3597816'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 3595547	</TD>'||chr(10)|| 
'<TD>Consolidated pts inv requests for 4/27/2004</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3595547'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 3580927	</TD>'||chr(10)|| 
'<TD>Inv wrapper to pull ego 3578797 into dmf patchset.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '3580927'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 1879342	</TD>'||chr(10)|| 
'<TD>Move order trxns are not costed if stock is transferred from another org</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '1879342'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2022598	</TD>'||chr(10)|| 
'<TD>Erp1156install, patch 1960366 errors out in the d driver, file inviusi1.Sql</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2022598'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2429715	</TD>'||chr(10)|| 
'<TD>Allocation doesnt honor the existing reservation and creates excess resv</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2429715'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2679885	</TD>'||chr(10)|| 
'<TD>Allocations do not honour existing reservations - backport</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2679885'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2592468	</TD>'||chr(10)|| 
'<TD>App-fnd-0020 performing receipt for lot controlled item for intransit shipment.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2592468'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2595647	</TD>'||chr(10)|| 
'<TD>Lot translate transactions do not show up in material transactions form</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2595647'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2546592	</TD>'||chr(10)|| 
'<TD>L1156ads, lot geneology is not working for any transactions in flow manufacturin</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2546592'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2592356	</TD>'||chr(10)|| 
'<TD>Lov of lots brings all the available lots in the mobile apps</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2592356'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2536932	</TD>'||chr(10)|| 
'<TD>Inv_move_order_pub.Process_move_order api errors with invalid locator control</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2536932'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2489799	</TD>'||chr(10)|| 
'<TD>Perfgsiap, subinventory form query is doing a full table scan.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2489799'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2541243	</TD>'||chr(10)|| 
'<TD>Item reservations form calculates available quantity incorrectly</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2541243'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2046399	</TD>'||chr(10)|| 
'<TD>Invisdst, no lov for "category set" for functional area "service"</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2046399'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 2116731	</TD>'||chr(10)|| 
'<TD>Incoin not assigning categories correctly in child org </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '2116731'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 10273104 </TD>'||chr(10)|| 
'<TD>Order Management. 31 December 2010, Order Management (11.5.10) Cumulative Patch. </TD>'||chr(10)|| 
'<TD>N/A </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '10273104'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 14498177 </TD>'||chr(10)|| 
'<TD>Order Management. after applying this patch, performance of initialize credit summaries program will improve. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '14498177'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 14538008 </TD>'||chr(10)|| 
'<TD>Order Management. after applying this patch, OE_AUDIT_ATTR_HISTORY table will not have incorrect records. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '14538008'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 17261990 </TD>'||chr(10)|| 
'<TD>WMS. This patch fixes the root cause for multiple issues which prevent LPNs from being Received, Inspected or Putaway and also include Unload functionality for Inbound LPNs. </TD>'||chr(10)|| 
'<TD>N/A </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '17261990'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 10129740 </TD>'||chr(10)|| 
'<TD>WMS. Oracle Warehouse Management System : Release 11.5.10 , Rollup Patch 20 (WMS 11.5.10 RUP20) </TD>'||chr(10)|| 
'<TD>N/A </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '10129740'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 12372608 </TD>'||chr(10)|| 
'<TD>Order Management. After this patch, Order Import Child Request processes the records in the interface tables properly.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '12372608'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 14686283 </TD>'||chr(10)|| 
'<TD>WMS. Interface Trip Stop is erroing with message:For this transaction row the serial records are missing.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '14686283'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 12320502 </TD>'||chr(10)|| 
'<TD>Shipping. In WMS enabled organization, Pick Release fails with error: ORA-01403: no data found.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '12320502'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 7694048 </TD>'||chr(10)|| 
'<TD>Shipping. Patch containing the Exceptions LDT file(WSHXCUTL.ldt), overrides any Exception Definition Settings modified by the user..</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '7694048'
) where :APPS_REL like '11.5.%';

REM R12.0 Critical patches

select * from (select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 6970752 </TD>'||chr(10)|| 
'<TD>This patch fixes the issue of locator being stamped under a subinventory eventhough the subinventory is not locator controlled.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '6970752'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 8650417 </TD>'||chr(10)|| 
'<TD>This patch is recommended for all customers on Release 12.0+ who is using workflow Line Flow - Generic, Bill Only with Inventory Interface. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '8650417'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 8976818 </TD>'||chr(10)|| 
'<TD>Patch fixes the issue of transfer price stamped on the transaction is not correct in case of ISO shipment transactions between OPM organizations belonging to different legal entities.</TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '8976818'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 9341322 </TD>'||chr(10)|| 
'<TD>WMS_RULE packages are not created for Inventory picking rules. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '9341322'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 16911464 </TD>'||chr(10)|| 
'<TD>This patch fixes the root cause for multiple issues which prevent LPNs from being Received, Inspected or Putaway and also include Unload functionality for Inbound LPNs.  </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '16911464'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 17182390 </TD>'||chr(10)|| 
'<TD>Extensions to LPN Unload functionality for WMS mobile. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '17182390'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 8205117 </TD>'||chr(10)|| 
'<TD>Patch containing the Exceptions LDT file(WSHXCUTL.ldt), overrides any Exception Definition Settings modified by the user. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '8205117'
) where :APPS_REL like '12.0.%';

REM R12.1 Critical patches

select * from (select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 14240171 </TD>'||chr(10)|| 
'<TD>In Oracle Inventory,unmarked serial numbers in status 6 are being generated after mobile receiving and it prevent generating the same serial number </TD>'||chr(10)|| 
'<TD>No </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '14240171'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 12596775 </TD>'||chr(10)|| 
'<TD>Receiving INV Intransit Shipments With Mobile Mwa Does not Commit When Transfer </TD>'||chr(10)|| 
'<TD>No </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '12596775'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 12799914 </TD>'||chr(10)|| 
'<TD>Users get "Unexpected Error occurred" on the Mobile GUI application when pressing Next Item </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('12799914', '14611722', '16272776', '17442200', '18081430', '18618946', '19447782', '20187263')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 11816806 </TD>'||chr(10)|| 
'<TD>Tasks intermittently not showing up in wms mobile </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('11816806', '14611722', '16272776', '17442200', '18081430', '18618946', '19447782', '20187263')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 12666693 </TD>'||chr(10)|| 
'<TD>Mobile pick load page wrongly increases picked quantity </TD>'||chr(10)|| 
'<TD>No </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '12666693'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 17868828 </TD>'||chr(10)|| 
'<TD>This patch is created to adress Picking Allocation issues in PJM organizations for all pegging types of Items. </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ( '17868828', '18655199', '19447782', '19447776', '20187263', '20187255')
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 18655199 </TD>'||chr(10)|| 
'<TD>This patch is created to adress Picking Allocation issues in PJM organizations for all pegging types of Items. </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('18655199', '19447782', '19447776', '20187263', '20187255')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 12949295 </TD>'||chr(10)|| 
'<TD>This patch resolves the issue of Movement Statistics showing incorrect invoice information for SO transactions. </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('12949295', '18081430', '18618946', '19447782', '20187263')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 14082325 </TD>'||chr(10)|| 
'<TD>This patch fixes the issue of Movement Statistics Processor creating duplicate records for RMA transactions. </TD>'||chr(10)|| 
'<TD>No </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '14082325'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 20187255 </TD>'||chr(10)|| 
'<TD>Inventory RUP11 (R12.INV.B.delta.11). </TD>'||chr(10)|| 
'<TD>N/A </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '20187255'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 20230847 </TD>'||chr(10)|| 
'<TD>Oracle Inventory Management Recommended Patch Collection (Dec. 2014). </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('20230847')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 9341322 </TD>'||chr(10)|| 
'<TD>WMS_RULE packages are not created for Inventory picking rules. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '9341322'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 9481759 </TD>'||chr(10)|| 
'<TD>This patch is recommended for all customers on Rel 12.1 who is using workflow Line Flow - Generic, Bill Only with Inventory Interface. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '9481759'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 10046974 </TD>'||chr(10)|| 
'<TD>Items. BMCDEL(Item Deletion Group Program) Deleted Sales Order Lines. </TD>'||chr(10)|| 
'<TD>Yes (PIM) </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('10046974', '13385260', '17389256', '16226394', '17795054', '17774755', '19030202')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 20234886 </TD>'||chr(10)|| 
'<TD>Items. Item Master Recommended Patch Collection ( Feb 2015). </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '20234886'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 14350185 </TD>'||chr(10)|| 
'<TD>Order Management. This patch fixes the issue during the split of lines. </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('14350185', '19447776', '18615837', '18076740', '17512558', '14553928', '19447782', '18618946', '18081430', '17442200', '17376133', '20187263', '20187255')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 13582129 </TD>'||chr(10)|| 
'<TD>Order Management. This patch improves the performance of copying of sales order with repricing option. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '13582129'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 14040669 </TD>'||chr(10)|| 
'<TD>Order Management. Applying this patch will ensure that org context is set back to original org context if an Error is encountered when apply Credit Hold on Customer or Customer Site Level. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '14040669'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 20390490 </TD>'||chr(10)|| 
'<TD>ORDER MANAGEMENT 12.1 OCT 2014 CUMULATIVE PATCH. </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '20390490' 
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 7534520 </TD>'||chr(10)|| 
'<TD>Order Management. This patch fixes the issue of interface trip stop failing for an item which is tracked in primary and secondary unit of measures. </TD>'||chr(10)|| 
'<TD>TBD </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '7534520'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 20187263 </TD>'||chr(10)|| 
'<TD>WMS Rollup Patch 11 (R12.WMS.B.delta.11). </TD>'||chr(10)|| 
'<TD>N/A </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '20187263'
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 10082354 </TD>'||chr(10)|| 
'<TD>Shipping. Reservations on the sales order lines are deleted when Interface Trip Stop (OM interface) is submitted. </TD>'||chr(10)|| 
'<TD>Yes (Shipping) </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ( '10082354', '11893915', '19030202', '17774755', '18058537', '17678448', '17376156', '20976856')
UNION
select  
'<TR><TD>CRITICAL </TD>'||chr(10)|| 
'<TD>Patch 15953751 </TD>'||chr(10)|| 
'<TD>Shipping. Interface Trip Stop is erroing with message: For this transaction row the serial records are missing. Issue is happening for a Serial Controlled(At Receipt) Item having qty 1. </TD>'||chr(10)|| 
'<TD>Yes </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('15953751', '19447776', '19447782', '19030202', '18058537', '20187263', '20187255', '20976856')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 13812251 </TD>'||chr(10)|| 
'<TD>Shipping. While scheduling/unscheduling the order line, split delivery details are getting updated with incorrect secondary requested quantities. </TD>'||chr(10)|| 
'<TD>N/A </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '13812251'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 13812257 </TD>'||chr(10)|| 
'<TD>Shipping. While updating the order line, split delivery details are getting updated with incorrect secondary requested quantities. </TD>'||chr(10)|| 
'<TD>N/A </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '13812257'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 14103251 </TD>'||chr(10)|| 
'<TD>Shipping. Region to location mapping program doesnt map a location that has 2 or less character state, with a region that has 2 or less character state code, when state from region and location do not match. </TD>'||chr(10)|| 
'<TD>Yes (Shipping) </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('14103251', '19030202', '17774755', '18058537', '17678448', '17376156', '20976856')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 15845025 </TD>'||chr(10)|| 
'<TD>Shipping. During Inventory Interface for combination of internal order(s) with destination as Inventory and other order(s), records are stuck in Transactions Open Interface with error: Distribution Account is not valid for the given organization. </TD>'||chr(10)|| 
'<TD>Yes (Shipping) </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number IN ('15845025', '18058537', '20976856')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 15943315 </TD>'||chr(10)|| 
'<TD>Shipping. Delivery Details are getting created in ready to released status with requested quantity as 0. </TD>'||chr(10)|| 
'<TD>Yes (Shipping) </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN( '15943315', '18942314', '18262339', '17867969', '17345054', '16963311', '19030202', '17774755', '18058537', '17678448', '17376156', '20976856')
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 20976856 </TD>'||chr(10)|| 
'<TD>Shipping. Oracle Shipping Execution Recommended Patch Collection (Apr. 2015). </TD>'||chr(10)|| 
'<TD>No </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '20976856'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 8205117 </TD>'||chr(10)|| 
'<TD>Shipping. Patch containing the Exceptions LDT file(WSHXCUTL.ldt), overrides any Exception Definition Settings modified by the user. </TD>'||chr(10)|| 
'<TD>N/A </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  = '8205117'
UNION
select  
'<TR><TD>RECOMMENDED </TD>'||chr(10)|| 
'<TD>Patch 9921274 </TD>'||chr(10)|| 
'<TD>Shipping. During Pick Release process, move order header is deleted if delivery lines picked in last batch is ignored. </TD>'||chr(10)|| 
'<TD>Yes (Shipping) </TD>'||chr(10)|| 
decode(count(*), 0, '<TD bgcolor="#FF0000">MISSING</TD>', '<TD>Installed</TD>')||'</TR>'
from ad_bugs
where bug_number  IN ('9921274', '17376156', '17678448', '18058537', '17774755', '19030202', '20976856')
) where :APPS_REL like '12.1.%';

prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *******                   Section 2 : Inventory Administration                   *******
REM ****************************************************************************************

prompt <a name="section2"></a><B><font size="+2">Inventory Administration</font></B><BR><BR>

REM
REM ******* PROFILE SETTINGS *******
REM

prompt <script type="text/javascript">    function displayRows2sql1(){var row = document.getElementById("s2sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv200"></a>
prompt     <B>Profile Settings</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows2sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s2sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          select fpo.profile_option_name, fpovl.USER_PROFILE_OPTION_NAME, <br>
prompt              NVL((select to_char(fpov.PROFILE_OPTION_VALUE) from FND_PROFILE_OPTION_VALUES fpov <BR>
prompt              where fpo.profile_option_id = fpov.profile_option_id), 'Not Set') PROFILE_OPTION_VALUE<br>
prompt          from fnd_profile_options fpo, fnd_profile_options_vl fpovl<br>
prompt          where fpo.profile_option_id = fpovl.profile_option_id<br>
prompt          and fpo.profile_option_name like 'INV_BATCH_SIZE';</P>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PROFILE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>VALUE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SUGGESTION</B></TD>
exec :n := dbms_utility.get_time;

select theURL from 
(select 1 theorder, '<TR><TD>'||fpo.profile_option_name||'</TD>'||chr(10)|| 
'<TD>'||fpovl.USER_PROFILE_OPTION_NAME||'</TD>'||chr(10)|| 
'<TD>'||NVL((select to_char(fpov.PROFILE_OPTION_VALUE) from FND_PROFILE_OPTION_VALUES fpov where fpo.profile_option_id = fpov.profile_option_id), 'Not Set') ||'</TD>'||chr(10)||  
'<TD>If "Not Set", suggest to review setting. See Doc ID 1075935.1.</TD></TR>' theURL
from fnd_profile_options fpo, fnd_profile_options_vl fpovl
where fpo.profile_option_id = fpovl.profile_option_id
and fpo.profile_option_name like 'INV_BATCH_SIZE'
UNION
select 2 theorder, '<TR><TD>'||a.profile_option_name||'</TD>'|| 
'<TD>'||b.USER_PROFILE_OPTION_NAME||'</TD>'|| 
'<TD>'||NVL(DECODE(a.profile_option_name, 'INV_DEBUG_TRACE', DECODE(c.PROFILE_OPTION_VALUE, '1', 'Yes', '2', 'No', c.PROFILE_OPTION_VALUE), c.PROFILE_OPTION_VALUE), 'Not Set')  ||'</TD>'||chr(10)||  
'<TD>Only checking SITE... Be careful with enabling Debug in production. See Doc ID 148651.1 for INV debug details and Doc ID 759359.1 for FND debug.</TD></TR>' theURL
from 
        fnd_profile_options a
        , FND_PROFILE_OPTIONS_VL b
        , FND_PROFILE_OPTION_VALUES c
        , FND_USER d
        , FND_USER e
        , FND_RESPONSIBILITY_VL g
        , FND_APPLICATION h
where 
            a.profile_option_name IN ('AFLOG_ENABLED', 'INV_DEBUG_TRACE', 'INV_DEBUG_FILE', 'INV_DEBUG_LEVEL')
        and c.level_id = 10001 -- 'Site'
        and a.profile_option_name = b.profile_option_name
        and a.profile_option_id = c.profile_option_id
        and a.application_id = c.application_id
        and c.last_updated_by = d.user_id (+)
        and c.level_value = e.user_id (+)
        and c.level_value = g.responsibility_id (+)
        and c.level_value = h.application_id (+)
UNION
select 3 theorder, '<TR><TD>'||fpo.profile_option_name||'</TD>'|| 
'<TD>'||fpovl.USER_PROFILE_OPTION_NAME||'</TD>'|| 
'<TD>'||NVL((select to_char(DECODE(fpov.PROFILE_OPTION_VALUE, '1', 'Yes', '2', 'No', fpov.PROFILE_OPTION_VALUE)) from FND_PROFILE_OPTION_VALUES fpov where fpo.profile_option_id = fpov.profile_option_id), 'Not Set')   ||'</TD>'||chr(10)||  
'<TD>In R12.x, consider if you want material status enabled via this profile. See Doc ID 828934.1 or the user guide.</TD></TR>' theURL
from fnd_profile_options fpo, fnd_profile_options_vl fpovl
where fpo.profile_option_id = fpovl.profile_option_id
and :APPS_REL like '12.%'
and fpo.profile_option_name like 'INV_MATERIAL_STATUS') a
order by a.theorder; 

prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* ORG SETUP *******
REM

prompt <script type="text/javascript">    function displayRows2sql1(){var row = document.getElementById("s2sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv201"></a>
prompt     <B>Inventory Settings</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows2sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s2sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          TBD<br>
prompt          ...;</P>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>AREA</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>COUNT</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>COMMENT</B></TD>
exec :n := dbms_utility.get_time;
select org_summary.therow from (select 1 theorder, '<TR><TD>Organization</TD>'||chr(10)|| 
'<TD>Warehouse Management (WMS)</TD>'||chr(10)|| 
'<TD>'||count(*) ||'</TD><TD> ... </TD></TR>' therow
from mtl_parameters mp
where mp.wms_enabled_flag = 'Y'
UNION
select 2 theorder, '<TR><TD>Organization</TD>'||chr(10)|| 
'<TD>Project Manufacturing (PJM)</TD>'||chr(10)|| 
'<TD>'||count(*) ||'</TD><TD> ... </TD></TR>' therow
from mtl_parameters mp
where mp.PROJECT_REFERENCE_ENABLED = 1
UNION
select 3 theorder, '<TR><TD>Organization</TD>'||chr(10)|| 
'<TD>Negative Balance Allowed</TD>'||chr(10)|| 
'<TD>'||count(*) ||'</TD><TD> ... </TD></TR>' therow
from mtl_parameters mp
where mp.NEGATIVE_INV_RECEIPT_CODE = 1
UNION
select 4 theorder, '<TR><TD>Organization</TD>'||chr(10)|| 
'<TD>Total</TD>'||chr(10)|| 
'<TD>'||count(*) ||'</TD><TD> ... </TD></TR>' therow
from mtl_parameters mp) org_summary
order by org_summary.theorder;
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM
REM ******* TRANSACTION SUMMARY *******
REM
exec :n := dbms_utility.get_time;

prompt <script type="text/javascript">    function displayRows2sql3(){var row = document.getElementById("s2sql3");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv202"></a>
prompt     <B>Unprocessed Transaction Summary</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows2sql3()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s2sql3" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="6" height="60">
prompt       <blockquote><p align="left">
prompt          TBD<br>
prompt          ...;</P>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TABLE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ERRORS</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PROCESSING</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TOTAL</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>COMMENT</B></TD>
prompt </TR>

exec :n := dbms_utility.get_time;
select trans_summary.therow from (
select 1 theorder, 
'<TR><TD>Transaction Open Interface</TD>'|| 
'<TD>MTL_TRANSACTIONS_INTERFACE</TD>'|| 
'<TD>'||NVL(sum(decode(PROCESS_FLAG, 3, 1, 0)),0) || -- Errors
'</TD><TD>'||NVL(sum(decode(PROCESS_FLAG, 1, 1, 0)),0) || -- Processing
'</TD><TD>'||count(*) || -- Total
'</TD><TD> Interface records may be custom or relate standard processes like sales orders.</TD></TR>' therow
from mtl_transactions_interface 
UNION
select 2 theorder, 
'<TR><TD>Pending Transactions</TD>'|| 
'<TD>MTL_MATERIAL_TRANSACTIONS_TEMP</TD>'|| 
'</TD><TD>'||NVL(sum(decode(PROCESS_FLAG, 'E', 1, 0)),0) || -- Errors
'</TD><TD>'||NVL(sum(decode(PROCESS_FLAG, 'Y', 1, 0)),0) || -- Processing
'</TD><TD>'||count(*) || -- Total
'</TD><TD> Pending transactions will prevent period close.</TD></TR>' therow
from mtl_material_transactions_temp
UNION
select 3 theorder, 
'<TR><TD>Uncosted Transactions</TD>'|| 
'<TD>MTL_MATERIAL_TRANSACTIONS</TD>'|| 
'<TD>'||NVL(sum(decode(COSTED_FLAG, 'E', 1, 0)),0) || -- Errors
'</TD><TD>'||NVL(sum(decode(COSTED_FLAG, 'N', 1, 0)),0) || -- Processing
'</TD><TD>'||count(*) || -- Total
'</TD><TD> Uncosted transactions will prevent period close.</TD></TR>' therow
from mtl_material_transactions 
where costed_flag IN ('N', 'E')
) trans_summary
order by trans_summary.theorder;

prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM END of INV Admin section

REM **************************************************************************************** 
REM *******                   Section 3 : Common Data Issues                         *******
REM ****************************************************************************************

REM
REM ******* Top 20+ Inventory Data Issues *******
REM

prompt <a name="section3"></a><B><font size="+2">Data Issues</font></B><BR><BR>
exec :n := dbms_utility.get_time;

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody><font size="-1" face="Calibri"><tr><td><p>
prompt Note: For an index of the common data issues in invenotory, see Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=568012.1" target="_blank">568012.1</A>. 
prompt Many of these data issues have fixes available for you to download 
prompt and apply directly from a note. The note is listed where available in the table below. 
prompt The notes also list root-cause patches to avoid the issue. 
prompt If you can replicate the corruption after the patches, please log a new service request (SR).<BR>
prompt </p></font></td></tr></tbody>
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows3sql1(){var row = document.getElementById("s3sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv300"></a>
prompt     <B>Common Data Issues</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows3sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s3sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          Various SQL scripts... <br>
prompt          (At this point not listing each SQL. See the related identification script for more details.)</P>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NUM</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TOPIC</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>IDENTIFY SCRIPT</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ISSUE?</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NOTES</B></TD>

REM
REM ******* 1. MOQD Mismatch *******
REM

SELECT 
'<TR><TD>1</TD><TD>MOQD Mismatch</TD>'||chr(10)|| 
'<TD>mmt_moqd_mismatch_at_sublevel.sql</TD>'||chr(10)|| 
'<TD>N/A</TD>'||chr(10)|| 
'<TD>Temporarily disabled. Running too slow... '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=279205.1" target="_blank">279205.1</A> for more details.'||
'</TD></TR>'
from dual;

REM SELECT 
REM  '<TR><TD>1</TD><TD>MOQD Mismatch</TD>'||chr(10)|| 
REM  '<TD>'||'mmt_moqd_mismatch_at_sublevel.sql'||'</TD>'||chr(10)|| 
REM  decode(count(TXN.inventory_item_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
REM  '<TD>If Yes, then onhand mismatches exist. </TD></TR>' -- '<TD>'||'Organizations: '||count(distinct TXN.organization_id) ||', Items: '|| count(distinct TXN.inventory_item_id) ||', Difference: '|| sum(TXN.mmt_qty - NVL(ONHAND.qty,0)) ||'</TD></TR>'
REM  FROM 
REM        (SELECT mmt.organization_id, mmt.inventory_item_id, 
REM                 mmt.subinventory_code, sum(mmt.primary_quantity) mmt_qty 
REM         FROM mtl_material_transactions mmt, 
REM              mtl_secondary_inventories mse 
REM         WHERE mse.organization_id=mmt.organization_id 
REM           AND mse.secondary_inventory_name=mmt.subinventory_code 
REM           AND mse.quantity_tracked=1 
REM           AND mmt.transaction_action_id not in (5,6,24,30,50,51,52,55,26,7,11,17,10,9,13,14)
REM           AND mmt.lpn_id is null AND mmt.transfer_lpn_id is null 
REM           AND mmt.content_lpn_id is null 
REM           GROUP BY mmt.organization_id, mmt.inventory_item_id, 
REM                    mmt.subinventory_code) TXN, 
REM         (SELECT moq.organization_id, moq.inventory_item_id, 
REM             moq.subinventory_code, sum(moq.primary_transaction_quantity) qty 
REM          FROM  mtl_onhand_quantities_detail moq, 
REM                mtl_secondary_inventories mse 
REM         WHERE moq.organization_id=mse.organization_id 
REM           AND mse.secondary_inventory_name=moq.subinventory_code 
REM           AND mse.quantity_tracked=1 
REM           AND nvl(moq.containerized_flag,2) = 2 
REM           GROUP BY moq.organization_id, moq.inventory_item_id, 
REM                    moq.subinventory_code) ONHAND 
REM           WHERE TXN.inventory_item_id = ONHAND.inventory_item_id (+) 
REM            AND TXN.organization_id   = ONHAND.organization_id (+) 
REM            AND TXN.subinventory_code = ONHAND.subinventory_code (+) 
REM            AND abs(TXN.mmt_qty - NVL(ONHAND.qty,0)) > 0 
REM            AND exists (select 1 from mtl_parameters 
REM                        where organization_id = TXN.organization_id 
REM                        and wms_enabled_flag = 'N') 
REM  		and rownum = 1
REM          group by 'MOQD Mismatch', 'mmt_moqd_mismatch_at_sublevel.sql';
REM  

REM
REM ******* 2. Closed move orders *******
REM

SELECT 
'<TR><TD>2</TD><TD>Closed Move Orders</TD>'||chr(10)|| 
'<TD>ClosedMO.sql</TD>'||chr(10)|| 
decode(count(mtrh.request_number), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, then one or more move closed move orders exist. '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1471929.1" target="_blank">1471929.1</A> for more details including an identify script, root-cause patches, and datafix.'||
'</TD></TR>' -- '<TD> Move Orders: '|| count(distinct mtrh.request_number) ||', Quantity: '||NVL(sum(mtrl.quantity),0) ||'</TD></TR>'
from    mtl_txn_request_lines MTRL ,
        mtl_txn_request_headers MTRH,
        wsh_Delivery_Details wdd,
        oe_order_lines_All oel
where   wdd.released_Status = 'S'
and     wdd.move_order_line_id = mtrl.line_id 
and     wdd.move_order_line_id is not null
and     wdd.source_line_id  = mtrl.txn_source_line_id 
and     mtrh.header_id = mtrl.header_id
and     oel.line_id = wdd.source_line_id 
and     wdd.source_code = 'OE'
and     mtrl.line_Status = 5 
and     not exists (
          select 'x' from mtl_material_transactions  mmt
          where  mmt.move_order_line_id = mtrl.line_id and 
                 mmt.move_order_line_id is not null  ) 
and rownum = 1;

REM
REM ******* 3. Missing Move Order: N/A *******
REM
SELECT 
'<TR><TD>3</TD><TD>Missing Move Order</TD>'||chr(10)|| 
'<TD>Missing Move Orders</TD>'||chr(10)|| 
'<TD>N/A</TD>'||chr(10)|| 
'<TD>Not applicable - script is no longer needed. '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=301524.1" target="_blank">301524.1</A> for details.'||
'</TD></TR>'
from dual;

REM
REM ******* 4. Marked serial numbers *******
REM

SELECT 
'<TR><TD>4</TD><TD>Marked serial numbers</TD>'||chr(10)|| 
'<TD>Identify_SerialMark.sql/Identify_SerialTemp_Orphans</TD>'||chr(10)|| 
decode(count(msntotal.serial_number), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, then orphan serials exist. '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1472005.1" target="_blank">1472005.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' from
(select msn.serial_number
FROM mtl_serial_numbers msn
WHERE(msn.group_mark_id IS NOT NULL
 AND msn.group_mark_id <> -1)
 AND NOT EXISTS
  (SELECT 1
   FROM mtl_serial_numbers_temp msnt
   WHERE msn.group_mark_id = msnt.transaction_temp_id OR msn.group_mark_id = msnt.group_header_id)
AND NOT EXISTS
  (SELECT 1
   FROM wsh_delivery_details wdd
   WHERE wdd.inv_interfaced_flag <> 'Y'
   AND wdd.released_status IN('Y',    'C')
   AND wdd.transaction_temp_id IS NOT NULL
   AND msn.group_mark_id = wdd.transaction_temp_id)
AND NOT EXISTS
  (SELECT 1
   FROM wsh_delivery_details wdd
   WHERE wdd.inv_interfaced_flag <> 'Y'
   AND wdd.released_status IN('Y',    'C')
   AND msn.inventory_item_id = wdd.inventory_item_id
   AND msn.serial_number = wdd.serial_number)
AND NOT EXISTS
  (SELECT 1
   FROM mtl_cycle_count_entries mcce
   WHERE mcce.cycle_count_header_id = msn.group_mark_id
   AND mcce.cycle_count_entry_id = msn.line_mark_id
   AND mcce.entry_status_code IN(1,    2))
and rownum = 1
UNION
SELECT msnt.fm_serial_number
FROM mtl_serial_numbers_temp msnt
    WHERE   NOT EXISTS (SELECT 1 FROM mtl_material_transactions_temp mmtt
    WHERE  mmtt.transaction_temp_id = msnt.transaction_temp_id)
    AND     NOT EXISTS (SELECT 1 FROM MTL_TRANSACTION_LOTS_TEMP mtlt
    WHERE  mtlt.SERIAL_TRANSACTION_TEMP_ID = msnt.transaction_temp_id)
    AND     NOT EXISTS (SELECT 1 FROM wsh_delivery_details wdd
    WHERE  wdd.transaction_temp_id IS NOT NULL
    AND    wdd.transaction_temp_id = msnt.transaction_temp_id
    AND    wdd.released_status in ('Y','C')
    AND    wdd.inv_interfaced_flag <> 'Y')
    AND     NOT EXISTS (SELECT 1 FROM rcv_transactions_interface rti
    WHERE  interface_transaction_id = msnt.transaction_temp_id)
and rownum = 1
) msntotal;

REM
REM ******* 5. Serial number with leading/trailing spaces *******
REM
SELECT 
'<TR><TD>5</TD><TD>Serial number with leading/trailing spaces</TD>'||chr(10)|| 
'<TD>identify.sql</TD>'||chr(10)|| 
decode(count(serial_number), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, then leading/training spaces exist.'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1376548.1" target="_blank">1376548.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from mtl_serial_numbers 
where length(serial_number) != length(trim(serial_number))
and rownum = 1;

REM
REM ******* 6. Lot number with leading/trailing spaces *******
REM
SELECT 
'<TR><TD>6</TD><TD>Lot number with leading/trailing spaces</TD>'||chr(10)|| 
'<TD>lot_identify_issue.sql</TD>'||chr(10)|| 
decode(count(lot_number), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, then leading/training spaces exist.'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1451566.1" target="_blank">1451566.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from mtl_lot_numbers
where lot_number<> ltrim(rtrim(lot_number))
and rownum = 1;

REM
REM ******* 7. Corrupted Onhand related to Lots *******
REM
SELECT 
'<TR><TD>7</TD><TD>Corrupted Onhand related to Lots</TD>'||chr(10)|| 
'<TD>Is_itemlotcontrl_moqdnolot_per_org.sql / Is_itemnolot_moqdlot.sql</TD>'||chr(10)|| 
decode(count(moqall.inventory_item_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, then leading/training spaces exist.'||'</TD></TR>' 
from (
select moq.inventory_item_id
from inv.mtl_onhand_quantities_detail moq,inv.mtl_system_items_b msi
where moq.organization_id = msi.organization_id
and moq.inventory_item_id = msi.inventory_item_id
and msi.LOT_CONTROL_CODE = 2
and moq.LOT_NUMBER IS NULL
and nvl(moq.containerized_flag,2) = 2
and project_id is null
and rownum = 1
UNION
select moq.inventory_item_id
from inv.mtl_onhand_quantities_detail moq,inv.mtl_system_items_b msi
where moq.organization_id = msi.organization_id
and moq.inventory_item_id = msi.inventory_item_id
and msi.LOT_CONTROL_CODE = 1
and moq.LOT_NUMBER IS NOT NULL
and nvl(moq.containerized_flag,2) = 2
and project_id is null
and rownum = 1) moqall
;

REM
REM ******* 8. Physical Inventory Adjustment Errors *******
REM
SELECT 
'<TR><TD>8</TD><TD>Physical Inventory Adjustment Errors</TD>'||chr(10)|| 
'<TD>N/A</TD>'||chr(10)|| 
'<TD>N/A</TD>' ||chr(10)|| 
'<TD>No identification script here but see physical inventory error out.</TD></TR>' 
from dual;

REM
REM ******* 9. Sales Order reservations created with Zero demand header *******
REM
SELECT 
'<TR><TD>9</TD><TD>Sales Order reservations created with Zero demand header</TD>'||chr(10)|| 
'<TD>Is_rsv_0_header_id.sql</TD>'||chr(10)|| 
decode(count(demand_all.ID), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, one or more reservations maybe corrupt.'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1471942.1" target="_blank">1471942.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from 
(SELECT MR.RESERVATION_ID ID
FROM  MTL_RESERVATIONS MR
WHERE DEMAND_SOURCE_TYPE_ID IN (2,8)
  AND NVL(DEMAND_SOURCE_HEADER_ID, 0) = 0
  AND SUPPLY_SOURCE_TYPE_ID = 13
  AND ROWNUM = 1
UNION
SELECT MD.DEMAND_ID ID
FROM  MTL_DEMAND MD
WHERE DEMAND_SOURCE_TYPE IN (2,8)
  AND NVL(DEMAND_SOURCE_HEADER_ID, 0) = 0
  AND NVL(SUPPLY_SOURCE_TYPE, 13) = 13
  AND ROWNUM = 1) demand_all;

REM
REM ******* 10. Error while costing Material transactions *******
REM
SELECT 
'<TR><TD>10</TD><TD>Error while costing Material transactions</TD>'||chr(10)|| 
'<TD>N/A</TD>'||chr(10)|| 
'<TD>N/A</TD>' ||chr(10)|| 
'<TD>No identification script here yet. '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=428403.1" target="_blank">428403.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from dual;

REM
REM ******* 11. Incorrect Demand header id *******
REM
SELECT 
'<TR><TD>11</TD><TD>Incorrect Demand header id</TD>'||chr(10)|| 
'<TD>is_incorrect_demand.sql</TD>'||chr(10)|| 
decode(count(reservation_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, the demand header id is incorrect.'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1471944.1" target="_blank">1471944.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from mtl_reservations
where demand_source_type_id in (2,8)
and (nvl(demand_source_header_id,0) = 0
or demand_source_header_id not in
(select sales_order_id from mtl_sales_orders))
and rownum = 1;

REM
REM ******* 12. Onhand records with locator populated when sub inventory is not locator controlled *******
REM
SELECT 
'<TR><TD>12</TD><TD>Onhand records with locator populated when sub inventory is not locator controlled</TD>'||chr(10)|| 
'<TD>SQL from bug 4264580</TD>'||chr(10)|| 
decode(count(moqd.inventory_item_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, onhand with locator is populated incorrectly.'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=282480.1" target="_blank">282480.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from mtl_onhand_quantities_detail moqd
where locator_id is not null
and exists (select 1 from mtl_secondary_inventories msi
                   where msi.secondary_inventory_name =
moqd.subinventory_code
                   and   msi.organization_id = moqd.organization_id
                   and   msi.locator_type = 1)
and exists (select 1 from mtl_parameters
                    where organization_id = moqd.organization_id
                     and  STOCK_LOCATOR_CONTROL_CODE in (1, 4)
                     and  wms_enabled_flag = 'N')
and exists (select 1 from mtl_system_items msit
                      where msit.organization_id = moqd.organization_id
                      and   msit.inventory_item_id = moqd.inventory_item_id
                      and   msit.serial_number_control_code in (1, 6) )
and rownum = 1;

 
REM
REM ******* 13. Locator stamped on onhand record is different from the one existing in mtl_item_locations for the subinventory *******
REM
SELECT 
'<TR><TD>13</TD><TD>Locator stamped on onhand record is different from the one existing in mtl_item_locations for the subinventory</TD>'||chr(10)|| 
'<TD>SQL from bug 4264604</TD>'||chr(10)|| 
decode(count(moqd.inventory_item_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, locator is incorrect.'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=282480.1" target="_blank">282480.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from mtl_onhand_quantities_detail moqd
where moqd.locator_id is not null
and not exists (select 1 from mtl_item_locations mil
			   where mil.organization_id = moqd.organization_id
			   and  mil.subinventory_code = moqd.subinventory_code
			   and  mil.inventory_location_id = moqd.locator_id)
and exists (select 1 from mtl_secondary_inventories
		   where secondary_inventory_name = moqd.subinventory_code
		   and   organization_id = moqd.organization_id
		   and   locator_type in (2, 3) )
and exists (select 1 from mtl_parameters
		   where organization_id = moqd.organization_id
		   and  STOCK_LOCATOR_CONTROL_CODE = 4
		   and  wms_enabled_flag = 'N')
and exists (select 1 from mtl_system_items msit
		   where msit.organization_id = moqd.organization_id
		   and   msit.inventory_item_id = moqd.inventory_item_id
		   and   msit.serial_number_control_code in (1, 6) )
and rownum = 1;


REM
REM ******* 14. Onhand have records with Null Locator when Sub inventory is locator controlled *******
REM
SELECT 
'<TR><TD>14</TD><TD>Onhand have records with Null Locator when Sub inventory is locator controlled</TD>'||chr(10)|| 
'<TD>SQL from bug 4264563</TD>'||chr(10)|| 
decode(count(moqd.inventory_item_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, locator is expected but not present.'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=282480.1" target="_blank">282480.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from mtl_onhand_quantities_detail moqd
where locator_id is null
and exists (select 1 from mtl_secondary_inventories msi
               where msi.secondary_inventory_name = moqd.subinventory_code
               and  msi.organization_id = moqd.organization_id
               and  msi.locator_type in (2,3) )
and exists (select 1 from mtl_parameters
               where organization_id = moqd.organization_id
               and  STOCK_LOCATOR_CONTROL_CODE = 4
               and  wms_enabled_flag = 'N')
               and exists (select 1 from mtl_system_items msit
               where msit.organization_id = moqd.organization_id
               and  msit.inventory_item_id = moqd.inventory_item_id
               and  msit.serial_number_control_code in (1, 6) )
and rownum = 1;

REM
REM ******* 15. Update Standard Costs fails with Invalid value for intransit_owning_org_id in table MTL_SUPPLY *******
REM
SELECT 
'<TR><TD>15</TD><TD>Update Standard Costs fails with Invalid value for intransit_owning_org_id in table MTL_SUPPLY</TD>'||chr(10)|| 
'<TD>SQL from bug 4234883</TD>'||chr(10)|| 
decode(count(ms.SUPPLY_TYPE_CODE), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, the owning organization is incorrect in the supply.'||
'</TD></TR>' 
from mtl_supply MS
 WHERE EXISTS
          (SELECT 1
          FROM  rcv_shipment_headers RSH
          WHERE  MS.shipment_header_id = RSH.shipment_header_id
          AND    RSH.receipt_source_code in ('INVENTORY', 'INTERNAL ORDER')
          )
  AND NOT EXISTS
          (SELECT 1
          FROM  mtl_parameters MP
          WHERE  MP.organization_id = MS.intransit_owning_org_id)
and rownum = 1;

REM
REM ******* 16. Stuck transaction with Error occurred while relieving reservations  *******
REM
SELECT 
'<TR><TD>16</TD><TD>Stuck transaction with Error occurred while relieving reservations</TD>'||chr(10)|| 
'<TD>SQL from bug 4286036</TD>'||chr(10)|| 
'<TD>N/A</TD>' ||chr(10)|| 
'<TD>No identification script here. '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1471606.1" target="_blank">1471606.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from dual;

REM
REM ******* 17. Duplicate transactions in MTI already posted in MMTT and MMT and in MMTT already posted into MMT *******
REM
SELECT 
'<TR><TD>17</TD><TD>Duplicate MTI/MMTT/MMT</TD>'||chr(10)|| 
'<TD>identify.sql</TD>'||chr(10)|| 
decode(count(dups_all.inventory_item_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>If yes, duplicate transactions may need to be removed. '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1472074.1" target="_blank">1472074.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from (
select a.inventory_item_id from
mtl_material_transactions_temp b, mtl_transactions_interface a
where a.picking_line_id = b.picking_line_id
and a.trx_source_line_id = b.trx_source_line_id
and a.inventory_item_id = b.inventory_item_id
and b.transaction_type_id = a.transaction_type_id
and b.transaction_source_type_id in (2,8)
and b.picking_line_id is not null 
and rownum = 1
UNION
select a.inventory_item_id from
mtl_material_transactions b, mtl_material_transactions_temp a
where a.picking_line_id = b.picking_line_id
and a.trx_source_line_id = b.trx_source_line_id
and a.inventory_item_id = b.inventory_item_id
and b.transaction_type_id = a.transaction_type_id
and b.transaction_source_type_id in ( 2,8)
and b.picking_line_id is not null
and rownum = 1
UNION
select a.inventory_item_id from
mtl_material_transactions b, mtl_transactions_interface a
where a.picking_line_id = b.picking_line_id
and a.trx_source_line_id = b.trx_source_line_id
and a.inventory_item_id = b.inventory_item_id
and b.transaction_type_id = a.transaction_type_id
and b.transaction_source_type_id in (2,8)
and b.picking_line_id is not null 
and rownum = 1) dups_all;


REM
REM ******* 18. View material transactions screen raise error APP-FND-00756:CANNOT FIND COMBINATION CCID  *******
REM
SELECT 
'<TR><TD>18</TD><TD>View material transactions screen raise error APP-FND-00756</TD>'||chr(10)|| 
'<TD>SQL from bug 5008181</TD>'||chr(10)|| 
decode(count(mmt_all.transaction_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1471880.1" target="_blank">1471880.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
from (
select transaction_id from mtl_material_transactions
where transaction_source_type_id = 8
and transaction_id in (
select transfer_transaction_id from mtl_material_transactions
where transaction_Source_type_id=8 and transaction_action_id=2
and transaction_type_id=50 and primary_quantity < 0)
and rownum = 1
UNION
select transaction_id from mtl_material_transactions
where transaction_source_type_id=8 and transaction_quantity >0
and transaction_action_id in (3,12) and not exists(select 1 from
mtl_sales_orders where sales_order_id=transaction_source_id)
and rownum = 1) mmt_all; 

REM
REM ******* 19. Negative TRANSACTION_SOURCE_ID *******
REM
SELECT 
'<TR><TD>19</TD><TD>Negative TRANSACTION_SOURCE_ID</TD>'||chr(10)|| 
'<TD>identify.sql</TD>'||chr(10)|| 
decode(count(mmt.transaction_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>'||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1471862.1" target="_blank">1471862.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
FROM mtl_material_transactions MMT
WHERE transaction_source_id < 0
AND rownum = 1;

REM
REM ******* 20. CST_INVALID_INTERORG Error while costing Material transactions *******
REM
SELECT 
'<TR><TD>20</TD><TD>CST_INVALID_INTERORG Error while costing Material transactions</TD>'||chr(10)|| 
'<TD>identify.sql</TD>'||chr(10)|| 
decode(count(mmt.transaction_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>') ||chr(10)|| 
'<TD>Can cause costing errors. '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1461380.1" target="_blank">1461380.1</A> for identify script, root-cause patches, and datafix.'||
'</TD></TR>' 
FROM mtl_material_transactions MMT ,   MTL_TRANSACTION_TYPES MTT
WHERE 
         mmt.TRANSACTION_SOURCE_TYPE_ID IN (7,13)
     AND mmt.TRANSACTION_ACTION_ID =12
     AND mmt.FOB_POINT =2
     AND mmt.costed_flag = 'E'
	 AND (mmt.ERROR_EXPLANATION LIKE '%CST_INVALID_INTERORG%' or mmt.ERROR_CODE LIKE '%CST_INVALID_INTERORG%')
     AND MMT.TRANSFER_ORGANIZATION_ID = MMT.organization_id
     AND MMT.TRANSACTION_TYPE_ID = MTT.TRANSACTION_TYPE_ID
	 AND rownum = 1;

REM
REM ******* 21. Sales Order Issue transaction missing in MTI and MMT for a drop ship PO receipt and Sales Order line Shipped Qty not updated  *******
REM
SELECT 
'<TR><TD>21</TD><TD>Sales Order Issue transaction missing in MTI and MMT for a drop ship PO receipt and Sales Order line Shipped Qty not updated</TD>'||chr(10)|| 
'<TD>SQL from bug 4286036</TD>'||chr(10)|| 
'<TD>N/A</TD>' ||chr(10)|| 
'<TD>No identification script here. '||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=568012.1" target="_blank">568012.1</A> #21 for identify script'||
'</TD></TR>' 
from dual;

prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM End of INV datafixes

REM
REM ******* WIP Data Issues *******
REM

exec :n := dbms_utility.get_time;

prompt <script type="text/javascript">    function displayRows3sql2(){var row = document.getElementById("s3sql2");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv301"></a>
prompt     <B>WIP Common Data Issues</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows3sql2()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s3sql2" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          Various SQL scripts... <br>
prompt          (At this point not listing each SQL. See the related identification script for more details.)</P>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NUM</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TOPIC</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>IDENTIFY SCRIPT</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ISSUE?</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NOTES</B></TD>
prompt </TR>

REM
REM ******* 1. Duplicate WIP : Process *******
REM
SELECT 
'<TR><TD>1</TD><TD>Duplicate WIP Pending Issue Transactions for Process (OPM)</TD>'|| 
'<TD>INV1073279_1-ident.sql</TD>'||chr(10)||  
decode(count(a.transaction_temp_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>')  ||chr(10)||
'<TD>These MIGHT be duplicates but they could be over-completions. ' ||chr(10)||
'Confirm with users. See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1073279.1" target="_blank">1073279.1</A> for identify script and root-cause patches. '  ||chr(10)||
'An Sr is needed for a datafix.'||
'</TD></TR>' 
from (select mmtt.transaction_temp_id 
FROM mtl_material_transactions_temp mmtt, gme_batch_header gbh, mtl_parameters mp
WHERE mmtt.transaction_source_type_id = 5
AND mmtt.transaction_type_id = 35
AND mp.organization_id = mmtt.organization_id
AND mp.process_enabled_flag = 'Y'
AND gbh.batch_id = mmtt.transaction_source_id
AND gbh.organization_id = mmtt.organization_id
AND EXISTS (
	SELECT 1
	FROM gme_material_details gmm     --wip_requirement_operations  wro
	WHERE gmm.batch_id = mmtt.transaction_source_id
	AND gmm.inventory_item_id = mmtt.inventory_item_id
	AND gmm.organization_id = mmtt.organization_id
	AND gmm.actual_qty = nvl(wip_plan_qty,plan_qty))
AND EXISTS (
	SELECT 1
	FROM mtl_material_transactions mmt
	WHERE mmt.transaction_source_id = mmtt.transaction_source_id
	AND mmt.organization_id = mmtt.organization_id
	AND mmt.inventory_item_id = mmtt.inventory_item_id
	AND mmt.transaction_type_id = 35)
  AND rownum = 1) a;

REM
REM ******* 2. Duplicate WIP : Discrete Issue *******
REM
SELECT 
'<TR><TD>2</TD><TD>Duplicate WIP Pending Issue Transactions for Discrete</TD>'|| 
'<TD>INV1073279_1-ident.sql</TD>'|| 
decode(count(a.transaction_temp_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>')  ||chr(10)||
'<TD>These MIGHT be duplicates but they could be over-completions. '  ||chr(10)||
'Confirm with users. See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1073279.1" target="_blank">1073279.1</A> for identify script and root-cause patches. '  ||chr(10)||
'An Sr is needed for a datafix.'  ||chr(10)||
'</TD></TR>' 
from (select mmtt.transaction_temp_id 
FROM mtl_material_transactions_temp mmtt, wip_entities we, mtl_parameters mp
WHERE mmtt.transaction_source_type_id = 5
AND mmtt.transaction_type_id = 35
AND mp.organization_id = mmtt.organization_id
AND mp.process_enabled_flag = 'N'
AND we.wip_entity_id = mmtt.transaction_source_id
AND we.organization_id = mmtt.organization_id
AND EXISTS
	(SELECT 1
	FROM wip_requirement_operations wro
	WHERE wro.wip_entity_id = mmtt.transaction_source_id
	AND wro.inventory_item_id = mmtt.inventory_item_id
	AND wro.organization_id = mmtt.organization_id
	AND wro.operation_seq_num = mmtt.operation_seq_num
	AND wro.quantity_issued = wro.required_quantity)
AND EXISTS
	(SELECT 1
	FROM mtl_material_transactions mmt
	WHERE mmt.transaction_source_id = mmtt.transaction_source_id
	AND mmt.organization_id = mmtt.organization_id
	AND mmt.inventory_item_id = mmtt.inventory_item_id
	AND mmt.operation_seq_num = mmtt.operation_seq_num
	AND mmt.transaction_type_id = 35)
  AND rownum = 1) a;

REM
REM ******* 3. Duplicate WIP : Assembly Completions *******
REM
SELECT 
'<TR><TD>3</TD><TD>Duplicate WIP Pending Assembly Completion Transactions for Discrete</TD>'|| 
'<TD>INV1073279_1-ident.sql</TD>'|| 
decode(count(a.transaction_temp_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>')  ||chr(10)||
'<TD>These MIGHT be duplicates but they could be over-completions. '  ||chr(10)||
'Confirm with users. See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1073279.1" target="_blank">1073279.1</A> for identify script and root-cause patches. '  ||chr(10)||
'An Sr is needed for a datafix.'  ||chr(10)||
'</TD></TR>' 
from (select mmtt.transaction_temp_id 
FROM mtl_material_transactions_temp mmtt, wip_entities we, mtl_parameters mp
WHERE mmtt.transaction_source_type_id = 5
AND mmtt.transaction_type_id = 44
AND mp.organization_id = mmtt.organization_id
AND we.wip_entity_id = mmtt.transaction_source_id
AND we.organization_id = mmtt.organization_id
AND EXISTS
	(SELECT 1
	FROM wip_discrete_jobs wdj
	WHERE wdj.wip_entity_id = mmtt.transaction_source_id
	AND wdj.primary_item_id = mmtt.inventory_item_id
	AND wdj.organization_id = mmtt.organization_id
	AND (NVL(wdj.start_quantity,0) - NVL(quantity_completed,0) - NVL(quantity_scrapped,0) - NVL(mmtt.transaction_quantity,0)) <= 0)
AND EXISTS
	(SELECT 1
	FROM mtl_material_transactions mmt
	WHERE mmt.transaction_source_id = mmtt.transaction_source_id
	AND mmt.organization_id = mmtt.organization_id
	AND mmt.inventory_item_id = mmtt.inventory_item_id
	AND mmt.transaction_type_id = 44)
	AND rownum = 1) a;

prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM End of WIP datafixes

REM
REM ******* Costing Data Issues *******
REM

exec :n := dbms_utility.get_time;

prompt <script type="text/javascript">    function displayRows3sql3(){var row = document.getElementById("s3sql3");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv302"></a>
prompt     <B>Costing Common Data Issues</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows3sql3()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s3sql3" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          Various SQL scripts... <br>
prompt          (At this point not listing each SQL. See the related identification script for more details.)</P>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NUM</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TOPIC</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>IDENTIFY SCRIPT</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ISSUE?</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NOTES</B></TD>
prompt </TR>

REM
REM ******* 1. CST_MATCH_DATE_PERIOD *******
REM
SELECT 
'<TR><TD>1</TD><TD>CST_MATCH_DATE_PERIOD Error while costing Material transactions</TD>'  ||chr(10)||
'<TD>TBD</TD>'  ||chr(10)||
decode(count(mmt.transaction_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>')  ||chr(10)||
'<TD>Indicates a costing error. '  ||chr(10)||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1376394.1" target="_blank">1376394.1</A> for root-cause patch.'  ||chr(10)||
'</TD></TR>' 
FROM mtl_material_transactions MMT ,   MTL_TRANSACTION_TYPES MTT
WHERE 
      mmt.costed_flag = 'E'
	 AND (mmt.ERROR_EXPLANATION LIKE '%CST_MATCH_DATE_PERIOD%' or mmt.ERROR_CODE LIKE '%CST_MATCH_DATE_PERIOD%')
     AND MMT.TRANSFER_ORGANIZATION_ID = MMT.organization_id
     AND MMT.TRANSACTION_TYPE_ID = MTT.TRANSACTION_TYPE_ID
	 AND rownum = 1;

REM
REM ******* 2. CST_MATCH_TXFR_CG_ORG *******
REM
SELECT 
'<TR><TD>2</TD><TD>CST_MATCH_TXFR_CG_ORG Error while costing Material transactions</TD>'  ||chr(10)||
'<TD>TBD</TD>'  ||chr(10)||
decode(count(mmt.transaction_id), 0, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>')  ||chr(10)||
'<TD>Indicates a costing error. ' ||chr(10)||
'See Doc ID <A href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=453138.1" target="_blank">453138.1</A> for root-cause patch.'  ||chr(10)||
'</TD></TR>' 
FROM mtl_material_transactions MMT ,   MTL_TRANSACTION_TYPES MTT
WHERE 
      mmt.costed_flag = 'E'
	 AND (mmt.ERROR_EXPLANATION LIKE '%CST_MATCH_TXFR_CG_ORG%' or mmt.ERROR_CODE LIKE '%CST_MATCH_TXFR_CG_ORG%')
     AND MMT.TRANSFER_ORGANIZATION_ID = MMT.organization_id
     AND MMT.TRANSACTION_TYPE_ID = MTT.TRANSACTION_TYPE_ID
	 AND rownum = 1;

prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM End of COSTING datafixes
REM End of datafixes



REM **************************************************************************************** 
REM *******                   Section 4 : Performance                                *******
REM ****************************************************************************************

prompt <a name="section4"></a><B><font size="+2">Performance</font></B><BR><BR>

prompt <script type="text/javascript">    function displayRows4sql1(){var row = document.getElementById("s4sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri"><a name="inv400"></a>
prompt     <B>Performance</B></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s4sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="7" height="60">
prompt       <blockquote><p align="left">
prompt          SELECT decode( GREATEST(LAST_ANALYZED, (sysdate-30)), LAST_ANALYZED, 'NO', 'YES') <br>
prompt          FROM dba_tables c<br>
prompt          where table_name IN ('MTL_TXN_REQUEST_LINES', 'MTL_MATERIAL_TRANSACTIONS', 'MTL_SYSTEM_ITEMS_B', 'MTL_DEMAND', 'MTL_RESERVATIONS');</p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>TABLE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>LAST ANALYZED</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ROWS</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SAMPLE %</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ANALYZE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PURGE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NOTES</B></TD>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||table_name||'</TD>'||chr(10)|| 
'<TD>'||LAST_ANALYZED||'</TD>'||chr(10)|| 
'<TD>'||to_char(num_rows, '999G999G999G999G990')||'</TD>'||chr(10)|| 
'<TD>'||decode(num_rows, 0, 0, round(SAMPLE_SIZE/num_rows*100,0))||'</TD>'||chr(10)|| 
decode( GREATEST(LAST_ANALYZED, (sysdate-30)), LAST_ANALYZED, '<TD>NO</TD>', '<TD bgcolor="#FF0000">ISSUE</TD>')||chr(10)|| 
decode( table_name, 'MTL_TXN_REQUEST_LINES', decode(GREATEST(num_rows, 1000000), num_rows, '<TD bgcolor="#FF0000">ISSUE</TD>', '<TD>NO</TD>'), '<TD>NO</TD>')||chr(10)|| 
'<TD>Analyze and gather statistics at least weekly.</TD></TR>'
from dba_tables c
where table_name IN ('MTL_TXN_REQUEST_LINES', 'MTL_MATERIAL_TRANSACTIONS', 'MTL_SYSTEM_ITEMS_B', 'MTL_DEMAND', 'MTL_RESERVATIONS');
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM **************************************************************************************** 
REM *******                   Section 5 : References                                 *******
REM ****************************************************************************************

prompt <a name="section5"></a><B><font size="+2">References</font></B><BR><BR>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody><font size="-1" face="Calibri"><tr><td><p>   

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=335.1" target="_blank">
prompt Doc ID 335.1</a> - Period Close Advisor: E-Business Suite (EBS)<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=432.1" target="_blank">
prompt Doc ID 432.1</a> - Oracle Premier Support: Get Proactive! <br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=148651.1" target="_blank">
prompt Doc ID 148651.1</a> - INV DEBUG: How to get Debug Information for Inventory Material Transactions<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=146961.1" target="_blank">
prompt Doc ID 146961.1</a> - FAQ: Poor Performance for Inventory Transactions : Worker, Interface Transactions, Serial Numbers<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=414470.1" target="_blank">
prompt Doc ID 414470.1</a> - How To Determine the Product Information Management (PIM) Patchset and Rollup Patch Version<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=568012.1" target="_blank">
prompt Doc ID 568012.1</a> - FAQ: Inventory Standard Datafixes<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=601639.1" target="_blank">
prompt Doc ID 601639.1</a> - Generic Receiving Datafix Scripts and Root Cause Patches<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=726226.1" target="_blank">
prompt Doc ID 726226.1</a> - INV/WMS/RCV Family Patch Release History / Patchsets / RUPs<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1116887.1" target="_blank">
prompt Doc ID 1116887.1</a> - Critical E-Business Suite11i (11.5.10) Extended Support Information on Minimum Baseline Patch Requirements<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1290983.1" target="_blank">
prompt Doc ID 1290983.1</a> - Oracle Inventory, Product Information Management and Warehouse Management Teams Informational Webcast Series<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1295001.1" target="_blank">
prompt Doc ID 1295001.1</a> - FAQ: Item And PIM (APC/PLM) Standard Datafixes<br>
prompt <br>

prompt <a href="https://support.oracle.com/CSP/main/article?cmd=show\&type=NOT\&id=1366049.1" target="_blank">
prompt Doc ID 1366049.1</a> - Oracle EBS Logistics (INV/WMS/RCV) Product Information Center (PIC)<br>
prompt <br>

prompt My Oracle Support - <a href="https://community.oracle.com/community/support/oracle_e-business_suite/logistics" target="_blank">
prompt Logistics Community</a><br>

prompt </p></font></td></tr></tbody>
prompt </table><BR><BR>
prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *******                   Section 6 : Feedback                                   *******
REM ****************************************************************************************

prompt <a name="section6"></a><B><font size="+2">Feedback</font></B><BR><BR>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody><font size="-1" face="Calibri"><tr><td><p>
prompt <B>Still have questions?</B><BR>
prompt Click <a href="https://community.oracle.com/message/12265254" target="_blank">here</a> to provide FEEDBACK 
prompt for the <font color="#FF0000"><b><font size="+1">Inventory Analyzer Tool</font></b></font>,  
prompt and offer suggestions, improvements, or ideas to make this proactive script more useful.<br>
prompt <font color="#FF0000"><b><font size="+1">- OR -</font></b></font><br>
prompt Click <a href="https://community.oracle.com/community/support/oracle_e-business_suite/logistics" target="_blank">here</a> 
prompt to access the <font color="#FF0000"><b><font size="+1">Oracle Logistics Community</font></b></font> on My Oracle Support and 
prompt search for solutions or post new questions about Logistics.<br>
prompt As always, you can email the author directly <A HREF="mailto:james.phipps@oracle.com?subject=%20Inventory%20Analyzer%20Feedback
prompt \&body=Please attach a copy of your INV Analyzer output">here</A>.<BR>
prompt Be sure to include the output of the script for review.<BR>
prompt </p></font></td></tr></tbody>
prompt </table><BR><BR>

prompt <BR><A href="#top"><font size="-1">Back to Top</font></A><BR><BR>
prompt </blockquote>

begin
select to_char(sysdate,'hh24:mi:ss') into :et_time from dual;
end;
/

declare
	st_hr1 varchar2(10);
	st_mi1 varchar2(10);
	st_ss1 varchar2(10);
	et_hr1 varchar2(10);
	et_mi1 varchar2(10);
	et_ss1 varchar2(10);
	hr_fact varchar2(10);
	mi_fact varchar2(10);
	ss_fact varchar2(10);
begin
	dbms_output.put_line('<br>PL/SQL Script was started at:'||:st_time);
	dbms_output.put_line('<br>PL/SQL Script is complete at:'||:et_time);
	st_hr1 := substr(:st_time,1,2);
	st_mi1 := substr(:st_time,4,2);
	st_ss1 := substr(:st_time,7,2);
	et_hr1 := substr(:et_time,1,2);
	et_mi1 := substr(:et_time,4,2);
	et_ss1 := substr(:et_time,7,2);

	if et_hr1 >= st_hr1 then
		hr_fact := to_number(et_hr1) - to_number(st_hr1);
	else
		hr_fact := to_number(et_hr1+24) - to_number(st_hr1);
	end if;
	if et_ss1 >= st_ss1 then
		mi_fact := to_number(et_mi1) - to_number(st_mi1);
		ss_fact := to_number(et_ss1) - to_number(st_ss1);
	else
		mi_fact := (to_number(et_mi1) - to_number(st_mi1))-1;
		ss_fact := (to_number(et_ss1)+60) - to_number(st_ss1);
	end if;
	dbms_output.put_line('<br><br>Total time taken to complete the script: '||hr_fact||' Hrs '||mi_fact||' Mins '||ss_fact||' Secs');
end;
/


spool off
set heading on
set feedback on  
set verify on
exit;
