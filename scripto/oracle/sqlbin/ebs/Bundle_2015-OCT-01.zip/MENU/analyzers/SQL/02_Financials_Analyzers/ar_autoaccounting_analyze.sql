REM $Id: ar_autoaccounting_analyze.sql, 200.1 2015/08/07 11:55:15 vcrisost Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ar_autoaccounting_analyze.sql                                        |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit ar_autoaccounting_analyze_pkg.main             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 07-Aug-2015 vcrisost Created                                            |
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Oracle Receivables AutoAccounting Analyzer
REM
REM MENU_START
REM
REM SQL: Run Oracle Receivables AutoAccounting Analyzer
REM FNDLOAD: Load Oracle Receivables AutoAccounting Analyzer
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  Oracle Receivables AutoAccounting Analyzer [Doc ID: 1904785.1]
REM
REM  Compatible with: [12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package ar_autoaccounting_analyze_pkg.main as APPS to create an HTML report 
REM
REM    (2) Install Oracle Receivables AutoAccounting Analyzer as a concurrent program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group Payables Reports Only
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: AR_TOP
REM DEF_REQ_GROUP: Receivables All
REM PROG_NAME: ARAUTOACC
REM PROG_TEMPLATE: arautoacc.ldt
REM APP_NAME: Receivables
REM PROD_SHORT_NAME: AR
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ar_autoacc_objects.sql
REM ar_autoaccounting_analyzer.sql 
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END




SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "~"

PROMPT
-- PSD #1
PROMPT Submitting AR AutoAccounting Analyzer
PROMPT ===========================================================================
PROMPT Enter the org_id for the operating unit.  This parameter is required.
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 1 NUMBER DEFAULT -1 -
       PROMPT 'Enter the org_id(required): '

PROMPT
PROMPT ===========================================================================
PROMPT Enter account type with missing segment. This parameter is required.  
PROMPT Valid values are REC or REV or OFFSET 
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 2 CHAR -
       PROMPT 'Enter Account Type(required): '

PROMPT
PROMPT ===========================================================================
PROMPT Enter the missing segment number. This parameter is required.
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 3 NUMBER DEFAULT -1 -
       PROMPT 'Enter missing segment number(required): '
PROMPT

PROMPT ===========================================================================
PROMPT Enter the location of the error. This parameter is required.
PROMPT Valid values are AUTOINV or TRXFORM
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 4 CHAR -
       PROMPT 'Enter location of error(required) AUTOINV or TRXFORM: '

PROMPT       
PROMPT ===========================================================================
PROMPT Enter the ID of the transaction with error. This parameter is required.
PROMPT If error is in Transaction Form this is the CUSTOMER_TRX_ID
PROMPT If error is in AutoInvoice this is the INTERFACE_LINE_ID
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 5 NUMBER DEFAULT -1 -
       PROMPT 'Enter CUSTOMER_TRX_ID or INTERFACE_LINE_ID: '
PROMPT


DECLARE
-- PSD #3
  l_org_id         NUMBER := '~1';
  l_account_type   VARCHAR2(10) := '~2';
  l_missing_seg    NUMBER := '~3';
  l_where          VARCHAR2(25) := '~4';
  l_id             NUMBER := '~5';

BEGIN

-- PSD #4
  ar_autoaccounting_analyzer_pkg.main(
      p_org_id => l_org_id,
	    p_account_type_in => l_account_type,
      p_missing_seg => l_missing_seg,
      p_where => l_where,
      p_id => l_id );

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit; 
