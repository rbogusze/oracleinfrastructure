SET DEFINE '~'
WHENEVER SQLERROR EXIT

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.27                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    iby_fd_analyzer.sql                                                  |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+

declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,2);
    
 -- Validation to verify analyzer is run on proper e-Business application version
 -- So will fail before package is created
 if apps_version < '12' then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'             ***');
    dbms_output.put_line('*** This Analyzer script must run in version 12 or above    ***');
    dbms_output.put_line('*** Note: the error below is intentional                    ***');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness Version 12 or higher');
 end if;

END;
/

-- PSD #1
CREATE OR REPLACE PACKAGE iby_fd_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-- PSD #10

PROCEDURE main 
(            p_org_id                       IN VARCHAR2    DEFAULT NULL
           ,p_ppr_name                     IN VARCHAR2    DEFAULT NULL
           ,p_inv_num_1                    IN VARCHAR2    DEFAULT NULL
           ,p_check_id                     IN VARCHAR2    DEFAULT NULL
           ,p_from_date                    IN DATE        DEFAULT sysdate-90
           ,p_max_output_rows              IN NUMBER      DEFAULT 50
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')
;

-- PSD #16	  
PROCEDURE main_cp (
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
           ,p_org_id                       IN VARCHAR2    DEFAULT NULL
           ,p_ppr_name                     IN VARCHAR2    DEFAULT NULL
           ,p_inv_num_1                    IN VARCHAR2    DEFAULT NULL
           ,p_check_id                     IN VARCHAR2    DEFAULT NULL
           ,p_from_date                    IN VARCHAR2    DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 50
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y'
);

-- PSD #1
END iby_fd_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY iby_fd_analyzer_pkg AS
-- PSD #1a
-- $Id: iby_fd_analyzer.sql, 200.11 2015/08/28 09:49:24 ARNAL.ROBERT Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #15  
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1587455.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'IBYFD_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'IBYFD_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>IBYFD Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {

  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1587455.1:IBYANALYZER">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/iby_latest_ver.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
		 
		 -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
	   -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;

       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;			
			
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended Patches
-------------------------

FUNCTION check_rec_patches_1 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_1');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20289581';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.1: Payments Recommended Patch Collection (IBY RPC), FEB 2015';
   l_col_rows(5)(1) := '1481221.1';

   l_col_rows(1)(2) := '20178770';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.1: Payables Recommended Patch (Core AP) Collection (AP RPC), FEB 2015';
   l_col_rows(5)(2) := '1397581.1';

   l_col_rows(1)(3) := '20178740';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.1: Payables Recommended Patch Collection (ISP), FEB 2015';
   l_col_rows(5)(3) := '1397581.1';

   l_col_rows(1)(4) := '20178726';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.1: Payables Recommended Patch Collection (WF/PCARD), FEB 2015';
   l_col_rows(5)(4) := '1397581.1';

   l_col_rows(1)(5) := '16983427';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'ViewObject attribute is null'' Error Trying To Submit Payment Process Request';
   l_col_rows(5)(5) := '1481246.1';

   l_col_rows(1)(6) := '20042161';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.1: EBusiness Tax Recommended Patch Collection (ZX RPC), FEB 2015';
   l_col_rows(5)(6) := '1481235.1';

   l_col_rows(1)(7) := '16234039';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'Oracle Payments PPR Termination Enhancement Patch';
   l_col_rows(5)(7) := '1543611.1';

   l_col_rows(1)(8) := '16804401';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'Oracle Payments Enhanced Error Message Patch';
   l_col_rows(5)(8) := '1910230.1';

   l_col_rows(1)(9) := '20175470';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'R12.1: Subledger Accounting Recommended Patch Collection (SLA RPC), FEB 2015';
   l_col_rows(5)(9) := '1481222.1';

END IF;

   l_sig.title := 'Recommended Patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Some recommended patches were not applied in this instance.';
   l_sig.solution := '<ul>
	<li>Please review list above by clicking on arrow and schedule to apply any unappplied patches as soon as possible</li>
	<li>Refer to the note indicated for more information about each patch</li>
</ul>
';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'check_rec_patches',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_1');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_1 at step '||l_step);
  raise;
END check_rec_patches_1;

FUNCTION check_rec_patches_2 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_2');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '4495174';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.XDO.A included in patch:4461237 R12.ATG_PF.A';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '5907579';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.XDO.A.delta.1 included in patch:5907545 R12.ATG_PF.A.delta.1';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '5917336';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.XDO.A.delta.2 included in patch:5917344 R12.ATG_PF.A.delta.2';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '6077632';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.XDO.A.delta.3 included in patch:6077669 R12.ATG_PF.A.delta.3';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '6354146';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.XDO.A.delta.4 included in patch:6272680 R12.ATG_PF.A.delta.4';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '7237308';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.XDO.A.delta.6 included in patch:7237006 R12.ATG_PF.A.delta.6';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '6594787';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'R12.XDO.A.delta.5 included in patch:6594849 R12.ATG_PF.A.delta.5';
   l_col_rows(5)(7) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '7310274';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.XDO.B.delta.1 included in patch:7307198 R12.ATG_PF.B.delta.1';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '6430103';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.XDO.B included in patch:6430106 R12.ATG_PF.B';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '7651160';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.XDO.B.delta.2 included in patch:7651091 R12.ATG_PF.B.delta.2';
   l_col_rows(5)(3) := '';

END IF;

   l_sig.title := 'BI Publisher Integration - Recommended Patchsets';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Check if any of the recommended patchsets were not applied in this instance';
   l_sig.solution := '<ul><li>Please review list above and schedule to apply any unapplied patchsets as soon as possible</li>
    <li>Please note that XDO fixes are not released as standalone patchsets. Instead they are bundled in to ATG Family Packs</li>
    <li>Refer to the note indicated for more information about each patchset</li>
    <li>For additional details on available patches for XML embedded in EBS, refer to [1138602.1] </li></ul>';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'check_xdo_patchsets',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_2');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_2 at step '||l_step);
  raise;
END check_rec_patches_2;

FUNCTION check_rec_patches_3 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_3');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '9851616';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.XDO.A 1OFF:9752717:12.1.1:Accented Characters (French) Are Not Appearing Correctly in Bursting Email Body';
   l_col_rows(5)(1) := '1138602.1';

   l_col_rows(1)(2) := '13116125';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'AR: JOURNAL ENTRIES REPORT PERFORMANCE PROBLEM';
   l_col_rows(5)(2) := '1138602.1';

   l_col_rows(1)(3) := '9450112';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.XDO.A Sales Journal By GL Account Report (XML) -Incorrect GL Dates Displayed';
   l_col_rows(5)(3) := '1138602.1';

   l_col_rows(1)(4) := '9197676';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.XDO.A Backport:9113190:5.6.3:12.0.4:Field Alignment Of Justify Not Working When PDF Output';
   l_col_rows(5)(4) := '1138602.1';

   l_col_rows(1)(5) := '9003873';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.XDO.A XDO_CURRENCY_FORMAT_SETS_PKG.ADD_LANGUAGE Fails';
   l_col_rows(5)(5) := '1138602.1';

   l_col_rows(1)(6) := '8869321';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.XDO.A Error - Privatekey Is Not Supported - When Transmitting Payment File To Back';
   l_col_rows(5)(6) := '1138602.1';

   l_col_rows(1)(7) := '8793202';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'R12.XDO.A Need Ability To Chose To Ignore Invalid Characters Or Not Ignore';
   l_col_rows(5)(7) := '1138602.1';

   l_col_rows(1)(8) := '8745414';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'R12.XDO.A Total By Page In The RTF Layout To Be Printed In Words';
   l_col_rows(5)(8) := '1138602.1';

   l_col_rows(1)(9) := '8359991';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'R12.XDO.A An XDO Property To Enable Debug Logging';
   l_col_rows(5)(9) := '1138602.1';

   l_col_rows(1)(10) := '7274371';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'R12.XDO.A eText Update For XML Publisher 5.6.3';
   l_col_rows(5)(10) := '1138602.1';

   l_col_rows(1)(11) := '6900153';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'PERFORMANCE ISSUE IN AP REPORTS USING SLA DATATEMPLATE XLAJELINESRPT.XML';
   l_col_rows(5)(11) := '1138602.1';

   l_col_rows(1)(12) := '7425840';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := 'P_FETCH_FROM_GL PARAMETER NEEDS TO BE ADDED TO GLOBAL JOURNAL LEDGER REPORT';
   l_col_rows(5)(12) := '1138602.1';

   l_col_rows(1)(13) := '7209522';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := 'REPLACE THE RTF TEMPLATE FOR ACCOUNT ANALYSIS REPORT, SUBLEDGER ACCOUNTING';
   l_col_rows(5)(13) := '1138602.1';

   l_col_rows(1)(14) := '14004181';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := 'R12.XDO.A The Concurrent Completed With Warning Status If Repeating Field Have Value';
   l_col_rows(5)(14) := '1138602.1';

   l_col_rows(1)(15) := '13791540';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := 'R12.XDO.A Override Template Locale In TemplateHelper.processTemplate';
   l_col_rows(5)(15) := '1138602.1';

   l_col_rows(1)(16) := '13146709';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := 'R12.XDO.A TemplateHelper Produces A Garbled Output When Invoked By Multiple Threads';
   l_col_rows(5)(16) := '1138602.1';

   l_col_rows(1)(17) := '12382509';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := 'R12.XDO.A Program Calls XDODTEXE, errors - java.lang.NumberFormatException: For input string';
   l_col_rows(5)(17) := '1138602.1';

   l_col_rows(1)(18) := '10432202';
   l_col_rows(2)(18) := 'No';
   l_col_rows(3)(18) := NULL;
   l_col_rows(4)(18) := 'R12.XDO.A Base bug 10377266 : Backport request for oracle.xdo.template.formprocessor';
   l_col_rows(5)(18) := '1138602.1';

   l_col_rows(1)(19) := '10405679';
   l_col_rows(2)(19) := 'No';
   l_col_rows(3)(19) := NULL;
   l_col_rows(4)(19) := 'R12.XDO.A XML Publisher Limitation Of 2^31 On Concurrent Program Parameters';
   l_col_rows(5)(19) := '1138602.1';

   l_col_rows(1)(20) := '10065439';
   l_col_rows(2)(20) := 'No';
   l_col_rows(3)(20) := NULL;
   l_col_rows(4)(20) := 'R12.XDO.A API TemplateHelper.processTemplate Takes Long Time - Performance';
   l_col_rows(5)(20) := '1138602.1';

   l_col_rows(1)(21) := '14013094';
   l_col_rows(2)(21) := 'No';
   l_col_rows(3)(21) := NULL;
   l_col_rows(4)(21) := 'DB Patch: PARTITION ORDER IN INDEX DEFINITION IS DIFFERENT THAN TABLE PARTITION';
   l_col_rows(5)(21) := '1138602.1';

   l_col_rows(1)(22) := '7163158';
   l_col_rows(2)(22) := 'No';
   l_col_rows(3)(22) := NULL;
   l_col_rows(4)(22) := 'PAYABLES POSTED INVOICE REGISTER REPORT IS SHOWING INFO FOR BOTH LEDGERS';
   l_col_rows(5)(22) := '1138602.1';

   l_col_rows(1)(23) := '12609107';
   l_col_rows(2)(23) := 'No';
   l_col_rows(3)(23) := NULL;
   l_col_rows(4)(23) := 'PERFORMANCE OF THE GLOBAL JOURNAL LEDGER REPORT (JLSLAJNLLG)';
   l_col_rows(5)(23) := '1138602.1';

   l_col_rows(1)(24) := '8815942';
   l_col_rows(2)(24) := 'No';
   l_col_rows(3)(24) := NULL;
   l_col_rows(4)(24) := 'CFIX: JOURNAL ENTRY REPORT (XLAJELINESRPT) PERFORMANCE PROBLEM';
   l_col_rows(5)(24) := '1138602.1';

   l_col_rows(1)(25) := '9011171';
   l_col_rows(2)(25) := 'No';
   l_col_rows(3)(25) := NULL;
   l_col_rows(4)(25) := 'R12.1.1: SLOW PERFORMANCE WITH ACCOUNT ANALYSIS REPORT';
   l_col_rows(5)(25) := '1138602.1';

   l_col_rows(1)(26) := '8397147';
   l_col_rows(2)(26) := 'No';
   l_col_rows(3)(26) := NULL;
   l_col_rows(4)(26) := 'R12 - (AP) ACCOUNT ANALYSIS REPORT PERFORMANCE ISSUES';
   l_col_rows(5)(26) := '1138602.1';

   l_col_rows(1)(27) := '9501440';
   l_col_rows(2)(27) := 'No';
   l_col_rows(3)(27) := NULL;
   l_col_rows(4)(27) := 'R12.XDO.A Field Mappings Are Not Mapped In The Final Output When Reports Are Bursted Using PDF Template';
   l_col_rows(5)(27) := '1138602.1';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '13019389';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.FND.B Provides Integrated Support For Bursting';
   l_col_rows(5)(1) := '1138602.1';

   l_col_rows(1)(2) := '13116125';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'AR: JOURNAL ENTRIES REPORT PERFORMANCE PROBLEM';
   l_col_rows(5)(2) := '1138602.1';

   l_col_rows(1)(3) := '8397147';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12 - (AP) ACCOUNT ANALYSIS REPORT PERFORMANCE ISSUES';
   l_col_rows(5)(3) := '1138602.1';

   l_col_rows(1)(4) := '9011171';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.1.1: SLOW PERFORMANCE WITH ACCOUNT ANALYSIS REPORT';
   l_col_rows(5)(4) := '1138602.1';

   l_col_rows(1)(5) := '8815942';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'CFIX: JOURNAL ENTRY REPORT (XLAJELINESRPT) PERFORMANCE PROBLEM';
   l_col_rows(5)(5) := '1138602.1';

   l_col_rows(1)(6) := '12609107';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'PERFORMANCE OF THE GLOBAL JOURNAL LEDGER REPORT (JLSLAJNLLG)';
   l_col_rows(5)(6) := '1138602.1';

   l_col_rows(1)(7) := '12778226';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'R12.FND.B R12.1.3 Delivery Manager Sends Emailed PDFs As DAT Files';
   l_col_rows(5)(7) := '1138602.1';

   l_col_rows(1)(8) := '7687414';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'R12.TXK.B Rehosting xdoparser 10.1.0.5 With Fix For Bug 7586025 and 7339075';
   l_col_rows(5)(8) := '1138602.1';

   l_col_rows(1)(9) := '16729676';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'R12.XDO.B Set Timestamp Which Is Different From SYSDATE In Date Field In Digital Signature';
   l_col_rows(5)(9) := '1138602.1';

   l_col_rows(1)(10) := '15971443';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'R12.XDO.B E-Business Suite Limitation: PDF PDF/A Compliance';
   l_col_rows(5)(10) := '1138602.1';

   l_col_rows(1)(11) := '15837304';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'R12.XDO.B BI Publisher Doesnot Support PDFs Higher Than 1.4 Version';
   l_col_rows(5)(11) := '1138602.1';

   l_col_rows(1)(12) := '10432202';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := 'R12.XDO.B Base bug 10377266 : Backport request for oracle.xdo.template.formprocessor';
   l_col_rows(5)(12) := '1138602.1';

   l_col_rows(1)(13) := '10405679';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := 'R12.XDO.B XML Publisher Limitation Of 2^31 On Concurrent Program Parameters';
   l_col_rows(5)(13) := '1138602.1';

   l_col_rows(1)(14) := '10106579';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := 'R12.XDO.B XDO_OUTPUT_TYPE_LOOKUP Value Set Does Not Have XLS Validation';
   l_col_rows(5)(14) := '1138602.1';

   l_col_rows(1)(15) := '10065439';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := 'R12.XDO.B API TemplateHelper.processTemplate Takes Long Time - Performance';
   l_col_rows(5)(15) := '1138602.1';

   l_col_rows(1)(16) := '9501440';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := 'R12.XDO.B Field Mappings Are Not Mapped In The Final Output When Reports Are Bursted Using PDF Template';
   l_col_rows(5)(16) := '1138602.1';

   l_col_rows(1)(17) := '9440398';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := 'R12.XDO.B Backport:8248764:RUP6:11.5.10:Support Rendering BarCode 128 Font';
   l_col_rows(5)(17) := '1138602.1';

   l_col_rows(1)(18) := '9050393';
   l_col_rows(2)(18) := 'No';
   l_col_rows(3)(18) := NULL;
   l_col_rows(4)(18) := 'R12.XDO.B ER: Add Ability To Increment Dates in eText Layouts';
   l_col_rows(5)(18) := '1138602.1';

   l_col_rows(1)(19) := '9003873';
   l_col_rows(2)(19) := 'No';
   l_col_rows(3)(19) := NULL;
   l_col_rows(4)(19) := 'R12.XDO.B XDO_CURRENCY_FORMAT_SETS_PKG.ADD_LANGUAGE Fails';
   l_col_rows(5)(19) := '1138602.1';

   l_col_rows(1)(20) := '8869321';
   l_col_rows(2)(20) := 'No';
   l_col_rows(3)(20) := NULL;
   l_col_rows(4)(20) := 'R12.XDO.B Error - Privatekey Is Not Supported - When Transmitting Payment File To Back';
   l_col_rows(5)(20) := '1138602.1';

   l_col_rows(1)(21) := '16049151';
   l_col_rows(2)(21) := 'No';
   l_col_rows(3)(21) := NULL;
   l_col_rows(4)(21) := 'R12.XDO.B Corrupted File Bursted When Signature-Page-Index Is Set To Page That Not Exists';
   l_col_rows(5)(21) := '1138602.1';

   l_col_rows(1)(22) := '14764296';
   l_col_rows(2)(22) := 'No';
   l_col_rows(3)(22) := NULL;
   l_col_rows(4)(22) := 'R12.XDO.B Payment File Transmission Fails While Using SFTP File Transmission - Over 64 kB';
   l_col_rows(5)(22) := '1138602.1';

   l_col_rows(1)(23) := '14735894';
   l_col_rows(2)(23) := 'No';
   l_col_rows(3)(23) := NULL;
   l_col_rows(4)(23) := 'R12.XDO.B Generate Payroll XDO Report Produces Long Log Files With XDO Debug Messages';
   l_col_rows(5)(23) := '1138602.1';

   l_col_rows(1)(24) := '14541121';
   l_col_rows(2)(24) := 'No';
   l_col_rows(3)(24) := NULL;
   l_col_rows(4)(24) := 'R12.XDO.B iSetup Migration Of Multiple XML Template Files Fails Due To Java Error';
   l_col_rows(5)(24) := '1138602.1';

   l_col_rows(1)(25) := '14004181';
   l_col_rows(2)(25) := 'No';
   l_col_rows(3)(25) := NULL;
   l_col_rows(4)(25) := 'R12.XDO.B The Concurrent Completed With Warning Status If Repeating Field Have Value';
   l_col_rows(5)(25) := '1138602.1';

   l_col_rows(1)(26) := '13256309';
   l_col_rows(2)(26) := 'No';
   l_col_rows(3)(26) := NULL;
   l_col_rows(4)(26) := 'R12.XDO.B 1OFF:7588317:12.1.3:12.1.3:Table Of Content Always In The Same Font';
   l_col_rows(5)(26) := '1138602.1';

   l_col_rows(1)(27) := '13791540';
   l_col_rows(2)(27) := 'No';
   l_col_rows(3)(27) := NULL;
   l_col_rows(4)(27) := 'R12.XDO.B Override Template Locale In TemplateHelper.processTemplate';
   l_col_rows(5)(27) := '1138602.1';

   l_col_rows(1)(28) := '12575514';
   l_col_rows(2)(28) := 'No';
   l_col_rows(3)(28) := NULL;
   l_col_rows(4)(28) := 'R12.XDO.B 1OFF:9070963:FND.:12.1.3:Max-Height Is Not Propaged Into Inner Table';
   l_col_rows(5)(28) := '1138602.1';

   l_col_rows(1)(29) := '12826648';
   l_col_rows(2)(29) := 'No';
   l_col_rows(3)(29) := NULL;
   l_col_rows(4)(29) := 'R12.XDO.B 1OFF:12662816:FND.:5.6.3:Large Height Value In HTML Output Due To Inner Table';
   l_col_rows(5)(29) := '1138602.1';

   l_col_rows(1)(30) := '12686113';
   l_col_rows(2)(30) := 'No';
   l_col_rows(3)(30) := NULL;
   l_col_rows(4)(30) := 'R12.XDO.B XML Pub Bursting Report Appears As An Attachment In Outlook Rather Than Body';
   l_col_rows(5)(30) := '1138602.1';

   l_col_rows(1)(31) := '12415414';
   l_col_rows(2)(31) := 'No';
   l_col_rows(3)(31) := NULL;
   l_col_rows(4)(31) := 'R12.XDO.B 1OFF:11873050:12.1.3: FRM-41830, FRM-40212 Submitting Program - Publisher FSG';
   l_col_rows(5)(31) := '1138602.1';

   l_col_rows(1)(32) := '14013094';
   l_col_rows(2)(32) := 'No';
   l_col_rows(3)(32) := NULL;
   l_col_rows(4)(32) := 'DB Patch: PARTITION ORDER IN INDEX DEFINITION IS DIFFERENT THAN TABLE PARTITION';
   l_col_rows(5)(32) := '1138602.1';

   l_col_rows(1)(33) := '10146280';
   l_col_rows(2)(33) := 'No';
   l_col_rows(3)(33) := NULL;
   l_col_rows(4)(33) := 'R12.XDO.B SaxParser Support For Handling Invalid Characters In CDATA';
   l_col_rows(5)(33) := '1138602.1';

   l_col_rows(1)(34) := '12382509';
   l_col_rows(2)(34) := 'No';
   l_col_rows(3)(34) := NULL;
   l_col_rows(4)(34) := 'R12.XDO.B Program Calls XDODTEXE, errors - java.lang.NumberFormatException: For input string';
   l_col_rows(5)(34) := '1138602.1';

END IF;

   l_sig.title := 'BI Publisher Integration - Critical One-off Patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Check if all of the critical one-off patches were applied in this instance';
   l_sig.solution := '<ul><li>Please review list above and schedule to apply these patches as soon as possible</li>
    <li>These patches contain fix for issues known to cause failures during payment file generation	</li>
    <li>Refer to the note indicated for more information about each patch</li>
    <li>For additional details on available patches for XML embedded in EBS, refer to [1138602.1] </li></ul>';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'check_xdo_patches',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_3');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_3 at step '||l_step);
  raise;
END check_rec_patches_3;

FUNCTION check_rec_patches_4 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_4');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '12961561';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'CONSOLIDATED FIXES TO RIGHT FAX SOLUTION';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '8422142';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'IBY_FD_SRA_FORMAT DOES NOT CONTINUE WHEN IT ENCOUNTERS AN XMPL DM API ERROR';
   l_col_rows(5)(2) := '828203.1';

   l_col_rows(1)(3) := '10374184';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'UNABLE TO SEND NOTIFICATIONS TO SUPPLIER ( CUSTOMER) FOR REFUND PROCESS IN R12';
   l_col_rows(5)(3) := '1313343.1';

   l_col_rows(1)(4) := '9161623';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12-SEND REMITTANCE ADVICE - IBY_FD_SRA_FORMAT';
   l_col_rows(5)(4) := '1060753.1';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '10374184';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'UNABLE TO SEND NOTIFICATIONS TO SUPPLIER ( CUSTOMER) FOR REFUND PROCESS IN R12';
   l_col_rows(5)(1) := '1313343.1';

   l_col_rows(1)(2) := '12961561';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'CONSOLIDATED FIXES TO RIGHT FAX SOLUTION';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '9161623';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12-SEND REMITTANCE ADVICE - IBY_FD_SRA_FORMAT';
   l_col_rows(5)(3) := '1060753.1';

   l_col_rows(1)(4) := '8422142';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'IBY_FD_SRA_FORMAT DOES NOT CONTINUE WHEN IT ENCOUNTERS AN XMPL DM API ERROR';
   l_col_rows(5)(4) := '828203.1';

END IF;

   l_sig.title := 'SRA Recommended Patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please check if any of the recommended patches were not applied in this instance';
   l_sig.solution := '<ul><li>Please review list above and schedule to apply any unappplied patches as soon as possible</li><li>Refer to the note indicated for more information about each patch</li></ul>';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'check_sra_patches',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_4');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_4 at step '||l_step);
  raise;
END check_rec_patches_4;

FUNCTION check_rec_patches_5 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_5');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '4440000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Oracle XML Publisher Version 5.6.3';
   l_col_rows(5)(1) := '362496.1';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '4440000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Oracle XML Publisher Version 5.6.3';
   l_col_rows(5)(1) := '362496.1';

END IF;

   l_sig.title := 'BI Publisher Version';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Check the version of XML Publisher in this instance';
   l_sig.solution := '<ul>
	<li>Please review the above results and ensure that you are at the highest XDO publisher version</li>
	<li>Refer to the note indicated for more information about each patch</li>
</ul>';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'check_xdo_version',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_5');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_5 at step '||l_step);
  raise;
END check_rec_patches_5;




-------------------------
-- Signatures
-------------------------


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters(
            p_org_id                       IN VARCHAR2    DEFAULT NULL
           ,p_ppr_name                     IN VARCHAR2    DEFAULT NULL
           ,p_inv_num_1                    IN VARCHAR2    DEFAULT NULL
           ,p_check_id                     IN VARCHAR2    DEFAULT NULL
           ,p_from_date                    IN DATE        DEFAULT sysdate-90
           ,p_max_output_rows              IN NUMBER      DEFAULT 50
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_revision                  VARCHAR2(25);
  l_date_char                 VARCHAR2(30);
  l_instance                  V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version              FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host                      V$INSTANCE.HOST_NAME%TYPE;
  l_key                       VARCHAR2(255);
  l_system_function_var       VARCHAR2(2000);

  invalid_parameters EXCEPTION;

l_inv_id_1     NUMBER := NULL;
l_org_list     VARCHAR2(150);
l_ppr_id       NUMBER := NULL;
l_federal      VARCHAR2(30);
l_ss           VARCHAR2(255);

cursor invid(invn varchar2) is
    select invoice_id from ap_invoices_all where invoice_num = invn and org_id = p_org_id;


l_exists_val       VARCHAR2(2000);





BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.11  $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/08/28 09:49:16 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #7
  g_rep_info('File Name') := 'iby_fd_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
-- PSD #7b
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1587455.1" target="_blank">(Note 1587455.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------

-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  IF substr(l_apps_version,1,2) < '12' THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script must run in version 12 or above.');
	raise invalid_parameters;
  END IF;
  

  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');

debug('begin parameter validation: p_org_id');
IF p_org_id IS NULL OR p_org_id = '' THEN
   print_error('Parameter p_org_id is required.');
   raise invalid_parameters;
END IF;
IF p_org_id IS NOT NULL AND p_org_id <> '' THEN
BEGIN
SELECT SP.ORG_ID
INTO l_exists_val
FROM HR_OPERATING_UNITS O, AP_SYSTEM_PARAMETERS_ALL SP
WHERE SP.ORG_ID = p_org_id
AND SP.ORG_ID = O.ORGANIZATION_ID
;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('No operating unit organization ID specified. The org_id parameter is mandatory.');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_org_id');

debug('begin parameter validation: p_ppr_name');
IF p_ppr_name IS NOT NULL AND p_ppr_name <> '' THEN
BEGIN
SELECT CHECKRUN_NAME
INTO l_exists_val
FROM AP_INV_SELECTION_CRITERIA_ALL
WHERE CHECKRUN_NAME = p_ppr_name;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('Invalid checkrun number specified.');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_ppr_name');

debug('begin parameter validation: p_inv_num_1');
IF p_inv_num_1 IS NOT NULL AND p_inv_num_1 <> '' THEN
BEGIN
SELECT INVOICE_NUM
INTO l_exists_val
FROM AP_INVOICES_ALL
WHERE INVOICE_NUM = p_inv_num_1;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('Invalid invoice number specified.');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_inv_num_1');

debug('begin parameter validation: p_check_id');
IF p_check_id IS NOT NULL AND p_check_id <> '' THEN
BEGIN
SELECT CHECK_ID
INTO l_exists_val
FROM AP_CHECKS_ALL
WHERE CHECK_ID = p_check_id;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('Invalid check id specified.');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_check_id');



debug('begin parameter validation: p_debug_mode');
IF p_debug_mode IS NOT NULL AND p_debug_mode <> '' AND p_debug_mode NOT IN ( 'Y','N') THEN
   print_error('Debug Mode is invalid.  Valid values are Y or N');
   raise invalid_parameters;
END IF;
debug('end parameter validation: p_debug_mode');



debug('begin Additional Code: Additional Validation');
--Get ppr_id from ppr_name
  if (p_ppr_name is not null) then
    begin
      select checkrun_id 
      into l_ppr_id
      from AP_INV_SELECTION_CRITERIA_ALL
      where CHECKRUN_NAME = p_ppr_name;
    exception
      when others then
        print_log('Invalid checkrun number specified.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;

-- Get invoice id from invoice number
  if (nvl(p_inv_num_1,'-=#not set#=-') <> '-=#not set#=-') then
    begin
      open invid(p_inv_num_1);
      fetch invid into l_inv_id_1;
      close invid;
    exception
      when others then
        print_log('Invalid invoice number specified.'||sqlerrm);
        raise invalid_parameters;
    end;
  end if;

-- Check if FEDERAL is enabled
	if (p_org_id is not null) then
  		begin
		mo_global.set_policy_context('S',p_org_id);
		  if (FV_INSTALL.ENABLED) then
			l_federal := 'Enabled';
	    	  else
			l_federal := 'Not Enabled';
		  end if;
		end;
    end if;debug('end Additional Code: Additional Validation');



  -- PSD #8
  -- Create global hash for parameters. Numbers required for the output order
debug('begin populate parameters hash table');
   g_parameters('1. Operating Unit')                 := p_org_id;
   g_parameters('2. PPR Name')                       := p_ppr_name;
   g_parameters('3. Invoice Number')                 := p_inv_num_1;
   g_parameters('4. Check ID')                       := p_check_id;
   g_parameters('5. From Date')                      := p_from_date;
   g_parameters('6. Maximum Rows to Display')        := p_max_output_rows;
   g_parameters('7. Debug Mode')                     := p_debug_mode;
debug('end populate parameters hash table');



  l_key := g_parameters.first;
  -- Print parameters to the log
  print_log('Parameter Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_parameters(l_key));
    l_key := g_parameters.next(l_key);
  END LOOP;
  
  -- PSD #8a
  -- Create global hash of SQL token values
debug('begin populate sql tokens hash table');
   g_sql_tokens('##$$FDATE$$##')                           := p_from_date;
   g_sql_tokens('##$$PPRID$$##')                           := l_ppr_id;
   g_sql_tokens('##$$INVIDS$$##')                          := l_inv_id_1;
   g_sql_tokens('##$$CHKID$$##')                           := p_check_id;
   g_sql_tokens('##$$l_from_date$$##')                     := to_char(nvl(p_from_date,sysdate-90),'DD-MON-YYYY');
   g_sql_tokens('##$$PPRNAME$$##')                         := p_ppr_name;
   g_sql_tokens('##$$TDATE$$##')                           := to_char((sysdate),'DD-MON-YYYY');
   g_sql_tokens('##$$FEDERAL$$##')                         := l_federal;
   g_sql_tokens('##$$REL$$##')                             := g_rep_info('Apps Version');
   g_sql_tokens('##$$ORGID$$##')                           := p_org_id;
debug('end populate sql tokens hash table');



  l_key := g_sql_tokens.first;
  -- Print token values to the log

  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;

  -- PSD #7a-end

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN

null;
-- PSD #9
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------


debug('begin add_signature: Submit_PPR_Errors');
  add_signature(
      p_sig_id                 => 'Submit_PPR_Errors',
      p_sig_sql                => 'SELECT Adf.Filename, Adfv.Version
    FROM Ad_Files Adf, Ad_File_Versions Adfv
    Where  
    Adf.File_Id = Adfv.File_Id
    and (Fnd_Irep_Loader_Private.Compare_Versions(Adfv.Version,''120.9.12010000.8'') = ''<'')
    And Adf.App_Short_Name = ''SQLAP''
    And Adf.Filename = ''PsrCO.class''
    And Adfv.File_Version_Id = (Select Max(adfv2.File_Version_Id) from ad_file_versions adfv2 where Adf.File_Id = Adfv2.File_Id)',
      p_title                  => 'Error trying to submit PPR',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Does not have framework code fix',
      p_solution               => '<ul>
     <li>Apply patch 16983427</li>
	 <li>Reference: [1481246.1] or [1590278.1] depending on error.</li>
     </ul>',
      p_success_msg            => '<ul>
     <li>PsrCO.class is 120.9.12010000.8 or above so has fix.</li>
	 <li>Reference: [1481246.1] or [1590278.1] depending on error.</li>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: Submit_PPR_Errors');



debug('begin add_signature: 11810646_ORPH_ACCTS');
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
   l_info('Doc ID'):= '1370214.1';
  add_signature(
      p_sig_id                 => '11810646_ORPH_ACCTS',
      p_sig_sql                => 'SELECT ext_bank_account_id
	    ,      bank_account_num
	    ,      bank_id
	    ,      branch_id
	    ,      currency_code
	    ,      country_code
	    ,      bank_account_type
	    ,      account_suffix
	    FROM iby_ext_bank_accounts eba 
	    WHERE NOT EXISTS(SELECT ''OWNER''
	                      FROM iby_account_owners
			      WHERE account_owner_party_id <> -99  
			      AND ext_bank_account_id = eba.ext_bank_account_id )
            AND NOT EXISTS(SELECT ''ASSIGNMENT'' 
	                   FROM iby_pmt_instr_uses_all 
			   WHERE instrument_type = ''BANKACCOUNT'' 
			   AND instrument_id = eba.ext_bank_account_id)
            AND NOT EXISTS (SELECT ''UPGRADE_ASSIGNMENT''
	                    FROM IBY_UPG_INSTRUMENTS 
			    WHERE instrument_type = ''BANKACCOUNT''
			    AND instrument_id = eba.ext_bank_account_id)',
      p_title                  => '11810646_ORPH_ACCTS: Identify Orphaned Bank Accounts',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found orphan bank accounts that have no owner',
      p_solution               => 'Please review the orphan bank account records found. Use GDF [1370214.1] for data fix',
      p_success_msg            => 'No orphan bank accounts were found in table iby_external_payees_all',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 11810646_ORPH_ACCTS');



debug('begin add_signature: PPR_DATA_AIA');
  add_signature(
      p_sig_id                 => 'PPR_DATA_AIA',
      p_sig_sql                => 'SELECT 
	invoice_id, 
	invoice_type_lookup_code, 
	invoice_num, 
	invoice_amount, 
	invoice_date, 
	vendor_id, 
	vendor_site_id, 
	invoice_currency_code, 
	payment_currency_code, 
	payment_method_code, 
	payment_status_flag 
       FROM 
	ap_invoices_all 
      WHERE 
	invoice_id IN (SELECT calling_app_doc_unique_ref2 FROM iby_docs_payable_all WHERE payment_service_request_id in 
		(Select PAYMENT_SERVICE_REQUEST_ID 
		from  iby_pay_service_requests 
		where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##'')))',
      p_title                  => 'AP_INVOICES_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_AIA');



debug('begin add_signature: 952763.1-STEP_1');
   l_info('Comments'):= 'The invoice should not be selected by any other PPR';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_1',
      p_sig_sql                => 'SELECT       
		apsa.invoice_id,
		apsa.checkrun_id  Locked_By_PPR_Id,  ''Different PPR than specified for this report'' msg,
		apsa.payment_status_flag,
		apsa.gross_amount,
		apsa.amount_remaining 
    FROM 
		ap_payment_schedules_all apsa
    WHERE 
		apsa.invoice_id in (''##$$INVIDS$$##'') AND 
  		apsa.checkrun_id NOT in (''##$$PPRID$$##'')',
      p_title                  => '1: The invoice should not be selected by any other PPR',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice is already selected and locked by a previous PPR',
      p_solution               => 'Open the invoice and check if Payment Request field under Scheduled Payments tab is populated with PPR Name',
      p_success_msg            => 'Invoice is not selected by a previous PPR',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_1');



debug('begin add_signature: 10144798_DUP_BAN');
   l_info('Comments'):= 'Bug 10144798 Identify Duplicate External Bank Accounts';
   l_info('Doc ID'):= '1265353.1';
  add_signature(
      p_sig_id                 => '10144798_DUP_BAN',
      p_sig_sql                => 'SELECT ext_bank_account_id, bank_account_num, bank_id, branch_id, currency_code, country_code, bank_account_type, ACCOUNT_SUFFIX,  RANK() OVER (PARTITION BY
       bank_account_num,bank_id,branch_id,currency_code, country_code
       ORDER BY end_date DESC, creation_date, start_date, ext_bank_account_id )num
       FROM
       iby_ext_bank_accounts WHERE (bank_account_num, nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code) IN ( SELECT bank_account_num,  nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code FROM iby_ext_bank_accounts where country_code <> ''JP'' and country_code <> ''NZ'' GROUP BY 
       bank_account_num, bank_id, branch_id, currency_code, country_code HAVING
       Count(*)>1) 
UNION
	SELECT ext_bank_account_id, bank_account_num, bank_id, branch_id, currency_code, country_code, bank_account_type, ACCOUNT_SUFFIX, RANK() OVER (PARTITION BY
       bank_account_num,bank_id,branch_id,currency_code, country_code, bank_account_type
       ORDER BY end_date DESC, creation_date, start_date, ext_bank_account_id )num
       FROM
       iby_ext_bank_accounts WHERE (bank_account_num, nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code, nvl(bank_account_type,''XX'')) IN ( SELECT bank_account_num,  nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code, nvl(bank_account_type,''XX'') FROM iby_ext_bank_accounts where country_code = ''JP'' GROUP BY 
       bank_account_num, bank_id, branch_id, currency_code, country_code, bank_account_type HAVING
       Count(*)>1)
UNION
	SELECT ext_bank_account_id, bank_account_num, bank_id, branch_id, currency_code, country_code, bank_account_type, ACCOUNT_SUFFIX, RANK() OVER (PARTITION BY
       bank_account_num,bank_id,branch_id,currency_code, country_code, ACCOUNT_SUFFIX
       ORDER BY end_date DESC, creation_date, start_date, ext_bank_account_id )num
       FROM
       iby_ext_bank_accounts WHERE (bank_account_num, nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code, nvl(ACCOUNT_SUFFIX,''XX'')) IN ( SELECT bank_account_num,  nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code, nvl(ACCOUNT_SUFFIX,''XX'') FROM iby_ext_bank_accounts where country_code = ''NZ'' GROUP BY 
       bank_account_num, bank_id, branch_id, currency_code, country_code, ACCOUNT_SUFFIX HAVING
       Count(*)>1)',
      p_title                  => 'Duplicate Bank Account Numbers in IBY_EXT_BANK_ACCOUNTS Table',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found duplicate bank account numbers in IBY_EXT_BANK_ACCOUNTS table',
      p_solution               => 'Please review the list above. Use GDF [1265353.1] for data fix',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 10144798_DUP_BAN');



debug('begin add_signature: INV_DATA_AIA');
  add_signature(
      p_sig_id                 => 'INV_DATA_AIA',
      p_sig_sql                => 'SELECT * FROM ap_invoices_all aia 
	WHERE 
		aia.invoice_id in (##$$INVIDS$$##)',
      p_title                  => 'AP_INVOICES_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_DATA_AIA');



debug('begin add_signature: BI_SUMMARY');
   l_info('Comments'):= 'Setup Summary for BI Publisher';
  add_signature(
      p_sig_id                 => 'BI_SUMMARY',
      p_sig_sql                => 'Select 
		nvl(dummy,''High level setup requirements for BIP'') BIP_Setup
	 From 
		dual 
	 Where 
		dummy != ''X''',
      p_title                  => 'BI Publisher Related Setups for Payments',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'BI Publisher setups in E-Business Suite that can impact payment file creation and formatting',
      p_solution               => '<p>BI Publisher setups in E-Business Suite that can impact payment file creation and formatting.</p>

<ul>
	<li>The following are most common BI Publisher related setups within E-Business Suite Release 12 that will impact not just PPR process but other financial reports such as Account Analysis Report etc</li>
</ul>

<ol>
	<li>BI related patchset and one-off patches</li>
	<li>Memory setting for Output Post Processor concurrent manager that handles BI requests</li>
</ol>

<ul>
	<li>See sections below for validation of these setups</li>
</ul>

<p>  BI Publisher setups in E-Business Suite that can impact payment file creation and formatting.<br />
    <ul><br />
     <li>The following are most common BI Publisher related setups within E-Business Suite Release 12 that will impact not just PPR process but other financial reports such as Account Analysis Report etc</li><br />
    <br><br />
     <ol><br />
        <li>BI related patchset and one-off patches</li><br />
        <li>Memory setting for Output Post Processor concurrent manager that handles BI requests</li><br />
        <li>Memory setting at concurrent program definition level (in options field)</li><br />
        <li>Number of processes and threads allocated to Output Post processor concurrent manager</li><br />
        <li>Output Post Processor related timeout profiles</li><br />
       <li>BI Publisher runtime setting for temp directory</li><br />
       <li>BI Publisher FO Processing runtime settings </li><br />
       <li>BI Publisher Template version </li>       <br />
    </ol><br />
    <br><br />
    <br><br />
     <li>See sections below for validation of these setups</p>',
      p_success_msg            => '<p>BI Publisher setups in E-Business Suite that can impact payment file creation and formatting.</p>

<ul>
	<li>The following are most common BI Publisher related setups within E-Business Suite Release 12 that will impact not just PPR process but other financial reports such as Account Analysis Report etc
	<ol>
		<li>BI related patchset and one-off patches</li>
		<li>Memory setting for Output Post Processor concurrent manager that handles BI requests</li>
		<li>Memory setting at concurrent program definition level (in options field)</li>
		<li>Number of processes and threads allocated to Output Post processor concurrent manager</li>
		<li>Output Post Processor related timeout profiles</li>
		<li>BI Publisher runtime setting for temp directory</li>
		<li>BI Publisher FO Processing runtime settings</li>
		<li>BI Publisher Template version</li>
	</ol>
	</li>
	<br />
	<li>See sections below for validation of these setups</li>
</ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BI_SUMMARY');



debug('begin add_signature: 17856010_CASE1');
   l_info('Bug'):= '17856010';
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
  add_signature(
      p_sig_id                 => '17856010_CASE1',
      p_sig_sql                => 'SELECT 
	aisc.checkrun_name  PPR_Name,
	aisc.checkrun_id  PPR_Id,
            aisc.check_date,
            aisc.status ||''(Case 1)'',
            aisc.request_id,
            COUNT(DISTINCT invoice_id),
            COUNT(invoice_id),
            ''Y''
FROM 
	ap_inv_selection_criteria_all aisc,
            ap_selected_invoices_all asi
WHERE 
	asi.checkrun_id = aisc.checkrun_id  AND NOT EXISTS
           (SELECT ''Corresponding PSR''
            FROM iby_pay_service_requests ipsr
            WHERE ipsr.calling_app_id              = 200   AND
            ipsr.call_app_pay_service_req_code = aisc.checkrun_name)  AND
	aisc.status in (''CANCELING'', ''SELECTING'', ''CALCULATING'', ''REVIEW'', ''SELECTED'')
GROUP BY 
	aisc.checkrun_id,
            aisc.check_date,
            aisc.checkrun_name,
            aisc.status,
            aisc.request_id
UNION
SELECT 
	aisc.checkrun_name  PPR_Name,
	aisc.checkrun_id  PPR_ID,
            aisc.check_date,
            aisc.status ||''(Case 1.1)'',
            aisc.request_id,
            0,
            0,
	''Y''
FROM 
	ap_inv_selection_criteria_all aisc
WHERE 
	NOT EXISTS
            (SELECT ''Corresponding PSR''
            FROM iby_pay_service_requests ipsr
            WHERE ipsr.calling_app_id              = 200   AND
            ipsr.call_app_pay_service_req_code = aisc.checkrun_name )  AND
	aisc.status in (''CANCELING'', ''SELECTING'', ''CALCULATING'', ''UNSTARTED'', ''REVIEW'', ''SELECTED'')
            AND NOT EXISTS (
	    SELECT 1 FROM ap_selected_invoices_all asi
	    WHERE  asi.checkrun_id = aisc.checkrun_id
	  )
	  AND NOT EXISTS (
	    SELECT 1 FROM ap_payment_schedules_all aps
	    WHERE  aps.checkrun_id = aisc.checkrun_id
	  )
          GROUP BY aisc.checkrun_id,
            aisc.check_date,
            aisc.checkrun_name,
            aisc.status,
            aisc.request_id',
      p_title                  => '1.0/1.1: PPR is submitted but PSR is not yet created',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more PPR were submitted but corresponding PSR is not yet created. Causing to not be able to terminate PPR.',
      p_solution               => 'Use GDF [874862.1] for data fix.',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: 17856010_CASE1');



debug('begin add_signature: SRA_SUMMARY');
  add_signature(
      p_sig_id                 => 'SRA_SUMMARY',
      p_sig_sql                => 'Select 
		nvl(dummy,''High level setup requirements for SRA'') SRA_Setup
	 From 
		dual 
	 Where 
		dummy != ''X''',
      p_title                  => 'Setup Requirements for SRA Delivery',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Setup information only',
      p_solution               => 'Separate Remittance Advice Delivery Setup Summary',
      p_success_msg            => 'Separate Remittance Advice Delivery Setup Summary.
	<ul>
     <li>The following setup is needed for Separate Remittance Advice functionality </li>
	<br>
     <ol>
        <li>SRA related setup in Payment Process Profile under reporting tab</li>
        <li>SRA related setup in supplier details: Payment Details-->Payment Attributes-->Separate Remittance Advice Delivery tab </li>
        <li>Creation of xdodelivery.cfg file and setup of profile  IBY: XML Publisher Delivery Manager Configuration File </li>
        <li>Update SRA message SRA EMAIL FROM to point to valid email address</li>
        <li>Apply appropriate SRA related one-off patches</li>
	</ol>
	<br>
	<br>
     <li>See sections below for validation for some of these setups.</li>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SRA_SUMMARY');



debug('begin add_signature: 11810646_AR_ORPH_ASSIGN');
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
   l_info('Doc ID'):= '1370214.1';
  add_signature(
      p_sig_id                 => '11810646_AR_ORPH_ASSIGN',
      p_sig_sql                => 'SELECT actown.ext_bank_account_id,
                   ibypye.ext_payee_id,
		   ibypye.payee_party_id,
		   actown.account_owner_party_id,
                   ibypye.payment_function
		   FROM iby_account_owners actown,
		   iby_external_payees_all ibypye
		   WHERE actown.account_owner_party_id = ibypye.payee_party_id
		   AND ibypye.payment_function = ''AR_CUSTOMER_REFUNDS''
		   AND NOT EXISTS ( SELECT 1
		                   FROM iby_pmt_instr_uses_all
				   WHERE ext_pmt_party_id = ibypye.ext_payee_id
				   AND instrument_id      = actown.ext_bank_account_id)',
      p_title                  => '11810646_AR_ORPH_ASSIGN: Identify AR Orphan Bank Account Assignments',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found AR orphan bank account assignments',
      p_solution               => 'Please review the AR orphan assignment records found. Use GDF [1370214.1] for data fix.',
      p_success_msg            => 'No AR orphan bank account assignments were found',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 11810646_AR_ORPH_ASSIGN');



debug('begin add_signature: 1326421.1-Case1');
   l_info('Doc ID'):= '1326421.1';
  add_signature(
      p_sig_id                 => '1326421.1-Case1',
      p_sig_sql                => 'SELECT SUM(NVL(aid.amount,0)) AMT
        FROM ap_invoice_payments_all aip,ap_invoices_all ai,
        ap_invoice_distributions_all aid,ap_invoice_distributions_all aid2
     WHERE aip.check_id = (''##$$CHKID$$##'')
        AND ai.invoice_id = aip.invoice_id
        AND ai.invoice_type_lookup_code = ''PREPAYMENT''
        AND ai.invoice_id = aid2.invoice_id
        AND aid2.line_type_lookup_code = ''ITEM''
        AND aid.prepay_distribution_id = aid2.invoice_distribution_id',
      p_title                  => 'Prepayment remains at least partially applied',
      p_fail_condition         => '[AMT] <> [0]',
      p_problem_descr          => 'Prepayment has not been unapplied completely.',
      p_solution               => 'Unapply the prepayment and account that event.',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: 1326421.1-Case1');



debug('begin add_signature: 1913503.1-Form');
   l_info('Doc ID'):= '1913503.1';
  add_signature(
      p_sig_id                 => '1913503.1-Form',
      p_sig_sql                => 'SELECT Adf.Filename, Adfv.Version
    FROM Ad_Files Adf, Ad_File_Versions Adfv
    Where  
    Adf.File_Id = Adfv.File_Id
    and  
    ((''12.2'' =  substr(''##$$REL$$##'',1,4) AND
            FND_IREP_LOADER_PRIVATE.compare_versions(
              Adfv.Version,''120.445.12020000.49'') = ''<'' )
              Or
           (''12.1'' = substr(''##$$REL$$##'',1,4) AND
            Fnd_Irep_Loader_Private.Compare_Versions(
              Adfv.Version,''120.223.12010000.273'') = ''<'' ))
    And Adf.App_Short_Name = ''SQLAP''
    And Adf.Filename = ''APXPAWKB.fmb''
    And Adfv.File_Version_Id = (Select Max(adfv2.File_Version_Id) from ad_file_versions adfv2 where Adf.File_Id = Adfv2.File_Id)',
      p_title                  => 'Payments Workbench code bug causing FRM-40654 error',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payments Workbench (APXPAWKB.fmb) does not have code fix.',
      p_solution               => '<ul>
     <li>Apply patch 17898482</li>
     <li>This is a one-off so smallest patch that can be used for this code fix</li>
	 <li>Reference: [1913503.1]</li>
     </ul>',
      p_success_msg            => 'Have Payments Workbench code fix for [1913503.1]',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: 1913503.1-Form');



debug('begin add_signature: 18027976-Case1');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case1',
      p_sig_sql                => 'SELECT distinct ap.invoice_id,
					ap.invoice_num,
					ap.org_id,
					ap.Reason,
					''Y'' process_flag
			FROM 
				(SELECT ''Incorrect Amt Paid'' Reason
						,ai.invoice_id
						,ai.invoice_num
          					,ai.org_id
						,ai.invoice_amount
						,ai.amount_paid
						,(SELECT AP_UTILITIES_PKG.ap_round_currency(SUM(aid.amount) *
							NVL(ai.payment_cross_rate,1),ai.payment_currency_code)
                 				  FROM ap_invoice_distributions aid,ap_invoice_lines ail
						  WHERE ail.invoice_id=ai.invoice_id
						  AND aid.invoice_id=ai.invoice_id
						  AND ail.line_number = aid.invoice_line_number  
						  AND aid.prepay_distribution_id is not null
	 					  AND nvl(ail.invoice_includes_prepay_flag,''N'')<>''Y''
                				) prepay_amt
						,(SELECT SUM(aip.amount)
						FROM ap_invoice_payments aip
						WHERE aip.invoice_id =ai.invoice_id
						) pay_amt
				  FROM ap_invoices ai
			          WHERE ai.org_id = (##$$ORGID$$##)
			          AND ai.cancelled_date IS NULL
				  AND ai.validation_request_id is NULL
				  AND ai.invoice_date between (''##$$FDATE$$##'')and (''##$$TDATE$$##'')
				 ) ap
			WHERE (nvl(ap.pay_amt,0)- nvl(ap.prepay_amt,0)) <> nvl(ap.amount_paid,0)',
      p_title                  => 'Payment schedules which are not fully paid, but have payment_status_flag of Y',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case1');



debug('begin add_signature: IBY_INVALIDS');
  add_signature(
      p_sig_id                 => 'IBY_INVALIDS',
      p_sig_sql                => 'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''IBY%'' OR
         a.object_name like ''AP_%'' )
    AND a.status = ''INVALID''',
      p_title                  => 'Payments Related Invalid Objects',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There exist invalid Payments/Payables related objects',
      p_solution               => '<p><ul><br />
      <li>Recompile the individual objects manually or recompile the<br />
          entire APPS schema with adadmin utility</li><br />
      <li>Review any error messages provided</li><br />
   </ul></p>',
      p_success_msg            => '<p>No Payments related invalid objects exists in the database</p>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IBY_INVALIDS');



debug('begin add_signature: OPP_HEAP_CHECK');
   l_info('Comments'):= 'There is no UI to update heap space however the UPDATE statement in note 1268217.1 is approved by BIP Development';
   l_info('Doc ID'):= '1268217.1';
  add_signature(
      p_sig_id                 => 'OPP_HEAP_CHECK',
      p_sig_sql                => 'select SERVICE_HANDLE, DEVELOPER_PARAMETERS,
                  substr(developer_parameters,   
                  instr(developer_parameters,''-m'') + 3, 
                  (instr(developer_parameters,''m'',instr(developer_parameters,''-mx'') + 3)) -
                  (instr(developer_parameters,''-mx'') + 3)) Heap_Memory
      from FND_CP_SERVICES 
     WHERE SERVICE_HANDLE  LIKE ''%OPP%''
       -- Pick the number portion of parameter
       and to_number(
                      substr(developer_parameters,   
                      instr(developer_parameters,''-mx'') + 3, -- Start right after -mx
                      (instr(developer_parameters,''m'',instr(developer_parameters,''-mx'') + 3)) -
                      (instr(developer_parameters,''-mx'') + 3)  -- Finish right before the last m
                     )) <= 512
     UNION  -- this trick is to make a row selected if param is not set at all which typically should not occur
     select ''Parameter not set'' SERVICE_HANDLE, ''Heap memory not set'' DEVELOPER_PARAMETERS,
            ''Default typically too low'' Heap_Memory
       from dual
      where not exists (select 1 from FND_CP_SERVICES 
                         WHERE SERVICE_HANDLE  LIKE ''%OPP%'')',
      p_title                  => 'Output Post Processor (OPP) Heap Space too low or unset',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The Java Heap space for the OPP Concurrent Manager is likely too low or unset which can cause error "java.lang.OutOfMemoryError: Java heap space" in Payments processes',
      p_solution               => '<ul>
	<li>For normal Payments processing 1024MB of heap is recommended</li>
	<li>For large volume Payments processing 2048MB of heap is recommended</li>
	<li>Please follow instructions on Note [1268217.1] to update the heap space to any of the values recommended above</li>
	<li>Ensure that concurrent managers are bounced after increasing the heap space</li>
	<li>For additional information on troubleshooting BIP integration with IBY see [1410160.1]</li>
</ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPP_HEAP_CHECK');



debug('begin add_signature: PPR_DATA_AISCA');
  add_signature(
      p_sig_id                 => 'PPR_DATA_AISCA',
      p_sig_sql                => 'SELECT 
			aisca.checkrun_name PPR_Name, 
           	aisca.checkrun_id  PPR_Id, 
	         	aisca.status,
			aisca.PAYMENT_PROFILE_ID,
	           aisca.check_date,
            aisca.pay_from_date, 
            aisca.pay_thru_date,
            aisca.creation_date,
            aisca.pay_only_when_due_flag,
            aisca.low_payment_priority, 
            aisca.hi_payment_priority,
            aisca.invoice_batch_id, 
            aisca.vendor_type_lookup_code, 
            aisca.vendor_id, 
            aisca.party_id,
            aisca.zero_invoices_allowed, 
            aisca.zero_amounts_allowed, 
            aisca.inv_exchange_rate_type,
			aisca.PAYABLES_REVIEW_SETTINGS,
		aisca.CALC_AWT_INT_FLAG, 
		aisca.PAYMENTS_REVIEW_SETTINGS, 
		aisca.DOCUMENT_REJECTION_LEVEL_CODE,  
		aisca.PAYMENT_REJECTION_LEVEL_CODE,   
		aisca.CREATE_INSTRS_FLAG,
            aisca.payment_method_code,
            aisca.pay_group_option,
            aisca.le_group_option,
            aisca.currency_group_option,
            aisca.ou_group_option,
		aisca.BANK_CHARGE_BEARER,             
            aisca.SETTLEMENT_PRIORITY,            
            aisca.RESUBMIT_FLAG, 
            aisca.NEXT_VOUCHER_NUMBER,    
            aisca.PARTY_ID,               
            aisca.PAYMENT_DOCUMENT_ID,    
            aisca.CE_BANK_ACCT_USE_ID,    
            aisca.INV_AWT_EXISTS_FLAG 
	FROM 
		ap_inv_selection_criteria_all aisca
	WHERE 
		aisca.checkrun_id in (##$$PPRID$$##)',
      p_title                  => 'AP_INV_SELECTION_CRITERIA_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => 'Please check PPR entered',
      p_success_msg            => '<ul>
     <li>Table AP_INV_SELECTION_CRITERIA_ALL contains invoice selection criteria specified when submitting the PPR</li>
     <li>For any issues with PPR, check the data in the table and ensure that invoices meet the criteria specified</li>
     <li>If you are using payment date prior to sysdate, please ensure that ALLOW PRE-DATED PAYMENTS flag in Payables System Option is checked</li>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_AISCA');



debug('begin add_signature: INV_DATA_AILA');
  add_signature(
      p_sig_id                 => 'INV_DATA_AILA',
      p_sig_sql                => 'SELECT 
	line_number, 
	line_type_lookup_code, 
	line_source,
	accounting_date, 
	period_name, 
	deferred_acctg_flag, 
	org_id,
	wfapproval_status
        FROM 
	AP_INVOICE_LINES_ALL 
        WHERE 
	invoice_id in (##$$INVIDS$$##)',
      p_title                  => 'AP_INVOICE_LINES_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist',
      p_solution               => 'Please check invoice number entered',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_DATA_AILA');



debug('begin add_signature: 952763.1-STEP_2A');
   l_info('Comments'):= 'Invoice Due_Date should fall within Pay_From & Pay_Thru dates in PPR';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_2A',
      p_sig_sql                => 'SELECT 
		apsa.invoice_id, 
            apsa.payment_status_flag,
            apsa.payment_method_code, 
            apsa.amount_remaining, 
            apsa.payment_priority , 
            apsa.hold_flag,
            apsa.due_date,
            apsa.discount_date,
            apsa.second_discount_date,
            apsa.third_discount_date,
            aisca.pay_from_date,
		aisca.pay_thru_date
    FROM 
		ap_payment_schedules_all apsa, 
		ap_inv_selection_criteria_all aisca
    WHERE 
		apsa.invoice_id in (''##$$INVIDS$$##'') AND
 		aisca.checkrun_id in (''##$$PPRID$$##'') AND 
         	apsa.due_date NOT BETWEEN (nvl(aisca.pay_from_date,apsa.due_date)) AND (aisca.pay_thru_date)',
      p_title                  => '2a: Invoice Due_Date should fall within Pay_From and Pay_Thru dates in PPR',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice has due_date that does not fall within pay_from and pay_thru range specified in PPR',
      p_solution               => 'Submit a new PPR with adjusted pay_from and pay_thru range',
      p_success_msg            => 'Invoices due_date that falls within the range specified by Pay_From & Pay_Thru dates',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_2A');



debug('begin add_signature: ENCRYPT_DATA');
   l_info('Doc ID'):= '1573912.1, 1301337.1';
  add_signature(
      p_sig_id                 => 'ENCRYPT_DATA',
      p_sig_sql                => 'SELECT 
	isso.CC_ENCRYPTION_MODE, 
	isso.EXT_BA_ENCRYPTION_MODE, 
	isso.SYS_KEY_FILE_LOCATION,
  	isso.INSTR_SEC_CODE_ENCRYPTION_MODE, 
  	isso.CREDIT_CARD_MASK_SETTING, 
  	isso.CREDIT_CARD_UNMASK_LEN, 
  	isso.EXT_BA_MASK_SETTING,
  	isso.EXT_BA_UNMASK_LEN,
  	isso.ENCRYPT_SUPPLEMENTAL_CARD_DATA
   FROM 
  	iby_sys_security_options isso
   WHERE 
      isso.SYS_KEY_FILE_LOCATION is NULL',
      p_title                  => 'Payment Data Encryption & Masking Setup',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment data encryption is not enabled',
      p_solution               => '<ul>
     <li>To enable encryption, please  refer to [1301337.1] and [1430916.1]</li>
     <li>Before enabling payment data encryption, please review and understand contents of [1573912.1] - All About Oracle Payments Release 12 Wallets and Data Encryption</li>
     <li>After enabling encryption, ensure that a backup copy of self signed wallet file cwallet.sso is saved in secured location</li>
     </ul>',
      p_success_msg            => '<ul>
     <li>After enabling encryption, ensure that a backup copy of self signed wallet file cwallet.sso is saved in secured location</li>
     <li>For detailed explanation of payment data encryption, please review and understand contents of 1573912.1 - All About Oracle Payments Release 12 Wallets and Data Encryption</li>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ENCRYPT_DATA');



debug('begin add_signature: 13857555_DUP_PAYEE');
   l_info('Comments'):= 'Identify duplicate payee';
   l_info('Doc ID'):= '1308849.1';
  add_signature(
      p_sig_id                 => '13857555_DUP_PAYEE',
      p_sig_sql                => 'SELECT
        A.EXT_PAYEE_ID	,		
	    A.PAYEE_PARTY_ID	,		
	    A.PAYMENT_FUNCTION	,	
	    A.EXCLUSIVE_PAYMENT_FLAG		,
	    A.PARTY_SITE_ID                   ,
	    A.SUPPLIER_SITE_ID                ,
	    A.ORG_ID                          ,
	    A.ORG_TYPE                        ,
	    A.DEFAULT_PAYMENT_METHOD_CODE     ,
	    A.ECE_TP_LOCATION_CODE            ,
	    A.BANK_CHARGE_BEARER              ,
	    A.BANK_INSTRUCTION1_CODE          ,
	    A.BANK_INSTRUCTION2_CODE          ,
	    A.BANK_INSTRUCTION_DETAILS        ,
	    A.PAYMENT_REASON_CODE             ,
	    A.PAYMENT_REASON_COMMENTS         ,
	    A.INACTIVE_DATE                   ,
	    A.PAYMENT_TEXT_MESSAGE1           ,
	    A.PAYMENT_TEXT_MESSAGE2           ,
	    A.PAYMENT_TEXT_MESSAGE3           ,
	    A.DELIVERY_CHANNEL_CODE           ,
	    A.PAYMENT_FORMAT_CODE             ,
	    A.SETTLEMENT_PRIORITY             ,
	    A.REMIT_ADVICE_DELIVERY_METHOD    ,
	    A.REMIT_ADVICE_EMAIL              ,
	    A.REMIT_ADVICE_FAX                
	FROM iby_external_payees_all a
      WHERE EXISTS (SELECT ''duplicates''
			 FROM iby_external_payees_all b 
			 WHERE a.payee_party_id = b.payee_party_id 
			 AND a.payment_function = b.payment_function 
			 AND NVL(a.party_site_id, ''0'') = NVL(b.party_site_id, ''0'') 
			 AND NVL(a.supplier_site_id, ''0'') = NVL(b.supplier_site_id, ''0'') 
			 AND NVL(a.org_id, ''0'') = NVL(b.org_id, ''0'') 
			 AND NVL(a.org_type, ''0'') = NVL(b.org_type, ''0'') 
			 AND a.ext_payee_id <> b.ext_payee_id
		)
	ORDER BY 
			 a.PAYEE_PARTY_ID, 
			 a.last_update_date DESC',
      p_title                  => '13857555_DUP_PAYEE: Identify Duplicate Payee Records in IBY_EXTERNAL_PAYEES_ALL Table',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found duplicate payee records in iby_external_payees_all table',
      p_solution               => 'Please review the duplicate payee records found. Use GDF Patch 13857555 for data fix. Refer to [1308849.1] and [1315812.1] for additional details.',
      p_success_msg            => 'No duplicate payee records were found in table iby_external_payees_all',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 13857555_DUP_PAYEE');



debug('begin add_signature: 17856010_CASE2');
   l_info('Bug'):= '17856010';
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
  add_signature(
      p_sig_id                 => '17856010_CASE2',
      p_sig_sql                => 'SELECT 
		ipsr.call_app_pay_service_req_code  PPR_Name,
		aisc.checkrun_id  PPR_Id,
	            aisc.check_date,
          		AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status) || ''(Case 2)'' Status,
          		aisc.request_id,
          		COUNT(DISTINCT invoice_id),
          		COUNT(invoice_id),
          		''Y''
        FROM 
		iby_pay_service_requests ipsr,
          		ap_inv_selection_criteria_all aisc,
          		ap_payment_schedules_all aps
        WHERE         
		aisc.checkrun_name = ipsr.call_app_pay_service_req_code     AND 
		aps.checkrun_id      = aisc.checkrun_id     AND
        		ipsr.calling_app_id  = 200         AND
          		AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status) = ''TERMINATED''
        GROUP BY 
		aisc.checkrun_id,
          		aisc.check_date,
          		ipsr.call_app_pay_service_req_code,
          		AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status),
          		aisc.request_id',
      p_title                  => '2: PSR is TERMINATED but invoices were not released',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more PPR was terminated but corresponding invoices were not released.',
      p_solution               => 'Please review the PPR and corresponding invoices. Use GDF [874862.1] for data fix.',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 17856010_CASE2');



debug('begin add_signature: 11810646_CE_ORPH_ASSIGN');
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
   l_info('Doc ID'):= '1370214.1';
  add_signature(
      p_sig_id                 => '11810646_CE_ORPH_ASSIGN',
      p_sig_sql                => 'SELECT actown.ext_bank_account_id,
                   ibypye.ext_payee_id,
		   ibypye.payee_party_id,
		   actown.account_owner_party_id,
                   ibypye.payment_function
		   FROM iby_account_owners actown,
		   iby_external_payees_all ibypye
		   WHERE actown.account_owner_party_id = ibypye.payee_party_id
                   AND ibypye.org_type = ''LEGAL_ENTITY''
                   AND NOT EXISTS ( SELECT 1
		                   FROM iby_pmt_instr_uses_all
				   WHERE ext_pmt_party_id = ibypye.ext_payee_id
				   AND instrument_id      = actown.ext_bank_account_id)',
      p_title                  => '11810646_CE_ORPH_ASSIGN: Identify CE Orphan Bank Account Assignments',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found CE orphan bank account assignments',
      p_solution               => 'Please review the CE orphan assignment records found. Use GDF [1370214.1] for data fix.',
      p_success_msg            => 'No CE orphan bank account assignments were found',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 11810646_CE_ORPH_ASSIGN');



debug('begin add_signature: 1326421.1-Case2');
   l_info('Doc ID'):= '1326421.1';
  add_signature(
      p_sig_id                 => '1326421.1-Case2',
      p_sig_sql                => 'SELECT aid.*
     FROM ap_invoice_distributions_all aid_prepay,
        ap_invoice_payments_all aip,
        ap_invoices_all ai_prepay,
        ap_invoice_distributions_all aid,
        ap_invoice_distributions_all aidp
     WHERE aip.check_id = (''##$$CHKID$$##'')
        AND aip.invoice_id = ai_prepay.invoice_id
        AND ai_prepay.invoice_type_lookup_code = ''PREPAYMENT''
        AND aid_prepay.invoice_id = ai_prepay.invoice_id
        AND aid_prepay.invoice_distribution_id = aid.prepay_distribution_id
        AND aid.prepay_distribution_id IS NOT NULL
        AND aid.parent_reversal_id IS NOT NULL
        AND aid.amount > 0
        AND nvl(aid.posted_flag, ''N'') = ''N''
        AND aid.invoice_id = aidp.invoice_id
        AND aid.invoice_line_number = aidp.invoice_line_number
        AND aid.parent_reversal_id = aidp.invoice_distribution_id
        AND aid.prepay_distribution_id = aidp.prepay_distribution_id
        AND nvl(aidp.posted_flag, ''N'') = ''Y''',
      p_title                  => 'Prepayment unapplication event on the invoice has not been accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment unapplication event on the invoice has not been accounted',
      p_solution               => 'Run accounting for the prepayment invoice',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: 1326421.1-Case2');



debug('begin add_signature: 1913503.1-package');
   l_info('Doc ID'):= '1913503.1';
  add_signature(
      p_sig_id                 => '1913503.1-package',
      p_sig_sql                => 'SELECT als.text
    FROM all_source als
    Where  
    ((''12.2'' = substr(''##$$REL$$##'',1,4) AND
            FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                '' '',1,1)-1),''120.25.12020000.7'') = ''<'' ) 
              Or
           (''12.1'' = substr(''##$$REL$$##'',1,4) AND
            FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, instr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                '' '',1,1)-1),''120.15.12010000.18'') = ''<'' ))
    And   Als.Type = ''PACKAGE BODY''
    And   Als.Name = ''AP_CHECKS_PKG''
    And   Als.Text Like ''%$Header%''',
      p_title                  => 'AP_CHECKS_PKG code bug causing FRM-40654 error',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'AP_CHECKS_PKG (apichecb.pls) does not have code fix.',
      p_solution               => '<ul>
     <li>Apply patch 18290300</li>
     <li>This is a one-off so smallest patch that can be used for this code fix</li>
	 <li>Reference: [1913503.1]</li>
     </ul>',
      p_success_msg            => 'Have apichecb.pls code fix for [1913503.1]',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: 1913503.1-package');



debug('begin add_signature: 952763.1-STEP_2B');
   l_info('Comments'):= 'Invoice Due_Date should fall within Pay_From & Pay_Thru dates in PPR';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_2B',
      p_sig_sql                => 'SELECT 
		apsa.invoice_id, 
            apsa.payment_status_flag,
            apsa.payment_method_code, 
            apsa.amount_remaining, 
            apsa.payment_priority , 
            apsa.hold_flag,
            apsa.due_date,
            apsa.discount_date,
            apsa.second_discount_date,
            apsa.third_discount_date,
            aisca.pay_from_date,
		aisca.pay_thru_date,
		aisca.pay_only_when_due_flag
    FROM 
		ap_payment_schedules_all apsa, 
		ap_inv_selection_criteria_all aisca
    WHERE 
		apsa.invoice_id in (''##$$INVIDS$$##'') AND
 		aisca.checkrun_id in (''##$$PPRID$$##'') AND 
		aisca.pay_only_when_due_flag = ''Y''  AND
            apsa.due_date NOT BETWEEN (nvl(aisca.pay_from_date,apsa.due_date)) AND (aisca.pay_thru_date)',
      p_title                  => '2b: Invoice Due_Date should fall within Pay_From and Pay_Thru dates in PPR',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'pay_only_when_due_flag is set to N and the invoice has due_date that does not fall within pay_from and pay_thru range specified in PPR',
      p_solution               => 'Submit a new PPR with adjusted pay_from and pay_thru range',
      p_success_msg            => 'Invoice has due_date that falls within pay_from and pay_thru range specified in PPR',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_2B');



debug('begin add_signature: PPR_DATA_PMTSCHEDULES');
  add_signature(
      p_sig_id                 => 'PPR_DATA_PMTSCHEDULES',
      p_sig_sql                => 'Select * from ap_payment_schedules_all
	where checkrun_id in (##$$PPRID$$##)',
      p_title                  => 'AP_PAYMENT_SCHEDULES_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<ul>
     <li>No data returned</li>
	<li>Rows from this table will only be returned for Scheduled Payments that are currently Selected for Payment in the designated PPR</li>
    <li>The associated invoices will display Status: Selected for Payment if viewed in the Invoice Workbench form</li>
     </ul>',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_PMTSCHEDULES');



debug('begin add_signature: PPR_DATA_PAYGROUP');
  add_signature(
      p_sig_id                 => 'PPR_DATA_PAYGROUP',
      p_sig_sql                => 'Select * from ap_pay_group
	where checkrun_id in (SELECT a.checkrun_id  FROM ap_inv_selection_criteria_all a     
	WHERE a.checkrun_name = (''##$$PPRNAME$$##''))',
      p_title                  => 'AP_PAY_GROUP',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No pay group defined',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_PAYGROUP');



debug('begin add_signature: PPR_DATA_SELECTEDINVOICES');
  add_signature(
      p_sig_id                 => 'PPR_DATA_SELECTEDINVOICES',
      p_sig_sql                => 'Select * from ap_selected_invoices_all
	where checkrun_name in (''##$$PPRNAME$$##'')',
      p_title                  => 'AP_SELECTED_INVOICES_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<ul>
     <li>No data returned</li>
	<li>This table contains temporary data rows that are used for payment processing.</li>
    <li>Rows from this table will only be returned for Scheduled Payment that are currently Selected for Payment in the designated PPR</li>
    <li>The associated invoices will display Status: Selected for Payment if viewed in the Invoice Workbench form</li>
     </ul>',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_SELECTEDINVOICES');



debug('begin add_signature: PPR_DATA_IDPA');
  add_signature(
      p_sig_id                 => 'PPR_DATA_IDPA',
      p_sig_sql                => 'Select 
	calling_app_doc_ref_number invoice_NUM, 
	document_payable_id, 
	Document_status, 
	payment_date, 
	payment_currency_code, 
	payment_amount, 
	document_amount, 
	exclusive_payment_flag, 
	Payment_method_code, 
	ext_payee_id, 
	payee_party_id, 
	payment_profile_id, 
	internal_bank_Account_id, 
	CALLING_APP_DOC_UNIQUE_REF1, 
	CALLING_APP_DOC_UNIQUE_REF2 INVOICE_ID, 
	CALLING_APP_DOC_UNIQUE_REF3 PAYMENT_NUMBER, 
	CALLING_APP_DOC_UNIQUE_REF4, 
	CALLING_APP_DOC_UNIQUE_REF5 
      From 
	iby_docs_payable_all 
      Where 
		payment_service_request_id in 
			(Select PAYMENT_SERVICE_REQUEST_ID 
			from  iby_pay_service_requests 
			where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##''))',
      p_title                  => 'IBY_DOCS_PAYABLE_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'IBY_DOCS_PAYABLE_ALL',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_IDPA');



debug('begin add_signature: Void-sql1');
   l_info('Doc ID'):= '1326421.1';
  add_signature(
      p_sig_id                 => 'Void-sql1',
      p_sig_sql                => 'SELECT distinct aid.invoice_id
     FROM ap_invoice_distributions_all aid_prepay,
        ap_invoice_payments_all aip,
        ap_invoices_all ai_prepay,
        ap_invoice_distributions_all aid
     WHERE aip.check_id = (''##$$CHKID$$##'')
        AND aip.invoice_id = ai_prepay.invoice_id
        AND ai_prepay.invoice_type_lookup_code = ''PREPAYMENT''
        AND aid_prepay.invoice_id = ai_prepay.invoice_id
        AND aid_prepay.invoice_distribution_id = aid.prepay_distribution_id
        AND aid.prepay_distribution_id IS NOT NULL',
      p_title                  => 'Standard invoice that the prepayment is applied to',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Prepayment is not applied to any invoice',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Void-sql1');



debug('begin add_signature: 18027976-Case2');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case2',
      p_sig_sql                => 'SELECT ap.invoice_id,
				ap.invoice_num,
				ap.org_id,
				ap.Reason,
				''Y'' process_flag
			FROM 
				(SELECT ''Incorrect Amt Remaining'' Reason
						,ai.invoice_id
						,ai.invoice_num
						,ai.org_id
						,ai.invoice_amount
						,ai.amount_paid
						,nvl(ai.discount_amount_taken,0) disc_amt
						,nvl(ai.payment_cross_rate,1) payment_cross_rate
						,(SELECT AP_UTILITIES_PKG.ap_round_currency(SUM(ail.amount) *
							NVL(ai.payment_cross_rate,1),ai.payment_currency_code)
						  FROM ap_invoice_lines ail
						  WHERE ail.invoice_id=ai.invoice_id
             					  AND ail.line_type_lookup_code =''AWT''
             					) awt_amt
						,(SELECT AP_UTILITIES_PKG.ap_round_currency(SUM(ail.retained_amount) *
						    NVL(ai.payment_cross_rate,1),ai.payment_currency_code)
						  FROM ap_invoice_lines ail
						  WHERE ail.invoice_id=ai.invoice_id
                  				  AND nvl(ai.net_of_retainage_flag,''N'')<>''Y''
             					) retained_amt
						,(SELECT AP_UTILITIES_PKG.ap_round_currency(SUM(aid.amount) *
				 		    NVL(ai.payment_cross_rate,1),ai.payment_currency_code)
						  FROM ap_invoice_distributions aid,ap_invoice_lines ail
						  WHERE ail.invoice_id=ai.invoice_id
						  AND aid.invoice_id=ai.invoice_id
						  AND ail.line_number = aid.invoice_line_number  
						  AND aid.prepay_distribution_id is not null
						  AND nvl(ail.invoice_includes_prepay_flag,''N'')<>''Y''
						) prepay_amt
						,(SELECT SUM(aip.amount)
						  FROM ap_invoice_payments aip
  						  WHERE aip.invoice_id =ai.invoice_id
						) pay_amt
						,(SELECT SUM(amount_remaining)
		            		          FROM ap_payment_schedules aps
						  WHERE aps.invoice_id=ai.invoice_id
						) amount_remain
				FROM ap_invoices ai
				WHERE ai.org_id = (##$$ORGID$$##)
			        AND ai.cancelled_date IS NULL
				AND ai.validation_request_id is NULL
   				AND ai.invoice_date between (''##$$FDATE$$##'')and (''##$$TDATE$$##'')
				 ) ap
			WHERE (((ap.invoice_amount*ap.payment_cross_rate) - disc_amt + nvl(ap.awt_amt,0) + nvl(ap.retained_amt,0))
				-(nvl(ap.pay_amt,0)-nvl(ap.prepay_amt,0))) <> nvl(ap.amount_remain,0)',
      p_title                  => 'Payment schedules which are fully paid, but do not have a payment_status_flag of Y',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case2');



debug('begin add_signature: INV_DATA_AIDA');
  add_signature(
      p_sig_id                 => 'INV_DATA_AIDA',
      p_sig_sql                => 'SELECT 
	invoice_id, 
	invoice_line_number, 
	substr(distribution_line_number,1,8) 
	distribution_line_number, 
	substr(line_type_lookup_code,1,9) line_type_lookup_code, 
	accounting_date, 
	period_name, 
	amount, 
	base_amount, 
	posted_flag, 
	match_status_flag, 
	encumbered_flag, 
	substr(dist_code_combination_id,1,15) dist_code_combination_id, 
	substr(accounting_event_id,1,15) accounting_event_id, 
	substr(bc_event_id,1,15) bc_event_id, 
	substr(invoice_distribution_id,1,15) invoice_distribution_id, 
	substr(parent_reversal_id,1,15) parent_reversal_id, 
	substr(po_distribution_id,1,15) po_distribution_id, 
	org_id 
  FROM 
	AP_INVOICE_DISTRIBUTIONS_ALL 
  WHERE 
	invoice_id in (##$$INVIDS$$##) AND
	rownum < 100
  ORDER BY 
	invoice_distribution_id, invoice_line_number, distribution_line_number asc',
      p_title                  => 'AP_INVOICE_DISTRIBUTIONS_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_DATA_AIDA');



debug('begin add_signature: 952763.1-STEP_3');
   l_info('Comments'):= 'The invoice cannot already be fully paid';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_3',
      p_sig_sql                => 'SELECT 
 		apsa.invoice_id, 
		aia.invoice_num,
		apsa.PAYMENT_STATUS_FLAG, 
		apsa.checkrun_id   PPR_Id,
		apsa.gross_amount,
		apsa.amount_remaining 
     FROM 
		ap_payment_schedules_all apsa, 
		ap_invoices_all aia
     WHERE 
		apsa.invoice_id in (''##$$INVIDS$$##'') AND
	      apsa.invoice_id = aia.invoice_id AND 
	      ((apsa.payment_status_flag NOT in (''P'', ''N'')) AND
		(aia.payment_status_flag NOT in (''P'', ''N'')))',
      p_title                  => '3: The payment schedule cannot be fully paid',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice that is already fully paid will not be selected by PPR',
      p_solution               => 'Fully paid invoices cannot be processed again',
      p_success_msg            => 'Invoice was not fully paid',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_3');



debug('begin add_signature: 17856010_CASE3');
   l_info('Bug'):= '17856010';
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
  add_signature(
      p_sig_id                 => '17856010_CASE3',
      p_sig_sql                => 'SELECT 
		ipsr.call_app_pay_service_req_code  PPR_Name,
		aisc.checkrun_id  PPR_Id,
	            aisc.check_date,
          		AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status) || ''(Case 3)'' Status,
          		aisc.request_id,
          		COUNT(DISTINCT invoice_id),
          		COUNT(invoice_id),
          		''Y''
        FROM 
		iby_pay_service_requests ipsr,
          		ap_inv_selection_criteria_all aisc,
          		ap_payment_schedules_all aps,
          		iby_docs_payable_all idp 
        WHERE 
	         	aps.checkrun_id                                                    	  = aisc.checkrun_id   AND
        		ipsr.call_app_pay_service_req_code                                  = aisc.checkrun_name    AND
        		ipsr.calling_app_id                                                   	  = 200    AND
        		idp.calling_app_doc_unique_ref1                                       = aps.checkrun_id    AND
        		idp.calling_app_doc_unique_ref2                                       = aps.invoice_id    AND
        		idp.calling_app_doc_unique_ref3                                       = aps.payment_num    AND
        		idp.payment_service_request_id                                        = ipsr.payment_service_request_id     AND
        		idp.document_status                                                   IN 
        (''REMOVED'',''REMOVED_INSTRUCTION_TERMINATED'', ''REMOVED_REQUEST_TERMINATED'', ''REMOVED_PAYMENT_REMOVED'', ''REMOVED_PAYMENT_SPOILED'',
         ''FAILED_VALIDATION'', ''PAYMENT_FAILED_VALIDATION'', ''REJECTED'', ''FAILED_BY_REJECTION_LEVEL'', ''FAILED_BY_CALLING_APP'',
         ''FAILED_BY_RELATED_DOCUMENT'', ''REMOVED_PAYMENT_STOPPED'', ''REMOVED_PAYMENT_VOIDED'')
        GROUP BY 
		aisc.checkrun_id,
          		aisc.check_date,
          		ipsr.call_app_pay_service_req_code,
          		AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status),
          		aisc.request_id',
      p_title                  => '3: PSR is CONFIRMED - Documents payable were removed but the corresponding invoices remained locked',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more PPR was terminated but corresponding invoices were not released',
      p_solution               => 'Please review the PPR and corresponding invoices. Use GDF [874862.1] for data fix.',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 17856010_CASE3');



debug('begin add_signature: 11810646_DUP_OWNER');
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
   l_info('Doc ID'):= '1370214.1';
  add_signature(
      p_sig_id                 => '11810646_DUP_OWNER',
      p_sig_sql                => 'SELECT account_owner_id
	,ext_bank_account_id
	, account_owner_party_id
	, end_date
	,primary_flag
	FROM iby_account_owners
	WHERE ext_bank_account_id IN(SELECT ext_Bank_account_id 
		FROM iby_account_owners
		WHERE primary_flag= ''Y''
		GROUP BY ext_bank_account_id 
		HAVING count(*) >1)
	AND primary_flag=''Y''',
      p_title                  => '11810646_DUP_OWNER: Identify Duplicate Primary Account Owner',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found duplicate primary account owners',
      p_solution               => 'Please review the duplicate account owner records found. Use GDF [1370214.1] for data fix.',
      p_success_msg            => 'No duplicate primary account owner records were found in table iby_account_owners',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 11810646_DUP_OWNER');



debug('begin add_signature: REQ_SRA_PROFILES');
  add_signature(
      p_sig_id                 => 'REQ_SRA_PROFILES',
      p_sig_sql                => 'select
      b.user_profile_option_name profile_name
      , a.profile_option_name profile_short_name
      , decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',''Application''
      ,''10003'',''Responsibility''
      ,''10004'',''User''
      ,''Unknown'') Level_type
      , decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',nvl(h.application_short_name,to_char(c.level_value))
      ,''10003'',nvl(g.responsibility_name,to_char(c.level_value))
      ,''10004'',nvl(e.user_name,to_char(c.level_value))
      ,''Unknown'') level_value
      , c.PROFILE_OPTION_VALUE profile_value
    from
      apps.fnd_profile_options a
      , apps.FND_PROFILE_OPTIONS_VL b
      , apps.FND_PROFILE_OPTION_VALUES c
      , apps.FND_USER d
      , apps.FND_USER e
      , apps.FND_RESPONSIBILITY_VL g
      , apps.FND_APPLICATION h
    where
      b.profile_option_name in (''IBY_XDO_DELIVERY_CFG_FILE'')
      and a.profile_option_name = b.profile_option_name
      and a.profile_option_id = c.profile_option_id
      and a.application_id = c.application_id
      and c.last_updated_by = d.user_id (+)
      and c.level_value = e.user_id (+)
      and c.level_value = g.responsibility_id (+)
      and c.level_value = h.application_id (+)
      order by
      b.user_profile_option_name, c.level_id,
      decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',nvl(h.application_short_name,to_char(c.level_value))
      ,''10003'',nvl(g.responsibility_name,to_char(c.level_value))
      ,''10004'',nvl(e.user_name,to_char(c.level_value))
      ,''Unknown'')',
      p_title                  => 'Required SRA Profile',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Profile "IBY: XML Publisher Delivery Manager Configuration File" has not been set.',
      p_solution               => '<ul> 
     <li>Please follow instructions in [804283.1] to setup profile and create xdodelivery.cfg file</li>
     </ul>',
      p_success_msg            => 'Required profile "IBY: XML Publisher Delivery Manager Configuration File" has been set.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: REQ_SRA_PROFILES');



debug('begin add_signature: CP_HEAP_CHECK');
   l_info('Comments'):= 'Minimun heap space consumes at least that amount, therefore setting it is just for cases where max memory consuption is expected';
   l_info('Doc ID'):= '747750.1';
  add_signature(
      p_sig_id                 => 'CP_HEAP_CHECK',
      p_sig_sql                => 'SELECT a.USER_CONCURRENT_PROGRAM_NAME, a.CONCURRENT_PROGRAM_NAME, nvl(a.EXECUTION_OPTIONS,''Not Set'') Execution_Options
      FROM FND_CONCURRENT_PROGRAMS_VL a,
           FND_EXECUTABLES b
     WHERE a.executable_id = b.executable_id
       AND a.application_id = 673
       AND ( b.EXECUTION_FILE_PATH = ''oracle.apps.xdo.oa.cp'' OR
		 a.concurrent_program_id in  ( 
							41782,               
					--          72326,                  
							109051,                 
							109066,                 
							109068,                           
							109070,                           
							109071,                           
							109072,                           
							109073,                           
							109074,                           
							109075,                 
							109078,                           
							109079,                           
							109080,                           
							109081,                           
							109082,                 
							109088,                 
							109091,                 
							127702,                                                         
							195728,                 
							196710,                           
							197703))
--             a.concurrent_program_name in (''IBY_FD_PAYMENT_FORMAT_TEXT'',
--                                           ''IBY_FD_FINAL_PMT_REGISTER'',
--                                           ''IBY_FD_PAYMENT_FORMAT'',
--                                           ''IBY_FD_FINAL_PMT_REGISTER'',
--                                           ''IBY_FD_PAYMENT_FORMAT''))
       AND ( a.EXECUTION_OPTIONS is NULL OR
            instr(a.EXECUTION_OPTIONS,''-mx2048m'') < 0)',
      p_title                  => 'BIP/Java based concurrent programs maximum heap is unset or too low',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The Java Heap space for Payments concurrent programs is likely too low or unset which can cause error "java.lang.OutOfMemoryError: Java heap space"',
      p_solution               => '<ul>
	<li>For normal processing 1024MB is recommended</li>
	<li>For large volume processing 2048MB is recommended</li>
	<li>Please follow instructions on Note [747750.1] to update the heap space to any of the values recommended above</li>
	<li>This heap is used by conc. program java executable when generating the data (xml) file</li>
	<li>More information on troubleshooting BIP integration with IBY see [1410160.1]</li>
</ul>
',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CP_HEAP_CHECK');



debug('begin add_signature: PPR_DATA_INCR');
  add_signature(
      p_sig_id                 => 'PPR_DATA_INCR',
      p_sig_sql                => 'SELECT 
	system_profile_code , 
	group_by_payment_date, 
	group_by_payment_currency, 
	group_by_internal_bank_account, 
	group_by_max_payments_flag, 
	group_by_pay_service_request , 
	group_by_legal_entity, 
	group_by_bill_payable, 
	group_by_organization, 
	group_by_max_instruction_flag , 
	group_by_payment_function , 
	group_by_payment_reason , 
	group_by_rfc , 
	max_payments_per_instruction, 
	max_amount_per_instr_value, 
	max_amount_per_instr_curr_code, 
	max_amount_fx_rate_type, 
	sort_option_1, 
	sort_order_1, 
	sort_option_2, 
	sort_order_2, 
	sort_option_3 , 
	sort_order_3 
      FROM 
	iby_instr_creation_rules 
      WHERE 
	SYSTEM_PROFILE_CODE in ( SELECT system_profile_code FROM iby_payment_profiles WHERE payment_profile_id in 
	(SELECT distinct payment_profile_id FROM iby_payments_all WHERE payment_service_request_id in 
		(Select PAYMENT_SERVICE_REQUEST_ID 
		from  iby_pay_service_requests 
		where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##''))))',
      p_title                  => 'IBY_INSTR_CREATION_RULES',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_INCR');



debug('begin add_signature: OPT_SRA_PROFILES');
  add_signature(
      p_sig_id                 => 'OPT_SRA_PROFILES',
      p_sig_sql                => 'select
      b.user_profile_option_name profile_name
      , a.profile_option_name profile_short_name
      , decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',''Application''
      ,''10003'',''Responsibility''
      ,''10004'',''User''
      ,''Unknown'') Level_type
      , decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',nvl(h.application_short_name,to_char(c.level_value))
      ,''10003'',nvl(g.responsibility_name,to_char(c.level_value))
      ,''10004'',nvl(e.user_name,to_char(c.level_value))
      ,''Unknown'') level_value
      , c.PROFILE_OPTION_VALUE profile_value
    from
      apps.fnd_profile_options a
      , apps.FND_PROFILE_OPTIONS_VL b
      , apps.FND_PROFILE_OPTION_VALUES c
      , apps.FND_USER d
      , apps.FND_USER e
      , apps.FND_RESPONSIBILITY_VL g
      , apps.FND_APPLICATION h
    where
      b.profile_option_name in (''IBY_SRA_DELIVERY_FAX_TYPE'', ''IEX_SMTP_FROM'',''IEX_SMTP_HOST'')
      and a.profile_option_name = b.profile_option_name
      and a.profile_option_id = c.profile_option_id
      and a.application_id = c.application_id
      and c.last_updated_by = d.user_id (+)
      and c.level_value = e.user_id (+)
      and c.level_value = g.responsibility_id (+)
      and c.level_value = h.application_id (+)
      order by
      b.user_profile_option_name, c.level_id,
      decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',nvl(h.application_short_name,to_char(c.level_value))
      ,''10003'',nvl(g.responsibility_name,to_char(c.level_value))
      ,''10004'',nvl(e.user_name,to_char(c.level_value))
      ,''Unknown'')',
      p_title                  => 'Other SRA related profiles',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No profile has been set.',
      p_solution               => '<ul> 
     <li>For email & fax delivery, ensure that xdodelivery.cfg is created and profile ''IBY: XML Publisher Delivery Manager Configuration File'' is set</li>
     <li>Please follow instructions in [804283.1] to create xdodelivery.cfg file</li>
     <li>Refer to [1072399.1] for additional details on all SRA related setup</li> 
     <li>For Profile IBY: Fax for delivering Separate Remittance Advice, value of ''R'' indicates Rightfax and ''I'' indicates IPP Fax</li>
     </ul>',
      p_success_msg            => 'Click on arrow above to see which profile(s) has been set.
	Following profiles are being checked:
	<ul> 
     <li>IBY: Fax for delivering Separate Remittance Advice</li>
     <li>IEX: SMTP From</li>
     <li>IEX: SMTP Host</li> 
     </ul>
	 Recommendations if some profile has not been set:<ul>
	 <li>For email & fax delivery, ensure that xdodelivery.cfg is created and profile ''IBY: XML Publisher Delivery Manager Configuration File'' is set</li>
     <li>Please follow instructions in [804283.1] to create xdodelivery.cfg file</li>
     <li>Refer to [1072399.1] for additional details on all SRA related setup</li> 
     <li>For Profile IBY: Fax for delivering Separate Remittance Advice, value of ''R'' indicates Rightfax and ''I'' indicates IPP Fax</li>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPT_SRA_PROFILES');



debug('begin add_signature: PPR_DATA_IPA');
  add_signature(
      p_sig_id                 => 'PPR_DATA_IPA',
      p_sig_sql                => 'Select 
	Payment_id, 
	payment_method_code, 
	payment_status, 
	payments_complete_flag, 
	payment_amount, 
	internal_bank_Account_id, 
	ext_payee_id, 
	payment_instruction_id, 
	payment_profile_id, 
	void_Date 
       From 
	iby_payments_all 
       Where 
	payment_service_request_id  in  
		(Select PAYMENT_SERVICE_REQUEST_ID 
		from  iby_pay_service_requests 
		where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##''))',
      p_title                  => 'IBY_PAYMENTS_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_IPA');



debug('begin add_signature: PPR_DATA_IPIA');
  add_signature(
      p_sig_id                 => 'PPR_DATA_IPIA',
      p_sig_sql                => 'Select 
	payment_instruction_id, 
	payment_instruction_status, 
	payment_profile_id, 
	payment_count, 
	payments_complete_code, 
	payment_service_request_id, 
	print_instruction_immed_flag, 
	transmit_instr_immed_flag, 
	internal_bank_Account_id, 
	payment_document_id, 
	payment_reason_code, 
	payment_date, 
	payment_currency_code 
    From 
	iby_pay_instructions_all 
    Where 
	PAY_ADMIN_ASSIGNED_REF_CODE in (''##$$PPRNAME$$##'')',
      p_title                  => 'IBY_PAY_INSTRUCTIONS_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_IPIA');



debug('begin add_signature: PPR_DATA_IPSR');
  add_signature(
      p_sig_id                 => 'PPR_DATA_IPSR',
      p_sig_sql                => 'SELECT 
		ipsr.PAYMENT_SERVICE_REQUEST_ID, 
            ipsr.CALLING_APP_ID, 
            ipsr.CALL_APP_PAY_SERVICE_REQ_CODE,
            ipsr.PAYMENT_SERVICE_REQUEST_STATUS,
            ipsr.PROCESS_TYPE, 
            ipsr.ALLOW_ZERO_PAYMENTS_FLAG,
            ipsr.creation_date,
            ipsr.INTERNAL_BANK_ACCOUNT_ID,
            ipsr.PAYMENT_PROFILE_ID, 
            ipsr.MAXIMUM_PAYMENT_AMOUNT,
            ipsr.MINIMUM_PAYMENT_AMOUNT, 
            ipsr.DOCUMENT_REJECTION_LEVEL_CODE, 
            ipsr.PAYMENT_REJECTION_LEVEL_CODE, 
            ipsr.REQUIRE_PROP_PMTS_REVIEW_FLAG,
            ipsr.ORG_TYPE, 
            ipsr.CREATE_PMT_INSTRUCTIONS_FLAG, 
            ipsr.PAYMENT_DOCUMENT_ID,
            ipsr.REQUEST_ID
	FROM 
		IBY_PAY_SERVICE_REQUESTS ipsr
	WHERE 
		ipsr.PAYMENT_SERVICE_REQUEST_ID in  
			(Select PAYMENT_SERVICE_REQUEST_ID 
			from  iby_pay_service_requests 
			where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##''))',
      p_title                  => 'IBY_PAY_SERVICE_REQUESTS',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_IPSR');



debug('begin add_signature: INV_DATA_APSA');
  add_signature(
      p_sig_id                 => 'INV_DATA_APSA',
      p_sig_sql                => 'SELECT 
		apsa.invoice_id,
 		apsa.checkrun_id  PPR_Id, 
            apsa.payment_status_flag,
            apsa.payment_method_code, 
            apsa.amount_remaining, 
            apsa.payment_priority , 
            apsa.hold_flag,
            apsa.due_date,
            apsa.discount_date,
            apsa.second_discount_date,
            apsa.third_discount_date
	FROM 
		ap_payment_schedules_all apsa 
	WHERE 
		apsa.invoice_id in (##$$INVIDS$$##)',
      p_title                  => 'AP_PAYMENT_SCHEDULES_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_DATA_APSA');



debug('begin add_signature: Void-sql2');
   l_info('Doc ID'):= '1326421.1';
  add_signature(
      p_sig_id                 => 'Void-sql2',
      p_sig_sql                => 'SELECT pv.vendor_name "Vendor Name", ai.invoice_num "Invoice Num",
     ai.invoice_id "Invoice Id", ai.invoice_amount "Invoice amount", 
	 ail.line_number "Invoice Line Num",
     ai2.invoice_id "Prepay Invoice Id", ai2.invoice_num "Prepay Invoice Num",
     ail.prepay_line_number "Prepay Invoice Line Num",
     (-1)*(ail.amount - NVL(ail.included_tax_amount,0)) "Prepay Amount Applied",
     NULLIF((-1)*(NVL(ail.total_rec_tax_amount, 0) + NVL(ail.total_nrec_tax_amount, 0)), 0)  "Tax amount Applied"                         
       FROM AP_INVOICES_ALL ai, AP_INVOICES_ALL ai2, AP_INVOICE_LINES_ALL ail, AP_SUPPLIERS pv                      
         WHERE ai.invoice_id = ail.invoice_id                      
           AND ai2.invoice_id = ail.prepay_invoice_id                      
           AND ail.amount < 0                      
           AND NVL(ail.discarded_flag,''N'') <> ''Y''                      
           AND ail.line_type_lookup_code = ''PREPAY''                      
           AND ai.vendor_id = pv.vendor_id                      
           AND ai.invoice_type_lookup_code NOT IN (''PREPAYMENT'', ''CREDIT'',''DEBIT'')                      
           AND ai.invoice_id = (##$$INVIDS$$##)',
      p_title                  => 'Prepayment invoices applied to invoice',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Invoice is not applied to any prepayment invoice',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Void-sql2');



debug('begin add_signature: OPP_PROC_CHECK');
   l_info('Comments'):= 'OPP Processes & Threads';
   l_info('Doc ID'):= '1268217.1';
  add_signature(
      p_sig_id                 => 'OPP_PROC_CHECK',
      p_sig_sql                => 'SELECT 
		MIN_PROCESSES, 
		MAX_PROCESSES,  
		SLEEP_SECONDS, 
		substr(service_parameters, 57,1) Threads
    FROM 
		FND_CONCURRENT_QUEUE_SIZE
    WHERE 
		SERVICE_PARAMETERS like ''%oracle.apps.fnd.cp.opp.OPPServiceThread:2:0%''',
      p_title                  => 'Output Post Processor (OPP) Processes & Threads',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Ensure that process & thread count for OPP Manager is sufficient to handle the loads',
      p_solution               => '<ul>
	<li>Default value for process and thread is 1 and 5</li>
	<li>If you see reports failing with timeout error waiting for OPP, try adding more processes</li>
	<li>Make sure to bounce OPP manager after increasing processes/threads</li>
</ul>
',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPP_PROC_CHECK');



debug('begin add_signature: 18027976-Case3');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case3',
      p_sig_sql                => 'SELECT distinct ap.invoice_id,
					ai.invoice_num,
					ap.org_id,
					''Null Amt Remaining'' Reason,
					''Y'' process_flag
			FROM ap_payment_schedules ap,ap_invoices ai 
			WHERE ap.amount_remaining IS NULL
			AND ap.invoice_id = ai.invoice_id
			AND ap.org_id = (##$$ORGID$$##)
			AND ap.checkrun_id IS NULL
			AND ai.invoice_date between  (''##$$FDATE$$##'')and (''##$$TDATE$$##'')',
      p_title                  => 'Invoices which are fully paid, but do not have a payment_status_flag of Y',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case3');



debug('begin add_signature: 17856010_CASE4');
   l_info('Bug'):= '17856010';
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
  add_signature(
      p_sig_id                 => '17856010_CASE4',
      p_sig_sql                => 'SELECT 
          		ipsr.call_app_pay_service_req_code   PPR_NAME,
		aisc.checkrun_id   PPR_Id,
	            aisc.check_date,
          		AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status) || '' (Case 4)'' Status,
          		aisc.request_id,
          		COUNT(DISTINCT invoice_id),
          		COUNT(invoice_id),
          		''Y''
FROM 
		iby_pay_service_requests ipsr,
          		ap_inv_selection_criteria_all aisc,
          		ap_payment_schedules_all aps
          
WHERE 
		aps.checkrun_id                                                       = aisc.checkrun_id    AND
		ipsr.call_app_pay_service_req_code                                    = aisc.checkrun_name   AND
        		ipsr.calling_app_id                                                   = 200     AND
        		AP_PAYMENT_UTIL_PKG.get_psr_status (ipsr.payment_service_request_id,ipsr.payment_service_request_status) = ''CONFIRMED''   AND NOT EXISTS
		        (SELECT ''Corresponding Docs Payable'' from iby_docs_payable_all idp
		        WHERE idp.calling_app_doc_unique_ref1                                     = aps.checkrun_id
		        AND idp.calling_app_doc_unique_ref2                                       = aps.invoice_id
		        AND idp.calling_app_doc_unique_ref3                                       = aps.payment_num
		        AND idp.payment_service_request_id                                        = ipsr.payment_service_request_id
		        )
GROUP BY 
		aisc.checkrun_id,
          		aisc.check_date,
          		ipsr.call_app_pay_service_req_code,
	            AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status),
	           aisc.request_id',
      p_title                  => '4: PSR in PENDING REVIEW - New invoices were added but they were neither paid or released',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Newly added invoices during PPR in Pending Review status were neither paid nor released',
      p_solution               => 'Please review the PPR and corresponding invoices. Use GDF [874862.1] for data fix.',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 17856010_CASE4');



debug('begin add_signature: SRA_MESSAGES');
  add_signature(
      p_sig_id                 => 'SRA_MESSAGES',
      p_sig_sql                => 'SELECT 
		APPLICATION_ID,
		LANGUAGE_CODE,
		MESSAGE_NAME,
		MESSAGE_TEXT
	FROM 
		FND_NEW_MESSAGES
	WHERE
		MESSAGE_NAME like ''IBY_FD_SRA_EMAIL%''',
      p_title                  => 'SRA Message Setup',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Separate Remittance Advice Message Setup.
	<ul>
     <li>Please customize SRA related messages to your business conditions. Ensure that message SRA EMAIL FROM is set to a valid email address </li>
     <li>To update these messages, use the navigation below: </li>
		<ol>
	     <li>Responsibility: Application Developer-->Messages-->Query the messages and update the text</li>
       </ol>
     <li>Refer to [1072399.1] for additional details on all SRA related setup</li> 
     </ul>',
      p_solution               => '',
      p_success_msg            => 'Separate Remittance Advice Message Setup.
	<ul>
     <li>Please customize SRA related messages to your business conditions. Ensure that message SRA EMAIL FROM is set to a valid email address </li>
     <li>To update these messages, use the navigation below: </li>
		<ol>
	     <li>Responsibility: Application Developer-->Messages-->Query the messages and update the text</li>
       </ol>
     <li>Refer to [1072399.1] for additional details on all SRA related setup</li> 
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SRA_MESSAGES');



debug('begin add_signature: 952763.1-STEP_4');
   l_info('Comments'):= 'The invoice cannot be subject to forced revalidation';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_4',
      p_sig_sql                => 'SELECT 
		aia.invoice_id,
		aia.invoice_num,  
		apsa.gross_amount,
		apsa.amount_remaining, 
		aia.force_revalidation_flag 
     FROM 
		ap_invoices_all aia,
		ap_payment_schedules_all apsa
     WHERE 
		aia.invoice_id in (''##$$INVIDS$$##'') AND
            aia.invoice_id = apsa.invoice_id   AND
		aia.force_revalidation_flag NOT in (''N'', Null)',
      p_title                  => '4: Invoice cannot be subject to forced revalidation',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice has a status of force validation',
      p_solution               => 'Re-validate the invoice before it can be selected by a PPR',
      p_success_msg            => 'Invoice is not marked for forced revalidation',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_4');



debug('begin add_signature: 952763.1-STEP_5');
   l_info('Comments'):= 'The payment schedules payment priority must be between the Payment Priority High and Payment Priority Low parameters designated for the PPR';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_5',
      p_sig_sql                => 'SELECT 
            apsa.invoice_id, 
            apsa.payment_status_flag,
            apsa.payment_method_code, 
            apsa.amount_remaining, 
            apsa.payment_priority , 
            apsa.hold_flag,
            apsa.due_date,
            apsa.discount_date,
            apsa.second_discount_date,
            apsa.third_discount_date,
            aisca.low_payment_priority,
            aisca.hi_payment_priority
     FROM 
       	ap_payment_schedules_all apsa, 
		ap_inv_selection_criteria_all aisca
     WHERE 
            apsa.invoice_id in (''##$$INVIDS$$##'') AND 
            aisca.checkrun_id in (''##$$PPRID$$##'') AND 
            nvl(apsa.payment_priority,99)  NOT BETWEEN (aisca.hi_payment_priority) AND (aisca.low_payment_priority)',
      p_title                  => '5: Invoice payment priority falls within the range specified in PPR',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice has payment priority that falls outsite the range specified in PPR details',
      p_solution               => 'Adjust the PPR payment priority high and low values to include the invoice payment priority',
      p_success_msg            => 'Invoice does not have payment priority that falls outside the hi and low payment priority specified in PPR',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_5');



debug('begin add_signature: OPP_TIMEOUT_CHECK');
   l_info('Comments'):= 'Minimun heap space consumes at least that amount, therefore setting it is just for cases where max memory consuption is expected';
   l_info('Doc ID'):= '352518.1';
  add_signature(
      p_sig_id                 => 'OPP_TIMEOUT_CHECK',
      p_sig_sql                => 'select
      b.user_profile_option_name profile_name
      , a.profile_option_name profile_short_name
      , decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',''Application''
      ,''10003'',''Responsibility''
      ,''10004'',''User''
      ,''Unknown'') Level_type
      , decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',nvl(h.application_short_name,to_char(c.level_value))
      ,''10003'',nvl(g.responsibility_name,to_char(c.level_value))
      ,''10004'',nvl(e.user_name,to_char(c.level_value))
      ,''Unknown'') level_value
      , c.PROFILE_OPTION_VALUE profile_value
    from
      apps.fnd_profile_options a
      , apps.FND_PROFILE_OPTIONS_VL b
      , apps.FND_PROFILE_OPTION_VALUES c
      , apps.FND_USER d
      , apps.FND_USER e
      , apps.FND_RESPONSIBILITY_VL g
      , apps.FND_APPLICATION h
    where
      b.user_profile_option_name like ''%OPP%''
      and a.profile_option_name = b.profile_option_name
      and a.profile_option_id = c.profile_option_id
      and a.application_id = c.application_id
      and c.last_updated_by = d.user_id (+)
      and c.level_value = e.user_id (+)
      and c.level_value = g.responsibility_id (+)
      and c.level_value = h.application_id (+)
      order by
      b.user_profile_option_name, c.level_id,
      decode(to_char(c.level_id),''10001'',''Site''
      ,''10002'',nvl(h.application_short_name,to_char(c.level_value))
      ,''10003'',nvl(g.responsibility_name,to_char(c.level_value))
      ,''10004'',nvl(e.user_name,to_char(c.level_value))
      ,''Unknown'')',
      p_title                  => 'Output Post Processor (OPP) timeout likely too low',
      p_fail_condition         => '[PROFILE_VALUE] < [300]',
      p_problem_descr          => 'The timeout that the OPP uses when waiting for external requests is likely too low',
      p_solution               => '<ul>
	<li>Concurrent:OPP Response Timeout - specifies the amount of time a manager waits for OPP to respond to its request for post processing</li>
	<li>If your request is completing in warning status with a message indicating OPP did not pick up the request in the time indicated by this profile, consider increasing the response timeout</li>
	<li>Default setting for response timeout is 120 seconds. Try increasing to 300 seconds.</li>
	<li>If your request still completes in warning status, next step is to increase the number of processes and threads available for OPP</li>
	<li>Concurrent:OPP Process Timeout - specifies the amount of time the manager waits for the OPP to actually process the request</li>
	<li>If your request is completing in error status with a message indicating timeout while waiting for OPP to complete processing, consider increasing the process timeout</li>
	<li>Default setting for process timeout is 300 seconds. You can increase it to any suitable value</li>
	<li>For more information see [352518.1] and [862644.1]</li>
</ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPP_TIMEOUT_CHECK');



debug('begin add_signature: PPR_DATA_CBA');
  add_signature(
      p_sig_id                 => 'PPR_DATA_CBA',
      p_sig_sql                => 'SELECT Internal_Bank_Account_Id
    from iby_pay_service_requests
	where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##'')',
      p_title                  => 'CE_BANK_ACCOUNTS',
      p_fail_condition         => 'NRS',
      p_problem_descr          => ' ',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_CBA');



debug('begin add_signature: SRA_PPP_SETUP');
  add_signature(
      p_sig_id                 => 'SRA_PPP_SETUP',
      p_sig_sql                => 'SELECT  
		SYSTEM_PROFILE_CODE, 
		REMITTANCE_ADVICE_FORMAT_CODE, 
		REMIT_ADVICE_DELIVERY_METHOD  PPR_Delivery_Method, 
		AUTOMATIC_SRA_SUBMIT_FLAG, 
		SRA_OVERRIDE_PAYEE_FLAG, 
		DOCUMENT_COUNT_LIMIT, 
		ALLOW_MULTIPLE_COPY_FLAG,
		PAYMENT_DETAILS_LENGTH_LIMIT 
	FROM  
		IBY_REMIT_ADVICE_SETUP 
      WHERE 
		SYSTEM_PROFILE_CODE in 
			(select SYSTEM_PROFILE_CODE from IBY_SYS_PMT_PROFILES_TL where SYSTEM_PROFILE_NAME in 
			    (select PAYMENT_PROFILE_SYS_NAME from iby_payments_all where PAYMENT_SERVICE_REQUEST_ID in 
				    (select PAYMENT_SERVICE_REQUEST_ID from iby_pay_service_requests where CALL_APP_PAY_SERVICE_REQ_CODE in ''##$$PPRNAME$$##'')))',
      p_title                  => 'SRA Setup in Payment Process Profile (PPP)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Separate Remittance Advice related setup in payment process profile details',
      p_solution               => 'Separate Remittance Advice related setup in payment process profile details. 
	 <ul>
     <li>Please validate the following details from the data by clicking on arrow above</li>
	<ol>
	<li> Ensure that Remittance_Advice_Format_Code is specified</li>
	<li> To automatically send remittance after completion of PPR, ensure that Automatic_Sra_Submit_Flag is set</li>
	<li> If you wish the PPR remittance advice settings to override the supplier level details, ensure that Sra_Override_Payee_Flag is set</li>
	<li> You can update the setup using following steps:
		<ol>
		<li>Navigate to Payments Setup Administrator-->Funds Disbursement Setup-->Payment Process Profiles</li>
		<li>Query the Payment Process Profile being used</li>
	     <li>Navigate to Reporting Tab-->Separate Remittance Advice section and populate the details</li> 
          </ol>
      <li> For Email or Fax delivery methods, ensure that the email address or fax number is specified in the supplier detail</li>
      <li> These details can be specified either at supplier or supplier site level</li>
      <li> You can update the supplier setup using following steps:</li>
		<ol>
		<li>Navigate to Payables-->Suppliers-->Entry</li>
		<li>Query the supplier</li>
	     <li>Navigate to 	Reporting-->Payment Details-->Payment Attributes Section-->Separate Remittance Advice Delivery tab</li> 
		<li>Update Delivery Method, Email and Fax</li>
          </ol>
      </ol>
	  <li>If no data is returned for Separate Remittance Advice setup, it could be due to following scenarios:</li>
	<ol>
     <li> Payment Process Profile was not specified when submitting the PPR</li>
     <li> PPR probably errored out or terminated before it reached the point where payment processs profile was defaulted/specified at the time of payment creation</li>
     <li> PPR completed with status Cancelled - No Invoices Selected </li> 
	</ol>
     </ul>',
      p_success_msg            => 'Separate Remittance Advice related setup in payment process profile details.
	<ul>
     <li>Please validate the following details from the data by clicking on arrow above</li>
	<ol>
	<li> Ensure that Remittance_Advice_Format_Code is specified</li>
	<li> To automatically send remittance after completion of PPR, ensure that Automatic_Sra_Submit_Flag is set</li>
	<li> If you wish the PPR remittance advice settings to override the supplier level details, ensure that Sra_Override_Payee_Flag is set</li>
	<li> You can update the setup using following steps:
		<ol>
		<li>Navigate to Payments Setup Administrator-->Funds Disbursement Setup-->Payment Process Profiles</li>
		<li>Query the Payment Process Profile being used</li>
	     <li>Navigate to Reporting Tab-->Separate Remittance Advice section and populate the details</li> 
          </ol>
      <li> For Email or Fax delivery methods, ensure that the email address or fax number is specified in the supplier detail</li>
      <li> These details can be specified either at supplier or supplier site level</li>
      <li> You can update the supplier setup using following steps:</li>
		<ol>
		<li>Navigate to Payables-->Suppliers-->Entry</li>
		<li>Query the supplier</li>
	     <li>Navigate to 	Reporting-->Payment Details-->Payment Attributes Section-->Separate Remittance Advice Delivery tab</li> 
		<li>Update Delivery Method, Email and Fax</li>
          </ol>
      </ol>
	  <li>If no data is returned for Separate Remittance Advice setup, it could be due to following scenarios:</li>
	<ol>
     <li> Payment Process Profile was not specified when submitting the PPR</li>
     <li> PPR probably errored out or terminated before it reached the point where payment processs profile was defaulted/specified at the time of payment creation</li>
     <li> PPR completed with status Cancelled - No Invoices Selected </li> 
	</ol>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SRA_PPP_SETUP');



debug('begin add_signature: INV_DATA_ADP');
  add_signature(
      p_sig_id                 => 'INV_DATA_ADP',
      p_sig_sql                => 'SELECT 
	pay_proc_trxn_type_code, 
	calling_app_doc_unique_ref1 check_id, 
	calling_app_doc_unique_ref2 invoice_id, 
	calling_app_doc_unique_ref4 invoice_payment_id, 
	calling_app_doc_ref_number invoice_number, 
	payment_function, 
	payment_date, 
	document_date, 
	document_type, 
	payment_currency_code, 
	payment_amount, 
	payment_method_code 
  FROM 
	AP_DOCUMENTS_PAYABLE 
  WHERE 
	calling_app_id = 200 AND 
	calling_app_doc_unique_ref2 in (##$$INVIDS$$##)',
      p_title                  => 'AP_DOCUMENTS_PAYABLE',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_DATA_ADP');



debug('begin add_signature: 17856010_CASE5');
   l_info('Bug'):= '17856010';
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
  add_signature(
      p_sig_id                 => '17856010_CASE5',
      p_sig_sql                => 'SELECT 
            	aisc.checkrun_name  PPR_NAME,
		aisc.checkrun_id   PPR_Id,
	            aisc.check_date,
            	aisc.status || '' (Case 5)'' Status,
            	aisc.request_id,
            	COUNT(DISTINCT aps.invoice_id),
            	COUNT(aps.invoice_id),
            	''Y''
FROM 
		ap_inv_selection_criteria_all aisc,
               	ap_payment_schedules_all aps
WHERE 
		aps.checkrun_id = aisc.checkrun_id AND NOT EXISTS
            	(SELECT ''Data in AP_SELECTED_INVOICES_ALL''
            	FROM ap_selected_invoices_all asi
            	WHERE asi.checkrun_id = aisc.checkrun_id
	            )
GROUP BY 
		aisc.checkrun_id,
	            aisc.check_date,
            	aisc.checkrun_name,
            	aisc.status,
            	aisc.request_id',
      p_title                  => '5: PPR is stuck in SELECTING/CANCELING status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more PPR was stuck in SELECTING/CANCELING status',
      p_solution               => 'Please review the PPR and corresponding invoices. Use GDF [874862.1] for data fix.',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 17856010_CASE5');



debug('begin add_signature: 18027976-Case4');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case4',
      p_sig_sql                => 'SELECT ap.invoice_id,
				ap.invoice_num,
				ap.org_id,
				ap.Reason,
				''Y'' process_flag
			FROM 
				(SELECT ''Fully paid but Payment_status_flag not Y'' Reason
						,ai.invoice_id
						,ai.invoice_num
						,ai.org_id
						,ai.invoice_amount
						,ai.amount_paid
						,(SELECT AP_UTILITIES_PKG.ap_round_currency(SUM(aid.amount) *
						    NVL(ai.payment_cross_rate,1),ai.payment_currency_code)
            					  FROM ap_invoice_distributions aid,ap_invoice_lines ail
						  WHERE ail.invoice_id = ai.invoice_id
            					  AND aid.invoice_id = ai.invoice_id
						  AND ail.line_number = aid.invoice_line_number  
						  AND aid.prepay_distribution_id is not null
						  AND nvl(ail.invoice_includes_prepay_flag,''N'')<>''Y''
						) prepay_amt
						,(SELECT SUM(aip.amount)
						  FROM ap_invoice_payments aip
            					  WHERE aip.invoice_id = ai.invoice_id
						 ) pay_amt
						,(SELECT SUM(aps.amount_remaining)
						  FROM ap_payment_schedules aps
            					  WHERE aps.invoice_id = ai.invoice_id
						) amount_remain
				 FROM ap_invoices ai,ap_payment_schedules aps1
				 WHERE ai.org_id = (##$$ORGID$$##)
				 AND aps1.invoice_id = ai.invoice_id
				 AND (ai.payment_status_flag <> ''Y'' OR aps1.payment_status_flag <>''Y'')
				 AND ai.cancelled_date IS NULL
				 AND ai.validation_request_id IS NULL
 				 AND aps1.checkrun_id IS NULL
				 AND ai.invoice_date between  (''##$$FDATE$$##'')and (''##$$TDATE$$##'')
				) ap
			WHERE (nvl(ap.pay_amt,0) - nvl(ap.prepay_amt,0)) = nvl(ap.amount_paid,0)
			AND ap.amount_paid <> 0
 			AND ap.amount_remain = 0',
      p_title                  => 'Invoices which are not fully paid, but have a payment_status_flag of Y',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case4');



debug('begin add_signature: SRA_FORMAT_SETUP');
  add_signature(
      p_sig_id                 => 'SRA_FORMAT_SETUP',
      p_sig_sql                => 'Select 
   	   ifv.FORMAT_NAME,
	   ifv.FORMAT_CODE ,                   
	   ifv.FORMAT_TYPE_CODE,               
	   ifv.FORMAT_TEMPLATE_CODE,
	   xl.FILE_NAME,
	   xl.LOB_TYPE,
	   xl.LANGUAGE,
	   xl.TERRITORY,
	   xl.XDO_FILE_TYPE,
	   ifv.SEEDED_FLAG
	From 
	  iby_formats_vl ifv,
	  XDO_LOBS xl
     Where 
	  ifv.FORMAT_CODE like ''%REMIT%'' and 
	  ifv.FORMAT_TYPE_CODE = ''REMITTANCE_ADVICE'' and 
	  ifv.FORMAT_TEMPLATE_CODE = xl.LOB_CODE(+)',
      p_title                  => 'SRA Notification Format',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Separate Remittance Advice Notification Format',
      p_solution               => 'Separate Remittance Advice Notification Format.
	 <ul>
     <li>Please validate the following details from the data by clicking on arrow above</li>
	<ol>
	<li> Check format and template details and ensure that they are accurate</li>
	<li> Makesure that you have a valid template file associated with the format</li>
     </ul>',
      p_success_msg            => 'Separate Remittance Advice Notification Format.
	 <ul>
     <li>Please validate the following details from the data by clicking on arrow above</li>
	<ol>
	<li> Check format and template details and ensure that they are accurate</li>
	<li> Makesure that you have a valid template file associated with the format</li>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SRA_FORMAT_SETUP');



debug('begin add_signature: 18027976-Case5');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case5',
      p_sig_sql                => 'SELECT ap.invoice_id,
				ap.invoice_num,
				ap.org_id,
				ap.Reason,
				''Y'' process_flag
			FROM 
				(SELECT ''Inv unpaid but Payment_status_flag not N'' Reason
						,ai.invoice_id
						,ai.invoice_num
						,ai.org_id
						,ai.invoice_amount
						,ai.amount_paid
				 FROM ap_invoices ai,ap_payment_schedules aps
				 WHERE ai.org_id = (##$$ORGID$$##)
		  		 AND ai.invoice_id = aps.invoice_id
        			 AND (nvl(ai.payment_status_flag,''N'') <> ''N'' OR nvl(aps.payment_status_flag,''N'') <> ''N'')
				 AND ai.cancelled_date IS NULL
				 AND ai.invoice_amount <> 0
				 AND ai.validation_request_id IS NULL
				 AND aps.checkrun_id IS NULL
				 AND ai.invoice_date between (''##$$FDATE$$##'')and (''##$$TDATE$$##'')
				) ap
			WHERE nvl(ap.amount_paid,0) = 0',
      p_title                  => 'Invoices which are partially paid, but have a payment_status_flag of N or Y',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case5');



debug('begin add_signature: INV_DATA_AIPA');
  add_signature(
      p_sig_id                 => 'INV_DATA_AIPA',
      p_sig_sql                => 'SELECT 
	check_id, 
	substr(invoice_payment_id,1,15) invoice_payment_id, 
	amount, payment_base_amount, 
	invoice_base_amount, 
	accounting_date, 
	period_name, 
	posted_flag, 
	accounting_event_id, 
	invoice_id, 
	org_id 
FROM 
	AP_INVOICE_PAYMENTS_ALL 
WHERE 
	invoice_id in (##$$INVIDS$$##) 
ORDER BY check_id asc',
      p_title                  => 'AP_INVOICE_PAYMENTS_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist or no payments data exists',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_DATA_AIPA');



debug('begin add_signature: 17856010_CASE6');
   l_info('Bug'):= '17856010';
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
  add_signature(
      p_sig_id                 => '17856010_CASE6',
      p_sig_sql                => 'SELECT 
            	aisc.checkrun_name  PPR_NAME,
		aisc.checkrun_id  PPR_Id,
            	aisc.check_date,
            	aisc.status || '' (Case 6)'' Status,
            	aisc.request_id,
            	COUNT(DISTINCT aps.invoice_id),
            	COUNT(aps.invoice_id),
            	''Y''
FROM 
		ap_inv_selection_criteria_all aisc,
               	ap_payment_schedules_all aps
WHERE 
		aps.checkrun_id = aisc.checkrun_id AND EXISTS
	            (select 1
            	from ap_selected_invoices_all si2, 
		ap_payment_schedules_all ps
	            where si2.checkrun_id = aisc.checkrun_id
            	and si2.invoice_id = ps.invoice_id
            	and si2.payment_num = ps.payment_num
            	and ( (si2.org_id is null and ps.org_id is not null)  OR
                   	si2.exclusive_payment_flag is null OR
                   	ps.payment_method_code is null OR
                   	si2.payment_amount is null OR
                   	si2.payment_currency_code is null OR
                   	aisc.check_date is null  
	                )
            	 )       
GROUP BY 
		aisc.checkrun_id,
            	aisc.check_date,
            	aisc.checkrun_name,
            	aisc.status,
            	aisc.request_id',
      p_title                  => '6: PSR is CONFIRMED - New invoices added were neither paid or released',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more PPR was confirmed but newly added invoices were neither paid nor released',
      p_solution               => 'Please review the PPR and corresponding invoices. Use GDF [874862.1] for data fix.',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 17856010_CASE6');



debug('begin add_signature: OPP_RUNTIME_PROPS');
   l_info('Doc ID'):= '737311.1, 1410160.1';
  add_signature(
      p_sig_id                 => 'OPP_RUNTIME_PROPS',
      p_sig_sql                => 'SELECT xcpt.property_name PROPERTY_NAME, 
         xcp.xdo_cfg_name CONFIGURATION_NAME,
         DECODE (TO_CHAR (xcv.config_level), ''10'', ''Site'',''30'', ''DataSource'',''50'', ''Template'', ''???'') "LEVEL",
         DECODE (TO_CHAR (xcv.config_level), ''10'', '' '',''30'', xd.application_short_name || ''|'' || xd.data_source_code, ''50'', xt.application_short_name || ''|'' || xt.template_code,''???'') "CONTEXT_SHORT",
         DECODE (TO_CHAR (xcv.config_level), ''10'', '' '',''30'', 
                   (SELECT fat1.application_name || ''|'' || xdt.data_source_name
                      FROM xdo_ds_definitions_tl xdt, 
                           fnd_application fa1, 
                           fnd_application_tl fat1	
                     WHERE fa1.application_id = fat1.application_id 
                       AND fat1.LANGUAGE = ''US''
                       AND xd.application_short_name = fa1.application_short_name
                       AND xd.application_short_name = xdt.application_short_name
                       AND xd.data_source_code = xdt.data_source_code AND xdt.LANGUAGE = ''US''),
                   ''50'', (SELECT fat2.application_name || ''|'' || xtt.template_name
                            FROM xdo_templates_tl xtt, 
                                 fnd_application fa2, 
                                 fnd_application_tl fat2
                           WHERE fa2.application_id = fat2.application_id 
                             AND fat2.LANGUAGE = ''US''
                             AND xt.application_short_name = fa2.application_short_name
                             AND xt.application_short_name = xtt.application_short_name
                             AND xtt.template_code = xt.template_code 
                             AND xtt.LANGUAGE = ''US''), ''???'' ) "CONTEXT_DETAIL", xcv.VALUE PROPERTY_VALUE
    FROM xdo_config_properties_b xcp, xdo_config_properties_tl xcpt,
         xdo_config_values xcv, xdo_ds_definitions_b xd, xdo_templates_b xt
   WHERE xcp.property_code = xcpt.property_code AND xcpt.LANGUAGE = ''US''
     AND xcv.property_code = xcp.property_code
     AND xd.application_short_name(+) = xcv.application_short_name
     AND xd.data_source_code(+) = xcv.data_source_code
     AND xt.application_short_name(+) = xcv.application_short_name
     AND xt.template_code(+) = xcv.template_code
   ORDER BY xcv.config_level, xcp.CATEGORY, xcp.sort_order',
      p_title                  => 'BIP Runtime Properties',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'BI Publisher runtime properties Settings. Optimize these settting to prevent "java.lang.OutOfMemoryError" errors in the Output Post Processor log',
      p_solution               => '<p><ul><br />
     <li>Modify XDO runtime params to use optimization settings:</li><br />
     <ol><br />
        <li>As XML Publisher Administrator navigate to Administration->Configuration</li><br />
        <li>Under Temporary Directory pick a temporary file location on your concurrent processing node. This should be at least 5GB or 20x larger than largest XML data file you generate</li><br />
        <li>Under FO Processing, set:</li><br />
        <ul><br />
          <li>Use XML Publisher&#39;&#39;s XSLT processor set to True</li><br />
          <li>Enable scalable feature of XSLT processor set to False</li><br />
        <li>Note: If  Patch 7599031 is appplied, Enable scalable feature of XSLT processor can be set to True at template level for large reports to enable improved heap utilization</li><br />
          <li>Enable XSLT runtime optimization set to True</li><br />
          <li>Note: it is recommended to modify these settings at Template leveel instead of site level</li><br />
        </ul><br />
     </ol><br />
     <li>For more information see [737311.1] and [1410160.1]</li><br />
     </ul></p>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPP_RUNTIME_PROPS');



debug('begin add_signature: PPR_DATA_CPD');
  add_signature(
      p_sig_id                 => 'PPR_DATA_CPD',
      p_sig_sql                => 'SELECT Payment_Document_Id
     FROM iby_pay_service_requests
     WHERE CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##'')',
      p_title                  => 'CE_PAYMENT_DOCUMENTS',
      p_fail_condition         => 'NRS',
      p_problem_descr          => ' ',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_CPD');



debug('begin add_signature: 952763.1-STEP_6');
   l_info('Comments'):= 'The invoice is not in cancelled status';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_6',
      p_sig_sql                => 'SELECT 
		aia.invoice_id, 
		aia.invoice_num,
		apsa.gross_amount,
		apsa.amount_remaining, 
		aia.cancelled_date 
     FROM 
		ap_invoices_all aia,
		ap_payment_schedules_all apsa
     WHERE 
		aia.invoice_id in (##$$INVIDS$$##) AND
            aia.invoice_id = apsa.invoice_id   AND
  	 	aia.cancelled_date is NOT NULL',
      p_title                  => '6: Cancelled invoices will not be selected',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice has a cancelled status',
      p_solution               => 'Cancelled invoices(s) cannot be selected by a PPR',
      p_success_msg            => 'Invoice is not in cancelled status',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_6');



debug('begin add_signature: 952763.1-STEP_7');
   l_info('Comments'):= 'Ensure there is no Hold on the invoice payment schedule';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_7',
      p_sig_sql                => 'SELECT 
 		apsa.invoice_id, 
		aia.invoice_num,
		apsa.checkrun_id    PPR_Id,
		apsa.gross_amount,
		apsa.amount_remaining, 
		apsa.hold_flag 
     FROM
		ap_payment_schedules_all apsa,
		ap_invoices_all aia
     WHERE 
		aia.invoice_id = apsa.invoice_id  AND
		apsa.invoice_id in (##$$INVIDS$$##) AND
 		apsa.hold_flag NOT in (Null, ''N'')',
      p_title                  => '7: There cannot be a hold on the payment schedule',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoices has a Hold on payment schedule',
      p_solution               => 'Address the Hold to ensure that invoice gets selected by a PPR',
      p_success_msg            => 'Invoices has no hold on payment schedule',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_7');



debug('begin add_signature: 18027976-Case6');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case6',
      p_sig_sql                => 'SELECT distinct ap.invoice_id,
					ai.invoice_num,
					ap.org_id,
					''Null Payment status flag'' Reason,
					''Y'' process_flag
			FROM ap_payment_schedules ap ,ap_invoices ai
			WHERE (ap.payment_status_flag IS NULL OR ai.payment_status_flag is NULL)
			AND ai.org_id = (##$$ORGID$$##)
			AND ai.validation_request_id is NULL
 			AND ap.invoice_id = ai.invoice_id
			AND ap.checkrun_id IS NULL
			AND ai.invoice_date between (''##$$FDATE$$##'')and (''##$$TDATE$$##'')',
      p_title                  => 'Invoices with a null payment status flag',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case6');



debug('begin add_signature: PPR_DATA_IPP');
  add_signature(
      p_sig_id                 => 'PPR_DATA_IPP',
      p_sig_sql                => 'SELECT 
	payment_profile_name, 
	system_profile_code, 
	system_profile_name , 
	system_profile_description, 
	bepid, 
	security_protocol_code, 
	transmit_protocol_code,
	TRANSMIT_CONFIGURATION_ID, 
	payment_format_code, 
	positive_pay_format_code, 
	pay_file_letter_format_code, 
	print_instruction_immed_flag, 
	transmit_instr_immed_flag , 
	default_printer , 
	default_payment_document_id, 
	processing_type, 
	mark_complete_event, 
	manual_mark_complete_flag, 
	positive_pay_delivery_flag , 
	send_to_file_flag, 
	payment_profile_id, 
	bep_account_id 
      FROM 
	iby_payment_profiles 
      WHERE 
	payment_profile_id in (SELECT distinct payment_profile_id FROM iby_payments_all WHERE payment_service_request_id  in 
		(Select PAYMENT_SERVICE_REQUEST_ID 
		from  iby_pay_service_requests 
		where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##'')))',
      p_title                  => 'PAYMENT PROCESS PROFILE (PPP)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_IPP');



debug('begin add_signature: 17856010_CASE7');
   l_info('Bug'):= '17856010';
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
  add_signature(
      p_sig_id                 => '17856010_CASE7',
      p_sig_sql                => 'SELECT 
	           	ipsr.call_app_pay_service_req_code  PPR_NAME,
		aisc.checkrun_id  PPR_Id,
          		aisc.check_date,
	          	AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status) || '' (Case 7)'' Status,
          		aisc.request_id,
          		COUNT(DISTINCT invoice_id),
          		COUNT(invoice_id),
          		''Y''
FROM 
		iby_pay_service_requests ipsr,
          		ap_inv_selection_criteria_all aisc,
          		ap_payment_schedules_all aps,
          		iby_docs_payable_all idp 
WHERE 
		aps.checkrun_id                                                     = aisc.checkrun_id
		AND ipsr.call_app_pay_service_req_code                                    = aisc.checkrun_name
        		AND ipsr.calling_app_id                                                   = 200
        		AND AP_PAYMENT_UTIL_PKG.get_psr_status
            	(ipsr.payment_service_request_id,ipsr.payment_service_request_status) = ''CONFIRMED''
        		AND idp.calling_app_doc_unique_ref1                                       = aps.checkrun_id
        		AND idp.calling_app_doc_unique_ref2                                       = aps.invoice_id
        		AND idp.calling_app_doc_unique_ref3                                       = aps.payment_num
        		AND idp.payment_service_request_id                                        = ipsr.payment_service_request_id
        		AND idp.document_status                                                   IN 
        		(''PAYMENT_CREATED'')
		 AND exists
			(SELECT ''AP Pmt Data Exists''
     	            	FROM iby_docs_payable_all idp,
              		ap_checks_all ac,
              		ap_invoice_payments_all aip,
              		ap_payment_history_all aph
            		WHERE idp.payment_id        = ac.payment_id
            		AND ac.check_id             = aip.check_id
            		AND aip.invoice_id          = aps.invoice_id
            		AND aip.payment_num         = aps.payment_num
 		           AND aip.accounting_event_id = aph.accounting_event_id
            		AND ac.check_id             = aph.check_id
            		AND nvl(aip.reversal_flag,''N'') <> ''Y'')
GROUP BY 
		aisc.checkrun_id,
          		aisc.check_date,
          		ipsr.call_app_pay_service_req_code,
          		AP_PAYMENT_UTIL_PKG.get_psr_status(ipsr.payment_service_request_id,ipsr.payment_service_request_status),
         		aisc.request_id',
      p_title                  => '7: PSR is CONFIRMED - AP is stampted with payments data but invoices not released',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more PPR was confirmed and AP is stamped with payments data but corresponding invoices were not released',
      p_solution               => 'Please review the PPR and corresponding invoices. Use GDF [874862.1] for data fix.',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 17856010_CASE7');



debug('begin add_signature: INV_DATA_ACA');
  add_signature(
      p_sig_id                 => 'INV_DATA_ACA',
      p_sig_sql                => 'SELECT 
	check_id, 
	check_number, 
	vendor_site_code, 
	amount, base_amount, 
	checkrun_id, 
	checkrun_name, 
	check_date, 
	substr(status_lookup_code,1,15) status_lookup_code, 
	void_date, 
	org_id 
FROM 
	AP_CHECKS_ALL 
WHERE 
	check_id IN 
	( SELECT distinct check_id FROM AP_INVOICE_PAYMENTS_ALL WHERE invoice_id in (##$$INVIDS$$##))',
      p_title                  => 'AP_CHECKS_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist or no checks data exists',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_DATA_ACA');



debug('begin add_signature: BIP_TEMPLATE_VERSIONS');
  add_signature(
      p_sig_id                 => 'BIP_TEMPLATE_VERSIONS',
      p_sig_sql                => 'select LOB_CODE, LANGUAGE, TERRITORY, FILE_NAME, 
utl_raw.CAST_TO_VARCHAR2(dbms_lob.substr(FILE_DATA,100,dbms_lob.instr(FILE_DATA,utl_raw.cast_to_raw(''$Header'')))) VERSION
      from xdo_lobs
     where APPLICATION_SHORT_NAME = ''IBY''
     and lob_type = ''TEMPLATE_SOURCE''',
      p_title                  => 'BI Publisher Payments Template Versions',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Packages does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BIP_TEMPLATE_VERSIONS');



debug('begin add_signature: INV_DATA_APHA');
  add_signature(
      p_sig_id                 => 'INV_DATA_APHA',
      p_sig_sql                => 'SELECT 
	payment_history_id, 
	check_id, 
	accounting_date, 
	substr(transaction_type,1,20) transaction_type, 
	posted_flag, 
	substr(accounting_event_id,1,10) accounting_event_id, 
	rev_pmt_hist_id, 
	org_id 
FROM 
	AP_PAYMENT_HISTORY_ALL 
WHERE 
	check_id IN 
	( SELECT distinct check_id FROM AP_INVOICE_PAYMENTS_ALL WHERE invoice_id in (##$$INVIDS$$##)) ORDER BY payment_history_id asc',
      p_title                  => 'AP_PAYMENT_HISTORY_ALL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist or no payments data exists',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_DATA_APHA');



debug('begin add_signature: 18027976-Case7');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case7',
      p_sig_sql                => 'SELECT ap.invoice_id,
				ap.invoice_num,
				ap.org_id,
				ap.Reason,
				''Y'' process_flag
			FROM 
			      (SELECT ''Wrong pay status flag for partial paid invoices'' Reason
						,ai.invoice_id
						,ai.invoice_num
						,ai.org_id
						,ai.invoice_amount
						,ai.amount_paid
						,nvl(ai.discount_amount_taken,0) disc_amt
						,(SELECT AP_UTILITIES_PKG.ap_round_currency(SUM(aid.amount) *
    			      			   NVL(ai.payment_cross_rate,1),ai.payment_currency_code)
						  FROM ap_invoice_distributions aid, ap_invoice_lines ail
            					  WHERE ail.invoice_id = ai.invoice_id
						  AND aid.invoice_id = ai.invoice_id
						  AND ail.line_number = aid.invoice_line_number  
            					  AND aid.prepay_distribution_id is not null
						  AND nvl(ail.invoice_includes_prepay_flag,''N'') <>''Y''
						 ) prepay_amt
						,(SELECT SUM(aip.amount)
						  FROM ap_invoice_payments aip
            					  WHERE aip.invoice_id = ai.invoice_id
						 ) pay_amt
						,(SELECT SUM(aps.amount_remaining)
						  FROM ap_payment_schedules aps
            					  WHERE aps.invoice_id = ai.invoice_id
						 ) amount_remain
			       FROM ap_invoices ai
	      		       WHERE ai.org_id = (##$$ORGID$$##)
	      		       AND ai.cancelled_date IS NULL
      			       AND ai.validation_request_id is NULL
		               AND ai.payment_status_flag in (''N'',''Y'')
	                       AND ai.invoice_date between (''##$$FDATE$$##'')and (''##$$TDATE$$##'')
			      ) ap
			WHERE nvl(ap.amount_remain,0) <> 0
			AND nvl(ap.amount_paid,0) <> 0
			AND (nvl(ap.prepay_amt,0) <> 0 OR nvl(ap.pay_amt,0) <> 0)',
      p_title                  => 'Amount remaining is NULL',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case7');



debug('begin add_signature: 17856010_CASE8');
   l_info('Bug'):= '17856010';
   l_info('Comments'):= 'Identify Records For Generic Data Fix';
  add_signature(
      p_sig_id                 => '17856010_CASE8',
      p_sig_sql                => 'SELECT aisc.checkrun_id,
            aisc.check_date,
            aisc.checkrun_name,
            aisc.status || ''(Case 8)'',
            aisc.request_id,
            COUNT(DISTINCT aps.invoice_id),
            COUNT(aps.invoice_id),
            ''Y''
          FROM ap_inv_selection_criteria_all aisc,
               ap_payment_schedules_all aps
          WHERE 
		   aps.checkrun_id = aisc.checkrun_id
          AND EXISTS
              (select 1
               from ap_selected_invoices_all si2
                    , ap_invoices_all ai
               where si2.checkrun_id = aisc.checkrun_id
               and si2.invoice_id = ai.invoice_id
               and si2.vendor_name is null 
               and ai.vendor_id is not null)
	    GROUP BY aisc.checkrun_id,
            aisc.check_date,
            aisc.checkrun_name,
            aisc.status,
            aisc.request_id',
      p_title                  => '8: Vendor_name in ap_selected_invoices_all is null while corresponding invoice has not null vendor_id',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more PPR was confirmed and AP is stamped with payments data but corresponding invoices were not released',
      p_solution               => 'Please review the PPR and corresponding invoices. Use GDF [874862.1] for data fix.',
      p_success_msg            => 'No issue found with PPR and Invoices that need data fix',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 17856010_CASE8');



debug('begin add_signature: PPR_DATA_XL');
  add_signature(
      p_sig_id                 => 'PPR_DATA_XL',
      p_sig_sql                => 'SELECT 
	LOB_CODE,
	LOB_TYPE,
	FILE_NAME,
	LANGUAGE,
	TERRITORY,
	XDO_FILE_TYPE,
	FILE_STATUS,
	FILE_CONTENT_TYPE
    FROM 
	XDO_LOBS
    WHERE 
      LOB_CODE in (select FORMAT_TEMPLATE_CODE from iby_formats_vl where FORMAT_CODE in (select payment_format_code from iby_payment_profiles where payment_profile_id in (SELECT distinct payment_profile_id FROM iby_payments_all WHERE payment_service_request_id  in 
		(Select PAYMENT_SERVICE_REQUEST_ID 
		from  iby_pay_service_requests 
		where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##'')))))',
      p_title                  => 'XDO_LOBS',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_XL');



debug('begin add_signature: 952763.1-STEP_8');
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_8',
      p_sig_sql                => 'SELECT 
    		aia.invoice_id, 
		aia.invoice_num,
		assa.VENDOR_SITE_CODE, 
		assa.VENDOR_SITE_ID, 
		assa.hold_all_payments_flag 
     FROM 
          	ap_invoices_all aia,  
		ap_supplier_sites_all assa
     WHERE 
          	aia.invoice_id in (##$$INVIDS$$##) AND 
		aia.VENDOR_SITE_ID = assa.VENDOR_SITE_ID AND
 		assa.hold_all_payments_flag = ''Y''',
      p_title                  => '8: A supplier site level hold will prevent payment schedule selection',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice has a Hold at supplier site level',
      p_solution               => 'Check supplier details and remove hold',
      p_success_msg            => 'Invoice has no hold at supplier site level',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_8');



debug('begin add_signature: 952763.1-STEP_9');
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_9',
      p_sig_sql                => 'select aia.invoice_id, aia.party_id, aia.party_site_id, hps.party_id, hps.party_site_id
     FROM 
		ap_invoices_all aia, hz_party_sites hps 
     WHERE 
	aia.invoice_id in (##$$INVIDS$$##) AND
	aia.INVOICE_TYPE_LOOKUP_CODE = ''PAYMENT REQUEST'' AND 
	aia.PARTY_SITE_ID IS NOT NULL 		
    and aia.party_id = hps.party_id(+)
    And Aia.Party_Site_Id = Hps.Party_Site_Id(+)
    and hps.party_site_id is null',
      p_title                  => '9: For Payment Request invoices there must be a corresponding record in hz_party_sites',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice of type payment request has no corresponding record in HZ_PARTY_SITES table',
      p_solution               => 'Please log Service Request for data fix to have a record in HZ_PARTY_SITES',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_9');



debug('begin add_signature: SUPPLIER_DATA');
  add_signature(
      p_sig_id                 => 'SUPPLIER_DATA',
      p_sig_sql                => 'Select * from AP_SUPPLIERS Where vendor_id in (select vendor_id from ap_invoices_all where invoice_id in (##$$INVIDS$$##))',
      p_title                  => 'AP_SUPPLIERS (Invoice Supplier Details)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist',
      p_solution               => 'Please check invoice number entered',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SUPPLIER_DATA');



debug('begin add_signature: PPR_DATA_XT');
  add_signature(
      p_sig_id                 => 'PPR_DATA_XT',
      p_sig_sql                => 'Select 
  	  TEMPLATE_ID,
	  TEMPLATE_CODE,
	  DATA_SOURCE_CODE,
	  TEMPLATE_TYPE_CODE,
	  DEFAULT_LANGUAGE,
	  DEFAULT_TERRITORY,
	  DEFAULT_OUTPUT_TYPE,
	  TEMPLATE_STATUS,
	  USE_ALIAS_TABLE,
	  DEPENDENCY_FLAG,
	  MLS_LANGUAGE,
	  MLS_TERRITORY
    from
  	  XDO_TEMPLATES_B
    where
	  TEMPLATE_CODE in (select FORMAT_TEMPLATE_CODE from iby_formats_vl where FORMAT_CODE in (select payment_format_code from iby_payment_profiles where payment_profile_id in (SELECT distinct payment_profile_id FROM iby_payments_all WHERE payment_service_request_id  in 
		(Select PAYMENT_SERVICE_REQUEST_ID 
		from  iby_pay_service_requests 
		where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##'')))))',
      p_title                  => 'XDO_TEMPLATES',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_XT');



debug('begin add_signature: 18027976-Case8');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case8',
      p_sig_sql                => 'SELECT ap.invoice_id,
				ap.invoice_num,
				ap.org_id,
				ap.Reason,
				''Y'' process_flag
			FROM 
				(SELECT ''Incorrect pay status flag for partial paid invoices'' Reason
						,aps.invoice_id
						,ai.invoice_num
						,aps.org_id
						,aps.payment_num
						,aps.amount_remaining
						,aps.gross_amount
					 	,aps.payment_status_flag
						,(SELECT AP_UTILITIES_PKG.ap_round_currency(SUM(aid.amount) *
						   NVL(ai.payment_cross_rate,1), ai.payment_currency_code)
						  FROM ap_invoice_distributions aid
            					  WHERE aid.invoice_id = ai.invoice_id
						  AND aid.line_type_lookup_code = ''AWT''
						  AND aid.awt_invoice_payment_id IS NULL
						 ) inv_awt_amt
						,(SELECT SUM(aps.gross_amount)
						  FROM ap_payment_schedules aps
						  WHERE aps.invoice_id = ai.invoice_id
						 ) tot_gross_amt
				 FROM  ap_payment_schedules aps,
					ap_invoices ai
				 WHERE  aps.org_id = (##$$ORGID$$##)
				 AND  ai.invoice_id = aps.invoice_id
				 AND  ai.invoice_amount <> 0
				 AND  ai.cancelled_date IS NULL
				 AND  ai.validation_request_id is NULL
				 AND  aps.checkrun_id IS NULL
				 AND  nvl(ai.historical_flag,''N'') <> ''Y''
				 AND ai.invoice_date between (''##$$FDATE$$##'')and (''##$$TDATE$$##'')
				) ap
			WHERE ap.gross_amount <> 0
			AND ap.tot_gross_amt <> 0
			AND ap.payment_status_flag <> decode(nvl(ap.amount_remaining,0), 0, ''Y'',
								(ap.gross_amount+(nvl(ap.inv_awt_amt,0)*nvl(ap.gross_amount,0)/nvl(ap.tot_gross_amt,1))), ''N'', ''P'')',
      p_title                  => 'Invoices having an incorrect amount paid',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case8');



debug('begin add_signature: 16216890_STUCK_SPOILED');
   l_info('Comments'):= 'Bug 16216890';
   l_info('Doc ID'):= '1367272.1';
  add_signature(
      p_sig_id                 => '16216890_STUCK_SPOILED',
      p_sig_sql                => 'SELECT 
		doc.document_payable_id
		,doc.payment_id
		,doc.calling_app_doc_ref_number	
		,doc.payment_service_request_id	
      	,req.CALL_APP_PAY_SERVICE_REQ_CODE
	      ,doc.document_status
		,doc.payment_amount		
		,doc.ext_payee_id		
		,doc.payment_date		
		,doc.payment_method_code		
	FROM 
		iby_docs_payable_all doc, iby_pay_service_requests req
	WHERE 
		doc.payment_service_request_id = req.payment_service_request_id AND 
		doc.payment_id IN 
			(SELECT 
				payment_id			    
			FROM 	
				iby_payments_all pmt  
			WHERE 
--				pmt.payment_instruction_id in (##$$INSTRID$$##)  
				pmt.payment_instruction_id in (select PAYMENT_INSTRUCTION_ID from iby_pay_instructions_all
									    where PAY_ADMIN_ASSIGNED_REF_CODE in (''##$$PPRNAME$$##''))  
				AND pmt.payment_status = ''REMOVED_DOCUMENT_SPOILED''
				AND EXISTS ( SELECT ''CORRUPTED DOC''
				FROM iby_docs_payable_all docs
				WHERE docs.payment_id = pmt.payment_id
				AND docs.document_status =''PAYMENT_CREATED''))',
      p_title                  => 'Check If Any Payments Stuck In Spoiled Status For Given PPR',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found payments that are stuck in SPOILED status',
      p_solution               => 'Please review payments that are stuck in spoiled status. Use GDF [1367272.1] for data fix.',
      p_success_msg            => 'This PPR contains no payments that are stuck in spoiled status',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 16216890_STUCK_SPOILED');



debug('begin add_signature: 18027976-Case9');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case9',
      p_sig_sql                => 'SELECT 	ai.invoice_id,
				ai.invoice_num,
				ai.org_id,
				''Inc Amt Remn,paid for cancelled invs'' Reason,
				''Y'' process_flag
			FROM ap_invoices ai
			WHERE ai.cancelled_date IS NOT NULL
			AND (nvl(ai.amount_paid,0) <> 0 
				OR exists (SELECT 1 
					FROM ap_payment_schedules aps
					WHERE aps.invoice_id = ai.invoice_id
					AND amount_remaining <> 0))
			AND ai.org_id = (##$$ORGID$$##)
			AND ai.invoice_date between (''##$$FDATE$$##'')and (''##$$TDATE$$##'')
			AND ai.validation_request_id is NULL',
      p_title                  => 'Payment schedules having an incorrect amount remaining',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case9');



debug('begin add_signature: 952763.1-STEP_10');
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_10',
      p_sig_sql                => 'SELECT 
		*
     FROM 
		dual
     WHERE 
         ''##$$FEDERAL$$##'' = ''Enabled''',
      p_title                  => '10: Check for Federal Customers',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'FEDERAL is enabled, We need to check if it is economically beneficial to make the payment',
      p_solution               => 'Use fv_econ_benf_disc.ebd_check(x_batch_name,x_invoice_id, x_check_date, x_inv_duw_date, x_discount_amount, x_discount_date) should return Y for an invoice to be economically beneficial to be included in the payment batch',
      p_success_msg            => 'FEDERAL is not enabled, hence this case does not apply',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_10');



debug('begin add_signature: PPR_DATA_IF');
  add_signature(
      p_sig_id                 => 'PPR_DATA_IF',
      p_sig_sql                => 'SELECT 
	Format_Code,
	Format_Type_Code,
	Format_Template_Code,
	Reference_Format_Code,
	Extract_Id,
	Format_Name,
	Seeded_Flag
    FROM 
	iby_formats_vl
    WHERE 
      FORMAT_CODE in (select payment_format_code from iby_payment_profiles where payment_profile_id in (SELECT distinct payment_profile_id FROM iby_payments_all WHERE payment_service_request_id  in 
		(Select PAYMENT_SERVICE_REQUEST_ID 
		from  iby_pay_service_requests 
		where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##''))))',
      p_title                  => 'Payment Formats',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '<ul>
     <li>If PPR is stuck in formatting status with ORA-06553: PLS-306 error, check the value for Format_Type_Code </li>
     <li>Format type code associated with a payment format should be OUTBOUND_PAYMENT_INSTRUCTION</li>
     <li>For additional details, please refer to [1098223.1]</li>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_IF');



debug('begin add_signature: 18027976-Case10');
   l_info('Doc ID'):= '1174813.1';
  add_signature(
      p_sig_id                 => '18027976-Case10',
      p_sig_sql                => 'SELECT 	ai.invoice_id,
				ai.invoice_num,
				ai.org_id,
				''Incorrect Gross Amount on Schedule'' Reason,
				''Y'' process_flag
			FROM ap_invoices ai
			WHERE ((ai.PAY_CURR_INVOICE_AMOUNT <> ap_utilities_pkg.ap_round_currency((ai.invoice_amount - (
			  CASE
				WHEN NVL(ai.net_of_retainage_flag, ''N'') = ''N''
				THEN NVL(ABS(AP_INVOICES_UTILITY_PKG.get_retained_total(ai.invoice_id, ai.org_id)),0)
				ELSE 0
			  END))* ai.payment_cross_rate, ai.payment_currency_code))
			OR (ai.PAY_CURR_INVOICE_AMOUNT <>
			  (SELECT SUM(aps.gross_amount)
			  FROM ap_payment_schedules_all aps
			  WHERE aps.invoice_id = ai.invoice_id
			  )))
			AND ai.historical_flag IS NULL
			AND EXISTS
			  (SELECT 1
			  FROM ap_payment_schedules_all aps
			  WHERE aps.invoice_id         = ai.invoice_id
			  HAVING COUNT(aps.invoice_id) = 1
			  )
			AND ai.org_id = (##$$ORGID$$##)
			AND ai.cancelled_date IS NULL
		    AND ai.validation_request_id is NULL
		    AND ai.invoice_date between (''##$$FDATE$$##'')and (''##$$TDATE$$##'')',
      p_title                  => 'Invoices overpaid',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found invoices with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1174813.1] for data fix</li>
     <li>If GDF 1174813.1 does not resolve the issue, refer to [1640766.1] for other possibilities</li>
     <li>NOTE: the fix script cannot totally resolve this issue</li>
     </ul>',
      p_success_msg            => 'No invoice or payment data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 18027976-Case10');



debug('begin add_signature: 952763.1-STEP_11');
   l_info('Comments'):= 'If user specified an invoice batch name in PPR, invoice should be in that batch';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_11',
      p_sig_sql                => 'SELECT
		aia.invoice_id,
		aia.invoice_num,
		aia.batch_id  "Invoice Batch Id",
    		aisca.checkrun_id  PPR_Id,
		aisca.checkrun_name  PPR_Name,
		aisca.invoice_batch_id  "PPR Batch Id"
     FROM 
		ap_inv_selection_criteria_all aisca,
	      ap_invoices_all aia
     WHERE 
		aisca.checkrun_id in (##$$PPRID$$##) AND
		aisca.invoice_batch_id is not null AND
		aisca.invoice_batch_id NOT IN 
               (select 
			nvl(aia2.batch_id,-9999)
	         from 
			ap_invoices_all aia2
      	   where 
			aia2.invoice_id in (##$$INVIDS$$##))',
      p_title                  => '11: If the user specified an Invoice Batch Name, the invoice must be in that batch',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice does not belong to batch specified in PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either no invoice batch was specified in the PPR criteria or the invoice belongs to the invoice batch specified in PPR',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_11');



debug('begin add_signature: 19903129-Case1');
   l_info('Doc ID'):= '1937924.1';
  add_signature(
      p_sig_id                 => '19903129-Case1',
      p_sig_sql                => 'SELECT DISTINCT pi.payment_instruction_id
        , pi.process_type
        , pi.payment_instruction_status
        , pi.payments_complete_code
        , pi.payment_count
        , pi.transmit_instr_immed_flag
        , pi.pay_admin_assigned_ref_code
        , pi.transmission_date
        , pi.org_id
        , pi.payment_date
        , pi.payment_document_id
        , p.completed_pmts_group_id
        , p.payment_process_request_name
     FROM IBY_Pay_Instructions_All pi
        , IBY_Payments_All p
    WHERE 2=2
      AND p.process_type = ''STANDARD''
      AND p.payment_function = ''PAYABLES_DISB''
      AND p.payments_complete_flag = ''Y''
      And P.Creation_Date Between (''##$$FDATE$$##'')
                              And (''##$$TDATE$$##'')
      And Pi.Payment_Instruction_Id = P.Payment_Instruction_Id
      And P.Payment_Status Not In (''VOID'')
      And p.completed_pmts_group_id IS NOT NULL
      And NOT EXISTS
         ( SELECT 1 FROM AP_Checks_All c, IBY_Payments_All p2
           Where C.Payment_Id = P2.Payment_Id
            AND p2.payment_instruction_id = pi.payment_instruction_id )',
      p_title                  => 'Stuck PPR due to partial commit data',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Found PPR with potential data issues',
      p_solution               => '<ul>
     <li>Please review the list above. Use GDF [1937924.1] for data fix</li>
     </ul>',
      p_success_msg            => 'No PPR data issues were found for the time period specified',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 19903129-Case1');



debug('begin add_signature: SRA_DELIVERY');
  add_signature(
      p_sig_id                 => 'SRA_DELIVERY',
      p_sig_sql                => 'SELECT DISTINCT hp.PARTY_NAME,
		hps.PARTY_SITE_NAME,
		iep.PARTY_SITE_ID,
		iep.REMIT_ADVICE_DELIVERY_METHOD,
		iep.REMIT_ADVICE_EMAIL,
		iep.REMIT_ADVICE_FAX
	FROM
		HZ_PARTIES hp,
		HZ_PARTY_SITES hps,
		IBY_EXTERNAL_PAYEES_ALL iep,
		IBY_DOCS_PAYABLE_ALL dpa,
		IBY_PAY_SERVICE_REQUESTS psr
	WHERE
		psr.CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##'')
		and psr.PAYMENT_SERVICE_REQUEST_ID = dpa.PAYMENT_SERVICE_REQUEST_ID
		and dpa.EXT_PAYEE_ID = iep.EXT_PAYEE_ID
		and iep.PAYEE_PARTY_ID = hp.PARTY_ID
		and iep.PARTY_SITE_ID = hps.PARTY_SITE_ID
	ORDER BY hps.PARTY_SITE_NAME, iep.PARTY_SITE_ID',
      p_title                  => 'SRA Setup Review',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist',
      p_solution               => '',
      p_success_msg            => '<ul>
     <li>If the delivery method is email or fax, please ensure that email or fax number is provided</li>
     <li>Delivery E-Mail or Fax can be updated using the navigation: Supplier Detail--->Payment Details--->Separate Remittance Advice Delivery tab</li>
     <li>Delivery method and E-Mail details can be specified at supplier or supplier site level</li>
     <li>Refer to [1072399.1] for additional details on all SRA related setup</li> 
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SRA_DELIVERY');



debug('begin add_signature: SUPPLIER_SITE_DATA');
  add_signature(
      p_sig_id                 => 'SUPPLIER_SITE_DATA',
      p_sig_sql                => 'Select * from AP_SUPPLIER_SITES_ALL where VENDOR_SITE_ID in (select vendor_site_id from ap_invoices_all where invoice_id in (##$$INVIDS$$##))',
      p_title                  => 'AP_SUPPLIER_SITES_ALL (Invoice Supplier Site Details)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified Invoice does not exist',
      p_solution               => 'Please check invoice number entered',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SUPPLIER_SITE_DATA');



debug('begin add_signature: 952763.1-STEP_12');
   l_info('Comments'):= 'If the user specified the Payee the invoice must be from that payee';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_12',
      p_sig_sql                => 'SELECT 
		aia.invoice_id,
		aia.invoice_num,
		aia.vendor_id "Invoice Payee",
		aisca.checkrun_id   PPR_Id, 
		aisca.checkrun_name   PPR_Name,
		aisca.VENDOR_ID "PPR Payee"
    FROM
 		ap_inv_selection_criteria_all aisca,
    		ap_invoices_all aia
    WHERE 
		aisca.checkrun_id in (##$$PPRID$$##) AND 
		aisca.VENDOR_ID is not null  AND
      	aisca.VENDOR_ID NOT IN
		   (select 
			nvl(aia2.vendor_id,-9999)
         	    from 
			ap_invoices_all aia2
                where 
			aia2.invoice_id in (##$$INVIDS$$##))',
      p_title                  => '12: If the user specified the Payee the invoice must be from that payee',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice does not belong to payee specified in PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either no payee was specified in PPR criteria or invoice belonga to same payee as specified in PPR',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_12');



debug('begin add_signature: PPR_FORMAT_VALIDATIONS');
  add_signature(
      p_sig_id                 => 'PPR_FORMAT_VALIDATIONS',
      p_sig_sql                => 'SELECT
	 	f.FORMAT_CODE, 
	 	valv.VALIDATION_SET_CODE, 
		valst.VALIDATION_SET_DISPLAY_NAME, 
		valv.VALIDATION_ASSIGNMENT_ID , 
		valv.VALIDATION_PARAMETER_CODE , 
		valv.VAL_PARAM_VARCHAR2_VALUE , 
		valv.VAL_PARAM_NUMBER_VALUE, 
		vals.VALIDATION_LEVEL_CODE , 
		vals.VALIDATION_CODE_PACKAGE, 
		vals.VALIDATION_CODE_ENTRY_POINT, 
		vals.VALIDATION_CODE_LANGUAGE
    FROM
		iby_formats_b f, 
		IBY_VAL_ASSIGNMENTS val, 
		IBY_VALIDATION_VALUES valv, 
		IBY_VALIDATION_SETS_B vals, 
		IBY_VALIDATION_SETS_TL valst
	WHERE 
		f.FORMAT_CODE = val.ASSIGNMENT_ENTITY_ID
		and val.VALIDATION_ASSIGNMENT_ID = valv.VALIDATION_ASSIGNMENT_ID
		and val.VALIDATION_SET_CODE = vals.VALIDATION_SET_CODE
		and vals.VALIDATION_SET_CODE = valst.VALIDATION_SET_CODE
		and val.VAL_ASSIGNMENT_ENTITY_TYPE = ''FORMAT''
		and f.FORMAT_CODE IN 
		 (select payment_format_code from iby_payment_profiles where payment_profile_id in 
			(select distinct payment_profile_id FROM iby_payments_all WHERE payment_service_request_id  in 
				(Select PAYMENT_SERVICE_REQUEST_ID from  iby_pay_service_requests 
				where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##''))))
				order by valv.VALIDATION_ASSIGNMENT_ID',
      p_title                  => 'Payment Format Validation',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No validation is assigned to the formats associated with the PPR',
      p_solution               => 'If the PPR does exist, it is likely that no validation is assigned to the formats associated with the PPR',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_FORMAT_VALIDATIONS');



debug('begin add_signature: PAYEE_PAYMENT_DETAILS');
  add_signature(
      p_sig_id                 => 'PAYEE_PAYMENT_DETAILS',
      p_sig_sql                => 'SELECT
		*
	FROM 
		iby_external_payees_all  iep
	WHERE
		(iep.payee_party_id in (select party_id from ap_invoices_all where invoice_id in (##$$INVIDS$$##)) AND 
    		iep.PARTY_SITE_ID is NULL AND
    		iep.PARTY_SITE_ID is NULL)
    UNION
  	SELECT
		*
	FROM 
		iby_external_payees_all  iep
	WHERE
		(iep.payee_party_id in (select party_id from ap_invoices_all where invoice_id in (##$$INVIDS$$##)) AND
    		iep.PARTY_SITE_ID in (select party_site_id from ap_invoices_all where invoice_id in (##$$INVIDS$$##)) AND
    		iep.supplier_site_id in (select vendor_site_id from ap_invoices_all where invoice_id in (##$$INVIDS$$##)))',
      p_title                  => 'IBY_EXTERNAL_PAYEES_ALL (Invoice External Payee Details)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'IBY_EXTERNAL_PAYEES_ALL (Invoice External Payee Details)',
      p_solution               => 'Please check invoice number entered',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PAYEE_PAYMENT_DETAILS');



debug('begin add_signature: PPR_PMT_METHOD_VALIDATIONS');
  add_signature(
      p_sig_id                 => 'PPR_PMT_METHOD_VALIDATIONS',
      p_sig_sql                => 'SELECT
		pmtmth_b.PAYMENT_METHOD_CODE , 
		val.VALIDATION_SET_CODE, 
		valst.VALIDATION_SET_DISPLAY_NAME, 
		val.ASSIGNMENT_ENTITY_ID , 
		valv.VALIDATION_ASSIGNMENT_ID , 
		val.VAL_ASSIGNMENT_ENTITY_TYPE , 
		valv.VALIDATION_PARAMETER_CODE , 
		valv.VAL_PARAM_VARCHAR2_VALUE , 
		valv.VAL_PARAM_NUMBER_VALUE, 
		vals.VALIDATION_LEVEL_CODE , 
		val.INACTIVE_DATE,  
		vals.VALIDATION_CODE_PACKAGE , 
		vals.VALIDATION_CODE_ENTRY_POINT , 
		vals.VALIDATION_CODE_LANGUAGE
	FROM
 		IBY_PAYMENT_METHODS_B pmtmth_b, 
		IBY_VAL_ASSIGNMENTS val , 
		IBY_VALIDATION_VALUES valv , 
		IBY_VALIDATION_SETS_B vals, 
		IBY_VALIDATION_SETS_TL valst
	WHERE
 		pmtmth_b.PAYMENT_METHOD_CODE = val.ASSIGNMENT_ENTITY_ID
		and val.VALIDATION_ASSIGNMENT_ID = valv.VALIDATION_ASSIGNMENT_ID
		and val.VALIDATION_SET_CODE = vals.VALIDATION_SET_CODE
		and vals.VALIDATION_SET_CODE = valst.VALIDATION_SET_CODE
		and val.VAL_ASSIGNMENT_ENTITY_TYPE = ''METHOD''
		and pmtmth_b.PAYMENT_METHOD_CODE IN 
			(SELECT Payment_Method_Code FROM iby_docs_payable_all WHERE payment_service_request_id in 
				(Select PAYMENT_SERVICE_REQUEST_ID 
				from  iby_pay_service_requests 
				where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##'')))
	ORDER BY valv.VALIDATION_ASSIGNMENT_ID',
      p_title                  => 'Payment Method Validation',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Specified PPR does not exist or no validations are assigned to the payment method associated with the PPR',
      p_solution               => 'Please check PPR entered. If the PPR does exists, it is likely that no validation is assigned to the payment method associated with the PPR',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_PMT_METHOD_VALIDATIONS');



debug('begin add_signature: 952763.1-STEP_13');
   l_info('Comments'):= 'If the user specified an exchange rate type, it must not conflict with the exchange rate type on the invoice';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_13',
      p_sig_sql                => 'SELECT 
      	aia.invoice_id,
      	aia.invoice_num,
      	aia.EXCHANGE_RATE_TYPE  "Invoice Exchange Rate Type",
      	aisca.checkrun_id   PPR_Id, 
      	aisca.checkrun_name   PPR_Name,
      	aisca.INV_EXCHANGE_RATE_TYPE "PPR Exchange Rate Type"
      FROM
      	ap_inv_selection_criteria_all aisca,
        	ap_invoices_all aia
      WHERE 
      	aisca.checkrun_id in (##$$PPRID$$##) AND 
      	aia.Invoice_id in (##$$INVIDS$$##) AND
      	aisca.INV_EXCHANGE_RATE_TYPE = ''IS_USER'' and
      	aia.exchange_rate_type != ''User''
      UNION
      SELECT 
      	aia.invoice_id,
      	aia.invoice_num,
      	aia.EXCHANGE_RATE_TYPE  "Invoice Exchange Rate Type",
      	aisca.checkrun_id   PPR_Id, 
      	aisca.checkrun_name   PPR_Name,
      	aisca.INV_EXCHANGE_RATE_TYPE "PPR Exchange Rate Type"
      FROM
      	ap_inv_selection_criteria_all aisca,
         	ap_invoices_all aia
      WHERE 
      	aisca.checkrun_id in (##$$PPRID$$##) AND 
      	aia.Invoice_id in (##$$INVIDS$$##) AND
      	aisca.INV_EXCHANGE_RATE_TYPE = ''IS_NOT_USER'' and
      	(aia.exchange_rate_type = ''User'' OR
      	aia.exchange_rate_type != nvl(aia.exchange_rate_type,null))',
      p_title                  => '13: Ensure that PPR exchange rate type and invoice exchange rate type match',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice has exchange_rate_type that does not match with inv_exchange_rate_type of the PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either no inv_exchange_rate_type was specified in PPR criteria or invoice belong to same exchange rate as specified in PPR',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_13');



debug('begin add_signature: PPR_DOC_VAL_FAILURES');
  add_signature(
      p_sig_id                 => 'PPR_DOC_VAL_FAILURES',
      p_sig_sql                => 'SELECT transaction_type,
	transaction_id,
	error_code fail_code,
	error_message fail_reason
		FROM IBY_TRANSACTION_ERRORS
		WHERE transaction_type = ''DOCUMENT_PAYABLE''
		AND transaction_id IN
			(SELECT document_payable_id
			FROM iby_docs_payable_all
			WHERE payment_service_request_id IN
				(SELECT payment_service_request_id
				From Iby_Pay_Service_Requests
				WHERE call_app_pay_service_req_code in (''##$$PPRNAME$$##'')))',
      p_title                  => 'Document Validation Failures',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No payment validation failure found.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DOC_VAL_FAILURES');



debug('begin add_signature: 952763.1-STEP_14');
   l_info('Comments'):= 'If the user specified a payment method, it must match the payment method on the payment schedule';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_14',
      p_sig_sql                => 'SELECT 
		apsa.invoice_id,
		apsa.payment_method_code, 
		apsa.payment_method_code  "Inv Payment Method",
		aisca.checkrun_id    PPR_Id, 
		aisca.checkrun_name  PPR_Name,
		aisca.payment_method_code  "PPR Payment Method"
     FROM 
		ap_inv_selection_criteria_all aisca,
	      ap_payment_schedules_all apsa
     WHERE 
		aisca.checkrun_id in (##$$PPRID$$##)  AND
     		aisca.payment_method_code is not null  AND
     		aisca.payment_method_code NOT IN 
              (select 
			nvl(apsa2.payment_method_code,-9999)
               from 
			ap_payment_schedules_all apsa2
               where 
			apsa2.invoice_id in (##$$INVIDS$$##))',
      p_title                  => '14: If the user specified a payment method, it must match the payment method on the payment schedule',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice does not belong to payment method specified in PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either no payment method was specified in PPR criteria or invoice belongs to same payment method as specified in PPR',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_14');



debug('begin add_signature: 952763.1-STEP_15');
   l_info('Comments'):= 'If the user specified a vendor type, it must match the vendor type of the invoice supplier';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_15',
      p_sig_sql                => 'SELECT 
      	aisca.checkrun_id  PPR_Id, 
		aisca.checkrun_name  PPR_Name,
		aisca.vendor_type_lookup_code "PPR Vendor Type"
     FROM 
      	ap_inv_selection_criteria_all aisca
     WHERE  
      	aisca.checkrun_id in (##$$PPRID$$##) AND
      	aisca.vendor_type_lookup_code is not null AND
      	aisca.vendor_type_lookup_code NOT IN  
		   (select 
             	nvl(as2.vendor_type_lookup_code,-9999)
        	    from 
             	ap_suppliers as2
        	    where 
             	as2.vendor_id IN 
                      (select 
				  aia.vendor_id 
                       from 
				  ap_invoices_all aia
                       where 
				  aia.invoice_id in (##$$INVIDS$$##)))',
      p_title                  => '15: If the user specified a vendor type, it must match the vendor type of the invoices supplier',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice does not belong to vendor type specified in PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either no vendor type was specified in PPR criteria or invoice belongs to same vendor type as specified in PPR',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_15');



debug('begin add_signature: 952763.1-STEP_16');
   l_info('Comments'):= 'If any legal entities were specified, the invoice must be in one of those legal entities';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_16',
      p_sig_sql                => 'SELECT 
	    aia.invoice_id,
	    aia.invoice_num,
	    aisca.checkrun_id    PPR_Id,
	    aisca.checkrun_name    PPR_Name,
	    alg.legal_entity_id   PPR_LEGAL_ENTITY,
	    aia.legal_entity_id  INVOICE_LEGAL_ENTITY
          FROM
	    ap_invoices_all aia,
	    ap_le_group alg,
	    ap_inv_selection_criteria_all aisca
          WHERE
	    aia.invoice_id in (##$$INVIDS$$##) AND
	    aisca.checkrun_id in (##$$PPRID$$##)  AND
	    aisca.LE_GROUP_OPTION = ''SPECIFY''   AND 
	    aisca.checkrun_id = alg.checkrun_id  AND
	    alg.legal_entity_id NOT in 
		(select 
			aia2.legal_entity_id 
		from 
			ap_invoices_all aia2 
		where 
			aia2.invoice_id in (##$$INVIDS$$##))',
      p_title                  => '16: If any legal entities were specified, the invoice must be in one of those legal entities',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice does not belong to legal entities specified in PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either invoice belongs to same legal entity as specified in PPR or PPR was run for all legal entities',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_16');



debug('begin add_signature: 952763.1-STEP_17');
   l_info('Comments'):= 'If any operating units were specified, the invoice must be in one of those operating units';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_17',
      p_sig_sql                => 'SELECT 
	    aia.invoice_id,
	    aia.invoice_num,
	    aia.org_id  "Invoice Operating Unit",
	    aisca.checkrun_id    PPR_Id,
	    aisca.checkrun_name   PPR_Name,
	    aog.org_id   "PPR Operating Unit"
          FROM
	    ap_invoices_all aia,
	    ap_ou_group  aog,
	    ap_inv_selection_criteria_all aisca
          WHERE
	    aia.invoice_id in (##$$INVIDS$$##) AND
	    aisca.checkrun_id in (##$$PPRID$$##)  AND
	    aisca.OU_GROUP_OPTION = ''SPECIFY''   AND 
	    aisca.checkrun_id = aog.checkrun_id  AND
	    aog.org_id NOT in 
		(select 
			aia2.org_id
		from 
			ap_invoices_all aia2 
		where 
			aia2.invoice_id in (##$$INVIDS$$##))',
      p_title                  => '17: If any operating units were specified, the invoice must be in one of those operating units',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice does not belong to operating units specified in PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either invoice belongs to same operating unit as specified in PPR or PPR was run for all operating units',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_17');



debug('begin add_signature: 952763.1-STEP_18');
   l_info('Comments'):= 'If any currencies were specified, the invoice payment currency must match one of them';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_18',
      p_sig_sql                => 'SELECT 
	    aia.invoice_id,
	    aia.invoice_num,
	    aia.payment_currency_code "Invoice Currency Code",
	    aisca.checkrun_id    PPR_Id,
	    aisca.checkrun_name   PPR_Name,
	    acg.currency_code   "PPR Currency Code"
          FROM
	    ap_invoices_all aia,
	    ap_currency_group acg,
	    ap_inv_selection_criteria_all aisca
          WHERE
	    aia.invoice_id in (##$$INVIDS$$##) AND
	    aisca.checkrun_id in (##$$PPRID$$##)  AND
	    aisca.CURRENCY_GROUP_OPTION = ''SPECIFY''   AND 
	    aisca.checkrun_id = acg.checkrun_id  AND
	    acg.currency_code  NOT in 
		(select 
			aia2.payment_currency_code 
		from 
			ap_invoices_all aia2 
		where 
			aia2.invoice_id in (##$$INVIDS$$##))',
      p_title                  => '18: If any currencies were specified, the invoice payment currency must match one of them',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice does not belong to currency specified in PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either invoice belongs to same currency as specified in PPR or PPR was run for all currencies',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_18');



debug('begin add_signature: 952763.1-STEP_19');
   l_info('Comments'):= 'If any pay groups were specified, the invoice pay group must match one of them';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_19',
      p_sig_sql                => 'SELECT 
	    aia.invoice_id,
	    aia.invoice_num,
	    aia.pay_group_lookup_code     "Invoice Pay Group",
	    aisca.checkrun_id    PPR_Id,
	    aisca.checkrun_name   PPR_Name,
	    apg.VENDOR_PAY_GROUP    "PPR Pay Group"
          FROM
	    ap_invoices_all aia,
	    ap_pay_group  apg,
	    ap_inv_selection_criteria_all aisca
          WHERE
	    aia.invoice_id in (##$$INVIDS$$##) AND
	    aisca.checkrun_id in (##$$PPRID$$##)  AND
	    aisca.PAY_GROUP_OPTION = ''SPECIFY''   AND 
	    aisca.checkrun_id = apg.checkrun_id  AND
	    Aia.Pay_Group_Lookup_Code not In
        (Select apg2.Vendor_Pay_Group  From Ap_Pay_Group apg2   Where Checkrun_Id In     
		(Select A.Checkrun_Id From Ap_Inv_Selection_Criteria_All A  Where A.checkrun_id in (##$$PPRID$$##)))',
      p_title                  => '19: If any pay groups were specified, the invoice pay group must match one of them',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice does not belong to pay group specified in PPR',
      p_solution               => 'Modify your PPR criteria',
      p_success_msg            => 'Either invoice belongs to same pay group as specified in PPR or PPR was run for all pay groups',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_19');



debug('begin add_signature: 952763.1-STEP_20');
   l_info('Comments'):= 'For zero-amount invoices, the user must have checked the Include Zero Amount checkbox';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_20',
      p_sig_sql                => 'SELECT 
	    apsa.invoice_id,
 	    aia.invoice_num,
	    apsa.gross_amount,
          apsa.amount_remaining,
	        aisca.checkrun_id    PPR_Id,
	        aisca.checkrun_name   PPR_Name,
	    aisca.zero_invoices_allowed 
    FROM
	    ap_invoices_all aia,
	    ap_payment_schedules_all apsa,
	    ap_inv_selection_criteria_all aisca
    WHERE
	    apsa.invoice_id in (##$$INVIDS$$##) AND
	    apsa.invoice_id = aia.invoice_id   AND
	    aisca.checkrun_id in (##$$PPRID$$##)  AND
          apsa.amount_remaining = 0   AND
	    aisca.zero_invoices_allowed != ''Y''',
      p_title                  => '20: For zero-amount invoices, the user must have checked the Include Zero Amount checkbox',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice is for zero amount but the zero amount checkbox is not selected for the PPR',
      p_solution               => 'Modify your PPR criteria to check Include Zero Amount flag',
      p_success_msg            => 'Either there are no invoices with zero amount or Include Zero Amount flag in PPR was checked',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_20');



debug('begin add_signature: PPR_PMT_VAL_FAILURES');
  add_signature(
      p_sig_id                 => 'PPR_PMT_VAL_FAILURES',
      p_sig_sql                => 'SELECT transaction_type,
	transaction_id,
	error_code fail_code,
	error_message fail_reason
		FROM IBY_TRANSACTION_ERRORS
		WHERE transaction_type = ''PAYMENT''
		AND transaction_id IN
			(SELECT payment_id
			FROM iby_payments_all
			WHERE payment_service_request_id IN
				(SELECT payment_service_request_id
				FROM iby_pay_service_requests
				WHERE call_app_pay_service_req_code in (''##$$PPRNAME$$##'')))',
      p_title                  => 'Payment Validation Failures',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No payment validation failure found.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_PMT_VAL_FAILURES');



debug('begin add_signature: 952763.1-STEP_21');
   l_info('Comments'):= 'Unapproved invoice will not be selected';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_21',
      p_sig_sql                => 'Select Invoice_Id, invoice_Num, Wfapproval_Status From Ap_Invoices_All 
	 Where invoice_id in (##$$INVIDS$$##) 
     and wfapproval_status NOT in (''APPROVED'',''MANUALLY APPROVED'', ''NOT REQUIRED'')',
      p_title                  => '21: Unapproved invoice will not be selected',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<ul>
     <li>The invoice does not have one of the below approval status:</li>
	<ol>
     <li> APPROVED</li>
     <li> MANUALLY APPROVED</li>
     <li> NOT REQUIRED</li> 
	</ol>
     </ul>',
      p_solution               => 'Revalidate the invoice and approve.',
      p_success_msg            => 'Invoice is approved or approval not required.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_21');



debug('begin add_signature: 952763.1-STEP_21a');
   l_info('Comments'):= 'Unapproved invoice will not be selected';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_21a',
      p_sig_sql                => 'Select invoice_id,  line_number, amount, wfapproval_status from ap_invoice_lines_all 
	Where invoice_id in (##$$INVIDS$$##) 
    and wfapproval_status NOT in (''APPROVED'',''MANUALLY APPROVED'', ''NOT REQUIRED'')',
      p_title                  => '21a: Unapproved invoice line will not be selected',
      p_fail_condition         => 'RS',
      p_problem_descr          => '<ul>
     <li>The invoice line does not have one of the below approval status:</li>
	<ol>
     <li> APPROVED</li>
     <li> MANUALLY APPROVED</li>
     <li> NOT REQUIRED</li> 
	</ol>
     </ul>',
      p_solution               => 'Revalidate the invoice and approve.',
      p_success_msg            => 'All invoice lines are approved or approval not required.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_21a');



debug('begin add_signature: PPR_DATA_ITV');
  add_signature(
      p_sig_id                 => 'PPR_DATA_ITV',
      p_sig_sql                => 'SELECT 
 	itc.TRANSMIT_CONFIGURATION_NAME,
	itv.TRANSMIT_VALUE_ID, 
	itv.TRANSMIT_CONFIGURATION_ID, 
	itv.TRANSMIT_PARAMETER_CODE, 
	itv.TRANSMIT_VARCHAR2_VALUE, 
	itv.TRANSMIT_NUMBER_VALUE, 
	itv.TRANSMIT_DATE_VALUE
    FROM 
	IBY_TRANSMIT_VALUES ITV,
	IBY_TRANSMIT_CONFIGS_TL ITC
    WHERE 
	itv.TRANSMIT_CONFIGURATION_ID = ITC.TRANSMIT_CONFIGURATION_ID  AND
	itv.TRANSMIT_CONFIGURATION_ID in (
         Select TRANSMIT_CONFIGURATION_ID from iby_payment_profiles where payment_profile_id in 
		(SELECT distinct payment_profile_id FROM iby_payments_all WHERE payment_service_request_id  in 
			(Select PAYMENT_SERVICE_REQUEST_ID 
			from  iby_pay_service_requests 
			where CALL_APP_PAY_SERVICE_REQ_CODE in (''##$$PPRNAME$$##''))))
    ORDER BY itc.TRANSMIT_CONFIGURATION_NAME',
      p_title                  => 'Transmission Configuration',
      p_fail_condition         => 'NRS',
      p_problem_descr          => '<ul>
     <li>No data was returned for Transmission Configuration due to one of the following reasons:</li>
     <ol>
     <li>No payment process profile was specified when submitting the PPR and/or PPR stopped or terminated before the stage when payment process profile is defaulted </li>
     <li>This is a PRINTED payment which does not require transmission configuration setup</li>
     <li>This is an ELECTRONIC payment but no transmission configuration setup was performed. </li>
     </ol>
     </ul>',
      p_solution               => 'Please make sure that payment system and transmission configuration were defined in payment process profile-->Payment System tab',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPR_DATA_ITV');



debug('begin add_signature: 952763.1-STEP_24');
   l_info('Comments'):= 'An invoice with holds will not be selected for payment';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_24',
      p_sig_sql                => 'SELECT 
		aia.invoice_id,
		aia.invoice_num,
		aha.release_lookup_code
     FROM 
		ap_invoices_all aia,
		ap_holds_all aha
     WHERE 
		aia.invoice_id = aha.invoice_id  AND
		aha.invoice_id in (##$$INVIDS$$##) AND
		aha.release_lookup_code is null',
      p_title                  => '24: An invoice with holds will not be selected for payment',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'An invoice with holds will not be selected for payment',
      p_solution               => 'Remove the invoice hold and ensure that it is fully validated',
      p_success_msg            => 'Invoice is not on hold',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_24');



debug('begin add_signature: 952763.1-STEP_25');
   l_info('Comments'):= 'The invoice distributions must be fully validated';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_25',
      p_sig_sql                => 'SELECT 
          	aia.invoice_id, 
		aia.invoice_num,
		aida.invoice_line_number,
		aida.invoice_distribution_id, 
		aida.amount, 
		aida.match_status_flag, ''Not Validated'' "Status"
     FROM  
		ap_invoices_all aia,
       	ap_invoice_distributions_all aida
     WHERE
		aia.invoice_id = aida.invoice_id   AND
         	aida.invoice_id in (##$$INVIDS$$##) AND
		nvl(aida.match_status_flag,''N'') in (''N'',''T'',''S'')',
      p_title                  => '25: Check to see if the invoice distributions are fully validated',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more invoice distributions have not been fully validated',
      p_solution               => 'Validate your invoice distributions',
      p_success_msg            => 'All invoice distributions are validated',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_25');



debug('begin add_signature: 952763.1-STEP_26');
   l_info('Comments'):= 'Invoices without distributions will not get selected';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_26',
      p_sig_sql                => 'SELECT 
         	aia.invoice_id, 
		aia.invoice_num,
		aida.INVOICE_LINE_NUMBER, 
		aida.DISTRIBUTION_LINE_NUMBER   
     FROM 
		ap_invoices_all aia,
		ap_invoice_distributions_all aida 
     WHERE 
		aia.invoice_id = aida.invoice_id   AND		
		aida.invoice_id in (##$$INVIDS$$##)',
      p_title                  => '26: Invoices without distributions will not get selected',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Invoice does not have distributions',
      p_solution               => 'Check invoice details and ensure distributions exists',
      p_success_msg            => 'Invoice has distributions created',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_26');



debug('begin add_signature: 952763.1-STEP_27');
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_27',
      p_sig_sql                => 'SELECT 
         	aia.invoice_id, 
		aia.invoice_num,
		ftav.beneficiary_party_id,
		ftav.beneficiary_party_site_id,
		ftav.fv_tpp_pay_flag
     FROM 
		ap_invoices_all aia,
		fv_tpp_assignments_v ftav
     WHERE 
           ''##$$FEDERAL$$##'' = ''Enabled''  AND
        	 aia.invoice_id in (##$$INVIDS$$##)',
      p_title                  => '27: Customers using CCR (a Federal functionality) the Invoice Supplier should not be CCR Expired',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Federal is enabled. Please ensure that there is no row in FV_TPP_ASSIGNMENTS_V where the beneficiary_party_id and beneficiary_party_site_id match the party_id and party_site_id from ap_invoices_all and the fv_tpp_pay_flag equals N',
      p_solution               => 'Check invoice details and ensure that supplier is not CCR expired',
      p_success_msg            => 'Federal is not enabled. This case does not apply',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_27');



debug('begin add_signature: 952763.1-STEP_28');
   l_info('Comments'):= 'The check date must be in an open AP period';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_28',
      p_sig_sql                => 'SELECT 
      		aia.invoice_num,
		aia.invoice_id,
      		aia.set_of_books_id,
   	    	aisca.checkrun_id    PPR_Id,
	    	aisca.checkrun_name   PPR_Name,
      		aisca.check_date,
      		gps.start_date,
      		gps.end_date,
      		gps.closing_status
          FROM
	    	ap_invoices_all aia,
	    	gl_period_statuses gps,
	    	ap_inv_selection_criteria_all aisca
	WHERE
      		aia.invoice_id in (##$$INVIDS$$##) AND
      		aisca.checkrun_id in (##$$PPRID$$##)  AND
      		aia.set_of_books_id =  gps.set_of_books_id  AND
			gps.application_id = 200  AND
      		gps.closing_status = ''O''   AND
      		aisca.check_date between gps.start_date AND gps.end_date',
      p_title                  => '28: The check date must be in an open AP period',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Invoice has check date that falls outside an open period',
      p_solution               => 'Check invoice check date or ensure that period to cover check date is open',
      p_success_msg            => 'Check date falls within the open period',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_28');



debug('begin add_signature: 952763.1-STEP_29');
   l_info('Comments'):= 'If pre-date payables is diabled, payment date cannot be earlier than current date';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_29',
      p_sig_sql                => 'SELECT 
	    	aia.invoice_num,
         	aia.invoice_id,
	    	aisca.checkrun_name,
	    	aisca.checkrun_id    PPR_Id,
	    	aisca.checkrun_name   PPR_Name,
	    	to_date(aisca.creation_date,''DD-Mon-YY HH:MI:SS'') Creation_Date,
	    	to_date(aisca.check_date, ''DD-Mon-YY HH:MI:SS'')  Check_date,
	    	aspa.post_dated_payments_flag
      FROM
	    	ap_invoices_all aia,
	    	ap_system_parameters_all aspa,
	    	ap_inv_selection_criteria_all aisca
      WHERE
	 --	aia.invoice_id in (##$$INVIDS$$##) AND
	    	aisca.checkrun_id in (##$$PPRID$$##)  AND
      	aspa.post_dated_payments_flag = ''N'' AND
         	to_date(aisca.check_date, ''DD-Mon-YY HH:MI:SS'') < to_date(aisca.creation_date,''DD-Mon-YY HH:MI:SS'')',
      p_title                  => '29: If pre-date payables is diabled, payment date cannot be earlier than current date',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Pre-date payments are disabled but the invoice has check date that is earlier than PPR date',
      p_solution               => 'Either allow pre-dated payments by updating the payables system options or adjust invoice payment date',
      p_success_msg            => 'Check date is not earlier than PPR creation date',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_29');



debug('begin add_signature: 952763.1-STEP_30');
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_30',
      p_sig_sql                => 'SELECT aia.invoice_id, aia.invoice_num, aia.relationship_id, aia.party_id, aia.party_site_id, aia.vendor_id, 
	aia.vendor_site_id, aia.remit_to_supplier_id, aia.remit_to_supplier_Site_id, iepr.relationship_id, iepr.party_id, 
	iepr.supplier_site_id, iepr.remit_party_id, iepr.remit_supplier_site_id, iepr.active  
     FROM 
		ap_invoices_all aia, 
		iby_ext_payee_relationships iepr 
     Where aia.invoice_id in (##$$INVIDS$$##)
	 and Aia.Relationship_Id = Iepr.Relationship_Id
     and aia.relationship_id not in (-1) and iepr.active = ''N''',
      p_title                  => '30: When third-party payments functionality is used the payee relationship must be active',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice is making payment to 3rd party but the payee relationship is not active',
      p_solution               => 'Need to activate third-party relationship',
      p_success_msg            => 'No invoice is making payment to 3rd party which is not active in',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_30');



debug('begin add_signature: 952763.1-STEP_31');
   l_info('Comments'):= 'If exchange rates are mandatory or the exchange rate type is user, exchange rates must be available';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_31',
      p_sig_sql                => 'SELECT 
	    	aisca.checkrun_id    PPR_Id,
	    	aisca.checkrun_name   PPR_Name,
		aisca.exchange_rate_type,
		aisca.status 		 
     FROM 
		ap_inv_selection_criteria_all aisca
     WHERE 
		aisca.checkrun_id in (##$$PPRID$$##) AND
  		aisca.inv_exchange_rate_type = ''User'' AND 
		aisca.status = ''MISSING RATES''',
      p_title                  => '31: If exchange rates are mandatory or the exchange rate type is user, exchange rates must be available',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Exchange rate was not specified when submitting the PPR',
      p_solution               => 'Ensure exchage rate is available',
      p_success_msg            => 'No issue found with invoice exchange rates',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_31');



debug('begin add_signature: 952763.1-STEP_33');
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_33',
      p_sig_sql                => 'SELECT
      	aisca.checkrun_id, 
		aisca.PAYMENT_DOCUMENT_ID 
     FROM
		ap_inv_selection_criteria_all aisca 
	WHERE aisca.checkrun_id in (##$$PPRID$$##) and
		aisca.PAYMENT_DOCUMENT_ID in 
		(select cpd.PAYMENT_DOCUMENT_ID from ce_payment_documents cpd where cpd.MANUAL_PAYMENTS_ONLY_FLAG = ''Y'')',
      p_title                  => '33: If running a Payment Process Request using a set of Payment Documents that has the option Restrict Use To Manually Issued Payments checked',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment document associated with the PPR has Restrict Use To Manually Issued Payments flag enabled',
      p_solution               => 'Select another payment document which has the flag unchecked or process payments manually from invoice workbench',
      p_success_msg            => 'No issue found with Restrict Use To Manually Issued Payments flag for payment document selected',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_33');



debug('begin add_signature: 952763.1-STEP_35');
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_35',
      p_sig_sql                => 'SELECT
          aisca.checkrun_id  ppr_id,
          aisca.checkrun_name ppr_name,
          aisca.vendor_id  Supplier,
          aisca.ZERO_AMOUNTS_ALLOWED  maximize_credits
     FROM 
		ap_inv_selection_criteria_all aisca,
		ap_invoices_all aia
     WHERE 
		aisca.checkrun_id in (##$$PPRID$$##) AND
          	aisca.zero_amounts_allowed = ''N'' And
            Aia.Invoice_Id In (##$$INVIDS$$##) And
          	aia.Invoice_Type_Lookup_Code = ''CREDIT''',
      p_title                  => '35: If supplier account has credit balance, ensure that Maximize Credits flag is checked',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'PPR was submitted with Maximize Credits flag unchecked. In such case, PPR will not select any supplier invoices if a credit balance exists unless sum of payments is greater than credit balance',
      p_solution               => 'If the supplier credit balance amount is greater than the sum of all payments for that supplier, ensure that Maximize Credits flag is enabled. Also enure that exclusive_payment_flag is N in ap_invoices_all for the other invoice for the same supplier selected by the PPR',
      p_success_msg            => 'Maximize Credits flag is checked, hence case does not apply',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_35');



debug('begin add_signature: 952763.1-STEP_NET');
   l_info('Comments'):= 'Invoice locked by Netting batch';
   l_info('Doc ID'):= '952763.1';
  add_signature(
      p_sig_id                 => '952763.1-STEP_NET',
      p_sig_sql                => 'Select nvl(a.dummy,''AP/AR Netting Case'') AP_AR_NETTING_CASE from dual a where dummy = ''Z''',
      p_title                  => 'Rare case when invoice was already selected and locked by a Netting Batch',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'If all of the above cases were negative, yet the invoice is still not picked up by PPR.',
      p_solution               => 'Special case for AP/AR Netting',
      p_success_msg            => 'It is possible that you are using AP/AR Netting functionality and this invoice is locked by a Netting Batch.
	<ul>
     <li>To see if this scenario applies, check the scheduled payment details of the invoice</li>
     <li>If scheduled payments details includes a checkrun_id, run the following sql to check if it pertains to Netting Batch</li>
     <li>SELECT * FROM FUN_NET_BATCHES_ALL WHERE CHECKRUN_ID = <checkrun_id from scheduled payment details> </li>
     <li>If it returns a row, then invoice is locked by Netting Batch. It is not releated to standard PPR process</li>
     <li>If the query does not return a row, then check if that checrun_id exists in AP_INV_SELECTION_CRITERIA_ALL table</li>
     <li>If it does, then invoice is not selected due to some other unknown cause which is not covered here. Log SR with Oracle Support to address it</li>
     </ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: 952763.1-STEP_NET');

  

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;

-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main(
            p_org_id                       IN VARCHAR2    DEFAULT NULL
           ,p_ppr_name                     IN VARCHAR2    DEFAULT NULL
           ,p_inv_num_1                    IN VARCHAR2    DEFAULT NULL
           ,p_check_id                     IN VARCHAR2    DEFAULT NULL
           ,p_from_date                    IN DATE        DEFAULT sysdate-90
           ,p_max_output_rows              IN NUMBER      DEFAULT 50
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

 IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;

  IF g_is_concurrent THEN
     g_rep_info('Calling From'):='Concurrent Program';
  ELSE
     g_rep_info('Calling From'):='SQL Script';
  END IF;

  l_step := '10';
  initialize_files;
  
  -- PSD #11
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Payments (IBY) Funds Disbursement';

  l_step := '20';
 -- PSD #12

   validate_parameters(
     p_org_id                       => p_org_id
    ,p_ppr_name                     => p_ppr_name
    ,p_inv_num_1                    => p_inv_num_1
    ,p_check_id                     => p_check_id
    ,p_from_date                    => p_from_date
    ,p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );



  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #13
debug('begin section: Proactive and Preventative Recommendations');
start_section('Proactive and Preventative Recommendations');
   IF (substr(g_rep_info('Apps Version'),1,4) = '12.1') THEN
      set_item_result(run_stored_sig('Submit_PPR_Errors'));
   END IF;
      IF ((substr(g_rep_info('Apps Version'),1,4) = '12.0') OR 
    (substr(g_rep_info('Apps Version'),1,4) = '12.1')) THEN
         set_item_result(check_rec_patches_1);
      END IF;
         set_item_result(run_stored_sig('IBY_INVALIDS'));
         set_item_result(run_stored_sig('ENCRYPT_DATA'));
end_section;
debug('end section: Proactive and Preventative Recommendations');


debug('begin section: Identify Stuck Invoices');
start_section('Identify Stuck Invoices');
   set_item_result(run_stored_sig('17856010_CASE1'));
   set_item_result(run_stored_sig('17856010_CASE2'));
   set_item_result(run_stored_sig('17856010_CASE3'));
   set_item_result(run_stored_sig('17856010_CASE4'));
   set_item_result(run_stored_sig('17856010_CASE5'));
   set_item_result(run_stored_sig('17856010_CASE6'));
   set_item_result(run_stored_sig('17856010_CASE7'));
   set_item_result(run_stored_sig('17856010_CASE8'));
   set_item_result(run_stored_sig('16216890_STUCK_SPOILED'));
end_section;
debug('end section: Identify Stuck Invoices');


debug('begin section: 952763.1: PPR Invoice Selection Diagnostic');
IF nvl(g_sql_tokens('##$$INVIDS$$##'),'no invoices') <> 'no invoices' THEN
   start_section('952763.1: PPR Invoice Selection Diagnostic');
      set_item_result(run_stored_sig('952763.1-STEP_1'));
      set_item_result(run_stored_sig('952763.1-STEP_2A'));
      set_item_result(run_stored_sig('952763.1-STEP_2B'));
      set_item_result(run_stored_sig('952763.1-STEP_3'));
      set_item_result(run_stored_sig('952763.1-STEP_4'));
      set_item_result(run_stored_sig('952763.1-STEP_5'));
      set_item_result(run_stored_sig('952763.1-STEP_6'));
      set_item_result(run_stored_sig('952763.1-STEP_7'));
      set_item_result(run_stored_sig('952763.1-STEP_8'));
      set_item_result(run_stored_sig('952763.1-STEP_9'));
      set_item_result(run_stored_sig('952763.1-STEP_10'));
      set_item_result(run_stored_sig('952763.1-STEP_11'));
      set_item_result(run_stored_sig('952763.1-STEP_12'));
      set_item_result(run_stored_sig('952763.1-STEP_13'));
      set_item_result(run_stored_sig('952763.1-STEP_14'));
      set_item_result(run_stored_sig('952763.1-STEP_15'));
      set_item_result(run_stored_sig('952763.1-STEP_16'));
      set_item_result(run_stored_sig('952763.1-STEP_17'));
      set_item_result(run_stored_sig('952763.1-STEP_18'));
      set_item_result(run_stored_sig('952763.1-STEP_19'));
      set_item_result(run_stored_sig('952763.1-STEP_20'));
      set_item_result(run_stored_sig('952763.1-STEP_21'));
      set_item_result(run_stored_sig('952763.1-STEP_21a'));
      set_item_result(run_stored_sig('952763.1-STEP_24'));
      set_item_result(run_stored_sig('952763.1-STEP_25'));
      set_item_result(run_stored_sig('952763.1-STEP_26'));
      set_item_result(run_stored_sig('952763.1-STEP_27'));
      set_item_result(run_stored_sig('952763.1-STEP_28'));
      set_item_result(run_stored_sig('952763.1-STEP_29'));
      set_item_result(run_stored_sig('952763.1-STEP_30'));
      set_item_result(run_stored_sig('952763.1-STEP_31'));
      set_item_result(run_stored_sig('952763.1-STEP_33'));
      set_item_result(run_stored_sig('952763.1-STEP_35'));
      set_item_result(run_stored_sig('952763.1-STEP_NET'));
   end_section;
END IF;
debug('end section: 952763.1: PPR Invoice Selection Diagnostic');


debug('begin section: Payment Related Data Issues');
start_section('Payment Related Data Issues');
   set_item_result(run_stored_sig('18027976-Case1'));
   set_item_result(run_stored_sig('18027976-Case2'));
   set_item_result(run_stored_sig('18027976-Case3'));
   set_item_result(run_stored_sig('18027976-Case4'));
   set_item_result(run_stored_sig('18027976-Case5'));
   set_item_result(run_stored_sig('18027976-Case6'));
   set_item_result(run_stored_sig('18027976-Case7'));
   set_item_result(run_stored_sig('18027976-Case8'));
   set_item_result(run_stored_sig('18027976-Case9'));
   set_item_result(run_stored_sig('18027976-Case10'));
   set_item_result(run_stored_sig('19903129-Case1'));
end_section;
debug('end section: Payment Related Data Issues');


debug('begin section: Void Related Issues 121-2');
IF ((substr(g_rep_info('Apps Version'),1,4) = '12.1') OR 
(substr(g_rep_info('Apps Version'),1,4) = '12.2')) THEN
   start_section('Void Related Issues');
      set_item_result(run_stored_sig('1913503.1-Form'));
      set_item_result(run_stored_sig('1913503.1-package'));
      IF nvl(g_sql_tokens('##$$CHKID$$##'),'no chk') <> 'no chk' THEN
         set_item_result(run_stored_sig('1326421.1-Case1'));
         set_item_result(run_stored_sig('1326421.1-Case2'));
         set_item_result(run_stored_sig('Void-sql1'));
      END IF;
         IF nvl(g_sql_tokens('##$$INVIDS$$##'),'no invoices') <> 'no invoices' THEN
            set_item_result(run_stored_sig('Void-sql2'));
         END IF;
   end_section;
END IF;
debug('end section: Void Related Issues 121-2');


debug('begin section: Void Related Issues 120');
IF (substr(g_rep_info('Apps Version'),1,4) = '12.0') THEN
   start_section('Void Related Issues');
      IF nvl(g_sql_tokens('##$$CHKID$$##'),'no chk') <> 'no chk' THEN
         set_item_result(run_stored_sig('1326421.1-Case1'));
         set_item_result(run_stored_sig('1326421.1-Case2'));
         set_item_result(run_stored_sig('Void-sql1'));
      END IF;
         IF nvl(g_sql_tokens('##$$INVIDS$$##'),'no invoices') <> 'no invoices' THEN
            set_item_result(run_stored_sig('Void-sql2'));
         END IF;
   end_section;
END IF;
debug('end section: Void Related Issues 120');


debug('begin section: Identify Orphan Bank Accounts');
start_section('Identify Orphan Bank Accounts');
   set_item_result(run_stored_sig('11810646_ORPH_ACCTS'));
   set_item_result(run_stored_sig('11810646_AR_ORPH_ASSIGN'));
   set_item_result(run_stored_sig('11810646_CE_ORPH_ASSIGN'));
   set_item_result(run_stored_sig('11810646_DUP_OWNER'));
end_section;
debug('end section: Identify Orphan Bank Accounts');


debug('begin section: Identify Duplicate Records');
start_section('Identify Duplicate Records');
   set_item_result(run_stored_sig('10144798_DUP_BAN'));
   set_item_result(run_stored_sig('13857555_DUP_PAYEE'));
end_section;
debug('end section: Identify Duplicate Records');


debug('begin section: Separate Remittance Advice (SRA)');
start_section('Separate Remittance Advice (SRA)');
   set_item_result(run_stored_sig('SRA_SUMMARY'));
   set_item_result(check_rec_patches_4);
   set_item_result(run_stored_sig('REQ_SRA_PROFILES'));
   set_item_result(run_stored_sig('OPT_SRA_PROFILES'));
   set_item_result(run_stored_sig('SRA_MESSAGES'));
   set_item_result(run_stored_sig('SRA_PPP_SETUP'));
   set_item_result(run_stored_sig('SRA_FORMAT_SETUP'));
   IF nvl(g_sql_tokens('##$$PPRID$$##'),'no ppr') <> 'no ppr' THEN
      set_item_result(run_stored_sig('SRA_DELIVERY'));
   END IF;
end_section;
debug('end section: Separate Remittance Advice (SRA)');


debug('begin section: Payments/BI Publisher Integration');
start_section('Payments/BI Publisher Integration');
   set_item_result(run_stored_sig('BI_SUMMARY'));
   set_item_result(check_rec_patches_2);
   set_item_result(check_rec_patches_3);
   set_item_result(run_stored_sig('OPP_HEAP_CHECK'));
   set_item_result(run_stored_sig('CP_HEAP_CHECK'));
   set_item_result(run_stored_sig('OPP_PROC_CHECK'));
   set_item_result(run_stored_sig('OPP_TIMEOUT_CHECK'));
   set_item_result(run_stored_sig('OPP_RUNTIME_PROPS'));
   set_item_result(check_rec_patches_5);
   set_item_result(run_stored_sig('BIP_TEMPLATE_VERSIONS'));
end_section;
debug('end section: Payments/BI Publisher Integration');


debug('begin section: PPR Data Collection');
IF nvl(g_sql_tokens('##$$PPRID$$##'),'no ppr') <> 'no ppr' THEN
   start_section('PPR Data Collection');
      set_item_result(run_stored_sig('PPR_DATA_AIA'));
      set_item_result(run_stored_sig('PPR_DATA_AISCA'));
      set_item_result(run_stored_sig('PPR_DATA_PMTSCHEDULES'));
      set_item_result(run_stored_sig('PPR_DATA_PAYGROUP'));
      set_item_result(run_stored_sig('PPR_DATA_SELECTEDINVOICES'));
      set_item_result(run_stored_sig('PPR_DATA_IDPA'));
      set_item_result(run_stored_sig('PPR_DATA_INCR'));
      set_item_result(run_stored_sig('PPR_DATA_IPA'));
      set_item_result(run_stored_sig('PPR_DATA_IPIA'));
      set_item_result(run_stored_sig('PPR_DATA_IPSR'));
      set_item_result(run_stored_sig('PPR_DATA_CBA'));
      set_item_result(run_stored_sig('PPR_DATA_CPD'));
      set_item_result(run_stored_sig('PPR_DATA_IPP'));
      set_item_result(run_stored_sig('PPR_DATA_XL'));
      set_item_result(run_stored_sig('PPR_DATA_XT'));
      set_item_result(run_stored_sig('PPR_DATA_IF'));
      set_item_result(run_stored_sig('PPR_FORMAT_VALIDATIONS'));
      set_item_result(run_stored_sig('PPR_PMT_METHOD_VALIDATIONS'));
      set_item_result(run_stored_sig('PPR_DOC_VAL_FAILURES'));
      set_item_result(run_stored_sig('PPR_PMT_VAL_FAILURES'));
      set_item_result(run_stored_sig('PPR_DATA_ITV'));
   end_section;
END IF;
debug('end section: PPR Data Collection');


debug('begin section: Invoice Data Collection');
IF nvl(g_sql_tokens('##$$INVIDS$$##'),'no invoices') <> 'no invoices' THEN
   start_section('Invoice Data Collection');
      set_item_result(run_stored_sig('INV_DATA_AIA'));
      set_item_result(run_stored_sig('INV_DATA_AILA'));
      set_item_result(run_stored_sig('INV_DATA_AIDA'));
      set_item_result(run_stored_sig('INV_DATA_APSA'));
      set_item_result(run_stored_sig('INV_DATA_ADP'));
      set_item_result(run_stored_sig('INV_DATA_AIPA'));
      set_item_result(run_stored_sig('INV_DATA_ACA'));
      set_item_result(run_stored_sig('INV_DATA_APHA'));
      set_item_result(run_stored_sig('SUPPLIER_DATA'));
      set_item_result(run_stored_sig('SUPPLIER_SITE_DATA'));
      set_item_result(run_stored_sig('PAYEE_PAYMENT_DETAILS'));
   end_section;
END IF;
debug('end section: Invoice Data Collection');




  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/message/12570415" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;


PROCEDURE main_cp(
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
           ,p_org_id                       IN VARCHAR2    DEFAULT NULL
           ,p_ppr_name                     IN VARCHAR2    DEFAULT NULL
           ,p_inv_num_1                    IN VARCHAR2    DEFAULT NULL
           ,p_check_id                     IN VARCHAR2    DEFAULT NULL
           ,p_from_date                    IN VARCHAR2    DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 50
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y'
)
 IS

BEGIN
  g_retcode := 0;
  g_errbuf := null;

-- PSD #17  

   main(
     p_org_id                       => p_org_id
    ,p_ppr_name                     => p_ppr_name
    ,p_inv_num_1                    => p_inv_num_1
    ,p_check_id                     => p_check_id
    ,p_from_date                    => FND_DATE.canonical_to_date(p_from_date)
    ,p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );


  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


-- PSD #1
END iby_fd_analyzer_pkg;
/
show errors
exit;
-- Exit required for bundling project so do not remove