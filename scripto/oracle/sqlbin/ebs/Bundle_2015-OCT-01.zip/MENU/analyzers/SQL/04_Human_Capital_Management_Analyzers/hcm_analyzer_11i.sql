REM $Id: hcm_analyzer.sql 200.42 2015/24/08 05:11:16 pkm ship $
REM	Consolidated script to diagnose issues that can cause problems in your HCM on an environment.
REM   How to run it? Follow the directions found in the Note 1562530.1 EBS Human Capital Management (HCM) Technical Analyzer
REM   
REM   	sqlplus apps/<password>	@hcm_analyzer.sql run_type (ALL for data collector or ISSUES for analyzer) product (BEN, HR, IRC, OTL, OTA, PAY, SSHR, ALL)
REM   Output file format found in the same directory if run manually in the file you spooled

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i
REM 
REM MENU_TITLE: HCM Technical Analyzer for 11i 
REM
REM MENU_START
REM
REM SQL: Run HCM Technical Analyzer for 11i
REM FNDLOAD: Load HCM Technical Analyzer Analyzer for 11i as a Concurrent Program 
REM 
REM MENU_END 
REM
REM HELP_START  
REM 
REM  HCM Technical Analyzer Help (Related Doc ID: 1562530.1) 
REM
REM  Compatible: 11i
REM 
REM  Explanation of available options:
REM
REM    (1) Run HCM Technical Analyzer
REM        o Runs hcm_analyzer.sql as APPS 
REM        o Creates an HTML report in MENU/output 
REM
REM    (2) Install HCM Technical Analyzer as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: 
REM          "Global HRMS Reports & Process" 
REM
REM
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: PER_TOP
REM PROG_NAME: HCM_ANALYZER_SQL
REM DEF_REQ_GROUP: Global HRMS Reports & Process
REM PROG_TEMPLATE: hcm_tech11i_prog.ldt
REM APP_NAME: Human Resources
REM PROD_SHORT_NAME: PER 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM ARG: RUN_TYPE: Enter RUN TYPE [Ex: ISSUES/ALL] DEFAULT: ALL
REM ARG: PRODUCT: Enter Product Code [Ex: HR/PAY/BEN/OTL/OTA/IRC/SSHR/ALL] DEFAULT: ALL
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT 
REM
REM ANALYZER_BUNDLE_END

set arraysize 1
set heading off
set feedback off  
set echo off
set verify off
SET CONCAT ON
SET CONCAT .
SET ESCAPE OFF
SET ESCAPE '\'

set lines 120
set pages 9999
set serveroutput on size 1000000

variable st_time 	varchar2(100);
variable et_time 	varchar2(100);



begin
select to_char(sysdate,'hh24:mi:ss') into :st_time from dual;
end;
/

REM Uncomment the 7 lines below by removing the REM tag at the beginning of each line
REM to automatically spool the output report to a meaningful name.

/*
COLUMN host_name NOPRINT NEW_VALUE hostname
SELECT host_name from v$instance;
COLUMN instance_name NOPRINT NEW_VALUE instancename
SELECT instance_name from v$instance;
COLUMN sysdate NOPRINT NEW_VALUE when
select to_char(sysdate, 'YYYY-Mon-DD') "sysdate" from dual;
SPOOL hcm_&&hostname._&&instancename._&&when..html
*/


VARIABLE APPS_REL    	VARCHAR2(50);
VARIABLE db_ver    	  VARCHAR2(100);
VARIABLE n		        NUMBER;
VARIABLE HOST        	VARCHAR2(80);
VARIABLE SID         	VARCHAR2(20);
VARIABLE PLATFORM   VARCHAR2(100);
VARIABLE hr_status varchar2(20);
VARIABLE pay_status varchar2(20);
VARIABLE issuep varchar2(2);
VARIABLE v_rup_date varchar2(20);
VARIABLE e1 number;
VARIABLE e2 number;
VARIABLE e3 number;
VARIABLE e4 number;
VARIABLE e5 number;
VARIABLE e6 number;
VARIABLE e7 number;
VARIABLE w1 number;
VARIABLE w2 number;
VARIABLE w3 number;
VARIABLE w4 number;
VARIABLE w5 number;
VARIABLE w6 number;
VARIABLE w7 number;
VARIABLE rup_level_n varchar2(50);
VARIABLE p1 varchar2(50);
VARIABLE p2 varchar2(50);
declare

	run_type varchar2(20):='&&1';
	product varchar2(20):='&&2';

begin

  Null;
   
end;
/

alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

prompt <HTML>
prompt <HEAD>
prompt <TITLE>HCM Analyzer</TITLE>
prompt <STYLE TYPE="text/css">
prompt <!-- table {background-color: #000000 color:#000000; font-size: 10pt; font-weight: bold; padding:2px; text-align:left}
prompt td {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt; border-style: solid; border-width: 1; border-color: #DEE6EF}
prompt tr {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt}
prompt th {background-color: #DEE6EF; color: #000000; height: 20; border-style: solid; border-width: 2; border-color: #f7f7e7}
prompt th.rowh {background-color: #CCCC99; color: #336699; height: 20; border-style: solid; border-width: 1; border-top-color: #f7f7e7; border-bottom-color: #f7f7e7; border-left-width: 0; border-right-width: 0}
prompt .divTitle {
prompt  -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; font-family: Calibri; background-color: #152B40; border: 1px solid #003399; padding: 9px; margin: 0px; box-shadow: 3px 3px 3px #AAAAAA; color: #F4F4F4; font-size: x-large; font-weight: bold; } 
prompt .divSection {
prompt  -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; font-family: Calibri;  background-color: #CCCCCC; border: 1px solid #DADADA; padding: 9px; margin: 0px;  box-shadow: 3px 3px 3px #AAAAAA; }
prompt .divSectionTitle {
prompt width: 98.5%;font-family: Calibri;font-weight: bold;background-color: #152B40;color: #FFFFFF;padding: 9px;margin: 0px;
prompt box-shadow: 3px 3px 3px #AAAAAA;-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;height: 30px;overflow:hidden;}
prompt .columns       { 
prompt width: 98.5%; font-family: Calibri;font-weight: bold;background-color: #254B72;color: #FFFFFF;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;
prompt -moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;height: 30px;}
prompt div.divSectionTitle div   { height: 30px; float: left; }
prompt div.left          { width: 80%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
prompt div.right         { width: 20%; background-color: #152B40; font-size: medium; border-radius: 6px;}
prompt div.clear         { clear: both; }
prompt .divItem {
prompt  -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; font-family: Calibri; background-color: #F4F4F4; border: 1px solid #EAEAEA; padding: 9px; margin: 0px; box-shadow: 3px 3px 3px #AAAAAA; }
prompt .divItemTitle {
prompt  font-family: Calibri; font-size: medium; font-weight: bold; color: #336699; border-bottom-style: solid; border-bottom-width: medium; border-bottom-color: #3973AC; margin-bottom: 9px; padding-bottom: 2px; margin-left: 3px; margin-right: 3px; }
prompt  .divwarn {
prompt    -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; font-family: Calibri; color: #333333; background-color: #FFEF95; border: 0px solid #FDC400; padding: 9px; margin: 0px; box-shadow: 3px 3px 3px #AAAAAA; font-size: 11pt; }
prompt .diverr {
prompt  font-family: Calibri; font-size: 11pt; font-weight: bold; color: #333333; background-color: #ffd8d8; box-shadow: 3px 3px 3px #AAAAAA; -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; padding: 9px; margin: 3px; }
prompt .graph {font-family: Arial, Helvetica, sans-serif;font-size: small;}
prompt .graph tr {font-family: Arial, Helvetica, sans-serif;font-size: small;background-color: transparent;}
prompt .graph td {font-family: Arial, Helvetica, sans-serif;font-size: small;background-color: transparent;border: 0px transparent;}
prompt .TitleBar, .TitleImg{display:table-cell;width:95%;vertical-align: middle;--border-radius: 6px;font-family: Calibri;background-color: #152B40; padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;color: #F4F4F4;font-size: xx-large;font-size: 4 vw;font-weight: bold;overflow:hidden;}
prompt .TitleImg{}
prompt .TitleBar > div{height:25px;}
prompt .TitleBar .Title2{font-family: Calibri;background-color: #152B40;padding: 9px;margin: 0px;color: #F4F4F4;font-size: medium;font-size: 4 vw;}
prompt .divok {
prompt border: 1px none #00CC99; font-family: Calibri; font-size: 11pt; font-weight: normal; background-color: #ECFFFF; color: #333333;  padding: 9px; margin: 3px; box-shadow: 3px 3px 3px #AAAAAA; -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; }
prompt .divSum {font-family: Calibri;background-color: #F4F4F4;}
prompt .divSumTitle {font-family: Calibri;font-size: medium;color: #336699;}
prompt A {	COLOR: #0066cc}
prompt A:visited {	COLOR: #0066cc}
prompt A:hover {	COLOR: #0099cc}
prompt A:active {	COLOR: #0066cc}
prompt .detail {	TEXT-DECORATION: none}
prompt .legend {font-weight: normal;color: #0000FF;font-size: 9pt; font-weight: bold}
prompt .btn {border: #000000;border-style: solid;border-width: 2px;width:190;height:50;border-radius: 6px;background: linear-gradient(#FFFFFF, #B0B0B0);font-weight: bold;color: blue;margin-top: 5px;margin-bottom: 5px;margin-right: 5px;margin-left: 5px;vertical-align: middle;}
prompt .toctable {background-color: #F4F4F4;}
   
prompt span.errbul {color: #EE0000;font-size: large;font-weight: bold;text-shadow: 1px 1px #AAAAAA;}
prompt span.warbul {color: #FFAA00;font-size: large;font-weight: bold;text-shadow: 1px 1px #AAAAAA;}
prompt -->
prompt </STYLE>
prompt <script type="text/javascript">
prompt	   function displayItem(e, itm_id) {
prompt     var tbl = document.getElementById(itm_id);
prompt     if (tbl.style.display == ""){
prompt        e.innerHTML =
prompt           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt        tbl.style.display = "none"; }
prompt     else {
prompt         e.innerHTML =
prompt           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt         tbl.style.display = ""; }
prompt   }
prompt   function displayItem2(e, itm_id) {
prompt     var tbl = document.getElementById(itm_id);
prompt     if (tbl.style.display == ""){
prompt        e.innerHTML =
prompt           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt        e.innerHTML = e.innerHTML.replace("Hide","Show");
prompt        tbl.style.display = "none"; }
prompt     else {
prompt         e.innerHTML =
prompt           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt         e.innerHTML = e.innerHTML.replace("Show","Hide");
prompt         tbl.style.display = ""; }
prompt   }  
prompt  function activateTab(pageId) {
prompt   var tabCtrl = document.getElementById('tabCtrl');
prompt    var pageToActivate = document.getElementById(pageId);
prompt    for (var i = 0; i < tabCtrl.childNodes.length; i++) {
prompt        var node = tabCtrl.childNodes[i];
prompt        if (node.nodeType == 1) { /* Element */
prompt            node.style.display = (node == pageToActivate) ? 'block' : 'none';
prompt        }   } }
prompt    function activateTab2(pageId) {
prompt      var tabCtrl = document.getElementById('tabCtrl');
prompt        var pageToActivate = document.getElementById(pageId);
prompt        for (var i = 0; i < tabCtrl.childNodes.length; i++) {
prompt        var node = tabCtrl.childNodes[i];
prompt        if (node.nodeType == 1) { /* Element */
prompt            node.style.display = (node == pageToActivate) ? 'block' : 'none';
prompt        } }
prompt     tabCtrl = document.getElementById('ExecutionSummary2');
prompt     tabCtrl.style.display = "none";
prompt     tabCtrl = document.getElementById('ExecutionSummary1');
prompt     tabCtrl.innerHTML = tabCtrl.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt    }
prompt function opentabs() {
prompt  var tabCtrl = document.getElementById('tabCtrl'); 
prompt    for (var i = 0; i < tabCtrl.childNodes.length; i++) {
prompt        var node = tabCtrl.childNodes[i];
prompt  if (node.nodeType == 1)  {
prompt 	   if (node.toString() != '[object HTMLScriptElement]') { node.style.display =  'block' ; 
prompt       }  }   }  }
prompt function closetabs() {
prompt  var tabCtrl = document.getElementById('tabCtrl');  
prompt    for (var i = 0; i < tabCtrl.childNodes.length; i++) {
prompt        var node = tabCtrl.childNodes[i];
prompt        if (node.nodeType == 1) { /* Element */
prompt            node.style.display =  'none' ;  }    }   }
prompt   function closeall()
prompt           {var txt = "s1sql";
prompt           var i;
prompt           var x=document.getElementById('s1sql0');
prompt           for (i=0;i<88;i++)
prompt           {
prompt                      x=document.getElementById(txt.concat(i.toString())); 
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none';   
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt              }  	}
prompt           for (i=272;i<277;i++)
prompt           {
prompt                      x=document.getElementById(txt.concat(i.toString())); 
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none';   
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt              }  	}
prompt           for (i=472;i<477;i++)
prompt           {
prompt                      x=document.getElementById(txt.concat(i.toString())); 
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none';   
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt              }  	}
prompt           txt = "s1sql100";
prompt           for (i=1;i<300;i++)
prompt {			   x=document.getElementById(txt.concat(i.toString()));                                      
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none'; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt			}
prompt		  	}	      
prompt 		txt = "s1sql200";                                                                                       
prompt		for (i=1;i<300;i++)                                                                                   
prompt			{   x=document.getElementById(txt.concat(i.toString()));                                      
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none'; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt			}
prompt		  	}	}     
  
prompt     function openall()
prompt     {var txt = "s1sql";
prompt     var i;                                                                    
prompt     var x=document.getElementById('s1sql0');                                      
prompt     for (i=0;i<88;i++)                                                               
prompt     {			   x=document.getElementById(txt.concat(i.toString()));                                             
prompt     		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  
prompt              }  	}
prompt     for (i=272;i<277;i++)                                                                                         
prompt     {			   x=document.getElementById(txt.concat(i.toString()));                                             
prompt     		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  
prompt              }  	}
prompt     for (i=472;i<477;i++)                                                                                         
prompt     {			   x=document.getElementById(txt.concat(i.toString()));                                             
prompt     		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  
prompt              }  	}
prompt     		  }  
prompt function hideRow(target)
prompt    {var row = document.getElementById(target);
prompt    row.style.display = 'none';
prompt    row = document.getElementById(target.concat('b'));
prompt    row.scrollIntoView();
prompt	row.innerHTML = row.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));	   
prompt     }
prompt function hideRow2(target)
prompt    {var row = document.getElementById(target);
prompt    row.style.display = 'none';
prompt    row = document.getElementById(target.concat('b'));
prompt    row.scrollIntoView();
prompt	row.innerHTML = row.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt	row.innerHTML = row.innerHTML.replace("Hide","Show");   
prompt     }	 
prompt     </script>
prompt  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
prompt  <script>
prompt  $(document).ready(function(){
prompt  var src = $('img#error_ico').attr('src');
prompt  $('img.error_ico').attr('src', src);
prompt  var src = $('img#warn_ico').attr('src');
prompt  $('img.warn_ico').attr('src', src);
prompt  var src = $('img#check_ico').attr('src');
prompt  $('img.check_ico').attr('src', src);
prompt  });</script>
prompt </HEAD>
prompt <BODY>

prompt <div style="display: none;">
prompt <img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAANYSURBVHjaYvz//z8DDBQwMor+ZWDw+8fA4PKHgcEUiOWB+CEQnwbiPb8ZGDat+///NQMSAAggRpgBQM3OQI25XiGe/jr2Ngwi6hoMbHz8DF/v3mR4dO4cw/HjZxjWHru4C2hQ3+7//3fCDAAIILABhUDNUnJS/UHZSbpKcuIMDCf3Mvy9fo7h7/OnDP+FxRj+i8sx/BOXZTh8+xnDosPnb936/L3yzP//60AGAAQQYwEDA8jZs/M7a/yVvz9n+LdxAcP/v38Z/gId9g/oJBD9F0wzAj2kzrDn43+G7pM3j7xkYEh5+P//TYAAYgL5GeRskM3/Ni1gYEyrZWCcsx9FM9fC/Qzs2fUMP4Heseb6z+AgzmfDycAQw8jIyAYQQExAP7mA/Axy9r8/QOOM7RmYTB0YWOfvBxsA0sxi5gDE9kDD/jP8e/2KQZeXlYGJgcEe6AMJgABiSGNguPN919r/v93l/v/UZfj/XYfh/59T+/+DwO+TEPrnif3/nygy/H8oz/D/niLr/yMawv+1GBieAw0wAgggkAvk2fgFGf6/eMrwD+rkb3GODH9OHQDb/OvkAYbXkY6QcADiP79+Mwj8/c0AVCoKNEAAIIBABjz8dvcGwz8hMbABIMwJdTZIM5u5A4Pwsv0Mf4Caf4Mw0PHPvv4C0gyg9MAFEEAgA04/PHeW4b+EHNgGzgUIzW+ANv88cYCBw8KBQXLlfrD8v/9MDFe//QEZcBtowDeAAAIZsOfEsTPguAZF1e+TB+Ga/wBd8yzMkeH78QMMX48dBBvwGyh25vtfhh8MDBeABnwACCDGQKBfgJwlBT42bmZ/3jL8unOD4S8w+EGaQZHyBxqdIPZfRmaGjV8ZGOZ+/nvyFQPDFKC+QwABxARK20Dn9C0EprC9n4BOVFBn+McvBFTMyvCHgZHhD1DTX0YWht/MrGDNG77+vfuFgWELUPNNoAteAAQQPC+YMjIGAdNaoZOkgI0eLxuDAhsDg9DfPwxPvv5kuPrlF8Ppb38ZDv/4dxKk+R0Dw0GglutAvW8AAogROTfKMzKqg1IYKJEADVMFRRUotEEBBvLzRwaGU1Cb74M0g/QABBCKAWABYPIEpzAGBhFQPIOiChTaoAADYpCmF0A9v2DqAQIMAAqQl7ObLOmtAAAAAElFTkSuQmCC" alt="error_ico">

prompt <img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAJHSURBVHjaYvz//z8DNjAhlnHdv38MgUC8vmT5/yAGHAAggBhABqDj/hgG7+OLvP+DwJEF3v+jLRgKsKkDYYAAYsJiMzMDI0uHkV87A8NpRgYJ9q0MSqIMBQJcjFLYHAAQQBgGAJ2c7BaZpMP26ziYr6zMwGBhwiDvb8BQxAgE6OoBAgjFOb1RDDwTE3mf/v3+5H9nCvf/FEfG/51JjP+fb2T4X+3F8EZFlEEL3QsAAcSEZnuRX3KhFNO7uQxnL3xjuPuQgeHsJQYGCVEGBjtLBmFbFYZyoCNYkPUABBDcgJ5IRmluQZkyeZM0Bobn3QziohBxcRGQyQwMVsZANi9DmKk8gyWyAQABxIRke3VgZhU344tWIOcLg4c9JHo9bIH0XwYGHg4GBjcbBg49SbArOGD6AAKIEeSPrnBGLSFp7UsprauYGa7qAQ34C9YEshlMQ/G/PwwM5V0M/048YAg+fO//BpABAAHEBLW9KzS/k5nhSRlc88K1DAwxJYwMC9cjDGACGujvwMCkIcpQBXQFL0gvQAAxdYQy2hvb23vzC/EwMLzbCrd591FGhmevgPRxRoQrgC6w0WVg0FdkMHVSZogGGQAQQExA20stA0rBAcfwH+FsV4v/DFLAgHQ1+w/XDDPISpuBQU6AIRnoCmGAAGIBGmDCeNuHgYEDyc9AOt4biD3QNP+ByKlKMjCwMzGogNIZQACBDNjS08+QDKQZ8GFQnkOmP/5gOA00QAAggMCxAHSKPpAjx0A6eAQQQIy4sjOxACDAAOXOBcGE78mYAAAAAElFTkSuQmCC" alt="warn_ico">

prompt <img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAELSURBVHjaYvz//z8DJQAggJhIUcyYwNjAGMP4nzGcsQEmBhBADCAXEIMZ4hkaGKIZ/h//dvw/QyDDfwZnhskgcYAAIl3zKQYI9mIA+V0dIIDI12zOsAxogC9AAEEUpQIVpQIFgTSG5ig8moEuAAgguObjv4//RzYExeYL2DWD1AEEEANc82uG/1Ufq/4zJAMVBTNMhtt8EarZE1MzCAMEEML5rxkQhhBhMwwDBBAiDEA2PwXie0BDXlURtBmGAQIIwYA6m+E6A0KzF37NIAwQQKgcb6AhgcRrBmGAAMIUAKYwYjWDMEAAMWLLTIyMjOpASg2IbwHlb+LLHwABxEhpbgQIICYGCgFAgAEAGJx1TwQYs20AAAAASUVORK5CYII=" alt="check_ico">
prompt </div>

prompt <div class="TitleBar"><div class="Title1">HCM Technical Analyzer</div>
prompt <div class="Title2">Compiled using version 200.42 / Latest version:
prompt <a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1562530.1:HCM_ANALYZER_11i">
prompt <img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/hcm_technical_latest_version.gif" title="Click here to download the latest version of analyzer" alt="Latest Version Icon"></a></div></div>
prompt <div class="TitleImg"><a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div><br>


prompt <div class="divSection">
prompt <div class="divItem">
prompt <div class="divItemTitle">Report Information</div>
prompt <span class="legend">Legend: <img class="error_ico"> Error <img class="warn_ico"> Warning <img class="check_ico"> Passed Check</span>	


declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_rows number;
  v_date varchar2(200);
begin
  
  :e1:=0;
  :e2:=0;
  :e3:=0;
  :e4:=0;
  :e5:=0;
  :e6:=0;
  :e7:=0;
  :w1:=0;
  :w2:=0;
  :w3:=0;
  :w4:=0;
  :w5:=0;
  :w6:=0;
  :w7:=0;
  
  select upper(instance_name), host_name into :sid, :host 
  from   v$instance;
  SELECT RELEASE_NAME into :apps_rel from FND_PRODUCT_GROUPS; 
  select to_char(sysdate, 'Dy Month DD, YYYY hh24:mi:ss') into v_date from dual;
  
  dbms_output.put_line('<table width="100%" class="graph"><tbody><tr class="top"><td width="33%">');
  dbms_output.put_line('<A class=detail onclick="displayItem(this,''s1sql91'');" href="javascript:;">&#9654; Execution Details</A>') ;   dbms_output.put_line('<TABLE style="DISPLAY: none" id=s1sql91><TBODY>');
  dbms_output.put_line('<TR><TH>Host:</TH>');
  dbms_output.put_line('<TD>'||:host||'</TD></TR>');
  dbms_output.put_line('<TR><TH>Instance: </TH>');
  dbms_output.put_line('<TD>'||:sid||'</TD></TR>');
  dbms_output.put_line('<TR><TH>Applications Version: </TH>');
  dbms_output.put_line('<TD>'||:apps_rel||'</TD></TR>');
  dbms_output.put_line('<TR><TH>Execution Date: </TH>');
  dbms_output.put_line('<TD>'||v_date||'</TD></TR>');
  dbms_output.put_line('<TR><TH>Analyzer version: </TH>');
  dbms_output.put_line('<TD>200.42</TD></TR>');
   dbms_output.put_line('</TBODY></TABLE></td>');
  dbms_output.put_line('<td width="33%"><A class=detail onclick="displayItem(this,''s1sql92'');" href="javascript:;">&#9654; Parameters</A>');
  dbms_output.put_line('<TABLE style="DISPLAY: none" id=s1sql92 >');
  dbms_output.put_line('<TBODY><TR>');
  dbms_output.put_line('<TH>Run Type</TH>');
  dbms_output.put_line('<TD>');
  if upper(run_type)='ISSUES' then
          dbms_output.put_line('ISSUES: Health Check (only issues and advices) ');
  else
          if upper(run_type)='ALL' then
                 dbms_output.put_line('ALL: Data Collector (all informations and advices) ');
          else
                dbms_output.put_line('<font color="red"> <b>Incorrect run type option. Correct values: ALL, ISSUES</b></font>');
          end if;
  end if;
  dbms_output.put_line('</TD></TR>');
  dbms_output.put_line('<TR>');
  dbms_output.put_line('<TH>Product</TH>');
  dbms_output.put_line('<TD>');


  case upper(product)
    when 'PAY' then
          dbms_output.put_line('Pay: Payroll');
    when 'HR' then 
          dbms_output.put_line('HR: Human Resources');
    when 'BEN' then
          dbms_output.put_line('BEN: Benefits');
	when 'OTA' then
          dbms_output.put_line('OTA: Learning Management');
    when 'OTL' then
          dbms_output.put_line('OTL: Time and Labor');
    when 'SSHR' then
		  dbms_output.put_line('SSHR: Self Service Human Resources');
	when 'IRC' then
		  dbms_output.put_line('IRC: iRecruitment');
	when 'ALL' then
          dbms_output.put_line('ALL: All HCM products');
    else
          dbms_output.put_line('<font color="red"> Incorrect product option. Correct values: BEN, HR, IRC, OTL, OTA, PAY, SSHR, ALL</font>');
  end case;  
   dbms_output.put_line('</TD></TR></TBODY></TABLE></td>');
	
	dbms_output.put_line('<td width="33%"><div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>');
    dbms_output.put_line('<div id="ExecutionSummary2" style="display:none"></div>');
    dbms_output.put_line('</td></tr></table>');

   dbms_output.put_line('</div><br>');
  
 SELECT L.MEANING  into :hr_status
      FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '800')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'	AND l.language = 'US';
  	dbms_output.put_line('<div class="divItem" id="toccontent">');
	dbms_output.put_line('<div class="divItemTitle">Sections In This Report</div></div>');
    dbms_output.put_line('<div align="center">');
	dbms_output.put_line('<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> / ');
	dbms_output.put_line('<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a></div>');
	dbms_output.put_line('</div><br>');

	dbms_output.put_line('<div id="tabCtrl">');
    dbms_output.put_line('<div id="page1" style="display: block;">');


end;
/




-- Overview (database and Application details)

declare
		run_type varchar2(20):='&1';
    product varchar2(20):='&2';
		test			varchar2(240);
		apps_rel  varchar2(10);
		n 			  number;
		host      varchar2(80);
		sid       varchar2(50);
		platform varchar2(100);
		hr_status varchar2(40);
		per_status varchar2(40);
		db_charset V$NLS_PARAMETERS.value%type;
		db_lang V$NLS_PARAMETERS.value%type;
		multiOrg FND_PRODUCT_GROUPS.MULTI_ORG_FLAG%type;
		multiCurr FND_PRODUCT_GROUPS.MULTI_CURRENCY_FLAG%type;
		v_hxc_status 	FND_LOOKUPS.MEANING%type;
		v_hxt_status 	FND_LOOKUPS.MEANING%type;

		rup_level varchar2(20);
		v_exists number;
		v_code varchar2(50);
		v_appl varchar2(50);
		frm_ver varchar2(50);
		cursor legislations is
				SELECT DECODE(legislation_code
							   ,null,'Global'
							   ,legislation_code)                
					   , DECODE(application_short_name
							   , 'PER', 'Human Resources'
							   , 'PAY', 'Payroll'
							   , 'GHR', 'Federal Human Resources'
							   , 'CM',  'College Data'
							   , application_short_name)          
				  FROM hr_legislation_installations
				  WHERE status = 'I'
				  ORDER BY legislation_code;
		v_wfVer WF_RESOURCES.TEXT%type:='';
		v_crtddt V$DATABASE.CREATED%type;
		irc_status varchar2(20);
		cursor bg is
		SELECT o.business_group_id bgi,o.organization_id oi,otl.name name,o3.ORG_INFORMATION9 lc			
			,o3.ORG_INFORMATION10 cc,o4.ORG_INFORMATION2 ef ,to_char(o.date_from , 'DD-MON-YYYY') df,to_char(o.date_to, 'DD-MON-YYYY') dt
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;
Begin
  
  :n := dbms_utility.get_time;
  
  
    
  SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, 'TNS for '), ':' )||pcv2.status, 1, 80)
    INTO :platform
        FROM product_component_version pcv1,
           product_component_version pcv2
     WHERE UPPER(pcv1.product) LIKE '%TNS%'
       AND UPPER(pcv2.product) LIKE '%ORACLE%'
       AND ROWNUM = 1;
       
 	select banner into :db_ver from V$VERSION WHERE ROWNUM = 1;
	select VALUE into db_lang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
	select VALUE into db_charset FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';	
	SELECT MULTI_ORG_FLAG,MULTI_CURRENCY_FLAG into multiOrg, multiCurr FROM FND_PRODUCT_GROUPS;
		

	SELECT L.MEANING  into :pay_status
		  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '801')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'	AND l.language = 'US';
	if :apps_rel like '12.%' then
		select count(*) into v_exists from fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		if v_exists >0 then	
		SELECT L.MEANING  into irc_status  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		end if;
	 end if;  
        
	if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into rup_level FROM ad_bugs adb
            WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646')
			; 
			 SELECT DECODE(bug_number
                  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
				  ,'19193000', 'R12.HR_PF.C.Delta.6'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs  
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
				  
    elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');            
                 
           SELECT DECODE(BUG_NUMBER
                  ,'20000288','R12.HR_PF.B.delta.8'
				  ,'18004477', 'R12.HR_PF.B.delta.7'
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;            

            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
            
           SELECT DECODE(BUG_NUMBER
                  , '16077077', 'R12.HR_PF.A.delta.11'
                  , '13774477', 'R12.HR_PF.A.delta.10'
                  , '10281209', 'R12.HR_PF.A.delta.9'
                  , '9301208', 'R12.HR_PF.A.delta.8'
                  , '7577660', 'R12.HR_PF.A.delta.7'
                  , '7004477', 'R12.HR_PF.A.delta.6'
                  , '6610000', 'R12.HR_PF.A.delta.5'
                  , '6494646', 'R12.HR_PF.A.delta.4'
                  , '6196269', 'R12.HR_PF.A.delta.3'
                  , '5997278', 'R12.HR_PF.A.delta.2'
                  , '5881943', 'R12.HR_PF.A.delta.1'
                  , '4719824', 'R12.HR_PF.A')
                  , LAST_UPDATE_DATE  
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                 
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
            
            if v_exists>0 then         
				   select max(to_number(bug_number)) into rup_level from ad_bugs 
							WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
						   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');                    
								 
				   SELECT DECODE(BUG_NUMBER
                           , '2803988', 'HRMS_PF.E'
                           , '2968701', 'HRMS_PF.F'
                           , '3116666', 'HRMS_PF.G'
                           , '3233333', 'HRMS_PF.H'
                           , '3127777', 'HRMS_PF.I'
                           , '3333633', 'HRMS_PF.J'
                           , '3500000', 'HRMS_PF.K'
                           , '5055050', 'HR_PF.K.RUP.1'
                           , '5337777', 'HR_PF.K.RUP.2'
                           , '6699770', 'HR_PF.K.RUP.3'
                           , '7666111', 'HR_PF.K.RUP.4'
                           , '9062727', 'HR_PF.K.RUP.5'
                           , '10015566', 'HR_PF.K.RUP.6'
                           , '12807777', 'HR_PF.K.RUP.7'
                           , '14488556', 'HR_PF.K.RUP.8'
						   ,'17774746', 'HR_PF.K.RUP.9'
                            )  
                        , LAST_UPDATE_DATE  
                          into :rup_level_n, :v_rup_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =rup_level and rownum < 2;
						
				end if;   
      end if;
	
	if :apps_rel like '12.2%' then
			SELECT decode(max(to_number(adb.bug_number)),'10110982','OA Framework 12.2','14222219','OA Framework 12.2.1','15890638','OA Framework 12.2.2' ,'17007206','OA Framework 12.2.3','17909318','OA Framework 12.2.4','OA Framework 12.2') 
			into frm_ver FROM ad_bugs adb         
			WHERE adb.bug_number in ('10110982', '14222219','15890638', '17007206', '17909318')
			;
				  
    elsif :apps_rel like '12.1%' then                       
           SELECT decode(max(to_number(bug_number)),'17774755','OA Framework 12.1.3.2 RPC1','15880118','OA Framework 12.1.3.2','11894708','OA Framework 12.1.3.1' ,'9239090','OA Framework 12.1.3','8919491','OA Framework 12.1.3','Unknown') 
		   into frm_ver FROM ad_bugs         
			WHERE bug_number in ('17774755','15880118','11894708','9239090','8919491'); 
    elsif :apps_rel like '12.0%' then
            SELECT decode(max(to_number(bug_number)),'6728000','OA Framework 12.0.6','6435000','OA Framework 12.0.4','6141000','OA Framework 12.0.3' ,'5484000','OA Framework 12.0.2','5082400','OA Framework 12.0.1','OA Framework 12.0') 
			into frm_ver FROM ad_bugs         
			WHERE bug_number in ('5082400', '5484000' ,'6141000','6435000','6728000');  
    elsif   :apps_rel like '11.5%' then   
            SELECT decode(max(to_number(bug_number)),'2085104','OA Framework 5.5.2C','2227335','OA Framework 5.5.2E','2278688','OA Framework 5.6.0E' ,'2771817','OA Framework 5.7.0H','3875569','OA Framework 11.5.10',
			 '4017300', 'OA Framework 11.5.10 ATG_PF.H RUP1',
			 '4125550', 'OA Framework 11.5.10 ATG_PF.H RUP2',
			 '4334965', 'OA Framework 11.5.10 ATG_PF.H RUP3',
			 '4676589', 'OA Framework 11.5.10 ATG_PF.H RUP4',
			 '5473858', 'OA Framework 11.5.10 ATG_PF.H RUP5',
			 '5903765', 'OA Framework 11.5.10 ATG_PF.H RUP6',
			 '6241631', 'OA Framework 11.5.10 ATG_PF.H RUP7',
			'Unknown') 
			into frm_ver FROM ad_bugs         
			WHERE bug_number in ('2085104','2227335','2278688','2771817','3061106','3875569','4017300', '4125550','4334965', '4676589','5473858','5903765','6241631');    
				  
      end if;	  
	
	dbms_output.put_line('<a name="overview"></a>');
	dbms_output.put_line('<div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="overview" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Instance Overview:'); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF"> /  </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
	   
	dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	dbms_output.put_line('<a class=detail2 href="#sum">Instance Summary</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#db">Database Details</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#apps">Application Details</a> <br></td><td class="toctable">');
	  if upper(run_type)='ALL' then
			dbms_output.put_line('<a class=detail2 href="#products">Products Status</a> <br>');
			dbms_output.put_line('<a class=detail2 href="#legislations">Legislations Installed</a> <br>');
	  end if;
	  select count(1) into v_exists from FND_LANGUAGES 
		  where INSTALLED_FLAG in ('B','I') ;
	  if v_exists>1 or upper(run_type)='ALL'  then
			 dbms_output.put_line('<a class=detail2 href="#nls">Languages Installed</a> <br>');
	  end if;
	dbms_output.put_line('</td></tr></table></div><br>');
	  
	    
	select count(1) into v_exists FROM V$DATABASE;
	if v_exists=1 then	
	SELECT CREATED into v_crtddt FROM V$DATABASE;
	end if;
	select count(1) into v_exists FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';
	if v_exists=1 then
	SELECT TEXT into v_wfVer  FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';	
	end if;				

	dbms_output.put_line('<DIV class=divItem><a name="sum"></a>');
	dbms_output.put_line('<DIV id="s1sql0b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql0'');" href="javascript:;">&#9654; Instance Summary</A></DIV>');

	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql0" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Instance Summary</B></font></TD>');	
	dbms_output.put_line(' </TR>');
	dbms_output.put_line('<TR><TD>Instance Name = '||:sid||'<br>');
	dbms_output.put_line('Instance Creation Date = '||v_crtddt||'<br>');
	dbms_output.put_line('Server/Platform = '||:platform||'<br>');
	dbms_output.put_line('Language/Characterset = '||db_lang||' / '||db_charset||'<br>');
	dbms_output.put_line('Database = '||:db_ver||'<br>');
	dbms_output.put_line('Applications = '||:apps_rel||'<br>');
	dbms_output.put_line('OA Framework Version = '||frm_ver||'<br>');
	dbms_output.put_line('Workflow = '||v_wfVer||'<br>');
	dbms_output.put_line('PER '||:hr_status||' - PAY '||:pay_status||'<br><br>');
	if :apps_rel like '11.5%' and v_exists=0 then   
           dbms_output.put_line('no RUP');		
    else
			dbms_output.put_line(:rup_level_n|| ' applied on ' || :v_rup_date ||'<br>');
	end if;
	dbms_output.put_line('<br>Installed legislations<br>');
	dbms_output.put_line('Code   Application');
	dbms_output.put_line('<br>-------------------<br>');
	
	  
	open legislations;
    loop
          fetch legislations into v_code,v_appl;
          EXIT WHEN  legislations%NOTFOUND;
          dbms_output.put_line(v_code||'   '||v_appl||'<br>');         
    end loop;
    close legislations;	
	
	dbms_output.put_line(' </TABLE> </div> ');
	
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    	
	dbms_output.put_line('<div id="fordx" style="display:none">');
		dbms_output.put_line('Instance Name = '||:sid||chr(10)||'Instance Creation Date = '||v_crtddt);
		dbms_output.put_line('Server/Platform = '||:platform||chr(10)||'Language/Characterset = '||db_lang||' / '||db_charset);
		dbms_output.put_line('Database = '||:db_ver||chr(10)||'Applications = '||:apps_rel||chr(10)||'OA Framework Version = '||frm_ver||chr(10)||'Workflow = '||v_wfVer);
		dbms_output.put_line('PER '||:hr_status||chr(10)||'PAY '||:pay_status||chr(10)||'IRC '||irc_status||chr(10)||chr(10)||:rup_level_n|| ' applied on ' || :v_rup_date ||chr(10)||chr(10)||'Installed legislations');
		open legislations;
		loop
			  fetch legislations into v_code,v_appl;
			  EXIT WHEN  legislations%NOTFOUND;
			  dbms_output.put_line(v_code||'   '||v_appl);         
		end loop;
		close legislations;
		dbms_output.put_line(chr(10)||lpad('Bus Grp ID',10)||lpad('Org ID',10)||lpad('Organization Name',50)||lpad('Legis',6)||lpad('Curr',6)||lpad('Enabl',7)||' '||lpad('Date From',11) ||' '||lpad('Date To',11));
	for org_rec in bg loop
		dbms_output.put_line(lpad(org_rec.bgi,10)||lpad(org_rec.oi,10)||lpad(org_rec.name,50)||lpad(org_rec.lc,6)||lpad(org_rec.cc,6)||lpad(org_rec.ef,7)||' '||lpad(org_rec.df,11)||' '||lpad(org_rec.dt,11));
	end loop;	
	
	dbms_output.put_line('</div>');
	
	dbms_output.put_line('<a name="db"></a>');
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql1b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql1'');" href="javascript:;">&#9654; Database Details</A></DIV>');	
	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql1" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Database details</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql2b" onclick="displayItem2(this,''s1sql2'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql2" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="5" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          SELECT upper(instance_name), host_name<br>');
	dbms_output.put_line('          	FROM   fnd_product_groups, v$instance;<br>');
	dbms_output.put_line('        SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, ''TNS for ''), '':'' )||pcv2.status, 1, 80)<br>');
	dbms_output.put_line('            	FROM product_component_version pcv1,<br>');
	dbms_output.put_line('                   product_component_version pcv2<br>');
	dbms_output.put_line('             	WHERE UPPER(pcv1.product) LIKE ''%TNS%''<br>');
	dbms_output.put_line('               	AND UPPER(pcv2.product) LIKE ''%ORACLE%''<br>');
	dbms_output.put_line('               	AND ROWNUM = 1;<br>');
	dbms_output.put_line('        SELECT banner from V$VERSION WHERE ROWNUM = 1;<br>');
	dbms_output.put_line('        SELECT value FROM V$NLS_PARAMETERS WHERE parameter in (''NLS_LANGUAGE'',''NLS_CHARACTERSET'');');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Hostname</B></TD>');
	dbms_output.put_line(' <TH><B>Platform</B></TD>');
	dbms_output.put_line(' <TH><B>Sid</B></TD>');
	dbms_output.put_line(' <TH><B>Database version</B></TD>');
	dbms_output.put_line(' <TH><B>Language</B></TD>');
	dbms_output.put_line(' <TH><B>Character set</B></TD>');
	dbms_output.put_line('<TR><TD>'||:host||'</TD>'||chr(10)||'<TD>'||:platform||'</TD>'||chr(10));
	dbms_output.put_line('<TD>'||:sid||'</TD>'||chr(10)||'<TD>'||:db_ver||'</TD>'||chr(10)||'<TD>'||db_lang||'</TD>'||chr(10)||'<TD>'||db_charset ||'</TD></TR>'||chr(10));	 	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE> </div> ');
	
	if :apps_rel like '11.5%' and (:db_ver like '9.2%' or :db_ver like '10.1%' or :db_ver like '10.2.0.2%' or :db_ver like '10.2.0.3%' or :db_ver like '11.1.0.6%') then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Minimum Requirements: Database 10.2.0.4 or 11.1.0.7!<br>');
		dbms_output.put_line('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=883202.1" target="_blank">Note 883202.1</a> ');
		dbms_output.put_line('Patch Requirements for Sustaining Support for Oracle E-Business Suite Release 11.5.10<br>');
		dbms_output.put_line('</div><br><br>');
		:w1:=:w1+1;
	elsif :apps_rel like '12.0%' and (:db_ver like '9.2%' or :db_ver like '10.1%' or :db_ver like '10.2.0.2%' or :db_ver like '10.2.0.3%' or :db_ver like '10.2.0.4%' or :db_ver like '11.1.0.6%' or :db_ver like '11.2.0.1%') then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Minimum Requirements: Oracle Database 10.2.0.5, 11.1.0.7, or 11.2.0.2!<br>');
		dbms_output.put_line('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1334562.1" target="_blank">Note 1334562.1</a> ');
		dbms_output.put_line('Minimum Patch Requirements for Extended Support of Oracle E-Business Suite Human Capital Management (HCM) Release 12.0<br>');
		dbms_output.put_line('</div><br><br>');
		:w1:=:w1+1;
	end if;
	
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

  
	 :n := dbms_utility.get_time;
	
    
	if upper(product)='OTL' then
		SELECT L.MEANING  into v_hxc_status
		  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '809')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'
		AND l.language = 'US';
		
		SELECT L.MEANING  into v_hxt_status
		  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '808')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'
		AND l.language = 'US';
	end if;
    
	dbms_output.put_line('<DIV class=divItem><a name="apps"></a>');
	dbms_output.put_line('<DIV id="s1sql3b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql3'');" href="javascript:;">&#9654; Application Details</A></DIV>');
	if upper(product)='OTL' then		
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql3" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=7 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Application Details</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql4b" onclick="displayItem2(this,''s1sql4'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql4" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="7" height="60">');
	else
	
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql3" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Application Details</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql4b" onclick="displayItem2(this,''s1sql4'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql4" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="5" height="60">');
	end if;
	
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          SELECT RELEASE_NAME from FND_PRODUCT_GROUPS;<br>');	
	dbms_output.put_line('          SELECT MULTI_ORG_FLAG,MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS;<br>');
	dbms_output.put_line('          SELECT V.APPLICATION_ID, L.MEANING  <br>');
	dbms_output.put_line('              FROM FND_APPLICATION_ALL_VIEW V, FND_PRODUCT_INSTALLATIONS I, FND_LOOKUPS L<br>');
	dbms_output.put_line('              WHERE (V.APPLICATION_ID = I.APPLICATION_ID)<br>');
  
	if upper(product)='OTL' then
		dbms_output.put_line('                AND (V.APPLICATION_ID in (''800'',''801'',''808'',''809''))<br>');
	else
		dbms_output.put_line('                AND (V.APPLICATION_ID in (''800'',''801''))<br>');
	end if;
  
	dbms_output.put_line('                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')<br>');
	dbms_output.put_line('               AND (L.LOOKUP_CODE = I.Status);<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Release</B></TD>');
	dbms_output.put_line(' <TH><B>HRMS RUP</B></TD>');
	dbms_output.put_line(' <TH><B>MultiOrg Flag</B></TD>');
	dbms_output.put_line(' <TH><B>MultiCurrency Flag</B></TD>');
	
	if upper(product)='OTL' then
				dbms_output.put_line(' <TH><B>HXC Status</B></TD>');
				dbms_output.put_line(' <TH><B>HXT Status</B></TD>');
	end if;
	
	dbms_output.put_line(' <TH><B>HR Status</B></TD>');
	dbms_output.put_line(' <TH><B>PAY Status</B></TD>');

	dbms_output.put_line('<TR><TD>'||:apps_rel||'</TD>'||chr(10));
	
	if :apps_rel like '11.5%'  and v_exists=0 then
					dbms_output.put_line('<TD>no RUP</TD>'||chr(10));			
    else
			dbms_output.put_line('<TD>'||:rup_level_n|| ' applied on ' || :v_rup_date ||'</TD>'||chr(10));
	end if;
	
	dbms_output.put_line('<TD>'||multiOrg||'</TD>'||chr(10));
	if upper(product)='OTL' then
	    dbms_output.put_line('<TD>'||multiCurr||'</TD>'||chr(10)||'<TD>'||v_hxc_status||'</TD>'||chr(10)||'<TD>'||v_hxt_status);
		dbms_output.put_line('</TD>'||chr(10)||'<TD>'||:hr_status||'</TD>'||chr(10)||'<TD>'||:pay_status||'</TD></TR>'||chr(10));
	else
		dbms_output.put_line('<TD>'||multiCurr||'</TD>'||chr(10)||'<TD>'||:hr_status||'</TD>'||chr(10)||'<TD>'||:pay_status||'</TD></TR>'||chr(10));	 	
	end if;
	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	if upper(product)='OTL' then
		dbms_output.put_line(' <TH COLSPAN=7 bordercolor="#DEE6EF"><font face="Calibri">');
	else
		dbms_output.put_line(' <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	end if;
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE> </div> ');
	if :apps_rel like '11.5%' then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please note that statutory legislative support expired on November 30th 2013');
		dbms_output.put_line(', please refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1384995.1" target="_blank">Note 1384995.1</a> ');
		dbms_output.put_line(' When Is Statutory Legislative Support for Payroll Going To End For Release 11i<br></div>');	
		:w1:=:w1+1;
	end if;
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



--  Products Status  

declare
	run_type varchar2(20):='&1';
	v_appl fnd_application_all_view.application_name%type; 
	v_appls fnd_application_all_view.application_short_name%type; 
	v_applid varchar2(20);
	v_status fnd_lookups.meaning%type;
	v_patch fnd_product_installations.patch_level%type;
	cursor products is
	select t.application_name , b.application_short_name
		, to_char(t.application_id)
		, l.meaning
		, decode(i.patch_level, null, '11i.' || b.application_short_name || '.?', i.patch_level)
		from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
		where (t.application_id = i.application_id)
		AND b.application_id = t.application_id
		 and (b.application_id in ('0', '50', '101','178', '203', '231', '275', '426', '453', '800', '801', '802', '803', '804', '805', '808', '809', '810', '821', '8301', '8302', '8303','8401','8403'))
		and (l.lookup_type = 'FND_PRODUCT_STATUS')
		and (l.lookup_code = i.status )
		AND t.language = 'US' AND l.language = 'US' order by upper(t.application_name);

begin
if upper(run_type)='ALL' then
	dbms_output.put_line(' <a name="products"></a>');
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql5b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql5'');" href="javascript:;">&#9654; Products Status</A></DIV>');

	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql5" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Applications Status</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql6b" onclick="displayItem2(this,''s1sql6'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql6" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('        select v.application_name , v.application_short_name  <br>');     
	dbms_output.put_line('        , to_char(v.application_id) <br>');
	dbms_output.put_line('        , l.meaning    <br>');             
	dbms_output.put_line('        , decode(i.patch_level, null, ''11i.'' || v.application_short_name || ''.?'', i.patch_level) <br>');
	dbms_output.put_line('        from fnd_application_all_view v, fnd_product_installations i, fnd_lookups l<br>');
	dbms_output.put_line('        where (v.application_id = i.application_id)<br>');
	dbms_output.put_line('        and (v.application_id in <br>');
	dbms_output.put_line('         (''0'', ''50'', ''178'', ''275'', ''426'', ''453'', ''800'', ''801'', ''802'', ''803'', ''804'', ''805'', ''808'', ''809'', ''810'', ''8301'', ''8302'', ''8303''))<br>');
	dbms_output.put_line('        and (l.lookup_type = ''FND_PRODUCT_STATUS'')<br>');
	dbms_output.put_line('        and (l.lookup_code = i.status )');
	dbms_output.put_line('        order by upper(v.application_name);');
    dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Application</B></TD>');
	dbms_output.put_line(' <TH><B>Short Name</B></TD>');
	dbms_output.put_line(' <TH><B>Code</B></TD>');
	dbms_output.put_line(' <TH><B>Status</B></TD>');
	dbms_output.put_line(' <TH><B>Patchset</B></TD>');
		
	:n := dbms_utility.get_time;
	open products;
    loop
          fetch products into v_appl,v_appls,v_applid,v_status,v_patch;
          EXIT WHEN  products%NOTFOUND;
          dbms_output.put_line('<TR><TD>'||v_appl||'</TD>'||chr(10)||'<TD>'||v_appls||'</TD>'||chr(10));
		  if v_appls='HXC' and :apps_rel like '12.%'  then
				dbms_output.put_line('<TD>'||v_applid||'</TD>'||chr(10)||'<TD>'||v_status||'</TD>'||chr(10)||'<TD>-</TD> </TR>'||chr(10));
		  else
				dbms_output.put_line('<TD>'||v_applid||'</TD>'||chr(10)||'<TD>'||v_status||'</TD>'||chr(10)||'<TD>'||v_patch||'</TD> </TR>'||chr(10));
		  end if;	  
    end loop;
    close products;
	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE> </div> ');
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

end if;

EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Legislation Installed  

declare
	run_type varchar2(20):='&1';
	v_code varchar2(20); 
	v_appl varchar2(50);
	v_appls varchar2(50);
	v_date varchar2(30);
	v_action varchar2(20);
	cursor legislations is
	select  decode(legislation_code,null,'global',legislation_code), 
	decode(application_short_name , 'PER', 'Human Resources' , 'PAY', 'Payroll' , 'GHR', 'Federal Human Resources' , 'CM',  'College Data' , application_short_name),
    application_short_name ,to_char(last_update_date, 'DD-MON-YYYY')
	from hr_legislation_installations
      where status = 'I' 
      order by legislation_code;
begin
dbms_output.put_line(' <a name="legislations"></a>');
if upper(run_type)='ALL' then
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql7b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql7'');" href="javascript:;">&#9654; Legislations Installed</A></DIV>');	
	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql7" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Legislations Installed</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql8b" onclick="displayItem2(this,''s1sql8'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql8" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('         select decode(legislation_code,null,''global'',legislation_code) <br>');
	dbms_output.put_line('          , decode(application_short_name<br>');
	dbms_output.put_line('          , ''PER'', ''Human Resources''<br>');
	dbms_output.put_line('          , ''PAY'', ''Payroll''<br>');
	dbms_output.put_line('          , ''GHR'', ''Federal Human Resources''<br>');
	dbms_output.put_line('          , ''CM'',  ''College Data''<br>');
	dbms_output.put_line('          , application_short_name) <br>');
	dbms_output.put_line('          , application_short_name <br>');
	dbms_output.put_line('          ,decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'')<br>');
	dbms_output.put_line('          , last_update_date  <br>');
	dbms_output.put_line('          from hr_legislation_installations <br>');
	dbms_output.put_line('          where status = ''I''<br>');
	dbms_output.put_line('          order by legislation_code;');
  dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Legislation Code</B></TD>');
	dbms_output.put_line(' <TH><B>Application Name</B></TD>');
	dbms_output.put_line(' <TH><B>Application Code</B></TD>');
	dbms_output.put_line(' <TH><B>Action</B></TD>');
	dbms_output.put_line(' <TH><B>Applied Date</B></TD>');
	
	:n := dbms_utility.get_time;
	open legislations;
    loop
          fetch legislations into v_code,v_appl,v_appls,v_date;
          EXIT WHEN  legislations%NOTFOUND;
          dbms_output.put_line('<TR><TD>'||v_code||'</TD>'||chr(10)||'<TD>'||v_appl||'</TD>'||chr(10));
		  dbms_output.put_line('<TD>'||v_appls||'</TD>'||chr(10));
		  dbms_output.put_line('<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD> </TR>'||chr(10));
          
    end loop;
    close legislations;
	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql7'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE> </div> ');
	
	dbms_output.put_line('<div class="divok">');
   	dbms_output.put_line('<font color="blue">Advice:</font> Review <A href="#mandatory">mandatory patching section</A>');	
	dbms_output.put_line(' as per <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1160507.1" target="_blank">Note 1160507.1</a> ');
    dbms_output.put_line('Oracle E-Business Suite HCM Information Center - Consolidated HRMS Mandatory Patch list');
    dbms_output.put_line('</div>');
	
 
    dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

--  Check NLS synchronization with US language (if you use additional languages) 

declare
    run_type varchar2(20):='&1';
	lang number;
    v_lang_code FND_LANGUAGES.LANGUAGE_CODE%type;
    v_flag varchar2(25);
    v_language FND_LANGUAGES.NLS_LANGUAGE%type;
    cursor languages is
    SELECT LANGUAGE_CODE ,  
             decode(INSTALLED_FLAG ,'B','Base language','I','Installed language'),
             NLS_LANGUAGE
      FROM FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I')
      order by LANGUAGE_CODE;
begin
    select count(1) into lang from FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I') ;
    if lang>1 or upper(run_type)='ALL'  then
			dbms_output.put_line(' <a name="nls"></a>');			
            dbms_output.put_line('<DIV class=divItem>');
			dbms_output.put_line('<DIV id="s1sql33b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql33'');" href="javascript:;">&#9654; Languages Installed</A></DIV>');								  
                                  dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql33" style="display:none" >');
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('     <B>Languages:</B></font></TD>');
                                  dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                                  dbms_output.put_line('<A class=detail id="s1sql34b" onclick="displayItem2(this,''s1sql34'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  dbms_output.put_line('   </TD>');
                                  dbms_output.put_line(' </TR>');
                                  dbms_output.put_line(' <TR id="s1sql34" style="display:none">');
                                  dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
                                  dbms_output.put_line('       <blockquote><p align="left">');
                                  dbms_output.put_line('          SELECT LANGUAGE_CODE , <br>');                                   
                                  dbms_output.put_line('                 decode(INSTALLED_FLAG ,''B'',''Base language'',''I'',''Installed language''),<br>');  
                                  dbms_output.put_line('                 NLS_LANGUAGE<br>'); 
                                  dbms_output.put_line('                FROM FND_LANGUAGES <br>'); 
                                  dbms_output.put_line('                where INSTALLED_FLAG in (''B'',''I'')<br>'); 
                                  dbms_output.put_line('                order by LANGUAGE_CODE;<br>'); 
                                  dbms_output.put_line('          </blockquote><br>');
                                  dbms_output.put_line('     </TD>');
                                  dbms_output.put_line('   </TR>');
                                  dbms_output.put_line(' <TR>');
                                  dbms_output.put_line(' <TH><B>Code</B></TD>');
                                  dbms_output.put_line(' <TH><B>Flag</B></TD>');
                                  dbms_output.put_line(' <TH><B>Language</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open languages;
                                  loop
                                        fetch languages into v_lang_code, v_flag, v_language;
                                        EXIT WHEN  languages%NOTFOUND;
                                        dbms_output.put_line('<TR><TD>'||v_lang_code||'</TD>'||chr(10)||'<TD>'||v_flag||'</TD>'||chr(10)||'<TD>'||v_language||'</TD></TR>'||chr(10));
                                  end loop;
                                  close languages;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  dbms_output.put_line(' </TABLE> </div> ');
                     if lang>1 then               
                                  dbms_output.put_line('<div class="divok">');
								  dbms_output.put_line('<font color="blue">Advice: </font>Periodically check if you NLS level is in sync with US level:<br>');
                                  dbms_output.put_line('Follow <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=252422.1" target="_blank" >Note 252422.1</a> Requesting Translation Synchronization Patches<br>');
                                  dbms_output.put_line('-> this will synchronize your languages with actual US level<br>');
                                  dbms_output.put_line('Note! This is just an advice. This does not mean your NLS is not synchronized! Follow this step ONLY if you have translation issues.');
								  dbms_output.put_line('</div>');
					end if;
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    end if;
	dbms_output.put_line('</div>');
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Patching status
-- HRMS RUP


	
declare
    run_type varchar2(20):='&1';
    rup_level varchar2(20);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_rows number;
	v_exists number;
	issue boolean:=FALSE;
	product varchar2(20):='&&2';
	
-- Display patch
	procedure dpatch (v_leg varchar2, v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	  v_patch2 varchar(10):=v_patch;
	begin		
		select count(1) into v_exists from hr_legislation_installations
					where Legislation_code = v_leg and status='I';
		if v_exists>0 then
					dbms_output.put_line(v_leg||': ');
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								 issue:=TRUE;
								 dbms_output.put_line('<div class="divwarn">');
								 dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Not applied ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> ');
								 dbms_output.put_line(v_name||'</div><br>');
								 :w5:=:w5+1;
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							dbms_output.put_line('Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'<br>');
							
						end if;
		end if;
	end;
	procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	  v_exists number:=0;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;
						if (v_exists=0) then             
								 issue:=TRUE;
								 dbms_output.put_line('<div class="divwarn">');
								 dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Not installed ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> ');
								 dbms_output.put_line(v_name||'<br></div>');
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							dbms_output.put_line('Patch '||v_patch||' ' || v_name);
							dbms_output.put_line(' applied on '||v_patch_date||'<br>');
							
						end if;
	end;

begin
      
	  :issuep:=0;
	  
	  dbms_output.put_line('</div>');
	dbms_output.put_line('<div id="page2" style="display: none;">');
	dbms_output.put_line('<a name="rup"></a><a name="patching"></a><div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="patching" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Patching: '); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF"> /  </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
	

      dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	  dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	  dbms_output.put_line('<a class=detail2 href="#rup">HRMS RUP and hrglobal</a> <br>');	  
      dbms_output.put_line('<a class=detail2 href="#mandatory">Mandatory Patches</a> <br>');
	  if upper(product) in ('OTL','ALL') then
			dbms_output.put_line('<a class=detail2 href="#projects">Projects</a> <br>');
	  end if;
	  dbms_output.put_line('<a class=detail2 href="#atg">ATG</a> <br></td><td class="toctable">');      
      dbms_output.put_line('<a class=detail2 href="#geocode">Geocode</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#quantum">Quantum</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#jit">JIT</a> <br>');
	  if upper(product) in ('SSHR','ALL') then
			dbms_output.put_line('<a class=detail2 href="#org">Organization Chart Feature</a> <br>');
	  end if;
      dbms_output.put_line('<a class=detail2 href="#perf">Performance patches</a> <br>');      
      dbms_output.put_line('</td></tr></table>');
	dbms_output.put_line('</div><br>');
	
	    dbms_output.put_line(' <div class="divItem"><br><b>HRMS RUP and hrglobal</b><br>');
      
       if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into rup_level FROM ad_bugs adb
			WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646');           
                 
            if rup_level='19193000' then
                  
                  if upper(run_type)='ALL' then
                          dbms_output.put_line('<b>Actual level:</b> Patch 19193000 R12.HR_PF.C.delta.6 applied on '||:v_rup_date||'<br><br>');
                  end if;
                  dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Ensure you applied patches to fix known issues (note periodically updated): ');
                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1992028.1" target="_blank"> Note 1992028.1</a> ');
                  dbms_output.put_line('Known Issues on Top of Patch 19193000 - R12.HR_PF.C.DELTA.6 (HRMS 12.2 RUP6) </div>');			  
				   
            else
                  SELECT DECODE(bug_number
                  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  dbms_output.put_line('<b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '<br><br>');
				  dbms_output.put_line('<div class="divwarn">');
                  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19193000">');
				  dbms_output.put_line('Patch 19193000</a> R12.HR_PF.C.delta.6</div><br><br>');
				  :w5:=:w5+1;
				  :issuep:=1;
							  
				  
            end if;
			if (:hr_status='Installed') then
					  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');					 
					  dpatch('AU','19026516', 'AUSTRALIA SUPERSTREAM DATA CAPTURE - PHASE 1');
					  dpatch('CA','20365000','End of Year 2014 Phase 3');
					  dpatch('IN','20733388','R121 TRACKING BUG FOR INDIA 2015-16 BUDGET CHANGES');
					  dpatch('NL','18789871', 'Discount hiring young employee and Legal Minimum Wages');
					  dpatch('NZ','19245681', 'NEW ZEALAND CONSOLIDATED PATCH ABOVE- 12.2.3');
					  dpatch('MX','20259629','2014 EOY Phase 1');
					  dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
					  dpatch('SG','20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');
					  dpatch('US','20365000','End of Year 2014 Phase 3');
					  dpatch('ZA','20812316', 'ZA: COIDA LIMIT CHANGED EFFECTIVE FROM 1 APRIL 2015');
					  if issue then
						:issuep:=1;
					  end if;
				
			end if;			
			if upper(run_type)='ALL' then               
					dbms_output.put_line('<br><b>HRMS Family Packs history</b>:<br>');
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('17909898', 'R12.HR_PF.C.Delta.5');
					dpatch('17050005', 'R12.HR_PF.C.Delta.4');
					dpatch('17001123', 'R12.HR_PF.C.delta.3');
					dpatch('16169935', 'R12.HR_PF.C.delta.2');
					dpatch('14040707', 'R12.HR_PF.C.delta.1');
					dpatch('10124646', 'R12.HR_PF.C');						
					dbms_output.put_line('<br>');				
            end if;
            
      elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');            
            if (:hr_status='Installed') then
									  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');								  
									  dpatch('AE','17449352', 'AFTER UPGRADE 12.1.3,ORA-00904:"U1": INVALID IDENTIFIER WHEN VIEW ITD BALANCE');
									  dpatch('AU','19026516', 'AUSTRALIA SUPERSTREAM DATA CAPTURE - PHASE 1');
									  dpatch('CA','20365000','End of Year 2014 Phase 3');
									  dpatch('DK','20107803', 'Danish Legislative Changes 2015');
									  dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');									 
									  dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
									  dpatch('IN','21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
									  dpatch('JP','19862190','H27 TERMINATION TAX RATE CHANGES EFFECTIVE 01-JAN-2015');
									  dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
									  dpatch('MX','20259629','2014 EOY Phase 1');
									  dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
									  dpatch('US','20365000','End of Year 2014 Phase 3');									  
									  dpatch('ZA','20812316', 'ZA: COIDA LIMIT CHANGED EFFECTIVE FROM 1 APRIL 2015');				  
								end if; 	
			if rup_level='20000288' then
                  
                  dbms_output.put_line('<br><br><b>Actual level:</b> Patch 20000288 R12.HR_PF.B.delta.8 applied on '||:v_rup_date||'<br><br>');                  
                  dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Ensure you applied patches to fix known issues (note periodically updated): ');
                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1992029.1" target="_blank"> Note 1992029.1</a> ');
                  dbms_output.put_line('Known Issues on Top of Patch 20000288 - R12.HR_PF.B.DELTA.8 (HRMS 12.1 RUP8)</div>');	
				   	
            
            else
                  SELECT DECODE(BUG_NUMBER                  
				  ,'18004477', 'R12.HR_PF.B.delta.7'
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  dbms_output.put_line('<br><b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<div class="divwarn">');
				  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=20000288">');
				  dbms_output.put_line('Patch 20000288</a> R12.HR_PF.B.delta.8</div><br><br>');
				  :w5:=:w5+1;
				  :issuep:=1;
				  
				  if rup_level='16000686' and (:hr_status='Installed') then
					  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
					  dpatch('AE','17449352', 'AFTER UPGRADE 12.1.3,ORA-00904:"U1": INVALID IDENTIFIER WHEN VIEW ITD BALANCE');
					  dpatch('AU','19026516', 'AUSTRALIA SUPERSTREAM DATA CAPTURE - PHASE 1');
					  dpatch('CA','18075556','R12.PAY.B End of Year 2013 Phase 3');
					  dpatch('DK','18087349', 'E-income File Record 6002 Changes');
					  dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
					  dpatch('HK','17385401','R121 HK.15 HK STATUTORY MPF MIN/MAX RI CHANGES FOR 1 NOV 2013/1 JUNE 2014');
					  dpatch('IE','19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					  dpatch('IN','19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
					  dpatch('KR','18472619','KOREA CUMULATIVE RELEASE PATCH - R12.0.KR.70');
					  dpatch('KW','16787133', 'TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');
					  dpatch('MX','18349603','YE13P2:121:MEXICO YEAREND - 2013 PHASE 2');
					  dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
					  dpatch('SG','17651515','R121.SG.36 - SINGAPORE HRMS CONSOLIDATED PATCH');					  
					  dpatch('US','18285981','R12.PAY.B Q1 2014 Statutory and JIT Update');
					  dpatch('ZA','18318317', 'ZA BUDGET SPEECH CHANGES 2014/15 ');					  
					 
                 end if;  
				 
				  if rup_level='13418800' and (:hr_status='Installed') then
						  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
						 dpatch('AU','16365150','R121.AU.20 AUSTRALIA CUMULATIVE RELEASE');
						  dpatch('DK','16002560','DANISH LEGISLATIVE CHANGES 2013 PART-3');
						  dpatch('GB','16373594','TYE13 P11D LEGISLATIVE CHANGES FOR 2012-2013');
						  dpatch('HK','16457605','R121 HK.14 HK STATUTORY MINIMUM WAGE RATE CHANGE 1ST MAY 2013');
						  dpatch('IE','16811074','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');
						  dpatch('IN', '14351982','HRMS R12.1:Budget 2012 Additional Changes for SEC 80CCG AND 80TTA');
						  dpatch('JP','17015507','JAPANESE HRMS CONSOLIDATED PATCH R121.JP.13');
						  dpatch('KW','16787133', 'TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');						 
						  dpatch('NL','17309051','Dutch Labour Handicap Discount Calculation to use Full Time Salary');
						  dpatch('SG','17173295','R121.SG.35 - SINGAPORE HRMS CONSOLIDATED PATCH');
						  dpatch('ZA','16543654','ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013 TO R312 480');
						  dpatch('ZA', '16608448','AFTER APPLYING THE RUP5 PATCH SSHR PAYSLIP PAYROLL');						  
				  end if;
            end if; 
			if upper(run_type)='ALL' then               
					dbms_output.put_line('<br><b>HRMS Family Packs history</b>:<br>');
					dpatch('20000288','R12.HR_PF.B.delta.8');
					dpatch('18004477', 'R12.HR_PF.B.delta.7');
				    dpatch('16000686', 'R12.HR_PF.B.delta.6');    
                    dpatch('13418800', 'R12.HR_PF.B.delta.5');
                    dpatch('10281212', 'R12.HR_PF.B.delta.4');
                    dpatch('9114911', 'R12.HR_PF.B.delta.3');
                    dpatch('8337373', 'R12.HR_PF.B.delta.2');
                    dpatch('7446767', 'R12.HR_PF.B.delta.1');
                    dpatch('6603330', 'R12.HR_PF.B');				
            end if;
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
            
            if rup_level='16077077' then
                 
                  if upper(run_type)='ALL' then
                          dbms_output.put_line('<b>Actual level:</b> Patch 16077077 R12.HR_PF.A.delta.11 applied on '||:v_rup_date||'<br><br>');
                  end if;
                  dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Ensure you applied patches to fix known issues (note periodically updated): ');
                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1538635.1" target="_blank"> Note 1538635.1</a> ');
                  dbms_output.put_line('Known Issues on Top of Patch 16077077 - r12.hr_pf.a.delta.11</div>');
				  if (:hr_status='Installed') then
					  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
					  dpatch('CA','20365000','End of Year 2014 Phase 3');
					  dpatch('DK','20107803', 'Danish Legislative Changes 2015');
					  dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');					
					  dpatch('HK','17385401','R12.HK.15 HK STATUTORY MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');
					  dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
					  dpatch('IN','19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
					  dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
					  dpatch('MX','20259629','2014 EOY Phase 1');
					  dpatch('NL','19071113','Delivers new discount for hiring young employees and updates to Legal Minimum Wages effective July 2014');
					  dpatch('SG','17651515','R12.SG.36 - SINGAPORE HRMS CONSOLIDATED PATCH');					  
					  dpatch('US','20365000','End of Year 2014 Phase 3');				 
					  dpatch('ZA','19544341', 'ZA: AUGTYE14 REPORTING CHANGES');
					  if issue then
						:issuep:=1;
					  end if;
				end if;
            else
                  SELECT DECODE(BUG_NUMBER
                  , '16077077', 'R12.HR_PF.A.delta.11'
                  , '13774477', 'R12.HR_PF.A.delta.10'
                  , '10281209', 'R12.HR_PF.A.delta.9'
                  , '9301208', 'R12.HR_PF.A.delta.8'
                  , '7577660', 'R12.HR_PF.A.delta.7'
                  , '7004477', 'R12.HR_PF.A.delta.6'
                  , '6610000', 'R12.HR_PF.A.delta.5'
                  , '6494646', 'R12.HR_PF.A.delta.4'
                  , '6196269', 'R12.HR_PF.A.delta.3'
                  , '5997278', 'R12.HR_PF.A.delta.2'
                  , '5881943', 'R12.HR_PF.A.delta.1'
                  , '4719824', 'R12.HR_PF.A')
                  , LAST_UPDATE_DATE  
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  dbms_output.put_line('<b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<div class="divwarn">');
				  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install ');
				  dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=16077077">Patch 16077077</a> R12.HR_PF.A.delta.11<br><br></div>');
				  :issuep:=1;
				  :w5:=:w5+1;
				  if rup_level='13774477' and (:hr_status='Installed') then
						  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
						 dpatch('AU','16365150','R121.AU.20 AUSTRALIA CUMULATIVE RELEASE');
						  dpatch('DK','16002560','DANISH LEGISLATIVE CHANGES 2013 PART-3');
						  dpatch('GB','16373594','TYE13 P11D LEGISLATIVE CHANGES FOR 2012-2013');
						  dpatch('HK','16457605','R12.HK.14 HK STATUTORY MINIMUM WAGE RATE CHANGE 1ST MAY 2013');
						  dpatch('IE','16811074','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');
						  dpatch('IN', '17579687','12.0BL: INDIA CONSOLIDATED UPDATE IN.09 ');						  
						  dpatch('KR','18472619','KOREA CUMULATIVE RELEASE PATCH - R12.0.KR.70');
						  dpatch('KW','16787133', 'TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');
						  
						  dpatch('NL','17309051','Dutch Labour Handicap Discount Calculation to use Full Time Salary');
						  dpatch('SG','17173295','R12.SG.35 - SINGAPORE HRMS CONSOLIDATED PATCH');
						  dpatch('ZA','16543654','ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013 TO R312 480');
						  dpatch('ZA', '16654857','SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');						
				  end if;
            end if;
			if upper(run_type)='ALL' then                
					dbms_output.put_line('<br><b>HRMS Family Packs history</b>:<br>');
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('13774477', 'R12.HR_PF.A.delta.10');
					dpatch('10281209', 'R12.HR_PF.A.delta.9');
					dpatch( '9301208', 'R12.HR_PF.A.delta.8');
					dpatch('7577660', 'R12.HR_PF.A.delta.7');
					dpatch('7004477', 'R12.HR_PF.A.delta.6');
					dpatch('6610000', 'R12.HR_PF.A.delta.5');
					dpatch('6494646', 'R12.HR_PF.A.delta.4');
					dpatch('6196269', 'R12.HR_PF.A.delta.3');
					dpatch('5997278', 'R12.HR_PF.A.delta.2');
					dpatch('5881943', 'R12.HR_PF.A.delta.1');
					dpatch('4719824', 'R12.HR_PF.A');					
					dbms_output.put_line(' <br>');				
            end if;			
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_rows from ad_bugs 
            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
            
            if v_rows=0 then
                    dbms_output.put_line('<div class="diverr">');
					dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> No RUP patch applied!<br><br>');
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17774746">Patch 17774746</a> HR_PF.K.RUP.9<br></div>');
					:e5:=:e5+1;
            else        
                    select max(to_number(bug_number)) into rup_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
                   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
                    if rup_level='17774746' then
                         
                          if upper(run_type)='ALL' then
                                  dbms_output.put_line('<b>Actual level:</b> Patch 17774746 HR_PF.K.RUP.9 applied on '||:v_rup_date||'<br><br>');
                          end if;
						  dbms_output.put_line('<font color="blue">Advice:</font> Ensure you applied patches to fix known issues (note periodically updated): ');
                          dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1636768.1" target="_blank"> Note 1636768.1</a> ');
                          dbms_output.put_line('Known Issues on Top of Patch 17774746 - 11i.hr_pf.k.delta.9 (HRMS 11i RUP9)<br><br>');
						  
						  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');							 
							  dpatch('GB','18305045','UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014');
							  if issue then
								:issuep:=1;
							  end if;
										
                    else
                          SELECT DECODE(BUG_NUMBER
                           , '2803988', 'HRMS_PF.E'
                           , '2968701', 'HRMS_PF.F'
                           , '3116666', 'HRMS_PF.G'
                           , '3233333', 'HRMS_PF.H'
                           , '3127777', 'HRMS_PF.I'
                           , '3333633', 'HRMS_PF.J'
                           , '3500000', 'HRMS_PF.K'
                           , '5055050', 'HR_PF.K.RUP.1'
                           , '5337777', 'HR_PF.K.RUP.2'
                           , '6699770', 'HR_PF.K.RUP.3'
                           , '7666111', 'HR_PF.K.RUP.4'
                           , '9062727', 'HR_PF.K.RUP.5'
                           , '10015566', 'HR_PF.K.RUP.6'
                           , '12807777', 'HR_PF.K.RUP.7'
                           , '14488556', 'HR_PF.K.RUP.8'
						   ,'17774746', 'HR_PF.K.RUP.9'
                            )  
                        , LAST_UPDATE_DATE  
                          into :rup_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =rup_level and rownum < 2;
                          
                          dbms_output.put_line('<b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '<br><br>');
                          dbms_output.put_line('<div class="divwarn">');
						  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install ');
						  dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17774746">Patch 17774746</a> HR_PF.K.RUP.9<br><br></div>');
						  :issuep:=1;
						  :w5:=:w5+1;
						  
						  if rup_level = '14488556' and (:hr_status='Installed') then
							  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
							  dpatch('AU','16319187','11I.AU.20 AUSTRALIA CUMULATIVE RELEASE');
							  dpatch('CA','18075555','End of Year 2013 Phase 3');		
							  dpatch('GB','17964873','UK TAX YEAR END CHANGES 2013 - 2014');							 						  							  
							  dpatch('US','18075555','End of Year 2013 Phase 3');				 	
							  
						end if;
						
						   if rup_level='12807777' and (:hr_status='Installed') then
								  dbms_output.put_line('<b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
								  dpatch('AU','16319187','11I.AU.20 AUSTRALIA CUMULATIVE RELEASE');								 
								  dpatch('DK','16002352','DANISH LEGISLATIVE CHANGES 2013 PART-3');								  
								  dpatch('HK','17539543','HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');
								  dpatch('IE','16811068','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');
								  dpatch('IN','17578798','INDIA CONSOLIDATED UPDATE IN.09 ');
								  dpatch('GB','13343360',' 	TYE12 : UK END OF YEAR CHANGES 2011-12');
								  dpatch('JP','17015482', 'JAPANESE HRMS CONSOLIDATED PATCH R115.JP.13');
								  dpatch('KR','16518233','KOREA CUMULATIVE RELEASE PATCH - 11i.KR.69');
								  dpatch('KW','16806105','TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');
								  						  				 
								  dpatch('NL','17309047','Dutch Labour Handicap Discount Calculation');	
								  dpatch('NZ','13627558', ' 11I - NZ STATUTORY UPDATES - 2012 ');								  
								  dpatch('SG','17188127','SINGAPORE CUMULATIVE RELEASE SG.35');
								  dpatch('ZA','16543639', 'ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013');
								  dpatch('ZA','16654854', 'SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');								  
						  end if;
						  
                    end if; 
					if upper(run_type)='ALL' then						
							dbms_output.put_line('<br><b>HRMS Family Packs history</b>:<br>');
							dpatch('2803988', 'HRMS_PF.E');
							dpatch('2968701', 'HRMS_PF.F');
							dpatch('3116666', 'HRMS_PF.G');
							dpatch('3233333', 'HRMS_PF.H');
							dpatch('3127777', 'HRMS_PF.I');
							dpatch('3333633', 'HRMS_PF.J');
							dpatch('3500000', 'HRMS_PF.K');
							dpatch('5055050', 'HR_PF.K.RUP.1');
							dpatch('5337777', 'HR_PF.K.RUP.2');
							dpatch('6699770', 'HR_PF.K.RUP.3');
							dpatch('7666111', 'HR_PF.K.RUP.4');
							dpatch('9062727', 'HR_PF.K.RUP.5');
							dpatch('10015566', 'HR_PF.K.RUP.6');
							dpatch('12807777', 'HR_PF.K.RUP.7');
							dpatch('14488556', 'HR_PF.K.RUP.8');
							dpatch('17774746', 'HR_PF.K.RUP.9');						
					end if;
            end if;   
      end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



-- Hrglobal version

declare
    v_exists number;
    v_hrglobal_date ad_patch_runs.end_date%type;
	v_action ad_patch_runs.end_date%type;
    v_hrglobal_patch_opt ad_patch_runs.PATCH_ACTION_OPTIONS%type;
    v_hrglobal_patch ad_applied_patches.patch_name%type;
	cursor get_patches (rupdate date) is
	select distinct PATCH_TYPE,PATCH_NAME,max(trunc(LAST_UPDATE_DATE)) ld from ad_applied_patches where last_update_date> rupdate group by PATCH_TYPE,PATCH_NAME order by max(trunc(LAST_UPDATE_DATE));
begin
      
         
      if   :apps_rel like '12%' then
            SELECT count(1) into v_exists
            FROM ad_patch_runs pr
            WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
              AND pr.SUCCESS_FLAG = 'Y'
              AND pr.end_date =(
               SELECT MAX(pr.end_date)
               FROM ad_patch_runs pr
               WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
                 AND pr.SUCCESS_FLAG = 'Y');
      else
            SELECT count(1) into v_exists
            FROM ad_patch_runs pr
            WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
              AND pr.SUCCESS_FLAG = 'Y'
              AND pr.end_date =(
               SELECT MAX(pr.end_date)
               FROM ad_patch_runs pr
               WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
                 AND pr.SUCCESS_FLAG = 'Y');
      end if;
      
      if (v_exists>0)  then
              if   :apps_rel like '12%' then
					  SELECT pr.end_date 
						   , pr.PATCH_ACTION_OPTIONS 
					  into v_hrglobal_date, v_hrglobal_patch_opt 
					  FROM ad_patch_runs pr
					  WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
						AND pr.SUCCESS_FLAG = 'Y'
						AND pr.end_date =(
						 SELECT MAX(pr.end_date)
						 FROM ad_patch_runs pr
						 WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
						   AND pr.SUCCESS_FLAG = 'Y');
			else
						SELECT pr.end_date 
						   , pr.PATCH_ACTION_OPTIONS 
					  into v_hrglobal_date, v_hrglobal_patch_opt 
						FROM ad_patch_runs pr
						WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
						  AND pr.SUCCESS_FLAG = 'Y'
						  AND pr.end_date =(
						   SELECT MAX(pr.end_date)
						   FROM ad_patch_runs pr
						   WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
							 AND pr.SUCCESS_FLAG = 'Y');
			end if;	 
				 
              select ap.patch_name  patchnumber into v_hrglobal_patch
                    from ad_applied_patches ap
                       , ad_patch_drivers pd
                       , ad_patch_runs pr
                       , ad_patch_run_bugs prb
                       , ad_patch_run_bug_actions prba
                       , ad_files f
                    where f.file_id                  = prba.file_id
                      and prba.executed_flag         = 'Y'
                      and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                      and prb.patch_run_id           = pr.patch_run_id
                      and pr.patch_driver_id         = pd.patch_driver_id
                      and pd.applied_patch_id        = ap.applied_patch_id
                      and f.filename = 'hrglobal.drv'
                      and pr.end_date = (select max(pr.end_date)
                                                 from ad_applied_patches ap
                                                    , ad_patch_drivers pd
                                                    , ad_patch_runs pr
                                                    , ad_patch_run_bugs prb
                                                    , ad_patch_run_bug_actions prba
                                                    , ad_files f
                                                  where f.file_id                  = prba.file_id
                                                    and prba.executed_flag         = 'Y'
                                                    and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                    and prb.patch_run_id           = pr.patch_run_id
                                                    and pr.patch_driver_id         = pd.patch_driver_id
                                                    and pd.applied_patch_id        = ap.applied_patch_id
                                                    and f.filename = 'hrglobal.drv');

                dbms_output.put_line('<br><br>Your date of last successful run of hrglobal.drv was with patch '||v_hrglobal_patch|| ' ' || v_hrglobal_patch_opt ||' on ' || v_hrglobal_date   ||'<br><br>' );
				
				if(:hr_status='Installed')  then
					if v_hrglobal_date<:v_rup_date then
						dbms_output.put_line('<div class="divwarn">');
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You did not performed hrglobal after last HRMS RUP applied!</div><br>');
						:issuep:=1;
						:w5:=:w5+1;
					else
						dbms_output.put_line('<img class="check_ico">OK! You performed hrglobal after HRMS RUP.<br><br>');
					end if;
					
					select  max( last_update_date) into v_action  from hr_legislation_installations  where (status is not null or action is not null) ;
					dbms_output.put_line('Last time performed DataInstal on ' || v_action   ||'<br><br>' );
					if v_hrglobal_date<v_action then
						dbms_output.put_line('<div class="divwarn">');
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You did not performed hrglobal after running DataInstall!</div><br><br>');
						:issuep:=1;
						:w5:=:w5+1;
					else
						dbms_output.put_line('<img class="check_ico">OK! You performed hrglobal after running DataInstall.<br><br>');
					end if;
				end if;
				
                dbms_output.put_line(' To identify the version please run: strings -a $PER_TOP/patch/115/driver/hrglobal.drv | grep Header <br><br>');
                dbms_output.put_line('<font color="blue">Advice:</font> Please periodically review (note periodically updated): ');
				if   :apps_rel like '12.2%' then
					dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1469456.1" target="_blank"> Note 1469456.1</a> ');
					dbms_output.put_line('DATAINSTALL AND HRGLOBAL APPLICATION: 12.2 SPECIFICS<br>'); 
				else
					dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=145837.1" target="_blank"> Note 145837.1</a> ');
					dbms_output.put_line('Latest Oracle HRMS Legislative Data Patch Available (HR Global / hrglobal)<br>'); 
				end if;
				
				dbms_output.put_line('<br><br>List of applied patches after latest HRMS RUP:<br>');
				for ex_rec in get_patches(:v_rup_date) loop
				dbms_output.put_line(ex_rec.PATCH_TYPE || '  '|| ex_rec.PATCH_NAME|| ' applied on '|| to_char(ex_rec.ld,'DD-MON-RR')||'<br>');
				end loop;
				dbms_output.put_line('<br>');
      end if;


EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- DataInstalled actions



declare
    v_exists number;
    v_leg_code varchar2(7);
    v_apps hr_legislation_installations.application_short_name%type;
    v_action hr_legislation_installations.action%type;
      cursor datainstaller_actions is
          select decode(hli.legislation_code
                   ,null,'global'
                   ,hli.legislation_code) 
           , hli.application_short_name                  
           , hli.action                                 
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name
      order by legislation_code desc, application_short_name asc;

begin      
      
      select count(1) into v_exists
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name;
      
      if v_exists>0 then
                                  dbms_output.put_line('<br><A class=detail onclick="displayItem(this,''s1sql36'');" href="javascript:;"><font size="+0.5">&#9654; DataInstaller Actions</font></A>');
                                  
                                  dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql36" style="display:none" >');
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('     <B>DataInstaller actions:</B></font></TD>');
                                  dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                                  dbms_output.put_line('<A class=detail id="s1sql37b" onclick="displayItem2(this,''s1sql37'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  dbms_output.put_line('   </TD>');
                                  dbms_output.put_line(' </TR>');
                                  dbms_output.put_line(' <TR id="s1sql37" style="display:none">');
                                  dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                                  dbms_output.put_line('       <blockquote><p align="left">');
                                  dbms_output.put_line('          select decode(hli.legislation_code <br>');   
                                  dbms_output.put_line('                   ,null,''global''<br>');
                                  dbms_output.put_line('                   ,hli.legislation_code) <br>');           
                                  dbms_output.put_line('           , hli.application_short_name <br>');   
                                  dbms_output.put_line('           , hli.action<br>');                  
                                  dbms_output.put_line('      from user_views uv<br>');
                                  dbms_output.put_line('         , hr_legislation_installations hli<br>');
                                  dbms_output.put_line('      where uv.view_name in (select view_name from hr_legislation_installations)<br>');
                                  dbms_output.put_line('      and uv.view_name = hli.view_name<br>');
                                  dbms_output.put_line('      order by legislation_code desc, application_short_name asc;<br>');
                                  dbms_output.put_line('          </blockquote><br>');
                                  dbms_output.put_line('     </TD>');
                                  dbms_output.put_line('   </TR>');
                                  dbms_output.put_line(' <TR>');
                                  dbms_output.put_line(' <TH><B>Legislation Code</B></TD>');
                                  dbms_output.put_line(' <TH><B>Application Name</B></TD>');
                                  dbms_output.put_line(' <TH><B>Action</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open datainstaller_actions;
                                  loop
                                        fetch datainstaller_actions into  v_leg_code,v_apps ,v_action;
                                        EXIT WHEN  datainstaller_actions%NOTFOUND;
                                        dbms_output.put_line('<TR><TD>'||v_leg_code||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD></TR>'||chr(10));
                                  end loop;
                                  close datainstaller_actions;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  dbms_output.put_line(' </TABLE>');
                                  
                                  dbms_output.put_line('<div class="diverr">');
								  dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> You have legislations currently selected for install by the DataInstall.');
                                  dbms_output.put_line(' Please resolve hrglobal issues ');
								  dbms_output.put_line('in order to install/upgrade all legislative data selected during DataInstaller.<br>');
                                  dbms_output.put_line('Please review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=140511.1" target="_blank" >Note 140511.1</a> ');
								  dbms_output.put_line('How to Install HRMS Legislative Data Using Data Installer and hrglobal.drv</div><br><br>');
								  :issuep:=1;
								  :e5:=:e5+1;
         end if;                                      
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


--  Statutory exceptions

      
declare
    cursor statutory is
    select table_name
           , surrogate_id 
           , true_key
           , exception_text
      from hr_stu_exceptions;
    v_table_name hr_stu_exceptions.table_name%type;
    v_surrogate_id hr_stu_exceptions.surrogate_id%type;
    v_true_key hr_stu_exceptions.true_key%type;
    v_exception_text hr_stu_exceptions.exception_text%type;
    v_exists number;
    
begin    
      select count(1) into v_exists
					  from hr_stu_exceptions;      
     
      if v_exists>0 then
                                  dbms_output.put_line('<A class=detail onclick="displayItem(this,''s1sql38'');" href="javascript:;"><font size="+0.5">&#9654; Statutory Exceptions</font></A>');
                                 
                                  dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql38" style="display:none" >');
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('     <B>Statutory exceptions:</B></font></TD>');
                                  dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                                  dbms_output.put_line('<A class=detail id="s1sql39b" onclick="displayItem2(this,''s1sql39'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  dbms_output.put_line('   </TD>');
                                  dbms_output.put_line(' </TR>');
                                  dbms_output.put_line(' <TR id="s1sql39" style="display:none">');
                                  dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                                  dbms_output.put_line('       <blockquote><p align="left">');
                                  dbms_output.put_line('          select table_name <br>');                                     
                                  dbms_output.put_line('           , to_char(surrogate_id) surrogate_id<br>'); 
                                  dbms_output.put_line('           , true_key<br>'); 
                                  dbms_output.put_line('           , exception_text<br>'); 
                                  dbms_output.put_line('            from hr_stu_exceptions;<br>'); 
                                  dbms_output.put_line('          </blockquote><br>');
                                  dbms_output.put_line('     </TD>');
                                  dbms_output.put_line('   </TR>');
                                  dbms_output.put_line(' <TR>');
                                  dbms_output.put_line(' <TH><B>Table name</B></TD>');
                                  dbms_output.put_line(' <TH><B>Surrogate ID</B></TD>');
                                  dbms_output.put_line(' <TH><B>True key</B></TD>');
                                  dbms_output.put_line(' <TH><B>Exception</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open statutory;
                                  loop
                                        fetch statutory into  v_table_name , v_surrogate_id , v_true_key , v_exception_text;
                                        EXIT WHEN  statutory%NOTFOUND;
                                        dbms_output.put_line('<TR><TD>'||v_table_name||'</TD>'||chr(10)||'<TD>'||v_surrogate_id||'</TD>'||chr(10)||'<TD>'||v_true_key||'</TD>'||chr(10)||'<TD>');
                                        dbms_output.put_line(v_exception_text);
                                        dbms_output.put_line('</TD></TR>'||chr(10));
                                  end loop;
                                  close statutory;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  dbms_output.put_line(' </TABLE> ');
                                  
                                   dbms_output.put_line('<div class="diverr">');
								  dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> You have statutory exceptions. ');
                                  dbms_output.put_line('In order to solve please review:<br>');
                                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=101351.1" target="_blank" >Note 101351.11</a> ');
								  dbms_output.put_line('HRGLOBAL.DRV:DIAGNOSING PROBLEMS WITH LEGISLATIVE UPDATES - HR_LEGISLATION.INSTALL</div>');
								  :issuep:=1;
                                  :e5:=:e5+1;
                                 
         end if;  

      
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



-- Mandatory Patches

declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_exists number:=0; 
  v_status varchar2(100);  
  issue boolean:=FALSE;
  -- Display patch
	procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	  v_exists number:=0;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;
						if (v_exists=0) then             
								 issue:=TRUE;
								 dbms_output.put_line('<div class="diverr">');
								 dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font> Please plan to install ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> ');
								 dbms_output.put_line(v_name||'<br></div>');
								:e5:=:e5+1;								 
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							dbms_output.put_line('Patch '||v_patch||' ' || v_name);
							dbms_output.put_line(' applied on '||v_patch_date||'<br>');
							
						end if;
	end; 
begin
dbms_output.put_line(' <br><br><a name="mandatory"></a><b>Mandatory Patches</b>');     
select count(1) 
     into v_exists
      from hr_legislation_installations
     where 
	 (substr(application_short_name,1,4)='PAY' 
	 or
	 ( substr(application_short_name,1,4)='PER' and Legislation_code = 'US'))
	 and status='I';
if v_exists>0  and :pay_status='Installed' then
	
	dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="1">');
	 
	 select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AU'  and status='I';     
     if v_exists>0 then
                
				dbms_output.put_line('<tr><td>AU Australia</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21238399', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21267565', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19764591', 'AU.22 AUSTRALIA CONSOLIDATED PATCH');	
				elsif :apps_rel like '11.5%' then					
					dpatch('14488556', 'HR_PF.K.RUP.8');
					dpatch('17314780','11I.AU.21 AUSTRALIA CUMULATIVE RELEASE');					
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'CN'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>CN China</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('13715802','R12.PER.B - TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');
					dpatch('16741703','R12.PER.B - Prevent Tax payable when under One Yuan (RMB)');									
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('13715802','R12.PER.A - TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');				
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('13717027','TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');
					dpatch('14625844','Prevent Tax Payable when under One YUAN (RMB)');					
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'DK'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>DK Denmark</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20218977', 'ABP PGGM Calculation Changes 2015');
					dpatch('20107803', 'Danish Legislative Changes 2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20218977', 'ABP PGGM Calculation Changes 2015');
					dpatch('20107803', 'Danish Legislative Changes 2015');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('16002352', 'Danish Legislative Changes 2013 Part-3');
					dpatch('15945507', 'Danish Legislative Changes 2013 Part 1, 2');
					dpatch('13500283', 'Danish Legislative Changes 2012');					
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
			select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'FI'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>FI Finland</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('12793751', 'Delivers the Finland legislative changes for 2011 Part-I');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('12793751', 'Delivers the Finland legislative changes for 2011 Part-I');				
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('10393363', 'Delivers the Finland legislative changes for 2011 Part-I');				
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'HK'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>HK Hong Kong</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20768287','TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20768287','TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('17385401','R12.PER.A - R12.HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013 1 JUN 2014');										
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('17539543','HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');				
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>IE Ireland</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20460989', 'Ireland Cumulative Legislative Patch 2015');
					dpatch('20210371', 'USC On Tax Information Screen');
					dpatch('20073662', 'Ireland Budget Changes Effective 01-JAN-2015');
					dpatch('19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20195113', 'Ireland Electronic P60 Changes');
					dpatch('20255656', 'Employer PAYE Reference Reporting Changes');
					dpatch('20235946', 'Employers PAYE Reference Increased To 9 Characters');
					dpatch('20210371', 'USC On Tax Information Screen');
					dpatch('19820820', 'Ireland EIR Code Address Changes For 2015');
					dpatch('20073662', 'Ireland Budget Changes Effective 01-JAN-2015');					
					dpatch('18510224','IE MEDICAL INSURANCE CHANGES 2014');
					dpatch('19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					dpatch('19060389', 'Ireland P35 Version 11 Reporting Changes');
					dpatch('19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20255656', 'Employer PAYE Reference Reporting Changes');
					dpatch('20235946', 'Employers PAYE Reference Increased To 9 Characters');
					dpatch('20210371', 'USC On Tax Information Screen');
					dpatch('19820820', 'Ireland EIR Code Address Changes For 2015');
					dpatch('20073662', 'Ireland Budget Changes Effective 01-JAN-2015');					
					dpatch('18510224','IE MEDICAL INSURANCE CHANGES 2014');
					dpatch('19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					dpatch('19060389', 'Ireland P35 Version 11 Reporting Changes');
					dpatch('19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('16811068', 'Ireland Local Property Tax And Report Changes');
					dpatch('16905146', 'Ireland Local Property Tax P30 Paper Report Changes');
					dpatch('16925013', 'LPT Deducting Over 5 Not 6 Months From July 2013');
					dpatch('16976741', 'IE P30 Paper Report Not Reporting Non Zero USC/LPT');
					dpatch('16999708', 'LPT Deducing From Statutory Redundancy');
					dpatch('17180755', 'IE SEPA FURTHER CHANGES: AIB FORMAT'); 
					dpatch('17542073', 'IE SEPA HSBC BANK CHANGES');
					dpatch('17573671', 'IE SEPA ULSTER BANK CHANGES');
					dpatch('17592973', 'Generating SEPA File For PayPath Payment Method, SEPA Danske Bank Format');
					dpatch('17731547', 'EAP NOVEMBER 2013 ISSUES: P35 XML REPORT CHANGES');
					dpatch('17775887', 'IRELAND SEPA CHANGES: HSBC FORMAT: FEEDBACK FROM HSBC');			
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IN'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>IN India</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('13914662','INDIA HRMS CONSOLIDATED UPDATE 11i.IN.08');	
					dpatch('13870875','Form 24Q E-TDS Regular Changes');
					dpatch('14351973','India Budget Changes for Section 80CCG and Section 80TTA');
					dpatch('16359871','Andhra Pradesh professional Tax changes Effective 06-FEB-2013');
					dpatch('16520998','India Budget Changes Gujarat Professional Tax Changes Effective 01-APR-2013');
					dpatch('16669518','Madhya Pradesh Professional Tax Changes Effective 01-APR-2013	');				
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'JP'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>JP Japan</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('17015507','R12.PER.B - JAPANESE HRMS CONSOLIDATED PATCH R121.JP.13');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('13330458','R12.PER.A - JAPANESE HRMS CONSOLIDATED PATCH R12.JP.12');	
					dpatch('13743712','R12.PER.A - H24 UNEMPLOYMENT INSURANCE RATE');					
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('17015482','JAPANESE HRMS CONSOLIDATED UPDATE R115.JP.13');					
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KR'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>KR Korea</td><td>');
                if (:apps_rel like '12.2%') then
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');						
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');				
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('16518233','KOREA CUMULATIVE RELEASE PATCH - 11i.KR.69');
					dpatch('17446056','KOREA 2013 YEA CHANGES: RENT EXEMPTION,MAXIMUM SPECIAL EXEMPTION LIMIT');
					dpatch('18107426','KOREA 2013 YEA CHANGES: SINGLE PARENT EXEMPTION');
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KW'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>KW Kuwait</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20331815', 'Change in employee social insurance contributions for Kuwait');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20331815', 'Change in employee social insurance contributions for Kuwait');									
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19009589', 'R12.PAY.A - KW Unemployment Insurance');
					dpatch('16787133', 'R12.PAY.A - Kuwait SI changes 2013');
					dpatch('15934773', 'R12.PAY.A - KUWAIT Report changes');					
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('16806105', 'Kuwait SI changes 2013');
					dpatch('15934061', 'KUWAIT Report changes');					
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'MX' and status='I';
     
     if v_exists>0 then
                dbms_output.put_line('<tr><td>MX Mexico</td><td>');
				if (:apps_rel like '12.2%') then					
					dpatch('17050005', 'HRMS RUP4');	
					dpatch('20259629','2014 EOY Phase 1');
					dpatch('20794928','Economic Zone B Minimum Wage');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');					
					dpatch('20259629','2014 EOY Phase 1');
					dpatch('20794928','Economic Zone B Minimum Wage');
				elsif (:apps_rel like '12.0%') then
					dpatch('16077077', 'R12.HR_PF.A.delta.11');					
					dpatch('20259629','2014 EOY Phase 1');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('15919087','NOV 2012 MINIMUM WAGE UPDATES');
					dpatch('14776810','2012 Year End Phase 1');
					dpatch('16034967','2013 Year Begin');
					dpatch('16023541','GETTING WRONG VALUES WITH SS QUOTA PRORATED WHEN SENIORITY CHANGES IN MID');
					dpatch('16090552','2012 Year End Phase 2');
					dpatch('16270938','NO ANNUAL TAX ADJUST, ISR IS STILL ZERO FOR THE ISR WITHHELD');
					dpatch('16607347','11I: MEXICO STATE TAX UPDATES 2013');
					dpatch('17500878','11I:MX SEP13: QUINTANA ROO STATE TAX RATE UPDATE');
				end if;				
				dbms_output.put_line('</td></tr>');
				
	end if;  
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NL'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>NL Netherlands</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');	
					dpatch('20279973', 'ABP PGGM Calculation Changes 2015');
					dpatch('20972577', 'Legislative Changes - Legal Minimum Wages effective from 01-Jul-2015');
				elsif (:apps_rel like '12.1%') then						
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20279973', 'ABP PGGM Calculation Changes 2015');
					dpatch('20972577', 'Legislative Changes - Legal Minimum Wages effective from 01-Jul-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20279973', 'ABP PGGM Calculation Changes 2015');			
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('17558120', 'Delivers changes to Dutch Annual Tax Statement for the Employee Report effective 2013');				
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NO'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>NO Norway</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21327657', 'NO: Half tax calculation');	
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21327657', 'NO: Half tax calculation');						
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('14177955', 'Delivers the K27 reimbursement file upload');			
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('14171993', 'Delivers the K27 reimbursement file upload');				
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NZ'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>NZ New Zealand</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20699005', 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20699005', 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('11867792','R12.PER.A - NEW ZEALAND CUMULATIVE RELEASE R12.NZ.08');	
					dpatch('13697009','R12.PER.A - NZ STATUTORY UPDATES 2012');					
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('11867781','NEW ZEALAND CUMULATIVE RELEASE 11i.NZ.08');
					dpatch('13627558','NZ STATUTORY UPDATES 2012');					
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SA'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>SA Saudi Arabia</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('18723486', 'SA Unemployment insurance changes');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('18723486', 'SA Unemployment insurance changes');
					dpatch('19054295', 'Can not create absence');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('18760981', 'SA Unemployment insurance changes');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');				
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SE'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>SE Sweden</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');										
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('12589129', 'Delivers the Sweden legislative changes for 2011');				
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('10393370', 'Delivers the Sweden legislative changes for 2011');
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SG'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>SG Singapore</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');	
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20055967','IRAS and IR21 CHANGES EOY 2014');										
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('17188127','SG.35 SINGAPORE CONSOLIDATED PATCH');				
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AE'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>AE United Arab Emirates</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('19900524','UAE National identifier validation changes');
					dpatch('20075576','UAE National identifier validation changes and Formula Result rule for KW SI');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('19900524','UAE National identifier validation changes');
					dpatch('19819953','ROUTING NUMBER IN UAE LEGISLATION');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19900524','UAE National identifier validation changes');
					dpatch('19819953','ROUTING NUMBER IN UAE LEGISLATION');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');					
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'GB'  and status='I';
     
     if v_exists>0 then
                v_exists:=0;
				dbms_output.put_line('<tr><td>UK GB United Kingdom</td><td>');
				dbms_output.put_line('<font color="blue">Advice:</font> Periodically review:<br><a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1324671.1" target="_blank">Note 1324671.1</a> ');
				dbms_output.put_line('EBS UK Payroll : Real Time Information (RTI) White Paper and Patch Information<br><br>');				
				if (:apps_rel like '12.2%') then
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20513833','RTI GB UPDATE NI CATEGORY ERRORS');
					dpatch('20066028','PENSERVER LEGISLATIVE CHANGES');
					dpatch('20314902','YEAR END 2014-15 / START OF YEAR 2015-16');
					dpatch('20201659','UK YEAR END 2014-15 / START OF YEAR 2015-16');	
					dpatch('19223877','P11D LEGISLATIVE CHANGES for 2014-15');
					dpatch('20591016','SHARED PARENTAL LEAVE AND PAY CHANGES');
					dpatch('20692428','TAX YEAR END BUG FIXES');
					dpatch('20888184','TAX YEAR END BUG FIXES');
					dpatch('21033080','PENSIONS AUTOMATIC ENROLMENT/RE-ENROLMENT LEGISLATIVE CHANGES');
				elsif (:apps_rel like '12.0%') then
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('18776254','RTI CONSOLIDATED PATCH: SEPTEMBER 2014');
					dpatch('18972503','RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES');
					dpatch('18693666','DIRECT EARNINGS ATTACHMENT CHANGES: PHASE2');		
					dpatch('18453569','LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme');
					dpatch('18333366','DIRECT EARNINGS ATTACHMENT CHANGES');
					dpatch('18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
					dpatch('18285764', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/LGPS CHANGES');					
					dpatch('18100149','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014');
					dpatch('17274247','RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH');
				elsif :apps_rel like '11.5%' then
					dpatch('17774746', 'HR_PF.K.RUP.9');
					dbms_output.put_line('<div class="divok">');
					dbms_output.put_line('Note: These patches are only available with ACS Service, please refer ');
					dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1597416.1" target="_blank">Note 1597416.1</a> Payroll Legislative Updates for Oracle E-Business Suite 11.5.10:<br>');
					dbms_output.put_line('</div>');
					dpatch('18776031','RTI CONSOLIDATED PATCH: SEPTEMBER 2014');
					dpatch('18972450','RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES');
					dpatch('18449320','LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme');
					dpatch('18333164','DIRECT EARNINGS ATTACHMENT CHANGES');
					dpatch('18305045','UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014');
					dpatch('18293579','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /P11D/LGPS CHANGES');
					dpatch('18285780','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /LGPS CHANGES');
					dpatch('18100105','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014');					
					dpatch('18032762','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014:PHASE2 PATCH');					
					dpatch('17964873','UK TAX YEAR END CHANGES 2013 - 2014');
					dpatch('17274234','RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH');	
				end if;
				
				dbms_output.put_line('</td></tr>');
	end if;  
	
     select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  (Legislation_code = 'US' ) and status='I';
     
     if v_exists>0 then
				dbms_output.put_line('<tr><td>US United States</td><td>');
                 if (:apps_rel like '12.2%') then		
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21142484','Q2 2015 Statutory and JIT Update');
				elsif (:apps_rel like '12.1%') then		
					dpatch('21142484','Q2 2015 Statutory and JIT Update');
				elsif (:apps_rel like '12.0%') then
					dpatch('19507770','Q3 2014 Statutory and JIT Update');
				elsif :apps_rel like '11.5%' then					
					dpatch('21142464','Q2 2015 Statutory and JIT Update');
				end if;	                           
				dbms_output.put_line('</td></tr>');
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  (Legislation_code = 'US' or Legislation_code = 'CA') and status='I';
     
     if v_exists>0 then	
                dbms_output.put_line('<tr><td>US CA United States and Canada</td><td>');
				if (:apps_rel like '12.2%') then							
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.1%') then							
					dpatch('20000288', 'R12.HR_PF.B.delta.8');	
					dpatch('20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');					
					dpatch('19701971','End of Year 2014 Phase 1');
					dpatch('20212223','End of Year 2014 Phase 2');
					dpatch('20365000','End of Year 2014 Phase 3');
				elsif :apps_rel like '11.5%' then				
					dpatch('17774746', 'HR_PF.K.RUP.9');			
					dpatch('20364999','End of Year 2014 Phase 3');
					dpatch('20301513','Year Begin 2015 Statutory Update 2');
					dpatch('20212121','Year Begin 2015 Statutory Update');
				end if;	
				dbms_output.put_line('</td></tr>');
	end if;
     	 
	
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PER'
     and  Legislation_code = 'US'  and status='I';
     
     if v_exists>0 then
                
				dbms_output.put_line('<tr><td>US United States HR</td><td>');
                if (:apps_rel like '12.2%') then
					dpatch('18844524','US HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 12.2.3 or Higher');
					dpatch('20979690','US HR 2015 ANNUAL STATUTORY PATCH FOR RELEASE 12.2');
				elsif (:apps_rel like '12.1%') then					
					dpatch('18844524','US HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 12.1 HRMS RUP6');
					dpatch('20979690','US HR 2015 ANNUAL STATUTORY PATCH FOR RELEASE 12.1 HRMS RUP6 or later');
				elsif (:apps_rel like '12.0%') then					
					dpatch('18844524','US HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 12.0');	
				elsif :apps_rel like '11.5%' then					
					dpatch('18844514','UUS HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 11I');
					dpatch('20979676','US HR 2015 ANNUAL STATUTORY PATCH');
				end if;		
				dbms_output.put_line('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'ZA'  and status='I';     
     if v_exists>0 then                
				dbms_output.put_line('<tr><td>ZA South Africa</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');					
					dpatch('21499164', 'INTEREST RATE GLOBAL VALUE CHANGE EEFECTIVE FROM 01-AUG-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21499164', 'INTEREST RATE GLOBAL VALUE CHANGE EEFECTIVE FROM 01-AUG-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');	
					dpatch('19544341', 'ZA: AUGTYE14 REPORTING CHANGES');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');	
					dpatch('17366859', 'ZA : Tax Audit report');					
				end if;			
				dbms_output.put_line('</td></tr>');				
	end if;
	
	dbms_output.put_line('</table>');
    
	
 	if :apps_rel like '11.5%' then
		:issuep:=1;
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please note that statutory legislative support expired on November 30th 2013');
		dbms_output.put_line(', please refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1384995.1" target="_blank">Note 1384995.1</a> ');
		dbms_output.put_line(' When Is Statutory Legislative Support for Payroll Going To End For Release 11i<br></div>');
	end if;
                 
 end if;      
 if :apps_rel like '11.5%'  then
		if upper(product) in ('ALL','BEN') then
				dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Benefits: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=124100.1" target="_blank">Note 124100.1</a> ');
				dbms_output.put_line('Benefits Compensation and Benefits Patch List</div>');		
			end if;		
			if upper(product) in ('ALL','IRC') then
				dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> iRecruitment: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=199221.1" target="_blank">Note 199221.1</a> ');
				dbms_output.put_line('Oracle 11i HRMS iRecruitment (iRec) Recommended and Mandatory Patches</div>');
			end if;
			if upper(product) in ('ALL','OTL') then
				dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Time and Labor: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=214886.1" target="_blank">Note 214886.1</a> ');
				dbms_output.put_line('Oracle 11i Time and Labor (OTL) Mandatory Patch List</div>');
			end if;
			if upper(product) in ('ALL','SSHR') then
				dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Self Service Human Resources: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=108897.1" target="_blank">Note 108897.1</a> ');
				dbms_output.put_line('Recommended Patch List for Self-Service Human Resources (SSHR) in HRMS 11i </div>');
			end if;
	elsif (upper(product) in ('ALL','HR')) and ((:apps_rel like '11.5%') or (:apps_rel like '12.0%')) then
			dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Human Resources: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=108547.1" target="_blank">Note 108547.1</a> ');
			dbms_output.put_line('Oracle Human Resources Recommended Patches</div>');	
	end if;	
	dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> In order to identify recommended patches use My Oracle Support - Recommended Patches</div>');         
	
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Baseline patches
declare
  v_status varchar2(5);
  no_rows number;
  v_exists number;
  issue boolean:=FALSE;
  -- Display patch
	procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	  v_exists number:=0;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch;
					end if;
						if (v_exists=0) then             
								 issue:=TRUE;
								 dbms_output.put_line('<div class="divwarn">');
								 dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> ');
								 dbms_output.put_line(v_name||'<br></div>');
								:w5:=:w5+1;
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch and rownum < 2;
							dbms_output.put_line('Patch '||v_patch||' ' || v_name);
							dbms_output.put_line(' applied on '||v_patch_date||'<br>');
							
						end if;
	end;

begin
    
    if :apps_rel like '11.5%' or :apps_rel like '12.0%' then
		dbms_output.put_line(' <br><br><b>Baseline patches</b><br>');
		if :apps_rel like '11.5%' then
          dpatch('5903765','11i.ATG_PF.H.delta.6');
          select count(1) into no_rows from fnd_product_installations where application_id=203;
		  if no_rows=1 then
				  select status into v_status from fnd_product_installations where application_id=203;
				  if v_status='I' then						
						dpatch('4428060',' - baseline patch for AME');
				  end if;
          end if;
		  select status into v_status from fnd_product_installations where application_id=453;
          if v_status='I' then                
				dpatch('4001448',' - baseline patch for HRI');
          end if; 
		  dpatch('6699770',' - baseline patch for PER, BEN, PSP, IRC, Self Service');          
          select status into v_status from fnd_product_installations where application_id=810;
          if v_status='I' then
                dpatch('7446888',' - baseline patch for OTA');				
          end if; 
          select count(1) into no_rows from fnd_product_installations where status='I' and application_id in (801, 8301) ;
          if no_rows>0 then
                dpatch('7666111',' - baseline patch for PAY, GHR');				
          end if; 
          select status into v_status from fnd_product_installations where application_id=808;
          if v_status='I' then
                dpatch('7226660','  - baseline patch for HXT');				
          end if; 
          if issue then
			  dbms_output.put_line('<div class="divwarn">');
			  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font>You have baseline patches missing.</div><br>');
		  else
			  dbms_output.put_line('HCM Product Level Requirements applied.<br>');
		  end if;
			  dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Please review ');
              dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1199724.1" target="_blank">Note 1199724.1</a>');
			  dbms_output.put_line(' E-Business Suite 11.5.10 Minimum Patch Level and Extended Support Information Center</div>');
          
		elsif :apps_rel like '12.0%' then
			  dpatch('7004477','R12.HR_PF.A.delta.6 (Minimum baseline)');
			  dpatch('9301208','R12.HR_PF.A.delta.8 (Minimum baseline for those customers whose legislation tax year end/tax year begin schedule must be applied as a prerequisite before processing the legislative Year End)');
			  if issue then
				 dbms_output.put_line('<div class="divwarn">');
				 dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font>You have baseline patches missing.</div><br>');
			  else
				  dbms_output.put_line('HCM Product Level Requirements applied.<br>');
			  end if;
			  dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Please review ');
              dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1334562.1" target="_blank">Note 1334562.1</a> ');
			  dbms_output.put_line('- Minimum Patch Requirements for Extended Support of Oracle E-Business Suite Human Capital Management (HCM) Release 12.0</div>');
		end if;
		
		if issue then
              :issuep:=1;
		end if;
	end if; 
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

-- Projects patching level


declare
    run_type varchar2(20):='&1';
	product varchar2(20):='&2';
    pj_level varchar2(20);
    pj_level_n varchar2(50);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_exists number;
begin

   if upper(product) in ('OTL','ALL') then   
        
      if :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into pj_level from ad_bugs 
            WHERE BUG_NUMBER IN ('7456340','8504800','9147711','12378114','14162290','17839156');            
            
			
            if pj_level='17839156' then
                  
                  if upper(run_type)='ALL' then
                          dbms_output.put_line(' <br><br><a name="projects"></a><b>Projects</b><br>');
						  dbms_output.put_line('<b>Actual level:</b> Patch 17839156 (R12.PJ_PF.B.DELTA.6) Projects Upd Pack 6 for 12.1<br><br>');					  
                  end if;
                  
                  
            else
                  SELECT DECODE(BUG_NUMBER,
                 '7456340', '(R12.PJ_PF.B.DELTA.1) Projects Upd Pack 1 for 12.1',
				'8504800', '(R12.PJ_PF.B.DELTA.2) Projects Upd Pack 2 for 12.1',
				'9147711', '(R12.PJ_PF.B.DELTA.3) Projects Upd Pack 3 for 12.1',
			   '12378114', '(R12.PJ_PF.B.DELTA.4) Projects Upd Pack 4 for 12.1',
			   '14162290', '(R12.PJ_PF.B.DELTA.5) Projects Upd Pack 5 for 12.1')
                , LAST_UPDATE_DATE   
                  into pj_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =pj_level and rownum < 2;
                  dbms_output.put_line(' <br><br><a name="projects"></a><b>Projects</b><br>');
                  dbms_output.put_line('<b>Actual level:</b> Patch ' || pj_level || ' ' || pj_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<font color="blue">Advice:</font> Latest PJ level is: <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17839156">Patch 17839156</a> R12.PJ_PF.B.DELTA.6<br>');
				  				 
            end if; 
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into pj_level from ad_bugs 
            WHERE BUG_NUMBER IN ('6022657','6266113','6512963','7292354');
            
            if pj_level='7292354' then
                  
                  if upper(run_type)='ALL' then
                          dbms_output.put_line(' <br><br><a name="projects"></a><b>Projects</b><br>');
						  dbms_output.put_line('<b>Actual level:</b> Patch 7292354 R12.PJ_PF.A.DELTA.6<br>');
                
                  end if;
            else
                  SELECT DECODE(BUG_NUMBER,
                 '6022657', '(R12.PJ_PF.A.DELTA.2) Projects Update Pack 2',
				'6266113', '(R12.PJ_PF.A.DELTA.3) Projects Update Pack 3',
				'6512963', '(R12.PJ_PF.A.DELTA.4) Projects Update Pack 4',
				'7292354', '(R12.PJ_PF.A.DELTA.6) Projects Update Pack 6')
                  , LAST_UPDATE_DATE  
                  into pj_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =pj_level and rownum < 2;
                  dbms_output.put_line(' <br><br><a name="projects"></a><b>Projects</b><br>');
                  dbms_output.put_line('<b>Actual level:</b> Patch ' || pj_level || ' ' || pj_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<font color="blue">Advice:</font> Latest PJ level is:  <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=7292354">Patch 7292354</a> R12.PJ_PF.A.DELTA.6<br>');
				 				 
            end if;   
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
            
            if v_exists=0 then
                    dbms_output.put_line(' <br><br><a name="projects"></a><b>Projects</b><br>');
					dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> No PJ patch applied!<br><br>');
                    dbms_output.put_line('<font color="blue">Advice:</font> Latest PJ level is: <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=5644830">Patch 5644830</a> (11i.PJ_PF.M) Rollup 4<br>');
					
            else        
                    select max(to_number(bug_number)) into pj_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('2342093','2484626','3074777','3397153','4027334','4285356','4667949','3485155','4461989','4997599','5105878','5644830');
                    if pj_level='5644830' then
                          
                          if upper(run_type)='ALL' then
                                  dbms_output.put_line(' <br><br><a name="projects"></a><b>Projects</b><br>');
								  dbms_output.put_line('<b>Actual level:</b> Patch 5644830 (11i.PJ_PF.M) Rollup 4<br><br>');
								  
                          end if;
                                         
                          
                    else
                          SELECT DECODE(BUG_NUMBER,
                         '2342093', 'PJ_PF:CONSOLIDATED 11.5.7 UPGRADE FIXES FOR PROJECT ACCOUNTING PRODUCT FAMILY',
						'2484626',  'FAMILY PACK 11i.PJ_PF.K',    
						'3074777',  'FAMILY PACK 11i.PJ_PF.L',        
						'3397153', '(11i.PJ_PF.L10) Projects Family Pack L10',
						'4027334', '(11.5.10) Projects Consolidated Patch for CU1',
						'4285356', '(11.5.10) Projects Consolidated Patch for CU2',
						'4667949', '(11i.PJ_PF.L10) Rollup 1',
						'3485155', '(11i.PJ_PF.M) Projects Family Pack M',
						'4461989', '(11i.PJ_PF.M) Rollup',
						'4997599', '(11i.PJ_PF.M) Rollup 2',
						'5105878', '(11i.PJ_PF.M) Rollup 3',
						'5644830', '(11i.PJ_PF.M) Rollup 4')
                        , LAST_UPDATE_DATE  
                          into pj_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =pj_level and rownum < 2;
                          dbms_output.put_line(' <br><br><a name="projects"></a><b>Projects</b><br>');
                          dbms_output.put_line('<b>Actual level:</b> Patch ' || pj_level || ' ' || pj_level_n || ' applied on ' || v_date || '<br><br>');
                          dbms_output.put_line('<font color="blue">Advice:</font> Latest PJ level is: <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=5644830">Patch 5644830</a> (11i.PJ_PF.M) Rollup 4<br>');
						  						  
       
                    end if;                   
            end if;   
      end if;
      
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



-- ATG patching level


declare
    run_type varchar2(20):='&1';
    atg_level varchar2(20);
    atg_level_n varchar2(50);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_exists number;
begin

      
      dbms_output.put_line(' <br><br><a name="atg"></a><b>ATG</b><br>');
      
      if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into atg_level FROM ad_bugs adb
			WHERE adb.bug_number in ('10110982','14222219','15890638','17007206','17909318')
			;
			if atg_level='17909318' then                  
                  dbms_output.put_line('<b>Actual level:</b> Patch 17909318 R12.ATG_PF.C.delta.4<br><br>');  
            else
				SELECT DECODE(BUG_NUMBER
				 , '10110982', 'R12.ATG_PF.C'
				 , '14222219', 'R12.ATG_PF.C.delta.1'
				 , '15890638', 'R12.ATG_PF.C.delta.2'
				 , '17007206', 'R12.ATG_PF.C.delta.3','17909318', 'R12.ATG_PF.C.delta.4')
					, LAST_UPDATE_DATE   
					  into atg_level_n, v_date
					  FROM ad_bugs 
					  WHERE BUG_NUMBER =atg_level and rownum < 2;
				 dbms_output.put_line('<b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<div class="divwarn">');
				  dbms_output.put_line('<font color="#CC3311">Warning: </font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17909318">Patch 17909318</a> ');
				  dbms_output.put_line('R12.ATG_PF.C.delta.4<br></div>');
				  :issuep:=1;
				  :w5:=:w5+1;
			end if;
                 
	  elsif  :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into atg_level from ad_bugs 
            WHERE BUG_NUMBER IN ('6430106','7307198','7651091','8919491');            
                 
            if atg_level='8919491' then
                  
                  if upper(run_type)='ALL' then
                          dbms_output.put_line('<b>Actual level:</b> Patch 8919491 R12.ATG_PF.B.delta.3<br><br>');
                  end if;
                  dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Ensure you applied patches to fix known issues (note periodically updated): ');
                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1273640.1" target="_blank"> Note 1273640.1</a> ');
                  dbms_output.put_line('Known ATG issues on Top of 12.1.3 - r12.atg_pf.b.delta.3, Patch 8919491</div>');
                  
            else
                  SELECT DECODE(BUG_NUMBER
                 , '6430106', 'R12.ATG_PF.B'
                 , '7307198', 'R12.ATG_PF.B.delta.1'
                 , '7651091', 'R12.ATG_PF.B.delta.2'
                 , '8919491', 'R12.ATG_PF.B.delta.3')
                , LAST_UPDATE_DATE   
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
                  
                  dbms_output.put_line('<b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '<br><br>');
				  dbms_output.put_line('<div class="divwarn">');
                  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=8919491">Patch 8919491</a> R12.ATG_PF.B.delta.3</div><br>');
				  :issuep:=1;
				  :w5:=:w5+1;
            end if; 
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into atg_level from ad_bugs 
            WHERE BUG_NUMBER IN ('4461237','5907545','5917344','6077669','6272680','6594849','7237006');
            
            if atg_level='7237006' then
                  
                  if upper(run_type)='ALL' then
                          dbms_output.put_line('<b>Actual level:</b> Patch 7237006 R12.ATG_PF.A.delta.6<br>');
                  else
                          dbms_output.put_line('<img class="check_ico">OK! You are at latest level available: Patch 7237006 R12.ATG_PF.A.delta.6.<br>');
                  end if;
            else
                  SELECT DECODE(BUG_NUMBER
                 , '4461237', 'R12.ATG_PF.A'
                 , '5907545', 'R12.ATG_PF.A.delta.1'
                 , '5917344', 'R12.ATG_PF.A.delta.2'
                 , '6077669', 'R12.ATG_PF.A.delta.3'
                 , '6272680', 'R12.ATG_PF.A.delta.4'
                 , '6594849', 'R12.ATG_PF.A.delta.5'
                 , '7237006', 'R12.ATG_PF.A.delta.6')
                  , LAST_UPDATE_DATE  
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
                  
                  dbms_output.put_line('<b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '<br><br>');
				  dbms_output.put_line('<div class="divwarn">');
                  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=7237006">Patch 7237006</a> R12.ATG_PF.A.delta.6</div><br>');
				  :issuep:=1;
				  :w5:=:w5+1;
            end if;   
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
            
            if v_exists=0 then
                    dbms_output.put_line('<div class="diverr">');
					dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> No ATG RUP patch applied!<br><br>');
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=6241631">Patch 6241631</a> 11i.ATG_PF.H RUP7</div><br>');
					:e5:=:e5+1;
            else        
                    select max(to_number(bug_number)) into atg_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
                    if atg_level='6241631' then
                          
                          if upper(run_type)='ALL' then
                                  dbms_output.put_line('<b>Actual level:</b> Patch 6241631 11i.ATG_PF.H RUP7<br><br>');
                          end if;
                          dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> Ensure you applied patches to fix known issues (note periodically updated): ');
                          dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=858801.1" target="_blank"> Note 858801.1</a> ');
                          dbms_output.put_line('Known Issues On Top of 11i.atg_pf.h.delta.7 (RUP7) - 6241631</div>');                    
                          
                    else
                          SELECT DECODE(BUG_NUMBER
                         , '3438354', '11i.ATG_PF.H'
                         , '4017300', '11i.ATG_PF.H RUP1'
                         , '4125550', '11i.ATG_PF.H RUP2'
                         , '4334965', '11i.ATG_PF.H RUP3'
                         , '4676589', '11i.ATG_PF.H RUP4'
                         , '5473858', '11i.ATG_PF.H RUP5'
                         , '5903765', '11i.ATG_PF.H RUP6'
                         , '6241631', '11i.ATG_PF.H RUP7')
                        , LAST_UPDATE_DATE  
                          into atg_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =atg_level and rownum < 2;
                          
                          dbms_output.put_line('<b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '<br><br>');
						  dbms_output.put_line('<div class="divwarn">');
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=6241631">Patch 6241631</a> 11i.ATG_PF.H RUP7</div><br>');
						  :issuep:=1;
						  :w5:=:w5+1;
       
                    end if;                   
            end if;   
      end if;
     
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Geocode patching level

declare
  run_type varchar2(20):='&1';
  v_exists number:=0;
  v_patch_date ad_bugs.LAST_UPDATE_DATE%type;
  v_status varchar2(100);
  v_last_date date;
  v_geocode_date date;
  patch varchar2(20);
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin
    
     select count(1) 
     into v_exists
      from hr_legislation_installations
     where (Legislation_code = 'US' or Legislation_code = 'CA') and status='I';
     
     if v_exists>0 then
                v_exists:=0;
                if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
                      SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='21276246' ;
                      patch:='21276246';
                elsif :apps_rel like '12.0%' then
					select count(1) into v_exists from ad_bugs where bug_number='19139617';
                      patch:='19139617';
				elsif :apps_rel like '11.5%' then
                      select count(1) into v_exists from ad_bugs where bug_number='21276241';
                      patch:='21276241';
                end if;
                
                if (v_exists=0) then             
                         issue1:=TRUE;
                else
                          select LAST_UPDATE_DATE  
                          into v_patch_date
                          FROM ad_bugs 
                          where bug_number=patch and rownum < 2;
                          
                          select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%';
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),upper('Completed Normal'))=0 then 
                                      issue3:=TRUE;
                                  else
                                         if v_last_date<v_patch_date then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
							
							SELECT count(1) into v_exists
							FROM pay_patch_status
							WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
							AND status        = 'C';
							
							if v_exists=0 then
								issue5:=TRUE;
							else
								SELECT max(applied_date) into v_geocode_date
								FROM pay_patch_status
								WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
								AND status        = 'C';
							end if;
              end if;
              
               
              
              if upper(run_type)='ALL' or issue1 or issue2 or issue3 or issue4 or issue5 then 
                        dbms_output.put_line(' <br><br><a name="geocode"></a><b>Geocode</b><br>');
                        
                        if issue1 then
                                :w5:=:w5+1;
								if (:pay_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										elsif :apps_rel like '12.0%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ANNUAL GEOCODE UPDATE - 2014<br>');
										elsif :apps_rel like '11.5%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										end if;	
										dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Ensure you perform Geocode Upgrade Manager process after the patch.</div><br>');
								elsif (:pay_status='Shared') and (:hr_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ');
											dbms_output.put_line('ANNUAL GEOCODE UPDATE - 2014</div><br>');
										elsif :apps_rel like '12.0%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ');
											dbms_output.put_line('ANNUAL GEOCODE UPDATE - 2014</div><br>');
										elsif :apps_rel like '11.5%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ');
											dbms_output.put_line('ANNUAL GEOCODE UPDATE - 2014</div><br>');
										end if;
										dbms_output.put_line('<div class="divwarn">');
										dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records ensure you perform Geocode Upgrade Manager process after the patch.<br>');
										dbms_output.put_line('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=745638.1" target="_blank">Note 745638.1</a> ');
										dbms_output.put_line('Requirements for Address Validation with HR Only Installation</div><br>');
								end if;									
                        else
								dbms_output.put_line('Patch '||patch||' Oracle US and Canada Payroll - Annual Geocode applied on '||v_patch_date||'<br>');
                        end if;
                        
                        if issue2 then
                            :w5:=:w5+1;
							if (:pay_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>You never performed Geocode Upgrade Manager process!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware you never performed Geocode Upgrade Manager process!</div><br>');
							end if;
                        end if;
                        
                        if issue3 then                            
							:w5:=:w5+1;
							if (:pay_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Your last run of Geocode Upgrade Manager process completed in error. Please review!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware your last run of Geocode Upgrade Manager process completed in error. Please review!</div><br>');
							end if;
                        end if;
                        if issue4 then                            
							:w5:=:w5+1;
							if (:pay_status='Installed') then
								dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>You did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware you did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							end if;
                        end if;
						
						if (:apps_rel not like '12.0%') then
						if issue5  then
                            :w5:=:w5+1;
							if (:pay_status='Installed')  then								
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>GEOCODE_ANNUAL_2015 information not applied!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed')   then								
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware GEOCODE_ANNUAL_2015 information are not applied!</div><br>');
							end if;
                        elsif not issue1 then
							dbms_output.put_line('GEOCODE_ANNUAL_2015 information applied on '||v_geocode_date||'<br>');
                        end if;
						end if;
                        
						if not issue1 and not issue2 and not issue3 and not issue4 then
							dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
						end if;
						
                        if issue1 or issue2 or issue3 or issue4 or (issue5 and :apps_rel not like '12.0%') then
                                :issuep:=1;
								if :apps_rel like '12.2%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=2038283.1" target="_blank">Note 2038283.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.2.x');
								elsif :apps_rel like '12.1%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=2038282.1" target="_blank">Note 2038282.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.1.x');
                                elsif :apps_rel like '12.0%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1912683.1" target="_blank">Note 1912683.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2014 Annual Geocode Readme - Release 12.0.x');
                                else
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=2038281.1" target="_blank">Note 2038281.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 11i');
                                end if;
                          
                        else
                                if upper(run_type)='ALL' then
                                        dbms_output.put_line('<img class="check_ico">OK! All checks are <img class="check_ico">OK!<br>');									
											
                                end if;
                        end if;
                        
               end if;         
       end if; 
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Quantum patching level

declare
  run_type varchar2(20):='&1';
  v_exists number:=0;
  v_status varchar2(100);
  v_last_date date;
  patch varchar2(20);
  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type;	
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin
if (:pay_status='Installed') then    
     select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  (Legislation_code = 'US' or Legislation_code = 'CA') and status='I';
     
     if v_exists>0 then
                select count(1) into v_exists
                from ad_applied_patches ap
                   , ad_patch_drivers pd
                   , ad_patch_runs pr
                   , ad_patch_run_bugs prb
                   , ad_patch_run_bug_actions prba
                   , ad_files f
                where f.file_id                  = prba.file_id
                  and prba.executed_flag         = 'Y'
                  and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                  and prb.patch_run_id           = pr.patch_run_id
                  and pr.patch_driver_id         = pd.patch_driver_id
                  and pd.applied_patch_id        = ap.applied_patch_id
                  and f.filename = 'pyvendor.zip'
                  and pr.end_date = (select max(pr.end_date)
                                             from ad_applied_patches ap
                                                , ad_patch_drivers pd
                                                , ad_patch_runs pr
                                                , ad_patch_run_bugs prb
                                                , ad_patch_run_bug_actions prba
                                                , ad_files f
                                              where f.file_id                  = prba.file_id
                                                and prba.executed_flag         = 'Y'
                                                and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                and prb.patch_run_id           = pr.patch_run_id
                                                and pr.patch_driver_id         = pd.patch_driver_id
                                                and pd.applied_patch_id        = ap.applied_patch_id
                                                and f.filename = 'pyvendor.zip');      

                
                 if (v_exists=0) then             
                         issue1:=TRUE;
                else
                           if :apps_rel like '12.%' then
								SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='19701971' ;
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701971' and rownum < 2;
								end if;						  
						   elsif :apps_rel like '11.5%'	then
								select count(1) into v_exists from ad_bugs where bug_number='19701970';
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701970' and rownum < 2;
								end if;
						   end if;						
						   select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%' ;
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                 FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),'ERROR')<>0 then 
                                      issue3:=TRUE;
                                  else
                                         if SYSDATE-v_last_date>30 then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
              end if;
              
               
              
              if upper(run_type)='ALL' or issue1 or issue2 or issue3 or issue4 or issue5 then 
                        dbms_output.put_line(' <br><br><a name="quantum"></a><b>Quantum</b><br>');
                    
						if issue2 or issue4 then
							dbms_output.put_line('<div class="divwarn">');
							if issue2 then
										  dbms_output.put_line('Never performed Quantum Data Update Installer! ');
										  dbms_output.put_line('Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this issue. Please verify with System Administrator.<br>');
										  :w5:=:w5+1;
							end if;
							if issue4 then
										  dbms_output.put_line('Your last run of Quantum Data Update Installer was on ');
										  dbms_output.put_line(v_last_date||' more than 30 days ago. Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this error. Please verify with System Administrator.<br>');
										  :w5:=:w5+1;										  
							end if;
							dbms_output.put_line('</div>');
						end if;
					if issue1 or issue3 or issue5 then
						dbms_output.put_line('<div class="diverr">');
                        if issue5 then
										  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>You don''t have the patch delivering latest Quantum version 4.0.<br>');
										  dbms_output.put_line('Please install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=');
										  if :apps_rel like '12.%' then
											dbms_output.put_line('19701971">Patch 19701971</a><br>');										 
										  elsif :apps_rel like '11.5%' then
										     dbms_output.put_line('19701970">Patch 19701970</a><br>');
										  end if;
										  :e5:=:e5+1;
						end if;
						if issue1 then
                                  :e5:=:e5+1;
								  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>No Quantum patch applied<br>');
                                  dbms_output.put_line('Ensure you also perform Quantum Data Update Installer.<br>');
                        end if;
                        
                                               
                        if issue3 then
                                  :e5:=:e5+1;
								  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>Your last run of Quantum Data Update Installer process completed in error. <br>');
								  dbms_output.put_line('Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this error. Please verify with System Administrator.<br>');
                        end if;
                                               
                       :issuep:=1;
						dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                        dbms_output.put_line('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations<br>');
						dbms_output.put_line('</div><br>');
                    end if;
					if not issue1 and not issue5 then
							if :apps_rel like '12.%' then
								dbms_output.put_line('Patch 19701971 applied on '||v_patch_date||'<br>');
							elsif :apps_rel like '11.5%' then
								dbms_output.put_line('Patch 19701970 applied on '||v_patch_date||'<br>');
							end if;
						end if;
					if not issue1 and not issue2 and not issue3 and not issue4 then
							dbms_output.put_line('Your last run of Quantum Data Update Installer was on '||v_last_date||'<br>');                                                           
                    end if;    
                    dbms_output.put_line('<div class="divok"><font color="blue">Advice: </font>Please periodically review:  <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                    dbms_output.put_line('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations</div>');
                        
                 
               end if;         
       end if; 
end if;       
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- JIT patching level

declare
  run_type varchar2(20):='&1';
  v_exists number:=0;
-- Display patch
	procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	  v_exists number:=0;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch;
					end if;					
						if (v_exists=0) then
								 dbms_output.put_line('<div class="diverr">');
								 dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font> Please plan to install ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> ');
								 dbms_output.put_line(v_name||'<br></div>');
								:e5:=:e5+1;								 
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch and rownum < 2;
							dbms_output.put_line('<img class="check_ico">OK! Patch '||v_patch||' ' || v_name);
							dbms_output.put_line(' applied on '||v_patch_date||'<br>');
							
						end if;
	end;   
begin
     select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'US'  and status='I';
     
     if v_exists>0 then
			dbms_output.put_line(' <br><br><a name="jit"></a><b>JIT</b><br>');
			
				if (:apps_rel like '12.2%') then
							dpatch('21142484','Q2 2015 Statutory and JIT Update');
						elsif (:apps_rel like '12.1%') then
							dpatch('21142484','Q2 2015 Statutory and JIT Update');
						elsif (:apps_rel like '12.0%') then		
							dpatch('19507770','Q3 2014 Statutory and JIT Update');
						elsif :apps_rel like '11.5%' then					
							dpatch('21142464','Q2 2015 Statutory and JIT Update'); 
				end if;
		             
    end if;   
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



-- Display Organization Chart Feature patch
declare 
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_exists number;
  v_patch_date ad_bugs.LAST_UPDATE_DATE%type;
begin
    if upper(product) in ('SSHR','ALL') and :apps_rel like '12.1%' then
		select count(1) into v_exists from ad_bugs where bug_number='13691576';
			if upper(run_type)='ALL' or v_exists=0 then
					dbms_output.put_line(' <br><br><a name="org"></a><b>Organization Chart Feature</b><br>');		
						if (v_exists=0) then
								 dbms_output.put_line('<div class="divwarn">');
								 dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Not installed ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=13691576">Patch 13691576</a> Organization Chart in Oracle SSHR<br>');	
								 dbms_output.put_line('Please ignore this warning if you are not using Organization Chart Feature as per ');
								 dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1408355.1" target="_blank">Note 1408355.1</a> Using the Organization Chart Feature in Oracle SSHR');
								 dbms_output.put_line('</div>');
								 :w5:=:w5+1;
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='13691576' and rownum < 2;
							dbms_output.put_line('Patch 13691576 Organization Chart in Oracle SSHR applied on '||v_patch_date||'<br>');							
						end if;
					
			end if;
	end if;
end;
/

-- Performance patches



begin
    dbms_output.put_line(' <br><br><a name="perf"></a><b>Performance</b><br>');
    dbms_output.put_line('<div class="divok"><font color="blue">Advice:</font> For performance patches please periodically review: ');
    dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=244040.1" target="_blank">Note 244040.1</a> - Oracle E-Business Suite Recommended Performance Patches</div>');
	dbms_output.put_line('<DIV align="center"><A class=detail onclick="displayItem(this,''s1sql45'');" href="javascript:;">&#9654; How to check database patches</A></DIV>');    
    dbms_output.put_line(' <TABLE align="center" border="1" cellspacing="0" cellpadding="2" id="s1sql45" style="display:none" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH align="left" COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line(' <blockquote>-	cd RDBMS_ORACLE_HOME<br>');
    dbms_output.put_line('-	. ./SID_hostname.env<br>');
    dbms_output.put_line('-	export PATH=$ORACLE_HOME/OPatch:$PATH<br>');
    dbms_output.put_line('-	opatch lsinventory<br>');
    dbms_output.put_line('-	Compare results with the patches from ');
	dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=244040.1" target="_blank">Note 244040.1</a> - Oracle E-Business Suite Recommended Performance Patches<br>');
	dbms_output.put_line('</blockquote>');
    dbms_output.put_line(' </TD><TR></TABLE>'); 
                                  
  dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
  dbms_output.put_line('</div></div>');
end;
/



-- Profile settings
-- Big profiles

declare
	  run_type varchar2(20):='&1';
	  product varchar2(20):='&2';
	  v_name fnd_profile_options_tl.user_profile_option_name%type; 
	  v_short_name fnd_profile_options.profile_option_name%type;
	  v_short_name_old fnd_profile_options.profile_option_name%type;
	  v_level varchar2(30);
	  v_level_old varchar2(30);
	  v_context varchar2(300);
	  v_value fnd_profile_option_values.profile_option_value%type;
	  v_id fnd_profile_options.PROFILE_OPTION_ID%type; 
	  v_big_no number :=1;
	  v_big_no2 number :=1;
	
		cursor big_profiles  is
		select n.user_profile_option_name,
		  po.profile_option_name ,
		   decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
		(
				'PER_SECURITY_PROFILE_ID',
				'PER_BUSINESS_GROUP_ID',
				'HR_CROSS_BUSINESS_GROUP',
				'HR_USER_TYPE',
				'ORG_ID',		
				'HR_LOCAL_OR_GLOBAL_NAME_FORMAT',
				'PER_NATIONAL_IDENTIFIER_VALIDATION',
				'PER_USE_TITLE_IN_FULL_NAME',
				'PER_ENABLE_DTW4',
				'DATETRACK:ENABLED'  
				)
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;	
		v_security	varchar2(42);
		v_rows number;
		v_org_name HR_ALL_ORGANIZATION_UNITS.NAME%type;
		
        
begin
	dbms_output.put_line('</div>');
	dbms_output.put_line('<div id="page3" style="display: none;">');	
	dbms_output.put_line('<a name="settings"></a><a name="profiles"></a><div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="settings" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Settings: '); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF"> /  </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
	if upper(run_type)='ALL' then
	dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
		dbms_output.put_line('<a class=detail2 href="#profiles">Profiles Settings</a> <br>');
		dbms_output.put_line('<a class=detail2 href="#security">Security Profile Details</a> <br>');
        dbms_output.put_line('<a class=detail2 href="#ssp">Ssp_temp_affected_rows rows</a> <br>');
		  if upper(product) in ('PAY','HR','ALL') then 
			  dbms_output.put_line('<a class=detail2 href="#international">International Payroll Usage</a> <br>');
		  end if;
		  dbms_output.put_line('</td><td class="toctable">');
		  if upper(product) in ('PAY','ALL') then
			  dbms_output.put_line('<a class=detail2 href="#rules">Pay Legislation Rules</a> <br>');			  
			  dbms_output.put_line('<a class=detail2 href="#pay_trigger_events">Pay Triggers Events</a> <br>');
			  dbms_output.put_line('<a class=detail2 href="#pay_action">Pay Action Parameters</a> <br>');  
		  end if;
		  dbms_output.put_line('<a class=detail2 href="#setup">Business Group Details</a> <br>');
		  if upper(product) in ('HR','SSHR','ALL') then
			  dbms_output.put_line('<a class=detail2 href="#employee">Employee Numbering Details</a> <br>');  
		  end if;
		 dbms_output.put_line('</td></tr></table>');
	dbms_output.put_line('</div><br>');
	end if;
		
		
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql40b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql40'');" href="javascript:;">&#9654; Profile Settings</A></DIV>');
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql40" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Profile Settings</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql41b" onclick="displayItem2(this,''s1sql41'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql41" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
    
		dbms_output.put_line('         select n.user_profile_option_name, <br>');    	
		dbms_output.put_line('               po.profile_option_name ,<br>');
		dbms_output.put_line('         decode(to_char(pov.level_id),<br>');
		dbms_output.put_line('         ''10001'', ''Site'',<br>');
		dbms_output.put_line('         ''10002'', ''Application'',<br>');
		dbms_output.put_line('         ''10003'', ''Responsibility'',<br>');
		dbms_output.put_line('         ''10005'', ''Server'',<br>');
		dbms_output.put_line('         ''10006'', ''Org'',<br>');
		dbms_output.put_line('         ''10007'', ''Servresp'',<br>');
		dbms_output.put_line('          ''10004'', ''User'', ''???'') ,<br>');
		dbms_output.put_line('         decode(to_char(pov.level_id),<br>');
		dbms_output.put_line('          ''10001'', ''Site'',<br>');
		dbms_output.put_line('         ''10002'', nvl(app.application_short_name,to_char(pov.level_value)),<br>');
		dbms_output.put_line('         ''10003'', nvl(rsp.responsibility_name,to_char(pov.level_value)),<br>');
		dbms_output.put_line('          ''10005'', svr.node_name,<br>');
		dbms_output.put_line('         ''10006'', org.name,<br>');
		dbms_output.put_line('         ''10007'', pov.level_value ||'', ''|| pov.level_value_application_id ||'', ''|| pov.level_value2,<br>');
		dbms_output.put_line('          ''10004'', nvl(usr.user_name,to_char(pov.level_value)),<br>');
		dbms_output.put_line('          ''???'') ,<br>');
		dbms_output.put_line('          pov.profile_option_value<br>');
		dbms_output.put_line('         from   fnd_profile_options po,<br>');
		dbms_output.put_line('         fnd_profile_option_values pov,<br>');
		dbms_output.put_line('         fnd_profile_options_tl n,<br>');
		dbms_output.put_line('         fnd_user usr,<br>');
		dbms_output.put_line('         fnd_application app,<br>');
		dbms_output.put_line('         fnd_responsibility_vl rsp,<br>');
		dbms_output.put_line('         fnd_nodes svr,<br>');
		dbms_output.put_line('         hr_operating_units org<br>');
		
		if upper(run_type)='ALL' then
						dbms_output.put_line('         where po.profile_option_name in (<br>');
							dbms_output.put_line('         ''HR_USER_TYPE'',<br>');
							dbms_output.put_line('         ''PER_BUSINESS_GROUP_ID'',<br>');
							dbms_output.put_line('         ''PER_SECURITY_PROFILE_ID'',<br>');
							dbms_output.put_line('         ''HR_CROSS_BUSINESS_GROUP'',<br>');
							dbms_output.put_line('         ''ORG_ID'',<br>');
							dbms_output.put_line('         ''PER_ENABLE_DTW4'',<br>');
							dbms_output.put_line('         ''DATETRACK:ENABLED'',<br>');
							dbms_output.put_line('          ''FND_DISABLE_OA_CUSTOMIZATIONS'',''FND_CUSTOM_OA_DEFINTION''<br>');	
							dbms_output.put_line('         ''FND_OA_ENABLE_DEFAULTS''<br>');	
						case upper(product)
							WHEN 'PAY' then						
							dbms_output.put_line('           ,''HR_PAYROLL_CURRENCY_RATES'',<br>');
							dbms_output.put_line('           ''HR_PAYROLL_CONTACT_SOURCE'',<br>');
							dbms_output.put_line('           ''HR_VIEW_PAYSLIP_FROM_DATE'',<br>');
							dbms_output.put_line('           ''HR_MV_HIRE_SKIP_ACT_VALIDATION'',<br>');
							dbms_output.put_line('         ''PAY_PPM_MULTI_ASSIGNMENT_ENABLE'',<br>');							
							dbms_output.put_line('         ''PAY_PSS_PAYMENTS_LIST'',<br>');
							dbms_output.put_line('         ''PAY_PSS_PAYMENT_FUNCTION'',<br>');
							dbms_output.put_line('         ''PAY_SIMULATION_ENABLE_FLAG'',<br>');
							dbms_output.put_line('         ''PAY_SIM_MULTI_ASSIGNMENT_ENABLE'',<br>');
							dbms_output.put_line('         ''PAY_KEEP_ENBL_HRACES'',<br>');
							dbms_output.put_line('         ''PAY_PSS_RUN_TYPE_DISPLAY'',<br>');
							dbms_output.put_line('         ''PAY_USE_FF_PTO'',<br>');
							dbms_output.put_line('         ''GB PAYROLL PENSIONS ENROLL CHECK'',<br>');
							dbms_output.put_line('         ''GB_PAYE_NI_AGGREGATION'',<br>');
							dbms_output.put_line('         ''GB_OVERRIDE_SOY'',<br>');
							dbms_output.put_line('         ''GB_DEFAULT_AGG_FLAG'',<br>');
							dbms_output.put_line('         ''GB RTI UPTAKE'',<br>');
							dbms_output.put_line('         ''PAY_IE_P35_REPORTING_YEAR'')<br>');												
							
						WHEN 'HR' then								
								dbms_output.put_line('         ''HR_ALLOW_NEG_ABS_BAL'',<br>');
								dbms_output.put_line('         ''PER_ABSENCE_DURATION_AUTO_OVERWRITE'',<br>');
								dbms_output.put_line('         ''HR_VIEWS_LAYOUT_ABSENCE'',<br>');
								dbms_output.put_line('         ''HR_SCH_BASED_ABS_CALC'',<br>');							 
							  dbms_output.put_line('         ''PER_GLOBAL_APL_NUM'',<br>');
							  dbms_output.put_line('         ''PER_GLOBAL_CWK_NUM'',<br>');
							  dbms_output.put_line('         ''PER_GLOBAL_EMP_NUM'',<br>');
							  dbms_output.put_line('         ''HR_CANCEL_APPLICATION'',<br>');
							  dbms_output.put_line('         ''HR_PROPAGATE_DATA_CHANGES'',<br>');      
							  dbms_output.put_line('         ''HR_LOCAL_OR_GLOBAL_NAME_FORMAT'',<br>');
							  dbms_output.put_line('         ''PAY_USE_FF_PTO'')<br>');
							  dbms_output.put_line('''HZ_DQM_ENABLED_FLAG'',<br>''HZ_DQM_IGNORE_CONC_LIMITS'',<br>''HZ_DQM_ENABLE_REALTIME_SYNC'')<br>');
						WHEN 'IRC' then								
							  dbms_output.put_line('         ) or  (po.profile_option_name like ''IRC%'')<br>');
						WHEN 'OTA' then
								dbms_output.put_line('         ) or (po.profile_option_name like ''OTA%'')<br>');
						WHEN 'BEN' then						
								dbms_output.put_line('         ) or  (po.profile_option_name like ''BEN%'')<br>');
						WHEN 'OTL' then							  
							  dbms_output.put_line('         ,''PA_PTE_AUTOAPPROVE_TS'',''PO_SERVICES_ENABLED'',<br>');							
							  dbms_output.put_line('         ''HR_ABS_OTL_INTEGRATION'',<br>');
							  dbms_output.put_line('         ''PER_ACCRUAL_PLAN_ELEMENT_SET'',<br>');
							  dbms_output.put_line('         ''PER_ABSENCE_DURATION_AUTO_OVERWRITE'')<br>');
							  dbms_output.put_line('         or  po.profile_option_name like ''HXT%''<br>');
							  dbms_output.put_line('         or po.profile_option_name like ''HXC%''<br>');							  
							 
						WHEN 'SSHR' then							  
							  dbms_output.put_line('         ,''AR_CHANGE_CUST_NAME'',<br>');							  
							  dbms_output.put_line('         ''HR_ALLOW_NEG_ABS_BAL'',<br>');
							  dbms_output.put_line('         ''PER_ABSENCE_DURATION_AUTO_OVERWRITE'',<br>');
							  dbms_output.put_line('         ''HR_VIEWS_LAYOUT_ABSENCE'',<br>');
							  dbms_output.put_line('         ''HR_SCH_BASED_ABS_CALC'',<br>');							
							  dbms_output.put_line('         ''PER_GLOBAL_APL_NUM'',<br>');
							  dbms_output.put_line('         ''PER_GLOBAL_CWK_NUM'',<br>');
							  dbms_output.put_line('         ''PER_GLOBAL_EMP_NUM'',<br>');
							  dbms_output.put_line('         ''HR_CANCEL_APPLICATION'',<br>');
							  dbms_output.put_line('         ''HR_PROPAGATE_DATA_CHANGES'',<br>');      
							  dbms_output.put_line('         ''HR_LOCAL_OR_GLOBAL_NAME_FORMAT'',<br>');
							  dbms_output.put_line('         ''PAY_USE_FF_PTO'',<br>');							 
							  dbms_output.put_line('         ''HR_APPRAISEE_ADD_PARTICIPANTS'',<br>');
							  dbms_output.put_line('         ''HR_WORKER_APPRAISALS_MENU'',<br>');
							  dbms_output.put_line('         ''HR_MANAGER_APPRAISALS_MENU'',<br>');
							  dbms_output.put_line('         ''HR_APPLY_COMPETENCIES_TO_PERSON'',<br>');
							  dbms_output.put_line('         ''HR_TALENT_MGMT_SRC_TYPE'',<br>');
							  dbms_output.put_line('         ''HR_SAVE_STAY_APPRAISALS_PAGE'',<br>');
							  dbms_output.put_line('         ''HR_ALLOW_UPDATES_TO_OBJECTIVE_DETAILS_ADDED_BY_APPRAISEE'',<br>');							  						  
							  dbms_output.put_line('         ''HR_TOTAL_COMP_OBJ_PRECESION'',<br>');
							  dbms_output.put_line('         ''HR_ALLOW_APPRAISALS_CROSS_BG'',<br>');
							  dbms_output.put_line('         ''PER_WPM_APPRAISAL_UPDATE_AFTER_PERIOD'',<br>');
							  dbms_output.put_line('         ''PER_VIEW_HISTORICAL_PLANS'',<br>');
							  dbms_output.put_line('         ''HR_ENABLE_TALENT_PROFILE'',<br>');
							  dbms_output.put_line('         ''HR_SELF_SERVICE_HR_LICENSED'',<br>');
							  dbms_output.put_line('         ''HR_SUCCESSION_MGMT_LICENSED'',<br>');
							  dbms_output.put_line('         ''PQH_ALLOW_APPROVER_TO_EDIT_TXN'',<br>');
							  dbms_output.put_line('         ''BEN_CWB_LICENSE_CHECK'',<br>');
							  dbms_output.put_line('         ''OTA_ORACLE_ILEARNING_LICENSED'',<br>');
							  dbms_output.put_line('         ''AME_INSTALLED_FLAG'',<br>');
							  dbms_output.put_line('         ''AME_INSTALLATION_LEVEL'',<br>');
							  dbms_output.put_line('         ''HR_ABS_OTL_INTEGRATION'',<br>');
							  dbms_output.put_line('          ''FND_EXTERNAL_ADF_URL'')<br>');
						WHEN 'ALL' then							  
							  dbms_output.put_line('           ''HR_PAYROLL_CURRENCY_RATES'',<br>');
							  dbms_output.put_line('           ''HR_PAYROLL_CONTACT_SOURCE'',<br>');
							  dbms_output.put_line('           ''HR_VIEW_PAYSLIP_FROM_DATE'',<br>');
							  dbms_output.put_line('           ''HR_MV_HIRE_SKIP_ACT_VALIDATION'',<br>');	
							  dbms_output.put_line('         ''HR_ALLOW_NEG_ABS_BAL'',<br>');
							  dbms_output.put_line('         ''PER_ABSENCE_DURATION_AUTO_OVERWRITE'',<br>');
							  dbms_output.put_line('         ''HR_VIEWS_LAYOUT_ABSENCE'',<br>');
							  dbms_output.put_line('         ''HR_SCH_BASED_ABS_CALC'',<br>');							 
							  dbms_output.put_line('         ''PER_GLOBAL_APL_NUM'',<br>');
							  dbms_output.put_line('         ''PER_GLOBAL_CWK_NUM'',<br>');
							  dbms_output.put_line('         ''PER_GLOBAL_EMP_NUM'',<br>');
							  dbms_output.put_line('         ''HR_CANCEL_APPLICATION'',<br>');
							  dbms_output.put_line('         ''HR_PROPAGATE_DATA_CHANGES'',<br>');      
							  dbms_output.put_line('         ''HR_LOCAL_OR_GLOBAL_NAME_FORMAT'',<br>');
							  dbms_output.put_line('         ''PAY_USE_FF_PTO'',<br>');
							  dbms_output.put_line('         ''HR_APPRAISEE_ADD_PARTICIPANTS'',<br>');
							  dbms_output.put_line('         ''HR_WORKER_APPRAISALS_MENU'',<br>');
							  dbms_output.put_line('         ''HR_MANAGER_APPRAISALS_MENU'',<br>');
							  dbms_output.put_line('         ''HR_APPLY_COMPETENCIES_TO_PERSON'',<br>');
							  dbms_output.put_line('         ''HR_TALENT_MGMT_SRC_TYPE'',<br>');
							  dbms_output.put_line('         ''HR_SAVE_STAY_APPRAISALS_PAGE'',<br>');
							  dbms_output.put_line('         ''HR_ALLOW_UPDATES_TO_OBJECTIVE_DETAILS_ADDED_BY_APPRAISEE'',<br>');
							  dbms_output.put_line('         ''HR_TOTAL_COMP_OBJ_PRECESION'',<br>');
							  dbms_output.put_line('         ''HR_ALLOW_APPRAISALS_CROSS_BG'',<br>');
							  dbms_output.put_line('         ''PER_WPM_APPRAISAL_UPDATE_AFTER_PERIOD'',<br>');
							  dbms_output.put_line('         ''PER_VIEW_HISTORICAL_PLANS'',<br>');
							  dbms_output.put_line('         ''HR_ENABLE_TALENT_PROFILE'',<br>');
							  dbms_output.put_line('         ''HR_SELF_SERVICE_HR_LICENSED'',<br>');
							  dbms_output.put_line('         ''HR_SUCCESSION_MGMT_LICENSED'',<br>');
							  dbms_output.put_line('         ''PQH_ALLOW_APPROVER_TO_EDIT_TXN'',<br>');
							  dbms_output.put_line('         ''BEN_CWB_LICENSE_CHECK'',<br>');
							  dbms_output.put_line('         ''OTA_ORACLE_ILEARNING_LICENSED'',<br>');
							  dbms_output.put_line('         ''AME_INSTALLED_FLAG'',<br>');
							  dbms_output.put_line('         ''AME_INSTALLATION_LEVEL'',<br>');
							  dbms_output.put_line('         ''HR_ABS_OTL_INTEGRATION'',<br>');
							  dbms_output.put_line('         ''PAY_PPM_MULTI_ASSIGNMENT_ENABLE'',<br>');
								dbms_output.put_line('         ''PAY_FR_CHECK_MANDATORY_ASG_ATTRIBUTES'',<br>');								
								dbms_output.put_line('         ''PAY_PSS_PAYMENT_FUNCTION'',<br>');
								dbms_output.put_line('         ''PAY_SIMULATION_ENABLE_FLAG'',<br>');
								dbms_output.put_line('         ''PAY_SIM_MULTI_ASSIGNMENT_ENABLE'',<br>');
								dbms_output.put_line('         ''PAY_KEEP_ENBL_HRACES'',<br>');
								dbms_output.put_line('         ''PAY_PSS_RUN_TYPE_DISPLAY'',<br>');
								dbms_output.put_line('         ''PAY_USE_FF_PTO'',<br>');
								dbms_output.put_line('         ''PER_ENABLE_DTW4'',<br>');
								dbms_output.put_line('         ''GB PAYROLL PENSIONS ENROLL CHECK'',<br>');
								dbms_output.put_line('         ''GB_OVERRIDE_SOY'',<br>');
								dbms_output.put_line('         ''GB_DEFAULT_AGG_FLAG'',<br>');
								dbms_output.put_line('         ''GB RTI UPTAKE'',<br>');
								dbms_output.put_line('         ''PAY_IE_P35_REPORTING_YEAR'',<br>');
								dbms_output.put_line('         ''GB_PAYE_NI_AGGREGATION'',<br>');
								dbms_output.put_line('          ''FND_EXTERNAL_ADF_URL'',<br>');
							  dbms_output.put_line('          ''FND_DISABLE_OA_CUSTOMIZATIONS'',''FND_CUSTOM_OA_DEFINTION''<br>');	
							  dbms_output.put_line('         ''FND_OA_ENABLE_DEFAULTS'')<br>');
							  dbms_output.put_line('         or po.profile_option_name like ''HXT%''<br>');
							  dbms_output.put_line('         or po.profile_option_name like ''HXC%''<br>');
							  dbms_output.put_line('         or po.profile_option_name in (''PA_PTE_AUTOAPPROVE_TS'',''PO_SERVICES_ENABLED'')))<br>');
						else
							null;
						end case;
		end if;

		
		if upper(run_type)='ISSUES' then
							  dbms_output.put_line('         where  (po.profile_option_name in (<br>');
							  dbms_output.put_line('           list of profiles with issues<br>');			
							  dbms_output.put_line('           )<br>');
		end if;
		dbms_output.put_line('          and    pov.application_id = po.application_id<br>');
		dbms_output.put_line('          and    po.profile_option_name = n.profile_option_name<br>');
		dbms_output.put_line('          and    pov.profile_option_id = po.profile_option_id<br>');
		dbms_output.put_line('          and    usr.user_id (+) = pov.level_value<br>');
		dbms_output.put_line('          and    rsp.application_id (+) = pov.level_value_application_id<br>');
		dbms_output.put_line('          and    rsp.responsibility_id (+) = pov.level_value<br>');
		dbms_output.put_line('          and    app.application_id (+) = pov.level_value<br>');
		dbms_output.put_line('          and    svr.node_id (+) = pov.level_value<br>');
		dbms_output.put_line('          and    svr.node_id (+) = pov.level_value2<br>');
		dbms_output.put_line('         and    org.organization_id (+) = pov.level_value<br>');
		dbms_output.put_line('         and    n.language=''US''<br>');
		dbms_output.put_line('         order by n.user_profile_option_name,pov.level_id;<br>');
    
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH width="25%"><B>Long Name</B></TD>');
		dbms_output.put_line(' <TH width="15%"><B>Short Name</B></TD>');
		dbms_output.put_line(' <TH width="15%"><B>Level</B></TD>');
		dbms_output.put_line(' <TH width="30%"><B>Context</B></TD>');
		dbms_output.put_line(' <TH width="15%"><B>Profile Value</B></TD>');
    
    
	:n := dbms_utility.get_time;
	
    v_short_name_old:='x';
    v_level_old:='x';
   	
	if upper(run_type) = 'ALL' then
		  open big_profiles;
          loop
            fetch big_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  big_profiles%NOTFOUND;
                    if v_short_name<>v_short_name_old then
							  if v_big_no>1 then  
									v_big_no2 :=v_big_no-1;
									dbms_output.put_line('<tr><td><A class=detail onclick="hideRow2(''s1sql100'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
									dbms_output.put_line('</TABLE></td></TR>');
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        dbms_output.put_line('-');
                    else
                        dbms_output.put_line(v_context );
                    end if;
                    case v_short_name
					when 'PER_SECURITY_PROFILE_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from PER_SECURITY_PROFILES 
									where SECURITY_PROFILE_ID = v_value;
								if v_rows=1 then
										select substr(SECURITY_PROFILE_NAME,1,40) into v_security from PER_SECURITY_PROFILES 
											where SECURITY_PROFILE_ID = v_value;							
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_security);
								else
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					when 'HR_USER_TYPE' then
							case v_value
							when 'INT' then
								dbms_output.put_line('</TD>'||chr(10)||'<TD>INT - HR with Payroll User' );
							when 'PAY' then
								dbms_output.put_line('</TD>'||chr(10)||'<TD>PAY - Payroll User' );
							when 'PER' then
								dbms_output.put_line('</TD>'||chr(10)||'<TD>PER - HR User' );
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
							end case;
					when 'ORG_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;
								if v_rows=1 then									
										select NAME into v_org_name from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;										
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_org_name);									
								else
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					when 'PER_BUSINESS_GROUP_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;
								if v_rows=1 then									
										select NAME into v_org_name from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;										
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_org_name);									
								else
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					else
							dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
					end case;
                    dbms_output.put_line('</TD></TR>'||chr(10));              
          end loop;
          close big_profiles;
		  
		  v_big_no2 :=v_big_no-1;
		  dbms_output.put_line('<tr><td><A class=detail onclick="hideRow2(''s1sql100'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
									
		  dbms_output.put_line(' </TABLE>');
	end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name fnd_profile_options_tl.user_profile_option_name%type; 
  v_short_name fnd_profile_options.profile_option_name%type;
  v_short_name_old fnd_profile_options.profile_option_name%type;
  v_level varchar2(30);
  v_level_old varchar2(30);
  v_context varchar2(300);
  v_value fnd_profile_option_values.profile_option_value%type;
  v_id fnd_profile_options.PROFILE_OPTION_ID%type;
  issue0 boolean := FALSE;	
  issue1 boolean := FALSE;
  issue2 boolean := FALSE;
  issue3 boolean := FALSE;
  issue4 boolean := FALSE;
  issue5 boolean := FALSE;
  issue6 boolean := FALSE;
  issue7 boolean := FALSE;
  issue8 boolean := FALSE;
  issue9 boolean := FALSE;
  issue10 boolean := FALSE;
  issue11 boolean := FALSE;
  issue12 boolean := FALSE;
  issue13 boolean := FALSE;
  issue131 boolean := FALSE;
  issue14 boolean := FALSE;
  issue142 boolean := FALSE;
  issue15 boolean := FALSE;
  issue16 boolean := FALSE;
  issue17 boolean := FALSE;
  issue18 boolean := FALSE;
  issue19 boolean := FALSE;
  issue182 boolean := FALSE;
  issue192 boolean := FALSE;
  issue20 boolean := FALSE; 
  issue21 boolean := FALSE;
   issue22 boolean := FALSE;
  issue23 boolean := FALSE;
  issue24 boolean := FALSE;
  issue25 boolean := FALSE;
  issue26 boolean := FALSE;
  v_rows number;
  v_begin_table number;
  v_end_table number;
  v_big_no_old number;
  v_big_no number;
	
	cursor pay_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where po.profile_option_name in
             (
              'HR_PAYROLL_CURRENCY_RATES',
				'HR_PAYROLL_CONTACT_SOURCE',
				'HR_VIEW_PAYSLIP_FROM_DATE',
				'HR_MV_HIRE_SKIP_ACT_VALIDATION',
				'PAY_PPM_MULTI_ASSIGNMENT_ENABLE',
				'PAY_PSS_PAYMENTS_LIST',
				'PAY_PSS_PAYMENT_FUNCTION',
				'PAY_SIMULATION_ENABLE_FLAG',
				'PAY_SIM_MULTI_ASSIGNMENT_ENABLE',
				'PAY_KEEP_ENBL_HRACES',
                'PAY_PSS_RUN_TYPE_DISPLAY',
                'PAY_USE_FF_PTO',
				'GB PAYROLL PENSIONS ENROLL CHECK',
				'GB_PAYE_NI_AGGREGATION',
				'PAY_IE_P35_REPORTING_YEAR',
				'GB_OVERRIDE_SOY',
				'GB_DEFAULT_AGG_FLAG',
				'GB RTI UPTAKE'
			  )
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
    
	cursor irc_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where po.profile_option_name like 'IRC%'			 
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
		
	cursor hr_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
              (
              'HR_ALLOW_NEG_ABS_BAL',
              'PER_ABSENCE_DURATION_AUTO_OVERWRITE',
              'HR_VIEWS_LAYOUT_ABSENCE',
              'HR_SCH_BASED_ABS_CALC', 
              'PER_GLOBAL_APL_NUM',
              'PER_GLOBAL_CWK_NUM',
              'PER_GLOBAL_EMP_NUM','PER_EX_SECURITY_PROFILE',
              'HR_CANCEL_APPLICATION',
              'HR_PROPAGATE_DATA_CHANGES',
              'HR_LOCAL_OR_GLOBAL_NAME_FORMAT',
              'PAY_USE_FF_PTO',
			  'HZ_DQM_ENABLED_FLAG',
			  'HZ_DQM_IGNORE_CONC_LIMITS',
			  'HZ_DQM_ENABLE_REALTIME_SYNC'
			  )
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;	 
	
	cursor ben_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name like 'BEN%'
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;	
		
	cursor ota_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name like 'OTA%'
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;	
		
	cursor sshr_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
              ('AR_CHANGE_CUST_NAME',
			  'HR_APPRAISEE_ADD_PARTICIPANTS',
			  'HR_WORKER_APPRAISALS_MENU',
			  'HR_MANAGER_APPRAISALS_MENU',
			  'HR_APPLY_COMPETENCIES_TO_PERSON',
			  'HR_TALENT_MGMT_SRC_TYPE',
			  'HR_SAVE_STAY_APPRAISALS_PAGE',
			  'HR_ALLOW_UPDATES_TO_OBJECTIVE_DETAILS_ADDED_BY_APPRAISEE',
			  'HR_TOTAL_COMP_OBJ_PRECESION',
			  'HR_ALLOW_APPRAISALS_CROSS_BG',
			  'PER_WPM_APPRAISAL_UPDATE_AFTER_PERIOD',
			  'PER_VIEW_HISTORICAL_PLANS',
			  'HR_ENABLE_TALENT_PROFILE',
			  'HR_SELF_SERVICE_HR_LICENSED',
			  'HR_SUCCESSION_MGMT_LICENSED',
			  'BEN_CWB_LICENSE_CHECK',
			  'OTA_ORACLE_ILEARNING_LICENSED',
			  'AME_INSTALLED_FLAG',
			  'AME_INSTALLATION_LEVEL',
			  'HR_ABS_OTL_INTEGRATION',
			  'FND_EXTERNAL_ADF_URL',
			  'PQH_ALLOW_APPROVER_TO_EDIT_TXN'
              ) 
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;

	cursor otl_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  (po.profile_option_name like 'HXT%' 
				or po.profile_option_name like 'HXC%' 
				or po.profile_option_name in ('PA_PTE_AUTOAPPROVE_TS',
				'HR_ABS_OTL_INTEGRATION',
					'PER_ACCRUAL_PLAN_ELEMENT_SET',
					'PER_ABSENCE_DURATION_AUTO_OVERWRITE')
              ) 
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;

	cursor all_profiles is
   select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  (po.profile_option_name in (              
			  'FND_DISABLE_OA_CUSTOMIZATIONS','FND_CUSTOM_OA_DEFINTION',
			  'FND_OA_ENABLE_DEFAULTS',
			  'ENABLE_SECURITY_GROUPS',
			  'UPLOAD_FILE_SIZE_LIMIT',
			  'APPS_FRAMEWORK_AGENT','APPS_JSP_AGENT'
			,'APPS_WEB_AGENT','APPS_SERVLET_AGENT','APPS_SSO'
			,'FND_FWK_COMPATIBILITY_MODE'
			,'WEB_PROXY_HOST'
			,'WEB_PROXY_PORT'
			,'WEB_PROXY_BYPASS_DOMAINS'
			,'PER_WIP_AUTOMATIC_SAVE'
			,'FND_NATIVE_CLIENT_ENCODING'
			,'ICX_CLIENT_IANA_ENCODING')
               or po.profile_option_name like 'BNE%' )
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
        
begin

 if upper(product) ='OTL' or upper(product) ='ALL' then	
    open otl_profiles;
    loop
            fetch otl_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  otl_profiles%NOTFOUND;
            CASE v_short_name
							  when 'HXT_BATCH_SIZE' then 
								if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
									if v_value<25 then
										issue1:=TRUE;
									end if;
								end if;
							  when 'HXT_HOL_HOURS_FROM_HOL_CAL' then
								if v_value ='Y' then                
								  issue2:=TRUE;
								elsif v_value='N' then
									issue3:=TRUE;
								end if;  
							  when 'HXT_ROLLUP_BATCH_HOURS' then
								if v_value ='Y' then                
								  issue4:=TRUE;
								elsif v_value='N' then
									issue5:=TRUE;
								end if; 
							  when 'HXC_TIMEKEEPER_OVERRIDE' then 
								if v_value='N' then
									issue6:=TRUE;
								end if;     
							  when 'HXC_ALLOW_TERM_SS_TIMECARD' then 
								if v_value='N' then
									issue7:=TRUE;
								end if;    
							  when 'HXC_DEFER_WORKFLOW' then
								if v_value ='Y' then                
								  issue8:=TRUE;
								elsif v_value='N' then
									issue9:=TRUE;
								end if; 
							  when 'HXC_RETRIEVAL_MAX_ERRORS' then
								if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
									if v_value<500 then                
									  issue10:=TRUE;
									elsif v_value<1000 then
										issue11:=TRUE;
									end if; 
								end if;
							  when 'HXC_RETRIEVAL_CHANGES_DATE' then
								if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
									if v_value < 8 then                
									  issue12:=TRUE;
									elsif v_value < 30 then                
									  issue13:=TRUE;
									elsif v_value < 365 then
									  issue131:=TRUE;
									end if; 
								end if;
							  when 'HXC_RETRIEVAL_BATCH_SIZE' then 
								if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
									if v_value<50 then
										issue14:=TRUE;
									elsif v_value<100 then
										issue142:=TRUE;					
									end if; 
								end if;
							  when 'HXC_RETRIEVAL_OPTIONS' then
								if v_value='BEE Only' then                
								  issue15:=TRUE;
								elsif v_value='OTLR Only' then
									issue16:=TRUE;
								end if; 
							  when 'PA_PTE_AUTOAPPROVE_TS' then 
								if v_value='Y' then
									issue17:=TRUE;
								end if; 
							  else
								null;
							END CASE;			
						 
				   
      end loop;
      close otl_profiles;
  end if;
  
  	  
  if upper(product) in('PAY','ALL') then
  	select count(1) 
     into v_rows
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';     
     if v_rows>0 then
		select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
			where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'   and pov.level_id='10001'
			and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
			if v_rows = 0 then
				issue22:=TRUE;
			else
				select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
					where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'   and pov.level_id='10001' and pov.profile_option_value='2014'
					and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
					if v_rows = 0 then
						issue23:=TRUE;
					end if;				
			end if;
		select   count(distinct pov.profile_option_value)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
					where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'  
					and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
			if v_rows >1 then
				issue24:=TRUE;
			end if;
	 end if;
  end if;  
  
  if upper(product) in('HR','SSHR','ALL') then
		select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='PER_GLOBAL_EMP_NUM'  and  pov.profile_option_value='Y'
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
		if v_rows >1 then
				issue25:=TRUE;
			end if;
  end if;
    
		  
  if upper(product) in ('SSHR','OTA','ALL') then	
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_WORKER_APPRAISALS_MENU' and pov.level_id='10001' and pov.profile_option_value is null 
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;					
					if v_rows>0 then
						issue18:=TRUE;
					end if;
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_WORKER_APPRAISALS_MENU' and pov.level_id='10001' 
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;					
					if v_rows=0 then
						issue18:=TRUE;
					end if;					
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_WORKER_APPRAISALS_MENU' and pov.level_id='10001' and pov.profile_option_value <>'HR_EMPLOYEE_APPRAISALS_MENU' 
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;					
					if v_rows>0 then
						issue182:=TRUE;
					end if;
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_MANAGER_APPRAISALS_MENU' and pov.level_id='10001' and pov.profile_option_value is null
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;	
					if v_rows>0 then
						issue19:=TRUE;
					end if;
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_MANAGER_APPRAISALS_MENU' and pov.level_id='10001' 
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;	
					if v_rows=0 then
						issue19:=TRUE;
					end if;
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_MANAGER_APPRAISALS_MENU' and pov.level_id='10001' and pov.profile_option_value <>'HR_MANAGER_APPRAISALS_MENU'
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;	
					if v_rows>0 then
						issue192:=TRUE;
					end if;
	end if;
	
	if upper(product) in ('SSHR','ALL') then				
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='AR_CHANGE_CUST_NAME'  and pov.level_id = 10001 and (pov.profile_option_value is null or pov.profile_option_value='N')
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;	
					if v_rows>0 then
						issue21:=TRUE;
					end if;
  end if;
  

  
	select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
	where  po.profile_option_name ='FND_DISABLE_OA_CUSTOMIZATIONS'   and pov.profile_option_value='N'
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
	if v_rows > 0 then
		issue0:=TRUE;
	end if;
	
	select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
	where  po.profile_option_name ='FND_OA_ENABLE_DEFAULTS'   and pov.profile_option_value='N'
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
	if v_rows > 0 then
		issue20:=TRUE;
	end if;
	
	SELECT  count(1) into v_rows
         FROM    fnd_profile_options po
                ,fnd_profile_option_values pov
         WHERE   po.profile_option_name = 'ENABLE_SECURITY_GROUPS'
         AND     po.application_id = 0
         AND     po.profile_option_id = pov.profile_option_id
         AND     po.application_id = pov.application_id
         AND     (pov.level_id = 10002  AND  hr_general.chk_application_id (pov.level_value) = 'TRUE')
         AND     pov.profile_option_value = 'Y';
	if v_rows > 0 then
		issue26:=TRUE;
	end if;
	
	v_short_name_old:='x';
    v_level_old:='x';
	v_big_no:=11;
	v_begin_table:=0;
	v_end_table:=0;
	
	open all_profiles;
          loop
            fetch all_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  all_profiles%NOTFOUND;
            if upper(run_type)='ALL' or (issue0 and v_short_name='FND_DISABLE_OA_CUSTOMIZATIONS')  
			or (issue20 and v_short_name='FND_OA_ENABLE_DEFAULTS') then				 
					 if v_short_name<>v_short_name_old then
							  if v_big_no>11 then  
									dbms_output.put_line('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        dbms_output.put_line('-');
                    else
                        dbms_output.put_line(v_context );
                    end if;
                    dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
                    dbms_output.put_line('</TD></TR>'||chr(10));              
			end if;
		  end loop;
   close all_profiles;
   if v_begin_table<>v_end_table then
		dbms_output.put_line(' </TABLE>');
   end if;
		
	
	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(run_type)='ALL' and upper(product) in ('BEN','ALL')  then
          open ben_profiles;
          loop
            fetch ben_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  ben_profiles%NOTFOUND;            
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									dbms_output.put_line('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        dbms_output.put_line('-');
                    else
                        dbms_output.put_line(v_context );
                    end if;
                    dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
                    dbms_output.put_line('</TD></TR>'||chr(10));              
		  end loop;
          close ben_profiles;  
		  if v_begin_table<>v_end_table then
				dbms_output.put_line(' </TABLE>');
		  end if;
    end if;
	
	
	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(run_type)='ALL' and upper(product) in ('IRC','ALL')  then
          open irc_profiles;
          loop
            fetch irc_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  irc_profiles%NOTFOUND;            
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									dbms_output.put_line('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        dbms_output.put_line('-');
                    else
                        dbms_output.put_line(v_context );
                    end if;
                    dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
                    dbms_output.put_line('</TD></TR>'||chr(10));            
			
		  end loop;
          close irc_profiles;  
		  if v_begin_table<>v_end_table then
				dbms_output.put_line(' </TABLE>');
		  end if;
    end if;
	
	

	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
    if upper(product) in ('HR','SSHR','ALL')  then
          open hr_profiles;
          loop
            fetch hr_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  hr_profiles%NOTFOUND;
			if upper(run_type)='ALL' or (issue25 and v_short_name='PER_GLOBAL_EMP_NUM')  then
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									dbms_output.put_line('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
                   if v_short_name=v_short_name_old and v_level=v_level_old then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        dbms_output.put_line('-');
                    else
                        dbms_output.put_line(v_context );
                    end if;
					if v_short_name<>'HR_LOCAL_OR_GLOBAL_NAME_FORMAT' then
							dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
						else
							if v_value like 'G%' then								
								dbms_output.put_line('</TD>'||chr(10)||'<TD>Global Format' );
							elsif v_value like 'L%' then							
								dbms_output.put_line('</TD>'||chr(10)||'<TD>Local Format' );
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
							end if;
					end if;
                    
                    dbms_output.put_line('</TD></TR>'||chr(10));              
          end if;
		  end loop;
          close hr_profiles;  
		  if v_begin_table<>v_end_table then
				dbms_output.put_line(' </TABLE>');
		  end if;
    end if;

	
	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(product) in ('SSHR','ALL')  then
          open sshr_profiles;
          loop
            fetch sshr_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  sshr_profiles%NOTFOUND;
             if upper(run_type)='ALL' or ((issue18 or issue182) and v_short_name='HR_WORKER_APPRAISALS_MENU') or (issue21 and v_short_name='AR_CHANGE_CUST_NAME')
				or ((issue19 or issue192) and v_short_name='HR_MANAGER_APPRAISALS_MENU') then
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									dbms_output.put_line('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        dbms_output.put_line('-');
                    else
                        dbms_output.put_line(v_context );
                    end if;
                    dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
                    dbms_output.put_line('</TD></TR>'||chr(10));              
			 end if;
		  end loop;
          close sshr_profiles;  
		  if v_begin_table<>v_end_table then
				dbms_output.put_line(' </TABLE>');
		  end if;
    end if;

	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
    if upper(product) in ('OTL','ALL') then
          open otl_profiles;
          loop
            fetch otl_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  otl_profiles%NOTFOUND;
			if upper(run_type)='ALL' or (issue1 and v_short_name='HXT_BATCH_SIZE') 
				or ((issue2 or issue3) and v_short_name='HXT_HOL_HOURS_FROM_HOL_CAL')  
				or ((issue4 or issue5) and v_short_name='HXT_ROLLUP_BATCH_HOURS')
				or (issue6 and v_short_name='HXC_TIMEKEEPER_OVERRIDE')
				or (issue7 and v_short_name='HXC_ALLOW_TERM_SS_TIMECARD')
				or ((issue8 or issue9) and v_short_name='HXC_DEFER_WORKFLOW')
				or ((issue10 or issue11) and v_short_name='HXC_RETRIEVAL_MAX_ERRORS')
				or ((issue2 or issue13) and v_short_name='HXC_RETRIEVAL_CHANGES_DATE')
				or ((issue14 or issue142) and v_short_name='HXC_RETRIEVAL_BATCH_SIZE')
				or ((issue15 or issue16) and v_short_name='HXC_RETRIEVAL_OPTIONS')
				or (issue17 and v_short_name='PA_PTE_AUTOAPPROVE_TS') then
						   if v_short_name<>v_short_name_old then
									  if v_big_no>v_big_no_old then  
											dbms_output.put_line('</TABLE></td></TR>');
											v_end_table:=v_end_table+1;
									  end if;
									  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
									  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
									  dbms_output.put_line('   </TD>');
									  dbms_output.put_line(' </TR>');
									  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
									  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
									  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
									  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
									  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
									  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
									  v_begin_table:=v_begin_table+1;
									  v_big_no:=v_big_no+1;
									  
							end if;
						   if v_short_name=v_short_name_old and v_level=v_level_old then
								dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
								dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
								dbms_output.put_line('</TD>'||chr(10)||'<TD>');
							else
								dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
								dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
								dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
							end if;
							v_short_name_old:=v_short_name;
							v_level_old:=v_level;
				  
							if v_context is null then
								dbms_output.put_line('-');
							else
								dbms_output.put_line(v_context );
							end if;
							dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
							dbms_output.put_line('</TD></TR>'||chr(10));      
				end if;					
          end loop;
          close otl_profiles;
		  if v_begin_table<>v_end_table then
				dbms_output.put_line(' </TABLE>');
		  end if;
    end if;
    

	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(product) in ('OTA','ALL')  then
          open ota_profiles;
          loop
            fetch ota_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  ota_profiles%NOTFOUND;
			if upper(run_type)='ALL' or ((issue18 or issue182) and v_short_name='HR_WORKER_APPRAISALS_MENU') 
				or ((issue19 or issue192) and v_short_name='HR_MANAGER_APPRAISALS_MENU') then

					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									dbms_output.put_line('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        dbms_output.put_line('-');
                    else
                        dbms_output.put_line(v_context );
                    end if;
                    dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
                    dbms_output.put_line('</TD></TR>'||chr(10)); 
			end if;
		  end loop;
          close ota_profiles;  
		  if v_begin_table<>v_end_table then
				dbms_output.put_line(' </TABLE>');
		  end if;
    end if;
	
	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(product) in ('ALL','PAY')  then
          open pay_profiles;
          loop
            fetch pay_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  pay_profiles%NOTFOUND;
			if upper(run_type)='ALL' or ((issue22 or issue23 or issue24) and v_short_name='PAY_IE_P35_REPORTING_YEAR')  then
			if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									dbms_output.put_line('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
			end if;
            if v_short_name=v_short_name_old and v_level=v_level_old then
                dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                dbms_output.put_line('</TD>'||chr(10)||'<TD>');
            else
                dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
            end if;
            v_short_name_old:=v_short_name;
            v_level_old:=v_level;
            
            if v_context is null then
                dbms_output.put_line('-');
            else
                dbms_output.put_line(v_context );
            end if;
            dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
            dbms_output.put_line('</TD></TR>'||chr(10));
          end if;      
          end loop;
          close pay_profiles;
		  if v_begin_table<>v_end_table then
				dbms_output.put_line(' </TABLE>');
		  end if;
    end if;

		  
    
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql40'');" href="javascript:;">Collapse section</a></td></tr>');
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> </div> ');
	
	if upper(run_type)='ALL' and (not issue26) then
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('<font color="blue">Information:</font> Multiple Security Group is NOT enabled.<br></div>');
	end if;
 
     if upper(run_type)='ALL' or issue0 or issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 or issue11 or issue12 or issue13 or issue14 or issue15 or issue16 or issue17 or issue18 or issue19 or issue20 then
		if issue0 or issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 or issue11 or issue12 or issue13 or issue14 or issue15 or issue16 or issue17 or issue18 or issue182 or issue19 or issue192 or issue20 or issue21 
		or issue22 or issue23 or issue24 or issue25 or issue26 then			
			if issue26 then
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('<font color="blue">Information:</font> Multiple Security Group is enabled.<br></div>');
			end if;
			if issue0 then
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('<font color="blue">Advice:</font> Profile "Disable Self-Service Personal" is set to N at one/several levels, ');
				dbms_output.put_line('so personalization/OA page customization is used. This can cause issues in system behavior (caused by custom personalization).<br> ');
				dbms_output.put_line('If you have issues in web pages, before raising an Service Request, please turn this profile to Y (to disable all personalizations) and retest. ');
				dbms_output.put_line('If the issue is not reproducible, then it is caused by customization.<br>');
				dbms_output.put_line('</div>');
			end if;
			if issue20 then
				dbms_output.put_line('<div class="divwarn">');
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "FND:OA:Enable Defaults" is set to N at one/several levels, ');
				dbms_output.put_line('so default values specified in personalizations and base meta data applied to your pages will not be displayed.<br> ');
				dbms_output.put_line('</div>');
				:w4:=:w4+1;
			end if;
			
			
			if (upper(product) in ('SSHR','OTA','ALL')) then
				if (issue18 or issue19) then    
				  dbms_output.put_line('<div class="diverr">');
				  if issue18 then
					dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Profile "HR: Worker Appraisals Menu" is not set at Site level, ');
					dbms_output.put_line('this may case issues when working with custom responsibility/menu. ');
					:e4:=:e4+1;
				  end if;
				  if issue19 then
					dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Profile "HR: Manager Appraisals Menu" is not set as Manager Appraisals Menu, ');
					dbms_output.put_line('this may case issues when working with custom responsibility/menu. ');
					:e4:=:e4+1;
				  end if;
				  dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=796769.1" target="_blank" >Note 796769.1</a> ');
				  dbms_output.put_line('Appraisal Not Being Created When Performance Management Plan Is Published <br></div>');
				end if;
				  
				if (issue182 or issue192) then 
					dbms_output.put_line('<div class="divok">');
					if issue182 then
						dbms_output.put_line('<font color="blue">Comment:</font> Profile "HR: Worker Appraisals Menu" is not set as Employee Appraisals Menu, ');
						dbms_output.put_line('Custom menu is set here, please make sure it follows the same structure of seeded menu. ');						
					end if;
					if issue192 then
						dbms_output.put_line('<font color="blue">Comment:</font> Profile "HR: Manager Appraisals Menu" is not set as Manager Appraisals Menu, ');
						dbms_output.put_line('Custom menu is set here, please make sure it follows the same structure of seeded menu. ');
					end if;
					dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=796769.1" target="_blank" >Note 796769.1</a> ');
				    dbms_output.put_line('Appraisal Not Being Created When Performance Management Plan Is Published <br></div>');
				end if;  
			  end if;
			if (upper(product)in('SSHR','ALL')) and (issue21) then    
				  dbms_output.put_line('<div class="divwarn">');		  
				  
				  if issue21 then
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "HZ: Change Party Name" shoud be set to Yes at Site level. ');
					dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=732008.1" target="_blank" >Note 732008.1</a> ');
					dbms_output.put_line('Modify Employee Information and Receive Error APP-PER_289974 <br>');
					:w4:=:w4+1;
				  end if;
				  
				  dbms_output.put_line('</div>');
			  end if;
			
			if (upper(product)='PAY' or upper(product)='ALL') and (issue22 or issue23 or issue24) then    
				  dbms_output.put_line('<div class="divwarn">');
				if issue22 then				
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "HR: IE P35 Reporting Year" is not set at Site Level.<br> ');				
					:w4:=:w4+1;
				end if;
				if issue23 then							
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "HR: IE P35 Reporting Year" is not set to current tax year 2014.<br> ');
							:w4:=:w4+1;
				end if;
				if issue23 then							
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "HR: IE P35 Reporting Year" is set to different values at different levels.<br> ');							
							:w4:=:w4+1;
				end if;				  
				  dbms_output.put_line('</div>');
			  end if;
			
			if (upper(product) in ('HR','SSHR','ALL')) and (issue25) then    
				  dbms_output.put_line('<div class="divok">');
				  dbms_output.put_line('<font color="#CC3311">For Oracle Support:</font> Profile "HR:Use Global Employee Numbering" is set to Yes.<br> ');
				  dbms_output.put_line('This note was followed: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=259160.1" target="_blank">Note 259160.1</a> Step By Step Instructions For Implementing Global Sequencing<br>');
				  dbms_output.put_line('Once a customer implements Global Numbering, they cannot go backwards and revert back to Automatic or Manual Numbering via Business Group Info.<br>');
				  dbms_output.put_line('They must continue to use Global Numbering.<br>');				  					  
				  dbms_output.put_line('</div>');
			  end if;
			
			if upper(product)='OTL' or upper(product)='ALL' then    
				if issue1 or issue6 or issue7 or issue11 or issue13 or issue142 then
					dbms_output.put_line('<div class="divwarn">');
					  if issue1 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "HXT: Batch Size" is lower than 25 at one/several levels, ');
						dbms_output.put_line('we recommend the value to be 25.<br>');
						:w4:=:w4+1;
					  end if;
					   if issue6 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "OTL: Allow Change Group Timekeeper" is set to N at ');
						dbms_output.put_line('one/several levels, this will stop you from setting up Timekeeper functionality.<br>');
						:w4:=:w4+1;
					  end if;
					  if issue7 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "OTL: Allow Self Service Time Entry for Terminated Employees" ');
						dbms_output.put_line('is set to N at one/several levels, ');
						dbms_output.put_line('so Terminated (not finally closed) employees will not be able to enter timecards for their previous periods.<br>');
						:w4:=:w4+1;
					  end if;
					  if issue11 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "OTL: Max Errors" is less than 1000 at one/several levels. ');
						dbms_output.put_line('Please increase it to 1000.<br>');
						:w4:=:w4+1;
					  end if;
					  if issue13 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "OTL: Number of past days for which retrieval considers changes (days)" is less than 30 at one/several levels. ');
						dbms_output.put_line('Recommended value is 365 days.<br>');
						:w4:=:w4+1;
					  end if;
					   if issue142 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Profile "OTL: Transfer Batch Size" is less than 100 at one/several levels.<br>');
						dbms_output.put_line('Please refer <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1304058.1" target="_blank">Note 1304058.1</a> ');
						dbms_output.put_line('Transfer Time From OTL to BEE Batch Size for Optimal Performance.<br>');
						:w4:=:w4+1;
					  end if;
					  dbms_output.put_line('</div>');
				  end if;
				  if issue131 or issue15 or issue16 or issue2 or issue3 or issue4 or issue5 or issue8 or issue9 then
					dbms_output.put_line('<div class="divok">');
					  if issue131 then
						dbms_output.put_line('<font color="blue">Advice:</font>Profile "OTL: Number of past days for which retrieval considers changes (days)" is less than 365 at one/several levels. ');
						dbms_output.put_line('Recommended value is 365 days.<br>');
					  end if;				  
					   if issue15 then
						dbms_output.put_line('<font color="blue">Information:</font> Profile "OTL: Transfer to OTLR and / or BEE" is set to "BEE only" at one/several levels, ');
						dbms_output.put_line('so OTLR Timecards will not be transferred.<br>');
					  end if;      
					  if issue16 then
						dbms_output.put_line('<font color="blue">Information:</font> Profile "OTL: Transfer to OTLR and / or BEE" is set to "OTLR only" at one/several levels, ');
						dbms_output.put_line('so Non-OTLR Timecards will not be transferred.<br>');
					  end if; 
					  if issue2 then
						dbms_output.put_line('<font color="blue">Information:</font> Profile "HXT: Holiday Hours from Holiday Calendar" is set to Y ');
						dbms_output.put_line('at one/several levels, this will auto-generate the holidays from the Holiday Calendar.<br>');
					  end if;      
					  if issue3 then
						dbms_output.put_line('<font color="blue">Information:</font> Profile "HXT: Holiday Hours from Holiday Calendar" is set to N ');
						dbms_output.put_line('at one/several levels, this will auto-generate the holidays from the Workplan.<br>');
					  end if;  
					  if issue4 then
						dbms_output.put_line('<font color="blue">Information:</font> Profile "HXT: Rollup Batch Hours" is set to Y at one/several levels, ');
						dbms_output.put_line('so Elements will be rolled up when transferring them to BEE.<br>');
					  end if;      
					  if issue5 then
						dbms_output.put_line('<font color="blue">Information:</font> Profile "HXT: Rollup Batch Hours" is set to N at one/several levels, ');
						dbms_output.put_line('so Elements will be not be rolled up when transferring them to BEE.<br>');
					  end if; 				  
					  if issue8 then
						dbms_output.put_line('<font color="blue">Information:</font> Profile "OTL: Defer approval process on timecard submission" is set to Y ');
						dbms_output.put_line('at one/several levels, so Workflow will not be automatically invoked when timecards are submitted.<br>');
					  end if;      
					  if issue9 then
						dbms_output.put_line('<font color="blue">Information:</font> Profile "OTL: Defer approval process on timecard submission" is set to N ');
						dbms_output.put_line('at one/several levels, so Workflow will be invoked automatically for each timecard submitted.<br>');
					  end if;
					  dbms_output.put_line('</div>');
				  end if;
				  if issue10 or issue12 or issue14 or issue17 then
					dbms_output.put_line('<div class="diverr">');
						  if issue10 then
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Profile "OTL: Max Errors" is less than 500 at one/several levels. ');
							dbms_output.put_line('Please increase it to 1000.<br>');
							:e4:=:e4+1;
						  end if;				  
						  if issue12 then
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Profile "OTL: Number of past days for which retrieval considers changes (days)" is less than 8 at one/several levels. ');
							dbms_output.put_line('This is a very small period of time to consider changes for timecards. Recommended value is 365 days.<br>');
							:e4:=:e4+1;
						  end if;					 
						  if issue14 then
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Profile "OTL: Transfer Batch Size" is less than 50 at one/several levels.<br>');
							dbms_output.put_line('Please refer <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1304058.1" target="_blank">Note 1304058.1</a> ');
							dbms_output.put_line('Transfer Time From OTL to BEE Batch Size for Optimal Performance.<br>');
							:e4:=:e4+1;
						  end if;				 
						  if issue17 then
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Profile "PA: Autoapprove Timesheets" is set to Y at one/several levels. ');
							dbms_output.put_line('Any Projects Timecard will be autoapproved regardless of Approval Style in OTL. This overrides OTL setup.<br>');
							:e4:=:e4+1;
						  end if;       
						dbms_output.put_line('</div>');
				  end if;
			end if;
			
			
		end if;		

		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	end if;

EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

-- DateTrack Enabled and HR: Enable DTW4 defaulting for HR shared


declare
    run_type varchar2(20):='&1';
    v_level_id  varchar2(50);
    v_appl_id FND_PROFILE_OPTIONS.APPLICATION_ID%type;
    v_level varchar2(50);
    v_value FND_PROFILE_OPTION_VALUES.PROFILE_OPTION_VALUE%type;
    v_level_value FND_PROFILE_OPTION_VALUES.LEVEL_VALUE%type;
    profile_number number;
    issue1 boolean:=FALSE;
    issue2 boolean:=FALSE;
    
    cursor datetrack is
    select 
    decode(to_char(fpov.level_id),
                  '10001', 'Site',
                  '10002', 'Application') ,
    fpo.APPLICATION_ID,
    fpov.LEVEL_VALUE,
     decode(to_char(fpov.level_id),
                  '10001', 'Site',
                  '10002', nvl(app.application_short_name,to_char(fpov.level_value))),
    DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
    DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
    fpov.PROFILE_OPTION_VALUE)) 
    from FND_PROFILE_OPTIONS fpo,
    FND_PROFILE_OPTIONS_TL fpotl,
    FND_PROFILE_OPTION_VALUES fpov,
    FND_APPLICATION app
    where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME
    and    app.application_id (+) = fpov.level_value
    and fpo.PROFILE_OPTION_NAME like 'DATETRACK:ENABLED'
    and fpotl.PROFILE_OPTION_NAME like 'DATETRACK:ENABLED'
    and fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
    and fpotl.LANGUAGE = 'US'
    and fpov.PROFILE_OPTION_ID = 1208
    and fpov.LEVEL_ID IN (10001,10002)
    and   fpov.LEVEL_VALUE != '804';
    

    cursor enabledtw4 is
    select 
    decode(to_char(fpov.level_id),
                  '10001', 'Site',
                  '10002', 'Application') ,
    fpo.APPLICATION_ID ,
    fpov.LEVEL_VALUE,
     decode(to_char(fpov.level_id),
                  '10001', 'Site',
                  '10002', nvl(app.application_short_name,to_char(fpov.level_value))),
    DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
    DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
    fpov.PROFILE_OPTION_VALUE)) 
    from FND_PROFILE_OPTIONS fpo,
    FND_PROFILE_OPTIONS_TL fpotl,
    FND_PROFILE_OPTION_VALUES fpov,
    FND_APPLICATION app
    where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
    and    app.application_id (+) = fpov.level_value
    and   fpotl.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4' 
    and   fpo.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4'
    and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
    and   fpov.LEVEL_ID IN (10001,10002) 
    and   fpotl.LANGUAGE = 'US' 
    and   fpo.APPLICATION_ID = 800;


	
begin
     if (:hr_status='Shared') then
		select count(1) into profile_number
		from FND_PROFILE_OPTIONS fpo, 
		FND_PROFILE_OPTIONS_TL fpotl, 
		FND_PROFILE_OPTION_VALUES fpov
			where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
			and   fpo.PROFILE_OPTION_NAME like 'DATETRACK:ENABLED' 
			and   fpotl.PROFILE_OPTION_NAME like 'DATETRACK:ENABLED' 
			and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
			and   fpotl.LANGUAGE = 'US' 
			and   fpov.PROFILE_OPTION_VALUE='Y'
			and   fpov.PROFILE_OPTION_ID = 1208
			and   fpov.LEVEL_ID IN (10001,10002) 
			and   fpov.LEVEL_VALUE != '804';
		if profile_number>0 then
            issue1:=TRUE;
    end if;
             
	   
    select count(1) into profile_number
    from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov
		where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
		and   fpotl.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4' 
    and   fpo.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4'
		and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
		and   fpov.LEVEL_ID IN (10001,10002) 
		and   fpotl.LANGUAGE = 'US' 
		and   fpo.APPLICATION_ID = 800
    and fpov.PROFILE_OPTION_VALUE<>'N';
		
		if profile_number>0 then
                issue2:=TRUE;
    end if;
		
   if issue1 then
			:e4:=:e4+1;
			dbms_output.put_line('<DIV class=divItem>');
			dbms_output.put_line('<DIV id="s1sql29b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql29'');" href="javascript:;">&#9654; DateTrack:Enabled</A></DIV>');
							dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql29" style="display:none" >');
							dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('     <B>Incorrect settings</B></font></TD>');
							dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
							dbms_output.put_line('<A class=detail id="s1sql30b" onclick="displayItem2(this,''s1sql30'');" href="javascript:;">&#9654; Show SQL Script</A>');
							dbms_output.put_line('   </TD>');
							dbms_output.put_line(' </TR>');
							dbms_output.put_line(' <TR id="s1sql30" style="display:none">');
							dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
							dbms_output.put_line('       <blockquote><p align="left">');
							dbms_output.put_line('        select   decode(to_char(fpov.level_id),  <br>');   
							dbms_output.put_line('            ''10001'', ''Site'',<br>');
							dbms_output.put_line('         ''10002'', ''Application''),<br>');
							dbms_output.put_line('                     fpo.APPLICATION_ID, fpov.LEVEL_VALUE, <br>'); 
							dbms_output.put_line('                    decode(to_char(fpov.level_id),');
							dbms_output.put_line('                                 ''10001'', ''Site'',');
							dbms_output.put_line('                                 ''10002'', nvl(app.application_short_name,to_char(fpov.level_value))),');
							dbms_output.put_line('                   DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',');
							dbms_output.put_line('                   DECODE(fpov.PROFILE_OPTION_VALUE,''N'',''No'',');
							dbms_output.put_line('                   fpov.PROFILE_OPTION_VALUE)) ');
							dbms_output.put_line('            from FND_PROFILE_OPTIONS fpo,  <br>'); 
							dbms_output.put_line('             FND_PROFILE_OPTIONS_TL fpotl,  <br>'); 
							dbms_output.put_line('             FND_PROFILE_OPTION_VALUES fpov, <br>'); 
							dbms_output.put_line('             FND_APPLICATION app<br>'); 
							dbms_output.put_line('            where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME  <br>'); 
							dbms_output.put_line('            and    app.application_id (+) = fpov.level_value<br>'); 
							dbms_output.put_line('            and   fpo.PROFILE_OPTION_NAME = ''DATETRACK:ENABLED''  <br>'); 
							dbms_output.put_line('            and   fpotl.PROFILE_OPTION_NAME = ''DATETRACK:ENABLED''  <br>'); 
							dbms_output.put_line('            and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID  <br>'); 
							dbms_output.put_line('            and   fpotl.LANGUAGE = ''US''  <br>'); 
							dbms_output.put_line('            and   fpov.PROFILE_OPTION_VALUE=''Y'' <br>'); 
							dbms_output.put_line('            and   fpov.PROFILE_OPTION_ID = 1208 <br>'); 
							dbms_output.put_line('            and   fpov.LEVEL_ID IN (10001,10002)  <br>'); 
							dbms_output.put_line('            and   fpov.LEVEL_VALUE != ''804''; <br>');
		
							dbms_output.put_line('          </blockquote><br>');
							dbms_output.put_line('     </TD>');
							dbms_output.put_line('   </TR>');
							dbms_output.put_line(' <TR>');
							dbms_output.put_line(' <TH><B>Level</B></TD>');
							dbms_output.put_line(' <TH><B>Application ID</B></TD>');
							dbms_output.put_line(' <TH><B>Level Value</B></TD>');
							dbms_output.put_line(' <TH><B>Context</B></TD>');
							dbms_output.put_line(' <TH><B>Actual Incorrect Value (need to change to NULL)</B></TD>');
							  
							:n := dbms_utility.get_time;
							open datetrack;
							  loop
									fetch datetrack into v_level_id ,  v_appl_id , v_level_value, v_level, v_value ;
									EXIT WHEN  datetrack%NOTFOUND;
									dbms_output.put_line('<TR><TD>'||v_level_id||'</TD>'||chr(10)||'<TD>'||v_appl_id||'</TD>'||chr(10)||'<TD>'||v_level_value||'</TD>'||chr(10));
									dbms_output.put_line('<TD>'||v_level||'</TD>'||chr(10)||'<TD>'||v_value||'</TD> </TR>'||chr(10));	  
							  end loop;
							close datetrack;
							
							:n := (dbms_utility.get_time - :n)/100;
							dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							dbms_output.put_line(' </TABLE> </div> '); 
							
							dbms_output.put_line('<div class="diverr">');
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Incorrect profile value for DateTrack:Enabled for above levels.</div><br>');
							
					
		   end if;
		   
	if issue2 then
			:e4:=:e4+1;
			dbms_output.put_line('<DIV class=divItem>');
			dbms_output.put_line('<DIV id="s1sql31b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql31'');" href="javascript:;">&#9654; HR: Enable DTW4 defaulting</A></DIV>');
						  				  
							dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql31" style="display:none" >');
							dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('     <B>Incorrect settings</B></font></TD>');
							dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
							dbms_output.put_line('<A class=detail id="s1sql32b" onclick="displayItem2(this,''s1sql32'');" href="javascript:;">&#9654; Show SQL Script</A>');
							dbms_output.put_line('   </TD>');
							dbms_output.put_line(' </TR>');
							dbms_output.put_line(' <TR id="s1sql32" style="display:none">');
							dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
							dbms_output.put_line('       <blockquote><p align="left">');
							dbms_output.put_line('        select   decode(to_char(fpov.level_id),  <br>');   
							dbms_output.put_line('            ''10001'', ''Site'',<br>');
							dbms_output.put_line('         ''10002'', ''Application''),<br>');
							dbms_output.put_line('                     fpo.APPLICATION_ID, fpov.LEVEL_VALUE, <br>'); 
							dbms_output.put_line('                    decode(to_char(fpov.level_id),');
							dbms_output.put_line('                                 ''10001'', ''Site'',');
							dbms_output.put_line('                                 ''10002'', nvl(app.application_short_name,to_char(fpov.level_value))),');
							dbms_output.put_line('                   DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',');
							dbms_output.put_line('                   DECODE(fpov.PROFILE_OPTION_VALUE,''N'',''No'',');
							dbms_output.put_line('                   fpov.PROFILE_OPTION_VALUE))');
							dbms_output.put_line('            from FND_PROFILE_OPTIONS fpo,  <br>'); 
							dbms_output.put_line('             FND_PROFILE_OPTIONS_TL fpotl,  <br>'); 
							dbms_output.put_line('             FND_PROFILE_OPTION_VALUES fpov, <br>'); 
							dbms_output.put_line('             FND_APPLICATION app<br>'); 
							dbms_output.put_line('            where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME  <br>'); 
							dbms_output.put_line('            and    app.application_id (+) = fpov.level_value<br>'); 
							dbms_output.put_line('            and   fpo.PROFILE_OPTION_NAME = ''PER_ENABLE_DTW4''  <br>'); 
							dbms_output.put_line('            and   fpotl.PROFILE_OPTION_NAME = ''PER_ENABLE_DTW4''  <br>'); 
							dbms_output.put_line('            and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID  <br>'); 
							dbms_output.put_line('            and   fpotl.LANGUAGE = ''US''  <br>'); 
							dbms_output.put_line('            and   fpov.LEVEL_ID IN (10001,10002)  <br>'); 
							dbms_output.put_line('            and   fpov.LEVEL_VALUE = ''800''; <br>');        
							dbms_output.put_line('          </blockquote><br>');
							dbms_output.put_line('     </TD>');
							dbms_output.put_line('   </TR>');
							dbms_output.put_line(' <TR>');
							dbms_output.put_line(' <TH><B>Level</B></TD>');
							dbms_output.put_line(' <TH><B>Application ID</B></TD>');
							dbms_output.put_line(' <TH><B>Level Value</B></TD>');
							dbms_output.put_line(' <TH><B>Context</B></TD>');
							dbms_output.put_line(' <TH><B>Actual Incorrect Value (need to change to N)</B></TD>');
							  
							:n := dbms_utility.get_time;
							open enabledtw4;
							  loop
									fetch enabledtw4 into v_level_id ,  v_appl_id , v_level_value, v_level, v_value ;
									EXIT WHEN  enabledtw4%NOTFOUND;
									dbms_output.put_line('<TR><TD>'||v_level_id||'</TD>'||chr(10)||'<TD>'||v_appl_id||'</TD>'||chr(10)||'<TD>'||v_level_value||'</TD>'||chr(10));
									dbms_output.put_line('<TD>'||v_level||'</TD>'||chr(10)||'<TD>'||v_value||'</TD></TR>'||chr(10));	  
							  end loop;
							close enabledtw4;
							
							:n := (dbms_utility.get_time - :n)/100;
							dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							dbms_output.put_line(' </TABLE> </div> ');
							dbms_output.put_line('<div class="diverr">');
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Incorrect profile value for HR: Enable DTW4 defaulting for above levels.</div>');												
													

			end if;
		
	if issue1 or issue2 then				
			dbms_output.put_line('<div class="diverr">');		
           dbms_output.put_line('Please raise a service request with Oracle Support and refer to this section of output.<br>');             
           dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1075831.1" target="_blank" >Note 1075831.1</a> Within Shared HR Environments What Types of Records Would You Expect to See in HR tables <br>');
           dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1476979.1" target="_blank" >Note 1476979.1</a> Shared HR Implementation - Things to check when doing an Oracle Human Resources Shared HR implementation.');
			dbms_output.put_line('</div>');	  
			dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
    end if;
 
	end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Display Security profile details
declare
	run_type varchar2(20):='&1';
       
    cursor security is
    select security_profile_id, nvl(security_profile_name,'null') from PER_SECURITY_PROFILES 
	order by upper(security_profile_name);
    v_sec_id PER_SECURITY_PROFILES.security_profile_id%type;
	v_sec_name PER_SECURITY_PROFILES.SECURITY_PROFILE_NAME%type;
begin
       	
    if upper(run_type)='ALL'  then
				
			dbms_output.put_line('<a name="security"></a>');
			dbms_output.put_line('<DIV class=divItem>');
			dbms_output.put_line('<DIV id="s1sql49b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql49'');" href="javascript:;">&#9654; Security Profile Details</A></DIV>');
						
                        dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql49" style="display:none" >');
                        dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                        dbms_output.put_line('     <B>Security Profile Details</B></font></TD>');
                        dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                        dbms_output.put_line('<A class=detail id="s1sql50b" onclick="displayItem2(this,''s1sql50'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        dbms_output.put_line('   </TD>');
                        dbms_output.put_line(' </TR>');
                        dbms_output.put_line(' <TR id="s1sql50" style="display:none">');
                        dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
                        dbms_output.put_line('       <blockquote><p align="left">');
                        dbms_output.put_line('        select security_profile_id, security_profile_name from PER_SECURITY_PROFILES  <br>');   
                        dbms_output.put_line('        order by upper(security_profile_name);<br>');  
    
                        dbms_output.put_line('          </blockquote><br>');
                        dbms_output.put_line('     </TD>');
                        dbms_output.put_line('   </TR>');
                        dbms_output.put_line(' <TR>');
                        dbms_output.put_line(' <TH><B>Security Profile ID</B></TD>');                        
                        dbms_output.put_line(' <TH><B>Security Profile Name</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open security;
                          loop
                                fetch security into v_sec_id ,  v_sec_name;
                                EXIT WHEN  security%NOTFOUND;
                                dbms_output.put_line('<TR><TD>'||v_sec_id||'</TD>'||chr(10)||'<TD>'||v_sec_name||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close security;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       

						dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql49'');" href="javascript:;">Collapse section</a></td></tr>');
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						dbms_output.put_line(' </TABLE> </div> ');
						
						 dbms_output.put_line('<div class="divok">');
						 dbms_output.put_line('<font color="blue">Advice:</font> Please review ');
						 dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=394083.1" target="_blank">Note 394083.1</a> ');
						 dbms_output.put_line('Understanding and Using HRMS Security in Oracle HRMS<br>');
						 dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1266051.1" target="_blank">Note 1266051.1</a> ');
						 dbms_output.put_line('Troubleshooting eBusiness Suite HRMS Security Issues<br>');
						 dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1385633.1" target="_blank">Note 1385633.1</a> ');
						 dbms_output.put_line('Security, MultiOrg, and Multi Org Access Control(MOAC) support in relation to Oracle Human Resources applications<br>');		
						 dbms_output.put_line('</div>');
						dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR><br>');						
			            
       end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

-- Display International Payroll usage
declare
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';   
    cursor c_international is
    SELECT   fcr.argument1 international_legislation_code
				,ftv.territory_short_name, fcr.request_date
		FROM     fnd_concurrent_requests fcr
				,fnd_concurrent_programs fcp
				,fnd_territories_tl ftv
		WHERE    fcr.concurrent_program_id = fcp.concurrent_program_id
			 AND ftv.territory_code = fcr.argument1
			 AND ftv.LANGUAGE='US'
			 AND fcp.concurrent_program_name = 'PYINTSTU'; 
	
    v_code fnd_concurrent_requests.argument1%type;
	v_name fnd_territories_tl.territory_short_name%type;
	v_date fnd_concurrent_requests.request_date%type;
begin
       	
    if upper(run_type)='ALL' and upper(product) in ('ALL','PAY','HR')  then
				
			dbms_output.put_line('<a name="international"></a>');						
						dbms_output.put_line('<DIV class=divItem>');
						dbms_output.put_line('<DIV id="s1sql63b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql63'');" href="javascript:;">&#9654; International Payroll Usage</A></DIV>');
                        dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql63" style="display:none" >');
                        dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                        dbms_output.put_line('     <B>Concurrent process International HRMS Setup</B></font></TD>');
                        dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                        dbms_output.put_line('<A class=detail  id="s1sql54b"  onclick="displayItem2(this,''s1sql64'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        dbms_output.put_line('   </TD>');
                        dbms_output.put_line(' </TR>');
                        dbms_output.put_line(' <TR id="s1sql64" style="display:none">');
                        dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
                        dbms_output.put_line('       <blockquote><p align="left">');
                        dbms_output.put_line('        SELECT   fcr.argument1 international_legislation_code<br>');
						dbms_output.put_line('        ,ftv.territory_short_name, fcr.request_date<br>');
						dbms_output.put_line('        FROM     fnd_concurrent_requests fcr<br>');
						dbms_output.put_line('        ,fnd_concurrent_programs fcp<br>');
						dbms_output.put_line('        ,fnd_territories_tl ftv<br>');
						dbms_output.put_line('        WHERE    fcr.concurrent_program_id = fcp.concurrent_program_id<br>');
						dbms_output.put_line('        AND ftv.territory_code = fcr.argument1<br>');
						dbms_output.put_line('        AND ftv.LANGUAGE=''US''<br>');
						dbms_output.put_line('        AND fcp.concurrent_program_name = ''PYINTSTU'';	<br>');		   
                        dbms_output.put_line('          </blockquote><br>');
                        dbms_output.put_line('     </TD>');
                        dbms_output.put_line('   </TR>');
                        dbms_output.put_line(' <TR>');
                        dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Country code</B></TD>');                        
                        dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Country Name</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Date when concurrent request was performed</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open c_international;
                          loop
                                fetch c_international into v_code, v_name, v_date;
                                EXIT WHEN  c_international%NOTFOUND;
                                dbms_output.put_line('<TR><TD>'||v_code||'</TD>'||chr(10)||'<TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_date||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close c_international;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						dbms_output.put_line(' </TABLE> </div> ');			
						
						
						dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						
			            
       end if;
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;
/



-- Display Pay Legislation Rules
declare
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';   
    cursor rules is
    select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules 
	order by LEGISLATION_CODE;
    V_LEG pay_legislation_rules.LEGISLATION_CODE%type;
	V_RULE_TYPE pay_legislation_rules.RULE_TYPE%type;
	V_RULE_MODE pay_legislation_rules.RULE_MODE%type;
begin
       	
    if upper(run_type)='ALL' and upper(product) in ('ALL','PAY')  then
				
			dbms_output.put_line('<a name="rules"></a>');						
						dbms_output.put_line('<DIV class=divItem>');
						dbms_output.put_line('<DIV id="s1sql53b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql53'');" href="javascript:;">&#9654; Pay Legislation Rules</A></DIV>');
                        dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql53" style="display:none" >');
                        dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                        dbms_output.put_line('     <B>Pay Legislation Rules</B></font></TD>');
                        dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                        dbms_output.put_line('<A class=detail  id="s1sql54b"  onclick="displayItem2(this,''s1sql54'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        dbms_output.put_line('   </TD>');
                        dbms_output.put_line(' </TR>');
                        dbms_output.put_line(' <TR id="s1sql54" style="display:none">');
                        dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
                        dbms_output.put_line('       <blockquote><p align="left">');
                        dbms_output.put_line('        select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules  <br>');   
                        dbms_output.put_line('        order by LEGISLATION_CODE;<br>');     
                        dbms_output.put_line('          </blockquote><br>');
                        dbms_output.put_line('     </TD>');
                        dbms_output.put_line('   </TR>');
                        dbms_output.put_line(' <TR>');
                        dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Legislation</B></TD>');                        
                        dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Rule Type</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Rule Mode</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open rules;
                          loop
                                fetch rules into v_leg, v_rule_type, v_rule_mode;
                                EXIT WHEN  rules%NOTFOUND;
                                dbms_output.put_line('<TR><TD>'||v_leg||'</TD>'||chr(10)||'<TD>'||v_rule_type||'</TD>'||chr(10)||'<TD>'||v_rule_mode||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close rules;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       

						dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql54'');" href="javascript:;">Collapse section</a></td></tr>');
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						dbms_output.put_line(' </TABLE> </div> ');			
						
						
						dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						
			            
       end if;
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;
/


-- Display pay_trigger_events
declare
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';	
	v_table pay_trigger_events.table_name%type;
    v_trigger pay_trigger_events.short_name%type;
	v1 pay_trigger_events.generated_flag%type;
	v2 pay_trigger_events.enabled_flag%type;
	v3 pay_trigger_components.enabled_flag%type;
    no_triggers number;
 	issue boolean := FALSE;
  cursor flag_triggers is
	  select pte.table_name, pte.short_name, pte.generated_flag,pte.enabled_flag, ptc.enabled_flag 
		from pay_trigger_events pte,
		pay_trigger_components ptc
		where (short_name like 'PER_%'
			 OR short_name like 'PAY_%')
		and pte.event_id = ptc.event_id(+)
		and (pte.generated_flag<>'Y' or pte.enabled_flag<>'Y' or ptc.enabled_flag<>'Y')
		order by pte.table_name;  

begin
	if upper(product) in ('PAY', 'ALL') then 
	  select count(1) into no_triggers from pay_trigger_events pte,
		pay_trigger_components ptc
		where (short_name like 'PER_%'
			 OR short_name like 'PAY_%')
		and pte.event_id = ptc.event_id(+)
		and (pte.generated_flag<>'Y' or pte.enabled_flag<>'Y' or ptc.enabled_flag<>'Y');
		if no_triggers>0 then
						issue:=TRUE;
		end if;
        
			if issue or upper(run_type)='ALL' then
				dbms_output.put_line(' <a name="pay_trigger_events"></a>');
				dbms_output.put_line('<DIV class=divItem>');
				dbms_output.put_line('<DIV id="s1sql51b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql51'');" href="javascript:;">&#9654; Pay Triggers Events</A></DIV>');		
				dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql51" style="display:none" >');
				dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
				dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
				dbms_output.put_line('     <B>Triggers with flag not set to Y:</B></font></TD>');
				dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
				dbms_output.put_line('<A class=detail  id="s1sql52b"  onclick="displayItem2(this,''s1sql52'');" href="javascript:;">&#9654; Show SQL Script</A>');
				dbms_output.put_line('   </TD>');
				dbms_output.put_line(' </TR>');
				dbms_output.put_line(' <TR id="s1sql52" style="display:none">');
				dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
				dbms_output.put_line('       <blockquote><p align="left">');
				
				dbms_output.put_line('          select pte.table_name, pte.short_name, pte.generated_flag,pte.enabled_flag, ptc.enabled_flag <br>');
				dbms_output.put_line('          from pay_trigger_events pte,<br>');
				dbms_output.put_line('          pay_trigger_components ptc<br>');
				dbms_output.put_line('          where (short_name like ''PER_%''<br>');
				dbms_output.put_line('          	 OR short_name like ''PAY_%'')<br>');
				dbms_output.put_line('          and pte.event_id = ptc.event_id(+)<br>');
				dbms_output.put_line('          and (pte.generated_flag<>''Y'' or pte.enabled_flag<>''Y'' or ptc.enabled_flag<>''Y'')<br>');
				dbms_output.put_line('          order by pte.table_name; <br>');

				dbms_output.put_line('          </blockquote><br>');
				dbms_output.put_line('     </TD>');
				dbms_output.put_line('   </TR>');
				dbms_output.put_line(' <TR>');
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Table name</B></TD>');		
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Trigger Name</B></TD>');
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Generated flag</B></TD>');
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Enabled flag - events</B></TD>');
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Enabled flag - components</B></TD>');
			
				:n := dbms_utility.get_time;
			
				open flag_triggers;
					  loop
						 fetch flag_triggers into v_table,v_trigger,v1,v2,v3;
						 EXIT WHEN  flag_triggers%NOTFOUND;
						 dbms_output.put_line('<TR><TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD>'||chr(10));
						 if v1<>'Y' then
							dbms_output.put_line('<TD><font color="red">'||v1||'</font></TD>'||chr(10));
						 else
							dbms_output.put_line('<TD>'||v1||'</TD>'||chr(10));
						 end if;
						 if v2<>'Y' then
							dbms_output.put_line('<TD><font color="red">'||v2||'</font></TD>'||chr(10));
						 else
							dbms_output.put_line('<TD>'||v2||'</TD>'||chr(10));
						 end if;
						 if v3<>'Y' then
							dbms_output.put_line('<TD><font color="red">'||v3||'</font></TD></TR>'||chr(10));
						 else
							dbms_output.put_line('<TD>'||v3||'</TD>'||chr(10));
						 end if;								 
					  end loop;
				close flag_triggers;    
			 
				:n := (dbms_utility.get_time - :n)/100;
				dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
				dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
				dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
				dbms_output.put_line(' </TABLE> </div> ');
				
				
				if issue  then
					dbms_output.put_line('<div class="divwarn">');
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You have trigger(s) with flag not set to Y (not set or set to N).<br>');		
					dbms_output.put_line('</div>');
					:w4:=:w4+1;
				elsif upper(run_type)='ALL' then             
					dbms_output.put_line('<br><div class="divok">');
					dbms_output.put_line('<img class="check_ico">OK! All triggers have flag set on Y.<br>');
					dbms_output.put_line('</div>');
				end if;
				
				
				dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
			end if;	
	end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



-- PAY Action parameters


declare
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_pay_name pay_action_parameters.parameter_name%type; 
	v_pay_value pay_action_parameters.parameter_value%type;
	v_min_ini_trans number;
	v_cpu number;
	v_rows number;
	status_leg varchar2(2);
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue8 boolean := FALSE;
	issue9 boolean := FALSE;
	issue10 boolean := FALSE;
	cursor pay_action is
	select parameter_name, nvl(parameter_value,'null') 
      from pay_action_parameters
	  order by parameter_name;

begin

dbms_output.put_line(' <a name="ssp"></a>');
select count(1) into v_rows from ssp_temp_affected_rows;
if upper(run_type)='ALL' or v_rows>0 then
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql84b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql84'');" href="javascript:;">&#9654; SSP_TEMP_AFFECTED_ROWS</A></DIV>');
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql84" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>SSP_TEMP_AFFECTED_ROWS rows</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail  id="s1sql10b"  onclick="displayItem2(this,''s1sql85'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD></TR>');
		dbms_output.put_line(' <TR id="s1sql85" style="display:none">');
		dbms_output.put_line('    <TD colspan="1" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select count(1) from SSP_TEMP_AFFECTED_ROWS');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line(' </TD></TR><TR>');
		dbms_output.put_line(' <TH><font face="Calibri"><B>Count of rows</B></TD>');	
		:n := dbms_utility.get_time;
		dbms_output.put_line('<TR><TD>'||v_rows||'</TD></TR>'||chr(10));			
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
	
		if v_rows>0 then
			dbms_output.put_line('<div class="divwarn">');
			dbms_output.put_line('<img class="warn_ico">For Oracle Support: SSP_TEMP_AFFECTED_ROWS table has rows.</div>');
			:w4:=:w4+1;
		else
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('OK! No rows in SSP_TEMP_AFFECTED_ROWS<br>');
				dbms_output.put_line('</div>');
		end if;			
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
	end if;
	

dbms_output.put_line(' <a name="pay_action"></a>');

if upper(product)='PAY' or upper(product)='ALL' then
	
	SELECT SUBSTR(value, 1, 10)
						into v_cpu
						FROM v$parameter
						WHERE name = 'cpu_count';
	select decode(status, null,'N','I')
						into status_leg
						from hr_legislation_installations
						where substr(application_short_name,1,4)='PAY'
						and  Legislation_code = 'US';
						
	select count(1) into v_rows from pay_action_parameters where parameter_name='RANGE_PERSON_ID';
	if v_rows=0 then
		issue1:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='RANGE_PERSON_ID';
		if v_pay_value <>'Y' then
			issue1:=TRUE;
		end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name='LOW_VOLUME';
	if v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='LOW_VOLUME';
		if v_pay_value <>'N' then
			issue2:=TRUE;
		end if;
	end if;
	
	if status_leg='I' then
			select count(1) into v_rows from pay_action_parameters where parameter_name='TAX_LIBRARIES';
			if v_rows=0 then
				issue3:=TRUE;
			elsif v_rows=1 then
				select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='TAX_LIBRARIES';
				if v_pay_value is NULL then
					issue3:=TRUE;
				end if;
			end if;
			select count(1) into v_rows from pay_action_parameters where parameter_name='TAX_DATA';
			if v_rows=0 then
				issue3:=TRUE;
			elsif v_rows=1 then
				select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='TAX_DATA';
				if v_pay_value is NULL then
					issue3:=TRUE;
				end if;
			end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name='THREADS';
	v_pay_value:=1;
	if v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='THREADS';
	elsif v_rows=0 then
		v_pay_value:=1;
	end if;
	if v_pay_value<1.5*v_cpu or v_pay_value>2*v_cpu then
		issue5:=TRUE;
	end if;						
	SELECT min(ini_trans)
						into v_min_ini_trans
						FROM DBA_TABLES
						WHERE table_name IN ('FF_ARCHIVE_ITEMS'
                          ,'FF_ARCHIVE_ITEM_CONTEXTS'
                          ,'PAY_ACTION_INFORMATION'
                          ,'PAY_ASSIGNMENT_ACTIONS'
                          ,'PAY_ASSIGNMENT_LATEST_BALANCES'
                          ,'PAY_BALANCE_CONTEXT_VALUES'
                          ,'PAY_COSTS'
                          ,'PAY_DEFINED_BALANCES'
                          ,'PAY_ELEMENT_ENTRIES_F'
                          ,'PAY_ELEMENT_ENTRY_VALUES_F'
                          ,'PAY_INPUT_VALUES_F'
                          ,'PAY_PAYROLL_ACTIONS'
                          ,'PAY_PERIODS_OF_SERVICE'
                          ,'PAY_PERSON_LATEST_BALANCES'
                          ,'PAY_POPULATION_RANGES'
                          ,'PAY_PRE_PAYMENTS'
                          ,'PAY_RUN_BALANCES'
                          ,'PAY_RUN_RESULTS'
                          ,'PAY_RUN_RESULT_VALUES'
                          ,'PAY_US_RPT_TOTALS'
                          ,'PER_ALL_ASSIGNMENTS_F'
                          ,'PER_ALL_PEOPLE_F');
	if v_pay_value>v_min_ini_trans then
		issue6:=TRUE;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'RR%BUFFER%SIZE';
	if v_rows=0 then
		issue7:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'RR%BUFFER%SIZE';
		if v_pay_value <100 then
			issue7:=TRUE;
		end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'RRV%BUFFER%SIZE';
	if v_rows=0 then
		issue8:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'RRV%BUFFER%SIZE';
		if v_pay_value <100 then
			issue8:=TRUE;
		end if;
	end if;	
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'BAL%BUFFER%SIZE';
	if v_rows=0 then
		issue9:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'BAL%BUFFER%SIZE';
		if v_pay_value <100 then
			issue9:=TRUE;
		end if;
	end if;	
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'EE%BUFFER%SIZE';
	if v_rows=0 then
		issue10:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like'EE%BUFFER%SIZE';
		if v_pay_value <100 then
			issue10:=TRUE;
		end if;
	end if;	
	
	if upper(run_type)='ALL' or issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 then
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql9b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql9'');" href="javascript:;">&#9654; PAY Action Parameters</A></DIV>');
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql9" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>PAY action parameters</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail  id="s1sql10b"  onclick="displayItem2(this,''s1sql10'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql10" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select parameter_name, parameter_value <br>');
		dbms_output.put_line('          from pay_action_parameters<br>');
		dbms_output.put_line('			order by parameter_name');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD>');
	
		:n := dbms_utility.get_time;
		
		open pay_action;
		loop
			fetch pay_action into v_pay_name,v_pay_value;
			EXIT WHEN  pay_action%NOTFOUND;
			dbms_output.put_line('<TR><TD>'||v_pay_name||'</TD>'||chr(10)||'<TD>');
			dbms_output.put_line(v_pay_value);
			dbms_output.put_line('</TD></TR>'||chr(10));
          
		end loop;
		close pay_action;

		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql9'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
	
		if issue1 or issue2 or issue3 or issue4 then
			dbms_output.put_line('<div class="diverr">');
			if issue1 then
				dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please set RANGE_PERSON_ID to Y<br>');
				:e4:=:e4+1;
			end if;
			
			if issue2 then
				dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please set LOW_VOLUME<br>');
				:e4:=:e4+1;
			end if;
			
			if issue3 then
				dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please set TAX_LIBRARIES<br>');
				:e4:=:e4+1;
			end if;
			
			if issue4 then
				dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please set TAX_DATA<br>');
				:e4:=:e4+1;
			end if;
			dbms_output.put_line('</div>');
		end if;
		
		if issue5 or issue6 or issue7 or issue8 or issue9 or issue10 then
			dbms_output.put_line('<div class="divwarn">');
			if issue5 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please set Threads to 1.5 to 2 times the number of processors, ');
				dbms_output.put_line('meaning between '||ceil(1.5*v_cpu)||' and '||ceil(2*v_cpu)||' <br>');
				dbms_output.put_line('<font color="blue">Advice:</font> Check <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=359354.1" target="_blank">Note 359354.1</a> ');
				dbms_output.put_line('How to Determine the Best Setting for the THREADS Parameter in the Pay_Action_Parameters Table<br>');
				:w4:=:w4+1;
			end if;
			
			if issue6 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please ensure the number of threads set in PAY_ACTION_PARAMETERS is the same ');
				dbms_output.put_line('or lower than the ini_trans on hot PAY tables <br>');
				:w4:=:w4+1;
			end if;
			
			if issue7 or issue8 or issue9 or issue10 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If trace files show differences between execute and fetch timings, then worth having a look at buffer sizes:<br>');
				if issue7 then
					dbms_output.put_line(' - Try setting RR BUFFER SIZE to 100.<br>');
				end if;
				if issue8 then
					dbms_output.put_line(' - Try setting RRV BUFFER SIZE to 100.<br>');
				end if;
				if issue9 then
					dbms_output.put_line(' - Try setting BAL BUFFER SIZE to 100.<br>');
				end if;
				if issue10 then
					dbms_output.put_line(' - Try setting EE BUFFER SIZE to 100.<br>');
				end if;
				:w4:=:w4+1;
			end if;
			
			dbms_output.put_line('</div>');
		end if;
		
		dbms_output.put_line('<div class="divok">');
		dbms_output.put_line('<font color="blue">Advice:</font> Please review:<br> ');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=549367.1" target="_blank">Note 549367.1</a> ');
		dbms_output.put_line('Oracle Human Resources Payroll PAY_ACTION_PARAMETERS Comprehensive Overview<br>');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=226987.1" target="_blank">Note 226987.1</a> ');
		dbms_output.put_line('Oracle 11i and R12 Human Resources and Benefits Tuning and System Health Checks<br>');
		dbms_output.put_line('</div>');
		
		if (not issue1) and (not issue2) and (not issue3) and (not issue4) and (not issue5) and (not issue6) and (not issue7) and (not issue8) and (not issue9) and (not issue10) then
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('Verified parameters are correctly set<br>');
				dbms_output.put_line('</div>');
		end if;	
		
		
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
	end if;
	

	
end if;

EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;
/


-- Setup Business Group settings


declare
    run_type varchar2(20):='&1';
    bg_id number;
    org_id number;
    org_name HR_ALL_ORGANIZATION_UNITS.NAME%type;
    legislation PER_BUSINESS_GROUPS.LEGISLATION_CODE%type;
    currency PER_BUSINESS_GROUPS.CURRENCY_CODE%type;
    profile_number number;
    issue1 boolean := FALSE;
    issue2 boolean := FALSE;
    issue3 boolean := FALSE;
	cursor c_bg is
		SELECT o.business_group_id,otl.name,o.organization_id,o3.ORG_INFORMATION9 legislation_code
			,hr_general_utilities.get_lookup_meaning('EMP_NUM_GEN_METHOD',o3.org_information2)
			,hr_general_utilities.get_lookup_meaning('APL_NUM_GEN_METHOD',o3.org_information3)
			,hr_general_utilities.get_lookup_meaning('CWK_NUM_GEN_METHOD',o3.org_information16)
			,o3.ORG_INFORMATION10 currency_code,o4.ORG_INFORMATION2 enabled_flag ,to_char(o.date_from , 'DD-MON-YYYY'),to_char(o.date_to, 'DD-MON-YYYY')
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;         
	  v_bg_id HR_ALL_ORGANIZATION_UNITS.BUSINESS_GROUP_ID%type;
	  v_bg_id_old HR_ALL_ORGANIZATION_UNITS.BUSINESS_GROUP_ID%type;
	  v_org_id HR_ALL_ORGANIZATION_UNITS.ORGANIZATION_ID%type;
	  v_name HR_ALL_ORGANIZATION_UNITS.NAME%type;
	  v_leg PER_BUSINESS_GROUPS.LEGISLATION_CODE%type;
	  v_emp fnd_lookups.meaning%type;
	  v_apl fnd_lookups.meaning%type;
	  v_cwk fnd_lookups.meaning%type;
	  v_cur PER_BUSINESS_GROUPS.CURRENCY_CODE%type;
	  v_enabled PER_BUSINESS_GROUPS.ENABLED_FLAG%type;
	  v_date_from varchar2(15);
	  v_date_to varchar2(15);
	  v_hr varchar2(3);   
	  
-- check if is hr org
FUNCTION bg_hr_org_ck (p_org_id IN integer)
  RETURN varchar2
IS
  l_dummy   varchar2 (3);
BEGIN
  SELECT   1
  INTO     l_dummy
  FROM     hr_organization_information hoi
  WHERE    1 = 1
       AND hoi.org_information_context = 'CLASS'
       AND org_information1 = 'HR_ORG'
       AND organization_id = p_org_id;

  l_dummy     := 'Yes';
  return l_dummy;
EXCEPTION
  WHEN no_data_found
  THEN
    l_dummy     := 'No';
    return l_dummy;
END;       

begin
   
	select count(1) into profile_number
		FROM HR_ALL_ORGANIZATION_UNITS O , 
		HR_ALL_ORGANIZATION_UNITS_TL OTL , 
		HR_ORGANIZATION_INFORMATION O2 ,
		HR_ORGANIZATION_INFORMATION O3 , 
		HR_ORGANIZATION_INFORMATION O4 
		WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
		AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
		AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
		AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
		AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
		AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
		AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
		AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
		AND OTL.LANGUAGE = 'US'
		and O.ORGANIZATION_ID=0;
		if profile_number>0 then
             select o.business_group_id, 
             o.organization_id, 
             otl.name, 
             o3.ORG_INFORMATION9, 
             o3.ORG_INFORMATION10
              into bg_id,org_id,org_name,legislation,currency
            FROM HR_ALL_ORGANIZATION_UNITS O , 
				HR_ALL_ORGANIZATION_UNITS_TL OTL , 
				HR_ORGANIZATION_INFORMATION O2 ,
				HR_ORGANIZATION_INFORMATION O3 , 
				HR_ORGANIZATION_INFORMATION O4 
				WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
				AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
				AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
				AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
				AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
				AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
				AND OTL.LANGUAGE = 'US'
				and O.ORGANIZATION_ID=0;
            
            if legislation<>'US' then
                issue1:=TRUE;
            end if;
            if currency<>'USD' then
                issue2:=TRUE;
            end if;
            if org_name<>'Setup Business Group' then
                issue3:=TRUE;
            end if;   
            
                
       end if;
	    if upper(run_type)='ALL' or issue1 or issue2 or issue3 then
				
                  dbms_output.put_line('<a name="setup"></a>');
                 
				 		dbms_output.put_line('<DIV class=divItem>');
						dbms_output.put_line('<DIV id="s1sql65b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql65'');" href="javascript:;">&#9654; Business Group Details</A></DIV>');		
						dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql65" style="display:none" >');
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line('   <TH COLSPAN=11 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('     <B>Business Group details:</B></font></TD>');
						dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
						dbms_output.put_line('<A class=detail  id="s1sql66b"  onclick="displayItem2(this,''s1sql66'');" href="javascript:;">&#9654; Show SQL Script</A>');
						dbms_output.put_line('   </TD>');
						dbms_output.put_line(' </TR>');
						dbms_output.put_line(' <TR id="s1sql66" style="display:none">');
						dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="11" height="60">');
						dbms_output.put_line('       <blockquote><p align="left">');			
						dbms_output.put_line('SELECT o.business_group_id,otl.name,o.organization_id,o3.ORG_INFORMATION9 legislation_code<br>');
						dbms_output.put_line(',hr_general_utilities.get_lookup_meaning(''EMP_NUM_GEN_METHOD'',o3.org_information2)<br>');
						dbms_output.put_line(',hr_general_utilities.get_lookup_meaning(''APL_NUM_GEN_METHOD'',o3.org_information3)<br>');
						dbms_output.put_line(',hr_general_utilities.get_lookup_meaning(''CWK_NUM_GEN_METHOD'',o3.org_information16)<br>');
						dbms_output.put_line(',o3.ORG_INFORMATION10 currency_code,o4.ORG_INFORMATION2 enabled_flag ,o.date_from ,o.date_to<br>');
						dbms_output.put_line('FROM HR_ALL_ORGANIZATION_UNITS O,HR_ALL_ORGANIZATION_UNITS_TL OTL ,HR_ORGANIZATION_INFORMATION O2 ,HR_ORGANIZATION_INFORMATION O3 , HR_ORGANIZATION_INFORMATION O4 <br>');
						dbms_output.put_line('WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) <br>');
						dbms_output.put_line('AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID <br>');
						dbms_output.put_line('AND O3.ORG_INFORMATION_CONTEXT = ''Business Group Information'' AND O2.ORG_INFORMATION_CONTEXT (+) = ''Work Day Information'' <br>');
						dbms_output.put_line('AND O4.ORG_INFORMATION_CONTEXT = ''CLASS'' AND O4.ORG_INFORMATION1 = ''HR_BG'' AND O4.ORG_INFORMATION2 = ''Y'' AND OTL.LANGUAGE = ''US''<br>');			
						dbms_output.put_line('ORDER BY   1;<br>');							
						dbms_output.put_line('          </blockquote><br>');
						dbms_output.put_line('     </TD>');
						dbms_output.put_line('   </TR>');
						dbms_output.put_line(' <TR>');						
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Business Unit ID</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Organization ID</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Organization Name</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Legislation Code</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Employee number generation</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Applicant number generation</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Contingent worker numb gen</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Currency Code</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Enabled Flag</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Date From</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Date To</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Is HR ORG</B></TD>');						
						
						:n := dbms_utility.get_time;
						 open c_bg;
						  loop
							fetch c_bg into v_bg_id,v_name,v_org_id,v_leg,v_emp,v_apl,v_cwk,v_cur,v_enabled,v_date_from,v_date_to;					
							EXIT WHEN  c_bg%NOTFOUND;
							v_hr:= bg_hr_org_ck(v_org_id);
							dbms_output.put_line('<TR><TD>'||v_bg_id||'</TD>'||chr(10)||'<TD>'||v_org_id||'</TD>'||chr(10));							
							dbms_output.put_line('<TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_leg||'</TD>'||chr(10));
							dbms_output.put_line('<TD>'||v_emp||'</TD>'||chr(10)||'<TD>'||v_apl||'</TD>'||chr(10));
								dbms_output.put_line('<TD>'||v_cwk||'</TD>'||chr(10)||'<TD>'||v_cur||'</TD>'||chr(10)||'<TD>'||v_enabled||'</TD>'||chr(10));
								dbms_output.put_line('<TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_hr||'</TD></TR>'||chr(10));	
						  end loop;
						  close c_bg;
						  
						  :n := (dbms_utility.get_time - :n)/100;
					dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql65'');" href="javascript:;">Collapse section</a></td></tr>');
					dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
					dbms_output.put_line(' <TH COLSPAN=11 bordercolor="#DEE6EF"><font face="Calibri">');
					dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
					dbms_output.put_line(' </TABLE> </div> ');
				
				if issue1 or issue2 or issue3 then
					 dbms_output.put_line('<div class="diverr">');
					  if issue1 then
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Current legislation is ' || legislation || ' (is not US).');
							dbms_output.put_line(' Changing the Legislation of the Setup Business Group is never allowed under any condition!<br>');
							:e4:=:e4+1;
					  end if;
					  if issue2 then
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Current currency is ' || currency || ' (is not USD).');
							dbms_output.put_line(' Changing the Currency of the Setup Business Group is never allowed under any condition!<br>');
							:e4:=:e4+1;
					  end if;
					  if issue3 then
							dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Current organization name for Setup Business Group is ' || org_name || ' (is not Setup Business Group).');
							dbms_output.put_line(' Setup Business Group Name should not be changed!<br>');
							:e4:=:e4+1;
					  end if;				  
                        dbms_output.put_line('Please raise a service request with Oracle Support and refer to this section of output.<br>');        
                        dbms_output.put_line('Please review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=815934.1" target="_blank" >Note 815934.1</a> ');
						dbms_output.put_line('After Upgrade - Setup Business Group Name Reverts Back To Setup Business Group<br>');
                        dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=796593.1" target="_blank" >Note 796593.1</a> ');
						dbms_output.put_line('Can the Setup Business Group name be Changed? ');
						dbms_output.put_line('</div>');
                  end if;
                 				  
				  
                  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
            end if;
           
	
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Display Employee numbering
declare
    run_type varchar2(20):='&1';
	product varchar2(20):='&2';
    issue1 boolean := FALSE;
    issue2 boolean := FALSE;
	v_rows number;
	cursor c_package is
		select OWNER, NAME, TEXT   from   ALL_SOURCE
		   where  UPPER(NAME) like UPPER('%NUMBER_GENERATION%')
		   and    OWNER = 'APPS'   and    TEXT like '%$Header%'
		   order  by NAME;
	v_owner ALL_SOURCE.OWNER%type;
	v_name ALL_SOURCE.NAME%type;
	v_text ALL_SOURCE.TEXT%type;
	cursor c_formula is
		select FUNCTION_ID,CLASS,NAME,BUSINESS_GROUP_ID,DATA_TYPE,DEFINITION,LAST_UPDATED_BY,LAST_UPDATE_DATE,LEGISLATION_CODE,DESCRIPTION 
		from FF_FUNCTIONS_V 
		   where UPPER(DATA_TYPE) = UPPER('number') 
		   and UPPER(DEFINITION) like UPPER('%NUM%GEN%');	 
	v_funct FF_FUNCTIONS_V.FUNCTION_ID%type;
	v_class FF_FUNCTIONS_V.CLASS%type;
	v_name2 FF_FUNCTIONS_V.NAME%type;
	v_bg FF_FUNCTIONS_V.BUSINESS_GROUP_ID%type;	
	v_bg_old FF_FUNCTIONS_V.BUSINESS_GROUP_ID%type;	
	v_date_type FF_FUNCTIONS_V.DATA_TYPE%type;
	v_definition FF_FUNCTIONS_V.DEFINITION%type;
	v_lby FF_FUNCTIONS_V.LAST_UPDATED_BY%type;
	v_ldate FF_FUNCTIONS_V.LAST_UPDATE_DATE%type;
	v_leg FF_FUNCTIONS_V.LEGISLATION_CODE%type;
	v_desc FF_FUNCTIONS_V.DESCRIPTION%type;
	cursor c_next is
		  SELECT BUSINESS_GROUP_ID, TYPE, NEXT_VALUE 
		   FROM PER_NUMBER_GENERATION_CONTROLS
		   WHERE TYPE IN ('EMP','APL', 'CWK')
		   order by 1,2;
	v_type PER_NUMBER_GENERATION_CONTROLS.TYPE%type;
	v_next PER_NUMBER_GENERATION_CONTROLS.NEXT_VALUE%type;
	
	v_max_e_no varchar2(50);
	v_max_a_no varchar2(50);
	v_max_n_no varchar2(50);
	
begin
    if upper(product) in ('HR','SSHR','ALL') then
	
	select count(1) into v_rows from   ALL_SOURCE
		   where  UPPER(NAME) like UPPER('%NUMBER_GENERATION%')
		   and    OWNER = 'APPS'
		   and    TEXT like '%$Header%';
	if v_rows>0 then
		issue1:=true;
	end if;
    select count(1) into v_rows from FF_FUNCTIONS_V 
		   where UPPER(DATA_TYPE) = UPPER('number') 
		   and UPPER(DEFINITION) like UPPER('%NUM%GEN%'); 
	if v_rows>0 then
		issue1:=true;
	end if;
	
    if upper(run_type)='ALL' or issue1 or issue2 then
		dbms_output.put_line('<a name="employee"></a>');
                 
				 		dbms_output.put_line('<DIV class=divItem>');
						dbms_output.put_line('<DIV id="s1sql67b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql67'');" href="javascript:;">&#9654; Employee Numbering Details</A></DIV>');		
						dbms_output.put_line('<DIV id="s1sql67" style="display: none;">');
						
						if issue1 then						
							dbms_output.put_line('<A class=detail onclick="displayItem(this,''s1sql68'');" href="javascript:;">      &#9654; Custom Number Generation Packages</A>');
							dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql68" style="display:none" >');
							dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('     <B>Custom Number Generation Packages:</B></font></TD>');
							dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
							dbms_output.put_line('<A class=detail  id="s1sql69b"  onclick="displayItem2(this,''s1sql69'');" href="javascript:;">&#9654; Show SQL Script</A>');
							dbms_output.put_line('   </TD>');
							dbms_output.put_line(' </TR>');
							dbms_output.put_line(' <TR id="s1sql69" style="display:none">');
							dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
							dbms_output.put_line('       <blockquote><p align="left">');			
							dbms_output.put_line('               select OWNER, NAME, TEXT   from   ALL_SOURCE<br>');
							dbms_output.put_line('               where  UPPER(NAME) like UPPER(''%NUMBER_GENERATION%'')<br>');
							dbms_output.put_line('               and    OWNER = ''APPS''   and  TEXT like ''%$Header%''<br>');
							dbms_output.put_line('               order  by NAME;<br>');
							dbms_output.put_line('          </blockquote><br>');
							dbms_output.put_line('     </TD>');
							dbms_output.put_line('   </TR>');
							dbms_output.put_line(' <TR>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Owner</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Text</B></TD>');						
							
							:n := dbms_utility.get_time;
							open c_package;
							  loop
								fetch c_package into v_owner,v_name,v_text;
								EXIT WHEN  c_package%NOTFOUND;
								dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10));							
								dbms_output.put_line('<TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_text||'</TD></TR>'||chr(10));	
							  end loop;
							close c_package;						
							
							:n := (dbms_utility.get_time - :n)/100;
							dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							dbms_output.put_line(' </TABLE>  ');
						end if;
						
						if issue2 then
							dbms_output.put_line('<br><br><A class=detail onclick="displayItem(this,''s1sql70'');" href="javascript:;">      &#9654; Custom Number Generation FF FAST FORMULA</A>');
							dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql70" style="display:none" >');
							dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							dbms_output.put_line('   <TH COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('     <B>Custom Number Generation FF FAST FORMULA:</B></font></TD>');
							dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
							dbms_output.put_line('<A class=detail  id="s1sql48b"  onclick="displayItem2(this,''s1sql71'');" href="javascript:;">&#9654; Show SQL Script</A>');
							dbms_output.put_line('   </TD>');
							dbms_output.put_line(' </TR>');
							dbms_output.put_line(' <TR id="s1sql71" style="display:none">');
							dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="9" height="60">');
							dbms_output.put_line('       <blockquote><p align="left">');
							dbms_output.put_line('select FUNCTION_ID,CLASS,NAME,BUSINESS_GROUP_ID,DATA_TYPE,DEFINITION,LAST_UPDATED_BY,LAST_UPDATE_DATE,LEGISLATION_CODE,DESCRIPTION<br>'); 
							dbms_output.put_line('from FF_FUNCTIONS_V<br>'); 
							dbms_output.put_line('   where UPPER(DATA_TYPE) = UPPER(''number'') <br>');
							dbms_output.put_line('   and UPPER(DEFINITION) like UPPER(''%NUM%GEN%'');<br>');
							dbms_output.put_line('          </blockquote><br>');
							dbms_output.put_line('     </TD>');
							dbms_output.put_line('   </TR>');
							dbms_output.put_line(' <TR>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Function ID</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Class</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Business Group ID</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Data Type</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Definition</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Last updated by</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Last update date</B></TD>');	
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Legislation code</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Description</B></TD>');
							
							:n := dbms_utility.get_time;						
							open c_formula;
							  loop
								fetch c_formula into v_funct,v_class,v_name2,v_bg,v_date_type,v_definition,v_lby,v_ldate,v_leg,v_desc;
								EXIT WHEN  c_formula%NOTFOUND;
								dbms_output.put_line('<TR><TD>'||v_funct||'</TD>'||chr(10)||'<TD>'||v_class||'</TD>'||chr(10));							
								dbms_output.put_line('<TD>'||v_name2||'</TD>'||chr(10)||'<TD>'||v_bg||'</TD>'||chr(10));
								dbms_output.put_line('<TD>'||v_date_type||'</TD>'||chr(10)||'<TD>'||v_definition||'</TD>'||chr(10)||'<TD>'||v_lby||'</TD>'||chr(10));
								dbms_output.put_line('<TD>'||v_ldate||'</TD>'||chr(10)||'<TD>'||v_leg||'</TD>'||chr(10)||'<TD>'||v_desc||'</TD></TR>'||chr(10));	
							  end loop;
							close c_formula;						
							
							:n := (dbms_utility.get_time - :n)/100;
							dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							dbms_output.put_line(' <TH COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							dbms_output.put_line(' </TABLE><br>');
						end if;
						
						dbms_output.put_line('<br><A class=detail onclick="displayItem(this,''s1sql72'');" href="javascript:;">      &#9654; Next sequence number used to create a new employee number</A>');
						dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql72" style="display:none" >');
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('     <B>Next sequence number details:</B></font></TD>');
						dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
						dbms_output.put_line('<A class=detail  id="s1sql73b"  onclick="displayItem2(this,''s1sql73'');" href="javascript:;">&#9654; Show SQL Script</A>');
						dbms_output.put_line('   </TD>');
						dbms_output.put_line(' </TR>');
						dbms_output.put_line(' <TR id="s1sql73" style="display:none">');
						dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
						dbms_output.put_line('       <blockquote><p align="left">');
						dbms_output.put_line('SELECT BUSINESS_GROUP_ID, TYPE, NEXT_VALUE<br>'); 
					    dbms_output.put_line('FROM PER_NUMBER_GENERATION_CONTROLS<br>');
					    dbms_output.put_line('WHERE TYPE IN (''EMP'',''APL'', ''CWK'')<br>');
					    dbms_output.put_line('order by 1,2;<br>');						
						dbms_output.put_line('          </blockquote><br>');
						dbms_output.put_line('     </TD>');
						dbms_output.put_line('   </TR>');
						dbms_output.put_line(' <TR>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Business Group ID</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Type</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Next Value</B></TD>');						
						v_bg_old:=-1;
						
						:n := dbms_utility.get_time;
						 open c_next;
						  loop
							fetch c_next into v_bg,v_type,v_next;
							EXIT WHEN  c_next%NOTFOUND;
							if  v_bg<>v_bg_old then
								dbms_output.put_line('<TR><TD>'||v_bg||'</TD>'||chr(10));
							else
								dbms_output.put_line('<TR><TD></TD>'||chr(10));
							end if;
							dbms_output.put_line('<TD>'||v_type||'</TD>'||chr(10)||'<TD>'||v_next||'</TD></TR>'||chr(10));
							v_bg_old:=v_bg;							
						  end loop;
						  close c_next;
						  
						  :n := (dbms_utility.get_time - :n)/100;
					dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql72'');" href="javascript:;">Collapse section</a></td></tr>');
					dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
					dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
					dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
					dbms_output.put_line(' </TABLE>  ');
					
					dbms_output.put_line('<br><br><A class=detail onclick="displayItem(this,''s1sql74'');" href="javascript:;">      &#9654; Max values for Employee/Applicant/NPW numbers</A>');
					dbms_output.put_line('<DIV id="s1sql74" style="display: none;">');
					SELECT 	MAX(TO_CHAR(employee_number)), MAX(TO_CHAR(applicant_number)),MAX(TO_CHAR(npw_number))
					   into v_max_e_no,v_max_a_no,v_max_n_no
					   FROM PER_ALL_PEOPLE_F;
					dbms_output.put_line('<br>      MAX Employee Number is: '||v_max_e_no||'<br>');
					dbms_output.put_line('      MAX Applicant Number is: '||v_max_a_no||'<br>');
					dbms_output.put_line('      MAX NPW Number is: '||v_max_n_no||'<br>');
					dbms_output.put_line('</div>');

					dbms_output.put_line('</div></div>');
				

				if issue1 or issue2 then
					 dbms_output.put_line('<div class="divwarn">');
					  if issue1 then
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Custom Number Generation Package available!<br>');
							:w4:=:w4+1;
					  end if;
					  if issue2 then
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Custom Number Generation FF FAST FORMULA available!<br>');
							:w4:=:w4+1;
					  end if;					 
					  dbms_output.put_line('Custom Number Generation Using FastFormula is used as per internal Note 279458.1 How To Implement Custom Person Numbering Using FastFormula<br>');
					  dbms_output.put_line('DISCLAIMER: While this functionality was released by Oracle HR Development with 11i.HR_PF.H patch 3233333 ');
					  dbms_output.put_line('any implementation making use of this feature is purely a Customization.<br>');
					  dbms_output.put_line('Oracle Support Services will not support these FF Fast Formulas nor the associated Functions.<br>');
					  dbms_output.put_line('It is up to the customer to create and diagnose any code used to implement this functionality.<br>');
					  dbms_output.put_line('</div>');
                  end if;
                 				  
				  
                  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
            end if;
                
       end if;
	dbms_output.put_line('</div>');
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;
/




-- Database initialization parameters  

declare
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_db_parameter v$parameter.name%type; 
	v_db_value v$parameter.value%type;
	database_version	varchar2(100);
	apps_version	varchar2(50);
	issue1 varchar2(100) := '';
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	cursor db_init is
	select name, nvl(value,'null') from v$parameter 
      where name in ('max_dump_file_size','timed_statistics'
	  ,'user_dump_dest','compatible'
	  ,'sql_trace'
	  ,'utl_file_dir','_optimizer_autostats_job')
      order by name;
	cursor db_init2 is
		select name, nvl(value,'null') from v$parameter order by name;

begin
	dbms_output.put_line('</div>');
    dbms_output.put_line('<div id="page4" style="display: none;">');
	dbms_output.put_line('<a name="performance"></a><div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="performance" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Performance: '); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF"> /  </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
	if upper(run_type)='ALL' then
	dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	  dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">'); 
	  dbms_output.put_line('<a class=detail2 href="#db_init_ora">Database Initialization Parameters</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#gather">Gather Schema Statistics</a> <br>');      
      if product='PAY' or product='ALL' then
          dbms_output.put_line('<a class=detail2 href="#hot">Hot Payroll Tables</a><br>');
      end if;
      dbms_output.put_line('</td></tr></table>');
	dbms_output.put_line('</div><br>');
	end if;

	dbms_output.put_line(' <a name="db_init_ora"></a>');

	database_version:=:db_ver;
	apps_version:=:apps_rel;
	
	open db_init;
	loop
          fetch db_init into v_db_parameter,v_db_value;
          EXIT WHEN  db_init%NOTFOUND;
		  CASE v_db_parameter
				when 'compatible' then 
					CASE
						when database_version like '%8.1%' then
							if v_db_value<>'8.1.7' then
								issue1:='Please set Compatible parameter to 8.1.7';
							end if;
						when database_version like '%9.2%' then
							if v_db_value<>'9.2.0' then
								issue1:='Please set Compatible parameter to 9.2.0';
							end if;
						when database_version like '%10.1%' then
							if v_db_value<>'10.1.0' then
								issue1:='Please set Compatible parameter to 10.1.0';
							end if;
						when database_version like '%10.2%' then
							if v_db_value<>'10.2.0' then
								issue1:='Please set Compatible parameter to 10.2.0';
							end if;
						when database_version like '%11.1%' then
							if v_db_value<>'11.1.0' then
								issue1:='Please set Compatible parameter to 11.1.0';
							end if;
						when database_version like '%11.2%' then
							if v_db_value<>'11.2.0' then
								issue1:='Please set Compatible parameter to 11.2.0';
							end if;
						when database_version like '%12.1%' then
							if v_db_value<>'12.1.0' then
								issue1:='Please set Compatible parameter to 12.1.0';
							end if;
						else
							null;
					end case;
				when 'max_dump_file_size' then
					if v_db_value <>'UNLIMITED' then
						issue2:=TRUE;
					end if;
				when '_optimizer_autostats_job' then
					begin
						if database_version like '%11.1%' or database_version like '%11.2%' then
							if v_db_value <>'FALSE' then
								issue3:=TRUE;
							end if;	
						end if;
					end;
				when 'timed_statistics' then
					begin
						if database_version like '%8.1%' or database_version like '%9.2%' or database_version like '%10.1%' or database_version like '%10.2%' then
							if v_db_value <> 'TRUE' then
								issue4:=TRUE;
							end if;	
						end if;
					end;			
				else
					null;
			END CASE;
			
          
    end loop;
    close db_init;
	
	if upper(run_type)='ALL' or issue1<>'' or issue2 or issue3 or issue4 then
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql11b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql11'');" href="javascript:;">&#9654; Database Initialization Parameters</A></DIV>');
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql11" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Database parameters</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql12b" onclick="displayItem2(this,''s1sql12'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql12" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select name, value from v$parameter <br>');
		dbms_output.put_line('         order by name;<br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Parameter</B></TD>');
		dbms_output.put_line(' <TH><B>Value</B></TD>');
	
		:n := dbms_utility.get_time;
		open db_init2;
		loop
			fetch db_init2 into v_db_parameter,v_db_value;
			EXIT WHEN  db_init2%NOTFOUND;
			dbms_output.put_line('<TR><TD>'||v_db_parameter||'</TD>'||chr(10)||'<TD>');
			dbms_output.put_line(substr(v_db_value,1,250));
			dbms_output.put_line('</TD></TR>'||chr(10));
          
		end loop;
		close db_init2;

		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql11'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
	
		if issue1<>'' or issue3 or issue4 then
			dbms_output.put_line('<div class="divwarn">');
		
			if issue1<>'' then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font>'||issue1||'<br>');
				:w2:=:w2+1;
			end if;		
			
			if issue3 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please set _optimizer_autostats_job to FALSE<br>');
				:w2:=:w2+1;
			end if;
			
			if issue4 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please set timed_statistics to TRUE<br>');
				:w2:=:w2+1;
			end if;
			dbms_output.put_line('</div>');
		end if;
		
		dbms_output.put_line('<div class="divok">');
		if issue2 then
			dbms_output.put_line('<font color="blue">Advice:</font> If you need to run a trace please set Max_dump_file_size = UNLIMITED<br>');
		end if;
		dbms_output.put_line('<font color="blue">Advice:</font> If you have performance issue please ensure you have correct database initialization parameters as per ');
		if apps_version like '12.%' then
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=396009.1" target="_blank">Note 396009.1</a> Database Initialization Parameters for Oracle E-Business Suite Release 12<br>');
		else 
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=216205.1" target="_blank">Note 216205.1</a> Database Initialization Parameters for Oracle Applications Release 11i<br>');
		end if;
		dbms_output.put_line('Use <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=174605.1" target="_blank">Note 174605.1</a> bde_chk_cbo.sql - EBS initialization parameters - Healthcheck<br>');
		dbms_output.put_line('This will help you to identify the difference between actual values and required values. Verify that all Mandatory Parameters - MP are set correctly<br><br>');
		if upper(product) in ('PAY', 'ALL') then
			dbms_output.put_line('Review also <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		end if;
		
		if issue1='' and (not issue2) and (not issue3) and (not issue4) then
				dbms_output.put_line('Verified parameters are correctly set');
		end if;
		dbms_output.put_line('</div>');		
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
	end if;
	
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



-- Latest run of concurrent request Gather schema statistics  

declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  status_all varchar2(100);
  status_hr varchar2(100);
  status_hxc varchar2(100);
  status_hxt varchar2(100);
  status_pa varchar2(100);
  status_ben varchar2(100);
  status_ota varchar2(100);
  last_date_all date;
  last_date_hr date;
  last_date_hxc date;
  last_date_hxt date;
  last_date_pa date;
  last_date_ben date;
  last_date_ota date;
  last_date_normal date;
  status2 varchar2(100);
  last_date2 date;
  need_run boolean:=FALSE;
  days number;
  no_rows number;
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  issue6 boolean:=FALSE;
  issue7 boolean:=FALSE;
  issue8 boolean:=FALSE;
  issue9 boolean:=FALSE;
  issue10 boolean:=FALSE;
  issue11 boolean:=FALSE;
  issue12 boolean:=FALSE;
  issue13 boolean:=FALSE;
  issue14 boolean:=FALSE;
  issue15 boolean:=FALSE;
  issue16 boolean:=FALSE;
  issue17 boolean:=FALSE;
  issue18 boolean:=FALSE;
  issue19 boolean:=FALSE;
  issue20 boolean:=FALSE;
  issue21 boolean:=FALSE;
  v_PROG_SCHEDULE_TYPE varchar2(100);
  v_PROG_SCHEDULE varchar2(400);
  v_USER_NAME fnd_user.user_name%type;
  v_START_DATE fnd_concurrent_requests.requested_start_date%type;
  v_ARGUMENT_TEXT FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_all FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_hr FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_hxc FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_hxt FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_pa FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_ben FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_ota FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
begin
      select count(1) into no_rows
      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL');
        
      if no_rows=0 then
          issue1:=TRUE;
      else
          SELECT * 
                  into status_all,last_date_all,v_ARGUMENT_TEXT_all
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
            AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
          ORDER BY 2 desc)
          where rownum < 2;
      
          if instr(upper(status_all),upper('Completed Normal'))=0 then 
              issue2:=TRUE;
          else
              select  sysdate-last_date_all into days from dual;
              if days>7 then
                    issue3:=TRUE;
              end if;
          end if;
        end if;
        
        
      select count(1) into no_rows
      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,');
        
      if no_rows=0 then
          issue4:=TRUE;
      else
          SELECT * 
          into status_hr,last_date_hr,v_ARGUMENT_TEXT_hr
          FROM (
          SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
           ,ACTUAL_COMPLETION_DATE pEndDate,ARGUMENT_TEXT        
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
            AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
          ORDER BY 2 desc)
          where rownum < 2;
      
          if instr(upper(status_hr),upper('Completed Normal'))=0 then 
              issue5:=TRUE;
          else
              select  sysdate-last_date_hr into days from dual;
              if days>7 then
                    issue6:=TRUE;
              end if;
          end if;
        end if;
                        

           
--OTL checks      
      if upper(product) in ('OTL','ALL') then
      -- HXC gather schema statistics
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC');
                
              if no_rows=0 then
                  issue7:=TRUE;
              else
                  SELECT * 
                  into status_hxc,last_date_hxc,v_ARGUMENT_TEXT_hxc
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC')
                  ORDER BY 2 desc)
                  where rownum < 2;
                  
                  if instr(upper(status_hxc),upper('Completed Normal'))=0 then 
                      issue8:=TRUE;
                  else
                      select  sysdate-last_date_hxc into days from dual;
                      if days>7 then
                            issue9:=TRUE;
                      end if;
                  end if;
                end if;
              
              -- HXT gather schema statistics
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT');
                
              if no_rows=0 then
                  issue10:=TRUE;
              else
                  SELECT * 
                  into status_hxt,last_date_hxt,v_ARGUMENT_TEXT_hxt
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate,ARGUMENT_TEXT        
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT')
                  ORDER BY 2 desc)
                  where rownum < 2;
              
                  if instr(upper(status_hxt),upper('Completed Normal'))=0 then 
                      issue11:=TRUE;
                  else
                      select  sysdate-last_date_hxt into days from dual;
                      if days>7 then
                            issue12:=TRUE;
                      end if;
                  end if;
                  
                end if;
              
              -- PA gather schema statistics  
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,');
                
              if no_rows=0 then
                  issue13:=TRUE;
              else
                  SELECT * 
                  into status_pa,last_date_pa,v_ARGUMENT_TEXT_pa
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate,ARGUMENT_TEXT        
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,')
                  ORDER BY 2 desc)
                  where rownum < 2;
              
                  if instr(upper(status_pa),upper('Completed Normal'))=0 then 
                      issue14:=TRUE;
                  else
                      select  sysdate-last_date_pa into days from dual;
                      if days>7 then
                            issue15:=TRUE;
                      end if;
                  end if;
                  
                end if;
      end if;  


-- BEN checks
      if upper(product) in ('BEN','ALL') then
      -- BEN gather schema statistics
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN');
                
              if no_rows=0 then
                  issue16:=TRUE;
              else
                  SELECT * 
                  into status_ben,last_date_ben,v_ARGUMENT_TEXT_ben
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate,ARGUMENT_TEXT        
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN')
                  ORDER BY 2 desc)
                  where rownum < 2;
                  
                  if instr(upper(status_ben),upper('Completed Normal'))=0 then 
                      issue17:=TRUE;
                  else
                      select  sysdate-last_date_ben into days from dual;
                      if days>7 then
                            issue18:=TRUE;
                      end if;
                  end if;
                end if;
	 end if;
	 
-- OTA checks
      if upper(product) in ('OTA','ALL') then
      -- OTA gather schema statistics
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA');
                
              if no_rows=0 then
                  issue19:=TRUE;
              else
                  SELECT * 
                  into status_ota,last_date_ota,v_ARGUMENT_TEXT_ota
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA')
                  ORDER BY 2 desc)
                  where rownum < 2;
                  
                  if instr(upper(status_ben),upper('Completed Normal'))=0 then 
                      issue20:=TRUE;
                  else
                      select  sysdate-last_date_ben into days from dual;
                      if days>7 then
                            issue21:=TRUE;
                      end if;
                  end if;
                end if;
	 end if;
	 
	  
       if upper(run_type)='ALL' or issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 or issue11 or issue12 or issue13 or issue14 or issue15 or issue16 or issue17 or issue18 or issue19 or issue20 or issue21 then
                   
                    dbms_output.put_line(' <a name="gather"></a>');
                    dbms_output.put_line('<DIV class=divItem>');
					dbms_output.put_line('<DIV id="s1sql13b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql13'');" href="javascript:;">&#9654; Gather Statistics</A></DIV>');                    
                    dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql13" style="display:none" >');
                    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                    dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                    dbms_output.put_line('     <B>Statistics</B></TD>');
                    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                    dbms_output.put_line('<A class=detail id="s1sql14b" onclick="displayItem2(this,''s1sql14'');" href="javascript:;">&#9654; Show SQL Script</A>');
                    dbms_output.put_line('   </TD>');
                    dbms_output.put_line(' </TR>');
                    dbms_output.put_line(' <TR id="s1sql14" style="display:none">');
                    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                    dbms_output.put_line('       <blockquote><p align="left">');
                    dbms_output.put_line('          SELECT PHAS.MEANING || '' '' || STAT.MEANING pStatus <br>');                        
                    dbms_output.put_line('                     ,ACTUAL_COMPLETION_DATE pEndDate      <br>');  
                    dbms_output.put_line('                      FROM FND_CONC_REQ_SUMMARY_V fcrs<br>');
                    dbms_output.put_line('                     , FND_LOOKUPS STAT<br>');
                    dbms_output.put_line('                     , FND_LOOKUPS PHAS<br>');
                    dbms_output.put_line('                      WHERE STAT.LOOKUP_CODE = FCRS.STATUS_CODE<br>');
                    dbms_output.put_line('                     AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE''<br>');
                    dbms_output.put_line('                     AND PHAS.LOOKUP_CODE = FCRS.PHASE_CODE<br>');
                    dbms_output.put_line('                      AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE''<br>');
                    dbms_output.put_line('                      AND (UPPER(program) LIKE ''GATHER SCHEMA%''<br>');
                    dbms_output.put_line('                      AND substr(UPPER(ARGUMENT_TEXT),1,3) in (''HR,'',''ALL''<br>');
                    case upper(product)
					when 'OTL' then
                        dbms_output.put_line('                      ,''HXC'',''HXT'',''PA,''');    
                    when 'BEN' then
                        dbms_output.put_line('                      ,''BEN''');    
                    when 'OTA' then
                        dbms_output.put_line('                      ,''OTA''');
					when 'ALL' then
						dbms_output.put_line('                      ,''BEN'',''HXC'',''HXT'',''PA,'',''OTA''');
					else
						null;
					end case;
                    dbms_output.put_line('                      ))<br>');
                    dbms_output.put_line('                      ORDER BY 2 desc<br>');

                    dbms_output.put_line('          </blockquote><br>');
                    dbms_output.put_line('     </TD>');
                    dbms_output.put_line('   </TR>');
                    dbms_output.put_line(' <TR>');
                    dbms_output.put_line(' <TH><B>Request</B></TD>');
                    dbms_output.put_line(' <TH><B>Status</B></TD>');
                    dbms_output.put_line(' <TH><B>Last run</B></TD>');
					dbms_output.put_line(' <TH><B>Last Time Completed Normal</B></TD>');
					dbms_output.put_line(' <TH><B>Scheduling</B></TD>');
                  
                    :n := dbms_utility.get_time;
                    
                    dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for ALL'||'</TD>'||chr(10));
                    if issue1 then
                          dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
						  :p1:='never';
                    elsif issue2 then
							if instr(upper(status_all),'ERROR')=0 then 
                                      issue2:=FALSE;
							end if;		  
							select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
							if no_rows>0 then
								SELECT * 
								  into last_date_normal,v_ARGUMENT_TEXT
								  FROM (
								  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
								  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
								  ORDER BY 1 desc)
								  where rownum < 2;
								  :p1:=last_date_normal;
								  dbms_output.put_line('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT);
								  dbms_output.put_line('</TD>'||chr(10));
								  select  sysdate-last_date_normal into days from dual;
								  if days>7 then
										issue3:=TRUE;
										last_date_all:=last_date_normal;
								  else
										issue3:=FALSE;
								  end if;
							else
								dbms_output.put_line('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
								dbms_output.put_line('<TD>never</TD>'||chr(10));
								issue2:=TRUE;
								:p1:='never';
							end if;
					else
                          dbms_output.put_line('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
						  dbms_output.put_line('<TD>'||last_date_all||' with parameters:');
						  dbms_output.put_line(v_ARGUMENT_TEXT_all);
						  dbms_output.put_line('</TD>'||chr(10));
						  :p1:=last_date_all;
                    end if;
					select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL');
					if no_rows=0 then
								dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
					else						  
								select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
								SELECT 
									 NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
									 DECODE(NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
									 'PERIODICALLY',
									 'EVERY ' || fcr.resubmit_interval || ' ' ||
									 fcr.resubmit_interval_unit_code || ' FROM ' ||
									 fcr.resubmit_interval_type_code || ' OF PREV RUN',
									 'ONCE',
									 'AT :' ||
									 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
									 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
									 fu.user_name USER_NAME,
									 requested_start_date START_DATE									
									 FROM fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									ORDER BY 2 desc)
									where rownum < 2;
								  
								  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
								  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
					end if;
                    
                    dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for HR'||'</TD>'||chr(10));
                    if issue4 then
                          dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
						  :p2:='never';
                    elsif issue5 then
							if instr(upper(status_hr),'ERROR')=0 then 
                                      issue5:=FALSE;
							end if;
							select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
							if no_rows>0 then
								SELECT * 
								  into last_date_normal,v_ARGUMENT_TEXT
								  FROM (
								  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
								  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
								  ORDER BY 1 desc)
								  where rownum < 2;
								  :p2:=last_date_normal;
								  dbms_output.put_line('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT);
								  dbms_output.put_line('</TD>'||chr(10));
								  select  sysdate-last_date_normal into days from dual;
								  if days>7 then
										issue6:=TRUE;
										last_date_hr:=last_date_normal;
								  else
										issue6:=FALSE;
								  end if;
							else
								dbms_output.put_line('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
								dbms_output.put_line('<TD>never</TD>'||chr(10));
								issue5:=TRUE;
								:p2:='never';
							end if;
					else
                          dbms_output.put_line('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
						  dbms_output.put_line('<TD>'||last_date_hr||' with parameters:');
						  dbms_output.put_line(v_ARGUMENT_TEXT_hr);
						  dbms_output.put_line('</TD>'||chr(10));
						  :p2:=last_date_hr;
                    end if;
					select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,');
					
					if no_rows=0 then
								dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
					else						  
								select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
								SELECT 
									 NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
									 DECODE(NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
									 'PERIODICALLY',
									 'EVERY ' || fcr.resubmit_interval || ' ' ||
									 fcr.resubmit_interval_unit_code || ' FROM ' ||
									 fcr.resubmit_interval_type_code || ' OF PREV RUN',
									 'ONCE',
									 'AT :' ||
									 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
									 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
									 fu.user_name USER_NAME,
									 requested_start_date START_DATE
									 FROM fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									ORDER BY 2 desc)
									where rownum < 2;
								  
								  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
								  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
					end if;
                    
					
                    if upper(product) in ('OTL','ALL') then
                          dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for HXC'||'</TD>'||chr(10));
                          if issue7 then
								  dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue8 then
									if instr(upper(status_hxc),'ERROR')=0 then 
                                      issue8:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  dbms_output.put_line('<TD>'||status_hxc||'</TD>'||chr(10)||'<TD>'||last_date_hxc||'</TD>'||chr(10));
										  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
										  dbms_output.put_line(v_ARGUMENT_TEXT);
										  dbms_output.put_line('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue9:=TRUE;
												last_date_hxc:=last_date_normal;
										  else
												issue9:=FALSE;
										  end if;
									else
										dbms_output.put_line('<TD>'||status_hxc||'</TD>'||chr(10)||'<TD>'||last_date_hxc||'</TD>'||chr(10));
										dbms_output.put_line('<TD>never</TD>'||chr(10));
										issue8:=TRUE;
									end if;
							else
								  dbms_output.put_line('<TD>'||status_hxc||'</TD>'||chr(10)||'<TD>'||last_date_hxc||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_hxc||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT_hxc);
								  dbms_output.put_line('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC');
							
							if no_rows=0 then
										dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE											 
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                          
                          dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for HXT'||'</TD>'||chr(10));
                          if issue10 then
								  dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue11 then
									if instr(upper(status_hxt),'ERROR')=0 then 
                                      issue11:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  dbms_output.put_line('<TD>'||status_hxt||'</TD>'||chr(10)||'<TD>'||last_date_hxt||'</TD>'||chr(10));
										  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
										  dbms_output.put_line(v_ARGUMENT_TEXT);
										  dbms_output.put_line('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue12:=TRUE;
												last_date_hxt:=last_date_normal;
										  else
												issue12:=FALSE;
										  end if;
									else
										dbms_output.put_line('<TD>'||status_hxt||'</TD>'||chr(10)||'<TD>'||last_date_hxt||'</TD>'||chr(10));
										dbms_output.put_line('<TD>never</TD>'||chr(10));
										issue11:=TRUE;
									end if;
							else
								  dbms_output.put_line('<TD>'||status_hxt||'</TD>'||chr(10)||'<TD>'||last_date_hxt||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_hxt||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT_hxt);
								  dbms_output.put_line('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT');
							
							if no_rows=0 then
										dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE											 
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                          
                          dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for PA'||'</TD>'||chr(10));
                          		if issue13 then
								  dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue14 then
									if instr(upper(status_pa),'ERROR')=0 then 
                                      issue14:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  dbms_output.put_line('<TD>'||status_pa||'</TD>'||chr(10)||'<TD>'||last_date_pa||'</TD>'||chr(10));
										  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
										  dbms_output.put_line(v_ARGUMENT_TEXT);
										  dbms_output.put_line('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue15:=TRUE;
												last_date_pa:=last_date_normal;
										  else
												issue15:=FALSE;
										  end if;
									else
										dbms_output.put_line('<TD>'||status_pa||'</TD>'||chr(10)||'<TD>'||last_date_pa||'</TD>'||chr(10));
										dbms_output.put_line('<TD>never</TD>'||chr(10));
										issue14:=TRUE;
									end if;
							else
								  dbms_output.put_line('<TD>'||status_pa||'</TD>'||chr(10)||'<TD>'||last_date_pa||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_pa||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT_pa);
								  dbms_output.put_line('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,');
							
							if no_rows=0 then
										dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                    end if;
					
					if upper(product) in ('BEN','ALL') then
                          dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for BEN'||'</TD>'||chr(10));
                          	if issue16 then
								  dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue17 then
									if instr(upper(status_ben),'ERROR')=0 then 
                                      issue17:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT       
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  dbms_output.put_line('<TD>'||status_ben||'</TD>'||chr(10)||'<TD>'||last_date_ben||'</TD>'||chr(10));
										  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
										  dbms_output.put_line(v_ARGUMENT_TEXT);
										  dbms_output.put_line('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue18:=TRUE;
												last_date_ben:=last_date_normal;
										  else
												issue18:=FALSE;
										  end if;
									else
										dbms_output.put_line('<TD>'||status_ben||'</TD>'||chr(10)||'<TD>'||last_date_ben||'</TD>'||chr(10));
										dbms_output.put_line('<TD>never</TD>'||chr(10));
										issue17:=TRUE;
									end if;
							else
								  dbms_output.put_line('<TD>'||status_ben||'</TD>'||chr(10)||'<TD>'||last_date_ben||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_ben||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT_ben);
								  dbms_output.put_line('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN');
							
							if no_rows=0 then
										dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE											
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                    end if;
                    
                    if upper(product) in ('OTA','ALL') then
                          dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for OTA'||'</TD>'||chr(10));
                          	if issue19 then
								  dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue20 then
									if instr(upper(status_ben),'ERROR')=0 then 
                                      issue20:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT       
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  dbms_output.put_line('<TD>'||status_ota||'</TD>'||chr(10)||'<TD>'||last_date_ota||'</TD>'||chr(10));
										  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
										  dbms_output.put_line(v_ARGUMENT_TEXT);
										  dbms_output.put_line('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue18:=TRUE;
												last_date_ota:=last_date_normal;
										  else
												issue18:=FALSE;
										  end if;
									else
										dbms_output.put_line('<TD>'||status_ota||'</TD>'||chr(10)||'<TD>'||last_date_ota||'</TD>'||chr(10));
										dbms_output.put_line('<TD>never</TD>'||chr(10));
										issue20:=TRUE;
									end if;
							else
								  dbms_output.put_line('<TD>'||status_ota||'</TD>'||chr(10)||'<TD>'||last_date_ota||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_ota||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT_ota);
								  dbms_output.put_line('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA');
							
							if no_rows=0 then
										dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE											
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                    end if;
					
                    :n := (dbms_utility.get_time - :n)/100;
                    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                    dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                    dbms_output.put_line(' </TABLE> </div> ');



              dbms_output.put_line('<div class="divwarn">');
              if issue1 and issue4 then
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You never performed Gather Schema Statistics for HR!<br> ');
					:w2:=:w2+1;
              end if;              
                    
              if issue2 then
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL is not Completed Normal. ');
					:w2:=:w2+1;      
              end if;
              
              if issue5 then
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for HR is not Completed Normal. ');
					:w2:=:w2+1;     
              end if;
              
			  if issue1 and issue6 then
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your never performed gather schema statistics for ALL, and for HR was on '||last_date_hr||'.');
                    dbms_output.put_line('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w2:=:w2+1;
			  end if;
			  
              if issue3 and (issue6 or issue5 or issue4) then
                    dbms_output.put_line('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all);
                    dbms_output.put_line('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w2:=:w2+1;                         
              elsif issue3 and issue6 then
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for HR was on '||last_date_hr||'.');
                    dbms_output.put_line('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w2:=:w2+1;					                         
              end if;
              
              if upper(product) in ('OTL','ALL') then
                    
                    if issue1 and issue7 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You never performed Gather Schema Statistics for HXC!<br> ');
						  :w2:=:w2+1;
                    end if;
                    if issue8 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for HXC is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
					
					if issue1 and issue9 then
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your never performed gather schema statistics for ALL, and for HXC was on '||last_date_hxc||'.');
							 dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
					
                    if issue3 and issue9 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL was on ' || last_date_all||' and for HXC was on '||last_date_hxc||'.');
                          dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
						  :w2:=:w2+1;						  
                    end if;
                    
                    if issue1 and issue10 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You never performed Gather Schema Statistics for HXT!<br> ');
						  :w2:=:w2+1;
                    end if;
                    if issue11 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for HXT is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
                    
					if issue1 and issue12 then
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your never performed gather schema statistics for ALL and for HXT was on '||last_date_hxt||'.');
							 dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
					  
					if issue3 and issue12 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for HXT was on '||last_date_hxt||'.');
                          dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');     
						  :w2:=:w2+1;						  
                    end if;
                    
                    if issue1 and issue13 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You never performed Gather Schema Statistics for PA!<br> ');
						  :w2:=:w2+1; 
                    end if;
                    if issue14 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for PA is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
					if issue1 and issue15 then
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your never performed gather schema statistics for ALL, and for PA was on '||last_date_pa||'.');
							 dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
                    if issue3 and issue15 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for PA was on '||last_date_pa||'.');
                          dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
						  :w2:=:w2+1;						  
                    end if;
              end if; 
			  if upper(product) in ('BEN','ALL') then
                    
                    if issue1 and issue16 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You never performed Gather Schema Statistics for BEN!<br> ');
						  :w2:=:w2+1;
                    end if;
                    if issue17 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for BEN is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
					
					if issue1 and issue18 then
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your never performed gather schema statistics for ALL, and for BEN was on '||last_date_ben||'.');
							 dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
					
                    if issue3 and issue18 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for BEN was on '||last_date_ben||'.');
                          dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
						  :w2:=:w2+1;						  
                    end if;			  
			end if;
			
            if upper(product) in ('OTA','ALL') then
                    
                    if issue1 and issue19 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You never performed Gather Schema Statistics for OTA!<br> ');
						  :w2:=:w2+1;
                    end if;
                    if issue20 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for OTA is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
					
					if issue1 and issue21 then
							dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your never performed gather schema statistics for ALL, and for OTA was on '||last_date_ota||'.');
							 dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
					
                    if issue3 and issue21 then
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for OTA was on '||last_date_ota||'.');
                          dbms_output.put_line('Frequency of this concurrent request should be weekly.<br>');  
						  :w2:=:w2+1;						  
                    end if;			  
			end if;
			
            if (issue1 and issue4) or issue2 or issue5 or (issue1 and issue6) or (issue3 and (issue6 or issue5 or issue4)) or (issue1 and issue7) or issue8 or (issue1 and issue9) or (issue3 and issue9) 
			or (issue1 and issue10) or issue11 or  (issue1 and issue12) or(issue3 and issue12) or (issue1 and issue13) or issue14 or (issue1 and issue15) or (issue3 and issue15) 
			or (issue1 and issue16) or issue17 or (issue1 and issue18) or (issue3 and issue18)  or (issue1 and issue19) or issue20 or (issue1 and issue21) or (issue3 and issue21) then
				 
				 dbms_output.put_line('In order to schedule use <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=419728.1" target="_blank" >Note 419728.1</a> ');
				 dbms_output.put_line('Concurrent Processing - How To Gather Statistics On Oracle Applications Release 11i and/or Release 12 - Concurrent Process,Temp Tables, Manually <br>');
				 dbms_output.put_line('Note! You can ignore the warning if you are manually gathering statistics using FND_STATS.GATHER_SCHEMA_STATS.<br>');
			 end if;
                        
               dbms_output.put_line('</div>'); 
			  if not issue1 and not issue2 and not issue3 then
					dbms_output.put_line('<div class="divok">');
					dbms_output.put_line('<img class="check_ico">OK! Gather Scema statistics was performed in last week without errors.<br><br>');
					dbms_output.put_line('</div>');
			  else
					 if issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 or issue11 or issue12 or issue13 or issue14 or issue15 or issue16 or issue17 or issue18 or issue19 or issue20 or issue21 then
                         dbms_output.put_line('<div class="divwarn">');
						 dbms_output.put_line('Please review also <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=226987.1" target="_blank" >Note 226987.1</a>');
						 dbms_output.put_line('Oracle 11i and R12 Human Resources (HRMS) and Benefits (BEN) Tuning and System Health Checks <br>');                         
						 if upper(product) in ('PAY','ALL') then
                              dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=246332.1" target="_blank" >Note 246332.1</a> FLOAUG Presentation: Working with Support on Payroll Performance Issues');							  
						 end if;
						 dbms_output.put_line('</div>');
					 else
							dbms_output.put_line('<div class="divok">');
							dbms_output.put_line('<img class="check_ico">OK! Gather Scema statistics was performed in last week without errors.');
							dbms_output.put_line('</div>');
					 end if;
			  end if;
		  
	  
              dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
        end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/




-- Hot PAY Tables 

declare
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_table_name dba_tables.table_name%type; 
  v_last_analyzed dba_tables.last_analyzed%type;
	v_pct_free dba_tables.pct_free%type;
  v_ini_trans dba_tables.ini_trans%type;
  v_max_trans dba_tables.max_trans%type;
  v_degree dba_tables.degree%type;
  v_sample varchar2(30);
  v_num_rows dba_tables.num_rows%type;
  v_index_name dba_indexes.index_name%type;
  v_i_ini_trans dba_indexes.ini_trans%type;
  v_thread pay_action_parameters.parameter_value%type;
  v_rows number;
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
  issue7 boolean := FALSE;
	issue1_el boolean := FALSE;
	issue2_el boolean := FALSE;
	issue3_el boolean := FALSE;
	issue4_el boolean := FALSE;
	issue5_el boolean := FALSE;
	issue6_el boolean := FALSE;
  issue7_el boolean := FALSE;  
  
	cursor hot is
	SELECT table_name, last_analyzed, pct_free, ini_trans, max_trans, ltrim(rtrim(degree))
           , round(((decode(sample_size,0,null,sample_size))/(decode(num_rows,0,null,num_rows)))*100,2) , num_rows
      FROM DBA_TABLES
      WHERE table_name IN ('FF_ARCHIVE_ITEMS'
                          ,'FF_ARCHIVE_ITEM_CONTEXTS'
                          ,'PAY_ACTION_INFORMATION'
                          ,'PAY_ASSIGNMENT_ACTIONS'
                          ,'PAY_ASSIGNMENT_LATEST_BALANCES'
                          ,'PAY_BALANCE_CONTEXT_VALUES'
                          ,'PAY_COSTS'
                          ,'PAY_DEFINED_BALANCES'
                          ,'PAY_ELEMENT_ENTRIES_F'
                          ,'PAY_ELEMENT_ENTRY_VALUES_F'
                          ,'PAY_INPUT_VALUES_F'
                          ,'PAY_PAYROLL_ACTIONS'
                          ,'PAY_PERIODS_OF_SERVICE'
                          ,'PAY_PERSON_LATEST_BALANCES'
                          ,'PAY_POPULATION_RANGES'
                          ,'PAY_PRE_PAYMENTS'
                          ,'PAY_RUN_BALANCES'
                          ,'PAY_RUN_RESULTS'
                          ,'PAY_RUN_RESULT_VALUES'
                          ,'PAY_US_RPT_TOTALS'
                          ,'PER_ALL_ASSIGNMENTS_F'
                          ,'PER_ALL_PEOPLE_F') order by table_name;
  cursor cindexes (t_name varchar2) is
  select index_name, last_analyzed, pct_free, ini_trans, max_trans, degree 
      	FROM dba_indexes
      	WHERE table_name = t_name
        order by index_name;

begin

dbms_output.put_line(' <a name="hot"></a>');

if upper(product)='PAY'  or upper(product)='ALL' then
	
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql17b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql17'');" href="javascript:;">&#9654; Hot PAY Tables</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql17" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=7 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Hot Tables</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql18b" onclick="displayItem2(this,''s1sql18'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql18" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         SELECT table_name, last_analyzed, pct_free, ini_trans, max_trans, ltrim(rtrim(degree))<br>');
		dbms_output.put_line('                    , round(((decode(sample_size,0,null,sample_size))/(decode(num_rows,0,null,num_rows)))*100,2) , num_rows<br>');
		dbms_output.put_line('               FROM DBA_TABLES<br>');
		dbms_output.put_line('               WHERE table_name IN (''FF_ARCHIVE_ITEMS''<br>');
		dbms_output.put_line('                                   ,''FF_ARCHIVE_ITEM_CONTEXTS''<br>');
		dbms_output.put_line('                                   ,''PAY_ACTION_INFORMATION''<br>');
		dbms_output.put_line('                                   ,''PAY_ASSIGNMENT_ACTIONS''<br>');
		dbms_output.put_line('                                   ,''PAY_ASSIGNMENT_LATEST_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_BALANCE_CONTEXT_VALUES''<br>');
		dbms_output.put_line('                                   ,''PAY_COSTS''<br>');
		dbms_output.put_line('                                   ,''PAY_DEFINED_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_ELEMENT_ENTRIES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_ELEMENT_ENTRY_VALUES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_INPUT_VALUES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_PAYROLL_ACTIONS''<br>');
		dbms_output.put_line('                                   ,''PAY_PERIODS_OF_SERVICE''<br>');
		dbms_output.put_line('                                   ,''PAY_PERSON_LATEST_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_POPULATION_RANGES''<br>');
		dbms_output.put_line('                                   ,''PAY_PRE_PAYMENTS''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_RESULTS''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_RESULT_VALUES''<br>');
		dbms_output.put_line('                                   ,''PAY_US_RPT_TOTALS''<br>');
		dbms_output.put_line('                                   ,''PER_ALL_ASSIGNMENTS_F''<br>');
		dbms_output.put_line('                                   ,''PER_ALL_PEOPLE_F'');<br>');
    
		dbms_output.put_line('        SELECT table_name, index_name, last_analyzed, pct_free, ini_trans, max_trans, degree<br>');
		dbms_output.put_line('                FROM dba_indexes<br>');
		dbms_output.put_line('                WHERE table_name IN (''FF_ARCHIVE_ITEMS''<br>');
		dbms_output.put_line('                                   ,''FF_ARCHIVE_ITEM_CONTEXTS''<br>');
		dbms_output.put_line('                                   ,''PAY_ACTION_INFORMATION''<br>');
		dbms_output.put_line('                                   ,''PAY_ASSIGNMENT_ACTIONS''<br>');
		dbms_output.put_line('                                   ,''PAY_ASSIGNMENT_LATEST_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_BALANCE_CONTEXT_VALUES''<br>');
		dbms_output.put_line('                                   ,''PAY_COSTS''<br>');
		dbms_output.put_line('                                   ,''PAY_DEFINED_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_ELEMENT_ENTRIES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_ELEMENT_ENTRY_VALUES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_INPUT_VALUES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_PAYROLL_ACTIONS''<br>');
		dbms_output.put_line('                                   ,''PAY_PERIODS_OF_SERVICE''<br>');
		dbms_output.put_line('                                   ,''PAY_PERSON_LATEST_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_POPULATION_RANGES''<br>');
		dbms_output.put_line('                                   ,''PAY_PRE_PAYMENTS''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_RESULTS''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_RESULT_VALUES''<br>');
		dbms_output.put_line('                                   ,''PAY_US_RPT_TOTALS''<br>');
		dbms_output.put_line('                                   ,''PER_ALL_ASSIGNMENTS_F''<br>');
		dbms_output.put_line('                                   ,''PER_ALL_PEOPLE_F'');<br>');
		dbms_output.put_line('          </blockquote><br>');       

		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Table Name</B></TD>');
		dbms_output.put_line(' <TH><B>Last Analyzed</B></TD>');
		dbms_output.put_line(' <TH><B>Pct Free</B></TD>');
		dbms_output.put_line(' <TH><B>Ini trans</B></TD>');
		dbms_output.put_line(' <TH><B>Max trans</B></TD>');
		dbms_output.put_line(' <TH><B>Degree</B></TD>');
		dbms_output.put_line(' <TH><B>% Sample</B></TD>');
		dbms_output.put_line(' <TH><B>Number of Rows</B></TD>');
	
  
	:n := dbms_utility.get_time;
  
	select count(1) into v_rows from pay_action_parameters where parameter_name='THREADS';
	if v_rows=0 then
		v_thread:=1;
	else	
		select max(parameter_value) into v_thread
			  from pay_action_parameters where parameter_name='THREADS';
	end if;
	
	open hot;
	loop
	  fetch hot into v_table_name,v_last_analyzed,v_pct_free,v_ini_trans,v_max_trans,v_degree,v_sample,v_num_rows;
	  EXIT WHEN  hot%NOTFOUND;
      issue1_el:=FALSE;
      issue2_el:=FALSE;
      issue3_el:=FALSE;
      issue4_el:=FALSE;
	  issue5_el:=FALSE;	  
      if v_last_analyzed-sysdate>7 then
           issue1:=TRUE;
           issue1_el:=TRUE;
      end if;
      if v_ini_trans<10 then
            issue2:=TRUE;
            issue2_el:=TRUE;
      end if;
      if v_ini_trans<v_thread then
            issue3:=TRUE;
            issue3_el:=TRUE;
      end if;
      if v_sample<10 then
            issue4:=TRUE;
            issue4_el:=TRUE;
      end if;    
      if v_table_name='PAY_US_RPT_TOTALS'  then
            select count(1) into v_num_rows from PAY_US_RPT_TOTALS;
			if v_num_rows>1000 then
				issue5:=TRUE;
				issue5_el:=TRUE;
			end if;
      end if;
      if issue1_el or issue2_el or issue3_el or issue4_el or issue5_el then
          dbms_output.put_line('<TR><TD><font color="red">'||v_table_name||'</font></TD>'||chr(10));
      else
          dbms_output.put_line('<TR><TD>'||v_table_name||'</TD>'||chr(10));
      end if;
      if issue1_el then
          dbms_output.put_line('<TD><font color="red">'||v_last_analyzed||'</font></TD>'||chr(10));
      else
          dbms_output.put_line('<TD>'||v_last_analyzed||'</TD>'||chr(10));
      end if;
      dbms_output.put_line('<TD>'||v_pct_free||'</TD>'||chr(10));
      if issue2_el or issue3_el then
          dbms_output.put_line('<TD><font color="red">'||v_ini_trans||'</font></TD>'||chr(10));
      else
          dbms_output.put_line('<TD>'||v_ini_trans||'</TD>'||chr(10));
      end if;
      dbms_output.put_line('<TD>'||v_max_trans||'</TD>'||chr(10)||'<TD>'||v_degree||'</TD>'||chr(10));
      if issue4_el then
          dbms_output.put_line('<TD><font color="red">'||v_sample||'</font></TD>'||chr(10));
      else
          dbms_output.put_line('<TD>'||v_sample||'</TD>'||chr(10));
      end if;
     if issue5_el then
          dbms_output.put_line('<TD><font color="red">'||v_num_rows||'</font></TD>'||chr(10));
      else
          dbms_output.put_line('<TD>'||v_num_rows||'</TD>'||chr(10));
      end if;
	       
	  dbms_output.put_line('</TD></TR>'||chr(10));
      
      dbms_output.put_line('<tr><td></td><TH COLSPAN=7>');
      
      dbms_output.put_line('<table><tr BGCOLOR=#DEE6E0><td>Index name</td><td>Last analyzed</td><td>Pct free</td><td>Ini trans</td><td>Max trans</td><td>Degree</td></tr>');
            
      open cindexes (v_table_name);
      loop
            fetch cindexes into v_index_name, v_last_analyzed,v_pct_free,v_i_ini_trans,v_max_trans,v_degree;
            EXIT WHEN  cindexes%NOTFOUND;
            issue6_el:=FALSE;
            issue7_el:=FALSE;
            
            if v_last_analyzed-sysdate>7 then                  
                  issue6:=TRUE;
                  issue6_el:=TRUE;
            end if;
            
            if v_i_ini_trans<v_ini_trans+1 then
                  if v_index_name not like 'SYS_IL%' then
					  issue7:=TRUE;
					  issue7_el:=TRUE;
				  end if;
            end if;
            
            if issue6_el or issue7_el then
                dbms_output.put_line('<tr><td><font color="red">'||v_index_name||'</font></td>');
            else
                dbms_output.put_line('<tr><td>'||v_index_name||'</td>');
            end if;
            if issue6_el then
                dbms_output.put_line('<td><font color="red">'||v_last_analyzed||'</font></TD>');
            else
                dbms_output.put_line('<td>'||v_last_analyzed||'</TD>');
            end if;
            dbms_output.put_line('<td>'||v_pct_free||'</td>');
            if issue7_el then
                dbms_output.put_line('<td><font color="red">'||v_i_ini_trans||'</font></TD>');
            else
                dbms_output.put_line('<td>'||v_i_ini_trans||'</TD>');
            end if;
            dbms_output.put_line('<td>'||v_max_trans||'</td><td>'||v_degree||'</td><tr>');
      end loop;
      close cindexes;   
	  
      dbms_output.put_line('</table> </td></tr>');
          
		end loop;
		close hot;

		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql17'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
	
		dbms_output.put_line('<div class="divwarn">');
		if issue1 then
			  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Last_Analyzed for tables is more than 1 week. This can be an issue or not depending on your pay period. ');
			  dbms_output.put_line('Last_analyzed should be within a time period associated with the customers pay periods ');
			  dbms_output.put_line(' ie.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc');
			  :w2:=:w2+1;
		end if;
		
		if issue2 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please set Ini_trans value to 10 or higher for tables with red!<br>');
			:w2:=:w2+1;
		end if;
		
		if issue3 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> The setting of the pay_action_parameters Threads setting ('||v_thread||') must be less then or equal to the Ini_trans setting.  ');
			dbms_output.put_line('If the Ini_trans setting is lower then the Threads setting this could cause system contention.<br>');
			:w2:=:w2+1;
		end if;
    
		if issue4 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Sample size should be at least 10% - if performance issue associated with one of these tables (as identified in a trace) may consider analyzing a larger sample.  <br>');
			:w2:=:w2+1;
		end if;
		
		if issue5 then
			  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Pay_US_RPT_Totals table should not contain a large number of records.  ');
			  dbms_output.put_line('This table temporarily stores records until a US Payroll reports completes successfully, then removes records. ');
			  dbms_output.put_line('Records are retained only if a report fails. ');
			  dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=256143.1" target="_blank">Note 256143.1</a> How to remove obsolete data on PAY_US_RPT_TOTALS table<br>');
			  :w2:=:w2+1;
		end if;
		
		if issue6 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Last_Analyzed for indexes is more than 1 week. This can be an issue or not depending on your pay period. ');
			  dbms_output.put_line('Last_analyzed should be within a time period associated with the customers pay periods ');
			  dbms_output.put_line(' ie.  If payroll is run weekly, these indexes should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc');
			  :w2:=:w2+1;
		end if;
		
		if issue7 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please set Ini_trans value for indexes to (Ini_trans of table)+1 <br>');
			:w2:=:w2+1;
		end if;
		
		dbms_output.put_line('<font color="blue">Advice:</font> Please review:<br> ');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=549367.1" target="_blank">Note 246332.1</a> FLOAUG Presentation: Working with Support on Payroll Performance Issues<br>');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=226987.1" target="_blank">Note 226987.1</a> Oracle 11i and R12 Human Resources and Benefits Tuning and System Health Checks');
		dbms_output.put_line('</div>');
		
		if (not issue1) and (not issue2) and (not issue3) and (not issue4) and (not issue5) and (not issue6) then
				dbms_output.put_line('<div class="divwarn">');
				dbms_output.put_line('Verified values are correctly set');
				dbms_output.put_line('</div>');
		end if;			
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
end if;

dbms_output.put_line('</div>');
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

-- Invalid objects   

declare
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_name dba_objects.object_name%type; 
	v_type dba_objects.object_type%type;
	v_owner dba_objects.owner%type;
	no_invalids number;
	no_errors number;
	inv_error VARCHAR2(250);
	issue boolean := FALSE;

	cursor invalids (prod varchar2) is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like upper(prod) or object_name like 'PER%' or object_name like 'HR/_%' escape '/')
	  order by 1,2;
	cursor invalids_hr is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'PER%' or object_name like 'HR%')
	  order by 1,2;
    cursor invalids_pay is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'PAY%' or object_name like 'FF%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/')
	  order by 1,2;
    cursor invalids_otl is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'PAY%' or object_name like 'HX%' or object_name like 'WF%')
	  order by 1,2;
	cursor invalids_sshr is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'BEN%' or object_name like 'HR/_%' escape '/' or object_name like 'PAY%' or  object_name like 'PER%' )
	  order by 1,2;
	  
	cursor invalids_all is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED'  
	  and ROWNUM<200
	  order by 1,2;
	
	cursor invalid_errors (object varchar2, object_type varchar2, object_owner varchar2) is
	  select nvl(substr(text,1,240) ,'null')
      from   all_errors
		where  name = object
		and    type = object_type
		and    owner = object_owner
		and ROWNUM<5;

begin

  dbms_output.put_line('</div>');
  dbms_output.put_line('<div id="page5" style="display: none;">');
	dbms_output.put_line('<a name="database"></a><div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="database" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Database Objects: '); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF"> /  </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
	if upper(run_type)='ALL' then
	dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	 dbms_output.put_line('<a class=detail2 href="#invalids">Invalid Objects</a> <br>');
      if upper(product) in ('HR','SSHR','IRC','ALL') then
          dbms_output.put_line('<a class=detail2 href="#indexes">Invalid Special / Intermedia Indexes</a> <br>');
      end if;
      dbms_output.put_line('<a class=detail2 href="#triggers">Triggers</a> <br></td><td class="toctable">');
      dbms_output.put_line('<a class=detail2 href="#timestamp">Dependency timestamp discrepancies</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#packages">Packages Versions</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#java">Java Classes Versions</a> <br></td><tr></table>');   
	dbms_output.put_line('</div><br>');
	end if;

  case upper(product) 
        when 'PAY' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'PAY%' or object_name like 'FF%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        when 'HR' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'PER%' or object_name like 'HR%');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        when 'BEN' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'BEN%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        when 'OTA' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'OTA%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
		when 'OTL' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'HX%' or object_name like 'PAY%' or object_name like 'WF%');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        when 'SSHR' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'BEN%' or object_name like 'HR/_%' escape '/' or object_name like 'PAY%' or  object_name like 'PER%' );
              if no_invalids>0 then
                    issue:=TRUE;
              end if;		
		when 'IRC' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'IRC%' or object_name like 'HR/_%' escape '/' or  object_name like 'PER%' );
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
		when 'ALL' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' ;
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        else
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' ;
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
  end case;
        
	if upper(run_type)='ALL' or issue then
		dbms_output.put_line(' <a name="invalids"></a>');
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql19b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql19'');" href="javascript:;">&#9654; Invalid Objects</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="3" id="s1sql19" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Fix next invalid objects:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql20b" onclick="displayItem2(this,''s1sql20'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql20" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select owner, object_name, object_type <br>');
		dbms_output.put_line('               from dba_objects<br>');
		dbms_output.put_line('               where status != ''VALID'' and object_type != ''UNDEFINED'' <br>');
		case upper(product)
		WHEN 'HR' then
			dbms_output.put_line('                and (object_name like ''PER%'' or object_name like ''HR%'') <br>');
		WHEN 'PAY' then
			dbms_output.put_line('                and (object_name like ''PAY%'' or object_name like ''FF%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'BEN' then
			dbms_output.put_line('                and (object_name like ''BEN%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'OTA' then
			dbms_output.put_line('                and (object_name like ''OTA%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'OTL' then
			dbms_output.put_line('                and (object_name like ''HX%'' or object_name like ''PAY%'' or object_name like ''WF%'') <br>'); 
		WHEN 'SSHR' then	
			dbms_output.put_line('                and (object_name like ''BEN%'' or object_name like ''PER%'' or object_name like ''PAY%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
        WHEN 'IRC' then
			dbms_output.put_line('                and (object_name like ''IRC%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'ALL' then
			dbms_output.put_line('                and  and ROWNUM<200<br>');
		ELSE
			null;
		end case;
		dbms_output.put_line('                order by 1,2;<br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Owner</B></TD>');
		dbms_output.put_line(' <TH><B>Object</B></TD>');
    	dbms_output.put_line(' <TH><B>Type</B></TD>');
		dbms_output.put_line(' <TH><B>Error</B></TD>');
	
		:n := dbms_utility.get_time;
    
    
      case upper(product) 
        when 'PAY' then
              open invalids_pay;
              loop
                    fetch invalids_pay into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_pay%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close invalids_pay;
          when 'HR' then
              open invalids_hr;
              loop
                    fetch invalids_hr into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_hr%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close invalids_hr;
          when 'SSHR' then
              open invalids_sshr;
              loop
                    fetch invalids_sshr into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_sshr%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close invalids_sshr;
			  
		  when 'BEN' then
              open invalids ('BEN');
              loop
                    fetch invalids into v_owner,v_name,v_type;
                    EXIT WHEN  invalids%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close invalids;
		   when 'OTA' then
              open invalids ('OTA');
              loop
                    fetch invalids into v_owner,v_name,v_type;
                    EXIT WHEN  invalids%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close invalids;
		  when 'IRC' then
              open invalids ('IRC');
              loop
                    fetch invalids into v_owner,v_name,v_type;
                    EXIT WHEN  invalids%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close invalids;
		  when 'OTL' then
              open invalids_otl;
              loop
                    fetch invalids_otl into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_otl%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close invalids_otl;
         else
              open invalids_all;
              loop
                    fetch invalids_all into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_all%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close invalids_all;
        end case;
        
	
		
		:n := (dbms_utility.get_time - :n)/100;
		if issue and no_invalids>10 then
			dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql19'');" href="javascript:;">Collapse section</a></td></tr>');
		end if;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
	
		
		if issue then
				:w3:=:w3+1;
				dbms_output.put_line('<div class="divwarn">');
				if upper(product)='ALL' then
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You have '||no_invalids||' invalid object(s) in database.<br>');
				else
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You have '||no_invalids||' invalid object(s).<br>');	
				end if;
				dbms_output.put_line('<font color="blue">Advice:</font> Please run adadmin -> Compile apps schema.<br>');
				dbms_output.put_line('If you still have invalids review steps from: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1325394.1" target="_blank">Note 1325394.1</a>');
				dbms_output.put_line(' Troubleshooting Guide - invalid objects in the E-Business Suite Environment 11i and 12');
				dbms_output.put_line('</div>');
		elsif upper(run_type)='ALL' then
              dbms_output.put_line('<div class="divok">');
			  dbms_output.put_line('No invalid object for '||product);
              dbms_output.put_line('</div>');
        end if;
		
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	end if;	
		
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Invalid Intermedia Indexes 


declare
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_name dba_objects.object_name%type; 
  no_invalids number;
	issue boolean := FALSE;

	cursor intermedia is
	    select index_name
      from   dba_indexes
      where  index_name in ('HR_LOCATIONS_N1', 'HR_LOCATIONS_SPT','IRC_DOCUMENTS_CTX', 'IRC_DOCUMENTS_CTX1', 'IRC_POSTING_CON_TL_CTX', 'IRC_SEARCH_CRITERIA_CTX', 'PER_ADDRESSES_N4', 'PER_EMPDIR_PEOPLE_N1', 'PER_ADDRESSES_SPT')
      and (status!='VALID' or domidx_status!='VALID' or domidx_opstatus!='VALID');



begin

if upper(product) in ('HR','SSHR','IRC','ALL') then
	dbms_output.put_line(' <a name="indexes"></a>');

	  select count(1) into no_invalids from dba_indexes
		  where  index_name in ('HR_LOCATIONS_N1', 'HR_LOCATIONS_SPT','IRC_DOCUMENTS_CTX', 'IRC_DOCUMENTS_CTX1', 'IRC_POSTING_CON_TL_CTX', 'IRC_SEARCH_CRITERIA_CTX', 'PER_ADDRESSES_N4', 'PER_EMPDIR_PEOPLE_N1', 'PER_ADDRESSES_SPT')
		  and (status!='VALID' or domidx_status!='VALID' or domidx_opstatus!='VALID');
	  if no_invalids>0 then
						issue:=TRUE;
	  end if;
 
        
	if issue or upper(run_type)='ALL' then
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql21b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql21'');" href="javascript:;">&#9654; Invalid Special / Intermedia Indexes</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql21" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Fix next invalid indexes:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql22b" onclick="displayItem2(this,''s1sql22'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql22" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select index_name <br>');
		dbms_output.put_line('          from   dba_indexes<br>');
		dbms_output.put_line('               where  index_name in (''HR_LOCATIONS_N1'', ''HR_LOCATIONS_SPT'',''IRC_DOCUMENTS_CTX'', <br>');
		dbms_output.put_line('               ''IRC_DOCUMENTS_CTX1'',  ''IRC_POSTING_CON_TL_CTX'', ''IRC_SEARCH_CRITERIA_CTX'', <br>');
		dbms_output.put_line('               ''PER_ADDRESSES_N4'', ''PER_EMPDIR_PEOPLE_N1'', ''PER_ADDRESSES_SPT'')<br>');
		dbms_output.put_line('               and (status!=''VALID'' or domidx_status!=''VALID'' or domidx_opstatus!=''VALID'');<br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Index Name</B></TD>');
	
		:n := dbms_utility.get_time;
   
		open intermedia;
		loop
				fetch intermedia into v_name;
				EXIT WHEN  intermedia%NOTFOUND;
				dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'</TR>'||chr(10));           
		end loop;
		close intermedia;
       
	
		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
		
		
		if issue then
			:e3:=:e3+1;
			dbms_output.put_line('<div class="diverr">');
			dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please fix invalid Special / Intermedia Indexes! Use<br>');
   
				if :apps_rel like '12.%' then
					  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=743720.1" target="_blank">Note 743720.1</a> Oracle Text: Re-installation and Rebuilding of Applications R12 Oracle Text Indexes<br>');
					else
						if :apps_rel like '11.5.10%' then
							  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=312640.1" target="_blank">Note 312640.1</a> Oracle Text: Re-installation of Applications 11i Oracle Text Indexes<br>');
						else
							  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=185414.1" target="_blank">Note 185414.1</a> interMedia Text: Re-installation of Applications 11i Text Indexes (11.5.0 - 11.5.9)<br>');
						end if;
				end if;
			dbms_output.put_line('</div>');	
		elsif upper(run_type)='ALL' then
              dbms_output.put_line('<div class="divok">');
			  dbms_output.put_line('<img class="check_ico">OK! No invalid intermedia index.<br>');
              dbms_output.put_line('</div>');
        end if;
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
  end if;	

end if;

EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Disabled triggers 

declare
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';
	v_owner dba_triggers.owner%type; 
	v_table dba_triggers.table_name%type;
    v_trigger dba_triggers.trigger_name%type;
	v_status all_triggers.status%type;
    no_triggers number;
	no_triggers2 number;
 	issue boolean := FALSE;
	issue_alr boolean := FALSE;
	issue_only_alr boolean := FALSE;
	cursor disabled_triggers (prod varchar2) is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR','HXT','HXC','HRI','BEN')
      and (table_name like upper(prod)||'%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
      order by 1, 2, 3;
  cursor disabled_triggers_pay is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR')
      and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
      order by 1, 2, 3;    
   cursor disabled_triggers_sshr is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR')
      and (table_name like 'PAY%' or table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
      order by 1, 2, 3;    
  cursor disabled_triggers_otl is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR','HXT','HXC')
      and (table_name like 'PAY%' or table_name like 'HX%')
      order by 1, 2, 3; 
  cursor disabled_triggers_all is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR','HXT','HXC','HRI','BEN')
      order by 1, 2, 3;
  cursor who_triggers is
	  select TABLE_NAME,TRIGGER_NAME,STATUS 
		  from all_triggers 
		  where UPPER(table_name) in 
			 ( 'PER_ALL_PEOPLE_F', 'PER_ALL_ASSIGNMENTS_F', 'PER_PERIODS_OF_SERVICE', 'PER_PERSON_TYPE_USAGES_F', 'PER_ADDRESSES'
			 , 'HR_LOCATIONS_ALL', 'HR_LOCATIONS_ALL_TL', 'HR_ALL_ORGANIZATION_UNITS', 'HR_ALL_ORGANIZATION_UNITS_TL', 'HR_ALL_POSITIONS_F'
			 , 'HR_ALL_POSITIONS_F_TL', 'PER_ALL_POSITIONS', 'PER_JOBS', 'PER_JOBS_TL')
		  and TRIGGER_NAME like '%WHO%'
		  and OWNER like 'APPS%'		  
		  order by table_name, trigger_name;
	cursor ovn_triggers is
	 select TABLE_NAME,TRIGGER_NAME,STATUS 
      from all_triggers 
      where OWNER like 'APPS%'
      and (trigger_name like 'HR%OVN%' or  trigger_name like 'PER%OVN%')
      order by owner, table_name;


begin

	  dbms_output.put_line(' <a name="triggers"></a>');
	  case upper(product) 
			when 'PAY' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'HR' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HRI') and (table_name like 'HR%' or table_name like 'PER%');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HRI') and (table_name like 'HR%' or table_name like 'PER%')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'SSHR' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'BEN' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','BEN')
				  and (table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','BEN')
				  and (table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'OTA' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','OTA')
				  and (table_name like 'OTA%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','OTA')
				  and (table_name like 'OTA%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'IRC' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','BEN')
				  and (table_name like 'IRC%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','BEN')
				  and (table_name like 'IRC%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'OTL' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HXT','HXC')
				  and (table_name like 'HX%' or table_name like 'PAY%');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HXT','HXC')
				  and (table_name like 'HX%' or table_name like 'PAY%')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			else
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HXT','HXC','HRI','BEN');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HXT','HXC','HRI','BEN')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
	  end case;

        
	if (issue and not issue_only_alr) or upper(run_type)='ALL' then
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql76b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql76'');" href="javascript:;">&#9654; Triggers</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql76" style="display:none" >');
		dbms_output.put_line(' <TR><TH>');
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql23b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql23'');" href="javascript:;">&#9654; Disabled Triggers</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql23" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Disabled triggers:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql24b" onclick="displayItem2(this,''s1sql24'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql24" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select owner, table_name, trigger_name <br>');
		dbms_output.put_line('                from dba_triggers <br>');
		dbms_output.put_line('                where status = ''DISABLED'' <br>');
		dbms_output.put_line('                and table_owner in (''HR'',''HXT'',''HXC'',''HRI'',''BEN'') <br>');
		CASE upper(product)
		WHEN 'HR' then
			dbms_output.put_line('                and (table_name like ''PER%'' or table_name like ''HR%'') <br>');
		WHEN 'PAY' then
			dbms_output.put_line('                and (table_name like ''PAY%'' or table_name like ''FF%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'SSHR' then
			dbms_output.put_line('                and (table_name like ''PAY%'' or table_name like ''BEN%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'BEN' then
			dbms_output.put_line('                and (table_name like ''BEN%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'OTA' then
			dbms_output.put_line('                and (table_name like ''OTA%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'OTL' then
			dbms_output.put_line('                and (table_name like ''HX%'' or table_name like ''PAY%'') <br>'); 
		WHEN 'IRC' then
			dbms_output.put_line('                and (table_name like ''IRC%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		ELSE
			null;
		end case;
		dbms_output.put_line('                order by 1, 2, 3; <br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Owner</B></TD>');
		dbms_output.put_line(' <TH><B>Table name</B></TD>');
		dbms_output.put_line(' <TH><B>Trigger Name</B></TD>');
	
		:n := dbms_utility.get_time;
    
		CASE upper(product)
		WHEN 'ALL' then
			  open disabled_triggers_all;
			  loop
				 fetch disabled_triggers_all into v_owner,v_table,v_trigger;
				 EXIT WHEN  disabled_triggers_all%NOTFOUND;
				 if v_trigger like 'ALR%' then
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					dbms_output.put_line('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			  end loop;
			  close disabled_triggers_all;
		WHEN 'PAY' then
			 open disabled_triggers_pay;
			  loop
				 fetch disabled_triggers_pay into v_owner,v_table,v_trigger;
				 EXIT WHEN  disabled_triggers_pay%NOTFOUND;
				 if v_trigger like 'ALR%' then
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					dbms_output.put_line('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			  end loop;
			close disabled_triggers_pay;
		WHEN 'OTL' then
			open disabled_triggers_otl;
			loop
			   fetch disabled_triggers_otl into v_owner,v_table,v_trigger;
			   EXIT WHEN  disabled_triggers_otl%NOTFOUND;
			   if v_trigger like 'ALR%' then
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					dbms_output.put_line('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			end loop;
			close disabled_triggers_otl;
		WHEN 'SSHR' then
			open disabled_triggers_sshr;
			loop
			   fetch disabled_triggers_sshr into v_owner,v_table,v_trigger;
			   EXIT WHEN  disabled_triggers_sshr%NOTFOUND;
			   if v_trigger like 'ALR%' then
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					dbms_output.put_line('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			end loop;
			close disabled_triggers_sshr;
		else
			open disabled_triggers(product);
			loop
				 fetch disabled_triggers into v_owner,v_table,v_trigger;
				 EXIT WHEN  disabled_triggers%NOTFOUND;
				 if v_trigger like 'ALR%' then
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					dbms_output.put_line('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			end loop;
			close disabled_triggers;
		end case;
    
    	
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
		
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql77b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql77'');" href="javascript:;">&#9654; WHO Triggers</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql77" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>WHO triggers:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail  id="s1sql78b"  onclick="displayItem2(this,''s1sql78'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD></TR>');
		dbms_output.put_line(' <TR id="s1sql78" style="display:none">');
		dbms_output.put_line('    <TD colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select TABLE_NAME,TRIGGER_NAME,STATUS from all_triggers  where UPPER(table_name) in <br>');
		dbms_output.put_line('	 ( ''PER_ALL_PEOPLE_F'', ''PER_ALL_ASSIGNMENTS_F'', ''PER_PERIODS_OF_SERVICE'', ''PER_PERSON_TYPE_USAGES_F'', ''PER_ADDRESSES''<br>');
		dbms_output.put_line('	 , ''HR_LOCATIONS_ALL'', ''HR_LOCATIONS_ALL_TL'', ''HR_ALL_ORGANIZATION_UNITS'', ''HR_ALL_ORGANIZATION_UNITS_TL'', ''HR_ALL_POSITIONS_F''<br>');
		dbms_output.put_line('	 , ''HR_ALL_POSITIONS_F_TL'', ''PER_ALL_POSITIONS'', ''PER_JOBS'', ''PER_JOBS_TL'')<br>');
		dbms_output.put_line('  and TRIGGER_NAME like ''%WHO%''  and OWNER like ''APPS%''	 order by table_name, trigger_name;<br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD></TR><TR>');
		dbms_output.put_line(' <TH><font face="Calibri"><B>Table name</B></TD>');
		dbms_output.put_line(' <TH><font face="Calibri"><B>Trigger Name</B></TD>');
		dbms_output.put_line(' <TH><font face="Calibri"><B>Status</B></TD>');
	
		:n := dbms_utility.get_time;   

		open who_triggers;
			loop
				 fetch who_triggers into v_table,v_trigger,v_status;
				 EXIT WHEN  who_triggers%NOTFOUND;
				 dbms_output.put_line('<TR><TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD>'||chr(10));
				 if v_status <> 'ENABLED' then
					dbms_output.put_line('<TD><font color="#CC3311">'||v_status||'</font></TD></TR>'||chr(10));
				 else
				    dbms_output.put_line('<TD>'||v_status||'</font></TD></TR>'||chr(10));
				 end if;
			end loop;
			close who_triggers;

		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
		
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql79b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql79'');" href="javascript:;">&#9654; OVN Triggers</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql79" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>OVN triggers:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail  id="s1sql80b"  onclick="displayItem2(this,''s1sql80'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql80" style="display:none">');
		dbms_output.put_line('    <TD colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select TABLE_NAME,TRIGGER_NAME,STATUS from all_triggers  where OWNER like ''APPS%''<br>');
		dbms_output.put_line('and (trigger_name like ''HR%OVN%'' or  trigger_name like ''PER%OVN%'')  order by owner, table_name; <br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD></TR><TR>');
		dbms_output.put_line(' <TH><font face="Calibri"><B>Table name</B></TD>');
		dbms_output.put_line(' <TH><font face="Calibri"><B>Trigger Name</B></TD>');
		dbms_output.put_line(' <TH><font face="Calibri"><B>Status</B></TD>');	
		:n := dbms_utility.get_time;    

		open ovn_triggers;
			loop
				 fetch ovn_triggers into v_table,v_trigger,v_status;
				 EXIT WHEN  ovn_triggers%NOTFOUND;
				 dbms_output.put_line('<TR><TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD>'||chr(10));
				 if v_status <> 'ENABLED' then
					dbms_output.put_line('<TD><font color="#CC3311">'||v_status||'</font></TD></TR>'||chr(10));
				 else
				    dbms_output.put_line('<TD>'||v_status||'</font></TD></TR>'||chr(10));
				 end if;
			end loop;
			close ovn_triggers;

    
     
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> </th></tr></table> </div> ');
		
		if issue and (not issue_alr) then
			dbms_output.put_line('<div class="divwarn">');
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You have disabled trigger(s).<br>');
			dbms_output.put_line('In order to re-enable use command: alter trigger trigger_name enable <br>');		
			dbms_output.put_line('</div>');	
			:w3:=:w3+1;
		elsif issue_only_alr then
			dbms_output.put_line('<div class="divok">');
			dbms_output.put_line('You have disabled trigger(s) only related to alert. These are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.<br>');
			dbms_output.put_line('</div>');
   		elsif issue_alr and (not issue_only_alr) then
			dbms_output.put_line('<div class="divwarn">');
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You have disabled trigger(s).<br>');
			dbms_output.put_line('In order to re-enable use command: alter trigger trigger_name enable<br>');
			dbms_output.put_line('You have disabled trigger(s) related to alert (ALR_). These are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.<br>Please focus on non ALR_ disabled triggers.<br>');
			dbms_output.put_line('</div>');
			:w3:=:w3+1;
		elsif upper(run_type)='ALL' and (not issue) then             
            dbms_output.put_line('<div class="divok">');
			dbms_output.put_line('<img class="check_ico">OK! No disabled trigger.<br>');
			dbms_output.put_line('</div>');
        end if;
		
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	end if;	
		
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Timestamp de-synchronization in database


declare
	run_type varchar2(20):='&1';
 	issue boolean := FALSE;
  v_problems number:=0;
begin
     select count(1) into v_problems
     from sys.obj$ do, sys.dependency$ d, sys.obj$ po
     where p_obj#=po.obj#(+)
     and d_obj#=do.obj#
     and do.status=1 /*dependent is valid*/
     and po.status=1 /*parent is valid*/
     and po.stime!=p_timestamp /*parent timestamp does not match*/
     and do.type# not in (28,29,30) /*dependent type is not java*/
     and po.type# not in (28,29,30) /*parent type is not java*/;
     
 
     IF v_problems>0 or upper(run_type)='ALL' then
              		dbms_output.put_line(' <a name="timestamp"></a>');
                  dbms_output.put_line('<DIV class=divItem>');
				  dbms_output.put_line('<DIV id="s1sql25b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql25'');" href="javascript:;">&#9654; Dependency timestamp discrepancies</A></DIV>');
                  
                  dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="0" id="s1sql25" style="display:none" >');
                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                  dbms_output.put_line('   <TH COLSPAN=0 bordercolor="#DEE6EF"><font face="Calibri">');
                  dbms_output.put_line('     <B>Dependency timestamp discrepancies between the database objects:</B></font></TD>');
                  dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                  dbms_output.put_line('<A class=detail id="s1sql26b" onclick="displayItem2(this,''s1sql26'');" href="javascript:;">&#9654; Show SQL Script</A>');
                  dbms_output.put_line('   </TD>');
                  dbms_output.put_line(' </TR>');
                  dbms_output.put_line(' <TR id="s1sql26" style="display:none">');
                  dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="0" height="60">');
                  dbms_output.put_line('       <blockquote><p align="left">');
                  dbms_output.put_line('          select count(1)  <br>');
                  dbms_output.put_line('                from sys.obj$ do, sys.dependency$ d, sys.obj$ po <br>');
                  dbms_output.put_line('                     where p_obj#=po.obj#(+)<br>');
                  dbms_output.put_line('                     and d_obj#=do.obj#<br>');
                  dbms_output.put_line('                     and do.status=1 /*dependent is valid*/<br>');
                  dbms_output.put_line('                     and po.status=1 /*parent is valid*/<br>');
                  dbms_output.put_line('                     and po.stime!=p_timestamp /*parent timestamp does not match*/<br>');
                  dbms_output.put_line('                     and do.type# not in (28,29,30) /*dependent type is not java*/<br>');
                  dbms_output.put_line('                     and po.type# not in (28,29,30) /*parent type is not java*/;<br>');
                  dbms_output.put_line('          </blockquote><br>');
                  dbms_output.put_line('     </TD>');
                  dbms_output.put_line('   </TR>');
                  dbms_output.put_line(' <TR>');
                  dbms_output.put_line(' <TH><B>Number</B></TD>');
                
                  :n := dbms_utility.get_time;
                  
                  dbms_output.put_line('<TR><TD>'||v_problems||'</TD></TR>'||chr(10));
                   
                
                  
                  :n := (dbms_utility.get_time - :n)/100;
                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                  dbms_output.put_line(' <TH COLSPAN=0 bordercolor="#DEE6EF"><font face="Calibri">');
                  dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                  dbms_output.put_line(' </TABLE> </div> ');
                  
				  
                  if v_problems>0 then
						:e3:=:e3+1;
						dbms_output.put_line('<div class="diverr">');
                        dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> You have dependency timestamp discrepancies between the database objects.<br>');
                        dbms_output.put_line('Please follow <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=370137.1" target="_blank">Note 370137.1</a>' );
                        dbms_output.put_line('After Upgrade, Some Packages Intermittently Fail with ORA-04065');                           
						dbms_output.put_line('</div>');
                  elsif upper(run_type)='ALL' then
                        dbms_output.put_line('<div class="divok">');
						dbms_output.put_line('<img class="check_ico">OK! No dependency timestamp discrepancies between the database objects found.<br>');
						dbms_output.put_line('</div>');
                  end if;
				  
				  dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
     end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



-- Packages version

declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
  wtf_version ad_file_versions.version%type;
  
  cursor package_vers(prod varchar2) is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where name like  upper(prod)||'%' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and line =2 
  order by Name; 

  cursor package_vers_otl is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where (name like 'HX%' or 
        name in ('PAGTCX',
        'PA_OTC_API',
        'PAY_BATCH_ELEMENT_ENTRY_API' ,
        'PAY_HR_OTC_RETRIEVAL_INTERFACE' ,
        'PAY_HXC_DEPOSIT_INTERFACE' ,
        'PAY_ZA_SOTC_PKG'  ,
        'PA_OTC_API' , 
        'PA_PJC_CWK_UTILS'  ,
        'PA_TIME_CLIENT_EXTN' ,
        'PO_HXC_INTERFACE_PVT',
        'RCV_HXT_GRP')
        ) 
  and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')   
  and line =2 
  order by Name; 
  
  cursor package_vers_hr is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where  (name like  'HR%' or name like 'PER%') and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and line =2 
  order by Name; 

  cursor package_vers_sshr is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where  (name like 'HR/_%' escape '/' or name like 'PER%') and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and line =2 
  order by Name; 
  
Begin

  if upper(run_type)='ALL'  then
    dbms_output.put_line('<a name="packages"></a>');
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql27b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql27'');" href="javascript:;">');
                  
	if upper(product) = 'PAY' then	
		dbms_output.put_line('&#9654; PAY Packages version</A></DIV>');
	elsif upper(product) = 'ALL' then
		dbms_output.put_line('&#9654; BEN Packages version</A></DIV>');
	else	
		dbms_output.put_line('&#9654; Packages version</A></DIV>');
	end if;
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql27" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Packages version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql28b" onclick="displayItem2(this,''s1sql28'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql28" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select Name as Package, <br>');
		dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		dbms_output.put_line('          from dba_source <br>');
    CASE upper(product) 
	WHEN 'OTL' then
        dbms_output.put_line('                where (name like ''HX%'' or <br>');
        dbms_output.put_line('                  name in (''PAGTCX'', <br>');
        dbms_output.put_line('                  ''PA_OTC_API'',<br>');
        dbms_output.put_line('                  ''PAY_BATCH_ELEMENT_ENTRY_API'' ,<br>');
        dbms_output.put_line('                  ''PAY_HR_OTC_RETRIEVAL_INTERFACE'' ,<br>');
        dbms_output.put_line('                  ''PAY_HXC_DEPOSIT_INTERFACE'' ,<br>');
        dbms_output.put_line('                  ''PAY_ZA_SOTC_PKG''  ,<br>');
        dbms_output.put_line('                  ''PA_OTC_API'' , <br>');
        dbms_output.put_line('                  ''PA_PJC_CWK_UTILS''  ,<br>');
        dbms_output.put_line('                  ''PA_TIME_CLIENT_EXTN'' ,<br>');
        dbms_output.put_line('                  ''PO_HXC_INTERFACE_PVT'',<br>');
        dbms_output.put_line('                  ''RCV_HXT_GRP''))<br>');    
    WHEN 'HR'  then    
        dbms_output.put_line('          where (name like ''HR%'' or name like ''PER%'') <br>');
    WHEN 'SSHR'  then    
        dbms_output.put_line('          where (name like ''HR/_%'' escape ''/'' or name like ''PER%'') <br>');
    WHEN 'PAY' then
        dbms_output.put_line('          where name like  ''PAY%'' <br>');
    WHEN 'BEN' then
        dbms_output.put_line('          where name like  ''BEN%'' <br>');
    WHEN 'OTA' then
        dbms_output.put_line('          where name like  ''OTA%'' <br>');
	WHEN 'IRC' then
        dbms_output.put_line('          where name like  ''IRC%'' <br>');
	WHEN 'ALL' then
		dbms_output.put_line('          where name like  ''BEN%'' <br>');
	ELSE
		null;
	end case;
    dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
	dbms_output.put_line('          order by Name;<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Name</B></TD>');
    dbms_output.put_line(' <TH><B>Type</B></TD>');
	dbms_output.put_line(' <TH><B>File</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    case upper(product) 
        when 'PAY' then
              open package_vers('PAY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
			  open package_vers('PY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
			  close package_vers;
          when 'HR' then
              open package_vers_hr;
              loop
                    fetch package_vers_hr into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers_hr%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers_hr;
          when 'SSHR' then
              open package_vers_sshr;
              loop
                    fetch package_vers_sshr into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers_sshr%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers_sshr;        
		 when 'BEN' then
              open package_vers ('BEN');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
           when 'OTA' then
              open package_vers ('OTA');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
		  when 'ALL' then
              open package_vers ('BEN');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
		  when 'IRC' then
              open package_vers ('IRC');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
		  when 'OTL' then                         
                select sub.version into wtf_version
                from (
                   select adf.filename filename,
                   afv.version version,
                   rank()over(partition by adf.filename
                     order by afv.version_segment1 desc,
                     afv.version_segment2 desc,afv.version_segment3 desc,
                     afv.version_segment4 desc,afv.version_segment5 desc,
                     afv.version_segment6 desc,afv.version_segment7 desc,
                     afv.version_segment8 desc,afv.version_segment9 desc,
                     afv.version_segment10 desc,
                     afv.translation_level desc) as rank1
                   from ad_file_versions afv,
                     (
                     select filename, app_short_name, subdir, file_id
                     from ad_files
                     where upper(filename) like upper('hxcempwf.wft') and subdir like '%US%'
                     ) adf
                   where adf.file_id = afv.file_id
                ) sub
                where rank1 = 1 and rownum < 2;
               dbms_output.put_line('<TR><TD>hxcempwf.wft</TD>'||chr(10)||'<TD>-</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line('hxcempwf.wft</TD>'||chr(10)||'<TD>'||wtf_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
              
              open package_vers_otl;
              loop
                    fetch package_vers_otl into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers_otl%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers_otl;
         
		 else
              null;
    end case;
  
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql27'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');
    

	 dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
  wtf_version ad_file_versions.version%type;
  
  cursor package_vers(prod varchar2) is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where name like  upper(prod)||'%' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and line =2 
  order by Name;  
  
Begin

  if upper(run_type)='ALL' and upper(product) in ( 'PAY', 'ALL') then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql272b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql272'');" href="javascript:;">');
	if upper(product) = 'PAY' then	
		dbms_output.put_line('&#9654; FF Packages version</A></DIV>');
	elsif upper(product) = 'ALL' then
		dbms_output.put_line('&#9654; IRC Packages version</A></DIV>');
	end if;
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql272" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Packages version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql282b" onclick="displayItem2(this,''s1sql282'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql282" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select Name as Package, <br>');
		dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		dbms_output.put_line('          from dba_source <br>');
    if upper(product) = 'PAY' then
        dbms_output.put_line('          where name like ''FF%'' <br>');
    else   
        dbms_output.put_line('          where name like  ''IRC%'' <br>');
	end if;
    dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
	dbms_output.put_line('          order by Name;<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Name</B></TD>');
    dbms_output.put_line(' <TH><B>Type</B></TD>');
	dbms_output.put_line(' <TH><B>File</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    case upper(product) 
        when 'PAY' then
              open package_vers('FF');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;      
		  when 'ALL' then
              open package_vers ('IRC');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;		
		 else
              null;
    end case;
  
    
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql272'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE></div> ');
    

	  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
  wtf_version ad_file_versions.version%type;
  
   cursor package_vers_hr is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where  (name like  'HR%' or name like 'PER%') and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and line =2 
  order by Name;   
  
Begin

  if upper(run_type)='ALL' and upper(product) in ( 'PAY', 'ALL') then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql273b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql273'');" href="javascript:;">');
	dbms_output.put_line('&#9654; HR Packages version</A></DIV>');
	
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql273" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Packages version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql283b" onclick="displayItem2(this,''s1sql283'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql283" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select Name as Package, <br>');
		dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		dbms_output.put_line('          from dba_source <br>');
    dbms_output.put_line('          where (name like  ''HR%'' or name like ''PER%'') <br>');
    dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
	dbms_output.put_line('          order by Name;<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Name</B></TD>');
    dbms_output.put_line(' <TH><B>Type</B></TD>');
	dbms_output.put_line(' <TH><B>File</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    open package_vers_hr;
              loop
                    fetch package_vers_hr into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers_hr%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
    close package_vers_hr;
  
    
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql273'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE></div> ');
    

	  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/



declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
  wtf_version ad_file_versions.version%type;
  
   cursor package_vers_otl is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where (name like 'HX%' or 
        name in ('PAGTCX',
        'PA_OTC_API',
        'PAY_BATCH_ELEMENT_ENTRY_API' ,
        'PAY_HR_OTC_RETRIEVAL_INTERFACE' ,
        'PAY_HXC_DEPOSIT_INTERFACE' ,
        'PAY_ZA_SOTC_PKG'  ,
        'PA_OTC_API' , 
        'PA_PJC_CWK_UTILS'  ,
        'PA_TIME_CLIENT_EXTN' ,
        'PO_HXC_INTERFACE_PVT',
        'RCV_HXT_GRP')
        ) 
  and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and line =2 
  order by Name;  
  
Begin

  if upper(run_type)='ALL' and upper(product) = 'ALL' then
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql274b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql274'');" href="javascript:;">');
	dbms_output.put_line('&#9654; OTL Packages version</A></DIV>');
	
	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql274" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Packages version:</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql284b" onclick="displayItem2(this,''s1sql284'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql284" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          select Name as Package, <br>');
	dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
	dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
	dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
	dbms_output.put_line('          from dba_source <br>');
	dbms_output.put_line('                where (name like ''HX%'' or <br>');
    dbms_output.put_line('                  name in (''PAGTCX'', <br>');
    dbms_output.put_line('                  ''PA_OTC_API'',<br>');
    dbms_output.put_line('                  ''PAY_BATCH_ELEMENT_ENTRY_API'' ,<br>');
    dbms_output.put_line('                  ''PAY_HR_OTC_RETRIEVAL_INTERFACE'' ,<br>');
    dbms_output.put_line('                  ''PAY_HXC_DEPOSIT_INTERFACE'' ,<br>');
    dbms_output.put_line('                  ''PAY_ZA_SOTC_PKG''  ,<br>');
    dbms_output.put_line('                  ''PA_OTC_API'' , <br>');
    dbms_output.put_line('                  ''PA_PJC_CWK_UTILS''  ,<br>');
    dbms_output.put_line('                  ''PA_TIME_CLIENT_EXTN'' ,<br>');
    dbms_output.put_line('                  ''PO_HXC_INTERFACE_PVT'',<br>');
    dbms_output.put_line('                  ''RCV_HXT_GRP''))<br>');    
    dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
	dbms_output.put_line('          order by Name;<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Name</B></TD>');
    dbms_output.put_line(' <TH><B>Type</B></TD>');
	dbms_output.put_line(' <TH><B>File</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    select sub.version into wtf_version
                from (
                   select adf.filename filename,
                   afv.version version,
                   rank()over(partition by adf.filename
                     order by afv.version_segment1 desc,
                     afv.version_segment2 desc,afv.version_segment3 desc,
                     afv.version_segment4 desc,afv.version_segment5 desc,
                     afv.version_segment6 desc,afv.version_segment7 desc,
                     afv.version_segment8 desc,afv.version_segment9 desc,
                     afv.version_segment10 desc,
                     afv.translation_level desc) as rank1
                   from ad_file_versions afv,
                     (
                     select filename, app_short_name, subdir, file_id
                     from ad_files
                     where upper(filename) like upper('hxcempwf.wft') and subdir like '%US%'
                     ) adf
                   where adf.file_id = afv.file_id
                ) sub
                where rank1 = 1 and rownum < 2;
               dbms_output.put_line('<TR><TD>hxcempwf.wft</TD>'||chr(10)||'<TD>-</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line('hxcempwf.wft</TD>'||chr(10)||'<TD>'||wtf_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
              
    open package_vers_otl;
              loop
                    fetch package_vers_otl into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers_otl%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
    close package_vers_otl;
  
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql274'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');
    

	 dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
  wtf_version ad_file_versions.version%type;
  
  cursor package_vers(prod varchar2) is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where name like  upper(prod)||'%' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and line =2 
  order by Name; 
  
Begin

  if upper(run_type)='ALL' and upper(product) = 'ALL' then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql276b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql276'');" href="javascript:;">');
	dbms_output.put_line('&#9654; OTA Packages version</A></DIV>');
	
	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql276" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Packages version:</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql286b" onclick="displayItem2(this,''s1sql286'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql286" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          select Name as Package, <br>');
	dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
	dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
	dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
	dbms_output.put_line('          from dba_source <br>');
    dbms_output.put_line('          where name like  ''OTA%'' <br>');
    dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
	dbms_output.put_line('          order by Name;<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Name</B></TD>');
    dbms_output.put_line(' <TH><B>Type</B></TD>');
	dbms_output.put_line(' <TH><B>File</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    open package_vers('OTA');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
    close package_vers;
  
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql276'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');
    

	 dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
  wtf_version ad_file_versions.version%type;
  
  cursor package_vers(prod varchar2) is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where name like  upper(prod)||'%' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type in('PACKAGE','PACKAGE BODY')  
  and line =2 
  order by Name; 
  
Begin

  if upper(run_type)='ALL' and upper(product) = 'ALL' then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql275b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql275'');" href="javascript:;">');
	dbms_output.put_line('&#9654; PAY Packages version</A></DIV>');
	
	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql275" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Packages version:</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql285b" onclick="displayItem2(this,''s1sql285'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql285" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          select Name as Package, <br>');
	dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
	dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
	dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
	dbms_output.put_line('          from dba_source <br>');
    dbms_output.put_line('          where name like  ''PAY%'' <br>');
    dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
	dbms_output.put_line('          order by Name;<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Name</B></TD>');
    dbms_output.put_line(' <TH><B>Type</B></TD>');
	dbms_output.put_line(' <TH><B>File</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    open package_vers('PAY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
    close package_vers;
	open package_vers('PY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
    close package_vers;
  
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql275'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');
    

	 dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Java classes version


declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;
  
  


Begin

  if upper(run_type)='ALL'  then
    dbms_output.put_line('<a name="java"></a>');
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql47b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql47'');" href="javascript:;">');
	if upper(product)='ALL' then
		dbms_output.put_line('&#9654; BEN Java Classes Version</A></DIV>');
	elsif upper(product)='PAY' then
		dbms_output.put_line('&#9654; PAY Java Classes Version</A></DIV>');
	else
		dbms_output.put_line('&#9654; Java Classes Version</A></DIV>');
	end if;
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql47" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Java version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql48b" onclick="displayItem2(this,''s1sql48'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql48" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
		dbms_output.put_line('            from (<br>');
		dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
		dbms_output.put_line('               file_version.version version,<br>');
		dbms_output.put_line('               rank()over(partition by files.filename<br>');
		dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
		dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
		dbms_output.put_line('               from ad_file_versions file_version,<br>');
		dbms_output.put_line('                 (<br>');
		dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
		dbms_output.put_line('                 from ad_files<br>');
    CASE upper(product) 
	WHEN 'OTL' then
    	dbms_output.put_line('                 where app_short_name=''HXC'' and upper(filename) like upper(''%.class'')<br>');
    WHEN 'HR' then
        dbms_output.put_line('                 where app_short_name=''PER'' and upper(filename) like upper(''%.class'')<br>');
    WHEN 'SSHR' then
        dbms_output.put_line('                 where app_short_name=''PER'' and upper(filename) like upper(''%.class'')<br>');
	WHEN 'PAY' then
        dbms_output.put_line('                 where app_short_name=''PAY'' and upper(filename) like upper(''%.class'')<br>');
    WHEN 'BEN' then
        dbms_output.put_line('                 where app_short_name=''BEN'' and upper(filename) like upper(''%.class'')<br>');
    WHEN 'OTA' then
        dbms_output.put_line('                 where app_short_name=''OTA'' and upper(filename) like upper(''%.class'')<br>');
	WHEN 'ALL' then
        dbms_output.put_line('                 where app_short_name=''BEN'' and upper(filename) like upper(''%.class'')<br>');
	WHEN 'IRC' then
        dbms_output.put_line('                 where app_short_name=''IRC'' and upper(filename) like upper(''%.class'')<br>');
	ELSE
		null;
	end case;
    
		dbms_output.put_line('                 ) files<br>');
		dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
		dbms_output.put_line('            ) que<br>');
		dbms_output.put_line('            where rank1 = 1<br>');
		dbms_output.put_line('            order by 1,2;<br>');  
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>File directory</B></TD>');
    dbms_output.put_line(' <TH><B>Filename</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
   case upper(product) 
        when 'PAY' then
              open java_vers('PAY');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
          when 'HR' then
              open java_vers('PER');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
          when 'SSHR' then
              open java_vers('PER');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
		  when 'BEN' then
              open java_vers('BEN');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
		  when 'ALL' then
              open java_vers('BEN');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
		  when 'IRC' then
              open java_vers('IRC');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers; 
		  when 'OTL' then                         
              open java_vers('HXC');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
		  when 'OTA' then                         
              open java_vers('OTA');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
         else
              null;
    end case;
  
    
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql47'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE></div> ');
    

	  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/




declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;
  
  


Begin

  if upper(run_type)='ALL' and (:apps_rel like '12.%') and upper(product) in ('PAY','ALL','IRC') then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql472b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql472'');" href="javascript:;">');
	if upper(product) in ('ALL','IRC') then
		dbms_output.put_line('&#9654; IRC Java Classes Version</A></DIV>');
	elsif upper(product)='PAY' then
		dbms_output.put_line('&#9654; FF Java Classes Version</A></DIV>');	
	end if;
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql472" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Java version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql482b" onclick="displayItem2(this,''s1sql482'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql482" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
		dbms_output.put_line('            from (<br>');
		dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
		dbms_output.put_line('               file_version.version version,<br>');
		dbms_output.put_line('               rank()over(partition by files.filename<br>');
		dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
		dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
		dbms_output.put_line('               from ad_file_versions file_version,<br>');
		dbms_output.put_line('                 (<br>');
		dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
		dbms_output.put_line('                 from ad_files<br>');
 	if upper(product) in ('ALL','IRC') then
        dbms_output.put_line('                 where app_short_name=''IRC'' and upper(filename) like upper(''%.class'')<br>'); 
	else
		dbms_output.put_line('                 where app_short_name=''FF'' and upper(filename) like upper(''%.class'')<br>');
	end if;
    
		dbms_output.put_line('                 ) files<br>');
		dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
		dbms_output.put_line('            ) que<br>');
		dbms_output.put_line('            where rank1 = 1<br>');
		dbms_output.put_line('            order by 1,2;<br>');  
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>File directory</B></TD>');
    dbms_output.put_line(' <TH><B>Filename</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
   if upper(product) in ('PAY') then
              open java_vers('FF');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
	elsif upper(product) in ('ALL','IRC') then
              open java_vers('IRC');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers; 		  
    end if;
  
    
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql472'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE></div> ');
    

	  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;
  
  


Begin

  if upper(run_type)='ALL'  and upper(product) ='ALL' then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql473b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql473'');" href="javascript:;">');
	dbms_output.put_line('&#9654; PAY Java Classes Version</A></DIV>');	
		dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql473" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Java version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql483b" onclick="displayItem2(this,''s1sql483'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql483" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
		dbms_output.put_line('            from (<br>');
		dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
		dbms_output.put_line('               file_version.version version,<br>');
		dbms_output.put_line('               rank()over(partition by files.filename<br>');
		dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
		dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
		dbms_output.put_line('               from ad_file_versions file_version,<br>');
		dbms_output.put_line('                 (<br>');
		dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
		dbms_output.put_line('                 from ad_files<br>');
		dbms_output.put_line('                 where app_short_name=''PAY'' and upper(filename) like upper(''%.class'')<br>');   
    
		dbms_output.put_line('                 ) files<br>');
		dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
		dbms_output.put_line('            ) que<br>');
		dbms_output.put_line('            where rank1 = 1<br>');
		dbms_output.put_line('            order by 1,2;<br>');  
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>File directory</B></TD>');
    dbms_output.put_line(' <TH><B>Filename</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
              open java_vers('PAY');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
  
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql473'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');
    

	 dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/




declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;
  
  


Begin

  if upper(run_type)='ALL'  and upper(product) in ('ALL','PAY','IRC') then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql474b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql474'');" href="javascript:;">');
	if :apps_rel like '11.5%' then
		dbms_output.put_line('&#9654; PER and IRC Java Classes Version</A></DIV>');
	else
		dbms_output.put_line('&#9654; PER Java Classes Version</A></DIV>');
	end if;
	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql474" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Java version:</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql484b" onclick="displayItem2(this,''s1sql484'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql484" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
	dbms_output.put_line('            from (<br>');
	dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
	dbms_output.put_line('               file_version.version version,<br>');
	dbms_output.put_line('               rank()over(partition by files.filename<br>');
	dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
	dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
	dbms_output.put_line('               from ad_file_versions file_version,<br>');
	dbms_output.put_line('                 (<br>');
	dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
	dbms_output.put_line('                 from ad_files<br>');
	dbms_output.put_line('                 where app_short_name=''PER'' and upper(filename) like upper(''%.class'')<br>');   
    
	dbms_output.put_line('                 ) files<br>');
	dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
	dbms_output.put_line('            ) que<br>');
	dbms_output.put_line('            where rank1 = 1<br>');
	dbms_output.put_line('            order by 1,2;<br>');  
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>File directory</B></TD>');
    dbms_output.put_line(' <TH><B>Filename</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    open java_vers('PER');
    v_dir_old:='';
    loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
    end loop;
    close java_vers;
  
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql474'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');
    

	dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/




declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;
  
  


Begin

  if upper(run_type)='ALL'  and upper(product) ='ALL' then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql475b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql475'');" href="javascript:;">');
	dbms_output.put_line('&#9654; OTL Java Classes Version</A></DIV>');	
	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql475" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Java version:</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql485b" onclick="displayItem2(this,''s1sql485'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql485" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
	dbms_output.put_line('            from (<br>');
	dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
	dbms_output.put_line('               file_version.version version,<br>');
	dbms_output.put_line('               rank()over(partition by files.filename<br>');
	dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
	dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
	dbms_output.put_line('               from ad_file_versions file_version,<br>');
	dbms_output.put_line('                 (<br>');
	dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
	dbms_output.put_line('                 from ad_files<br>');
	dbms_output.put_line('                 where app_short_name=''HXC'' and upper(filename) like upper(''%.class'')<br>');   
    
	dbms_output.put_line('                 ) files<br>');
	dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
	dbms_output.put_line('            ) que<br>');
	dbms_output.put_line('            where rank1 = 1<br>');
	dbms_output.put_line('            order by 1,2;<br>');  
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>File directory</B></TD>');
    dbms_output.put_line(' <TH><B>Filename</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    open java_vers('HXC');
    v_dir_old:='';
    loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
    end loop;
    close java_vers;
  
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql475'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');
    

	dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
 
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;
  
  


Begin

  if upper(run_type)='ALL'  and upper(product) ='ALL' then
    dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql476b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql476'');" href="javascript:;">');
	dbms_output.put_line('&#9654; OTA Java Classes Version</A></DIV>');	
	dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql476" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Java version:</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql486b" onclick="displayItem2(this,''s1sql486'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql486" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
	dbms_output.put_line('            from (<br>');
	dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
	dbms_output.put_line('               file_version.version version,<br>');
	dbms_output.put_line('               rank()over(partition by files.filename<br>');
	dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
	dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
	dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
	dbms_output.put_line('               from ad_file_versions file_version,<br>');
	dbms_output.put_line('                 (<br>');
	dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
	dbms_output.put_line('                 from ad_files<br>');
	dbms_output.put_line('                 where app_short_name=''OTA'' and upper(filename) like upper(''%.class'')<br>');   
    
	dbms_output.put_line('                 ) files<br>');
	dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
	dbms_output.put_line('            ) que<br>');
	dbms_output.put_line('            where rank1 = 1<br>');
	dbms_output.put_line('            order by 1,2;<br>');  
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>File directory</B></TD>');
    dbms_output.put_line(' <TH><B>Filename</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    open java_vers('OTA');
    v_dir_old:='';
    loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
    end loop;
    close java_vers;
  
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql476'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');
    

	dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
  dbms_output.put_line('</div>');
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/




-- Purging issues

declare
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  status varchar2(160);
  last_date date;
  status2 varchar2(160);
  last_date2 date;
  need_run boolean:=FALSE;
  days number;
  no_rows number;
  no_rows_fnd number;
  no_rows_wf number;
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;  
  arg FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_no_rows number; 

begin
	:n := dbms_utility.get_time;
	
	dbms_output.put_line('</div>');
    if upper(product) in ('HR','SSHR', 'OTL','OTA','IRC','ALL') then
	dbms_output.put_line('<div id="page6" style="display: none;">');
	dbms_output.put_line('<a name="workflow"></a><a name="stuck"></a><div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="workflow" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Workflow Details: '); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF"> /  </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
	if upper(run_type)='ALL' then
	dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	 if product in ('HR','SSHR','OTL','ALL') then
			  dbms_output.put_line('<a class=detail2 href="#purge">Purging</a> <br>');
		  end if;
	  dbms_output.put_line('<a class=detail2 href="#stuck">Workflows with Errors</a> <br></td><tr></table>');       
	dbms_output.put_line('</div><br>');
	end if;
	if upper(product) in ('OTL','ALL') then
        
        select wf_purge.getpurgeablecount('HXCEMP') into no_rows_wf from dual;
        if no_rows_wf>1000 then
            issue1:=TRUE;
        end if;        
	end if;
	
	if upper(product) in ('HR','SSHR','ALL') then
        
        SELECT count(1) into no_rows        
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'COMPLETE DEFUNCT HR WORKFLOW%'
				AND upper(PHAS.MEANING || ' ' || STAT.MEANING)=upper('Completed Normal');
                
                if no_rows=0 then
                      issue2:=TRUE;
                else
                      SELECT * 
                      into status2,last_date2, arg
                      FROM (
                      SELECT PHAS.MEANING || ' ' || STAT.MEANING        
                      ,ACTUAL_COMPLETION_DATE , ARGUMENT_TEXT        
                      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'COMPLETE DEFUNCT HR WORKFLOW%'
					  AND upper(PHAS.MEANING || ' ' || STAT.MEANING)=upper('Completed Normal')
                      ORDER BY 2 desc)
                      where rownum < 2;
              
                      select  sysdate-last_date2 into days from dual;
						  if days>180 then
								issue4:=TRUE;
						  end if;
					  
              
                end if; 
   end if;
    
    :n := (dbms_utility.get_time - :n)/100;
    
    if upper(product) in ('OTL', 'HR','SSHR', 'ALL') then 
        if run_type='ALL' or issue2 or issue4 or issue1 then
                
                dbms_output.put_line(' <a name="purge"></a>');
				dbms_output.put_line('<DIV class=divItem>');
				dbms_output.put_line('<DIV id="s1sql15b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql15'');" href="javascript:;">&#9654; Purging Issues</A></DIV>');		
				
                dbms_output.put_line(' <TABLE width="95%"  border="1" cellspacing="0" cellpadding="2" id="s1sql15" style="display:none" >');
                dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                dbms_output.put_line('     <B>Purging issues:</B></TD>');
                dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                dbms_output.put_line('<A class=detail id="s1sql16b" onclick="displayItem2(this,''s1sql16'');" href="javascript:;">&#9654; Show SQL Script</A>');
                dbms_output.put_line('   </TD>');
                dbms_output.put_line(' </TR>');
                dbms_output.put_line(' <TR id="s1sql16" style="display:none">');
                dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
                dbms_output.put_line('       <blockquote><p align="left">');
                if upper(product) in ('HR', 'SSHR', 'ALL') then
                      dbms_output.put_line('          SELECT * FROM (<br>');
                      dbms_output.put_line('          SELECT PHAS.MEANING || '' '' || STAT.MEANING pStatus <br>');      
                      dbms_output.put_line('          ,ACTUAL_COMPLETION_DATE pEndDate     ');   
                      dbms_output.put_line('          FROM FND_CONC_REQ_SUMMARY_V fcrs , FND_LOOKUPS STAT, FND_LOOKUPS PHAS<br>');
                      dbms_output.put_line('          WHERE STAT.LOOKUP_CODE = FCRS.STATUS_CODE<br>');
                      dbms_output.put_line('          AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE''<br>');
                      dbms_output.put_line('          AND PHAS.LOOKUP_CODE = FCRS.PHASE_CODE<br>');
                      dbms_output.put_line('          AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE''<br>');
                      dbms_output.put_line('          AND UPPER(program) LIKE ''COMPLETE DEFUNCT HR WORKFLOW%''<br>');
					  dbms_output.put_line('          AND upper(PHAS.MEANING || '' '' || STAT.MEANING)=upper(''Completed Normal'')<br>');
                      dbms_output.put_line('          ORDER BY 2 desc)<br>');
                      dbms_output.put_line('          where rownum < 2;<br><br>');       
                end if;
                if upper(product) in ('OTL', 'ALL') then
                      dbms_output.put_line('          select wf_purge.getpurgeablecount(''HXCEMP'') from dual; <br>');            
                end if;
                dbms_output.put_line('          </blockquote><br>');
                dbms_output.put_line('     </TD>');
                dbms_output.put_line('   </TR>');
                dbms_output.put_line(' <TR>');
				if upper(product) in ('OTL') then
					dbms_output.put_line(' <TH><B>Purgeable Obsolete Workflow</B></TD>');
					dbms_output.put_line(' <TH><B>Purgeable Workflow Count</B></TD>');
				else
					dbms_output.put_line(' <TH><B>Issue</B></TD>');
					dbms_output.put_line(' <TH><B>Status</B></TD>');
                end if;
				
               
				if upper(product) in ('HR','SSHR', 'ALL') then
                        
                       if issue2 then
								dbms_output.put_line('<TR><TD>'||'Complete Defunct HR Workflow Processes'||'</TD>'||chr(10)||'<TD><font color="red">Never completed normal</font></TD></TR>'||chr(10));
						elsif issue4 then
								dbms_output.put_line('<TR><TD>'||'Complete Defunct HR Workflow Processes'||'</TD>'||chr(10)||'<TD>Status: '||status2||' - Last run completed normal: <font color="red">');
								dbms_output.put_line(last_date2||'</font> - Parameters: '||arg||'</TD></TR>'||chr(10));
						else
								dbms_output.put_line('<TR><TD>'||'Complete Defunct HR Workflow Processes'||'</TD>'||chr(10)||'<TD>Status: '||status2||' - Last run completed normal: ');
								dbms_output.put_line(last_date2||' - Parameters: '||arg||'</TD></TR>'||chr(10));
						end if;
						
                end if;
                
                if upper(product) in ('OTL', 'ALL') then
                       if issue1 then
                              dbms_output.put_line('<TR><TD>'||'<font color="red">wf_purge.getpurgeablecount(''HXCEMP'') </font>'||'</TD>'||chr(10)||'<TD><font color="red">'||no_rows_wf||' rows</font></TD></TR>'||chr(10));
                        else
                              dbms_output.put_line('<TR><TD>'||'wf_purge.getpurgeablecount(''HXCEMP'') '||'</TD>'||chr(10)||'<TD>'||no_rows_wf||' rows</TD></TR>'||chr(10));
                        end if;   
                end if;               

              
                
               
                dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                dbms_output.put_line(' </TABLE> </div> ');
              
			  
                if upper(product) in ('HR','SSHR', 'ALL') then                      
                     if issue4 then                          
						  dbms_output.put_line('<div class="divok">');
						  dbms_output.put_line('<font color="blue">Advice: </font>You did not performed ''Complete Defunct HR Workflow Processes'' in last 6 months.<br>  ');
						  dbms_output.put_line('</div>');
					end if;
					if issue2 then
					  dbms_output.put_line('<div class="divwarn">');
                      dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> ''Complete Defunct HR Workflow Processes'' never Completed Normal.<br>  ');
					  :w6:=:w6+1;                       
					  dbms_output.put_line('</div>');
                    end if;
					if issue2 or issue4 then					
                      dbms_output.put_line('<div class="divok">');
					  dbms_output.put_line('Please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=237524.1" target="_blank" >Note 237524.1</a> How to Run the HR Workflow Cleanup Process (HRWFDFCT)<br>');
					  dbms_output.put_line('</div>');
					  
                    end if;
              end if;
              if upper(product) in ('OTL', 'ALL') then
                      if issue1 then
                          dbms_output.put_line('<div class="divwarn">');
						  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Your Purgeable Workflow count (for HXCEMP) is more than 1000. ');
                          dbms_output.put_line('Please run ''Purge Obsolete Workflow Runtime Data'' with (Item Type = OTL Workflows for Employees) from System Administrator responsibility.<br> ');
						  dbms_output.put_line('</div>');
						  :w6:=:w6+1;
                      end if; 
              end if;
              
              if (not issue2) and (not issue1) and (not issue4) then
                    dbms_output.put_line('<div class="divok">');
					dbms_output.put_line('All verified checks are <img class="check_ico">OK!');
					dbms_output.put_line('</div>');
              end if;		  
			 
              
              dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
          end if; 
  end if;
  end if;
	
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/


-- Display Workflow Stuck issues
declare
	  run_type varchar2(20):='&1';
	  product varchar2(20):='&2';
	  v_it wf_process_activities.PROCESS_ITEM_TYPE%type; 
	  v_activity wf_process_activities.ACTIVITY_NAME%type;
	  v_ik wf_items.ITEM_KEY%type;
	  v_it_old wf_process_activities.PROCESS_ITEM_TYPE%type; 
	  v_activity_old wf_process_activities.ACTIVITY_NAME%type;
	  v_code wf_item_activity_statuses.activity_result_code%type;	 
	  v_date  wf_items.begin_date%type;
	  v_err_name varchar2(10000);
	  v_err_name_old varchar2(10000);
	  v_process_activity wf_item_activity_statuses.process_activity%type;
	  v_big_no number :=1;
	  v_big_no2 number :=1;
	  v_rows number;
	  v_count number;
	
		cursor sshr_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.process_item_type in  ('HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC')
			and ROWNUM<1000
			order by 1,2,4,5;

		cursor otl_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.PROCESS_ITEM_TYPE in  ('HXCEMP', 'HXCSAW')
			and ROWNUM<1000
			order by 1,2,4,5;
		cursor irc_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.PROCESS_ITEM_TYPE in  ('HRSSA','HRSFL','IRC_WF','IRCOFFER','IRC_NTF','IRC_REG')
			and ROWNUM<1000
			order by 1,2,4,5;
		cursor all_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.PROCESS_ITEM_TYPE in  ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'IRC_WF','IRC_REG','OTWF', 'HRCKLTSK', 'HRSSA', 'HRSFL','HRWPM', 'HRRIRPRC', 'PSPERAVL')
			and ROWNUM<1000
			order by 1,2,4,5;
		cursor ota_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.PROCESS_ITEM_TYPE in  ('OTWF')
			and ROWNUM<1000
			order by 1,2,4,5;
		        
begin
if upper(product) in ('HR','SSHR', 'OTL','OTA','IRC','ALL') then
		case upper(product)
			when 'SSHR' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'					
					AND p.PROCESS_ITEM_TYPE in  ('HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC');	
			when 'HR' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'					
					AND p.PROCESS_ITEM_TYPE in  ('HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC');
			when 'OTL' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'
					AND p.PROCESS_ITEM_TYPE in  ('HXCEMP', 'HXCSAW');	
			when 'OTA' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'
					AND p.PROCESS_ITEM_TYPE in  ('OTWF');
			when 'IRC' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'
					AND p.PROCESS_ITEM_TYPE in  ('HRSSA','HRSFL','IRC_WF','IRCOFFER','IRC_NTF','IRC_REG');	
			when 'ALL' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'
					AND p.PROCESS_ITEM_TYPE in  ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'IRC_WF','IRC_REG','OTWF',  'HRCKLTSK', 'HRSSA', 'HRSFL','HRWPM', 'HRRIRPRC', 'PSPERAVL');	
			else
							null;
		end case;
		
		if upper(run_type)='ALL' or v_rows>0 then	
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql55b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql55'');" href="javascript:;">&#9654; Workflows with Errors</A></DIV>');
			
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql55" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Workflows with Errors</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail  id="s1sql56b"  onclick="displayItem2(this,''s1sql56'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql56" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
    
		dbms_output.put_line('         select p.process_item_type, p.activity_name, activity_result_code, wi.item_key, substr(s.error_message,1,200), wi.begin_date<br>');
		dbms_output.put_line('         	FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi<br>');
		dbms_output.put_line('         	WHERE p.instance_id = s.process_activity<br>');
		dbms_output.put_line('         	and wi.item_type = s.item_type<br>');
		dbms_output.put_line('         	and wi.item_key = s.item_key<br>');
		dbms_output.put_line('         	AND activity_status = ''ERROR''<br>');			
		dbms_output.put_line('         	AND p.PROCESS_ITEM_TYPE in <br>');		
		case upper(product)
						WHEN 'SSHR' then
							dbms_output.put_line('     (''HRCKLTSK'', ''HRSSA'', ''HRWPM'', ''HRRIRPRC'')<br>');
						WHEN 'HR' then
							dbms_output.put_line('     (''HRCKLTSK'', ''HRSSA'', ''HRWPM'', ''HRRIRPRC'')<br>');
						WHEN 'OTL' then
							dbms_output.put_line('    (''HXCEMP'', ''HXCSAW'')<br>');							
						WHEN 'OTA' then
							dbms_output.put_line('    (''OTWF'')<br>');
						WHEN 'IRC' then
							dbms_output.put_line('  (''HRSSA'',''HRSFL'',''IRC_WF'',''IRCOFFER'',''IRC_NTF'',''IRC_REG'')<br>');
						WHEN 'ALL' then						
								dbms_output.put_line('    (''BENCWBFY'', ''SSBEN'', ''GHR_SF52'', ''HXCEMP'', ''HXCSAW'', ''IRC_NTF'', ''IRCOFFER'', ''IRC_WF'',''IRC_REG'',<br>');
								dbms_output.put_line('     ''OTWF'', ''HRCKLTSK'', ''HRSSA'', ''HRSFL'',''HRWPM'', ''HRRIRPRC'', ''PSPERAVL'')<br>');
						else
							null;
		end case;
		dbms_output.put_line('         	and ROWNUM<1000<br>');
		dbms_output.put_line('         	order by 1,2,4,5;<br>');    
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Item Type</B></TD>');
		dbms_output.put_line(' <TH width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Activity</B></TD>');
		dbms_output.put_line(' <TH width="50%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Error Message (first 200 characters)</B></TD>');
		dbms_output.put_line(' <TH width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Count of errors</B></TD>');
		dbms_output.put_line(' <TH width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Show Details</B></TD>');
    
    
	:n := dbms_utility.get_time;
	
	if v_rows>0 then
		if v_rows>1000 then
			dbms_output.put_line('<TR><TD COLSPAN=5>You have more than 1000 workflows with errors. Error list truncated.</TD><TR>');
		end if;
	
				v_it_old:='x';
				v_activity_old:='x';
				v_err_name_old:='x';
				case upper(product)
					WHEN 'SSHR' then
						open sshr_workflow;
					WHEN 'HR' then
						open sshr_workflow;
					WHEN 'OTL' then
						open otl_workflow;							
					WHEN 'IRC' then
						open irc_workflow;
					WHEN 'OTA' then
						open ota_workflow;
					WHEN 'ALL' then						
						open all_workflow;
					else
							null;				
				end case;
				loop
						case upper(product)
							WHEN 'SSHR' then
								fetch sshr_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  sshr_workflow%NOTFOUND;
							WHEN 'HR' then
								fetch sshr_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  sshr_workflow%NOTFOUND;
							WHEN 'OTL' then
								fetch otl_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  otl_workflow%NOTFOUND;							
							WHEN 'OTA' then
								fetch ota_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  ota_workflow%NOTFOUND;	
							WHEN 'IRC' then
								fetch irc_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  irc_workflow%NOTFOUND;
							WHEN 'ALL' then						
								fetch all_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  all_workflow%NOTFOUND;
							else
							null;
						end case;								  
								
								if v_it<>v_it_old or v_activity<>v_activity_old or v_err_name<>v_err_name_old then
										  if v_big_no>1 then
												v_big_no2 :=v_big_no-1;
												dbms_output.put_line('<tr><td><A class=detail onclick="hideRow2(''s1sql200'||v_big_no2||''');" href="javascript:;">Collapse details</a></td></tr>');
												dbms_output.put_line('</TABLE></td></TR>');
										  end if;
										  dbms_output.put_line('<TR><TD>'||v_it||'</TD>'||chr(10)||'<TD>'||v_activity ||'</TD>'||chr(10)||'<TD>');
										  if v_err_name is null then
											dbms_output.put_line('-</TD>'||chr(10));
										  else
											dbms_output.put_line(replace(substr(v_err_name,1,200),chr(10),'<br>'));											
											dbms_output.put_line('</TD>'||chr(10));
										  end if;
										  SELECT count(s.ITEM_KEY) into v_count
												FROM wf_item_activity_statuses s,wf_process_activities p
												WHERE p.instance_id = s.process_activity
												AND activity_status = 'ERROR'												
												AND p.PROCESS_ITEM_TYPE = v_it and p.ACTIVITY_NAME=v_activity and substr(nvl(s.error_message,'null'),1,200)=nvl(v_err_name,'null');
										  dbms_output.put_line('<TD>'||v_count ||'</TD>'||chr(10));
										  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql200'||v_big_no||'b" onclick="displayItem2(this,''s1sql200'||v_big_no||''');" href="javascript:;">&#9654; Show Details</A>');
										  dbms_output.put_line('   </TD>');
										  dbms_output.put_line(' </TR>');
										  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql200'||v_big_no||'" style="display:none">');
										  dbms_output.put_line(' <TR><TD width="10%"></TD><TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Result</B></TD>');
										  dbms_output.put_line(' <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Item Key</B></TD>');
										  dbms_output.put_line(' <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Begin Date</B></TD>');										  
										  dbms_output.put_line(' <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Command to get error stack</B></TD>');
										  dbms_output.put_line(' <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Command to run wfstat</B></TD></TR>');										  
										  v_big_no:=v_big_no+1;
										  
								end if;
								
								v_it_old:=v_it;
								v_activity_old:=v_activity;
								v_err_name_old:=v_err_name;

								dbms_output.put_line('<TD></TD>');
								dbms_output.put_line('<TD>'||v_code||'</TD>'||chr(10));
								dbms_output.put_line('<TD>'||v_ik||'</TD>'||chr(10));								
								dbms_output.put_line('<TD>'||v_date||'</TD>'||chr(10));
								
								dbms_output.put_line('<TD>select Error_Stack from wf_item_activity_statuses<br> where item_type='''||v_it||'''');
								dbms_output.put_line(' and item_key='''||v_ik||''' and process_activity='||v_process_activity||';</TD>'||chr(10));
								dbms_output.put_line('<TD>@wfstat.sql '||v_it||' '||v_ik||'</TD>'||chr(10));
											   
								dbms_output.put_line('</TR>'||chr(10));              
					  end loop;
					  case upper(product)
						WHEN 'SSHR' then
							close sshr_workflow;
						WHEN 'HR' then
							close sshr_workflow;
						WHEN 'OTL' then
							close otl_workflow;							
						WHEN 'OTA' then
							close ota_workflow;
						WHEN 'IRC' then
							close irc_workflow;
						WHEN 'ALL' then						
							close all_workflow;	
						else
							null;
					end case;
					  
					  v_big_no2 :=v_big_no-1;
					  dbms_output.put_line('<tr><td><A class=detail onclick="hideRow2(''s1sql200'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
												
					  dbms_output.put_line(' </TABLE>');
		
	end if;
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql55'');" href="javascript:;">Collapse section</a></td></tr>');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> </div> ');
	
	if v_rows=0 then
		dbms_output.put_line('<div class="divok">');    
		dbms_output.put_line('<img class="check_ico">OK! No workflow in error.');
        dbms_output.put_line('</div>');
	else
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>You have '||v_rows||' workflows with errors! Please review the table and run the wfstat.sql command to take details.<br>');
		dbms_output.put_line('<blockquote>');
		if :apps_rel like '11.%' then
			dbms_output.put_line('1. Go to script directory: $FND_TOP/admin/sql<br>');
		else
			dbms_output.put_line('1. Go to script directory: $FND_TOP/sql<br>');
		end if;
		dbms_output.put_line('2. Connect to sqlplus: sqlplus apps/apps_password<br>');
		dbms_output.put_line('3. Spool the upcoming output to your $HOME directory: SQL> spool $HOME/wf_oracle_stat.txt<br>');
		dbms_output.put_line('4. Execute wfstat.sql as adviced in the table: SQL> @wfstat.sql ITEM_TYPE ITEM_KEY<br>');
		dbms_output.put_line('5. Turn spool off: SQL> spool off </blockquote>');
		dbms_output.put_line('</div>');
		:w6:=:w6+1;
	end if;
	dbms_output.put_line('<div class="divok">');    
	dbms_output.put_line('For generic Workflow issues please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1369938.1" target="_blank">Note 1369938.1</a> ');
	dbms_output.put_line('Workflow Analyzer script for E-Business Suite Workflow Monitoring and Maintenance');
    dbms_output.put_line('</div>');
	
	dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
end if;	
end if;
  dbms_output.put_line('</div>');
EXCEPTION
					when others then
					  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
					  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;
/

declare
product varchar2(20):='&&2';
cursor get_user(p_user_id number) is
select user_name
from fnd_user
where user_id=p_user_id;
l_user_name fnd_user.user_name%type;

cursor get_node(p_node_id number) is
select node_name,webhost
from fnd_nodes
where node_id=p_node_id;
l_node_name fnd_nodes.node_name%type;
l_webhost fnd_nodes.webhost%type;


cursor get_guest_user_resps(p_user_name varchar2) is
select responsibility_key,secg.security_group_key,RESPONSIBILITY_NAME,resp.start_date,resp.end_date
,rol.EXPIRATION_DATE
,urol.EXPIRATION_DATE user_expiration_date
from fnd_responsibility resp, fnd_responsibility_tl respname
,fnd_user_resp_groups rg
,fnd_user usr
,wf_local_roles rol
,fnd_security_groups secg
,wf_local_user_roles urol
where usr.user_name=p_user_name
and resp.RESPONSIBILITY_ID=respname.RESPONSIBILITY_ID and resp.APPLICATION_ID=respname.APPLICATION_ID and respname.language='US'
and rg.user_id=usr.user_id
and rg.responsibility_id=resp.responsibility_id
and rg.responsibility_application_id=resp.application_id
and sysdate between usr.start_date and nvl(usr.end_date,sysdate)
and sysdate between rg.start_date and nvl(rg.end_date,sysdate)
and sysdate between resp.start_date and nvl(resp.end_date,sysdate)
and secg.security_group_id=rg.security_group_id
and rol.name='FND_RESP|PER|'||resp.responsibility_key||'|'||secg.security_group_key
and urol.user_name=p_user_name
and urol.role_name='FND_RESP|PER|'||resp.responsibility_key||'|'||secg.security_group_key
order by responsibility_key;
l_instance_name v$instance.instance_name%type;
l_instance_version v$instance.version%type;
cursor c_flex_context_default(p_flex_name varchar2,p_application_id number) is
select fdf.title
,fdf.CONTEXT_COLUMN_NAME 
,fdf.DEFAULT_CONTEXT_FIELD_NAME 
,fdf.DEFAULT_CONTEXT_VALUE 
,fdf.DESCRIPTIVE_FLEXFIELD_NAME
from FND_DESCRIPTIVE_FLEXS_VL fdf
where DESCRIPTIVE_FLEXFIELD_NAME =p_flex_name
and application_id=p_application_id;

cursor c_flex_contexts(p_flex_name varchar2,p_application_id number) is
select DESCRIPTIVE_FLEX_CONTEXT_CODE 
from FND_DESCR_FLEX_CONTEXTS 
where DESCRIPTIVE_FLEXFIELD_NAME =p_flex_name
and application_id=p_application_id
order by decode(DESCRIPTIVE_FLEX_CONTEXT_CODE,'Global Data Elements','1',DESCRIPTIVE_FLEX_CONTEXT_CODE);

cursor c_flex_fields(p_flex_name varchar2,p_context varchar2,p_application_id number) is
select fdfc.APPLICATION_COLUMN_NAME 
,fdfc.END_USER_COLUMN_NAME 
,fdfc.ENABLED_FLAG 
,fdfc.DISPLAY_FLAG 
,fdfc.REQUIRED_FLAG 
,fdfc.default_value
,ffvs.FLEX_VALUE_SET_NAME 
from FND_DESCR_FLEX_COL_USAGE_VL fdfc
,FND_FLEX_VALUE_SETS ffvs
where fdfc.DESCRIPTIVE_FLEXFIELD_NAME =p_flex_name
and fdfc.DESCRIPTIVE_FLEX_CONTEXT_CODE=p_context
and fdfc.application_id=p_application_id
and fdfc.FLEX_VALUE_SET_ID =ffvs.FLEX_VALUE_SET_ID 
order by fdfc.COLUMN_SEQ_NUM;

l_retval varchar2(4000);
l_url varchar(2000);
geom     MDSYS.SDO_GEOMETRY;
cursor get_pset(name varchar2) is
select menu_id
from fnd_menus
where menu_name=name;
l_emp_site_vis_pset number;
l_ext_site_vis_pset number;

cursor get_grant(pset number,user varchar2)is
select start_date,end_date
from fnd_grants
where grantee_type='USER'
and grantee_key=user
and menu_id=pset;

cursor get_org_info is
select org.name
,hoi.org_information1
,hoi.org_information3
,hoi.org_information4
,hoi.org_information5
,hoi.org_information6
,hoi.org_information9
,hoi2.org_information3 apl_numbering
,ast.user_status
,ast.external_status
,ppttl.user_person_type
from hr_organization_information hoi
,hr_all_organization_units org
,per_assignment_status_types_tl ast
,per_person_types_tl ppttl
,hr_organization_information hoi2
where hoi.organization_id=org.organization_id
and org.organization_id=org.business_group_id
and hoi.org_information_context='BG Recruitment'
and hoi.org_information7=ast.assignment_status_type_id(+)
and hoi2.ORG_INFORMATION_CONTEXT = 'Business Group Information'
and hoi2.organization_id=org.organization_id
and ast.language(+)=USERENV('LANG')
and hoi.org_information8=ppttl.person_type_id(+)
and ppttl.language(+)=USERENV('LANG');

cursor get_ex_emp is
select menu_name,fme.grant_flag
from fnd_menu_entries fme
,fnd_menus fm
,fnd_form_functions ff
where fme.function_id=ff.function_id
and ff.function_name='IRC_EX_EMP_REGISTRATION'
and fme.MENU_ID=fm.MENU_ID;

l_pset_start_date date;
l_pset_end_date date;
l_guest_user varchar2(30);

l_proxy_server varchar2(255);
l_proxy_port varchar2(255);
l_proxy_bypass varchar2(255);
l_fwk_agent varchar2(255);
issue boolean:=false;

l_doc_name varchar2(4000);
l_customization_name varchar2(4000);

cursor c_alldocs is
  select path_docid from jdr_paths
  where ((path_type = 'DOCUMENT' AND path_seq = -1) OR
    (path_type = 'PACKAGE' AND path_seq = 0))
  start with path_owner_docid = jdr_mds_internal.getDocumentId('/oracle/apps/per/irc')
  connect by prior path_docid = path_owner_docid;


cursor c_cust2(p_document_id number) is
select cl1.path_docid,jdr_mds_internal.getDocumentName(cl1.path_docid) docName,jda.att_value developerMode
from jdr_paths cl1
,    jdr_paths bm1
,    jdr_paths cl2
,    jdr_paths bm2
,    jdr_paths cl3
,    jdr_paths bm3
,    jdr_attributes jda
where cl1.path_name=bm1.path_name
and bm1.path_docid=p_document_id
and bm1.path_docid!=cl1.path_docid
and cl2.path_name=bm2.path_name
and cl1.path_owner_docid=cl2.path_docid
and bm1.path_owner_docid=bm2.path_docid
and cl2.path_name=bm2.path_name
and cl1.path_owner_docid=cl2.path_docid
and bm1.path_owner_docid=bm2.path_docid
and cl3.path_name=bm3.path_name
and cl2.path_owner_docid=cl3.path_docid
and bm2.path_owner_docid=bm3.path_docid
and jda.att_comp_docid=cl1.path_docid
and att_name='developerMode';

cursor c_cust3(p_document_id number) is
select COMP_SEQ,COMP_LEVEL,COMP_GROUPING,COMP_ELEMENT  from JDR_COMPONENTS where comp_element = 'replace' and COMP_DOCID = p_document_id;

Begin
dbms_output.put_line('</div>');
if upper(product) in ('ALL','IRC') then
 dbms_output.put_line('<div id="page7" style="display: none;">');
 dbms_output.put_line('<a name="irc"></a><div class="divSection">');
 dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="ircsetup" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">IRecruitment Setup: '); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF"> /  </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
 dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
 dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
 dbms_output.put_line('<a class=detail2 href="#irc1">Proxy Profile Option Analysis</a> <br>');      
       dbms_output.put_line('<a class=detail2 href="#irc2">Guest User Settings</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#irc3">Ex-employee registration check</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#irc4">iRec Business Group settings</a> <br></td><td class="toctable">');
      dbms_output.put_line('<a class=detail2 href="#irc5">Flex context</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#irc6">Connection tests</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#irc7">Geocode test</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#irc8">XML Parser</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#irc9">Customizations</a> <br></td></tr></table>');	  
 dbms_output.put_line('</div><br>');
                 
  dbms_output.put_line('<a name="irc1"></a><b>Proxy Profile Option Analysis</b><br>');

l_proxy_server:=rtrim(fnd_profile.value('WEB_PROXY_HOST'));
l_proxy_port:=rtrim(fnd_profile.value('WEB_PROXY_PORT'));
l_proxy_bypass:=rtrim(fnd_profile.value('WEB_PROXY_BYPASS_DOMAINS'));
l_fwk_agent:=rtrim(fnd_profile.value('APPS_FRAMEWORK_AGENT'));
dbms_output.put_line('WEB_PROXY_HOST: '||l_proxy_server);
dbms_output.put_line('<br>WEB_PROXY_PORT: '||l_proxy_port);
dbms_output.put_line('<br>WEB_PROXY_BYPASS_DOMAINS: '||l_proxy_bypass);
dbms_output.put_line('<br>APPS_FRAMEWORK_AGENT: '||l_fwk_agent);

dbms_output.put_line('<div class="divok"><span class="sectionblue1">Advice: </span>If using a proxy server, be sure all of these 3 system profiles (WEB_PROXY_HOST, WEB_PROXY_PORT, WEB_PROXY_BYPASS_DOMAINS) are setup correctly. ');

dbms_output.put_line('<br>The WEB_PROXY_BYPASS_DOMAINS to define the proxy exclusion list must be in the following format *.mydomain1.com;*.mydomain2.com (Note the * asterisk in front and ; semi colon as the separator)</div>');

if(l_proxy_server!='' and l_proxy_port='')then
  dbms_output.put_line('<div class="diverr"><img class="error_ico"><font color="red">Error:</font> You have specified a proxy server, but not a proxy port.</div>');
  :e7:=:e7+1;
end if;

if(instr(l_fwk_agent,l_proxy_server)>0) then
  dbms_output.put_line('<div class="diverr"><img class="error_ico"><font color="red">Error:</font> You appear to have your proxy server set to be your application server. Set the correct proxy server.</div>');
  :e7:=:e7+1;
end if;

if(l_proxy_server='') then
  dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> You do not have a proxy server set. This is generally incorrect.</div>');
  :w7:=:w7+1;
end if;

if(l_proxy_bypass='') then
  dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> You do not have an proxy bypass domains set. This is generally incorrect.</div>');
  :w7:=:w7+1;
end if;

if(l_proxy_server!='' and substr(l_proxy_bypass,1,1)!='*') then
  dbms_output.put_line('<div class="diverr"><img class="error_ico"><font color="red">Error:</font> Your proxy server bypass domains are of the wrong format. They must start with *. e.g. *.oracle.com</div>');
  :e7:=:e7+1;
end if;


open get_pset('IRC_EXT_SITE_VISITOR_PSET');
fetch get_pset into l_ext_site_vis_pset;
close get_pset;
open get_pset('IRC_EMP_SITE_VISITOR_PSET');
fetch get_pset into l_emp_site_vis_pset;
close get_pset;

dbms_output.put_line('<br><br><a name="irc2"></a><b>Guest User Settings</b><br>');

l_guest_user:=substrb(fnd_profile.value('GUEST_USER_PWD'),0,instrb(fnd_profile.value('GUEST_USER_PWD'),'/')-1);
if(l_guest_user!='GUEST') then
  dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> Your guest user is not named GUEST. This is not supported from 11.5.10 onwards</div>');
  :w7:=:w7+1;
  issue:=true;
end if;

dbms_output.put_line('<DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql83b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql83'');" href="javascript:;">&#9654; Guest user</A></DIV>');
dbms_output.put_line(' <div id="s1sql83" style="display:none" >');
dbms_output.put_line('<table><tr><th>Responsibility name</th><th>Responsibility key</th><th>Start date</th><th>End date</th><th>Security group key</th><th>Status</th></tr>');	

  for resp_rec in get_guest_user_resps('GUEST') loop
  dbms_output.put_line('<tr><td>'||resp_rec.RESPONSIBILITY_NAME ||'</td><td> '|| resp_rec.responsibility_key||'</td><td> ');
  dbms_output.put_line(resp_rec.start_date||'</td><td> '|| resp_rec.end_date||'</td><td> '|| resp_rec.security_group_key||'</td><td>');
if(not resp_rec.expiration_date>=trunc(sysdate)) then
  dbms_output.put_line(' has expired<br>');
  issue:=true;
end if;
if(not resp_rec.user_expiration_date>=trunc(sysdate)) then
  dbms_output.put_line(' user role has expired<br>');
  issue:=true;
end if;
if(l_ext_site_vis_pset is not null) then
  if(resp_rec.responsibility_key='IRC_EXT_CANDIDATE') then
    open get_grant(l_ext_site_vis_pset,l_guest_user);
    fetch get_grant into l_pset_start_date, l_pset_end_date;
    if get_grant%notfound then
      close get_grant;
      dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> You have not granted the external site visitor permission set to the guest user.');
      dbms_output.put_line('Users will not be able to connect to the site visitor screens.</div>');
	  :w7:=:w7+1;
	  issue:=true;
    else
      close get_grant;
      if l_pset_start_date>sysdate or sysdate>nvl(l_pset_end_date,sysdate) then
        dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> Your external site visitor permission set grant to the guest user is out of date.</div>');
		:w7:=:w7+1;
		issue:=true;
      else
        dbms_output.put_line('External site visitor permission set granted.<br>');
      end if;
    end if;
  end if;
end if;

if(l_emp_site_vis_pset is not null) then
  if(resp_rec.responsibility_key='IRC_EMP_CANDIDATE') then
    open get_grant(l_emp_site_vis_pset,l_guest_user);
    fetch get_grant into l_pset_start_date, l_pset_end_date;
    if get_grant%notfound then
      close get_grant;
      dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> You have not granted the employee site visitor permission set to the guest user.');
      dbms_output.put_line('Users will not be able to connect to the employee site visitor screens.</div>');
	  :w7:=:w7+1;
	  issue:=true;
    else
      close get_grant;
      if l_pset_start_date>sysdate or sysdate>nvl(l_pset_end_date,sysdate) then
        dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> Your employee site visitor permission set grant to the guest user is out of date.</div>');
		:w7:=:w7+1;
		issue:=true;
      else
        dbms_output.put_line('Employee site visitor permission set granted.<br>');
      end if;
    end if;
  end if;
end if;
dbms_output.put_line('</td></tr>');
end loop;
dbms_output.put_line('</table><br> </div></div>');
if not issue then
	dbms_output.put_line('<div class="divok"><img class="check_ico">OK! Verified guest settings are OK.</div>');
else
	dbms_output.put_line('<div class="divwarn"><img class="warn_ico"> <span class="sectionorange">Warning: </span> You have warnings reported for GUEST user.</div>');
end if;

dbms_output.put_line('<br><br><a name="irc3"></a><DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql81b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql81'');" href="javascript:;">&#9660; Ex-employee registration check</A></DIV>');
dbms_output.put_line(' <div id="s1sql81" style="display:block" >');	

dbms_output.put_line('<table><tr><th>Menu</th><th>Granted</th></tr>');
for ex_rec in get_ex_emp loop
dbms_output.put_line('<tr><td>'||ex_rec.menu_name||' </td><td>'||ex_rec.grant_flag || '</td></tr>');
end loop;
dbms_output.put_line('</table><br></div></div> ');

dbms_output.put_line('<br><br><a name="irc4"></a><DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql86b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql86'');" href="javascript:;">&#9660; iRec Business Group settings</A></DIV>');
dbms_output.put_line(' <div id="s1sql86" style="display:block" >');	
dbms_output.put_line('<table><tr><th>Name</th><th>Code</th><th>Openings</th><th>Org</th><th>Loc</th><th>Status</th><th>Candidate Type</th><th>Excluded</th><th>Numbering</th></tr>');
for org_rec in get_org_info loop
  dbms_output.put_line('<tr><td>'|| org_rec.name);
  dbms_output.put_line(' </td><td>'||org_rec.org_information1||' </td><td>');
  dbms_output.put_line(org_rec.org_information3);
  dbms_output.put_line(' '||org_rec.org_information6||' </td><td>');
  dbms_output.put_line(org_rec.org_information4||' </td><td>');
  dbms_output.put_line(org_rec.org_information5);
  dbms_output.put_line(' </td><td> '||org_rec.user_status);
  dbms_output.put_line(' ('||org_rec.external_status||') </td><td> ');
  dbms_output.put_line(  org_rec.user_person_type||' </td><td>');
  dbms_output.put_line(org_rec.org_information9);
  dbms_output.put_line('</td><td>'||org_rec.apl_numbering||'</td></tr>');
end loop;
dbms_output.put_line('</table><br> </div></div><br>');

dbms_output.put_line('<a name="irc5"></a><DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql82b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql82'');" href="javascript:;">&#9654; Flex context</A></DIV>');
dbms_output.put_line(' <div id="s1sql82" style="display:none" >');	
for context_def_rec in c_flex_context_default('IRC_SEARCH_CRITERIA',800) loop
dbms_output.put_line('<br>Flex: '||context_def_rec.title);
dbms_output.put_line('<br>Context default: '||context_def_rec.DEFAULT_CONTEXT_VALUE);
  for flex_contexts_rec in c_flex_contexts (context_def_rec.DESCRIPTIVE_FLEXFIELD_NAME,800) loop
  dbms_output.put_line('  Context: '||flex_contexts_rec.DESCRIPTIVE_FLEX_CONTEXT_CODE);
    dbms_output.put_line('<table><tr><th>Field</th><th>Enabled</th><th>Displayed</th><th>Required</th><th>Value Set</th><th>Default</th></tr>');
    for flex_fields_rec in c_flex_fields(context_def_rec.DESCRIPTIVE_FLEXFIELD_NAME,flex_contexts_rec.DESCRIPTIVE_FLEX_CONTEXT_CODE,800) loop
    dbms_output.put_line('<tr><td>'||flex_fields_rec.APPLICATION_COLUMN_NAME||' ('||flex_fields_rec.END_USER_COLUMN_NAME||')');
    dbms_output.put_line('</td><td>'||flex_fields_rec.ENABLED_FLAG||' </td><td>'||flex_fields_rec.DISPLAY_FLAG||' </td><td> '||flex_fields_rec.REQUIRED_FLAG);
    dbms_output.put_line('</td><td> '||flex_fields_rec.FLEX_VALUE_SET_NAME||' </td><td>'||flex_fields_rec.default_value ||'</td></tr>');
    end loop;
    dbms_output.put_line('</table><br> ');
  end loop;
end loop;
dbms_output.put_line('</div></div>');

dbms_output.put_line('<br><br><a name="irc6"></a><b>External Network Test</b><br>');


begin
l_retval:='No response';
l_url:='http://www.google.com/';
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url,
                            proxy => hr_util_web.proxyforURL(l_url)),0,128);
dbms_output.put_line('<div class="divok">');
dbms_output.put_line(replace(replace(l_retval,'<',' '),'>',' '));
dbms_output.put_line('<br><img class="check_ico">OK! The external network test was a success. This means that you can make external network connections from the database</div>');
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
dbms_output.put_line('<br>The external network test failed. This means that you can not make external network connections from the database,');
dbms_output.put_line('<br>e.g. for location seaching. You may also be unable to make external network conncections from the middle tier,');
dbms_output.put_line('<br>e.g. for resume parsing or background checking</div>');
:w7:=:w7+1;
end;

dbms_output.put_line('<br><br><b>Internal Network Test</b><br>');

begin
l_retval:='No response';
l_url:=fnd_profile.value('APPS_FRAMEWORK_AGENT')||'/OA_HTML/JobPositionSeeker.xsl';
  if(lower(substr(l_url,1,5))='https') then
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url
                           ,proxy => hr_util_web.proxyforURL(substr(l_url,1,2000))
                           ,wallet_path=>'file:'||fnd_profile.value('FND_DB_WALLET_DIR')
                           ,wallet_password=>fnd_preference.eget('#INTERNAL','WF_WEBSERVICES','EWALLETPWD', 'WFWS_PWD')
                           ),0,128);
  else
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url
                           ,proxy => hr_util_web.proxyforURL(substr(l_url,1,2000))
                           ),0,128);
  end if;
dbms_output.put_line('<div class="divok">');
dbms_output.put_line(replace(replace(l_retval,'<',' '),'>',' '));
dbms_output.put_line('<br><img class="check_ico">OK! The internal network test was a success. This means that you can make network connections from the database to the middle tier');
dbms_output.put_line('You need to make sure the network facilitates network connectivity on all nodes (data base and middle tiers).<br>');
dbms_output.put_line('If you use SSL (https), then verify that your wallet manager is configured according to Note 123718.1.</div>');
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
dbms_output.put_line('<br>The internal network test failed. This means that you can not make network connections from the database to the middle tier.<br>');
dbms_output.put_line('This will stop functionality like background checking, resume generation and job postings from working.</div>');
:w7:=:w7+1;

end;


begin
if (length(fnd_profile.value('IRC_BACKGROUND_CHECK_VENDOR_URL'))>1) then
  dbms_output.put_line('<br><br><b>Background Check Network Test</b>');

  l_retval:='No response';
  l_url:=fnd_profile.value('IRC_BACKGROUND_CHECK_VENDOR_URL');
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url,
                            proxy => hr_util_web.proxyforURL(l_url)),0,128);
  dbms_output.put_line('<div class="divok">');
  dbms_output.put_line(replace(replace(l_retval,'<',' '),'>',' '));
  dbms_output.put_line('<br><img class="check_ico">OK! You are able to succesfully communicate from the database to the background check vendor.<br>');
  dbms_output.put_line('This is a good indication, but not a guarantee, that you will be able to connect from the middle tier.<br>');
dbms_output.put_line('Also, if you are using the background check functionality be sure that this site can connect from all nodes (middle tiers and database)</div>');


end if;
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
  dbms_output.put_line('<br><img class="check_ico">OK! You are not able to succesfully communicate from the database to the background check vendor.<br>');
  dbms_output.put_line('This is a strong indication that you will not be able to connect from the middle tier.</div>');
  :w7:=:w7+1;

end;

begin
if (length(fnd_profile.value('IRC_RESUME_PARSING_VENDOR_URL'))>1) then
  dbms_output.put_line('<br><br><b>Resume Parsing Network Test</b><br>');

  l_retval:='No response';
  l_url:=fnd_profile.value('IRC_RESUME_PARSING_VENDOR_URL');
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url,
                            proxy => hr_util_web.proxyforURL(l_url)),0,128);
  dbms_output.put_line('<div class="divok">');
  dbms_output.put_line(replace(replace(l_retval,'<',' '),'>',' '));
  dbms_output.put_line('<br><img class="check_ico">OK! You are able to succesfully communicate from the database to the resume parsing vendor.<br>');
  dbms_output.put_line('This is a good indication, but not a guarantee, that you will be able to connect from the middle tier.</div>');

end if;
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
  dbms_output.put_line('<br>You are not able to succesfully communicate from the database to the resume parsing vendor.<br>');
  dbms_output.put_line('This is a strong indication that you will not be able to connect from the middle tier.</div>');
  :w7:=:w7+1;

end;



dbms_output.put_line('<br><br><b>Url_fw.conf file entries</b><br>');
dbms_output.put_line('<div class="divok"><span class="sectionblue1">Advice: </span>Please CHECK for the appropriate entries in the url_fw.conf file<br>');
dbms_output.put_line('The file httpd.conf has the path to the url_fw.conf. Whatever the httpd.conf says, that is where it is. it is usually the same directory as httpd.conf and that is typically $IAS_CONFIG_HOME/Apache/Apache/conf ');
dbms_output.put_line('(Note: url_fw.conf is ONLY on the web tier)<br>');
dbms_output.put_line('Verify the following files are included in the url_fw.conf file, if not, please add to all servers (internal and external):<br>');
dbms_output.put_line('<blockquote> RewriteRule ^/OA_HTML/IRCRESUMEUK1\.xsl$ - [L]<br>');
dbms_output.put_line('RewriteRule ^/OA_HTML/IRCRESUMEUK2\.xsl$ - [L]<br>');
dbms_output.put_line('RewriteRule ^/OA_HTML/IRCRESUMEUS1\.xsl$ - [L]<br>');
dbms_output.put_line('RewriteRule ^/OA_HTML/IRCRESUMEUS2\.xsl$ - [L]<br>');
dbms_output.put_line('RewriteRule ^/OA_HTML/IRCRESUMEUS3\.xsl$ - [L] </blockquote> </div>');



begin
if (length(fnd_profile.value('IRC_GEOCODE_HOST'))>1) then
  dbms_output.put_line('<br><br><a name="irc7"></a><b>eLocation Test</b>');

    geom := irc_location_utility.address2geometry(address_line1 => '500 Oracle pky'
                             ,address_line2=> 'redwood city'
                             ,address_line3 => 'CA'
                            ,country=>'US');
    dbms_output.put_line('<div class="divok">');
	dbms_output.put_line('Latitude: ' || geom.SDO_POINT.y);
    dbms_output.put_line('<br>Longitude: ' || geom.SDO_POINT.x);

  dbms_output.put_line('<br><img class="check_ico">OK! You have succesfully communicated with the eLocation server.</div>');

end if;
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
  dbms_output.put_line('<br>You have not succesfully communicated with the eLocation server. You will not be able to search by distance to location</div>');
  :w7:=:w7+1;
end;

begin
dbms_output.put_line('<br><br><a name="irc8"></a><b>XMLParser version:</b> '||ecx_utils.XMLVersion);

dbms_output.put_line('<br><br><a name="irc9"></a><DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql87b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql87'');" href="javascript:;">&#9654; Customizations</A></DIV>');
dbms_output.put_line(' <div id="s1sql87" style="display:none" >');

if(fnd_profile.value_specific(name=>'FND_MIGRATED_TO_JRAD',application_id=>800)='N') then
	dbms_output.put_line('Running in AK mode - not checking personalizations<br><br>');
	else
	dbms_output.put_line('Running in MDS Mode<br><br>');

	  for doc_rec in c_alldocs loop
		l_doc_name:=jdr_mds_internal.getDocumentName(doc_rec.path_docid);
		for cust_rec in c_cust2(doc_rec.path_docid) loop
		  dbms_output.put_line(cust_rec.docName);
		  dbms_output.put_line(' Developer Mode:'||cust_rec.developerMode||'<br>');		  
		end loop;		
	  end loop;
	  
	  dbms_output.put_line('<br><br>VO substitutions:<br>');
	  for doc_rec in c_alldocs loop
		l_doc_name:=jdr_mds_internal.getDocumentName(doc_rec.path_docid);
		for cust_rec in c_cust3(doc_rec.path_docid) loop
		  dbms_output.put_line(l_doc_name);
		  dbms_output.put_line(' SEQ:'||cust_rec.COMP_SEQ||'LEVEL'||cust_rec.COMP_LEVEL||'GROUPING' ||cust_rec.COMP_GROUPING||'ELEMENT''||cust_rec.COMP_ELEMENT||<br>');		  
		end loop;		
	  end loop;
	  
dbms_output.put_line('</div></div>');
end if;
end;   

   dbms_output.put_line('</div></div>');
end if; 
dbms_output.put_line('</div>');
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;
/


declare
v_errors number;
v_warnings number;
product varchar2(20):='&2';
begin
dbms_output.put_line('<br><br><a name="errors"></a>');
	v_errors:=:e1+:e2+:e3+:e4+:e5+:e6+:e7;
	v_warnings:=:w1+:w2+:w3+:w4+:w5+:w6+:w7;
	dbms_output.put_line('<script type="text/javascript">');
	dbms_output.put_line('var auxs;');
	dbms_output.put_line('auxs = document.getElementById("ExecutionSummary1").innerHTML;');
	dbms_output.put_line('document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if v_errors>0 and v_warnings>0 then
		dbms_output.put_line('"('||v_errors||'<img class=\\"error_ico\\"> '||v_warnings||'<img class=\\"warn_ico\\">)</A>";');
	elsif v_errors>0 and v_warnings=0 then
		dbms_output.put_line('"(<img class=\\"error_ico\\">'||v_errors||')</A>";');
	elsif v_errors=0 and v_warnings>0 then
		dbms_output.put_line('"(<img class=\\"warn_ico\\">'||v_warnings||')</A>";');
	elsif v_errors=0 and v_warnings=0 then
		dbms_output.put_line('"(<img class=\\"check_ico\\"> No issues reported)</A>";');
	end if;
	
	dbms_output.put_line('auxs = document.getElementById("ExecutionSummary2").innerHTML;');
	dbms_output.put_line('document.getElementById("ExecutionSummary2").innerHTML = auxs + ');			

	dbms_output.put_line(' "<TABLE width=\\"95%\\"><TR>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Section</B></TD>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Errors</B></TD>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Warnings</B></TD>"+');
	
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page1'');\\" href=\\"javascript:;\\">Instance Overview</A>"+');
	if :e1>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w1>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');	
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e1||'</TD><TD>'||:w1||'</TD> </TR>"+');
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page2'');\\" href=\\"javascript:;\\">Patching</A>"+');
	if :e5>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w5>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e5||'</TD><TD>'||:w5||'</TD> </TR>"+');
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page3'');\\" href=\\"javascript:;\\">Settings</A>"+');	
	if :e4>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w4>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e4||'</TD><TD>'||:w4||'</TD> </TR>"+');
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page4'');\\" href=\\"javascript:;\\">Performance</A>"+');
	if :e2>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w2>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');	
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e2||'</TD><TD>'||:w2||'</TD> </TR>"+');
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page5'');\\" href=\\"javascript:;\\">Database Objects</A>"+');
	if :e3>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w3>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e3||'</TD><TD>'||:w3||'</TD> </TR>"+');
	if upper(product) in ('HR','SSHR', 'OTL','IRC','OTA','ALL') then
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page6'');\\" href=\\"javascript:;\\">Workflow Details</A>"+');	
	if :e6>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w6>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e6||'</TD><TD>'||:w6||'</TD> </TR>"+');
	end if;
	if upper(product) in ('ALL','IRC')  then
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page7'');\\" href=\\"javascript:;\\">IRecruitment Setup</A>"+');
	if :e7>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w7>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e7||'</TD><TD>'||:w7||'</TD> </TR>"+');     
    end if;	
			
	dbms_output.put_line(' "</TABLE></div>";');     	


	dbms_output.put_line('auxs = document.getElementById("toccontent").innerHTML;');
	dbms_output.put_line('document.getElementById("toccontent").innerHTML = auxs + ');
	dbms_output.put_line('"<div align=\\"center\\">"+');
	-- Tabs 
	
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page1'')\\" >"+');
			dbms_output.put_line('"<b>Instance Overview</b> "+');
			if :e1>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w1>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	 
	  
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page2'')\\" >"+');
			dbms_output.put_line('"<b>Patching</b>"+');
			if :e5>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w5>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;
			
	
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page3'')\\" >"+');
			dbms_output.put_line('"<b>Settings</b> "+');
			if :e4>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w4>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	 
			
	
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page4'')\\" >"+');
			dbms_output.put_line('"<b>Performance</b> "+');
			if :e2>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w2>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	
	
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page5'')\\" >"+');
			dbms_output.put_line('"<b>Database Objects and Versions</b> "+');
			if :e3>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w3>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	
			
	  if upper(product) in ('HR','SSHR', 'OTL','IRC','OTA','ALL') then
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page6'')\\" >"+');
			dbms_output.put_line('"<b>Workflow Details</b> "+');
			if :e6>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w6>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	
      end if;
	  if upper(product) in ('ALL','IRC')  then
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page7'')\\" >"+');
			dbms_output.put_line('"<b>IRecruitment Setup</b> "+');
			if :e7>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w7>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	
      end if;
      dbms_output.put_line('"</div>";');
	  

			dbms_output.put_line('auxs = document.getElementById("overview").innerHTML;');
			dbms_output.put_line('document.getElementById("overview").innerHTML = auxs + ');
			if :e1>0 and :w1>0 then
				dbms_output.put_line(' "'||:e1||' <img class=\\"error_ico\\">  '||:w1||' <img class=\\"warn_ico\\"> ";');
			elsif :e1>0 then
				dbms_output.put_line(' "'||:e1||' <img class=\\"error_ico\\"> ";');
			elsif :w1>0 then
				dbms_output.put_line(' "'||:w1||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;						
	
			dbms_output.put_line('auxs = document.getElementById("patching").innerHTML;');
			dbms_output.put_line('document.getElementById("patching").innerHTML = auxs + ');
			if :e5>0 and :w5>0 then
				dbms_output.put_line(' "'||:e5||' <img class=\\"error_ico\\">  '||:w5||' <img class=\\"warn_ico\\"> ";');
			elsif :e5>0 then
				dbms_output.put_line(' "'||:e5||' <img class=\\"error_ico\\"> ";');
			elsif :w5>0 then
				dbms_output.put_line(' "'||:w5||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;		
						
	
			dbms_output.put_line('auxs = document.getElementById("settings").innerHTML;');
			dbms_output.put_line('document.getElementById("settings").innerHTML = auxs + ');
			if :e4>0 and :w4>0 then
				dbms_output.put_line(' "'||:e4||' <img class=\\"error_ico\\">  '||:w4||' <img class=\\"warn_ico\\"> ";');
			elsif :e4>0 then
				dbms_output.put_line(' "'||:e4||' <img class=\\"error_ico\\"> ";');
			elsif :w4>0 then
				dbms_output.put_line(' "'||:w4||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;	
					
	 
			dbms_output.put_line('auxs = document.getElementById("performance").innerHTML;');
			dbms_output.put_line('document.getElementById("performance").innerHTML = auxs + ');
			if :e2>0 and :w2>0 then
				dbms_output.put_line(' "'||:e2||' <img class=\\"error_ico\\">  '||:w2||' <img class=\\"warn_ico\\"> ";');
			elsif :e2>0 then
				dbms_output.put_line(' "'||:e2||' <img class=\\"error_ico\\"> ";');
			elsif :w2>0 then
				dbms_output.put_line(' "'||:w2||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;			
	
			dbms_output.put_line('auxs = document.getElementById("database").innerHTML;');
			dbms_output.put_line('document.getElementById("database").innerHTML = auxs + ');
			if :e3>0 and :w3>0 then
				dbms_output.put_line(' "'||:e3||' <img class=\\"error_ico\\">  '||:w3||' <img class=\\"warn_ico\\"> ";');
			elsif :e3>0 then
				dbms_output.put_line(' "'||:e3||' <img class=\\"error_ico\\"> ";');
			elsif :w3>0 then
				dbms_output.put_line(' "'||:w3||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;		
	
	  if upper(product) in ('HR','SSHR', 'OTL','IRC','OTA','ALL') then
			dbms_output.put_line('auxs = document.getElementById("workflow").innerHTML;');
			dbms_output.put_line('document.getElementById("workflow").innerHTML = auxs + ');
			if :e6>0 and :w6>0 then
				dbms_output.put_line(' "'||:e6||' <img class=\\"error_ico\\">  '||:w6||' <img class=\\"warn_ico\\"> ";');
			elsif :e6>0 then
				dbms_output.put_line(' "'||:e6||' <img class=\\"error_ico\\"> ";');
			elsif :w6>0 then
				dbms_output.put_line(' "'||:w6||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;				
      end if;
	  if upper(product) in ('IRC','ALL') then
			dbms_output.put_line('auxs = document.getElementById("ircsetup").innerHTML;');
			dbms_output.put_line('document.getElementById("ircsetup").innerHTML = auxs + ');
			if :e7>0 and :w7>0 then
				dbms_output.put_line(' "'||:e7||' <img class=\\"error_ico\\">  '||:w7||' <img class=\\"warn_ico\\"> ";');
			elsif :e7>0 then
				dbms_output.put_line(' "'||:e7||' <img class=\\"error_ico\\"> ";');
			elsif :w7>0 then
				dbms_output.put_line(' "'||:w7||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;				
      end if;
	
	  dbms_output.put_line('</script>');
	
	

EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;
/

begin
select to_char(sysdate,'hh24:mi:ss') into :et_time from dual;
end;
/

declare
	st_hr1 varchar2(10);
	st_mi1 varchar2(10);
	st_ss1 varchar2(10);
	et_hr1 varchar2(10);
	et_mi1 varchar2(10);
	et_ss1 varchar2(10);
	hr_fact varchar2(10);
	mi_fact varchar2(10);
	ss_fact varchar2(10);
	vss number;
	vse number;
	vt number;
begin
	dbms_output.put_line('<br><br><hr><br><TABLE width="50%"><THEAD><STRONG>HCM Analyzer Performance Data</STRONG></THEAD>');
    dbms_output.put_line('<TBODY><TR><TH>Started at:</TH><TD>'||:st_time||'</TD></TR>');
    dbms_output.put_line('<TR><TH>Complete at:</TH><TD>'||:et_time||'</TD></TR>');
    	
	st_hr1 := substr(:st_time,1,2);
	st_mi1 := substr(:st_time,4,2);
	st_ss1 := substr(:st_time,7,2);
	et_hr1 := substr(:et_time,1,2);
	et_mi1 := substr(:et_time,4,2);
	et_ss1 := substr(:et_time,7,2);
	
	vss:=st_hr1*60*60 + st_mi1*60+st_ss1;
	vse:=et_hr1*60*60 + et_mi1*60+et_ss1;
	
	
	dbms_output.put_line('<TR><TH>Total time taken to complete the script:</TH>');
	if vse>vss then	
			vt:=vse-vss;			
	else
			vt:=24*60*60-vss +vse;
	end if;
	
	if (vt > 3600) then
								dbms_output.put_line('<TD>'||trunc(vt/3600)||' hours, '||trunc((vt-((trunc(vt/3600))*3600))/60)||' minutes, '||trunc(vt-((trunc(vt/60))*60))||' seconds</TD></TR>');
	elsif (vt > 60) then
								dbms_output.put_line('<TD>'||trunc(vt/60)||' minutes, '||trunc(vt-((trunc(vt/60))*60))||' seconds</TD></TR>');
	elsif (vt < 60) then
								dbms_output.put_line('<TD>'||trunc(vt)||' seconds</TD></TR>');
	end if;
			
	dbms_output.put_line('</TBODY></TABLE>');
	
end;
/


-- Feedback and Community reference

prompt   
prompt   
prompt <!-- **************************************************************************************** -->
prompt <!-- *******                           Section 9 : Feedback                           ******* -->
prompt <!-- **************************************************************************************** -->
prompt 


-- Display feedback and communities reference
declare
		db_ver    	  VARCHAR2(100);
		db_charset V$NLS_PARAMETERS.value%type;
		db_lang V$NLS_PARAMETERS.value%type;
		rup_level varchar2(20);
		v_exists number;
		platform varchar2(100);		
		cursor legislations is
				SELECT DECODE(legislation_code
							   ,null,'Global'
							   ,legislation_code)  leg              
					   , DECODE(application_short_name
							   , 'PER', 'Human Resources'
							   , 'PAY', 'Payroll'
							   , 'GHR', 'Federal Human Resources'
							   , 'CM',  'College Data'
							   , application_short_name) application         
				  FROM hr_legislation_installations
				  WHERE status = 'I'
				  ORDER BY legislation_code;
		v_wfVer WF_RESOURCES.TEXT%type:='';
		v_crtddt V$DATABASE.CREATED%type;
		irc_status varchar2(20);
		v1_1320920 varchar2(30);
		v2_1320920 varchar2(30);
		cursor bg is
		SELECT o.business_group_id bgi,o.organization_id oi,otl.name name,o3.ORG_INFORMATION9 lc			
			,o3.ORG_INFORMATION10 cc,o4.ORG_INFORMATION2 ef ,to_char(o.date_from , 'DD-MON-YYYY') df,to_char(o.date_to, 'DD-MON-YYYY') dt
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;
	cursor c_pay is select parameter_name, nvl(parameter_value,'null') param_value
      from pay_action_parameters
      where parameter_name in ('BAL BUFFER SIZE','EE_BUFFER_SIZE','RR_BUFFER_SIZE','RRV_BUFFER_SIZE','CHUNK SIZE','RANGE_PERSON_ID','THREADS','TRACE','LOW_VOLUME');
      max_dump v$parameter.value%type;

  FUNCTION compare_versions(p_ver1 IN VARCHAR2, p_ver2 IN VARCHAR2)
  RETURN INTEGER IS
    l_ver1     VARCHAR2(100) := p_ver1;
    l_ver2     VARCHAR2(100) := p_ver2;
    l_seg1     VARCHAR2(20);
    l_seg2     VARCHAR2(20);
    l_seg1_num NUMBER;
    l_seg2_num NUMBER;
    l_idx      NUMBER;

  BEGIN

    IF (l_ver1 = l_ver2 OR (l_ver1 is null and l_ver2 is null)) THEN
      RETURN(0);
    ELSIF (l_ver1 is null) THEN
      RETURN(-1);
    ELSIF (l_ver2 is null) THEN
      RETURN(1);
    END IF;

    WHILE l_ver1 is not null AND l_ver2 is not null LOOP
      l_idx := instr(l_ver1, '.');
      IF l_idx <> 0 THEN
        l_seg1 := substr(l_ver1, 1, l_idx -1);
        l_ver1 := substr(l_ver1, l_idx+1);
      ELSE
        l_seg1 := l_ver1;
        l_ver1 := null;
      END IF;
      l_idx := instr(l_ver2, '.');
      IF l_idx <> 0 THEN
        l_seg2 := substr(l_ver2, 1, l_idx -1);
        l_ver2 := substr(l_ver2, l_idx+1);
      ELSE
        l_seg2 := l_ver2;
        l_ver2 := null;
      END IF;
      BEGIN
        l_seg1_num := to_number(l_seg1);
        l_seg2_num := to_number(l_seg2);
        IF l_seg1_num < l_seg2_num THEN
          RETURN(-1);
        ELSIF l_seg1_num > l_seg2_num THEN
          RETURN(1);
        END IF;
      EXCEPTION WHEN VALUE_ERROR THEN
        IF l_seg1 < l_seg2 THEN
          RETURN(-1);
        ELSIF l_seg1 > l_seg2 THEN
          RETURN(1);
        END IF;
      END;
    END LOOP;
    IF l_ver1 is null AND l_ver2 is null THEN
      RETURN(0);
    ELSIF l_ver1 is null THEN
      RETURN(-1);
    ELSIF l_ver2 is null THEN
      RETURN(1);
    END IF;
  EXCEPTION WHEN OTHERS THEN
    dbms_output.put_line('Error: '||sqlerrm);
  END compare_versions;
begin
	
	dbms_output.put_line('<br><hr><a name="feedback"></a><table border="2" name="NoteBox" cellpadding="1" bordercolor="#C1A90D" bgcolor="#CCCCCC" cellspacing="1"><br>');
	dbms_output.put_line('<b>Still have questions or suggestions?</b><br>  <A HREF="https://community.oracle.com/message/12181012#12181012"  target="_blank">');
	dbms_output.put_line('<img src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback.png" title="Click here to provide feedback"/></a><br>');
	dbms_output.put_line('Click the button above to ask questions about and/or provide feedback on the HCM Technical Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!<br>');
	
	SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, 'TNS for '), ':' )||pcv2.status, 1, 80)
    INTO platform
        FROM product_component_version pcv1,
           product_component_version pcv2
     WHERE UPPER(pcv1.product) LIKE '%TNS%'
       AND UPPER(pcv2.product) LIKE '%ORACLE%'
       AND ROWNUM = 1;
	select VALUE into db_lang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
	select VALUE into db_charset FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';
	select banner into db_ver from V$VERSION WHERE ROWNUM = 1;
	select count(1) into v_exists FROM V$DATABASE;
	if v_exists=1 then	
	SELECT CREATED into v_crtddt FROM V$DATABASE;
	end if;
	select count(1) into v_exists FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';
	if v_exists=1 then
	SELECT TEXT into v_wfVer  FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';	
	end if;	
	if :apps_rel like '12.%' then
		select count(*) into v_exists from fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		if v_exists >0 then	
		SELECT L.MEANING  into irc_status  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		else
		  irc_status:='Not available';
		end if;
	else
	  irc_status:='Not available';
	 end if;  
	
	dbms_output.put_line('<!-- ######BEGIN DX SUMMARY######');
	dbms_output.put_line('<diagnostic><run_details>');
    dbms_output.put_line('<detail name="Instance">'||:sid||'</detail>');
    dbms_output.put_line('<detail name="Instance Date">'||v_crtddt||'</detail>');
    dbms_output.put_line('<detail name="Platform">'||platform||'</detail>');
    dbms_output.put_line('<detail name="File Version">200.42</detail>');
    dbms_output.put_line('<detail name="Language">'||db_lang||' / '||db_charset||'</detail>');
    dbms_output.put_line('<detail name="Database">'||db_ver||'</detail>');
	dbms_output.put_line('<detail name="Application">'||:apps_rel||'</detail>');
    dbms_output.put_line('<detail name="Workflow">'||v_wfVer||'</detail>');
    dbms_output.put_line('<detail name="PER">'||:hr_status||'</detail>');
    dbms_output.put_line('<detail name="PAY">'||:pay_status||'</detail>');
    dbms_output.put_line('<detail name="IRC">'||irc_status||'</detail>');	
	dbms_output.put_line('<detail name="RUP">'||:rup_level_n|| ' applied on ' || :v_rup_date||'</detail>');
  dbms_output.put_line('</run_details>');
  dbms_output.put_line('<parameters>');
    for l_rec in legislations loop
	dbms_output.put_line('<parameter name="Legislation">'||l_rec.leg||'   '||l_rec.application||'</parameter>');
	end loop;
	for org_rec in bg loop
		dbms_output.put_line('<parameter name="BG"><![CDATA['||lpad(org_rec.bgi,10)||' | '||lpad(org_rec.oi,10)||' | '||lpad(org_rec.name,30)||' | '||lpad(org_rec.lc,6)||' | '||lpad(org_rec.cc,6)||' | '||lpad(org_rec.ef,7)||' | '||lpad(org_rec.df,11)||' | '||lpad(org_rec.dt,11)||']]></parameter>');
	end loop;
		for c_rec in c_pay loop
		dbms_output.put_line('<parameter name="PERF">'||c_rec.parameter_name||': '||c_rec.param_value||'</parameter>');
	end loop;
	select nvl(value,'null') into max_dump from v$parameter  where lower(name) ='max_dump_file_size';
	dbms_output.put_line('<parameter name="PERF">Max_dump_file_sixe: '||max_dump||'</parameter>');
	dbms_output.put_line('<parameter name="PERF">Gather Schema Statistics for ALL - last time completed normally: '||:p1||'</parameter>');
	dbms_output.put_line('<parameter name="PERF">Gather Schema Statistics for HR - last time completed normally: '||:p2||'</parameter>');
	dbms_output.put_line('</parameters> <issues><signature id="INSTSUM"><failure row="1">d</failure></signature>');
  if :apps_rel like '12.1%' then
			  select que.version into v1_1320920
			  from (
				 select file_version.version version,
				 rank()over(partition by files.filename
				   order by file_version.version_segment1 desc,
				   file_version.version_segment2 desc,file_version.version_segment3 desc,
				   file_version.version_segment4 desc,file_version.version_segment5 desc,
				   file_version.version_segment6 desc,file_version.version_segment7 desc,
				   file_version.version_segment8 desc,file_version.version_segment9 desc,
				   file_version.version_segment10 desc,
				   file_version.translation_level desc) as rank1
				 from ad_file_versions file_version,
				   (
				   select filename, app_short_name, subdir, file_id
				   from ad_files
				   where upper(filename) like upper('DirectReportsVO.xml')
				   ) files
				 where files.file_id = file_version.file_id
			  ) que
			  where rank1 = 1;
			  select substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4) into v2_1320920
			  from dba_source where  name like  'HR_TERMINATION_SS' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type ='PACKAGE BODY'  
			  and line =2;  
			  if compare_versions(v1_1320920,'120.5.12010000.5')<0 or compare_versions(v2_1320920,'120.2.12010000.6')<0 then
				dbms_output.put_line('<signature id="NOTE1320920"><failure row="1">');
				dbms_output.put_line('<column name="vDirectReportsVO">'||v1_1320920||'</column>');
				dbms_output.put_line('<column name="vHR_TERMINATION_SS">'||v2_1320920||'</column>');
				dbms_output.put_line('</failure></signature>');
			  end if;
  end if;
  
  dbms_output.put_line('</issues></diagnostic>');
  dbms_output.put_line('######END DX SUMMARY######-->');
end;
/


spool off
set heading on
set feedback on  
set verify on

set termout on

exit
;
