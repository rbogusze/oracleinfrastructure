REM $Id: pay_analyzer.sql 200.27 2015/19/08 05:11:16 pkm ship $
REM   
REM  Consolidated script to diagnose issues that can cause problems in your Payroll on an environment.
REM
REM   How to run it? Follow the directions found in the Note 1631780.1 
REM   
REM   	sqlplus apps/<password>	@pay_analyzer11.sql 
REM
REM   
REM   Output file format found in the same directory if run manually in the file you spooled

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i
REM 
REM MENU_TITLE: HCM Payroll Analyzer for 11i
REM
REM MENU_START
REM
REM SQL: Run (HCM) Payroll Analyzer for 11i
REM FNDLOAD: Load (HCM) Person Analyzer for 11i as a Concurrent Program 
REM 
REM MENU_END 
REM
REM HELP_START  
REM 
REM  EBS Payroll Analyzer (Doc ID 1631780.1)
REM
REM  Compatible: 11i
REM 
REM  Explanation of available options:
REM  
REM    (1) Run EBS Payroll Analyzer for 11i
REM        o Runs pay_analyzer.sql as APPS
REM        o Creates an HTML report file in MENU/output/ 
REM
REM    (2) Install EBS Payroll Analyzer for 11i as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: 
REM          "Global HRMS Reports & Process" 
REM
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: PAY_TOP
REM PROG_NAME: PAY_ANALYZER_SQL
REM DEF_REQ_GROUP: Global SLA/Payroll Processes
REM PROG_TEMPLATE: pay11i_prog.ldt
REM APP_NAME: Payroll
REM PROD_SHORT_NAME: PAY 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT 
REM
REM ANALYZER_BUNDLE_END

set arraysize 1
set heading off
set feedback off  
set echo off
set verify off
SET CONCAT ON
SET CONCAT .
SET ESCAPE OFF
SET ESCAPE '\'

set lines 120
set pages 9999
set serveroutput on size 1000000

variable st_time 	varchar2(100);
variable et_time 	varchar2(100);
VARIABLE rup_level_n varchar2(50);



begin
select to_char(sysdate,'hh24:mi:ss') into :st_time from dual;
end;
/

REM Uncomment the 7 lines below by removing the REM tag at the beginning of each line
REM to automatically spool the output report to a meaningful name.

/*
COLUMN host_name NOPRINT NEW_VALUE hostname
SELECT host_name from v$instance;
COLUMN instance_name NOPRINT NEW_VALUE instancename
SELECT instance_name from v$instance;
COLUMN sysdate NOPRINT NEW_VALUE when
select to_char(sysdate, 'YYYY-Mon-DD') "sysdate" from dual;
SPOOL pay_&&hostname._&&instancename._&&when..html
*/

VARIABLE n		        NUMBER;
VARIABLE HOST        	VARCHAR2(80);
VARIABLE SID         	VARCHAR2(20);
VARIABLE apps_rel  varchar2(50);
VARIABLE hr_status varchar2(20);
VARIABLE pay_status varchar2(20);
VARIABLE v_rup_date varchar2(20);
VARIABLE rup_level varchar2(20);
VARIABLE issuep varchar2(2);
VARIABLE w1 number;
VARIABLE w2 number;
VARIABLE w3 number;
VARIABLE w4 number;
VARIABLE w5 number;
VARIABLE w6 number;
VARIABLE w7 number;
VARIABLE w8 number;
VARIABLE w9 number;
VARIABLE w10 number;
VARIABLE w11 number;
VARIABLE w12 number;
VARIABLE w13 number;
VARIABLE w14 number;
VARIABLE w15 number;
VARIABLE w16 number;
VARIABLE w17 number;
VARIABLE w18 number;
VARIABLE w19 number;
VARIABLE w20 number;
VARIABLE w21 number;
VARIABLE w22 number;
VARIABLE w23 number;
VARIABLE w24 number;
VARIABLE w25 number;
VARIABLE w26 number;
VARIABLE w27 number;
VARIABLE w28 number;
VARIABLE w29 number;
VARIABLE w30 number;
VARIABLE w31 number;
VARIABLE e1 number;
VARIABLE e2 number;
VARIABLE e3 number;
VARIABLE e4 number;
VARIABLE e5 number;
VARIABLE e6 number;
VARIABLE e7 number;
VARIABLE e8 number;
VARIABLE e9 number;
VARIABLE e10 number;
VARIABLE e11 number;
VARIABLE e12 number;
VARIABLE e13 number;
VARIABLE e14 number;
VARIABLE e15 number;
VARIABLE e16 number;
VARIABLE e17 number;
VARIABLE e18 number;
VARIABLE e19 number;
VARIABLE e20 number;
VARIABLE e21 number;
VARIABLE e22 number;
VARIABLE e23 number;
VARIABLE e24 number;
VARIABLE e25 number;
VARIABLE e26 number;
VARIABLE e27 number;
VARIABLE e28 number;
VARIABLE e29 number;
VARIABLE e30 number;
VARIABLE e31 number;
VARIABLE v_link_no number;
VARIABLE p1 varchar2(50);
VARIABLE p2 varchar2(50);

alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';



prompt <HTML>
prompt <HEAD>
prompt <TITLE>Payroll Analyzer</TITLE>
prompt <STYLE TYPE="text/css">
prompt <!-- table {background-color: #000000 color:#000000; font-size: 10pt; font-weight: bold; padding:2px; text-align:left}
prompt td {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt; border-style: solid; border-width: 1; border-color: #DEE6EF}
prompt tr {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt}
prompt th {background-color: #DEE6EF; color: #000000; height: 20; border-style: solid; border-width: 2; border-color: #f7f7e7}
prompt th.rowh {background-color: #CCCC99; color: #336699; height: 20; border-style: solid; border-width: 1; border-top-color: #f7f7e7; border-bottom-color: #f7f7e7; border-left-width: 0; border-right-width: 0}

prompt .divTitle {
prompt  -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; font-family: Calibri; background-color: #152B40; border: 1px solid #003399; padding: 9px; margin: 0px; box-shadow: 3px 3px 3px #AAAAAA; color: #F4F4F4; font-size: x-large; font-weight: bold; } 
prompt .divSection {
prompt  -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; font-family: Calibri; font-size: 11pt; background-color: #CCCCCC; border: 1px solid #DADADA; padding: 9px; margin: 0px;  box-shadow: 3px 3px 3px #AAAAAA; }
prompt .divSectionTitle {
prompt width: 98.5%;font-family: Calibri;font-size: x-large;font-weight: bold;background-color: #152B40;color: #FFFFFF;padding: 9px;margin: 0px;
prompt box-shadow: 3px 3px 3px #AAAAAA;-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;height: 30px;overflow:hidden;}
prompt .columns       { 
prompt width: 98.5%; font-family: Calibri;font-weight: bold;background-color: #254B72;color: #FFFFFF;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;
prompt -moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;height: 30px;}
prompt div.divSectionTitle div   { height: 30px; float: left; }
prompt div.left          { width: 80%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
prompt div.right         { width: 20%; background-color: #152B40; font-size: medium; border-radius: 6px;}
prompt div.clear         { clear: both; }
prompt .divItem {
prompt  -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; font-family: Calibri; background-color: #F4F4F4; border: 1px solid #EAEAEA; padding: 9px; margin: 0px; box-shadow: 3px 3px 3px #AAAAAA; }
prompt .divItemTitle {
prompt  font-family: Calibri; font-size: medium; font-weight: bold; color: #336699; border-bottom-style: solid; border-bottom-width: medium; border-bottom-color: #3973AC; margin-bottom: 9px; padding-bottom: 2px; margin-left: 3px; margin-right: 3px; }
prompt  .divwarn {
prompt    -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; font-family: Calibri; color: #333333; background-color: #FFEF95; border: 0px solid #FDC400; padding: 9px; margin: 0px; box-shadow: 3px 3px 3px #AAAAAA; font-size: 11pt; }
prompt .toctable {background-color: #F4F4F4;}
prompt .diverr {
prompt  font-family: Calibri; font-size: 11pt; font-weight: bold; color: #333333; background-color: #ffd8d8; box-shadow: 3px 3px 3px #AAAAAA; -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; padding: 9px; margin: 0px; }
prompt .graph {font-family: Arial, Helvetica, sans-serif;font-size: small;}
prompt .graph tr {font-family: Arial, Helvetica, sans-serif;font-size: small;background-color: transparent;}
prompt .graph td {font-family: Arial, Helvetica, sans-serif;font-size: small;background-color: transparent;border: 0px transparent;}
prompt .TitleBar, .TitleImg{display:table-cell;width:95%;vertical-align: middle;--border-radius: 6px;font-family: Calibri;background-color: #152B40;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;color: #F4F4F4;font-size: xx-large;font-size: 4 vw;font-weight: bold;overflow:hidden;}
prompt .TitleImg{}
prompt .TitleBar > div{height:25px;}
prompt .TitleBar .Title2{font-family: Calibri;background-color: #152B40;padding: 9px;margin: 0px;color: #F4F4F4;font-size: medium;font-size: 4 vw;}
prompt .divok {
prompt border: 1px none #00CC99; font-family: Calibri; font-size: 11pt; font-weight: normal; background-color: #ECFFFF; color: #333333;  padding: 9px; margin: 0px; box-shadow: 3px 3px 3px #AAAAAA; -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; }
prompt .divSum {font-family: Calibri;background-color: #F4F4F4;}
prompt .divSumTitle {font-family: Calibri;font-size: medium;color: #336699;}
prompt A {	COLOR: #0066cc}
prompt A:visited {	COLOR: #0066cc}
prompt A:hover {	COLOR: #0099cc}
prompt A:active {	COLOR: #0066cc}
prompt .detail {	TEXT-DECORATION: none}
prompt .legend {font-weight: normal;color: #0000FF;font-size: 9pt; font-weight: bold}
prompt .btn {border: #000000;border-style: solid;border-width: 2px;width:190;height:50;border-radius: 6px;background: linear-gradient(#FFFFFF, #B0B0B0);font-weight: bold;color: blue;margin-top: 5px;margin-bottom: 5px;margin-right: 5px;margin-left: 5px;vertical-align: middle;}  
  
prompt span.errbul {color: #EE0000;font-size: large;font-weight: bold;text-shadow: 1px 1px #AAAAAA;}
prompt -->
prompt </STYLE>
prompt <script type="text/javascript">
prompt	   function displayItem(e, itm_id) {
prompt     var tbl = document.getElementById(itm_id);
prompt     if (tbl.style.display == ""){
prompt        e.innerHTML =
prompt           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt        tbl.style.display = "none"; }
prompt     else {
prompt         e.innerHTML =
prompt           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt         tbl.style.display = ""; }
prompt   }
prompt   function displayItem2(e, itm_id) {
prompt     var tbl = document.getElementById(itm_id);
prompt     if (tbl.style.display == ""){
prompt        e.innerHTML =
prompt           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt        e.innerHTML = e.innerHTML.replace("Hide","Show");
prompt        tbl.style.display = "none"; }
prompt     else {
prompt         e.innerHTML =
prompt           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt         e.innerHTML = e.innerHTML.replace("Show","Hide");
prompt         tbl.style.display = ""; }
prompt   }   
prompt		function activateTab(pageId) {
prompt			 var tabCtrl = document.getElementById('tabCtrl');
prompt			   var pageToActivate = document.getElementById(pageId);
prompt			   for (var i = 0; i < tabCtrl.childNodes.length; i++) {
prompt				   var node = tabCtrl.childNodes[i];
prompt				   if (node.nodeType == 1) { /* Element */
prompt					   node.style.display = (node == pageToActivate) ? 'block' : 'none';
prompt				   }
prompt				}
prompt		   }
prompt function opentabs() {
prompt  var tabCtrl = document.getElementById('tabCtrl'); 
prompt    for (var i = 0; i < tabCtrl.childNodes.length; i++) {
prompt        var node = tabCtrl.childNodes[i];
prompt  if (node.nodeType == 1)  {
prompt 	   if (node.toString() != '[object HTMLScriptElement]') { node.style.display =  'block' ; 
prompt       }  }   }  }
prompt function closetabs() {
prompt  var tabCtrl = document.getElementById('tabCtrl');  
prompt    for (var i = 0; i < tabCtrl.childNodes.length; i++) {
prompt        var node = tabCtrl.childNodes[i];
prompt        if (node.nodeType == 1) { /* Element */
prompt            node.style.display =  'none' ;  }    }   }
prompt function activateTab2(pageId) {
prompt     var tabCtrl = document.getElementById('tabCtrl');
prompt       var pageToActivate = document.getElementById(pageId);
prompt       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
prompt           var node = tabCtrl.childNodes[i];
prompt           if (node.nodeType == 1) { /* Element */
prompt               node.style.display = (node == pageToActivate) ? 'block' : 'none';
prompt           } }
prompt     tabCtrl = document.getElementById('ExecutionSummary2');
prompt     tabCtrl.style.display = "none";
prompt     tabCtrl = document.getElementById('ExecutionSummary1');
prompt        tabCtrl.innerHTML = tabCtrl.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt   }
prompt           function closeall()
prompt           {var txt = "s1sql";
prompt           var i;
prompt           var x=document.getElementById('s1sql0');
prompt           for (i=0;i<102;i++)
prompt           {
prompt                      x=document.getElementById(txt.concat(i.toString())); 
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none';   
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt              }  	}
prompt           for (i=272;i<273;i++)
prompt           {
prompt                      x=document.getElementById(txt.concat(i.toString())); 
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none';   
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt              }  	}
prompt           for (i=472;i<473;i++)
prompt           {
prompt                      x=document.getElementById(txt.concat(i.toString())); 
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none';   
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt              }  	}
prompt           txt = "s1sql500";
prompt           for (i=1;i<3000;i++)
prompt {			   x=document.getElementById(txt.concat(i.toString()));                                      
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none'; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt		  }	}  
prompt           txt = "s1sql300";
prompt           for (i=1;i<35;i++)
prompt {			   x=document.getElementById(txt.concat(i.toString()));                                      
prompt		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none'; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  
prompt			}
prompt		  }	}  
  
prompt     function openall()
prompt     {var txt = "s1sql";
prompt     var i;                                                                    
prompt     var x=document.getElementById('s1sql0');                                      
prompt     for (i=0;i<102;i++)                                                               
prompt     {			   x=document.getElementById(txt.concat(i.toString()));                                             
prompt     		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  
prompt              }  	}
prompt     for (i=272;i<273;i++)                                                                                         
prompt     {			   x=document.getElementById(txt.concat(i.toString()));                                             
prompt     		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  
prompt              }  	}
prompt     for (i=472;i<473;i++)                                                                                         
prompt     {			   x=document.getElementById(txt.concat(i.toString()));                                             
prompt     		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  
prompt              }  	}
prompt  txt = "s1sql500";
prompt     for (i=1;i<3000;i++)                                                                                         
prompt     {			   x=document.getElementById(txt.concat(i.toString()));                                             
prompt     		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  
prompt              }  	}
prompt txt = "s1sql300";
prompt     for (i=1;i<35;i++)                                                                                         
prompt     {			   x=document.getElementById(txt.concat(i.toString()));                                             
prompt     		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''; 
prompt			x = document.getElementById(txt.concat(i.toString(),'b'));  
prompt			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
prompt			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  
prompt              }  	}
prompt     		  }  

prompt function hideRow(target)
prompt    {var row = document.getElementById(target);
prompt    row.style.display = 'none';
prompt    row = document.getElementById(target.concat('b'));
prompt    row.scrollIntoView();
prompt	row.innerHTML = row.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));	   
prompt     }
prompt function hideRow2(target)
prompt    {var row = document.getElementById(target);
prompt    row.style.display = 'none';
prompt    row = document.getElementById(target.concat('b'));
prompt    row.scrollIntoView();
prompt	row.innerHTML = row.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
prompt	row.innerHTML = row.innerHTML.replace("Hide","Show");   
prompt     }	 
prompt  </script>
prompt  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
prompt  <script>
prompt  $(document).ready(function(){
prompt  var src = $('img#error_ico').attr('src');
prompt  $('img.error_ico').attr('src', src);
prompt  var src = $('img#warn_ico').attr('src');
prompt  $('img.warn_ico').attr('src', src);
prompt  var src = $('img#check_ico').attr('src');
prompt  $('img.check_ico').attr('src', src);
prompt  });</script>

prompt </HEAD>
prompt <BODY>

prompt <div style="display: none;">
prompt <img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAANYSURBVHjaYvz//z8DDBQwMor+ZWDw+8fA4PKHgcEUiOWB+CEQnwbiPb8ZGDat+///NQMSAAggRpgBQM3OQI25XiGe/jr2Ngwi6hoMbHz8DF/v3mR4dO4cw/HjZxjWHru4C2hQ3+7//3fCDAAIILABhUDNUnJS/UHZSbpKcuIMDCf3Mvy9fo7h7/OnDP+FxRj+i8sx/BOXZTh8+xnDosPnb936/L3yzP//60AGAAQQYwEDA8jZs/M7a/yVvz9n+LdxAcP/v38Z/gId9g/oJBD9F0wzAj2kzrDn43+G7pM3j7xkYEh5+P//TYAAYgL5GeRskM3/Ni1gYEyrZWCcsx9FM9fC/Qzs2fUMP4Heseb6z+AgzmfDycAQw8jIyAYQQExAP7mA/Axy9r8/QOOM7RmYTB0YWOfvBxsA0sxi5gDE9kDD/jP8e/2KQZeXlYGJgcEe6AMJgABiSGNguPN919r/v93l/v/UZfj/XYfh/59T+/+DwO+TEPrnif3/nygy/H8oz/D/niLr/yMawv+1GBieAw0wAgggkAvk2fgFGf6/eMrwD+rkb3GODH9OHQDb/OvkAYbXkY6QcADiP79+Mwj8/c0AVCoKNEAAIIBABjz8dvcGwz8hMbABIMwJdTZIM5u5A4Pwsv0Mf4Caf4Mw0PHPvv4C0gyg9MAFEEAgA04/PHeW4b+EHNgGzgUIzW+ANv88cYCBw8KBQXLlfrD8v/9MDFe//QEZcBtowDeAAAIZsOfEsTPguAZF1e+TB+Ga/wBd8yzMkeH78QMMX48dBBvwGyh25vtfhh8MDBeABnwACCDGQKBfgJwlBT42bmZ/3jL8unOD4S8w+EGaQZHyBxqdIPZfRmaGjV8ZGOZ+/nvyFQPDFKC+QwABxARK20Dn9C0EprC9n4BOVFBn+McvBFTMyvCHgZHhD1DTX0YWht/MrGDNG77+vfuFgWELUPNNoAteAAQQPC+YMjIGAdNaoZOkgI0eLxuDAhsDg9DfPwxPvv5kuPrlF8Ppb38ZDv/4dxKk+R0Dw0GglutAvW8AAogROTfKMzKqg1IYKJEADVMFRRUotEEBBvLzRwaGU1Cb74M0g/QABBCKAWABYPIEpzAGBhFQPIOiChTaoAADYpCmF0A9v2DqAQIMAAqQl7ObLOmtAAAAAElFTkSuQmCC" alt="error_ico">

prompt <img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAJHSURBVHjaYvz//z8DNjAhlnHdv38MgUC8vmT5/yAGHAAggBhABqDj/hgG7+OLvP+DwJEF3v+jLRgKsKkDYYAAYsJiMzMDI0uHkV87A8NpRgYJ9q0MSqIMBQJcjFLYHAAQQBgGAJ2c7BaZpMP26ziYr6zMwGBhwiDvb8BQxAgE6OoBAgjFOb1RDDwTE3mf/v3+5H9nCvf/FEfG/51JjP+fb2T4X+3F8EZFlEEL3QsAAcSEZnuRX3KhFNO7uQxnL3xjuPuQgeHsJQYGCVEGBjtLBmFbFYZyoCNYkPUABBDcgJ5IRmluQZkyeZM0Bobn3QziohBxcRGQyQwMVsZANi9DmKk8gyWyAQABxIRke3VgZhU344tWIOcLg4c9JHo9bIH0XwYGHg4GBjcbBg49SbArOGD6AAKIEeSPrnBGLSFp7UsprauYGa7qAQ34C9YEshlMQ/G/PwwM5V0M/048YAg+fO//BpABAAHEBLW9KzS/k5nhSRlc88K1DAwxJYwMC9cjDGACGujvwMCkIcpQBXQFL0gvQAAxdYQy2hvb23vzC/EwMLzbCrd591FGhmevgPRxRoQrgC6w0WVg0FdkMHVSZogGGQAQQExA20stA0rBAcfwH+FsV4v/DFLAgHQ1+w/XDDPISpuBQU6AIRnoCmGAAGIBGmDCeNuHgYEDyc9AOt4biD3QNP+ByKlKMjCwMzGogNIZQACBDNjS08+QDKQZ8GFQnkOmP/5gOA00QAAggMCxAHSKPpAjx0A6eAQQQIy4sjOxACDAAOXOBcGE78mYAAAAAElFTkSuQmCC" alt="warn_ico">

prompt <img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAELSURBVHjaYvz//z8DJQAggJhIUcyYwNjAGMP4nzGcsQEmBhBADCAXEIMZ4hkaGKIZ/h//dvw/QyDDfwZnhskgcYAAIl3zKQYI9mIA+V0dIIDI12zOsAxogC9AAEEUpQIVpQIFgTSG5ig8moEuAAgguObjv4//RzYExeYL2DWD1AEEEANc82uG/1Ufq/4zJAMVBTNMhtt8EarZE1MzCAMEEML5rxkQhhBhMwwDBBAiDEA2PwXie0BDXlURtBmGAQIIwYA6m+E6A0KzF37NIAwQQKgcb6AhgcRrBmGAAMIUAKYwYjWDMEAAMWLLTIyMjOpASg2IbwHlb+LLHwABxEhpbgQIICYGCgFAgAEAGJx1TwQYs20AAAAASUVORK5CYII=" alt="check_ico">
prompt </div>

prompt <div class="TitleBar"><div class="Title1">Payroll Analyzer</div>
prompt <div class="Title2">Compiled using version 200.27 / Latest version: 
prompt <a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1631780.1:PAY_ANALYZER11">
prompt <img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/hcm_pay_latest_version.gif" title="Click here to download the latest version of analyzer" alt="Latest Version Icon"></a></div></div>
prompt <div class="TitleImg"><a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div><br>


declare
v_date varchar2(200);
procedure leg_tabs (v_leg varchar2, v_leg_name varchar2, v_page varchar2) is
  v_exists number;  
Begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = v_leg  and status='I';     
     if v_exists>0 then
               dbms_output.put_line('<button onclick="activateTab('''||v_page||''')" style="width:190;height:50" >');
			   dbms_output.put_line('<font color="blue" ><b>'||v_leg_name||'</b> </font></button> '); 			
	 end if;
end;
begin	
	:w1:=0; :w2:=0; :w3:=0; :w4:=0; :w5:=0;
	:w6:=0; :w7:=0; :w8:=0; :w9:=0; :w10:=0;
	:w11:=0; :w12:=0; :w13:=0; :w14:=0; :w15:=0;
	:w16:=0; :w17:=0; :w18:=0; :w19:=0; :w20:=0;
	:w21:=0; :w22:=0; :w23:=0; :w24:=0; :w25:=0;
	:w26:=0; :w27:=0; :w28:=0; :w29:=0; :w30:=0; :w31:=0;
	:e1:=0; :e2:=0; :e3:=0; :e4:=0; :e5:=0;
	:e6:=0; :e7:=0; :e8:=0; :e9:=0; :e10:=0;
	:e11:=0; :e12:=0; :e13:=0; :e14:=0; :e15:=0;
	:e16:=0; :e17:=0; :e18:=0; :e19:=0; :e20:=0;
	:e21:=0; :e22:=0; :e23:=0; :e24:=0; :e25:=0;
	:e26:=0; :e27:=0; :e28:=0; :e29:=0; :e30:=0; :e31:=0;
	:v_link_no :=1;

	dbms_output.put_line('<div class="divSection">');
	dbms_output.put_line('<div class="divItem">');
	dbms_output.put_line('<div class="divItemTitle">Report Information</div>');
	dbms_output.put_line('<span class="legend">Legend: \&nbsp;\&nbsp;<img class="error_ico"> Error \&nbsp;\&nbsp;<img class="warn_ico"> Warning \&nbsp;\&nbsp;<img class="check_ico"> Passed Check</span>');
 	
	 select upper(instance_name), host_name into :sid, :host 
	  from   v$instance;
	  SELECT RELEASE_NAME into :apps_rel from FND_PRODUCT_GROUPS; 
	  select to_char(sysdate, 'Dy Month DD, YYYY hh24:mi:ss') into v_date from dual;  		
	
	
	   dbms_output.put_line('<table width="100%" class="graph"><tbody><tr class="top"><td width="33%">');
  dbms_output.put_line('<A class=detail onclick="displayItem(this,''RunDetails'');" href="javascript:;">&#9654; Execution Details</A>') ; 
	  dbms_output.put_line('<TABLE style="DISPLAY: none" id=RunDetails><TBODY>');
	  dbms_output.put_line('<TR><TH>Host:</TH>');
	  dbms_output.put_line('<TD>'||:host||'</TD></TR>');
	  dbms_output.put_line('<TR><TH>Instance: </TH>');
	  dbms_output.put_line('<TD>'||:sid||'</TD></TR>');
	  dbms_output.put_line('<TR><TH>Applications Version: </TH>');
	  dbms_output.put_line('<TD>'||:apps_rel||'</TD></TR>');
	  dbms_output.put_line('<TR><TH>Execution Date: </TH>');
	  dbms_output.put_line('<TD>'||v_date||'</TD></TR>');
	  dbms_output.put_line('<TR><TH>Analyzer version: </TH>');
	  dbms_output.put_line('<TD>200.27</TD></TR>');
	  dbms_output.put_line('</TBODY></TABLE></td>');

	dbms_output.put_line('<td width="33%"><div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>');
    dbms_output.put_line('<div id="ExecutionSummary2" style="display:none"></div>');
    dbms_output.put_line('</td></tr></table>');

   dbms_output.put_line('</div><br>');
   
	dbms_output.put_line('<div class="divItem" id="toccontent">');
	dbms_output.put_line('<div class="divItemTitle">Sections In This Report</div></div>');	
	    dbms_output.put_line('<div align="center">');
	dbms_output.put_line('<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> / ');
	dbms_output.put_line('<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a></div>');
	dbms_output.put_line('</div><br></div>');
	
  dbms_output.put_line('<div id="tabCtrl">');
  dbms_output.put_line('<div id="page1" style="display: block;">');
  
	dbms_output.put_line('<div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="generic" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Generic'); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF" size="1">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF">/  </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF" size="1">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
	
	dbms_output.put_line('<div class="divItem" >');
	dbms_output.put_line('<div class="divItemTitle">In This Section</div>');

-- Display table of contents        
  dbms_output.put_line('<table width="95%" border="0"> <tr> <td width="50%" class="toctable">');
  
  dbms_output.put_line('<b><br><a href="#overview"><font size="+1">Overview</font></a> ');
  dbms_output.put_line('<blockquote><a href="#sum">- Instance Summary</a> <br>');
  dbms_output.put_line('          <a href="#db">- Database Details</a> <br>');
  dbms_output.put_line('          <a href="#apps">- Application Details</a> <br>');
  dbms_output.put_line('          <a href="#products">- Products Status</a> <br>');
  dbms_output.put_line('          <a href="#legislations">- Legislations Installed</a> <br>');
  dbms_output.put_line('          <a href="#nls">- Languages Installed</a> <br>');
  dbms_output.put_line('</blockquote>');
    
  dbms_output.put_line('<br><a href="#performance"><font size="+1">Performance Details</font></a> '); 
      dbms_output.put_line('<blockquote><a href="#db_init_ora">- Database Initialization Parameters</a> <br>');
      dbms_output.put_line('          <a href="#gather">- Gather Schema Statistics</a> <br>');     
      dbms_output.put_line('          <a href="#hot">- Hot Payroll Tables</a><br>');      
      dbms_output.put_line('</blockquote>');
     
  
  dbms_output.put_line('<br><a href="#database"><font size="+1">Database Objects</font></a>');  
      dbms_output.put_line('<blockquote><a href="#invalids">- Invalid Objects</a> <br>');    
      dbms_output.put_line('          <a href="#triggers">- Disabled Triggers</a> <br>');
      dbms_output.put_line('          <a href="#timestamp">- Dependency timestamp discrepancies between the database objects</a> <br></blockquote>');
	  
       
  
  dbms_output.put_line('</td><td width="50%" class="toctable">');
   
  dbms_output.put_line('<br><b><a href="#versions"><font size="+1">Versions</font></a>');
		dbms_output.put_line('<blockquote><a href="#packages">- Packages versions</a> <br>');
		dbms_output.put_line('          <a href="#java">- Java Classes Versions</a> <br>');
		dbms_output.put_line('          <a href="#forms">- Forms versions</a> <br>');
		dbms_output.put_line('          <a href="#reports">- Reports Versions</a> <br>');
		dbms_output.put_line('          <a href="#ccode">- C Code Versions</a> </blockquote>');		
	  
   dbms_output.put_line('<br><b><a href="#settings"><font size="+1">Settings</font></a>');
		dbms_output.put_line('<blockquote><a href="#profiles">- Profiles Settings</a> <br>');
		dbms_output.put_line('<a href="#security">- Security Profile Details</a> <br>');
		dbms_output.put_line('<a href="#international">- International Payroll Usage</a> <br>');
		dbms_output.put_line('<a href="#pay_trigger_events">- Pay Triggers Events</a> <br>');
		dbms_output.put_line('<a href="#pay_action">- Pay Action Parameters</a> <br>'); 
		dbms_output.put_line('<a href="#ssp">- Ssp_temp_affected_rows rows</a> <br>');
		dbms_output.put_line('</blockquote>');
 
  
  dbms_output.put_line('<a href="#patching"><font size="+1">Patching</font></a>');
      dbms_output.put_line('<blockquote><a href="#rup">- HRMS RUP</a> <br>');
	  dbms_output.put_line('          <a href="#hrglobal">- Hrglobal</a> <br>');
	  dbms_output.put_line('          <a href="#atg">- ATG</a> <br>');      
      dbms_output.put_line('          <a href="#perf">- Performance patches</a> <br>');      
      dbms_output.put_line('</blockquote>');
  
	dbms_output.put_line('</td></tr></table>');
	dbms_output.put_line('</td> </tr> </table><br><br>');
	
	dbms_output.put_line('</div><br/>');
	
	dbms_output.put_line('</div><br><br>');
		
end;
/

-- Display database and application details
declare
		db_ver		VARCHAR2(100); 		
		platform varchar2(100);
		db_charset V$NLS_PARAMETERS.value%type;
		db_lang V$NLS_PARAMETERS.value%type;
		multiOrg FND_PRODUCT_GROUPS.MULTI_ORG_FLAG%type;
		multiCurr FND_PRODUCT_GROUPS.MULTI_CURRENCY_FLAG%type;
		v_hxc_status 	FND_LOOKUPS.MEANING%type;
		v_hxt_status 	FND_LOOKUPS.MEANING%type;		
		v_date varchar2(200);
		v_exists number;
		v_code varchar2(50);
		v_appl varchar2(50);
		cursor legislations is
				SELECT DECODE(legislation_code
							   ,null,'Global'
							   ,legislation_code)   leg             
					   , DECODE(application_short_name
							   , 'PER', 'Human Resources'
							   , 'PAY', 'Payroll'
							   , 'GHR', 'Federal Human Resources'
							   , 'CM',  'College Data'
							   , application_short_name)  application        
				  FROM hr_legislation_installations
				  WHERE status = 'I'
				  ORDER BY legislation_code;
		v_wfVer WF_RESOURCES.TEXT%type:='';
		v_crtddt V$DATABASE.CREATED%type;
		cursor bg is
		SELECT o.business_group_id bgi,o.organization_id oi,otl.name name,o3.ORG_INFORMATION9 lc			
			,o3.ORG_INFORMATION10 cc,o4.ORG_INFORMATION2 ef ,to_char(o.date_from , 'DD-MON-YYYY') df,to_char(o.date_to, 'DD-MON-YYYY') dt
			FROM hr_all_organization_UNITS O , 
			hr_all_organization_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;
Begin
  
  :n := dbms_utility.get_time;
      
  SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, 'TNS for '), ':' )||pcv2.status, 1, 80)
    INTO platform
        FROM product_component_version pcv1,
           product_component_version pcv2
     WHERE UPPER(pcv1.product) LIKE '%TNS%'
       AND UPPER(pcv2.product) LIKE '%ORACLE%'
       AND ROWNUM = 1;
       
 	select banner into db_ver from V$VERSION WHERE ROWNUM = 1;
	select VALUE into db_lang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
	select VALUE into db_charset FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';
  
      SELECT L.MEANING  into :hr_status
      FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '800')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'	AND l.language = 'US';
	  SELECT L.MEANING  into :pay_status
		  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '801')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'	AND l.language = 'US';
	     

    if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into :rup_level FROM ad_bugs adb
            WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646')
			; 
			 SELECT DECODE(bug_number
                  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
				  ,'19193000', 'R12.HR_PF.C.Delta.6'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =:rup_level and rownum < 2;
				  
    elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into :rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');            
                 
           SELECT DECODE(BUG_NUMBER
                  ,'20000288','R12.HR_PF.B.delta.8'
				  ,'18004477', 'R12.HR_PF.B.delta.7'
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =:rup_level and rownum < 2;            

            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into :rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
            
           SELECT DECODE(BUG_NUMBER
                  , '16077077', 'R12.HR_PF.A.delta.11'
                  , '13774477', 'R12.HR_PF.A.delta.10'
                  , '10281209', 'R12.HR_PF.A.delta.9'
                  , '9301208', 'R12.HR_PF.A.delta.8'
                  , '7577660', 'R12.HR_PF.A.delta.7'
                  , '7004477', 'R12.HR_PF.A.delta.6'
                  , '6610000', 'R12.HR_PF.A.delta.5'
                  , '6494646', 'R12.HR_PF.A.delta.4'
                  , '6196269', 'R12.HR_PF.A.delta.3'
                  , '5997278', 'R12.HR_PF.A.delta.2'
                  , '5881943', 'R12.HR_PF.A.delta.1'
                  , '4719824', 'R12.HR_PF.A')
                  , LAST_UPDATE_DATE  
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =:rup_level and rownum < 2;
                 
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
            
            if v_exists>0 then         
				   select max(to_number(bug_number)) into :rup_level from ad_bugs 
							WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
						   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');                    
								 
				   SELECT DECODE(BUG_NUMBER
                           , '2803988', 'HRMS_PF.E'
                           , '2968701', 'HRMS_PF.F'
                           , '3116666', 'HRMS_PF.G'
                           , '3233333', 'HRMS_PF.H'
                           , '3127777', 'HRMS_PF.I'
                           , '3333633', 'HRMS_PF.J'
                           , '3500000', 'HRMS_PF.K'
                           , '5055050', 'HR_PF.K.RUP.1'
                           , '5337777', 'HR_PF.K.RUP.2'
                           , '6699770', 'HR_PF.K.RUP.3'
                           , '7666111', 'HR_PF.K.RUP.4'
                           , '9062727', 'HR_PF.K.RUP.5'
                           , '10015566', 'HR_PF.K.RUP.6'
                           , '12807777', 'HR_PF.K.RUP.7'
                           , '14488556', 'HR_PF.K.RUP.8'
						   , '17774746', 'HR_PF.K.RUP.9'
                            )  
                        , LAST_UPDATE_DATE  
                          into :rup_level_n, :v_rup_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =:rup_level and rownum < 2;
						
				end if;   
      end if;
	
		  
	dbms_output.put_line('<a name="overview"></a>');
	dbms_output.put_line('<div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">Instance Overview</div><br>');

    
	select count(1) into v_exists FROM V$DATABASE;
	if v_exists=1 then	
	SELECT CREATED into v_crtddt FROM V$DATABASE;
	end if;
	select count(1) into v_exists FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';
	if v_exists=1 then
	SELECT TEXT into v_wfVer  FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';	
	end if;		
		
	dbms_output.put_line('<DIV class=divItem><a name="sum"></a>');
	dbms_output.put_line('<DIV id="s1sql0b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql0'');" href="javascript:;">&#9654; Instance Summary</A></DIV>');

	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql0" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Instance Summary</B></font></TD>');	
	dbms_output.put_line(' </TR>');
	dbms_output.put_line('<TR><TD>Instance Name = '||:sid||'<br>');
	dbms_output.put_line('Instance Creation Date = '||v_crtddt||'<br>');
	dbms_output.put_line('Server/Platform = '||platform||'<br>');
	dbms_output.put_line('Language/Characterset = '||db_lang||'<br>');
	dbms_output.put_line('Database = '||db_ver||'<br>');
	dbms_output.put_line('Applications = '||:apps_rel||'<br>');
	dbms_output.put_line('Workflow = '||v_wfVer||'<br>');
	dbms_output.put_line('PER '||:hr_status||' - PAY '||:pay_status||'<br><br>');
	if  :apps_rel like '11.5%' and v_exists=0 then   
           dbms_output.put_line('no RUP');		
    else
			dbms_output.put_line(:rup_level_n|| ' applied on ' || :v_rup_date ||'<br>');
	end if;
	dbms_output.put_line('<br>Installed legislations<br>');
	dbms_output.put_line('Code   Application');
	dbms_output.put_line('<br>-------------------<br>');
	
	  
	open legislations;
    loop
          fetch legislations into v_code,v_appl;
          EXIT WHEN  legislations%NOTFOUND;
          dbms_output.put_line(v_code||'   '||v_appl||'<br>');         
    end loop;
    close legislations;	
	
	dbms_output.put_line(' </TABLE> </div> ');
	
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	
	dbms_output.put_line('<div id="fordx" style="display:none">');
		dbms_output.put_line('Instance Name = '||:sid||chr(10)||'Instance Creation Date = '||v_crtddt);
		dbms_output.put_line('Server/Platform = '||platform||chr(10)||'Language/Characterset = '||db_lang||' / '||db_charset);
		dbms_output.put_line('Database = '||db_ver||chr(10)||'Applications = '||:apps_rel||chr(10)||'Workflow = '||v_wfVer);
		dbms_output.put_line('PER '||:hr_status||chr(10)||'PAY '||:pay_status||chr(10)||chr(10)||:rup_level_n|| ' applied on ' || :v_rup_date ||chr(10)||chr(10)||'Installed legislations');
		open legislations;
		loop
			  fetch legislations into v_code,v_appl;
			  EXIT WHEN  legislations%NOTFOUND;
			  dbms_output.put_line(v_code||'   '||v_appl);         
		end loop;
		close legislations;
		dbms_output.put_line(chr(10)||lpad('Bus Grp ID',10)||lpad('Org ID',10)||lpad('Organization Name',50)||lpad('Legis',6)||lpad('Curr',6)||lpad('Enabl',7)||' '||lpad('Date From',11) ||' '||lpad('Date To',11));
	for org_rec in bg loop
		dbms_output.put_line(lpad(org_rec.bgi,10)||lpad(org_rec.oi,10)||lpad(org_rec.name,50)||lpad(org_rec.lc,6)||lpad(org_rec.cc,6)||lpad(org_rec.ef,7)||' '||lpad(org_rec.df,11)||' '||lpad(org_rec.dt,11));
	end loop;	
	
	dbms_output.put_line('</div>');
	
	dbms_output.put_line('<a name="db"></a>');
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql1b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql1'');" href="javascript:;">&#9654; Database Details</A></DIV>');	
	
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql1" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Database details</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql2b" style="width:220px" onclick="displayItem2(this,''s1sql2'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql2" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="5" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          SELECT upper(instance_name), host_name<br>');
	dbms_output.put_line('          	FROM   fnd_product_groups, v$instance;<br>');
	dbms_output.put_line('        SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, ''TNS for ''), '':'' )||pcv2.status, 1, 80)<br>');
	dbms_output.put_line('            	FROM product_component_version pcv1,<br>');
	dbms_output.put_line('                   product_component_version pcv2<br>');
	dbms_output.put_line('             	WHERE UPPER(pcv1.product) LIKE ''%TNS%''<br>');
	dbms_output.put_line('               	AND UPPER(pcv2.product) LIKE ''%ORACLE%''<br>');
	dbms_output.put_line('               	AND ROWNUM = 1;<br>');
	dbms_output.put_line('        SELECT banner from V$VERSION WHERE ROWNUM = 1;<br>');
	dbms_output.put_line('        SELECT value FROM V$NLS_PARAMETERS WHERE parameter in (''NLS_LANGUAGE'',''NLS_CHARACTERSET'');');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Hostname</B></TD>');
	dbms_output.put_line(' <TH><B>Platform</B></TD>');
	dbms_output.put_line(' <TH><B>Sid</B></TD>');
	dbms_output.put_line(' <TH><B>Database version</B></TD>');
	dbms_output.put_line(' <TH><B>Language</B></TD>');
	dbms_output.put_line(' <TH><B>Character set</B></TD>');
	dbms_output.put_line('<TR><TD>'||:host||'</TD>'||chr(10)||'<TD>'||platform||'</TD>'||chr(10));
	dbms_output.put_line('<TD>'||:sid||'</TD>'||chr(10)||'<TD>'||db_ver||'</TD>'||chr(10)||'<TD>'||db_lang||'</TD>'||chr(10)||'<TD>'||db_charset ||'</TD></TR>'||chr(10));	 	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE> </div> ');
	
	if :apps_rel like '11.5%' and (db_ver like '9.2%' or db_ver like '10.1%' or db_ver like '10.2.0.2%' or db_ver like '10.2.0.3%' or db_ver like '11.1.0.6%') then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Minimum Requirements: Database 10.2.0.4 or 11.1.0.7!<br>');
		dbms_output.put_line('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=883202.1" target="_blank">Note 883202.1</a> ');
		dbms_output.put_line('Patch Requirements for Sustaining Support for Oracle E-Business Suite Release 11.5.10<br>');
		dbms_output.put_line('</div><br><br>');
		:w1:=:w1+1;
	elsif :apps_rel like '12.0%' and (db_ver like '9.2%' or db_ver like '10.1%' or db_ver like '10.2.0.2%' or db_ver like '10.2.0.3%' or db_ver like '10.2.0.4%' or db_ver like '11.1.0.6%' or db_ver like '11.2.0.1%') then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Minimum Requirements: Oracle Database 10.2.0.5, 11.1.0.7, or 11.2.0.2!<br>');
		dbms_output.put_line('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1334562.1" target="_blank">Note 1334562.1</a> ');
		dbms_output.put_line('Minimum Patch Requirements for Extended Support of Oracle E-Business Suite Human Capital Management (HCM) Release 12.0<br>');
		dbms_output.put_line('</div><br><br>');
		:w1:=:w1+1;
	end if;
	
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

  
	 :n := dbms_utility.get_time;
	 
	 SELECT MULTI_ORG_FLAG,MULTI_CURRENCY_FLAG into multiOrg, multiCurr FROM FND_PRODUCT_GROUPS;	    

	
	dbms_output.put_line('<DIV class=divItem><a name="apps"></a>');
	dbms_output.put_line('<DIV id="s1sql3b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql3'');" href="javascript:;">&#9654; Application Details</A></DIV>');
	

		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql3" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Application Details</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql4b" style="width:220px" onclick="displayItem2(this,''s1sql4'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql4" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="5" height="60">');
	
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('          SELECT RELEASE_NAME from FND_PRODUCT_GROUPS;<br>');	
	dbms_output.put_line('          SELECT MULTI_ORG_FLAG,MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS;<br>');
	dbms_output.put_line('          SELECT V.APPLICATION_ID, L.MEANING  <br>');
	dbms_output.put_line('              FROM FND_APPLICATION_ALL_VIEW V, FND_PRODUCT_INSTALLATIONS I, FND_LOOKUPS L<br>');
	dbms_output.put_line('              WHERE (V.APPLICATION_ID = I.APPLICATION_ID)<br>');
  	dbms_output.put_line('                AND (V.APPLICATION_ID in (''800'',''801''))<br>'); 
	dbms_output.put_line('                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')<br>');
	dbms_output.put_line('               AND (L.LOOKUP_CODE = I.Status);<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Release</B></TD>');
	dbms_output.put_line(' <TH><B>HRMS RUP</B></TD>');
	dbms_output.put_line(' <TH><B>MultiOrg Flag</B></TD>');
	dbms_output.put_line(' <TH><B>MultiCurrency Flag</B></TD>');
	dbms_output.put_line(' <TH><B>HR Status</B></TD>');
	dbms_output.put_line(' <TH><B>PAY Status</B></TD>');

	dbms_output.put_line('<TR><TD>'||:apps_rel||'</TD>'||chr(10));
	
            
    if  :apps_rel like '11.5%'  and v_exists=0 then
					dbms_output.put_line('<TD>no RUP</TD>'||chr(10));			
    else
			dbms_output.put_line('<TD>'||:rup_level_n|| ' applied on ' || :v_rup_date ||'</TD>'||chr(10));
	end if;
	
	
	
	dbms_output.put_line('<TD>'||multiOrg||'</TD>'||chr(10));
	
	dbms_output.put_line('<TD>'||multiCurr||'</TD>'||chr(10)||'<TD>'||:hr_status||'</TD>'||chr(10)||'<TD>'||:pay_status||'</TD></TR>'||chr(10));	 	

	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE> </div> ');
	if :apps_rel like '11.5%' then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please note that statutory legislative support expired on November 30th 2013');
		dbms_output.put_line('<span class="sectionb">, please refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1384995.1" target="_blank">Note 1384995.1</a> ');
		dbms_output.put_line(' When Is Statutory Legislative Support for Payroll Going To End For Release 11i<br></div>');	
		:w1:=:w1+1;
	end if;
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;
/

-- Display HCM Products status
declare
	v_appl fnd_application_all_view.application_name%type; 
	v_appls fnd_application_all_view.application_short_name%type; 
	v_applid varchar2(20);
	v_status fnd_lookups.meaning%type;
	v_patch fnd_product_installations.patch_level%type;
	cursor products is
	select t.application_name , b.application_short_name
		, to_char(t.application_id)
		, l.meaning
		, decode(i.patch_level, null, '11i.' || b.application_short_name || '.?', i.patch_level)
		from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
		where (t.application_id = i.application_id)
		AND b.application_id = t.application_id
		 and (b.application_id in ('0', '50', '101','178', '203', '231', '275', '426', '453', '800', '801', '802', '803', '804', '805', '808', '809', '810', '821', '8301', '8302', '8303','8401','8403'))
		and (l.lookup_type = 'FND_PRODUCT_STATUS')
		and (l.lookup_code = i.status )
		AND t.language = 'US' AND l.language = 'US' order by upper(t.application_name);	

begin

	dbms_output.put_line(' <a name="products"></a>');
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql5b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql5'');" href="javascript:;">&#9654; Products Status</A></DIV>');

	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql5" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('     <B>Applications Status</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail id="s1sql6b" style="width:220px" onclick="displayItem2(this,''s1sql6'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD>');
	dbms_output.put_line(' </TR>');
	dbms_output.put_line(' <TR id="s1sql6" style="display:none">');
	dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('        select v.application_name , v.application_short_name  <br>');     
	dbms_output.put_line('        , to_char(v.application_id) <br>');
	dbms_output.put_line('        , l.meaning    <br>');             
	dbms_output.put_line('        , decode(i.patch_level, null, ''11i.'' || v.application_short_name || ''.?'', i.patch_level) <br>');
	dbms_output.put_line('        from fnd_application_all_view v, fnd_product_installations i, fnd_lookups l<br>');
	dbms_output.put_line('        where (v.application_id = i.application_id)<br>');
	dbms_output.put_line('        and (v.application_id in <br>');
	dbms_output.put_line('         (''0'', ''50'', ''178'', ''275'', ''426'', ''453'', ''800'', ''801'', ''802'', ''803'', ''804'', ''805'', ''808'', ''809'', ''810'', ''8301'', ''8302'', ''8303''))<br>');
	dbms_output.put_line('        and (l.lookup_type = ''FND_PRODUCT_STATUS'')<br>');
	dbms_output.put_line('        and (l.lookup_code = i.status )');
	dbms_output.put_line('        order by upper(v.application_name);');
    dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Application</B></TD>');
	dbms_output.put_line(' <TH><B>Short Name</B></TD>');
	dbms_output.put_line(' <TH><B>Code</B></TD>');
	dbms_output.put_line(' <TH><B>Status</B></TD>');
	dbms_output.put_line(' <TH><B>Patchset</B></TD>');
		
	:n := dbms_utility.get_time;
	open products;
    loop
          fetch products into v_appl,v_appls,v_applid,v_status,v_patch;
          EXIT WHEN  products%NOTFOUND;
          dbms_output.put_line('<TR><TD>'||v_appl||'</TD>'||chr(10)||'<TD>'||v_appls||'</TD>'||chr(10));
		  if v_appls='HXC' and :apps_rel like '12.%'  then
				dbms_output.put_line('<TD>'||v_applid||'</TD>'||chr(10)||'<TD>'||v_status||'</TD>'||chr(10)||'<TD>-</TD> </TR>'||chr(10));
		  else
				dbms_output.put_line('<TD>'||v_applid||'</TD>'||chr(10)||'<TD>'||v_status||'</TD>'||chr(10)||'<TD>'||v_patch||'</TD> </TR>'||chr(10));
		  end if;	  
    end loop;
    close products;
	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE> </div> ');
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;
/

-- Display legislations and status
declare
	v_code varchar2(20); 
	v_appl varchar2(50);
	v_appls varchar2(50);
	v_date varchar2(30);
	v_action varchar2(20);
	cursor legislations is
	select  decode(legislation_code,null,'global',legislation_code), 
	decode(application_short_name , 'PER', 'Human Resources' , 'PAY', 'Payroll' , 'GHR', 'Federal Human Resources' , 'CM',  'College Data' , application_short_name),
    application_short_name,
	decode(action,'F','Force Install','C','Clear','U','Upgrade','I','Install'),
	to_char(last_update_date, 'DD-MON-YYYY')
	from hr_legislation_installations
      where status = 'I' 
      order by legislation_code;
begin
dbms_output.put_line(' <a name="legislations"></a>');
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql7b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql7'');" href="javascript:;">&#9654; Legislations Installed</A></DIV>');	
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql7" style="display:none" >');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
	dbms_output.put_line('     <B>Legislations Installed</B></font></TD>');
	dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
	dbms_output.put_line('<A class=detail  id="s1sql8b"  onclick="displayItem2(this,''s1sql8'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD></TR><TR id="s1sql8" style="display:none">');
	dbms_output.put_line('    <TD colspan="4" height="60">');
	dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('         select decode(legislation_code,null,''global'',legislation_code) <br>');
	dbms_output.put_line('          , decode(application_short_name<br>, ''PER'', ''Human Resources''<br>, ''PAY'', ''Payroll''<br>, ''GHR'', ''Federal Human Resources''<br>');
	dbms_output.put_line('          , ''CM'',  ''College Data''<br>, application_short_name) <br>, application_short_name <br>');
	dbms_output.put_line('          ,decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'')<br> , last_update_date  <br>');
	dbms_output.put_line('          from hr_legislation_installations <br> where status = ''I''<br> order by legislation_code;');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD></TR><TR>');
	dbms_output.put_line(' <TH><B>Legislation Code</B></TD><TH><B>Application Name</B></TD><TH><B>Application Code</B></TD><TH><B>Action</B></TD><TH><B>Applied Date</B></TD>');
	
	:n := dbms_utility.get_time;
	open legislations;
    loop
          fetch legislations into v_code,v_appl,v_appls,v_action,v_date;
          EXIT WHEN  legislations%NOTFOUND;
          dbms_output.put_line('<TR><TD>'||v_code||'</TD>'||chr(10)||'<TD>'||v_appl||'</TD>'||chr(10));
		  dbms_output.put_line('<TD>'||v_appls||'</TD>'||chr(10));
		  dbms_output.put_line('<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD> </TR>'||chr(10));          
    end loop;
    close legislations;
	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql7'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE>');
	dbms_output.put_line('</div>');
    	
    dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;
/

-- Display installed languages (NLS)
declare
    lang number;
    v_lang_code FND_LANGUAGES.LANGUAGE_CODE%type;
    v_flag varchar2(25);
    v_language FND_LANGUAGES.NLS_LANGUAGE%type;
    cursor languages is
    SELECT LANGUAGE_CODE ,  
             decode(INSTALLED_FLAG ,'B','Base language','I','Installed language'),
             NLS_LANGUAGE
      FROM FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I')
      order by LANGUAGE_CODE;
begin
    select count(1) into lang from FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I') ;
    dbms_output.put_line(' <a name="nls"></a>');
			                      dbms_output.put_line('<DIV class=divItem>');
									dbms_output.put_line('<DIV id="s1sql33b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql33'');" href="javascript:;">&#9654; Languages Installed</A></DIV>');								  
                                  dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql33" style="display:none" >');
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('     <B>Languages:</B></font></TD>');
                                  dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                                  dbms_output.put_line('<A class=detail id="s1sql34b" style="width:220px" onclick="displayItem2(this,''s1sql34'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  dbms_output.put_line('   </TD>');
                                  dbms_output.put_line(' </TR>');
                                  dbms_output.put_line(' <TR id="s1sql34" style="display:none">');
                                  dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
                                  dbms_output.put_line('       <blockquote><p align="left">');
                                  dbms_output.put_line('          SELECT LANGUAGE_CODE , <br>');                                   
                                  dbms_output.put_line('                 decode(INSTALLED_FLAG ,''B'',''Base language'',''I'',''Installed language''),<br>');  
                                  dbms_output.put_line('                 NLS_LANGUAGE<br>'); 
                                  dbms_output.put_line('                FROM FND_LANGUAGES <br>'); 
                                  dbms_output.put_line('                where INSTALLED_FLAG in (''B'',''I'')<br>'); 
                                  dbms_output.put_line('                order by LANGUAGE_CODE;<br>'); 
                                  dbms_output.put_line('          </blockquote><br>');
                                  dbms_output.put_line('     </TD>');
                                  dbms_output.put_line('   </TR>');
                                  dbms_output.put_line(' <TR>');
                                  dbms_output.put_line(' <TH><B>Code</B></TD>');
                                  dbms_output.put_line(' <TH><B>Flag</B></TD>');
                                  dbms_output.put_line(' <TH><B>Language</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open languages;
                                  loop
                                        fetch languages into v_lang_code, v_flag, v_language;
                                        EXIT WHEN  languages%NOTFOUND;
                                        dbms_output.put_line('<TR><TD>'||v_lang_code||'</TD>'||chr(10)||'<TD>'||v_flag||'</TD>'||chr(10)||'<TD>'||v_language||'</TD></TR>'||chr(10));
                                  end loop;
                                  close languages;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  dbms_output.put_line(' </TABLE> </div> ');
                     if lang>1 then               
                                  dbms_output.put_line('<div class="divok">');    
								  dbms_output.put_line('<font color="blue">Advice: </font> Periodically check if you NLS level is in sync with US level:<br>');
                                  dbms_output.put_line('Follow <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=252422.1" target="_blank" >Note 252422.1</a> ');
								  dbms_output.put_line('Requesting Translation Synchronization Patches<br>');
                                  dbms_output.put_line('-> this will synchronize your languages with actual US level<br>');
                                  dbms_output.put_line('Note! This is just an advice. This does not mean your NLS is not synchronized! Follow this step ONLY if you have translation issues.<br>');								  
								  dbms_output.put_line('</div>');
					end if;
			dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

	dbms_output.put_line('</div>');
end;
/

-- Display database initialization parameters
declare
	v_db_parameter v$parameter.name%type; 	
	v_db_value v$parameter.value%type;
	database_version	varchar2(100);
	apps_version	varchar2(50);
	issue1 varchar2(100) := '';
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	cursor db_init is
	select name, nvl(value,'null') from v$parameter 
      where name in ('max_dump_file_size','timed_statistics'
	  ,'user_dump_dest','compatible'
	  ,'sql_trace'
	  ,'utl_file_dir','_optimizer_autostats_job')
      order by name;
	cursor db_init2 is
			select name, nvl(value,'null') from v$parameter order by name;

begin

   dbms_output.put_line('<br><br><a name="performance"></a><div class="divSection">');
  dbms_output.put_line('<div class="divSectionTitle">Performance Details</div><br>');	

	dbms_output.put_line(' <a name="db_init_ora"></a>');

	select banner into database_version from V$VERSION WHERE ROWNUM = 1;
	apps_version:=:apps_rel;
	
	open db_init;
	loop
          fetch db_init into v_db_parameter,v_db_value;
          EXIT WHEN  db_init%NOTFOUND;
		  CASE v_db_parameter
				when 'compatible' then 
					CASE
						when database_version like '%8.1%' then
							if v_db_value<>'8.1.7' then
								issue1:='Please set Compatible parameter to 8.1.7';
							end if;
						when database_version like '%9.2%' then
							if v_db_value<>'9.2.0' then
								issue1:='Please set Compatible parameter to 9.2.0';
							end if;
						when database_version like '%10.1%' then
							if v_db_value<>'10.1.0' then
								issue1:='Please set Compatible parameter to 10.1.0';
							end if;
						when database_version like '%10.2%' then
							if v_db_value<>'10.2.0' then
								issue1:='Please set Compatible parameter to 10.2.0';
							end if;
						when database_version like '%11.1%' then
							if v_db_value<>'11.1.0' then
								issue1:='Please set Compatible parameter to 11.1.0';
							end if;
						when database_version like '%11.2%' then
							if v_db_value<>'11.2.0' then
								issue1:='Please set Compatible parameter to 11.2.0';
							end if;
						when database_version like '%12.1%' then
							if v_db_value<>'12.1.0' then
								issue1:='Please set Compatible parameter to 12.1.0';
							end if;
						else
							null;
					end case;
				when 'max_dump_file_size' then
					if v_db_value <>'UNLIMITED' then
						issue2:=TRUE;
					end if;
				when '_optimizer_autostats_job' then
					begin
						if database_version like '%11.1%' or database_version like '%11.2%' then
							if v_db_value <>'FALSE' then
								issue3:=TRUE;
							end if;	
						end if;
					end;
				when 'timed_statistics' then
					begin
						if database_version like '%8.1%' or database_version like '%9.2%' or database_version like '%10.1%' or database_version like '%10.2%' then
							if v_db_value <> 'TRUE' then
								issue4:=TRUE;
							end if;	
						end if;
					end;			
				else
					null;
			END CASE;
			
          
    end loop;
    close db_init;	

		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql11b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql11'');" href="javascript:;">&#9654; Database Initialization Parameters</A></DIV>');
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql11" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Database parameters</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql12b" style="width:220px" onclick="displayItem2(this,''s1sql12'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql12" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select name, value from v$parameter <br>');		
		dbms_output.put_line('         order by name;<br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Parameter</B></TD>');
		dbms_output.put_line(' <TH><B>Value</B></TD>');
	
		:n := dbms_utility.get_time;
		open db_init2;
		loop
			fetch db_init2 into v_db_parameter,v_db_value;
			EXIT WHEN  db_init2%NOTFOUND;
			dbms_output.put_line('<TR><TD>'||v_db_parameter||'</TD>'||chr(10)||'<TD>');
			dbms_output.put_line(SUBSTR(v_db_value,1,250));
			dbms_output.put_line('</TD></TR>'||chr(10));
          
		end loop;
		close db_init2;

		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
		
		if issue1<>'' or issue3 or issue4 then
			dbms_output.put_line('<div class="divwarn">');		
			if issue1<>'' then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>'||issue1||'<br>');
				:w1:=:w1+1;
			end if;
							
			if issue3 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please set _optimizer_autostats_job to FALSE<br>');
				:w1:=:w1+1;
			end if;
			
			if issue4 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please set timed_statistics to TRUE<br>');
				:w1:=:w1+1;
			end if;		
			dbms_output.put_line('</div>');
		end if;
		
		dbms_output.put_line('<div class="divok">');
		if issue2 then			
			dbms_output.put_line('<font color="blue">Advice: </font> If you need to run a trace please set Max_dump_file_size = UNLIMITED<br>');
		end if;
		dbms_output.put_line('<font color="blue">Advice: </font> If you have performance issue please ensure you have correct database initialization parameters as per ');
		if apps_version like '12.%' then
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=396009.1" target="_blank">Note 396009.1</a> Database Initialization Parameters for Oracle E-Business Suite Release 12<br>');
		else 
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=216205.1" target="_blank">Note 216205.1</a> Database Initialization Parameters for Oracle Applications Release 11i<br>');
		end if;
		dbms_output.put_line('Use <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=174605.1" target="_blank">Note 174605.1</a> bde_chk_cbo.sql - EBS initialization parameters - Healthcheck<br>');
		dbms_output.put_line('This will help you to identify the difference between actual values and required values. Verify that all Mandatory Parameters - MP are set correctly<br><br>');
		dbms_output.put_line('Review also <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
				
		
		if issue1='' and (not issue2) and (not issue3) and (not issue4) then
				dbms_output.put_line('Verified parameters are correctly set');
		end if;	
		dbms_output.put_line('</div>');
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');


end;
/


-- Display status, last run of gather schema statistics concurrent request
declare
  status_all varchar2(100);
  status_hr varchar2(100); 
  last_date_all date;
  last_date_hr date; 
  last_date_normal date;
  status2 varchar2(100);
  last_date2 date;
  need_run boolean:=FALSE;
  days number;
  no_rows number;
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  issue6 boolean:=FALSE;
  v_PROG_SCHEDULE_TYPE varchar2(100);
  v_PROG_SCHEDULE varchar2(400);
  v_USER_NAME fnd_user.user_name%type;
  v_START_DATE fnd_concurrent_requests.requested_start_date%type;
  v_ARGUMENT_TEXT FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_all FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_hr FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
begin
      select count(1) into no_rows
      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL');
        
      if no_rows=0 then
          issue1:=TRUE;
      else
          SELECT * 
          into status_all,last_date_all,v_ARGUMENT_TEXT_all
          FROM (
          SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
           ,ACTUAL_COMPLETION_DATE pEndDate,ARGUMENT_TEXT        
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
            AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
          ORDER BY 2 desc)
          where rownum < 2;
      
          if instr(upper(status_all),upper('Completed Normal'))=0 then 
              issue2:=TRUE;			  
          else
              select  sysdate-last_date_all into days from dual;
              if days>7 then
                    issue3:=TRUE;
              end if;
          end if;
        end if;
        
        
      select count(1) into no_rows
      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,');
        
      if no_rows=0 then
          issue4:=TRUE;
      else
          SELECT * 
          into status_hr,last_date_hr,v_ARGUMENT_TEXT_hr
          FROM (
          SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
           ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
            AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
          ORDER BY 2 desc)
          where rownum < 2;
      
          if instr(upper(status_hr),upper('Completed Normal'))=0 then 
              issue5:=TRUE;
          else
              select  sysdate-last_date_hr into days from dual;
              if days>7 then
                    issue6:=TRUE;
              end if;
          end if;
        end if;
                        
  
		dbms_output.put_line(' <a name="gather"></a>');
                    
                     dbms_output.put_line('<DIV class=divItem>');
					dbms_output.put_line('<DIV id="s1sql13b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql13'');" href="javascript:;">&#9654; Gather Statistics</A></DIV>');                    
                    dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="4" id="s1sql13" style="display:none" >');
                    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                    dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                    dbms_output.put_line('     <B>Statistics</B></TD>');
                    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                    dbms_output.put_line('<A class=detail id="s1sql14b" style="width:220px" onclick="displayItem2(this,''s1sql14'');" href="javascript:;">&#9654; Show SQL Script</A>');
                    dbms_output.put_line('   </TD>');
                    dbms_output.put_line(' </TR>');
                    dbms_output.put_line(' <TR id="s1sql14" style="display:none">');
                    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                    dbms_output.put_line('       <blockquote><p align="left">');
                    dbms_output.put_line('          SELECT PHAS.MEANING || '' '' || STAT.MEANING pStatus <br>');                        
                    dbms_output.put_line('                     ,ACTUAL_COMPLETION_DATE pEndDate      <br>');  
                    dbms_output.put_line('                      FROM FND_CONC_REQ_SUMMARY_V fcrs<br>');
                    dbms_output.put_line('                     , FND_LOOKUP_VALUES STAT<br>');
                    dbms_output.put_line('                     , FND_LOOKUP_VALUES PHAS<br>');
                    dbms_output.put_line('                      WHERE STAT.LOOKUP_CODE = FCRS.STATUS_CODE<br>');
                    dbms_output.put_line('                     AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE''<br>');
                    dbms_output.put_line('                     AND PHAS.LOOKUP_CODE = FCRS.PHASE_CODE<br>');
                    dbms_output.put_line('                      AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE''<br>');
                    dbms_output.put_line('                      AND (UPPER(program) LIKE ''GATHER SCHEMA%''<br>');
                    dbms_output.put_line('                      AND substr(UPPER(ARGUMENT_TEXT),1,3) in (''HR,'',''ALL''<br>');
                    dbms_output.put_line('                      ))<br>');
                    dbms_output.put_line('                      ORDER BY 2 desc<br>');

                    dbms_output.put_line('          </blockquote><br>');
                    dbms_output.put_line('     </TD>');
                    dbms_output.put_line('   </TR>');
                    dbms_output.put_line(' <TR>');
                    dbms_output.put_line(' <TH><B>Request</B></TD>');
                    dbms_output.put_line(' <TH><B>Status</B></TD>');
                    dbms_output.put_line(' <TH><B>Last run</B></TD>');
					dbms_output.put_line(' <TH><B>Last Time Completed Normal</B></TD>');
					dbms_output.put_line(' <TH><B>Scheduling</B></TD>');
                  
                    :n := dbms_utility.get_time;
                    
                   dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for ALL'||'</TD>'||chr(10));
                    if issue1 then
                          dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
                          :p1:='never';
                    elsif issue2 then
							if instr(upper(status_all),'ERROR')=0 then 
                                      issue2:=FALSE;
							end if;		  
							select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
							if no_rows>0 then
								SELECT * 
								  into last_date_normal,v_ARGUMENT_TEXT
								  FROM (
								  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
								  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
								  ORDER BY 1 desc)
								  where rownum < 2;
								  dbms_output.put_line('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT);
								  dbms_output.put_line('</TD>'||chr(10));
								  :p1:=last_date_normal;
								  select  sysdate-last_date_normal into days from dual;
								  if days>7 then
										issue3:=TRUE;
										last_date_all:=last_date_normal;
								  else
										issue3:=FALSE;
								  end if;
							else
								dbms_output.put_line('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
								dbms_output.put_line('<TD>never</TD>'||chr(10));
								issue2:=TRUE;
								:p1:='never';
							end if;
					else
                          dbms_output.put_line('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
						  dbms_output.put_line('<TD>'||last_date_all||' with parameters:');
						  dbms_output.put_line(v_ARGUMENT_TEXT_all);
						  dbms_output.put_line('</TD>'||chr(10));
						  :p1:=last_date_all;
                    end if;
					select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL');
					if no_rows=0 then
								dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
					else						  
								select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
								SELECT 
									 NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
									 DECODE(NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
									 'PERIODICALLY',
									 'EVERY ' || fcr.resubmit_interval || ' ' ||
									 fcr.resubmit_interval_unit_code || ' FROM ' ||
									 fcr.resubmit_interval_type_code || ' OF PREV RUN',
									 'ONCE',
									 'AT :' ||
									 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
									 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
									 fu.user_name USER_NAME,
									 requested_start_date START_DATE									
									 FROM fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									ORDER BY 2 desc)
									where rownum < 2;
								  
								  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
								  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
					end if;
                    
                    dbms_output.put_line('<TR><TD>'||'Gather Schema Statistics for HR'||'</TD>'||chr(10));
                    if issue4 then
                          dbms_output.put_line('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
                          :p2:='never';
                    elsif issue5 then
							if instr(upper(status_hr),'ERROR')=0 then 
                                      issue5:=FALSE;
							end if;
							select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
							if no_rows>0 then
								SELECT * 
								  into last_date_normal,v_ARGUMENT_TEXT
								  FROM (
								  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
								  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
								  ORDER BY 1 desc)
								  where rownum < 2;
								  dbms_output.put_line('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||last_date_normal||' with parameters:');
								  dbms_output.put_line(v_ARGUMENT_TEXT);
								  dbms_output.put_line('</TD>'||chr(10));
								  :p2:=last_date_normal;
								  select  sysdate-last_date_normal into days from dual;
								  if days>7 then
										issue6:=TRUE;
										last_date_hr:=last_date_normal;
								  else
										issue6:=FALSE;
								  end if;
							else
								dbms_output.put_line('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
								dbms_output.put_line('<TD>never</TD>'||chr(10));
								:p2:='never';
							end if;
					else
                          dbms_output.put_line('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
						  dbms_output.put_line('<TD>'||last_date_hr||' with parameters:');
						  dbms_output.put_line(v_ARGUMENT_TEXT_hr);
						  dbms_output.put_line('</TD>'||chr(10));
						  :p2:=last_date_hr;
                    end if;
					select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,');
					
					if no_rows=0 then
								dbms_output.put_line('<TD>no scheduling</TD></TR>'||chr(10));
					else						  
								select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
								SELECT 
									 NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
									 DECODE(NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
									 'PERIODICALLY',
									 'EVERY ' || fcr.resubmit_interval || ' ' ||
									 fcr.resubmit_interval_unit_code || ' FROM ' ||
									 fcr.resubmit_interval_type_code || ' OF PREV RUN',
									 'ONCE',
									 'AT :' ||
									 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
									 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
									 fu.user_name USER_NAME,
									 requested_start_date START_DATE
									 FROM fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									ORDER BY 2 desc)
									where rownum < 2;
								  
								  dbms_output.put_line('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
								  dbms_output.put_line(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
					end if;
                                 
                    
                    :n := (dbms_utility.get_time - :n)/100;
                    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                    dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                    dbms_output.put_line(' </TABLE> </div> ');



              dbms_output.put_line('<div class="divwarn">');
              if issue1 and issue4 then
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You never performed Gather Schema Statistics for HR!<br> ');
					:w1:=:w1+1;
					     
              end if;
              
                    
              if issue2 then
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL is not Completed Normal. ');
					:w1:=:w1+1;
					      
              end if;
              
              if issue5 then
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for HR is not Completed Normal. ');
					:w1:=:w1+1;
					     
              end if;
              
			  if issue1 and issue6 then
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your never performed gather schema statistics for ALL, and for HR was on '||last_date_hr||'.');
                    dbms_output.put_line('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w1:=:w1+1;
					
			  end if;
			  
              if issue3 and (issue6 or issue5 or issue4) then
                    dbms_output.put_line('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all);
                    dbms_output.put_line('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w1:=:w1+1;                         
              elsif issue3 and issue6 then
                    dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for HR was on '||last_date_hr||'.');
                    dbms_output.put_line('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w1:=:w1+1;					                         
              end if;
  		
            if (issue1 and issue4) or issue2 or issue5 or (issue1 and issue6) or (issue3 and (issue6 or issue5 or issue4)) then
				 dbms_output.put_line('In order to schedule use <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=419728.1" target="_blank" >Note 419728.1</a> ');
				 dbms_output.put_line('Concurrent Processing - How To Gather Statistics On Oracle Applications Release 11i and/or Release 12 - Concurrent Process,Temp Tables, Manually <br>');
				 dbms_output.put_line('Note! You can ignore the warning if you are manually gathering statistics using FND_STATS.GATHER_SCHEMA_STATS.<br>');
				 
			 end if;
                        
              dbms_output.put_line('</div>');
			  
			  if not issue1 and not issue2 and not issue3 then
					dbms_output.put_line('<div class="divok">');
					dbms_output.put_line('<img class="check_ico">OK! Gather Scema statistics was performed in last week without errors.<br><br>');
					dbms_output.put_line('</div>');
			  else
					 if issue2 or issue3 or issue4 or issue5 or issue6 then
                         dbms_output.put_line('<div class="divwarn">');
						 dbms_output.put_line('Please review also <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=226987.1" target="_blank" >Note 226987.1</a> ');
						 dbms_output.put_line('Oracle 11i and R12 Human Resources (HRMS) and Benefits (BEN) Tuning and System Health Checks <br>');                         
						 dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=246332.1" target="_blank" >Note 246332.1</a> FLOAUG Presentation: Working with Support on Payroll Performance Issues');
						 dbms_output.put_line('</div>');
					 else
							dbms_output.put_line('<div class="divok">');
							dbms_output.put_line('<img class="check_ico">OK! Gather Scema statistics was performed in last week without errors.<br><br>');
							dbms_output.put_line('</div>');
					 end if;
			  end if;
			  
			   
              dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

    
end;
/


-- Display hot PAY tables and indexes
declare
  v_table_name dba_tables.table_name%type; 
  v_last_analyzed dba_tables.last_analyzed%type;
  v_pct_free dba_tables.pct_free%type;
  v_ini_trans dba_tables.ini_trans%type;
  v_max_trans dba_tables.max_trans%type;
  v_degree dba_tables.degree%type;
  v_sample varchar2(30);
  v_num_rows dba_tables.num_rows%type;
  v_index_name dba_indexes.index_name%type;
  v_i_ini_trans dba_indexes.ini_trans%type;
  v_thread pay_action_parameters.parameter_value%type;
  v_rows number;
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue1_el boolean := FALSE;
	issue2_el boolean := FALSE;
	issue3_el boolean := FALSE;
	issue4_el boolean := FALSE;
	issue5_el boolean := FALSE;
	issue6_el boolean := FALSE;
	issue7_el boolean := FALSE;  
  
	cursor hot is
	SELECT table_name, last_analyzed, pct_free, ini_trans, max_trans, ltrim(rtrim(degree))
           , round(((decode(sample_size,0,null,sample_size))/(decode(num_rows,0,null,num_rows)))*100,2) , num_rows
      FROM DBA_TABLES
      WHERE table_name IN ('FF_ARCHIVE_ITEMS'
                          ,'FF_ARCHIVE_ITEM_CONTEXTS'
                          ,'PAY_ACTION_INFORMATION'
                          ,'PAY_ASSIGNMENT_ACTIONS'
                          ,'PAY_ASSIGNMENT_LATEST_BALANCES'
                          ,'PAY_BALANCE_CONTEXT_VALUES'
                          ,'PAY_COSTS'
                          ,'PAY_DEFINED_BALANCES'
                          ,'PAY_ELEMENT_ENTRIES_F'
                          ,'PAY_ELEMENT_ENTRY_VALUES_F'
                          ,'PAY_INPUT_VALUES_F'
                          ,'PAY_PAYROLL_ACTIONS'
                          ,'PAY_PERIODS_OF_SERVICE'
                          ,'PAY_PERSON_LATEST_BALANCES'
                          ,'PAY_POPULATION_RANGES'
                          ,'PAY_PRE_PAYMENTS'
                          ,'PAY_RUN_BALANCES'
                          ,'PAY_RUN_RESULTS'
                          ,'PAY_RUN_RESULT_VALUES'
                          ,'PAY_US_RPT_TOTALS'
                          ,'PER_ALL_ASSIGNMENTS_F'
                          ,'PER_ALL_PEOPLE_F') order by table_name;
  cursor cindexes (t_name varchar2) is
  select index_name, last_analyzed, pct_free, ini_trans, max_trans, degree 
      	FROM dba_indexes
      	WHERE table_name = t_name
        order by index_name;

begin

dbms_output.put_line(' <a name="hot"></a>');

		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql17b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql17'');" href="javascript:;">&#9654; Hot PAY Tables</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql17" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=7 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Hot Tables</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql18b" style="width:220px" onclick="displayItem2(this,''s1sql18'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql18" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         SELECT table_name, last_analyzed, pct_free, ini_trans, max_trans, ltrim(rtrim(degree))<br>');
		dbms_output.put_line('                    , round(((decode(sample_size,0,null,sample_size))/(decode(num_rows,0,null,num_rows)))*100,2) , num_rows<br>');
		dbms_output.put_line('               FROM DBA_TABLES<br>');
		dbms_output.put_line('               WHERE table_name IN (''FF_ARCHIVE_ITEMS''<br>');
		dbms_output.put_line('                                   ,''FF_ARCHIVE_ITEM_CONTEXTS''<br>');
		dbms_output.put_line('                                   ,''PAY_ACTION_INFORMATION''<br>');
		dbms_output.put_line('                                   ,''PAY_ASSIGNMENT_ACTIONS''<br>');
		dbms_output.put_line('                                   ,''PAY_ASSIGNMENT_LATEST_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_BALANCE_CONTEXT_VALUES''<br>');
		dbms_output.put_line('                                   ,''PAY_COSTS''<br>');
		dbms_output.put_line('                                   ,''PAY_DEFINED_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_ELEMENT_ENTRIES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_ELEMENT_ENTRY_VALUES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_INPUT_VALUES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_PAYROLL_ACTIONS''<br>');
		dbms_output.put_line('                                   ,''PAY_PERIODS_OF_SERVICE''<br>');
		dbms_output.put_line('                                   ,''PAY_PERSON_LATEST_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_POPULATION_RANGES''<br>');
		dbms_output.put_line('                                   ,''PAY_PRE_PAYMENTS''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_RESULTS''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_RESULT_VALUES''<br>');
		dbms_output.put_line('                                   ,''PAY_US_RPT_TOTALS''<br>');
		dbms_output.put_line('                                   ,''PER_ALL_ASSIGNMENTS_F''<br>');
		dbms_output.put_line('                                   ,''PER_ALL_PEOPLE_F'');<br>');
    
		dbms_output.put_line('        SELECT table_name, index_name, last_analyzed, pct_free, ini_trans, max_trans, degree<br>');
		dbms_output.put_line('                FROM dba_indexes<br>');
		dbms_output.put_line('                WHERE table_name IN (''FF_ARCHIVE_ITEMS''<br>');
		dbms_output.put_line('                                   ,''FF_ARCHIVE_ITEM_CONTEXTS''<br>');
		dbms_output.put_line('                                   ,''PAY_ACTION_INFORMATION''<br>');
		dbms_output.put_line('                                   ,''PAY_ASSIGNMENT_ACTIONS''<br>');
		dbms_output.put_line('                                   ,''PAY_ASSIGNMENT_LATEST_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_BALANCE_CONTEXT_VALUES''<br>');
		dbms_output.put_line('                                   ,''PAY_COSTS''<br>');
		dbms_output.put_line('                                   ,''PAY_DEFINED_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_ELEMENT_ENTRIES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_ELEMENT_ENTRY_VALUES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_INPUT_VALUES_F''<br>');
		dbms_output.put_line('                                   ,''PAY_PAYROLL_ACTIONS''<br>');
		dbms_output.put_line('                                   ,''PAY_PERIODS_OF_SERVICE''<br>');
		dbms_output.put_line('                                   ,''PAY_PERSON_LATEST_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_POPULATION_RANGES''<br>');
		dbms_output.put_line('                                   ,''PAY_PRE_PAYMENTS''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_BALANCES''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_RESULTS''<br>');
		dbms_output.put_line('                                   ,''PAY_RUN_RESULT_VALUES''<br>');
		dbms_output.put_line('                                   ,''PAY_US_RPT_TOTALS''<br>');
		dbms_output.put_line('                                   ,''PER_ALL_ASSIGNMENTS_F''<br>');
		dbms_output.put_line('                                   ,''PER_ALL_PEOPLE_F'');<br>');
		dbms_output.put_line('          </blockquote><br>');       

		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Table Name</B></TD>');
		dbms_output.put_line(' <TH><B>Last Analyzed</B></TD>');
		dbms_output.put_line(' <TH><B>Pct Free</B></TD>');
		dbms_output.put_line(' <TH><B>Ini trans</B></TD>');
		dbms_output.put_line(' <TH><B>Max trans</B></TD>');
		dbms_output.put_line(' <TH><B>Degree</B></TD>');
		dbms_output.put_line(' <TH><B>% Sample</B></TD>');
		dbms_output.put_line(' <TH><B>Number of Rows</B></TD>');
	
  
	:n := dbms_utility.get_time;
  
	select count(1) into v_rows from pay_action_parameters where parameter_name='THREADS';
	if v_rows=0 then
		v_thread:=1;
	else	
		select max(parameter_value) into v_thread
			  from pay_action_parameters where parameter_name='THREADS';
	end if;
      
	open hot;
	loop
	  fetch hot into v_table_name,v_last_analyzed,v_pct_free,v_ini_trans,v_max_trans,v_degree,v_sample,v_num_rows;
	  EXIT WHEN  hot%NOTFOUND;
      issue1_el:=FALSE;
      issue2_el:=FALSE;
      issue3_el:=FALSE;
      issue4_el:=FALSE;
      issue5_el:=FALSE;
      if v_last_analyzed-sysdate>7 then
           issue1:=TRUE;
           issue1_el:=TRUE;
      end if;
      if v_ini_trans<10 then
            issue2:=TRUE;
            issue2_el:=TRUE;
      end if;
      if v_ini_trans<v_thread then
            issue3:=TRUE;
            issue3_el:=TRUE;
      end if;
      if v_sample<10 then
            issue4:=TRUE;
            issue4_el:=TRUE;
      end if;
      if v_table_name='PAY_US_RPT_TOTALS'  then
            select count(1) into v_num_rows from PAY_US_RPT_TOTALS;
			if v_num_rows>1000 then
				issue5:=TRUE;
				issue5_el:=TRUE;
			end if;
      end if;
      if issue1_el or issue2_el or issue3_el or issue4_el or issue5_el then
          dbms_output.put_line('<TR><TD><font color="red">'||v_table_name||'</TD>'||chr(10));
      else
          dbms_output.put_line('<TR><TD>'||v_table_name||'</TD>'||chr(10));
      end if;
      if issue1_el then
          dbms_output.put_line('<TD><font color="red">Issue: '||v_last_analyzed||'</TD>'||chr(10));
      else
          dbms_output.put_line('<TD>'||v_last_analyzed||'</TD>'||chr(10));
      end if;
      dbms_output.put_line('<TD>'||v_pct_free||'</TD>'||chr(10));
      if issue2_el or issue3_el then
          dbms_output.put_line('<TD><font color="red">Issue: '||v_ini_trans||'</TD>'||chr(10));
      else
          dbms_output.put_line('<TD>'||v_ini_trans||'</TD>'||chr(10));
      end if;
      dbms_output.put_line('<TD>'||v_max_trans||'</TD>'||chr(10)||'<TD>'||v_degree||'</TD>'||chr(10));
      if issue4_el then
          dbms_output.put_line('<TD><font color="red">Issue: '||v_sample||'</TD>'||chr(10));
      else
          dbms_output.put_line('<TD>'||v_sample||'</TD>'||chr(10));
      end if;
      if issue5_el then
          dbms_output.put_line('<TD><font color="red">Issue: '||v_num_rows||'</TD>'||chr(10));
      else
          dbms_output.put_line('<TD>'||v_num_rows||'</TD>'||chr(10));
      end if;
      
	  dbms_output.put_line('</TD></TR>'||chr(10));
      
      dbms_output.put_line('<tr><td></td><TH COLSPAN=7>');
      
      dbms_output.put_line('<table><tr BGCOLOR=#DEE6E0><td>Index name</td><td>Last analyzed</td><td>Pct free</td><td>Ini trans</td><td>Max trans</td><td>Degree</td></tr>');
            
      open cindexes (v_table_name);
      loop
            fetch cindexes into v_index_name, v_last_analyzed,v_pct_free,v_i_ini_trans,v_max_trans,v_degree;
            EXIT WHEN  cindexes%NOTFOUND;
            issue6_el:=FALSE;
            issue7_el:=FALSE;
            
            if v_last_analyzed-sysdate>7 then                  
                  issue6:=TRUE;
                  issue6_el:=TRUE;
            end if;
            
            if v_i_ini_trans<v_ini_trans+1 then
                  issue7:=TRUE;
                  issue7_el:=TRUE;
            end if;
            
            if issue6_el or issue7_el then
                dbms_output.put_line('<tr><td><font color="red">'||v_index_name||'</td>');
            else
                dbms_output.put_line('<tr><td>'||v_index_name||'</td>');
            end if;
            if issue6_el then
                dbms_output.put_line('<td><font color="red">Issue: '||v_last_analyzed||'</TD>');
            else
                dbms_output.put_line('<td>'||v_last_analyzed||'</TD>');
            end if;
            dbms_output.put_line('<td>'||v_pct_free||'</td>');
            if issue7_el then
                dbms_output.put_line('<td><font color="red">Issue: '||v_i_ini_trans||'</TD>');
            else
                dbms_output.put_line('<td>'||v_i_ini_trans||'</TD>');
            end if;
            dbms_output.put_line('<td>'||v_max_trans||'</td><td>'||v_degree||'</td><tr>');
      end loop;
      close cindexes;   
	  
      dbms_output.put_line('</table> </td></tr>');
          
		end loop;
		close hot;

		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql17'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
		
		dbms_output.put_line('<div class="divwarn">');
		if issue1 then
			  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Last_Analyzed for tables is more than 1 week. This can be an issue or not depending on your pay period. ');
			  dbms_output.put_line('Last_analyzed should be within a time period associated with the customers pay periods ');
			  dbms_output.put_line(' ie.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc');
			  :w1:=:w1+1;
		end if;
		
		if issue2 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please set  Ini_trans value to 10 or higher for tables with red!<br>');
			:w1:=:w1+1;
		end if;
		
		if issue3 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> The setting of the pay_action_parameters Threads setting ('||v_thread||') must be less then or equal to the Ini_trans setting.  ');
			dbms_output.put_line('If the Ini_trans setting is lower then the Threads setting this could cause system contention.<br>');
			:w1:=:w1+1;
		end if;
    
		if issue4 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Sample size should be at least 10% - if performance issue associated with one of these tables (as identified in a trace) may consider analyzing a larger sample.  <br>');
			:w1:=:w1+1;
		end if;
		
		if issue5 then
			  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Pay_US_RPT_Totals table should not contain a large number of records.  ');
			  dbms_output.put_line('This table temporarily stores records until a US Payroll reports completes successfully, then removes records. ');
			  dbms_output.put_line('<br>Records are retained only if a report fails. ');
			  dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=256143.1" target="_blank">Note 256143.1</a> How to remove obsolete data on PAY_US_RPT_TOTALS table<br>');
			  :w1:=:w1+1;
		end if;
		
		if issue6 then
			  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Last_Analyzed for indexes is more than 1 week. This can be an issue or not depending on your pay period. ');
			  dbms_output.put_line('Last_analyzed should be within a time period associated with the customers pay periods ');
			  dbms_output.put_line(' ie.  If payroll is run weekly, these indexes should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc');
			  :w1:=:w1+1;
		end if;
		
		if issue7 then
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please set Ini_trans value for indexes to (Ini_trans of table)+1 <br>');
			:w1:=:w1+1;
		end if;
		
		dbms_output.put_line('<font color="blue">Advice: </font> Please review:<br> ');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=549367.1" target="_blank">Note 246332.1</a> FLOAUG Presentation: Working with Support on Payroll Performance Issues<br>');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=226987.1" target="_blank">Note 226987.1</a> Oracle 11i and R12 Human Resources and Benefits Tuning and System Health Checks<br>');
		dbms_output.put_line('</div>');
		
		if (not issue1) and (not issue2) and (not issue3) and (not issue4) and (not issue5) and (not issue6) then
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('Verified values are correctly set<br>');
				dbms_output.put_line('</div>');
		end if;			
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
dbms_output.put_line('</div>');

end;
/

-- Display invalid objects
declare
	v_name dba_objects.object_name%type; 
	v_type dba_objects.object_type%type;
	v_owner dba_objects.owner%type;
	no_invalids number;
	no_errors number;
	inv_error VARCHAR2(250);
	issue boolean := FALSE;

    cursor invalids_pay is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'PAY%' or object_name like 'FF%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/')
	  order by 2;
 	
	cursor invalid_errors (object varchar2, object_type varchar2, object_owner varchar2) is
	    select nvl(substr(text,1,240) ,'null')
      from   all_errors
		where  name = object
		and    type = object_type
		and    owner = object_owner;

begin

  dbms_output.put_line('<br><br><a name="database"></a><div class="divSection">');
  dbms_output.put_line('<div class="divSectionTitle">Database Objects</div><br>');

  select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'PAY%' or object_name like 'FF%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/');
  if no_invalids>0 then
                    issue:=TRUE;
  end if;

  dbms_output.put_line(' <a name="invalids"></a>');
		dbms_output.put_line(' <a name="invalids"></a>');
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql19b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql19'');" href="javascript:;">&#9654; Invalid Objects</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql19" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Fix next invalid objects:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql20b" style="width:220px" onclick="displayItem2(this,''s1sql20'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql20" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select owner, object_name, object_type <br>');
		dbms_output.put_line('               from dba_objects<br>');
		dbms_output.put_line('               where status != ''VALID'' and object_type != ''UNDEFINED'' <br>');
		dbms_output.put_line('                and (object_name like ''PAY%'' or object_name like ''FF%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		dbms_output.put_line('                order by 2;<br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Owner</B></TD>');
		dbms_output.put_line(' <TH><B>Object</B></TD>');
    	dbms_output.put_line(' <TH><B>Type</B></TD>');
		dbms_output.put_line(' <TH><B>Error</B></TD>');
	
		:n := dbms_utility.get_time;    
    
        open invalids_pay;
              loop
                    fetch invalids_pay into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_pay%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								dbms_output.put_line(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
        close invalids_pay;
                
	
		
		:n := (dbms_utility.get_time - :n)/100;
		if issue and no_invalids>10 then
			dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql19'');" href="javascript:;">Collapse section</a></td></tr>');
		end if;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
	
		
		if issue then
				dbms_output.put_line('<div class="divwarn">');
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You have '||no_invalids||' invalid object(s) related to Payroll');
				select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED';
				dbms_output.put_line('from a total of '||no_invalids||' invalid object(s) in database.<br>');
				:w1:=:w1+1;
				
				dbms_output.put_line('<font color="blue">Advice: </font> Please run adadmin -> Compile apps schema.<br>');
				dbms_output.put_line('If you still have invalids review steps from: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1325394.1" target="_blank">Note 1325394.1</a>');
				dbms_output.put_line(' Troubleshooting Guide - invalid objects in the E-Business Suite Environment 11i and 12');
				dbms_output.put_line('</div>');				
        else
				 dbms_output.put_line('<div class="divok">');
				 dbms_output.put_line('<img class="check_ico">OK! No invalid object for Payroll.<br>');
				 dbms_output.put_line('</div>');
        end if;
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

		
end;
/


-- Display disabled triggers
declare
	v_owner dba_triggers.owner%type; 
	v_table dba_triggers.table_name%type;
    v_trigger dba_triggers.trigger_name%type;
    no_triggers number;
	no_triggers2 number;
 	issue boolean := FALSE;
	issue_alr boolean := FALSE;
	issue_only_alr boolean := FALSE;
  cursor disabled_triggers_pay is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR')
      and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
      order by 1, 2, 3;   
begin

	  dbms_output.put_line(' <a name="triggers"></a>');
	  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
        
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql23b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql23'');" href="javascript:;">&#9654; Disabled Triggers</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql23" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Disabled triggers:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql24b" style="width:220px" onclick="displayItem2(this,''s1sql24'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql24" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select owner, table_name, trigger_name <br>');
		dbms_output.put_line('                from dba_triggers <br>');
		dbms_output.put_line('                where status = ''DISABLED'' <br>');
		dbms_output.put_line('                and table_owner in (''HR'',''HXT'',''HXC'',''HRI'',''BEN'') <br>');
		dbms_output.put_line('                and (table_name like ''PAY%'' or table_name like ''FF%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		dbms_output.put_line('                order by 1, 2, 3; <br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Owner</B></TD>');
		dbms_output.put_line(' <TH><B>Table name</B></TD>');
		dbms_output.put_line(' <TH><B>Trigger Name</B></TD>');
	
		:n := dbms_utility.get_time;
    
		open disabled_triggers_pay;
			  loop
				 fetch disabled_triggers_pay into v_owner,v_table,v_trigger;
				 EXIT WHEN  disabled_triggers_pay%NOTFOUND;
				 if v_trigger like 'ALR%' then
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					dbms_output.put_line('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					dbms_output.put_line('<TD><font color="orange">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			  end loop;
		close disabled_triggers_pay;
		
		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
		
		if issue and (not issue_alr) then
			dbms_output.put_line('<div class="divwarn">');
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You have disabled trigger(s).<br>');
			dbms_output.put_line('In order to re-enable use command: alter trigger trigger_name enable <br>');
			dbms_output.put_line('</div>');
			:w1:=:w1+1;
		elsif issue_only_alr then
			dbms_output.put_line('<div class="divok">');
			dbms_output.put_line(' You have disabled trigger(s) only related to alert. These are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.<br>');
			dbms_output.put_line('</div>');
   		elsif issue_alr and (not issue_only_alr) then
			dbms_output.put_line('<div class="divwarn">');
			dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You have disabled trigger(s).<br>');
			dbms_output.put_line('In order to re-enable use command: alter trigger trigger_name enable<br>');
			dbms_output.put_line('You have disabled trigger(s) related to alert (ALR_). These are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.<br>');
			dbms_output.put_line('Please focus on not ALR_ disabled triggers.<br>');
			dbms_output.put_line('</div>');
			:w1:=:w1+1;
		elsif  (not issue) then             
            dbms_output.put_line('<div class="divok">');
			dbms_output.put_line('<img class="check_ico">OK! No disabled trigger.<br>');
            dbms_output.put_line('</div>');
        end if;
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
end;
/


-- Display desyncronization in database
declare	
 	issue boolean := FALSE;
    v_problems number:=0;
begin
     select count(1) into v_problems
     from sys.obj$ do, sys.dependency$ d, sys.obj$ po
     where p_obj#=po.obj#(+)
     and d_obj#=do.obj#
     and do.status=1 /*dependent is valid*/
     and po.status=1 /*parent is valid*/
     and po.stime!=p_timestamp /*parent timestamp does not match*/
     and do.type# not in (28,29,30) /*dependent type is not java*/
     and po.type# not in (28,29,30) /*parent type is not java*/;
     
	dbms_output.put_line(' <a name="timestamp"></a>');
  
                  dbms_output.put_line('<DIV class=divItem><a name="sum"></a>');
				 dbms_output.put_line('<DIV id="s1sql25b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql25'');" href="javascript:;">&#9654; Dependency timestamp discrepancies</A></DIV>');                  
                 dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="0" id="s1sql25" style="display:none" >');
                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                  dbms_output.put_line('   <TH COLSPAN=0 bordercolor="#DEE6EF"><font face="Calibri">');
                  dbms_output.put_line('     <B>Dependency timestamp discrepancies between the database objects:</B></font></TD>');
                  dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                  dbms_output.put_line('<A class=detail id="s1sql26b" style="width:220px" onclick="displayItem2(this,''s1sql26'');" href="javascript:;">&#9654; Show SQL Script</A>');
                  dbms_output.put_line('   </TD>');
                  dbms_output.put_line(' </TR>');
                  dbms_output.put_line(' <TR id="s1sql26" style="display:none">');
                  dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="0" height="60">');
                  dbms_output.put_line('       <blockquote><p align="left">');
                  dbms_output.put_line('          select count(1)  <br>');
                  dbms_output.put_line('                from sys.obj$ do, sys.dependency$ d, sys.obj$ po <br>');
                  dbms_output.put_line('                     where p_obj#=po.obj#(+)<br>');
                  dbms_output.put_line('                     and d_obj#=do.obj#<br>');
                  dbms_output.put_line('                     and do.status=1 /*dependent is valid*/<br>');
                  dbms_output.put_line('                     and po.status=1 /*parent is valid*/<br>');
                  dbms_output.put_line('                     and po.stime!=p_timestamp /*parent timestamp does not match*/<br>');
                  dbms_output.put_line('                     and do.type# not in (28,29,30) /*dependent type is not java*/<br>');
                  dbms_output.put_line('                     and po.type# not in (28,29,30) /*parent type is not java*/;<br>');
                  dbms_output.put_line('          </blockquote><br>');
                  dbms_output.put_line('     </TD>');
                  dbms_output.put_line('   </TR>');
                  dbms_output.put_line(' <TR>');
                  dbms_output.put_line(' <TH><B>Number</B></TD>');
                
                  :n := dbms_utility.get_time;
                  
                  dbms_output.put_line('<TR><TD>'||v_problems||'</TD></TR>'||chr(10));
                   
                
                  
                  :n := (dbms_utility.get_time - :n)/100;
                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                  dbms_output.put_line(' <TH COLSPAN=0 bordercolor="#DEE6EF"><font face="Calibri">');
                  dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                  dbms_output.put_line(' </TABLE> </div> ');
                  
				  if v_problems>0 then
						dbms_output.put_line('<div class="diverr">');
                        dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font> You have dependency timestamp discrepancies between the database objects.<br>');
                        dbms_output.put_line('Please follow <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=370137.1" target="_blank">Note 370137.1</a>' );
                        dbms_output.put_line('After Upgrade, Some Packages Intermittently Fail with ORA-04065');                     
                        dbms_output.put_line('</div>');
						:e1:=:e1+1;
                  else
                        dbms_output.put_line('<div class="divok">');
						dbms_output.put_line('<img class="check_ico">OK! No dependency timestamp discrepancies between the database objects found.');
                        dbms_output.put_line('</div>');
                  end if;
				  dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
				  
				  dbms_output.put_line('</div>');
 
end;
/

-- Display packages version
declare
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
    
  cursor package_vers(prod varchar2) is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where name like  upper(prod)||'%' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and owner='APPS'  and type in('PACKAGE','PACKAGE BODY') 
  and line =2 
  order by Name;  
  
Begin
	
	dbms_output.put_line('<br><br><a name="versions"></a><div class="divSection">');
	dbms_output.put_line('<div class="divSectionTitle">Versions</div><br>');
	
	dbms_output.put_line('<a name="packages"></a>');
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql27b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql27'');" href="javascript:;">');
    dbms_output.put_line('&#9654; PAY Packages version</A></DIV>');
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql27" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Packages version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql28b" style="width:220px" onclick="displayItem2(this,''s1sql28'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql28" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select Name as Package, <br>');
		dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		dbms_output.put_line('          from dba_source <br>');
        dbms_output.put_line('          where (name like  ''PAY%'' or name like  ''PY%'') <br>');   
    dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
	dbms_output.put_line('          order by Name;<br>');
	dbms_output.put_line('          </blockquote><br>');
	dbms_output.put_line('     </TD>');
	dbms_output.put_line('   </TR>');
	dbms_output.put_line(' <TR>');
	dbms_output.put_line(' <TH><B>Name</B></TD>');
    dbms_output.put_line(' <TH><B>Type</B></TD>');
	dbms_output.put_line(' <TH><B>File</B></TD>');
    dbms_output.put_line(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
	open package_vers('PAY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
    close package_vers;
    open package_vers('PY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
    close package_vers;
    
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql27'');" href="javascript:;">Collapse section</a></td></tr>');
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE></div> ');    

	 dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>'); 
 

 
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql272b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql272'');" href="javascript:;">');
		dbms_output.put_line('&#9654; FF Packages version</A></DIV>');
			dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql272" style="display:none" >');
			dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
			dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
			dbms_output.put_line('     <B>Packages version:</B></font></TD>');
			dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
			dbms_output.put_line('<A class=detail id="s1sql282b" style="width:220px" onclick="displayItem2(this,''s1sql282'');" href="javascript:;">&#9654; Show SQL Script</A>');
			dbms_output.put_line('   </TD>');
			dbms_output.put_line(' </TR>');
			dbms_output.put_line(' <TR id="s1sql282" style="display:none">');
			dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
			dbms_output.put_line('       <blockquote><p align="left">');
			dbms_output.put_line('          select Name as Package, <br>');
			dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
			dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
			dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
			dbms_output.put_line('          from dba_source <br>');		
			dbms_output.put_line('          where name like ''FF%'' <br>');		
		dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
		dbms_output.put_line('          order by Name;<br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>Name</B></TD>');
		dbms_output.put_line(' <TH><B>Type</B></TD>');
		dbms_output.put_line(' <TH><B>File</B></TD>');
		dbms_output.put_line(' <TH><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;
		
	   
		open package_vers('FF');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
						dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						dbms_output.put_line('</TD></TR>'||chr(10));
					end loop;
		close package_vers;   
		  
		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql272'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE></div> ');
    

		dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
end;
/

declare
v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
    
  cursor package_vers(prod varchar2) is
  select Name, decode(type,'PACKAGE', 'PACKAGE SPEC',type),
  substr(text,instr(text,'$Header: ',1,1)+9 , instr(text,'.p',1,1) -  instr(text,'$Header: ',1,1)-5 )  , 
  substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4)
  from dba_source 
  where name like  upper(prod)||'%' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and owner='APPS'  and type in('PACKAGE','PACKAGE BODY') 
  and line =2 
  order by Name;
begin
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql273b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql273'');" href="javascript:;">');
		dbms_output.put_line('&#9654; HR Packages version</A></div>');
	
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql273" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Packages version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail  id="s1sql283b"  onclick="displayItem2(this,''s1sql283'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql283" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select Name as Package, <br>');
		dbms_output.put_line('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		dbms_output.put_line('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		dbms_output.put_line('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		dbms_output.put_line('          from dba_source <br>');
		dbms_output.put_line('          where (name like  ''HR%'' or name like ''PER%'') <br>');
		dbms_output.put_line('          and instr(text,''$Header'') <>0 and line =2 <br>');
		dbms_output.put_line('          order by Name;<br>');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Type</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>File</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;
		
	   
		open package_vers('PER');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						dbms_output.put_line(v_type||'</TD>'||chr(10)||'<TD>');
						dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						dbms_output.put_line('</TD></TR>'||chr(10));
					end loop;
		close package_vers;
		open package_vers('HR');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						dbms_output.put_line(v_type||'</TD>'||chr(10)||'<TD>');
						dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						dbms_output.put_line('</TD></TR>'||chr(10));
					end loop;
		close package_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql273'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE></div> ');
    

		dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

end;
/


-- Display java classes version
declare
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;
  
  


Begin
 

	dbms_output.put_line('<DIV class=divItem><a name="java"></a>');
	dbms_output.put_line('<DIV id="s1sql47b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql47'');" href="javascript:;">');	
	dbms_output.put_line('&#9654; PAY Java Classes Version</A></DIV>');	
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql47" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Java version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql48b" style="width:220px" onclick="displayItem2(this,''s1sql48'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql48" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select sub.subdir,sub.filename, sub.version <br>');  
		dbms_output.put_line('            from (<br>');
		dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
		dbms_output.put_line('            from (<br>');
		dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
		dbms_output.put_line('               file_version.version version,<br>');
		dbms_output.put_line('               rank()over(partition by files.filename<br>');
		dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
		dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
		dbms_output.put_line('               from ad_file_versions file_version,<br>');
		dbms_output.put_line('                 (<br>');
		dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
		dbms_output.put_line('                 from ad_files<br>');
		dbms_output.put_line('                 where app_short_name=''PAY'' and upper(filename) like upper(''%.class'')<br>');
    
		dbms_output.put_line('                 ) files<br>');
		dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
		dbms_output.put_line('            ) que<br>');
		dbms_output.put_line('            where rank1 = 1<br>');
		dbms_output.put_line('            order by 1,2;<br>');  
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>File directory</B></TD>');
		dbms_output.put_line(' <TH><B>Filename</B></TD>');
		dbms_output.put_line(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;    
   
		open java_vers('PAY');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		dbms_output.put_line('</TD></TR>'||chr(10));
          		end loop;
        close java_vers;
      
  
		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql47'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE></div> ');
    

		dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');


     dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql472b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql472'');" href="javascript:;">');
	dbms_output.put_line('&#9654; FF Java Classes Version</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql472" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Java version:</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql482b" style="width:220px" onclick="displayItem2(this,''s1sql482'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql482" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('          select sub.subdir,sub.filename, sub.version <br>');  
		dbms_output.put_line('            from (<br>');
		dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
		dbms_output.put_line('            from (<br>');
		dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
		dbms_output.put_line('               file_version.version version,<br>');
		dbms_output.put_line('               rank()over(partition by files.filename<br>');
		dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
		dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
		dbms_output.put_line('               from ad_file_versions file_version,<br>');
		dbms_output.put_line('                 (<br>');
		dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
		dbms_output.put_line('                 from ad_files<br>');
		dbms_output.put_line('                 where app_short_name=''FF'' and upper(filename) like upper(''%.class'')<br>');    
		dbms_output.put_line('                 ) files<br>');
		dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
		dbms_output.put_line('            ) que<br>');
		dbms_output.put_line('            where rank1 = 1<br>');
		dbms_output.put_line('            order by 1,2;<br>');  
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH><B>File directory</B></TD>');
		dbms_output.put_line(' <TH><B>Filename</B></TD>');
		dbms_output.put_line(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
	   open java_vers('FF');
				  v_dir_old:='';
				  loop
						fetch java_vers into v_dir,v_file,v_version;
						EXIT WHEN  java_vers%NOTFOUND;
						if v_dir_old=v_dir then
							dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
						else
							dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
						end if;
						v_dir_old:=v_dir;
						dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
							dbms_output.put_line('</TD></TR>'||chr(10));
					end loop;
		close java_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql472'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE></div> ');
    

		dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>'); 

end;
/


-- Display forms version				  
declare
				 v_dir ad_files.subdir%type;
				  v_dir_old ad_files.subdir%type;
				  v_file ad_files.filename%type;
				  v_version ad_file_versions.version%type;
				   
				  cursor forms_vers is
				  select que.subdir,que.filename, que.version
				  from (
					 select files.filename filename,files.subdir subdir,
					 file_version.version version,
					 rank()over(partition by files.filename
					   order by file_version.version_segment1 desc,
					   file_version.version_segment2 desc,file_version.version_segment3 desc,
					   file_version.version_segment4 desc,file_version.version_segment5 desc,
					   file_version.version_segment6 desc,file_version.version_segment7 desc,
					   file_version.version_segment8 desc,file_version.version_segment9 desc,
					   file_version.version_segment10 desc,
					   file_version.translation_level desc) as rank1
					 from ad_file_versions file_version,
					   (
					   select filename, app_short_name, subdir, file_id
					   from ad_files
					   where app_short_name in ('PAY') and upper(filename) like upper('%.fmb') and subdir like 'forms%US'
					   ) files
					 where files.file_id = file_version.file_id
				  ) que
				  where rank1 = 1
				  order by 1,2;
				  begin
							dbms_output.put_line('<DIV class=divItem><a name="forms"></a>');
							dbms_output.put_line('<DIV id="s1sql79b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql79'');" href="javascript:;">&#9654; Forms Version</A></DIV>');		
		
							dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql79" style="display:none" >');
							dbms_output.put_line('  <TR> <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('     <B>Forms version:</B></font></TD>');
							dbms_output.put_line('     <TH bordercolor="#DEE6EF">');
							dbms_output.put_line('<A class=detail id="s1sql80b" onclick="displayItem2(this,''s1sql80'');" href="javascript:;">&#9654; Show SQL Script</A>');
							dbms_output.put_line('   </TD>');
							dbms_output.put_line(' </TR>');
							dbms_output.put_line(' <TR id="s1sql80" style="display:none">');
							dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
							dbms_output.put_line('       <blockquote><p align="left">');
							dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
							dbms_output.put_line('            from (<br>');
							dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
							dbms_output.put_line('               file_version.version version,<br>');
							dbms_output.put_line('               rank()over(partition by files.filename<br>');
							dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
							dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
							dbms_output.put_line('               from ad_file_versions file_version,<br>');
							dbms_output.put_line('                 (<br>');
							dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
							dbms_output.put_line('                 from ad_files<br>');
						dbms_output.put_line('                 where app_short_name in (''PAY'') and upper(filename) like upper(''%.fmb'') and subdir like ''forms%US''<br>');  
							dbms_output.put_line('                 ) files<br>');
							dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
							dbms_output.put_line('            ) que<br>');
							dbms_output.put_line('            where rank1 = 1<br>');
							dbms_output.put_line('            order by 1,2;<br>');  
							dbms_output.put_line('          </blockquote><br>');
							dbms_output.put_line('     </TD>');
							dbms_output.put_line('   </TR>');
							dbms_output.put_line(' <TR>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>File directory</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Filename</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Version</B></TD>');

						
							:n := dbms_utility.get_time;
						
					   
										 
								  open forms_vers;
								  v_dir_old:='';
								  loop
										fetch forms_vers into v_dir,v_file,v_version;
										EXIT WHEN  forms_vers%NOTFOUND;
										if v_dir_old=v_dir then
											dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
										else
											dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
										end if;
										v_dir_old:=v_dir;
										dbms_output.put_line(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
											dbms_output.put_line('</TD></TR>'||chr(10));
									end loop;
								  close forms_vers;
					 
					  
						
							:n := (dbms_utility.get_time - :n)/100;
							dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql79'');" href="javascript:;">Collapse section</a></td></tr>');
							dbms_output.put_line(' <TR><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							dbms_output.put_line(' </TABLE></div> ');
						

						  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
				  EXCEPTION
			when others then			  
			  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
			  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1<br>');
end;
/

-- Display reports version				  
declare
				  v_dir ad_files.subdir%type;
				  v_dir_old ad_files.subdir%type;
				  v_file ad_files.filename%type;
				  v_version ad_file_versions.version%type;
				   
				  cursor Reports_vers is
				  select que.subdir,que.filename, que.version
				  from (
					 select files.filename filename,files.subdir subdir,
					 file_version.version version,
					 rank()over(partition by files.filename
					   order by file_version.version_segment1 desc,
					   file_version.version_segment2 desc,file_version.version_segment3 desc,
					   file_version.version_segment4 desc,file_version.version_segment5 desc,
					   file_version.version_segment6 desc,file_version.version_segment7 desc,
					   file_version.version_segment8 desc,file_version.version_segment9 desc,
					   file_version.version_segment10 desc,
					   file_version.translation_level desc) as rank1
					 from ad_file_versions file_version,
					   (
					   select filename, app_short_name, subdir, file_id
					   from ad_files
					   where (app_short_name like 'PAY') and upper(filename) like upper('%.rdf') and subdir like 'rep%US'
					   ) files
					 where files.file_id = file_version.file_id
				  ) que
				  where rank1 = 1
				  order by 1,2;
				  begin
							dbms_output.put_line('<DIV class=divItem><a name="reports"></a>');
							dbms_output.put_line('<DIV id="s1sql77b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql77'');" href="javascript:;">&#9654; Reports Version</A></DIV>');		
							dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql77" style="display:none" >');
							dbms_output.put_line('   <TR><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('     <B>Reports version:</B></font></TD>');
							dbms_output.put_line('     <TH bordercolor="#DEE6EF">');
							dbms_output.put_line('<A class=detail id="s1sql78b"  onclick="displayItem2(this,''s1sql78'');" href="javascript:;">&#9654; Show SQL Script</A>');
							dbms_output.put_line('   </TD>');
							dbms_output.put_line(' </TR>');
							dbms_output.put_line(' <TR id="s1sql78" style="display:none">');
							dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
							dbms_output.put_line('       <blockquote><p align="left">');
							dbms_output.put_line('          select que.subdir,que.filename, que.version <br>');  
							dbms_output.put_line('            from (<br>');
							dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
							dbms_output.put_line('               file_version.version version,<br>');
							dbms_output.put_line('               rank()over(partition by files.filename<br>');
							dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
							dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
							dbms_output.put_line('               from ad_file_versions file_version,<br>');
							dbms_output.put_line('                 (<br>');
							dbms_output.put_line('                 select filename, app_short_name, subdir, file_id<br>');
							dbms_output.put_line('                 from ad_files<br>');
						dbms_output.put_line('                 where (app_short_name like ''PAY'') and upper(filename) like upper(''%.rdf'') and subdir like ''rep%US''<br>');  
							dbms_output.put_line('                 ) files<br>');
							dbms_output.put_line('               where files.file_id = file_version.file_id<br>');
							dbms_output.put_line('            ) que<br>');
							dbms_output.put_line('            where rank1 = 1<br>');
							dbms_output.put_line('            order by 1,2;<br>');  
							dbms_output.put_line('          </blockquote><br>');
							dbms_output.put_line('     </TD>');
							dbms_output.put_line('   </TR>');
							dbms_output.put_line(' <TR>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>File directory</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Filename</B></TD>');
							dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Version</B></TD>');

						
							:n := dbms_utility.get_time;
						
					   
										 
								  open Reports_vers;
								  v_dir_old:='';
								  loop
										fetch Reports_vers into v_dir,v_file,v_version;
										EXIT WHEN  Reports_vers%NOTFOUND;
										if v_dir_old=v_dir then
											dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
										else
											dbms_output.put_line('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
										end if;
										v_dir_old:=v_dir;										
										
										dbms_output.put_line(v_file||'</TD>'||chr(10));
										
										dbms_output.put_line('<TD>'||v_version);
										dbms_output.put_line('</TD></TR>'||chr(10));
									end loop;
								  close Reports_vers;
					 
					  
						
							:n := (dbms_utility.get_time - :n)/100;
							dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql77'');" href="javascript:;">Collapse section</a></td></tr>');
							dbms_output.put_line(' <TR><TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							dbms_output.put_line(' </TABLE></div> ');
						

						  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
						  
						  
		EXCEPTION
			when others then			  
			  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
			  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1<br>');
end;
/

-- Display c-code version				  
declare
				  v_file ad_files.filename%type;
				  v_version ad_file_versions.version%type;
				   
				  cursor c_vers is
				  select substr(que.filename,1,instr(que.filename,'.')-1), que.version
				  from (
					 select files.filename filename,files.subdir subdir,
					 file_version.version version,
					 rank()over(partition by files.filename
					   order by file_version.version_segment1 desc,
					   file_version.version_segment2 desc,file_version.version_segment3 desc,
					   file_version.version_segment4 desc,file_version.version_segment5 desc,
					   file_version.version_segment6 desc,file_version.version_segment7 desc,
					   file_version.version_segment8 desc,file_version.version_segment9 desc,
					   file_version.version_segment10 desc,
					   file_version.translation_level desc) as rank1
					 from ad_file_versions file_version,
					   (
					   select filename, app_short_name, subdir, file_id
					   from ad_files
					   where app_short_name in ('PAY','FF') and lower(filename) like '%.o'
					   ) files
					 where files.file_id = file_version.file_id
				  ) que
				  where rank1 = 1
				  order by 1,2;
				  begin
							dbms_output.put_line('<DIV class=divItem><a name="ccode"></a>');
							dbms_output.put_line('<DIV id="s1sql55b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql55'');" href="javascript:;">&#9654; C Code Version</A></DIV>');		
							dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="1" id="s1sql55" style="display:none" >');
							dbms_output.put_line('   <TR><TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('     <B>C code version:</B></font></TD>');
							dbms_output.put_line('     <TH bordercolor="#DEE6EF">');
							dbms_output.put_line('<A class=detail id="s1sql56b"  onclick="displayItem2(this,''s1sql56'');" href="javascript:;">&#9654; Show SQL Script</A>');
							dbms_output.put_line('   </TD>');
							dbms_output.put_line(' </TR>');
							dbms_output.put_line(' <TR id="s1sql56" style="display:none">');
							dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
							dbms_output.put_line('       <blockquote><p align="left">');
							dbms_output.put_line('          select substr(que.filename,1,instr(que.filename,''.'')-1), que.version <br>  from (<br>');
							dbms_output.put_line('               select files.filename filename,files.subdir subdir,<br>');
							dbms_output.put_line('               file_version.version version,<br>  rank()over(partition by files.filename<br>');
							dbms_output.put_line('                 order by file_version.version_segment1 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
							dbms_output.put_line('                 file_version.version_segment10 desc,<br>');
							dbms_output.put_line('                 file_version.translation_level desc) as rank1<br>');
							dbms_output.put_line('               from ad_file_versions file_version,<br>  (<br> select filename, app_short_name, subdir, file_id<br>   from ad_files<br>');
						    dbms_output.put_line('                 where app_short_name in (''PAY'',''FF'') and lower(filename) like ''%.o''<br>');  
							dbms_output.put_line('                 ) files<br>   where files.file_id = file_version.file_id<br>');
							dbms_output.put_line('            ) que<br>  where rank1 = 1<br>  order by 1,2;<br>');  
							dbms_output.put_line('          </blockquote><br>');
							dbms_output.put_line('     </TD> </TR> <TR>');
							dbms_output.put_line(' <TH><B>Filename</B></TD><TH><B>Version</B></TD>');

							:n := dbms_utility.get_time;						
								  open c_vers;								 
								  loop
										fetch c_vers into v_file,v_version;
										EXIT WHEN  c_vers%NOTFOUND;	
										dbms_output.put_line('<TR><TD>'||v_file||'</TD>'||chr(10));										
										dbms_output.put_line('<TD>'||v_version);
										dbms_output.put_line('</TD></TR>'||chr(10));
									end loop;
								  close c_vers;	 
							:n := (dbms_utility.get_time - :n)/100;
							dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql55'');" href="javascript:;">Collapse section</a></td></tr>');
							dbms_output.put_line(' <TR><TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
							dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							dbms_output.put_line(' </TABLE></div> ');						

						  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
						  
						  dbms_output.put_line('</div>');
		EXCEPTION
			when others then			  
			  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
			  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1<br>');
end;
/
	
-- Display HR profiles settings
declare	 
	  v_name fnd_profile_options_tl.user_profile_option_name%type; 
	  v_short_name fnd_profile_options.profile_option_name%type;
	  v_short_name_old fnd_profile_options.profile_option_name%type;
	  v_level varchar2(50);
	  v_level_old varchar2(50);
	  v_context varchar2(300);
	  v_value fnd_profile_option_values.profile_option_value%type;
	  v_id fnd_profile_options.PROFILE_OPTION_ID%type; 
	  v_big_no number :=1;
	  v_big_no2 number :=1;
	
		cursor big_profiles  is
		select n.user_profile_option_name,
		  po.profile_option_name ,
		   decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
		(
				'PER_SECURITY_PROFILE_ID',
				'PER_BUSINESS_GROUP_ID',
				'HR_CROSS_BUSINESS_GROUP',
				'HR_USER_TYPE',
				'ORG_ID'   
				)
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
		v_security	varchar2(42);
		v_rows number;
		v_org_name hr_all_organization_UNITS.NAME%type;
        
begin

		dbms_output.put_line('<br><br><a name="settings"></a><a name="profiles"><div class="divSection">');
		dbms_output.put_line('<div class="divSectionTitle">Settings</div><br>');			
		
		
		dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql40b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql40'');" href="javascript:;">&#9654; Profile Settings</A></DIV>');
		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql40" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Profile Settings</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql41b" style="width:220px" onclick="displayItem2(this,''s1sql41'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql41" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
    
		dbms_output.put_line('         select n.user_profile_option_name, <br>');    	
		dbms_output.put_line('               po.profile_option_name ,<br>');
		dbms_output.put_line('         decode(to_char(pov.level_id),<br>');
		dbms_output.put_line('         ''10001'', ''Site'',<br>');
		dbms_output.put_line('         ''10002'', ''Application'',<br>');
		dbms_output.put_line('         ''10003'', ''Responsibility'',<br>');
		dbms_output.put_line('         ''10005'', ''Server'',<br>');
		dbms_output.put_line('         ''10006'', ''Org'',<br>');
		dbms_output.put_line('         ''10007'', ''Servresp'',<br>');
		dbms_output.put_line('          ''10004'', ''User'', ''???'') ,<br>');
		dbms_output.put_line('         decode(to_char(pov.level_id),<br>');
		dbms_output.put_line('          ''10001'', ''Site'',<br>');
		dbms_output.put_line('         ''10002'', nvl(app.application_short_name,to_char(pov.level_value)),<br>');
		dbms_output.put_line('         ''10003'', nvl(rsp.responsibility_name,to_char(pov.level_value)),<br>');
		dbms_output.put_line('          ''10005'', svr.node_name,<br>');
		dbms_output.put_line('         ''10006'', org.name,<br>');
		dbms_output.put_line('         ''10007'', pov.level_value ||'', ''|| pov.level_value_application_id ||'', ''|| pov.level_value2,<br>');
		dbms_output.put_line('          ''10004'', nvl(usr.user_name,to_char(pov.level_value)),<br>');
		dbms_output.put_line('          ''???'') ,<br>');
		dbms_output.put_line('          pov.profile_option_value<br>');
		dbms_output.put_line('         from   fnd_profile_options po,<br>');
		dbms_output.put_line('         fnd_profile_option_values pov,<br>');
		dbms_output.put_line('         fnd_profile_options_tl n,<br>');
		dbms_output.put_line('         fnd_user usr,<br>');
		dbms_output.put_line('         fnd_application app,<br>');
		dbms_output.put_line('         fnd_responsibility_vl rsp,<br>');
		dbms_output.put_line('         fnd_nodes svr,<br>');
		dbms_output.put_line('         hr_operating_units org<br>');
		
		dbms_output.put_line('         where po.profile_option_name in (<br>');
							dbms_output.put_line('           ''HR_PAYROLL_CURRENCY_RATES'',<br>');
							dbms_output.put_line('           ''HR_PAYROLL_CONTACT_SOURCE'',<br>');
							dbms_output.put_line('           ''HR_VIEW_PAYSLIP_FROM_DATE'',<br>');
							dbms_output.put_line('           ''HR_MV_HIRE_SKIP_ACT_VALIDATION'',<br>');
							dbms_output.put_line('         ''PAY_PPM_MULTI_ASSIGNMENT_ENABLE'',<br>');
							dbms_output.put_line('         ''PAY_PSS_PAYMENTS_LIST'',<br>');
							dbms_output.put_line('         ''PAY_PSS_PAYMENT_FUNCTION'',<br>');
							dbms_output.put_line('         ''PAY_SIMULATION_ENABLE_FLAG'',<br>');
							dbms_output.put_line('         ''PAY_SIM_MULTI_ASSIGNMENT_ENABLE'',<br>');
							dbms_output.put_line('         ''PAY_KEEP_ENBL_HRACES'',<br>');
							dbms_output.put_line('         ''PAY_PSS_RUN_TYPE_DISPLAY'',<br>');
							dbms_output.put_line('         ''PAY_USE_FF_PTO'',<br>');
							dbms_output.put_line('         ''PER_ENABLE_DTW4'',<br>');
							dbms_output.put_line('         ''GB PAYROLL PENSIONS ENROLL CHECK'',<br>');
							dbms_output.put_line('         ''GB_PAYE_NI_AGGREGATION'',<br>');
							dbms_output.put_line('         ''GB_OVERRIDE_SOY'',<br>');
							dbms_output.put_line('         ''GB_DEFAULT_AGG_FLAG'',<br>');
							dbms_output.put_line('         ''GB RTI UPTAKE'',<br>');
							dbms_output.put_line('         ''PAY_IE_P35_REPORTING_YEAR'',<br>');
							dbms_output.put_line('         ''PER_ENABLE_DTW4'',<br>');
							dbms_output.put_line('         ''DATETRACK:ENABLED'',<br>');
							dbms_output.put_line('          ''FND_DISABLE_OA_CUSTOMIZATIONS'',<br>');	
							dbms_output.put_line('         ''FND_OA_ENABLE_DEFAULTS'')<br>');		
		dbms_output.put_line('          and    pov.application_id = po.application_id<br>');
		dbms_output.put_line('          and    po.profile_option_name = n.profile_option_name<br>');
		dbms_output.put_line('          and    pov.profile_option_id = po.profile_option_id<br>');
		dbms_output.put_line('          and    usr.user_id (+) = pov.level_value<br>');
		dbms_output.put_line('          and    rsp.application_id (+) = pov.level_value_application_id<br>');
		dbms_output.put_line('          and    rsp.responsibility_id (+) = pov.level_value<br>');
		dbms_output.put_line('          and    app.application_id (+) = pov.level_value<br>');
		dbms_output.put_line('          and    svr.node_id (+) = pov.level_value<br>');
		dbms_output.put_line('          and    svr.node_id (+) = pov.level_value2<br>');
		dbms_output.put_line('         and    org.organization_id (+) = pov.level_value<br>');
		dbms_output.put_line('         and    n.language=''US''<br>');
		dbms_output.put_line('         order by n.user_profile_option_name,pov.level_id;<br>');
    
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH width="25%"><B>Long Name</B></TD>');
		dbms_output.put_line(' <TH width="15%"><B>Short Name</B></TD>');
		dbms_output.put_line(' <TH width="10%"><B>Level</B></TD>');
		dbms_output.put_line(' <TH width="35%"><B>Context</B></TD>');
		dbms_output.put_line(' <TH width="15%"><B>Profile Value</B></TD>');
    
    
	:n := dbms_utility.get_time;
	
    v_short_name_old:='x';
    v_level_old:='x';
   	
	 open big_profiles;
          loop
            fetch big_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  big_profiles%NOTFOUND;
                    if v_short_name<>v_short_name_old then
							  if v_big_no>1 then
									v_big_no2 :=v_big_no-1;
									dbms_output.put_line('<tr><td><A class=detail onclick="hideRow2(''s1sql100'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
									dbms_output.put_line('</TABLE></td></TR>');
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line('</TD>'||chr(10)||'<TD>');
                    else
                        dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        dbms_output.put_line('-');
                    else
                        dbms_output.put_line(v_context );
                    end if;
					case v_short_name
					when 'PER_SECURITY_PROFILE_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from PER_SECURITY_PROFILES 
									where SECURITY_PROFILE_ID = v_value;
								if v_rows=1 then
										select substr(SECURITY_PROFILE_NAME,1,40) into v_security from PER_SECURITY_PROFILES 
											where SECURITY_PROFILE_ID = v_value;							
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_security);
								else
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					when 'HR_USER_TYPE' then
							case v_value
							when 'INT' then
								dbms_output.put_line('</TD>'||chr(10)||'<TD>INT - HR with Payroll User' );
							when 'PAY' then
								dbms_output.put_line('</TD>'||chr(10)||'<TD>PAY - Payroll User' );
							when 'PER' then
								dbms_output.put_line('</TD>'||chr(10)||'<TD>PER - HR User' );
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
							end case;
					when 'ORG_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from hr_all_organization_UNITS
											where ORGANIZATION_ID=v_value;
								if v_rows=1 then									
										select NAME into v_org_name from hr_all_organization_UNITS
											where ORGANIZATION_ID=v_value;										
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_org_name);									
								else
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					when 'PER_BUSINESS_GROUP_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from hr_all_organization_UNITS
											where ORGANIZATION_ID=v_value;
								if v_rows=1 then									
										select NAME into v_org_name from hr_all_organization_UNITS
											where ORGANIZATION_ID=v_value;										
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_org_name);									
								else
										dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					else
							dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
					end case;
                    
                    dbms_output.put_line('</TD></TR>'||chr(10));              
          end loop;
          close big_profiles;
		  
		  
		  v_big_no2 :=v_big_no-1;
		  dbms_output.put_line('<tr><td><A class=detail onclick="hideRow2(''s1sql100'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
									
		  dbms_output.put_line(' </TABLE>');  
	
end;
/

-- Display profiles settings
declare
  v_name fnd_profile_options_tl.user_profile_option_name%type; 
  v_short_name fnd_profile_options.profile_option_name%type;
  v_short_name_old fnd_profile_options.profile_option_name%type;
  v_level varchar2(30);
  v_level_old varchar2(30);
  v_context varchar2(300);
  v_value fnd_profile_option_values.profile_option_value%type;
  v_id fnd_profile_options.PROFILE_OPTION_ID%type;
  issue0 boolean := FALSE;	
   issue1 boolean := FALSE;
  issue2 boolean := FALSE;
  issue3 boolean := FALSE;
  issue20 boolean := FALSE; 
  issue26 boolean := FALSE; 
  v_rows number;
  v_begin_table number;
  v_end_table number;
  v_big_no_old number;
  v_big_no number;
	
	cursor pay_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
       where po.profile_option_name in
             (
              'HR_PAYROLL_CURRENCY_RATES',
				'HR_PAYROLL_CONTACT_SOURCE',
				'HR_VIEW_PAYSLIP_FROM_DATE',
				'HR_MV_HIRE_SKIP_ACT_VALIDATION',
				'PAY_PPM_MULTI_ASSIGNMENT_ENABLE',
				'PAY_PSS_PAYMENTS_LIST',
				'PAY_PSS_PAYMENT_FUNCTION',
				'PAY_SIMULATION_ENABLE_FLAG',
				'PAY_SIM_MULTI_ASSIGNMENT_ENABLE',
				'PAY_KEEP_ENBL_HRACES',
                'PAY_PSS_RUN_TYPE_DISPLAY',
                'PAY_USE_FF_PTO',
			    'PER_ENABLE_DTW4',
				'GB PAYROLL PENSIONS ENROLL CHECK',
				'GB_PAYE_NI_AGGREGATION',
				'GB_OVERRIDE_SOY',
				'GB_DEFAULT_AGG_FLAG',
				'GB RTI UPTAKE',
				'PAY_IE_P35_REPORTING_YEAR'				
			  )
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
        
begin

  
	select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
	where  po.profile_option_name ='FND_DISABLE_OA_CUSTOMIZATIONS'   and pov.profile_option_value='N'
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
	if v_rows > 0 then
		issue0:=TRUE;
	end if;
	
	select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
	where  po.profile_option_name ='FND_OA_ENABLE_DEFAULTS'   and pov.profile_option_value='N'
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
	if v_rows > 0 then
		issue20:=TRUE;
	end if;
	
	SELECT  count(1) into v_rows
         FROM    fnd_profile_options po
                ,fnd_profile_option_values pov
         WHERE   po.profile_option_name = 'ENABLE_SECURITY_GROUPS'
         AND     po.application_id = 0
         AND     po.profile_option_id = pov.profile_option_id
         AND     po.application_id = pov.application_id
         AND     (pov.level_id = 10002  AND  hr_general.chk_application_id (pov.level_value) = 'TRUE')
         AND     pov.profile_option_value = 'Y';
	if v_rows > 0 then
		issue26:=TRUE;
	end if;
	
	select count(1) 
     into v_rows
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';     
     if v_rows>0 then
		select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
			where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'   and pov.level_id='10001'
			and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
			if v_rows = 0 then
				issue1:=TRUE;
			else
				select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
					where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'   and pov.level_id='10001' and pov.profile_option_value='2014'
					and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
					if v_rows = 0 then
						issue2:=TRUE;
					end if;				
			end if;
		select   count(distinct pov.profile_option_value)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
					where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'  
					and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
			if v_rows >1 then
				issue3:=TRUE;
			end if;
	 end if;
	 
	v_short_name_old:='x';
    v_level_old:='x';
	v_big_no:=6;
	v_begin_table:=0;
	v_end_table:=0;	
	v_big_no_old:=v_big_no;	
	open pay_profiles;
          loop
            fetch pay_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  pay_profiles%NOTFOUND;
			if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									dbms_output.put_line('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  dbms_output.put_line('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  dbms_output.put_line('   </TD>');
							  dbms_output.put_line(' </TR>');
							  dbms_output.put_line(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  dbms_output.put_line(' <TR><TD width="25%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Long Name</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Short Name</B></TD>');
							  dbms_output.put_line(' <TD width="10%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Level</B></TD>');
							  dbms_output.put_line(' <TD width="35%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Context</B></TD>');
							  dbms_output.put_line(' <TD width="15%" BGCOLOR=#DEE6EF><font face="Calibri"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
			end if;
            if v_short_name=v_short_name_old and v_level=v_level_old then
                dbms_output.put_line('<TR><TD></TD>'||chr(10)||'<TD>');
                dbms_output.put_line('</TD>'||chr(10)||'<TD>' );
                dbms_output.put_line('</TD>'||chr(10)||'<TD>');
            else
                dbms_output.put_line('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                dbms_output.put_line(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                dbms_output.put_line(v_level ||'</TD>'||chr(10)||'<TD>');
            end if;
            v_short_name_old:=v_short_name;
            v_level_old:=v_level;
            
            if v_context is null then
                dbms_output.put_line('-');
            else
                dbms_output.put_line(v_context );
            end if;
            dbms_output.put_line('</TD>'||chr(10)||'<TD>'     ||v_value );
            dbms_output.put_line('</TD></TR>'||chr(10));
                
          end loop;
          close pay_profiles;
	if v_begin_table<>v_end_table then
				dbms_output.put_line(' </TABLE>');
	end if;

		  
    
    :n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql40'');" href="javascript:;">Collapse section</a></td></tr>');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> </div> ');
    
	dbms_output.put_line('<div class="divok">');
	if issue26 then				
				dbms_output.put_line('<span class="sectionblue1">Information:</span> Multiple Security Group is enabled.<br></div>');
	else
				dbms_output.put_line('<span class="sectionblue1">Information:</span> Multiple Security Group is NOT enabled.<br></div>');
	end if;
    if issue0 then
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('<font color="blue">Advice: </font> Profile "Disable Self-Service Personal" is set to N at one/several levels, ');
				dbms_output.put_line('so personalization/OA page customization is used. This can cause issues in system behavior (caused by custom personalization).<br> ');
				dbms_output.put_line('If you have issues in web pages, before raising an Service Request, please turn this profile to Y (to disable all personalizations) and retest. ');
				dbms_output.put_line('If the issue is not reproducible, then it is caused by customization.<br>');
				dbms_output.put_line('</div>');
				
	end if;
	if issue20 then
				dbms_output.put_line('<div class="divwarn">');
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Profile "FND:OA:Enable Defaults" is set to N at one/several levels, ');
				dbms_output.put_line('so default values specified in personalizations and base meta data applied to your pages will not be displayed.<br> ');
				dbms_output.put_line('</div>');
				:w1:=:w1+1;
	end if;
	if issue1 then
				dbms_output.put_line('<div class="divwarn">');
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Profile "HR: IE P35 Reporting Year" is not set at Site Level.<br> ');
				dbms_output.put_line('</div>');
				:w1:=:w1+1;
	end if;
	if issue2 then
				dbms_output.put_line('<div class="divwarn">');
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Profile "HR: IE P35 Reporting Year" is not set to current tax year 2014.<br> ');
				dbms_output.put_line('</div>');
				:w1:=:w1+1;
	end if;
	if issue3 then
				dbms_output.put_line('<div class="divwarn">');
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Profile "HR: IE P35 Reporting Year" is set to different values at different levels.<br> ');
				dbms_output.put_line('</div>');
				:w1:=:w1+1;
	end if;
	dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br><br>');
	
end;
/

-- Display Security profile details
declare
    cursor security is
    select security_profile_id, nvl(security_profile_name,'null') from PER_SECURITY_PROFILES 
	order by upper(security_profile_name);
    v_sec_id PER_SECURITY_PROFILES.security_profile_id%type;
	v_sec_name PER_SECURITY_PROFILES.security_profile_name%type;
begin
      	
   dbms_output.put_line('<a name="security"></a>');
			dbms_output.put_line('<DIV class=divItem>');
			dbms_output.put_line('<DIV id="s1sql49b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql49'');" href="javascript:;">&#9654; Security Profile Details</A></DIV>');
			
                        dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql49" style="display:none" >');
                        dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                        dbms_output.put_line('     <B>Security Profile Details</B></font></TD>');
                        dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                        dbms_output.put_line('<A class=detail id="s1sql50b" style="width:220px" onclick="displayItem2(this,''s1sql50'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        dbms_output.put_line('   </TD>');
                        dbms_output.put_line(' </TR>');
                        dbms_output.put_line(' <TR id="s1sql50" style="display:none">');
                        dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
                        dbms_output.put_line('       <blockquote><p align="left">');
                        dbms_output.put_line('        select security_profile_id, security_profile_name from PER_SECURITY_PROFILES  <br>');   
                        dbms_output.put_line('        order by upper(security_profile_name);<br>');  
    
                        dbms_output.put_line('          </blockquote><br>');
                        dbms_output.put_line('     </TD>');
                        dbms_output.put_line('   </TR>');
                        dbms_output.put_line(' <TR>');
                        dbms_output.put_line(' <TH><B>ID</B></TD>');                        
                        dbms_output.put_line(' <TH><B>Security Profile Name</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open security;
                          loop
                                fetch security into v_sec_id ,  v_sec_name;
                                EXIT WHEN  security%NOTFOUND;
                                dbms_output.put_line('<TR><TD>'||v_sec_id||'</TD>'||chr(10)||'<TD>'||v_sec_name||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close security;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       

						dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql49'');" href="javascript:;">Collapse section</a></td></tr>');
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						dbms_output.put_line(' </TABLE> </div> ');
						dbms_output.put_line('<div class="divok">');
						 dbms_output.put_line('<font color="blue">Advice: </font> Please review ');
						 dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=394083.1" target="_blank">Note 394083.1</a> ');
						 dbms_output.put_line('Understanding and Using HRMS Security in Oracle HRMS<br>');
						 dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1266051.1" target="_blank">Note 1266051.1</a> ');
						 dbms_output.put_line('Troubleshooting eBusiness Suite HRMS Security Issues<br>');
						 dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1385633.1" target="_blank">Note 1385633.1</a> ');
						 dbms_output.put_line('Security, MultiOrg, and Multi Org Access Control(MOAC) support in relation to Oracle Human Resources applications<br>');		
						dbms_output.put_line('</div>');
						dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						

EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');	
end;
/

-- Display International Payroll usage
declare
    cursor c_international is
    SELECT   fcr.argument1 international_legislation_code
				,ftv.territory_short_name, fcr.request_date
		FROM     fnd_concurrent_requests fcr
				,fnd_concurrent_programs fcp
				,fnd_territories_tl ftv
		WHERE    fcr.concurrent_program_id = fcp.concurrent_program_id
			 AND ftv.territory_code = fcr.argument1
			 AND ftv.LANGUAGE='US'
			 AND fcp.concurrent_program_name = 'PYINTSTU'; 
	
    v_code fnd_concurrent_requests.argument1%type;
	v_name fnd_territories_tl.territory_short_name%type;
	v_date fnd_concurrent_requests.request_date%type;
begin
	
			dbms_output.put_line('<a name="international"></a>');						
						dbms_output.put_line('<DIV class=divItem>');
						dbms_output.put_line('<DIV id="s1sql53b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql53'');" href="javascript:;">&#9654; International Payroll Usage</A></DIV>');
                        dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql53" style="display:none" >');
                        dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
                        dbms_output.put_line('     <B>Concurrent process International HRMS Setup</B></font></TD>');
                        dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                        dbms_output.put_line('<A class=detail  id="s1sql54b"  onclick="displayItem2(this,''s1sql54'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        dbms_output.put_line('   </TD>');
                        dbms_output.put_line(' </TR>');
                        dbms_output.put_line(' <TR id="s1sql54" style="display:none">');
                        dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
                        dbms_output.put_line('       <blockquote><p align="left">');
                        dbms_output.put_line('        SELECT   fcr.argument1 international_legislation_code<br>');
						dbms_output.put_line('        ,ftv.territory_short_name, fcr.request_date<br>');
						dbms_output.put_line('        FROM     fnd_concurrent_requests fcr<br>');
						dbms_output.put_line('        ,fnd_concurrent_programs fcp<br>');
						dbms_output.put_line('        ,fnd_territories_tl ftv<br>');
						dbms_output.put_line('        WHERE    fcr.concurrent_program_id = fcp.concurrent_program_id<br>');
						dbms_output.put_line('        AND ftv.territory_code = fcr.argument1<br>');
						dbms_output.put_line('        AND ftv.LANGUAGE=''US''<br>');
						dbms_output.put_line('        AND fcp.concurrent_program_name = ''PYINTSTU'';	<br>');		   
                        dbms_output.put_line('          </blockquote><br>');
                        dbms_output.put_line('     </TD>');
                        dbms_output.put_line('   </TR>');
                        dbms_output.put_line(' <TR>');
                        dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Country code</B></TD>');                        
                        dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Country Name</B></TD>');
						dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Date when concurrent request was performed</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open c_international;
                          loop
                                fetch c_international into v_code, v_name, v_date;
                                EXIT WHEN  c_international%NOTFOUND;
                                dbms_output.put_line('<TR><TD>'||v_code||'</TD>'||chr(10)||'<TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_date||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close c_international;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						dbms_output.put_line(' </TABLE> </div> ');			
						
						
						dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						
	
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');	
end;
/

-- Display pay_trigger_events
declare
	
	v_table pay_trigger_events.table_name%type;
    v_trigger pay_trigger_events.short_name%type;
	v1 pay_trigger_events.generated_flag%type;
	v2 pay_trigger_events.enabled_flag%type;
	v3 pay_trigger_components.enabled_flag%type;
    no_triggers number;
 	issue boolean := FALSE;
  cursor flag_triggers is
	  select pte.table_name, pte.short_name, pte.generated_flag,pte.enabled_flag, ptc.enabled_flag 
		from pay_trigger_events pte,
		pay_trigger_components ptc
		where (short_name like 'PER_%'
			 OR short_name like 'PAY_%')
		and pte.event_id = ptc.event_id(+)
		and (pte.generated_flag<>'Y' or pte.enabled_flag<>'Y' or ptc.enabled_flag<>'Y')
		order by pte.table_name;  

begin

	  select count(1) into no_triggers from pay_trigger_events pte,
		pay_trigger_components ptc
		where (short_name like 'PER_%'
			 OR short_name like 'PAY_%')
		and pte.event_id = ptc.event_id(+)
		and (pte.generated_flag<>'Y' or pte.enabled_flag<>'Y' or ptc.enabled_flag<>'Y');
		if no_triggers>0 then
						issue:=TRUE;
		end if;
        
	
				dbms_output.put_line(' <a name="pay_trigger_events"></a>');
				dbms_output.put_line('<DIV class=divItem>');
				dbms_output.put_line('<DIV id="s1sql51b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql51'');" href="javascript:;">&#9654; Pay Triggers Events</A></DIV>');		
				dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql51" style="display:none" >');
				dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
				dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
				dbms_output.put_line('     <B>Triggers with flag not set to y:</B></font></TD>');
				dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
				dbms_output.put_line('<A class=detail  id="s1sql52b"  onclick="displayItem2(this,''s1sql52'');" href="javascript:;">&#9654; Show SQL Script</A>');
				dbms_output.put_line('   </TD>');
				dbms_output.put_line(' </TR>');
				dbms_output.put_line(' <TR id="s1sql52" style="display:none">');
				dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
				dbms_output.put_line('       <blockquote><p align="left">');
				
				dbms_output.put_line('          select pte.table_name, pte.short_name, pte.generated_flag,pte.enabled_flag, ptc.enabled_flag <br>');
				dbms_output.put_line('          from pay_trigger_events pte,<br>');
				dbms_output.put_line('          pay_trigger_components ptc<br>');
				dbms_output.put_line('          where (short_name like ''PER_%''<br>');
				dbms_output.put_line('          	 OR short_name like ''PAY_%'')<br>');
				dbms_output.put_line('          and pte.event_id = ptc.event_id(+)<br>');
				dbms_output.put_line('          and (pte.generated_flag<>''Y'' or pte.enabled_flag<>''Y'' or ptc.enabled_flag<>''Y'')<br>');
				dbms_output.put_line('          order by pte.table_name; <br>');

				dbms_output.put_line('          </blockquote><br>');
				dbms_output.put_line('     </TD>');
				dbms_output.put_line('   </TR>');
				dbms_output.put_line(' <TR>');
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Table name</B></TD>');		
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Trigger Name</B></TD>');
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Generated flag</B></TD>');
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Enabled flag - events</B></TD>');
				dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Enabled flag - components</B></TD>');
			
				:n := dbms_utility.get_time;
			
				open flag_triggers;
					  loop
						 fetch flag_triggers into v_table,v_trigger,v1,v2,v3;
						 EXIT WHEN  flag_triggers%NOTFOUND;
						 dbms_output.put_line('<TR><TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD>'||chr(10));
						 if v1<>'Y' then
							dbms_output.put_line('<TD><font color="red">'||v1||'</font></TD>'||chr(10));
						 else
							dbms_output.put_line('<TD>'||v1||'</TD>'||chr(10));
						 end if;
						 if v2<>'Y' then
							dbms_output.put_line('<TD><font color="red">'||v2||'</font></TD>'||chr(10));
						 else
							dbms_output.put_line('<TD>'||v2||'</TD>'||chr(10));
						 end if;
						 if v3<>'Y' then
							dbms_output.put_line('<TD><font color="red">'||v3||'</font></TD></TR>'||chr(10));
						 else
							dbms_output.put_line('<TD>'||v3||'</TD>'||chr(10));
						 end if;								 
					  end loop;
				close flag_triggers;    
			 
				:n := (dbms_utility.get_time - :n)/100;
				dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
				dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
				dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
				dbms_output.put_line(' </TABLE> </div> ');
				
				
				if issue  then
					dbms_output.put_line('<div class="divwarn">');
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You have trigger(s) with flag not set to Y (not set or set to N).<br>');		
					dbms_output.put_line('</div>');	
					:w1:=:w1+1;					
				else             
					dbms_output.put_line('<div class="divok">');
					dbms_output.put_line('<img class="check_ico">OK! All triggers have flag set on Y.<br>');
					dbms_output.put_line('</div>');
				end if;
				
				
				dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
			
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');	
end;
/


-- Display PAY_ACTION parameters
declare
	v_pay_name pay_action_parameters.parameter_name%type; 
	v_pay_value pay_action_parameters.parameter_value%type;
	v_min_ini_trans number;
	v_cpu number;
	v_rows number;
	status_leg varchar2(2);
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue8 boolean := FALSE;
	issue9 boolean := FALSE;
	issue10 boolean := FALSE;
	cursor pay_action is
	select parameter_name, nvl(parameter_value,'null') 
      from pay_action_parameters
	  order by parameter_name;

begin

dbms_output.put_line(' <a name="pay_action"></a>');
	
	SELECT SUBSTR(value, 1, 10)
						into v_cpu
						FROM v$parameter
						WHERE name = 'cpu_count';
	select decode(status, null,'N','I')
						into status_leg
						from hr_legislation_installations
						where substr(application_short_name,1,4)='PAY'
						and  Legislation_code = 'US';
						
	select count(1) into v_rows from pay_action_parameters where parameter_name='RANGE_PERSON_ID';
	if v_rows=0 then
		issue1:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='RANGE_PERSON_ID';
		if v_pay_value <>'Y' then
			issue1:=TRUE;
		end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name='LOW_VOLUME';
	if v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='LOW_VOLUME';
		if v_pay_value <>'N' then
			issue2:=TRUE;
		end if;
	end if;
	
	if status_leg='I' then
			select count(1) into v_rows from pay_action_parameters where parameter_name='TAX_LIBRARIES';
			if v_rows=0 then
				issue3:=TRUE;
			elsif v_rows=1 then
				select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='TAX_LIBRARIES';
				if v_pay_value is NULL then
					issue3:=TRUE;
				end if;
			end if;
			select count(1) into v_rows from pay_action_parameters where parameter_name='TAX_DATA';
			if v_rows=0 then
				issue3:=TRUE;
			elsif v_rows=1 then
				select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='TAX_DATA';
				if v_pay_value is NULL then
					issue3:=TRUE;
				end if;
			end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name='THREADS';
	v_pay_value:=1;
	if v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='THREADS';
	elsif v_rows=0 then
		v_pay_value:=1;
	end if;
	if v_pay_value<1.5*v_cpu or v_pay_value>2*v_cpu then
		issue5:=TRUE;
	end if;						
	SELECT min(ini_trans)
						into v_min_ini_trans
						FROM DBA_TABLES
						WHERE table_name IN ('FF_ARCHIVE_ITEMS'
                          ,'FF_ARCHIVE_ITEM_CONTEXTS'
                          ,'PAY_ACTION_INFORMATION'
                          ,'PAY_ASSIGNMENT_ACTIONS'
                          ,'PAY_ASSIGNMENT_LATEST_BALANCES'
                          ,'PAY_BALANCE_CONTEXT_VALUES'
                          ,'PAY_COSTS'
                          ,'PAY_DEFINED_BALANCES'
                          ,'PAY_ELEMENT_ENTRIES_F'
                          ,'PAY_ELEMENT_ENTRY_VALUES_F'
                          ,'PAY_INPUT_VALUES_F'
                          ,'PAY_PAYROLL_ACTIONS'
                          ,'PAY_PERIODS_OF_SERVICE'
                          ,'PAY_PERSON_LATEST_BALANCES'
                          ,'PAY_POPULATION_RANGES'
                          ,'PAY_PRE_PAYMENTS'
                          ,'PAY_RUN_BALANCES'
                          ,'PAY_RUN_RESULTS'
                          ,'PAY_RUN_RESULT_VALUES'
                          ,'PAY_US_RPT_TOTALS'
                          ,'PER_ALL_ASSIGNMENTS_F'
                          ,'PER_ALL_PEOPLE_F');
	if v_pay_value>v_min_ini_trans then
		issue6:=TRUE;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'RR%BUFFER%SIZE';
	if v_rows=0 then
		issue7:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'RR%BUFFER%SIZE';
		if v_pay_value <100 then
			issue7:=TRUE;
		end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'RRV%BUFFER%SIZE';
	if v_rows=0 then
		issue8:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'RRV%BUFFER%SIZE';
		if v_pay_value <100 then
			issue8:=TRUE;
		end if;
	end if;	
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'BAL%BUFFER%SIZE';
	if v_rows=0 then
		issue9:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'BAL%BUFFER%SIZE';
		if v_pay_value <100 then
			issue9:=TRUE;
		end if;
	end if;	
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'EE%BUFFER%SIZE';
	if v_rows=0 then
		issue10:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like'EE%BUFFER%SIZE';
		if v_pay_value <100 then
			issue10:=TRUE;
		end if;
	end if;	
	
	dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql9b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql9'');" href="javascript:;">&#9654; PAY Action Parameters</A></DIV>');
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql9" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>PAY action parameters</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail  id="s1sql10b"  onclick="displayItem2(this,''s1sql10'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql10" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="1" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select parameter_name, parameter_value <br>');
		dbms_output.put_line('          from pay_action_parameters<br>');
		dbms_output.put_line('			order by parameter_name');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD>');
	
		:n := dbms_utility.get_time;
		
		open pay_action;
		loop
			fetch pay_action into v_pay_name,v_pay_value;
			EXIT WHEN  pay_action%NOTFOUND;
			dbms_output.put_line('<TR><TD>'||v_pay_name||'</TD>'||chr(10)||'<TD>');
			dbms_output.put_line(v_pay_value);
			dbms_output.put_line('</TD></TR>'||chr(10));
          
		end loop;
		close pay_action;

		
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line('<tr><td><A class=detail onclick="hideRow(''s1sql9'');" href="javascript:;">Collapse section</a></td></tr>');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
	
		if issue1 or issue2 or issue3 or issue4 then
			dbms_output.put_line('<div class="diverr">');
			if issue1 then
				dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please set RANGE_PERSON_ID to Y<br>');
				:e1:=:e1+1;
			end if;
			
			if issue2 then
				dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please set LOW_VOLUME to N<br>');
				:e1:=:e1+1;
			end if;
			
			if issue3 then
				dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please set TAX_LIBRARIES<br>');
				:e1:=:e1+1;
			end if;
			
			if issue4 then
				dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> Please set TAX_DATA<br>');
				:e1:=:e1+1;
			end if;
			dbms_output.put_line('</div>');
		end if;
		
		if issue5 or issue6 or issue7 or issue8 or issue9 or issue10 then
			dbms_output.put_line('<div class="divwarn">');
			if issue5 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please set Threads to 1.5 to 2 times the number of processors, ');
				dbms_output.put_line('meaning between '||ceil(1.5*v_cpu)||' and '||ceil(2*v_cpu)||' <br>');
				dbms_output.put_line('<span class="sectionblue1">Advice:</span> Check <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=359354.1" target="_blank">Note 359354.1</a> ');
				dbms_output.put_line('How to Determine the Best Setting for the THREADS Parameter in the Pay_Action_Parameters Table<br>');
				:w1:=:w1+1;
			end if;
			
			if issue6 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please ensure the number of threads set in PAY_ACTION_PARAMETERS is the same ');
				dbms_output.put_line('or lower than the ini_trans on hot PAY tables <br>');
				:w1:=:w1+1;
			end if;
			
			if issue7 or issue8 or issue9 or issue10 then
				dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If trace files show differences between execute and fetch timings, then worth having a look at buffer sizes:<br>');
				if issue7 then
					dbms_output.put_line(' - Try setting RR BUFFER SIZE to 100.<br>');
				end if;
				if issue8 then
					dbms_output.put_line(' - Try setting RRV buffer SIZE to 100.<br>');
				end if;
				if issue9 then
					dbms_output.put_line(' - Try setting BAL BUFFER SIZE to 100.<br>');
				end if;
				if issue10 then
					dbms_output.put_line(' - Try setting EE BUFFER SIZE to 100.<br>');
				end if;
				:w1:=:w1+1;
			end if;
			
			dbms_output.put_line('</div>');
		end if;
		
		dbms_output.put_line('<div class="divok">');
		dbms_output.put_line('<span class="sectionblue1">Advice:</span> Please review:<br> ');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=549367.1" target="_blank">Note 549367.1</a> ');
		dbms_output.put_line('Oracle Human Resources Payroll PAY_ACTION_PARAMETERS Comprehensive Overview<br>');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=226987.1" target="_blank">Note 226987.1</a> ');
		dbms_output.put_line('Oracle 11i and R12 Human Resources and Benefits Tuning and System Health Checks<br>');
		dbms_output.put_line('</div>');
		
		if (not issue1) and (not issue2) and (not issue3) and (not issue4) and (not issue5) and (not issue6) and (not issue7) and (not issue8) and (not issue9) and (not issue10) then
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('Verified parameters are correctly set<br>');
				dbms_output.put_line('</div>');
		end if;	
		
		
		
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

		dbms_output.put_line(' <a name="ssp"></a>');
dbms_output.put_line('<DIV class=divItem>');
		dbms_output.put_line('<DIV id="s1sql21b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql21'');" href="javascript:;">&#9654; SSP_TEMP_AFFECTED_ROWS</A></DIV>');
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql21" style="display:none" >');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=1 bordercolor="#DEE6EF">');
		dbms_output.put_line('     <B>SSP_TEMP_AFFECTED_ROWS rows</B></font></TD><TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail  id="s1sql10b"  onclick="displayItem2(this,''s1sql22'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD></TR><TR id="s1sql22" style="display:none"><TD colspan="1" height="60">');
		dbms_output.put_line(' <blockquote><p align="left">select count(1) from SSP_TEMP_AFFECTED_ROWS</blockquote><br></TD></TR><TR>');
		dbms_output.put_line(' <TH><B>Count of rows</B></TD>');	
		:n := dbms_utility.get_time;
		dbms_output.put_line('<TR><TD>'||v_rows||'</TD></TR>'||chr(10));			
		:n := (dbms_utility.get_time - :n)/100;
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> </div> ');
	
		if v_rows>0 then
			dbms_output.put_line('<div class="divwarn">');
			dbms_output.put_line('<img class="warn_ico">For Oracle Support: SSP_TEMP_AFFECTED_ROWS table has rows.</div>');
			:w1:=:w1+1;
		else
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('OK! No rows in SSP_TEMP_AFFECTED_ROWS<br>');
				dbms_output.put_line('</div>');
		end if;			
		dbms_output.put_line(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
		
dbms_output.put_line('</div>');
end;
/


-- Display HRMS RUP level
declare
    rup_level varchar2(20);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_rows number;
	v_exists number;
	issue boolean:=FALSE;
	rup_n varchar2(50);
	cursor c_patching_122 is
		SELECT distinct PATCH_NAME, DECODE(PATCH_NAME
                  ,'19193000', 'R12.HR_PF.C.Delta.6'
				  ,'17909898', 'R12.HR_PF.C.Delta.5'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
                   ) 
                , trunc(LAST_UPDATE_DATE)                     
                  FROM ad_applied_patches
		WHERE PATCH_NAME IN ('19193000','17909898','17050005','17001123','16169935','14040707','10124646')
		order by trunc(LAST_UPDATE_DATE) desc;
	cursor c_patching_121 is
		SELECT distinct PATCH_NAME, DECODE(PATCH_NAME
                  ,'20000288','R12.HR_PF.B.delta.8'
				  ,'18004477', 'R12.HR_PF.B.delta.7'
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , trunc(LAST_UPDATE_DATE)                     
                  FROM ad_applied_patches
		WHERE PATCH_NAME IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330')
		order by trunc(LAST_UPDATE_DATE) desc;

	cursor c_patching_120 is
		SELECT distinct PATCH_NAME, DECODE(PATCH_NAME
						  , '16077077', 'R12.HR_PF.A.delta.11'
						  , '13774477', 'R12.HR_PF.A.delta.10'
						  , '10281209', 'R12.HR_PF.A.delta.9'
						  , '9301208', 'R12.HR_PF.A.delta.8'
						  , '7577660', 'R12.HR_PF.A.delta.7'
						  , '7004477', 'R12.HR_PF.A.delta.6'
						  , '6610000', 'R12.HR_PF.A.delta.5'
						  , '6494646', 'R12.HR_PF.A.delta.4'
						  , '6196269', 'R12.HR_PF.A.delta.3'
						  , '5997278', 'R12.HR_PF.A.delta.2'
						  , '5881943', 'R12.HR_PF.A.delta.1'
						  , '4719824', 'R12.HR_PF.A')
						, trunc(LAST_UPDATE_DATE)                     
						  FROM ad_applied_patches
		WHERE PATCH_NAME IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824')
		order by trunc(LAST_UPDATE_DATE) desc;

	cursor c_patching_11 is
		SELECT distinct PATCH_NAME, DECODE(PATCH_NAME
								   , '2803988', 'HRMS_PF.E'
								   , '2968701', 'HRMS_PF.F'
								   , '3116666', 'HRMS_PF.G'
								   , '3233333', 'HRMS_PF.H'
								   , '3127777', 'HRMS_PF.I'
								   , '3333633', 'HRMS_PF.J'
								   , '3500000', 'HRMS_PF.K'
								   , '5055050', 'HR_PF.K.RUP.1'
								   , '5337777', 'HR_PF.K.RUP.2'
								   , '6699770', 'HR_PF.K.RUP.3'
								   , '7666111', 'HR_PF.K.RUP.4'
								   , '9062727', 'HR_PF.K.RUP.5'
								   , '10015566', 'HR_PF.K.RUP.6'
								   , '12807777', 'HR_PF.K.RUP.7'
								   , '14488556', 'HR_PF.K.RUP.8'
								   , '17774746', 'HR_PF.K.RUP.9'
									)  
						, trunc(LAST_UPDATE_DATE)                     
						  FROM ad_applied_patches
		WHERE PATCH_NAME IN ('2803988','2968701','3116666','3233333','3127777','3333633',
						   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746')
		order by trunc(LAST_UPDATE_DATE) desc;
    
	

begin
      :issuep:=0;
	  
	  dbms_output.put_line('<br><br><a name="rup"></a><a name="patching"></a><div class="divSection">');
	  dbms_output.put_line('<div class="divSectionTitle">Patching</div>');	
		      

      dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" >');
      
      dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><th><b>Section</b></td><th><b>Status and advices</b></td></tr>');   
     
      
      dbms_output.put_line(' <TR><td>HRMS RUP</td><td>');
      
      if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into rup_level FROM ad_bugs adb
			WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646')
			;              
                 
            if rup_level='19193000' then
                  
                  dbms_output.put_line('<b>Actual level:</b> Patch 19193000 R12.HR_PF.C.delta.6 applied on '||:v_rup_date||'<br><br>');
                  dbms_output.put_line('<font color="blue">Advice:</font> Ensure you applied patches to fix known issues (note periodically updated): ');
                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1992028.1" target="_blank"> Note 1992028.1</a> ');
                  dbms_output.put_line('Known Issues on Top of Patch 19193000 - R12.HR_PF.C.DELTA.6 (HRMS 12.2 RUP6)<br><br>');	
				  
            else
                  SELECT DECODE(bug_number
                  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  dbms_output.put_line('<b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '<br><br>');
				  dbms_output.put_line('<div class="divwarn">');
                  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19193000">');
				  dbms_output.put_line('Patch 19193000</a> R12.HR_PF.C.delta.6</div><br><br>');
				  :w1:=:w1+1;
				  :issuep:=1;
							  
				  
            end if; 
			
                SELECT count(1) into v_rows FROM ad_applied_patches
						WHERE PATCH_NAME IN ('19193000','17909898','17050005','17001123','16169935','14040707','10124646');
				if v_rows>0 then
					dbms_output.put_line('<br>HRMS Patching history:<br>');
						open c_patching_122;
						loop
							  fetch c_patching_122 into rup_level,rup_n,v_date;
							  EXIT WHEN  c_patching_122%NOTFOUND;
							  dbms_output.put_line('Patch '||rup_level || ' ' || rup_n || ' applied on ' || to_char(v_date,'DD-MON-YYYY') || '<br>');	  
						end loop;
						close c_patching_122;					
					dbms_output.put_line('<br>');
				end if;
           
            
      elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');            
                 
            if rup_level='20000288' then
                  
                  dbms_output.put_line('Actual level: Patch 20000288 R12.HR_PF.B.delta.8 applied on '||:v_rup_date||'<br><br>');
                  dbms_output.put_line('<font color="blue">Advice: </font> Ensure you applied patches to fix known issues (note periodically updated): ');
                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1992029.1" target="_blank"> Note 1992029.1</a> ');
                  dbms_output.put_line('Known Issues on Top of Patch 20000288 - R12.HR_PF.B.DELTA.8 (HRMS 12.1 RUP8)<br><br>');
				  
 
            else
                  SELECT DECODE(BUG_NUMBER
                  ,'18004477', 'R12.HR_PF.B.delta.7'
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  dbms_output.put_line('Actual level: Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '<br><br>');
                   dbms_output.put_line('<div class="divwarn">');
                  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=20000288">');
				  dbms_output.put_line('Patch 20000288</a> R12.HR_PF.B.delta.8</div><br><br>');
				  :w1:=:w1+1;
				  :issuep:=1;				  				  
				  
            end if; 
			
                SELECT count(1) into v_rows FROM ad_applied_patches
						WHERE PATCH_NAME IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');
				if v_rows>0 then
					dbms_output.put_line('<br>HRMS Patching history:<br>');
						open c_patching_121;
						loop
							  fetch c_patching_121 into rup_level,rup_n,v_date;
							  EXIT WHEN  c_patching_121%NOTFOUND;
							  dbms_output.put_line('Patch '||rup_level || ' ' || rup_n || ' applied on ' || to_char(v_date,'DD-MON-YYYY') || '<br>');	  
						end loop;
						close c_patching_121;					
					dbms_output.put_line('<br>');
				end if;
            
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
            
            if rup_level='16077077' then
                 
                  dbms_output.put_line('Actual level: Patch 16077077 R12.HR_PF.A.delta.11<br><br>');                  
                  dbms_output.put_line('<font color="blue">Advice: </font> Ensure you applied patches to fix known issues (note periodically updated): ');
                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1538635.1" target="_blank"> Note 1538635.1</a> ');
                  dbms_output.put_line('Known Issues on Top of Patch 16077077 - r12.hr_pf.a.delta.11<br><br>');				  
				 
            else
                  SELECT DECODE(BUG_NUMBER
                  , '16077077', 'R12.HR_PF.A.delta.11'
                  , '13774477', 'R12.HR_PF.A.delta.10'
                  , '10281209', 'R12.HR_PF.A.delta.9'
                  , '9301208', 'R12.HR_PF.A.delta.8'
                  , '7577660', 'R12.HR_PF.A.delta.7'
                  , '7004477', 'R12.HR_PF.A.delta.6'
                  , '6610000', 'R12.HR_PF.A.delta.5'
                  , '6494646', 'R12.HR_PF.A.delta.4'
                  , '6196269', 'R12.HR_PF.A.delta.3'
                  , '5997278', 'R12.HR_PF.A.delta.2'
                  , '5881943', 'R12.HR_PF.A.delta.1'
                  , '4719824', 'R12.HR_PF.A')
                  , LAST_UPDATE_DATE  
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  dbms_output.put_line('Actual level: Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<div class="divwarn">');
                  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=16077077">');
				  dbms_output.put_line('Patch 16077077</a> R12.HR_PF.A.delta.11</div><br><br>');
				  :issuep:=1;	
				  :w1:=:w1+1;
				 
				  
            end if;  
			
                SELECT count(1) into v_rows FROM ad_applied_patches
						WHERE PATCH_NAME IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
				if v_rows>0 then
					dbms_output.put_line('<br>HRMS Patching history:<br>');
						open c_patching_120;
						loop
							  fetch c_patching_120 into rup_level,rup_n,v_date;
							  EXIT WHEN  c_patching_120%NOTFOUND;
							  dbms_output.put_line('Patch '|| rup_level || ' ' || rup_n || ' applied on ' || to_char(v_date,'DD-MON-YYYY') || '<br>');	  
						end loop;
						close c_patching_120;					
					dbms_output.put_line('<br>');
				end if;           
			
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_rows from ad_bugs 
            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
            
            if v_rows=0 then
                    dbms_output.put_line('<div class="diverr">');
					dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font> No RUP patch applied!<br><br>');
                     dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17774746">Patch 17774746</a> HR_PF.K.RUP.9<br></div>');
					:w1:=:w1+1;
					:issuep:=1;
            else        
                    select max(to_number(bug_number)) into rup_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
                   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
                    if rup_level='17774746' then
                         
                          dbms_output.put_line('Actual level: Patch 17774746 HR_PF.K.RUP.9 applied on '||:v_rup_date||'<br><br>');
                         dbms_output.put_line('<font color="blue">Advice:</font> Ensure you applied patches to fix known issues (note periodically updated): ');
                          dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1636768.1" target="_blank"> Note 1636768.1</a> ');
                          dbms_output.put_line('Known Issues on Top of Patch 17774746 - 11i.hr_pf.k.delta.9 (HRMS 11i RUP9)<br><br>'); 
						
                          
                    else
                          SELECT DECODE(BUG_NUMBER
                           , '2803988', 'HRMS_PF.E'
                           , '2968701', 'HRMS_PF.F'
                           , '3116666', 'HRMS_PF.G'
                           , '3233333', 'HRMS_PF.H'
                           , '3127777', 'HRMS_PF.I'
                           , '3333633', 'HRMS_PF.J'
                           , '3500000', 'HRMS_PF.K'
                           , '5055050', 'HR_PF.K.RUP.1'
                           , '5337777', 'HR_PF.K.RUP.2'
                           , '6699770', 'HR_PF.K.RUP.3'
                           , '7666111', 'HR_PF.K.RUP.4'
                           , '9062727', 'HR_PF.K.RUP.5'
                           , '10015566', 'HR_PF.K.RUP.6'
                           , '12807777', 'HR_PF.K.RUP.7'
                           , '14488556', 'HR_PF.K.RUP.8'
						   ,'17774746', 'HR_PF.K.RUP.9'
                            )  
                        , LAST_UPDATE_DATE  
                          into :rup_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =rup_level and rownum < 2;
                          
                          dbms_output.put_line('Actual level: Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '<br><br>');
                          dbms_output.put_line('<div class="divwarn">');
						  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> Please plan to install ');
						  dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17774746">Patch 17774746</a> HR_PF.K.RUP.9<br><br></div>');
						  :issuep:=1;
						  :w1:=:w1+1;						  
						
                    end if;
					
						SELECT count(1) into v_rows FROM ad_applied_patches
						WHERE PATCH_NAME IN ('2803988','2968701','3116666','3233333','3127777','3333633',
							'3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
						if v_rows>0 then
							dbms_output.put_line('<br>HRMS Patching history:<br>');
								open c_patching_11;
								loop
									  fetch c_patching_11 into rup_level,rup_n,v_date;
									  EXIT WHEN  c_patching_11%NOTFOUND;
									  dbms_output.put_line('Patch '||rup_level || ' ' || rup_n || ' applied on ' || to_char(v_date,'DD-MON-YYYY') || '<br>');	  
								end loop;
								close c_patching_11;					
							dbms_output.put_line('<br>');
						
					end if;					
            end if;   
      end if;
      --dbms_output.put_line('</td></tr>');
	 
      
end;
/

-- Display ATG level
declare
    atg_level varchar2(20);
    atg_level_n varchar2(50);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_exists number;
begin

      
      dbms_output.put_line(' <TR><td><a name="atg"></a>ATG</td><td>');
      
       if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into atg_level FROM ad_bugs adb
			WHERE adb.bug_number in ('10110982','14222219','15890638','17007206','17909318')
			;
			if atg_level='17909318' then                  
                  dbms_output.put_line('<b>Actual level:</b> Patch 17909318 R12.ATG_PF.C.delta.4<br><br>');  
            else
				SELECT DECODE(BUG_NUMBER
				 , '10110982', 'R12.ATG_PF.C'
				 , '14222219', 'R12.ATG_PF.C.delta.1'
				 , '15890638', 'R12.ATG_PF.C.delta.2'
				 , '17007206', 'R12.ATG_PF.C.delta.3','17909318', 'R12.ATG_PF.C.delta.4')
					, LAST_UPDATE_DATE   
					  into atg_level_n, v_date
					  FROM ad_bugs 
					  WHERE BUG_NUMBER =atg_level and rownum < 2;
				 dbms_output.put_line('<b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<div class="divwarn">');
				  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17909318">Patch 17909318</a> ');
				  dbms_output.put_line('R12.ATG_PF.C.delta.4<br></div>');
				  :w1:=:w1+1;
				  :issuep:=1;
			end if;
                 
	  elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into atg_level from ad_bugs 
            WHERE BUG_NUMBER IN ('6430106','7307198','7651091','8919491');            
                 
            if atg_level='8919491' then
                  dbms_output.put_line('Actual level: Patch 8919491 R12.ATG_PF.B.delta.3<br><br>');                  
                  dbms_output.put_line('<font color="blue">Advice: </font> Ensure you applied patches to fix known issues (note periodically updated): ');
                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1273640.1" target="_blank"> Note 1273640.1</a> ');
                  dbms_output.put_line('Known ATG issues on Top of 12.1.3 - r12.atg_pf.b.delta.3, Patch 8919491');
                  
            else
                  SELECT DECODE(BUG_NUMBER
                 , '6430106', 'R12.ATG_PF.B'
                 , '7307198', 'R12.ATG_PF.B.delta.1'
                 , '7651091', 'R12.ATG_PF.B.delta.2'
                 , '8919491', 'R12.ATG_PF.B.delta.3')
                , LAST_UPDATE_DATE   
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
                  
                  dbms_output.put_line('Actual level: Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<div class="divwarn">');
				  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=8919491">Patch 8919491</a> ');
				  dbms_output.put_line('R12.ATG_PF.B.delta.3<br></div>');
				  :w1:=:w1+1;
				  :issuep:=1;
            end if; 
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into atg_level from ad_bugs 
            WHERE BUG_NUMBER IN ('4461237','5907545','5917344','6077669','6272680','6594849','7237006');
            
            if atg_level='7237006' then                  
                  dbms_output.put_line('<img class="check_ico">OK! You are at latest level available: Patch 7237006 R12.ATG_PF.A.delta.6.<br>');                  
            else
                  SELECT DECODE(BUG_NUMBER
                 , '4461237', 'R12.ATG_PF.A'
                 , '5907545', 'R12.ATG_PF.A.delta.1'
                 , '5917344', 'R12.ATG_PF.A.delta.2'
                 , '6077669', 'R12.ATG_PF.A.delta.3'
                 , '6272680', 'R12.ATG_PF.A.delta.4'
                 , '6594849', 'R12.ATG_PF.A.delta.5'
                 , '7237006', 'R12.ATG_PF.A.delta.6')
                  , LAST_UPDATE_DATE  
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
                  
                  dbms_output.put_line('Actual level: Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '<br><br>');
                  dbms_output.put_line('<div class="divwarn">');
                  dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=7237006">Patch 7237006</a>');
				  dbms_output.put_line('				  R12.ATG_PF.A.delta.6<br></div>');
				  :issuep:=1;
				  :w1:=:w1+1;
            end if;   
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
            
            if v_exists=0 then
                    dbms_output.put_line('<div class="diverr">');
					dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font> No ATG RUP patch applied!<br><br>');
                    dbms_output.put_line('Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=6241631">Patch 6241631</a> ');
					dbms_output.put_line('11i.ATG_PF.H RUP7</div><br>');
					:issuep:=1;
					:e1:=:e1+1;
            else        
                    select max(to_number(bug_number)) into atg_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
                    if atg_level='6241631' then
                          
                          dbms_output.put_line('Actual level: Patch 6241631 11i.ATG_PF.H RUP7<br><br>');                          
                          dbms_output.put_line('<font color="blue">Advice: </font> Ensure you applied patches to fix known issues (note periodically updated): ');
                          dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=858801.1" target="_blank"> Note 858801.1</a> ');
                          dbms_output.put_line('Known Issues On Top of 11i.atg_pf.h.delta.7 (RUP7) - 6241631');                    
                          
                    else
                          SELECT DECODE(BUG_NUMBER
                         , '3438354', '11i.ATG_PF.H'
                         , '4017300', '11i.ATG_PF.H RUP1'
                         , '4125550', '11i.ATG_PF.H RUP2'
                         , '4334965', '11i.ATG_PF.H RUP3'
                         , '4676589', '11i.ATG_PF.H RUP4'
                         , '5473858', '11i.ATG_PF.H RUP5'
                         , '5903765', '11i.ATG_PF.H RUP6'
                         , '6241631', '11i.ATG_PF.H RUP7')
                        , LAST_UPDATE_DATE  
                          into atg_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =atg_level and rownum < 2;
                          
                          dbms_output.put_line('Actual level: Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '<br><br>');
                          dbms_output.put_line('<div class="divwarn">');
                          dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=6241631">');
						  dbms_output.put_line('Patch 6241631</a> 11i.ATG_PF.H RUP7<br></div>');
						  :issuep:=1;
						  :w1:=:w1+1;
       
                    end if;                   
            end if;   
      end if;
      dbms_output.put_line('</td></tr>');
end;
/

-- Display hrglobal information
declare
    v_exists number;
    v_hrglobal_date ad_patch_runs.end_date%type;
	v_action ad_patch_runs.end_date%type;
    v_hrglobal_patch_opt ad_patch_runs.PATCH_ACTION_OPTIONS%type;
    v_hrglobal_patch ad_applied_patches.patch_name%type;
begin
      
      dbms_output.put_line(' <TR><td><a name="hrglobal"></a>Hrglobal</td><td>');
      
      if   :apps_rel like '12%' then
            SELECT count(1) into v_exists
            FROM ad_patch_runs pr
            WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
              AND pr.SUCCESS_FLAG = 'Y'
              AND pr.end_date =(
               SELECT MAX(pr.end_date)
               FROM ad_patch_runs pr
               WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
                 AND pr.SUCCESS_FLAG = 'Y');
      else
            SELECT count(1) into v_exists
            FROM ad_patch_runs pr
            WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
              AND pr.SUCCESS_FLAG = 'Y'
              AND pr.end_date =(
               SELECT MAX(pr.end_date)
               FROM ad_patch_runs pr
               WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
                 AND pr.SUCCESS_FLAG = 'Y');
      end if;
      
      if v_exists>0 then
              if   :apps_rel like '12%' then
					  SELECT pr.end_date 
						   , pr.PATCH_ACTION_OPTIONS 
					  into v_hrglobal_date, v_hrglobal_patch_opt 
					  FROM ad_patch_runs pr
					  WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
						AND pr.SUCCESS_FLAG = 'Y'
						AND pr.end_date =(
						 SELECT MAX(pr.end_date)
						 FROM ad_patch_runs pr
						 WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
						   AND pr.SUCCESS_FLAG = 'Y');
			else
						SELECT pr.end_date 
						   , pr.PATCH_ACTION_OPTIONS 
					  into v_hrglobal_date, v_hrglobal_patch_opt 
						FROM ad_patch_runs pr
						WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
						  AND pr.SUCCESS_FLAG = 'Y'
						  AND pr.end_date =(
						   SELECT MAX(pr.end_date)
						   FROM ad_patch_runs pr
						   WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
							 AND pr.SUCCESS_FLAG = 'Y');
			end if;	 
				 
              select ap.patch_name  patchnumber into v_hrglobal_patch
                    from ad_applied_patches ap
                       , ad_patch_drivers pd
                       , ad_patch_runs pr
                       , ad_patch_run_bugs prb
                       , ad_patch_run_bug_actions prba
                       , ad_files f
                    where f.file_id                  = prba.file_id
                      and prba.executed_flag         = 'Y'
                      and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                      and prb.patch_run_id           = pr.patch_run_id
                      and pr.patch_driver_id         = pd.patch_driver_id
                      and pd.applied_patch_id        = ap.applied_patch_id
                      and f.filename = 'hrglobal.drv'
                      and pr.end_date = (select max(pr.end_date)
                                                 from ad_applied_patches ap
                                                    , ad_patch_drivers pd
                                                    , ad_patch_runs pr
                                                    , ad_patch_run_bugs prb
                                                    , ad_patch_run_bug_actions prba
                                                    , ad_files f
                                                  where f.file_id                  = prba.file_id
                                                    and prba.executed_flag         = 'Y'
                                                    and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                    and prb.patch_run_id           = pr.patch_run_id
                                                    and pr.patch_driver_id         = pd.patch_driver_id
                                                    and pd.applied_patch_id        = ap.applied_patch_id
                                                    and f.filename = 'hrglobal.drv');

                dbms_output.put_line('<br><br>Your date of last successful run of hrglobal.drv was with patch '||v_hrglobal_patch|| ' ' || v_hrglobal_patch_opt ||' on ' || v_hrglobal_date   ||'<br><br>' );
				
				if v_hrglobal_date<:v_rup_date then
					dbms_output.put_line('<div class="divwarn">');
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You did not performed hrglobal after last HRMS RUP applied!</div><br>');
					:issuep:=1;
					:w1:=:w1+1;
				else
					dbms_output.put_line('<img class="check_ico">OK! You performed hrglobal after HRMS RUP.<br><br>');
				end if;
				
				select  max( last_update_date) into v_action  from hr_legislation_installations  where (status is not null or action is not null) ;
				dbms_output.put_line('Last time performed DataInstal on ' || v_action   ||'<br><br>' );
				if v_hrglobal_date<v_action then
					dbms_output.put_line('<div class="divwarn">');
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning:</font> You did not performed hrglobal after running DataInstall!</div><br><br>');
					:issuep:=1;
					:w1:=:w1+1;
				else
					dbms_output.put_line('<img class="check_ico">OK! You performed hrglobal after running DataInstall.<br><br>');
				end if;
				
                dbms_output.put_line(' To identify the version please run: strings -a $PER_TOP/patch/115/driver/hrglobal.drv | grep Header <br><br>');
                dbms_output.put_line('<font color="blue">Advice: </font> Please periodically review (note periodically updated): ');
				if   :apps_rel like '12.2%' then
					dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1469456.1" target="_blank"> Note 1469456.1</a> ');
					dbms_output.put_line('DATAINSTALL AND HRGLOBAL APPLICATION: 12.2 SPECIFICS<br>'); 
				else
					dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=145837.1" target="_blank"> Note 145837.1</a> ');
					dbms_output.put_line('Latest Oracle HRMS Legislative Data Patch Available (HR Global / hrglobal)<br>');
				end if;
      end if;

end;
/

-- Display Data Installed issues
declare
    v_exists number;
    v_leg_code varchar2(7);
    v_apps hr_legislation_installations.application_short_name%type;
    v_action hr_legislation_installations.action%type;
    cursor datainstaller_actions is
          select decode(hli.legislation_code
                   ,null,'global'
                   ,hli.legislation_code) 
           , hli.application_short_name                  
           , hli.action                                 
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name
      order by legislation_code desc, application_short_name asc;

begin      
      
      select count(1) into v_exists
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name;
      
      if v_exists>0 then
                                  :w1:=:w1+1;
								  dbms_output.put_line('<br><A class=detail onclick="displayItem(this,''s1sql36'');" href="javascript:;"><font size="+0.5">&#9654; DataInstaller Actions</font></A>');
                                
                                  dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql36" style="display:none" >');
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('     <B>DataInstaller actions:</B></font></TD>');
                                  dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                                  dbms_output.put_line('<A class=detail id="s1sql37b" style="width:220px" onclick="displayItem2(this,''s1sql37'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  dbms_output.put_line('   </TD>');
                                  dbms_output.put_line(' </TR>');
                                  dbms_output.put_line(' <TR id="s1sql37" style="display:none">');
                                  dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                                  dbms_output.put_line('       <blockquote><p align="left">');
                                  dbms_output.put_line('          select decode(hli.legislation_code <br>');   
                                  dbms_output.put_line('                   ,null,''global''<br>');
                                  dbms_output.put_line('                   ,hli.legislation_code) <br>');           
                                  dbms_output.put_line('           , hli.application_short_name <br>');   
                                  dbms_output.put_line('           , hli.action<br>');                  
                                  dbms_output.put_line('      from user_views uv<br>');
                                  dbms_output.put_line('         , hr_legislation_installations hli<br>');
                                  dbms_output.put_line('      where uv.view_name in (select view_name from hr_legislation_installations)<br>');
                                  dbms_output.put_line('      and uv.view_name = hli.view_name<br>');
                                  dbms_output.put_line('      order by legislation_code desc, application_short_name asc;<br>');
                                  dbms_output.put_line('          </blockquote><br>');
                                  dbms_output.put_line('     </TD>');
                                  dbms_output.put_line('   </TR>');
                                  dbms_output.put_line(' <TR>');
                                  dbms_output.put_line(' <TH><B>Legislation Code</B></TD>');
                                  dbms_output.put_line(' <TH><B>Application Name</B></TD>');
                                  dbms_output.put_line(' <TH><B>Action</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open datainstaller_actions;
                                  loop
                                        fetch datainstaller_actions into  v_leg_code,v_apps ,v_action;
                                        EXIT WHEN  datainstaller_actions%NOTFOUND;
                                        dbms_output.put_line('<TR><TD>'||v_leg_code||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD></TR>'||chr(10));
                                  end loop;
                                  close datainstaller_actions;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  dbms_output.put_line(' </TABLE>');
                                  
                                  dbms_output.put_line('<div class="diverr">');
								  dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> You have legislations currently selected for install by the DataInstall.');
                                  dbms_output.put_line(' Please resolve hrglobal issues ');
								  dbms_output.put_line('in order to install/upgrade all legislative data selected during DataInstaller.<br>');
                                  dbms_output.put_line('Please review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=140511.1" target="_blank" >Note 140511.1</a> ');
								  dbms_output.put_line('How to Install HRMS Legislative Data Using Data Installer and hrglobal.drv</div><br><br>');
								  :issuep:=1;
								  :e1:=:e1+1;
								  
         end if;                                      
end;
/

-- Display Statutory Exceptions
declare

    cursor statutory is
    select table_name
           , surrogate_id 
           , true_key
           , exception_text
      from hr_stu_exceptions;
    v_table_name hr_stu_exceptions.table_name%type;
    v_surrogate_id hr_stu_exceptions.surrogate_id%type;
    v_true_key hr_stu_exceptions.true_key%type;
    v_exception_text hr_stu_exceptions.exception_text%type;
    v_exists number;
    
begin    
      select count(1) into v_exists
					  from hr_stu_exceptions;        
     
      if v_exists>0 then
                                  :w1:=:w1+1;
								  dbms_output.put_line('<A class=detail onclick="displayItem(this,''s1sql38'');" href="javascript:;"><font size="+0.5">&#9654; Statutory Exceptions</font></A>');
                                
                                  dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql38" style="display:none" >');
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('     <B>Statutory exceptions:</B></font></TD>');
                                  dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
                                  dbms_output.put_line('<A class=detail id="s1sql39b" style="width:220px" onclick="displayItem2(this,''s1sql39'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  dbms_output.put_line('   </TD>');
                                  dbms_output.put_line(' </TR>');
                                  dbms_output.put_line(' <TR id="s1sql39" style="display:none">');
                                  dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="4" height="60">');
                                  dbms_output.put_line('       <blockquote><p align="left">');
                                  dbms_output.put_line('          select table_name <br>');                                     
                                  dbms_output.put_line('           , to_char(surrogate_id) surrogate_id<br>'); 
                                  dbms_output.put_line('           , true_key<br>'); 
                                  dbms_output.put_line('           , exception_text<br>'); 
                                  dbms_output.put_line('            from hr_stu_exceptions;<br>'); 
                                  dbms_output.put_line('          </blockquote><br>');
                                  dbms_output.put_line('     </TD>');
                                  dbms_output.put_line('   </TR>');
                                  dbms_output.put_line(' <TR>');
                                  dbms_output.put_line(' <TH><B>Table name</B></TD>');
                                  dbms_output.put_line(' <TH><B>Surrogate ID</B></TD>');
                                  dbms_output.put_line(' <TH><B>True key</B></TD>');
                                  dbms_output.put_line(' <TH><B>Exception</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open statutory;
                                  loop
                                        fetch statutory into  v_table_name , v_surrogate_id , v_true_key , v_exception_text;
                                        EXIT WHEN  statutory%NOTFOUND;
                                        dbms_output.put_line('<TR><TD>'||v_table_name||'</TD>'||chr(10)||'<TD>'||v_surrogate_id||'</TD>'||chr(10)||'<TD>');
										dbms_output.put_line(v_true_key||'</TD>'||chr(10)||'<TD>');
                                        dbms_output.put_line(v_exception_text);
                                        dbms_output.put_line('</TD></TR>'||chr(10));
                                  end loop;
                                  close statutory;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  dbms_output.put_line(' <TH COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri">');
                                  dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  dbms_output.put_line(' </TABLE> ');
                                  
                                   dbms_output.put_line('<div class="diverr">');
								  dbms_output.put_line('<img class="error_ico"><font color="red">Error:</font> You have statutory exceptions. ');
                                  dbms_output.put_line('In order to solve please review:<br>');
                                  dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=101351.1" target="_blank" >Note 101351.1</a> ');
								  dbms_output.put_line('HRGLOBAL.DRV:DIAGNOSING PROBLEMS WITH LEGISLATIVE UPDATES - HR_LEGISLATION.INSTALL</div>');
								  :issuep:=1;
								  :e1:=:e1+1;
                                  
                                 
         end if;  

      dbms_output.put_line('</td></tr>');
      
      
      
          
end;
/


	
-- Display baseline patching status
declare
  v_status varchar2(5);
  no_rows number;
  v_exists number;
  issue boolean:=FALSE;
 -- Display patch
procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;	  
	  v_exists number;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								 --issue:=TRUE;
								 :issuep:=1;
								 :e1:=:e1+1;
								 dbms_output.put_line('<div class="diverr">');
								 dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>Please plan to install ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');	
								 dbms_output.put_line('</div>');
							else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							dbms_output.put_line('Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'<br>');
							
						end if;
	end; 
 

begin
    
    if :apps_rel like '11.5%' or :apps_rel like '12.0%' then
		dbms_output.put_line(' <TR><td>Baseline patches</td><td>');
		if :apps_rel like '11.5%' then		  
          dpatch('5903765','11i.ATG_PF.H.delta.6');         
		  dpatch('6699770',' - baseline patch for PER, BEN, PSP, IRC, Self Service');
          select count(1) into no_rows from fnd_product_installations where status='I' and application_id in (801, 8301) ;
          if no_rows>0 then
                dpatch('7666111',' - baseline patch for PAY, GHR');				
          end if;    
		  
         
              dbms_output.put_line('<font color="blue">Advice: </font> Please review ');
              dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1199724.1" target="_blank">Note 1199724.1</a> ');
			  dbms_output.put_line('- E-Business Suite 11.5.10 Minimum Patch Level and Extended Support Information Center<br>');
          
		elsif :apps_rel like '12.0%' then
			  dpatch('7004477','R12.HR_PF.A.delta.6 (Minimum baseline)');
			  dpatch('9301208','R12.HR_PF.A.delta.8 (Minimum baseline for legislation tax year end/begin schedule must be applied as a prereq before processing the legislative Year End (Note 135266.1))');
			 
			  dbms_output.put_line('<font color="blue">Advice: </font> Please review ');
              dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1334562.1" target="_blank">Note 1334562.1</a> ');
			  dbms_output.put_line('- Minimum Patch Requirements for Extended Support of Oracle E-Business Suite Human Capital Management (HCM) Release 12.0<br>');
		end if;
		
	dbms_output.put_line('</td></tr>');
	end if;    
  
end;
/

-- Display performance patches advices
declare
begin
     dbms_output.put_line(' <TR><td><a name="perf"></a>Performance</td><td>');
    dbms_output.put_line('<font color="blue">Advice: </font> For performance patches please periodically review: ');
    dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=244040.1" target="_blank">Note 244040.1</a> - ');
	dbms_output.put_line('Oracle E-Business Suite Recommended Performance Patches<br>');

    dbms_output.put_line('<DIV align="center"><A class=detail onclick="displayItem(this,''s1sql45'');" href="javascript:;">&#9654; How to check database patches</A></DIV>'); 
    dbms_output.put_line(' <TABLE align="center" border="1" cellspacing="0" cellpadding="2" id="s1sql45" style="display:none" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH align="left" COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line(' <blockquote>-	cd RDBMS_ORACLE_HOME<br>');
    dbms_output.put_line('-	. ./SID_hostname.env<br>');
    dbms_output.put_line('-	export PATH=$ORACLE_HOME/OPatch:$PATH<br>');
    dbms_output.put_line('-	opatch lsinventory<br>');
    dbms_output.put_line('-	Compare results with the patches from ');
	dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=244040.1" target="_blank">Note 244040.1</a> - ');
	dbms_output.put_line('Oracle E-Business Suite Recommended Performance Patches<br>');
	dbms_output.put_line('</blockquote>');
    dbms_output.put_line(' </TD><TR></TABLE>'); 
                                  
    
   dbms_output.put_line('</td></tr>');   
  
  dbms_output.put_line(' </TABLE> <br> ');
  
 if :issuep=1 then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Please review patching section ');
		dbms_output.put_line('as you have warning(s) reported. ');
		dbms_output.put_line('</div>');
  end if; 
  
  dbms_output.put_line('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
  dbms_output.put_line('</div>');
  
  dbms_output.put_line('</div>');
end;
/



declare
v_exists number;
 -- Display patch
procedure dpatch (v_leg varchar2, v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;	  
	  v_exists number;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								 case v_leg
									when  'AU' then
										:e2:=:e2+1;
									when 'BE' then 
										:e3:=:e3+1;
									when 'CA' then 	
										:e4:=:e4+1;
									when 'CN' then 
										:e5:=:e5+1;
									when 'ES' then
										:e6:=:e6+1;
									when 'DE' then 
										:e7:=:e7+1;
									when 'DK' then
										:e8:=:e8+1;
									when 'FI' then 
										:e9:=:e9+1;
									when 'FR' then 
										:e10:=:e10+1;
									when 'HK' then 	
										:e11:=:e11+1;
									when 'HU' then 
										:e12:=:e12+1;
									when 'IE' then 
										:e13:=:e13+1;
									when 'IN' then 
										:e14:=:e14+1;
									when 'IT' then 
										:e15:=:e15+1;
									when 'JP' then
										:e16:=:e16+1;
									when 'KR' then
										:e17:=:e17+1;
									when 'KW' then
										:e18:=:e18+1;
									when 'MX' then 
										:e19:=:e19+1;
									when 'NL' then 
										:e20:=:e20+1;
									when 'NO' then 
										:e21:=:e21+1;
									when 'NZ' then
										:e22:=:e22+1;
									when 'PL' then 
										:e23:=:e23+1;
									when 'RU' then
										:e24:=:e24+1;
									when 'SA' then 
										:e25:=:e25+1;									
									when 'SE' then 
										:e26:=:e26+1;
									when 'SG' then
										:e27:=:e27+1;
									when 'AE' then 	
										:e28:=:e28+1;
									when 'GB' then 
										:e29:=:e29+1;
									when 'US' then
										:e30:=:e30+1;
									when 'ZA' then
										:e31:=:e31+1;
									else
									null;
								end case;
								
								 dbms_output.put_line('<div class="diverr">');
								 dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>Please plan to install ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');	
								 dbms_output.put_line('</div>');
							else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							dbms_output.put_line('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
						EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
	end; 

procedure documents (v_no1 varchar2, v_note1 varchar2, v_no2 varchar2, v_note2 varchar2) is
begin
			dbms_output.put_line('<br><div class="divok">');
			dbms_output.put_line('Useful documentation:<br>');
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');			
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no2||'" target="_blank">Note '||v_no2||'</a> '||v_note2||'<br>');
			dbms_output.put_line('</div>');
end;
procedure documents (v_no1 varchar2, v_note1 varchar2) is
begin
			dbms_output.put_line('<br><div class="divok">');
			dbms_output.put_line('Useful documentation:<br>');
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');
			dbms_output.put_line('</div>');
end;

procedure bg_generic (v_leg varchar2, v_no number) is
	  v_bg hr_all_organization_units.organization_id%type;
	  v_name hr_all_organization_UNITS.NAME%type;	  
	  v_cur PER_BUSINESS_GROUPS.CURRENCY_CODE%type;
	  v_enabled PER_BUSINESS_GROUPS.ENABLED_FLAG%type;
	  v_date_from varchar2(15);
	  v_date_to varchar2(15);
	  v_hr varchar2(3);
	cursor c_bg (v_legislation varchar2)  is
			SELECT otl.name,o.organization_id,o3.ORG_INFORMATION10 currency_code,o4.ORG_INFORMATION2 enabled_flag ,to_char(o.date_from, 'DD-MON-YYYY') ,to_char(o.date_to, 'DD-MON-YYYY')
			FROM hr_all_organization_UNITS O , 
			hr_all_organization_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			and o3.ORG_INFORMATION9=v_legislation
			order by o.organization_id;
	v_short_name hr_organization_information.org_information1%type;			
			v_employee_number_generation fnd_lookups.meaning%type;
			v_applicant_number_generation fnd_lookups.meaning%type;
			v_contingent_worker_numb_gen fnd_lookups.meaning%type;
			v_grade_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_group_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_job_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_costing_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_position_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_competence_flex fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_currency hr_organization_information.org_information1%type;
			v_fiscal_year_start hr_organization_information.org_information1%type;
			v_minimum_working_age hr_organization_information.org_information1%type;
			v_maximum_working_age hr_organization_information.org_information1%type;
					
	
	v_lookup1 fnd_lookups.meaning%type;
	v_lookup2 fnd_lookups.meaning%type;
	v_lookup3 fnd_lookups.meaning%type;
	v_lookup4 fnd_lookups.meaning%type;	
	v_lookup9 fnd_lookups.meaning%type;
	v_lookup5 fnd_lookups.meaning%type;	
	v_lookup6 fnd_lookups.meaning%type;	
	v_lookup7 fnd_lookups.meaning%type;
	v_lookup8 fnd_lookups.meaning%type;
		
	
	cursor c_payroll (t_bg  NUMBER) is
				SELECT   prl.payroll_name
				,prl.period_type
				,prl.first_period_end_date
				,prl.number_of_years
				,prl.period_reset_years
				,prl.pay_date_offset
				,prl.direct_deposit_date_offset
				,prl.pay_advice_date_offset
				,prl.cut_off_date_offset
				,nvl (opm.org_payment_method_name, 'No Default Payment Method Set') default_payment_method
				,con.consolidation_set_name consolidation_set
				,prl.workload_shifting_level
				,prl.arrears_flag
				,prl.negative_pay_allowed_flag
				,prl.multi_assignments_flag
				,prl.prl_information1				
				,prl.prl_information21 days_after_period_start
				,prl.prl_information22 days_after_period_end
				,hr_general_utilities.get_lookup_meaning('MODELER_AVAILABLITY',prl.prl_information20)  modeling_availability_rule
				,prl.payroll_id
				,prl.default_payment_method_id default_payment_method_id				
		FROM     pay_all_payrolls_f prl
				,pay_org_payment_methods_f opm
				,pay_consolidation_sets con
				,hr_all_organization_units org				
				,per_time_period_types tpt
				,per_time_period_rules tpr
		WHERE    1 = 1
			 AND con.consolidation_set_id = prl.consolidation_set_id
			 AND opm.org_payment_method_id(+) = prl.default_payment_method_id
			 AND org.organization_id(+) = prl.organization_id			
			 AND tpt.period_type = prl.period_type
			 AND tpr.number_per_fiscal_year = tpt.number_per_fiscal_year
			 AND sysdate BETWEEN prl.effective_start_date AND prl.effective_end_date
			 AND prl.business_group_id = t_bg
			 order by 1;
	v_payroll_name pay_all_payrolls_f.payroll_name%type;
	v_period_type pay_all_payrolls_f.period_type%type;
	v_first_date pay_all_payrolls_f.first_period_end_date%type;
	v_number_of_years pay_all_payrolls_f.number_of_years%type;
	v_period_reset_years pay_all_payrolls_f.period_reset_years%type;
	v_pay_date_offset pay_all_payrolls_f.pay_date_offset%type;
	v_direct_deposit pay_all_payrolls_f.direct_deposit_date_offset%type;
	v_pay_advice_date_offset pay_all_payrolls_f.pay_advice_date_offset%type;
	v_cut_off_date pay_all_payrolls_f.cut_off_date_offset%type;
	v_default_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_consolidation pay_consolidation_sets.consolidation_set_name%type;
	v_workload_shifting pay_all_payrolls_f.workload_shifting_level%type;
	v_arrears_flag pay_all_payrolls_f.arrears_flag%type;
	v_negative_pay pay_all_payrolls_f.negative_pay_allowed_flag%type;
	v_multi_assignments pay_all_payrolls_f.multi_assignments_flag%type;
	v_legal_employer hr_all_organization_units.name%type;
	v_prl_information21 pay_all_payrolls_f.prl_information21%type;
	v_prl_information22 pay_all_payrolls_f.prl_information22%type;
	v_modeling_availability fnd_lookups.meaning%type;
	
	v_seg2 pay_external_accounts.segment2%type;
	v_seg3 pay_external_accounts.segment3%type;
	v_seg5 pay_external_accounts.segment5%type;
	v_seg6 pay_external_accounts.segment6%type;
	v_seg7 pay_external_accounts.segment7%type;
	v_seg10 pay_external_accounts.segment10%type;
	
	cursor c_org_pay (t_id  NUMBER) is
		SELECT   hr_general_utilities.get_lookup_meaning('PER_EU_COUNTRIES',pea.territory_code) country
				,hr_general_utilities.get_lookup_meaning ('HR_NL_BANK', pea.segment1)  bank_name
				,segment2 account_number
				,segment3 postal_code
				,hr_general_utilities.get_lookup_meaning ('HR_NL_CITY', pea.segment4)  city
				,segment5 street
				,segment6 telephone_number
				,segment7 telephone_extension
				,hr_general_utilities.get_lookup_meaning('HR_NL_BIC_CODES',pea.segment9) bank_identifier_code
				,segment10 iban_number
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_payment) cost_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_payment) cost_cleared_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_void_payment) cost_cleared_void_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.exclude_manual_payment) exclude_manual_payment
		FROM     pay_external_accounts pea, (SELECT   org_payment_method_id
													 ,external_account_id
													 ,business_group_id
													 ,cost_payment
													 ,cost_cleared_payment
													 ,cost_cleared_void_payment
													 ,exclude_manual_payment
													 ,effective_start_date
													 ,effective_end_date
											 FROM     pay_org_payment_methods_f) popm
		WHERE    1 = 1
			 AND pea.external_account_id = popm.external_account_id
			 AND popm.org_payment_method_id = t_id
			 AND sysdate BETWEEN effective_start_date AND effective_end_date;
			 
	cursor c_Organizational (t_pid  NUMBER, t_dpmid NUMBER) is
			SELECT   opm.org_payment_method_name org_paymentmethod_name
				,pt.payment_type_name payment_type
				,CASE
				   WHEN opu.org_payment_method_id = t_dpmid
				   THEN
					 'Yes'
				   ELSE
					 'No'
				 END default_payment_method
				,opu.effective_start_date
				,opu.effective_end_date
				,opu.org_payment_method_id
				,pt.payment_type_id
		FROM     pay_org_pay_method_usages_f opu
				,pay_org_payment_methods_f opm
				,pay_payment_types pt
		WHERE    1 = 1
			 AND opm.org_payment_method_id = opu.org_payment_method_id
			 AND pt.payment_type_id = opm.payment_type_id
			 AND sysdate between opm.effective_start_date and opm.effective_end_date
			 AND sysdate between opu.effective_start_date and opu.effective_end_date
			 AND opu.payroll_id = t_pid
			 order by 1;
	
	v_payroll_id pay_org_pay_method_usages_f.payroll_id%type;
	v_org_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_payment_type_name pay_payment_types.payment_type_name%type;
	v_default_payment_method_id pay_all_payrolls_f.default_payment_method_id%type;
	v_default_payment_method varchar2(10);
	v_effective_start_date pay_org_pay_method_usages_f.effective_start_date%type;
	v_effective_end_date pay_org_pay_method_usages_f.effective_end_date%type;
	v_org_payment_method_id pay_org_pay_method_usages_f.org_payment_method_id%type;
	v_payment_type_id pay_payment_types.payment_type_id%type;
	
   v_id_flex FND_ID_FLEX_STRUCTURES_TL.ID_FLEX_NUM%type;
	v_code varchar2(30);
	v_cos_name varchar2(30);
	v_description varchar2(30);
	v_freeze varchar2(10);
	v_cos_enabled varchar2(10);
	v_dynamic varchar2(10);
	cursor c_costing (t_bg  NUMBER) is
		SELECT t.ID_FLEX_NUM,substrb(b.ID_FLEX_STRUCTURE_CODE,1,25) Code,
		   substrb(t.ID_FLEX_STRUCTURE_NAME,1,25) Name,
		   substrb(t.DESCRIPTION,1,25) Description,
		   lpad(substr(FREEZE_FLEX_DEFINITION_FLAG,1,8),8) Frz,
		   lpad(substr(ENABLED_FLAG,1,8),8) Enable,
		   lpad(substr(DYNAMIC_INSERTS_ALLOWED_FLAG,1,9),9) Dynamic
	FROM FND_ID_FLEX_STRUCTURES b, FND_ID_FLEX_STRUCTURES_TL t
	WHERE (t.APPLICATION_ID=801) 
		and t.language='US'
		and b.ID_FLEX_CODE=t.ID_FLEX_CODE and b.ID_FLEX_NUM=t.ID_FLEX_NUM and
		  (t.ID_FLEX_CODE='COST')
		  and
		  (t.ID_FLEX_NUM = (select cost_allocation_structure
				  from per_business_groups
				  where business_group_id = t_bg))
	order by t.application_id, t.id_flex_code, t.id_flex_structure_name;

	v_segment varchar2(30);
	v_column varchar2(15);
	v_seg_number FND_ID_FLEX_SEGMENTS.SEGMENT_NUM%type;
	v_display varchar2(10);
	v_required varchar2(10);
	v_security varchar2(10);
	v_cos_enabled2 varchar2(10);
	
	
	cursor c_costing_segments (t_flex  NUMBER) is
	SELECT substrb(SEGMENT_NAME,1,25) Name,
		   substrb(DESCRIPTION,1,25) Description,
		   substr(ENABLED_FLAG,1,3) Enabled,
		   substr(t.APPLICATION_COLUMN_NAME,1,10) Col_Name,
		   SEGMENT_NUM Seg_No,
		   lpad(substr(DISPLAY_FLAG,1,5),5) Disp,
		   lpad(substr(REQUIRED_FLAG,1,5),5) Reqd,
		   lpad(substr(SECURITY_ENABLED_FLAG,1,5),5) Secr
	FROM FND_ID_FLEX_SEGMENTS_TL T, FND_ID_FLEX_SEGMENTS B
	WHERE (t.APPLICATION_ID=801) 
		and t.language='US' 
	   and b.ID_FLEX_NUM = t_flex 
	   and b.ID_FLEX_CODE=t.ID_FLEX_CODE and b.ID_FLEX_NUM=t.ID_FLEX_NUM and  B.APPLICATION_COLUMN_NAME = T.APPLICATION_COLUMN_NAME and
		   (b.ID_FLEX_CODE='COST') and 
		   (b.APPLICATION_ID=801) 
	order by t.application_id, t.id_flex_code, t.id_flex_num, decode(b.enabled_flag, 'Y', 1, 'N', 2), b.segment_num;

	
	
	v_cost varchar2(30);
	v_atr varchar2(15);
	cursor c_costing_qualifiers (t_flex  NUMBER, t_seg NUMBER) is	
	SELECT substrb(FSAV.SEGMENT_ATTRIBUTE_TYPE,1,20) Cost_Level,
		   lpad(substr(FSAV.ATTRIBUTE_VALUE,1,10),10) Visible
	FROM FND_SEGMENT_ATTRIBUTE_VALUES FSAV, FND_ID_FLEX_SEGMENTS FIFS, FND_ID_FLEX_SEGMENTS_TL T
	WHERE 
	FIFS.APPLICATION_ID = T.APPLICATION_ID and FIFS.ID_FLEX_CODE = T.ID_FLEX_CODE and
	FIFS.ID_FLEX_NUM = T.ID_FLEX_NUM and FIFS.APPLICATION_COLUMN_NAME = T.APPLICATION_COLUMN_NAME and T.LANGUAGE = 'US' and
	EXISTS (SELECT NULL 
				  FROM FND_SEGMENT_ATTRIBUTE_TYPES T 
				  WHERE T.APPLICATION_ID =  FSAV.APPLICATION_ID AND 
						T.ID_FLEX_CODE =  FSAV.ID_FLEX_CODE AND 
						T.SEGMENT_ATTRIBUTE_TYPE =  FSAV.SEGMENT_ATTRIBUTE_TYPE AND 
						GLOBAL_FLAG = 'N') and
		   (FSAV.ID_FLEX_NUM = t_flex) and (FIFS.SEGMENT_NUM = t_seg) and
		   (FSAV.APPLICATION_COLUMN_NAME = FIFS.APPLICATION_COLUMN_NAME) and
		   (FSAV.ID_FLEX_CODE='COST') and 
		   (FSAV.APPLICATION_ID=801) and
		   (FSAV.ID_FLEX_NUM = FIFS.ID_FLEX_NUM)
	order by FSAV.segment_attribute_type, FIFS.APPLICATION_COLUMN_NAME, FIFS.SEGMENT_NAME;
	
begin
		
	dbms_output.put_line('<br><DIV class=divItem>');
	dbms_output.put_line('<DIV  class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b"  onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Business Group Information</A></DIV>');					
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql500'||:v_link_no||'" style="display:none" >');
	:v_link_no:=:v_link_no+1;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Business Group Information:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql500'||:v_link_no||'" style="display:none">');
	:v_link_no:=:v_link_no+1;
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('SELECT    haou.name,hoi.organization_id,pbg.currency_code ,pbg.enabled_flag ,pbg.date_from ,pbg.date_to	  <br>');
						dbms_output.put_line('FROM       hr_organization_information hoi,hr_all_organization_units haou,per_business_groups pbg<br>');
						dbms_output.put_line('WHERE      hoi.organization_id = haou.organization_id<br>');
						dbms_output.put_line('AND pbg.organization_id = haou.organization_id<br>');
						dbms_output.put_line('AND hoi.org_information_context = ''Business Group Information''<br>');
						dbms_output.put_line('and pbg.legislation_code='''||v_leg||'''<br>');							
						dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
       
		
    :n := dbms_utility.get_time;
    dbms_output.put_line(' <TR>');
	dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	
		
    open c_bg(v_leg);
        loop
           fetch c_bg into v_name,v_bg,v_cur,v_enabled,v_date_from,v_date_to;					
			EXIT WHEN  c_bg%NOTFOUND;			
			dbms_output.put_line('<DIV class=divItem>');
			dbms_output.put_line('<DIV class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_bg||' - '||v_name||'</A></DIV>');
			dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
							
			dbms_output.put_line('Currency: '|| v_cur||'<br>');
			dbms_output.put_line('Enabled Flag: '|| v_enabled||'<br>');
			dbms_output.put_line('Date From: '|| v_date_from||'<br>');
			dbms_output.put_line('Date To: '|| v_date_to||'<br>');
		
			SELECT   org_information1 short_name					
					,hr_general_utilities.get_lookup_meaning('EMP_NUM_GEN_METHOD',org_information2) employee_number_generation
					,hr_general_utilities.get_lookup_meaning('APL_NUM_GEN_METHOD',org_information3) applicant_number_generation
					,hr_general_utilities.get_lookup_meaning('CWK_NUM_GEN_METHOD',org_information16) contingent_worker_numb_gen
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information4
							AND id_flex_code = 'GRD')       grade_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information5
							AND id_flex_code = 'GRP')        group_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information6
							AND id_flex_code = 'JOB')        job_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information7
							AND id_flex_code = 'COST')       costing_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information8
							AND id_flex_code = 'POS')        position_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information15
							AND id_flex_code = 'CMP')        competence_flexfield_structure
					,org_information10 currency
					,org_information11 fiscal_year_start
					,org_information12 minimum_working_age
					,org_information13 maximum_working_age
					into v_short_name,v_employee_number_generation,v_applicant_number_generation,v_contingent_worker_numb_gen, v_grade_flexfield_structure,v_group_flexfield_structure,v_job_flexfield_structure,v_costing_flexfield_structure,v_position_flexfield_structure,v_competence_flex,v_currency,v_fiscal_year_start,v_minimum_working_age,v_maximum_working_age
					FROM     hr_organization_information hoi
							, (SELECT   name, organization_id FROM hr_all_organization_units)
							 hou_bg
					WHERE    1 = 1
						 AND hoi.organization_id = hou_bg.organization_id
						 AND hoi.org_information_context LIKE 'Business Group Information'
						 AND hoi.org_information9 = v_leg
						 AND hou_bg.organization_id = v_bg 
						 AND	 rownum < 2;
						 
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Business Group Info Setup</A>');
			dbms_output.put_line('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;
			dbms_output.put_line('<tr><th>Organization Short Name</th><th>Employee Number Generation</th><th>Applicant Number Generation</th>');
			dbms_output.put_line('<th>Contingent Worker Numb Gen</th><th>Grade Flexfield Structure</th><th>Group Flexfield Structure</th>');
			dbms_output.put_line('<th>Job Flexfield Structure</th><th>Costing Flexfield Structure</th><th>Position Flexfield Structure</th><th>Competence Flexfield Structure</th>');
			dbms_output.put_line('<th>Currency</th><th>Fiscal Year Start</th><th>Minimum Working Age</th>');
			dbms_output.put_line('<th>Maximum Working Age</th></tr>');
		
			dbms_output.put_line('<TR><TD>'||v_short_name||'</TD>'||chr(10)||'<TD>'||v_employee_number_generation||'</TD>'||chr(10)||'<TD>'||v_applicant_number_generation||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_contingent_worker_numb_gen||'</TD>'||chr(10)||'<TD>'||v_grade_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_group_flexfield_structure||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_job_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_costing_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_position_flexfield_structure||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_competence_flex||'</TD>'||chr(10)||'<TD>'||v_currency||'</TD>'||chr(10)||'<TD>'||v_fiscal_year_start||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_minimum_working_age||'</TD>'||chr(10)||'<TD>'||v_maximum_working_age||'</TD></TR>'||chr(10));
			dbms_output.put_line('</table><br>');					  
								  
		
	
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;General Payroll Information</A>');
			dbms_output.put_line('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			dbms_output.put_line('<tr><th>Payroll Name</th><th>Period Type</th><th>First Period End Date</th><th>Number of Years</th><th>Period Reset Years</th>');
			dbms_output.put_line('<th>Pay Date Offset</th><th>Direct Deposit Date Offset</th>');
			dbms_output.put_line('<th>Pay advice date offset</th><th>Cut off date offset</th><th>Default Payment Method</th><th>Consolidation Set</th>');
			dbms_output.put_line('<th>Workload Shifting Level</th><th>Arrears Flag</th><th>Negative pay allowed flag</th><th>Multi assignments flag</th><th>Legal Employer ID</th>');
			dbms_output.put_line('<th>Modeling Availability Rule</th><th>Days after period start</th><th>Days after period end</th></tr>');
			
			
			open c_payroll(v_bg);
			loop
				  fetch c_payroll into v_payroll_name,v_period_type,v_first_date,v_number_of_years,v_period_reset_years,v_pay_date_offset,v_direct_deposit,v_pay_advice_date_offset,v_cut_off_date,v_default_payment,v_consolidation,v_workload_shifting,v_arrears_flag,v_negative_pay,v_multi_assignments,v_legal_employer,v_prl_information21,v_prl_information22,v_modeling_availability,v_payroll_id,v_default_payment_method_id;
				  EXIT WHEN  c_payroll%NOTFOUND;
				  dbms_output.put_line('<TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_payroll_name||'</A>');
					dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; Valid Organizational Payment Methods');
						dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table>');
							if v_default_payment_method_id is null then
							dbms_output.put_line('<tr><td>Default Payment Method is null</th></tr>');
							else
							dbms_output.put_line('<tr><th>Org Payment Method</th><th>Payment Type</th><th>Default Payment Method</th>');
							dbms_output.put_line('<th>Effective Start Date</th><th>Effective End Date</th><th>Org Payment Method ID</th><th>Payment Type ID</th></tr>');
							open c_Organizational(v_payroll_id,v_default_payment_method_id);
							loop
								  fetch c_Organizational into v_org_payment,v_payment_type_name,v_default_payment_method,v_effective_start_date,v_effective_end_date,v_org_payment_method_id,v_payment_type_id;
								  EXIT WHEN  c_Organizational%NOTFOUND;				  
								  dbms_output.put_line('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; '||v_org_payment||'</A>');
								  dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; Organizational payment method information');
								  dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table >');								 							  
								  dbms_output.put_line('<tr><th>Country</th><th>Bank name</th><th>Account number</th><th>Postal code</th><th>City</th><th>Street</th><th>Telephone number</th><th>');
								  dbms_output.put_line('Telephone extension</th><th>Bank identifier code</th><th>IBAN</th><th>Cost payment</th><th>Cost cleared payment</th><th>Cost cleared void payment</th><th>');
								  dbms_output.put_line('Exclude manual payment</th></tr>');
								  open c_org_pay(v_org_payment_method_id);
									loop
										  fetch c_org_pay into v_lookup1,v_lookup2,v_seg2,v_seg3, v_lookup3,v_seg5,v_seg6,v_seg7,v_lookup4,v_seg10,v_lookup9,v_lookup5,v_lookup6,v_lookup7;
										  EXIT WHEN  c_org_pay%NOTFOUND;				  
										      dbms_output.put_line('<TR><TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10)||'<TD>'||v_seg2||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg3||'</TD>'||chr(10)||'<TD>'||v_lookup3||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg5||'</TD>'||chr(10)||'<TD>'||v_seg6||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg7||'</TD>'||chr(10)||'<TD>'||v_lookup4||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg10||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10));											 
											  dbms_output.put_line('<TD>'||v_lookup7||'</TD></TR>'||chr(10));     
									end loop;
									close c_org_pay;
								dbms_output.put_line('</table><br></div>');							  
								  
								  dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_payment_type_name||'</TD>'||chr(10)||'<TD>'||v_default_payment_method||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_effective_start_date||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_effective_end_date||'</TD>'||chr(10)||'<TD>'||v_org_payment_method_id||'</TD>'||chr(10));								 
								  dbms_output.put_line('<TD>'||v_payment_type_id||'</TD></TR>'||chr(10));         
							end loop;
							close c_Organizational;
							end if;
						dbms_output.put_line('</table><br>');
						
				  dbms_output.put_line('</TD>');
				 
				  
				  dbms_output.put_line('<TD>'||v_period_type||'</TD>'||chr(10)||'<TD>'||v_first_date||'</TD>'||chr(10)||'<TD>'||v_number_of_years||'</TD>'||chr(10));
				  dbms_output.put_line('<TD>'||v_period_reset_years||'</TD>'||chr(10)||'<TD>'||v_pay_date_offset||'</TD>'||chr(10)||'<TD>'||v_direct_deposit||'</TD>'||chr(10));
				  dbms_output.put_line('<TD>'||v_pay_advice_date_offset||'</TD>'||chr(10)||'<TD>'||v_cut_off_date||'</TD>');
					dbms_output.put_line('<TD>'||v_default_payment||'</TD>'||chr(10)||'<TD>'||v_consolidation||'</TD>'||chr(10)||'<TD>'||v_workload_shifting||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_arrears_flag||'</TD>'||chr(10)||'<TD>'||v_negative_pay||'</TD>'||chr(10)||'<TD>'||v_multi_assignments||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_legal_employer||'</TD>'||chr(10)||'<TD>'||v_modeling_availability||'</TD>'||chr(10)||'<TD>'||v_prl_information21||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_prl_information22||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_payroll;
			dbms_output.put_line('</table><br><br>');			
			
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Cost Flexfield Structure and Values</A>');
			dbms_output.put_line('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			dbms_output.put_line('<tr><th>Name</th><th>ID Flex Number</th><th>Code</th><th>Description</th><th>Freeze</th>');
			dbms_output.put_line('<th>Enable</th><th>Dynamic</th></tr>');
			open c_costing(v_bg);
			loop
				  fetch c_costing into v_id_flex,v_code,v_cos_name,v_description,v_freeze,v_cos_enabled,v_dynamic;
				  EXIT WHEN  c_costing%NOTFOUND;
				  dbms_output.put_line('<TR><TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_cos_name||'</A>');
					dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; <b>Flexfield Segments Setup</b>');
						dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table>');
               						
							dbms_output.put_line('<tr><th>Segment Name</th><th>Description</th><th>Enabled</th>');
							dbms_output.put_line('<th>Application Column Name</th><th>Display</th><th>Required</th><th>Security</th></tr>');
							 
							open c_costing_segments(v_id_flex);
							loop
								  fetch c_costing_segments into v_segment,v_description,v_cos_enabled2,v_column,v_seg_number,v_display,v_required,v_security;
								  EXIT WHEN  c_costing_segments%NOTFOUND;				  
								  dbms_output.put_line('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; '||v_segment||'</A>');
								  dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; <b>Flexfield Qualifiers</b>');
								  dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table >');	   							 							  
								  dbms_output.put_line('<tr><th>Cost Level</th><th>Visible</th></tr>');
								  open c_costing_qualifiers(v_id_flex,v_seg_number);
									loop
										  fetch c_costing_qualifiers into v_cost,v_atr;
										  EXIT WHEN  c_costing_qualifiers%NOTFOUND;				  
										      dbms_output.put_line('<TR><TD>'||v_cost||'</TD>'||chr(10)||'<TD>'||v_atr||'</TD></TR>'||chr(10));     
									end loop;
									close c_costing_qualifiers;
								dbms_output.put_line('</table><br></div>');							  
								  
								  dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_cos_enabled2||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_column||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_display||'</TD>'||chr(10)||'<TD>'||v_required||'</TD>'||chr(10));								 
								  dbms_output.put_line('<TD>'||v_security||'</TD></TR>'||chr(10));         
							end loop;
							close c_costing_segments;
							
						dbms_output.put_line('</table><br>');
						
				  dbms_output.put_line('</TD>');
				 
				  dbms_output.put_line('<TD>'||v_id_flex||'</TD><TD>'||v_code||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_freeze||'</TD>'||chr(10)||'<TD>'||v_cos_enabled||'</TD>'||chr(10));				 
				  dbms_output.put_line('<TD>'||v_dynamic||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_costing;
			dbms_output.put_line('</table><br><br>');				
			
			dbms_output.put_line('</DIV>');
			dbms_output.put_line('</DIV>');        
			
        end loop;
    close c_bg;
                            
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line('</TD></TR> <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;


	
procedure datainstall (v_leg varchar2, v_no number) is
	v_exists number;
    v_apps hr_legislation_installations.application_short_name%type;
    v_action varchar2(20);
	v_date hr_legislation_installations.last_update_date%type; v_legislation hr_legislation_installations.legislation_code%type;
    cursor di_actions is
        select 
		    legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION,   
		   decode(action,'F','Force Install'
						 ,'C','Clear'
						 ,'U','Upgrade'
						 ,'I','Install') ACTION,
		   last_update_date
		from hr_legislation_installations
		where (status is not null or action is not null)
		and legislation_code = v_leg ;
	cursor rules is
		select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules
		where legislation_code = v_leg
		order by legislation_code;
	V_RULE_TYPE pay_legislation_rules.RULE_TYPE%type;
	V_RULE_MODE pay_legislation_rules.RULE_MODE%type;
begin
	dbms_output.put_line('<div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Data install status</div><br>');			
	
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>DataInstaller actions:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql200'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql200'||v_no||'" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('          select  legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION, <br>');
    dbms_output.put_line('          decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'') ACTION,<br>');
    dbms_output.put_line('           last_update_date <br>');           
    dbms_output.put_line('           from hr_legislation_installations <br>');   
    dbms_output.put_line('           where (status is not null or action is not null)<br>');                  
    dbms_output.put_line('            and legislation_code ='''||v_leg||''';<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');
    dbms_output.put_line(' <TH><B>Legislation</B></TD>'); dbms_output.put_line(' <TH><B>Application Name</B></TD>');
    dbms_output.put_line(' <TH><B>Action</B></TD>');
    dbms_output.put_line(' <TH><B>Last Update Date</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open di_actions;
        loop
            fetch di_actions into  v_legislation , v_apps, v_action, v_date;
            EXIT WHEN  di_actions%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD></TR>'||chr(10));
        end loop;
    close di_actions;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> <br> ');
	dbms_output.put_line('</div>');
	
	dbms_output.put_line('<br><div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Settings</div><br>');			
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql300'||v_no||'b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql300'||v_no||''');" href="javascript:;">&#9654; Pay Legislation Rules</A></DIV>');		
			
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql300'||v_no||'" style="display:none" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Pay Legislation Rules:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql301'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql301'||v_no||'" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('        select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules  <br>');   
    dbms_output.put_line('        order by LEGISLATION_CODE;<br>');   
    dbms_output.put_line('           where legislation_code ='''||v_leg||''';<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');    
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Legislation</B></TD>');                        
    dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Rule Type</B></TD>');
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Rule Mode</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open rules;
        loop
            fetch rules into v_legislation, v_rule_type, v_rule_mode;
            EXIT WHEN  rules%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_rule_type||'</TD>'||chr(10)||'<TD>'||v_rule_mode||'</TD></TR>'||chr(10));
        end loop;
    close rules;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
	
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;


-- Display geocode patching level
procedure geocode is
 
  v_exists number:=0;
  v_patch_date ad_bugs.LAST_UPDATE_DATE%type;
  v_status varchar2(100);
  v_last_date date;
  v_geocode_date date;
  patch varchar2(20);
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin
        
                if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
                      SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='21276246' ;
                      patch:='21276246';
                 elsif :apps_rel like '12.0%' then
					select count(1) into v_exists from ad_bugs where bug_number='19139617';
                      patch:='19139617';
				elsif :apps_rel like '11.5%' then
                      select count(1) into v_exists from ad_bugs where bug_number='21276241';
                      patch:='21276241';
                end if;
                
                if (v_exists=0) then             
                         issue1:=TRUE;
                else
                          select LAST_UPDATE_DATE  
                          into v_patch_date
                          FROM ad_bugs 
                          where bug_number=patch and rownum < 2;
                          
                          select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%';
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),upper('Completed Normal'))=0 then								 
                                      issue3:=TRUE;
                                  else
                                         if v_last_date<v_patch_date then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
							SELECT count(1) into v_exists
							FROM pay_patch_status
							WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
							AND status        = 'C';
							
							if v_exists=0 then
								issue5:=TRUE;
							else
								SELECT max(applied_date) into v_geocode_date
								FROM pay_patch_status
								WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
								AND status        = 'C';
							end if;
              end if;
              
               
            dbms_output.put_line('<div class="divSection">' );
			dbms_output.put_line('<div class="divSectionTitle">Geocode</div><br>');	  
            
                        if issue1 then
                                :w4:=:w4+1;
								
								if (:pay_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										elsif :apps_rel like '12.0%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ANNUAL GEOCODE UPDATE - 2014<br>');
										elsif :apps_rel like '11.5%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										end if;	
										dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Ensure you perform Geocode Upgrade Manager process after the patch.</div>');
								elsif (:pay_status='Shared') and (:hr_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ');
											dbms_output.put_line('ANNUAL GEOCODE UPDATE - 2014</div><br>');
										elsif :apps_rel like '12.0%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ');
											dbms_output.put_line('ANNUAL GEOCODE UPDATE - 2014</div><br>');
										elsif :apps_rel like '11.5%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015</div><br>');
										end if;
										dbms_output.put_line('<div class="divwarn">');
										dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records ensure you perform Geocode Upgrade Manager process after the patch.<br>');
										dbms_output.put_line('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=745638.1" target="_blank">Note 745638.1</a> ');
										dbms_output.put_line('Requirements for Address Validation with HR Only Installation</div><br>');
								end if;									
                        else
							dbms_output.put_line('Patch '||patch||' Oracle US and Canada Payroll Annual Geocode applied on '||v_patch_date||'<br>');
                        end if;
                        
                        if issue2 then
                            :w4:=:w4+1;
							
							if (:pay_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>You never performed Geocode Upgrade Manager process!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware you never performed Geocode Upgrade Manager process!</div><br>');
							end if;
                        end if;
                        
                        if issue3 then
                            :w4:=:w4+1;
							
							if (:pay_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Your last run of Geocode Upgrade Manager process is not Completed Normal. Please review!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');								
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware your last run of Geocode Upgrade Manager process completed in error. Please review!</div><br>');
							end if;
                        end if;
                        if issue4 then
                            :w4:=:w4+1;
							
							if (:pay_status='Installed') then
								dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>You did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware you did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							end if;
                        end if;
                        if (:apps_rel not like '12.0%') then 
						if issue5  then
                            :w4:=:w4+1;
							if (:pay_status='Installed') then								
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>GEOCODE_ANNUAL_2015 information not applied!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then								
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware GEOCODE_ANNUAL_2015 information are not applied!</div><br>');
							end if;
                        elsif not issue1 then
							dbms_output.put_line('GEOCODE_ANNUAL_2015 information applied on '||v_geocode_date||'<br>');
                        end if;
						end if;
                        
						if not issue1 and not issue2 and not issue3 and not issue4 then
							dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
						end if;
						
                        if issue1 or issue2 or issue3 or issue4 or (issue5 and :apps_rel not like '12.0%') then
                                :issuep:=1;
								dbms_output.put_line('<div class="divwarn">');
								if :apps_rel like '12.2%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038283.1" target="_blank">Note 2038283.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.2.x');
								elsif :apps_rel like '12.1%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038282.1" target="_blank">Note 2038282.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.1.x');
                                elsif :apps_rel like '12.0%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1912683.1" target="_blank">Note 1912683.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2014 Annual Geocode Readme - Release 12.0.x');
                                else
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038281.1" target="_blank">Note 2038281.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 11i');
                                end if;
                                dbms_output.put_line('</div>');         
						else
                                dbms_output.put_line('<img class="check_ico">OK! All checks are OK!<br>');
                               
                        end if;
						
            dbms_output.put_line('</div>');            
      
end;


-- Display Quantum level
procedure Quantum is
    v_exists number:=0;
  v_status varchar2(100);
  v_last_date date;
  patch varchar2(20);
  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type;	
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin

                select count(1) into v_exists
                from ad_applied_patches ap
                   , ad_patch_drivers pd
                   , ad_patch_runs pr
                   , ad_patch_run_bugs prb
                   , ad_patch_run_bug_actions prba
                   , ad_files f
                where f.file_id                  = prba.file_id
                  and prba.executed_flag         = 'Y'
                  and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                  and prb.patch_run_id           = pr.patch_run_id
                  and pr.patch_driver_id         = pd.patch_driver_id
                  and pd.applied_patch_id        = ap.applied_patch_id
                  and f.filename = 'pyvendor.zip'
                  and pr.end_date = (select max(pr.end_date)
                                             from ad_applied_patches ap
                                                , ad_patch_drivers pd
                                                , ad_patch_runs pr
                                                , ad_patch_run_bugs prb
                                                , ad_patch_run_bug_actions prba
                                                , ad_files f
                                              where f.file_id                  = prba.file_id
                                                and prba.executed_flag         = 'Y'
                                                and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                and prb.patch_run_id           = pr.patch_run_id
                                                and pr.patch_driver_id         = pd.patch_driver_id
                                                and pd.applied_patch_id        = ap.applied_patch_id
                                                and f.filename = 'pyvendor.zip');      

                
               if (v_exists=0) then             
                         issue1:=TRUE;
                else
                           if :apps_rel like '12.%' then
								SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='19701971' ;
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701971' and rownum < 2;
								end if;						  
						   elsif :apps_rel like '11.5%'	then
								select count(1) into v_exists from ad_bugs where bug_number='19701970';
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701970' and rownum < 2;
								end if;
						   end if;						
						   select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%' ;
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),'ERROR')<>0 then 
                                      issue3:=TRUE;
                                  else
                                         if SYSDATE-v_last_date>30 then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
              end if;
              
               
            dbms_output.put_line('<br><div class="divSection">' );
			dbms_output.put_line('<div class="divSectionTitle">Quantum</div><br>');
                        if issue1 or issue2 or issue3 or issue4 or issue5 then
								dbms_output.put_line('<div class="diverr">');
								if issue5 then
										  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>You don''t have latest Quantum version 4.0.<br>');
										  dbms_output.put_line('Please install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=');
										  if :apps_rel like '12.%' then
											dbms_output.put_line('19701971">Patch 19701971</a><br>');										 
										  elsif :apps_rel like '11.5%' then
										     dbms_output.put_line('19701970">Patch 19701970</a><br>');
										  end if;
										  :e4:=:e4+1;
								end if;
								if issue1 then
										  :e4:=:e4+1;
										
										dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>No Quantum patch applied<br>');
										  dbms_output.put_line('Ensure you also perform Quantum Data Update Installer.<br>');
								end if;
								
								if issue2 then
										  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>You never performed Quantum Data Update Installer ! ');										  
										  :e4:=:e4+1;
										
								end if;
								
								if issue3 then
										  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>Your last run of Quantum Data Update Installer process completed in error. <br>');
										 :e4:=:e4+1;
										
								end if;
								if issue4 then
										   dbms_output.put_line('Your last run of Quantum Data Update Installer was on ');
										  dbms_output.put_line(v_last_date||' more than 30 days ago. <br>');
										                                    
										  :e4:=:e4+1;
										
								end if;
                                               
                                :issuep:=1;
								dbms_output.put_line('Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this error. Please verify with System Administrator.<br>');
								dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                                dbms_output.put_line('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations<br>');
								dbms_output.put_line('</div>');
                                                     
                        end if;
                        
						if not issue1 and not issue5 then
							if :apps_rel like '12.%' then
								dbms_output.put_line('Patch 19701971 applied on '||v_patch_date||'<br>');
							elsif :apps_rel like '11.5%' then
								dbms_output.put_line('Patch 19701970 applied on '||v_patch_date||'<br>');
							end if;
						end if;
						if not issue1 and not issue2 and not issue3 and not issue4 then
								dbms_output.put_line('Your last run of Quantum Data Update Installer was on '||v_last_date||'<br>');                                                           
						end if;    
					
                        dbms_output.put_line('<font color="blue">Advice: </font>Please periodically review: ');
						dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                        dbms_output.put_line('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations<br>');
						
			dbms_output.put_line('</div>');
end;


PROCEDURE print_big_text(bigTextInput VARCHAR2)
  IS    
    bigText    VARCHAR2(32767) := bigTextInput;
  BEGIN
    LOOP
      EXIT WHEN bigText IS NULL;        
      dbms_output.put_line( SUBSTR(bigText, 1, 250) );     
      bigText := SUBSTR(bigText, 251);
    END LOOP;
  END print_big_text;
  
-- Display Setup for PDF Reports
procedure pdf_reports is
	v_database_id varchar2(100);
	v_output fnd_concurrent_programs.OUTPUT_FILE_TYPE%type;
	v_rows number;
	v_patch number;
	v number;
	status_leg varchar2(2);
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue8 boolean := FALSE;
	v_variable FND_ENV_CONTEXT.VARIABLE_NAME%type;
	v_value FND_ENV_CONTEXT.VALUE%type;
	cursor c_env is select VARIABLE_NAME , nvl(VALUE,'null') 
			from FND_ENV_CONTEXT
			where CONCURRENT_PROCESS_ID in
				  (select max(CONCURRENT_PROCESS_ID) from FND_CONCURRENT_PROCESSES
				   where CONCURRENT_QUEUE_ID in (select CONCURRENT_QUEUE_ID from FND_CONCURRENT_QUEUES where CONCURRENT_QUEUE_NAME = 'WFMLRSVC')
					 and QUEUE_APPLICATION_ID in (select APPLICATION_ID from FND_APPLICATION where APPLICATION_SHORT_NAME = 'FND'))
			  and VARIABLE_NAME in ('APPL_TOP', 'AF_JRE_TOP', 'FND_SECURE', 'APPLPTMP', 'PY_LIB_PATH', 'PY_PRELOAD')
			order by VARIABLE_NAME;
begin
	
	dbms_output.put_line('<br><div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Setup For PDF Reports</div><br>');			
	
	v:=2;
		
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2">');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Variable Settings</B></font></TD>');
	dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Variable</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD>');
	:n := dbms_utility.get_time;	
	open c_env;
    loop
          fetch c_env into v_variable,v_value;
          EXIT WHEN  c_env%NOTFOUND;
          dbms_output.put_line('<TR><TD>'||v_variable||'</TD>'||chr(10)||'<TD>');
			print_big_text(v_value);
			dbms_output.put_line('</TD></TR>'||chr(10));         
    end loop;
    close c_env;
	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE><br> ');


	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2">');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Concurrent Programs</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql6'||v||'b" style="width:220px" onclick="displayItem2(this,''s1sql6'||v||''');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql6'||v||'" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select CONCURRENT_PROGRAM_NAME, OUTPUT_FILE_TYPE from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) in ( <br>');
		dbms_output.put_line('''PYXMLRL1'',''PYCARL2PXML'',''PAYCAT4PDF'',''PAYCAT4APDF''');
		
		dbms_output.put_line('          )');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Code</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Output Type</B></TD>');
	
		:n := dbms_utility.get_time;
		
		
		select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYXMLRL1';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYXMLRL1' and rownum < 2;
			dbms_output.put_line('<TR><TD>RL1 PDF</TD><TD>PYXMLRL1</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'HTML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue1:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYCARL2PXML';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYCARL2PXML' and rownum < 2;
			dbms_output.put_line('<TR><TD>RL2 PDF</TD><TD>PYCARL2PXML</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'HTML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue2:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAT4PDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAT4PDF' and rownum < 2;
			dbms_output.put_line('<TR><TD>T4 PDF</TD><TD>PAYCAT4PDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'PDF' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue3:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAT4APDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAT4APDF' and rownum < 2;
			dbms_output.put_line('<TR><TD>T4a PDF</TD><TD>PAYCAT4APDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'HTML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue4:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAARCHCHQW';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCAARCHCHQW' and rownum < 2;
			dbms_output.put_line('<TR><TD>Canadian Cheque Writer (XML)</TD><TD>PAYCAARCHCHQW</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue5:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;			
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYCADEPADVXML';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) ='PYCADEPADVXML' and rownum < 2;
			dbms_output.put_line('<TR><TD>Canadian Deposit Advice (XML)</TD><TD>PYCADEPADVXML</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue6:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;			
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCATPCHQW';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYCATPCHQW' and rownum < 2;
			dbms_output.put_line('<TR><TD>Canadian Third Party Cheque Writer (XML)</TD><TD>PAYCATPCHQW</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue7:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;				
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
			
		
		
		
		:n := (dbms_utility.get_time - :n)/100;
		
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> ');
		
	
			if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7  then
				dbms_output.put_line('<div class="divwarn">If you are using PDF Reports:<br>');
				if issue1 then
					:w4:=:w4+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of RL1 PDF should be set to HTML<br> ');
				end if;
				if issue2 then
					:w4:=:w4+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of RL2 PDF should be set to HTML<br> ');
				end if;
				if issue3 then
					:w4:=:w4+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of T4 PDF should be set to PDF<br> ');
				end if;
				if issue4 then
					:w4:=:w4+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of T4a PDF should be set to HTML<br> ');
				end if;
				if issue5 then
					:w4:=:w4+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Canadian Cheque Writer (XML) should be set to XML<br> ');
					
				end if;
				if issue6 then
					:w4:=:w4+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Canadian Deposit Advice (XML) should be set to XML<br> ');
					
				end if;
				if issue7 then
					:w4:=:w4+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Canadian Third Party Cheque Writer (XML) should be set to XML<br> ');
					
				end if;	
				dbms_output.put_line('</div>');
			end if;
		
		if :apps_rel like '12.1%' then
			select count(1) into v_rows from ad_bugs where bug_number in ('10281212','12599994');
			if v_rows=0 then
				issue8:=TRUE;
			end if;
		end if;
		
		if (:apps_rel not like '12.1%') or issue8 then
			select fnd_web_config.database_id into v_database_id from dual;
			select count(1) into v_rows from pay_action_parameters where upper(PARAMETER_NAME)='DBC_FILE' and upper(PARAMETER_VALUE) like upper('%'||v_database_id||'.dbc');
			if v_rows=0 then
				issue8:=TRUE;
			end if;
		end if;
		if issue8 then
					:w4:=:w4+1;
					dbms_output.put_line('<div class="divwarn">If you are using PDF Reports:<br>');
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You have DBC_FILE incorect in pay_action_parameters table. '); 
					dbms_output.put_line('This should be set to <your path>'||v_database_id||'.dbc<br> ');
					dbms_output.put_line('</div>');
		end if;

		if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<span class="sectionblue1">Advice:</span> Please review:<br> ');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=562882.1" target="_blank">Note 562882.1</a> Oracle Human Resources (HRMS) Setup For US, CA and MX Legislations Payroll PDF Reports<br>');
		dbms_output.put_line('</div>');
		else
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('Verified parameters are correctly set<br>');
				dbms_output.put_line('</div>');
		end if;
		
		dbms_output.put_line('</div> <br>');


EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;


procedure header (v_leg varchar2) is
begin
			dbms_output.put_line('<div class="divSection"><div class="divSectionTitle">');		
			dbms_output.put_line('<div class="left"  id="'||replace(v_leg,' ','')||'" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">'||v_leg); 
			dbms_output.put_line('</div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
			dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;"><font color="#FFFFFF" size="1">&#9654; Expand All Checks</font></a>'); 
			dbms_output.put_line('<font color="#FFFFFF">/  </font><a class="detail" onclick="closeall();" href="javascript:;">');
			dbms_output.put_line('<font color="#FFFFFF" size="1">&#9660; Collapse All Checks</font></a></div><div class="clear"></div></div><br>');
			dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
			dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
			case v_leg 
			when 'Canada' then
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'g">Geocode</a> <br>');	  
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'q">Quantum</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br></td><td class="toctable">');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'pdf">Setup for PDF Reports</a> <br>');			
			else
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');	  
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			end case;
			dbms_output.put_line('</td></tr></table>');
			dbms_output.put_line('</div></div><br>');
end;

begin
--AU	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AU'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page2" style="display: none;">');header('Australia');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Australiap"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');			
			if (:apps_rel like '12.2%') then					
					dpatch('AU','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('AU','21238399', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('AU','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('AU','21267565', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('AU','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('AU','19764591', 'AU.22 AUSTRALIA CONSOLIDATED PATCH');
				elsif :apps_rel like '11.5%' then					
					dpatch('AU','14488556', 'HR_PF.K.RUP.8');
					dpatch('AU','17314780','11I.AU.21 AUSTRALIA CUMULATIVE RELEASE');					
			end if;
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');								
								dpatch('AU','21238399', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
								dbms_output.put_line('</div>');	
						elsif (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');								
								dpatch('AU','21267565', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');
								dbms_output.put_line('</div>');								
						elsif (:apps_rel like '12.0%') then	
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('AU','19764591', 'AU.22 AUSTRALIA CONSOLIDATED PATCH');
								dbms_output.put_line('</div>');
							
						elsif :apps_rel like '11.5%' then					
							if :rup_level='14488556' or :rup_level='12807777'   then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('AU','16365150','R121.AU.20 AUSTRALIA CUMULATIVE RELEASE');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Australiad"></a>');datainstall('AU',2);dbms_output.put_line('<a name="Australias"></a>');bg_generic('AU',2);
			dbms_output.put_line('</div>');
			
			documents('1504358.2','Information Center: Oracle HRMS (Australia)');
			dbms_output.put_line('</div>');
	end if;

--BE
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'BE'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page3" style="display: none;">');header('Belgium');
			datainstall('BE',3);bg_generic('BE',3);	dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;

--DE
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'DE'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page7" style="display: none;">');
			datainstall('DE',7);	bg_generic('DE',7);		dbms_output.put_line('</div>');
			
			dbms_output.put_line('</div>');
	end if;

--CA
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'CA'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page4" style="display: none;">');header('Canada');
			
			dbms_output.put_line('<a name="Canadag"></a>');geocode();	
			dbms_output.put_line('<a name="Canadaq"></a>');Quantum();
			--jit();
			dbms_output.put_line('<br><div class="divSection">');dbms_output.put_line('<a name="Canadap"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then							
					dpatch('CA','19193000', 'R12.HR_PF.C.Delta.6');			
					dpatch('CA','20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.1%') then							
					dpatch('CA','20000288', 'R12.HR_PF.B.delta.8');					 
					dpatch('CA','20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.0%') then					
					dpatch('CA','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('CA','19701971','End of Year 2014 Phase 1');
					dpatch('CA','20212223','End of Year 2014 Phase 2');
					dpatch('CA','20365000','End of Year 2014 Phase 3');
				elsif :apps_rel like '11.5%' then				
					dpatch('CA','17774746', 'HR_PF.K.RUP.9');	
					dpatch('CA','20364999','End of Year 2014 Phase 3');
					dpatch('CA','20301513','Year Begin 2015 Statutory Update 2');
					dpatch('CA','20212121','Year Begin 2015 Statutory Update');
				end if;	
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.%') then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('CA','20365000','End of Year 2014 Phase 3');
								dbms_output.put_line('</div>');							
						elsif :apps_rel like '11.5%' then	
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('CA','20364999','End of Year 2014 Phase 3');	
								dbms_output.put_line('</div>');			
					end if;	
			end if;
			dbms_output.put_line('</div><br>');dbms_output.put_line('<a name="Canadad"></a>'); datainstall('CA',4);dbms_output.put_line('<a name="Canadas"></a>');bg_generic('CA',4);	 dbms_output.put_line('</div>');		
			--seeded ('CA',4);
			dbms_output.put_line('<a name="Canadapdf"></a>');pdf_reports();
			documents('1504134.2','Information Center: Oracle HRMS (Canada)');
			dbms_output.put_line('</div>');
	end if;

-- CN
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'CN'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page5" style="display: none;">');header('China');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Chinap"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('CN','19193000', 'R12.HR_PF.C.Delta.6');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('CN','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('CN','13715802','R12.PER.B - TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');
					dpatch('CN','16741703','R12.PER.B - Prevent Tax payable when under One Yuan (RMB)');									
				elsif (:apps_rel like '12.0%') then					
					dpatch('CN','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('CN','13715802','R12.PER.A - TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');				
				elsif :apps_rel like '11.5%' then					
					dpatch('CN','12807777', 'HR_PF.K.RUP.7');
					dpatch('CN','13717027','TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');
					dpatch('CN','14625844','Prevent Tax Payable when under One YUAN (RMB)');					
				end if;		
			dbms_output.put_line('</div>');			
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Chinad"></a>');datainstall('CN',5);dbms_output.put_line('<a name="Chinas"></a>');bg_generic('CN',5); dbms_output.put_line('</div>');			
			
			dbms_output.put_line('</div>');
	end if;

--ES

	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'ES'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page6" style="display: none;">');header('Spain');
			datainstall('ES',6);	bg_generic('ES',6);	dbms_output.put_line('</div>');	
			
			dbms_output.put_line('</div>');
	end if;

--DK
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'DK'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page8" style="display: none;">');header('Denmark');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Denmarkp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('DK','19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('DK','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('DK','20218977', 'ABP PGGM Calculation Changes 2015');
					dpatch('DK','20107803', 'Danish Legislative Changes 2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('DK','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('DK','20218977', 'ABP PGGM Calculation Changes 2015');
					dpatch('DK','20107803', 'Danish Legislative Changes 2015');
				elsif :apps_rel like '11.5%' then					
					dpatch('DK','12807777', 'HR_PF.K.RUP.7');
					dpatch('DK','16002352', 'Danish Legislative Changes 2013 Part-3');
					dpatch('DK','15945507', 'Danish Legislative Changes 2013 Part 1, 2');
					dpatch('DK','13500283', 'Danish Legislative Changes 2012');					
				end if;		
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('DK','20107803', 'Danish Legislative Changes 2015');
								dbms_output.put_line('</div>');							
							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' or :rup_level='13774477' then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('DK','20107803', 'Danish Legislative Changes 2015');
								dbms_output.put_line('</div>');
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777' then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('DK','16002352','DANISH LEGISLATIVE CHANGES 2013 PART-3');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>');dbms_output.put_line('<a name="Denmarkd"></a>'); datainstall('DK',8);dbms_output.put_line('<a name="Denmarks"></a>');bg_generic('DK',8);	dbms_output.put_line('</div>');		
			documents('1509934.2','Information Center: Oracle HRMS (Denmark)');
			dbms_output.put_line('</div>');
	end if;


--FI
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'FI'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page9" style="display: none;">');header('Finland');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Finlandp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('FI','19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('FI','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('FI','12793751', 'Delivers the Finland legislative changes for 2011 Part-I');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('FI','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('FI','12793751', 'Delivers the Finland legislative changes for 2011 Part-I');				
				elsif :apps_rel like '11.5%' then					
					dpatch('FI','12807777', 'HR_PF.K.RUP.7');
					dpatch('FI','10393363', 'Delivers the Finland legislative changes for 2011 Part-I');				
				end if;			
			dbms_output.put_line('</div>');			
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Finlandd"></a>');datainstall('FI',9); dbms_output.put_line('<a name="Finlands"></a>');bg_generic('FI',9);dbms_output.put_line('</div>');			
			
			dbms_output.put_line('</div>');
	end if;


--FR
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'FR'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page10" style="display: none;">');header('France');
			datainstall('FR',10);	bg_generic('FR',10);	dbms_output.put_line('</div>');	
			
			dbms_output.put_line('</div>');
	end if;

--HK
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'HK'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page11" style="display: none;">');header('Hong Kong');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="HongKongp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('HK','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('HK','20768287','TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('HK','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('HK','20768287','TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('HK','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('HK','17385401','R12.PER.A - R12.HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013 1 JUN 2014');										
				elsif :apps_rel like '11.5%' then					
					dpatch('HK','12807777', 'HR_PF.K.RUP.7');
					dpatch('HK','17539543','HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');				
				end if;			
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('HK','17385401','R121 HK.15 HK STATUTORY MPF MIN/MAX RI CHANGES FOR 1 NOV 2013/1 JUNE 2014');
								dbms_output.put_line('</div>');							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('HK','17385401','R12.HK.15 HK STATUTORY MPF MIN/MAX RI CHANGES FOR 1 NOV 2013/1 JUNE 2014');
								dbms_output.put_line('</div>');		
							elsif :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('HK','16457605','R12.HK.14 HK STATUTORY MINIMUM WAGE RATE CHANGE 1ST MAY 2013');
								dbms_output.put_line('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777' or :rup_level='14488556' then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('HK','17539543','HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="HongKongd"></a>');datainstall('HK',11);dbms_output.put_line('<a name="HongKongs"></a>');bg_generic('HK',11); dbms_output.put_line('</div>');			
			
			dbms_output.put_line('</div>');
	end if;


--HU
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'HU'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page12" style="display: none;">');header('Hungary');
			datainstall('HU',12);bg_generic('HU',12);			dbms_output.put_line('</div>');
			
			dbms_output.put_line('</div>');
	end if;

--IE
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page13" style="display: none;">');header('Ireland');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Irelandp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('IE','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('IE','20460989', 'Ireland Cumulative Legislative Patch 2015');
					dpatch('IE','20210371', 'USC On Tax Information Screen');
					dpatch('IE','20073662', 'Ireland Budget Changes Effective 01-JAN-2015');
					dpatch('IE','19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif (:apps_rel like '12.1%') then					
					dpatch('IE','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('IE','20195113', 'Ireland Electronic P60 Changes');
					dpatch('IE','20255656', 'Employer PAYE Reference Reporting Changes');
					dpatch('IE','20235946', 'Employers PAYE Reference Increased To 9 Characters');
					dpatch('IE','20210371', 'USC On Tax Information Screen');
					dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
					dpatch('IE','20073662', 'Ireland Budget Changes Effective 01-JAN-2015');
					dpatch('IE','18510224','IE MEDICAL INSURANCE CHANGES 2014');
					dpatch('IE','19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					dpatch('IE','19060389', 'Ireland P35 Version 11 Reporting Changes');
					dpatch('IE','19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif (:apps_rel like '12.0%') then					
					dpatch('IE','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('IE','20255656', 'Employer PAYE Reference Reporting Changes');
					dpatch('IE','20235946', 'Employers PAYE Reference Increased To 9 Characters');
					dpatch('IE','20210371', 'USC On Tax Information Screen');
					dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
					dpatch('IE','20073662', 'Ireland Budget Changes Effective 01-JAN-2015');
					dpatch('IE','18510224','IE MEDICAL INSURANCE CHANGES 2014');
					dpatch('IE','19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					dpatch('IE','19060389', 'Ireland P35 Version 11 Reporting Changes');
					dpatch('IE','19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif :apps_rel like '11.5%' then					
					dpatch('IE','12807777', 'HR_PF.K.RUP.7');
					dpatch('IE','16811068', 'Ireland Local Property Tax And Report Changes');
					dpatch('IE','16905146', 'Ireland Local Property Tax P30 Paper Report Changes');
					dpatch('IE','16925013', 'LPT Deducting Over 5 Not 6 Months From July 2013');
					dpatch('IE','16976741', 'IE P30 Paper Report Not Reporting Non Zero USC/LPT');
					dpatch('IE','16999708', 'LPT Deducing From Statutory Redundancy');
					dpatch('IE','17180755', 'IE SEPA FURTHER CHANGES: AIB FORMAT'); 
					dpatch('IE','17542073', 'IE SEPA HSBC BANK CHANGES');
					dpatch('IE','17573671', 'IE SEPA ULSTER BANK CHANGES');
					dpatch('IE','17592973', 'Generating SEPA File For PayPath Payment Method, SEPA Danske Bank Format');
					dpatch('IE','17731547', 'EAP NOVEMBER 2013 ISSUES: P35 XML REPORT CHANGES');
					dpatch('IE','17775887', 'IRELAND SEPA CHANGES: HSBC FORMAT: FEEDBACK FROM HSBC');			
				end if;				
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
								dbms_output.put_line('</div>');	
							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
								dbms_output.put_line('</div>');		
							elsif :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IE','16811074','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');
								dbms_output.put_line('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777' or :rup_level='14488556' then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IE','16811068','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Irelandd"></a>');datainstall('IE',13);dbms_output.put_line('<a name="Irelands"></a>');bg_generic('IE',13);	dbms_output.put_line('</div>');		
			documents('315825.1', 'Oracle HRMS for Ireland Supplement', '1609505.2','Information Center: Oracle HRMS (Ireland)');
			dbms_output.put_line('</div>');
	end if;


--IN
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IN'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page14" style="display: none;">');header('India');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Indiap"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('IN','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('IN','21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
				elsif (:apps_rel like '12.1%') then					
					dpatch('IN','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('IN','21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
				elsif (:apps_rel like '12.0%') then					
					dpatch('IN','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('IN','19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
				elsif :apps_rel like '11.5%' then					
					dpatch('IN','12807777', 'HR_PF.K.RUP.7');
					dpatch('IN','13914662','INDIA HRMS CONSOLIDATED UPDATE 11i.IN.08');	
					dpatch('IN','13870875','Form 24Q E-TDS Regular Changes');
					dpatch('IN','14351973','India Budget Changes for Section 80CCG and Section 80TTA');
					dpatch('IN','16359871','Andhra Pradesh professional Tax changes Effective 06-FEB-2013');
					dpatch('IN','16520998','India Budget Changes Gujarat Professional Tax Changes Effective 01-APR-2013');
					dpatch('IN','16669518','Madhya Pradesh Professional Tax Changes Effective 01-APR-2013	');				
				end if;					
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','20733388','R121 TRACKING BUG FOR INDIA 2015-16 BUDGET CHANGES');
								dbms_output.put_line('</div>');	
					elsif (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
								dbms_output.put_line('</div>');							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
								dbms_output.put_line('</div>');		
							elsif :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','17579687','12.0BL: INDIA CONSOLIDATED UPDATE IN.09 ');
								dbms_output.put_line('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777'  then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('IN','17578798','INDIA CONSOLIDATED UPDATE IN.09 ');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Indiad"></a>');datainstall('IN',14);dbms_output.put_line('<a name="Indias"></a>');bg_generic('IN',14);	dbms_output.put_line('</div>');		
			documents('1504684.2',	'Information Center: Oracle HRMS (India)');
			dbms_output.put_line('</div>');
	end if;

--IT
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IT'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page15" style="display: none;">');header('Italy');
			datainstall('IT',15);	bg_generic('IT',15);		dbms_output.put_line('</div>');
			
			dbms_output.put_line('</div>');
	end if;

--JP
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'JP'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page16" style="display: none;">');header('Japan');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Japanp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('JP','19193000', 'R12.HR_PF.C.Delta.6');					
				elsif (:apps_rel like '12.1%') then	
					dpatch('JP','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('JP','17015507','R12.PER.B - JAPANESE HRMS CONSOLIDATED PATCH R121.JP.13');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('JP','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('JP','13330458','R12.PER.A - JAPANESE HRMS CONSOLIDATED PATCH R12.JP.12');	
					dpatch('JP','13743712','R12.PER.A - H24 UNEMPLOYMENT INSURANCE RATE');					
				elsif :apps_rel like '11.5%' then					
					dpatch('JP','12807777', 'HR_PF.K.RUP.7');
					dpatch('JP','17015482','JAPANESE HRMS CONSOLIDATED UPDATE R115.JP.13');					
				end if;					
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							if :rup_level='18004477' then
								dbms_output.put_line('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('JP','19862190','H27 TERMINATION TAX RATE CHANGES EFFECTIVE 01-JAN-2015');
								dbms_output.put_line('</div>');								
							elsif :rup_level='13418800' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('JP','17015507','JAPANESE HRMS CONSOLIDATED PATCH R121.JP.13');
								dbms_output.put_line('</div>');		
							end if;						
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777'  then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('JP','17015482', 'JAPANESE HRMS CONSOLIDATED PATCH R115.JP.13');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>');dbms_output.put_line('<a name="Japand"></a>'); datainstall('JP',16);dbms_output.put_line('<a name="Japans"></a>');bg_generic('JP',16);	dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;


--KR
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KR'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page17" style="display: none;">');header('Korea');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Koreap"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then
					dpatch('KR','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
				elsif (:apps_rel like '12.1%') then					
					dpatch('KR','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');						
				elsif (:apps_rel like '12.0%') then					
					dpatch('KR','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');					
				elsif :apps_rel like '11.5%' then					
					dpatch('KR','12807777', 'HR_PF.K.RUP.7');
					dpatch('KR','16518233','KOREA CUMULATIVE RELEASE PATCH - 11i.KR.69');
					dpatch('KR','17446056','KOREA 2013 YEA CHANGES: RENT EXEMPTION,MAXIMUM SPECIAL EXEMPTION LIMIT');
					dpatch('KR','18107426','KOREA 2013 YEA CHANGES: SINGLE PARENT EXEMPTION');
				end if;						
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
								dbms_output.put_line('</div>');								
					elsif (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
								dbms_output.put_line('</div>');
						elsif (:apps_rel like '12.0%') then					
							if  :rup_level='16077077' or :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
								dbms_output.put_line('</div>');	
							end if;								
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Koread"></a>');datainstall('KR',17);dbms_output.put_line('<a name="Koreas"></a>');bg_generic('KR',17);	dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;


--KW
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KW'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page18" style="display: none;">');header('Kuwait');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Kuwaitp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('KW','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('KW','20331815', 'Change in employee social insurance contributions for Kuwait');
				elsif (:apps_rel like '12.1%') then					
					dpatch('KW','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('KW','20331815', 'Change in employee social insurance contributions for Kuwait');											
				elsif (:apps_rel like '12.0%') then					
					dpatch('KW','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('KW','19009589', 'R12.PAY.A - KW Unemployment Insurance');
					dpatch('KW','16787133', 'R12.PAY.A - Kuwait SI changes 2013');
					dpatch('KW','15934773', 'R12.PAY.A - KUWAIT Report changes');					
				elsif :apps_rel like '11.5%' then					
					dpatch('KW','12807777', 'HR_PF.K.RUP.7');
					dpatch('KW','16806105', 'Kuwait SI changes 2013');
					dpatch('KW','15934061', 'KUWAIT Report changes');					
				end if;								
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
						dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','20331815', 'Change in employee social insurance contributions for Kuwait');
								dbms_output.put_line('</div>');	
					elsif (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','20331815', 'Change in employee social insurance contributions for Kuwait');
								dbms_output.put_line('</div>');
						elsif (:apps_rel like '12.0%') then					
							if  :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','16787133', 'TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');
								dbms_output.put_line('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='14488556' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','16806105','TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');	
								dbms_output.put_line('</div>');
							elsif :rup_level='12807777'  then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('KW','16806105','TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Kuwaitd"></a>');datainstall('KW',18);dbms_output.put_line('<a name="Kuwaits"></a>');bg_generic('KW',18);	dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;
end;
/

declare
v_exists number;
 -- Display patch
procedure dpatch (v_leg varchar2, v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;	  
	  v_exists number;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								 case v_leg
									when  'AU' then
										:e2:=:e2+1;
									when 'BE' then 
										:e3:=:e3+1;
									when 'CA' then 	
										:e4:=:e4+1;
									when 'CN' then 
										:e5:=:e5+1;
									when 'ES' then
										:e6:=:e6+1;
									when 'DE' then 
										:e7:=:e7+1;
									when 'DK' then
										:e8:=:e8+1;
									when 'FI' then 
										:e9:=:e9+1;
									when 'FR' then 
										:e10:=:e10+1;
									when 'HK' then 	
										:e11:=:e11+1;
									when 'HU' then 
										:e12:=:e12+1;
									when 'IE' then 
										:e13:=:e13+1;
									when 'IN' then 
										:e14:=:e14+1;
									when 'IT' then 
										:e15:=:e15+1;
									when 'JP' then
										:e16:=:e16+1;
									when 'KR' then
										:e17:=:e17+1;
									when 'KW' then
										:e18:=:e18+1;
									when 'MX' then 
										:e19:=:e19+1;
									when 'NL' then 
										:e20:=:e20+1;
									when 'NO' then 
										:e21:=:e21+1;
									when 'NZ' then
										:e22:=:e22+1;
									when 'PL' then 
										:e23:=:e23+1;
									when 'RU' then
										:e24:=:e24+1;
									when 'SA' then 
										:e25:=:e25+1;									
									when 'SE' then 
										:e26:=:e26+1;
									when 'SG' then
										:e27:=:e27+1;
									when 'AE' then 	
										:e28:=:e28+1;
									when 'GB' then 
										:e29:=:e29+1;
									when 'US' then
										:e30:=:e30+1;
									when 'ZA' then
										:e31:=:e31+1;
									else
									null;
								end case;
								 
								 dbms_output.put_line('<div class="diverr">');
								 dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>Please plan to install ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');	
								 dbms_output.put_line('</div>');
							else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							dbms_output.put_line('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
						EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
	end; 
	
procedure documents (v_no1 varchar2, v_note1 varchar2, v_no2 varchar2, v_note2 varchar2) is
begin
			dbms_output.put_line('<br><div class="divok">');
			dbms_output.put_line('Useful documentation:<br>');
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');			
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no2||'" target="_blank">Note '||v_no2||'</a> '||v_note2||'<br>');
			dbms_output.put_line('</div>');
end;
procedure documents (v_no1 varchar2, v_note1 varchar2) is
begin
			dbms_output.put_line('<br><div class="divok">');
			dbms_output.put_line('Useful documentation:<br>');
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');
			dbms_output.put_line('</div>');
end;

procedure bg_generic (v_leg varchar2, v_no number) is
	  v_bg hr_all_organization_units.organization_id%type;
	  v_name hr_all_organization_UNITS.NAME%type;	  
	  v_cur PER_BUSINESS_GROUPS.CURRENCY_CODE%type;
	  v_enabled PER_BUSINESS_GROUPS.ENABLED_FLAG%type;
	  v_date_from varchar2(15);
	  v_date_to varchar2(15);
	  v_hr varchar2(3);
	cursor c_bg (v_legislation varchar2)  is
			SELECT otl.name,o.organization_id,o3.ORG_INFORMATION10 currency_code,o4.ORG_INFORMATION2 enabled_flag ,to_char(o.date_from, 'DD-MON-YYYY') ,to_char(o.date_to, 'DD-MON-YYYY')
			FROM hr_all_organization_UNITS O , 
			hr_all_organization_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			and o3.ORG_INFORMATION9=v_legislation
			order by o.organization_id;
	v_short_name hr_organization_information.org_information1%type;			
			v_employee_number_generation fnd_lookups.meaning%type;
			v_applicant_number_generation fnd_lookups.meaning%type;
			v_contingent_worker_numb_gen fnd_lookups.meaning%type;
			v_grade_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_group_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_job_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_costing_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_position_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_competence_flex fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_currency hr_organization_information.org_information1%type;
			v_fiscal_year_start hr_organization_information.org_information1%type;
			v_minimum_working_age hr_organization_information.org_information1%type;
			v_maximum_working_age hr_organization_information.org_information1%type;
					
	
	v_lookup1 fnd_lookups.meaning%type;
	v_lookup2 fnd_lookups.meaning%type;
	v_lookup3 fnd_lookups.meaning%type;
	v_lookup4 fnd_lookups.meaning%type;	
	v_lookup9 fnd_lookups.meaning%type;
	v_lookup5 fnd_lookups.meaning%type;	
	v_lookup6 fnd_lookups.meaning%type;	
	v_lookup7 fnd_lookups.meaning%type;
	v_lookup8 fnd_lookups.meaning%type;
		
	
	cursor c_payroll (t_bg  NUMBER) is
				SELECT   prl.payroll_name
				,prl.period_type
				,prl.first_period_end_date
				,prl.number_of_years
				,prl.period_reset_years
				,prl.pay_date_offset
				,prl.direct_deposit_date_offset
				,prl.pay_advice_date_offset
				,prl.cut_off_date_offset
				,nvl (opm.org_payment_method_name, 'No Default Payment Method Set') default_payment_method
				,con.consolidation_set_name consolidation_set
				,prl.workload_shifting_level
				,prl.arrears_flag
				,prl.negative_pay_allowed_flag
				,prl.multi_assignments_flag
				,prl.prl_information1				
				,prl.prl_information21 days_after_period_start
				,prl.prl_information22 days_after_period_end
				,hr_general_utilities.get_lookup_meaning('MODELER_AVAILABLITY',prl.prl_information20)  modeling_availability_rule
				,prl.payroll_id
				,prl.default_payment_method_id default_payment_method_id				
		FROM     pay_all_payrolls_f prl
				,pay_org_payment_methods_f opm
				,pay_consolidation_sets con
				,hr_all_organization_units org				
				,per_time_period_types tpt
				,per_time_period_rules tpr
		WHERE    1 = 1
			 AND con.consolidation_set_id = prl.consolidation_set_id
			 AND opm.org_payment_method_id(+) = prl.default_payment_method_id
			 AND org.organization_id(+) = prl.organization_id			
			 AND tpt.period_type = prl.period_type
			 AND tpr.number_per_fiscal_year = tpt.number_per_fiscal_year
			 AND sysdate BETWEEN prl.effective_start_date AND prl.effective_end_date
			 AND prl.business_group_id = t_bg
			 order by 1;
	v_payroll_name pay_all_payrolls_f.payroll_name%type;
	v_period_type pay_all_payrolls_f.period_type%type;
	v_first_date pay_all_payrolls_f.first_period_end_date%type;
	v_number_of_years pay_all_payrolls_f.number_of_years%type;
	v_period_reset_years pay_all_payrolls_f.period_reset_years%type;
	v_pay_date_offset pay_all_payrolls_f.pay_date_offset%type;
	v_direct_deposit pay_all_payrolls_f.direct_deposit_date_offset%type;
	v_pay_advice_date_offset pay_all_payrolls_f.pay_advice_date_offset%type;
	v_cut_off_date pay_all_payrolls_f.cut_off_date_offset%type;
	v_default_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_consolidation pay_consolidation_sets.consolidation_set_name%type;
	v_workload_shifting pay_all_payrolls_f.workload_shifting_level%type;
	v_arrears_flag pay_all_payrolls_f.arrears_flag%type;
	v_negative_pay pay_all_payrolls_f.negative_pay_allowed_flag%type;
	v_multi_assignments pay_all_payrolls_f.multi_assignments_flag%type;
	v_legal_employer hr_all_organization_units.name%type;
	v_prl_information21 pay_all_payrolls_f.prl_information21%type;
	v_prl_information22 pay_all_payrolls_f.prl_information22%type;
	v_modeling_availability fnd_lookups.meaning%type;
	
	v_seg2 pay_external_accounts.segment2%type;
	v_seg3 pay_external_accounts.segment3%type;
	v_seg5 pay_external_accounts.segment5%type;
	v_seg6 pay_external_accounts.segment6%type;
	v_seg7 pay_external_accounts.segment7%type;
	v_seg10 pay_external_accounts.segment10%type;
	
	cursor c_org_pay (t_id  NUMBER) is
		SELECT   hr_general_utilities.get_lookup_meaning('PER_EU_COUNTRIES',pea.territory_code) country
				,hr_general_utilities.get_lookup_meaning ('HR_NL_BANK', pea.segment1)  bank_name
				,segment2 account_number
				,segment3 postal_code
				,hr_general_utilities.get_lookup_meaning ('HR_NL_CITY', pea.segment4)  city
				,segment5 street
				,segment6 telephone_number
				,segment7 telephone_extension
				,hr_general_utilities.get_lookup_meaning('HR_NL_BIC_CODES',pea.segment9) bank_identifier_code
				,segment10 iban_number
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_payment) cost_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_payment) cost_cleared_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_void_payment) cost_cleared_void_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.exclude_manual_payment) exclude_manual_payment
		FROM     pay_external_accounts pea, (SELECT   org_payment_method_id
													 ,external_account_id
													 ,business_group_id
													 ,cost_payment
													 ,cost_cleared_payment
													 ,cost_cleared_void_payment
													 ,exclude_manual_payment
													 ,effective_start_date
													 ,effective_end_date
											 FROM     pay_org_payment_methods_f) popm
		WHERE    1 = 1
			 AND pea.external_account_id = popm.external_account_id
			 AND popm.org_payment_method_id = t_id
			 AND sysdate BETWEEN effective_start_date AND effective_end_date;
			 
	cursor c_Organizational (t_pid  NUMBER, t_dpmid NUMBER) is
			SELECT   opm.org_payment_method_name org_paymentmethod_name
				,pt.payment_type_name payment_type
				,CASE
				   WHEN opu.org_payment_method_id = t_dpmid
				   THEN
					 'Yes'
				   ELSE
					 'No'
				 END default_payment_method
				,opu.effective_start_date
				,opu.effective_end_date
				,opu.org_payment_method_id
				,pt.payment_type_id
		FROM     pay_org_pay_method_usages_f opu
				,pay_org_payment_methods_f opm
				,pay_payment_types pt
		WHERE    1 = 1
			 AND opm.org_payment_method_id = opu.org_payment_method_id
			 AND pt.payment_type_id = opm.payment_type_id
			 AND sysdate between opm.effective_start_date and opm.effective_end_date
			 AND sysdate between opu.effective_start_date and opu.effective_end_date
			 AND opu.payroll_id = t_pid
			 order by 1;
	
	v_payroll_id pay_org_pay_method_usages_f.payroll_id%type;
	v_org_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_payment_type_name pay_payment_types.payment_type_name%type;
	v_default_payment_method_id pay_all_payrolls_f.default_payment_method_id%type;
	v_default_payment_method varchar2(10);
	v_effective_start_date pay_org_pay_method_usages_f.effective_start_date%type;
	v_effective_end_date pay_org_pay_method_usages_f.effective_end_date%type;
	v_org_payment_method_id pay_org_pay_method_usages_f.org_payment_method_id%type;
	v_payment_type_id pay_payment_types.payment_type_id%type;
	
    v_id_flex FND_ID_FLEX_STRUCTURES_TL.ID_FLEX_NUM%type;
	v_code varchar2(30);
	v_cos_name varchar2(30);
	v_description varchar2(30);
	v_freeze varchar2(10);
	v_cos_enabled varchar2(10);
	v_dynamic varchar2(10);
	cursor c_costing (t_bg  NUMBER) is
		SELECT t.ID_FLEX_NUM,substrb(b.ID_FLEX_STRUCTURE_CODE,1,25) Code,
		   substrb(t.ID_FLEX_STRUCTURE_NAME,1,25) Name,
		   substrb(t.DESCRIPTION,1,25) Description,
		   lpad(substr(FREEZE_FLEX_DEFINITION_FLAG,1,8),8) Frz,
		   lpad(substr(ENABLED_FLAG,1,8),8) Enable,
		   lpad(substr(DYNAMIC_INSERTS_ALLOWED_FLAG,1,9),9) Dynamic
	FROM FND_ID_FLEX_STRUCTURES b, FND_ID_FLEX_STRUCTURES_TL t
	WHERE (t.APPLICATION_ID=801) 
		and t.language='US'
		and b.ID_FLEX_CODE=t.ID_FLEX_CODE and b.ID_FLEX_NUM=t.ID_FLEX_NUM and
		  (t.ID_FLEX_CODE='COST')
		  and
		  (t.ID_FLEX_NUM = (select cost_allocation_structure
				  from per_business_groups
				  where business_group_id = t_bg))
	order by t.application_id, t.id_flex_code, t.id_flex_structure_name;

	v_segment varchar2(30);
	v_column varchar2(15);
	v_seg_number FND_ID_FLEX_SEGMENTS.SEGMENT_NUM%type;
	v_display varchar2(10);
	v_required varchar2(10);
	v_security varchar2(10);
	v_cos_enabled2 varchar2(10);
	
	
	cursor c_costing_segments (t_flex  NUMBER) is
	SELECT substrb(SEGMENT_NAME,1,25) Name,
		   substrb(DESCRIPTION,1,25) Description,
		   substr(ENABLED_FLAG,1,3) Enabled,
		   substr(t.APPLICATION_COLUMN_NAME,1,10) Col_Name,
		   SEGMENT_NUM Seg_No,
		   lpad(substr(DISPLAY_FLAG,1,5),5) Disp,
		   lpad(substr(REQUIRED_FLAG,1,5),5) Reqd,
		   lpad(substr(SECURITY_ENABLED_FLAG,1,5),5) Secr
	FROM FND_ID_FLEX_SEGMENTS_TL T, FND_ID_FLEX_SEGMENTS B
	WHERE (t.APPLICATION_ID=801) 
		and t.language='US' 
	   and b.ID_FLEX_NUM = t_flex 
	   and b.ID_FLEX_CODE=t.ID_FLEX_CODE and b.ID_FLEX_NUM=t.ID_FLEX_NUM and  B.APPLICATION_COLUMN_NAME = T.APPLICATION_COLUMN_NAME and
		   (b.ID_FLEX_CODE='COST') and 
		   (b.APPLICATION_ID=801) 
	order by t.application_id, t.id_flex_code, t.id_flex_num, decode(b.enabled_flag, 'Y', 1, 'N', 2), b.segment_num;

	
	
	v_cost varchar2(30);
	v_atr varchar2(15);
	cursor c_costing_qualifiers (t_flex  NUMBER, t_seg NUMBER) is	
	SELECT substrb(FSAV.SEGMENT_ATTRIBUTE_TYPE,1,20) Cost_Level,
		   lpad(substr(FSAV.ATTRIBUTE_VALUE,1,10),10) Visible
	FROM FND_SEGMENT_ATTRIBUTE_VALUES FSAV, FND_ID_FLEX_SEGMENTS FIFS, FND_ID_FLEX_SEGMENTS_TL T
	WHERE 
	FIFS.APPLICATION_ID = T.APPLICATION_ID and FIFS.ID_FLEX_CODE = T.ID_FLEX_CODE and
	FIFS.ID_FLEX_NUM = T.ID_FLEX_NUM and FIFS.APPLICATION_COLUMN_NAME = T.APPLICATION_COLUMN_NAME and T.LANGUAGE = 'US' and
	EXISTS (SELECT NULL 
				  FROM FND_SEGMENT_ATTRIBUTE_TYPES T 
				  WHERE T.APPLICATION_ID =  FSAV.APPLICATION_ID AND 
						T.ID_FLEX_CODE =  FSAV.ID_FLEX_CODE AND 
						T.SEGMENT_ATTRIBUTE_TYPE =  FSAV.SEGMENT_ATTRIBUTE_TYPE AND 
						GLOBAL_FLAG = 'N') and
		   (FSAV.ID_FLEX_NUM = t_flex) and (FIFS.SEGMENT_NUM = t_seg) and
		   (FSAV.APPLICATION_COLUMN_NAME = FIFS.APPLICATION_COLUMN_NAME) and
		   (FSAV.ID_FLEX_CODE='COST') and 
		   (FSAV.APPLICATION_ID=801) and
		   (FSAV.ID_FLEX_NUM = FIFS.ID_FLEX_NUM)
	order by FSAV.segment_attribute_type, FIFS.APPLICATION_COLUMN_NAME, FIFS.SEGMENT_NAME;
	
begin
		
	dbms_output.put_line('<br><DIV class=divItem>');
	dbms_output.put_line('<DIV  class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b"  onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Business Group Information</A></DIV>');					
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql500'||:v_link_no||'" style="display:none" >');
	:v_link_no:=:v_link_no+1;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Business Group Information:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql500'||:v_link_no||'" style="display:none">');
	:v_link_no:=:v_link_no+1;
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('SELECT    haou.name,hoi.organization_id,pbg.currency_code ,pbg.enabled_flag ,pbg.date_from ,pbg.date_to	  <br>');
						dbms_output.put_line('FROM       hr_organization_information hoi,hr_all_organization_units haou,per_business_groups pbg<br>');
						dbms_output.put_line('WHERE      hoi.organization_id = haou.organization_id<br>');
						dbms_output.put_line('AND pbg.organization_id = haou.organization_id<br>');
						dbms_output.put_line('AND hoi.org_information_context = ''Business Group Information''<br>');
						dbms_output.put_line('and pbg.legislation_code='''||v_leg||'''<br>');							
						dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
       
		
    :n := dbms_utility.get_time;
    dbms_output.put_line(' <TR>');
	dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	
		
    open c_bg(v_leg);
        loop
           fetch c_bg into v_name,v_bg,v_cur,v_enabled,v_date_from,v_date_to;					
			EXIT WHEN  c_bg%NOTFOUND;			
			dbms_output.put_line('<DIV class=divItem>');
			dbms_output.put_line('<DIV class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_bg||' - '||v_name||'</A></DIV>');
			dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
							
			dbms_output.put_line('Currency: '|| v_cur||'<br>');
			dbms_output.put_line('Enabled Flag: '|| v_enabled||'<br>');
			dbms_output.put_line('Date From: '|| v_date_from||'<br>');
			dbms_output.put_line('Date To: '|| v_date_to||'<br>');
		
			SELECT   org_information1 short_name					
					,hr_general_utilities.get_lookup_meaning('EMP_NUM_GEN_METHOD',org_information2) employee_number_generation
					,hr_general_utilities.get_lookup_meaning('APL_NUM_GEN_METHOD',org_information3) applicant_number_generation
					,hr_general_utilities.get_lookup_meaning('CWK_NUM_GEN_METHOD',org_information16) contingent_worker_numb_gen
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information4
							AND id_flex_code = 'GRD')       grade_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information5
							AND id_flex_code = 'GRP')        group_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information6
							AND id_flex_code = 'JOB')        job_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information7
							AND id_flex_code = 'COST')       costing_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information8
							AND id_flex_code = 'POS')        position_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information15
							AND id_flex_code = 'CMP')        competence_flexfield_structure
					,org_information10 currency
					,org_information11 fiscal_year_start
					,org_information12 minimum_working_age
					,org_information13 maximum_working_age
					into v_short_name,v_employee_number_generation,v_applicant_number_generation,v_contingent_worker_numb_gen, v_grade_flexfield_structure,v_group_flexfield_structure,v_job_flexfield_structure,v_costing_flexfield_structure,v_position_flexfield_structure,v_competence_flex,v_currency,v_fiscal_year_start,v_minimum_working_age,v_maximum_working_age
					FROM     hr_organization_information hoi
							, (SELECT   name, organization_id FROM hr_all_organization_units)
							 hou_bg
					WHERE    1 = 1
						 AND hoi.organization_id = hou_bg.organization_id
						 AND hoi.org_information_context LIKE 'Business Group Information'
						 AND hoi.org_information9 = v_leg
						 AND hou_bg.organization_id = v_bg 
						 AND	 rownum < 2;
						 
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Business Group Info Setup</A>');
			dbms_output.put_line('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;
			dbms_output.put_line('<tr><th>Organization Short Name</th><th>Employee Number Generation</th><th>Applicant Number Generation</th>');
			dbms_output.put_line('<th>Contingent Worker Numb Gen</th><th>Grade Flexfield Structure</th><th>Group Flexfield Structure</th>');
			dbms_output.put_line('<th>Job Flexfield Structure</th><th>Costing Flexfield Structure</th><th>Position Flexfield Structure</th><th>Competence Flexfield Structure</th>');
			dbms_output.put_line('<th>Currency</th><th>Fiscal Year Start</th><th>Minimum Working Age</th>');
			dbms_output.put_line('<th>Maximum Working Age</th></tr>');
		
			dbms_output.put_line('<TR><TD>'||v_short_name||'</TD>'||chr(10)||'<TD>'||v_employee_number_generation||'</TD>'||chr(10)||'<TD>'||v_applicant_number_generation||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_contingent_worker_numb_gen||'</TD>'||chr(10)||'<TD>'||v_grade_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_group_flexfield_structure||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_job_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_costing_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_position_flexfield_structure||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_competence_flex||'</TD>'||chr(10)||'<TD>'||v_currency||'</TD>'||chr(10)||'<TD>'||v_fiscal_year_start||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_minimum_working_age||'</TD>'||chr(10)||'<TD>'||v_maximum_working_age||'</TD></TR>'||chr(10));
			dbms_output.put_line('</table><br>');					  
								  
		
	
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;General Payroll Information</A>');
			dbms_output.put_line('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			dbms_output.put_line('<tr><th>Payroll Name</th><th>Period Type</th><th>First Period End Date</th><th>Number of Years</th><th>Period Reset Years</th>');
			dbms_output.put_line('<th>Pay Date Offset</th><th>Direct Deposit Date Offset</th>');
			dbms_output.put_line('<th>Pay advice date offset</th><th>Cut off date offset</th><th>Default Payment Method</th><th>Consolidation Set</th>');
			dbms_output.put_line('<th>Workload Shifting Level</th><th>Arrears Flag</th><th>Negative pay allowed flag</th><th>Multi assignments flag</th><th>Legal Employer ID</th>');
			dbms_output.put_line('<th>Modeling Availability Rule</th><th>Days after period start</th><th>Days after period end</th></tr>');
			
			
			open c_payroll(v_bg);
			loop
				  fetch c_payroll into v_payroll_name,v_period_type,v_first_date,v_number_of_years,v_period_reset_years,v_pay_date_offset,v_direct_deposit,v_pay_advice_date_offset,v_cut_off_date,v_default_payment,v_consolidation,v_workload_shifting,v_arrears_flag,v_negative_pay,v_multi_assignments,v_legal_employer,v_prl_information21,v_prl_information22,v_modeling_availability,v_payroll_id,v_default_payment_method_id;
				  EXIT WHEN  c_payroll%NOTFOUND;
				  dbms_output.put_line('<TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_payroll_name||'</A>');
					dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; Valid Organizational Payment Methods');
						dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table>');
							if v_default_payment_method_id is null then
							dbms_output.put_line('<tr><td>Default Payment Method is null</th></tr>');
							else
							dbms_output.put_line('<tr><th>Org Payment Method</th><th>Payment Type</th><th>Default Payment Method</th>');
							dbms_output.put_line('<th>Effective Start Date</th><th>Effective End Date</th><th>Org Payment Method ID</th><th>Payment Type ID</th></tr>');
							open c_Organizational(v_payroll_id,v_default_payment_method_id);
							loop
								  fetch c_Organizational into v_org_payment,v_payment_type_name,v_default_payment_method,v_effective_start_date,v_effective_end_date,v_org_payment_method_id,v_payment_type_id;
								  EXIT WHEN  c_Organizational%NOTFOUND;				  
								  dbms_output.put_line('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; '||v_org_payment||'</A>');
								  dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; Organizational payment method information');
								  dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table >');								 							  
								  dbms_output.put_line('<tr><th>Country</th><th>Bank name</th><th>Account number</th><th>Postal code</th><th>City</th><th>Street</th><th>Telephone number</th><th>');
								  dbms_output.put_line('Telephone extension</th><th>Bank identifier code</th><th>IBAN</th><th>Cost payment</th><th>Cost cleared payment</th><th>Cost cleared void payment</th><th>');
								  dbms_output.put_line('Exclude manual payment</th></tr>');
								  open c_org_pay(v_org_payment_method_id);
									loop
										  fetch c_org_pay into v_lookup1,v_lookup2,v_seg2,v_seg3, v_lookup3,v_seg5,v_seg6,v_seg7,v_lookup4,v_seg10,v_lookup9,v_lookup5,v_lookup6,v_lookup7;
										  EXIT WHEN  c_org_pay%NOTFOUND;				  
										      dbms_output.put_line('<TR><TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10)||'<TD>'||v_seg2||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg3||'</TD>'||chr(10)||'<TD>'||v_lookup3||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg5||'</TD>'||chr(10)||'<TD>'||v_seg6||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg7||'</TD>'||chr(10)||'<TD>'||v_lookup4||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg10||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10));											 
											  dbms_output.put_line('<TD>'||v_lookup7||'</TD></TR>'||chr(10));     
									end loop;
									close c_org_pay;
								dbms_output.put_line('</table><br></div>');							  
								  
								  dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_payment_type_name||'</TD>'||chr(10)||'<TD>'||v_default_payment_method||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_effective_start_date||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_effective_end_date||'</TD>'||chr(10)||'<TD>'||v_org_payment_method_id||'</TD>'||chr(10));								 
								  dbms_output.put_line('<TD>'||v_payment_type_id||'</TD></TR>'||chr(10));         
							end loop;
							close c_Organizational;
							end if;
						dbms_output.put_line('</table><br>');
						
				  dbms_output.put_line('</TD>');
				 
				  
				  dbms_output.put_line('<TD>'||v_period_type||'</TD>'||chr(10)||'<TD>'||v_first_date||'</TD>'||chr(10)||'<TD>'||v_number_of_years||'</TD>'||chr(10));
				  dbms_output.put_line('<TD>'||v_period_reset_years||'</TD>'||chr(10)||'<TD>'||v_pay_date_offset||'</TD>'||chr(10)||'<TD>'||v_direct_deposit||'</TD>'||chr(10));
				  dbms_output.put_line('<TD>'||v_pay_advice_date_offset||'</TD>'||chr(10)||'<TD>'||v_cut_off_date||'</TD>');
					dbms_output.put_line('<TD>'||v_default_payment||'</TD>'||chr(10)||'<TD>'||v_consolidation||'</TD>'||chr(10)||'<TD>'||v_workload_shifting||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_arrears_flag||'</TD>'||chr(10)||'<TD>'||v_negative_pay||'</TD>'||chr(10)||'<TD>'||v_multi_assignments||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_legal_employer||'</TD>'||chr(10)||'<TD>'||v_modeling_availability||'</TD>'||chr(10)||'<TD>'||v_prl_information21||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_prl_information22||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_payroll;
			dbms_output.put_line('</table><br><br>');			
			
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Cost Flexfield Structure and Values</A>');
			dbms_output.put_line('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			dbms_output.put_line('<tr><th>Name</th><th>ID Flex Number</th><th>Code</th><th>Description</th><th>Freeze</th>');
			dbms_output.put_line('<th>Enable</th><th>Dynamic</th></tr>');
			open c_costing(v_bg);
			loop
				  fetch c_costing into v_id_flex,v_code,v_cos_name,v_description,v_freeze,v_cos_enabled,v_dynamic;
				  EXIT WHEN  c_costing%NOTFOUND;
				  dbms_output.put_line('<TR><TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_cos_name||'</A>');
					dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; <b>Flexfield Segments Setup</b>');
						dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table>');
               						
							dbms_output.put_line('<tr><th>Segment Name</th><th>Description</th><th>Enabled</th>');
							dbms_output.put_line('<th>Application Column Name</th><th>Display</th><th>Required</th><th>Security</th></tr>');
							 
							open c_costing_segments(v_id_flex);
							loop
								  fetch c_costing_segments into v_segment,v_description,v_cos_enabled2,v_column,v_seg_number,v_display,v_required,v_security;
								  EXIT WHEN  c_costing_segments%NOTFOUND;				  
								  dbms_output.put_line('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; '||v_segment||'</A>');
								  dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; <b>Flexfield Qualifiers</b>');
								  dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table >');	   							 							  
								  dbms_output.put_line('<tr><th>Cost Level</th><th>Visible</th></tr>');
								  open c_costing_qualifiers(v_id_flex,v_seg_number);
									loop
										  fetch c_costing_qualifiers into v_cost,v_atr;
										  EXIT WHEN  c_costing_qualifiers%NOTFOUND;				  
										      dbms_output.put_line('<TR><TD>'||v_cost||'</TD>'||chr(10)||'<TD>'||v_atr||'</TD></TR>'||chr(10));     
									end loop;
									close c_costing_qualifiers;
								dbms_output.put_line('</table><br></div>');							  
								  
								  dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_cos_enabled2||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_column||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_display||'</TD>'||chr(10)||'<TD>'||v_required||'</TD>'||chr(10));								 
								  dbms_output.put_line('<TD>'||v_security||'</TD></TR>'||chr(10));         
							end loop;
							close c_costing_segments;
							
						dbms_output.put_line('</table><br>');
						
				  dbms_output.put_line('</TD>');
				 
				  dbms_output.put_line('<TD>'||v_id_flex||'</TD><TD>'||v_code||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_freeze||'</TD>'||chr(10)||'<TD>'||v_cos_enabled||'</TD>'||chr(10));				 
				  dbms_output.put_line('<TD>'||v_dynamic||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_costing;
			dbms_output.put_line('</table><br><br>');				
			
			dbms_output.put_line('</DIV>');
			dbms_output.put_line('</DIV>');        
			
        end loop;
    close c_bg;
                            
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line('</TD></TR> <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;

	
procedure datainstall (v_leg varchar2, v_no number) is
	v_exists number;
    v_apps hr_legislation_installations.application_short_name%type;
    v_action varchar2(20);
	v_date hr_legislation_installations.last_update_date%type; v_legislation hr_legislation_installations.legislation_code%type;
    cursor di_actions is
        select 
		    legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION,   
		   decode(action,'F','Force Install'
						 ,'C','Clear'
						 ,'U','Upgrade'
						 ,'I','Install') ACTION,
		   last_update_date
		from hr_legislation_installations
		where (status is not null or action is not null)
		and legislation_code =v_leg;
	cursor rules is
		select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules
		where legislation_code =v_leg
		order by legislation_code;
	V_RULE_TYPE pay_legislation_rules.RULE_TYPE%type;
	V_RULE_MODE pay_legislation_rules.RULE_MODE%type;
begin
	dbms_output.put_line('<div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Data install status</div><br>');			
	
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>DataInstaller actions:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql200'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql200'||v_no||'" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('          select  legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION, <br>');
    dbms_output.put_line('          decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'') ACTION,<br>');
    dbms_output.put_line('           last_update_date <br>');           
    dbms_output.put_line('           from hr_legislation_installations <br>');   
    dbms_output.put_line('           where (status is not null or action is not null)<br>');                  
    dbms_output.put_line('            and legislation_code ='''||v_leg||''';<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');
    dbms_output.put_line(' <TH><B>Legislation</B></TD>'); dbms_output.put_line(' <TH><B>Application Name</B></TD>');
    dbms_output.put_line(' <TH><B>Action</B></TD>');
    dbms_output.put_line(' <TH><B>Last Update Date</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open di_actions;
        loop
            fetch di_actions into  v_legislation , v_apps, v_action, v_date;
            EXIT WHEN  di_actions%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD></TR>'||chr(10));
        end loop;
    close di_actions;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> <br> ');
	dbms_output.put_line('</div>');
	
	dbms_output.put_line('<br><div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Settings</div><br>');			
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql300'||v_no||'b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql300'||v_no||''');" href="javascript:;">&#9654; Pay Legislation Rules</A></DIV>');		
			
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql300'||v_no||'" style="display:none" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Pay Legislation Rules:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql301'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql301'||v_no||'" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('        select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules  <br>');   
    dbms_output.put_line('        order by LEGISLATION_CODE;<br>');   
    dbms_output.put_line('           where legislation_code ='''||v_leg||''';<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');    
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Legislation</B></TD>');                        
    dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Rule Type</B></TD>');
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Rule Mode</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open rules;
        loop
            fetch rules into v_legislation, v_rule_type, v_rule_mode;
            EXIT WHEN  rules%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_rule_type||'</TD>'||chr(10)||'<TD>'||v_rule_mode||'</TD></TR>'||chr(10));
        end loop;
    close rules;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
	
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;


procedure profit_sharing (v_leg varchar2, v_no number) is
	v_legal_emp pay_user_rows_f.row_low_range_or_name%type;
	v_user_name pay_user_columns.user_column_name%type;
	v_esd pay_user_column_instances_f.effective_start_date%type;
	v_eed pay_user_column_instances_f.effective_start_date%type;
	v_value pay_user_column_instances_f.value%type;
    cursor c_profit is
        select pur.row_low_range_or_name Legal_Employer_Name
			,puc.user_column_name
			,puci.effective_start_date
			,puci.effective_end_date
			,puci.value
			from pay_user_tables put
			,pay_user_columns puc
			,pay_user_rows_f pur
			,pay_user_column_instances_f puci
			where put.legislation_code = 'MX'
			and put.user_table_name = 'PTU Factors'
			and puc.user_table_id = put.user_table_id
			and pur.user_table_id = put.user_table_id
			and puci.user_column_id = puc.user_column_id
			and puci.user_row_id = pur.user_row_id
			ORDER BY pur.row_low_range_or_name
			,puc.user_column_id
			,puci.effective_start_date; 

begin
			
	dbms_output.put_line('<br><DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql302'||v_no||'b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql302'||v_no||''');" href="javascript:;">&#9654; Profit Sharing PTU Factor</A></DIV>');		
			
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql302'||v_no||'" style="display:none" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Profit Sharing PTU Factor:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql303'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql303'||v_no||'" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('        select pur.row_low_range_or_name Legal_Employer_Name<br>');
	dbms_output.put_line('        		,puc.user_column_name<br>');
	dbms_output.put_line('        		,puci.effective_start_date<br>');
	dbms_output.put_line('        		,puci.effective_end_date<br>');
	dbms_output.put_line('        		,puci.value<br>');
	dbms_output.put_line('        		from pay_user_tables put<br>');
	dbms_output.put_line('        		,pay_user_columns puc<br>');
	dbms_output.put_line('        		,pay_user_rows_f pur<br>');
	dbms_output.put_line('        		,pay_user_column_instances_f puci<br>');
	dbms_output.put_line('        		where put.legislation_code = ''MX''<br>');
	dbms_output.put_line('        		and put.user_table_name = ''PTU Factors''<br>');
	dbms_output.put_line('        		and puc.user_table_id = put.user_table_id<br>');
	dbms_output.put_line('        		and pur.user_table_id = put.user_table_id<br>');
	dbms_output.put_line('        		and puci.user_column_id = puc.user_column_id<br>');
	dbms_output.put_line('        		and puci.user_row_id = pur.user_row_id<br>');
	dbms_output.put_line('        		ORDER BY pur.row_low_range_or_name<br>');
	dbms_output.put_line('        		,puc.user_column_id<br>');
	dbms_output.put_line('        		,puci.effective_start_date;<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');    
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Legal Employer Name</B></TD>');                        
    dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>User Column Name</B></TD>');
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Effective Start Date</B></TD>');
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Effective End Date</B></TD>');
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open c_profit;
        loop
            fetch c_profit into v_legal_emp,v_user_name,v_esd,v_eed,v_value;
            EXIT WHEN  c_profit%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_legal_emp||'</TD>'||chr(10)||'<TD>'||v_user_name||'</TD>'||chr(10)||'<TD>'||v_esd||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_eed||'</TD>'||chr(10)||'<TD>'||v_value||'</TD></TR>'||chr(10));
        end loop;
    close c_profit;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
	
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;



PROCEDURE print_big_text(bigTextInput VARCHAR2)
  IS    
    bigText    VARCHAR2(32767) := bigTextInput;
  BEGIN
    LOOP
      EXIT WHEN bigText IS NULL;        
      dbms_output.put_line( SUBSTR(bigText, 1, 250) );     
      bigText := SUBSTR(bigText, 251);
    END LOOP;
  END print_big_text;
  

-- Display Setup for PDF Reports
procedure pdf_reports (v_leg varchar2) is
	v_database_id varchar2(100);
	v_output fnd_concurrent_programs.OUTPUT_FILE_TYPE%type;
	v_rows number;
	v_patch number;
	v number;
	status_leg varchar2(2);
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue8 boolean := FALSE;
	v_variable FND_ENV_CONTEXT.VARIABLE_NAME%type;
	v_value FND_ENV_CONTEXT.VALUE%type;
	cursor c_env is select VARIABLE_NAME , nvl(VALUE,'null') 
			from FND_ENV_CONTEXT
			where CONCURRENT_PROCESS_ID in
				  (select max(CONCURRENT_PROCESS_ID) from FND_CONCURRENT_PROCESSES
				   where CONCURRENT_QUEUE_ID in (select CONCURRENT_QUEUE_ID from FND_CONCURRENT_QUEUES where CONCURRENT_QUEUE_NAME = 'WFMLRSVC')
					 and QUEUE_APPLICATION_ID in (select APPLICATION_ID from FND_APPLICATION where APPLICATION_SHORT_NAME = 'FND'))
			  and VARIABLE_NAME in ('APPL_TOP', 'AF_JRE_TOP', 'FND_SECURE', 'APPLPTMP', 'PY_LIB_PATH', 'PY_PRELOAD')
			order by VARIABLE_NAME;
begin
	
	dbms_output.put_line('<br><div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Setup For PDF Reports</div><br>');			
	
	case v_leg
		when 'US' then
			v:=1;
		when 'CA' then
			v:=2;
		when 'MX' then
			v:=3;
		else
			null;
	end case;
	
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2">');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Variable Settings</B></font></TD>');
	dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Variable</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD>');
	:n := dbms_utility.get_time;	
	open c_env;
    loop
          fetch c_env into v_variable,v_value;
          EXIT WHEN  c_env%NOTFOUND;
          dbms_output.put_line('<TR><TD>'||v_variable||'</TD>'||chr(10)||'<TD>');
			print_big_text(v_value);
			dbms_output.put_line('</TD></TR>'||chr(10));         
    end loop;
    close c_env;
	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE><br> ');


	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2">');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Concurrent Programs</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql6'||v||'b" style="width:220px" onclick="displayItem2(this,''s1sql6'||v||''');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql6'||v||'" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select CONCURRENT_PROGRAM_NAME, OUTPUT_FILE_TYPE from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) in ( <br>');
		case v_leg
		when 'US' then
			dbms_output.put_line('''PAYARCHCHQW'',''PYCADEPADVXML'', ''PYUSDEPADVXML'',''PAYUSW2PDF'', ''PYUS941T'',''EMP_1099R_PDF''');
		when 'CA' then
			dbms_output.put_line('''PYXMLRL1'',''PYCARL2PXML'',''PAYCAT4PDF'',''PAYCAT4APDF''');
		when 'MX' then
			dbms_output.put_line('''PAYMXDD''');
		else
			null;
		end case;
		dbms_output.put_line('          )');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Code</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Output Type</B></TD>');
	
		:n := dbms_utility.get_time;
		
		if :apps_rel like '12.2%' then
			v_patch:=1;
		elsif (:apps_rel like '12.1%') or (:apps_rel like '12.0%') then
			select count(1) into v_patch from ad_bugs where bug_number='15832452';
		elsif :apps_rel like '11.5%' then
			select count(1) into v_patch from ad_bugs where bug_number='16090736';
		end if;

		case v_leg
		when 'US' then
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYARCHCHQW';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYARCHCHQW' and rownum < 2;
			dbms_output.put_line('<TR><TD>Checkwriter (XML)</TD><TD>PAYARCHCHQW</TD>'||chr(10)||'<TD>');
			if v_patch=0 then
				if upper(v_output)<>'TEXT' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue1:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;
			else
				if upper(v_output)<>'XML' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue1:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;
			end if;			
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUSDEPADVXML';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) ='PYUSDEPADVXML' and rownum < 2;
			dbms_output.put_line('<TR><TD>Deposit Advice (XML)</TD><TD>PYUSDEPADVXML</TD>'||chr(10)||'<TD>');
			if v_patch=0 then
				if upper(v_output)<>'TEXT' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue2:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;
			else
				if upper(v_output)<>'XML' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue2:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;
			end if;	
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYUSW2PDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYUSW2PDF' and rownum < 2;
			dbms_output.put_line('<TR><TD>Employee W-2 PDF</TD><TD>PAYUSW2PDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue3:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUS941T';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUS941T' and rownum < 2;
			dbms_output.put_line('<TR><TD>Quarterly Tax Return Worksheet (Form 941 - PDF)</TD><TD>PYUS941T</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue4:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='EMP_1099R_PDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='EMP_1099R_PDF' and rownum < 2;
			dbms_output.put_line('<TR><TD>1099R Information Return - PDF</TD><TD>EMP_1099R_PDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'TEXT' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue5:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
		when 'MX' then
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDD';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDD' and rownum < 2;
			dbms_output.put_line('<TR><TD>Direct Deposit (Mexico)</TD><TD>PAYMXDD</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue1:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_SS_AFFL';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_SS_AFFL' and rownum < 2;
			dbms_output.put_line('<TR><TD>Social Security Affiliation Report</TD><TD>MX_SS_AFFL</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue2:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXXMLPSLP';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXXMLPSLP' and rownum < 2;
			dbms_output.put_line('<TR><TD>CFDI Payroll Payslip XML Extract</TD><TD>PYMXXMLPSLP</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue3:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_ISR_FORMAT37';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_ISR_FORMAT37' and rownum < 2;
			dbms_output.put_line('<TR><TD>ISR Tax Format 37 (XML)</TD><TD>MX_ISR_FORMAT37</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue4:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDIMMAG';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDIMMAG' and rownum < 2;
			dbms_output.put_line('<TR><TD>Information Declaration Report (DIM)</TD><TD>PAYMXDIMMAG</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue5:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXTRR';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXTRR' and rownum < 2;
			dbms_output.put_line('<TR><TD>Payroll Tax Remittance Report</TD><TD>PYMXTRR</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue6:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
		else
			null;
		end case;
		
		
		:n := (dbms_utility.get_time - :n)/100;
		
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> ');
		
		case v_leg
		when 'US' then
			if issue1 or issue2 or issue3 or issue4 or issue5 then
				dbms_output.put_line('<div class="divwarn">If you are using PDF Reports:<br>');
				if issue1 then
					:w30:=:w30+1;
					if v_patch=0 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Checkwriter (XML) should be set to Text<br> ');						
					else
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Checkwriter (XML) should be set to XML<br> ');						
					end if;
				end if;
				if issue2 then
					:w30:=:w30+1;
					if v_patch=0 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Deposit Advice (XML) should be set to Text<br> ');						
					else
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Deposit Advice (XML) should be set to XML<br> ');
					end if;
				end if;
				if issue3 then
					:w30:=:w30+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Employee W-2 PDF should be set to XML<br> ');
				end if;
				if issue4 then
					:w30:=:w30+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Quarterly Tax Return Worksheet (Form 941 - PDF) should be set to XML<br> ');
				end if;
				if issue5 then
					:w30:=:w30+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of 1099R Information Return - PDF should be set to Text<br> ');
				end if;
				
				dbms_output.put_line('</div>');
			end if;
		when 'MX' then
			if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 then
				dbms_output.put_line('<div class="divwarn">If you are using PDF Reports:<br>');
				if issue1 then					
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Direct Deposit (Mexico) should be set to XML<br> ');					
				end if;
				if issue2 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Social Security Affiliation Report should be set to XML<br> ');
				end if;
				if issue3 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of CFDI Payroll Payslip XML Extract should be set to XML<br> ');
				end if;
				if issue4 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of ISR Tax Format 37 (XML) should be set to XML<br> ');
				end if;
				if issue5 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Information Declaration Report (DIM) should be set to XML<br> ');
				end if;
				if issue6 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Payroll Tax Remittance Report should be set to XML<br> ');
				end if;
				dbms_output.put_line('</div>');
			end if;
		else
			null;
		end case;
	
		if :apps_rel like '12.1%' then
			select count(1) into v_rows from ad_bugs where bug_number in ('10281212','12599994');
			if v_rows=0 then
				issue8:=TRUE;
			end if;
		end if;
		
		if (:apps_rel not like '12.1%') or issue8 then
			select fnd_web_config.database_id into v_database_id from dual;
			select count(1) into v_rows from pay_action_parameters where upper(PARAMETER_NAME)='DBC_FILE' and upper(PARAMETER_VALUE) like upper('%'||v_database_id||'.dbc');
			if v_rows=0 then
				issue8:=TRUE;
			end if;
		end if;
		if issue8 then
					
					:w19:=:w19+1;
					:w30:=:w30+1;
					dbms_output.put_line('<div class="divwarn">If you are using PDF Reports:<br>');
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You have DBC_FILE incorect in pay_action_parameters table. '); 
					dbms_output.put_line('This should be set to <your path>'||v_database_id||'.dbc<br> ');
					dbms_output.put_line('</div>');
		end if;

		if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<span class="sectionblue1">Advice:</span> Please review:<br> ');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=562882.1" target="_blank">Note 562882.1</a> Oracle Human Resources (HRMS) Setup For US, CA and MX Legislations Payroll PDF Reports<br>');
		dbms_output.put_line('</div>');
		else
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('Verified parameters are correctly set<br>');
				dbms_output.put_line('</div>');
		end if;
		
		dbms_output.put_line('</div> <br>');


EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;


procedure rti is		
    cursor c_assignment is
        select information_type
			,      decode(active_inactive_flag,'Y','Active','N','Inactive')
			,      multiple_occurences_flag
			,      creation_date
			,      last_update_date
			from PER_ASSIGNMENT_INFO_TYPES
			where information_type like 'GB%RTI%';
	v_info_type PER_ASSIGNMENT_INFO_TYPES.information_type%type;
	v_flag varchar2(10);
	v_m_flag PER_ASSIGNMENT_INFO_TYPES.multiple_occurences_flag%type;
	v_date PER_ASSIGNMENT_INFO_TYPES.creation_date%type;
	v_date2 PER_ASSIGNMENT_INFO_TYPES.last_update_date%type;
	cursor c_modules is
		select module_id, module_name, description, application_id from PQP_CONFIGURATION_MODULES where LEGISLATION_CODE='GB' and MODULE_NAME like 'Real Time Information';     
	v_id PQP_CONFIGURATION_MODULES.module_id%type;
	v_name PQP_CONFIGURATION_MODULES.module_name%type;
	v_desc PQP_CONFIGURATION_MODULES.description%type;
	v_appl_id PQP_CONFIGURATION_MODULES.application_id%type;
	cursor c_types is
		select configuration_type, module_id, decode(active_inactive_flag,'Y','Active','Inactive'), 
		Description, multiple_occurences_flag, protected_flag, creation_date from PQP_CONFIGURATION_TYPES 
		where MODULE_ID in (select MODULE_ID from PQP_CONFIGURATION_MODULES where LEGISLATION_CODE='GB' and MODULE_NAME like 'Real Time Information') 
		and CONFIGURATION_TYPE ='PAY_GB_RTI_FPS_BACS' ;   
	v_type PQP_CONFIGURATION_TYPES.configuration_type%type;
	v_descr2 PQP_CONFIGURATION_TYPES.Description%type;
	v_flag2 PQP_CONFIGURATION_TYPES.protected_flag%type;
	
	cursor c_values is
		select configuration_value_id, business_group_id, pcv_information_category, pcv_information1, pcv_information2, creation_date, configuration_name 
		from pqp_configuration_values where PCV_INFORMATION_CATEGORY like 'PAY_GB_RTI%';
	v_conf_id pqp_configuration_values.configuration_value_id%type;
	v_bg pqp_configuration_values.business_group_id%type;
	v_pcv pqp_configuration_values.pcv_information_category%type;
	v_pcv1 pqp_configuration_values.pcv_information1%type;
	v_pcv2 pqp_configuration_values.pcv_information2%type;
	v_config pqp_configuration_values.configuration_name%type;
	v_column1	VARCHAR2(50);
	v_column2	VARCHAR2(50);
	v_column3	VARCHAR2(50);
	v_rows number;
	issue boolean:=false;
	v_sql varchar2(1000);
	v_cursorid number;
	v_dummy	INTEGER;
begin
			
	dbms_output.put_line('<br><DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql91b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql91'');" href="javascript:;">&#9654; Assignment extra information setup</A></DIV>');		
			
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql91" style="display:none" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>PER_ASSIGNMENT_INFO_TYPES:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql92'');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql92" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('        select information_type<br>');
	dbms_output.put_line(',decode(active_inactive_flag,''Y'',''Active'',''N'',''Inactive'')<br>');
	dbms_output.put_line(',multiple_occurences_flag,creation_date,last_update_date<br>');
	dbms_output.put_line('from PER_ASSIGNMENT_INFO_TYPES<br>');
	dbms_output.put_line('where information_type like ''GB%RTI%'';<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');    
	dbms_output.put_line(' <TH><B>Information Type</B></TD>');                        
    dbms_output.put_line(' <TH><B>Active/Inactive Flag</B></TD>');
	dbms_output.put_line(' <TH><B>Multiple Occurences Flag</B></TD>');
	dbms_output.put_line(' <TH><B>Cration date</B></TD>');
	dbms_output.put_line(' <TH><B>Last update date</B></TD>');
	
    :n := dbms_utility.get_time;
    
		
    open c_assignment;
        loop
            fetch c_assignment into v_info_type,v_flag,v_m_flag,v_date,v_date2;
            EXIT WHEN  c_assignment%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_info_type||'</TD>'||chr(10)||'<TD>'||v_flag||'</TD>'||chr(10)||'<TD>'||v_m_flag||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_date||'</TD>'||chr(10)||'<TD>'||v_date2||'</TD></TR>'||chr(10));
        end loop;
    close c_assignment;                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');	
	
	dbms_output.put_line('<br><DIV class=divItem>');
						dbms_output.put_line('<DIV id="s1sql93b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql93'');" href="javascript:;">&#9654; RTI Configuration performed</A></DIV>');		
						dbms_output.put_line('<DIV id="s1sql93" style="display: none;">');
											
						dbms_output.put_line('<A class=detail onclick="displayItem(this,''s1sql94'');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; PQP CONFIGURATION MODULES</A>');
						dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql94" style="display:none" >');
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('     <B>PQP CONFIGURATION MODULES:</B></font></TD>');
						dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
						dbms_output.put_line('<A class=detail  id="s1sql95b"  onclick="displayItem2(this,''s1sql95'');" href="javascript:;">&#9654; Show SQL Script</A>');
						dbms_output.put_line('   </TD>');
						dbms_output.put_line(' </TR>');
						dbms_output.put_line(' <TR id="s1sql95" style="display:none">');
						dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
						dbms_output.put_line('       <blockquote><p align="left">');			
						dbms_output.put_line('               select module_id, module_name, description, application_id from PQP_CONFIGURATION_MODULES<br>');
					    dbms_output.put_line('               where LEGISLATION_CODE=''GB'' and MODULE_NAME like ''Real Time Information''<br>');					   
						dbms_output.put_line('          </blockquote><br>');
						dbms_output.put_line('     </TD>');
						dbms_output.put_line('   </TR>');
						dbms_output.put_line(' <TR>');
						dbms_output.put_line(' <TH><B>Module ID</B></TD>');
						dbms_output.put_line(' <TH><B>Module Name</B></TD>');
						dbms_output.put_line(' <TH><B>Description</B></TD>');	
						dbms_output.put_line(' <TH><B>Application ID</B></TD>');
					
		      
	
						:n := dbms_utility.get_time;
						 open c_modules;
						  loop
							fetch c_modules into v_id ,v_name ,v_desc, v_appl_id;
							EXIT WHEN  c_modules%NOTFOUND;
							dbms_output.put_line('<TR><TD>'||v_id||'</TD>'||chr(10)||'<TD>'||v_name||'</TD>'||chr(10));							
							dbms_output.put_line('<TD>'||v_desc||'</TD>'||chr(10)||'<TD>'||v_appl_id||'</TD></TR>'||chr(10));	
						  end loop;
						  close c_modules;
						  
						:n := (dbms_utility.get_time - :n)/100;
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						dbms_output.put_line(' </TABLE>  ');	
						
		
						dbms_output.put_line('<br><br><A class=detail onclick="displayItem(this,''s1sql96'');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; PQP CONFIGURATION TYPES</A>');
						dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql96" style="display:none" >');
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line('   <TH COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('     <B>PQP CONFIGURATION TYPES:</B></font></TD>');
						dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
						dbms_output.put_line('<A class=detail  id="s1sql97b"  onclick="displayItem2(this,''s1sql97'');" href="javascript:;">&#9654; Show SQL Script</A>');
						dbms_output.put_line('   </TD>');
						dbms_output.put_line(' </TR>');
						dbms_output.put_line(' <TR id="s1sql97" style="display:none">');
						dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="6" height="60">');
						dbms_output.put_line('       <blockquote><p align="left">');
						dbms_output.put_line('select configuration_type, module_id, decode(active_inactive_flag,''Y'',''Active'',''Inactive''),<br>'); 
						dbms_output.put_line('Description, multiple_occurences_flag, protected_flag, creation_date from PQP_CONFIGURATION_TYPES <br>'); 
						dbms_output.put_line('where MODULE_ID in (select MODULE_ID from PQP_CONFIGURATION_MODULES where LEGISLATION_CODE=''GB'' and MODULE_NAME like ''Real Time Information'')  <br>');
						dbms_output.put_line('and CONFIGURATION_TYPE =''PAY_GB_RTI_FPS_BACS'' <br>');					
						dbms_output.put_line('          </blockquote><br>');
						dbms_output.put_line('     </TD>');
						dbms_output.put_line('   </TR>');
						dbms_output.put_line(' <TR>');
						dbms_output.put_line(' <TH><B>Configuration Type</B></TD>');
						dbms_output.put_line(' <TH><B>Module ID</B></TD>');
						dbms_output.put_line(' <TH><B>Active Inactive flag</B></TD>');
						dbms_output.put_line(' <TH><B>Description</B></TD>');
						dbms_output.put_line(' <TH><B>Multiple occurences flag</B></TD>');
						dbms_output.put_line(' <TH><B>Protected flag</B></TD>');
						dbms_output.put_line(' <TH><B>Creation date</B></TD>');				
						
						:n := dbms_utility.get_time;
						 open c_types;
						  loop
							fetch c_types into v_type,v_id,v_flag,v_descr2,v_m_flag,v_flag2,v_date;
							EXIT WHEN  c_types%NOTFOUND;
							dbms_output.put_line('<TR><TD>'||v_type||'</TD>'||chr(10)||'<TD>'||v_id||'</TD>'||chr(10));							
							dbms_output.put_line('<TD>'||v_flag||'</TD>'||chr(10)||'<TD>'||v_descr2||'</TD>'||chr(10));
							dbms_output.put_line('<TD>'||v_m_flag||'</TD>'||chr(10)||'<TD>'||v_flag2||'</TD>'||chr(10)||'<TD>'||v_date||'</TD></TR>'||chr(10));	
						  end loop;
						  close c_types;
						  
						:n := (dbms_utility.get_time - :n)/100;
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line(' <TH COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						dbms_output.put_line(' </TABLE>  ');								
	
						dbms_output.put_line('<br><br><A class=detail onclick="displayItem(this,''s1sql98'');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; PCV INFORMATION CATEGORY</A>');
						dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql98" style="display:none" >');
						dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						dbms_output.put_line('   <TH COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri">');
						dbms_output.put_line('     <B>PCV INFORMATION CATEGORY:</B></font></TD>');
						dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
						dbms_output.put_line('<A class=detail  id="s1sql99b"  onclick="displayItem2(this,''s1sql99'');" href="javascript:;">&#9654; Show SQL Script</A>');
						dbms_output.put_line('   </TD>');
						dbms_output.put_line(' </TR>');
						dbms_output.put_line(' <TR id="s1sql99" style="display:none">');
						dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="6" height="60">');
						dbms_output.put_line('       <blockquote><p align="left">');
						dbms_output.put_line('select configuration_value_id, business_group_id, pcv_information_category,<br>'); 
					    dbms_output.put_line('pcv_information1, pcv_information2, creation_date, configuration_name<br>');
					    dbms_output.put_line('from pqp_configuration_values where PCV_INFORMATION_CATEGORY like ''PAY_GB_RTI%''<br>');					   						
						dbms_output.put_line('          </blockquote><br>');
						dbms_output.put_line('     </TD></TR><TR>');
						dbms_output.put_line(' <TH><B>Configuration Value ID</B></TD>');
						dbms_output.put_line(' <TH><B>Business Group ID</B></TD>');
						dbms_output.put_line(' <TH><B>PCV information category</B></TD>');
						dbms_output.put_line(' <TH><B>PCV information 1</B></TD>');	
						dbms_output.put_line(' <TH><B>PCV information 2</B></TD>');
						dbms_output.put_line(' <TH><B>Creation date</B></TD>');	
						dbms_output.put_line(' <TH><B>Configuration Name</B></TD>');	
												
						:n := dbms_utility.get_time;
						 open c_values;
						  loop
							fetch c_values into v_conf_id,v_bg,v_pcv,v_pcv1,v_pcv2,v_date,v_config;
							EXIT WHEN  c_values%NOTFOUND;
							dbms_output.put_line('<TR><TD>'||v_conf_id||'</TD>'||chr(10)||'<TD>'||v_bg||'</TD>'||chr(10));							
							dbms_output.put_line('<TD>'||v_pcv||'</TD>'||chr(10)||'<TD>'||v_pcv1||'</TD>'||chr(10));
							dbms_output.put_line('<TD>'||v_pcv2||'</TD>'||chr(10)||'<TD>'||v_date||'</TD>'||chr(10)||'<TD>'||v_config||'</TD></TR>'||chr(10));						
						  end loop;
						  close c_values;
						  
						  :n := (dbms_utility.get_time - :n)/100;					
					dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
					dbms_output.put_line(' <TH COLSPAN=6 bordercolor="#DEE6EF"><font face="Calibri">');
					dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
					dbms_output.put_line(' </TABLE>  ');					
					dbms_output.put_line('</div></div>');
	
	select count(1) into v_rows from dba_tables where table_name='PAY_GB_FPS_DETAILS';
	if v_rows>0 then
	dbms_output.put_line('<br><DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql101b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql101'');" href="javascript:;">&#9654; Orphan FPS Records</A></DIV>');		
			
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql101" style="display:none" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Orphan FPS Records:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql102'');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql102" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('        SELECT fps_pay_act_id,fps_effective_date,fps_asg_act_id FROM pay_gb_fps_details<br>');
	dbms_output.put_line(' WHERE fps_pay_act_id NOT IN (SELECT ppa.payroll_action_id FROM pay_payroll_actions ppa)');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');    
	dbms_output.put_line(' <TH><B>FPS Pay Act ID</B></TD>');                        
    dbms_output.put_line(' <TH><B>FPS Effective Date</B></TD>');
	dbms_output.put_line(' <TH><B>Count (FPS Asg Act ID)</B></TD>');
    :n := dbms_utility.get_time;
								v_cursorid := DBMS_SQL.OPEN_CURSOR;

								v_sql := 'SELECT fps_pay_act_id,fps_effective_date,count(fps_asg_act_id) FROM  pay_gb_fps_details WHERE  fps_pay_act_id NOT IN (SELECT   ppa.payroll_action_id FROM  pay_payroll_actions ppa) group by fps_pay_act_id,fps_effective_date';

										 --Parse the query.
										 DBMS_SQL.PARSE(v_cursorid, v_sql, dbms_sql.native);
										 --Define output columns
										 DBMS_SQL.DEFINE_COLUMN(v_cursorid, 1, v_column1, 30);
										 DBMS_SQL.DEFINE_COLUMN(v_cursorid, 2, v_column2, 30);
										 DBMS_SQL.DEFINE_COLUMN(v_cursorid, 3, v_column3, 30);
										 --Execute dynamic sql
										 v_dummy := DBMS_SQL.EXECUTE(v_cursorid);
										 LOOP
											  IF DBMS_SQL.FETCH_ROWS(v_cursorid) = 0 then
												   exit;
											  END IF;								
											  DBMS_SQL.COLUMN_VALUE(v_cursorid,1,v_column1);
											  DBMS_SQL.COLUMN_VALUE(v_cursorid,2,v_column2);
											  DBMS_SQL.COLUMN_VALUE(v_cursorid,3,v_column3);
											  dbms_output.put_line('<TR><TD>'||v_column1||'</TD>'||chr(10)||'<TD>'||v_column2||'</TD>'||chr(10)||'<TD>'||v_column3||'</TD></TR>'||chr(10));
												issue:=TRUE;
										 END LOOP;
										 

										 DBMS_SQL.CLOSE_CURSOR(v_cursorid);
								
								:n := (dbms_utility.get_time - :n)/100; 
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');	
	if issue then
		:w29:=:w29+1;
		dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><font color="#CC3311">Warning: </font> Rollback has been used recently or in the past for the FPS Process. For the FPS process GB Rollback has to be used, as datafix might be required.<br>');
		dbms_output.put_line('Refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1589654.1" target="_blank">Note 1589654.1</a> FPS Rolled Back Using ROLLBACK Not GB ROLLBACK - Datafix Required<br></div>');
	else
		dbms_output.put_line('<div class="divok"><img class="check_ico">OK! No orphan FPS record.</div>');
	end if;
	end if;
	
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;

procedure file_version_uk is
	v_exists number;
    v_filename ad_files.filename%type;
	v_version ad_file_versions.version%type;
    v_update ad_file_versions.last_update_date%type;		
    cursor c_files is
        SELECT files.filename,ver2.version,ver2.last_update_date
			FROM ad_file_versions ver2,ad_files f2
			, (SELECT MAX (ver.file_version_id) file_version_id, f.filename
			FROM ad_file_versions ver, ad_files f
			WHERE f.file_id = ver.file_id
			AND (lower(f.filename) like ('pygbrti%') or lower(f.filename) like ('pygbfps%'))
			GROUP BY f.filename) files
			WHERE files.filename = f2.filename AND f2.file_id = ver2.file_id
			AND files.file_version_id = ver2.file_version_id and f2.app_short_name = 'PAY'
			order by files.filename desc;	

begin
			
	dbms_output.put_line('<br><DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql89b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql89'');" href="javascript:;">&#9654; RTI files</A></DIV>');		
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql89" style="display:none" >');	
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Pension functionality files:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql90'');" href="javascript:;">&#9654; Show SQL Script</A>');
	dbms_output.put_line('   </TD></TR><TR id="s1sql90" style="display:none">');	 
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('        SELECT files.filename,ver2.version,ver2.last_update_date  <br>');
	dbms_output.put_line('        FROM   ad_file_versions ver2,ad_files f2<br>');
	dbms_output.put_line('        	  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename<br> FROM     ad_file_versions ver, ad_files f<br>');
	dbms_output.put_line('        		 WHERE    f.file_id = ver.file_id<br> AND       (lower(f.filename) like (''pygbrti%'') or lower(f.filename) like (''pygbfps%''))<br>');
	dbms_output.put_line('        		 GROUP BY f.filename) files<br>  WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id<br>');
	dbms_output.put_line('       AND files.file_version_id = ver2.file_version_id and f2.app_short_name = ''PAY''<br>'); 	
	dbms_output.put_line('        order by files.filename desc;<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD></TR><TR>');    
	dbms_output.put_line(' <TH><B>Filename</B></TD>');                        
    dbms_output.put_line(' <TH><B>Version</B></TD>');
	dbms_output.put_line(' <TH><B>Last update</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open c_files;
			loop
				fetch c_files into v_filename, v_version, v_update;
				EXIT WHEN  c_files%NOTFOUND;
				dbms_output.put_line('<TR><TD>'||v_filename||'</TD>'||chr(10)||'<TD>'||v_version||'</TD>'||chr(10)||'<TD>'||v_update||'</TD></TR>'||chr(10));
			end loop;
		close c_files;   
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
	
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;


procedure file_version (v_leg varchar2) is
	v_exists number;
    v_filename ad_files.filename%type;
	v_version ad_file_versions.version%type;
    v_update ad_file_versions.last_update_date%type;		
    cursor c_pension is
        SELECT files.filename,ver2.version,ver2.last_update_date
			FROM   ad_file_versions ver2,ad_files f2
				  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename
					 FROM     ad_file_versions ver, ad_files f
					 WHERE    f.file_id = ver.file_id
					 AND      (lower(f.filename) like
								('pqp'||v_leg||'%'))  
					 GROUP BY f.filename) files
			WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id
			AND    files.file_version_id = ver2.file_version_id	and f2.app_short_name = 'PQP'
			order by files.filename desc;
	
	cursor c_ie is
		SELECT files.filename,ver2.version,ver2.last_update_date 
			FROM ad_file_versions ver2,ad_files f2
			, (SELECT MAX (ver.file_version_id) file_version_id, f.filename
			FROM ad_file_versions ver, ad_files f
			WHERE f.file_id = ver.file_id
			AND (lower(f.filename) like
			('p%yie%')) 
			GROUP BY f.filename) files
			WHERE files.filename = f2.filename AND f2.file_id = ver2.file_id
			AND files.file_version_id = ver2.file_version_id and f2.app_short_name = 'PAY'
			order by files.filename desc;

begin
	
	dbms_output.put_line('<br><div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Versions</div><br>');			
	dbms_output.put_line('<DIV class=divItem>');
	CASE v_leg
	when 'nl' then
		dbms_output.put_line('<DIV id="s1sql82b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql82'');" href="javascript:;">&#9654; Pension functionality files</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql82" style="display:none" >');
	when 'gb' then
		dbms_output.put_line('<DIV id="s1sql83b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql83'');" href="javascript:;">&#9654; Pension functionality files</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql83" style="display:none" >');
	when 'ie' then
		dbms_output.put_line('<DIV id="s1sql84b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql84'');" href="javascript:;">&#9654; Ireland code file versions</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql84" style="display:none" >');
	else
	null;
	end case;	
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Pension functionality files:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    CASE v_leg
	when 'nl' then
		dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql85'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql85" style="display:none">');
	when 'gb' then
		dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql86'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql86" style="display:none">');
	when 'ie' then
		dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql87'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql87" style="display:none">');
	else
	null;
	end case;    
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('        SELECT files.filename,ver2.version,ver2.last_update_date  <br>');

	dbms_output.put_line('        FROM   ad_file_versions ver2,ad_files f2<br>');
	dbms_output.put_line('        	  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename<br>');
	dbms_output.put_line('        		 FROM     ad_file_versions ver, ad_files f<br>');
	dbms_output.put_line('        		 WHERE    f.file_id = ver.file_id<br>');
	dbms_output.put_line('        		 AND      (lower(f.filename) like<br>');
	if v_leg in ('nl','gb') then
		dbms_output.put_line('        					(''pqp'||v_leg||'%'')) <br>'); 
	elsif v_leg='ie' then
		dbms_output.put_line('        					(''p%yie%'')) <br>'); 
	end if;
	dbms_output.put_line('        		 GROUP BY f.filename) files<br>');
	dbms_output.put_line('        WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id<br>');
	if v_leg in ('nl','gb') then
		dbms_output.put_line('        AND    files.file_version_id = ver2.file_version_id	and f2.app_short_name = ''PQP''<br>');
	elsif v_leg='ie' then
		dbms_output.put_line('       AND files.file_version_id = ver2.file_version_id and f2.app_short_name = ''PAY''<br>'); 
	end if;
	dbms_output.put_line('        order by files.filename desc;<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');    
	dbms_output.put_line(' <TH><B>Filename</B></TD>');                        
    dbms_output.put_line(' <TH><B>Version</B></TD>');
	dbms_output.put_line(' <TH><B>Last update</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    if v_leg in ('nl','gb') then
		open c_pension;
			loop
				fetch c_pension into v_filename, v_version, v_update;
				EXIT WHEN  c_pension%NOTFOUND;
				dbms_output.put_line('<TR><TD>'||v_filename||'</TD>'||chr(10)||'<TD>'||v_version||'</TD>'||chr(10)||'<TD>'||v_update||'</TD></TR>'||chr(10));
			end loop;
		close c_pension;
    elsif v_leg='ie' then
		open c_ie;
			loop
				fetch c_ie into v_filename, v_version, v_update;
				EXIT WHEN  c_ie%NOTFOUND;
				dbms_output.put_line('<TR><TD>'||v_filename||'</TD>'||chr(10)||'<TD>'||v_version||'</TD>'||chr(10)||'<TD>'||v_update||'</TD></TR>'||chr(10));
			end loop;
		close c_ie;
	end if;	
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
	
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;



procedure pension (v_leg varchar2) is
	v_exists number;
    v_filename ad_files.filename%type;
	v_version ad_file_versions.version%type;
    v_update ad_file_versions.last_update_date%type;		
    cursor c_pension is
        SELECT files.filename,ver2.version,ver2.last_update_date
			FROM   ad_file_versions ver2,ad_files f2
				  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename
					 FROM     ad_file_versions ver, ad_files f
					 WHERE    f.file_id = ver.file_id
					 AND      (lower(f.filename) like
								('pqp'||v_leg||'%'))  
					 GROUP BY f.filename) files
			WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id
			AND    files.file_version_id = ver2.file_version_id	and f2.app_short_name = 'PQP'
			order by files.filename desc;
	
begin
	
	dbms_output.put_line('<br><div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Versions</div><br>');			
	dbms_output.put_line('<DIV class=divItem>');
	if v_leg='nl' then
		dbms_output.put_line('<DIV id="s1sql82b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql82'');" href="javascript:;">&#9654; Pension functionality files</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql82" style="display:none" >');
	elsif v_leg='gb' then
		dbms_output.put_line('<DIV id="s1sql83b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql83'');" href="javascript:;">&#9654; Pension functionality files</A></DIV>');		
		dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql83" style="display:none" >');
	end if;	
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Pension functionality files:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
     dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    if v_leg='nl' then
		dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql84'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql84" style="display:none">');
	elsif v_leg='gb' then
		dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql85'');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql85" style="display:none">');
	end if;    
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('        SELECT files.filename,ver2.version,ver2.last_update_date  <br>');

	dbms_output.put_line('        FROM   ad_file_versions ver2,ad_files f2<br>');
	dbms_output.put_line('        	  , (SELECT   MAX (ver.file_version_id) file_version_id, f.filename<br>');
	dbms_output.put_line('        		 FROM     ad_file_versions ver, ad_files f<br>');
	dbms_output.put_line('        		 WHERE    f.file_id = ver.file_id<br>');
	dbms_output.put_line('        		 AND      (lower(f.filename) like<br>');
	dbms_output.put_line('        					(''pqp'||v_leg||'%'')) <br>'); 
	dbms_output.put_line('        		 GROUP BY f.filename) files<br>');
	dbms_output.put_line('        WHERE  files.filename = f2.filename	AND f2.file_id = ver2.file_id<br>');
	dbms_output.put_line('        AND    files.file_version_id = ver2.file_version_id	and f2.app_short_name = ''PQP''<br>');
	dbms_output.put_line('        order by files.filename desc;<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');    
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Filename</B></TD>');                        
    dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Version</B></TD>');
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Last update</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open c_pension;
        loop
            fetch c_pension into v_filename, v_version, v_update;
            EXIT WHEN  c_pension%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_filename||'</TD>'||chr(10)||'<TD>'||v_version||'</TD>'||chr(10)||'<TD>'||v_update||'</TD></TR>'||chr(10));
        end loop;
    close c_pension;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
	dbms_output.put_line('</div>');
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;


procedure header (v_leg varchar2) is
begin
			dbms_output.put_line('<div class="divSection"><div class="divSectionTitle">');		
			dbms_output.put_line('<div class="left"  id="'||replace(v_leg,' ','')||'" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">'||v_leg); 
			dbms_output.put_line('</div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
			dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;"><font color="#FFFFFF" size="1">&#9654; Expand All Checks</font></a>'); 
			dbms_output.put_line('<font color="#FFFFFF">/  </font><a class="detail" onclick="closeall();" href="javascript:;">');
			dbms_output.put_line('<font color="#FFFFFF" size="1">&#9660; Collapse All Checks</font></a></div><div class="clear"></div></div><br>');
			dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
			dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
			case v_leg		
			when 'Mexico' then			
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br></td><td class="toctable">');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'pdf">Setup for PDF Reports</a> <br>');
			when 'United Kingdom' then
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br></td><td class="toctable">');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'v">Versions</a> <br>');
			when 'Netherlands' then
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br></td><td class="toctable">');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'v">Versions</a> <br>');
			else
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');	  
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			end case;
			dbms_output.put_line('</td></tr></table>');
			dbms_output.put_line('</div></div><br>');
end;

begin
--MX
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'MX'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page19" style="display: none;">');header('Mexico');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Mexicop"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('MX','17050005', 'HRMS RUP4');
					dpatch('MX','20259629','2014 EOY Phase 1');
					dpatch('MX','20794928','Economic Zone B Minimum Wage');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('MX','20000288', 'R12.HR_PF.B.delta.8');					
					dpatch('MX','20259629','2014 EOY Phase 1');
					dpatch('MX','20794928','Economic Zone B Minimum Wage');
				elsif (:apps_rel like '12.0%') then
					dpatch('MX','16077077', 'R12.HR_PF.A.delta.11');					
					dpatch('MX','20259629','2014 EOY Phase 1');
				elsif :apps_rel like '11.5%' then					
					dpatch('MX','12807777', 'HR_PF.K.RUP.7');
					dpatch('MX','15919087','NOV 2012 MINIMUM WAGE UPDATES');
					dpatch('MX','14776810','2012 Year End Phase 1');
					dpatch('MX','16034967','2013 Year Begin');
					dpatch('MX','16023541','GETTING WRONG VALUES WITH SS QUOTA PRORATED WHEN SENIORITY CHANGES IN MID');
					dpatch('MX','16090552','2012 Year End Phase 2');
					dpatch('MX','16270938','NO ANNUAL TAX ADJUST, ISR IS STILL ZERO FOR THE ISR WITHHELD');
					dpatch('MX','16607347','11I: MEXICO STATE TAX UPDATES 2013');
					dpatch('MX','17500878','11I:MX SEP13: QUINTANA ROO STATE TAX RATE UPDATE');
				end if;														
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
						dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('MX','20259629','2014 EOY Phase 1');
								dbms_output.put_line('</div>');	
					elsif (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('MX','20259629','2014 EOY Phase 1');
								dbms_output.put_line('</div>');	
						elsif (:apps_rel like '12.0%') then					
							if  :rup_level='16077077' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('MX','20259629','2014 EOY Phase 1');
								dbms_output.put_line('</div>');	
							end if;									
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); 
			dbms_output.put_line('<a name="Mexicod"></a>');datainstall('MX',19);dbms_output.put_line('<a name="Mexicos"></a>');bg_generic('MX',19);	
			profit_sharing('MX',19);
			dbms_output.put_line('</div>');		
			dbms_output.put_line('<a name="Mexicopdf"></a>');pdf_reports('MX');
			documents('1507499.2','Information Center: Oracle HRMS (Mexico)');
			dbms_output.put_line('</div>');
	end if;


--NL
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NL'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page20" style="display: none;">');header('Netherlands');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Netherlandsp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			 if (:apps_rel like '12.2%') then					
					dpatch('NL','19193000', 'R12.HR_PF.C.Delta.6');	
					dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
					dpatch('NL','20972577', 'Legislative Changes - Legal Minimum Wages effective from 01-Jul-2015');
				elsif (:apps_rel like '12.1%') then						
					dpatch('NL','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
					dpatch('NL','20972577', 'Legislative Changes - Legal Minimum Wages effective from 01-Jul-2015');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('NL','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');			
				elsif :apps_rel like '11.5%' then					
					dpatch('NL','12807777', 'HR_PF.K.RUP.7');
					dpatch('NL','17558120', 'Delivers changes to Dutch Annual Tax Statement for the Employee Report effective 2013');				
				end if;												
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
							dbms_output.put_line('<br><div class="divItem">');
							dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
							dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
							dbms_output.put_line('</div>');
						elsif (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
								dbms_output.put_line('</div>');							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
								dbms_output.put_line('</div>');	
							elsif  :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','17309051','Dutch Labour Handicap Discount Calculation to use Full Time Salary');
								dbms_output.put_line('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='14488556' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','17309047','Dutch Labour Handicap Discount Calculation');	
								dbms_output.put_line('</div>');
							elsif :rup_level='12807777'  then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NL','17309047','Dutch Labour Handicap Discount Calculation');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Netherlandsd"></a>');datainstall('NL',20);dbms_output.put_line('<a name="Netherlandss"></a>');bg_generic('NL',20);		dbms_output.put_line('</div>');	
			dbms_output.put_line('<a name="Netherlandsv"></a>');file_version('nl'); dbms_output.put_line('</div>');	
			documents('1506687.2','Information Center: Oracle HRMS (Netherlands)');
			dbms_output.put_line('</div>');
	end if;

--NO	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NO'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page21" style="display: none;">');header('Norway');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Norwayp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('NO','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('NO','21327657', 'NO: Half tax calculation');
				elsif (:apps_rel like '12.1%') then					
					dpatch('NO','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('NO','21327657', 'NO: Half tax calculation');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('NO','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('NO','14177955', 'Delivers the K27 reimbursement file upload');			
				elsif :apps_rel like '11.5%' then					
					dpatch('NO','12807777', 'HR_PF.K.RUP.7');
					dpatch('NO','14171993', 'Delivers the K27 reimbursement file upload');				
				end if;												
			dbms_output.put_line('</div>');
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Norwayd"></a>');datainstall('NO',21);dbms_output.put_line('<a name="Norways"></a>');bg_generic('NO',21);	dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;


--NZ
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NZ'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page22" style="display: none;">');header('New Zealand');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="NewZealandp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('NZ','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('NZ','20699005', 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('NZ','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('NZ','20699005', 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('NZ','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('NZ','11867792','R12.PER.A - NEW ZEALAND CUMULATIVE RELEASE R12.NZ.08');	
					dpatch('NZ','13697009','R12.PER.A - NZ STATUTORY UPDATES 2012');					
				elsif :apps_rel like '11.5%' then					
					dpatch('NZ','12807777', 'HR_PF.K.RUP.7');
					dpatch('NZ','11867781','NEW ZEALAND CUMULATIVE RELEASE 11i.NZ.08');
					dpatch('NZ','13627558','NZ STATUTORY UPDATES 2012');					
				end if;													
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if :apps_rel like '12.2%' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NZ','19245681', 'NEW ZEALAND CONSOLIDATED PATCH ABOVE- 12.2.3');	
								dbms_output.put_line('</div>');							
					elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777'  then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('NZ','13627558', ' 11I - NZ STATUTORY UPDATES - 2012 ');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>');dbms_output.put_line('<a name="NewZealandd"></a>'); datainstall('NZ',22);dbms_output.put_line('<a name="NewZealands"></a>');bg_generic('NZ',22);	dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;

--PL
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'PL'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page23" style="display: none;">');header('Poland');
			datainstall('PL',23);	bg_generic('PL',23);dbms_output.put_line('</div>');		
			documents('1527959.2','Information Center: Oracle HRMS (Poland)');
			dbms_output.put_line('</div>');
	end if;

--RU
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'RU'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page24" style="display: none;">');
			datainstall('RU',24);bg_generic('RU',24);			dbms_output.put_line('</div>');
			
			dbms_output.put_line('</div>');
	end if;

--SA
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SA'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page25" style="display: none;">');header('Saudi Arabia');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="SaudiArabiap"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('SA','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('SA','18723486', 'SA Unemployment insurance changes');
				elsif (:apps_rel like '12.1%') then					
					dpatch('SA','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('SA','18723486', 'SA Unemployment insurance changes');
					dpatch('SA','19054295', 'Can not create absence');
				elsif (:apps_rel like '12.0%') then					
					dpatch('SA','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('SA','18760981', 'SA Unemployment insurance changes');
				elsif :apps_rel like '11.5%' then					
					dpatch('SA','12807777', 'HR_PF.K.RUP.7');				
				end if;												
			dbms_output.put_line('</div>');
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="SaudiArabiad"></a>');datainstall('SA',25);dbms_output.put_line('<a name="SaudiArabias"></a>');bg_generic('SA',25);	dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;

--SE
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SE'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page26" style="display: none;">');header('Sweden');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Swedenp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('SE','19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('SE','20000288', 'R12.HR_PF.B.delta.8');										
				elsif (:apps_rel like '12.0%') then					
					dpatch('SE','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('SE','12589129', 'Delivers the Sweden legislative changes for 2011');				
				elsif :apps_rel like '11.5%' then					
					dpatch('SE','12807777', 'HR_PF.K.RUP.7');
					dpatch('SE','10393370', 'Delivers the Sweden legislative changes for 2011');
				end if;	
			dbms_output.put_line('</div>');
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="Swedend"></a>');datainstall('SE',26);dbms_output.put_line('<a name="Swedens"></a>');bg_generic('SE',26);	dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;
	
	--SG
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SG'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page27" style="display: none;">');header('Singapore');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="Singaporep"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			 if (:apps_rel like '12.2%') then					
					dpatch('SG','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('SG','20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');
				elsif (:apps_rel like '12.1%') then					
					dpatch('SG','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('SG','20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('SG','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('SG','20055967','IRAS and IR21 CHANGES EOY 2014');										
				elsif :apps_rel like '11.5%' then					
					dpatch('SG','12807777', 'HR_PF.K.RUP.7');
					dpatch('SG','17188127','SG.35 SINGAPORE CONSOLIDATED PATCH');				
				end if;													
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then	
								dbms_output.put_line('<br><div class="divItem"><div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');
								dbms_output.put_line('</div>');
					elsif (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','17651515','R121.SG.36 - SINGAPORE HRMS CONSOLIDATED PATCH');
								dbms_output.put_line('</div>');							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','17651515','R12.SG.36 - SINGAPORE HRMS CONSOLIDATED PATCH');
								dbms_output.put_line('</div>');	
							elsif  :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','17173295','R12.SG.35 - SINGAPORE HRMS CONSOLIDATED PATCH');
								dbms_output.put_line('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='12807777'  then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('SG','17188127','SINGAPORE CUMULATIVE RELEASE SG.35');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>');dbms_output.put_line('<a name="Singapored"></a>'); datainstall('SG',27);	dbms_output.put_line('<a name="Singapores"></a>');bg_generic('SG',27);dbms_output.put_line('</div>');		
			
			dbms_output.put_line('</div>');
	end if;

--AE
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AE'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page28" style="display: none;">');header('United Arab Emirates');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="UnitedArabEmiratesp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('AE','19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('AE','19900524','UAE National identifier validation changes');
					dpatch('AE','20075576','UAE National identifier validation changes and Formula Result rule for KW SI');
				elsif (:apps_rel like '12.1%') then					
					dpatch('AE','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('AE','19900524','UAE National identifier validation changes');
					dpatch('AE','19819953','ROUTING NUMBER IN UAE LEGISLATION');
				elsif (:apps_rel like '12.0%') then					
					dpatch('AE','16077077', 'R12.HR_PF.A.delta.11');	
					dpatch('AE','19900524','UAE National identifier validation changes');
					dpatch('AE','19819953','ROUTING NUMBER IN UAE LEGISLATION');
				elsif :apps_rel like '11.5%' then					
					dpatch('AE','12807777', 'HR_PF.K.RUP.7');					
				end if;											
			dbms_output.put_line('</div>');
			if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('AE','17449352', 'AFTER UPGRADE 12.1.3,ORA-00904:"U1": INVALID IDENTIFIER WHEN VIEW ITD BALANCE');
								dbms_output.put_line('</div>');	
					end if;		
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="UnitedArabEmiratesd"></a>');datainstall('AE',28);dbms_output.put_line('<a name="UnitedArabEmiratess"></a>');	bg_generic('AE',28);dbms_output.put_line('</div>');		
			documents('1506985.2','Information Center: Oracle HRMS (United Arab Emirates)');
			dbms_output.put_line('</div>');
	end if;

	
	--GB
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'GB'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page29" style="display: none;">');header('United Kingdom');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="UnitedKingdomp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then
					dpatch('GB','19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then
					dpatch('GB','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('GB','20513833','RTI GB UPDATE NI CATEGORY ERRORS');
					dpatch('GB','20066028','PENSERVER LEGISLATIVE CHANGES');
					dpatch('GB','20314902','YEAR END 2014-15 / START OF YEAR 2015-16');
					dpatch('GB','20201659','UK YEAR END 2014-15 / START OF YEAR 2015-16');	
					dpatch('GB','19223877','P11D LEGISLATIVE CHANGES for 2014-15');
					dpatch('GB','20591016','SHARED PARENTAL LEAVE AND PAY CHANGES');
					dpatch('GB','20692428','TAX YEAR END BUG FIXES');
					dpatch('GB','20888184','TAX YEAR END BUG FIXES');
					dpatch('GB','21033080','PENSIONS AUTOMATIC ENROLMENT/RE-ENROLMENT LEGISLATIVE CHANGES');
				elsif (:apps_rel like '12.0%') then
					dpatch('GB','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('GB','18776254','RTI CONSOLIDATED PATCH: SEPTEMBER 2014');
					dpatch('GB','18972503','RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES');
					dpatch('GB','18693666','DIRECT EARNINGS ATTACHMENT CHANGES: PHASE2');		
					dpatch('GB','18453569','LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme');
					dpatch('GB','18333366','DIRECT EARNINGS ATTACHMENT CHANGES');
					dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
					dpatch('GB','18285764', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/LGPS CHANGES');					
					dpatch('GB','18100149','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014');
					dpatch('GB','17274247','RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH');
				elsif :apps_rel like '11.5%' then
					dpatch('GB','17774746', 'HR_PF.K.RUP.9');
					dbms_output.put_line('<div class="divok">');
					dbms_output.put_line('Note: These patches are only available with ACS Service, please refer ');
					dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1597416.1" target="_blank">Note 1597416.1</a> Payroll Legislative Updates for Oracle E-Business Suite 11.5.10:<br>');
					dbms_output.put_line('</div>');
					dpatch('GB','18776031','RTI CONSOLIDATED PATCH: SEPTEMBER 2014');
					dpatch('GB','18972450','RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES');
					dpatch('GB','18449320','LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme');
					dpatch('GB','18333164','DIRECT EARNINGS ATTACHMENT CHANGES');
					dpatch('GB','18305045','UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014');
					dpatch('GB','18293579','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /P11D/LGPS CHANGES');
					dpatch('GB','18285780','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /LGPS CHANGES');
					dpatch('GB','18100105','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014');					
					dpatch('GB','18032762','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014:PHASE2 PATCH');					
					dpatch('GB','17964873','UK TAX YEAR END CHANGES 2013 - 2014');
					dpatch('GB','17274234','RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH');		
				end if;							
			dbms_output.put_line('</div>');
				if (:hr_status='Installed') then
					if (:apps_rel like '12.1%') then					
							dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
								dbms_output.put_line('</div>');
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
								dbms_output.put_line('</div>');								
							elsif :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('GB','16373594','TYE13 P11D LEGISLATIVE CHANGES FOR 2012-2013');
								dbms_output.put_line('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then
							if :rup_level='14488556' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('GB','18305045','UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014');	
								dbms_output.put_line('</div>');							
							
							end if;				
					end if;	
			end if;
			dbms_output.put_line('<br><div class="divok">');
			dbms_output.put_line('Useful documentation:<br>');
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1499667.1" target="_blank">Note 1499667.1</a> UK Real Time Information, RTI, Known Issues<br>');
			dbms_output.put_line('Once a defect fix is delivered in a consolidated patch, it will be removed from the known issues list and available in:<br>');
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1324671.1" target="_blank">Note 1324671.1</a> EBS UK Payroll : Real Time Information (RTI) White Paper and Patch Information<br>');
			dbms_output.put_line('</div>');
				
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="UnitedKingdomd"></a>');datainstall('GB',29);dbms_output.put_line('<a name="UnitedKingdoms"></a>');bg_generic('GB',29); rti();	dbms_output.put_line('</div>');		
			dbms_output.put_line('<a name="UnitedKingdomv"></a>');file_version('gb');
			file_version_uk();
			dbms_output.put_line('</div>');
			documents('1499667.1','UK Real Time Information, RTI, Known Issues','1324671.1','EBS UK Payroll : Real Time Information (RTI) White Paper and Patch Information');
			documents('1504309.2','Information Center: Oracle HRMS (UK)');
			dbms_output.put_line('</div>');
	end if;

end;
/



declare
v_exists number;
 -- Display patch
procedure dpatch (v_leg varchar2, v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;	  
	  v_exists number;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								 case v_leg
									when  'AU' then
										:e2:=:e2+1;
									when 'BE' then 
										:e3:=:e3+1;
									when 'CA' then 	
										:e4:=:e4+1;
									when 'CN' then 
										:e5:=:e5+1;
									when 'ES' then
										:e6:=:e6+1;
									when 'DE' then 
										:e7:=:e7+1;
									when 'DK' then
										:e8:=:e8+1;
									when 'FI' then 
										:e9:=:e9+1;
									when 'FR' then 
										:e10:=:e10+1;
									when 'HK' then 	
										:e11:=:e11+1;
									when 'HU' then 
										:e12:=:e12+1;
									when 'IE' then 
										:e13:=:e13+1;
									when 'IN' then 
										:e14:=:e14+1;
									when 'IT' then 
										:e15:=:e15+1;
									when 'JP' then
										:e16:=:e16+1;
									when 'KR' then
										:e17:=:e17+1;
									when 'KW' then
										:e18:=:e18+1;
									when 'MX' then 
										:e19:=:e19+1;
									when 'NL' then 
										:e20:=:e20+1;
									when 'NO' then 
										:e21:=:e21+1;
									when 'NZ' then
										:e22:=:e22+1;
									when 'PL' then 
										:e23:=:e23+1;
									when 'RU' then
										:e24:=:e24+1;
									when 'SA' then 
										:e25:=:e25+1;									
									when 'SE' then 
										:e26:=:e26+1;
									when 'SG' then
										:e27:=:e27+1;
									when 'AE' then 	
										:e28:=:e28+1;
									when 'GB' then 
										:e29:=:e29+1;
									when 'US' then
										:e30:=:e30+1;
									when 'ZA' then
										:e31:=:e31+1;
									else
									null;
								end case;
								 
								 dbms_output.put_line('<div class="diverr">');
								 dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>Please plan to install ');
								 dbms_output.put_line('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');	
								 dbms_output.put_line('</div>');
							else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							dbms_output.put_line('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
						EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
	end; 
	
procedure documents (v_no1 varchar2, v_note1 varchar2, v_no2 varchar2, v_note2 varchar2) is
begin
			dbms_output.put_line('<br><div class="divok">');
			dbms_output.put_line('Useful documentation:<br>');
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');			
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no2||'" target="_blank">Note '||v_no2||'</a> '||v_note2||'<br>');
			dbms_output.put_line('</div>');
end;
procedure documents (v_no1 varchar2, v_note1 varchar2) is
begin
			dbms_output.put_line('<br><div class="divok">');
			dbms_output.put_line('Useful documentation:<br>');
			dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id='||v_no1||'" target="_blank">Note '||v_no1||'</a> '||v_note1||'<br>');
			dbms_output.put_line('</div>');
end;

procedure bg_generic (v_leg varchar2, v_no number) is
	  v_bg hr_all_organization_units.organization_id%type;
	  v_name hr_all_organization_UNITS.NAME%type;	  
	  v_cur PER_BUSINESS_GROUPS.CURRENCY_CODE%type;
	  v_enabled PER_BUSINESS_GROUPS.ENABLED_FLAG%type;
	  v_date_from varchar2(15);
	  v_date_to varchar2(15);
	  v_hr varchar2(3);
	cursor c_bg (v_legislation varchar2)  is
			SELECT otl.name,o.organization_id,o3.ORG_INFORMATION10 currency_code,o4.ORG_INFORMATION2 enabled_flag ,to_char(o.date_from, 'DD-MON-YYYY') ,to_char(o.date_to, 'DD-MON-YYYY')
			FROM hr_all_organization_UNITS O , 
			hr_all_organization_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			and o3.ORG_INFORMATION9=v_legislation
			order by o.organization_id;
	v_short_name hr_organization_information.org_information1%type;			
			v_employee_number_generation fnd_lookups.meaning%type;
			v_applicant_number_generation fnd_lookups.meaning%type;
			v_contingent_worker_numb_gen fnd_lookups.meaning%type;
			v_grade_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_group_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_job_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_costing_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_position_flexfield_structure fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_competence_flex fnd_id_flex_structures_vl.id_flex_structure_name%type;
			v_currency hr_organization_information.org_information1%type;
			v_fiscal_year_start hr_organization_information.org_information1%type;
			v_minimum_working_age hr_organization_information.org_information1%type;
			v_maximum_working_age hr_organization_information.org_information1%type;
					
	
	v_lookup1 fnd_lookups.meaning%type;
	v_lookup2 fnd_lookups.meaning%type;
	v_lookup3 fnd_lookups.meaning%type;
	v_lookup4 fnd_lookups.meaning%type;	
	v_lookup9 fnd_lookups.meaning%type;
	v_lookup5 fnd_lookups.meaning%type;	
	v_lookup6 fnd_lookups.meaning%type;	
	v_lookup7 fnd_lookups.meaning%type;
	v_lookup8 fnd_lookups.meaning%type;
		
	
	cursor c_payroll (t_bg  NUMBER) is
				SELECT   prl.payroll_name
				,prl.period_type
				,prl.first_period_end_date
				,prl.number_of_years
				,prl.period_reset_years
				,prl.pay_date_offset
				,prl.direct_deposit_date_offset
				,prl.pay_advice_date_offset
				,prl.cut_off_date_offset
				,nvl (opm.org_payment_method_name, 'No Default Payment Method Set') default_payment_method
				,con.consolidation_set_name consolidation_set
				,prl.workload_shifting_level
				,prl.arrears_flag
				,prl.negative_pay_allowed_flag
				,prl.multi_assignments_flag
				,prl.prl_information1				
				,prl.prl_information21 days_after_period_start
				,prl.prl_information22 days_after_period_end
				,hr_general_utilities.get_lookup_meaning('MODELER_AVAILABLITY',prl.prl_information20)  modeling_availability_rule
				,prl.payroll_id
				,prl.default_payment_method_id default_payment_method_id				
		FROM     pay_all_payrolls_f prl
				,pay_org_payment_methods_f opm
				,pay_consolidation_sets con
				,hr_all_organization_units org				
				,per_time_period_types tpt
				,per_time_period_rules tpr
		WHERE    1 = 1
			 AND con.consolidation_set_id = prl.consolidation_set_id
			 AND opm.org_payment_method_id(+) = prl.default_payment_method_id
			 AND org.organization_id(+) = prl.organization_id			
			 AND tpt.period_type = prl.period_type
			 AND tpr.number_per_fiscal_year = tpt.number_per_fiscal_year
			 AND sysdate BETWEEN prl.effective_start_date AND prl.effective_end_date
			 AND prl.business_group_id = t_bg
			 order by 1;
	v_payroll_name pay_all_payrolls_f.payroll_name%type;
	v_period_type pay_all_payrolls_f.period_type%type;
	v_first_date pay_all_payrolls_f.first_period_end_date%type;
	v_number_of_years pay_all_payrolls_f.number_of_years%type;
	v_period_reset_years pay_all_payrolls_f.period_reset_years%type;
	v_pay_date_offset pay_all_payrolls_f.pay_date_offset%type;
	v_direct_deposit pay_all_payrolls_f.direct_deposit_date_offset%type;
	v_pay_advice_date_offset pay_all_payrolls_f.pay_advice_date_offset%type;
	v_cut_off_date pay_all_payrolls_f.cut_off_date_offset%type;
	v_default_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_consolidation pay_consolidation_sets.consolidation_set_name%type;
	v_workload_shifting pay_all_payrolls_f.workload_shifting_level%type;
	v_arrears_flag pay_all_payrolls_f.arrears_flag%type;
	v_negative_pay pay_all_payrolls_f.negative_pay_allowed_flag%type;
	v_multi_assignments pay_all_payrolls_f.multi_assignments_flag%type;
	v_legal_employer hr_all_organization_units.name%type;
	v_prl_information21 pay_all_payrolls_f.prl_information21%type;
	v_prl_information22 pay_all_payrolls_f.prl_information22%type;
	v_modeling_availability fnd_lookups.meaning%type;
	
	v_seg2 pay_external_accounts.segment2%type;
	v_seg3 pay_external_accounts.segment3%type;
	v_seg5 pay_external_accounts.segment5%type;
	v_seg6 pay_external_accounts.segment6%type;
	v_seg7 pay_external_accounts.segment7%type;
	v_seg10 pay_external_accounts.segment10%type;
	
	cursor c_org_pay (t_id  NUMBER) is
		SELECT   hr_general_utilities.get_lookup_meaning('PER_EU_COUNTRIES',pea.territory_code) country
				,hr_general_utilities.get_lookup_meaning ('HR_NL_BANK', pea.segment1)  bank_name
				,segment2 account_number
				,segment3 postal_code
				,hr_general_utilities.get_lookup_meaning ('HR_NL_CITY', pea.segment4)  city
				,segment5 street
				,segment6 telephone_number
				,segment7 telephone_extension
				,hr_general_utilities.get_lookup_meaning('HR_NL_BIC_CODES',pea.segment9) bank_identifier_code
				,segment10 iban_number
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_payment) cost_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_payment) cost_cleared_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.cost_cleared_void_payment) cost_cleared_void_payment
				,hr_general_utilities.get_lookup_meaning('HR_NL_YES_NO',popm.exclude_manual_payment) exclude_manual_payment
		FROM     pay_external_accounts pea, (SELECT   org_payment_method_id
													 ,external_account_id
													 ,business_group_id
													 ,cost_payment
													 ,cost_cleared_payment
													 ,cost_cleared_void_payment
													 ,exclude_manual_payment
													 ,effective_start_date
													 ,effective_end_date
											 FROM     pay_org_payment_methods_f) popm
		WHERE    1 = 1
			 AND pea.external_account_id = popm.external_account_id
			 AND popm.org_payment_method_id = t_id
			 AND sysdate BETWEEN effective_start_date AND effective_end_date;
			 
	cursor c_Organizational (t_pid  NUMBER, t_dpmid NUMBER) is
			SELECT   opm.org_payment_method_name org_paymentmethod_name
				,pt.payment_type_name payment_type
				,CASE
				   WHEN opu.org_payment_method_id = t_dpmid
				   THEN
					 'Yes'
				   ELSE
					 'No'
				 END default_payment_method
				,opu.effective_start_date
				,opu.effective_end_date
				,opu.org_payment_method_id
				,pt.payment_type_id
		FROM     pay_org_pay_method_usages_f opu
				,pay_org_payment_methods_f opm
				,pay_payment_types pt
		WHERE    1 = 1
			 AND opm.org_payment_method_id = opu.org_payment_method_id
			 AND pt.payment_type_id = opm.payment_type_id
			 AND sysdate between opm.effective_start_date and opm.effective_end_date
			 AND sysdate between opu.effective_start_date and opu.effective_end_date
			 AND opu.payroll_id = t_pid
			 order by 1;
	
	v_payroll_id pay_org_pay_method_usages_f.payroll_id%type;
	v_org_payment pay_org_payment_methods_f.org_payment_method_name%type;
	v_payment_type_name pay_payment_types.payment_type_name%type;
	v_default_payment_method_id pay_all_payrolls_f.default_payment_method_id%type;
	v_default_payment_method varchar2(10);
	v_effective_start_date pay_org_pay_method_usages_f.effective_start_date%type;
	v_effective_end_date pay_org_pay_method_usages_f.effective_end_date%type;
	v_org_payment_method_id pay_org_pay_method_usages_f.org_payment_method_id%type;
	v_payment_type_id pay_payment_types.payment_type_id%type;
	
    v_id_flex FND_ID_FLEX_STRUCTURES_TL.ID_FLEX_NUM%type;
	v_code varchar2(30);
	v_cos_name varchar2(30);
	v_description varchar2(30);
	v_freeze varchar2(10);
	v_cos_enabled varchar2(10);
	v_dynamic varchar2(10);
	cursor c_costing (t_bg  NUMBER) is
		SELECT t.ID_FLEX_NUM,substrb(b.ID_FLEX_STRUCTURE_CODE,1,25) Code,
		   substrb(t.ID_FLEX_STRUCTURE_NAME,1,25) Name,
		   substrb(t.DESCRIPTION,1,25) Description,
		   lpad(substr(FREEZE_FLEX_DEFINITION_FLAG,1,8),8) Frz,
		   lpad(substr(ENABLED_FLAG,1,8),8) Enable,
		   lpad(substr(DYNAMIC_INSERTS_ALLOWED_FLAG,1,9),9) Dynamic
	FROM FND_ID_FLEX_STRUCTURES b, FND_ID_FLEX_STRUCTURES_TL t
	WHERE (t.APPLICATION_ID=801) 
		and t.language='US'
		and b.ID_FLEX_CODE=t.ID_FLEX_CODE and b.ID_FLEX_NUM=t.ID_FLEX_NUM and
		  (t.ID_FLEX_CODE='COST')
		  and
		  (t.ID_FLEX_NUM = (select cost_allocation_structure
				  from per_business_groups
				  where business_group_id = t_bg))
	order by t.application_id, t.id_flex_code, t.id_flex_structure_name;

	v_segment varchar2(30);
	v_column varchar2(15);
	v_seg_number FND_ID_FLEX_SEGMENTS.SEGMENT_NUM%type;
	v_display varchar2(10);
	v_required varchar2(10);
	v_security varchar2(10);
	v_cos_enabled2 varchar2(10);
	
	
	cursor c_costing_segments (t_flex  NUMBER) is
	SELECT substrb(SEGMENT_NAME,1,25) Name,
		   substrb(DESCRIPTION,1,25) Description,
		   substr(ENABLED_FLAG,1,3) Enabled,
		   substr(t.APPLICATION_COLUMN_NAME,1,10) Col_Name,
		   SEGMENT_NUM Seg_No,
		   lpad(substr(DISPLAY_FLAG,1,5),5) Disp,
		   lpad(substr(REQUIRED_FLAG,1,5),5) Reqd,
		   lpad(substr(SECURITY_ENABLED_FLAG,1,5),5) Secr
	FROM FND_ID_FLEX_SEGMENTS_TL T, FND_ID_FLEX_SEGMENTS B
	WHERE (t.APPLICATION_ID=801) 
		and t.language='US' 
	   and b.ID_FLEX_NUM = t_flex 
	   and b.ID_FLEX_CODE=t.ID_FLEX_CODE and b.ID_FLEX_NUM=t.ID_FLEX_NUM and  B.APPLICATION_COLUMN_NAME = T.APPLICATION_COLUMN_NAME and
		   (b.ID_FLEX_CODE='COST') and 
		   (b.APPLICATION_ID=801) 
	order by t.application_id, t.id_flex_code, t.id_flex_num, decode(b.enabled_flag, 'Y', 1, 'N', 2), b.segment_num;

	
	
	v_cost varchar2(30);
	v_atr varchar2(15);
	cursor c_costing_qualifiers (t_flex  NUMBER, t_seg NUMBER) is	
	SELECT substrb(FSAV.SEGMENT_ATTRIBUTE_TYPE,1,20) Cost_Level,
		   lpad(substr(FSAV.ATTRIBUTE_VALUE,1,10),10) Visible
	FROM FND_SEGMENT_ATTRIBUTE_VALUES FSAV, FND_ID_FLEX_SEGMENTS FIFS, FND_ID_FLEX_SEGMENTS_TL T
	WHERE 
	FIFS.APPLICATION_ID = T.APPLICATION_ID and FIFS.ID_FLEX_CODE = T.ID_FLEX_CODE and
	FIFS.ID_FLEX_NUM = T.ID_FLEX_NUM and FIFS.APPLICATION_COLUMN_NAME = T.APPLICATION_COLUMN_NAME and T.LANGUAGE = 'US' and
	EXISTS (SELECT NULL 
				  FROM FND_SEGMENT_ATTRIBUTE_TYPES T 
				  WHERE T.APPLICATION_ID =  FSAV.APPLICATION_ID AND 
						T.ID_FLEX_CODE =  FSAV.ID_FLEX_CODE AND 
						T.SEGMENT_ATTRIBUTE_TYPE =  FSAV.SEGMENT_ATTRIBUTE_TYPE AND 
						GLOBAL_FLAG = 'N') and
		   (FSAV.ID_FLEX_NUM = t_flex) and (FIFS.SEGMENT_NUM = t_seg) and
		   (FSAV.APPLICATION_COLUMN_NAME = FIFS.APPLICATION_COLUMN_NAME) and
		   (FSAV.ID_FLEX_CODE='COST') and 
		   (FSAV.APPLICATION_ID=801) and
		   (FSAV.ID_FLEX_NUM = FIFS.ID_FLEX_NUM)
	order by FSAV.segment_attribute_type, FIFS.APPLICATION_COLUMN_NAME, FIFS.SEGMENT_NAME;
	
begin
		
	dbms_output.put_line('<br><DIV class=divItem>');
	dbms_output.put_line('<DIV  class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b"  onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Business Group Information</A></DIV>');					
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql500'||:v_link_no||'" style="display:none" >');
	:v_link_no:=:v_link_no+1;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Business Group Information:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql500'||:v_link_no||'" style="display:none">');
	:v_link_no:=:v_link_no+1;
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
	dbms_output.put_line('SELECT    haou.name,hoi.organization_id,pbg.currency_code ,pbg.enabled_flag ,pbg.date_from ,pbg.date_to	  <br>');
						dbms_output.put_line('FROM       hr_organization_information hoi,hr_all_organization_units haou,per_business_groups pbg<br>');
						dbms_output.put_line('WHERE      hoi.organization_id = haou.organization_id<br>');
						dbms_output.put_line('AND pbg.organization_id = haou.organization_id<br>');
						dbms_output.put_line('AND hoi.org_information_context = ''Business Group Information''<br>');
						dbms_output.put_line('and pbg.legislation_code='''||v_leg||'''<br>');							
						dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
       
		
    :n := dbms_utility.get_time;
    dbms_output.put_line(' <TR>');
	dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
	
		
    open c_bg(v_leg);
        loop
           fetch c_bg into v_name,v_bg,v_cur,v_enabled,v_date_from,v_date_to;					
			EXIT WHEN  c_bg%NOTFOUND;			
			dbms_output.put_line('<DIV class=divItem>');
			dbms_output.put_line('<DIV class=divItemTitle><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_bg||' - '||v_name||'</A></DIV>');
			dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
							
			dbms_output.put_line('Currency: '|| v_cur||'<br>');
			dbms_output.put_line('Enabled Flag: '|| v_enabled||'<br>');
			dbms_output.put_line('Date From: '|| v_date_from||'<br>');
			dbms_output.put_line('Date To: '|| v_date_to||'<br>');
		
			SELECT   org_information1 short_name					
					,hr_general_utilities.get_lookup_meaning('EMP_NUM_GEN_METHOD',org_information2) employee_number_generation
					,hr_general_utilities.get_lookup_meaning('APL_NUM_GEN_METHOD',org_information3) applicant_number_generation
					,hr_general_utilities.get_lookup_meaning('CWK_NUM_GEN_METHOD',org_information16) contingent_worker_numb_gen
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information4
							AND id_flex_code = 'GRD')       grade_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information5
							AND id_flex_code = 'GRP')        group_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information6
							AND id_flex_code = 'JOB')        job_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information7
							AND id_flex_code = 'COST')       costing_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information8
							AND id_flex_code = 'POS')        position_flexfield_structure
					, (SELECT   id_flex_structure_name
					   FROM     fnd_id_flex_structures_vl
					   WHERE    id_flex_num = org_information15
							AND id_flex_code = 'CMP')        competence_flexfield_structure
					,org_information10 currency
					,org_information11 fiscal_year_start
					,org_information12 minimum_working_age
					,org_information13 maximum_working_age
					into v_short_name,v_employee_number_generation,v_applicant_number_generation,v_contingent_worker_numb_gen, v_grade_flexfield_structure,v_group_flexfield_structure,v_job_flexfield_structure,v_costing_flexfield_structure,v_position_flexfield_structure,v_competence_flex,v_currency,v_fiscal_year_start,v_minimum_working_age,v_maximum_working_age
					FROM     hr_organization_information hoi
							, (SELECT   name, organization_id FROM hr_all_organization_units)
							 hou_bg
					WHERE    1 = 1
						 AND hoi.organization_id = hou_bg.organization_id
						 AND hoi.org_information_context LIKE 'Business Group Information'
						 AND hoi.org_information9 = v_leg
						 AND hou_bg.organization_id = v_bg 
						 AND	 rownum < 2;
						 
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Business Group Info Setup</A>');
			dbms_output.put_line('<table id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;
			dbms_output.put_line('<tr><th>Organization Short Name</th><th>Employee Number Generation</th><th>Applicant Number Generation</th>');
			dbms_output.put_line('<th>Contingent Worker Numb Gen</th><th>Grade Flexfield Structure</th><th>Group Flexfield Structure</th>');
			dbms_output.put_line('<th>Job Flexfield Structure</th><th>Costing Flexfield Structure</th><th>Position Flexfield Structure</th><th>Competence Flexfield Structure</th>');
			dbms_output.put_line('<th>Currency</th><th>Fiscal Year Start</th><th>Minimum Working Age</th>');
			dbms_output.put_line('<th>Maximum Working Age</th></tr>');
		
			dbms_output.put_line('<TR><TD>'||v_short_name||'</TD>'||chr(10)||'<TD>'||v_employee_number_generation||'</TD>'||chr(10)||'<TD>'||v_applicant_number_generation||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_contingent_worker_numb_gen||'</TD>'||chr(10)||'<TD>'||v_grade_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_group_flexfield_structure||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_job_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_costing_flexfield_structure||'</TD>'||chr(10)||'<TD>'||v_position_flexfield_structure||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_competence_flex||'</TD>'||chr(10)||'<TD>'||v_currency||'</TD>'||chr(10)||'<TD>'||v_fiscal_year_start||'</TD>'||chr(10));
			dbms_output.put_line('<TD>'||v_minimum_working_age||'</TD>'||chr(10)||'<TD>'||v_maximum_working_age||'</TD></TR>'||chr(10));
			dbms_output.put_line('</table><br>');					  
								  
		
	
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;General Payroll Information</A>');
			dbms_output.put_line('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			dbms_output.put_line('<tr><th>Payroll Name</th><th>Period Type</th><th>First Period End Date</th><th>Number of Years</th><th>Period Reset Years</th>');
			dbms_output.put_line('<th>Pay Date Offset</th><th>Direct Deposit Date Offset</th>');
			dbms_output.put_line('<th>Pay advice date offset</th><th>Cut off date offset</th><th>Default Payment Method</th><th>Consolidation Set</th>');
			dbms_output.put_line('<th>Workload Shifting Level</th><th>Arrears Flag</th><th>Negative pay allowed flag</th><th>Multi assignments flag</th><th>Legal Employer ID</th>');
			dbms_output.put_line('<th>Modeling Availability Rule</th><th>Days after period start</th><th>Days after period end</th></tr>');
			
			
			open c_payroll(v_bg);
			loop
				  fetch c_payroll into v_payroll_name,v_period_type,v_first_date,v_number_of_years,v_period_reset_years,v_pay_date_offset,v_direct_deposit,v_pay_advice_date_offset,v_cut_off_date,v_default_payment,v_consolidation,v_workload_shifting,v_arrears_flag,v_negative_pay,v_multi_assignments,v_legal_employer,v_prl_information21,v_prl_information22,v_modeling_availability,v_payroll_id,v_default_payment_method_id;
				  EXIT WHEN  c_payroll%NOTFOUND;
				  dbms_output.put_line('<TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_payroll_name||'</A>');
					dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; Valid Organizational Payment Methods');
						dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table>');
							if v_default_payment_method_id is null then
							dbms_output.put_line('<tr><td>Default Payment Method is null</th></tr>');
							else
							dbms_output.put_line('<tr><th>Org Payment Method</th><th>Payment Type</th><th>Default Payment Method</th>');
							dbms_output.put_line('<th>Effective Start Date</th><th>Effective End Date</th><th>Org Payment Method ID</th><th>Payment Type ID</th></tr>');
							open c_Organizational(v_payroll_id,v_default_payment_method_id);
							loop
								  fetch c_Organizational into v_org_payment,v_payment_type_name,v_default_payment_method,v_effective_start_date,v_effective_end_date,v_org_payment_method_id,v_payment_type_id;
								  EXIT WHEN  c_Organizational%NOTFOUND;				  
								  dbms_output.put_line('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; '||v_org_payment||'</A>');
								  dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; Organizational payment method information');
								  dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table >');								 							  
								  dbms_output.put_line('<tr><th>Country</th><th>Bank name</th><th>Account number</th><th>Postal code</th><th>City</th><th>Street</th><th>Telephone number</th><th>');
								  dbms_output.put_line('Telephone extension</th><th>Bank identifier code</th><th>IBAN</th><th>Cost payment</th><th>Cost cleared payment</th><th>Cost cleared void payment</th><th>');
								  dbms_output.put_line('Exclude manual payment</th></tr>');
								  open c_org_pay(v_org_payment_method_id);
									loop
										  fetch c_org_pay into v_lookup1,v_lookup2,v_seg2,v_seg3, v_lookup3,v_seg5,v_seg6,v_seg7,v_lookup4,v_seg10,v_lookup9,v_lookup5,v_lookup6,v_lookup7;
										  EXIT WHEN  c_org_pay%NOTFOUND;				  
										      dbms_output.put_line('<TR><TD>'||v_lookup1||'</TD>'||chr(10)||'<TD>'||v_lookup2||'</TD>'||chr(10)||'<TD>'||v_seg2||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg3||'</TD>'||chr(10)||'<TD>'||v_lookup3||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg5||'</TD>'||chr(10)||'<TD>'||v_seg6||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg7||'</TD>'||chr(10)||'<TD>'||v_lookup4||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_seg10||'</TD>'||chr(10)||'<TD>'||v_lookup9||'</TD>'||chr(10));
											  dbms_output.put_line('<TD>'||v_lookup5||'</TD>'||chr(10)||'<TD>'||v_lookup6||'</TD>'||chr(10));											 
											  dbms_output.put_line('<TD>'||v_lookup7||'</TD></TR>'||chr(10));     
									end loop;
									close c_org_pay;
								dbms_output.put_line('</table><br></div>');							  
								  
								  dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_payment_type_name||'</TD>'||chr(10)||'<TD>'||v_default_payment_method||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_effective_start_date||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_effective_end_date||'</TD>'||chr(10)||'<TD>'||v_org_payment_method_id||'</TD>'||chr(10));								 
								  dbms_output.put_line('<TD>'||v_payment_type_id||'</TD></TR>'||chr(10));         
							end loop;
							close c_Organizational;
							end if;
						dbms_output.put_line('</table><br>');
						
				  dbms_output.put_line('</TD>');
				 
				  
				  dbms_output.put_line('<TD>'||v_period_type||'</TD>'||chr(10)||'<TD>'||v_first_date||'</TD>'||chr(10)||'<TD>'||v_number_of_years||'</TD>'||chr(10));
				  dbms_output.put_line('<TD>'||v_period_reset_years||'</TD>'||chr(10)||'<TD>'||v_pay_date_offset||'</TD>'||chr(10)||'<TD>'||v_direct_deposit||'</TD>'||chr(10));
				  dbms_output.put_line('<TD>'||v_pay_advice_date_offset||'</TD>'||chr(10)||'<TD>'||v_cut_off_date||'</TD>');
					dbms_output.put_line('<TD>'||v_default_payment||'</TD>'||chr(10)||'<TD>'||v_consolidation||'</TD>'||chr(10)||'<TD>'||v_workload_shifting||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_arrears_flag||'</TD>'||chr(10)||'<TD>'||v_negative_pay||'</TD>'||chr(10)||'<TD>'||v_multi_assignments||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_legal_employer||'</TD>'||chr(10)||'<TD>'||v_modeling_availability||'</TD>'||chr(10)||'<TD>'||v_prl_information21||'</TD>'||chr(10));
					dbms_output.put_line('<TD>'||v_prl_information22||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_payroll;
			dbms_output.put_line('</table><br><br>');			
			
			dbms_output.put_line('<br><br><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654;Cost Flexfield Structure and Values</A>');
			dbms_output.put_line('<table width="95%" id="s1sql500'||:v_link_no||'" style="display: none;">');
			:v_link_no:=:v_link_no+1;			
			dbms_output.put_line('<tr><th>Name</th><th>ID Flex Number</th><th>Code</th><th>Description</th><th>Freeze</th>');
			dbms_output.put_line('<th>Enable</th><th>Dynamic</th></tr>');
			open c_costing(v_bg);
			loop
				  fetch c_costing into v_id_flex,v_code,v_cos_name,v_description,v_freeze,v_cos_enabled,v_dynamic;
				  EXIT WHEN  c_costing%NOTFOUND;
				  dbms_output.put_line('<TR><TD width="25%"><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">&#9654; '||v_cos_name||'</A>');
					dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
					:v_link_no:=:v_link_no+1;
						dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; <b>Flexfield Segments Setup</b>');
						dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table>');
               						
							dbms_output.put_line('<tr><th>Segment Name</th><th>Description</th><th>Enabled</th>');
							dbms_output.put_line('<th>Application Column Name</th><th>Display</th><th>Required</th><th>Security</th></tr>');
							 
							open c_costing_segments(v_id_flex);
							loop
								  fetch c_costing_segments into v_segment,v_description,v_cos_enabled2,v_column,v_seg_number,v_display,v_required,v_security;
								  EXIT WHEN  c_costing_segments%NOTFOUND;				  
								  dbms_output.put_line('<TR><TD><A class=detail id="s1sql500'||:v_link_no||'b" onclick="displayItem(this,''s1sql500'||:v_link_no||''');" href="javascript:;">\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;&#9654; '||v_segment||'</A>');
								  dbms_output.put_line('<DIV id="s1sql500'||:v_link_no||'" style="display: none;">');
								  :v_link_no:=:v_link_no+1;
								  dbms_output.put_line('<br><br>\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp; <b>Flexfield Qualifiers</b>');
								  dbms_output.put_line('\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;\&nbsp;<table >');	   							 							  
								  dbms_output.put_line('<tr><th>Cost Level</th><th>Visible</th></tr>');
								  open c_costing_qualifiers(v_id_flex,v_seg_number);
									loop
										  fetch c_costing_qualifiers into v_cost,v_atr;
										  EXIT WHEN  c_costing_qualifiers%NOTFOUND;				  
										      dbms_output.put_line('<TR><TD>'||v_cost||'</TD>'||chr(10)||'<TD>'||v_atr||'</TD></TR>'||chr(10));     
									end loop;
									close c_costing_qualifiers;
								dbms_output.put_line('</table><br></div>');							  
								  
								  dbms_output.put_line('</TD>'||chr(10)||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_cos_enabled2||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_column||'</TD>'||chr(10));
								  dbms_output.put_line('<TD>'||v_display||'</TD>'||chr(10)||'<TD>'||v_required||'</TD>'||chr(10));								 
								  dbms_output.put_line('<TD>'||v_security||'</TD></TR>'||chr(10));         
							end loop;
							close c_costing_segments;
							
						dbms_output.put_line('</table><br>');
						
				  dbms_output.put_line('</TD>');
				 
				  dbms_output.put_line('<TD>'||v_id_flex||'</TD><TD>'||v_code||'<TD>'||v_description||'</TD>'||chr(10)||'<TD>'||v_freeze||'</TD>'||chr(10)||'<TD>'||v_cos_enabled||'</TD>'||chr(10));				 
				  dbms_output.put_line('<TD>'||v_dynamic||'</TD></TR>'||chr(10));				  
							  
				  
			end loop;
			close c_costing;
			dbms_output.put_line('</table><br><br>');				
			
			dbms_output.put_line('</DIV>');
			dbms_output.put_line('</DIV>');        
			
        end loop;
    close c_bg;
                            
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line('</TD></TR> <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;

	
procedure datainstall (v_leg varchar2, v_no number) is
	v_exists number;
    v_apps hr_legislation_installations.application_short_name%type;
    v_action varchar2(20);
	v_date hr_legislation_installations.last_update_date%type; v_legislation hr_legislation_installations.legislation_code%type;
    cursor di_actions is
        select 
		    legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION,   
		   decode(action,'F','Force Install'
						 ,'C','Clear'
						 ,'U','Upgrade'
						 ,'I','Install') ACTION,
		   last_update_date
		from hr_legislation_installations
		where (status is not null or action is not null)
		and legislation_code =v_leg;
	cursor rules is
		select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules
		where legislation_code =v_leg
		order by legislation_code;
	V_RULE_TYPE pay_legislation_rules.RULE_TYPE%type;
	V_RULE_MODE pay_legislation_rules.RULE_MODE%type;
begin
	dbms_output.put_line('<div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Data install status</div><br>');			
	
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>DataInstaller actions:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql200'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql200'||v_no||'" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="3" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('          select  legislation_code, substr(APPLICATION_SHORT_NAME,1,11) APPLICATION, <br>');
    dbms_output.put_line('          decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'') ACTION,<br>');
    dbms_output.put_line('           last_update_date <br>');           
    dbms_output.put_line('           from hr_legislation_installations <br>');   
    dbms_output.put_line('           where (status is not null or action is not null)<br>');                  
    dbms_output.put_line('            and legislation_code ='''||v_leg||''';<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');
    dbms_output.put_line(' <TH><B>Legislation</B></TD>'); dbms_output.put_line(' <TH><B>Application Name</B></TD>');
    dbms_output.put_line(' <TH><B>Action</B></TD>');
    dbms_output.put_line(' <TH><B>Last Update Date</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open di_actions;
        loop
            fetch di_actions into  v_legislation , v_apps, v_action, v_date;
            EXIT WHEN  di_actions%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD></TR>'||chr(10));
        end loop;
    close di_actions;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> <br> ');
	dbms_output.put_line('</div>');
	
	dbms_output.put_line('<br><div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Settings</div><br>');			
	dbms_output.put_line('<DIV class=divItem>');
	dbms_output.put_line('<DIV id="s1sql300'||v_no||'b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql300'||v_no||''');" href="javascript:;">&#9654; Pay Legislation Rules</A></DIV>');		
			
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql300'||v_no||'" style="display:none" >');
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('     <B>Pay Legislation Rules:</B></font></TD>');
    dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
    dbms_output.put_line('       <A class=detail  onclick="displayItem2(this,''s1sql301'||v_no||''');" href="javascript:;">&#9654; Show SQL Script</A>');
    dbms_output.put_line('   </TD>');
    dbms_output.put_line(' </TR>');
    dbms_output.put_line(' <TR id="s1sql301'||v_no||'" style="display:none">');
    dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
    dbms_output.put_line('       <blockquote><p align="left">');
    dbms_output.put_line('        select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules  <br>');   
    dbms_output.put_line('        order by LEGISLATION_CODE;<br>');   
    dbms_output.put_line('           where legislation_code ='''||v_leg||''';<br>');
    dbms_output.put_line('          </blockquote><br>');
    dbms_output.put_line('     </TD>');
    dbms_output.put_line('   </TR>');
    dbms_output.put_line(' <TR>');    
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Legislation</B></TD>');                        
    dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Rule Type</B></TD>');
	dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Rule Mode</B></TD>');
	
    :n := dbms_utility.get_time;
                              
    open rules;
        loop
            fetch rules into v_legislation, v_rule_type, v_rule_mode;
            EXIT WHEN  rules%NOTFOUND;
            dbms_output.put_line('<TR><TD>'||v_legislation||'</TD>'||chr(10)||'<TD>'||v_rule_type||'</TD>'||chr(10)||'<TD>'||v_rule_mode||'</TD></TR>'||chr(10));
        end loop;
    close rules;
                                  
    
    :n := (dbms_utility.get_time - :n)/100;
    dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
    dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    dbms_output.put_line(' </TABLE> ');
	dbms_output.put_line('</div>');
	
EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;



PROCEDURE print_big_text(bigTextInput VARCHAR2)
  IS    
    bigText    VARCHAR2(32767) := bigTextInput;
  BEGIN
    LOOP
      EXIT WHEN bigText IS NULL;        
      dbms_output.put_line( SUBSTR(bigText, 1, 250) );     
      bigText := SUBSTR(bigText, 251);
    END LOOP;
  END print_big_text;
  

-- Display Setup for PDF Reports
procedure pdf_reports (v_leg varchar2) is
	v_database_id varchar2(100);
	v_output fnd_concurrent_programs.OUTPUT_FILE_TYPE%type;
	v_rows number;
	v_patch number;
	v number;
	status_leg varchar2(2);
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue8 boolean := FALSE;
	v_variable FND_ENV_CONTEXT.VARIABLE_NAME%type;
	v_value FND_ENV_CONTEXT.VALUE%type;
	cursor c_env is select VARIABLE_NAME , nvl(VALUE,'null') 
			from FND_ENV_CONTEXT
			where CONCURRENT_PROCESS_ID in
				  (select max(CONCURRENT_PROCESS_ID) from FND_CONCURRENT_PROCESSES
				   where CONCURRENT_QUEUE_ID in (select CONCURRENT_QUEUE_ID from FND_CONCURRENT_QUEUES where CONCURRENT_QUEUE_NAME = 'WFMLRSVC')
					 and QUEUE_APPLICATION_ID in (select APPLICATION_ID from FND_APPLICATION where APPLICATION_SHORT_NAME = 'FND'))
			  and VARIABLE_NAME in ('APPL_TOP', 'AF_JRE_TOP', 'FND_SECURE', 'APPLPTMP', 'PY_LIB_PATH', 'PY_PRELOAD')
			order by VARIABLE_NAME;
begin
	
	dbms_output.put_line('<br><div class="divSection">' );
	dbms_output.put_line('<div class="divSectionTitle">Setup For PDF Reports</div><br>');			
	
	case v_leg
		when 'US' then
			v:=1;
		when 'CA' then
			v:=2;
		when 'MX' then
			v:=3;
		else
			null;
	end case;
	
	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2">');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Variable Settings</B></font></TD>');
	dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Variable</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD>');
	:n := dbms_utility.get_time;	
	open c_env;
    loop
          fetch c_env into v_variable,v_value;
          EXIT WHEN  c_env%NOTFOUND;
          dbms_output.put_line('<TR><TD>'||v_variable||'</TD>'||chr(10)||'<TD>');
			print_big_text(v_value);
			dbms_output.put_line('</TD></TR>'||chr(10));         
    end loop;
    close c_env;
	
	:n := (dbms_utility.get_time - :n)/100;
	dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
	dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	dbms_output.put_line(' </TABLE><br> ');


	dbms_output.put_line(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2">');
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line('   <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('     <B>Concurrent Programs</B></font></TD>');
		dbms_output.put_line('     <TD bordercolor="#DEE6EF">');
		dbms_output.put_line('<A class=detail id="s1sql6'||v||'b" style="width:220px" onclick="displayItem2(this,''s1sql6'||v||''');" href="javascript:;">&#9654; Show SQL Script</A>');
		dbms_output.put_line('   </TD>');
		dbms_output.put_line(' </TR>');
		dbms_output.put_line(' <TR id="s1sql6'||v||'" style="display:none">');
		dbms_output.put_line('    <TD BGCOLOR=#DEE6EF colspan="2" height="60">');
		dbms_output.put_line('       <blockquote><p align="left">');
		dbms_output.put_line('         select CONCURRENT_PROGRAM_NAME, OUTPUT_FILE_TYPE from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) in ( <br>');
		case v_leg
		when 'US' then
			dbms_output.put_line('''PAYARCHCHQW'',''PYCADEPADVXML'', ''PYUSDEPADVXML'',''PAYUSW2PDF'', ''PYUS941T'',''EMP_1099R_PDF''');
		when 'CA' then
			dbms_output.put_line('''PYXMLRL1'',''PYCARL2PXML'',''PAYCAT4PDF'',''PAYCAT4APDF''');
		when 'MX' then
			dbms_output.put_line('''PAYMXDD''');
		else
			null;
		end case;
		dbms_output.put_line('          )');
		dbms_output.put_line('          </blockquote><br>');
		dbms_output.put_line('     </TD>');
		dbms_output.put_line('   </TR>');
		dbms_output.put_line(' <TR>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Name</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Program Code</B></TD>');
		dbms_output.put_line(' <TH BGCOLOR=#DEE6EF><font face="Calibri"><B>Output Type</B></TD>');
	
		:n := dbms_utility.get_time;
		
		if :apps_rel like '12.2%' then
			v_patch:=1;
		elsif (:apps_rel like '12.1%') or (:apps_rel like '12.0%') then
			select count(1) into v_patch from ad_bugs where bug_number='15832452';
		elsif :apps_rel like '11.5%' then
			select count(1) into v_patch from ad_bugs where bug_number='16090736';
		end if;

		case v_leg
		when 'US' then
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYARCHCHQW';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYARCHCHQW' and rownum < 2;
			dbms_output.put_line('<TR><TD>Checkwriter (XML)</TD><TD>PAYARCHCHQW</TD>'||chr(10)||'<TD>');
			if v_patch=0 then
				if upper(v_output)<>'TEXT' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue1:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;
			else
				if upper(v_output)<>'XML' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue1:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;
			end if;			
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUSDEPADVXML';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME) ='PYUSDEPADVXML' and rownum < 2;
			dbms_output.put_line('<TR><TD>Deposit Advice (XML)</TD><TD>PYUSDEPADVXML</TD>'||chr(10)||'<TD>');
			if v_patch=0 then
				if upper(v_output)<>'TEXT' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue2:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;
			else
				if upper(v_output)<>'XML' then
					dbms_output.put_line('<font color="red">'||v_output||'</font>');
					issue2:=TRUE;
				else
					dbms_output.put_line(v_output);
				end if;
			end if;	
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYUSW2PDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYUSW2PDF' and rownum < 2;
			dbms_output.put_line('<TR><TD>Employee W-2 PDF</TD><TD>PAYUSW2PDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue3:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUS941T';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYUS941T' and rownum < 2;
			dbms_output.put_line('<TR><TD>Quarterly Tax Return Worksheet (Form 941 - PDF)</TD><TD>PYUS941T</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue4:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='EMP_1099R_PDF';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='EMP_1099R_PDF' and rownum < 2;
			dbms_output.put_line('<TR><TD>1099R Information Return - PDF</TD><TD>EMP_1099R_PDF</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'TEXT' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue5:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;
		when 'MX' then
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDD';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDD' and rownum < 2;
			dbms_output.put_line('<TR><TD>Direct Deposit (Mexico)</TD><TD>PAYMXDD</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue1:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;	

			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_SS_AFFL';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_SS_AFFL' and rownum < 2;
			dbms_output.put_line('<TR><TD>Social Security Affiliation Report</TD><TD>MX_SS_AFFL</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue2:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXXMLPSLP';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXXMLPSLP' and rownum < 2;
			dbms_output.put_line('<TR><TD>CFDI Payroll Payslip XML Extract</TD><TD>PYMXXMLPSLP</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue3:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_ISR_FORMAT37';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='MX_ISR_FORMAT37' and rownum < 2;
			dbms_output.put_line('<TR><TD>ISR Tax Format 37 (XML)</TD><TD>MX_ISR_FORMAT37</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue4:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDIMMAG';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PAYMXDIMMAG' and rownum < 2;
			dbms_output.put_line('<TR><TD>Information Declaration Report (DIM)</TD><TD>PAYMXDIMMAG</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue5:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
			
			select count(1) into v_rows from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXTRR';
			if v_rows>0 then
			select OUTPUT_FILE_TYPE into v_output from fnd_concurrent_programs where APPLICATION_ID=801 and upper(CONCURRENT_PROGRAM_NAME)='PYMXTRR' and rownum < 2;
			dbms_output.put_line('<TR><TD>Payroll Tax Remittance Report</TD><TD>PYMXTRR</TD>'||chr(10)||'<TD>');
			if upper(v_output)<>'XML' then
				dbms_output.put_line('<font color="red">'||v_output||'</font>');
				issue6:=TRUE;
			else
				dbms_output.put_line(v_output);
			end if;
			dbms_output.put_line('</TD></TR>'||chr(10));
			end if;		
		else
			null;
		end case;
		
		
		:n := (dbms_utility.get_time - :n)/100;
		
		dbms_output.put_line(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		dbms_output.put_line(' <TH COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri">');
		dbms_output.put_line('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		dbms_output.put_line(' </TABLE> ');
		
		case v_leg
		when 'US' then
			if issue1 or issue2 or issue3 or issue4 or issue5 then
				dbms_output.put_line('<div class="divwarn">If you are using PDF Reports:<br>');
				if issue1 then
					:w30:=:w30+1;
					if v_patch=0 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Checkwriter (XML) should be set to Text<br> ');						
					else
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Checkwriter (XML) should be set to XML<br> ');						
					end if;
				end if;
				if issue2 then
					:w30:=:w30+1;
					if v_patch=0 then
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Deposit Advice (XML) should be set to Text<br> ');						
					else
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Deposit Advice (XML) should be set to XML<br> ');
					end if;
				end if;
				if issue3 then
					:w30:=:w30+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Employee W-2 PDF should be set to XML<br> ');
				end if;
				if issue4 then
					:w30:=:w30+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Quarterly Tax Return Worksheet (Form 941 - PDF) should be set to XML<br> ');
				end if;
				if issue5 then
					:w30:=:w30+1;
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of 1099R Information Return - PDF should be set to Text<br> ');
				end if;
				
				dbms_output.put_line('</div>');
			end if;
		when 'MX' then
			if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 then
				dbms_output.put_line('<div class="divwarn">If you are using PDF Reports:<br>');
				if issue1 then					
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Direct Deposit (Mexico) should be set to XML<br> ');					
				end if;
				if issue2 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Social Security Affiliation Report should be set to XML<br> ');
				end if;
				if issue3 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of CFDI Payroll Payslip XML Extract should be set to XML<br> ');
				end if;
				if issue4 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of ISR Tax Format 37 (XML) should be set to XML<br> ');
				end if;
				if issue5 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Information Declaration Report (DIM) should be set to XML<br> ');
				end if;
				if issue6 then
						:w19:=:w19+1;
						dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> Output of Payroll Tax Remittance Report should be set to XML<br> ');
				end if;
				dbms_output.put_line('</div>');
			end if;
		else
			null;
		end case;
	
		if :apps_rel like '12.1%' then
			select count(1) into v_rows from ad_bugs where bug_number in ('10281212','12599994');
			if v_rows=0 then
				issue8:=TRUE;
			end if;
		end if;
		
		if (:apps_rel not like '12.1%') or issue8 then
			select fnd_web_config.database_id into v_database_id from dual;
			select count(1) into v_rows from pay_action_parameters where upper(PARAMETER_NAME)='DBC_FILE' and upper(PARAMETER_VALUE) like upper('%'||v_database_id||'.dbc');
			if v_rows=0 then
				issue8:=TRUE;
			end if;
		end if;
		if issue8 then
					
					:w19:=:w19+1;
					:w30:=:w30+1;
					dbms_output.put_line('<div class="divwarn">If you are using PDF Reports:<br>');
					dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font> You have DBC_FILE incorect in pay_action_parameters table. '); 
					dbms_output.put_line('This should be set to <your path>'||v_database_id||'.dbc<br> ');
					dbms_output.put_line('</div>');
		end if;

		if issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 then
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<span class="sectionblue1">Advice:</span> Please review:<br> ');
		dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=562882.1" target="_blank">Note 562882.1</a> Oracle Human Resources (HRMS) Setup For US, CA and MX Legislations Payroll PDF Reports<br>');
		dbms_output.put_line('</div>');
		else
				dbms_output.put_line('<div class="divok">');
				dbms_output.put_line('Verified parameters are correctly set<br>');
				dbms_output.put_line('</div>');
		end if;
		
		dbms_output.put_line('</div> <br>');


EXCEPTION
when others then
  dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in PAY Analyzer Note 1631780.1 <br>');
end;


-- Display geocode patching level
procedure geocode is
 
  v_exists number:=0;
  v_patch_date ad_bugs.LAST_UPDATE_DATE%type;
  v_status varchar2(100);
  v_last_date date;
  v_geocode_date date;
  patch varchar2(20);
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin
        
                if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
                      SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='21276246' ;
                      patch:='21276246';
                elsif :apps_rel like '12.0%' then
					select count(1) into v_exists from ad_bugs where bug_number='19139617';
                      patch:='19139617';
				elsif :apps_rel like '11.5%' then
                      select count(1) into v_exists from ad_bugs where bug_number='21276241';
                      patch:='21276241';
                end if;
                
                if (v_exists=0) then             
                         issue1:=TRUE;
                else
                          select LAST_UPDATE_DATE  
                          into v_patch_date
                          FROM ad_bugs 
                          where bug_number=patch and rownum < 2;
                          
                          select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%';
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),upper('Completed Normal'))=0 then								 
                                      issue3:=TRUE;
                                  else
                                         if v_last_date<v_patch_date then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
							SELECT count(1) into v_exists
							FROM pay_patch_status
							WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
							AND status        = 'C';
							if v_exists=0 then
								issue5:=TRUE;
							else
								SELECT max(applied_date) into v_geocode_date
								FROM pay_patch_status
								WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
								AND status        = 'C';
							end if;
              end if;
              
               
            dbms_output.put_line('<div class="divSection">');
			dbms_output.put_line('<div class="divSectionTitle">Geocode</div><br>');	  
            
                        if issue1 then
                                
								:w30:=:w30+1;
								if (:pay_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										elsif :apps_rel like '12.0%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ANNUAL GEOCODE UPDATE - 2014<br>');
										elsif :apps_rel like '11.5%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										end if;	
										dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Ensure you perform Geocode Upgrade Manager process after the patch.</div>');
								elsif (:pay_status='Shared') and (:hr_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ANNUAL GEOCODE UPDATE - 2015</div><br>');
										elsif :apps_rel like '12.0%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ');
											dbms_output.put_line('ANNUAL GEOCODE UPDATE - 2014</div><br>');
										elsif :apps_rel like '11.5%' then
											dbms_output.put_line('<div class="divwarn">');
											dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015</div><br>');
										end if;
										dbms_output.put_line('<div class="divwarn">');
										dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records ensure you perform Geocode Upgrade Manager process after the patch.<br>');
										dbms_output.put_line('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=745638.1" target="_blank">Note 745638.1</a> ');
										dbms_output.put_line('Requirements for Address Validation with HR Only Installation</div><br>');
								end if;									
                        else
							dbms_output.put_line('Patch '||patch||' Oracle US and Canada Payroll Annual Geocode applied on '||v_patch_date||'<br>');
                        end if;
                        
                        if issue2 then
                            
							:w30:=:w30+1;
							if (:pay_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>You never performed Geocode Upgrade Manager process!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware you never performed Geocode Upgrade Manager process!</div><br>');
							end if;
                        end if;
                        
                        if issue3 then
                           
							:w30:=:w30+1;
							if (:pay_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Your last run of Geocode Upgrade Manager process is not Completed Normal. Please review!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');								
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware your last run of Geocode Upgrade Manager process completed in error. Please review!</div><br>');
							end if;
                        end if;
                        if issue4 then
                            
							:w30:=:w30+1;
							if (:pay_status='Installed') then
								dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>You did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware you did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							end if;
                        end if;
                        if (:apps_rel not like '12.0%') then 
						if issue5  then                           
							:w30:=:w30+1;
							if (:pay_status='Installed') then								
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>GEOCODE_ANNUAL_2015 information not applied!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then								
								dbms_output.put_line('<div class="divwarn">');
								dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are maintaining tax records be aware GEOCODE_ANNUAL_2015 information are not applied!</div><br>');
							end if;
                        elsif not issue1 then
							dbms_output.put_line('GEOCODE_ANNUAL_2015 information applied on '||v_geocode_date||'<br>');
                        end if;
						end if;
                        
						if not issue1 and not issue2 and not issue3 and not issue4 then
							dbms_output.put_line('Geocode Upgrade Manager process Completed Normal on '||v_last_date||'<br>');
						end if;
						
                        if issue1 or issue2 or issue3 or issue4 or (issue5 and :apps_rel not like '12.0%') then
                                :issuep:=1;
								dbms_output.put_line('<div class="divwarn">');
								if :apps_rel like '12.2%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038283.1" target="_blank">Note 2038283.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.2.x');
								elsif :apps_rel like '12.1%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038282.1" target="_blank">Note 2038282.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.1.x');
                                elsif :apps_rel like '12.0%' then
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1912683.1" target="_blank">Note 1912683.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2014 Annual Geocode Readme - Release 12.0.x');
                                else
                                    dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=2038281.1" target="_blank">Note 2038281.1</a> ');
                                    dbms_output.put_line('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 11i');
                                end if;
                                dbms_output.put_line('</div>');         
						else
                                dbms_output.put_line('<img class="check_ico">OK! All checks are OK!<br>');
                               
                        end if;
						
            dbms_output.put_line('</div>');            
      
end;


-- Display Quantum level
procedure Quantum is
    v_exists number:=0;
  v_status varchar2(100);
  v_last_date date;
  patch varchar2(20);
  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type;	
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin

                select count(1) into v_exists
                from ad_applied_patches ap
                   , ad_patch_drivers pd
                   , ad_patch_runs pr
                   , ad_patch_run_bugs prb
                   , ad_patch_run_bug_actions prba
                   , ad_files f
                where f.file_id                  = prba.file_id
                  and prba.executed_flag         = 'Y'
                  and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                  and prb.patch_run_id           = pr.patch_run_id
                  and pr.patch_driver_id         = pd.patch_driver_id
                  and pd.applied_patch_id        = ap.applied_patch_id
                  and f.filename = 'pyvendor.zip'
                  and pr.end_date = (select max(pr.end_date)
                                             from ad_applied_patches ap
                                                , ad_patch_drivers pd
                                                , ad_patch_runs pr
                                                , ad_patch_run_bugs prb
                                                , ad_patch_run_bug_actions prba
                                                , ad_files f
                                              where f.file_id                  = prba.file_id
                                                and prba.executed_flag         = 'Y'
                                                and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                and prb.patch_run_id           = pr.patch_run_id
                                                and pr.patch_driver_id         = pd.patch_driver_id
                                                and pd.applied_patch_id        = ap.applied_patch_id
                                                and f.filename = 'pyvendor.zip');      

                
               if (v_exists=0) then             
                         issue1:=TRUE;
                else
                            if :apps_rel like '12.%' then
								SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='19701971' ;
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701971' and rownum < 2;
								end if;						  
						   elsif :apps_rel like '11.5%'	then
								select count(1) into v_exists from ad_bugs where bug_number='19701970';
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701970' and rownum < 2;
								end if;
						   end if;				
						   select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%' ;
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),'ERROR')<>0 then 
                                      issue3:=TRUE;
                                  else
                                         if SYSDATE-v_last_date>30 then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
              end if;
              
               
            dbms_output.put_line('<br><div class="divSection">');
			dbms_output.put_line('<div class="divSectionTitle">Quantum</div><br>');
                         if issue1 or issue2 or issue3 or issue4 or issue5 then
								dbms_output.put_line('<div class="diverr">');
								if issue5 then
										  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>You don''t have the patch delivering latest Quantum version 4.0.<br>');
										  dbms_output.put_line('Please install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=');
										  if :apps_rel like '12.%' then
											dbms_output.put_line('19701971">Patch 19701971</a><br>');										 
										  elsif :apps_rel like '11.5%' then
										     dbms_output.put_line('19701970">Patch 19701970</a><br>');
										  end if;
										  :e30:=:e30+1;
								end if;
								if issue1 then
										  :e30:=:e30+1;
										
										dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>No Quantum patch applied<br>');
										  dbms_output.put_line('Ensure you also perform Quantum Data Update Installer.<br>');
								end if;
								
								if issue2 then
										  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>You never performed Quantum Data Update Installer ! ');
										  :e30:=:e30+1;
										
								end if;
								
								if issue3 then
										  dbms_output.put_line('<img class="error_ico"><font color="red">Error: </font>Your last run of Quantum Data Update Installer process completed in error. <br>');
								 		  :e30:=:e30+1;
										
								end if;
								if issue4 then
										   dbms_output.put_line('Your last run of Quantum Data Update Installer was on ');
										  dbms_output.put_line(v_last_date||' more than 30 days ago. <br>');
										                        
										  :e30:=:e30+1;
										
								end if;
                                               
                                :issuep:=1;
								dbms_output.put_line('Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this error. Please verify with System Administrator.<br>');
								dbms_output.put_line('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                                dbms_output.put_line('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations<br>');
								dbms_output.put_line('</div>');
                                                    
                        end if;
                        
					if not issue1 and not issue5 then
							if :apps_rel like '12.%' then
								dbms_output.put_line('Patch 19701971 applied on '||v_patch_date||'<br>');
							elsif :apps_rel like '11.5%' then
								dbms_output.put_line('Patch 19701970 applied on '||v_patch_date||'<br>');
							end if;
						end if;
						if not issue1 and not issue2 and not issue3 and not issue4 then
								dbms_output.put_line('Your last run of Quantum Data Update Installer was on '||v_last_date||'<br>');                                                           
						end if;    
					
                       dbms_output.put_line('<font color="blue">Advice: </font>Please periodically review: ');
						dbms_output.put_line('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                        dbms_output.put_line('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations<br>');
						
			dbms_output.put_line('</div>');
end;


-- Display JIT patching
procedure jit is
  v_exists number:=0;
  v_status varchar2(100);
  v_last_date date;
  patch varchar2(20);
  v_month varchar2(4);
  v_year varchar2(4);
  v_quarter varchar2(4);
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  v_patch varchar2(20);
  v_patch_name varchar2(50);
  v_date date;
  
begin
    dbms_output.put_line('<br><div class="divSection">' );
	 dbms_output.put_line('<div class="divSectionTitle">JIT</div><br>');
	 if (:apps_rel like '12.2%') then
							dpatch('US','21142484','Q2 2015 Statutory and JIT Update');
						elsif (:apps_rel like '12.1%') then
							dpatch('US','21142484','Q2 2015 Statutory and JIT Update');
						elsif (:apps_rel like '12.0%') then		
							dpatch('US','19507770','Q3 2014 Statutory and JIT Update');
						elsif :apps_rel like '11.5%' then					
							dpatch('US','21142464','Q2 2015 Statutory and JIT Update'); 
				end if;    
    dbms_output.put_line('</div><br>');
end;

procedure header (v_leg varchar2) is
begin
			dbms_output.put_line('<div class="divSection"><div class="divSectionTitle">');		
			dbms_output.put_line('<div class="left"  id="'||replace(v_leg,' ','')||'" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">'||v_leg); 
			dbms_output.put_line('</div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
			dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;"><font color="#FFFFFF" size="1">&#9654; Expand All Checks</font></a>'); 
			dbms_output.put_line('<font color="#FFFFFF">/  </font><a class="detail" onclick="closeall();" href="javascript:;">');
			dbms_output.put_line('<font color="#FFFFFF" size="1">&#9660; Collapse All Checks</font></a></div><div class="clear"></div></div><br>');
			dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
			dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
			case v_leg 			
			when 'United States' then
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'g">Geocode</a> <br>');	  
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'q">Quantum</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'j">JIT</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br></td><td class="toctable">');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'pdf">Setup for PDF Reports</a> <br>');			
			else
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'p">Patching</a> <br>');	  
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'d">Data install status</a> <br>');
			dbms_output.put_line('<a href="#'||replace(v_leg,' ','')||'s">Settings</a> <br>');
			end case;
			dbms_output.put_line('</td></tr></table>');
			dbms_output.put_line('</div></div><br>');
end;
begin



--US
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'US'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page30" style="display: none;">');header('United States');
			dbms_output.put_line('<a name="UnitedStatesg"></a>');geocode();	
			dbms_output.put_line('<a name="UnitedStatesq"></a>');Quantum();
			dbms_output.put_line('<a name="UnitedStatesj"></a>');jit();
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="UnitedStatesp"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
						
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then							
					dpatch('US','19193000', 'R12.HR_PF.C.Delta.6');					
					dpatch('US','21142484','Q2 2015 Statutory and JIT Update');
					dpatch('US','20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.1%') then								
					dpatch('US','20000288', 'R12.HR_PF.B.delta.8');					 
					dpatch('US','21142484','Q2 2015 Statutory and JIT Update');
					dpatch('US','20365000','End of Year 2014 Phase 3');
				elsif (:apps_rel like '12.0%') then					
					dpatch('US','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('US','19507770','Q3 2014 Statutory and JIT Update');
					dpatch('US','19701971','End of Year 2014 Phase 1');
					dpatch('US','20212223','End of Year 2014 Phase 2');
					dpatch('US','20365000','End of Year 2014 Phase 3');
				elsif :apps_rel like '11.5%' then					
					dpatch('US','17774746', 'HR_PF.K.RUP.9');					
					dpatch('US','21142464','Q2 2015 Statutory and JIT Update');
					dpatch('US','20364999','End of Year 2014 Phase 3');
					dpatch('US','20301513','Year Begin 2015 Statutory Update 2');
					dpatch('US','20212121','Year Begin 2015 Statutory Update');
				end if;	
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
						if (:apps_rel like '12.%') then							
							dbms_output.put_line('<br><div class="divItem">');
							dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
							dpatch('US','20365000','End of Year 2014 Phase 3');
							dbms_output.put_line('</div>');						
						elsif :apps_rel like '11.5%' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('US','20364999','End of Year 2014 Phase 3');	
								dbms_output.put_line('</div>');			
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="UnitedStatesd"></a>');datainstall('US',30);dbms_output.put_line('<a name="UnitedStatess"></a>');bg_generic('US',30);
			dbms_output.put_line('</div>');
			--seeded ('US',30);
			pdf_reports('US');
			documents('1527958.2','Information Center: Oracle HRMS (US)');
			dbms_output.put_line('</div>');
	end if;

--ZA
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'ZA'  and status='I';     
     if v_exists>0 then
			dbms_output.put_line('<div id="page31" style="display: none;">');header('South Africa');
			dbms_output.put_line('<div class="divSection">');dbms_output.put_line('<a name="SouthAfricap"></a>');
			dbms_output.put_line('<div class="divSectionTitle">Patching</div>');
			dbms_output.put_line('<br><div class="divItem">');
			dbms_output.put_line('<div class="divItemTitle">Mandatory Patches</div>');	
			if (:apps_rel like '12.2%') then					
					dpatch('ZA','19193000', 'R12.HR_PF.C.Delta.6');	
					dpatch('ZA','21499164', 'INTEREST RATE GLOBAL VALUE CHANGE EEFECTIVE FROM 01-AUG-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('ZA','20000288', 'R12.HR_PF.B.delta.8');
					dpatch('ZA','21499164', 'INTEREST RATE GLOBAL VALUE CHANGE EEFECTIVE FROM 01-AUG-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('ZA','16077077', 'R12.HR_PF.A.delta.11');
					dpatch('ZA','19544341', 'ZA: AUGTYE14 REPORTING CHANGES');
				elsif :apps_rel like '11.5%' then					
					dpatch('ZA','12807777', 'HR_PF.K.RUP.7');	
					dpatch('ZA','17366859', 'ZA : Tax Audit report');					
				end if;															
			dbms_output.put_line('</div>');
			
			if (:hr_status='Installed') then
					if (:apps_rel like '12.2%') then
						dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','20812316', 'ZA: COIDA LIMIT CHANGED EFFECTIVE FROM 1 APRIL 2015');
								dbms_output.put_line('</div>');
					elsif (:apps_rel like '12.1%') then					
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','20812316', 'ZA: COIDA LIMIT CHANGED EFFECTIVE FROM 1 APRIL 2015');
								dbms_output.put_line('</div>');							
						elsif (:apps_rel like '12.0%') then					
							if :rup_level='16077077' then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','19544341', 'ZA: AUGTYE14 REPORTING CHANGES');
								dbms_output.put_line('</div>');
							elsif  :rup_level='13774477' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','16543654','ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013 TO R312 480');
								dpatch('ZA','16654857','SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');
								dbms_output.put_line('</div>');	
							end if;
						elsif :apps_rel like '11.5%' then					
							if :rup_level='14488556' then
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','16543639', 'ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013');
								dpatch('ZA','16654854', 'SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');	
								dbms_output.put_line('</div>');
							elsif :rup_level='12807777'  then		
								dbms_output.put_line('<br><div class="divItem">');
								dbms_output.put_line('<div class="divItemTitle">Latest Hrglobal Patch</div>');
								dpatch('ZA','16543639', 'ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013');
								dpatch('ZA','16654854', 'SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');	
								dbms_output.put_line('</div>');
							end if;				
					end if;	
			end if;
			dbms_output.put_line('</div><br>'); dbms_output.put_line('<a name="SouthAfricad"></a>');datainstall('ZA',31);dbms_output.put_line('<a name="SouthAfricas"></a>');bg_generic('ZA',31);
			dbms_output.put_line('</div>');
			documents('1514993.2','Information Center: Oracle HRMS (South African)');
			dbms_output.put_line('</div>');
	end if;
	
	dbms_output.put_line('</div>');
end;
/


-- Display overview of issues
declare
v_warnings number;
v_errors number;
procedure leg_tabs (v_leg varchar2, v_leg_name varchar2, v_page varchar2, v_e number, v_w number) is
  v_exists number;  
Begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = v_leg  and status='I';     
     if v_exists>0 then               
			   dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2('''||v_page||''');\\" href=\\"javascript:;\\">'||v_leg_name||'</A>"+');
				if v_e>0 then
							dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
						elsif v_w>0 then
							dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');	
						else
							dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
						end if;	
				dbms_output.put_line('"</TD><TD>'||v_e||'</TD><TD>'||v_w||'</TD> </TR>"+');
			   
	 end if;
end;
procedure leg_tabs2 (v_leg varchar2, v_leg_name varchar2, v_page varchar2, v_e number, v_w number) is
  v_exists number;  
Begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = v_leg  and status='I';     
     if v_exists>0 then               
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab('''||v_page||''')\\" >"+');
			dbms_output.put_line('"<b>'||v_leg_name||'</b> "+');
			if v_e>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif v_w>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	 
	 end if;
end;
procedure leg_tabs3 (v_leg varchar2, v_leg_name varchar2, v_page varchar2, v_e number, v_w number) is
  v_exists number;  
Begin
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = v_leg  and status='I';     
     if v_exists>0 then               
			dbms_output.put_line('auxs = document.getElementById("'||v_leg_name||'").innerHTML;');
			dbms_output.put_line('document.getElementById("'||v_leg_name||'").innerHTML = auxs + ');
			if v_e>0 and v_w>0 then
				dbms_output.put_line(' ":  '||v_e||' <img class=\\"error_ico\\">  '||v_w||' <img class=\\"warn_ico\\"> ";');
			elsif v_e>0 then
				dbms_output.put_line(' ":  '||v_e||' <img class=\\"error_ico\\"> ";');
			elsif v_w>0 then
				dbms_output.put_line(' ":  '||v_w||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' ": <img class=\\"check_ico\\"> ";');
			end if;	 
	 end if;
end;
begin
	
	v_warnings:=:w1+:w2+:w3+:w4+:w5+:w6+:w7+:w8+:w9+:w10+:w11+:w12+:w13+:w14+:w15+:w16+:w17+:w18+:w19+:w20+:w21+:w22+:w23+:w24+:w25+:w26+:w27+:w28+:w29+:w30+:w31;
	v_errors:=:e1+:e2+:e3+:e4+:e5+:e6+:e7+:e8+:e9+:e10+:e11+:e12+:e13+:e14+:e15+:e16+:e17+:e18+:e19+:e20+:e21+:e22+:e23+:e24+:e25+:e26+:e27+:e28+:e29+:e30+:e31;
	
	dbms_output.put_line('<script type="text/javascript">');
	dbms_output.put_line('var auxs;');
	dbms_output.put_line('auxs = document.getElementById("ExecutionSummary1").innerHTML;');
	dbms_output.put_line('document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if v_errors>0 and v_warnings>0 then
		dbms_output.put_line('"('||v_errors||'<img class=\\"error_ico\\"> '||v_warnings||'<img class=\\"warn_ico\\">)</A>";');
	elsif v_errors>0 and v_warnings=0 then
		dbms_output.put_line('"(<img class=\\"error_ico\\">'||v_errors||')</A>";');
	elsif v_errors=0 and v_warnings>0 then
		dbms_output.put_line('"(<img class=\\"warn_ico\\">'||v_warnings||')</A>";');
	elsif v_errors=0 and v_warnings=0 then
		dbms_output.put_line('"(<img class=\\"check_ico\\"> No issues reported)</A>";');
	end if;
	
	
	dbms_output.put_line('auxs = document.getElementById("ExecutionSummary2").innerHTML;');
	dbms_output.put_line('document.getElementById("ExecutionSummary2").innerHTML = auxs + ');			

	dbms_output.put_line(' "<TABLE width=\\"95%\\"><TR>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Section</B></TD>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Errors</B></TD>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Warnings</B></TD>"+');
	
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page1'');\\" href=\\"javascript:;\\">Generic</A>"+');
	if :e1>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w1>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');	
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e1||'</TD><TD>'||:w1||'</TD> </TR>"+');
	
	leg_tabs ('AU', 'Australia', 'page2',:e2 ,:w2);
	leg_tabs ('BE', 'Belgium', 'page3',:e3 ,:w3);  		 
	leg_tabs ('CA', 'Canada', 'page4',:e4 ,:w4); 		 
	leg_tabs ('CN', 'China', 'page5',:e5 ,:w5); 		 
	leg_tabs ('ES', 'Spain', 'page6',:e6 ,:w6); 	 	 
	leg_tabs ('DE', 'Germany', 'page7',:e7 ,:w7); 		 
	leg_tabs ('DK', 'Denmark', 'page8',:e8 ,:w8); 	 	 
	leg_tabs ('FI', 'Finland', 'page9',:e9 ,:w9); 	 	 
	leg_tabs ('FR', 'France', 'page10',:e10 ,:w10); 	 	 
	leg_tabs ('HK', 'Hong Kong', 'page11',:e11 ,:w11); 	 	 
	leg_tabs ('HU', 'Hungary', 'page12',:e12 ,:w12); 	 	 
	leg_tabs ('IE', 'Ireland', 'page13',:e13 ,:w13); 	 	 
	leg_tabs ('IN', 'India', 'page14',:e14 ,:w14); 		 
	leg_tabs ('IT', 'Italy', 'page15',:e15 ,:w15); 	 	 
	leg_tabs ('JP', 'Japan', 'page16',:e16 ,:w16); 	 	 
	leg_tabs ('KR', 'Korea', 'page17',:e17 ,:w17); 	 	 
	leg_tabs ('KW', 'Kuwait', 'page18',:e18 ,:w18); 	 	 
	leg_tabs ('MX', 'Mexico', 'page19',:e19 ,:w19); 		 
	leg_tabs ('NL', 'Netherlands', 'page20',:e20 ,:w20); 		 
	leg_tabs ('NO', 'Norway', 'page21',:e21 ,:w21); 		 
	leg_tabs ('NZ', 'New Zealand', 'page22',:e22 ,:w22); 		 
	leg_tabs ('PL', 'Poland', 'page23',:e23 ,:w23); 	 	 
	leg_tabs ('RU', 'Russia', 'page24',:e24 ,:w24); 	 	 
	leg_tabs ('SA', 'Saudi Arabia', 'page25',:e25 ,:w25); 	 	 
	leg_tabs ('SE', 'Sweden', 'page26',:e26 ,:w26); 	 
	leg_tabs ('SG', 'Singapore', 'page27',:e27 ,:w27); 	 	 
	leg_tabs ('AE', 'United Arab Emirates', 'page28',:e28 ,:w28); 	 	 
	leg_tabs ('GB', 'United Kingdom', 'page29',:e29 ,:w29); 	 	 
	leg_tabs ('US', 'United States', 'page30',:e30 ,:w30);  	 
	leg_tabs ('ZA', 'South Africa', 'page31',:e31 ,:w31); 	

	dbms_output.put_line(' "</TABLE></div>";');   
	
	dbms_output.put_line('auxs = document.getElementById("toccontent").innerHTML;');
	dbms_output.put_line('document.getElementById("toccontent").innerHTML = auxs + ');
	dbms_output.put_line('"<div align=\\"center\\">"+');
	-- Tabs 
	dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page1'')\\" >"+');
	dbms_output.put_line('"<b>Generic</b> "+');
	if :e1>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
	elsif :w1>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
	else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
	end if;	
	leg_tabs2 ('AU', 'Australia', 'page2',:e2 ,:w2);
	leg_tabs2 ('BE', 'Belgium', 'page3',:e3 ,:w3);  		 
	leg_tabs2 ('CA', 'Canada', 'page4',:e4 ,:w4); 		 
	leg_tabs2 ('CN', 'China', 'page5',:e5 ,:w5); 		 
	leg_tabs2 ('ES', 'Spain', 'page6',:e6 ,:w6); 	 	 
	leg_tabs2 ('DE', 'Germany', 'page7',:e7 ,:w7); 		 
	leg_tabs2 ('DK', 'Denmark', 'page8',:e8 ,:w8); 	 	 
	leg_tabs2 ('FI', 'Finland', 'page9',:e9 ,:w9); 	 	 
	leg_tabs2 ('FR', 'France', 'page10',:e10 ,:w10); 	 	 
	leg_tabs2 ('HK', 'Hong Kong', 'page11',:e11 ,:w11); 	 	 
	leg_tabs2 ('HU', 'Hungary', 'page12',:e12 ,:w12); 	 	 
	leg_tabs2 ('IE', 'Ireland', 'page13',:e13 ,:w13); 	 	 
	leg_tabs2 ('IN', 'India', 'page14',:e14 ,:w14); 		 
	leg_tabs2 ('IT', 'Italy', 'page15',:e15 ,:w15); 	 	 
	leg_tabs2 ('JP', 'Japan', 'page16',:e16 ,:w16); 	 	 
	leg_tabs2 ('KR', 'Korea', 'page17',:e17 ,:w17); 	 	 
	leg_tabs2 ('KW', 'Kuwait', 'page18',:e18 ,:w18); 	 	 
	leg_tabs2 ('MX', 'Mexico', 'page19',:e19 ,:w19); 		 
	leg_tabs2 ('NL', 'Netherlands', 'page20',:e20 ,:w20); 		 
	leg_tabs2 ('NO', 'Norway', 'page21',:e21 ,:w21); 		 
	leg_tabs2 ('NZ', 'New Zealand', 'page22',:e22 ,:w22); 		 
	leg_tabs2 ('PL', 'Poland', 'page23',:e23 ,:w23); 	 	 
	leg_tabs2 ('RU', 'Russia', 'page24',:e24 ,:w24); 	 	 
	leg_tabs2 ('SA', 'Saudi Arabia', 'page25',:e25 ,:w25); 	 	 
	leg_tabs2 ('SE', 'Sweden', 'page26',:e26 ,:w26); 	 
	leg_tabs2 ('SG', 'Singapore', 'page27',:e27 ,:w27); 	 	 
	leg_tabs2 ('AE', 'United Arab Emirates', 'page28',:e28 ,:w28); 	 	 
	leg_tabs2 ('GB', 'United Kingdom', 'page29',:e29 ,:w29); 	 	 
	leg_tabs2 ('US', 'United States', 'page30',:e30 ,:w30);  	 
	leg_tabs2 ('ZA', 'South Africa', 'page31',:e31 ,:w31);	 	 
  	dbms_output.put_line('"</div>";');

	dbms_output.put_line('auxs = document.getElementById("generic").innerHTML;');
			dbms_output.put_line('document.getElementById("generic").innerHTML = auxs + ');
			if :e1>0 and :w1>0 then
				dbms_output.put_line(' ": '||:e1||' <img class=\\"error_ico\\">  '||:w1||' <img class=\\"warn_ico\\"> ";');
			elsif :e1>0 then
				dbms_output.put_line(' ": '||:e1||' <img class=\\"error_ico\\"> ";');
			elsif :w1>0 then
				dbms_output.put_line(' ": '||:w1||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' ": <img class=\\"check_ico\\"> ";');
			end if;	
		leg_tabs3 ('AU', 'Australia', 'page2',:e2 ,:w2);
	leg_tabs3 ('BE', 'Belgium', 'page3',:e3 ,:w3);  		 
	leg_tabs3 ('CA', 'Canada', 'page4',:e4 ,:w4); 		 
	leg_tabs3 ('CN', 'China', 'page5',:e5 ,:w5); 		 
	leg_tabs3 ('ES', 'Spain', 'page6',:e6 ,:w6); 	 	 
	leg_tabs3 ('DE', 'Germany', 'page7',:e7 ,:w7); 		 
	leg_tabs3 ('DK', 'Denmark', 'page8',:e8 ,:w8); 	 	 
	leg_tabs3 ('FI', 'Finland', 'page9',:e9 ,:w9); 	 	 
	leg_tabs3 ('FR', 'France', 'page10',:e10 ,:w10); 	 	 
	leg_tabs3 ('HK', 'HongKong', 'page11',:e11 ,:w11); 	 	 
	leg_tabs3 ('HU', 'Hungary', 'page12',:e12 ,:w12); 	 	 
	leg_tabs3 ('IE', 'Ireland', 'page13',:e13 ,:w13); 	 	 
	leg_tabs3 ('IN', 'India', 'page14',:e14 ,:w14); 		 
	leg_tabs3 ('IT', 'Italy', 'page15',:e15 ,:w15); 	 	 
	leg_tabs3 ('JP', 'Japan', 'page16',:e16 ,:w16); 	 	 
	leg_tabs3 ('KR', 'Korea', 'page17',:e17 ,:w17); 	 	 
	leg_tabs3 ('KW', 'Kuwait', 'page18',:e18 ,:w18); 	 	 
	leg_tabs3 ('MX', 'Mexico', 'page19',:e19 ,:w19); 		 
	leg_tabs3 ('NL', 'Netherlands', 'page20',:e20 ,:w20); 		 
	leg_tabs3 ('NO', 'Norway', 'page21',:e21 ,:w21); 		 
	leg_tabs3 ('NZ', 'NewZealand', 'page22',:e22 ,:w22); 		 
	leg_tabs3 ('PL', 'Poland', 'page23',:e23 ,:w23); 	 	 
	leg_tabs3 ('RU', 'Russia', 'page24',:e24 ,:w24); 	 	 
	leg_tabs3 ('SA', 'SaudiArabia', 'page25',:e25 ,:w25); 	 	 
	leg_tabs3 ('SE', 'Sweden', 'page26',:e26 ,:w26); 	 
	leg_tabs3 ('SG', 'Singapore', 'page27',:e27 ,:w27); 	 	 
	leg_tabs3 ('AE', 'UnitedArabEmirates', 'page28',:e28 ,:w28); 	 	 
	leg_tabs3 ('GB', 'UnitedKingdom', 'page29',:e29 ,:w29); 	 	 
	leg_tabs3 ('US', 'UnitedStates', 'page30',:e30 ,:w30);  	 
	leg_tabs3 ('ZA', 'SouthAfrica', 'page31',:e31 ,:w31);
	
  	dbms_output.put_line('</script>');	
end;
/



-- Print duration of script

begin
select to_char(sysdate,'hh24:mi:ss') into :et_time from dual;
end;
/

declare
	st_hr1 varchar2(10);
	st_mi1 varchar2(10);
	st_ss1 varchar2(10);
	et_hr1 varchar2(10);
	et_mi1 varchar2(10);
	et_ss1 varchar2(10);
	hr_fact varchar2(10);
	mi_fact varchar2(10);
	ss_fact varchar2(10);
	vss number;
	vse number;
	vt number;
begin
	
	dbms_output.put_line('<br><br><hr><br><TABLE width="50%"><THEAD><STRONG>PAY Analyzer Performance Data</STRONG></THEAD>');
    dbms_output.put_line('<TBODY><TR><TH>Started at:</TH><TD>'||:st_time||'</TD></TR>');
    dbms_output.put_line('<TR><TH>Complete at:</TH><TD>'||:et_time||'</TD></TR>');
    	
	st_hr1 := substr(:st_time,1,2);
	st_mi1 := substr(:st_time,4,2);
	st_ss1 := substr(:st_time,7,2);
	et_hr1 := substr(:et_time,1,2);
	et_mi1 := substr(:et_time,4,2);
	et_ss1 := substr(:et_time,7,2);
	
	vss:=st_hr1*60*60 + st_mi1*60+st_ss1;
	vse:=et_hr1*60*60 + et_mi1*60+et_ss1;
	
	
	dbms_output.put_line('<TR><TH>Total time taken to complete the script:</TH>');
	if vse>vss then	
			vt:=vse-vss;			
	else
			vt:=24*60*60-vss +vse;
	end if;
	
		if (vt > 3600) then
								dbms_output.put_line('<TD>'||trunc(vt/3600)||' hours, '||trunc((vt-((trunc(vt/3600))*3600))/60)||' minutes, '||trunc(vt-((trunc(vt/60))*60))||' seconds</TD></TR>');
	elsif (vt > 60) then
								dbms_output.put_line('<TD>'||trunc(vt/60)||' minutes, '||trunc(vt-((trunc(vt/60))*60))||' seconds</TD></TR>');
	elsif (vt < 60) then
								dbms_output.put_line('<TD>'||trunc(vt)||' seconds</TD></TR>');
	end if;
			
	dbms_output.put_line('</TBODY></TABLE>');
	
end;
/


declare
		db_ver    	  VARCHAR2(100);
		db_charset V$NLS_PARAMETERS.value%type;
		db_lang V$NLS_PARAMETERS.value%type;
		rup_level varchar2(20);
		v_exists number;
		platform varchar2(100);		
		cursor legislations is
				SELECT DECODE(legislation_code
							   ,null,'Global'
							   ,legislation_code)  leg              
					   , DECODE(application_short_name
							   , 'PER', 'Human Resources'
							   , 'PAY', 'Payroll'
							   , 'GHR', 'Federal Human Resources'
							   , 'CM',  'College Data'
							   , application_short_name) application         
				  FROM hr_legislation_installations
				  WHERE status = 'I'
				  ORDER BY legislation_code;
		v_wfVer WF_RESOURCES.TEXT%type:='';
		v_crtddt V$DATABASE.CREATED%type;
		irc_status varchar2(20);
		cursor bg is
		SELECT o.business_group_id bgi,o.organization_id oi,otl.name name,o3.ORG_INFORMATION9 lc			
			,o3.ORG_INFORMATION10 cc,o4.ORG_INFORMATION2 ef ,to_char(o.date_from , 'DD-MON-YYYY') df,to_char(o.date_to, 'DD-MON-YYYY') dt
			FROM hr_all_organization_UNITS O , 
			hr_all_organization_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;
		cursor c_pay is select parameter_name, nvl(parameter_value,'null') param_value
		      from pay_action_parameters
		      where parameter_name in ('BAL BUFFER SIZE','EE_BUFFER_SIZE','RR_BUFFER_SIZE','RRV_BUFFER_SIZE','CHUNK SIZE','RANGE_PERSON_ID','THREADS','TRACE','LOW_VOLUME');
      		max_dump v$parameter.value%type;
begin
	
	
	if :apps_rel like '11.5%'  then
		dbms_output.put_line('<br><table border="2" name="NoteBox" cellpadding="1" bordercolor="#C1A90D" bgcolor="#CCCCCC" cellspacing="1">');
		dbms_output.put_line('<tbody><tr><td> <font size="+1">Statutory Legislative Support Expired</font> </td></tr></tbody> </table> <BR>');
		dbms_output.put_line('<div class="divwarn">');
		dbms_output.put_line('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please note that statutory legislative support expired on November 30th 2013');
		dbms_output.put_line(', please refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1631780.1\&id=1384995.1" target="_blank">Note 1384995.1</a> ');
		dbms_output.put_line(' When Is Statutory Legislative Support for Payroll Going To End For Release 11i<br></div>');
	end if;
	
	dbms_output.put_line('<br><hr><a name="feedback"></a><table border="2" name="NoteBox" cellpadding="1" bordercolor="#C1A90D" bgcolor="#CCCCCC" cellspacing="1"><br>');
	dbms_output.put_line('<b>Still have questions or suggestions?</b><br>  <A HREF="https://community.oracle.com/message/12646480"  target="_blank">');
	dbms_output.put_line('<img src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback.png" title="Click here to provide feedback"/></a><br>');
	dbms_output.put_line('Click the button above to ask questions about and/or provide feedback on the Payroll Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!<br>');
	
	
SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, 'TNS for '), ':' )||pcv2.status, 1, 80)
    INTO platform
        FROM product_component_version pcv1,
           product_component_version pcv2
     WHERE UPPER(pcv1.product) LIKE '%TNS%'
       AND UPPER(pcv2.product) LIKE '%ORACLE%'
       AND ROWNUM = 1;
	select VALUE into db_lang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
	select VALUE into db_charset FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';
	select banner into db_ver from V$VERSION WHERE ROWNUM = 1;
	select count(1) into v_exists FROM V$DATABASE;
	if v_exists=1 then	
	SELECT CREATED into v_crtddt FROM V$DATABASE;
	end if;
	select count(1) into v_exists FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';
	if v_exists=1 then
	SELECT TEXT into v_wfVer  FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';	
	end if;	
	if :apps_rel like '12.%' then
		select count(*) into v_exists from fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		if v_exists >0 then	
		SELECT L.MEANING  into irc_status  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		else
		  irc_status:='Not available';
		end if;
	else
	  irc_status:='Not available';
	 end if;  
	
	dbms_output.put_line('<!-- ######BEGIN DX SUMMARY######');
	dbms_output.put_line('<diagnostic><run_details>');
    dbms_output.put_line('<detail name="Instance">'||:sid||'</detail>');
    dbms_output.put_line('<detail name="Instance Date">'||v_crtddt||'</detail>');
    dbms_output.put_line('<detail name="Platform">'||platform||'</detail>');
    dbms_output.put_line('<detail name="File Version">200.27</detail>');
    dbms_output.put_line('<detail name="Language">'||db_lang||' / '||db_charset||'</detail>');
    dbms_output.put_line('<detail name="Database">'||db_ver||'</detail>');
	dbms_output.put_line('<detail name="Application">'||:apps_rel||'</detail>');
    dbms_output.put_line('<detail name="Workflow">'||v_wfVer||'</detail>');
    dbms_output.put_line('<detail name="PER">'||:hr_status||'</detail>');
    dbms_output.put_line('<detail name="PAY">'||:pay_status||'</detail>');
    dbms_output.put_line('<detail name="IRC">'||irc_status||'</detail>');	
	dbms_output.put_line('<detail name="RUP">'||:rup_level_n|| ' applied on ' || :v_rup_date||'</detail>');
  dbms_output.put_line('</run_details>');
  dbms_output.put_line('<parameters>');
    for l_rec in legislations loop
	dbms_output.put_line('<parameter name="Legislation">'||l_rec.leg||'   '||l_rec.application||'</parameter>');
	end loop;
	for org_rec in bg loop
		dbms_output.put_line('<parameter name="BG"><![CDATA['||lpad(org_rec.bgi,10)||' | '||lpad(org_rec.oi,10)||' | '||lpad(org_rec.name,30)||' | '||lpad(org_rec.lc,6)||' | '||lpad(org_rec.cc,6)||' | '||lpad(org_rec.ef,7)||' | '||lpad(org_rec.df,11)||' | '||lpad(org_rec.dt,11)||']]></parameter>');
	end loop;
	for c_rec in c_pay loop
		dbms_output.put_line('<parameter name="PERF">'||c_rec.parameter_name||': '||c_rec.param_value||'</parameter>');
	end loop;
	select nvl(value,'null') into max_dump from v$parameter  where lower(name) ='max_dump_file_size';
	dbms_output.put_line('<parameter name="PERF">Max_dump_file_sixe: '||max_dump||'</parameter>');
	dbms_output.put_line('<parameter name="PERF">Gather Schema Statistics for ALL - last time completed normally: '||:p1||'</parameter>');
	dbms_output.put_line('<parameter name="PERF">Gather Schema Statistics for HR - last time completed normally: '||:p2||'</parameter>');
  dbms_output.put_line('</parameters> <issues><signature id="INSTSUM"><failure row="1">d</failure></signature></issues></diagnostic>');
  dbms_output.put_line('######END DX SUMMARY######-->');
end;
/

REM  ==============SQL PLUS Environment setup===================

Spool off

set termout on

exit
;
