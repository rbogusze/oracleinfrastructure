SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE '~'

REM $Id: hcm_person_analyzer.sql, 200.15 2015/09/14 23:27:42 nragavar Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.21                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    hcm_person_analyzer.sql                                              |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Consolidated script to diagnose issues that can cause problems in    |
REM |       your HCM - Person(s) on an environment.                           |
REM | HISTORY                                                                 |
REM |                                                                         |
REM | 01-May-2014  nragavar  created         Initial Version                  |
REM |                                                                         |
REM | 23-Jun-2014  nragavar  Added           Added check for Application Version 
REM |                                        and minor changes.               
REM | 14-Jul-2014  nragavar  Added           added column SEX and titled column 'Gender'
REM | 27-Jan-2015  nragavar  Added           added column SPECIAL_CEILING_STEP_ID to Assignment details section
REM |                                        Updated 'Payroll Element Entries' section for duplicate rows
REM | 06-Feb-2015  nragavar  Added           Added new section 'PAYE and NI aggregation Details' 
REM | 12-Mar-2015  nragavar  Added           Updated section 'Assignment Action Details'
REM | 01-Apr-2015  nragavar  Added           Updated section 'Assignment Action Details' and 'line_out' procedure
REM |                                          Code changes to handle error : ERROR: ORA-06502: PL/SQL: numeric or value 
REM |                                            error: host bind array too small ORA-06512: at line 1 ERROR: ORA-06502: PL/SQL: numeric or value 
REM |                                            error: host bind array too small ORA-06512: at line 1
REM | 03-Apr-2015  nragavar  Added           Added new section 'Business Group Details' 
REM | 27-Apr-2015  nragavar  Update          Updated section 'Business Group Details'
REM |                                          and $Header to $Id
REM | 27-Apr-2015  nragavar  Update          Major changes for new Analyzer standards    
REM | 19-Jun-2015  nragavar  Update          Added sections PERSON_ISSUE1,PERSON_ISSUE2,PERSON_ISSUE3
REM |                                          ASSIGNMENT_ISSUE1,ASSIGNMENT_ISSUE2,ASSIGNMENT_ISSUE3,
REM |                                          Shared HR customers only section added.
REM | 22-Jul-2015  nragavar  Update          Added multiple sections for DX summary. 
REM |                                          Copy and paste for Person and Assignment details and issues
REM | 31-Aug-2015  nragavar  Update  200.13  Added multiple sections for PERSONS_CWK_ISSUE1, PERSONS_PEE_ISSUE2. 
REM | 04-Sep-2015  nragavar  Update  200.14  Added Analyzer Bundle.
REM | 14-Sep-2015  nragavar  Update  200.15  Latest Version image file change
REM |
REM +=========================================================================+
REM


-- PROMPTS/ACCEPTS are to be used if running from SQL*Plus
-- If submitting analyzer as a concurrent process (cp), then need to remove/comment below ACCEPTS/PROMPTS section
-- Variables below when accepting parameters are numbers because this is needed when running as a cp, but can be change if running from SQL*Plus
-- So 2 files would be needed (one to be run from SQL*Plus, other for CP)
/*
PROMPT
-- PSD #1
PROMPT Submitting Person Analyzer.
PROMPT ===========================================================================
PROMPT Enter the Person Id.  This parameter is required.
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 1 CHAR DEFAULT -1 -
       PROMPT 'Enter the person_id(required): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the date from which to begin validating transactions(default sysdate-90)
PROMPT ===========================================================================
COLUMN date1 new_value curdate NOPRINT
-- PSD #2
ACCEPT 2 DATE FORMAT 'DD-MON-YYYY' DEFAULT '31-DEC-9999' -
       PROMPT 'Enter the START DATE DD-MON-YYYY (default sysdate-90): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the maximum number of rows to display on row limited queries
PROMPT ===========================================================================
-- PSD #2
ACCEPT 3 NUMBER DEFAULT 50 -
       PROMPT 'Enter the maximum rows to display [50]: '
PROMPT
PROMPT
*/
DECLARE
-- PSD #3
  l_person_id  VARCHAR2(250) := '~1';
  l_from_date  DATE := to_date('~2','RRRR/MM/DD'); 
  l_max_rows   NUMBER := '~3';
  l_debug_mode VARCHAR2(1) := 'Y';

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;

g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #17
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=xxxxxxx.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;

g_preserve_trailing_blanks BOOLEAN := true;

----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

-- PSD #4
    l_log_file := 'Person_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'Person_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
              'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfL'||
              'T8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the background color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

-- Print title
-- PSD #5  
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1675487.1:PER_ANA_SCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/hcm_per_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">DocId \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','S','I') THEN
    IF result = 'S' THEN
      g_sections(g_sections.last).result := 'S';
    ELSE
      g_sections(g_sections.last).result := result;
    END IF;
  ELSIF g_sections(g_sections.last).result = 'W' THEN
    IF result = 'E' THEN
      g_sections(g_sections.last).result := result;
    END IF;
  END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
		 
		 -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;		 

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
  l_step := 'Validate parameters';
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  	
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
          -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
          -- this ensures trailing blanks added for padding are honored by browsers
          -- affects only printing, DX summary handled separately
          IF g_preserve_trailing_blanks THEN
		  
		     l_html := l_html || '
                       <th>'||RPAD(RTRIM(p_col_headings(i),' '), 
                                -- pad length is the number of spaces existing times the length of &nbsp; => 6
                               (length(p_col_headings(i)) - length(RTRIM(p_col_headings(i),' '))) * 6 
							   + length(RTRIM(p_col_headings(i),' ')),'&nbsp;');  
          ELSE
             l_html := l_html || '
                       <th>'||nvl(RTRIM(p_col_headings(i),' '),'&nbsp;')||'</th>';
          END IF;
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
		  -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
          -- this ensures trailing blanks added for padding are honored by browsers
          -- affects only printing, DX summary handled separately

          IF g_preserve_trailing_blanks THEN
            l_curr_Val := RPAD(RTRIM(l_curr_Val,' '), 
                                -- pad length is the number of spaces existing times the length of &nbsp; => 6
                               (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
                               '&nbsp;');
          ELSE
            l_curr_Val := RTRIM(l_curr_Val, ' ');
          END IF;
		  		  
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i), l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);
/* commenting this as each has its own failure the parent should fail based on its own 
   criteria
           IF l_result in ('W','E') THEN
             l_fail_flag := true;
           END IF;
*/

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF l_sig_fail THEN
		  IF p_sig.fail_type ='E' THEN 
		  g_section_toc := g_section_toc || '<img class="error_ico">';       
		  ELSIF p_sig.fail_type ='W' THEN
			g_section_toc := g_section_toc ||'<img class="warn_ico">';   	 
		   end if;
	   end if;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF l_sig_fail THEN
		  IF p_sig.fail_type ='E' THEN 
		  g_section_toc := g_section_toc || '<img class="error_ico">';       
		  ELSIF p_sig.fail_type ='W' THEN
			g_section_toc := g_section_toc ||'<img class="warn_ico">';   	 
		   end if;
	   end if;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;
	
  END IF;	
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
-- PSD #6  
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;

  CURSOR get_app_date(p_ptch VARCHAR2) IS
  SELECT max(pr.start_date) app_date
  FROM ad_patch_runs pr
  WHERE pr.patch_run_id in (
          SELECT prb.patch_run_id
          FROM   ad_bugs b,
                 ad_patch_run_bugs prb
          WHERE  b.bug_number = p_ptch
          AND    prb.bug_id = b.bug_id
          UNION
          SELECT pr2.patch_run_id
          FROM ad_applied_patches ap,
               ad_patch_drivers pd,
               ad_patch_runs pr2
          WHERE ap.patch_name = p_ptch
          AND   pd.applied_patch_id = ap.applied_patch_id
          AND   pr2.patch_driver_id = pd.patch_driver_id);
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #6a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'

--print_out(g_rep_info('Apps Version'));
  IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN
    l_step := '20';
    l_col_rows.extend(5); 

    l_col_rows(1)(1) := '19193000';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.HR_PF.C.delta.6';
    l_col_rows(5)(1) := '[1992120.1]';

    l_col_rows(1)(2) := '17909898';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'R12.HR_PF.C.delta.5';
    l_col_rows(5)(2) := '[1644357.1]';

    l_col_rows(1)(3) := '17050005';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'R12.HR_PF.C.delta.4';
    l_col_rows(5)(3) := '[1665609.1]';

    l_col_rows(1)(4) := '17001123';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'R12.HR_PF.C.delta.3';
    l_col_rows(5)(4) := '[]';

    l_col_rows(1)(5) := '16169935';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'R12.HR_PF.C.delta.2';
    l_col_rows(5)(5) := '[]';

    l_col_rows(1)(6) := '14040707';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.HR_PF.C.delta.1';
    l_col_rows(5)(6) := '[]';

    l_col_rows(1)(7) := '10124646';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'R12.HR_PF.C';
    l_col_rows(5)(7) := '[]';
    
	
  ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN 
    l_step := '25';
    l_col_rows.extend(5);	      

    l_col_rows(1)(1) := '20000288';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'Release 12.1 HRMS RUP8';
    l_col_rows(5)(1) := '[1989740.1]';

    l_col_rows(1)(2) := '18004477';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'Release 12.1 HRMS RUP7';
    l_col_rows(5)(2) := '[1645859.1]';

    l_col_rows(1)(3) := '16000686';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'Release 12.1 HRMS RUP6';
    l_col_rows(5)(3) := '[1549442.1]';

    l_col_rows(1)(4) := '13418800';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'Release 12.1 HRMS RUP5';
    l_col_rows(5)(4) := '[1456556.1]';

    l_col_rows(1)(5) := '10281212';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'Release 12.1 HRMS RUP4';
    l_col_rows(5)(5) := '[1313891.1]';

    l_col_rows(1)(6) := '9114911';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'Oracle Human Resource Management System 12.1.3 Product Family Release Update Pack';
    l_col_rows(5)(6) := '[1081427.1]';

    l_col_rows(1)(7) := '8337373';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Oracle Human Resource Management System Release Update Pack 2 for 12.1 (R12.HR_PF.B.DELTA.2)';
    l_col_rows(5)(7) := '[949437.1]';
    
    l_col_rows(1)(8) := '7446767';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'Release 12.1 HRMS RUP1';
    l_col_rows(5)(8) := '[]';

    l_col_rows(1)(9) := '6603330';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'R12 HRMS FAMILY PACK B';
    l_col_rows(5)(9) := '[]';

 -- If want to go based on more e-Business Application version, just add for example:
 -- ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
  ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN 
    l_step := '30';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '16077077';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'Oracle HRMS Release Update Pack 11 for 12.0 (R12.HR_PF.A.DELTA.11)';
    l_col_rows(5)(1) := '[1564126.1]';

    l_col_rows(1)(2) := '13774477';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'Oracle HRMS Release Update Pack 10 for 12.0 (R12.HR_PF.A.DELTA.10)';
    l_col_rows(5)(2) := '[1468789.1]';

    l_col_rows(1)(3) := '10281209';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'Oracle HRMS Release Update Pack 9 for 12.0 (R12.HR_PF.A.DELTA.9)';
    l_col_rows(5)(3) := '[1338475.1]';

    l_col_rows(1)(4) := '9301208';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'Oracle HRMS Release Update Pack 8 for 12.0 (R12.HR_PF.A.DELTA.8)';
    l_col_rows(5)(4) := '[1097842.1]';

    l_col_rows(1)(5) := '7577660';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'Oracle HRMS Release Update Pack 7 for 12.0 (R12.HR_PF.A.DELTA.7)';
    l_col_rows(5)(5) := '[818408.1]';

    l_col_rows(1)(6) := '7004477';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.HR_PF.A.DELTA.6';
    l_col_rows(5)(6) := '[744036.1]';

    l_col_rows(1)(7) := '6610000';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Oracle HRMS Release Update Pack 5 for 12.0 (R12.HR_PF.A.DELTA.5)';
    l_col_rows(5)(7) := '[565977.1]';

    l_col_rows(1)(8) := '6494646';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'R12.HR_PF.A.DELTA.4';
    l_col_rows(5)(8) := '[466091.1]';

    l_col_rows(1)(9) := '6196269';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Oracle HRMS Release Update Pack 3 for 12.0 (R12.HR_PF.A.DELTA.3)';
    l_col_rows(5)(9) := '[452716.1]';
    
    l_col_rows(1)(10) := '5997278';
    l_col_rows(2)(10) := 'No';
    l_col_rows(3)(10) := NULL;
    l_col_rows(4)(10) := 'Oracle HRMS Release Update Pack 2 for 12.0 (R12.HR_PF.A.DELTA.2)';
    l_col_rows(5)(10) := '[430740.1]';
    
    l_col_rows(1)(11) := '5881943';
    l_col_rows(2)(11) := 'No';
    l_col_rows(3)(11) := NULL;
    l_col_rows(4)(11) := 'Oracle HRMS Release Update Pack 1 for 12.0 (R12.HR_PF.A.DELTA.1)';
    l_col_rows(5)(11) := '[417916.1]';        
  
  ELSIF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2' THEN 
    l_step := '30';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '16077077';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'Oracle HRMS Release Update Pack 11 for 12.0 (R12.HR_PF.A.DELTA.11)';
    l_col_rows(5)(1) := '[]';

    l_col_rows(1)(2) := '13774477';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'Oracle HRMS Release Update Pack 10 for 12.0 (R12.HR_PF.A.DELTA.10)';
    l_col_rows(5)(2) := '[]';

    l_col_rows(1)(3) := '10281209';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'Oracle HRMS Release Update Pack 9 for 12.0 (R12.HR_PF.A.DELTA.9)';
    l_col_rows(5)(3) := '[]';

    l_col_rows(1)(4) := '9301208';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'Oracle HRMS Release Update Pack 8 for 12.0 (R12.HR_PF.A.DELTA.8)';
    l_col_rows(5)(4) := '[1097842.1]';

    l_col_rows(1)(5) := '7577660';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'Oracle HRMS Release Update Pack 7 for 12.0 (R12.HR_PF.A.DELTA.7)';
    l_col_rows(5)(5) := '[818408.1]';

    l_col_rows(1)(6) := '7004477';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.HR_PF.A.DELTA.6';
    l_col_rows(5)(6) := '[744036.1]';

    l_col_rows(1)(7) := '6610000';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Oracle HRMS Release Update Pack 5 for 12.0 (R12.HR_PF.A.DELTA.5)';
    l_col_rows(5)(7) := '[565977.1]';

    l_col_rows(1)(8) := '6494646';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'R12.HR_PF.A.DELTA.4';
    l_col_rows(5)(8) := '[466091.1]';

    l_col_rows(1)(9) := '6196269';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Oracle HRMS Release Update Pack 3 for 12.0 (R12.HR_PF.A.DELTA.3)';
    l_col_rows(5)(9) := '[452716.1]';
     
  -- PSD #6a-end

  END IF;
  
  -- Check if applied
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i));
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RSGT1 (RS greater than 1), RS (row selected), NRS (no row selected)
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') --should signature be included in DX Summary
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #7
PROCEDURE validate_parameters (
  p_person_id       IN NUMBER,
  p_from_date       IN DATE,
  p_max_output_rows IN NUMBER,
  p_debug_mode      IN VARCHAR2) IS

  l_from_date    VARCHAR2(25);
  l_to_date      VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;

  invalid_parameters EXCEPTION;
  
  -- PSD #9a
  l_person_id_1  NUMBER := NULL;
  l_chk_id_1     NUMBER := NULL;
  l_ppr_id       NUMBER := NULL; 
  l_federal      VARCHAR2(30);
  l_ss           VARCHAR2(255);
  l_key          VARCHAR2(255);
  
  cursor cur_person_id(p_person_id varchar2) is
    Select count(1) 
    from   per_all_people_f 
    where  person_id = p_person_id and rownum = 1;

  -- PSD #9a-end
  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #8  
  l_revision := rtrim(replace('$Revision: 200.15 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/09/14 22:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #9  
  g_rep_info('File Name') := 'hcm_person_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  
  -- PSD #9a
  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');

  IF p_person_id is null THEN
    print_log('No Person ID specified. '||
      'The Person Id parameter is mandatory.');
    raise invalid_parameters;
  END IF;
  
  l_from_date := to_char(nvl(p_from_date,sysdate-90),'DD-MON-YYYY');

  l_to_date  := to_char((sysdate),'DD-MON-YYYY');


  g_sql_tokens('##$$cur_person_id$$##') := l_ss;
  print_log('cur_person_id = '||l_ss);

  l_ss := null;
  if (l_chk_id_1 is not null) then
    l_ss := to_char(l_chk_id_1);
  end if;  

  l_key := g_sql_tokens.first;
  -- Print token values to the log
 
  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  
  -- PSD #10
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Person Id') := p_person_id;
  g_parameters('4. From Date') := l_from_date;
  g_parameters('5. Max Rows') := 	g_max_output_rows;
  g_parameters('6. Debug Mode') := p_debug_mode;
  
  -- PSD #10a
  -- Create global hash of SQL token values
  g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');
  g_sql_tokens('##$$PERID$$##') := to_char(p_person_id);
  g_sql_tokens('##$$FDATE$$##') := l_from_date;
  -- PSD #9a-end

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info       HASH_TBL_4K;
  l_inst_name  varchar2(20);
  l_host_name  varchar2(50); 
  l_rel_name   varchar2(50);
  l_created    date;
  l_wf_ver     varchar2(100);
  l_db_version varchar2(250);
  l_hr_status  varchar2(50);
  l_pay_status varchar2(50);
  l_multorg    FND_PRODUCT_GROUPS.MULTI_ORG_FLAG%type;
  l_multiCurr  FND_PRODUCT_GROUPS.MULTI_CURRENCY_FLAG%type;
  l_step       VARCHAR2(5);
  l_overview   varchar2(3000); 
  
BEGIN
-- PSD #11
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------
  
  -------------------------------------------------------------------
  -- Example signature that can be used to check for invalid objects
  --------------------------------------------------------------------
  -- Signature for Invalid objects
  -- PSD #11a
  add_signature(
   'INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''HR%'' OR
         a.object_name like ''PER_%'' )
    AND a.status = ''INVALID''',
   'Person Related Invalid Objects',
   'RS',
   'There exist invalid Person related objects',
   '<ul>
      <li>Recompile the individual objects manually or recompile the
          entire APPS schema with adadmin utility</li>
      <li>Review any error messages provided</li>
   </ul>',
   'No Person related invalid objects exists in the database',
   'ALWAYS',
   'E');  
  
  -- PSD #11
  -- INSTANCE_SUMMARY
  
	/*	select 'Instance Name = '|| upper(instance_name) instance_name from v$instance
		union
    select 'Host Name = '|| host_name from v$instance
    union
		select 'Release Name = '|| release_name from fnd_product_groups
		union
		select 'Database Created = ' || created from v$database
		union
		select 'Database Version = ' || banner db_version from v$version where rownum = 1
		union
    select 'Workflow Version = ' || text from wf_resources 
      where type = 'WFTKN' and name = 'WF_VERSION' and language = 'US'
		union
		SELECT 'HR Status = ' || L.MEANING 
	  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
	  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
		AND (b.APPLICATION_ID = '800')
		AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
		AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'	AND l.language = 'US'
		union
	  SELECT 'PAY Status = ' || L.MEANING 
	  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
	  WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	    AND b.application_id = t.application_id
		AND (b.APPLICATION_ID = '801')
		AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
		AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'	AND l.language = 'US'
		union
		SELECT 'Multi Org = ' || MULTI_ORG_FLAG FROM FND_PRODUCT_GROUPS
		union
    SELECT 'Multi Curr = ' || MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS;		
  */

   
  l_step := '44';
  -- signature for person issue - where person exists dates with gap or overlap of person record
  --   
  -- PSD #12a
  add_signature(
   'PERSONS_CWK_ISSUE1',
   'select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(effective_start_date, 11, '' '') "Eff Strt Dt"
		      ,rpad(effective_end_date, 11, '' '') "Effe End Dt" 
		      ,rpad(full_name, 30, '' '') "Full Name                     "
		      ,rpad(person_id, 10, '' '') "Person Id"
		      ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
		      ,rpad(nvl(current_npw_flag,''-''), 13, '' '') "Curr NPW Flag"
		      ,rpad(nvl(npw_number,''-''), 10, '' '') "NPW Number"
	 from   per_all_people_f 
	 where  (npw_number is null
	        or
		      current_npw_flag is null)
   and    person_type_id in (select person_type_id 
                             from   per_person_types 
                             where  (system_person_type like ''%CWK%''))
   ',
   'Contingent worker with improper setup',
   'RS',
   'There is a possible problem with contingent workers (CWK) that have a null CURRENT_NPW_FLAG or NPW_NUMBER columns <br>
    See Note:  Terminate Contingent Worker - APP-PAY-07092 The action is invalid for this record - [1339204.1]',
   'Please open a new service request with Oracle Human Resources support with Person Analyzer Note - [1675487.1] output uploaded',
   'Contingent worker setup with NPW_NUMBER and CURRENT_NPW_FLAG are set',
   'FAILURE',
   'W',
   'RS',
   'N',
   l_info); 

  l_step := '44';
  -- signature for persons issue - Persons element entry with start date is > end date
  --   
  -- PSD #12a
  add_signature(
   'PERSONS_PEE_ISSUE2',
   'select distinct pee.element_entry_id, 
           pee.assignment_id, 
           pet.element_name,
           decode(pet.processing_type,''R'',''Recurring'', ''Non-Recurring'') Processing, 
           pee.element_link_id, 
           pee.effective_start_date,
           pee.effective_end_date
    from   pay_element_entries_f pee, 
           pay_element_types_f pet, 
           per_all_assignments_f paa
    where  pee.effective_start_date > pee.effective_end_date
    and    pee.element_type_id = pet.element_type_id
    and    pee.assignment_id = paa.assignment_id
    Order by pee.assignment_id
   ',
   'Person / Assignment ids with Elements entries that have an End Date before Start Date',
   'RS',
   'There is a possible data issue where Person / Assignment ids have Elements entries that have an end date before start date.<br>
    See note - [340188.1] Reverse Termination - APP-PAY-51058 ''An Error Occurred in hrentmnt.validate_adjust_entry''',
   'Please open a new service request with Oracle Human Resources support with Person Analyzer Note - [1675487.1] ouput uploaded',
   'Element entries Start Date is <= End Date',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info); 
  
  l_overview := '	select ''Instance Name = ''|| upper(instance_name) "Instance Summary" from v$instance
              		union
                    select ''Host Name     = ''|| host_name from v$instance
                    union
              		select ''Applications  = ''|| release_name from fnd_product_groups
              		union
              		select ''Instance Creation Date = '' || created from v$database
              		union
              		select ''Database               = '' || banner db_version from v$version where rownum = 1
              		union
                    select ''Workflow Version       = '' || text from wf_resources 
                    where type = ''WFTKN'' and name = ''WF_VERSION'' and language = ''US''
              		union
              		SELECT ''PER / HR Status        = '' || L.MEANING 
              	    FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
              	    WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
              		AND (b.APPLICATION_ID = ''800'')
              		AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
              		AND (L.LOOKUP_CODE = I.Status)
              		AND t.language = ''US''	AND l.language = ''US''
              		union
              	    SELECT ''PAY Status             = '' || L.MEANING 
              	    FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
              	    WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
              	    AND b.application_id = t.application_id
              		AND (b.APPLICATION_ID = ''801'')
              		AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
              		AND (L.LOOKUP_CODE = I.Status)
              		AND t.language = ''US''	AND l.language = ''US''
              		union
              		SELECT ''Multi Org              = '' || MULTI_ORG_FLAG FROM FND_PRODUCT_GROUPS
              		union
                    SELECT '' Multi Currency         = '' || MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS
				    union
					select * from (select  pd.patch_abstract||'' ( ''||ap.patch_name||'' ) Applied on ''||to_char(pr2.start_date,''DD-Mon-YYYY HH:MI:SS'')
					from    ad_applied_patches ap,
					        ad_patch_drivers pd,
        					ad_patch_runs pr2
					where   --ap.patch_name = ''20000288'' --p_ptch
					pd.patch_abstract like ''%12.1%RUP%''
					and     pd.applied_patch_id = ap.applied_patch_id
					and     pr2.patch_driver_id = pd.patch_driver_id
					order by  ap.patch_name desc)
					where rownum = 1';
  
  add_signature(
   'OVERVIEW',
   l_overview,   
   'Instance Summary',
   'RS',
   'Basic Instance details',
   null,
   'No Overview information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');
	
  l_step := '43';
  -- signature for product_detail
  -- PSD #11a
  add_signature(
   'PRODUCTS_INSTALL',
   'select t.application_name application, b.application_short_name "Short Name"
      , to_char(t.application_id) "Application ID"
      , l.meaning Status
      , decode(i.patch_level, null, ''11i.'' || b.application_short_name || ''.?'', i.patch_level) "Patch Level"
      from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
      where (t.application_id = i.application_id)
      AND b.application_id = t.application_id
      and (b.application_id in (''0'', ''50'', ''101'',''178'', ''203'', ''231'', ''275'', ''426'', ''453'', ''800'', ''801'',
          ''802'', ''803'', ''804'', ''805'', ''808'', ''809'', ''810'', ''821'', ''8301'', ''8302'', ''8303'',''8401'',''8403''))
      and (l.lookup_type = ''FND_PRODUCT_STATUS'')
      and (l.lookup_code = i.status )
      AND t.language = ''US'' AND l.language = ''US'' order by upper(t.application_name)',   
   'Products Install Details',
   'RS',
   'The above table is the installation status of HRMS related Products and their patch set level.
    If the patch set is not stored in the database a ''?'' is substituted for the patch set letter.',
   '',
   'No product information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  -- signature for Legislations Installed
  -- PSD #12a
  add_signature(
   'INSTALLED_LEGISLATIONS',
   'select  rpad(decode(legislation_code,null,''global'',legislation_code),16,'' '') "Legislation Code", 
            rpad(decode(application_short_name , ''PER'', ''Human Resources'' , ''PAY'', ''Payroll'' , ''GHR'',
                   ''Federal Human Resources'' , ''CM'',  ''College Data'' , application_short_name),16,'' '') "Application Name",
            rpad(application_short_name,16,'' '') "Application Code",
            rpad(decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'',''-''),13,'' '') "Action       ",
            rpad(to_char(last_update_date, ''DD-MON-YYYY''),12,'' '') "Applied Date"
    from hr_legislation_installations
        where status = ''I'' 
        order by legislation_code',
   'Installed Legislations',
   'RS',
   'All legislations installed',
   '',
   'No Installed Legislations information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');

  -- signature for Business groups
  -- PSD #12a
  add_signature(
   'BUSINESS_GROUPS',
   'SELECT  rpad(o.business_group_id,10,'' '') "Bus Grp ID"
            ,rpad(otl.name,20,'' '') "Organization Name   "
			,rpad(o.organization_id,6,'' '')  "Org Id"
			,rpad(o3.ORG_INFORMATION9,8,'' '') "Leg Code"
  			,rpad(hr_general_utilities.get_lookup_meaning(''EMP_NUM_GEN_METHOD'',o3.org_information2),11,'' '') "Emp Num Gen"
  			,rpad(hr_general_utilities.get_lookup_meaning(''APL_NUM_GEN_METHOD'',o3.org_information3),12,'' '') "Appl Num Gen"
  			,rpad(hr_general_utilities.get_lookup_meaning(''CWK_NUM_GEN_METHOD'',o3.org_information16),14,'' '') "Contig Num Gen"
  			,rpad(o3.org_information10,8,'' '') "Currency"
			,rpad(o4.org_information2,7,'' '') "Enabled"
			,rpad(to_char(o.date_from , ''DD-MON-YYYY''),11,'' '') "Date From  "
			,rpad(nvl(to_char(o.date_to, ''DD-MON-YYYY''),''-''),11,'' '') "Date To    "
  		from hr_all_organization_units o , 
  			hr_all_organization_units_tl otl , 
  			hr_organization_information o2 ,
  			hr_organization_information o3 , 
  			hr_organization_information o4 
  		where o.organization_id = otl.organization_id 
  			and o.organization_id = o2.organization_id (+) 
  			and o.organization_id = o3.organization_id 
  			and o.organization_id = o4.organization_id 
  			and o3.org_information_context = ''Business Group Information'' 
  			and o2.org_information_context (+) = ''Work Day Information'' 
  			and o4.org_information_context = ''CLASS'' 
  			and o4.org_information1 = ''HR_BG'' and o4.org_information2 = ''Y'' 
  			and otl.language = ''US''
  			order by   1',
   'Business Group Details',
   'RS',
   'All business groups details',
   '',
   'No Business Groups exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');

  -- signature for Shared HR installed customers ONLY
  -- PSD #12a
  add_signature(
   'SHARED_HR',
   'select fpotl.USER_PROFILE_OPTION_NAME, 
		   fpov.LEVEL_ID, 
		   fpo.APPLICATION_ID, 
		   DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',''N'',''No'',
			 fpov.PROFILE_OPTION_VALUE) "Profile Option value", 
		   fpov.LEVEL_VALUE 
	from FND_PROFILE_OPTIONS fpo, 
		 FND_PROFILE_OPTIONS_TL fpotl, 
		 FND_PROFILE_OPTION_VALUES fpov
	where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
	and   fpo.PROFILE_OPTION_NAME = ''DATETRACK:ENABLED'' 
	and   fpotl.PROFILE_OPTION_NAME = ''DATETRACK:ENABLED'' 
	and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
	and   fpotl.LANGUAGE = ''US'' 
	and   fpov.PROFILE_OPTION_ID = 1208
	and   fpov.LEVEL_ID IN (10001,10002) 
	and   fpov.LEVEL_VALUE != ''804''
	union
	select fpotl.USER_PROFILE_OPTION_NAME "User Profile Option Name", 
		   fpov.LEVEL_ID lid, 
		   fpo.APPLICATION_ID ,
		   DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',''N'',''No'',
			 fpov.PROFILE_OPTION_VALUE) "Profile Option value", 
		   fpov.level_value  
	from   FND_PROFILE_OPTIONS fpo, 
		   FND_PROFILE_OPTIONS_TL fpotl, 
		   FND_PROFILE_OPTION_VALUES fpov
	where  fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
	and    fpotl.PROFILE_OPTION_NAME = ''PER_ENABLE_DTW4'' 
	and    fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
	and    fpov.LEVEL_ID IN (10001,10002) 
	and    fpotl.LANGUAGE = ''US'' 
	and    fpo.APPLICATION_ID = 800
    ',
   'Shared HR installed customers ONLY',
   'RS',
   'Profiles Enabled in shared HR that are not allowed Enabled in shared HR environments <br>',
   'Profiles ''DateTrack:Enabled'' and ''HR: Enable DTW4 defaulting'' are not allowed to be active in a shared HR installed environment. <br>
	These profiles are only allowed to be active and used within fully installed Oracle Human Resources environments.<br>
    <br>
	Leaving these profiles Enabled can cause datetrack records to be created, which is data corruption in shared HR.<br>
    <br>
	Please see the following note and correct the settings for these profiles. <br>
	Note - [1075831.1] - Within ''Shared HR'' Environments What Types of Records Would You Expect to See in HR tables ? <br>
    <br>
	<br>
	To correct profile ''DateTrack:Enabled''  run the following against each of your instances.<br>
    <br>
	UPDATE FND_PROFILE_OPTION_VALUES <br>
	SET PROFILE_OPTION_VALUE = NULL <br>
	where APPLICATION_ID = 803 <br>
	and PROFILE_OPTION_ID = 1208 <br>
	and LEVEL_ID IN (10001,10002) <br>
	and LEVEL_VALUE IN (0,800,801,805,808,809,810,833,8301,8302,8303) <br>
    <br>
	commit<br>
    <br>
    <br>
	To correct profile ''HR: Enable DTW4 defaulting'' perform the following against each of your instances. <br>
    <br>
	navigate to <br>
	System Administrator responsibility ><br>
	Profile ><br>
	System ><br>
	query for the profile and set it to  ''No''  at Site  level > <br>
	Save<br>
    ',
   'Profiles for Shared HR are not available',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
    
  l_step := '44';
  -- signature for person_details
  -- PSD #12a
    -- replace(rpad(ppf.effective_start_date, 11, '' ''), '' '', ''&nbsp;'')
  add_signature(
   'PERSON_DETAILS',
   'select 
		   rpad(ppf.effective_start_date, 11, '' '') "Eff Strt Dt"
         , rpad(ppf.effective_end_date, 11, '' '') "Effe End Dt"
		 , rpad(ppf.full_name, 30, '' '') "Full Name                     "
		 , rpad(ppf.person_id, 9, '' '') "Person Id"
         , rpad(nvl(ppf.employee_number,''-''), 10, '' '') "Emp Number"
         , rpad(nvl(ppf.applicant_number,''-''), 10, '' '') "App Number"
         , rpad(nvl(ppf.npw_number,''-''), 10, '' '') "NPW Number"
         , rpad(ppt.system_person_type || '' - '' || ppt.user_person_type|| '' ('' || ppt.person_type_id || '')'',27,'' '') "Person Type (ID)           "
         , rpad(nvl(ppf.attribute_category,''-''), 10, '' '')      "Attr Categ"
         , rpad(ppf.party_id, 8, '' '')                 "Party ID"
         , rpad(ppf.business_group_id, 10, '' '')       "Bus Grp ID"
         , rpad(nvl(ppf.current_applicant_flag,''-''), 14, '' '')  "Curr Appl Flag"
         , rpad(nvl(ppf.current_emp_or_apl_flag,''-''), 18, '' '') "Curr Emp/Appl Flag"
         , rpad(nvl(ppf.current_employee_flag,''-''), 13, '' '')   "Curr Emp Flag"
         , rpad(nvl(ppf.current_npw_flag,''-''), 13, '' '')        "Curr NPW Flag"
         , rpad(decode(to_char(ppf.SEX),''F'',''(F) Female'',''M'',''(M) Male'',''N'',''(N) Unspecified'',''U'',''(U) Unknown''), 15, '' '')  "Gender         " 
         , rpad(nvl(ppf.email_address,''-''), 30, '' '')          "Email Address                 "
         , rpad(ppf.start_date, 10, '' '')            "Start Date"
         , rpad(nvl(to_char(ppf.original_date_of_hire),''-''), 14, '' '')  "Ori Dt of Hire"
         , rpad(nvl(to_char(ppf.comment_id),''-''), 10, '' '')            "Comment ID"
         , rpad(ppf.object_version_number, 7, '' '')  "Obj Ver"
         , rpad(decode(to_char(nvl(ppf.expense_check_send_to_address,''-'')),''h'',''home'', ''o'',''office'',''p'',''provisional'',''-''), 11, '' '')  "Mail To    "
         , rpad(ppf.created_by, 10, '' '')        "Created By"
         , rpad(ppf.creation_date, 13, '' '')     "Creation Date"
         , rpad(ppf.last_updated_by, 11, '' '')   "Last Upd By"
         , rpad(ppf.last_update_date, 13, '' '') "Last Upd Date"
      from
           per_person_types         ppt
         , per_all_people_f         ppf
      where ppf.person_id = ##$$PERID$$##
        and ppf.person_type_id = ppt.person_type_id',
   'Person Details',
   'RS',
   'This section lists the People details for each Effective Date Range for Person. Also lists the Person Name, Type and Party Id for each Effective Date Range',
   '',
   'No Person details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');

l_step := '44';
  -- signature for person issue - where person exists without effective end date '4712 Dec 31'
  --  replace(rpad(ppf.effective_start_date, 11, '' ''), '' '', ''&nbsp;'')
  -- PSD #12a
  add_signature(
   'PERSON_ISSUE1',
   'select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(effective_start_date, 11, '' '') "Eff Strt Dt"
		  ,rpad(effective_end_date, 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
    from  per_all_people_f
    where person_id = ##$$PERID$$##
    and   not exists (
              select person_id
			        ,count(to_char(effective_end_date,''YYYYMMDD'')) l_end_date
 			  from  per_all_people_f where person_id = ##$$PERID$$## 
			  and   to_char(effective_end_date,''yyyymmdd'') = ''47121231''
              group by Person_id
              having count(to_char(effective_end_date,''YYYYMMDD'')) = 1
			union
			  select person_id, count(to_char(effective_end_date,''YYYYMMDD'')) l_end_date 
              from   per_all_people_f 
			  where  person_id = ##$$PERID$$##
              and    to_char(effective_end_date,''yyyymmdd'') = ''47121231''
              group by Person_id
              having count(to_char(effective_end_date,''YYYYMMDD'')) > 1)',
   'Person Record - issue with Effective End Date ',
   'RS',
   'This section lists the People details for which there data corruption with 
    no record end dating with 31st Dec 4712 or two records with Effective end date as 31st Dec 4712',
   'Correct the Dates for the Person',
   'No person with this issue of missing person with end dating 31st Dec 4712 or multiple Effective end date with 31s Dec 4712.',
   'ALWAYS',
   'E',
   'Y',
   'N',
   l_info);   

  l_step := '44';
  -- signature for person issue - where person exists dates with gap or overlap of person record
  --   
  -- PSD #12a
  add_signature(
   'PERSON_ISSUE2',
   'select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(effective_start_date, 11, '' '') "Eff Strt Dt"
		  ,rpad(effective_end_date, 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
    from  per_all_people_f c
    where person_id = ##$$PERID$$##
    and exists ( select a.person_id,a.effective_start_date, a.effective_end_date,count(a.person_id) 
	             from per_all_people_f a, per_all_people_f b
                 where a.person_id = b.person_id 
                 and a.person_id = c.person_id
                 and trunc(a.effective_end_date) >= trunc(b.effective_start_date+1)
                 and trunc(a.effective_end_date) <= trunc(b.effective_end_date)
                 group by  a.person_id,a.effective_start_date, a.effective_end_date
                 having count(a.person_id) > 1
				)
	union
    select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(effective_start_date, 11, '' '') "Eff Strt Dt"
		  ,rpad(effective_end_date, 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
    from  per_all_people_f e
    where person_id = ##$$PERID$$##	
	AND NOT EXISTS (SELECT person_id
                    FROM per_all_people_f c
                    WHERE person_id = e.person_id
                    AND e.person_id = c.person_id
                    AND (SELECT COUNT(*)
                         FROM
                          (SELECT a.person_id,
                                  TO_CHAR(TRUNC(a.effective_start_date),''yyyymmdd''),
                                  TO_CHAR(TRUNC(a.effective_end_date),''yyyymmdd''),
                                  b.effective_start_date,
                                  b.effective_end_date,
                                  COUNT(a.person_id)
                          FROM per_all_people_f a,
                               per_all_people_f b
                          WHERE a.person_id  = b.person_id
                          AND a.person_id    = ##$$PERID$$##
                          AND TRUNC(a.effective_start_date)-1 = TRUNC(b.effective_end_date)
                          AND a.effective_start_date          > b.effective_end_date
                          GROUP BY a.person_id,
                                TO_CHAR(TRUNC(a.effective_start_date),''yyyymmdd''),
                                TO_CHAR(TRUNC(a.effective_end_date),''yyyymmdd''),
                                b.effective_start_date,
                                b.effective_end_date
                          HAVING COUNT(a.person_id) =1
                         ) )  =  (SELECT COUNT(person_id)-1
                                  FROM per_all_people_f d
                                  WHERE d.person_id = c.person_id )
                   )
   ',
   'Person Record - Overlap or Gap in effective dates',
   'RS',
   'This section lists the People details for which there data corruption with <br>
    1) Person record with overlapping dates <br> 2) Person Record with gap in effective dates ',
   'Correct the Dates for the Person',
   'No person with this issue with overlapping effective dates or gap in effective dates.',
   'ALWAYS',
   'E',
   'Y',
   'N',
   l_info);   

  l_step := '44';
  -- signature for person issue - where person exists dates with gap or overlap of person record
  --   
  -- PSD #12a
  add_signature(
   'PERSON_ISSUE3',
   'select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(effective_start_date, 11, '' '') "Eff Strt Dt"
		  ,rpad(effective_end_date, 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
	from per_all_people_f 
	where person_id = ##$$PERID$$##
	and   date_of_birth is null
   ',
   'Person Record - Missing Date of Birth',
   'RS',
   'Date of Birth missing for person. An Employee cannot be entered on a Payroll without a Date of Birth.',
   '',
   'Person is with Date of Birth data',
   'ALWAYS',
   'W',
   'Y',
   'N',
   l_info);
   
  l_step := '45';
  -- signature for fnd_user_details
  -- PSD #12a
  add_signature(
   'FND_USER_DETAILS',
   'select fu.user_name,                                              
             fu.user_id,                                                 
             fu.email_address,                                          
             fu.start_date,                                             
             fu.end_date 
      from fnd_user fu                                                        
      where fu.employee_id in                                                 
           (select papf.person_id                                             
            from per_all_people_f papf                                        
            where papf.person_id = ##$$PERID$$##                                
            and papf.effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY''))',
   'FND User Details',
   'RS',
   'This section lists defined FND User',
   '',
   'No FND User details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
  l_step := '46'; 
  
  -- signature for fnd_user_resp_details
  -- PSD #12b
  add_signature(
   'FND_USER_RESP_DETAILS',
   'select frtl.responsibility_name,
             furg.responsibility_id,
             furg.user_id, 
             furg.start_date, 
             furg.end_date
      from fnd_user_resp_groups furg, 
           fnd_responsibility_tl frtl 
      where furg.responsibility_id = frtl.responsibility_id                
      and   user_id in                                                       
            (select user_id                                                   
             from FND_USER FU                                                    
             where fu.employee_id = ##$$PERID$$##)
      order by frtl.responsibility_name',
   'Responsibilities Assigned to FND User',
   'RS',
   'This section lists the assigned Responsibilities',
   '',
   'No FND User responsibility details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   
  l_step := '47';
  -- signature for contact_details
  -- PSD #12b
  add_signature(
   'CONTACT_DETAILS',
   'select rpad(ppf.effective_start_date, 11, '' '') "Eff Strt Dt"
         , rpad(ppf.effective_end_date, 11, '' '') "Effe End Dt"
		 , rpad(ppf.full_name, 30, '' '') "Full Name                     "
		 , rpad(con.contact_person_id, 11, '' '') "Cont Per ID"
         , rpad(c.meaning, 20, '' '') "Meaning             "
         , rpad(con.primary_contact_flag, 14, '' '') "Prim Cont Flag"
		 , rpad(con.dependent_flag, 8, '' '') "Dep Flag"
		 , rpad(con.beneficiary_flag, 8, '' '') "Ben Flag"
		 , rpad(con.rltd_per_rsds_w_dsgntr_flag, 9, '' '') "RltdFlag"
         , rpad(con.personal_flag, 9, '' '') "Pers Flag"
         , rpad(con.third_party_pay_flag, 15, '' '') "Thrd Party Flag"
         , rpad(con.created_by, 10, '' '') "Created By"
         , rpad(CON.LAST_UPDATED_BY, 10, '' '') "Lst Upd By"
      from  hr_lookups c, 
            per_contact_relationships con,
            per_all_people_f ppf 
      where c.lookup_type = ''CONTACT''             
      and   c.lookup_code = con.contact_type      
      and   con.contact_person_id = ppf.person_id 
      and   con.person_id = ##$$PERID$$##',
   'Contact Details',
   'RS',
   'This section lists Employee Contact details',
   '',
   ' No Contact details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   
  l_step := '48';
  
  -- signature for PAYE and NI Aggregation Details
  -- PSD #12b
  add_signature(
   'PAYE_NI_DETAILS',
   'select EFFECTIVE_START_DATE Start_Date
           , EFFECTIVE_END_DATE End_Date
           , substrb(ppf.per_information2,1,11) Director
           , substrb(ppf.per_information9,1,15) NI
           , substrb(ppf.per_information10,1,15) PAYE
      from   per_all_people_f ppf
      where  ppf.person_id = ##$$PERID$$##',
   'PAYE and NI Aggregation Details',
   'RS',
   'This section lists PAYE and NI aggregation details',
   '',
   'No PAYE and NI Aggregation details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   
  l_step := '49';
  -- signature for Assignment Details
  -- PSD #12b
  -- replace(rpad(ppf.effective_start_date, 11, '' ''), '' '', ''&nbsp;'')
  add_signature(
   'ASSIGNMENT_DETAILS',
   'select
          rpad(to_char(paf.assignment_id), 9, '' '') "Assign ID"
        , rpad(nvl(paf.assignment_number,''-''), 10, '' '') "Assign Num"
        , rpad(paf.effective_start_date, 11, '' '') "Eff Strt Dt"
        , rpad(paf.effective_end_date, 11, '' '') "Effe End Dt"
        , rpad(nvl(hr_general.decode_lookup(''YES_NO'',paf.primary_flag),''-''), 9, '' '') "Prim Flag"
        ,rpad(nvl(to_char(paf.assignment_sequence),''-''), 7, '' '') "Asg Seq" 
        , rpad(decode(to_char(paf.assignment_type),''A'',''Applicant'',''B'',''Benefits'',''C'',''Contingent'',''E'',''Employee'')
          || '' ('' || paf.assignment_status_type_id || '')'', 15, '' '')     "Assignment Type"
        , rpad(nvl(hr_general.decode_lookup(''PER_ASS_SYS_STATUS'',past.per_system_status),''-''), 20, '' '')  "Assignment Status   "
        , rpad(nvl(to_char(paf.organization_id),''-''), 6, '' '') "Org ID"
        , rpad(nvl(to_char(paf.location_id),''-''), 6, '' '') "Loc ID"
        , rpad(nvl(to_char(paf.job_id),''-''), 6, '' '') "Job ID"
        , rpad(nvl(to_char(paf.position_id),''-''), 6, '' '') "Pos ID"
        , rpad(nvl(to_char(paf.grade_id),''-''), 6, '' '') "Gra ID"
        , rpad(nvl(to_char(paf.period_of_service_id),''-''), 13, '' '') "Prd of Ser ID"
        , rpad(nvl(to_char(paf.business_group_id),''-''), 6, '' '') "Bus ID"
        , rpad(nvl(to_char(paf.pay_basis_id),''-''), 12, '' '') "Pay Basis ID"
        , rpad(nvl(to_char(paf.payroll_id),''-''), 10, '' '') "Payroll ID"
        , rpad(nvl(to_char(paf.supervisor_id),''-''), 13, '' '') "Supervisor ID"
        , rpad(nvl(to_char(paf.vacancy_id),''-''), 10, '' '') "Vacancy ID"
        , rpad(nvl(to_char(paf.object_version_number),''-''), 3, '' '') "OVN"
        , rpad(nvl(to_char(paf.projected_assignment_end) ,''-''), 12, '' '') "Proj Asg End"
        , rpad(paf.created_by, 10, '' '') "Created By"
        , rpad(paf.creation_date, 13, '' '') "Creation Date"
        , rpad(paf.last_updated_by, 10, '' '') "Updated By"
        , rpad(paf.last_update_date, 11, '' '') "Update Date"
		, rpad(nvl(to_char(paf.special_ceiling_step_id),'' ''), 15, '' '') "Spec Ceil St ID"
      from per_assignments_f          paf
        , per_assignment_status_types past 
      where paf.person_id = ##$$PERID$$##
      and past.assignment_status_type_id = paf.assignment_status_type_id
      order by assignment_id, effective_start_date',
   'Assignment Details',
   'RS',
   'This section lists the Assignment details for each Effective Date Range',
   '',
   'No Assignment details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');  

  l_step := '49';
  -- signature for Assignment - More than 1 Primary assignment
  -- PSD #12b
  add_signature(
   'ASSIGNMENT_ISSUE1',
   'select rpad(a.assignment_id, 13, '' '') "Assignment ID"
          ,rpad(nvl(a.assignment_number,''-''), 10, '' '') "Assign Num"
          ,rpad(a.person_id, 9, '' '') "Person ID"
          ,rpad(a.effective_start_date, 11, '' '') "Eff Strt Dt"
          ,rpad(a.effective_end_date, 11, '' '') "Effe End Dt"
		  ,rpad(a.primary_flag, 9, '' '') "Prim Flag"
    from per_all_assignments_f a, per_all_assignments_f b
    where a.assignment_id <> b.assignment_id
    and   (a.effective_start_date between b.effective_start_date and b.effective_end_date
           or
           a.effective_end_date between b.effective_start_date and b.effective_end_date)
    and   a.primary_flag = ''Y'' and b.primary_flag = ''Y''       
    and   a.person_id = b.person_id
    and   a.person_id = ##$$PERID$$##',
   'Assignments Issue - Primary Flag',
   'RS',
   'This section lists the Assignment with two Primary Assignments active at the same point of time.',
   '',
   'No Assignment with multiple Primary Flag ',
   'ALWAYS',
   'E',
   'Y',
   'N',
   l_info);  

  l_step := '49';
  -- signature for Assignment - Overlap of active primary assignment
  -- PSD #12b
  add_signature(
   'ASSIGNMENT_ISSUE2',
   'select rpad(c.assignment_id, 13, '' '') "Assignment ID"
          ,rpad(nvl(c.assignment_number,''-''), 10, '' '') "Assign Num"
          ,rpad(c.person_id, 9, '' '') "Person ID"
          ,rpad(c.effective_start_date, 11, '' '') "Eff Strt Dt"
          ,rpad(c.effective_end_date, 11, '' '') "Effe End Dt"
		  ,rpad(nvl(to_char(c.assignment_status_type_id),''-''), 14, '' '') "Asg St Type ID" 
		  ,rpad(nvl(d.user_status,''-''), 22, '' '') "Assignment User Status"
    from per_all_assignments_f c, per_assignment_status_types  d
    where c.person_id = ##$$PERID$$##
    and c.assignment_status_type_id = d.assignment_status_type_id
    and c.Primary_flag = ''Y''
    and c.assignment_status_type_id = 1
    and exists (select a.person_id,a.effective_start_date, a.effective_end_date,count(a.person_id) 
	             from per_all_assignments_f a, per_all_assignments_f b
                 where a.person_id = b.person_id 
                 and a.person_id = c.person_id
                 and trunc(a.effective_end_date) >= trunc(b.effective_start_date+1)
                 and trunc(a.effective_end_date) <= trunc(b.effective_end_date)
                 and a.assignment_id = b.assignment_id
                 and a.assignment_id = c.assignment_id
                 group by  a.person_id,a.effective_start_date, a.effective_end_date
                 having count(a.person_id) > 1
            )
	',
   'Assignments Issue - Overlap effective date',
   'RS',
   'This section lists the Assignment with Primary Active Assignment with overlap of effective date.',
   '',
   'No Assignment with Overlap of effective date ',
   'ALWAYS',
   'E',
   'Y',
   'N',
   l_info); 

  -- signature for Assignment - Gap of active primary assignment details
  -- PSD #12b
  add_signature(
   'ASSIGNMENT_ISSUE3',
   'SELECT distinct rpad(papf.person_id, 9, '' '') "Person ID"
          ,rpad(paaf.assignment_id, 13, '' '') "Assignment ID"
          ,rpad(paaf.effective_start_date, 11, '' '') "Eff Strt Dt"
          ,rpad(paaf.effective_end_date, 11, '' '') "Effe End Dt"
		  ,rpad(decode(to_char(paaf.assignment_type),''A'',''Applicant'',''B'',''Benefits'',''C'',''Contingent'',''E'',''Employee'')
                  || '' ('' || paaf.assignment_status_type_id || '')'', 15, '' '') "Assignment Type" 
		  ,rpad(nvl(HR_GENERAL.DECODE_LOOKUP(''PER_ASS_SYS_STATUS'',past.per_system_status),''-''), 17, '' '') "Assignment Status"
      FROM apps.per_all_people_f papf,
           apps.per_all_assignments_f  paaf,
           apps.per_assignment_status_types past
      WHERE papf.person_id = ##$$PERID$$##
      AND paaf.person_id = papf.person_id
      AND paaf.primary_flag = ''Y''
      AND(paaf.effective_start_date BETWEEN papf.effective_start_date AND papf.effective_end_date
      OR  paaf.effective_end_date BETWEEN papf.effective_start_date AND papf.effective_end_date)
      AND past.assignment_status_type_id = paaf.assignment_status_type_id
      AND paaf.person_id IN
            (SELECT a.person_id
             FROM apps.per_all_assignments_f a
             WHERE a.primary_flag = ''Y''
             AND exists
                (SELECT asub.assignment_id
                 FROM apps.per_all_assignments_f asub
                 WHERE asub.primary_flag = ''Y''
                 and asub.person_id = a.person_id
                 AND asub.effective_start_date > a.effective_end_date)  
             AND NOT exists
                (SELECT asub1.assignment_id
                 FROM apps.per_all_assignments_f asub1
                 WHERE asub1.primary_flag = ''Y''
                 AND asub1.person_id = a.person_id
                 AND asub1.effective_start_date = a.effective_end_date + 1))
      ORDER BY 1, 2, 3
	',
   'Assignments Issue - Gaps in Primary Assignment',
   'RS',
   'This section lists Assignment records if any Gap in Primary Assignment is found.',
   '',
   'No gaps found in Primary Assignment',
   'ALWAYS',
   'E',
   'Y',
   'N',
   l_info);    

   l_step := '491';   
   
  -- signature for Payroll PAYE Reference Details
  -- PSD #12b
  add_signature(
   'PAYROLL_PAYE_DETAILS',
   'SELECT substrb(papf.payroll_id,1,6) payroll_id,                     
             substrb(papf.payroll_name,1,30) payroll_name,                    
             substrb(papf.effective_start_date,1,11) effective_start_date,        
             substrb(papf.effective_end_date,1,11) effective_end_date,          
             substrb(flex.segment1,1,11) payee_reference,                    
             substrb(flex.segment10,1,11) unique_id,                  
             substrb(flex.segment14,1,20) ECON,                       
             substrb(flex.segment4,1,3) MAX_HOL,                      
             substrb(flex.segment9,1,4) BACS                          
      FROM hr_soft_coding_keyflex flex, 
           pay_all_payrolls_f papf 
      WHERE papf.soft_coding_keyflex_id = flex.soft_coding_keyflex_id 
      AND EXISTS (SELECT 1 FROM per_all_assignments_f paaf            
                  WHERE person_id = ##$$PERID$$##
                  AND paaf.payroll_id = papf.payroll_id)              
      ORDER BY papf.payroll_id,                                       
               papf.payroll_name,                                     
               to_date(papf.effective_start_date,''DD-MON-YYYY'')',
   'Payroll PAYE Reference Details',
   'RS',
   'This section lists the Person Type Usage for each Effective Date Range',
   '',
   'No Payroll PAYE reference details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  l_step := '492';
  -- signature for Assignment Action Details
  -- PSD #12b
  add_signature(
   'ASG_ACT_DETAILS',
   'SELECT DISTINCT
		( SELECT DISTINCT fcp.user_concurrent_program_name
		  FROM fnd_concurrent_programs_tl fcp
		  WHERE source_lang = ''US''
		  AND fcp.concurrent_program_id =
			  ( SELECT DISTINCT fcr.concurrent_program_id
			    FROM fnd_concurrent_requests fcr
			    WHERE fcr.request_id =
					  ( SELECT DISTINCT ppa.request_id
					    FROM pay_payroll_actions ppa
					    WHERE ppa.payroll_action_id = pact.payroll_action_id))) conc_prog_name
	  ,substrb (act.assignment_id, 1, 9) assign_id
	  ,pact.effective_date eff_date
	  ,decode(pact.action_type
			  ,''A'',''Cash''
			  ,''B'',''Bal Adj''
			  ,''C'',''Costing''
			  ,''CP'',''Cost Pay''
			  ,''H'',''Cheq writ''
			  ,''L'',''Retro by Ele''
			  ,''M'',''Mag txr''
			  ,''O'',''Retropay''
			  ,''P'',''Prepay''
			  ,''Q'',''Quickpay''
			  ,''R'',''Payroll Run''
			  ,''S'',''Retro Cost''
			  ,''T'',''Tfr to GL''
			  ,''U'',''Quick Prepay''
			  ,''V'',''Reversal''
			  ,''X'',''Mag Rept'') act_type
	  ,substrb (act.action_sequence, 1, 6) act_seq
	  ,substrb (act.assignment_action_id, 1, 10) assign_act_id
	  ,substrb (act.source_action_id, 1, 9) source
	  ,substrb (act.action_status, 1, 7) ass_act_sts
	  ,substrb (pact.action_status, 1, 8) pay_act_sts
	  ,substrb (pact.payroll_action_id, 1, 10) pay_act_id
	  ,pact.start_date
	  ,pact.end_date
	  ,pact.legislative_parameters leg_parameters
	  ,pact.creation_date
	 FROM pay_payroll_actions pact
		,pay_assignment_actions act
	 	,per_all_assignments_f paaf
	 WHERE act.payroll_action_id = pact.payroll_action_id
	 AND act.assignment_id = paaf.assignment_id
	 AND paaf.person_id = ##$$PERID$$##
	 ORDER BY assign_id, eff_date DESC, assign_act_id DESC',
   'Assignment Action Details',
   'RS',
   'This section lists the Assignment Action details',
   '',
   'No Assignment Action details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   
  
  -- signature for Grade Details
  -- PSD #12b
  add_signature(
   'GRADE_DETAILS',
   'select distinct                                        
        substrb(pspf.effective_start_date,1,11) eff_start_date,
        substrb(pspf.effective_end_date,1,11) eff_end_date,
        substrb(pg.grade_id,1,9) grade_id,
        substrb(pg.name,1, 20) grade_name,                 
        substrb(pps.name,1,20) spine_name,                 
        substrb(pspf.step_id,1,7) step_id,                 
        substrb(psp.spinal_point,1,12) spinal_point,       
        substrb(pspsf.sequence,1,4) step                   
    from                                                   
        per_all_people_f ppf,                              
        per_all_assignments_f paf,                         
        per_spinal_point_placements_f pspf,                
        per_spinal_point_steps_f pspsf,                    
        per_grade_spines_f pgs,                            
        per_grades pg,                                     
        per_spinal_points psp,                             
        per_parent_spines pps                              
    where pg.grade_id =  paf.grade_id                      
    and ppf.person_id = ##$$PERID$$##
    and ppf.person_id = paf.person_id
    and paf.assignment_id = pspf.assignment_id             
    and pgs.parent_spine_id = pspf.parent_spine_id         
    and pg.grade_id = pgs.grade_id                         
    and pps.parent_spine_id = pgs.parent_spine_id          
    and pspsf.spinal_point_id = psp.spinal_point_id
    and pspsf.spinal_point_id = psp.spinal_point_id
    and pspsf.grade_spine_id = pgs.grade_spine_id
    and pspsf.step_id = pspf.step_id 
    order by eff_start_date',
   'Grade Step Details',
   'RS',
   'This section lists the Grade Step details',
   '',
   'No Grade Step details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Absence Details
  -- PSD #12b
  add_signature(
   'ABSENCE_DETAILS',
   'select                                                                                                            
          substrb(nvl(paa.date_start,paa.DATE_PROJECTED_START),1,11) START_DATE,
          substrb(nvl(paa.date_end,paa.date_projected_end),1,11) END_DATE,
          decode(nvl(paa.date_start,''01-JAN-4712''),
                to_date(''01-JAN-4712'',''DD-MON-YYYY''),''Projected'',''Actual'') Act_Proj,
          substrb(pat.name,1,25) REASON,
          substrb(paa.absence_days,1,6) DAYS,
          substrb(paa.absence_hours,1,6) HOURS,
          substrb(paa.occurrence,1,10) OCCURRENCE,
          substrb(paa.object_version_number, 1,4) OVN
    from  per_absence_attendances paa,
          per_absence_attendance_types pat 
    where paa.person_id = ##$$PERID$$##
    and   paa.absence_attendance_type_id = pat.absence_attendance_type_id
    order by to_date(START_DATE,''dd-mon-yyyy'')',
   'Absence Details',
   'RS',
   'This section lists the Absence details',
   '',
   'No Absence details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Event Details
  -- PSD #12b
  add_signature(
   'EVENT_DETAILS',
   'select distinct                                          
           assignment_id,              
           event_id,                       
           date_start,              
           date_end,                  
           type,                     
           event_or_interview
        from per_events pe                                       
        where assignment_id in                                   
              (select distinct paf.assignment_id                     
               from per_all_assignments_f paf, per_all_people_f ppf  
               where ppf.person_id = ##$$PERID$$##                     
               and paf.person_id = ppf.person_id)                    
        order by assignment_id,date_start',
   'Event Details',
   'RS',
   'This section lists the EVENT details',
   '',
   'No Event details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Application Details
  -- PSD #12b
  add_signature(
   'APPL_DETAILS',
   'select distinct                                          
           application_id,              
           business_group_id,                       
           date_received,              
           date_end,                  
           object_version_number,                     
           created_by,
           last_updated_by
        from per_applications                                        
        where person_id = ##$$PERID$$##',
   'Application Details',
   'RS',
   'This section lists the Application details',
   '',
   'No Application details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for People Reporting Details
  -- PSD #12b
  add_signature(
   'PPL_REPORT_DETAILS',
   'select distinct
       full_name,
       employee_number,
       person_id
    from per_all_people_f
    where person_id in (
           select paf.person_id
           from  per_all_assignments_f paf
           start with paf.person_id = ##$$PERID$$##
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           connect by PRIOR paf.person_id = paf.supervisor_id
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           minus
           select paf.person_id
           from  per_all_assignments_f paf
           where paf.person_id =  ##$$PERID$$## )
           and sysdate between effective_start_date and effective_end_date',
   'People Reporting To This Person',
   'RS',
   'This section lists the people reporting',
   '',
   'No People reporting to this person exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Person Reporting Details
  -- PSD #12b
  add_signature(
   'PERSON_REPORT_DETAILS',
   'select distinct
       full_name,
       employee_number,
       person_id
    from per_all_people_f
    where person_id in (
           select paf.person_id
           from  per_all_assignments_f paf
           start with paf.person_id = ##$$PERID$$##
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           connect by PRIOR paf.supervisor_id = paf.person_id
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           minus
           select paf.person_id
           from  per_all_assignments_f paf
           where paf.person_id = ##$$PERID$$## )
           and sysdate between effective_start_date and effective_end_date',
   'Who This Person Reports To',
   'RS',
   'This section lists who this person reports to',
   '',
   'This Person does not reports to other person',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Person Security Profiles assigned Details
  -- PSD #12b
  add_signature(
   'PER_SEC_PROF_DETAILS',
   'select pspa.user_id ,                         
           pspa.sec_profile_assignment_id,        
           pspa.security_group_id,                 
           pspa.security_profile_id,               
           pspa.responsibility_id,               
           pspa.responsibility_application_id,
           pspa.start_date,                       
           pspa.end_date,                         
           frtl.responsibility_name             
    from per_sec_profile_assignments pspa,              
         fnd_responsibility_tl frtl                     
    where pspa.user_id =                                
         (select fuser.user_id from fnd_user fuser      
          where fuser.employee_id = ##$$PERID$$##)        
    and pspa.responsibility_id = frtl.responsibility_id 
    and frtl.language = ''US''                            
    order by pspa.start_date, frtl.responsibility_name',
   'PER Security Profile Assigned to Employee details',
   'RS',
   'This section lists the Security Profiles assigned',
   '',
   'No Person Security Profiles assigned to employee',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Employee Supplier Details
  -- PSD #12b
  -- If 11i release, ap_suppliers table does not exists. 
  --    instead use the table 
  if g_rep_info('Apps Version') like '11.5%' then
    add_signature(
     'EMP_SUPL_DETAILS',
     'select vendor_id,         
             vendor_name,       
             employee_id,             
             start_date_active, 
             end_date_active,   
             created_by,     
             creation_date,    
             last_updated_by,
             last_update_date
      from  po_vendors 
      where employee_id = to_char(##$$PERID$$##)',
     'Employee Supplier Details',
     'RS',
     'This section lists the Employee Supplier record. Within table AP_SUPPLIERS column EMPLOYEE_ID = PERSON_ID ',
     '',
     'No Employee Supplier details exists',
     'ALWAYS',
     'I',
     'Y',
     'N',
     l_info);
  else 
    add_signature(
     'EMP_SUPL_DETAILS',
     'select vendor_id,         
             vendor_name,       
             employee_id,             
             start_date_active, 
             end_date_active,   
             created_by,     
             creation_date,    
             last_updated_by,
             last_update_date,
             party_id
      from  ap_suppliers 
      where employee_id = to_char(##$$PERID$$##)',
     'Employee Supplier Details',
     'RS',
     'This section lists the Employee Supplier record. Within table AP_SUPPLIERS column EMPLOYEE_ID = PERSON_ID ',
     '',
     'No Employee Supplier details exists',
     'ALWAYS',
     'I',
     'Y',
     'N',
     l_info);
  end if;
  
  -- signature for Location Details
  -- PSD #12b
  add_signature(
   'LOC_DETAILS',
   'select paf.assignment_number, 
             paf.location_id, 
             hla.style, 
             hla.description, 
             hla.creation_date, 
             hla.inactive_date
      from per_all_assignments_f paf, 
           hr_locations_all hla
      where paf.person_id = ##$$PERID$$##
      and   paf.assignment_status_type_id = 1
      and   paf.location_id = hla.location_id
      and   paf.effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY'')
      order by paf.assignment_number',
   'Location Details',
   'RS',
   'This section lists the Location details for each distinct active assignment record',
   '',
   'No Location details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Period of Service Details 
  -- PSD #12b
  add_signature(
   'PERIOD_SER_DETAILS',
   'select  period_of_service_id
           ,business_group_id
           ,date_start
           ,accepted_termination_date
           ,actual_termination_date
           ,final_process_date
           ,notified_termination_date
           ,leaving_reason
           ,last_standard_process_date
           ,adjusted_svc_date
           ,created_by
           ,creation_date
           ,last_updated_by
           ,last_update_date
           ,object_version_number
    from  per_periods_of_service
    where person_id = ##$$PERID$$##
    order by period_of_service_id',
   'Periods of Service Details',
   'RS',
   'This section lists the Periods of Service details for each effective date range',
   '',
   'No Periods of Service details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Period of Placements Details 
  -- PSD #12b
  add_signature(
   'PERIOD_PLACEMENTS_DETAILS',
   'select period_of_placement_id
         , date_start                    
         , last_standard_process_date
         , actual_termination_date
         , final_process_date
         , created_by
         , last_updated_by
    from per_periods_of_placement
    where person_id = ##$$PERID$$##
    order by 1,2',
   'Period of Placements Details',
   'RS',
   'This section lists the Periods of Placement details for each Effective Date Range.
   PER_PERIODS_OF_PLACEMENT is used for CONTINGENT WORKER records in place of table PER_PERIODS_OF_SERVICE',
   '',
   'No Period of Placements details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Person Type Usage Details 
  -- PSD #12b
  add_signature(
   'PER_TYPE_USAGE_DETAILS',
   'select   ptu.person_type_usage_id
           , ptu.effective_start_date           
           , ptu.effective_end_date             
           , ppt.system_person_type || '' - '' || ppt.user_person_type || '' ('' || ptu.person_type_id || '')'' perType
           , ptu.object_version_number
           , ptu.created_by                     
           , ptu.creation_date                  
           , ptu.last_updated_by                
           , ptu.last_update_date
    from   per_person_type_usages_f ptu
           , per_person_types ppt
    where    ptu.person_id = ##$$PERID$$##
    and      ptu.person_type_id = ppt.person_type_id
    order by 1,2',
   'Person Type Usage Details',
   'RS',
   'This section lists the Person Type Usage for each Effective Date Range',
   '',
   'No Person Type Usage details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Person Address Details 
  -- PSD #12b
  add_signature(
   'PER_ADDRESS_DETAILS',
   'select address_id      
         , business_group_id  
         , style                                                              
         , date_from                                                          
         , date_to                                                            
         , hr_general.decode_lookup(''YES_NO'',primary_flag) primary_flag
         , party_id    
         , town_or_city                                                       
         , region_1                                                           
         , region_2                                                           
         , postal_code                                                        
         , created_by    
         , last_updated_by    
         , add_dtls.meaning
    from per_addresses, 
         (select lookup_type,language,lookup_code,meaning, enabled_flag,start_date_active,end_date_active 
          from fnd_lookup_values 
          where lookup_type = ''ADDRESS_TYPE'' and language = ''US'' ) add_dtls
    where person_id = ##$$PERID$$##
    and   add_dtls.lookup_code = address_type (+)
    order by 4',
   'Person Address Details',
   'RS',
   'This section lists the Address details for each effective date range',
   '',
   'No Person Address details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Address Styles Details 
  -- PSD #12b
  add_signature(
   'ADDRESS_STYLE_DETAILS',
   'select style,
           count(*) s_count
    from per_addresses
    group by style',
   'Address Styles Details',
   'RS',
   'This section lists a count of each address style from table PER_ADDRESSES',
   '',
   'No Address Styles details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Person Analysis Details 
  -- PSD #12b
  add_signature(
   'PERSON_ANALYSIS_DETAILS',
   'select person_analysis_id
         , business_group_id
         , analysis_criteria_id
         , date_from
         , date_to
         , object_version_number
         , party_id
         , created_by
         , last_updated_by
    from per_person_analyses
    where person_id = ##$$PERID$$##
    order by 4',
   'Person Analysis Details',
   'RS',
   'This section lists the Person Analysis details for each Effective Date Range',
   '',
   'No Person Analysis details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Benefits Payroll Details 
  -- PSD #12b
  add_signature(
   'BENEFITS_PAYROLL_DETAILS',
   'select distinct ppf.payroll_name 
      from
         hr_organization_information hoi,
         pay_payrolls_f ppf,
         per_all_people_f pf,
         per_organization_units pou
      where hoi.organization_id = pou.organization_id
      and pf.business_group_id = pou.business_group_id
      and hoi.org_information_context like ''Benefit%''
      and ppf.payroll_id = hoi.org_information2
      and pf.person_id = ##$$PERID$$##',
   'Benefits Payroll Details',
   'RS',
   'This section lists the Benefits Payroll details',
   '',
   'No Benefits Payroll details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for WF Local Roles 
  -- PSD #12b
  add_signature(
   'WF_LOCAL_ROLES_DETAILS',
   'Select name                         
         , display_name
         , email_address
         , orig_system
         , orig_system_id
         , start_date
         , expiration_date
         , status
         , created_by
         , last_updated_by
    from wf_local_roles 
    where orig_system_id = ##$$PERID$$##
    order by name',
   'Workflow Local Roles Details',
   'RS',
   'This section lists the WF_LOCAL_ROLES details. <br>
    The corresponding PERSON_ID column in table WF_LOCAL_ROLES is USER_ORIG_SYSTEM_ID. <br> 
    Records listed under column ''Originating System'' in table WF_LOCAL_ROLES: <br><br>

    PER_ROLE - HR apps creates this record when EMP is hired. <br>
    <ul>
      <li>PER - ATG apps creates this record when FND_USER is attached to an employee</li>
      <li>HZ_PARTY - AP apps creates this record when an AP vendor is created</li>
      <li>POS - POS approver type record is created when a Position is assigned to an Employee who is attached to an FND user</li> 
    </ul>
    HR support is ONLY responsible for the data stored in the PER_ROLE and POS records in this table. ',
   '',
   'No WF Local Roles information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for WF User Roles 
  -- PSD #12b
  add_signature(
   'WF_USER_ROLES_DETAILS',
   'select user_name
          , user_orig_system_id
          , user_orig_system
          , role_orig_system
          , start_date
          , expiration_date
    from wf_user_roles 
    where user_orig_system_id = ##$$PERID$$## 
    and expiration_date is not null 
    order by 1,3,4',
   'Workflow User Roles Details',
   'RS',
   'This section lists the WF_USER_ROLES details.<br>
    The corresponding PERSON_ID column in table WF_USER_ROLES is USER_ORIG_SYSTEM_ID. <br>
    The HRMS application ''does not populate this table data''.',
   '',
   'No Workflow User Roles details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for WF Local User Roles 
  -- PSD #12b
  add_signature(
   'WF_LOCAL_USER_ROLES_DETAILS',
   'select user_name
          , user_orig_system_id
          , user_orig_system
          , role_orig_system
          , start_date
          , expiration_date
          , created_by
          , last_updated_by
    from wf_local_user_roles 
    where user_orig_system_id = ##$$PERID$$## 
    and expiration_date is not null 
    order by 1,3,4',
   'Workflow Local User Roles Details',
   'RS',
   'This section lists the WF_LOCAL_USER_ROLES details where EXPIRATION_DATE IS NOT NULL ',
   '',
   'No WF Local User Roles information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
  
  -- signature for WF User Role Assignments 
  -- PSD #12b
  add_signature(
   'WF_USER_ROLE_ASG_DETAILS',
   'select user_name
          , user_orig_system_id
          , user_orig_system
          , role_orig_system
          , start_date
          , end_date
          , created_by
          , last_updated_by
    from wf_user_role_assignments 
    where user_orig_system_id = ##$$PERID$$## 
    and end_date is not null 
    order by 1,3,4',
   'Workflow User Roles Assignments Details',
   'RS',
   'This section lists the WF_USER_ROLE_ASSIGNMENTS details where END_DATE IS NOT NULL',
   '',
   'No Workflow User Roles Assignments details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
  
  -- signature for HZ Parties 
  -- PSD #12b
  add_signature(
   'HZ_PARTIES',
   'select
         person_identifier
       , party_id
       , party_name
       , party_type
       , orig_system_reference
       , creation_date
       , status
       , email_address
       , created_by
       , last_updated_by
    from hz_parties
    where person_identifier = to_char(##$$PERID$$##)',
   'HZ Parties Details',
   'RS',
   '<b>HR is not responsible for any other records created in this table.</b><br><br>
    This section lists the HZ_PARTIES details for each Effective Date Range.
    The corresponding PERSON_ID column in table HZ_PARTIES is PERSON_IDENTIFIER. <br><br>

    Records listed under column ''Party Type'' in table HZ_PARTIES: 

    PERSON - this record is created when an EMPLOYEE is hired.',
   '',
   'No HZ Parties details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info); 

  -- signature for HZ Person Profiles 
  -- PSD #12b
  add_signature(
   'HZ_PERSON_PROFILES',
   'select
           person_identifier
         , party_id
         , person_name
         , effective_start_date
         , effective_end_date
         , created_by
         , last_updated_by
      from hz_person_profiles
      where person_identifier = to_char(##$$PERID$$##)',
   'HZ Person Profiles Details',
   'RS',
   'This section lists the HZ_PERSON_PROFILES details for each Effective Date Range
    The corresponding PERSON_ID column in table HZ_PERSON_PROFILES is PERSON_IDENTIFIER. <br>

    <b>HR is not responsible for any other records created in this table.</b>',
   '',
   'No HZ Person Profiles details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  -- signature for Salary Administration Analysis (PER_ALL_ASSIGNMENTS_F)
  -- PSD #12b
  add_signature(
   'SAL_ADMIN_ANALYSIS',
   'SELECT paaf.assignment_id,
           paaf.effective_start_date,
           paaf.effective_end_date,
           decode(to_char(paaf.assignment_type),''A'',''Applicant'',''B'',''Benefits'',''C'',''Contingent'',''E'',''Employee'')
           || ''('' || paaf.assignment_status_type_id || '')''  Asg_Type,
           HR_GENERAL.DECODE_LOOKUP(''PER_ASS_SYS_STATUS'',past.per_system_status)  status1,
           paaf.payroll_id,
           paaf.pay_basis_id,
           paaf.created_by,
           paaf.last_updated_by
    FROM per_all_assignments_f paaf,
         per_assignment_status_types past
    WHERE paaf.person_id = ##$$PERID$$##
    and past.assignment_status_type_id = paaf.assignment_status_type_id
    and paaf.assignment_type = ''E''
    and paaf.effective_end_date = ''31-DEC-4712''
    and paaf.period_of_service_id IS NOT NULL
    and paaf.pay_basis_id IS NOT NULL
    ORDER BY paaf.assignment_id',
   'Salary Administration Analysis Details - Assignments',
   'RS',
   'Salary Administration analysis from PER_ALL_ASSIGNMENTS_F table',
   '',
   'No Salary Administration Analysis Details - Assignments',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Salary Administration Analysis (PER_PAY_PROPOSALS)
  -- PSD #12b
  add_signature(
   'SAL_ADMIN_ANALYSIS_1',
   'SELECT assignment_id,
           pay_proposal_id,
           change_date,
           date_to,
           last_change_date,
           approved,
           created_by,
           last_updated_by
    FROM per_pay_proposals 
    WHERE assignment_id  in                                                          
         (SELECT paaf1.assignment_id                                           
          FROM   per_all_assignments_f paaf1,                                  
                 per_assignment_status_types past1                             
          WHERE paaf1.person_id = ##$$PERID$$##
          and past1.assignment_status_type_id = paaf1.assignment_status_type_id
          and paaf1.assignment_type = ''E''                                      
          and paaf1.effective_end_date = ''31-DEC-4712''                         
          and paaf1.period_of_service_id IS NOT NULL                           
          and paaf1.pay_basis_id IS NOT NULL)                                  
    ORDER BY assignment_id, change_date',
   'Salary Administration Analysis Details - Proposals',
   'RS',
   'There exist Salary Administration Analysis details',
   '',
   'No Salary Administration Analysis details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  -- signature for Salary Administration Analysis (PER_PAY_BASIS and PAY_INPUT_VALUES_F)
  -- PSD #12b
  add_signature(
   'SAL_ADMIN_ANALYSIS_2',
   'SELECT  ppb.pay_basis_id, 
            piv.element_type_id , 
            ppb.input_value_id 
    FROM  per_pay_bases ppb, 
          pay_input_values_f piv 
    WHERE ppb.pay_basis_id in  
         (SELECT paaf1.pay_basis_id
          FROM   per_all_assignments_f paaf1,
                 per_assignment_status_types past1
          WHERE paaf1.person_id = ##$$PERID$$##
          and past1.assignment_status_type_id = paaf1.assignment_status_type_id 
          and paaf1.assignment_type = ''E''
          and paaf1.effective_end_date = ''31-DEC-4712'' 
          and paaf1.period_of_service_id IS NOT NULL 
          and paaf1.pay_basis_id IS NOT NULL)
    and ppb.input_value_id = piv.input_value_id 
    and SYSDATE BETWEEN piv.effective_start_date AND piv.effective_end_date',
   'Salary Administration Analysis Details - Pay Basis and Input Values',
   'RS',
   'Salary Administration analysis from PER_PAY_BASIS and PAY_INPUT_VALUES_F tables',
   '',
   'No Salary Administration Analysis Details - Pay Basis and Input Values exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  -- signature for Salary Administration Analysis (PAY_ELEMENT_ENTRIES_F)
  -- PSD #12b
  add_signature(
   'SAL_ADMIN_ANALYSIS_3',
   'select element_entry_id, 
           element_type_id, 
           element_link_id, 
           effective_start_date, 
           effective_end_date, 
           creator_type, 
           creator_id, 
           entry_type, 
           created_by,
           last_updated_by
    from pay_element_entries_f 
    where assignment_id in 
         (select paaf1.assignment_id
          from   per_all_assignments_f paaf1,
                 per_assignment_status_types past1
          where paaf1.person_id = ##$$PERID$$##
          and past1.assignment_status_type_id = paaf1.assignment_status_type_id 
          and paaf1.assignment_type = ''E''
          and paaf1.effective_end_date = ''31-DEC-4712'' 
          and paaf1.period_of_service_id IS NOT NULL 
          and paaf1.pay_basis_id IS NOT NULL)
    and element_type_id in  
         (select piv.element_type_id
          from  per_pay_bases ppb, 
                pay_input_values_f piv 
          where ppb.pay_basis_id in  
               (select paaf1.pay_basis_id
                from   per_all_assignments_f paaf1,
                       per_assignment_status_types past1
                where paaf1.person_id = ##$$PERID$$##
                and past1.assignment_status_type_id = paaf1.assignment_status_type_id 
                and paaf1.assignment_type = ''E''
                and paaf1.effective_end_date = ''31-DEC-4712'' 
                and paaf1.period_of_service_id IS NOT NULL 
                and paaf1.pay_basis_id IS NOT NULL)
          and ppb.input_value_id = piv.input_value_id 
          and sysdate between piv.effective_start_date and piv.effective_end_date)
    order by element_type_id, effective_start_date, effective_end_date',
   'Salary Administration Analysis Details - Pay Element Entries',
   'RS',
   'There exist Salary Administration Analysis Details - Pay Element Entries.<br>
   Creator Type<br>
   ==========<br>
   If Creator Type = ''SP'' then this salary was entered via Salary Admin screen <br>
   If Creator Type = ''F'' then this salary was entered via API <br>
   If Creator Type = ''B'' then this salary was entered via Compensation Workbench',
   '',
   'No Salary Administration Analysis Details - Pay Element Entries',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Object Version Number is null on PER_ALL_PEOPLE_F, 
  --    PER_ALL_ASSIGNMENTS_F, PER_PERIODS_OF_SERVICE, PAY_ELEMENT_ENTRIES_F, 
  --    PAY_ELEMENT_LINKS_F, PER_PAY_PROPOSALS
  -- PSD #12b
  add_signature(
   'OVN_DETAILS_PAPF',
   'select person_id,
           effective_start_date,
           effective_end_date
    from per_all_people_f
    where person_id = ##$$PERID$$##
    and object_version_number is null',
   'Object Version Number (OVN) is null - PER_ALL_PEOPLE_F',
   'RS',
   'Records from PER_ALL_PEOPLE_F where OVN is NULL for this employee',
   '<ul>
      <li>Check the details</li>
      <li>Review data</li>
   </ul>',
   'No record from per_all_people_f with OVN is null',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  add_signature(
   'OVN_DETAILS_PAAF',
   'select person_id,
           effective_start_date,
           effective_end_date
    from   per_all_assignments_f
    where  person_id = ##$$PERID$$##
    and    object_version_number is null',
   'Object Version Number (OVN) is null - PER_ALL_ASSIGNMENTS_F',
   'RS',
   'Records from PER_ALL_ASSIGNMENTS_F where OVN is NULL for this employee',
   '',
   'No record from per_all_assignments_f with OVN is null',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  add_signature(
   'OVN_DETAILS_PPOS',
   'select person_id,
           period_of_service_id,
           date_start
    from   per_periods_of_service
    where  person_id = ##$$PERID$$##
    and    object_version_number is null',
   'Object Version Number (OVN) is null - PER_PERIODS_OF_SERVICE',
   'RS',
   'There exists per_periods_of_service records with OVN is null',
   '',
   'No record from per_periods_of_service with OVN is null',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  add_signature(
   'OVN_DETAILS_PEEF',
   'select peef.assignment_id, 
             peef.element_entry_id, 
             peef.element_link_id, 
             peef.element_type_id, 
             peef.effective_start_date, 
             peef.effective_end_date 
      from pay_element_entries_f peef
      where peef.object_version_number is null 
      and peef.assignment_id in 
           (select paaf.assignment_id
            from per_all_assignments_f paaf 
            where paaf.person_id = ##$$PERID$$##)
      order by peef.assignment_id, peef.effective_start_date',
   'Object Version Number (OVN) is null - PAY_ELEMENT_ENTRIES_F',
   'RS',
   'There exists pay_element_entries_f records with OVN is null',
   '',
   'No record from pay_element_entries_f with OVN is null',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info); 
   
  add_signature(
   'OVN_DETAILS_PELF',
   'select pelf.element_link_id, 
             pelf.effective_start_date,  
             pelf.effective_end_date
      from pay_element_links_f pelf
      where pelf.object_version_number is null 
      and pelf.element_link_id in 
           (select peef.element_link_id
            from pay_element_entries_f peef
            where peef.assignment_id in 
              (select paaf.assignment_id
               from per_all_assignments_f paaf 
               where paaf.person_id = ##$$PERID$$##)) 
      order by pelf.element_link_id, pelf.effective_start_date',
   'Object Version Number (OVN) is null - PAY_ELEMENT_LINKS_F',
   'RS',
   'There exists pay_element_links_f records with OVN is null',
   '',
   'No record from pay_element_links_f with OVN is null',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  add_signature(
   'OVN_DETAILS_PPP',
   'select ppp.assignment_id, 
             ppp.pay_proposal_id,
             ppp.creation_date
      from per_pay_proposals ppp 
      where ppp.object_version_number is null 
      and ppp.assignment_id in 
           (select paaf.assignment_id
            from per_all_assignments_f paaf 
            where paaf.person_id = ##$$PERID$$##) 
      order by ppp.assignment_id, ppp.pay_proposal_id, ppp.creation_date',
   'Object Version Number (OVN) is null - PER_PAY_PROPOSALS',
   'RS',
   'There exists per_pay_proposals records with OVN is null',
   '',
   'No record from per_pay_proposals with OVN is null',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Person Payroll Details
  -- PSD #12b
  add_signature(
   'PER_PAYROLL_DETAILS',
   'select                                                             
         paf.effective_start_date
       , paf.effective_end_date
       , paf.assignment_id
       , paf.organization_id
       , papf.business_group_id
       , papf.payroll_name
       , ppb.name "Pay Basis Name"
       , hr_key.concatenated_segments
    from per_assignments_f            paf
       , per_assignment_status_types  past
       , per_pay_bases                ppb
       , hr_soft_coding_keyflex       hr_key
       , pay_all_payrolls_f           papf
    where paf.person_id = ##$$PERID$$## 
    and  past.assignment_status_type_id = paf.assignment_status_type_id
    and  paf.payroll_id = papf.payroll_id
    and  paf.pay_basis_id = ppb.pay_basis_id
    and  paf.soft_coding_keyflex_id = hr_key.soft_coding_keyflex_id
    order by 1',
   'Person Payroll Details information',
   'RS',
   'This section lists the Payroll details for each Effective Date Range',
   '',
   'No Person Payroll Details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  -- signature for Payroll Element Entries
  -- PSD #12b
  add_signature(
   'PAYROLL_ELEMENT_ENTRIES',
   'SELECT  pef.effective_start_date
          , pef.effective_end_date
          , pef.assignment_id
          , pef.element_entry_id
          , pef.element_link_id
          , pet.element_name
          , pet.element_type_id
          , HR_GENERAL.DECODE_LOOKUP(''ENTRY_TYPE'', pef.Entry_type) entry_type    
          , HR_GENERAL.DECODE_LOOKUP(''CREATOR_TYPE'', pef.creator_type) creator_type 
    from pay_element_entries_f      pef
          --, pay_element_entry_values_f pev
          , pay_element_links_f        pel
          , pay_element_types_f        pet 
    WHERE pef.assignment_id IN (SELECT assignment_id FROM per_all_assignments_f WHERE person_id = ##$$PERID$$##) 
    AND pef.element_link_id = pel.element_link_id 
    AND pel.element_type_id = pet.element_type_id  
    AND pef.effective_start_date >= pet.effective_start_date
    AND pef.effective_end_date <= pet.effective_end_date	  
    ORDER BY 1,2,3,4,5',
   'Payroll Element Entries',
   'RS',
   'This section lists the Payroll Element Entries for each Effective Date Range.
    There may appear to be duplicate rows, since a record is shown for each element 
      with a non null value even though the values are not displayed.',
   '',
   'No Payroll Element Entries exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for NI Element Entry details
  -- PSD #12b
  add_signature(
   'NI_ELEMENT_ENTRIES',
   'SELECT paaf.assignment_id,
          peef.element_entry_id,
          peef.effective_start_date,
          peef.effective_end_date,
          peef.entry_type,
          max(decode(piv.name,''Category'',peev1.screen_entry_value)) NI_Cat, 
          max(decode(piv.name,''Pension'',peev1.screen_entry_value)) Pension, 
          max(decode(piv.name,''Certificate'',peev1.screen_entry_value)) Cert, 
          max(decode(piv.name,''Process Type'',peev1.screen_entry_value)) Process_Type, 
          max(decode(piv.name,''Periods'',peev1.screen_entry_value)) Periods, 
          max(decode(piv.name,''Date of Renewal'',peev1.screen_entry_value)) Date_of_Renewal, 
          max(decode(piv.name,''Priority Period Type'',peev1.screen_entry_value)) Priority_Period_Type, 
          max(decode(piv.name,''SCON'',peev1.screen_entry_value)) SCON
      FROM pay_element_entry_values_f peev1,
           pay_element_entries_f peef,
           pay_input_values_f piv,
           pay_element_types_f pet,
           per_all_assignments_f paaf,
           per_all_people_f papf
      WHERE pet.element_name = ''NI''
      and  pet.effective_end_date = to_date(''31-12-4712'', ''DD-MM-YYYY'')
      and  pet.element_type_id = piv.element_type_id
      and  pet.effective_start_date between piv.effective_start_date and piv.effective_end_date
      and  pet.element_type_id = peef.element_type_id
      and  peef.element_entry_id = peev1.element_entry_id
      and  peef.effective_start_date between peev1.effective_start_date and peev1.effective_end_date
      and  piv.input_value_id = peev1.input_value_id
      and  peef.assignment_id = paaf.assignment_id
      and  peef.effective_start_date between paaf.effective_start_date and paaf.effective_end_date
      and  paaf.person_id = papf.person_id
      and  paaf.effective_start_date between papf.effective_start_date and papf.effective_end_date
      and  papf.person_id = ##$$PERID$$## 
      group by 
           paaf.assignment_id,
           peef.element_entry_id,
           peef.effective_start_date,
           peef.effective_end_date,
           peef.entry_type
      order by paaf.assignment_id,
           peef.element_entry_id,
           peef.effective_start_date,
           peef.effective_end_date,
           peef.entry_type',
   'NI Element Entries Details',
   'RS',
   'There exist NI Element Entries details',
   '',
   'No NI Element Entries exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

   -- End of Person details
   -- Legislations specific details
   -- India
   
   -- signature for NI Element Entry details
  -- PSD #12b
  add_signature(
   'IN_STATU_INFO',
   'select rpad(paaf.person_id,9,'' '') "Person ID"
         , rpad(paaf.assignment_id,13,'' '') "Assignment ID"
		 , rpad(hsck.concatenated_segments,30,'' '')  "Concatenated Segments         "
		 , rpad(nvl(hsck.segment1,''-''),13,'' '') "GRE (Tax Org)"
		 , rpad(nvl(hsck.segment2,''-''),8,'' '') "PF Org  "
		 , rpad(nvl(hsck.segment3,''-''),12,'' '') "Prof Tax Org"
		 , rpad(nvl(hsck.segment4,''-''),7,'' '') "ESI Org"
		 , rpad(nvl(hsck.segment5,''-''),7,'' '') "Factory"
		 , rpad(nvl(hsck.segment6,''-''),13,'' '') "Establishment"
		 , rpad(nvl(hsck.segment8,''-''),12,'' '')  "Gratuity Act"
		 , rpad(nvl(hsck.segment9,''-''),20,'' '') "Substantial Interest"
		 , rpad(nvl(hsck.segment10,''-''),8,'' '') "Director"
		 , rpad(nvl(hsck.segment11,''-''),13,'' '') "Specified Emp"
		 , rpad(nvl(hsck.segment12,''-''),31,'' '') "PF/EPS Contri"
	from   hr_soft_coding_keyflex  hsck,                                   
		   per_all_assignments_f paaf                                      
	where  hsck.soft_coding_keyflex_id = paaf.soft_coding_keyflex_id       
	   and paaf.person_id = ##$$PERID$$##',
   'India Legislation Statutory Information',
   'RS',
   'Satutory Information for the Employee',
   '',
   'No Statutory information created for this person',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');
      
   
  -- signature for Payroll Details - Common to all Persons
  -- PSD #12b
  add_signature(
   'PAYROLL_DETAILS',
   'select payroll_id
         , payroll_name
         , effective_start_date
         , effective_end_date
         , business_group_id
         , object_version_number
    from pay_all_payrolls_f
    order by payroll_id,effective_start_date',
   'Payroll Details',
   'RS',
   'This section lists the Payroll details for each Effective Date range for PAYROLL_ID',
   '',
   'No Payroll details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

-- signature for Status of OVN Triggers - Common to all Persons
  -- PSD #12b
  add_signature(
   'STATUS_OF_OVN_TRIGGERS',
   'select table_name,
           trigger_name, 
           status 
    from all_triggers 
    where upper(table_name) in
       (''PER_ALL_PEOPLE_F'',
        ''PER_ALL_ASSIGNMENTS_F'',
        ''PER_PERIODS_OF_SERVICE'',
        ''PAY_ELEMENT_ENTRIES_F'',
        ''PAY_ELEMENT_LINKS_F'',
        ''PAY_ELEMENT_TYPES_F'',
        ''PER_PAY_PROPOSALS'')
    and upper(trigger_name) like upper(''%OVN%'')
    order by table_name, trigger_name',
   'Status of OVN Triggers Details',
   'RS',
   'There exist Status of ''OVN'' Triggers details',
   '',
   'No Status of ''OVN'' Triggers exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);


  -- signature for Status of OVN Triggers - Common to all Persons
  -- PSD #12b
  add_signature(
   'STATUS_OF_OVN_TRIGGERS_HR_PER',
   'select owner, 
           table_name,
           trigger_name, 
           status 
    from all_triggers 
    where owner = ''APPS''
    and trigger_name like ''HR%OVN%'' or trigger_name like ''PER%OVN%''
    order by owner, table_name',
   'OVN Triggers Status - HR and PER tables',
   'RS',
   'There exist Status of ''OVN'' Triggers information',
   '',
   'No Status of ''OVN'' Triggers information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);


  -- signature for Installed languages (NLS) - Common to all Persons
  -- PSD #12b
  add_signature(
   'LANGUAGES_INSTALLED_DETAILS',
   'SELECT language_code ,  
           decode(INSTALLED_FLAG ,''B'',''Base Installed Language'',''I'',''Additional Installed Language'',''D'',''Not Installed''),
           nls_language, 
           nls_territory
      FROM FND_LANGUAGES 
      where INSTALLED_FLAG in (''B'',''I'')
      order by LANGUAGE_CODE',
   'Languages Installed Details',
   'RS',
   'This section lists Languages Installed',
   '',
   'No Installed Languages details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
  
  -- signature for Person Types - Common to all Persons
  -- PSD #12b
  add_signature(
   'PERSON_TYPES',
   'select                                                                  
          business_group_id
        , person_type_id
        , active_flag
        , default_flag
        , system_person_type || ''--'' || user_person_type pt
     from per_person_types                                                   
     union all
     select distinct null,null,null,null, SYSTEM_PERSON_TYPE||''--''||USER_PERSON_TYPE
     from per_person_types
     order by 1 desc,5',
   'Person Types Details',
   'RS',
   'This section display Customer defined Person Types (via Business Group id) and system seeded Person Types (no Business Group id)',
   '',
   'No Person Types details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   
   
  -- signature for Assignment status Types - Common to all Persons
  -- PSD #12b
  add_signature(
   'ASSIGNMENT_STATUS_TYPES',
   'select assignment_status_type_id,
           business_group_id,
           active_flag,
           default_flag,
           primary_flag,
           user_status,
           per_system_status
    from per_assignment_status_types
    order by assignment_status_type_id',
   'Assignment Status Types Details',
   'RS',
   'There exist Assignment Status Types details',
   '',
   'No Assignment Status Types details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
   -- signature for Status of 'WHO' Triggers of HR tables - Common to all Persons
  -- PSD #12b
  add_signature(
   'WHO_TRIGGERS_HR',
   'select owner, 
           table_name,
           trigger_name, 
           status 
    from all_triggers 
    where UPPER(table_name) in 
       ( ''PER_ALL_PEOPLE_F''
       , ''PER_ALL_ASSIGNMENTS_F''
       , ''PER_PERIODS_OF_SERVICE''
       , ''PER_PERSON_TYPE_USAGES_F''
       , ''PER_ADDRESSES''
       , ''HR_LOCATIONS_ALL''
       , ''HR_LOCATIONS_ALL_TL''
       , ''HR_ALL_ORGANIZATION_UNITS''
       , ''HR_ALL_ORGANIZATION_UNITS_TL''
       , ''HR_ALL_POSITIONS_F''
       , ''HR_ALL_POSITIONS_F_TL''
       , ''PER_ALL_POSITIONS''
       , ''PER_JOBS''
       , ''PER_JOBS_TL'')
    and trigger_name like ''%WHO%'' 
    order by table_name, trigger_name',
   'WHO Triggers Status - HR Tables',
   'RS',
   'Status of ''WHO'' Triggers of HR tables details',
   '',
   'No ''WHO'' Triggers of HR tables details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
                 
  -------------------------------------------
  -- Example signatures
  -- PSD #11b
  -------------------------------------------

  l_info.delete;
  l_info('Doc ID') := '390023.1'; -- example using l_info
  l_info('Bug Number') := '9707155'; -- example using l_info
  add_signature(
   'Note390023.1_case_GEN4',
   'SELECT ''PO/PA'' "Doc Type",
           h.segment1 "Doc Number",
           h.po_header_id "Doc ID",
           h.org_id,
           null "Release Num",
           null "PO Release ID",
           h.type_lookup_code "Type Code",
           h.authorization_status "Athorization Status",
           nvl(h.cancel_flag,''N'') canceled,
           nvl(h.closed_code,''OPEN'') "Closed Code",
           h.change_requested_by "Change Requested By",
           h.revision_num,
           h.wf_item_type, h.wf_item_type "##$$FK1$$##",
           h.wf_item_key, h.wf_item_key "##$$FK2$$##",
           h.approved_date "Approved Date"
    FROM po_headers_all h
    WHERE to_date(''##$$FDATE$$##'') <= (
            SELECT max(ah.action_date) FROM po_action_history ah
            WHERE ah.object_id = h.po_header_id
            AND   ah.object_type_code IN (''PO'',''PA'')
            AND   ah.action_code = ''SUBMIT''
            AND   ah.object_sub_type_code = h.type_lookup_code)
    AND   h.org_id = ##$$PERID$$##
    AND   h.authorization_status IN (''IN PROCESS'', ''PRE-APPROVED'')
    AND   nvl(h.cancel_flag,''N'') <> ''Y''
    AND   nvl(h.closed_code,''OPEN'') <> ''FINALLY CLOSED''
    AND   nvl(h.change_requested_by,''NONE'') NOT IN (''REQUESTER'',''SUPPLIER'')
    AND   (nvl(h.ENCUMBRANCE_REQUIRED_FLAG, ''N'') <> ''Y'' OR
           h.type_lookup_code <> ''BLANKET'')
    AND   NOT EXISTS (
            SELECT null
            FROM wf_item_activity_statuses ias,
                 wf_notifications n
            WHERE ias.notification_id is not null
            AND   ias.notification_id = n.group_id
            AND   n.status = ''OPEN''
            AND   ias.item_type = ''POAPPRV''
            AND   ias.item_key IN (
                    SELECT i.item_key FROM wf_items i
                    START WITH i.item_type = ''POAPPRV''
                    AND        i.item_key = h.wf_item_key
                    CONNECT BY PRIOR i.item_type = i.parent_item_type
                    AND        PRIOR i.item_key = i.parent_item_key
                    AND     nvl(i.end_date,sysdate+1) >= sysdate))
    ORDER BY 1,2',
   'Recent Documents - Candidates for Reset',
   'RS',
   'Recent documents exist which are candidates for reset.  The documents
    listed are all IN PROCESS or PRE-APPROVED approval status
    and do not have an open workflow notification.',
   '<ul><li>Review the results in the Workflow Activity section
         for the documents.</li>
      <li>If multiple documents are stuck with errors in the same
         workflow activity then try the Mass Retry in [458216.1].</li>
      <li>For all other document see [390023.1] for details on
         how to reset these documents if needed.</li>
      <li>To obtain a summary count for all such documents in your 
         system by document type, refer to [1584264.1]</li></ul>',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('Note390023.1_case_GEN4_CHILD1',
     'Note390023.1_case_GEN4_CHILD2'));

    l_info.delete;
    add_signature(
     'Note390023.1_case_GEN4_CHILD1',
     'SELECT DISTINCT
             ac.name Activity,
             ias.activity_result_code Result,
             ias.error_name ERROR_NAME,
             ias.error_message ERROR_MESSAGE,
             ias.error_stack ERROR_STACK
      FROM wf_item_activity_statuses ias,
           wf_process_activities pa,
           wf_activities ac,
           wf_activities ap,
           wf_items i
      WHERE ias.item_type = ''##$$FK1$$##''
      AND   ias.item_key  = ''##$$FK2$$##''
      AND   ias.activity_status     = ''ERROR''
      AND   ias.process_activity    = pa.instance_id
      AND   pa.activity_name        = ac.name
      AND   pa.activity_item_type   = ac.item_type
      AND   i.item_type             = ias.item_type
      AND   i.item_key              = ias.item_key
      AND   i.begin_date            >= ac.begin_date
      AND   i.begin_date            < nvl(ac.end_date, i.begin_date+1)
      AND   (ias.error_name is not null OR
             ias.error_message is not null OR
             ias.error_stack is not null)
      ORDER BY 1,2',
     'WF Activity Errors for This Document',
     'RS',
     'No errored WF activities found for the document',
     null,
     null,
     'ALWAYS',
     'I',
     'RS');
	 
    -------------------------------------------
    -- End of example signatures
    -------------------------------------------	 
    -- PSD #11b-end

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;





---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #12
PROCEDURE main (
      p_person_id       IN NUMBER   DEFAULT null,
      p_from_date       IN DATE     DEFAULT sysdate - 90,
      p_max_output_rows IN NUMBER   DEFAULT 50,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
 
-- PSD #13
-- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'Person';

  l_step := '20';
  validate_parameters(
      p_person_id,
      p_from_date,
      p_max_output_rows,
      p_debug_mode);

  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #14
  start_section('Proactive Recommendations');
     set_item_result(check_rec_patches);
     set_item_result(run_stored_sig('INVALIDS'));
     set_item_result(run_stored_sig('PERSONS_CWK_ISSUE1'));
     set_item_result(run_stored_sig('PERSONS_PEE_ISSUE2'));	 
  end_section;
  start_section('Instance Overview');
     set_item_result(run_stored_sig('OVERVIEW'));
     set_item_result(run_stored_sig('PRODUCTS_INSTALL'));
     set_item_result(run_stored_sig('INSTALLED_LEGISLATIONS'));
     set_item_result(run_stored_sig('BUSINESS_GROUPS'));
	 set_item_result(run_stored_sig('SHARED_HR'));
  end_section;
  
  start_section('Person Queried');
     --print_rep_subsection('Person Details');
        set_item_result(run_stored_sig('PERSON_DETAILS'));
		set_item_result(run_stored_sig('PERSON_ISSUE1'));
		set_item_result(run_stored_sig('PERSON_ISSUE2'));
		set_item_result(run_stored_sig('PERSON_ISSUE3'));
        set_item_result(run_stored_sig('FND_USER_DETAILS'));
        set_item_result(run_stored_sig('FND_USER_RESP_DETAILS'));
        set_item_result(run_stored_sig('CONTACT_DETAILS'));
        set_item_result(run_stored_sig('PAYE_NI_DETAILS'));
        set_item_result(run_stored_sig('ASSIGNMENT_DETAILS'));
		set_item_result(run_stored_sig('ASSIGNMENT_ISSUE1'));
		set_item_result(run_stored_sig('ASSIGNMENT_ISSUE2'));
		set_item_result(run_stored_sig('ASSIGNMENT_ISSUE3'));
        set_item_result(run_stored_sig('PAYROLL_PAYE_DETAILS'));
        set_item_result(run_stored_sig('ASG_ACT_DETAILS'));
        set_item_result(run_stored_sig('GRADE_DETAILS'));
        set_item_result(run_stored_sig('ABSENCE_DETAILS'));
        set_item_result(run_stored_sig('EVENT_DETAILS'));
        set_item_result(run_stored_sig('APPL_DETAILS'));
        set_item_result(run_stored_sig('PPL_REPORT_DETAILS'));
        set_item_result(run_stored_sig('PERSON_REPORT_DETAILS'));
        set_item_result(run_stored_sig('PER_SEC_PROF_DETAILS'));
        set_item_result(run_stored_sig('EMP_SUPL_DETAILS'));
        set_item_result(run_stored_sig('LOC_DETAILS'));
        set_item_result(run_stored_sig('PERIOD_SER_DETAILS'));
        set_item_result(run_stored_sig('PERIOD_PLACEMENTS_DETAILS'));
        set_item_result(run_stored_sig('PER_TYPE_USAGE_DETAILS'));
        set_item_result(run_stored_sig('PER_ADDRESS_DETAILS'));
        set_item_result(run_stored_sig('ADDRESS_STYLE_DETAILS'));
        set_item_result(run_stored_sig('PERSON_ANALYSIS_DETAILS'));
        set_item_result(run_stored_sig('BENEFITS_PAYROLL_DETAILS'));
        set_item_result(run_stored_sig('WF_LOCAL_ROLES_DETAILS'));
        set_item_result(run_stored_sig('WF_USER_ROLES_DETAILS'));
        set_item_result(run_stored_sig('WF_LOCAL_USER_ROLES_DETAILS'));
        set_item_result(run_stored_sig('WF_USER_ROLE_ASG_DETAILS'));
        set_item_result(run_stored_sig('HZ_PARTIES'));
        set_item_result(run_stored_sig('HZ_PERSON_PROFILES'));
        set_item_result(run_stored_sig('SAL_ADMIN_ANALYSIS'));
        set_item_result(run_stored_sig('SAL_ADMIN_ANALYSIS_1'));
        set_item_result(run_stored_sig('SAL_ADMIN_ANALYSIS_2'));
        set_item_result(run_stored_sig('SAL_ADMIN_ANALYSIS_3'));
        set_item_result(run_stored_sig('OVN_DETAILS_PAPF'));
        set_item_result(run_stored_sig('OVN_DETAILS_PAAF'));
        set_item_result(run_stored_sig('OVN_DETAILS_PPOS'));
        set_item_result(run_stored_sig('OVN_DETAILS_PEEF'));
        set_item_result(run_stored_sig('OVN_DETAILS_PELF'));
        set_item_result(run_stored_sig('OVN_DETAILS_PPP'));
        set_item_result(run_stored_sig('PER_PAYROLL_DETAILS'));
        set_item_result(run_stored_sig('PAYROLL_ELEMENT_ENTRIES'));
        set_item_result(run_stored_sig('NI_ELEMENT_ENTRIES'));
     --print_rep_subsection_end;
	 -- Legislation specific information.
	 -- India 
	    set_item_result(run_stored_sig('IN_STATU_INFO'));
	 -- End of India	 
  end_section;
  start_section('Common Information');
     set_item_result(run_stored_sig('PAYROLL_DETAILS'));
     set_item_result(run_stored_sig('STATUS_OF_OVN_TRIGGERS'));
     set_item_result(run_stored_sig('STATUS_OF_OVN_TRIGGERS_HR_PER'));
     set_item_result(run_stored_sig('LANGUAGES_INSTALLED_DETAILS'));
     set_item_result(run_stored_sig('PERSON_TYPES'));
     set_item_result(run_stored_sig('ASSIGNMENT_STATUS_TYPES'));
     set_item_result(run_stored_sig('WHO_TRIGGERS_HR'));     
  end_section;
  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #15
  print_out('<a href="https://community.oracle.com/thread/3577897" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

---------------------------------
-- MAIN ENTRY POINT FOR CONC PROC
-- only needed if passing parameters
---------------------------------
-- PSD #18
/*PROCEDURE main_cp(
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_org_id          IN NUMBER   DEFAULT null,
      p_trx_type        IN VARCHAR2 DEFAULT 'PO',
      p_po_num          IN VARCHAR2 DEFAULT null,
      p_req_num         IN VARCHAR2 DEFAULT null,
      p_release_num     IN NUMBER   DEFAULT null,
      p_from_date       IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 20,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

l_trx_num VARCHAR2(25);

BEGIN
  g_retcode := 0;
  g_errbuf := null;
  l_trx_num := nvl(p_po_num, p_req_num);
-- PSD #19  
  main(
      p_org_id => p_org_id,
      p_trx_type => p_trx_type,
      p_trx_num => l_trx_num,
      p_release_num => p_release_num,
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode);

  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;*/


BEGIN

  IF l_person_id is not null THEN
    
    IF l_max_rows < 0 THEN
      l_max_rows := 50;
    END IF;
  
    IF l_from_date is null or l_from_date = TO_DATE ('31-DEC-9999')
    THEN
      l_from_date := (sysdate-90);
    END IF;
  
  -- PSD #16
     main(
        p_person_id => l_person_id,      
        p_from_date => l_from_date,
        p_max_output_rows => l_max_rows,
        p_debug_mode => 'Y');
      
  END IF;  
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit
;
