REM HEADER
REM   $Id: demantra_performance_analyzer.sql v200.00 JJG $
REM   
REM MODIFICATION LOG:
REM	
REM	
REM	Consolidated script to diagnose the current status and footprint of Performance on an environment.
REM     This script can be run on 6.1 or higher.
REM
REM   demantra_performance_analyzer.sql
REM     
REM   	This script was created to collect all the required information to understand what performance impact 
REM   	embedded in Oracle Applications has on an Demantra instance.
REM
REM
REM   How to run it? Follow the directions found in the Master Note XXXX1369938.1
REM   
REM   	sqlplus apps/<password>	@demantra_performance_analyzer.sql
REM   
REM   Output file format found in the same directory if run manually
REM
REM	demantra_performance_analyzer_<HOST_NAME>_<SID>_<DATE>.html
REM
REM Add 'is logging enabled'
REM
REM
REM *************************************************************************
REM
REM     Created: December 5th, 2013
REM     Last Updated: October 6th, 2014
REM
REM
REM  CHANGE HISTORY:
REM   1.00  5-Dec-2013 JJG Creation from design
REM   1.00  21-Aug-2013 - commented ACCEPT capability, replaced with && input for .ldt file creation
REM   2.00  25-Aug-2014 - Added additional performance graphs, adjusted tables, added new Demantra details
REM   2.00  6-Oct-2014 - Added, worksheets make use of parallelism
REM
REM
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Demantra Performance and Setup Analyzer
REM
REM MENU_START
REM
REM SQL: Run Demantra Performance and Setup Analyzer Analyzer
REM FNDLOAD: Load Demantra Performance and Setup Analyzer Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM 
REM 
REM HELP_START  
REM 
REM  V7.3.1: Demantra Performance and Setup Analyzer / Monitoring Tool Help [Doc ID: 1618885.1] 
REM
REM  Compatible: 11i 12.0 12.1 12.2 
REM
REM  Explanation of available options:
REM
REM    (1) Run V7.3.1: Demantra Performance and Setup Analyzer / Monitoring Tool
REM        o Runs demantra_performance_analyzer.sql as APPS
REM        o Creates an HTML report file under MENU/output
REM
REM    (2) Install V7.3.1: Demantra Performance and Setup Analyzer / Monitoring Tool as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "All MSC Reports"
REM
REM 
REM HELP_END 
REM
REM FNDLOAD_START 
REM
REM PROD_TOP: MSD_TOP
REM PROG_NAME: MSCDPA_SQL
REM APP_NAME: Demand Planning
REM DEF_REQ_GROUP: Demand Planning
REM PROG_TEMPLATE: MSCDPA_SQL_prog.ldt
REM PROD_SHORT_NAME: MSD 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END 


set arraysize 1
set heading off
set feedback off  
set echo off
set verify off
SET CONCAT ON
SET CONCAT .
SET ESCAPE OFF
SET ESCAPE '\'

set lines 120
set pages 9999
set serveroutput on size 100000

VARIABLE gv_schema     varchar2(30);
VARIABLE my_schema     varchar2(30);
VARIABLE TEST		VARCHAR2(240);
variable st_time 	varchar2(100);
variable et_time 	varchar2(100);
VARIABLE SID         	VARCHAR2(20);
VARIABLE HOST        	VARCHAR2(16);
VARIABLE INSTANCE_NAME 	VARCHAR2(16);
VARIABLE APPS_REL    	VARCHAR2(10);
VARIABLE SYSDATE        varchar2(12);
VARIABLE n		NUMBER;
VARIABLE cluster_db     VARCHAR2(10);
VARIABLE cluster_db_ins NUMBER;
VARIABLE DB_VER    	VARCHAR2(10);
VARIABLE v_ins          NUMBER;
VARIABLE v_cfc          NUMBER;
VARIABLE v_tot_time     NUMBER;
VARIABLE v_snap_time    NUMBER;
VARIABLE v_worker_time  NUMBER;
VARIABLE ecphy          NUMBER;
VARIABLE eclog          NUMBER;
VARIABLE ecphy1         NUMBER;
VARIABLE eclog1         NUMBER;
VARIABLE ecphy2         NUMBER;
VARIABLE eclog2         NUMBER;
VARIABLE ecphy3         NUMBER;
VARIABLE eclog3         NUMBER;
VARIABLE ecphy4         NUMBER;
VARIABLE eclog4         NUMBER;
VARIABLE ecphy5         NUMBER;
VARIABLE eclog5         NUMBER;
VARIABLE ecphy6         NUMBER;
VARIABLE eclog6         NUMBER;
VARIABLE numschemas	NUMBER;
VARIABLE chk		NUMBER;
VARIABLE ratio          NUMBER;
VARIABLE blk_size       NUMBER;
VARIABLE GB_Free        NUMBER;
VARIABLE Largest_GB     NUMBER;
VARIABLE GB_alloc       NUMBER;
VARIABLE GB_max         NUMBER;


Declare
  gv_schema		varchar2(30);
  my_schema		varchar2(30);
  test			varchar2(240);
  sid         		varchar2(20);
  host        		varchar2(16);
  instance_name 	varchar2(16);
  sysdate               varchar2(12);
  apps_rel    		varchar2(10);
  n 			number;
  cluster_db            varchar2(10);
  cluster_db_ins        number;
  db_ver		varchar2(10); 
  ecphy                 number;
  eclog                 number;
  ecphy1                number;
  eclog1                number;
  ecphy2                number;
  eclog2                number;
  ecphy3                number;
  eclog3                number;
  ecphy4                number;
  eclog4                number;
  ecphy5                number;
  eclog5                number;
  ecphy6                number;
  eclog6                number;
  numschemas		number;
  chk			number;
  blk_size              number;
  ratio                 number;
  GB_Free               NUMBER;
  Largest_GB            NUMBER;
  GB_alloc              NUMBER;
  GB_max                NUMBER;
  
begin
select to_char(sysdate,'hh24:mi:ss') into :st_time from dual;

select to_char(sysdate, 'YYYY-Mon-DD') into :sysdate from dual;

end;
/


REM REM COLUMN host_name NOPRINT NEW_VALUE hostname
REM SELECT substr(host_name,1,15) into :host from v$instance;
REM REM COLUMN instance_name NOPRINT NEW_VALUE instancename
REM SELECT instance_name into :instance_name from v$instance;
REM REM COLUMN sysdate NOPRINT NEW_VALUE when
REM select to_char(sysdate, 'YYYY-Mon-DD') "sysdate" from dual;

REM Comment the following 1 line if submitting via concurrent request
REM SPOOL demantra_performance_analyzer.html

alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';

prompt <HTML>
prompt <HEAD>
prompt <TITLE>Demantra Performance Analyzer</TITLE>
prompt <STYLE TYPE="text/css">
prompt <!-- TD {font-size: 10pt; font-family: calibri; font-style: normal} -->
prompt </STYLE>
prompt </HEAD>
prompt <BODY>

prompt <TABLE border="1" cellspacing="0" cellpadding="10">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD bordercolor="#DEE6EF"><font face="Calibri">
prompt <B><font size="+2">Demantra Performance Analyzer for 
select UPPER(instance_name) from v$instance;
prompt <B><font size="+2"> on 
select UPPER(substr(host_name,1,16)) from v$instance;
prompt </font></B></TD></TR>
prompt </TABLE><BR>

prompt <a href="https://support.oracle.com/rs?type=doc\&id=432.1" target="_blank">
prompt <img src="https://blogs.oracle.com/ebs/resource/Proactive/banner4.jpg" title="Click here to see other helpful Oracle Proactive Tools" width="758" height="81" border="0" alt="Proactive Services Banner" /></a></a>
prompt <br>

prompt <font size="+1"><i><b>Demantra Performance Analyzer v2.00 compiled on : 
select to_char(sysdate, 'Dy Month DD, YYYY') from dual;
prompt at 
select to_char(sysdate, ' hh24:mi:ss') from dual;
prompt </b></i></font><BR><BR>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt This Demantra Performance Analyzer script reviews the current environment footprint, analyzes runtime tables, profiles, settings, <br>
prompt and configurations for the overall environment.  Providing helpful feedback and recommendations on best practicesany for your chosen Demantra instance.
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt <font size="+1">This analyzer can be submittied:<br>
prompt 1. Directly after the processing of your Demantra process<br>
prompt 2. Directly after the Demantra process completes, AFTER you gather NEW statistics<br>
prompt 3. Directly before the Demantra process is submitted<br>
prompt 4. Directly before the Demantra process is submitted, AFTER you gather statistics<BR><BR>
prompt We are recommending that the statistics are kept up to date since the results of this analyzer are dependant upon instance health.<BR><BR>
prompt </font></td></tr></tbody> 
prompt </table><BR><BR>

prompt <BR>

prompt       <p><a name="top"><b><font size="+2">Table of Contents</font></b></a> </p>
prompt <blockquote>
prompt       <p><a href="#section1"><b><font size="+1">Demantra Performance Analyzer Overview</font></b></a> 
prompt         <br>
prompt       <blockquote> 
prompt         <a href="#adv110"> - Demantra Schema Selection</a><br>
prompt         <a href="#adv111"> - Demantra Related Profiles</a><br>
prompt         <a href="#adv112"> - E-Business Suite Version</a><br>
prompt         <a href="#adv113"> - Database Parameter Settings</a><br>
prompt         <a href="#adv114"> - APS_PARAMS</a></br>
prompt         <a href="#adv115"> - Verify Sys_params - AppServerURL, AppServerLocation </a></br>
prompt         <a href="#adv116"> - Verify 4 Parameters Which Related to the Manual Update Process</a></br>
prompt         <a href="#adv117"> - Review Parameter maxdbconnections</a></br>
prompt         <a href="#adv118"> - Do you have LOG_IT set to active?</a></br>
prompt         <a href="#adv119"> - DB Exception Log</a></br>
prompt         <a href="#adv120"> - Integ_status </a></br>
prompt         <a href="#adv121"> - LOG_DATA_MODEL Last 50 Entries</a></br>
prompt         <a href="#adv122"> - WF_PROCESS_LOG</a></br>
prompt         <a href="#adv123"> - Are There any Locks </a></br>
prompt         <a href="#adv124"> - ACTIVE COMBINATIONS by LEVEL</a></br>
prompt         <a href="#adv125"> - Clearing Forecast Values</a><br>
prompt         <a href="#adv126"> - Distributed Engine Processing Load Key Parameter Check from SYS_PARAMS</a></br>
prompt         <a href="#adv127"> - Engine Profile init_params_0</a></br>
prompt         <a href="#adv128"> - Engine Profile init_params_1</a></br>
prompt         <a href="#adv129"> - Business Logic Engine APS_PARAMS Parameter Check</a></br>
prompt         <a href="#adv130"> - Verify engineplatform</a></br>
prompt         <a href="#adv131"> - Verify enginebaseURL</a></br>
prompt         <a href="#adv132"> - Is the Engine Running?  Where?</a><br>
prompt         <a href="#adv133"> - Parameter MaxEngMemory</a><br>
prompt         <a href="#adv134"> - Distributed Engine</a></br>
prompt         <a href="#adv135"> - Determine if the Engine Failed</a></br>
prompt         <a href="#adv136"> - Check Worksheet Related Parameters in APS_PARAMS, parallelism and more</a></br> 
prompt         <a href="#adv137"> - Missing Dates in Sales_Data</a></br> 
prompt         <a href="#adv138"> - Verify Tablespace Parameters</a></br> 
prompt         <a href="#adv139"> - Combinations that meet the rule for Insert_Units</a></br> 
prompt         <a href="#adv140"> - System Statistics</a></br> 
prompt         <a href="#adv141"> - Wait Statistics</a></br> 
prompt         <a href="#adv142"> - DB_PARAMS EP_Load Check</a></br> 
prompt         <a href="#adv143"> - Buffer Cache Hit Ratio Percent</a></br>
prompt         <a href="#adv144"> - Dictionary Cache Hit Ratio</a></br>
prompt         <a href="#adv145"> - Sorts in Memory</a></br>
prompt         <a href="#adv146"> - The percentage of FREE shared pool</a></br>
prompt         <a href="#adv147"> - Shared Pool Reloads</a></br>
prompt         <a href="#adv148"> - Freelist Performance Impact</a></br>
prompt         <a href="#adv149"> - Library Reload Ratio Percent</a></br>
prompt         <a href="#adv150"> - Library Cache Constraint Activity and Shared Pool</a></br>
prompt         <a href="#adv151"> - Datafile Activity Constraints</a></br>
prompt         <a href="#adv152"> - IO Disbursement Across Datafiles for Tablespace</a></br>
prompt         <a href="#adv153"> - System Events</a></br>
prompt         <a href="#adv154"> - Network Wait Events</a></br>
prompt         <a href="#adv155"> - Network Wait Class Summary</a></br>
prompt         <a href="#adv156"> - Database Object Fragmentation</a></br>
prompt         <a href="#adv157"> - Segments Where Free Space <= Next Extent</a></br>
prompt         <a href="#adv158"> - Cluster Factor > 50% Rows vs Blocks and Related Storage Facts</a></br>
prompt         <a href="#adv159"> - Free Space by Tablespace</a></br>
prompt         <a href="#adv160"> - Wait Statistics</a></br>
prompt         <a href="#adv161"> - System Statistics</a></br>
prompt         <a href="#adv162"> - Large Table Health Check</a></br>
prompt         <a href="#adv163"> - MaxDBConnections</a></br>
prompt         <a href="#adv164"> - Degree of Parallelism</a></br>
prompt         <a href="#adv165"> - Chained Row count</a></br>
prompt         <a href="#adv166"> - Future Features</a>
prompt       </blockquote>
prompt         <a href="#section2"><b><font size="+1">References</font></b></a><br><br> 
prompt         <a href="#section3"><b><font size="+1">Feedback</font></b></a> 
prompt </blockquote>

prompt <BR><BR>

REM **************************************************************************************** 
REM *******                   Section 1 : Demantra Analyzer Overview                 *******
REM ****************************************************************************************

prompt <a name="section1"></a><B><font size="+2">Demantra Performance - Setup Analyzer</font></B><BR><BR>
prompt <blockquote>

    
begin

select upper(instance_name) into :sid from v$instance;

select substr(host_name,1,16) into :host from fnd_product_groups, v$instance;

select release_name into :apps_rel from fnd_product_groups, v$instance;

select value into :blk_size from v$parameter where name= 'db_block_size';

select fnd_profile.value('MSD_DEM_SCHEMA') into :my_schema from dual;

:gv_schema := :my_schema;

end;
/


prompt <BR><b>Description:</b><BR> This section chooses the Schema for the Demantra Analyzer output based on the value of profile option: MSD: Schema. <br>
prompt If there are multiple schemas available, you can change the value of the Demantra profile MSD: Schema.<BR><br>
prompt This submission of the analyzer will use 
print :my_schema

REM **************************************************************************************** 
REM ******* Valid Schema Selection *******
REM **************************************************************************************** 
REM
prompt <script type="text/javascript">    function displayRows1sql1(){var row = document.getElementById("s1sql1");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <br><br><TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF">
prompt     <font face="Calibri"><a name="adv110"></a>
prompt      <a name="top"><b><font size="+2"> Current Demantra Schema Owners </font></B></a>
prompt     </font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql1()" >SQL Script</button></div>
prompt     </TD>
prompt </TR>
prompt <TR id="s1sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          select owner, table_name from all_tables where table_name like 'SALES_DATA';</p><br>
prompt       </blockquote>
prompt     </TD>
prompt </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Schema Owner</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD>
prompt </TR>
exec :n := dbms_utility.get_time;

select  
'<TR><TD>'||owner||'</TD>'||chr(10)|| 
'<TD>'||table_name||'</TD></TR>'
from all_tables
where table_name = 'SALES_DATA';
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM **************************************************************************************** 
REM ******* Demantra Schema Related Profiles *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql2(){var row = document.getElementById("s1sql2");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF">
prompt    <font face="Calibri"><a name="adv111"></a>
prompt     <a name="top"><b><font size="+2"> Demantra Schema Related Profiles </font></B></a></font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql2()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql2" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="2" height="45">
prompt       <blockquote><p align="left">
prompt          select fav.application_name, fpo1.user_profile_option_name profileName,<br>
prompt    substr(fpov.profile_option_value, 1, 52) pov,decode(fpov.level_id, 10001, 'Site', 10002, 'Appl', 10003, 'Resp', 10004, 'User', 'None') lvl,<br>
prompt      from   fnd_application_vl fav,,fnd_profile_options_vl fpo1,,fnd_profile_option_values fpov <br>
prompt      where  fav.application_id=fpo1.application_id and fpo1.profile_option_id=fpov.profile_option_id <br>
prompt      and fpov.application_id    in fpo1.application_id and    fpov.profile_option_id = c_poi<br>
prompt and    ((fpov.level_id = 10001 and fpov.level_value = 0) or    (fpov.level_id = 10002 and fpov.level_value = fpo1.application_id)<br>
prompt or    (fpov.level_id = 10003 and fpov.level_value_application_id = fpo1.application_id <br>
prompt and    fpov.level_value = (select fnd_profile.value('RESP_ID') from dual)) or (fpov.level_id = 10004 and fpov.level_value = (select fnd_profile.value('USER_ID') from dual)))<br>
prompt order  by fpov.level_id desc;</p>  
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ApplicationName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>UserProfileOptionName</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>ProfileOptionValue</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SetAt</B></TD></TR>
exec :n := dbms_utility.get_time;
select 
'<TR><TD>'||fav.application_name||'</TD>'||chr(10)|| 
'<TD>'||fpo1.user_profile_option_name||'</TD>'||chr(10)||
'<TD>'||fpov.profile_option_value||'</TD>'||chr(10)||
'<TD>'||decode(fpov.level_id, 10001, 'Site', 10002, 'Appl', 10003, 'Resp', 10004, 'User','None')||'</TD></TR>'
  from   fnd_application_vl fav
        ,fnd_profile_options_vl fpo1
        ,fnd_profile_option_values fpov
  where  fav.application_id = fpo1.application_id
  and fpo1.profile_option_id = fpov.profile_option_id
  and fpov.application_id = fpo1.application_id
  and fpov.profile_option_id in (select profile_option_id poi from fnd_profile_options_vl fpo
                                    where user_profile_option_name in ('MSD_DEM: Schema')
                                    and   start_date_active <= sysdate
                                    and    (nvl(end_date_active,sysdate) >= sysdate))
  and    ((level_id = 10001 and level_value = 0)
   or    (level_id = 10002 and level_value = fpov.application_id)
   or    (level_id = 10003 and level_value_application_id = fpov.application_id 
  and    level_value = (select fnd_profile.value('RESP_ID') from dual)) 
   or    (level_id = 10004 and level_value = (select fnd_profile.value('USER_ID') from dual)))
  order  by level_id desc;
  prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM **************************************************************************************** 
REM ******* Ebusiness Suite Version *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql3(){var row = document.getElementById("s1sql3");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF">
prompt     <font face="Calibri"><a name="adv112"></a>
prompt      <a name="top"><b><font size="+2"> E-Business Suite Version </font></B></a>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql3()" >SQL Script</button></div>
prompt     </TD>
prompt </TR>
prompt <TR id="s1sql3" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          select vi.instance_name, fpg.release_name, vi.host_name, vi.startup_time, vi.version <br>
prompt          from fnd_product_groups fpg, v$instance vi<br>
prompt          where upper(substr(fpg.APPLICATIONS_SYSTEM_NAME,1,4)) = upper(substr(vi.INSTANCE_NAME,1,4));</p>
prompt       </blockquote>
prompt     </TD>
prompt </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RELEASE</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>HOSTNAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>STARTED</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DATABASE</B></TD>
prompt </TR>
exec :n := dbms_utility.get_time;
select  
'<TR><TD>'||vi.instance_name||'</TD>'||chr(10)|| 
'<TD>'||fpg.release_name||'</TD>'||chr(10)|| 
'<TD>'||vi.host_name||'</TD>'||chr(10)|| 
'<TD>'||vi.startup_time||'</TD>'||chr(10)|| 
'<TD>'||vi.version||'</TD></TR>'
from fnd_product_groups fpg, v$instance vi
where upper(substr(fpg.APPLICATIONS_SYSTEM_NAME,1,4)) = upper(substr(vi.INSTANCE_NAME,1,4));
prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>




REM **************************************************************************************** 
REM ******* Database Parameter Settings *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql4(){var row = document.getElementById("s1sql4");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv113"></a>
prompt     <a name="top"><b><font size="+2"> RDBMS Check </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql4()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql4" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="45">
prompt       <blockquote><p align="left">
prompt          select * from v$parameter ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>

exec :n := dbms_utility.get_time;
prompt     <a name="adv113"></a>
Declare
Cursor cdp1 is select name, value
              from v$parameter
              where name in ('optimizer_index_caching','optimizer_index_cost_adj','optimizer_mode','cursor_sharing','db_file_multiblock_read_count','optimizer_capture_sql_plan_baselines'
,'optimizer_use_sql_plan_baselines','_b_tree_bitmap_plans')
order by name;
              
v_max_dump_file_size number;
v_ins   number;
v_cfc   number;

Begin
       dbms_output.put_line('<TABLE border="1" cellspacing="0" cellpadding="2">');
       dbms_output.put_line('<TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri">');
       dbms_output.put_line('<a name="wfadmins"></a><a name="top"><b><font size="+2"> Recommendations for Database Parameters </font></B></a></font></TD></TR>');
       dbms_output.put_line('<TR>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>NAME</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>VALUE</B></font></TD>');
       dbms_output.put_line('<TD BGCOLOR=#DEE6EF><font face="Calibri"><B>RECOMMENDATIONS</B></font></TD>');
       
For dp in cdp1
          LOOP

                
                dbms_output.put_line('<TR><TD>'||dp.name||'</TD>');                                                                                                     
		dbms_output.put_line('<TD>'||dp.value||'</TD>');   
                
                IF dp.name='_b_tree_bitmap_plans' THEN
                  IF dp.value='FALSE' THEN
                   dbms_output.put_line('<TD>'||'You have the recommended value of FALSE'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('The __b_tree_bitmap_plans parameter must be set to FALSE due to performance related issues.'||'</TD></TR>');
                  END IF;
                END IF;

                IF dp.name='cursor_sharing' THEN
                  IF dp.value='EXACT' THEN
                   dbms_output.put_line('<TD>'||'It is ecommended to use FORCE if VCP is not sharing the RDBMS.  This forces the reuse of SQL already in memory when possible.'||'</TD></TR>');
                  END IF;
                END IF;

                IF dp.name='db_file_multiblock_read_count' THEN
                  dbms_output.put_line('<TD>'||'Recommended between 25 and 50.  Reduces the cost to access indexes and should reduce the RDBMS response time.'||'</TD></TR>');
                END IF;

                IF dp.name='optimizer_capture_sql_plan_baselines' THEN
                  IF dp.value='FALSE' THEN
                   dbms_output.put_line('<TD>'||'FALSE is the correct value.'||'</TD></TR>');
                  ELSE
                   dbms_output.put_line('<TD>'||'<B>Warning</B>');
                   dbms_output.put_line('This parameter should be FALSE.  The default is FALSE.'||'</TD></TR>');
                  END IF;
                END IF;

                IF dp.name='optimizer_index_caching' THEN
                  dbms_output.put_line('<TD>'||'To help the optimizer know, on average, how much of an index resides inside the data buffer.'||'</TD></TR>');
                END IF;

                IF dp.name='optimizer_index_cost_adj' THEN
                  dbms_output.put_line('<TD>'||'Default 100% - the optimizer evaluates index access at the regular cost.  50% makes the index access path look half as expensive. Normal is between 25 and 50.'||'</TD></TR>');
                END IF;

                IF dp.name='optimizer_mode' THEN
                  dbms_output.put_line('<TD>'||'Test the following OPTIMIZER_MODE options: all_rows, choose, rule. Typically all_rows delivers best performance.'||'</TD></TR>');
                END IF;

                IF dp.name='optimizer_use_sql_plan_baselines' THEN
                  IF dp.value='TRUE' THEN
                   dbms_output.put_line('<TD>'||'Demantra Development suggests this parameter be sets to FALSE.  The default is TRUE.'||'</TD></TR>');
                  END IF;
                END IF;

          END LOOP;
        dbms_output.put_line('</TABLE><P><P>');
Exception
When others then
dbms_output.put_line('Error at DB Parameters'||sqlerrm);
          
end;
/
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>





REM **************************************************************************************** 
REM APS_PARAMS
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql5(){var row = document.getElementById("s1sql5");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv114"></a>
prompt     <a name="top"><b><font size="+2"> APS_PARAMS Check </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows4sql5()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql5" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="45">
prompt       <blockquote><p align="left">
prompt          select * from schemaXXX.aps_params ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(35);
v_value varchar2(40);
v_number number;
v_comments varchar2(1000);

Begin

stmt_str:= 'select substr(pname,1,35), value_number from '||:gv_schema||'.'||'aps_params order by pname';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname,v_number;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        IF v_pname='log.history' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Demantra Log.History Parameter Clarification, a supplement to what is found in the Demantra Implementation Guide (Doc ID 761234.1)'||'</TD></TR>');
        END IF;
        IF v_pname='tunnel.client.maxConnections' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'The DEFAULT_NUMBER should be 10.'||'</TD>');
        END IF;
        IF v_pname='MaxUpdateThreads' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Check Support for parallel integration procedure, Max number of Parallel Update threads (Set ti Number of DB Server CPUs + 1.)'||'</TD>');
        END IF;
        IF v_pname='MaxSqlInExpressionTokens' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Beginning in v7301, due to the fixes made in Bug 9259750 - ABILITY TO INCREASE THE MAXSQLINEXPRESSIONTOKENS PARAMETER TO GREATER THAN 1000 there is no hard limit imposed.<br>');
           dbms_output.put_line('However, regardless of what version you run, it is best to try to make sure you are loading or viewing data at an aggregated level for best performance.<br>');
           dbms_output.put_line('For example, Item by Region instead or Item by Store or Promotion by Region instead of Promotion by Store.<br>');
           dbms_output.put_line('The ability to configure the max selected filters member is done by the value of MaxSqlInExpressionTokens in AppServer.properties file.<br>');
           dbms_output.put_line('The webserver needs to be restarted after modifying AppServer.properties file.  MaxAvailableFilterMembers specifies the maximum number of');
           dbms_output.put_line('entries that a filtered drop-down list can display.<br>'||'</TD>');
        END IF;
        IF v_pname='MaxAvailableFilterMembers' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(nvl(v_number, 0), 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Specifies the maximum number of members that can be retrieved in the worksheet filter screen.  If the user selects more members than allowed, a message<br>');
           dbms_output.put_line('asks the user to add further filtering.  This limit helps to prevent users from creating worksheets with too many members, which can adversely<br>');
           dbms_output.put_line('affect performance.  From Business Modeler-> parameters ->system parameter system Set MaxAvailableFilterMembers a number higher than the number<br>');
           dbms_output.put_line('of Parent Customer records.<br>'||'</td>');
        END IF;
        IF v_pname='BLEThreadPoolSize' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(nvl(v_number, 0), 0)||'</TD>');
           dbms_output.put_line('<TD>'||'For Server Extensions, you can try increasing the amount of pool size for the BLE.  This change should be done carefully as to not apply<br>');
       	   dbms_output.put_line('overhead on the database.  In any case it should not exceed the number of the database server CPU +1.<br>'||'</TD>');
        END IF;
        IF v_pname='BLEThreadTimeout' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'The typical default setting is 5000'||'</TD>');
        END IF;
        IF v_pname='ChangedDataIndicator' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Controls whether or not changed combinations and series values are highlighted in a worksheet. <br>Applies to unsaved changes in the worksheet,');
           dbms_output.put_line('either manual user edits or after importing data from Excel. The indicator no longer appears once the user saves pending changes.<br>The default value is 1,');
           dbms_output.put_line('which means the indicator is displayed.'||'</TD>');
        END IF;
        IF v_pname='DBConnectionTimeout' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Application Server, App.Server.  Default 5000. The database connection time-out period, in milliseconds.'||'</TD>');
        END IF;
        IF v_pname='DBDateFormat' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Application Server, App.Server.  The date format used in the database.  Default format yyyy/MM/dd hh:mm:ss z'||'</TD>');
        END IF;
        IF v_pname='DBIdleTimeout' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'The connection idle timeout period.  Control Oracle Demantra database connections.  Recommended: 300000 (5 minutes).'||'</TD>');
        END IF;
        IF v_pname='DBName' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Application Server, App.Server.  The meaning of this parameter depends on the database used: For Oracle databases, this is the Oracle SID.'||'</TD>');
        END IF;
        IF v_pname='DBPort' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Application Server, App.Server.  The port number of the database server.'||'</TD>');
        END IF;
        IF v_pname='DBType' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Application Server, App.Server.  Indicates the type of database that Demantra is using.'||'</TD>');
        END IF;
        IF v_pname='DBUser' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Application Server, App.Server.  Database user in which the Demantra data schema resides. See the Oracle Demantra Installation Guide.'||'</TD>');
        END IF;
        IF v_pname='DOL.multithreaded.loading' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Controls data loading mode for the DOL, Dynamic Open Link, servlet. 1 = Use multi threaded loading according to worksheet run parameters, 0 = Disable multi threaded loading process.'||'</TD>');
        END IF;
        IF v_pname='DatabaseEncoding' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Visible only to owner. Encoding style for Oracle Web products.'||'</TD>');
        END IF;
        IF v_pname='FillValueExportToExcel' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Controls if all rows or columns are labeled with combination information, or only the first row. Enabling allows one to more easily create reports, such as pivot tables, within Excel.'||'</TD>');
        END IF;
        IF v_pname='Graph.MaxLabelWidth' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Maximum width of labels in graphs in Collaborator Workbench, Demand Management, and Promotion Effectiveness. If a label is longer than this width, the last characters of the label are represented by three periods.'||'</TD>');
        END IF;
        IF v_pname='ImportBlockSize' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'The number of rows for each commit, used during import.'||'</TD>');
        END IF;
        IF v_pname='ImportFromFileDefaultMode' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Controls the default mode for importing data. Valid values are: 1 -The radio button for bulk upload of all values is enabled as default. 0 -The radio button for Upload to Worksheet and View before Saving is enable.'||'</TD>');
        END IF;
        IF v_pname='Legend.MaxLegendItemWidth' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Maximum character width of the legend in a graph-type content pane in collaborator Workbench. If any lines of the legend are too longer, the last characters of those lines are represented by three periods.'||'</TD>');
        END IF;
       IF v_pname='License.ExpirationMessage' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'appserver.system: Application Server parameter.'||'</TD>');
        END IF;
        IF v_pname='LookAndFeel' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Controls whether the default icons are used in Demantra worksheets. Set to 0 to use icons from previous versions. System-wide setting, affects all users. Requires application server restart.'||'</TD>');
        END IF;
        IF v_pname='MaxDBConnections' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'The maximum number of database connections for the Demantra database user.  Recommended: the number of concurrent users multiplied by 2.'||'</TD>');
        END IF;
        IF v_pname='MinDBConnections' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'The minimum number of database connections for the Demantra database user.'||'</TD>');
        END IF;
        IF v_pname='OpenFileAfterExport' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Determines if the file exported by the Export Data option is automatically opened after export. 1 -Opened after the export data process completes. 0 -Not opened after the export data process completes.'||'</TD>');
        END IF;
        IF v_pname='worksheet.full.load' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'worksheet.full.load=1 (used when using cross tab worksheets).<br>');
           dbms_output.put_line('See Demantra WORKSHEET PARAMETERS General, Organized Checklist. A Place to Begin for Maintenance and Proper Diagnostics (Doc ID 1519805.1).<BR>'||'</TD>');
        END IF;
        IF v_pname='ApprovalProcessScope' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'If you are using General Level worksheets that do not include sales_data series, set the parameter from 0 to 1.<br>');
           dbms_output.put_line('This will have a positive performance impact because it eliminates the join with sales_data  the setting of worksheet.full.load?<BR>'||'</TD>');
        END IF;
        IF v_pname='threadpool.query_run.size' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'This is the total number of threads allocated for the query run.  This should be adjusted based on the number of concurrent users and the<br>');
	   dbms_output.put_line('threadpool.query_run.per_user.  The product of number of concurrent users and threadpool.query_run.per_user.  For example if the <br>');
	   dbms_output.put_line('threadpool.query_run.per_user is set to 4 and expected number of concurrent users is 10, this parameter should be set to 40. MaxDBConnections<br>');
	   dbms_output.put_line('parameter should also be modified accordingly to account for the increase in number of threads for this parameter.<br>');
           dbms_output.put_line('For additional information see Oracle Demantra Parameters for Performance MyOracleSupport ID 1201774.1<BR>'||'</TD>');
        END IF;
        IF v_pname='worksheet.data.comb.block_size' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'This parameter controls the block size for worksheet data retrieval.  It defaults to 0, downloading all combinations in a single select.<br>');
	   dbms_output.put_line('This setting is appropriate for crosstab worksheets to display all the combinations together.   That is, worksheets in which the levels are displayed<br>');
	   dbms_output.put_line('within the table vs. as dropdowns or within the members browser.<br>');
	   dbms_output.put_line('For additional information see MyOracleSupport doc Oracle Demantra Parameters for Performance, ID 1201774.1<BR>'||'</TD>');
        END IF;
        IF v_pname='client.worksheet.calcSummaryExpressions' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'This parameter defaults to 1.  If true, summary line client expressions are supported. Complex summary expressions can have a performance impact.<br>');
      	   dbms_output.put_line('If this is set to 0, simple summary expressions (Sum, Max, etc.) are only supported.<br>');
           dbms_output.put_line('Please see Demantra Parameters for Performance (Doc ID 1201774.1) for more information.<BR>'||'</TD>');
        END IF;
        IF v_pname='client.worksheet.sortSeriesByDisplayOrder' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Business Modeler shows that the default order is By Configuration which means that the default sort in the Worksheet Designer is according to series order');
           dbms_output.put_line('set in Business Modeler.  The series are not sorted alphabetically in the worksheet designer->series tab, the series are not sorted alphabetically by default.');
	   dbms_output.put_line('When we create a new worksheet and click on series->All series ->Verify the order of the series.  We expect that series should be sorted by default as it happens');
	   dbms_output.put_line('in any fresh installation.  After changing the parameter to Alphabetically and restart the application server, the results where correct.'||'</TD>');
	        END IF;
       END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *******************************************************************
REM ******* Verify Sys_params - AppServerURL, AppServerLocation *******
REM *******************************************************************

prompt <script type="text/javascript"> function displayRows1sql6(){var row = document.getElementById("s1sql6");if (row.style.display == '') row.style.display = 'none'; else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2" width="100%">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv115"></a>
prompt     <a name="top"><b><font size="+2"> AppServer SYS_PARAMS Check </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql6()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql6" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="160">
prompt       <blockquote><p align="left">
prompt          select * from schemaXXX.sys_params ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(60);
v_value varchar2(1000);
v_comments varchar2(1000);

Begin

stmt_str:= 'select pname, pval from '||:gv_schema||'.'||'sys_params order by pname';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname,v_value;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        IF v_pname='AppServerURL' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_value, (null))||'</TD>');
           dbms_output.put_line('<TD>'||'Parameter value to mach your specific application URL.'||'<br>');
           dbms_output.put_line('Verify X_drive:\Demantra\V731\Collaborator\demantra\tools\desktopInstaller  win_installer.properties'||'<br>');
           dbms_output.put_line('Compare connection information from AppServer.properties file (or aps_params table in later versions) and tnsnames.ora:'||'<br>');
           dbms_output.put_line('Confirm that was added a line with, or alias name is the full database machine name.'||'<br>');
           dbms_output.put_line('Confirm that the GLUE information in the web.xml file has the correct URL information displaying the correct machine name and port number of the web server.'||'<br>');
           dbms_output.put_line('After a failed attempt and new changes, do not forget to rebuild the WAR file and clear internet and cache and old demantra folders in program files / user temp'||'<br>');
           dbms_output.put_line('Note that these changes need to be made on the windows machine and then the WAR file needs to be recreated and redeployed if the web server is on an UNIX/LINUX machine.'||'</TD>');
        END IF;
        IF v_pname='AppServerLocation' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_value, (null))||'</TD>');
           dbms_output.put_line('<TD>'||'AppServerUrl and AppServerLocation parameters in the sys_params table need to be changed to reflect the DEV webserver.'||'</TD>');
        END IF;
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM **************************************************************************************** 
REM ******* Verify 4 Parameters Which Related to the Manual Update Process *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql7(){var row = document.getElementById("s1sql7");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2" width=100%">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv116"></a>
prompt     <p><a name="top"><b><font size="+2"> Batch and Manual Update Process + Connections Parameters.  Save data in worksheets parameters.</font></B></a></p><br>
prompt     <a name="top"><font size="+1">There are only 4 parameters which related to the manual update process:<br>
prompt     a. threadpool.update.data.manual.size<br>
prompt     b. threadpool.update.table.manual.size<br>
prompt     c. threadpool.update.comb.manual.size<br>
prompt     d. threadpool.update.record.manual.size<br><br>
prompt     If one of these 4 parameters is set to NULL, the update process should finish successfully, since in this case, we set a default value internally, in the application, instead of NULL.<br><br>
prompt     If one of these 4 parameters is set to zero, the process will not complete since there are no available tasks for the update process.  The allocated tasks is zero.<br>
prompt     Therefore, the value of each one of the 4 parameters above should always be greater than zero.<br><br>
prompt     The application server behaves differently in case the parameters are NULL or zero.<br>
prompt     If parameter is NULL - we use a default value, internally in the application, instead of NULL.<br>
prompt     If parameter is zero - we use this value and in this case, there are no threads for the update process and that is why update does not complete.<bR>
prompt     Currently, In Business Modeler, numeric parameters are represented as 0.00 in case the value is zero or NULL and therefore the user<br>
prompt     may believe that in both cases the value is zero. The values of these parameters can be found in the aps_params table.</font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql7()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql7" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="160">
prompt       <blockquote><p align="left">
prompt          select jjg* from schemaXXX.aps_params ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value Description</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(40);
v_val_number number;
v_comments varchar2(1000);

Begin


stmt_str:= 'select substr(pname,1,40), value_number from '||:gv_schema||'.'||'aps_params order by pname';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname, v_val_number;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        IF v_pname='threadpool.update.data.manual.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
           dbms_output.put_line('<TD>'||'Number of parallel manual update processes, application server can handle at a time.'||'<br>');
           dbms_output.put_line('The number of update threads.'||'</TD>');
        END IF;
        IF v_pname='threadpool.update.table.manual.size' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
           dbms_output.put_line('<TD>'||'Number of parallel manual update tables, application server handle at a process.'||'</TD>');
        END IF;
        IF v_pname='threadpool.update.comb.manual.size' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
           dbms_output.put_line('<TD>'||'Number of parallel manual update combs, application server handle at a table.'||'</TD>');
        END IF;
        IF v_pname='threadpool.update.record.manual.size' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
           dbms_output.put_line('<TD>'||'Number of parallel manual update records, application server handle at a comb.'||'</TD>');
        END IF;
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM ******* Review Parameter maxdbconnections *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql8(){var row = document.getElementById("s1sql8");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv117"></a>
prompt     <a name="top"><b><font size="+2"> MaxDBConnections </font></b></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql8()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql8" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="60">
prompt       <blockquote><p align="left">
prompt          select pname, nvl(value_string, (null)), description from aps_params;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(60);
v_val_number number;
v_comments varchar2(16);

Begin

stmt_str:= 'select pname, decode(value_number,null,0,value_number) from '||:gv_schema||'.'||'aps_params';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname,v_val_number;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        IF lower(v_pname)='maxdbconnections' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_val_number||'</TD>');
           dbms_output.put_line('<TD>'||'It is important to make sure that the application server will have all the needed threads to execute all parallel');
           dbms_output.put_line('requests; query executions, workflow runs, updates, etc.<br>A rule of thumb will be the number of concurrent ');
           dbms_output.put_line('users * threadpool.query_run.per_user *10 (if threadpool.query_run.per_user > 4).'||'</TD>');
        END IF;
        IF lower(v_pname) = 'mindbconnections' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_val_number||'</TD>');
           dbms_output.put_line('<TD>'||'The minimum number of database connections for the Demantra database user.'||'</TD>');
        END IF;
        IF lower(v_pname) = 'dbidletimeout' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_val_number||'</TD>');
           dbms_output.put_line('<TD>'||'The connection idle timeout period.  Recommended: 300000 (5 minutes).'||'</TD>');
        END IF;
        IF lower(v_pname) = 'dbconnectiontimeout' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_val_number||'</TD>');
           dbms_output.put_line('<TD>'||'The database connection timeout period.'||'</TD>');
        END IF;
     END LOOP;
    close c1;
END;
/

prompt </TABLE><P><P>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM **************************************************************************************** 
REM ******* LOG_IT_PARAMS *******
REM **************************************************************************************** 
REM
prompt <script type="text/javascript">    function displayRows1sql9(){var row = document.getElementById("s1sql9");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <br><br><TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF">
prompt     <font face="Calibri"><a name="adv118"></a>
prompt      <a name="top"><b><font size="+2"> Do you have LOG_IT set to active? </font></B></a>
prompt     </font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql9()" >SQL Script</button></div>
prompt     </TD>
prompt </TR>
prompt <TR id="s1sql9" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="60">
prompt       <blockquote><p align="left">
prompt          select subtra(pname,1,20), <br>
prompt          log_table,<br>
prompt          logging_level<br>
prompt          from log_it_params;</p><br>
prompt       </blockquote>
prompt     </TD>
prompt </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pname</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Log_Table</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Logging_Level</B></TD></TR>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(20);
v_log_table varchar2(30);
v_logging_level number;


Begin

stmt_str:= 'select substr(pname,1,20), log_table, logging_level from '||:gv_schema||'.'||'log_it_params';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname, v_log_table, v_logging_level;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_log_table||'</TD>');
           dbms_output.put_line('<TD>'||v_logging_level||'</TD></TR>');
      END LOOP;
      close c1;
END;
/
prompt </TABLE></p>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>





REM **************************************************************************************** 
REM ******* DB_EXCEPTION_LOG Engine Profiles *******
REM **************************************************************************************** 

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> DB_EXCEPTION_LOG </font></b></a><br>
prompt     <a name="top"><font size="+1">   When an engine is not configured on a Linux box but is run through Windows, then the way to enable the enhanced 
prompt         engine logs is through the Engine Administrator<br>
prompt         <Demantra Install Root>\Demand Planner\Analytical Engines\bin\EngineAdministrator.exe.  Go to Settings-->Configure<br>
prompt         Select the logs that you want to enable, for example SQL, User, Nodes etc<br>
prompt         However in a Linux box you cannot run the EngineAdministrator.exe.<br>
prompt         In order to enable enhanced logs for the engine, review How to configure Enhanced Engine logs for Engine Configured Either on Windows or Linux (Doc ID 1454588.1)<br><br>
prompt        * Entry<br>
prompt           Key argument="EngineManagerLogFile" / <br>
prompt           Value type="string" argument="\engine2k\EngineManager.log" /> <br>
prompt           /Entry<br>
prompt        * Entry<br>
prompt           Key argument="EngineLogFile" / <br>
prompt           Value type="string" argument="\engine2k\Engine2k.log" / <br>
prompt           /Entry<br><br>
prompt         Used to configure the engine.  Where engines will be executed is defined in $engine_root/bin/Settings.xml file under the ComputerNames section.  You will find it in $ENGINE_ROOT/bin/Settings.xml.<br>
prompt         One of the key parameters to starting the engine is EngineUnixPortConfig.  There are two log file settings  JJG what are they?</font></a></TD>
prompt </tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql10(){var row = document.getElementById("s1sql10");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv119"></a>
prompt     <a name="top"><b><font size="+2"> DB_EXCEPTION_LOG </font></B></a><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql10()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql10" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="185">
prompt       <blockquote><p align="left">
prompt       select err_date, proc_name, err_msg <br>
prompt       from owner.db_exception_log order by 1 desc;<br>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Err Date</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Procedure</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Message</B></TD></TR>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
err_dt date;
v_proc_name varchar2(40);
v_msg varchar2(70);

Begin

stmt_str:= 'select err_date, substr(proc_name,1,40), substr(err_msg,1,70) from '||:gv_schema||'.'||'db_exception_log where rownum <21 order by 1 desc';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into err_dt, v_proc_name, v_msg;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||err_dt||'</TD>');
           dbms_output.put_line('<TD>'||v_proc_name||'</TD>');
           dbms_output.put_line('<TD>'||v_msg||'</TD></TR>');
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM ****************************************************************
REM ******* integ_status *******
REM ****************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> INTEG_STATUS </font></b></a><br>
prompt     <a name="top"><font size="+1">To review detailed log files for the EP_LOAD EP LOAD process, see integ_status table.  Run this query to see staus of EBS Full Download.<br> 
prompt select * from demantra.integ_status order by status_date desc, will show that SALES_DOWNLOAD is running.<br></font></a>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql11(){var row = document.getElementById("s1sql11");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv120"></a>
prompt     <a name="top"><b><font size="+2"> INTEG_STATUS </font></B></a><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql11()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql11" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="185">
prompt       <blockquote><p align="left">
prompt       select status_date,<br>
prompt       substr(username,1,10),<br>
prompt       substr(process,1,40),<br>
prompt       substr(stage,1,40),<br>
prompt       substr(status,1,25)<br>
prompt       from msdem.integ_status<br>
prompt       where rownum < 25<br>
prompt       order by status_date desc;<br>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status_Date</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Username</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Process</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Stage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD></TR>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_status_date date;
v_username varchar2(10);
v_process varchar2(40);
v_stage varchar2(40);
v_status varchar2(25);

Begin

stmt_str:= 'select status_date, substr(username,1,10), substr(process,1,40), substr(stage,1,40), substr(status,1,25) from '||:gv_schema||'.'||'integ_status where rownum <25 order by 1 desc';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into V_status_date, V_username, v_process, v_stage, v_status;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_status_date||'</TD>');
           dbms_output.put_line('<TD>'||v_username||'</TD>');
           dbms_output.put_line('<TD>'||v_process||'</TD>');
           dbms_output.put_line('<TD>'||v_stage||'</TD>');
           dbms_output.put_line('<TD>'||v_status||'</TD></TR>');
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM ******* LOG_DATA_MODEL *******
REM **************************************************************************************** 

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> LOG_DATA_MODEL </font></b></a><br>
prompt     <a name="top"><font size="+1">   When an engine is not configured on a Linux box but is run through the windows, then the way to enable the enhanced 
prompt         engine logs is through the Engine Administrator<br>
prompt         <Demantra Install Root>\Demand Planner\Analytical Engines\bin\EngineAdministrator.exe.  Go to Settings-->Configure<br>
prompt         Select the logs that you want to enable, for example SQL, User, Nodes, etc.<br>
prompt         However in a Linux box you cannot run the EngineAdministrator.exe.<br>
prompt         In order to enable enhanced logs for the engine, review How to configure Enhanced Engine logs for Engine Configured Either on Windows or Linux (Doc ID 1454588.1)<br><br>
prompt        * Entry<br>
prompt           Key argument="EngineManagerLogFile" / <br>
prompt           Value type="string" argument="\engine2k\EngineManager.log" /> <br>
prompt           /Entry<br>
prompt        * Entry<br>
prompt           Key argument="EngineLogFile" / <br>
prompt           Value type="string" argument="\engine2k\Engine2k.log" / <br>
prompt           /Entry<br><br>
prompt         Used to configure the engine.  You will find it in $ENGINE_ROOT/bin/Settings.xml.<br>
prompt         One of the key parameters to starting the engine is EngineUnixPortConfig.</font></a></TD>
prompt </tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql12(){var row = document.getElementById("s1sql12");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv121"></a>
prompt     <a name="top"><b><font size="+2"> LOG_DATA_MODEL Last 50 Entries </font></B></a><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql12()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql12" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="185">
prompt       <blockquote><p align="left">
prompt       select log_id,<BR>
prompt       log_date,<BR>
prompt       substr(proc_name,1,25),<BR>
prompt       log_type,<BR>
prompt       substr(log_msg,1,35)<BR>
prompt       from your_schema_owner.LOG_DATA_MODEL<BR>
prompt       where rownum < 50<BR>
prompt       order by log_date desc;<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Log_ID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Log_Date</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Proc_Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Log_Type</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Log_Message</B></TD></TR>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_log_id number;
v_log_date date;
v_proc_name varchar2(30);
v_log_type varchar2(10);
v_log_msg varchar2(45);

Begin

stmt_str:= 'select log_id, log_date, substr(proc_name,1,30), log_type, substr(log_msg,1,45) from '||:gv_schema||'.'||'log_data_model where rownum <50 order by log_date desc';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_log_id, v_log_date, v_proc_name, v_log_type, v_log_msg;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_log_id||'</TD>');
           dbms_output.put_line('<TD>'||v_log_date||'</TD>');
           dbms_output.put_line('<TD>'||v_proc_name||'</TD>');
           dbms_output.put_line('<TD>'||v_log_type||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_log_msg,'null')||'</TD></TR>');
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM ******* wf_process_log *******
REM **************************************************************************************** 

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> Workflow WF_PROCESS_LOG </font></b></a><br>
prompt     <a name="top"><font size="+1"> When you log in to workflow manager,you are able to see the process log.  The process log will store all of the workflows that have ran based<br>
prompt     on the parameter that is set in the business modeler.  The process log information is stored in wf_process_log table.<br><br>  
prompt     To view process log , log into workflow manager -<br>
prompt     1. On the bottom of the Workflow Management page, click Process Log.  The Process Log page appears.<br>
prompt     2. The Work flow log provides infomration of schema id (workflow id ), starttime, end time, the workflow (initiator), Last step executed in the workflow and the status<br>
prompt     of the workflow if it has completed, running or failed.<br>
prompt     3. All the details related to the workflow process log are captured in the wf_process_log table.<br>
prompt     You also need to see the log.history parameter setting under application server ->workflow to see how many days of history will be shown in workflow process log.<br><br>
prompt     You can set the frequency of the purge for the process log through the log.history parameter. The same can be set through the Business Modeler:<br>
prompt     Business Modeler --> Parameters --> System Parameters -->Application Server --> Workflow<br>
prompt     The default value is 1 (in day)<br><br>
prompt     Once you have edited the parameter, bounce the web server to reflect this change. Please note that if you are on versions prior<br>
prompt     to v7.3.0 then you might need to recreate and redeploy the WAR file depending on your web architecture. <br>
prompt     Note that restarting the Web Server will also purge this WF_Process_Log table.<br><br>
prompt     Below are the status of the wf_process_log and portal_task<br>
prompt     wf_process_log.status:<br>
prompt     -3 = ENDLESS_LOOP<br>
prompt     -2 = FAILED<br>
prompt     -1 = TERMINATED<br>
prompt      0 = COMPLETED<br>
prompt      1 = ACTIVE<br>
prompt      2 = PAUSED<br><br><br>
prompt     portal_task.status<br>
prompt      0 = ACCEPTED<br>
prompt     -1 = DONE<br>
prompt     -2 = load from DB and run into a problem<br>
prompt     -5 = TIMEOUT_OVER<br><br>
prompt If your work flow is not processing as expected verify the details in the following tables: wf_process_log, integ_status, wf_scheduler and wf_schemas.<br>
prompt In addition, if Demantra finds any abnormality in the workflow behavior, it loads this information into db_exception_log or portal_task.<br><br>
prompt Please see the below for additional information:<br>
prompt Demantra Log.History Parameter Clarification, a supplement to what is found in the Demantra Implementation Guide Doc ID 761234.1</font></a></TD></tr></tbody></table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql13(){var row = document.getElementById("s1sql13");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv122"></a>
prompt     <a name="top"><b><font size="+2"> WF_PROCESS_LOG </font></B></a><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql13()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql13" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="185">
prompt       <blockquote><p align="left">
prompt       select initiator,<br>
prompt       status,<br>
prompt       schema_id,<br>
prompt       process_id,<br>
prompt       step_id,<br>
prompt       num_steps,<br>
prompt       record_updated<br>
prompt       from wf_process_log<br>
prompt       where rownum <25<br>
prompt       order by 7 desc;<br>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Initiator</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Schema_ID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Process_ID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Step_ID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Num_Steps</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Record_Updated</B></TD></TR>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_INITIATOR            NUMBER(10);
v_STATUS               NUMBER(3);
v_SCHEMA_ID            NUMBER(10);
v_PROCESS_ID           NUMBER(10);
v_STEP_ID              VARCHAR2(50);
v_NUM_STEPS            NUMBER(5);
v_RECORD_UPDATED       DATE;

Begin

stmt_str:= 'select initiator, status, schema_id, process_id, step_id, num_steps, record_updated from '||:gv_schema||'.'||'wf_process_log where rownum <25 order by 7 desc';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_INITIATOR, v_STATUS, v_SCHEMA_ID, v_PROCESS_ID, v_STEP_ID, v_NUM_STEPS, v_RECORD_UPDATED;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_INITIATOR||'</TD>');
           dbms_output.put_line('<TD>'||v_status||'</TD>');
           dbms_output.put_line('<TD>'||v_schema_id||'</TD>');
           dbms_output.put_line('<TD>'||v_process_id||'</TD>');
           dbms_output.put_line('<TD>'||v_step_id||'</TD>');
           dbms_output.put_line('<TD>'||v_num_steps||'</TD>');
           dbms_output.put_line('<TD>'||v_record_updated||'</TD></TR>');
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM **************************************************************************************** 
REM ******* Reveal Locks *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql14(){var row = document.getElementById("s1sql14");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=7 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv123"></a>
prompt     <a name="top"><b><font size="+2"> Are There any Locks <font></B></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql14()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql14" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="8" height="60">
prompt       <blockquote><p align="left">
prompt       select oracle_username, <br>
prompt       os_user_name, <br>
prompt       locked_mode, <br>
prompt       object_name, <br>
prompt       object_type <br>
prompt       from   v$locked_object a, <br>
prompt       dba_objects b <br>
prompt       where  a.object_id = b.object_id <br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Object_ID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Session_ID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Oracle User Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>OS User Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Mode</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Type</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Process</B></TD></TR>
exec :n := dbms_utility.get_time;
Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_OracleUser varchar2(60);
v_object_id number;
v_session_id number;
v_OSUser varchar2(60);
v_mode varchar2(30);
v_Name varchar2(60);
v_Type varchar2(60);
v_process varchar2(24);

Begin

stmt_str:= 'select a.object_id, session_id, oracle_username, os_user_name, locked_mode, object_name, object_type, process from v$locked_object a, dba_objects b where a.object_id = b.object_id';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_object_id, v_session_id, v_OracleUser, v_OSUser, v_mode, v_Name, v_Type, v_process;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_object_id||'</TD>');
           dbms_output.put_line('<TD>'||v_session_id||'</TD>');
           dbms_output.put_line('<TD>'||v_OracleUser||'</TD>');
           dbms_output.put_line('<TD>'||v_OSUser||'</TD>');
           dbms_output.put_line('<TD>'||v_mode||'</TD>');
           dbms_output.put_line('<TD>'||v_Name||'</TD>');
           dbms_output.put_line('<TD>'||v_Type||'</TD>');
           dbms_output.put_line('<TD>'||v_process||'</TD>');
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM **************************************************************************************** 
REM ******* Purging Old Data *******
REM **************************************************************************************** 

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Old SALES_DATA and MDP_MATRIX Rows That Could be Purged or Deleted</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> The recommendation is to purge old, unused data from the schema�s data tables.<br>
prompt     This, currently, should be done as a user defined process, but in the future Demantra will provide its own archiving capabilities.<br>
prompt     The easiest way to purge data is when the schema is partitioned based on time range.<br>
prompt     This way the archiving process includes purging of old partitions.<br>
prompt     It is also important, every year is a general recommendation, to purge old combinations from mdp_marix.<br>
prompt     Run a query detecting combinations in mdp_matrix that do not have any associated data in sales_data, the data was purged already and delete them from mdp_matrix.</font></a><br><br>
prompt    <p><b><font size="+1">Select item_id,location_id from mdp_matrix where (item_id,location_id) not in select item_id,location_id from sales_data;</font></b><br>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

REM **************************************************************************************** 
REM ******* Influencing Engine Performance *******
REM **************************************************************************************** 

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Engine Performance Hints</font></b></a></p><br>
prompt         <a name="top"><font size="+1">The first time the engine runs it will definitely take a longer time than the second time onwards. First time Insert units create future rows for the <br>
prompt         entire lead-time that you have specified.  Next time it only adds rows incrementally. You can run Insert units separately. To skip this procedure,<br>
prompt         set in INIT_PARAMS_0: Run Insert Units=3, this will improve engine start up time.  Generally we should focus on the second run onwards.<br><br>
prompt         If we have combinations with prediction status=98 and Aggri_98=1 or with prediction status=99 and Aggri_99, and if these combinations are<br>
prompt         not below the nodes on which we want to calculate forecast, we can change their prediction status to 96.  In that way we avoid the unneeded aggregations.<br><br>
prompt         Set RunPartialDivider = 1 in init_params_0, you may have to add this parameter.  The idea is to do the full branch division only once in a while<br>
prompt         and at the rest of the time do partial division only for the new combinations added since the last time.  This will improve the startup time for the engine.</font></a><br>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>


REM ************************************************************************
REM ******* MDP_MATRIX - ACTIVE COMBINATIONS and ENGINE PERFORMANCE  *******
REM ************************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> Engine Workload in MDP_Matrix </font></b></a><br>
prompt     <a name="top"><font size="+1"> The Analytical Engine ignores any young or dead combinations, except when it is necessary to aggregate.<br>
prompt In case of aggregation, Demantra considers the do_aggri, aggri_98, or aggri_99 flag of the combination � recall these control aggregation<br>
prompt Demantra sets the prediction_status indicator as follows:<br><br>
prompt For fictive combinations, is_fictive = 1, Demantra automatically sets the prediction status to 98<br>
prompt For real combinations, is_fictive equal to 0 or 2, Demantra uses the following rules:<br>
prompt If do_fore is 0, then prediction_status will be 99<br>
prompt If do_fore is 1, then prediction_status is set as follows:<br>
prompt If the combination is dead because of the dying_time parameter, then prediction_status is set to 99<br>
prompt If the combination is young because of the mature_age parameter, then prediction_status is set to 98<br>
prompt Otherwise, the prediction_status is set to 1<br>
prompt If do_fore is 2, then prediction_status will be 97<br><br>
prompt Whenever encountering Engine performance issues and/or OutOfMemory errors the following SQL needs to be run:<br>
prompt Select count(*), <br>
prompt prediction_status, <br>
prompt do_fore, <br>
prompt do_aggri, <br>
prompt aggri_98,<br>
prompt aggri_99, <br>
prompt level_id<br>
prompt from mdp_matrix<br> 
prompt Group by prediction_status, do_fore, do_aggri, aggri_98, aggri_99, level_id;
prompt See MyOracleSupport Ntoe: Demantra Controlling MDP_MATRIX Combinations Assigned to Forecasting Tasks Using TargetTaskSize, 1473437.1<br><br>
prompt HINT:  Control of forecast tree branch size<br>
prompt - Run the following sql to determine how even the branches are being split by the engine:<br><br>
prompt Select branch_id,count(*) from mdp_matrix where  prediction_status i= 1 group by branch_id.<br>
prompt Select COUNT(*), LEVEL_ID FROM  MDP_MATRIX WHERE prediction_status = 1 AND DO_FORE = 1 GROUP BY LEVEL_ID<br><br>
prompt   This will give you an understanding if some of the individual branches have an unusually large number of<br>
prompt   rows and thus might indicate that the engine is not efficiently dividing up the parallel tasks.<br><br>
prompt - Based on the results of this sql, we may want to adjust the branch id multiplier and/or the number of engines<br>
prompt   (both of these settings are found in the Engine Administrator).  Reference 1473437.1 as noted above. <br>
prompt </font></a></TD></tr></tbody></table><BR><BR>
prompt <script type="text/javascript">    function displayRows1sql15(){var row = document.getElementById("s1sql15");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=5 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv124"></a>
prompt     <a name="top"><b><font size="+2"> ACTIVE COMBINATIONS by LEVEL </font></B></a><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql15()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql15" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="185">
prompt       <blockquote><p align="left">
prompt Select count(*), <br>
prompt prediction_status, <br>
prompt do_fore, <br>
prompt do_aggri, <br>
prompt aggri_98,<br>
prompt aggri_99, <br>
prompt level_id<br>
prompt from mdp_matrix<br> 
prompt Group by prediction_status, do_fore, do_aggri, aggri_98, aggri_99, level_id asc<br>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Prediction_Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DO_Fore</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DO_Aggri</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Aggri_98</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Aggri_99</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Level_ID</B></TD></TR>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_count              NUMBER(15);
v_prediction_status  NUMBER(3);
v_do_fore            NUMBER(12);
v_do_aggri           NUMBER(12);
v_aggri_98           NUMBER(12);
v_aggri_99           NUMBER(12);
v_level_id           NUMBER(5);

Begin

stmt_str:= 'select count(*), prediction_status, do_fore, do_aggri, aggri_98, aggri_99, level_id from '||:gv_schema||'.'||'mdp_matrix group by (prediction_status, do_fore, do_aggri, aggri_98, aggri_99, level_id)';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_count, v_prediction_status, v_do_fore, v_do_aggri, v_aggri_98, v_aggri_99, v_level_id;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_count||'</TD>');
           dbms_output.put_line('<TD>'||v_prediction_status||'</TD>');
           dbms_output.put_line('<TD>'||v_do_fore||'</TD>');
           dbms_output.put_line('<TD>'||v_do_aggri||'</TD>');
           dbms_output.put_line('<TD>'||v_aggri_98||'</TD>');
           dbms_output.put_line('<TD>'||v_aggri_99||'</TD>');
           dbms_output.put_line('<TD>'||v_level_id||'</TD></TR>');
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>




REM **************************************************************************************** 
REM ******* verify the ResetForeVals Parameter *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql16(){var row = document.getElementById("s1sql16");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv125"></a>
prompt     <a name="top"><font size="+2"><B> Clearing Forecast Values </B></font></a><br>
prompt     <a name="top"><font size="+1">The ResetForeVals parameter controls the reset of inactive combinations<br>
prompt     * Off <br>
prompt     * Yes, all combinations with prediction status of 97, 98, or 99, fore = 2, will get null forecast values and<br>
prompt       active combinations will be overwritten by the new forecast.<br>
prompt     * No, If set to No, then the existing forecast for inactive combinations will not be cleared.<br>
prompt     * "All" can not be used with EngineOutputThreshold>0 at the same engine  profile." <br>
prompt       Note: Setting this parameter to 'All' may substantially increase engine run time<br>
prompt     Each engine profile shares or overrides the BASE profile.</font></a><br></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql16()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql16" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt       select substr(value_float,1,20) from init_params_0 where pname = 'ResetForeVals';<br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_val1 varchar2(500);
v_float float(2);

Begin

stmt_str:= 'select substr(value_float,1,20) from '||:gv_schema||'.'||'init_params_0 where pname = ''ResetForeVals''';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_float;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||nvl(v_float, (null))||'</TD></TR>');
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ***********************************************************************************************
REM ******* Verify max_fore_sales_date, max_sales_date, min_fore_sales_date, min_sales_date *******
REM ***********************************************************************************************

REM chg colspan from 2 to 9
REM chg s4sql14 to 

prompt <table border="1" name="alertBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Verify max_fore_sales_date, max_sales_date, min_fore_sales_date, min_sales_date</font></b></a></p><br>
prompt         <a name="top"><font size="+1">max_sales_date: The latest sales date loaded as history in the system.  Analytical engine will use last_date as last date of actual sales.<br>
prompt  So if you are setting the engine to use a older date for actual sales then the latest sales loaded in the system as history, need to ensure you  already have all the records in<br>
prompt  sales_data table to max_sales_date date.  The following parameter values should be valid (ie if the start of the week at your site is Monday, then these parameters should have Monday dates):<br>
prompt  init_params.last_date_backup<br>
prompt  sys_params.max_sales_date<br>
prompt  sys_params.min_fore_sales_date<br>
prompt  sys_params.max_fore_sales_date<br>
prompt  You may use Business Modeler - Parameters - Engine parameters.</font></a><br>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>


prompt <script type="text/javascript">    function displayRows1sql17(){var row = document.getElementById("s1sql17");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2" width="100%">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv126"></a>
prompt     <a name="top"><b><font size="+2">Verify Dates Min Sales and Max Sales</font></B></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql17()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql7" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="160">
prompt       <blockquote><p align="left">
prompt          select * from schemaXXX.sys_params ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(60);
v_value varchar2(1000);
v_comments varchar2(1000);

Begin

stmt_str:= 'select pname, pval from '||:gv_schema||'.'||'sys_params order by pname';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname,v_value;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        IF v_pname='max_fore_sales_date' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_value||'</TD>');

           dbms_output.put_line('<TD>'||'Incorrectly setting MAX_SALES_DATE can cause errors such as<br><br>');
           dbms_output.put_line('Engine fails with HRESULT=0x80004005 - Unspecified error; Unspecified error ERROR Caught exception at DmM3TreeIterator::Execeute()<br>');
           dbms_output.put_line('Correct max sales, delete the rows in the current future, delete also last months as needed<br>');
           dbms_output.put_line('1. REBUILD_SCHEMA<br>');
           dbms_output.put_line('2. recompile the invalid objects.<br>');
           dbms_output.put_line('3. Bounce the server<br>');
           dbms_output.put_line('Reset Engine Run by performing:init_params.last_date_backup = sys_params.max_fore_sales_date = sys_params.max_sales_date<br>');
           dbms_output.put_line('update sys_params set PVAL = (select PVAL from msdem.SYS_PARAMS where PNAME = max_sales_date) where pname = max_fore_sales_date;commit;<br>');
           dbms_output.put_line('Restart the webserver<br>'||'</TD>');

        END IF;
        IF v_pname='max_sales_date' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_value||'</TD>');
           dbms_output.put_line('<TD>'||'Ensure that basic parameters used by the Engine are correct. For example, the value in the max_sales_date parameter<br>');
           dbms_output.put_line('select pval from sys_params where pname = max_sales_date<br>');
           dbms_output.put_line('This value, in most cases, should match the value of the last sales_date value from the sales_data table where Quantity Form is greater than<br>');
           dbms_output.put_line('or equal to 0 (Zero is considered a legitimate data point)<br>');
           dbms_output.put_line('select max(sales_data) from sales_data where Quantity Form Expression >= 0<br>'); 
           dbms_output.put_line('Quantity Form Expression =  represents the expression ex.  nvl(pseudo_sale,actual_quantity)*(1 + nvl(demand_fact,0)).<br>');
           dbms_output.put_line('Also, a problem could occur in FillMissingDates() and could be caused by the values of the max_sales_date and last_date / last_date_backup parameters.<br>');
           dbms_output.put_line('Insert_units procedure will insert records in the span of time from max_sales_date to max_sales_date + lead only.<br>');
           dbms_output.put_line('Analytical engine will use last_date as last date of actual sales. So if you are setting the engine to use a older date for<br>');
           dbms_output.put_line('actual sales then the latest sales loaded in the system as history, need to ensure you  already have all the records in sales_data<br>');
           dbms_output.put_line('table until max_sales_date date.<br>');
           dbms_output.put_line('Please also set max_fore_sales_date in sys_params to the same as max_sales_date, which should reflect the same date as<br>');
           dbms_output.put_line('last_date_backup.  Then run again the engine.<br>'||'</TD>');
        END IF;
        IF v_pname='min_fore_sales_date' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_value||'</TD>');
           dbms_output.put_line('<TD>'||'Businnes Impact<br>');
           dbms_output.put_line('Unable to bring Demantra Production History information into APCC.  There is information in the Actual Production series.<br><br>'); 
           dbms_output.put_line('Symptoms that might point to this same accidental future Demand data load issue are:<br>');
           dbms_output.put_line('- Client reports that the Forecast Override series for future time buckets becomes uneditable after the latest data load/engine run.<br>');
           dbms_output.put_line('- Many combinations now have a Forecast System Status = Dead Address (mdp_matrix.prediction_status = 99).<br>');
           dbms_output.put_line('- Due to this issue, users cannot enter overrides since the system perceives the max_sales_date value as an incorrect date in the future.<br><br>');
           dbms_output.put_line('SQL> update sys_params set min_fore_sales_date = sales_date+1 bucket<br>');
           dbms_output.put_line('SQL> commit;<br><br>');
           dbms_output.put_line('Note sales_date+1 bucket = the next sales_date bucket past the last sales_date value in sales_data.<br>');
           dbms_output.put_line('So if this a weekly system. last sales_date = 8/1/2008 then sales_date + 1 week = 8/8/2008<br>'||'</TD>');
        END IF;
        IF v_pname='min_sales_date' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||v_value||'</TD>');
           dbms_output.put_line('<TD>'||'This is the earliest possible sales_date in the SALES_DATA table.<br>');
           dbms_output.put_line('Review min_sales_date and ensure that it reflects the minimum sales_date in the sales_data table. This date cannot be on or after the max_sales_date.<br>'||'</TD>'); 
        END IF;
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM **************************************************************************************** 
REM ******* Application Server Memory Setting *******
REM **************************************************************************************** 
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2">Application Server Memory and JVM Version</font></B></a><br>
prompt     <a name="top"><font size="+1">Check the memory settings of the Application server, in some cases the default of 512M is used, and is a bottleneck in the work of the application<br>
prompt     server that needs to go to the �gc� all the time.  This can be tuned based on the initial memory consumption of the Appserver at startup and the<br>
prompt     parallel user work needed by the application.  Another factor is the JVM itself; is it 32bit?  64bit is the recommended JVM for Demantra Application server).</font></a><br></TD>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>


REM **************************************************************************************** 
REM ******* Client Memory Setting *******
REM **************************************************************************************** 
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2">Tuning the Client Workstation</font></B></a><br>
prompt     <a name="top"><font size="+1">Client tuning, begin with Starting Demantra Applications. Hardware. Upgrade. Clone. Performance. System. Compatibility. Java. Engine. Integration Document : 1372253.1<br><br>
prompt     1) Go to Business Modeler<br>
prompt     2) Update client.JREMaxMemory parameter to 512<br>
prompt   3.1) Close all web browsers. Verify that no java process is running on client machine.<br>
prompt   3.2) Delete java cache<br>
prompt        - Manually delete java user temp files: the actual "cache" folder from %appdata%\Sun\Java\Deployment<br>
prompt        - Empty user browser temp files<br>
prompt   3.3) Restart the Web Application Server<br>
prompt     4) Instruct user to go to ..../configureEnv.jsp to have it automatically set JVM memory to 512MB - http://localhost:8080/demantra/portal/configureEnv.jsp<br><br>
prompt   Java related The actual memory consumption percentage is:    (Used Memory / MAX Memory)*100<br>
prompt   Note: Sometimes Plug-in Console Window is not accessible from the System Tray. In such a case it is possible to view the plug-in log file directly.<br>
prompt   Go to $USER_HOME/Application Data/Sun/Java/Deployment/log directory and open the pluginXXX_XX.trace file that matches your Java version.<br>
prompt   See Document: 738503.1 - How to set the Java Plugin Heap Size in response to an OutofMemory error and in general for best performance - JAVA - Newer versions of JRE improves Performance.<br>
prompt   Document: 1157173.1 - DEVELOPMENT Suggested Performance ADVICE Plus</font></a><br><br>
Prompt   </td></tr></tbody></table><br><br>


REM **************************************************************************************** 
REM ******* Engine Profiles *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql18(){var row = document.getElementById("s1sql18");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv127"></a>
prompt     <a name="top"><b><font size="+2">Engine Profile INIT_PARAMS_0</font></B></a><br>
prompt     <a name="top"><font size="+1">This is the BASE profile.<br>
prompt     Please note that it is now possible to have multiple profiles for the engine and you might have some overriding parameters<br>
prompt     in other init_params_xxx file.  Please check your schema to see if you have any additional init_params_xxx that might have<br>
prompt     overriding parameters.  Check for the INIT_PARAMS_TABLE_NAME that you are using for the engine run and query the table.<br>
prompt     For example, if you have INIT_PARAMS_0 as the data in the INIT_PARAMS_TABLE_NAME for your engine run, then review the output in the next section below.</font></a></TD><BR>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql18()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql18" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt       To show Defaults use this :<br>
prompt       select * from init_params_0;<br><br>
prompt       To show Overriding settings use this :<br>
prompt       select * from init_params_0<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Description</B></TD></TR>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(25);
v_float float(30);
v_desc varchar2(35);

Begin

stmt_str:= 'select substr(pname,1,25), substr(value_float,1,30), substr(description,1,35) from '||:gv_schema||'.'||'init_params_0';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname, v_float, v_desc;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_float, (null))||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_desc, (null))||'</TD><TR>');
         IF v_pname='log.history' THEN
           dbms_output.put_line('<TD>'||'Demantra Log.History Parameter Clarification, a supplement to what is found in the Demantra Implementation Guide (Doc ID 761234.1)'||'</TD>');
        END IF;
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM ******* Engine Profile 1 *******
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql19(){var row = document.getElementById("s1sql19");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=2 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv128"></a>
prompt     <a name="top"><b><font size="+2">Engine Profiles INIT_PARAMS_1</font></B></a><br>
prompt     <a name="top"><font size="+1">Each engine profile shares or overrides the BASE profile.<br>
prompt     Are you dealing with overrides?<br><br>
prompt     Please note that it is now possible to have multiple profile for the engine and you might have some overriding parameters<br>
prompt     in other init_params_xxx file.  Please check your schema to see if you have any additional init_params_xxx that might have<br>
prompt     overriding parameters.  Check for the INIT_PARAMS_TABLE_NAME that you are using for the engine run and query the table.<br>
prompt     For example, if you have INIT_PARAMS_1 as the data in the INIT_PARAMS_TABLE_NAME for your engine run, then run the query below:<br><br>
prompt     select * from init_params_1;<br><br>
prompt     Check that there are no parameter entries such as last_date, last_date_backup, lead or RunInsertUnits.  These parameters will take<br>
prompt     precedence over the corresponding parameters in init_params_0.</font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql19()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql19" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt       To show Defaults use this :<br>
prompt       select * from init_params_0;<br><br>
prompt       To show Overriding settings use this :<br>
prompt       select * from init_params_1
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Description</B></TD></TR>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(40);
v_string varchar2(400);
v_desc varchar2(255);

Begin

stmt_str:= 'select pname, value_string, description from '||:gv_schema||'.'||'init_params_1';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname, v_string, v_desc;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_string, (null))||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_desc, (null))||'</TD><TR>');
         IF v_pname='log.history' THEN
           dbms_output.put_line('<TD>'||'Demantra Log.History Parameter Clarification, a supplement to what is found in the Demantra Implementation Guide (Doc ID 761234.1)'||'</TD>');
        END IF;
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>




REM **************************************************************************************** 
REM Business Logic Engine APS_PARAMS Parameter Check
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql20(){var row = document.getElementById("s1sql20");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv129"></a>
prompt     <a name="top"><b><font size="+2"> Business Logic Engine APS_PARAMS Parameter Check </font></B></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql20()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql20" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="45">
prompt       <blockquote><p align="left">
prompt          select * from schemaXXX.aps_params ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(60);
v_value varchar2(1000);
v_val_nbr number;
v_comments varchar2(1000);

Begin

stmt_str:= 'select pname, value_number from '||:gv_schema||'.'||'aps_params order by pname';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname,v_val_nbr;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
--        dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
--         dbms_output.put_line('<TD>'||v_value||'</TD>');
--         dbms_output.put_line('<TD>'||v_comments||'</TD>');
        IF v_pname='BLEThreadPoolSize' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||v_val_nbr||'</TD>');
	   dbms_output.put_line('<TD>'||'Visible only to owner.  Number of threads that the Business Logic Engine can use.  If the DB server has 2 dual core processors the BLEThreadPoolSize<br>');
           dbms_output.put_line('can go as high as (2x2)+1.  For Server Extensions, you can try increasing the amount of pool size for the BLE.<br>');
           dbms_output.put_line('This change should be done carefully as to not apply database overhead. It should not exceed the number of the database server CPU x 2 + 1.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='BLETimeOut' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||v_val_nbr||'</TD>');
	   dbms_output.put_line('<TD>'||'Length of time, in milliseconds, before an idle thread (of the Business Logic Engine) times out.'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.data.batch.size' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||v_val_nbr||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel batch (Integration/BLE) update processes, app server handle at a time.'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.table.batch.size' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||v_val_nbr||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel batch (Integration/BLE) update tables, app server handle at process.'||'</TD></TR>');
        END IF;
        IF v_pname='Threadpool.update.comb.batch.size' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||v_val_nbr||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel batch (Integration/BLE) update combs, app server handle at a table.'||'</TD></TR>');
        END IF;
        IF v_pname='Threadpool.update.record.batch.size' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||v_val_nbr||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel batch (Integration/BLE) update records, app server handle at a comb.'||'</TD></TR>');
        END IF;
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM **************************************************************************************** 
REM Verify engineplatform
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql21(){var row = document.getElementById("s1sql21");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv130"></a>
prompt   <a name="top"><b><font size="+2"> Verify engineplatform </font></b></a><br>
prompt   <a name="top"><font size="+1"The operating system platform on which the engine is executed.  Set to 1 for Linux.<br>
prompt   You can update these parameters either in Business Modeler (Parameters > System Parameters, System tab), or by <br>
prompt   performing the following update statement:<br><br>
prompt   UPDATE SYS_PARAMS SET pval = '1' WHERE lower(pname) = 'engineplatform'<br>
prompt   For additional details, please see MyOracleSupport note: Demantra Engine on Linux or Unix Failure Hanging Error Not Starting Debugging Install and Configuration Checklist, 1086704.1</font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql21()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql21" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="1" height="185">
prompt       <blockquote><p align="left">
prompt          select pval from SYS_PARAMS WHERE lower(pname) = 'engineplatform' ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_value varchar2(100);

Begin

stmt_str:= 'select pval from '||:gv_schema||'.'||'sys_params where lower(pname) = ''engineplatform''';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_value;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        dbms_output.put_line('<TR><TD>'||nvl(v_value, (null))||'</TD></TR>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM **************************************************************************************** 
REM Verify EngineBaseURL
REM **************************************************************************************** 

prompt <script type="text/javascript">    function displayRows1sql22(){var row = document.getElementById("s1sql22");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv131"></a>
prompt     <a name="top"><b><font size="+2"> Verify enginebaseURL </font></B></a><br><br>
prompt     <a name="top"><font size="+1"> The base URL to be used to execute the engine.  This is applicable to Linux/Unix.<br>
prompt        You can update these parameters either in Business Modeler (Parameters > System Parameters, System tab), or by performing<br> 
prompt        the following update statement:<br><br>
prompt        UPDATE SYS_PARAMS SET pval = '#URL#' WHERE lower(pname) = 'enginebaseurl'<br><br>
prompt        See Development Sponsored note Demantra Engine on Linux Install Upgrade Troubleshooting Configuration - Re-written, April 2014, 9th Revision, Doc ID 1389868.1</font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql22()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql22" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="1" height="185">
prompt       <blockquote><p align="left">
prompt          select pval from SYS_PARAMS WHERE lower(pname) = 'EngineBaseURL' ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_value varchar2(100);

Begin

stmt_str:= 'select pval from '||:gv_schema||'.'||'sys_params where lower(pname) = ''enginebaseurl''';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_value;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        dbms_output.put_line('<TR><TD>'||nvl(v_value, (null))||'</TD></TR>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM Is the Engine Running?  Where?
REM ****************************************************************************************

prompt <script type="text/javascript">    function displayRows1sql23(){var row = document.getElementById("s1sql23");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv132"></a>
prompt     <a name="top"><b><font size="+2"> Is the Engine Running?  Where? </font></B></a><br><br>
prompt     <a name="top"><font size="+1"> The Demantra engine runs periodically, it is not running at all times.  The run of the Analytical engine varies with the planning cycle you have adopted<br>
prompt   in your system.  Mostly it is either monthly or weekly.  The engine status can be checked from forecast_history table:<br>
prompt   *  -2: Engine was never executed<br>
prompt   *  -1: Engine manager is doing some initialization for engine to run<br>
prompt   *   0: Engine is running normally<br>
prompt   *   1: Engine run has completed successfully<br>
prompt   *   2: configuration problems<br><br>
prompt        check EngineManager.log<br>
prompt        check ENGINE_ROOT, LD_LIBRARY_PATH, ORACLE_HOME<br>
prompt        Check EngineURL parameter finishes with / in sys_params table<br><br>
prompt      * It is important to stop Engine in Simulation mode before you start it in the batch <br>
prompt        mode.  Before starting in the batch mode make sure there is no Engine.exe running. <br><br>
prompt      * To start the engineStarter<br>
prompt        cd $ENGINE_ROOT/lib<br>
prompt       ./EngineStarter 12345 &  <-Port number from settings.xml<br><br>
prompt      * To stop engineStarter, use the following command:<br>
prompt        ps -ef | grep EngineStarter | grep -v grep | awk '{print $2}' | xargs kill -9<br><br>
prompt      * Alternatively you can run $ENGINE_ROOT/bin/kill_all_engine.sh<br>
prompt       script which seeks and kills all old engine related processes<br><br>
prompt      * On Linux platforms, the engine is Application Server compatible. You can<br>
prompt        use a browser to start, stop, and restart it.<br></font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql23()" >SQL Script</button></div></TD>
prompt </TR>
prompt <TR id="s1sql23" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="5" height="185">
prompt       <blockquote><p align="left">
prompt          select * from forecast_history order by 5 desc;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Date</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Start Date</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Time SIG</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Description</B></TD>

exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_value varchar2(200);
v_last date;
v_start date;
v_time date;
v_status number;
v_desc varchar2(30);
Begin


stmt_str:= 'select last_date, start_date, time_sig, status, substr(forecast_description,1,30) from '||:gv_schema||'.'||'forecast_history order by 3 desc';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_last, v_start, v_time, v_status, v_desc;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        dbms_output.put_line('<TR><TD>'||v_last||'</TD>');
        dbms_output.put_line('<TD>'||v_start||'</TD>');
        dbms_output.put_line('<TD>'||v_time||'</TD>');
        dbms_output.put_line('<TD>'||nvl(v_status, (null))||'</TD>');
        dbms_output.put_line('<TD>'||nvl(v_desc, (null))||'</TD><TR>');
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM ******* Parameter MaxEngMemory *******
REM ****************************************************************************************

prompt <script type="text/javascript">    function displayRows1sql24(){var row = document.getElementById("s1sql24");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv133"></a>
prompt     <a name="top"><b><font size="+2"> Parameter MaxEngMemory </font></B></a><br>
prompt     <a name="top"><font size="+1"> This parameter should always be set to 100.  As the engine processes individual nodes for a very large branch eventually it reaches the limitations<br>
prompt     of available memory which results in an error containing the text �threw Matlab exception: A memory allocation request failed�<br>
prompt     As each engine task is completed, the Engine Manager evaluates the amount of memory currently used by all analytical engine processes on the machine.<br>
prompt     If this amount in megabytes exceeds the value of MaxEngMemory, the engine instance is stopped and a new instance is initiated.<br></font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql24()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql24" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="1" height="185">
prompt       <blockquote><p align="left">
prompt       select value_string from init_params_0 where pname = 'MaxEngMemory';<br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Numeric Value</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_val number;

Begin

stmt_str:= 'select decode(value_string, null, 0, value_string) from '||:gv_schema||'.'||'init_params_0 where pname = ''MaxEngMemory''';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_val;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TD>'||nvl(v_val, (null))||'</TD>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM ******* Distributed Engine Check *******
REM ****************************************************************************************

prompt <script type="text/javascript">    function displayRows1sql25(){var row = document.getElementById("s1sql25");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv134"></a>
prompt     <a name="top"><b><font size="+2"> Distributed Engine </font></B></a><br>
prompt     <a name="top"><font size="+1">How to setup other servers (Windows only machines until v73) so it can work as slave/distributed machines to the master Engine.<br>
prompt How to set up and register the slave/distributed engines on those blades/machines.  MOS document 751772.1 covers two deployments; Windows and Linux.  Read the Windows<br>
prompt information even if you are deploying on Linux.  There is useful information in that section for Linux deployments.<br><br>
prompt In some versions there is a hidden parameter, not visible through<br>
prompt     Business Modeler --> Parameters --> System Parameters, called Distributed_Analytical_Engine which needs to be set to 1.  If it is not set to 1 then update the column to 1 plus commit.<br><br>
prompt     For additional information see Distributed Engine: How to setup another windows server so it can work as another Engine? document 751772.1.<br></font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql25()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql25" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="1" height="185">
prompt       <blockquote><p align="left">
prompt       select value_string, description from init_params_0 where  pname = 'Distributed_Analytical_Engine';
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Description</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_desc varchar2(200);
v_value_string varchar2(100);

Begin

stmt_str:= 'select value_string, description from '||:gv_schema||'.'||'init_params_0 where  pname = ''Distributed_Analytical_Engine''';

     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_value_string, v_desc;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||nvl(v_value_string, (null))||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_desc, (null))||'</TD></TR>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM ******* Determine if the Engine Failed *******
REM ****************************************************************************************

prompt <script type="text/javascript">    function displayRows1sql26(){var row = document.getElementById("s1sql26");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv135"></a>
prompt     <a name="top"><b><font size="+2"> Determine if the Engine Failed </font></B></a><br>
prompt     <a name="top"><font size="+1">What you are looking for is a status = 1 (success) for the latest engine run as indicated by the time_sig (date of engine run).<br>
prompt     If it is not equal to 1 then review the engine manager logs as per the Errors with the Demantra Batch or Simulation Engine section<br>
prompt     of Note 741464.1 and corrective actions should be taken and/or a Support Request should be entered.<br><br>
prompt     Status = 2 - shows configuration problems - check ENGINE_ROOT, LD_LIBRARY_PATH, ORACLE_HOME</font></a></TD><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql26()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql26" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="1" height="185">
prompt       <blockquote><p align="left">
prompt      select time_sig,<br>
prompt      status,<br>
prompt      engine,<br>
prompt      substr(engine_version,1,10),<br>
prompt      engine_profiles_id,<br>
prompt      substr(init_params_table_name,1,20)<br>
prompt      from msdem.forecast_history<br>
prompt      order by time_sig desc;<br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Time_Sig</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Status</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Engine</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Engine_Version</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Engine_Profiles_ID</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Init_Params_Table_Name</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_time_sig date;
v_status number;
v_engine number;
v_engine_version varchar2(10);
v_engine_profiles_id number;
v_init_params_table_name varchar2(20);

Begin

stmt_str:= 'select time_sig, status, engine, substr(engine_version,1,10), engine_profiles_id, substr(init_params_table_name,1,20) from '||:gv_schema||'.'||'forecast_history order by time_sig desc';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_time_sig, v_status, v_engine, v_engine_version, v_engine_profiles_id, v_init_params_table_name;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||nvl(v_time_sig,(null))||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_status,(null))||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_engine,(null))||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_engine_version,(null))||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_engine_profiles_id,(null))||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_init_params_table_name, (null))||'</TD></TR>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *******************************************************************************
REM ****************************  Worksheet RELATED  *****************************
REM *******************************************************************************


REM *******************************************************************************
REM ******************  Configurable Combinations in the Worksheet  ***************
REM *******************************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Configurable Combinations in the Worksheet</font></b></a></p><br>
prompt     <a name="top"><font size="+1">The number of combinations allowed is configurable, and, of course, depends on available resources, i.e., memory (client side).<br>
prompt  The UI Limitations feature, introduced in v7.3.0 controls these configurations. This feature was introduced in order to protect client side from out of memory via "bad"<br>
prompt  configuration worksheet (i.e., too much data).  It uses heuristic methods to pre-calculate the "weight" of a worksheet, compares that weight with the configured limitations,<br>
prompt  and pops-up the message, if the weight exceeds the limitations set.  Following please find the parameters needs to be set (using the Business Modeler) for configuring UI limitations:<br><br>
prompt  client.uilimitations.maxcombs.ws<br>
prompt  The maximum amount of combinations that can be retrieved for a single worksheet.<br>
prompt  Default value: 2000.<br><br>
prompt  client.uilimitations.maxcells.ws<br>
prompt  The maximum number of cells allowed for a single worksheet (crosstab) (memory limit per Worksheet).<br>
prompt  If this parameter is set to a larger value than client.uilimitations.maxcells, then client.uilimitations.maxcells value is used instead.<br>
prompt  Default value: 100000.<br><br>
prompt  client.uilimitations.maxcells<br>
prompt  The maximum number of cells allowed totally for the client (memory limit per client)<br>
prompt  Default value: 300000.<br><br>
prompt  client.uilimitations.maxdiskspace<br>
prompt  Maximum disk space allowed to be used by the LRU Disk Cache in Kb.<br>
prompt  Default value: 200000.<br><br>
prompt  client.uilimitations.warning<br>
prompt  The percentage out of the client.uilimitations.maxxxx parameters to which to display the warning messages upon. For example, if the max combs is 1000 and this value is 80(%),<br>
prompt  then when trying to load 800 combinations - the warning message will be displayed to the client.  If user has entered 0, it is ignored and the default value is used instead.<br>
prompt  If this value is 100, no warnings will be displayed, since the error messages precedes it.<br>
prompt  Default value: 80.<br><br>
prompt  max.worksheet.db.weight<br><br>
prompt  The maximum database weight (rows of item/location ratio) allowed to be retrieved for a single worksheet.<br>
prompt  Default value: 0.5.</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>


REM *******************************************************************************
REM ******************  Scalability in the Work Sheet  ***************
REM *******************************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Scalability in the Work Sheet</font></b></a></p><br>
prompt     <a name="top"><font size="+1">First, the client side memory should be configured appropriately.  If this is a large worksheet then by all means the Java Console configuration must match<br>
prompt   the required memory. I would start there.<br>
prompt   Second, review the amount of data being loaded by the worksheet, the amount of combinations loaded, the structure of the crosstab can be modified, the series which are included in the<br>
prompt   worksheet, the amount of views presented for the worksheet on screen and any options for further filtering of the worksheet.<br><br>
prompt   How many cells are in the crosstab?   Sample config:<br><br>
prompt   If the worksheet has 1487 combinations and all are in the crosstab.  There are 13 visible series in the worksheet, so assume there are at least 20 series overall, including hidden.<br>
prompt   20 series x 52 buckets x 1487 combinations = 1,546,480cells in the crosstab.  That is a large number.  This worksheet is big in terms of memory consumption, network traffic and since all<br>
prompt   combinations are included in the crosstab it would be slow.</font></a><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>


REM ******************************************************************************************************
REM ******************  worksheet, make use of parallelism by running multiple threads  ******************
REM ******************************************************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Worksheet, Make use of Parallelism by Running Multiple Threads</font></b></a></p><br>
prompt     <a name="top"><font size="+1">The way the worksheets make use of parallelism is by running multiple threads in the Java application server, not at the database.  You can configure this in APP_PARAMS.<br>
prompt     For example, if the following are set:<br>
prompt     threadpool.query_run.size=40<br>
prompt     threadpool.query_run.per_user=4<br>
prompt     - A single user running a worksheet query will have 4 parallel threads accessing the database at the same time.  All users together are limited to 40 threads.<br>
prompt     Parameter Setting<br>
prompt     -----------------<br>
prompt     - There are no valid general recommendations available.    Each implementation is different. <br>
prompt     - The setting for the parameters depends on the number of concurrent users, the number of concurrent batch jobs and their nature, the database hardware configuration and more. <br>
prompt     - Each setting, listed below, has a description and configuration rules that need to be addressed per implementation.<br><br>
prompt     # Maximum size of the Query Run Thread pool, if this value is missing or is negative, the query run execution mechanism will not use threads.<br>
prompt     threadpool.query_run.size=40<br><br>
prompt     # The amount of threads that a single thread can use.  If the query run thread pool size is negative this value is meaningless<br>
prompt     threadpool.query_run.per_user=4<br><br>
prompt     #Number of parallel manual update processes, app server handle at a time.<br>
prompt      threadpool.update.data.manual.size=8<br><br>
prompt     #Number of parallel manual update tables, app server handle at a process.<br>
prompt     threadpool.update.table.manual.size=2<br><br>
prompt     #Number of parallel manual update combs, app server handle at a table.<br>
prompt     threadpool.update.comb.manual.size=2<br><br>
prompt     #Number of parallel manual update records, app server handle at a comb.<br>
prompt     threadpool.update.record.manual.size=2<br><br>
prompt     #Number of parallel batch(Integration/Ble) update processes, app server handle at a time.<br>
prompt     threadpool.update.data.batch.size=2<br><br>
prompt     #Number of parallel batch(Integration/Ble) update tables, app server handle at process.<br>
prompt     threadpool.update.table.batch.size=2<br><br>
prompt     #Number of parallel batch(Integration/Ble) update combs, app server handle at a table.<br>
prompt     threadpool.update.comb.batch.size=2<br><br>
prompt     #Number of parallel batch(Integration/Ble) update records, app server handle at a combination.<br>
prompt     threadpool.update.record.batch.size=2<br><br>
prompt     #Support for parallel integration procedure # Max number of Parallel Update Threads.  Default Threads = 5 (Number of DB Server CPU + 1)<br>
prompt     MaxUpdateThreads=5<br><br>
prompt     First, the client side memory should be configured appropriately.  If this is a large worksheet then by all means the Java Console configuration must match<br></font></a><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>


REM ******************************************************************************************************
REM Worksheet Related Parameters in APS_PARAMS
REM ****************************************************************************************

prompt <script type="text/javascript">    function displayRows1sql27(){var row = document.getElementById("s1sql27");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2" width=100%">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=4 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv136"></a>
prompt     <p><a name="top"><b><font size="+2"> Check Worksheet Related Parameters in APS_PARAMS </font></B></a></p><br>
prompt     <a name="top"><font size="+1">These parameters have direct impact on the performance of the worksheet.</font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql27()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql27" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="160">
prompt       <blockquote><p align="left">
prompt          select jjg* from schemaXXX.aps_params ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value Description</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(40);
v_val_number number;
v_comments varchar2(1000);

Begin


stmt_str:= 'select lower(substr(pname,1,40)), value_number from '||:gv_schema||'.'||'aps_params order by pname';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname, v_val_number;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        IF v_pname='threadpool.query_run.per_user' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'This is the total number of threads allocated for the query run.  This should be adjusted based on the number of concurrent users and the.<br>');
	   dbms_output.put_line('threadpool.query_run.per_user.  Product of the number of concurrent users and threadpool.query_run.per_user.  For example if<br>');
	   dbms_output.put_line('thethreadpool.query_run.per_user is set to 4 and expected number of concurrent users is 10, this parameter should be set to 40.<br>');
	   dbms_output.put_line('MaxDBConnections parameter should also be modified accordingly.  to account for the increase in number of threads for this parameter.<br>');
	   dbms_output.put_line('See Oracle Demantra Parameters for Performance MyOracleSupport Doc ID 1201774.1.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.query_run.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'The amount of threads that a single thread can use.  If the query run thread pool size is negative this value is meaningless<br>'||'</TD></TR>');
        END IF;
        IF v_pname='maxdbconnections' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
           dbms_output.put_line('<TD>'||'It is important to make sure that the application server will have all the needed threads to execute all parallel');
           dbms_output.put_line('requests; query executions, workflow runs, updates, etc.<br>A rule of thumb will be the number of concurrent ');
           dbms_output.put_line('users * threadpool.query_run.per_user *10 (if threadpool.query_run.per_user > 4).'||'</TD></TR>');
        END IF;
        IF v_pname='mindbconnections' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
           dbms_output.put_line('<TD>'||'The minimum number of database connections for the Demantra database user.'||'</TD></TR>');
        END IF;
        IF v_pname='dbidletimeout' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
           dbms_output.put_line('<TD>'||'The connection idle timeout period.  Recommended: 300000 (5 minutes).'||'</TD></TR>');
        END IF;
        IF v_pname='dbconnectiontimeout' THEN
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
           dbms_output.put_line('<TD>'||'The database connection timeout period.'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.data.manual.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel manual update tables, app server handle at a process.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.table.manual.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel manual update combs, app server handle at a table.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.comb.manual.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel manual update records, app server handle at a comb.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.comb.batch.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel batch(Integration/Ble) update records, app server handle at a combination.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.record.manual.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel batch(Integration/Ble) update processes, app server handle at a time.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.data.batch.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel batch(Integration/Ble) update tables, app server handle at process.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.table.batch.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Number of parallel batch(Integration/Ble) update combs, app server handle at a table.<br>'||'</TD></TR>');
        END IF;
        IF v_pname='threadpool.update.record.batch.size' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'Support for parallel integration procedure # Max number of Parallel Update Threads.  Default Threads = 5 (Number of DB Server CPU + 1)<br>'||'</TD></TR>');
        END IF;
        IF v_pname='MaxUpdateThreads' THEN        
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val_number, 0)||'</TD>');
	   dbms_output.put_line('<TD>'||'First, the client side memory should be configured appropriately.  If this is a large worksheet then by all means the Java Console configuration must match<br>'||'</TD></TR>');
        END IF;
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM ***********************************************************
REM ******* Missing Dates in Sales_Data and MDP_Matrix  *******
REM ***********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Missing Dates in Sales_Data and MDP_Matrix</font></b></a></p><br>
prompt     <a name="top"><font size="+1">Are you missing sales dates in the table Sales_Date or MDP_Matrix?  The following two info boxes will reveal both.  For additional information please<br>
prompt   MyOracleSupport note, Not all Members being included in the Demantra Worksheet, Export View is not including all rows, note ID 969874.1</font></a><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows1sql28(){var row = document.getElementById("s1sql28");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF">
prompt     <font face="Calibri"><a name="adv137"></a>
prompt      <a name="top"><b><font size="+2"> Missing Dates in Sales_Data</font></B></a>
prompt     </font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql28()" >SQL Script</button></div>
prompt     </TD>
prompt </TR>
prompt <TR id="s1sql28" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="1" height="60">
prompt       <blockquote><p align="left">
prompt          select count(*) 
prompt          from sales_data 
prompt          where sales_date not in (select datet from inputs);</p>
prompt       </blockquote>
prompt     </TD>
prompt </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD>
prompt </TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_count number;

Begin

stmt_str:= 'select count(*) from '||:gv_schema||'.'||'sales_data where sales_date not in (select datet from '||:gv_schema||'.'||'inputs)';

     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_count;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
         dbms_output.put_line('<TR><TD>'||v_count||'</TD>');
      END LOOP;
     close c1;
END;
/

prompt </TABLE>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


rem ==========   and MDP_Matrix

prompt <script type="text/javascript">    function displayRows1sql29(){var row = document.getElementById("s1sql29");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF">
prompt     <font face="Calibri"><a name="adv80"></a>
prompt      <a name="top"><b><font size="+2"> Missing Dates in MDP_Matrix</font></B></a>
prompt     </font>
prompt   </TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql29()" >SQL Script</button></div>
prompt     </TD>
prompt </TR>
prompt <TR id="s1sql29" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="1" height="60">
prompt       <blockquote><p align="left">
prompt          select count(1) from owner.mdp_matrix where (item_id,location_id) <br>
prompt          not in (select distinct item_id,location_id from owner.sales_data) and (prediction_status=1 or (prediction_status=98 and aggri_98=1) or (prediction_status=99 and aggri_99=1));</p>
prompt       </blockquote>
prompt     </TD>
prompt </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD>
prompt </TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_count number;

Begin

stmt_str:= 'select count(1) from '||:gv_schema||'.'||'mdp_matrix where (item_id,location_id) not in (select distinct item_id,location_id from '||:gv_schema||'.'||'sales_data) and (prediction_status=1 or (prediction_status=98 and aggri_98=1) or (prediction_status=99 and aggri_99=1))';

     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_count;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
         dbms_output.put_line('<TR><TD>'||v_count||'</TD>');
      END LOOP;
     close c1;
END;
/

prompt </TABLE>


exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>




REM ****************************************************************************************
REM Verify Tablespace PARAMS
REM ****************************************************************************************

prompt <script type="text/javascript">    function displayRows1sql30(){var row = document.getElementById("s1sql30");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv138"></a>
prompt     <a name="top"><b><font size="+2"> Verify Tablespace Parameters </font></B></a)<br>
prompt     <a name="top"><font size="+1">Verify that the six system parameters specifying engine used tablespaces are set correctly. <br></font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql30()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql30" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt          select pname, pval from sys_params where pname like '%space' ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(60);
v_value varchar2(100);

Begin

stmt_str:= 'select pname, pval from '||:gv_schema||'.'||'sys_params where pname like ''%space''';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname,v_value;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
        dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
        dbms_output.put_line('<TD>'||nvl(v_value,(null))||'</TD>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ****************************************************************************************
REM ******* Combinations that meet the rule for Insert_Units *******
REM ****************************************************************************************

prompt <script type="text/javascript">    function displayRows1sql31(){var row = document.getElementById("s1sql31");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv139"></a>
prompt     <a name="top"><b><font size="+2"> Combinations that meet the rule for future forecast date buckets created by Insert_Units  </font></B></a><br>
prompt     <a name="top"><font size="+1">Do you have at least 1 combination that meets the rule for Insert_Units to work on and insert rows into the future:<br>
prompt     More information on how future buckets are created and/or if you find that no combinations are eligible per the results of the above SQL<br>
prompt     are found in Note 452817.1  - How To Get Forecasting Buckets Generated For The Entire Horizon When The Item Location Combination Is Dead.<br></font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql31()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql31" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="1" height="185">
prompt       <blockquote><p align="left">
prompt       select count(*) from mdp_matrix where level_id > 0 and prediction_status <> 99 and do_fore <> 0;<br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Eligible</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_val number;

Begin

stmt_str:= 'select count(*) from '||:gv_schema||'.'||'mdp_matrix where level_id > 0 and prediction_status <> 99 and do_fore <> 0';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_val;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TD>'||v_val||'</TD>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM *********************************************************
REM ******* All System Statistics ***************************
REM *********************************************************
REM 
REM prompt <script type="text/javascript">    function displayRows1sql32(){var row = document.getElementById("s1sql32");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
REM prompt <TABLE border="1" cellspacing="0" cellpadding="2">
REM prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
REM prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv140"></a>
REM prompt     <a name="top"><b><font size="+2"> System Statistics</font></B></a></font></TD>
REM prompt     <TD bordercolor="#DEE6EF">
REM prompt       <div align="right"><button onclick="displayRows1sql32()" >SQL Script</button></div>
REM prompt   </TD>
REM prompt </TR>
REM prompt <TR id="s1sql32" style="display:none">
REM prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
REM prompt       <blockquote><p align="center">
REM prompt      Select STATISTIC#,<BR>
REM prompt      NAME,<BR>
REM prompt      CLASS,<BR>
REM prompt      VALUE<BR>
REM prompt      from v$sysstat<BR>
REM prompt      order by class<BR>
REM prompt       </blockquote>
REM prompt     </TD>
REM prompt   </TR>
REM prompt <TR>
REM prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Statistic_#</B></TD> 
REM prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD> 
REM prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Class</B></TD> 
REM prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD> 
REM exec :n := dbms_utility.get_time;
REM select
REM '<TR><TD>'||STATISTIC#||'</TD>'||chr(10)||
REM '<TD>'||name||'</TD>'||chr(10)|| 
REM '<TD>'||class||'</TD>'||chr(10)|| 
REM '<TD>'||value||'</TD><TR>' 
REM FROM v$sysstat
REM order by class;
REM 
REM prompt </TABLE>
REM 
REM exec :n := (dbms_utility.get_time - :n)/100;
REM exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
REM 
REM prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>
REM 
REM 

REM *******************************************************************************
REM ****************************  Workflow RELATED  *******************************
REM *******************************************************************************

REM ****************************************************************************************
REM ******* Data Load / Work Flow Check *******
REM ****************************************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> Data Load / Work Flow Check </font></b></a><br>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> Verify the workflow Status </font></b></a><br>
prompt     <a name="top"><font size="+1"> Run the following: begin APPS.MSD_DEM_SOP.LOAD_PLAN_DATA (:supply_plan_id);<BR>
prompt     end; <BR>
prompt     Check Exception Detection WF step: <BR>
prompt     "LaunchSupplyPlanExceptionDetection" of schema before running it under the right user, make sure it has executed correctly.
prompt  </font></a></TD>
prompt  </td></tr></tbody> 
prompt  </table><BR><BR>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> Verify Data in the Staging Tables + Errors </font></b></a><br>
prompt     <a name="top"><font size="+1"> Run the following SQL:<BR>
prompt     select * from biio_supply_plans<BR>
prompt     select * from biio_supply_plans_pop<BR>
prompt     select * from biio_other_plan_data<BR>
prompt     select * from t_src_item_tmpl<BR>
prompt     select * from t_src_loc_tmpl<BR>
prompt     select * from BIIO_PURGE_PLAN<BR><BR>
prompt     Check for Errors: <BR>
prompt     select * from BIIO_SUPPLY_PLANS_err<BR>
prompt     select * from BIIO_SUPPLY_PLANS_POP_err<BR>
prompt     select * from BIIO_OTHER_PLAN_DATA_ERR<BR>
prompt     "LaunchSupplyPlanExceptionDetection" of schema before running it under the right user, make sure it has executed correctly.
prompt  </font></a></TD>
prompt  </td></tr></tbody> 
prompt  </table><BR><BR>
prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <a name="top"><b><font size="+2"> Enhancement on Collaborator.log file</b><br>
prompt    <../conf - file logconf.lcf -- remove the hash sign in front of the specific line #<br>
prompt    or from your portal page http://..........>/demantra/admin/loggerManager.jsp<br>
prompt    The only difference is that in the first case restart the web server and after solving the problem - you have to revert changes in order not to affect performance.<br>
prompt     log4j.category.appserver.workflow.general=DEBUG<br>
prompt     log4j.category.appserver.workflow.steps=DEBUG<br>
prompt     log4j.category.appserver.workflow.timing=DEBUG<br>
prompt     log4j.category.workflow.general=DEBUG<br>
prompt     Test again, check on the time stamp when the issue occurred.<br>
prompt  </font></a></TD>
prompt  </td></tr></tbody> 
prompt  </table><BR><BR>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR


REM *******************************************************************************
REM ****************************  Workflow RELATED END  ***************************
REM *******************************************************************************


REM *******************************************************************************
REM ****************************  EP_LOAD RELATED  ********************************
REM *******************************************************************************


prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">EP Load Parameters</font></b></a></p><br>
prompt     <a name="top"><font size="+1">The EP LOAD procedures in 7.3.1.4 and above are when compared to prior versions.<br>
prompt 1. EP LOAD procedures use dynamically code to process staging tables.  This avoids the EP LOAD procedures from getting INVALID status when staging tables are modified.<br>
prompt 2. The dynamic code removed the need for EP_LOAD_SALES to recompile other dependent procedures.<br>
prompt 3. EP_LOAD_SALES is designed to try to insert data according to the primary key to reduce chaining / fragmentation.<br>  
prompt 4. Improved logging : DB_SECTION_LOG and DB_TIMING_LOG now show which column was used for the SALES_DATA MERGE loop and how many time it looped rounds (ie how many MERGES it ran).<br>
prompt Key Logs for loading:<br>
prompt - DB_TIMING_LOG This logs how long specific procedures take to complete with processed row count(s)<br>
prompt - DB_SECTION_LOG This logs how long specific section in a procedure takes to complete with processed row count(s)<br>
prompt   *  DB_SECTION_LOG and DB_TIMING_LOG now show which column was used for the SALES_DATA MERGE loop and how many times it looped (ie how many MERGES it ran)<br>
prompt - DB_EXCEPTION_LOG<br>
prompt * The DB_EXCEPTION_LOG table stores logging information during CTO calculations and it stores many processing exceptions.<br><br>
prompt To produce detailed log files for the EP_LOAD EP LOAD process.  The log files include:<br>
prompt   - DB_TIMING_LOG<br>
prompt   - DB_SECTION_LOG<br>
prompt   - DB_EXCEPTION_LOG<br>
prompt   - DB_WARNING_LOG<br>
prompt   - INTEG_STATUS<br>
prompt   - LOG_EP_LOAD_ITEMS<br>
prompt     * This should show us exactly which level has an issue<br><br>
prompt To evalute the EP LOAD process, in addition to the log files, check the following using select * from:<br>
prompt   - INTEG_STATUS<br>
prompt   - LOG_EP_CHECK_ITEMS<br>
prompt   - LOG_EP_CHECK_LOCATION<br>
prompt   - LOG_EP_LOAD_ITEMS<br>
prompt   - LOG_EP_LOAD_LOCATIONS<br>
prompt   - LOG_EP_LOAD_SALES<br>
prompt   - LOG_EP_LOAD_MDP_LEVEL<br>
prompt   - LOG_MDP_ADD<br>
prompt Review db_audit_log table for object changes made by the upgrade<br>
prompt   - DB_Exception_Log table LOG_DATA_MODEL table (an automatic LOG_IT log).<br><br>
prompt If any of the below parameters are changed then the load procedures will need re-generating.<br>
prompt Run as the demantra schema owner using SQLplus or SQL Developer.<br>
prompt If you change any of the EP_LOAD paramters below, you will have to follow the steps to reset:<br>
prompt EXEC CALL_DM_BUILD_PROCEDURES;<br>
prompt EXEC BUILD_ORDER_COMPILE;<br>
prompt EXEC COMPILE_ALL; </font></a>
prompt </td></tr></tbody> 
prompt </table><BR><BR>


REM ****************************************************************************************
REM DB_PARAMS
REM ****************************************************************************************

prompt <script type="text/javascript">    function displayRows1sql33(){var row = document.getElementById("s1sql33");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=3 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv142"></a>
prompt     <a name="top"><b><font size="+2"> DB_PARAMS EP_Load Check </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows1sql33()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s1sql33" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="3" height="45">
prompt       <blockquote><p align="left">
prompt          select * from schemaXXX.db_params ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE	IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(35);
v_value varchar2(40);
v_comments varchar2(1000);

Begin

stmt_str:= 'select substr(pname,1,35), substr(value_string,1,40) from '||:gv_schema||'.'||'aps_params order by pname';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname,v_value;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
--        dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
--         dbms_output.put_line('<TD>'||v_value||'</TD>');
--         dbms_output.put_line('<TD>'||v_comments||'</TD>');
        IF v_pname='ep_load_sales_loadnullactualqty' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_value, (null))||'</TD>');
	   dbms_output.put_line('<TD>'||'Settings are TRUE or FALSE, the Default is FALSE.<br>');
	   dbms_output.put_line('When FALSE, EP_LOAD_SALES excludes loading data with NULL values in the ACTUAL_QTY from the T_SRC_SALES table. <br>');
	   dbms_output.put_line('When FALSE, ACTUAL_QTY = NULL are treated as an error and are moved to the %_ERR table.  Whether TRUE or FALSE, combinations<br>');
	   dbms_output.put_line('with ACTUAL_QTY = NULL will still be added to MDP_MATRIX.  For customers that want to load both sales with ACTUAL_QUANTITY = null<br>');
	   dbms_output.put_line('and sales with ACTUAL_QUANTITY not null, submit the following:<br>');
	   dbms_output.put_line('UPDATE db_params set pval = TRUE WHERE pname = Ep_Load_Sales_LoadNullActualQty<br>');
	   dbms_output.put_line('COMMIT'||'</TD></TR>');
        END IF;
        IF v_pname='ep_load_sales_loadfromstagingtabledirectly' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_value, (null))||'</TD>');
	   dbms_output.put_line('<TD>'||'Settings are TRUE or FALSE, the Default is TRUE.<br>');
	   dbms_output.put_line('When set to TRUE, the EP_LOAD_SALES procedure will load sales directly from the sales staging table.<br>');
	   dbms_output.put_line('When set to FALSE, EP_LOAD_SALES copies the staging table to a loading table.<br>');
	   dbms_output.put_line('The performance saving here is in the time avoiding the table copy.'||'</TD></TR>');
        END IF;
        IF v_pname='ep_load_sales_disableenabletriggers' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_value, (null))||'</TD>');
	   dbms_output.put_line('<TD>'||'Settings are TRUE or FALSE, the Default is TRUE<br>');
	   dbms_output.put_line('When set to TRUE the EP_LOAD_SALES procedure will identify enabled seeded triggers on SALES_DATA and will disable them.<br>');
	   dbms_output.put_line('When the sales are loaded the triggers will be re-enabled.  The triggers are used to synchronize specific series between<br>');
	   dbms_output.put_line('SALES_DATA and PROMOTION_DATA.  The sales series are not part of the sales load.<br>');
 	   dbms_output.put_line('The performance saving here the updates in the triggers are not fired.  If these seeded triggers have been customized then<br>');
 	   dbms_output.put_line('you may want to set this parameter to FALSE.<br>'||'</td></tr>');
        END IF;
        IF v_pname='ep_load_sales_reportnullactualqty' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_value, (null))||'</TD>');
	   dbms_output.put_line('<TD>'||'Settings are TRUE or FALSE, the Default is TRUE.<br>');
	   dbms_output.put_line('This is a new parameter for 7.3.1.4 and 12.2.0.  It has been added to enable EP_LOAD_SALES to behave as it previously did.<br>');
	   dbms_output.put_line('Previously EP_LOAD_SALES would load sales with ACTUAL_QTY = NULL into MDP_MATRIX only.  No errors for these sales would be recorded.<br>');
	   dbms_output.put_line('The new parameter Ep_Load_Sales_LoadNullActualQty allows you to now load ACTUAL_QTY = NULL into SALES_DATA.<br>');
	   dbms_output.put_line('When Ep_Load_Sales_LoadNullActualQty is FALSE it treats ACTUAL_QTY = NULL as error sales, reporting them via the T_SRC_SALE_TMPL_ERR table.<br>');
	   dbms_output.put_line('Having the following (default) settings allows  ACTUAL_QTY = NULL sales  to be loaded to MDP_MATRIX and not reported as errors.<br>');
	   dbms_output.put_line('Ep_Load_Sales_LoadNullActualQty = FALSE<br>');
	   dbms_output.put_line('and<br>');
	   dbms_output.put_line('Ep_Load_Sales_ReportNullActualQty = FALSE<br>'||'</TD></TR>');
        END IF;
        IF v_pname='ep_load_sales_sales_data_merge_loopcontrol' THEN
	   dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
	   dbms_output.put_line('<TD>'||nvl(v_value, (null))||'</TD>');
	   dbms_output.put_line('<TD>'||'This parameter is an override for the choice of SALES_DATA MERGE commit level control.<br>');
           dbms_output.put_line('This is an existing parameter, but the value may need re-setting.<br>');
           dbms_output.put_line('EP_LOAD_SALES, by default uses a cursor loop over then T_SRC_SALES_TMPL table to enable the MERGE to SALE_DATA to have a commit control.<br>');
           dbms_output.put_line('The default commit control is set as the leading SALES_DATA primary key column, and is used to try to reduce fragmentation and row chaining.<br>');
           dbms_output.put_line('The SALES_DATA primary key is mapped to load columns in the T_SRC_SALES_TMPL table.  The load columns will be added to and removed from T_SRC_SALES_TMPL during the load process.<br>');
           dbms_output.put_line('SALES_DATA.ITEM_ID = T_SRC_SALES_TMPL.LD_ITEM_ID<br>');
           dbms_output.put_line('SALES_DATA.LOCATION_ID = T_SRC_SALES_TMPL.LD_LOCATION_ID<br>');
           dbms_output.put_line('SALES_DATA.SALES_DATE = T_SRC_SALES_TMPL.AGGRE_SD<br><br>');
           dbms_output.put_line('Ep_Load_Sales_SALES_DATA_Merge_LoopControl is not used when Ep_Load_Sales_SALES_DATA_Merge_InOneMerge = TRUE<br>');
           dbms_output.put_line('This parameter should be set by the customer if needed.<br>');
           dbms_output.put_line('The parameter can be set as null or any column in T_SRC_SALES_TMPL or LD_ITEM_ID, LD_LOCATION_ID, AGGRE_SD.<br>');
           dbms_output.put_line('A knowledge of the volumes in a level column and the typical load amount is important when setting this parameter.<br>');
           dbms_output.put_line('For customers that load many weeks of data in one load.  When SALES_DATE is not the leading primary key column and AGGRE_SD is a good commit control column.<br>');
           dbms_output.put_line('AGGRE_SD is the sales date of the staging sales_date converted to match the model time bucket resolution.<br>');
           dbms_output.put_line('UPDATE db_params set pval = AGGRE_SD WHERE pname = Ep_Load_Sales_SALES_DATA_Merge_LoopControl<br>');
           dbms_output.put_line('COMMIT;<br>'||'</TD></TR>');
        END IF;
      END LOOP;
       close c1;
END;
/

prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Additional EP_LOAD parameters</font></b></a></p><br>
prompt     <a name="top"><font size="+1">Parameter: Ep_Load_ItemsUseParallelDML<br>
prompt Default value: FALSE<br>
prompt Description: Two possible values:<br>
prompt TRUE = use PARALLEL DML on objects that are set as parallel.<br>
prompt FALSE = do not use PARALLEL DML on objects that are set as parallel.<br><br>
prompt Parameter: Ep_Load_ItemsUseParallel<br>
prompt Default value: TRUE<br>
prompt Description: Two possible values:<br>
prompt TRUE = EP_LOAD_ITEMS use parallel hints<br>
prompt FALSE = EP_LOAD_ITEMS does not use parallel hints<br><br>
prompt Parameter: Ep_Load_ItemsUseOneCommit<br>
prompt Default value: FALSE<br>
prompt Description: Two possible values:<br>
prompt TRUE = EP_LOAD_ITEMS use only one commit<br>
prompt FALSE = EP_LOAD_ITEMS does not use only one commit</font></a>
prompt </td></tr></tbody> 
prompt </table><BR><BR>


prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


prompt <table border="1" name="CyanBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Clean Up Between Data Loads </font></b></a></p><br>
prompt  <a name="top"><font size="+1">It is important to clean the datastore between data load submissions.  The procedures below will clean most of the objects related to the data load.<br>
prompt  Along with clean import tables, it is important to clear your caches.  To clear the cache, see Clearing Cache below.<br>
prompt  Data Cleanup Procedures:<br>
prompt  EXECUTE DATA_CLEANUP.clean_schema_temps(commit_point NUMBER DEFAULT DEFAULT_COMMIT_POINT );<br>
prompt  EXECUTE DATA_CLEANUP.CLEAN_LEVEL_DATA; COMMIT;<br>
prompt  EXECUTE DATA_CLEANUP.clean_schema_int(commit_point NUMBER DEFAULT DEFAULT_COMMIT_POINT);<br><br>
prompt  Are you looking at older cached System Logs?<br>
prompt    For IE, Hold the Ctrl key and press the F5 key<br>
prompt  Or, hold the Ctrl key and click the Refresh button on the toolbar<br>
prompt    For FF, hold down the Ctrl key and then press F5<br>
prompt  Or, hold down both the Ctrl and Shift keys and then press R<br>
prompt    For Chrome Either: Hold the Ctrl key and press F5<br>
prompt  Or, hold the Ctrl key and click Reload button<br>
prompt    All logs will have a suffix of .log<br>
prompt    bal_log.txt is the only exception<br><br>
prompt </font></a></td></tr></tbody></table>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM ********************************************************************************************************
REM ****************************  EP_LOAD RELATED MyOracleSupport Reference ********************************
REM ********************************************************************************************************

prompt <table border="1" name="CyanBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">EP_LOAD RELATED MyOracleSupport Reference </font></b></a></p><br>
prompt  <a name="top"><font size="+1">EBS to Demantra Data Load / Import Diagnostics Investigation (Doc ID 809410.1)<br>
prompt  Demantra Shipment and Booking History Collection - Loading Custom Data (Doc ID 1577700.1)<br>
prompt  Collect Shipment And Booking History Failing With ORA-01555 Error (Doc ID 1466844.1)<br>
prompt  Demantra Product Category From EBS (Doc ID 750020.1)<br>
prompt </font></a></td></tr></tbody></table>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



rem select * from wf_schemas where application_id = 'WF_SCHEMA:631'


REM *******************************************************************************
REM ****************************  EP_LOAD RELATED END  ****************************
REM *******************************************************************************


REM *******************************************************************************
REM ****************************  12.2.4  *****************************************
REM *******************************************************************************
REM Launch Management Error Check
REM select error_message
REM from npi_series_data
REM Here is the text for the note to enable DOP hint
REM Attention!
REM In order to enable automatic DOP hint for Demantra worksheets dynamic_hint_enabled parameter in sys params should not exist (rename or delete it). In order to disable automatic DOP hint 
REM for Demantra worksheets dynamic_hint_enabled parameter should exist and a value 0 has to be used.
REM
REM ================================================================================
REM ==========================  RDBMS SQL  ==============================

REM **************************************************************************************** 
REM **************************************************************************************** 
REM **************************************************************************************** 
REM *******            ASCP Performance Analyzer RDBMS Statistics *******
REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 




REM **************************************************************************************** 
REM **************************************************************************************** 
REM **************************************************************************************** 
REM *******                   Section 1 : ASCP Performance Analyzer RDBMS Statistics *******
REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 




REM *******************************************************************
REM *************  Buffer Cache Hit Ratio Percent  ********************
REM *******************************************************************

prompt <a name="adv143"></a><font size="+2">Buffer Cache Hit Ratio Percent</font><BR><BR>

begin

select round((1-(pr.value/(bg.value+cg.value)))*100,2) into :ratio
from v$sysstat pr, v$sysstat bg, v$sysstat cg
where pr.name='physical reads'
and bg.name='db block gets'
and cg.name='consistent gets';

dbms_output.put_line('<b>Buffer Cache Hit Percent Gauge</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

if (:ratio < 80) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=525x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 80 percent.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

  else   if (:ratio between 81 and 95) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:90');
  dbms_output.put('\&chl=Fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 95 percent.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put_line('<b>Workflow Runtime Data Table Gauge</b><BR>');
  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=Good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your cache hit percent is good.  No performance impact.</font><BR><BR> ');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *************  Dictionary Cache Hit Ratio
REM **************************************************************************************** 

prompt <a name="adv144"></a><B><font size="+2">Dictionary Cache Hit Ratio</font></B><BR><BR>

begin

select round(sum(gets-getmisses)*100/sum(gets),2) into :ratio
from v$rowcache;

dbms_output.put_line('<b>Data Dictionary Hit Percent Gauge</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

if (:ratio < 70) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR>');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

  else if (:ratio between 70 and 90) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:80');
  dbms_output.put('\&chl=Fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR> ');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=Good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">The data dictionary resides in the shared pool. Make sure the shared pool has enough memory so that more data dictionary can be cached.</font><BR> ');
    dbms_output.put_line('To read more, see How to Calculate Your Shared Pool Size, MOS Note:1012046.6<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *************  Sorts in Memory
REM **************************************************************************************** 

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Sorts in Memory</font></b></a></p><br>
prompt     <a name="top"><font size="+1">This metric represents the sort efficiency as measured by the percentage of times sorts were performed in memory as opposed to going to disk.<br>
prompt     For best performance, most sorts should occur in memory because sorts to disks are less efficient. If the sort area is too small, extra sort runs will be required during the sort<br>
prompt     operation. This increases CPU and I/O resource consumption.  This test checks the percentage of sorts performed in memory rather than to disk. If the value is less than or equal to the<br>
prompt     threshold values specified by the threshold arguments, and the number of occurrences exceeds the value specified in the "Number of Occurrences" parameter, then a warning or critical alert<br>
prompt     is generated.  For addtional information see Common Observations, Causes, and Solutions for Oracle Database Performance Issues (Doc ID 1453975.1), section <br>
prompt     Cause Identified: Incorrect manual workarea sizing</font></a>
prompt </td></tr></tbody> 
prompt </table><BR><BR>


prompt <a name="adv145"></a><B><font size="+2">Sorts in Memory</font></B><BR><BR>

begin

select round((mem.value/(mem.value+dsk.value))*100,2) into :ratio
from v$sysstat mem, v$sysstat dsk
where mem.name='sorts (memory)'
and dsk.name='sorts (disk)';

dbms_output.put_line('<b>Sorts in Memory Percent Gauge</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

if (:ratio < 70) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=Critial" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">This is a measure of the proportion of data sorts which occur within memory rather than on disk.</p><BR><BR>');
    dbms_output.put_line('<p>Sorts on disk make use of the users tempoary table space.  The maximum size of sort which will occur in memory is defined by the sort area size, </p><BR>');
    dbms_output.put_line('<p>which is the size within the PGA which will be used. Each Oracle process which sorts will allocate this much memory, though it may not use all of it.</p><BR>');
    dbms_output.put_line('<p>Use of memory for this purpose reduces that available to the SGA.</p><BR>');
    dbms_output.put_line('<p>The sorts are too large to fit in memory and some of the sort data is written out directly to disk. This data is later read back in, using direct reads.</p><BR>');
dbms_output.put_line('<p>With larger Sort Areas in memory, the likelihood of them being exhausted during a sorting operation and having to use a temporary tablespace on disk is reduced.</p><br>');
dbms_output.put_line('<p>Please see Troubleshooting: Tuning the Shared Pool and Tuning Library Cache Latch Contention (Doc ID 62143.1)</font></p><BR>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
  dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:95');
  dbms_output.put('\&chl=Good" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Normally, if expensive sorts are hurting your SQL performance, you will notice it elsewhere first.</font></p>');
    dbms_output.put_line('<p>Your sort in memory percent seems healthy.</p><BR><BR>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM *************  Free Shared Pool %
REM **************************************************************************************** 

prompt <a name="adv146"></a><B><font size="+2">The percentage of FREE shared pool</font></B><BR><BR>

begin

select round((sum(decode(name,'free memory',bytes,0))/sum(bytes))*100,2) into :ratio from v$sgastat;

dbms_output.put_line('<b>The percentage of FREE shared pool</b>'||'<font size="+1"> Your Free Percent is: '||:ratio||'</font><BR><BR>');

if (:ratio > 10) THEN

    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">This percentage has greater impact when your process is runnging.  Afterwards the shared pool will be released.</p><BR> ');
    dbms_output.put_line('<p>The percentage of shared pool free, not in use.  This statistic is valuable as you notice a trend.  For example, if a large percentage of the shared pool,</p>');
    dbms_output.put_line('<p>is consistenly free, it is likely that the size of the shared pool can be reduced.  However, lower free values are not necessarily a problem unless other</p>');
    dbms_output.put_line('<p>factors point to problems.  For example, poor dictionary cache hit ratio or a large proportion of reloads.</p><BR>');
    dbms_output.put_line('<p>See Troubleshooting: Tuning the Shared Pool and Tuning Library Cache Latch Contention (Doc ID 62143.1)</p></font><BR>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

else

    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+2">The percentage of free shared pool is less than 10 %.  It is recommended that that the pool is reviewed to determine if the RDBMS requires additional space.</font><BR> ');
    dbms_output.put_line('This percentage has greater importance when your process is running.  Afterwards, the shared pool will be released.<BR><BR>');
    dbms_output.put_line('For more information, see MyOracleSupport note 455179.1.</p><br>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');



    
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM ****************    Shared Pool Reloads
REM **************************************************************************************** 

prompt <a name="adv147"></a><B><font size="+2">Shared Pool Reloads</font></B><BR><BR>

begin

select round(sum(reloads)/sum(pins),2) into :ratio
from v$librarycache
where namespace in ('SQL AREA','TABLE/PROCEDURE','BODY','TRIGGER');

dbms_output.put_line('<b>Shared Pool Reloads Percent</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

    dbms_output.put_line('<table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">It is best if the percentage is low.  We recommend reviewing the following should the percentage be 65% or greater.</font></p><BR>');
    dbms_output.put_line('<p>Shared pool reloads occur when Oracle has to implicitly reparse SQL or PL/SQL at execution.  A larger shared pool will reduce implicit reparsing.</p>');
    dbms_output.put_line('<p>Ensuring that similar pieces of SQL are written identically will increase sharing of code.  Review the parameter CURSOR_SHARING.  To make use of additional</p>');
    dbms_output.put_line('<p>shared SQL  memory that is available for shared SQL areas, review the parameter OPEN_CURSORS permitted for a session.  Review the parameters open_cursors</p>');
    dbms_output.put_line('<p>and CURSOR_SHARING.</p><BR>');
    dbms_output.put_line('<p>cursor_sharing - The default value for cursor_sharing is EXACT; it should be changed to FORCE for better performance.</p>');
    dbms_output.put_line('<p>If the DB has both Demantra and ASCP on the same instance, it is recommended to keep cursor_sharing = EXCAT.  One of the reasons it is preferred to have separate installs.</p>');
    dbms_output.put_line('<p>Demantra system runs better when it has more memory in the Oracle Server Buffer Cache.  This change should decrease the number of physical I/O�s that are required</p>');
    dbms_output.put_line('<p>and hence results in better performance. Demantra recommends that at least 1 GB be dedicated to the buffer cache. This value is, of course, dependent on</p>');
    dbms_output.put_line('<p>the overall data volume. When using CTO, it is recommended to increase your SGA settings as well.</p><br>');
    dbms_output.put_line('<p>For more information see, Troubleshooting: Tuning the Shared Pool and Tuning Library Cache Latch Contention, Doc ID 62143.1.</p><br>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');

end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM **************************************************************************************** 
REM ****************  FREELIST
REM **************************************************************************************** 

prompt <a name="adv148"></a><B><font size="+2">Freelist Performance Impact</font></B><BR><BR>

begin

select round((sum(decode(w.class,'free list',count,0))/
(sum(decode(name,'db block gets',value,0))
+ sum(decode(name,'consistent gets',value,0))))*100,2) into :ratio
from v$waitstat w, v$sysstat;

dbms_output.put_line('<b>Free List Contention Performance Impact Gauge</b>'||'<font size="+1"> Your impact is: '||:ratio||'</font><BR><BR>');

if (:ratio < 20) THEN

    dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
    dbms_output.put('\&chxt=y');
    dbms_output.put('\&chs=500x250');
    dbms_output.put('\&cht=gm');
    dbms_output.put('\&chco=000000,05FA00|FF0000');
    dbms_output.put('\&chd=t:5');
    dbms_output.put('\&chl=Low" width="500" height="250" alt="" />');
    dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your Freelist contention is LOW performance impact.<BR> ');
    dbms_output.put_line('<p>For more information, see OPS/RAC: Using Free List Groups to reduce contention on free list descriptors, note 72384.1.</font><BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

  else if (:ratio between 21 and 40) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,05FA00|FF0000');
  dbms_output.put('\&chd=t:40');
  dbms_output.put('\&chl=Fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
 dbms_output.put_line('<p><font size="+1">In tablespaces with manual segment-space management, Oracle Database uses the FREELISTS storage parameter to improve performance of space management in</p><BR>');
    dbms_output.put_line('<p>OLTP systems by increasing the number of insert points in the segment. In tablespaces with automatic segment-space management, this parameter is ignored,</p><BR> ');
    dbms_output.put_line('<p>because the database adapts to varying workload.  If more processes are attempting to make inserts than there are free lists some processes will have to</p><BR> ');
    dbms_output.put_line('<p>wait for access to a free list.  Increasing the wait count and the performance impact.</p><br>');
    dbms_output.put_line('<p>For more information, see OPS/RAC: Using Free List Groups to reduce contention on free list descriptors, note 72384.1.</font><BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|LOW|FAIR|HIGH');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,05FA00|FF0000');
  dbms_output.put('\&chd=t:50');
  dbms_output.put('\&chl=HIGH" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">In tablespaces with manual segment-space management, Oracle Database uses the FREELISTS storage parameter to improve performance of space management in</p><BR> ');
    dbms_output.put_line('<p>OLTP systems by increasing the number of insert points in the segment. In tablespaces with automatic segment-space management, this parameter is ignored,</p><BR> ');
    dbms_output.put_line('<p>because the database adapts to varying workload.  If more processes are attempting to make inserts than there are free lists some processes will have to</p><BR> ');
    dbms_output.put_line('<p>wait for access to a free list.  Increasing the wait count and the performance impact.</p><br>;');
    dbms_output.put_line('<p>For more information, see OPS/RAC: Using Free List Groups to reduce contention on free list descriptors, note 72384.1.</font><BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody>');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *******************************************************************
REM *************  Library Cache Hit Ratio Percent  ********************
REM *******************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt     <p><a name="top"><b><font size="+2">Library Reload Ratio Percent</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> The proportion of requests for a lock on an object which were satisfied by finding that object's handle already in memory.<br>
prompt     If your reload ratio is greater than 90%-95% you most likely do not require any increase of the SHARED_POOL_SIZE parameter.<br>
prompt     The pin ratio, as found in the AWR report, is not as important as the reload ratio.  The reload ratio is directly related to specific SQL and PL/SQL blocks.  Shared pool reloads<br>
prompt     occur when Oracle has to implicitly reparse SQL or PL/SQL at the point when it attempts to execute it.  A larger shared pool wil reduce the number of times that code needs to be reloaded.<br>
prompt     Also, ensuring that similar pieces of SQL are written identically will increase sharing of code.<br><br>  
prompt     However, if your reload ratio is low, investigate the statistics 'parse time CPU', 'parse time elapsed' and to a lesser extent the "latch sleep" count from the library cache and<br>
prompt     shared pool latches.  If the amount of time in these two states is a high fraction of the total run time, you may want to investigate any objects that are not pinned in the shared pool<br>
prompt     but could be pinned.  Try pinning the objects, restart and continue monitoring.  If the reload rate still fails to diminish consider reviewing the size of the shared pool and possbily<br>
prompt     contacting Oracle Support.<br>
prompt     Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.</font></a><br><Br>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

prompt <a name="adv149"></a><B><font size="+2">Library Reload Ratio Percent</font></B><BR><BR>

begin

select round(((sum(reloads)/nvl(sum(pins),1))*100)*100, 2) into :ratio
from v$librarycache;

dbms_output.put_line('<b>Library Reload Ratio Percent</b>'||'<font size="+1"> Your ratio is: '||:ratio||'</font><BR><BR>');

if (:ratio >= 89) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|CRITICAL|FAIR|GOOD');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:90');
  dbms_output.put('\&chl=GOOD" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="RedBox" cellpadding="10" bordercolor="#CC0033" bgcolor="#CC6666" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 90 percent.</font><BR> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance is not impacted with your current ratio.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');

  else if (:ratio between 65 and 89) THEN

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:75');
  dbms_output.put('\&chl=fair" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="OrangeBox" cellpadding="10" bordercolor="#FF9900" bgcolor="#FFCC66" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your overall performance will suffer when the cache hit percent is below 95 percent.</font><BR> ');
    dbms_output.put_line('Should you need additional information, please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1.<BR><BR></p>');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  else

  dbms_output.put('<img src="http://chart.apis.google.com/chart?chxl=0:|critical|fair|good');
  dbms_output.put('\&chxt=y');
  dbms_output.put('\&chs=500x250');
  dbms_output.put('\&cht=gm');
dbms_output.put('\&chco=000000,FF0000|05FA00');
  dbms_output.put('\&chd=t:30');
  dbms_output.put('\&chl=Critical" width="500" height="250" alt="" />');
  dbms_output.put_line('<BR><BR>');
  
    dbms_output.put_line('<table border="1" name="GreenBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#D7E8B0" cellspacing="0">');
    dbms_output.put_line('<tbody><font face="Calibri"><tr><td> ');
    dbms_output.put_line('<p><font size="+1">Your cache hit percent is not good.  There is a performance impact.  Please see MOS note: Understanding and Tuning Buffer Cache and DBWR, Note 62172.1</font><BR><BR> ');
    dbms_output.put_line('</td></tr></tbody> ');
    dbms_output.put_line('</table><BR>');
    
  end if;
end if;
end;
/

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************
REM ******* Library Cache Greater Details *******
REM *********************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Is the shared pool the hot object or performance constraint?</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> Report column definition.  This will help to interpret the contents of the V$LIBRARYCACHE view and the possible impact to the shared pool:<br><br>
prompt     namespace - is the object type.  The values SQL AREA, TABLE/PROCEDURE, BODY, and TRIGGER<br>
prompt     pins - times the item in the library cache was executed<br>
prompt     pinhits - total executions when the specific item was present in the library cache<br>
prompt     pinhitratio - ratio of pinhits to pins<br>
prompt     reloads - the number of times the code had to be reloaded into the library cache due to aging or invalidation<br><br>
prompt     The pin_ratio should be close to 100 percent.  This indicates the data required to process the request is already allocated and valid in the library cache.<br>
prompt     Keep in mind that it may not be possible to achieve and maintain 100%.  It is best to achieve a hit ratio of greater than 95 percent.  At startup, you most likely will not<br>
prompt     achieve your desired ratio.  However, if your reload ratio is low, investigate the statistics 'parse time CPU', 'parse time elapsed' and to a lesser extent the "latch sleep"<BR>
prompt     count from the library cache and shared pool latches.  If the amount of time in these two statistics is a high fraction of the total time, you may want to investigate any objects<BR>
prompt     that are not pinned in the shared pool but could be pinned, pinning the objects and continue monitoring.  If the reload rate still fails to diminish consider reviewing the size of<BR>
prompt     the shared pool and possbily contacting Oracle Support.<br>
prompt     See Troubleshooting: Tuning the Shared Pool and Tuning Library Cache Latch Contention (Doc ID 62143.1)</font></a><br>

prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows2sql9(){var row = document.getElementById("s2sql9");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv150"></a>
prompt     <a name="top"><b><font size="+2"> Library Cache Constraint Activity and Shared Pool </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows2sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s2sql9" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt       select namespace,<BR>
prompt       pins,<BR>
prompt       pinhits,<BR>
prompt       round(pinhitratio*100,2),<BR>
prompt       reloads,<BR>
prompt       reloads / decode(pins, 0, 1, pins)<BR>
prompt       from v$librarycache</p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Object_NameExt_Manage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pins</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pinhits</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pin_Ratio</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Reloads</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Reload_Ratio</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||namespace||'</TD>'||chr(10)||
'<TD>'||pins||'</TD>'||chr(10)||
'<TD>'||pinhits||'</TD>'||chr(10)||
'<TD>'||round(pinhitratio*100,2)||'</TD>'||chr(10)||
'<TD>'||reloads||'</TD>'||chr(10)||
'<TD>'||round((reloads / decode(pins, 0, 1, pins)) * 100,2)||'</TD></TR>'
from v$librarycache;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>

REM *********************************************
REM ******* I/O Data Files Disbursement    *******
REM *********************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Data File I/O Load Disbursement</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> This report reveals the constraint placed on datafiles.  Should you see IO per data file that is unbalanced,
prompt     it is strongly advised that an investigation is conducted, discovering the segments in the datafile.  It is advised that the load be balanced across many
prompt     datafiles.  Perhaps you have too many active tablespaces in the datafile.<br>
prompt     Troubleshooting I/O Related Waits (Doc ID 223117.1)</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript"> function displayRows5sql1(){var row = document.getElementById("s5sql1");if (row.style.display == '') row.style.display = 'none';else row.style.display = ''; }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv151"></a>
prompt     <a name="top"><b><font size="+2"> Datafile Activity Constraints </font></B></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql1()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql1" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt       SELECT NAME,<BR>
prompt       PHYRDS,<BR>
Prompt       ROUND ((RATIO_TO_REPORT (PHYRDS) OVER ()) * 100, 2),<BR>
prompt       PHYWRTS,<BR>
prompt       ROUND ((RATIO_TO_REPORT (PHYWRTS) OVER ()) * 100, 2)<BR>
prompt       (nvl(PHYRDS,0) + nvl(PHYWRTS,0))<BR>
prompt       FROM V$DATAFILE F, V$FILESTAT S<BR>
prompt       WHERE F.FILE# = S.FILE#<BR>
prompt       and rownum < 20<BR>
prompt       ORDER BY PHYRDS DESC<BR></p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>DBF_Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phys_Reads</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Reads</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Phys_Writes</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Writes</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Reads_Writes</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||name||'</TD>'||chr(10)||
'<TD>'||phyrds||'</TD>'||chr(10)||
'<TD>'||ROUND ((RATIO_TO_REPORT (PHYRDS) OVER ()) * 100, 2)||'</TD>'||chr(10)||
'<TD>'||phywrts||'</TD>'||chr(10)||
'<TD>'||ROUND ((RATIO_TO_REPORT (PHYWRTS) OVER ()) * 100, 2)||'</TD>'||chr(10)||
'<TD>'||(nvl(PHYRDS,0) + nvl(PHYWRTS,0))||'</TD></TR>'
FROM V$DATAFILE DF, V$FILESTAT FS
WHERE DF.FILE# = FS.FILE#
and rownum < 20
ORDER BY PHYRDS DESC;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ***************************************************************
REM ******* IO Disbursement Across Datafiles for Tablespace *******
REM ***************************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">IO Disbursement Across Datafiles for Tablespace</font></b></a></p><br>
prompt     <a name="top"><font size="+1">Drilling further into the datafile, revealing the tablespaces. Do you have data tables and indexes in the same tablespace?
prompt     Do you have large active segments in the same tablespace?  Do you have several active tablespaces within the out of balance datafile?  Oracle recommends separation
prompt     of active segments into multiple tablespaces.  Active tablespaces in individual datafiels.<br>
prompt     See Troubleshooting I/O Related Waits (Doc ID 223117.1)</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows5sql2(){var row = document.getElementById("s5sql2");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv152"></a>
prompt     <a name="top"><b><font size="+2"> IO Disbursement Across Datafiles for Tablespace </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql2()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql2" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt       SELECT vts.name,<BR> 
prompt         DF.NAME,<BR>
prompt         PHYRDS,<BR>
prompt         ROUND ( (RATIO_TO_REPORT (PHYRDS) OVER ()) * 100, 2),<BR>
prompt         PHYWRTS, <BR>
prompt         ROUND ( (RATIO_TO_REPORT (PHYWRTS) OVER ()) * 100, 2),<BR>
prompt         (nvl(PHYRDS,0) + nvl(PHYWRTS,0))
prompt    FROM V$DATAFILE DF, V$FILESTAT FS, v$tablespace VTS
prompt   WHERE DF.FILE# = FS.FILE# 
prompt   AND DF.TS# = VTS.TS#
prompt       ORDER BY vts.name, PHYRDS DESC;</p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Tablespace_Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Data_File_Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Reads</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Read_Ratio</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Writes</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Write_ratio</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||vts.name||'</TD>'||chr(10)||
'<TD>'||df.name||'</TD>'||chr(10)||
'<TD>'||phyrds||'</TD>'||chr(10)||
'<TD>'||ROUND ( (RATIO_TO_REPORT (PHYRDS) OVER ()) * 100, 2)||'</TD>'||chr(10)||
'<TD>'||phywrts||'</TD>'||chr(10)||
'<TD>'||ROUND ( (RATIO_TO_REPORT (PHYWRTS) OVER ()) * 100, 2)||'</TD>'||chr(10)||
'<TD>'||(nvl(PHYRDS,0) + nvl(PHYWRTS,0))||'</TD></TR>'
FROM V$DATAFILE DF, V$FILESTAT FS, v$tablespace VTS
WHERE DF.FILE# = FS.FILE# 
AND DF.TS# = VTS.TS#
and rownum < 75
ORDER BY PHYRDS DESC;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* System Events *******************************
REM *********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">System Wait Events</font></b></a></p><br>
prompt <a name="top"><font size="+1">Oracle event wait analysis is an educated process when performing system tuning.  The v$system_event view is important.  We are looking at system events that are happening within your system.<br>
prompt  High waits on system events can point to disk I/O bottlenecks, network bottlenecks and environment bottlenecks.<br>
prompt  Below, we have eliminated the most commone idle wait events and include those waits that have average wait > 10 seconds.<br>
prompt  This report will give you insight into the causes of wait event impact.<br>
prompt  This is a good place to begin your investigation as to why the wait event is on this report.   Perhaps it is a critical clue to your performance improvement solution.<br>
prompt  See: Using the AWR to Analyze Demantra Performance (Doc ID 1450237.1)</font></a><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows5sql3(){var row = document.getElementById("s5sql3");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv153"></a>
prompt     <a name="top"><b><font size="+2"> System Events</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql3()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql3" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt       SELECT event,<BR>
prompt       total_waits,<BR>
prompt       round(time_waited / 100, 0),<BR>
prompt       total_timeouts,<BR>
prompt       average_wait / 100<BR>
prompt       from sys.v_$system_event<BR>
prompt       where event not in <BR>
prompt    ('dispatcher timer',<BR>
prompt    'lock element cleanup',<BR>
prompt    'Null event',<BR>
prompt    'parallel query dequeue wait',<BR>
prompt    'parallel query idle wait - Slaves',<BR>
prompt    'pipe get',<BR>
prompt    'PL/SQL lock timer',<BR>
prompt    'pmon timer',<BR>
prompt    'rdbms ipc message',<BR>
prompt    'slave wait',<BR>
prompt    'smon timer',<BR>
prompt    'SQL*Net break/reset to client',<BR>
prompt    'SQL*Net message from client',<BR>
prompt    'SQL*Net message to client',<BR>
prompt    'SQL*Net more data to client',<BR>
prompt    'virtual circuit status',<BR>
prompt    'WMON goes to sleep')<BR>
prompt    and average_wait > 10<BR>
prompt    AND event not like 'DFS%'<BR>
prompt    and event not like '%done%'<BR>
prompt    and event not like '%Idle%'<BR>
prompt    AND event not like 'KXFX%'<BR>
prompt    order by 2 desc;<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Event</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Waits</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Seconds_Waited</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Timeouts</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Time_Waited</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Average_Wait_Seconds</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(event,1,50)||'</TD>'||chr(10)||
'<TD>'||total_waits||'</TD>'||chr(10)|| 
'<TD>'||round(time_waited / 100, 0)||'</TD>'||chr(10)||
'<TD>'||total_timeouts||'</TD>'||chr(10)|| 
'<TD>'||time_waited||'</TD>'||chr(10)||
'<TD>'||average_wait / 100||'</TD><TR>'
FROM v$system_event
where event not in
    ('dispatcher timer',
    'lock element cleanup',
    'Null event',
    'parallel query dequeue wait',
    'parallel query idle wait - Slaves',
    'pipe get',
    'PL/SQL lock timer',
    'pmon timer',
    'rdbms ipc message',
    'slave wait',
    'smon timer',
    'SQL*Net break/reset to client',
    'SQL*Net message from client',
    'SQL*Net message to client',
    'SQL*Net more data to client',
    'virtual circuit status',
    'WMON goes to sleep')
and average_wait > 10
AND event not like 'DFS%'
and event not like '%done%'
and event not like '%Idle%'
AND event not like 'KXFX%'
order by total_waits desc;

prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* Network V$System_Event Wait Events **************
REM *********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Network V$System_Event</font></b></a></p><br>
prompt <a name="top"><font size="+1">This report will give you an overview of your network waits.  By themselves, they may mean very little.  However, when reviewing your overall.<br>
prompt  system performance, these become part of your collected performance landscape.  Additional investigation will most likely be required to discover a bottleneck.<br><br>
prompt  For the next two data points, see the following notes:<br>
prompt  WAITEVENT: "SQL*Net message from client" Reference Note (Doc ID 34395.1)<br>
prompt  WAITEVENT: "SQL*Net message to client" Reference Note (Doc ID 34397.1)<br>
prompt  WAITEVENT: "SQL*Net message to dblink" Reference Note (Doc ID 34398.1)</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows5sql4(){var row = document.getElementById("s5sql4");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv154"></a>
prompt     <a name="top"><b><font size="+2">Network Wait Events</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql4()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql4" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt       SELECT event,<BR>
prompt       total_waits,<BR>
prompt       round(time_waited / 100, 0),<BR>
prompt       total_timeouts,<BR>
prompt       average_wait / 100<BR>
prompt       from sys.v_$system_event<BR>
prompt       where event in ('SQL*Net break/reset to client','SQL*Net message from client', 'SQL*Net message to client', 'SQL*Net more data to client)
prompt       and event not like '%done%'
prompt       and event not like '%idle%'
prompt       order by 2 desc;<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Event</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Waits</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Seconds_Waited</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Timeouts</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Average_Wait_Seconds</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(event,1,30)||'</TD>'||chr(10)||
'<TD>'||total_waits||'</TD>'||chr(10)|| 
'<TD>'||round((time_waited / 100), 0)||'</TD>'||chr(10)||
'<TD>'||total_timeouts||'</TD>'||chr(10)|| 
'<TD>'||average_wait / 100||'</TD><TR>'
FROM v$system_event
where event in ('SQL*Net break/reset to client','SQL*Net message from client', 'SQL*Net message to client', 'SQL*Net more data to client')
and event not like '%done%'
and event not like '%Idle%'
order by total_waits desc;

prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* Network Wait Class Events **************
REM *********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Network V$System_Wait_Class Summary</font></b></a></p><br>
prompt <a name="top"><font size="+1">This report selects the network performance statistics from V$system_wait_class.  This is a good place to start if you suspect that there may be 
prompt and bottleneck issue in your network.  We eliminate the idle wait_class.</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows5sql6(){var row = document.getElementById("s5sql6");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv155"></a>
prompt     <a name="top"><b><font size="+2">Network Wait Class Summary</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql6()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql6" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt       SELECT wait_class,<BR>
prompt       total_waits,<BR>
prompt       ROUND(100 * (total_waits / decode(sum_waits,0,1,sum_waits)),2),<BR>
prompt       time_waited,<BR>
prompt       ROUND(100 * (time_waited / decode(sum_time,0,1,sum_time)),2)<BR>
prompt       FROM (SELECT wait_class,<BR>
prompt       total_waits,<BR>
prompt       time_waited<BR>
prompt       FROM v$system_wait_class<BR>
prompt       WHERE wait_class = 'Network'<BR>
prompt       and wait_class != 'Idle'),<BR>
prompt       (SELECT SUM(total_waits) sum_waits,<BR>
prompt       SUM(time_waited) sum_time<BR>
prompt       FROM v$system_wait_class<BR>
prompt       WHERE wait_class != 'Idle')<BR>
prompt       ORDER BY 5 DESC<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Wait_Class</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Total_Waits</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pct_Total_Waits</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Time_waited</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pct_Wait_Time</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(wait_class,1,30)||'</TD>'||chr(10)||
'<TD>'||total_waits||'</TD>'||chr(10)|| 
'<TD>'||ROUND(100 * (total_waits / decode(sum_waits,0,1,sum_waits)),2)||'</TD>'||chr(10)||
'<TD>'||time_waited||'</TD>'||chr(10)|| 
'<TD>'||ROUND(100 * (time_waited / decode(sum_time,0,1,sum_time)),2)||'</TD><TR>'
FROM (SELECT wait_class,
             total_waits,
             time_waited
      FROM v$system_wait_class
      WHERE wait_class = 'Network'
      and wait_class != 'Idle'),
(SELECT SUM(total_waits) sum_waits,
SUM(time_waited) sum_time
FROM v$system_wait_class
WHERE wait_class != 'Idle')
ORDER BY total_waits DESC;

prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM **************************************************************************************** 
REM *******                   Section 2 : ASCP Entity Data Volume                    *******
REM ****************************************************************************************
REM 
REM prompt <a name="section2"></a><B><font size="+2">ASCP Entity Size in MB and Percent Fragmentation </font></B><BR><BR>
REM 
REM
REM ******* Verify Entity Size in MB and Percent Fragmentation  *******
REM

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Database Object Fragmentation > 50% </font></b></a></p><br>
prompt <a name="top"><font size="+1">This report will give you a list of tables where the fragmentation is > 50%.  These objects should be rebuilt to reduce the fragmentation thus<br>
prompt  improving performance</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows5sql7(){var row = document.getElementById("s5sql7");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv156"></a>
prompt     <a name="top"><b><font size="+2">Database Object Fragmentation</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql7()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql7" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt       select substr(table_name,1,30),
prompt       round((blocks*8),2) "size (kb)" , <BR>
prompt       round((num_rows*avg_row_len/1024),2) "actual_data (kb)",<BR>
prompt       (round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) "wasted_space (kb)",<BR>
prompt       round(((round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) / round((blocks*8),2)) * 100, 2) pct<BR>
prompt       from dba_tables<BR>
prompt       where (round((blocks*8),2) > round((num_rows*avg_row_len/1024),2))<BR>
prompt       and ((round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) / round((blocks*8),2)) * 100 > 50<BR>
prompt       order by 4 desc<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table_Name</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Size_KB</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Actual_Data_KB</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Wasted_KB</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Fragmentation_Percent</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(table_name,1,30)||'</TD>'||chr(10)||
'<TD>'||round((blocks*8),2)||'</TD>'||chr(10)|| 
'<TD>'||round((num_rows*avg_row_len/1024),2)||'</TD>'||chr(10)||
'<TD>'||(round((blocks*8),2) - round((num_rows*avg_row_len/1024),2))||'</TD>'||chr(10)|| 
'<TD>'||round(((round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) / round((blocks*8),2)) * 100, 2)||'</TD><TR>'
from dba_tables
where owner = :gv_schema 
and (round((blocks*8),2) > round((num_rows*avg_row_len/1024),2))
and ((round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) / round((blocks*8),2)) * 100 > 80
and rownum < 50
order by (round((blocks*8),2) - round((num_rows*avg_row_len/1024),2)) desc;
prompt </table><br>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* Segments Where Free Space <= Next Extent  *******
REM *********************************************************

prompt <a name="section2"></a><B><font size="+2">Value Chain Planning Segments Where Next Size is Larger Than Free Space Available Summary</font></B><BR>
prompt <a name="section2.1"></a><font size="+1">Not applicable to LMT (Locally Managed Tablespaces)<br><br>
prompt For additional information see the followionig myoraclesupport notes:<br>
prompt Reclaiming unused space in an E-Business Suite Instance tablespace (Doc ID 303709.1) or<br>
prompt How To Reclaim Wasted Space on The Segment (Table, Index and LOB) and Tablespace Levels (Doc ID 1682748.1)</font></a>BR><BR>

prompt <script type="text/javascript">    function displayRows5sql8(){var row = document.getElementById("s5sql8");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv157"></a>
prompt     <a name="top"><b><font size="+2"> Segments Where Free Space <= Next Extent </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql8()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql8" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt          select substr(a.owner,1,12),<BR>
prompt          segment_type,<BR>
prompt          count(2) AS "Number of Segments"<BR>
prompt          from dba_segments a<BR>
prompt          where a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)<BR>
prompt          OR a.EXTENTS = a.MAX_EXTENTS<BR>
prompt          group by owner, segment_type<BR></p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR id="s2sql51" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="right">
prompt          select substr(a.tablespace_name,1,30) "TName",<BR>
prompt          substr(a.owner,1,12) "Owner",<BR>
prompt          substr(a.segment_name,1,30) "SegName",<BR>
prompt          a.next_extent "NextExt",<BR>
prompt          a.segment_type "SegType" <BR>
prompt          from dba_segments a<BR>
prompt          where a.owner = 'MSC' 
prompt          and a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)<BR>
prompt          OR a.EXTENTS = a.MAX_EXTENTS<BR>
prompt          order by a.next_extent;</p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Owner</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Segment Type</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(a.owner,1,12)||'</TD>'||chr(10)||
'<TD>'||a.segment_type||'</TD>'||chr(10)||
'<TD>'||count(2)||' '||'</TD></TR>'
from dba_segments a
where a.owner = :gv_schema 
and a.next_extent >= (select max(b.BYTES) from  dba_free_space b where b.tablespace_name = a.tablespace_name)
OR a.EXTENTS = a.MAX_EXTENTS
group by owner, segment_type;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ******************************
REM ******* cluster factor *******
REM ******************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Cluster Factor > 50% and Related Data Points</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> The lower the CF, closer to the number of blocks in the table vs the number of rows, the more efficient it is to use the index as<br>
prompt     less table blocks would need to be accessed to retrieve the necessary data via the chosen index.<br><br>
prompt     So far so good.  However, what if part of the incoming row is stored in block one and the remainder in block 2?  When the row is <br>
prompt     required, block 1 and block 2 will be read into cache resulting in near zero waiting for the entire row.  OK, fast forward, what if<br>
prompt     the table has 100m rows and imagine that this situation occurs 30% of the time.  Your current CF method is most likely skewed<br>
prompt     and incorrect.<br><br>
prompt     Now for the good news, bug 13262857 - INDEX CLUSTERING FACTOR COMPUTATION IS PESSIMISTIC.  The computation of the index clustering<br>
prompt     factor in dbms_stats package is pessimistic about the caching ratio of the table blocks.  It assumes that at most one block from the<br>
prompt     table is cached. <br><br>
prompt     This is an enhancement to allow a user to specify the number of blocks that dbms_stats package will consider when gathering the index clustering <br>
prompt     factor statistics. Prior to this enhancement dbms_stats assumed 1 and it still does after the enhancement.  This enhancement allows the user to <br>
prompt     specify a value between 1 and 255.  There is also an AUTO option which if specified then dbms_stats will use 1% of the table blocks up to <br>
prompt     0.1% of the buffer cache size, in blocks.  <br><br>
prompt     The new CF approach is currently available with patches that can be applied on both Exadata databases and Oracle versions 11.1.0.7, 11.2.0.2 and 11.2.0.3.<br>
prompt     The Patch ID is 15830250.<br><br>
prompt     Regarding the table below.  Is your cluster factor closer to the number of blocks (good) or the number of rows (not as good)?<br><Br>
prompt  </td></tr></tbody> 
prompt </table><BR><BR>

prompt <a name="section2"></a><B><font size="+2">Cluster Factor Index - Table Health</font></B><BR>

prompt <script type="text/javascript">    function displayRows5sql9(){var row = document.getElementById("s5sql9");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv158"></a>
prompt     <a name="top"><b><font size="+2"> Cluster Factor > 50% Rows vs Blocks and Related Storage Facts</font></B></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql9()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql9" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt        select substr(a.table_name,1,10),<br>
prompt        substr(index_name,1,30),<br>
prompt        blevel,<br>
prompt        leaf_blocks,<br>
prompt        distinct_keys,<br>
prompt        AVG_LEAF_BLOCKS_PER_KEY,<br>
prompt        AVG_DATA_BLOCKS_PER_KEY,<br>
prompt        b.sample_size,<br>
prompt        b.last_analyzed,<br>
prompt        CLUSTERING_FACTOR,<br>
prompt        blocks,<br>
prompt        b.NUM_ROWS<br>
prompt        from all_indexes a, all_tables b<br>
prompt        where a.table_name in ('MDP_MATRIX', 'SALES_DATA')<br>
prompt        and b.table_name = a.table_name<br>
prompt        and table_owner = 'MSDEM'<br>
prompt        order by 1, 2; </p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Index Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>blevel</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>leaf_blocks</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Distinct Keys</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>AVG Leaf Blks</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Avg Data Blks</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Sample Size</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Analyzed</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Cluster Factor</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Blocks</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Nbr Rows</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||substr(a.table_name,1,10)||'</TD>'||chr(10)||
'<TD>'||substr(index_name,1,30)||'</TD>'||chr(10)||
'<TD>'||blevel||'</TD>'||chr(10)||
'<TD>'||leaf_blocks||'</TD>'||chr(10)||
'<TD>'||distinct_keys||'</TD>'||chr(10)||
'<TD>'||AVG_LEAF_BLOCKS_PER_KEY||'</TD>'||chr(10)||
'<TD>'||AVG_DATA_BLOCKS_PER_KEY||'</TD>'||chr(10)||
'<TD>'||b.sample_size||'</TD>'||chr(10)||
'<TD>'||b.last_analyzed||'</TD>'||chr(10)||
'<TD>'||clustering_factor||'</TD>'||chr(10)||
'<TD>'||Blocks||'</TD>'||chr(10)||
'<TD>'||b.num_rows||'</TD></TR>'
from all_indexes a, all_tables b
where a.table_name in ('MDP_MATRIX', 'SALES_DATA')
and blocks / decode(b.num_rows,0,1,b.num_rows) > 50
and b.table_name = a.table_name
and table_owner = :gv_schema
order by a.table_name, index_name; 


prompt </TABLE>
exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM ******************************************************************
REM **************   Space used
REM ******************************************************************

prompt <a name="section2"></a><B><font size="+2">Value Chain Planning Freespace by Tablespace in GB</font></B><BR>
prompt <a name="section2.1"></a><font size="+1">Reports ASSM or manually managed segments.</font><BR><BR>

prompt <script type="text/javascript">    function displayRows5sql10(){var row = document.getElementById("s5sql10");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv159"></a>
prompt     <a name="top"><b><font size="+2"> Free Space by Tablespace </font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql10()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql10" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="left">
prompt        select extent_management Ext_Manage,<BR>
prompt         allocation_type Alloc_Type,<BR>
prompt         segment_space_management SPC_Manage,<BR>
prompt         substr(c.tablespace_name,1,25),<BR>
prompt        GB_alloc Gbytes, <BR>
prompt        GB_alloc-nvl(GB_free,0) used,<BR>
prompt        nvl(GB_free,0) free, <BR>
prompt        round(((GB_alloc-nvl(GB_free,0))/ GB_alloc)*100, 2) pct_used,<BR>
prompt        nvl(largest_GB,0) largest,<BR>
prompt        nvl(GB_max, GB_alloc) Max_Size,<BR>
prompt        from (select round(sum(bytes)/1024/1024,2) GB_free, <BR>
prompt         round(max(bytes)/1024/1024,2) largest_GB,<BR>
prompt         tablespace_name<BR>
prompt         from  sys.dba_free_space<BR> 
prompt         group by tablespace_name ) a,<BR>
prompt        ( select round(sum(bytes)/1024/1024,2) GB_alloc,<BR> 
prompt            round(sum(maxbytes)/1024/1024,2) GB_max,<BR>
prompt            tablespace_name <BR>
prompt            from sys.dba_data_files<BR> 
prompt            group by tablespace_name <BR>
prompt            union all<BR>
prompt            select round(sum(bytes)/1024/1024,2) GB_alloc,<BR> 
prompt            round(sum(maxbytes)/1024/1024,2) BB_max,<BR>
prompt            tablespace_name <BR>
prompt            from sys.dba_temp_files<BR> 
prompt            group by tablespace_name ) b,<BR>
prompt            dba_tablespaces c<BR>
prompt        where a.tablespace_name (+) = b.tablespace_name<BR>
prompt        and c.tablespace_name = b.tablespace_name<BR>
prompt        order by 1; </p><BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Ext_Manage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Alloc_Type</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>SPC_Manage</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Gbytes</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Used</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Free</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Used</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Largest</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Max_Size</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||extent_management||'</TD>'||chr(10)||
'<TD>'||allocation_type||'</TD>'||chr(10)||
'<TD>'||segment_space_management||'</TD>'||chr(10)||
'<TD>'||substr(c.tablespace_name,1,25)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_alloc,0)||'</TD>'||chr(10)||
'<TD>'||round((nvl(GB_alloc,0) - nvl(GB_free,0)),2)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_free,0)||'</TD>'||chr(10)||
'<TD>'||round(((nvl(GB_alloc,0) - nvl(GB_free,0))/ nvl(GB_alloc,0))*100, 2)||'</TD>'||chr(10)||
'<TD>'||nvl(largest_GB,0)||'</TD>'||chr(10)||
'<TD>'||nvl(GB_max, nvl(GB_alloc,0))||'</TD></TR>'
from ( select tablespace_name,
nvl(round(sum(bytes)/1024/1024,2),0) GB_Free,
nvl(round(max(bytes)/1024/1024,2),0) Largest_GB
from  sys.dba_free_space
group by tablespace_name ) a,
( select tablespace_name,
  nvl(round(sum(bytes)/1024/1024,2),0) GB_alloc,
  nvl(round(sum(maxbytes)/1024/1024,2),0) GB_max
  from sys.dba_data_files
  group by tablespace_name
  union all
  select tablespace_name,
  nvl(round(sum(bytes)/1024/1024,2),0) GB_alloc,
  nvl(round(sum(maxbytes)/1024/1024,2),0) GB_max
  from sys.dba_temp_files
  group by tablespace_name )b,
  dba_tablespaces c
where a.tablespace_name (+) = b.tablespace_name
and c.tablespace_name = b.tablespace_name
order by 1;
prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *********************************************************
REM ******* All Wait Statistics ***************************
REM *********************************************************

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="top"><b><font size="+2">Wait Statistics</font></b></a></p><br>
prompt     <a name="top"><font size="+1"> WAIT STATISTIC:<br><br>
prompt     Class - Class of block affected by contention<br>
prompt     Count - Number of waits by class of block<br>
prompt     Time - Sum of all wait times for class/block<BR>
prompt     Data Blocks - Possibly too many modified blocks in the buffer cache.  Investigate adding DBWR processes.<br>
prompt     Free List - If there are parallel loading programs.  Review the freelist performance guage above.<br>
prompt     Segment Header - There may be if full table scans are contending with a data loading processes.  Parallel options can add to the wait.<br>
prompt     Sort Block - Parallel Query option.  Reducing the degree of parallelism or decreasing the SORT_AREA_SIZE init.ora parameter setting may have a positive impact.<br>
prompt     Undo Block - Multiple users updating records in the same data block at a very fast rate. Investigate freelist and increasing the PCTFREE of the tables involved.<br>
prompt     Undo Header - You may not have enough rollback segments to support the number of concurrent transactions.  Produce an AWR report and investigate further.<br><br>
prompt     See: Troubleshooting I/O Related Waits (Doc ID 223117.1)<br>
prompt          High temporary usage by queries against dictionary tables with wait 'direct path write temp' (Doc ID 1591156.1)</font></a><br><br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

prompt <script type="text/javascript">    function displayRows5sql11(){var row = document.getElementById("s5sql11");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv160"></a>
prompt     <a name="top"><b><font size="+2"> Wait Statistics</font></B></a></font></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql11()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql11" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="50">
prompt       <blockquote><p align="center">
prompt      Select class,<BR>
prompt      count,<BR>
prompt      time<BR>
prompt      from v$waitstat<BR>
prompt      order by class<BR>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Class</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Count</B></TD> 
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Time</B></TD> 
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||class||'</TD>'||chr(10)||
'<TD>'||count||'</TD>'||chr(10)|| 
'<TD>'||time||'</TD><TR>' 
FROM v$waitstat
order by class;

prompt </TABLE>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>



REM
REM ******* System Statistics *******
REM

prompt <script type="text/javascript">    function displayRows5sql12(){var row = document.getElementById("s5sql12");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv161"></a>
prompt      <a name="top"><b><font size="+2"> System Statistics </font></B></a><br>
prompt      <a name="top"><font size="+1">Oracle recommends that you gather system statistics during peak load in order to give the optimizer the ability to choose the best plan based on<br>
prompt         system resource usage and throughput as well as the normal information about the database objects.<br>
prompt         System statistics are gathered to allow the optimizer to consider a system's I/O and CPU performance and utilization.<br><br>
prompt         They allow the optimizer to adjust access paths to allow for the actual performance of a particular system by recording actual system statistics.<br>
prompt         The statistics are collected using the DBMS_STATS.GATHER_SYSTEM_STATS procedure and are stored in SYS.AUX_STATS$.<br>
prompt         Do SREADTIM and MREADTIM have a value?  If not, run  DBMS_STATS.GATHER_SYSTEM_STATS<br><br>
prompt         Note: When new system statistics are gathered, unlike table, index or column statistics, Oracle does not invalidate existing parsed SQL statements <br>
prompt         which are already in the shared pool.  Only newly executed SQL statements will use the new system statistics.  You could run ALTER SYSTEM FLUSH shared_pool<br>
prompt         in order to make sure all new SQL statements are hard parsed and use the new system statistics, but this is probably not a good thing to do on a production <br>
prompt         system during times of high load.<br><br>
prompt         See: How to Collect and Display System Statistics (CPU and IO) for CBO use (Doc ID 149560.1)<br>
prompt              Statistics Gathering: Frequency and Strategy Guidelines (Doc ID 44961.1)<br>
prompt              Demantra 11g Statistics new Features and Best Practices Gather Schema Stats (Doc ID 1458911.1)</font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql12()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql12" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="2" height="185">
prompt       <blockquote><p align="left">
prompt       select pname, pval1 from sys.aux_stats$ where sname = 'SYSSTATS_MAIN';<br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param NAME</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_pname varchar2(60);
v_val1 varchar2(60);

Begin

stmt_str:= 'select pname, pval1 from sys.aux_stats$ where sname = ''SYSSTATS_MAIN''';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_pname, v_val1;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
           dbms_output.put_line('<TD>'||nvl(v_val1, (null))||'</TD>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM
REM ******* Verify the Health of Large Tables *******
REM

prompt <script type="text/javascript">    function displayRows5sql13(){var row = document.getElementById("s5sql13");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=8 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv162"></a>
prompt   <a name="top"><b><font size="+2"> Large Table Health Check</font></B></a>/<br> 
prompt   <a name="top"><b><font size="+1">Gather Database statistics on the main data tables such as mdp_matrix, sales_data, promotion_data and indexes.<br>
prompt   * After sufficient testing with good results, statistics can be locked on the tables for the Database optimizer to use. <br>
prompt   Fixed object and dictionary stats can be gathered to improve performance of recursive queries.<br>
prompt   - execute dbms_stats.gather_dictionary_stats;<br>
prompt   - execute dbms_stats.gather_fixed_objects_stats;<br>
prompt   - execute dbms_stats.delete_system_stats;<br>
prompt   - execute dbms_stats.gather_system_stats(gathering_mode=>'noworkload'); <br><br>
prompt   INITRANS Controls the initial transaction slots. Is this set correctly?;<br>
prompt   Doc ID:Demantra DB Health and Performance: Oracle Demantra Database Best Practices - Demantra Performance Clustering Factor;<br>
prompt   Out of Order Ratio TABLE_REORG CHECK_REORG (Doc ID 1499638.1);<br> 
prompt   IniTrans/MaxTrans:;<br>
prompt   Controls Transaction Slots (ITLs), and more specifically the number of ITLs a block can allocate on a table.;<br>
prompt   It is recommended that MaxTrans will be 255, but the IniTrans configuration should be set to the maximum; <br>  
prompt   number of parallel sessions modifying the table (you can start with 10 as a starting point if this information is not available).;</font></a></TD><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql13()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql13" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
prompt       <blockquote><p align="left">
prompt       SELECT num_rows, <br>
prompt       pct_free, <br>
prompt       chain_cnt, <br>
prompt       ini_trans, <br>
prompt       avg_row_len, <br>
prompt       degree, <br>
prompt       last_analyzed, <br>
prompt       partitioned, <br>
prompt       row_movement <br>
prompt       FROM   sys.dba_tables <br>
prompt       WHERE  table_name in ('SALES_DATA', 'MDP_MATRIX', 'PROMOTION_DATA');<br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Num Rows</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Pct Free</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Chain Cnt</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Ini_trans</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Avg Row Len</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Degree</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Last Analyzed</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Partitioned</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Row Movement</B></TD></tr>
exec :n := dbms_utility.get_time;
Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_numrows number;
v_pctfree number;
v_chain number;
v_ini_trans number;
v_avgrow number;
v_degree varchar2(40);
v_last_analyzed date;
v_partitioned varchar2 (20);
v_rowmove varchar2(8);

Begin

stmt_str:= 'SELECT num_rows, 
       pct_free, 
       chain_cnt, 
       ini_trans,
       avg_row_len, 
       degree,
       last_analyzed, 
       partitioned, 
       row_movement
FROM   sys.dba_tables
WHERE  table_name in (''SALES_DATA'', ''MDP_MATRIX'', ''PROMOTION_DATA'')';
     Open c1 for stmt_str ;
      LOOP
         FETCH c1 into v_numrows, v_pctfree, v_chain, v_ini_trans, v_avgrow, v_degree, v_last_analyzed, v_partitioned, v_rowmove;
        -- dbms_output.put_line('V Flag is in loop :'||v_flag);
         EXIT WHEN c1%NOTFOUND;
           dbms_output.put_line('<TR><TD>'||v_numrows||'</TD>');
           dbms_output.put_line('<TD>'||v_pctfree||'</TD>');
           dbms_output.put_line('<TD>'||v_chain||'</TD>');
           dbms_output.put_line('<TD>'||v_ini_trans||'</TD>');
           dbms_output.put_line('<TD>'||v_avgrow||'</TD>');
           dbms_output.put_line('<TD>'||v_degree||'</TD>');
           dbms_output.put_line('<TD>'||v_last_analyzed||'</TD>');
           dbms_output.put_line('<TD>'||v_partitioned||'</TD>');
           dbms_output.put_line('<TD>'||v_rowmove||'</TD>');
      END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM
REM ******* Analyze Table Sales_Data Validate Structure Cascade Fast - COMING SOON *******
REM
REM
REM Check for corruption
REM SQL> ANALYZE TABLE SALES_DATA VALIDATE STRUCTURE CASCADE FAST;
REM SQL> ANALYZE TABLE MDP_MATRIX VALIDATE STRUCTURE CASCADE FAST;
REM SQL> ANALYZE TABLE PROMOTION_DATA VALIDATE STRUCTURE CASCADE FAST;
REM
REM Info Note:
REM If the results indicate that there is corruption then run:
REM 
REM SQL> ANALYZE TABLE enter the table here VALIDATE STRUCTURE CASCADE;
REM 
REM prompt <script type="text/javascript">    function displayRows5sql14(){var row = document.getElementByIdREM ("s5sql14");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
REM prompt <TABLE border="1" cellspacing="0" cellpadding="2">
REM prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
REM prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv163"></a>
REM prompt     <a name="top"><font size="+1"><B> MaxDBConnections </font></B></a></TD>
REM prompt     <TD bordercolor="#DEE6EF">
REM prompt       <div align="right"><button onclick="displayRows5sql14()" >SQL Script</button></div>
REM prompt   </TD>
REM prompt </TR>
REM prompt <TR id="s5sql14" style="display:none">
REM prompt    <TD BGCOLOR=#DEE6EF colspan="10" height="185">
REM prompt       <blockquote><p align="left">
REM prompt          select * from schemaXXX.aps_params ;
REM prompt          <br>
REM prompt          </p>
REM prompt       </blockquote>
REM prompt     </TD>
REM prompt   </TR>
REM prompt <TR>
REM prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Param Name</B></TD>
REM prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Value String</B></TD>
REM prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Comments</B></TD></TR>
REM exec :n := dbms_utility.get_time;
REM 
REM Declare
REM stmt_str varchar2(1000);
REM TYPE CUR_TYPE	IS REF CURSOR;
REM c1 CUR_TYPE;
REM v_pname varchar2(60);
REM v_value varchar2(1000);
REM v_table_name varchar2(60);
REM 
REM Begin
REM 
REM stmt_str:= 'select pname, value_string from '||:gv_schema||'.'||'aps_params';
REM      Open c1 for stmt_str ;
REM       LOOP
REM          FETCH c1 into v_pname,v_value;
REM         -- dbms_output.put_line('V Flag is in loop :'||v_flag);
REM          EXIT WHEN c1%NOTFOUND;
REM         IF v_pname='maxdbconnections' THEN        
REM            dbms_output.put_line('<TR><TD>'||v_pname||'</TD>');
REM            dbms_output.put_line('<TD>'||v_value||'</TD>');
REM            dbms_output.put_line('<TD>'||'It is important to make sure that the application server will have all the needed threads to execute all parallel'||'</TD>');
REM            dbms_output.put_line('<TD>'||'requests; query executions, workflow runs, updates, etc.  A rule of thumb will be the number of concurrent'||'</TD>');
REM            dbms_output.put_line('<TD>'||'users * threadpool.query_run.per_user *10 (if threadpool.query_run.per_user > 4).'||'</TD>');
REM         END IF;
REM       END LOOP;
REM        close c1;
REM END;
REM /
REM 
REM prompt </TABLE><P><P>
REM 
REM prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
REM 
REM exec :n := (dbms_utility.get_time - :n)/100;
REM exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');
REM 
REM prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>
REM 
REM 


REM
REM ******* Verify Degree of Parallelism *******
REM

prompt <script type="text/javascript">    function displayRows5sql15(){var row = document.getElementById("s5sql15");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=1 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv164"></a>
prompt     <a name="top"><b><font size="+2"> Degree of Parallelism </font></B></a><br>
prompt     <a name="top"><font size="+1"> We recommend using either application or database parallel setting but not both at the same time since it is known to cause errors. <br>
prompt     For Example:<br><br>
prompt     If the SALES_DATA table is set to a parallel degree of 8, 8 processes will execute the parallel query. <br>
prompt     Implementing PARALLEL DEGREE on a table might not work so well for Demantra, because the Engine can run lots of queries at <br>
prompt     the same time.<br><br>  
prompt     If each of those is also a parallel query then you risk overloading the DB server.  The Demantra code knows<br>
prompt     how to take advantage of running queries in parallel without changing the table parallel degree, unfortunately this feature<br>
prompt     is only enabled when running on an Exadata or SuperCluster server hardware with the Demantra CDP license installed.') <br><br>
prompt     You will need to experiment with the parallel degree. </font></a></TD>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql15()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql15" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="2" height="185">
prompt       <blockquote><p align="left">
prompt          select table_name, degree from dba_tables ;
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Degree</B></TD></TR>
exec :n := dbms_utility.get_time;

Declare
stmt_str varchar2(1000);
TYPE CUR_TYPE IS REF CURSOR;
c1 CUR_TYPE;
v_name varchar2(60);
v_degree varchar(20);

Begin

stmt_str:= 'select table_name, degree from dba_tables';
     Open c1 for stmt_str;
      LOOP
         FETCH c1 into v_name,v_degree;
         EXIT WHEN c1%NOTFOUND;
        IF v_name='SALES_DATA' THEN        
           dbms_output.put_line('<TR><TD>'||v_name||'</TD>');
           dbms_output.put_line('<TD>'||v_degree||'</TD>');
        END IF;
        IF v_name='PROMOTION_DATA' THEN        
           dbms_output.put_line('<TR><TD>'||v_name||'</TD>');
           dbms_output.put_line('<TD>'||v_degree||'</TD>');
        END IF;  
        IF v_name='MDP_MATRIX' THEN        
           dbms_output.put_line('<TR><TD>'||v_name||'</TD>');
           dbms_output.put_line('<TD>'||v_degree||'</TD>');
        END IF;
        IF v_name='OE_ORDER_LINES_ALL' THEN        
           dbms_output.put_line('<TR><TD>'||v_name||'</TD>');
           dbms_output.put_line('<TD>'||v_degree||'</TD>');
        END IF;
       END LOOP;
       close c1;
END;
/
prompt </TABLE><P><P>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM *************************************************************************
REM ******* Report Chained Row Count *******
REM where chain_cnt >0 and num_rows > 0
REM *************************************************************************

prompt <script type="text/javascript">    function displayRows5sql16(){var row = document.getElementById("s5sql16");if (row.style.display == '')  row.style.display = 'none';	else row.style.display = '';    }</script>
prompt <TABLE border="1" cellspacing="0" cellpadding="2">
prompt <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">
prompt   <TD COLSPAN=9 bordercolor="#DEE6EF"><font face="Calibri"><a name="adv165"></a>
prompt     <a name="top"><b><font size="+2"> Chained Row count </font></B></a></TD>
prompt     <a name="top"><b><font size="+1"> See: Row Chaining and Row Migration (Doc ID 122020.1)<br>
prompt      How to Identify, Avoid and Eliminate Chained and Migrated Rows ? (Doc ID 746778.1)</font></a><br>
prompt     <TD bordercolor="#DEE6EF">
prompt       <div align="right"><button onclick="displayRows5sql16()" >SQL Script</button></div>
prompt   </TD>
prompt </TR>
prompt <TR id="s5sql16" style="display:none">
prompt    <TD BGCOLOR=#DEE6EF colspan="4" height="185">
prompt       <blockquote><p align="left">
prompt       select <br>
prompt       table_name,<br> 
prompt       pct_free, <br>
prompt       pct_used, <br>
prompt       avg_row_len, <br>
prompt       num_rows, <br>
prompt       chain_cnt,<br>
prompt       chain_cnt/decode(num_rows,0,1,num_rows) <br>
prompt       from dba_tables<br>
prompt       where owner = schema_owner <br>
prompt       and chain_cnt > 0 <br>
prompt       order by chain_cnt desc <br>
prompt          <br>
prompt          </p>
prompt       </blockquote>
prompt     </TD>
prompt   </TR>
prompt <TR>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Table Name</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Free</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>PCT_Used</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>AVG_Row_Length</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Num_Rows</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Chain_CNT</B></TD>
prompt <TD BGCOLOR=#DEE6EF><font face="Calibri"><B>Chain_PCT</B></TD></TR>
exec :n := dbms_utility.get_time;
select
'<TR><TD>'||table_name||'</TD>'||chr(10)||
'<TD>'||pct_free||'</TD>'||chr(10)||
'<TD>'||pct_used||'</TD>'||chr(10)||
'<TD>'||avg_row_len||'</TD>'||chr(10)||
'<TD>'||num_rows||'</TD>'||chr(10)||
'<TD>'||chain_cnt||'</TD>'||chr(10)||
'<TD>'||chain_cnt/decode(num_rows,0,1,num_rows)||'</TD></TR>'
from dba_tables
where owner = :gv_schema
and chain_cnt > 0
order by chain_cnt desc;

prompt </TABLE>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>


REM
REM ******* partitions *******
REM
REM Statistics on partitions, are you using incremental statistics?
REM Are there objects >5m rows?





REM **************************************************************************************** 
REM **************************************************************************************** 
REM **************************************************************************************** 
REM **************** END Section  : Performance Analyzer RDBMS Statistics *****************
REM ****************************************************************************************
REM **************************************************************************************** 
REM **************************************************************************************** 


rem  1. Set the database server sqlnet.ora parameter SQLNET.EXPIRE_TIME to '5' or higher 

REM
REM ******* Future Features *******
REM
REM
REM last_date_backup is set to 1 Jan 1900. It should ideally be equal to max_sales_date in sys_params. Please change it, bounce the application server, re-run the engine and let me know if it worked. Thanks.

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt   <tbody> <tr><td> 
prompt       <p><a name="adv166"><b><font size="+2">Future Features</font></b></a></p><br>
prompt     <B>  Future Features - Released as Often as Possible</B><br><br>
prompt 1. Should I consider partitioning?<br>
prompt 2. Display remaining logs if converted to PERL<br>
prompt 3. SQL used in plan options for form for demand schedules - for local schedules<br>
prompt    select scn.scenario_name,<br>
prompt    scn.demand_plan_name||':'||scn.scenario_name,<br>
prompt    lu.meaning,<br>
prompt    designator_type,<br>
prompt    scn.scenario_id,<br>
prompt    input_schedule_id,<br>
prompt    scn.error_type error_type,<br>
prompt    null ship_to<br>
prompt    from mfg_lookups lu, msd_dp_ascp_scenarios_v scn<br>
prompt    where lu.lookup_type = 'MSC_DESIGNATOR_TYPE_SHORT'<br>
prompt    and lu.lookup_code = 7<br>
prompt    and scn.global_scenario_flag ='N'<br>
prompt    and scn.scenario_name <> :mrp_plans.compile_designator<br>
prompt    and ( scn.sr_instance_id = -23453 or scn.sr_instance_id = :mrp_plan_orgs.sr_instance_id )<br>
prompt    and scn.last_revision is not null<br>
prompt    :mrp_plans.compile_designator is a variable from the form.<br><br>
prompt 4. SQL used in plan options for form for demand schedules - for global schedules<br>
prompt    select scn.scenario_name designator,<br>
prompt    scn.demand_plan_name||':'||scn.scenario_name description,<br>
prompt    lu.meaning,<br>
prompt    designator_type,<br>
prompt    scn.scenario_id input_schedule_id,<br>
prompt    scn.sr_instance_id<br>
prompt    from mfg_lookups lu, msd_dp_ascp_scenarios_v scn<br>
prompt    where lu.lookup_type = 'MSC_DESIGNATOR_TYPE_SHORT'<br>
prompt    and lu.lookup_code = 7 <br>
prompt    and scn.global_scenario_flag = 'Y'<br>
prompt    and scn.scenario_name <> :mrp_plans.compile_designator<br>
prompt    and scn.last_revision is not null<br>
prompt    ORDER BY 1,2;<br><br>
prompt 5. msd_dp_ascp_scenarios_v (view definition for demand_plan_id = 5555555)<br>
prompt    SELECT 5555555 demand_plan_id,<br>
prompt    SUBSTR(tl.name, 1, 30) demand_plan_name,<br>
prompt    tq.id + 5555555 scenario_id,<br>
prompt    SUBSTR(tq.query_name, 1, 30) scenario_name,<br>
prompt    -23453 organization_id,<br>
prompt    msd_dem_upload_forecast.get_sr_instance_id_for_profile(tq.id) sr_instance_id,<br>
prompt    msd_dem_upload_forecast.get_error_type(tq.id) error_type,<br>
prompt    'Y' consume_flag,<br>
prompt    msd_dem_upload_forecast.is_global_scenario (tq.id) global_scenario_flag,<br>
prompt    '1' last_revision<br>
prompt    FROM msd_dem_transfer_list tl,<br>
prompt    msd_dem_transfer_query tq<br>
prompt    WHERE tl.id = tq.transfer_id<br>
prompt    AND tq.integration_type <> 1<br>
prompt    AND tq.export_type = 1<br>
prompt    AND tq.presentation_type = 1<br><br>
prompt    AND msd_dem_upload_forecast.is_valid_scenario(tq.id) = 1;<br>
prompt 6. transfer_query<br>
prompt    select APPLICATION_ID from transfer_querywhere QUERY_NAME = <your integration interface>; <br>
prompt    select query_name FROM TRANSFER_QUERY WHERE application_id;<br>
prompt 7. wf_schema<br>
prompt 8. _ERR tables<br>
prompt 9. Verify Permissions.<br>
prompt 10. Report parameters that control ROLLING_UPDATES.<br>
prompt 11. Verify RunInsertUnits.<br>
prompt 12. Review your worksheet hints.<br>
prompt 13. Configurable Combinations in the Worksheet.<br>
prompt 14. Verify Ep_Load_Sales_LoadFromStagingTableDirectly.<br>
prompt 15. Verify Ep_Load_Sales_DisableEnableTriggers.<br>
prompt 16. Report Ep_Load_Sales_SALES_DATA_Merge_LoopControl.<br>
prompt 17. Review Verify ep_load_do_commits.<br>
prompt 18. Review using the redo log sizing advisor<br>
prompt 19. Verify profile setting MSD_DEM: Debug Mode<br>
prompt 20. Add 12.2.4 Known Issues Diagnostics<br>
prompt </td></tr></tbody> 
prompt </table><BR><BR>

exec :n := (dbms_utility.get_time - :n)/100;
exec dbms_output.put_line('<font size="-1"><i> Elapsed time '||:n|| ' seconds</i></font><P><P>');

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR

REM **************************************************************************************** 
REM *******                   Section 2 : References                                 *******
REM ****************************************************************************************

prompt <a name="section2"></a><B><font size="+2">References</font></B><BR><BR>
prompt <blockquote>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody><font size="-1" face="Calibri"><tr><td><p>   
prompt <br>
prompt <a href="https://communities.oracle.com/portal/server.pt/community/demantra_solutions/231" target="_blank">
prompt My Oracle Support - Demantra Communities</a><br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=1320509.1" target="_blank">
prompt This is where to list Demantra Information Center (PIC) (Doc ID xxxxxxx.1)</a><br>
prompt <br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=761234.1" target="_blank">
prompt Note 761234.1 - Demantra Log.History Parameter Clarification, a supplement to what is found in the Demantra Implementation Guide</a><br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=1458911.1" target="_blank">
prompt Note 1458911.1 - Demantra 11g Statistics new Features and Best Practices Gather Schema Stats</a><br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=1454588.1" target="_blank">
prompt Note 1454588.1 - How to configure Enhanced Engine logs for Engine Configured Either on Windows or Linux</a><br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=452817.1" target="_blank">
prompt Note 452817.1 - How To Get Forecasting Buckets Generated For The Entire Horizon When The Item Location Combination Is Dead</a><br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=751772.1" target="_blank">
prompt Note 751772.1 - Distributed Engine Windows and Linux Deploying Multiple Engines Howto and Troubleshoot</a><br>
prompt <a href="https://support.oracle.com/rs?type=doc\&id=741464.1" target="_blank">
prompt Note 741464.1 - Key Logs When Troubleshooting Demantra Issues</a><br>
prompt </p></font></td></tr></tbody>
prompt </table><BR><BR>

prompt <A href="#top"><font size="-1">Back to Top</font></A><BR><BR>
prompt </blockquote>


REM **************************************************************************************** 
REM *******                   Section 3 : Feedback                                   *******
REM ****************************************************************************************

prompt <a name="section3"></a><B><font size="+2">Feedback</font></B><BR><BR>
prompt <blockquote>

prompt <table border="1" name="NoteBox" cellpadding="10" bordercolor="#C1A90D" bgcolor="#FEFCEE" cellspacing="0">
prompt <tbody><font size="-1" face="Calibri"><tr><td><p>
prompt <B>Still have questions?</B><BR>Access the <a title="Live browser iFrame window"><em><font color="#FF0000"><b><font size="+1">Oracle Demantra Community</font></b></font></em></a> on My Oracle Support by clicking the FEEDBACK button below,
prompt to provide feedback, search for answers or start a new discussion about the Demantra Analyzer.<br>
prompt As always, you can email the author directly <A HREF="mailto:jeffery.goulette@oracle.com?subject=%20Demantra%20Analyzer%20Feedback
prompt \&body=Please attach a copy of your Demantra Analyzer output">here</A>.<BR>
prompt Be sure to include the output of the script for review.<BR>
prompt </p></font></td></tr></tbody>
prompt </table><BR><BR>

prompt <a href="https://community.oracle.com/message/12233735" target="_blank">
prompt <div align="center"><button style="background-color:#D7E8B0" >Click Here To Provide Feedback or Access the Oracle Demantra Community</button></a></div>


prompt <BR><A href="#top"><font size="-1">Back to Top</font></A><BR><BR>
prompt </blockquote>



REM
REM ******************** End of the Report *************************
REM

begin
select to_char(sysdate,'hh24:mi:ss') into :et_time from dual;
end;
/

declare
	st_hr1 varchar2(10);
	st_mi1 varchar2(10);
	st_ss1 varchar2(10);
	et_hr1 varchar2(10);
	et_mi1 varchar2(10);
	et_ss1 varchar2(10);
	hr_fact varchar2(10);
	mi_fact varchar2(10);
	ss_fact varchar2(10);
begin
	dbms_output.put_line('<br>PL/SQL Script was started at:'||:st_time);
	dbms_output.put_line('<br>PL/SQL Script is complete at:'||:et_time);
	st_hr1 := substr(:st_time,1,2);
	st_mi1 := substr(:st_time,4,2);
	st_ss1 := substr(:st_time,7,2);
	et_hr1 := substr(:et_time,1,2);
	et_mi1 := substr(:et_time,4,2);
	et_ss1 := substr(:et_time,7,2);

	if et_hr1 >= st_hr1 then
		hr_fact := to_number(et_hr1) - to_number(st_hr1);
	else
		hr_fact := to_number(et_hr1+24) - to_number(st_hr1);
	end if;
	if et_ss1 >= st_ss1 then
		mi_fact := to_number(et_mi1) - to_number(st_mi1);
		ss_fact := to_number(et_ss1) - to_number(st_ss1);
	else
		mi_fact := (to_number(et_mi1) - to_number(st_mi1))-1;
		ss_fact := (to_number(et_ss1)+60) - to_number(st_ss1);
	end if;
	dbms_output.put_line('<br><br>Total time taken to complete the script: '||hr_fact||' Hrs '||mi_fact||' Mins '||ss_fact||' Secs');
end;
/

prompt </HTML>

spool off
set heading on
set feedback on  
set verify on
exit
;

