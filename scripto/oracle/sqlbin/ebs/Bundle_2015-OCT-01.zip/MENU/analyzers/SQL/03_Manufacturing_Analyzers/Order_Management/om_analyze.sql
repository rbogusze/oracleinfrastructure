REM $Id: om_analyze.sql, 200.1 2015/15/01 23:27:42 arobert Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.13                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    om_analyze.sql                                                   |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the om_analyzer_pkg.main procedure       |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2
REM 
REM MENU_TITLE: Order Management Sales Order Analyzer
REM
REM MENU_START
REM
REM SQL: Run (ONT) Sales Order Analyzer
REM FNDLOAD: Load (ONT) Sales Order Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM 
REM 
REM HELP_START  
REM 
REM  Order Management (ONT) Sales Order Analyzer  [Doc ID: 1665244.1] 
REM
REM  Compatible: 12.0|12.1|12.2 
REM
REM  Explanation of available options:
REM
REM    (1) Run Order Management Analyzer: 
REM        o Runs om_analyzer_pkg.main as APPS and creates an HTML output file
REM
REM    (2) Install Order Management Analyzer as a Concurrent Program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "OM Concurrent Programs"
REM
REM 
REM HELP_END 
REM  
REM FNDLOAD_START 
REM
REM PROD_TOP: ONT_TOP
REM PROG_NAME: ONTSOANL
REM DEF_REQ_GROUP: OM Concurrent Programs
REM APP_NAME: Order Management
REM PROG_TEMPLATE: ONTSOAZ_prog.ldt
REM PROD_SHORT_NAME: ONT 
REM
REM FNDLOAD_END
REM
REM DEPENDENCIES_START 
REM 
REM om_analyzer.sql
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
-- PSD #1
PROMPT Submitting OM Analyzer.



BEGIN

-- PSD #4
  om_analyzer_pkg.main;

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
