REM +==============================================================================================================
REM |    Copyright (c) 2014 Oracle Corporation, Redwood Shores, CA, USA     
REM |                         All rights reserved.                          
REM +==============================================================================================================
REM | FILENAME                                                              
REM |  AR_AUTOACC_OBJECTS.sql                                            
REM |                                                                       
REM | DESCRIPTION                                                           
REM |   Script to create views required for value sets used by AutoAccounting Analyzer                       
REM |                                                                       
REM | HISTORY                                                               
REM |   23-JUL-2014 VCRISOST                            
REM +=======================================================================+
-- $Id: ar_autoacc_objects.sql,v 200.1 2014/07/23 16:04:00 vcrisost Exp $


/* create view used by ID parameter, for value set AR_AUTOACC_ID */
create or replace view AR_AUTOACC_ID as
select 'AutoInvoice' err_loc, interface_line_id id, null trx_number
from ra_interface_lines
where nvl(INTERFACE_STATUS,'X') <> 'P'
union
select 'Transaction Form' err_loc, customer_trx_id id, trx_number
from ra_customer_trx;


/* create view used by ID parameter, for value set AR_AUTOACC_WHERE */
create or replace view AR_AUTOACC_WHERE as
select 'AutoInvoice' err_loc from dual
union
select 'Transaction Form' err_loc from dual;

exit;