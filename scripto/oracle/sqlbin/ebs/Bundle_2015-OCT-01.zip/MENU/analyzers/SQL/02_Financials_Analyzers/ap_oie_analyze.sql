REM $Id: ap_oie_analyze.sql, 200.2 2015/08/10 10:47:50 skpasupu Exp skpasupu $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ap_oie_analyze.sql (was oie_setup.sql)                               |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the ap_oie_detect_pkg.main_pc                  |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 12-NOV-2012 SKPASUPU  Created.                                          |
REM | 20-MAR-2015 AROBERT   Removed as at end of SET ECHO command             |
REM | 10-AUG-2015 AROBERT   Added Bundle messages                             |
REM +=========================================================================+

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Internet Expenses (OIE) Analyzer
REM
REM MENU_START
REM SQL: Run Internet Expenses Analyzer
REM FNDLOAD: Load Internet Expenses Analyzer as a Concurrent Program 
REM MENU_END 
REM
REM HELP_START  
REM 
REM  Internet Expenses (OIE) Analyzer to Validate Setup, 
REM  Transaction Data Help [Doc ID: 1559272.1] 
REM
REM  Compatible: 12.0|12.1|12.2
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package AP_OIE_DETECT_PKG as APPS to create an HTML report 
REM
REM    (2) Install Internet Expenses Analyzer as a concurrent program
REM        o Will run FNDLOAD as APPS 
REM        o Will define the analyzer as a concurrent executable/program 
REM        o Will add the analyzer to default request group Payables Reports Only
REM
REM 
REM HELP_END 
REM
REM FNDLOAD_START 
REM
REM PROD_TOP: AP_TOP
REM PROG_NAME: APOIEAZ
REM DEF_REQ_GROUP: Payables Reports Only
REM APP_NAME: Payables
REM PROG_TEMPLATE: APOIEANL.ldt
REM PROD_SHORT_NAME: SQLAP 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ap_oie_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE 
REM
REM ANALYZER_BUNDLE_END


SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF
SET VERIFY OFF
SET DEFINE "&"

PROMPT ===========================================================================
PROMPT Enter the org_id(s) for the operating unit(s).  For multiple 
PROMPT operating units, separate with commas. (Mandatory)
PROMPT ===========================================================================
PROMPT
ACCEPT ous CHAR PROMPT 'Enter the OU org_id(s): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the person_id for the employee (Optional)
PROMPT ===========================================================================
PROMPT
ACCEPT per CHAR PROMPT 'Enter the Person_id: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the Responsibility Name (Optional) -- Payables, Vision Operations (USA)
PROMPT ===========================================================================
PROMPT
ACCEPT resp CHAR PROMPT 'Enter the responsibility name: '
PROMPT

DECLARE
  l_org_ids    VARCHAR2(240) :=  '&ous';
  l_per        number := '&per';
  l_resp       VARCHAR2(240) :=  '&resp';
  
BEGIN

  ap_oie_detect_pkg.main(
      p_org_ids => l_org_ids,
      p_per => l_per,
      p_resp => l_resp,
      p_debug_mode => 'Y');
      
EXCEPTION 
WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
EXIT
