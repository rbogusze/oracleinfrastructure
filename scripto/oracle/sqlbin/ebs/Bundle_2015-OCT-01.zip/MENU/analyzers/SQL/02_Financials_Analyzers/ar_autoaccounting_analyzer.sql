SET DEFINE '~'

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.17                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ar_autoaccounting_analyzer.sql                                       |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+

-- PSD #1
CREATE OR REPLACE PACKAGE ar_autoaccounting_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);
  

PROCEDURE main (
   p_org_id            IN NUMBER,
   p_account_type_in   IN VARCHAR2,
   p_missing_seg       IN NUMBER,
   p_where             IN VARCHAR2,
   p_id                IN NUMBER);
   

PROCEDURE main_cp(
   errbuf              OUT VARCHAR2,
   retcode             OUT VARCHAR2,
   p_org_id            IN NUMBER,
   p_account_type_in   IN VARCHAR2,
   p_missing_seg       IN NUMBER,
   p_where             IN VARCHAR2,
   p_id                IN NUMBER);
   

-- PSD #1
END ar_autoaccounting_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY ar_autoaccounting_analyzer_pkg AS
-- $Id: ar_autoaccounting_analyzer.sql, 200.1 2015/08/05 vcrisost Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;

g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1904785.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;

   
   TYPE autoacc_row IS RECORD
   (
    segment_name  FND_ID_FLEX_SEGMENTS_VL.segment_name%type,
    segment       ra_account_default_segments.segment%type,
    table_name    ra_account_default_segments.table_name%type,
    constant      ra_account_default_segments.constant%type,
    source        ra_account_default_segments.table_name%type
   );

   TYPE autoacc_tbl is TABLE of autoacc_row INDEX BY BINARY_INTEGER;
   autoacc_t autoacc_tbl;
   
   /*   
   p_org_id            NUMBER;
   p_account_type      VARCHAR2(10);
   p_account_type1     VARCHAR2(10) := NULL;
   p_missing_seg       NUMBER;
   p_where             VARCHAR2(10);
   p_id                NUMBER;
   */
   
   g_org_id            NUMBER := NULL;
   g_account_type      VARCHAR2(10) := NULL;
   g_account_type_exp  VARCHAR2(25) := NULL;
   g_missing_seg       NUMBER := NULL;
   g_where             VARCHAR2(30) := NULL;
   g_id                NUMBER := NULL;
   g_source_constant   BOOLEAN := FALSE;
   g_miss_table        ra_account_default_segments.table_name%type := NULL;
   g_inv_rule          ra_customer_trx.invoicing_rule_id%type;
   
   g_salesrep_id       NUMBER;
   g_salesrep_name     VARCHAR2(360);
   
   g_site_use_id       NUMBER;
   g_trx_type_id       NUMBER;
   g_trx_number        ra_customer_trx.trx_number%type;
   g_allow_clear         ra_batch_sources.create_clearing_flag%type;
   
   p_seg_ctr           NUMBER := 0;
   p_ctr           NUMBER := 0;
   p_site_id       NUMBER;
   p_trx_type_name VARCHAR2(20);
   p_trx_type_id   NUMBER;
   p_salesrep_ref  VARCHAR2(30);
   p_salesrep_id   NUMBER;
   p_site_ref      VARCHAR2(240);
   p_trx_type_ref  VARCHAR2(20);
   p_memo_line_ref VARCHAR2(50);
   p_mtl_system_items_seg1 VARCHAR2(40);
   p_mtl_system_items_seg2 VARCHAR2(40);
   p_mtl_system_items_seg3 VARCHAR2(40);
   p_mtl_system_items_seg4 VARCHAR2(40);
   p_mtl_system_items_seg5 VARCHAR2(40);
   p_mtl_system_items_seg6 VARCHAR2(40);
   p_mtl_system_items_seg7 VARCHAR2(40);
   p_mtl_system_items_seg8 VARCHAR2(40);
   p_mtl_system_items_seg9 VARCHAR2(40);
   p_mtl_system_items_seg10 VARCHAR2(40);
   p_mtl_system_items_seg11 VARCHAR2(40);
   p_mtl_system_items_seg12 VARCHAR2(40);
   p_mtl_system_items_seg13 VARCHAR2(40);
   p_mtl_system_items_seg14 VARCHAR2(40);
   p_mtl_system_items_seg15 VARCHAR2(40);
   p_mtl_system_items_seg16 VARCHAR2(40);
   p_mtl_system_items_seg17 VARCHAR2(40);
   p_mtl_system_items_seg18 VARCHAR2(40);
   p_mtl_system_items_seg19 VARCHAR2(40);
   p_mtl_system_items_seg20 VARCHAR2(40);
   p_line_id             NUMBER;
   p_inv_item_id         NUMBER;
   p_inv_item            VARCHAR2(40);
   p_memo_line_id        NUMBER;
   p_warehouse_id        NUMBER;
   p_memo                VARCHAR2(1) := 'N';
   p_item                VARCHAR2(1) := 'N';
   
   p_salesrep_number     VARCHAR2(30);
   p_account_number      hz_cust_accounts.account_number%type;
   p_party_name          hz_parties.party_name%type;
   p_site_number         hz_party_sites.party_site_number%type;
   p_trx_name            ra_cust_trx_types.name%type;
   p_memo_name           ar_memo_lines.name%type;
   p_allow_salescredits  ra_batch_sources.allow_sales_credit_flag%type;
   p_salesperson_rule    ra_batch_sources.salesperson_rule%type;
   p_cust_trx_type_rule  ra_batch_sources.cust_trx_type_rule%type;
   p_inventory_item_rule ra_batch_sources.inventory_item_rule%type;
   p_memo_reason_rule    ra_batch_sources.memo_reason_rule%type;
   p_bill_address_rule   ra_batch_sources.bill_address_rule%type;
   p_batch_source_name   ra_batch_sources.name%type;
   p_batch_id            ra_batch_sources.batch_source_id%type;
   p_bill_id             hz_cust_accounts.cust_account_id%type;
   p_bill_ref            hz_cust_accounts.orig_system_reference%type;
   p_site_use_id         NUMBER;
   

   p_miss_rev            VARCHAR2(1);
   p_miss_rec            VARCHAR2(1);
   p_miss_ue             VARCHAR2(1);
   p_miss_ub             VARCHAR2(1);
   p_miss_clearing       VARCHAR2(1);

   p_miss_table    ra_account_default_segments.table_name%type;
   p_miss_constant ra_account_default_segments.constant%type;

   CURSOR lines (trxid in NUMBER) is
   select memo_line_id, inventory_item_id, warehouse_id, customer_trx_line_id
   from ra_customer_trx_lines
   where customer_trx_id = trxid;

     
   
----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'ARAUTOACC_ANALYZER_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'ARAUTOACC_ANALYZER_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;

  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1904785.1:ARAUTOACC_200_1">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/ar_autoacc_latest_ver.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');

END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">DocId \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','S','I') THEN
    IF result = 'S' THEN
      g_sections(g_sections.last).result := 'S';
    ELSE
      g_sections(g_sections.last).result := result;
    END IF;
  ELSIF g_sections(g_sections.last).result = 'W' THEN
    IF result = 'E' THEN
      g_sections(g_sections.last).result := result;
    END IF;
  END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
  l_step := 'Validate parameters';
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1.'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2.'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4.'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);
/* commenting this as each has its own failure the parent should fail based on its own 
   criteria
           IF l_result in ('W','E') THEN
             l_fail_flag := true;
           END IF;
*/

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -- Print actions
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -- Print solution only if passed
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   --Code for Table of Contents of each section  
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   IF MOD(g_section_sig, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF l_sig_fail THEN
		  IF p_sig.fail_type ='E' THEN 
		  g_section_toc := g_section_toc || '<img class="error_ico">';       
		  ELSIF p_sig.fail_type ='W' THEN
			g_section_toc := g_section_toc ||'<img class="warn_ico">';   	 
		   end if;
	   end if;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF l_sig_fail THEN
		  IF p_sig.fail_type ='E' THEN 
		  g_section_toc := g_section_toc || '<img class="error_ico">';       
		  ELSIF p_sig.fail_type ='W' THEN
			g_section_toc := g_section_toc ||'<img class="warn_ico">';   	 
		   end if;
	   end if;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;

-------------------------
-- Recommended patches 
-------------------------
-- PSD #4
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;

  CURSOR get_app_date(p_ptch VARCHAR2) IS
  SELECT max(pr.start_date) app_date
  FROM ad_patch_runs pr
  WHERE pr.patch_run_id in (
          SELECT prb.patch_run_id
          FROM   ad_bugs b,
                 ad_patch_run_bugs prb
          WHERE  b.bug_number = p_ptch
          AND    prb.bug_id = b.bug_id
          UNION
          SELECT pr2.patch_run_id
          FROM ad_applied_patches ap,
               ad_patch_drivers pd,
               ad_patch_runs pr2
          WHERE ap.patch_name = p_ptch
          AND   pd.applied_patch_id = ap.applied_patch_id
          AND   pr2.patch_driver_id = pd.patch_driver_id);
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #4a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,2) = '12' THEN
    l_step := '20';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := 'N/A';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.0 Oracle Receivables Critical & Recommended Patches';
    l_col_rows(5)(1) := '[1473872.1]';

    l_step := '30';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '20260691';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.1: Receivables Recommended Patch Collection (AR RPC), Feb 2015';
    l_col_rows(5)(1) := '[1980300.1]';

    l_col_rows(1)(2) := '20042161';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'R12.1: E-Business Tax Recommended Patch Collection (ZX), Feb 2015';
    l_col_rows(5)(2) := '[1481235.1]';

    l_col_rows(1)(3) := '20307606';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'R12.1: E-Business Tax Reporting Ledger Recommended Patch Collection (ZX), Feb 2015';
    l_col_rows(5)(3) := '[1481235.1]';

  -- PSD #4a-end


  END IF;
  -- Check if applied
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i));
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;

PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RSGT1 (RS greater than 1), RS (row selected), NRS (no row selected)
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  P_INCLUDE_IN_DX_SUMMARY   VARCHAR2    DEFAULT 'N') --should signature be included in DX Summary
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters (
   p_org_id            IN NUMBER,
   p_account_type      IN VARCHAR2,
   p_missing_seg       IN NUMBER,
   p_where             IN VARCHAR2,
   p_id                IN NUMBER) 
IS

  l_from_date    VARCHAR2(25);
  l_to_date      VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;

  
  -- PSD #7a
  l_inv_id_1     NUMBER := NULL;
  l_chk_id_1     NUMBER := NULL;
  l_ppr_id       NUMBER := NULL; 
  l_federal      VARCHAR2(30);
  l_ss           VARCHAR2(255);
  l_key          VARCHAR2(255);
  
  p_ctr          NUMBER;
  g_max_seg      NUMBER;
  invalid_parameters EXCEPTION;

  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.1 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/08/05 08:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  
-- PSD #7
  g_rep_info('File Name') := 'ar_autoaccounting_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1904785.1" target="_blank">(Note 1904785.1)</a>' || ' is a self-service health-check script that reviews your AutoAccounting setup and provides feedback and recommendations. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  
  print_log('ar_autoaccounting_analyzer.sql');
  print_log('File Version = ' || l_revision);   
  print_log('Execution Date = ' || to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
  print_log('--------------------------------------------------------------');
  print_log('Parameters passed in are: ');
  print_log('   p_org_id = ' || p_org_id);
  print_log('   p_account_type = ' || p_account_type);
  print_log('   p_missing_seg = ' || p_missing_seg);
  print_log('   p_where = ' || p_where);
  print_log('   p_id = ' || p_id);
  print_log('--------------------------------------------------------------');
  print_log('Validating parameters');
  
  -- PSD #7a
   select count(*)
   into p_ctr
   from ar_system_parameters_all
   where org_id = p_org_id;

   if p_ctr <> 1 then
      print_log('ERROR: Invalid p_org_id Value = ' || p_org_id);
      raise invalid_parameters;
   else
      -- set Org context   
      mo_global.set_policy_context('S',p_org_id); 
      arp_global.init_global;
      print_log('1. p_org_id = ' || p_org_id || ' has been validated. Setting org context');
   end if;
   
   if upper(p_where) not in ('AUTOINV','TRXFORM','AUTOINVOICE','TRANSACTION FORM') then
      print_log('ERROR: Invalid p_where value = ' || upper(p_where));
      raise invalid_parameters;
   else
      if p_where = 'AUTOINVOICE' then
         g_where := 'AUTOINV';
      elsif p_where = 'TRANSACTION FORM' then
         g_where := 'TRXFORM';
      else
         g_where := upper(p_where);
      end if;
      print_log('2. p_where = ' || g_where || ' has been validated.');
   end if;
      
   -- validate ID parameter
   if nvl(p_id,-99) = -99 then
      print_log('ERROR: Invalid p_id value = ' || p_id);
      raise invalid_parameters;
   else 
      if g_where = 'TRXFORM' then
         begin
            select nvl(invoicing_rule_id, -88), primary_salesrep_id, bill_to_site_use_id, cust_trx_type_id, trx_number
            into g_inv_rule, g_salesrep_id, g_site_use_id, g_trx_type_id, g_trx_number
            from ra_customer_trx
            where customer_trx_id = p_id;           

            print_log('3. p_id = ' || p_id || ' has been validated against Transactions table.');
 
         exception
         when no_data_found then 
            print_log('ERROR: '|| p_id ||', does not exist in Transactions table.');
            raise invalid_parameters;
         end; 
      elsif g_where = 'AUTOINV' then
         begin
           select nvl(a.invoicing_rule_id, nvl(b.rule_id, -88)), nvl(c.create_clearing_flag,'N')
            into g_inv_rule, g_allow_clear
            from ra_interface_lines a, ra_rules b, ra_batch_sources c
            where nvl(a.invoicing_rule_name,'X-x-X') = b.name(+)
              and a.batch_source_name = c.name(+)
              and interface_line_id = p_id;
              
            print_log('3. p_id = ' || p_id || ' has been validated against Interface table.');

         exception 
         when no_data_found then
            print_log('ERROR: '|| p_id || ', does not exist in Interface table.');
            raise invalid_parameters;
         end;    
      end if;
   end if;
 
   if nvl(p_account_type,'XXX') not in ('REC','REV','OFFSET') then
      print_log('ERROR: Invalid Parameter Value = ' || p_account_type || ' for Account Type, please enter REC, REV or OFFSET');
      raise invalid_parameters;
   else
      g_account_type := p_account_type;
      -- reset values for OFFSET accounts      
      if g_account_type = 'OFFSET' then
         if g_inv_rule = -2 then
            -- In Advance
            g_account_type := 'UNEARN';
            g_account_type_exp := 'Unearned Reveue';
            print_log('4. OFFSET p_account_type has been validated and set to UNEARN.');
         elsif g_inv_rule = -3 then
            -- In Arrears
            g_account_type := 'UNBILL';
            g_account_type_exp := 'Unbilled Receivable';
            print_log('4. OFFSET p_account_type has been validated and set to UNBILL.');
         else
            -- no Invoicing Rules, is it SUSPENSE account then?
            if g_allow_clear = 'Y' then
               g_account_type := 'SUSPENSE';
               g_account_type_exp := 'AutoInvoice Clearing';
               print_log('4. OFFSET p_account_type has been validated and set to SUSPENSE.');
            else
               -- no offset account to check
               print_log('ERROR: p_account_type = ' || p_account_type ||' could not be properly set.');
               raise invalid_parameters;
            end if;
         end if;
      else
         if g_account_type = 'REV' then
            g_account_type_exp := 'Revenue';
         end if;
         if g_account_type = 'REC' then
            g_account_type_exp := 'Receivable';
         end if; 
         print_log('4. p_account_type = ' || p_account_type || ' has been validated.');
      end if;
   end if;   
   

   begin
      -- validate missing_seg   
      SELECT max(e.segment_num)
      into   g_max_seg
      FROM   FND_ID_FLEX_SEGMENTS_VL b,   
             GL_LEDGERS c,  
             AR_SYSTEM_PARAMETERS d,   
             RA_ACCOUNT_DEFAULT_SEGMENTS e,
             ra_account_defaults a
      WHERE  b.application_id = 101   
      AND    b.id_flex_code = 'GL#'     
      AND    d.set_of_books_id = c.ledger_id   
      AND    b.id_flex_num = c.chart_of_accounts_id  
      AND    e.segment = b.application_column_name  
      AND    a.gl_default_id = e.gl_default_id
      and    a.type = p_account_type;  
      
      if p_missing_seg > g_max_seg then
         print_log('ERROR: p_missing_seg = ' || p_missing_seg || ', exceeds the number of GL Account Segments =  ' || g_max_seg);
         raise invalid_parameters;
      else
         print_log('5. p_missing_seg = ' || p_missing_seg || ' has been validated.');
      end if;
      
  exception
  when no_data_found then
     print_log('Error: Could not find AutoAccounting setup.');
     print_log('Please complete the AutoAccounting Setup for ' || g_account_type || ':');
     print_log('1. Responsibility: Receivables Manager');
     print_log('2. Navigation: Setup > Transactions > AutoAccounting');
     print_log('3. Query for Type = ' || g_account_type_exp ||', and ensure you have defined Sources for all segments');
     raise invalid_parameters;
  end;
  
  -- set SQL TOKENS
  g_sql_tokens('##$$ACCOUNTTYPE$$##') := g_account_type;
  g_sql_tokens('##$$SALESREPID$$##') := g_salesrep_id;
  g_sql_tokens('##$$SITEUSEID$$##') := g_site_use_id;
  g_sql_tokens('##$$TRXTYPEID$$##') := g_trx_type_id;
  g_sql_tokens('##$$ID$$##') := g_id;
  g_sql_tokens('##$$ORGID$$##') := g_org_id;
  
  -- PSD #8
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Operating Unit') := g_org_id;
  g_parameters('2. Account Type') := p_account_type;
  g_parameters('3. Missing Segment') := g_missing_seg;
  g_parameters('4. Error Location') := g_where;
  g_parameters('5. ID') := g_id;
  
 

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


FUNCTION show_autoacc_setup RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
 
 
   CURSOR segments (accttype IN VARCHAR2) is
    SELECT b.segment_name, e.segment_num, e.table_name, e.constant,
           decode(e.table_name,'RA_CUST_TRX_TYPES',         'Transaction Types', 
                               'RA_SITE_USES',              'Site', 
                               'RA_SALESREPS',              'Salesreps', 
                               'RA_STD_TRX_LINES',          'Standard Lines',
                               e.table_name)         
    FROM   FND_ID_FLEX_SEGMENTS_VL b,   
           GL_LEDGERS c,  
           AR_SYSTEM_PARAMETERS d,   
           RA_ACCOUNT_DEFAULT_SEGMENTS e,
           ra_account_defaults a
    WHERE  b.application_id = 101   
    AND    b.id_flex_code = 'GL#'     
    AND    d.set_of_books_id = c.ledger_id   
    AND    b.id_flex_num = c.chart_of_accounts_id  
    AND    e.segment = b.application_column_name  
    AND    a.gl_default_id = e.gl_default_id
    and    a.type = accttype
    and    d.org_id = a.org_id
    order by segment_num;

   p_seg_ctr NUMBER := 0;

BEGIN

   -- Column headings

  l_step := '10';
  l_hdr.extend(4);
  l_hdr(1) := 'Segment Number';
  l_hdr(2) := 'Segment Name';
  l_hdr(3) := 'Source';
  l_hdr(4) := 'Status';

  print_log('Following are the segments & sources associated to ' || g_account_type);
  open segments(g_account_type);
  loop

     fetch segments into autoacc_t(p_seg_ctr);
     exit when segments%NOTFOUND;
     
     if autoacc_t(p_seg_ctr).segment_name is not null then
        l_step := to_char(20 + p_seg_ctr);

        l_col_rows.extend(4);
        l_col_rows(1)(p_seg_ctr+1) := p_seg_ctr + 1;
        l_col_rows(2)(p_seg_ctr+1) := autoacc_t(p_seg_ctr).segment_name;
        
        if autoacc_t(p_seg_ctr).table_name is not null then
           l_col_rows(3)(p_seg_ctr+1) := autoacc_t(p_seg_ctr).source;
           print_log(p_seg_ctr || ' ' || autoacc_t(p_seg_ctr).segment_name || '  ' || autoacc_t(p_seg_ctr).table_name );
           
           if p_seg_ctr = (g_missing_seg - 1) then
              -- segment is sourced from table          
              g_miss_table := autoacc_t(p_seg_ctr).table_name;
              l_col_rows(4)(p_seg_ctr+1) := 'Analyzer will verify this setup';
           else
              l_col_rows(4)(p_seg_ctr+1) := ' ';
           end if;
          
        elsif autoacc_t(p_seg_ctr).constant is not null then
           l_col_rows(3)(p_seg_ctr+1) := autoacc_t(p_seg_ctr).constant; 
           print_log(p_seg_ctr || ' ' || autoacc_t(p_seg_ctr).segment_name || '  ' || autoacc_t(p_seg_ctr).constant );
                         
           if p_seg_ctr = (g_missing_seg - 1) then
              -- segment is sourced from constant
              l_col_rows(4)(p_seg_ctr+1) := 'Analyzer not needed, segment is sourced from a constant value';
              g_source_constant := TRUE;
              g_miss_table := NULL;
              
           else
              l_col_rows(4)(p_seg_ctr+1) := ' ';
           end if;
        end if; 
     end if;
     
     p_seg_ctr := p_seg_ctr + 1;
   end loop;
   close segments;

   l_Step := '30';
   l_sig.title := 'Current ' || g_account_type || ' AutoAccounting Setup';
   l_sig.fail_condition := '[Status] = [Analyzer not needed, segment is sourced from a constant value]';  
   l_sig.problem_descr := 'Please check ' || g_account_type || ' AutoAccounting setup.';
   l_sig.solution := 'The AutoAccounting segment ' || g_missing_seg || ' is sourced from a constant.' ||
                     'This means no derivation logic is necessary and the segment should not be missing.' ||
                     'If you still have issues with this GL account, please review the GL segments in the error message and check that GL account is enabled.' ||
       '<ul><li><b>Responsibility:</b> General Ledger</li>' ||
       '<li><b>Navigation:</b> Setup > Accounts > Combinations </li>' ||
       '<li>Query for the GL account combination you are attempting to use and ensure it is enabled.</li></ul>';
   l_sig.success_msg := 'AutoAccounting Setup validated';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

   RETURN process_signature_results(
    'SHOW_AUTOACC_SETUP',  -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers

EXCEPTION 
WHEN OTHERS THEN
  print_log('Error retrieving AutoAccounting setup at step ' || l_step);
  raise;
END show_autoacc_setup;

---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN
-- PSD 9

  add_signature(
   'INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''AR%'')
    AND a.status = ''INVALID''',
   'Receivables Related Invalid Objects',
   'RS',
   'There exist invalid Receivables related objects',
   '<ul>
      <li>Recompile the individual objects manually or recompile the
          entire APPS schema with adadmin utility</li>
      <li>Review any error messages provided</li>
   </ul>',
   'No Receivables related invalid objects exists in the database',
   'ALWAYS',
   'E',
    p_include_in_dx_summary => 'Y'  
   );
   

  -- signatures to handle AutoAccounting from Salesperson Setup
  -------------------------------------------------------------
  add_signature(
   'GET_SALESREPS_CCID_REV',
   'SELECT name
    FROM ra_salesreps
    WHERE salesrep_id = ##$$SALESREPID$$##
    and nvl(gl_id_rev,-1) = -1',
   'Salesperson Setup',
   'RS',
   'You have not setup a GL Account for Revenue for this Salesperson' ,
   'Please define a Revenue Account as follows:<br>
    <b>Responsibility:</b> CRM Resource Manager<br>
    <b>Navigation:</b> Maintain Resources > Resources
    <ol><li>Query for Name shown above </li>
        <li>Click on Resource Details button </li>
        <li>Navigate to the Receivables tab </li>
        <li>Scroll to the right and enter a GL Account in the <b>Revenue Account</b> field </li>
    </ol>',
   null,
   'FAILURE',
   'E',
    'RS',
    p_include_in_dx_summary => 'Y'  );

  add_signature(
   'GET_SALESREPS_CCID_REC',
   'SELECT name
    FROM ra_salesreps
    WHERE salesrep_id = ##$$SALESREPID$$##
    and nvl(gl_id_rec,-1) = -1',
   'Salesperson Setup',
   'RS',
   'You have not setup a GL Account for Receivable for this Salesperson' ,
   'Please define a Receivable Account as follows:<br>
    <b>Responsibility:</b> CRM Resource Manager<br>
    <b>Navigation:</b> Maintain Resources > Resources
    <ol><li>Query for Name shown above </li>
        <li>Click on Resource Details button </li>
        <li>Navigate to the Receivables tab </li>
        <li>Scroll to the right and enter a GL Account in the <b>Receivable Account</b> field </li>
    </ol>',
   null,
   'FAILURE',
   'E',
    'RS',
    p_include_in_dx_summary => 'Y');
    
  add_signature(
   'LIST_ERR_SALESREPS',
   'select salesrep_number, name salesrep_name, decode(nvl(gl_id_rec,-1),-1,''Y'',''N'') Missing_Receivable, decode(nvl(gl_id_rev,-1),-1,''Y'',''N'') Missing_Revenue
    from   ra_salesreps
    where  (nvl(gl_id_rec,-1) = -1 or
            nvl(gl_id_rev,-1) = -1)',
   'Salesperson Records with Incomplete Revenue/Receivable Account Setup',
   'RS',
   'This list shows other Salesperson records in your instance that have incomplete Receivable or Revenue Account Setup' ,
   'If you use any of these salespersons in a transaction, and your AutoAccounting is sourced from Salesperson, you will encounter errors in AutoAccounting. You are advised to fix these records as follows:<br>
    <b>Responsibility:</b> CRM Resource Manager<br>
    <b>Navigation:</b> Maintain Resources > Resources
    <ol><li>Query for Name shown in list above</li>
        <li>Click on Resource Details button </li>
        <li>Navigate to the Receivables tab </li>
        <li>Scroll to the right and enter a GL Account in the <b>Receivables Account</b> or <b>Revenue Account field</b> </li>
    </ol>',
   null,
   'FAILURE',
   'W',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );

  -- signatures to handle AutoAccounting from Transaction Type Setup
  ------------------------------------------------------------------
  add_signature(
   'GET_TRX_CCID_REV',
    'SELECT name
    FROM ra_cust_trx_types
    WHERE cust_trx_type_id = ##$$TRXTYPEID$$##
    AND nvl(gl_id_rev,-1) = -1',
   'Transaction Type Setup',
   'RS',
   'You have not setup a GL Account for Revenue for this Transaction Type',
   'Please define a GL account as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Transaction Types 
    <ol><li>Query for Name shown above</li>
        <li>Go to the Account tab and enter a GL Account for <b>Revenue Account</b></li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
    p_include_in_dx_summary => 'Y'  );

  add_signature(
   'GET_TRX_CCID_REC',
    'SELECT name
    FROM ra_cust_trx_types
    WHERE cust_trx_type_id = ##$$TRXTYPEID$$##
    and nvl(gl_id_rec,-1) = -1',
   'Transaction Type Setup',
   'RS',
   'You have not setup a GL Account for Receivable for this Transaction Type',
   'Please define a GL account as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Transaction Types
    <ol><li>Query for Name shown above</li>
        <li>Go to the Account tab and enter a GL Account for <b>Receivable Account</b></li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
    p_include_in_dx_summary => 'Y'  );

  add_signature(
   'GET_TRX_CCID_UNEARN',
    'SELECT name
    FROM ra_cust_trx_types
    WHERE cust_trx_type_id = ##$$TRXTYPEID$$##
    and nvl(gl_id_unearned,-1) = -1',
   'Transaction Type Setup',
   'RS',
   'You have not setup a GL Account for Unearned Revenue for this Transaction Type',
   'Please define a GL account as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Transaction Types
    <ol><li>Query for Name shown above</li>
        <li>Go to the Account tab and enter a GL Account for <b>Unearned Revenue Account</b></li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
    p_include_in_dx_summary => 'Y'  );

  add_signature(
   'GET_TRX_CCID_UNBILL',
    'SELECT name
    FROM ra_cust_trx_types
    WHERE cust_trx_type_id = ##$$TRXTYPEID$$##
    and nvl(gl_id_unbilled,-1) = -1',
   'Transaction Type Setup',
   'RS',
   'You have not setup a GL Account for Unbilled Receivable for this Transaction Type',
   'Please define a GL account as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Transaction Types
    <ol><li>Query for Name shown above</li>
        <li>Go to the Account tab and enter a GL Account for <b>Unbilled Receivable Account</b></li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
    p_include_in_dx_summary => 'Y'  );

  add_signature(
   'GET_TRX_CCID_SUSPENSE',
    'SELECT name
    FROM ra_cust_trx_types
    WHERE cust_trx_type_id = ##$$TRXTYPEID$$##
    and nvl(gl_id_clearing,-1) = -1',
   'Transaction Type Setup',
   'RS',
   'You have not setup a GL Account for Clearing Account for this Transaction Type',
   'Please define a GL account as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Transaction Types
    <ol><li>Query for Name shown above</li>
        <li>Go to the Account tab and enter a GL Account for <b>Clearing Account</b></li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
    p_include_in_dx_summary => 'Y'  );
   
  add_signature(
   'LIST_ERR_TRXTYPES',
   '   select name, decode(nvl(gl_id_rec,-1),-1,''Y'',''N'') Missing_Receivable, decode(nvl(gl_id_rev,-1),-1,''Y'',''N'') Missing_Revenue,
          decode(nvl(gl_id_unbilled,-1),-1,''Y'',''N'') Missing_Unbilled_Receivable, decode(nvl(gl_id_unearned,-1),-1,''Y'',''N'') Missing_Unearned_Revenue,
          decode(nvl(gl_id_clearing,-1),-1,''Y'',''N'') Missing_Clearing
   from   ra_cust_trx_types
   where  (nvl(gl_id_rec,-1) = -1 or
           nvl(gl_id_rev,-1) = -1 or
           nvl(gl_id_unbilled,-1) = -1 or
           nvl(gl_id_unearned,-1) = -1 or
           nvl(gl_id_clearing,-1) = -1)',
   'Transaction Type Records with Incomplete GL Account Setup',
   'RS',
   'This list shows other Transaction Type records in your instance that have incomplete GL Account Setup' ,
   'If you use any of these Transaction Types in a transaction, and your AutoAccounting is sourced from Transaction Type, you will encounter errors in AutoAccounting.     
    You are advised to fix these records as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Transaction Types
    <ol><li>Query for Name shown in list above</li>
        <li>In the Accounts tab enter a GL account for fields shown as Missing in the list above </li>
    </ol>',
   null,
   'FAILURE',
   'W',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );
   
   -- signatures to handle AutoAccounting from Site Use Setup
   -----------------------------------------------------------
   add_signature(
   'GET_SITE_CCID_REV',
   'select hp.party_name, hca.account_number,  hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, ra_customer_trx trx, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id 
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = trx.bill_to_site_use_id
       and hca.cust_account_id = trx.bill_to_customer_id
       and trx.customer_trx_id = ##$$ID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_rev,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Revenue for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Revenue Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     
   
   add_signature(
   'GET_SITE_CCID_REC',
   'select hp.party_name, hca.account_number,  hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, ra_customer_trx trx, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id 
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = trx.bill_to_site_use_id
       and hca.cust_account_id = trx.bill_to_customer_id
       and trx.customer_trx_id = ##$$ID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_rec,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Receivable for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Receivable Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     

   add_signature(
   'GET_SITE_CCID_UNEARN',
   'select hp.party_name, hca.account_number,  hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, ra_customer_trx trx, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id 
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = trx.bill_to_site_use_id
       and hca.cust_account_id = trx.bill_to_customer_id
       and trx.customer_trx_id = ##$$ID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_unearned,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Unearned Revenue for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Unearned Revenue Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     


   add_signature(
   'GET_SITE_CCID_UNBILL',
   'select hp.party_name, hca.account_number,  hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, ra_customer_trx trx, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id 
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = trx.bill_to_site_use_id
       and hca.cust_account_id = trx.bill_to_customer_id
       and trx.customer_trx_id = ##$$ID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_unbilled,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Unbilled Receivable for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Unbilled Receivable Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     

   add_signature(
   'GET_SITE_CCID_SUSPENSE',
   'select hp.party_name, hca.account_number,  hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, ra_customer_trx trx, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id 
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = trx.bill_to_site_use_id
       and hca.cust_account_id = trx.bill_to_customer_id
       and trx.customer_trx_id = ##$$ID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_clearing,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Clearing Account for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Clearing Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );    
   
   add_signature(
   'GET_SITE_CCID_AI_REV',
   'select hp.party_name, hca.account_number, hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = ##$$SITEUSEID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_rev,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Revenue for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Revenue Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     

   add_signature(
   'GET_SITE_CCID_AI_REC',
   'select hp.party_name, hca.account_number,  hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = ##$$SITEUSEID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_rec,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Receivable for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Receivable Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     

   add_signature(
   'GET_SITE_CCID_AI_UNEARN',
   'select hp.party_name, hca.account_number, hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = ##$$SITEUSEID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_unearned,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Unearned Revenue for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Unearned Revenue Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     


   add_signature(
   'GET_SITE_CCID_AI_UNBILL',
   'select hp.party_name, hca.account_number, hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = ##$$SITEUSEID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_unbilled,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Unbilled Receivable for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Unbilled Receivable Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     

   add_signature(
   'GET_SITE_CCID_AI_SUSPENSE',
   'select hp.party_name, hca.account_number, hps.party_site_number
        from hz_cust_accounts  hca, hz_parties hp, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
       where hps.party_id = hp.party_id
       and hca.party_id = hps.party_id
       and hcas.cust_account_id = hca.cust_account_id
       and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
       and hcas.party_site_id = hps.party_site_id
       and hcsu.site_use_id = ##$$SITEUSEID$$##
       and hcsu.site_use_code = ''BILL_TO''
       and nvl(hcsu.gl_id_clearing,-1) = -1',
   'Site Use Setup',
   'RS',
   'You have not setup a GL Account for Clearing Account for this Site Use',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Enter a GL account for <b>Clearing Account</b> </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );  
   
   add_signature(
   'LIST_ERR_SITES',
   'select hp.party_name, hca.account_number, hps.party_site_number, 
          decode(nvl(gl_id_rec,-1),-1,''Y'',''N'') Missing_Receivable, decode(nvl(gl_id_rev,-1),-1,''Y'',''N'') Missing_Revenue,
          decode(nvl(gl_id_unbilled,-1),-1,''Y'',''N'') Missing_Unbilled, decode(nvl(gl_id_unearned,-1),-1,''Y'',''N'') Missing_Unearned,
          decode(nvl(gl_id_clearing,-1),-1,''Y'',''N'') Missing_Clearing
   from   hz_cust_accounts  hca, hz_parties hp, hz_party_sites hps, hz_cust_site_uses hcsu, hz_cust_acct_sites hcas
   where  hps.party_id = hp.party_id
   and    hca.party_id = hps.party_id 
   and    hcas.cust_account_id = hca.cust_account_id
   and    hcas.cust_acct_site_id = hcsu.cust_acct_site_id
   and    hcas.party_site_id = hps.party_site_id
   and    hcsu.site_use_code = ''BILL_TO''
   and    hcsu.status = ''A''
   and    (nvl(gl_id_rec,-1) = -1 or
           nvl(gl_id_rev,-1) = -1 or
           nvl(gl_id_unbilled,-1) = -1 or
           nvl(gl_id_unearned,-1) = -1 or
           nvl(gl_id_clearing,-1) = -1)',
   'Site Use Records with Incomplete GL Account Setup',
   'RS',
   'This list shows other Site Use records in your instance that have incomplete GL Account Setup',
   'If you use any of these Site Use records in a transaction, and your AutoAccounting is sourced from Sites, you will encounter errors in AutoAccounting.
    You are advised to fix these records as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Customers > Customers
    <ol><li>Query for Name = Party Name shown above</li>
        <li>Go to the Account Section and locate Account Number as shown above and click on Details icon.</li>
        <li>In the Sites Section, locate Site Number as shown above, and click on Details icon.</li>
        <li>Go To Business Purposes tab, and locate the Bill To Record and Click on Details Icon.</li>
        <li>Review and Complete the missing GL account</ol>',
   null,
   'FAILURE',
   'W',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );   

   -- signatures to handle AutoAccounting from Inventory Items Setup
   -----------------------------------------------------------------
   
   add_signature(
   'GET_ITEM_CCID_REV',
   'SELECT segment1 Item_Name
    FROM mtl_system_items
    WHERE organization_id = nvl(decode(##$$WAREHOUSEID$$##,-99,NULL), to_number(oe_profile.value(''SO_ORGANIZATION_ID'',##$$ORGID$$##)))
    AND inventory_item_id = ##$$INVITEMID$$##
    AND nvl(sales_account,-1) = -1',
   'Inventory Item Setup',
   'RS',
   'You have not setup a GL Account for Revenue for this Inventory Item',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Items > Define items
    <ol><li>Query for Name as shown above</li>
        <li>Go to the Invoicing tabb, and enter a GL Account for <b>Sales Account</b></li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     
   
  add_signature(
   'LIST_ERR_ITEMS',
   'SELECT segment1 Item_Name
    FROM mtl_system_items
    WHERE organization_id = nvl(decode(##$$WAREHOUSEID$$##,-99,NULL), to_number(oe_profile.value(''SO_ORGANIZATION_ID'',##$$ORGID$$##)))
    AND nvl(sales_account,-1) = -1',
   'Inventory Item Records with Incomplete GL Account Setup',
   'RS',
   'This list shows other Inventory Item records in your instance that have incomplete GL Account Setup',
   'If you use any of these Inventory Items in a transaction, and your AutoAccounting is sourced from Standard Lines, you will encounter errors in AutoAccounting.
    You are advised to fix these records as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Items > Define items
    <ol><li>Query for Name as shown above</li>
        <li>Go to the Invoicing tab, and enter a GL Account for <b>Sales Account</b></li></ol>',
   null,
   'FAILURE',
   'W',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );     


   -- signatures to handle AutoAccounting from Memo Lines Setup
   -----------------------------------------------------------------

   add_signature(
   'GET_MEMO_CCID_REV',
   'SELECT name
    FROM ar_memo_lines
    WHERE memo_line_id = ##$$MEMOLINEID$$##
    AND nvl(gl_id_rev,-1) = -1',
   'Memo Lines Setup',
   'RS',
   'You have not setup a GL Account for Revenue for this Memo Line',
   'Please do the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Memo Lines
    <ol><li>Query for Name as shown above</li>
        <li>Enter a GL Account for the <b>Revenue Account</b></li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );  
   
  add_signature(
   'LIST_ERR_MEMOS',
   'select name
    from   ar_memo_lines
    where  nvl(gl_id_rev,-1) = -1',
   'Memo Line Records with Incomplete GL Account Setup',
   'RS',
   'This list shows other Memo Line records in your instance that have incomplete GL Account Setup',
   'If you use any of these Memo Lines in a transaction, and your AutoAccounting is sourced from Standard Lines, you will encounter errors in AutoAccounting.
    You are advised to fix these records as follows:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Memo Lines
    <ol><li>Query for Name as shown above</li>
        <li>Enter a GL Account for the <b>Revenue Account</b></li></ol>',
   null,
   'FAILURE',
   'W',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 
   
  
  add_signature(
   'BATCH_NOT_ALLOW_SALESCREDIT',
   'select name, ALLOW_SALES_CREDIT_FLAG
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and nvl(ALLOW_SALES_CREDIT_FLAG,''N'') = ''N''',
   'Batch Source Does Not Allow Sales Credit',
   'RS',
   'The batch source you have chosen does not allow Sales Credits and yet your AutoAccounting is Sourced from Sales Person',
   'If you use any of these Memo Lines in a transaction, and your AutoAccounting is sourced from Standard Lines, you will encounter errors in AutoAccounting.
    Please correct the batch source setting:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Name as shown above</li>
        <li>navigate to the AutoInvoice Options tab, and Check the Allow Sales Credit checkbox</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 
   
   -- Signatures to handle Checking Batch Source for AutoInvoice
  add_signature(
   'BATCH_NO_SALESREP_ID',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and SALESPERSON_RULE = ''Id''
    and nvl(##$$SALESREPID$$##,-88) = -88',
   'Batch Source requires Salesrep ID',
   'RS',
   'The Batch Source requires you to provide a Salesperson ID but RA_INTERFACE_LINES.PRIMARY_SALESREP_ID is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Sales Credit Validation tab, review the setting for Salesperson</li>
        <li>Since Salesperson = Id, you need to provide a value in RA_INTERFACE_LINES.PRIMARY_SALESREP_ID</li>
        <li>If you want to provide RA_INTERFACE_LINES.PRIMARY_SALESREP_NUMBER instead in the Interface data, then change the settings in the Batch Source definition to Salesperson = Number</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 

  add_signature(
   'BATCH_NO_SALESREP_NUMBER',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and SALESPERSON_RULE = ''Number''
    and nvl(''##$$SALESREPNUMBER$$##'',''X-x-X'') = ''X-x-X''',
   'Batch Source requires Salesrep Number',
   'RS',
   'Batch Source requires you to provide a Salesperson Number but RA_INTERFACE_LINES.PRIMARY_SALESREP_NUMBER is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Sales Credit Validation tab, review the setting for Salesperson</li>
        <li>Since Salesperson = Number, you need to provide a value in RA_INTERFACE_LINES.PRIMARY_SALESREP_NUMBER</li>
        <li>If you want to provide RA_INTERFACE_LINES.PRIMARY_SALESREP_ID instead in the Interface data, then change the settings in the Batch Source definition to Salesperson = Id</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );  
   
  add_signature(
   'BATCH_NO_SALESREP_SETUP',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and nvl(SALESPERSON_RULE,''X-x-X'') = ''X-x-X''',
   'Batch Source is missing the setup for Salesperson',
   'RS',
   'The batch source does not specify whether Salesperson is Id or Number',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Sales Credit Validation tab, review the setting for Salesperson</li>
        <li>For Salesperson, pick either Number or Id</li>
        <li>If the batch shows that Number or ID is picked for Salesperson and yet you get this error, then please just make a dummy change to reset the values to force the form to save the correct settings to the table.</li>
        <li>Next, check your interface data to provide the expected value</li>
        <li>If you set Salesperson = Id, then provide a value in RA_INTERFACE_LINES.PRIMARY_SALESREP_ID</li>
        <li>If you set Salesperson = Number, then provide a value in RA_INTERFACE_LINES.PRIMARY_SALESREP_NUMBER</li>
        </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );
   
  add_signature(
   'BATCH_NO_TRXTYPE_ID',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and CUST_TRX_TYPE_RULE = ''Id''
    and nvl(##$$TRXTYPEID$$##,-88) = -88',
   'Batch source requires Transaction Type ID',
   'RS',
   'The Batch Source requires you to provide a Transaction Type ID but RA_INTERFACE_LINES.CUST_TRX_TYPE_ID is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Transacion type</li>
        <li>Since Transaction Type = Id, you need to provide a value in RA_INTERFACE_LINES.CUST_TRX_TYPE_ID</li>
        <li>If you want to provide RA_INTERFACE_LINES.CUST_TRX_TYPE_NAME instead in the Interface data, then change the settings in the Batch Source definition to Transaction Type = Value</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 

  add_signature(
   'BATCH_NO_TRXTYPE_VALUE',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and CUST_TRX_TYPE_RULE = ''Value''
    and nvl(''##$$TRXTYPENAME$$##'',''X-x-X'') = ''X-x-X''',
   'Batch Source requires Transaction Type Name',
   'RS',
   'The Batch Source requires you to provide a Transaction Type Name but RA_INTERFACE_LINES.CUST_TRX_TYPE_NAME is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Transacion type</li>
        <li>Since Transaction Type = Value, you need to provide a value in RA_INTERFACE_LINES.CUST_TRX_TYPE_NAME</li>
        <li>If you want to provide RA_INTERFACE_LINES.CUST_TRX_TYPE_ID instead in the Interface data, then change the settings in the Batch Source definition to Transaction Type = Id</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 
   
  add_signature(
   'BATCH_NO_TRXTYPE_SETUP',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and nvl(CUST_TRX_TYPE_RULE,''X-x-X'') = ''X-x-X''',
   'Batch source is missing the setup for Transaction Type',
   'RS',
   'The batch source does not specify whether Transaction Type is Id or Value',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Transacion type</li>
        <li>For Transaction type, pick either Id or Value</li>
        <li>If the batch shows that ID or Value is picked for Transaction Type and yet you get this error, then please just make a dummy change to reset the values to force the form to save the correct settings to the table.</li>
        <li>Next, check your interface data to provide the expected value</li>
        <li>If you set Transaction Type = Id, then provide a value in RA_INTERFACE_LINES.CUST_TRX_TYPE_ID</li>
        <li>If you set Transaction Type = Value, then provide a value in RA_INTERFACE_LINES.CUST_TRX_TYPE_NAME</li>
        </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );
   
   add_signature(
   'BATCH_NO_SITE_ID',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and BILL_ADDRESS_RULE = ''Id''
    and nvl(##$$BILLID$$##,-88) = -88',
   'Batch source requires Bill to Address ID',
   'RS',
   'The batch source requires you to provide a Bill To Address ID but RA_INTERFACE_LINES.ORIG_SYSTEM_BILL_ADDRESS_ID is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Customer Information tab, review the setting for Bill to Address </li>
        <li>Since Bill to Address = Id, you need to provide a value in RA_INTERFACE_LINES.ORIG_SYSTEM_BILL_ADDRESS_ID</li>
        <li>If you want to provide RA_INTERFACE_LINES.ORIG_SYSTEM_BILL_ADDRESS_REF instead in the Interface data, then change the settings in the Batch Source definition to Bill to Address = Value</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 

  add_signature(
   'BATCH_NO_SITE_VALUE',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and BILL_ADDRESS_RULE = ''Value''
    and nvl(''##$$BILLREF$$##'',''X-x-X'') = ''X-x-X''',
   'Batch Source requires Bill to Value',
   'RS',
   'The batch source requires you to provide a Bill to Address Value but your RA_INTERFACE_LINES.ORIG_SYSTEM_BILL_ADDRESS_REF is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Customer Information tab, review the setting for Bill to Address </li>
        <li>Since Bill to Address = Value, you need to provide a value in RA_INTERFACE_LINES.ORIG_SYSTEM_BILL_ADDRESS_REF</li>
        <li>If you want to provide RA_INTERFACE_LINES.ORIG_SYSTEM_BILL_ADDRESS_ID instead in the Interface data, then change the settings in the Batch Source definition to Bill to Address = Id</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );  
   
  add_signature(
   'BATCH_NO_SITE_SETUP',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and nvl(BILL_ADDRESS_RULE,''X-x-X'') = ''X-x-X''',
   'Batch Source is missing setup for Bill to Address',
   'RS',
   'The batch source does not specify whether Bill to Address is Id or Value',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Customer Information tab, review the setting for Bill to Address</li>
        <li>For Bill to Address, pick either Value or Id</li>
        <li>If the batch shows that Value or ID is picked for Bill To Address and yet you get this error, then please just make a dummy change to reset the values to force the form to save the correct settings to the table.</li>
        <li>Next, check your interface data to provide the expected value</li>
        <li>If you set Bill to Address = Id, then provide a value in RA_INTERFACE_LINES.ORIG_SYSTEM_BILL_ADDRESS_ID</li>
        <li>If you set Bill to Address = Value, then provide a value in RA_INTERFACE_LINES.ORIG_SYSTEM_BILL_ADDRESS_REF</li>
        </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );
     
  add_signature(
   'BATCH_NO_MEMO_ID',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and MEMO_REASON_RULE = ''Id''
    and nvl(##$$MEMOLINEID$$##,-88) = -88',
   'Batch Source requires Memo Reason ID',
   'RS',
   'The batch source requires you to provide a Memo Reason ID but RA_INTERFACE_LINES.MEMO_LINE_ID is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Memo Reason</li>
        <li>Since Memo Reason = Id, you need to provide a value in RA_INTERFACE_LINES.MEMO_LINE_ID</li>
        <li>If you want to provide RA_INTERFACE_LINES.MEMO_LINE_NAME instead in the Interface data, then change the settings in the Batch Source definition to Memo Reason = Value</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 

  add_signature(
   'BATCH_NO_MEMO_VALUE',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and MEMO_REASON_RULE = ''Value''
    and nvl(''##$$MEMOREF$$##'',''X-x-X'') = ''X-x-X''',
   'Batch Source requires Memo Reason Name',
   'RS',
   'The batch source requires you to provide a Memo Reason Name but RA_INTERFACE_LINES.MEMO_LINE_NAME is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Memo Reason</li>
        <li>Since Memo Reason = Value, you need to provide a value in RA_INTERFACE_LINES.MEMO_LINE_NAME</li>
        <li>If you want to provide RA_INTERFACE_LINES.MEMO_LINE_ID instead in the Interface data, then change the settings in the Batch Source definition to Memo Reason = Id</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 
   
  add_signature(
   'BATCH_NO_MEMO_SETUP',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and nvl(MEMO_REASON_RULE,''X-x-X'') = ''X-x-X''',
   'Batch Source is missing setup for Memo Reason',
   'RS',
   'The batch source does not specify whether Memo Reason is Id or Value',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Memo Reason</li>
        <li>For Memo Reason, pick either Id or Value</li>
        <li>If the batch shows that Id or Value is picked for Memo Reason and yet you get this error, then please just make a dummy change to reset the values to force the form to save the correct settings to the table.</li>
        <li>Next, check your interface data to provide the expected value</li>
        <li>If you set Memo Reason = Id, then provide a value in RA_INTERFACE_LINES.MEMO_LINE_ID</li>
        <li>If you set Memo Reason = Value, then provide a value in RA_INTERFACE_LINES.MEMO_LINE_NAME</li>
        </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );   
   
   add_signature(
   'NO_WAREHOUSE_ID',
   'select interface_line_id
    from ra_interface_lines
    where interface_line_id = ##$$ID$$##
    and nvl(WAREHOUSE_ID,-88) = -88',
   'Interface Line data does not contain a WAREHOUSE_ID value',
   'RS',
   'The system is unable to locate the inventory item because you have not provided a WAREHOUSE_ID value.',
   'Please check RA_INTERFACE_LINES.WAREHOUSE_ID and provide a valid value so system can locate the right inventory item.',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );   
   
  add_signature(
   'BATCH_NO_INV_ID',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and INVENTORY_ITEM_RULE = ''Id''
    and nvl(##$$INVITEMID$$##,-88) = -88',
   'Batch Source requires Inventory Item ID',
   'RS',
   'The Batch Source requires you to provide an Inventory Item ID but RA_INTERFACE_LINES.INVENTORY_ITEM_ID is null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Inventory ID</li>
        <li>Since Inventory Item = Id, you need to provide a value in RA_INTERFACE_LINES.INVENTORY_ITEM_ID</li>
        <li>If you want to provide segment values in RA_INTERFACE_LINES.MTL_SYSTEM_ITEMS_SEG% fields instead in the Interface data, then change the settings in the Batch Source definition to Inventory Item = Segment</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 

  add_signature(
   'BATCH_NO_INV_SEG',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and INVENTORY_ITEM_RULE = ''Segment''
    and nvl(''##$$INVITEMSEG1$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG2$$##'',''X-x-X'') = ''X-x-X''     
    and nvl(''##$$INVITEMSEG3$$##'',''X-x-X'') = ''X-x-X''   
    and nvl(''##$$INVITEMSEG4$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG5$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG6$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG7$$##'',''X-x-X'') = ''X-x-X''     
    and nvl(''##$$INVITEMSEG8$$##'',''X-x-X'') = ''X-x-X''   
    and nvl(''##$$INVITEMSEG9$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG10$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG11$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG12$$##'',''X-x-X'') = ''X-x-X''     
    and nvl(''##$$INVITEMSEG13$$##'',''X-x-X'') = ''X-x-X''   
    and nvl(''##$$INVITEMSEG14$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG15$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG16$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG17$$##'',''X-x-X'') = ''X-x-X''     
    and nvl(''##$$INVITEMSEG18$$##'',''X-x-X'') = ''X-x-X''   
    and nvl(''##$$INVITEMSEG19$$##'',''X-x-X'') = ''X-x-X''
    and nvl(''##$$INVITEMSEG20$$##'',''X-x-X'') = ''X-x-X''',
   'Batch Source requires Inventory Item Segments',
   'RS',
   'The batch source requires you to provide Inventory Item Segments, but RA_INTERFACE_LINES.MTL_SYSTEM_ITEMS_SEG% fields are null',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Inventory Item</li>
        <li>Since Inventory Item = Segment, you need to provide values in RA_INTERFACE_LINES.MTL_SYSTEM_ITEMS_SEG1 to 20 (to match the segments of your inventory item)</li>
        <li>If you want to provide RA_INTERFACE_LINES.INVENTORY_ITEM_ID instead in the Interface data, then change the settings in the Batch Source definition to Inventory Item = Id</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  ); 
   
  add_signature(
   'BATCH_NO_INV_SETUP',
   'select name
    from ra_batch_sources
    where name = ''##$$BATCHNAME$$##''
    and nvl(INVENTORY_ITEM_RULE,''X-x-X'') = ''X-x-X''',
   'Batch Source is missing setup for Inventory Item',
   'RS',
   'The batch source does not specify whether Inventory Item is Id or Segment',
   'Please check the following:<br>
    <b>Responsibility:</b> Receivables Manager<br>
    <b>Navigation:</b> Setup > Transactions > Sources
    <ol><li>Query for Batch Source name shown above</li>
        <li>Navigate to the Other Information tab, review the setting for Inventory Item</li>
        <li>For Memo Reason, pick either Id or Segment</li>
        <li>If the batch shows that ID or Segment is picked for Inventory Item and yet you get this error, then please just make a dummy change to reset the values to force the form to save the correct settings to the table.</li>
        <li>Next, check your interface data to provide the expected value</li>
        <li>If you set Inventory Item = Id, then provide a value in RA_INTERFACE_LINES.INVENTORY_ITEM_ID</li>
        <li>If you set Inventory Item = Segment, then provide a value in RA_INTERFACE_LINES.MTL_SYSTEM_ITEMS_SEG1 to 20 (to match the segments of your inventory item)</li>
        </ol>',
   null,
   'FAILURE',
   'E',
   'RS',
   'N',
    p_include_in_dx_summary => 'Y'  );   
   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;



---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10

PROCEDURE main (
   p_org_id            IN NUMBER,
   p_account_type_in   IN VARCHAR2,
   p_missing_seg       IN NUMBER,
   p_where             IN VARCHAR2,
   p_id                IN NUMBER) 
IS

  l_file_location    VARCHAR2(300);
  l_org_id_condition VARCHAR2(400);
  l_org_id_temp      NUMBER;
  l_req_id_temp      NUMBER;
  l_first            NUMBER := NULL;
  l_temp             number;
  l_checks_exists    varchar2(1);
  L_OBJECTS_EXISTS   VARCHAR2(1);
  l_source           varchar2(30);

  
  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

  l_continue   VARCHAR(1) := 'Y';
  bad_value    EXCEPTION;
BEGIN

   -- re-initialize values 
   g_sect_no := 1;
   g_sig_id := 0;
   g_item_id := 0;
  
   g_org_id := p_org_id;
   g_account_type := p_account_type_in;
   g_missing_seg := p_missing_seg;
   g_where := upper(p_where);
   g_id := p_id;
   
  l_step := '10';
  initialize_files;
  
  -- PSD #11
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Oracle Receivables AutoAccounting';

  l_step := '20';
 -- PSD #12
  print_log('Calling validate_parameters');
  
  validate_parameters(
    g_org_id,
    g_account_type,
    g_missing_seg,
    g_where,
    g_id);
 
  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  
  -- PSD #13
  
  print_log('--------------------------------------------------------------');
  print_log('Analyzing setup');
  
  start_section('Proactive Recommendations');
     set_item_result(check_rec_patches);
     set_item_result(run_stored_sig('INVALIDS'));
  end_section;
  
  start_section('Current ' || g_account_type || ' AutoAccounting Setup');
     set_item_result(show_autoacc_setup);
  end_section;
  

  start_section('AutoAccounting Setup Analysis');
     --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
     if g_where = 'TRXFORM' then 
     --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
     -- Error encountered in Transaction Form
        l_step := '80';
        if g_miss_table = 'RA_SALESREPS' then
           if g_account_type = 'REC' then         
              set_item_result(run_stored_sig('GET_SALESREPS_CCID_REC'));
           else
              set_item_result(run_stored_sig('GET_SALESREPS_CCID_REV'));
           end if;
           set_item_result(run_stored_sig('LIST_ERR_SALESREPS'));
        elsif g_miss_table = 'RA_CUST_TRX_TYPES' then
           if g_account_type = 'REC' then
              set_item_result(run_stored_sig('GET_TRX_CCID_REC'));
           elsif g_account_type = 'REV' then
              set_item_result(run_stored_sig('GET_TRX_CCID_REV'));
           elsif g_account_type = 'UNEARN' then
              set_item_result(run_stored_sig('GET_TRX_CCID_UNEARN'));
           elsif g_account_type = 'UNBILL' then
              set_item_result(run_stored_sig('GET_TRX_CCID_UNBILL'));
           elsif g_account_type = 'SUSPENSE' then
              set_item_result(run_stored_sig('GET_TRX_CCID_SUSPENSE'));
           end if;
           set_item_result(run_stored_sig('LIST_ERR_TRXTYPES')); 
        elsif g_miss_table = 'RA_SITE_USES' then
           if g_account_type = 'REV' then
              set_item_result(run_stored_sig('GET_SITE_CCID_REV'));
           elsif g_account_type = 'REC' then
              set_item_result(run_stored_sig('GET_SITE_CCID_REC'));
           elsif g_account_type = 'UNEARN' then
              set_item_result(run_stored_sig('GET_SITE_CCID_UNEARN'));
           elsif g_account_type = 'UNBILL' then
              set_item_result(run_stored_sig('GET_SITE_CCID_UNBILL'));
           elsif g_account_type = 'SUSPENSE' then
              set_item_result(run_stored_sig('GET_SITE_CCID_SUSPENSE'));       
           end if;
           set_item_result(run_stored_sig('LIST_ERR_SITES')); 
        elsif g_miss_table = 'RA_STD_TRX_LINES' then
           if g_account_type in ('REV','UNEARN','UNBILL') then
              open lines(g_id);
              loop
                 fetch lines into p_memo_line_id, p_inv_item_id, p_warehouse_id, p_line_id;
                 exit when lines%NOTFOUND;
            
                 if p_memo_line_id is not null then
                    p_memo := 'Y';
                    g_sql_tokens('##$$MEMOLINEID$$##') := p_memo_line_id;
                    print_log('In Loop: processing trx_line_id = ' || p_line_id || ' p_memo_line_id = ' || p_memo_line_id);
                    set_item_result(run_stored_sig('GET_MEMO_CCID_REV'));
                 end if;
 
                 if p_inv_item_id is not null then
                    p_item := 'Y';
                    g_sql_tokens('##$$INVITEMID$$##') := p_inv_item_id;
                    g_sql_tokens('##$$WAREHOUSEID$$##') := nvl(p_warehouse_id,-99);
                    print_log('In Loop: processing trx_line_id = ' || p_line_id || ' p_inv_item_id = ' || p_inv_item_id || ' p_warehouse_id = ' || p_warehouse_id); 
                    set_item_result(run_stored_sig('GET_ITEM_CCID_REV'));
        
                 end if;
               end loop;
               close lines;
           end if;     
           if p_memo = 'Y' then
              set_item_result(run_stored_sig('LIST_ERR_MEMOS'));
           end if;
           if p_item = 'Y' then
              set_item_result(run_stored_sig('LIST_ERR_ITEMS'));
           end if;
        elsif g_miss_table is NULL then
           print_log('AutoAccounting is sourced from a constant. Analyzer has no setup to verify.');
        end if;
     --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
     elsif g_where = 'AUTOINV' then
     --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------       
       -- error encountered in AutoInvoice
       -- gather data for AutoInvoice ID
       l_step := '70';
       select primary_salesrep_id, primary_salesrep_number, orig_system_bill_address_id, orig_system_bill_address_ref, orig_system_bill_customer_id, orig_system_bill_customer_ref,
            cust_trx_type_id, cust_trx_type_name, batch_source_name, memo_line_id, memo_line_name, inventory_item_id, warehouse_id, 
            MTL_SYSTEM_ITEMS_SEG1, MTL_SYSTEM_ITEMS_SEG2, MTL_SYSTEM_ITEMS_SEG3, MTL_SYSTEM_ITEMS_SEG4, MTL_SYSTEM_ITEMS_SEG5, 
            MTL_SYSTEM_ITEMS_SEG6, MTL_SYSTEM_ITEMS_SEG7, MTL_SYSTEM_ITEMS_SEG8, MTL_SYSTEM_ITEMS_SEG9, MTL_SYSTEM_ITEMS_SEG10, 
            MTL_SYSTEM_ITEMS_SEG11, MTL_SYSTEM_ITEMS_SEG12, MTL_SYSTEM_ITEMS_SEG13, MTL_SYSTEM_ITEMS_SEG14, MTL_SYSTEM_ITEMS_SEG15, 
            MTL_SYSTEM_ITEMS_SEG16, MTL_SYSTEM_ITEMS_SEG17, MTL_SYSTEM_ITEMS_SEG18, MTL_SYSTEM_ITEMS_SEG19, MTL_SYSTEM_ITEMS_SEG20
       into p_salesrep_id, p_salesrep_ref, p_site_id, p_site_ref, p_bill_id, p_bill_ref, 
          p_trx_type_id, p_trx_type_ref, p_batch_source_name, p_memo_line_id, p_memo_line_ref, p_inv_item_id, p_warehouse_id,
          p_mtl_system_items_seg1, p_mtl_system_items_seg2, p_mtl_system_items_seg3, p_mtl_system_items_seg4, p_mtl_system_items_seg5, 
          p_mtl_system_items_seg6, p_mtl_system_items_seg7, p_mtl_system_items_seg8, p_mtl_system_items_seg9, p_mtl_system_items_seg10, 
          p_mtl_system_items_seg11, p_mtl_system_items_seg12, p_mtl_system_items_seg13, p_mtl_system_items_seg14, p_mtl_system_items_seg15, 
          p_mtl_system_items_seg16, p_mtl_system_items_seg17, p_mtl_system_items_seg18, p_mtl_system_items_seg19, p_mtl_system_items_seg20
       from ra_interface_lines
       where interface_line_id = g_id; 
         
       g_sql_tokens('##$$SALESREPID$$##') := nvl(p_salesrep_id,-88);
       g_sql_tokens('##$$SALESREPNUMBER$$##') := nvl(p_salesrep_ref,'X-x-X');
       g_sql_tokens('##$$TRXTYPEID$$##') := nvl(p_trx_type_id,-88);
       g_sql_tokens('##$$TRXTYPENAME$$##') := nvl(p_trx_type_ref,'X-x-X');
       g_sql_tokens('##$$BILLID$$##') := nvl(p_bill_id,-88);
       g_sql_tokens('##$$BILLREF$$##') := nvl(p_bill_ref,'X-x-X');
       g_sql_tokens('##$$MEMOLINEID$$##') := nvl(p_memo_line_id,-88);
       g_sql_tokens('##$$MEMOREF$$##') := nvl(p_memo_line_ref,'X-x-X');
       g_sql_tokens('##$$INVITEMID$$##') := nvl(p_inv_item_id,-88);
       g_sql_tokens('##$$WAREHOUSEID$$##') := nvl(p_warehouse_id,-88);
       g_sql_tokens('##$$INVITEMSEG1$$##') := nvl(p_mtl_system_items_seg1,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG2$$##') := nvl(p_mtl_system_items_seg2,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG3$$##') := nvl(p_mtl_system_items_seg3,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG4$$##') := nvl(p_mtl_system_items_seg4,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG5$$##') := nvl(p_mtl_system_items_seg5,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG6$$##') := nvl(p_mtl_system_items_seg6,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG7$$##') := nvl(p_mtl_system_items_seg7,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG8$$##') := nvl(p_mtl_system_items_seg8,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG9$$##') := nvl(p_mtl_system_items_seg9,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG10$$##') := nvl(p_mtl_system_items_seg10,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG11$$##') := nvl(p_mtl_system_items_seg11,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG12$$##') := nvl(p_mtl_system_items_seg12,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG13$$##') := nvl(p_mtl_system_items_seg13,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG14$$##') := nvl(p_mtl_system_items_seg14,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG15$$##') := nvl(p_mtl_system_items_seg15,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG16$$##') := nvl(p_mtl_system_items_seg16,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG17$$##') := nvl(p_mtl_system_items_seg17,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG18$$##') := nvl(p_mtl_system_items_seg18,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG19$$##') := nvl(p_mtl_system_items_seg19,'X-x-X');
       g_sql_tokens('##$$INVITEMSEG20$$##') := nvl(p_mtl_system_items_seg20,'X-x-X');                    
       
       print_log('------------');
       print_log('INFORMATION: Interface Data: p_salesrep_id = ' || p_salesrep_id ||' p_salesrep_ref = ' || p_salesrep_ref || ' p_site_id = ' || p_site_id ||
               ' p_site_ref = ' || p_site_ref || ' p_trx_type_id = ' || p_trx_type_id || ' p_bill_id = ' || p_bill_id || ' p_bill_ref = ' || p_bill_ref ||
               ' p_trx_type_ref = ' || p_trx_type_ref || ' p_batch_source_name = ' || p_batch_source_name || ' p_memo_line_id = ' || p_memo_line_id ||
               ' p_memo_line_ref = ' || p_memo_line_ref || ' p_inv_item_id = ' || p_inv_item_id || 'p_mtl_system_items_seg1 = ' || p_mtl_system_items_seg1);
       print_log('------------');
            
       begin
          select batch_source_id, ALLOW_SALES_CREDIT_FLAG, SALESPERSON_RULE, CUST_TRX_TYPE_RULE, INVENTORY_ITEM_RULE, MEMO_REASON_RULE, BILL_ADDRESS_RULE
          into p_batch_id, p_allow_salescredits, p_salesperson_rule, p_cust_trx_type_rule, p_inventory_item_rule, p_memo_reason_rule, p_bill_address_rule
          from ra_batch_sources
          where name = p_batch_source_name;

          g_sql_tokens('##$$BATCHNAME$$##') := p_batch_source_name;
          print_log('------------');
          print_log('INFORMATION: Batch Source data: p_batch_id = ' || p_batch_id || ' p_allow_salescredits = ' || p_allow_salescredits || ' p_salesperson_rule = ' || p_salesperson_rule ||
                  ' p_cust_trx_type_rule = ' || p_cust_trx_type_rule || ' p_inventory_item_rule = ' || p_inventory_item_rule || ' p_memo_reason_rule = ' ||
                  p_memo_reason_rule || ' p_bill_address_rule = ' || p_bill_address_rule);
          print_log('------------');
       exception
       when no_data_found then
          raise bad_value;
          print_log('Did not find Batch Source. Please check the value used in RA_INTERFACE_LINES.BATCH_SOURCE_NAME');
       end;
         
       -- Error encountered in AutoInvoice
       l_step := '90';
       if g_miss_table = 'RA_SALESREPS' then
          -- check batch source settings
          if nvl(p_allow_salescredits,'N') = 'N' then
             set_item_result(run_stored_sig('BATCH_NOT_ALLOW_SALESCREDIT')); 
          else
              -- check Id/Number setting and interface data
              if nvl(p_salesperson_rule,'X-x-X') = 'Id' and nvl(p_salesrep_id,-88) = -88 then
                 l_continue := 'N';
                 set_item_result(run_stored_sig('BATCH_NO_SALESREP_ID')); 
              elsif nvl(p_salesperson_rule,'X-x-X') = 'Number' and nvl(p_salesrep_ref,'X-x-X') = 'X-x-X' then
                 l_continue := 'N';
                 set_item_result(run_stored_sig('BATCH_NO_SALESREP_NUMBER'));
              elsif nvl(p_salesperson_rule,'X-x-X') = 'X-x-X' then
                 l_continue := 'N';
                 set_item_result(run_stored_sig('BATCH_NO_SALESREP_SETUP'));
              elsif nvl(p_salesperson_rule,'X-x-X') = 'Number' and nvl(p_salesrep_ref,'X-x-X') <> 'X-x-X' then
                  begin
                     select salesrep_id
                     into   p_salesrep_id
                     from   ra_salesreps
                     where  salesrep_number = p_salesrep_ref;
                     
                     g_sql_tokens('##$$SALESREPID$$##') := p_salesrep_id;
                  exception
                  when no_data_found then
                    l_continue := 'N';
                    print_log('Error: Did not find Salesrep Id.');
                    raise bad_value;
                  end;   
              end if;
              if l_continue = 'Y' then
                 if g_account_type = 'REC' then         
                    set_item_result(run_stored_sig('GET_SALESREPS_CCID_REC'));
                 else
                    set_item_result(run_stored_sig('GET_SALESREPS_CCID_REV'));
                 end if;
                 set_item_result(run_stored_sig('LIST_ERR_SALESREPS'));
              end if;           
          end if;
       elsif g_miss_table = 'RA_CUST_TRX_TYPES' then
          if nvl(p_cust_trx_type_rule,'X-x-X') = 'Id' and nvl(p_trx_type_id,-88) = -88 then
             l_continue := 'N';
             set_item_result(run_stored_sig('BATCH_NO_TRXTYPE_ID')); 
          elsif nvl(p_cust_trx_type_rule,'X-x-X') = 'Value' and nvl(p_trx_type_ref,'X-x-X') = 'X-x-X' then
             l_continue := 'N';
             set_item_result(run_stored_sig('BATCH_NO_TRXTYPE_VALUE'));
          elsif nvl(p_cust_trx_type_rule,'X-x-X') = 'X-x-X' then
             l_continue := 'N';
             set_item_result(run_stored_sig('BATCH_NO_TRXTYPE_SETUP'));
          elsif nvl(p_cust_trx_type_rule,'X-x-X') = 'Value' and nvl(p_trx_type_ref,'X-x-X') <> 'X-x-X' then
             begin
                select cust_trx_type_id
                  into p_trx_type_id
                  from ra_cust_trx_types
                 where name = p_trx_type_ref;

                 g_sql_tokens('##$$TRXTYPEID$$##') := p_trx_type_id;
             exception
             when no_data_found then
                l_continue := 'N';
                print_log('Error: Did not find Transaction Type Id.');
                raise bad_value;
             end;   
          end if;
          if l_continue = 'Y' then
             if g_account_type = 'REC' then
                set_item_result(run_stored_sig('GET_TRX_CCID_REC'));
             elsif g_account_type = 'REV' then
                set_item_result(run_stored_sig('GET_TRX_CCID_REV'));
             elsif g_account_type = 'UNEARN' then
                set_item_result(run_stored_sig('GET_TRX_CCID_UNEARN'));
             elsif g_account_type = 'UNBILL' then
                set_item_result(run_stored_sig('GET_TRX_CCID_UNBILL'));
             elsif g_account_type = 'SUSPENSE' then
                set_item_result(run_stored_sig('GET_TRX_CCID_SUSPENSE'));
             end if;
             set_item_result(run_stored_sig('LIST_ERR_TRXTYPES')); 
          end if;           
       elsif g_miss_table = 'RA_SITE_USES' then
          if nvl(p_bill_address_rule, 'X-x-X')  = 'Id' and nvl(p_site_id,-88) = -88 then
             l_continue := 'N';
             set_item_result(run_stored_sig('BATCH_NO_SITE_ID')); 
          elsif nvl(p_bill_address_rule, 'X-x-X') = 'Value' and nvl(p_site_ref,'X-x-X') = 'X-x-X' then
             l_continue := 'N';
             set_item_result(run_stored_sig('BATCH_NO_SITE_VALUE'));                       
          elsif nvl(p_bill_address_rule,'X-x-X') = 'X-x-X' then
             l_continue := 'N';
             set_item_result(run_stored_sig('BATCH_NO_SITE_SETUP'));
          elsif nvl(p_bill_address_rule, 'X-x-X') = 'Value' and nvl(p_site_ref,'X-x-X') <> 'X-x-X' then
             begin
                SELECT site_use.site_use_id
                  INTO p_site_use_id
                  FROM HZ_CUST_ACCT_SITES ACCT_SITE,HZ_CUST_SITE_USES SITE_USE
                 WHERE ACCT_SITE.ORIG_SYSTEM_REFERENCE = p_site_ref
                   AND ACCT_SITE.CUST_ACCT_SITE_ID = SITE_USE.CUST_ACCT_SITE_ID
                   AND SITE_USE.SITE_USE_CODE = 'BILL_TO';

                g_sql_tokens('##$$SITEUSEID$$##') := p_site_use_id;
             exception
             when no_data_found then
                l_continue := 'N';
                print_log('Error: Did not find Bill-to Site Use Id with p_site_ref.');
                raise bad_value;
             end; 
          elsif nvl(p_bill_address_rule, 'X-x-X')  = 'Id' and nvl(p_site_id,-88) <> -88 then
             begin
                SELECT site_use.site_use_id
                  INTO p_site_use_id
                  FROM HZ_CUST_ACCT_SITES ACCT_SITE,HZ_CUST_SITE_USES SITE_USE
                 WHERE ACCT_SITE.CUST_ACCT_SITE_ID = p_site_id
                   AND ACCT_SITE.CUST_ACCT_SITE_ID = SITE_USE.CUST_ACCT_SITE_ID
                   AND SITE_USE.SITE_USE_CODE = 'BILL_TO';

                g_sql_tokens('##$$SITEUSEID$$##') := p_site_use_id;
             exception
             when no_data_found then
                l_continue := 'N';
                print_log('Error: Did not find Bill-to Site Use Id with p_site_id.');
                raise bad_value;
             end; 
          end if;
          if l_continue = 'Y' then
             if g_account_type = 'REV' then
                set_item_result(run_stored_sig('GET_SITE_CCID_AI_REV'));
             elsif g_account_type = 'REC' then
                set_item_result(run_stored_sig('GET_SITE_CCID_AI_REC'));
             elsif g_account_type = 'UNEARN' then
                set_item_result(run_stored_sig('GET_SITE_CCID_AI_UNEARN'));
             elsif g_account_type = 'UNBILL' then
                set_item_result(run_stored_sig('GET_SITE_CCID_AI_UNBILL'));
             elsif g_account_type = 'SUSPENSE' then
                set_item_result(run_stored_sig('GET_SITE_CCID_AI_SUSPENSE'));       
             end if;
             set_item_result(run_stored_sig('LIST_ERR_SITES')); 
          end if;
       elsif g_miss_table = 'RA_STD_TRX_LINES' then
          print_log('in p_miss_table = RA_STD_TRX_LINES');
          if p_memo_line_id is not null or p_memo_line_ref is not null then
             -- process memo lines                       
             if nvl(p_memo_reason_rule,'X-x-X') = 'Id' and nvl(p_memo_line_id, -88) = -88 then                      
                l_continue := 'N';
                set_item_result(run_stored_sig('BATCH_NO_MEMO_ID')); 
             elsif nvl(p_memo_reason_rule, 'X-x-X') = 'Value' and nvl(p_memo_line_ref,'X-x-X') = 'X-x-X' then
                l_continue := 'N';
                set_item_result(run_stored_sig('BATCH_NO_MEMO_VALUE')); 
             elsif nvl(p_memo_reason_rule,'X-x-X') = 'X-x-X' then
                l_continue := 'N';
                set_item_result(run_stored_sig('BATCH_NO_MEMO_SETUP'));
             elsif nvl(p_memo_reason_rule, 'X-x-X') = 'Value' and nvl(p_memo_line_ref,'X-x-X') <> 'X-x-X' then
                begin
                   select memo_line_id
                     into p_memo_line_id
                     from ar_memo_lines
                    where name = p_memo_line_ref;
                    g_sql_tokens('##$$MEMOLINEID$$##') := p_memo_line_id;
                exception
                when no_data_found then
                   l_continue := 'N';
                   print_log('Error: Did not find Memo Line Id.');
                   p_memo_line_id := -88;
                   raise bad_value;
                end;
             end if;
             if l_continue = 'Y' then
                if g_account_type in ('REV','UNEARN','UNBILL','SUSPENSE') then
                   set_item_result(run_stored_sig('GET_MEMO_CCID_REV'));
                end if;
             end if;
          else
            -- process inventory item
            if p_warehouse_id is null then
                l_continue := 'N';
                print_log('Error: You did not provide a WAREHOUSE_ID value, please correct this for INTERFACE_LINE_ID = ' || g_id);
                set_item_result(run_stored_sig('NO_WAREHOUSE_ID'));
            else
                if nvl(p_inventory_item_rule,'X-x-X') = 'Id' and nvl(p_inv_item_id, -88) = -88 then
                   l_continue := 'N';
                   set_item_result(run_stored_sig('BATCH_NO_INV_ID'));
                elsif nvl(p_inventory_item_rule, 'X-x-X')  = 'Segment' and
                   nvl(p_mtl_system_items_seg1,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg2,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg3,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg4,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg5,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg6,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg7,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg8,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg9,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg10,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg11,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg12,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg13,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg14,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg15,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg16,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg17,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg18,'X-x-X') = 'X-x-X' and
                   nvl(p_mtl_system_items_seg19,'X-x-X') = 'X-x-X' and nvl(p_mtl_system_items_seg20,'X-x-X') = 'X-x-X' then
                   l_continue := 'N';
                   set_item_result(run_stored_sig('BATCH_NO_INV_SEG'));
                elsif nvl(p_inventory_item_rule, 'X-x-X')  = 'X-x-X' then
                   l_continue := 'N';
                   set_item_result(run_stored_sig('BATCH_NO_INV_SETUP'));                 
                elsif nvl(p_inventory_item_rule, 'X-x-X')  = 'Segment' and 
                   (nvl(p_mtl_system_items_seg1,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg2,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg3,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg4,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg5,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg6,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg7,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg8,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg9,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg10,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg11,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg12,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg13,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg14,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg15,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg16,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg17,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg18,'X-x-X') <> 'X-x-X' or
                    nvl(p_mtl_system_items_seg19,'X-x-X') <> 'X-x-X' or nvl(p_mtl_system_items_seg20,'X-x-X') <> 'X-x-X') then
                    -- using MTL segments get the inventory_item_id
                    begin
                       select inventory_item_id
                         INTO p_inv_item_id
                         FROM mtl_system_items
                        WHERE organization_id = nvl(p_warehouse_id, to_number(oe_profile.value('SO_ORGANIZATION_ID',p_org_id)))
                          AND nvl(segment1,'X-x-X') = nvl(p_mtl_system_items_seg1,'X-x-X')
                          AND nvl(segment2,'X-x-X') = nvl(p_mtl_system_items_seg2,'X-x-X')
                          AND nvl(segment3,'X-x-X') = nvl(p_mtl_system_items_seg3,'X-x-X')
                          AND nvl(segment4,'X-x-X') = nvl(p_mtl_system_items_seg4,'X-x-X')
                          AND nvl(segment5,'X-x-X') = nvl(p_mtl_system_items_seg5,'X-x-X')
                          AND nvl(segment6,'X-x-X') = nvl(p_mtl_system_items_seg6,'X-x-X')
                          AND nvl(segment7,'X-x-X') = nvl(p_mtl_system_items_seg7,'X-x-X')
                          AND nvl(segment8,'X-x-X') = nvl(p_mtl_system_items_seg8,'X-x-X')
                          AND nvl(segment9,'X-x-X') = nvl(p_mtl_system_items_seg9,'X-x-X')
                          AND nvl(segment10,'X-x-X') = nvl(p_mtl_system_items_seg10,'X-x-X')
                          AND nvl(segment11,'X-x-X') = nvl(p_mtl_system_items_seg11,'X-x-X')
                          AND nvl(segment12,'X-x-X') = nvl(p_mtl_system_items_seg12,'X-x-X')
                          AND nvl(segment13,'X-x-X') = nvl(p_mtl_system_items_seg13,'X-x-X')
                          AND nvl(segment14,'X-x-X') = nvl(p_mtl_system_items_seg14,'X-x-X')
                          AND nvl(segment15,'X-x-X') = nvl(p_mtl_system_items_seg15,'X-x-X')
                          AND nvl(segment16,'X-x-X') = nvl(p_mtl_system_items_seg16,'X-x-X')
                          AND nvl(segment17,'X-x-X') = nvl(p_mtl_system_items_seg17,'X-x-X')
                          AND nvl(segment18,'X-x-X') = nvl(p_mtl_system_items_seg18,'X-x-X')
                          AND nvl(segment19,'X-x-X') = nvl(p_mtl_system_items_seg19,'X-x-X')
                          AND nvl(segment20,'X-x-X') = nvl(p_mtl_system_items_seg20,'X-x-X');
                          g_sql_tokens('##$$INVITEMID$$##') := nvl(p_inv_item_id,-88); 
                    exception
                    when no_data_found then
                       l_continue := 'N';
                       print_log('Error: Did not find Inventory Item Id Based on Segments provided.');
                       p_inv_item_id := -88;
                       raise bad_value;
                    end;
                end if;
                if l_continue = 'Y' then
                   if g_account_type in ('REV','UNEARN','UNBILL','SUSPENSE') then
                      set_item_result(run_stored_sig('GET_ITEM_CCID_REV'));
                   end if;
                end if;
             end if;
          end if;
       end if;
       
     end if;
        
  end_section;
  
  
  -- Start of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/message/12560385#12560385" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION 
WHEN bad_value THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

procedure main_cp( 
   errbuf              OUT VARCHAR2,
   retcode             OUT VARCHAR2,
   p_org_id            IN NUMBER,
   p_account_type_in   IN VARCHAR2,
   p_missing_seg       IN NUMBER,
   p_where             IN VARCHAR2,
   p_id                IN NUMBER) 
IS
BEGIN
  g_retcode := 0;
  g_errbuf  := NULL;
  print_log('In main_cp');
  
  main(p_org_id => p_org_id, 
       p_account_type_in => p_account_type_in,
       p_missing_seg => p_missing_seg,      
       p_where => nvl(p_where,'XXX'),
       p_id => nvl(p_id,0));
  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION
WHEN OTHERS THEN
  retcode := '2';
  errbuf  := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;



-- PSD #1
END ar_autoaccounting_analyzer_pkg;
/
show errors
exit;