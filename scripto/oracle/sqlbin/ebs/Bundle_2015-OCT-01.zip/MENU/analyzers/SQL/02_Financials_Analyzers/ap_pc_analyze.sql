REM $Id: ap_pc_analyze.sql, 200.2 2015/08/11 20:44:41 arobert Exp alumpe $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ap_pc_analyze.sql (was period_close.sql)                             |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the ap_gdf_detect_pkg.main_pc for a            |
REM |    period name,ledger and optional parameters date range & OU           |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 17-JUL-2012 SKPASUPU  Created.                                          |
REM | 17-JAN-2013 RARAJANG  Parameter Changed to Master.                      |
REM | 26-AUG-2014 AROBERT   Removed upper for p_name                          |
REM | 19-MAR-2015 AROBERT   Removed as at end of SET ECHO command             |
REM | 10-AUG-2015 AROBERT   Added Bundle messages                             |
REM +=========================================================================+

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Period Close Analyzer
REM
REM MENU_START
REM
REM SQL: Run Period Close Analyzer 
REM FNDLOAD: Load Period Close Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM
REM HELP_START  
REM 
REM Period Close Analyzer Help [Doc ID: 1489381.1]
REM
REM  Compatible: 12.0|12.1|12.2 
REM
REM  Explanation of available options:
REM
REM    (1) Runs AP_PCLOSE_DETECT_PKG as APPS and outputs an HTML report
REM
REM    (2) Install Period Close Analyzer as a concurrent program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group: 
REM          Payables Reports Only
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: AP_TOP
REM PROG_NAME: APPCLOSEVAL
REM DEF_REQ_GROUP: Payables Reports Only
REM APP_NAME: Payables
REM PROG_TEMPLATE: pca_prog.ldt
REM PROD_SHORT_NAME: SQLAP 
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ap_period_close_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF
SET VERIFY OFF
SET DEFINE "&"

PROMPT
PROMPT ===========================================================================
PROMPT Enter the period name which you are trying to close.
PROMPT ===========================================================================
PROMPT
ACCEPT p_name CHAR PROMPT 'Enter the Period Name: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the ledger ID which you are trying to close.
PROMPT ===========================================================================
PROMPT
ACCEPT ledger CHAR PROMPT 'Enter the Ledger ID: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the org_id(s) for the operating unit(s).  For multiple 
PROMPT operating units, separate with commas.  For all, leave blank.
PROMPT ===========================================================================
PROMPT
ACCEPT ous CHAR PROMPT 'Enter the OU org_id(s): '
PROMPT
PROMPT ===========================================================================
PROMPT NOTE: AP Data Validation Report lists the corruptions identified 
PROMPT in the given date range and suggest the available GDFs to resolve it.
PROMPT ===========================================================================
PROMPT
ACCEPT gdf CHAR PROMPT 'Do you want to run the AP Data Validation Report (Y/N)? '
PROMPT

DECLARE
  l_org_ids     VARCHAR2(240) :=  '&ous';
  l_master_gdf  VARCHAR2(2)   := upper('&gdf');
  l_ledger_id   VARCHAR2(240) :=  '&ledger';
  l_per_name    VARCHAR2(240) :=  '&p_name'; 

BEGIN

  ap_pclose_detect_pkg.main_pc(
      p_org_ids => l_org_ids,
      p_ledger_id => l_ledger_id,
      p_per_name => l_per_name,
      p_max_output_rows => 200,--any integer value to control the rows displayed
      p_master_gdf => l_master_gdf,
      p_debug_mode => 'Y');
      
EXCEPTION 
WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
EXIT
