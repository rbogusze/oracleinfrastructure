REM $Id: iby_fd_analyze.sql, 200.11 2015/08/28 09:49:24 ARNAL.ROBERT Exp $
REM +==================================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                            |
REM |                    Redwood Shores, California, USA                               |
REM |                         All rights reserved.                                     |
REM +==================================================================================+
REM |                                                                                  |
REM | FILENAME                                                                         |
REM |    iby_fd_analyze.sql                                                            |
REM |                                                                                  |
REM | DESCRIPTION                                                                      |
REM |    Wrapper SQL to submit the iby_fd_analyzer_pkg.main procedure                      |
REM |                                                                                  |
REM | HISTORY                                                                          |
REM |                                                                                  |
REM +==================================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: AP Payments Funds Disbursement Analyzer
REM
REM MENU_START
REM
REM SQL: Run AP Payments Funds Disbursement Analyzer
REM FNDLOAD: Load AP Payments Funds Disbursement Analyzer as a Concurrent Program 
REM 
REM MENU_END 
REM
REM HELP_START  
REM 
REM  AP Payments Funds Disbursement Analyzer to Validate Setup, 
REM  Transaction Data Help [Doc ID: 1587455.1] 
REM
REM  Compatible: 12.0|12.1|12.2
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package IBY_FD_ANALYZER_PKG as APPS to create an HTML report 
REM
REM    (2) Install Payments Funds Disbursement Analyzer as a concurrent program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group "Payables Reports Only"
REM
REM HELP_END 
REM
REM FNDLOAD_START 
REM
REM PROD_TOP: AP_TOP
REM PROG_NAME: APPMTANL
REM DEF_REQ_GROUP: Payables Reports Only
REM APP_NAME: Payables
REM PROG_TEMPLATE: IBYFDAZ.ldt
REM PROD_SHORT_NAME: SQLAP 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM iby_fd_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE 
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "~"
PROMPT
PROMPT Submitting EBS Payments (IBY) Funds Disbursement.

PROMPT ===========================================================================
PROMPT org_id for the operating unit. This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT p_org_id CHAR   PROMPT 'Enter the org_id: '
PROMPT
PROMPT ===========================================================================
PROMPT If you wish to analyze a Payment Process Request (PPR). 
PROMPT ===========================================================================
PROMPT
ACCEPT p_ppr_name CHAR   PROMPT 'Enter the PPR Name: '
PROMPT
PROMPT ===========================================================================
PROMPT If you wish to analyze why a specific Invoice is not picked-up by PPR enter the invoice number.   
PROMPT ===========================================================================
PROMPT
ACCEPT p_inv_num_1 CHAR   PROMPT 'Enter the Invoice Number: '
PROMPT
PROMPT ===========================================================================
PROMPT If you wish to analyze why a check cannot be voided. 
PROMPT ===========================================================================
PROMPT
ACCEPT p_check_id CHAR   PROMPT 'Enter the Check ID: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the date from which to begin validating transactions. 
PROMPT ===========================================================================
PROMPT
ACCEPT p_from_date DATE FORMAT 'DD-MON-YYYY' DEFAULT '31-DEC-9999' PROMPT 'Enter the From Date:  [DD-MON-YYYY]'
PROMPT
PROMPT ===========================================================================
PROMPT Enter the maximum number of rows to display on row limited queries. 
PROMPT ===========================================================================
PROMPT
ACCEPT p_max_output_rows NUMBER  DEFAULT '50' PROMPT 'Enter the Maximum Rows to Display [50]: '
PROMPT
PROMPT
DECLARE
   p_org_id                       VARCHAR2(240)  := '~p_org_id';
   p_ppr_name                     VARCHAR2(240)  := '~p_ppr_name';
   p_inv_num_1                    VARCHAR2(240)  := '~p_inv_num_1';
   p_check_id                     VARCHAR2(240)  := '~p_check_id';
   p_from_date                    DATE           := to_date('~p_from_date','DD-MON-YYYY');
   p_max_output_rows              NUMBER         := '~p_max_output_rows';

BEGIN
IF p_from_date = to_date('31-DEC-9999','DD-MON-YYYY') THEN
   p_from_date := NULL;
END IF;
IF p_from_date IS NULL THEN
   p_from_date := sysdate-90;
END IF;


   iby_fd_analyzer_pkg.main(
     p_org_id                       => p_org_id
    ,p_ppr_name                     => p_ppr_name
    ,p_inv_num_1                    => p_inv_num_1
    ,p_check_id                     => p_check_id
    ,p_from_date                    => p_from_date
    ,p_max_output_rows              => p_max_output_rows  );

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);

END;
/
exit;
