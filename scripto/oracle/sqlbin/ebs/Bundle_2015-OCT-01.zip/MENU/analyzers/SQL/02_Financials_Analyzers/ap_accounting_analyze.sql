REM $Id: ap_accounting_analyze.sql, 200.3 2013/01/17 12:05:13 rarajang $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ap_accounting_analyze.sql                                            |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the AP_ACCOUNTING_DETECT_PKG.main procedure    |
REM |    in single transaction mode.                                          |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 17-JAN-2013 RARAJANG  Created.                                          |
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Payables Create Accounting Analyzer
REM
REM MENU_START
REM
REM SQL: Run Payables Create Accounting Analyzer
REM FNDLOAD: Load Payables Create Accounting Analyzer as a Concurrent Program
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  Payables Create Accounting Analyzer  [Doc ID: 1665706.1]
REM
REM  Compatible with: [12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package AP_ACCOUNTING_DETECT_PKG as APPS to create an HTML report 
REM
REM    (2) Install Payables Create Accounting Analyzer as a concurrent program
REM        o Will run FNDLOAD as APPS 
REM        o Will define the analyzer as a concurrent executable/program 
REM        o Will add the analyzer to default request group Payables Reports Only
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: AP_TOP
REM DEF_REQ_GROUP: Payables Reports Only
REM PROG_NAME: APCAANL 
REM PROG_TEMPLATE: APCAANL.ldt
REM APP_NAME: Payables
REM PROD_SHORT_NAME: SQLAP 
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ap_accounting_analyzer.sql 
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
PROMPT Submit Create Accounting Analyzer for single transactions.
PROMPT
PROMPT ===========================================================================
PROMPT Enter the invoice id and/or check id where prompted.
PROMPT ===========================================================================
PROMPT
ACCEPT invoice_id NUMBER DEFAULT 0 -
       PROMPT 'Enter the INVOICE ID or press enter to leave blank: '
ACCEPT check_id NUMBER DEFAULT 0 -
       PROMPT 'Enter the CHECK ID   or press enter to leave blank: '
PROMPT
PROMPT
PROMPT

DECLARE
  l_inv_id NUMBER := &invoice_id; 
  l_chk_id NUMBER := &check_id;

BEGIN
  IF l_inv_id = 0 THEN l_inv_id := null; END IF;
  IF l_chk_id = 0 THEN l_chk_id := null; END IF;


  IF l_inv_id is not null OR l_chk_id is not null THEN
    AP_ACCOUNTING_DETECT_PKG.main_pc(
      p_invoice_id      => l_inv_id,
      p_check_id        => l_chk_id,
      p_max_output_rows => 10,
      p_debug_mode      => 'Y');
  ELSE
    dbms_output.put_line('No valid parameters entered.  Process not submitted.');
  END IF;

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
