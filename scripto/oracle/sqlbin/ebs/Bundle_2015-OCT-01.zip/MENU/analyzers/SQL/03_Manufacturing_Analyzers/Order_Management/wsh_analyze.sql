REM $Id: wsh_analyze.sql, 200.1 2015/15/01 23:27:42 arobert Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.13                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    wsh_analyze.sql                                                      |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the wsh_analyzer_pkg.main procedure            |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Shipping Execution (WSH) Analyzer 
REM
REM MENU_START
REM
REM SQL: Run Shipping Execution (WSH) Analyzer
REM FNDLOAD: Load Shipping Execution (WSH) Analyzer
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  R12: Shipping Execution (WSH) Analyzer [Doc ID: 1947935.1]
REM
REM  Compatible with: [12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package wsh_analyzer_pkg as APPS to create an HTML report 
REM
REM    (2) Install Shipping Execution (WSH) Analyzer as a concurrent program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group Payables Reports Only
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: ONT_TOP
REM PROG_NAME: SEWSHANL
REM PROG_TEMPLATE: SEWSHAZ_prog.ldt
REM DEF_REQ_GROUP: OM Concurrent Programs
REM APP_NAME: Order Management
REM PROD_SHORT_NAME: ONT
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM wsh_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
-- PSD #1
PROMPT Submitting WSH Analyzer.

BEGIN

-- PSD #4
  wsh_analyzer_pkg.main;

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
