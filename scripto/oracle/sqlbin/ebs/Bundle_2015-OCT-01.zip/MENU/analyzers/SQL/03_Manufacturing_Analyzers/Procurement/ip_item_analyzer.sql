SET DEFINE '~'
REM +=======================================================================+
REM |    Copyright (c) 2012 Oracle Corporation, Redwood Shores, CA, USA     |
REM |                         All rights reserved.                          |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |   ip_itemv1_analyzer_pkg.sql                                          |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM |   Script automating knowledge for on-site analysis of IP items        |
REM |   that do not appear and other IP recurring issues.                   |
REM |                                                                       |
REM | HISTORY 
REM |  18-JAN-2013 PFIORENT                                                 | 
REM |              & ALUMPE Draft version created                           |
REM |  05-SEP-2013 JXMCCALL                                                 | 
REM |              & WFLACK IP Draft version created                        |
REM |  22-NOV-2013 JXMCCALL Added MOAC Profile Check  120.13                |
REM |  12-MAR-2013 JXMCCALL Updated Patch list for New RUP and check for    |
REM |                       RDBMS patch  120.14                                   | 
REM +=======================================================================+

CREATE OR REPLACE PACKAGE ip_itemv1_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_num    IS TABLE OF NUMBER INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL());

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

PROCEDURE main (
      p_org_id            IN NUMBER   DEFAULT null,
	  p_user_name         IN VARCHAR2 DEFAULT null,
	  p_responsibility_id IN VARCHAR2 DEFAULT null,	  
      p_item_num          IN VARCHAR2 DEFAULT null,
      p_trx_num           IN VARCHAR2 DEFAULT null,
      p_line_num          IN NUMBER   DEFAULT null,
      p_from_date         IN DATE     DEFAULT sysdate - 90,
      p_max_output_rows   IN NUMBER   DEFAULT 20,
      p_debug_mode        IN VARCHAR2 DEFAULT 'Y');
	  
	  

PROCEDURE main_cp (
      errbuf              OUT VARCHAR2,
      retcode             OUT VARCHAR2,
      p_org_id            IN NUMBER   DEFAULT null,
	  p_user_name         IN VARCHAR2 DEFAULT null,
	  p_responsibility_id IN VARCHAR2 DEFAULT null,	 	  
      p_item_num          IN VARCHAR2 DEFAULT null,
      p_trx_num           IN VARCHAR2 DEFAULT null,
      p_line_num          IN NUMBER   DEFAULT null,
      p_from_date         IN VARCHAR2 DEFAULT null,
      p_max_output_rows   IN NUMBER   DEFAULT 20, 
      p_debug_mode        IN VARCHAR2 DEFAULT 'Y');
	  
	  

FUNCTION get_result   RETURN VARCHAR2;
FUNCTION get_fail_msg RETURN VARCHAR2;
FUNCTION get_exc_msg  RETURN VARCHAR2;
-- FUNCTION get_doc_amts(p_amt_type IN VARCHAR2) RETURN NUMBER;

END ip_itemv1_analyzer_pkg;
/
show errors



CREATE OR REPLACE PACKAGE BODY ip_itemv1_analyzer_pkg AS
-- $Id: ip_itemv1_analyzer.sql,v 120.14 2014/03/12 18:00:30 globsupt Exp globsupt $

----------------------------------
-- Global Variables             --
----------------------------------
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;

g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
--g_process_start_time  TIMESTAMP;
--g_query_total         INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_item_id         INTEGER := 0;

g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?id=';

g_app_method      VARCHAR2(15);
g_curr_empid      NUMBER;
g_app_results     HASH_TBL_2K;
g_doc_amts        HASH_TBL_NUM;

----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_out_file, p_msg);
    utl_file.fflush(g_out_file);
  ELSE
    fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;

PROCEDURE print_error (
  p_msg VARCHAR2,
  p_print_to_log VARCHAR2 DEFAULT 'N') is
BEGIN
  IF p_print_to_log = 'Y' THEN
    print_log(p_msg);
  END IF;
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;


----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE start_timer (p_start_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_start_time
  FROM   dual;
END start_timer;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(40);
  l_out_file         VARCHAR2(40);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  NO_UTL_DIR         EXCEPTION;
BEGIN
  --start_timer(g_process_start_time);
  --g_query_total := numtodsinterval(0,'SECOND');
  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD-HH24MISS') INTO l_date_char from dual;

    l_log_file := 'IP-ITEM-ANLZ-'||l_date_char||'.log';
    l_out_file := 'IP-ITEM-ANLZ-'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
-- Change the following two lines to set a max (,32627) as testing revealed the following:  Error: ORA-29285: file write error	
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',32627);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',32627);
    END IF;

    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<html><head>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Styles
  print_out('
<STYLE>
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  font-weight: bold;
  padding-bottom: 20px;
  background-color: #F7F2D7;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #C8B560;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}
a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}
.detail {
  text-decoration:none;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.divTitle {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #152B40;
  border: 1px solid #003399;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  color: #F4F4F4;
  font-size: x-large;
  font-weight: bold;
}
.divTitle1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large; font-weight: bold;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #254B72;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  border-bottom-style: solid;
  border-bottom-width: 3px;
  border-bottom-color: #996600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  border-bottom-style: solid;
  border-bottom-width: 3px;
  border-bottom-color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  border-bottom-style: solid;
  border-bottom-width: 2px;
  border-bottom-color: #55CC55;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
     if (tbl.style.display == ""){
        e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9650),String.fromCharCode(9660));
        e.innerHTML = e.innerHTML.replace("Hide","Show");
        tbl.style.display = "none"; }
     else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9650));
         e.innerHTML = e.innerHTML.replace("Show","Hide");
         tbl.style.display = ""; }
   }
</script>');
  print_out('</head><body>');
END print_page_header;

----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- pappl : application name (or whatever should go after      --
--         "Oracle eBusiness Suite)                           --
-- ptestname: name of the report                              --
--
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(pappl varchar2, ptestname varchar2) is
BEGIN
  -- Call print header as both title and header occur once in the report
  print_page_header;
  -- Print title
  print_out('<!----------------- Title ----------------->
    <div class="divTitle" id="Top">ORACLE eBusiness Suite ' || pappl || '<br>
    <div class="divTitle1">' || ptestname ||'</div></div><br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints report TOC placeholder                              --
----------------------------------------------------------------

PROCEDURE print_toc(
  psecttitle varchar2 DEFAULT 'Report Summary') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
  print_out('<!------------------ TOC ------------------>
    <div class="divSection"><div class="divSectionTitle" id="sect0">' ||
    psecttitle || '</div><br>');

  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
  print_out(
   '<table width="100%" class="graph"><tbody>
      <tr class="top"><td width="50%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');">
      &#9660; Run Details</a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="50%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');">
       &#9660; Parameters</a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
  print_out('</tbody></table></td></tr></tbody></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"></div><br>');
  -- Print out the graph holder
  print_out('<div class="divItem" id="healthsummary"></div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_toc_title    VARCHAR2 DEFAULT 'In This Report',
     p_graph_title  VARCHAR2 DEFAULT 'Overall Health Status',
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
BEGIN
  print_out('
<script type="text/javascript">
  document.getElementById("toccontent").innerHTML = "<div class=\"divItemTitle\">' ||
    p_toc_title || '</div><table width=\"100%\"><tr>" +');
  -- Dont want less than 3 table cells per row so force to loop in multiples of 3
  IF mod(g_sections.count,3) = 0 THEN
    l_loop_count := g_sections.count;
  ELSE
    l_loop_count := g_sections.count + 3 - mod(g_sections.count,3);
  END IF;
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
    -- Print end of row every 3 cells
    IF (i > 1) and (mod(i,3) = 1) THEN
      print_out('"</tr><tr>" +');
    END IF;
    -- Print a blank cell if out of sections
    IF i > g_sections.count THEN
      print_out('"<td></td>" +');
    ELSE
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
      print_out('"<td><a href=\"#sect'||to_char(i)||'\">' ||
        g_sections(i).name || '</a> " +');
      -- Print if section in error or warning the "dot"
      IF g_sections(i).result ='E' THEN
        print_out('"<span class=\"errbul\">&#8226;</span>" +');
        l_action_req := true;
      ELSIF g_sections(i).result ='W' THEN
        print_out('"<span class=\"warbul\">&#8226;</span>" +');
        l_action_req := true;
      END IF;
      -- Print end of cell
      print_out('"</td>" +');
    END IF;
  END LOOP;
  -- End the table
  print_out('"</tr></tbody></table>" +');
  -- Now print action required/not required box
  IF l_action_req THEN
--    Commenting as users found this confusing
--    g_retcode := 1;
--    g_errbuf := 'Errors and/or warnings detected.  Review process output';
    print_out('"<br><div class=\"divuar\"><div class=\"divuar1\">Action Required</div>" +');
    print_out('"Please review each section above for errors " +');
    print_out('"(<span class=\"errbul\">&#8226;</span>) " +');
    print_out('"or warnings (<span class=\"warbul\">&#8226;</span>) " +');
    print_out('"that have been encountered.</div>";');
  ELSE
--    g_retcode := 0;
--    g_errbuf := null;
    print_out('"<br><div class=\"divok\"><div class=\"divok1\">" +');
    print_out('"No issues found!</div>" +');
    print_out('"No action required, no issues were found.</div>";');
  END IF;
  print_out('</script>');
  -- End of the TOC section


  -- Now print the bar chart

  print_out('
    <script type="text/javascript">
    document.getElementById("healthsummary").innerHTML = "<div class=" +
     "\"divItemTitle\">'||p_graph_title||' <a class=\"detailsmall\" " +
     "href=\"javascript:;\" onclick=\"displayItem(this, ''graphtext'');\">" +
     "&#9660; Show Details</a> </div>" + ');

  print_out('"<div class=\"graph\" id=\"graphtext\" style=\"display:none\">'||
    'This chart represents the total count of errors, warnings and '||
    'successful checks for this report.  Please review the red boxes '||
    'for errors, yellow boxes for warnings and green boxes for successful '||
    'checks. Note that not all successful checks will necessarily appear in the '||
    'report output.</div>" +');

  l_tot_cnt := l_cnt_succ + l_cnt_warn + l_cnt_err;
  print_out('"<br/><div class=\"divsol\"><table width=\"900\" '||
    'class=\"graph\" cellspacing=\"6\" cellpadding=\"0\">" +');
  print_out('"<tbody><tr><td width=\"200\">'||p_err_label||'</td>" +');
  print_out('"<td width=\"400\" class=\"baruar\"><div style=\"width: '||
    trunc(l_cnt_err*90/l_tot_cnt) || '%\"></div>' || l_cnt_err ||
    '</td><td>' || trunc(l_cnt_err*100/l_tot_cnt) || '%</td></tr>"+');
  print_out('"<tr><td width=\"200\">'||p_warn_label||'</td>" +');
  print_out('"<td width=\"400\" class=\"barwarn\"><div style=\"width: '||
    trunc(l_cnt_warn*90/l_tot_cnt) ||
    '%\"></div>' || l_cnt_warn || '</td><td>' || trunc(l_cnt_warn*100/l_tot_cnt) ||
    '%</td></tr>"+');
  print_out('"<tr><td width=\"200\">'||p_pass_label||'</td>" +');
  print_out('"<td width=\"400\" class=\"barok\"><div style=\"width: '||
    trunc(l_cnt_succ*90/l_tot_cnt) ||
    '%\"></div>' || l_cnt_succ || '</td><td>' || trunc(l_cnt_succ*100/l_tot_cnt) ||
    '%</td></tr>"+');
  print_out('"</tbody></table></div>";');
  -- End
  print_out('</script>');
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

----------------------------------------------------------------------
-- Diag specific procedure (kluge) has to be here because calling from
-- process_signature results 
----------------------------------------------------------------------

PROCEDURE verify_approver(p_empid IN NUMBER) IS
  l_return_status VARCHAR2(1);
  l_return_code   VARCHAR2(25);
  l_exception_msg VARCHAR2(2000);
  l_auth_fail_msg VARCHAR2(2000);  
  l_doc_id        NUMBER;
BEGIN
  IF p_empid <> g_curr_empid OR g_curr_empid is null THEN
    IF g_sql_tokens('##$$TRXTP$$##') = 'RELEASE' THEN
      l_doc_id := to_number(g_sql_tokens('##$$RELID$$##'));
    ELSE
      l_doc_id := to_number(g_sql_tokens('##$$DOCID$$##'));
    END IF;
    g_curr_empid := p_empid;
    po_document_action_pvt.verify_authority(
      p_document_id => l_doc_id,
      p_document_type => g_sql_tokens('##$$TRXTP$$##'),
      p_document_subtype => g_sql_tokens('##$$SUBTP$$##'),
      p_employee_id => p_empid,
      x_return_status => l_return_status,
      x_return_code => l_return_code,
      x_exception_msg => l_exception_msg,
      x_auth_failed_msg  => l_auth_fail_msg);
    g_app_results('STATUS') := l_return_status;
    g_app_results('CODE') := l_return_code;
    g_app_results('EXC_MSG') := l_exception_msg;
    g_app_results('FAIL_MSG') := l_auth_fail_msg;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in verify_approver: '||sqlerrm);
  raise;
END verify_approver;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">DocId \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------

PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','S') THEN
    IF result = 'I' THEN
      g_sections(g_sections.last).result := 'S';
    ELSE
      g_sections(g_sections.last).result := result;
    END IF;
  ELSIF g_sections(g_sections.last).result = 'W' THEN
    IF result = 'E' THEN
      g_sections(g_sections.last).result := result;
    END IF;
  END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  start_timer(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := g_errbuf||'->run_sig_sql: '||l_step;
END run_sig_sql;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL    -- signature SQL column names
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_step := 'Validate parameters';
  IF (p_sig.fail_condition NOT IN ('RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
     ((p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
        ((p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
  l_html := l_html || '
    <div class="divItemTitle">' || p_sig.title;
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');">&#9660; Show Details</a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '190';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the
      -- children
      -- Table header
      l_html := '<div class="divtable"><table class="table1"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1.'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2.'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4.'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
-- AGL KLUGE FOR VERIFY AUTHORITY REMOVE IN TEMPLATES
        IF p_sig_id IN ('APP_SUP_HIERARCHY_MAIN','APP_POS_HIERARCHY_MAIN') THEN
          verify_approver(to_number(g_sql_tokens('##$$FK1$$##')));
        END IF;
-- END AGL KLUGE
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea);
           set_item_result(l_result);
/* commenting this as each has its own failure the parent should fail based on its own 
   criteria
           IF l_result in ('W','E') THEN
             l_fail_flag := true;
           END IF;
*/

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -- Print actions
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'W' THEN
      l_html := '<br><div class="divwarn"><div class="divwarn1">Warning</div>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'E' THEN
      l_html := '<br><div class="divuar"><div class="divuar1">Error</div>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<br><div class="divwarn"><div class="divok1">Information</div>' ||
        p_sig.problem_descr;
    END IF;

    -- Print solution only if passed
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><div class="divsol"><strong>Solution:</strong><br>
        ' || p_sig.solution || '</div>';
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1">No action required</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- Add final tags
  l_html := l_html || '
    </div><br>';
  -- Increment the print count for the section
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := 270;
  print_out(expand_links(l_html));

  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := g_errbuf||'->process_signature_results:'||l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  print_out('<div class="divSection"><div class="divSectionTitle" id="sect' ||
    g_sections.last || '">' || p_sect_title || '</div><br>');
END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'No Issues Found.') IS
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div><br><font style="font-size:x-small;">
    <a href="#Top">[Back to top]</a></font><br><br><br><br>');
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


---------------------------------
-- Recommended patches
---------------------------------

FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;

  CURSOR get_app_date(p_ptch VARCHAR2) IS
  SELECT max(pr.start_date) app_date
  FROM ad_patch_runs pr
  WHERE pr.patch_run_id in (
          SELECT prb.patch_run_id
          FROM   ad_bugs b,
                 ad_patch_run_bugs prb
          WHERE  b.bug_number = p_ptch
          AND    prb.bug_id = b.bug_id
          UNION
          SELECT pr2.patch_run_id
          FROM ad_applied_patches ap,
               ad_patch_drivers pd,
               ad_patch_runs pr2
          WHERE ap.patch_name = p_ptch
          AND   pd.applied_patch_id = ap.applied_patch_id
          AND   pr2.patch_driver_id = pd.patch_driver_id);
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- Row col values, release dependent
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '20';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '8781255';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'Procurement R12.0 Update Aug 2009 (12.0.x)';
    l_col_rows(5)(1) := '[222339.1]';
    l_col_rows(1)(2) := '12530695';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'This patch fixes the performance issue when re-extracing large GBPAs';
    l_col_rows(5)(2) := NULL;
    l_col_rows(1)(3) := '9237356';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'This patch resolves the issue of items '||
                 'created in item open interface not appearing in iProc';
    l_col_rows(5)(3) := '[985766.1]';
    l_col_rows(1)(4) := '9251059';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'Items created in Item Open Interface not transferring to iProcurement';
    l_col_rows(5)(4) := '[985766.1]';
	l_col_rows(1)(5) := '8866249';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'Items created in Item Open Interface not transferring to iProcurement';
    l_col_rows(5)(5) := '[1327431.1]';
	l_col_rows(1)(6) := '13864366';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'This patch ships the concurrent request to diagnose the item search issues';
    l_col_rows(5)(6) := '[1452360.1]';
	l_col_rows(1)(7) := '16805850';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Source document not showing when searching catalog with modified internal item number';
    l_col_rows(5)(7) := NULL;
	ELSE
    l_step := '30';
    l_col_rows.extend(11);
    l_col_rows(1)(1) := '18911810';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'PROCUREMENT FAMILY R12.1.3 JULY UPDATE 2014';
    l_col_rows(5)(1) := '[222339.1]';

    l_col_rows(1)(2) := '16690524';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'This patch fixed the issue of valid items from approved '||
                 'quotations are not able to be searched for in iProcurement '||
                 'if quotations are created and approved in different dates.';
    l_col_rows(5)(2) := '[1466184.1]';

    l_col_rows(1)(3) := '8866249';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'Items created in Item Open Interface not transferring to iProcurement.';
    l_col_rows(5)(3) := '[1327431.1]';

    l_col_rows(1)(4) := '16374319';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'This patch fixes the issue of new added blanket purchase agreement '||
                 'line can be searched for in iProcurement after performing cancel a line, even '||
                 'though the blanket purchase agreement status is requires reapproval.';
    l_col_rows(5)(4) := '[1586524.1]';

    l_col_rows(1)(5) := '17862028';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'item not found in IP when BPA line set to expired and BPA PRE-APPROVED';
    l_col_rows(5)(5) := '[1588653.1]';

	l_col_rows(1)(6) := '13864366';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'This patch ships the concurrent request to diagnose the item search issues';
    l_col_rows(5)(6) := '[1452360.1]';
	
    l_col_rows(1)(7) := '9140891';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'iProcurement Users Cannot Search and Find Newly Defined Master Items Which'||
                       	'are Associated to Existing Mapped Categories When Using RDBMS 11.2.0.1.';
    l_col_rows(5)(7) := '[1633427.1]';		

	
/*
    l_col_rows(1)(5) := '13495209';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'Accrual Reconciliation Load Run Program '||
                 'Cannot Migrate Write Off Transactions from 11i to R12: '||
                 'errors with ORA-00001: unique constraint '||
                 '(BOM.CST_WRITE_OFFS_U1) violated.';
    l_col_rows(5)(5) := '[1475396.1]';

    l_col_rows(1)(6) := '12677981';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'Unable Approve a Purchase Order Due to Tax '||
                 'Error Exception: 023 - An unexpected error has occurred.';
    l_col_rows(5)(6) := '[1281362.1]';

    l_col_rows(1)(7) := '12625661';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'In Oracle Purchasing, Contract Purchase Agreement '||
                 '(CPA) should be defaulted in Standard Purchase Order (SPO) '||
                 'while using advanced pricing and sourcing.';
    l_col_rows(5)(7) := '[1461908.1]';

    l_col_rows(1)(8) := '15971932';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'Purchase Order shipment was not allowed to be '||
                 'cancelled when quantity billed is equal to quantity received.';
    l_col_rows(5)(8) := '[1540294.1]';

    l_col_rows(1)(9) := '9146994';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Several issues with inactive items causing '||
                 'errors when added to the cart or when searched.';
    l_col_rows(5)(9) := '[822733.1]';

    l_col_rows(1)(10) := '11869611';
    l_col_rows(2)(10) := 'No';
    l_col_rows(3)(10) := NULL;
    l_col_rows(4)(10) := 'iProcurement charge account gets the error "Charge '||
                 'account is invalid." on the company segment even when the value '||
                 'is valid.';
    l_col_rows(5)(10) := '[944878.1]';

    l_col_rows(1)(11) := '16932593';
    l_col_rows(2)(11) := 'No';
    l_col_rows(3)(11) := NULL;
    l_col_rows(4)(11) := 'Approval Rollup for R12.1.3 - July 2013';
    l_col_rows(5)(11) := '[1567464.1]';
*/
  END IF;
  -- Check if applied
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i));
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches for Release ' || substr(g_rep_info('Apps Version'),1,4);
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Some recommended patches are not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply these patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RS, NRS, [col] operand [val]
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warn(W), Err(E), Info(I)
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL()) IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;
  l_key      VARCHAR2(255);

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

    -- Clear FK values if the sig has children
  IF l_sig.child_sigs.count > 0 THEN
    l_key := g_sql_tokens.first;
    WHILE l_key is not null LOOP
      IF l_key like '##$$FK_$$##' THEN 
        g_sql_tokens.delete(l_key);
      END IF;
      l_key := g_sql_tokens.next(l_key);
    END LOOP;
  END IF;
  
  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names

EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--                IP ITEM ANALYZER SPECIFICS FOLLOW
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
PROCEDURE validate_parameters (
  p_org_id            IN NUMBER,
  p_user_name         IN VARCHAR2,  
  p_responsibility_id IN NUMBER, 
  p_item_num          IN VARCHAR2,
  p_trx_num           IN VARCHAR2,
  p_line_num          IN NUMBER,
  p_from_date         IN DATE,
  p_max_output_rows   IN NUMBER,
  p_debug_mode        IN VARCHAR2) IS

 -- commented out the following as they appear to be used for PO ITEM ANALYZER
  l_doc_id       NUMBER;
  l_rel_id       NUMBER;
  l_line_num     NUMBER;
  l_doc_subtype  VARCHAR2(25);
  l_item_num     VARCHAR2(20);
  l_user_name    VARCHAR2(20);
  l_responsibility_id VARCHAR2(30);
  l_app_path_id  NUMBER;
  l_created_by   NUMBER;
  l_from_date    VARCHAR2(25);
  l_item_type    WF_ITEMS.ITEM_TYPE%TYPE;
  l_item_key     WF_ITEMS.ITEM_KEY%TYPE;
  l_key          VARCHAR2(255);

  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_run_date     VARCHAR2(30);
  l_date         DATE;
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;
  l_step         VARCHAR2(5);

  invalid_parameters EXCEPTION;

BEGIN

  -- Determine instance info
  l_step := '10';
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    l_step := '20';
    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    
    print_error('Error in validate_parameters gathering instance information: '
      ||sqlerrm,'Y');
    raise;
  END;


  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');

  l_step := '30';
  IF p_org_id is null THEN
    print_error('No operating unit organization ID specified. '||
      'The org_id parameter is mandatory.','Y');
    raise invalid_parameters;
  END IF;
  IF p_from_date is null THEN
    print_error('No "From Date" specified. '||
      'The from_date parameter is mandatory.','Y');
    raise invalid_parameters;
  END IF;

  l_from_date := to_char(nvl(p_from_date,sysdate-90),'DD-MON-YYYY');

/*l_step := '40';
  IF nvl(p_trx_type,'XXX') NOT IN ('PA','PO','REQUISITION','RELEASE','ANY') THEN
    print_error('Invalid trx type specified.','Y');
    print_error('Value should be one of PA, PO, REQUISTION, RELEASE, or ANY','Y');
    raise invalid_parameters;
  END IF;

  l_step := '50';
  IF (p_release_num is not null AND
      (p_trx_type <> 'RELEASE' OR p_trx_num is null)) OR
     ((p_release_num is null OR p_trx_num is null) AND
      p_trx_type = 'RELEASE') THEN
    print_error('Invalid combination. For a release the transaction type '||
      'should be RELEASE and the release number and PO number '||
      'must both be provided','Y');
    raise invalid_parameters;
  END IF;
*/

 -- IF p_line_num is not null THEN
    IF p_trx_num is not null and p_line_num is null THEN
    l_step := '60';
    BEGIN
	 SELECT h.po_header_id, r.created_by
      INTO   l_doc_id,  l_created_by
      FROM   po_headers_all h, po_lines_all r
      WHERE  h.segment1 = p_trx_num
      AND    h.org_id = p_org_id
      AND    r.org_id = h.org_id
      AND    r.po_header_id = h.po_header_id;
   --   AND    r.line_num = p_line_num;
      /*SELECT h.po_header_id, r.po_release_id, r.release_type,
             r.wf_item_type, r.wf_item_key, r.created_by
      INTO   l_doc_id, l_rel_id, l_doc_subtype,
             l_item_type, l_item_key, l_created_by
      FROM   po_headers_all h, po_releases_all r
      WHERE  h.segment1 = p_trx_num
      AND    h.org_id = p_org_id
      AND    r.org_id = h.org_id
      AND    r.po_header_id = h.po_header_id
      AND    r.release_num = p_release_num;*/
    EXCEPTION WHEN NO_DATA_FOUND THEN
      print_error('Invalid PO and org_id combination','Y');
      print_error('No PO document exists for values '||
        to_char(p_line_num)||'/'||p_trx_num||'/'||to_char(p_org_id),'Y');
      raise invalid_parameters;
    END;
	END If;
	
    IF p_trx_num is not null and p_line_num is not null THEN
    l_step := '65';
    BEGIN
	 SELECT h.po_header_id, r.line_num, r.created_by
      INTO   l_doc_id, l_line_num, l_created_by
      FROM   po_headers_all h, po_lines_all r
      WHERE  h.segment1 = p_trx_num
      AND    h.org_id = p_org_id
      AND    r.org_id = h.org_id
      AND    r.po_header_id = h.po_header_id
	  AND    r.line_num = p_line_num;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      print_error('Invalid line, PO and org_id combination','Y');
      print_error('No line document exists for values '||
        to_char(p_line_num)||'/'||p_trx_num||'/'||to_char(p_org_id),'Y');
      raise invalid_parameters;
	END;

 /* ELSIF p_trx_num is not null THEN
    IF p_trx_type is null OR p_trx_type = 'ANY' THEN
      print_error('You must specify the org_id and transaction type when '||
        'trx_number is specified.','Y');
      raise invalid_parameters;
    ELSIF p_trx_type IN ('PA','PO') THEN
      l_step := '70';
      BEGIN
        SELECT po_header_id, type_lookup_code, created_by,
               wf_item_type, wf_item_key
        INTO   l_doc_id, l_doc_subtype, l_created_by,
               l_item_type, l_item_key
        FROM   po_headers_all
        WHERE  segment1 = p_trx_num
        AND    ((p_trx_type = 'PA' AND
                 type_lookup_code IN ('BLANKET','CONTRACT')) OR
                (p_trx_type = 'PO' AND
                 type_lookup_code IN ('STANDARD','PLANNED')))
        AND    org_id = p_org_id
        AND    rownum = 1;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        print_error('Invalid transaction type, number, and org_id combination','Y');
        print_error('No document exists for values '||p_trx_type||
          '/'||p_trx_num||'/'||to_char(p_org_id),'Y');
        raise invalid_parameters;
      END;
    ELSIF p_trx_type = 'REQUISITION' THEN
      l_step := '80';
      BEGIN
        SELECT requisition_header_id, type_lookup_code,
               created_by, wf_item_type, wf_item_key
        INTO   l_doc_id, l_doc_subtype, l_created_by,
               l_item_type, l_item_key
        FROM   po_requisition_headers_all
        WHERE  segment1 = p_trx_num
        AND    org_id = p_org_id;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        print_error('Invalid transaction type, number, and org_id combination','Y');
        print_error('No document exists for values '||p_trx_type||
          '/'||p_trx_num||'/'||to_char(p_org_id),'Y');
        raise invalid_parameters;
      END; 
    END IF; */
  END IF;
  
 /* IF p_trx_type IN ('PA','PO') AND
     l_doc_subtype IN ('CONTRACT','BLANKET') THEN
    l_trx_type := 'PA';
  ELSE
    l_trx_type := p_trx_type;
  END IF; */
  
  -- Revision and date values populated by RCS
  l_revision := rtrim(replace('$Revision: 120.14 $','$',''));
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2013/09/13 22:08:26 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');

  -- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_rep_info('File Name') := 'ip_item_anlyzer.sql';
  g_rep_info('File Version') := l_revision;
  g_rep_info('File Date') := l_date_char;
  g_rep_info('Run Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');

  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Operating Unit') := p_org_id;
  g_parameters('2. Login Name') := p_user_name;
  g_parameters('3. Responsibility ID') := p_responsibility_id;  
  g_parameters('4. Item Number') := p_item_num;
  g_parameters('5. Trx Number') := p_trx_num;
  g_parameters('6. Line Number') := p_line_num;
  g_parameters('7. From Date') := l_from_date;
  g_parameters('8. Max Rows') := g_max_output_rows;
  g_parameters('9. Debug Mode') := p_debug_mode;

  -- Create global hash of SQL token values
  g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');
  g_sql_tokens('##$$ITEMNUM$$##') := p_item_num;
  g_sql_tokens('##$$SUBTP$$##') := l_doc_subtype;
  g_sql_tokens('##$$ORGID$$##') := to_char(p_org_id);
  g_sql_tokens('##$$DOCID$$##') := nvl(to_char(p_trx_num),'NULL');
  g_sql_tokens('##$$RELID$$##') := nvl(to_char(p_line_num),'NULL');
  g_sql_tokens('##$$FDATE$$##') := l_from_date;
  g_sql_tokens('##$$USERNAME$$##') := to_char(p_user_name);
  g_sql_tokens('##$$RESPID$$##') := to_char(p_responsibility_id);
  g_sql_tokens('##$$APPATH$$##') := nvl(to_char(l_app_path_id),'NULL');

  l_step := '90';
  l_key := g_sql_tokens.first;
  -- Print token values to the log
  print_log('SQL Token Values');
  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;



EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_error('Invalid parameters provided. Process cannot continue.','Y');
    raise;
  WHEN OTHERS THEN
    print_error('Error validating parameters:'||l_step||': '||sqlerrm,'Y');
    raise;
END validate_parameters;


---------------------------------------------
-- Load this test signatures               --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN
 
  -------------------------------------------
  -- Invalids
  -------------------------------------------
  add_signature(
   'IP_INVALIDS',                                           -- Signature ID
   'SELECT a.object_name "Object Name",
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c 
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,                                        
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''ICX%'' OR
         a.object_name like ''PO%'' OR
		 a.object_name like ''FND%'')
    AND a.status = ''INVALID''',                             -- SQL
   'iProcurement Related Invalid Objects.',                  -- User signature name (title in report)  
   'RS',                                                     -- Print SQL Output (Y, N, RS = only if rows selected) 
   'Invalid objects exist that are related to Procurement',     -- Problem description
   '<ul>
      <li>Recompile the individual objects or recompile the 
          entire APPS schema using the adadmin utility.</li>
      <li>Review any error messages provided and see [1527251.1]
          for details on compiling these invalid objects.</li>
   </ul>',                                               -- Solution HTML
   'Invalid objects for schemas ICX, PO and FND were not found.',             -- Success message if printing success (non default)
   'ALWAYS',                                             -- Print condition ALWAYS, SUCCESS, FAILURE, NEVER
   'E',                                                  -- Warn(W), Err(E), Info(I) 
   'Y');                                                 -- Limit output rows to the max rows value

   ------------------------------------------
   -- Check iP specific Profiles
   ------------------------------------------
    add_signature(
   'IP_SPECIFIC_PROFILES',
   'SELECT user_profile_option_name "Profile Option",
           a.profile_option_value "Profile Value",
           DECODE(a.level_id, 10001, ''Site'',
                              10002, ''Application'',
                              10003, ''Responsibility'',
                              10004, ''User'') "Level",
           DECODE(a.level_id, 10001, ''Site'', 10002, b.application_short_name, 10003, c.responsibility_name, 10004, d.user_name) "Level Value",
           c.responsibility_id
    FROM fnd_profile_option_values a,
         fnd_application b,
         fnd_responsibility_tl c,
         fnd_user d,
         fnd_profile_options e,
         fnd_profile_options_tl t
    WHERE a.profile_option_id  = e.profile_option_id
      AND a.level_value          = b.application_id(+)
      AND a.level_value          = c.responsibility_id(+)
      AND a.level_value          = d.user_id(+)
      AND t.profile_option_name  = e.profile_option_name
      AND t.LANGUAGE             = ''US''
      AND e.profile_option_name IN (''POR_AUTO_CREATE_SHOPPING_CAT'',
	                                ''REQUISITION_TYPE'',
	                                ''POR_ALLOW_MANUAL_SELECT_SOURCE'',
									''POR_DISPLAY_ADVANCED_SEARCH'',
									''POR_DISPLAY_SEARCH_AND_BROWSE'',
									''ORG_ID'',
									''XLA_MO_SECURITY_PROFILE_LEVEL'')
	  AND ((a.level_id = 10003 AND a.level_value = ##$$RESPID$$##) 
      OR   (a.level_id = 10004 AND d.user_name = ''##$$USERNAME$$##'')
      OR   (a.level_id = 10001 ))								
   ORDER BY e.profile_option_name,
            a.level_id DESC',
   'iProcurement Specific Profile Options.',
   'RS',
   'This shows specific profiles that should be reviewed when items do not appear in iProcurement.',
   '<ul>
   <li>Follow the solution instructions provided in [461747.1]</li>
   </ul>',
   null,
  'ALWAYS',
   'I',
   'RS');
   

   ------------------------------------------
   -- Check iP specific Profiles - MO: Security Profile. If not null then Provide error message
   ------------------------------------------
       add_signature(
   'IP_MOAC_PROFILE',
   'SELECT user_profile_option_name "Profile Option",
           a.profile_option_value "Profile Value",
           DECODE(a.level_id, 10003, ''Responsibility'') "Level",
           DECODE(a.level_id, 10003, c.responsibility_name) "Level Value",
           c.responsibility_id
    FROM fnd_profile_option_values a,
         fnd_application b,
         fnd_responsibility_tl c,
         fnd_profile_options e,
         fnd_profile_options_tl t
    WHERE a.profile_option_id  = e.profile_option_id
      AND a.level_value          = b.application_id(+)
      AND a.level_value          = c.responsibility_id(+)
      AND t.profile_option_name  = e.profile_option_name
      AND t.LANGUAGE             = ''US''
	  AND c.language             = ''US''
      AND e.profile_option_name IN (''XLA_MO_SECURITY_PROFILE_LEVEL'')
	  AND (a.level_id = 10003 
	  AND a.level_value = ##$$RESPID$$##  
      AND a.profile_option_value IS NOT NULL)
   ORDER BY e.profile_option_name,
            a.level_id DESC',
   'iProcurement MOAC Profile Option.',
   'RS',
   'This shows if there is a value in the MOAC profile. iProcurement Does not use MOAC at this time so this should always be NULL.',
   '<ul>
   <li> Review Note - Is Iprocurement Enabled For Multiple Operating Units (MOAC)?  [579900.1]</li>
   </ul>',
   'The Profile MO: Security Profile is correctly set to NULL for iProcurement Responsibility.',
  'ALWAYS',
   'E',
   'Y'); 

  
   
  ------------------------------------------
  -- Max Extents and Space Issues
  ------------------------------------------
  add_signature(
   'TABLESPACE_CHECK',
   'SELECT s.segment_name object_name,
           s.owner,
           s.tablespace_name tablespace,
           s.segment_type object_type,
           s.extents extents,
           s.max_extents max_extents,
           s.next_extent/1024/1024 next_extent,
           max(fs.bytes)/1024/1024 max,
           sum(fs.bytes)/1024/1024 free
    FROM dba_segments     s,
         dba_free_space   fs
    WHERE s.segment_type IN (''TABLE'',''INDEX'')
    AND   s.segment_name like ''PO\_%'' escape ''\''
    AND   fs.tablespace_name = s.tablespace_name
    GROUP BY s.tablespace_name, s.owner, s.segment_type,
           s.segment_name, s.extents, s.max_extents, s.next_extent
    HAVING (s.extents >= (s.max_extents - 2) OR
            s.next_extent > max(fs.bytes))
    ORDER BY extents desc',
   'Potential Space and Extents Issues',
   'RS',
    'The objects listed above are either approaching their
     maximum number or extents, or have a next extent size
     that is larger than the largest available block of
     free space in the tablespace.',
   '<ul> <li>Review items indicated and increase the max extents or add
    additional data files to the tablespace as required.</li></ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


-- Item Specific scripts

   ----------------------------------------------------------------
   -- IP Specific item details to ensure it can be extracted to ip
   ----------------------------------------------------------------
    add_signature(
   'IP_SPECIFIC_ITEM_EXTRACT',
   'SELECT INVENTORY_ITEM_ID, 
           SEGMENT1, 
		   ORGANIZATION_ID,
		   INVENTORY_ITEM_STATUS_CODE,
		   WEB_STATUS, 
		   LAST_UPDATE_DATE,
           END_DATE_ACTIVE, 
		   ENABLED_FLAG, 
		   PURCHASING_ITEM_FLAG, 
		   PURCHASING_ENABLED_FLAG, 
		   INTERNAL_ORDER_FLAG, 
		   LIST_PRICE_PER_UNIT
    FROM   mtl_system_items_kfv
    WHERE  Organization_id = ##$$ORGID$$##
	AND    segment1 = ''##$$ITEMNUM$$##''',
   'Specific Item Checks',
   'RS',
   'This shows specific item details from inventory.',
   '<ul>
   <li>This shows all inventory-related fields for a specific item.</li>
   <li>Follow the solution instructions provided in [1336169.1]</li>
   </ul>',
   null,
  'ALWAYS',
   'E',
   'RS',
   'Y');
   
   ----------------------------------------------------------------------
   -- IP Specific item details to ensure it can be extracted to ip-case 1
   ----------------------------------------------------------------------

 add_signature(
   'IP_SPECIFIC_ITEM_EXTRACT_case1',
   'SELECT invitems.segment1, icxitems.*
FROM   icx_cat_items_ctx_hdrs_tlp icxitems,
       mtl_system_items_b invitems,
       financials_system_params_all fsp
WHERE  icxitems.inventory_item_id = invitems.inventory_item_id
       AND icxitems.ip_category_id = ''-2''
       AND invitems.segment1 = ''##$$ITEMNUM$$##''
       AND fsp.inventory_organization_id = invitems.organization_id
       AND fsp.org_id = icxitems.org_id      
       AND fsp.org_id = ##$$ORGID$$##',
   'Specific Item With No iProcurement Shopping Category.',
   'RS',
   'This shows specific item details if the ip_category_id = -2. This means these items May not appear in iProcurement.',
   '<ul>
   <li>An ip_category of -2 indicates that the mapping may not be correct between the purchasing and IP shopping categories.</li>
	<li> However the item may still appear in the search results if the content zone allows items without shopping categories</li>
   <li>Follow the solution instructions provided in [1336169.1]</li>
   </ul>',
   'The item has a mapped Shopping catgeory to Purchasing category',
  'ALWAYS',
   'E',
   'RS',
   'Y');
   
   
   ----------------------------------------------------------------------
   -- IP Specific item details to ensure it can be extracted to ip-case 2
   ----------------------------------------------------------------------
       add_signature(
   'IP_SPECIFIC_ITEM_EXTRACT_case2',
   'SELECT INVENTORY_ITEM_ID, 
           SEGMENT1, 
		   ORGANIZATION_ID,
		   INVENTORY_ITEM_STATUS_CODE,
		   WEB_STATUS, 
		   LAST_UPDATE_DATE,
           END_DATE_ACTIVE, 
		   ENABLED_FLAG, 
		   PURCHASING_ITEM_FLAG, 
		   PURCHASING_ENABLED_FLAG, 
		   INTERNAL_ORDER_FLAG, 
		   LIST_PRICE_PER_UNIT
    FROM   mtl_system_items_kfv
    WHERE  Organization_id = ##$$ORGID$$##
	AND    segment1 = ''##$$ITEMNUM$$##''
       /* Base script ends, specific checks for this error follow */	
	AND    INVENTORY_ITEM_STATUS_CODE = ''Inactive''',
   'Item Status Is Not Active.',
   'RS',
   'The item is not an active inventory item.',
   '<ul>
   <li>Set the item status to Active.</li>
   <li>Follow the solution instructions provided in [880285.1]</li>
   </ul>',
   'Item Status is ACTIVE',
  'ALWAYS',
   'E',
   'Y');
   
   ----------------------------------------------------------------------
   -- IP Specific item details to ensure it can be extracted to ip-case 3
   ----------------------------------------------------------------------
       add_signature(
   'IP_SPECIFIC_ITEM_EXTRACT_case3',
   'SELECT INVENTORY_ITEM_ID, 
           SEGMENT1, 
		   ORGANIZATION_ID,
		   INVENTORY_ITEM_STATUS_CODE,
		   WEB_STATUS, 
		   LAST_UPDATE_DATE,
           END_DATE_ACTIVE, 
		   ENABLED_FLAG, 
		   PURCHASING_ITEM_FLAG, 
		   PURCHASING_ENABLED_FLAG, 
		   INTERNAL_ORDER_FLAG, 
		   LIST_PRICE_PER_UNIT
    FROM   mtl_system_items_kfv
    WHERE  Organization_id = ##$$ORGID$$##
	AND    segment1 = ''##$$ITEMNUM$$##''
       /* Base script ends, specific checks for this error follow */	
	AND    PURCHASING_ITEM_FLAG = ''N''',
   'Item Is Not Purchased.',
   'RS',
    'The item is not a Purchased inventory item.',
   '<ul>
   <li>Ensure the Purchased checkbox is selected under the purchasing tab of the item.</li>
   <li>Follow the solution instructions provided in [880285.1]</li>
   </ul>',
   'Item is Purchased',
  'ALWAYS',
   'E',
   'Y');
   
   ----------------------------------------------------------------------
   -- IP Specific item details to ensure it can be extracted to ip-case 4
   ----------------------------------------------------------------------
          add_signature(
   'IP_SPECIFIC_ITEM_EXTRACT_case4',
   'SELECT INVENTORY_ITEM_ID, 
           SEGMENT1, 
		   ORGANIZATION_ID,
		   INVENTORY_ITEM_STATUS_CODE,
		   WEB_STATUS, 
		   LAST_UPDATE_DATE,
           END_DATE_ACTIVE, 
		   ENABLED_FLAG, 
		   PURCHASING_ITEM_FLAG, 
		   PURCHASING_ENABLED_FLAG, 
		   INTERNAL_ORDER_FLAG, 
		   LIST_PRICE_PER_UNIT
    FROM   mtl_system_items_kfv
    WHERE  Organization_id = ##$$ORGID$$##
	AND    segment1 = ''##$$ITEMNUM$$##''
       /* Base script ends, specific checks for this error follow */	
	AND    PURCHASING_ENABLED_FLAG = ''N''',
   'Item Is Not Purchasable.',
   'RS',
    'The item is not a Purchasable inventory item.',
   '<ul>
   <li>Ensure the Purchasable checkbox is selected under the purchasing tab of the item.</li>
   <li>Follow the solution instructions provided in [880285.1]</li>
   </ul>',
   'Item is Purchasable',
  'ALWAYS',
   'E',
   'Y');
   

   ----------------------------------------------------------------------
   -- IP Specific item details to ensure it can be extracted to ip-case 5
   ----------------------------------------------------------------------
             add_signature(
   'IP_SPECIFIC_ITEM_EXTRACT_case5',
   'SELECT INVENTORY_ITEM_ID, 
           SEGMENT1, 
		   ORGANIZATION_ID,
		   INVENTORY_ITEM_STATUS_CODE,
		   WEB_STATUS, 
		   LAST_UPDATE_DATE,
           END_DATE_ACTIVE, 
		   ENABLED_FLAG, 
		   PURCHASING_ITEM_FLAG, 
		   PURCHASING_ENABLED_FLAG, 
		   INTERNAL_ORDER_FLAG, 
		   LIST_PRICE_PER_UNIT
    FROM   mtl_system_items_kfv
    WHERE  Organization_id = ##$$ORGID$$##
	AND    segment1 = ''##$$ITEMNUM$$##''
       /* Base script ends, specific checks for this error follow */	
	AND     LIST_PRICE_PER_UNIT is null',
   'Item Has No List Price.',
   'RS',
    'The item has no List Price.',
   '<ul>
   <li>Ensure there is a list price greater than 0 under the purchasing tab of the item.</li>
   <li>Follow the solution instructions provided in [880285.1]</li>
   </ul>',
   'Item has a valid List Price',
  'ALWAYS',
   'E',
   'Y');
   
   

  -------------------------------------------
  -- IP all items with ip_category = -2
  ------------------------------------------
  -- removed the limit of the # of records returned so the user can see them all at this time.
  add_signature(
   'IP_ALL_ITEM',
   'SELECT invitems.segment1, icxitems.*
FROM   icx_cat_items_ctx_hdrs_tlp icxitems,
       mtl_system_items_b invitems,
       financials_system_params_all fsp
WHERE  icxitems.inventory_item_id = invitems.inventory_item_id
	   AND icxitems.ip_category_id = ''-2''
       AND fsp.inventory_organization_id = invitems.organization_id
       AND fsp.org_id = icxitems.org_id      
       AND fsp.org_id = ##$$ORGID$$##',
   'All Items With Non-Mapped Shopping Categories.',
   'RS',
   'This shows all item details if the ip_category_id = -2. This means these items MAY not appear in iProcurement,',
   '<ul>
    <li>An ip_category of -2 indicates that the mapping may not be correct between the purchasing and IP shopping categories.</li>
	<li> However the item may still appear in the search results if the content zone allows items without shopping categories</li>
	<li>Follow the solution instructions provided in [1336169.1]</li>
   </ul>',
      'Item has a valid shopping category mapped to a purchasing category',
   'ALWAYS',
   'E',
   'Y');
   
   
-- Category specific scripts
   
  -------------------------------------------
  -- IP all non mapped Purchasing Categories
  -------------------------------------------
  -- removed the limit of the # of records returned so the user can see them all at this time.
  
 add_signature(
   'IP_NON_MAPPED_PO_CATEGORIES',
   'SELECT purchcategories.category_id purchasing_category_key,
           purchcategories.concatenated_segments
           purchasing_category_segments,
           purchcategoriestl.language
FROM mtl_categories_kfv purchcategories,
   --  mtl_category_set_valid_cats mcsvc,
     mtl_categories_tl purchcategoriestl,
     mtl_default_sets_view v
WHERE v.functional_area_id = 2 
 --   AND mcsvc.category_set_id = v.category_set_id
 --   AND mcsvc.category_id = purchcategories.category_id
AND purchcategories.structure_id = v.structure_id
AND Nvl(purchcategories.start_date_active,SYSDATE) <= SYSDATE
AND SYSDATE < Nvl(purchcategories.end_date_active,SYSDATE + 1)
AND SYSDATE < Nvl(purchcategories.disable_date,SYSDATE + 1)
AND NOT EXISTS (SELECT 1
FROM icx.icx_por_category_data_sources
     purchasingcatmapping
WHERE To_char(purchcategories.category_id) =
      purchasingcatmapping.external_source_key)
 AND purchcategoriestl.category_id = purchcategories.category_id',
   'All Non-Mapped Purchasing Categories.',
   'RS',
   'This shows all PO categories that are currently not mapped to a iProcurement category (Shopping Category)',
   '<ul>
    <li>Review the Purchasing categories above and determine if they should be mapped to a shopping category.</li>
	<li> Profile POR: Autocreate Shopping Category and Mapping should be set to Yes if auto-mapping is desired.</li>
	<li> For more information, see [1370859.1]</li>
   </ul>',
   null,
  'ALWAYS',
   'I',
   'RS',
   'Y');
  
  
  
-- PO Issues

  -------------------------------------------  
-- Items on Purchase Orders Not Appearing due to no category mapping
  -------------------------------------------
 
 add_signature(
   'IP_PO_DOCUMENT_ITEMS_NOT_SHOWING',
   'SELECT POH.SEGMENT1, POL.po_line_id,
           NVL(ICXM.SHOPPING_CATEGORY_ID, NULL) ip_cat_id, mtl.segment1 "Item Number", pol.item_description, pol.expiration_date
    FROM PO_HEADERS_ALL POH, PO_LINES_ALL POL, PO_ATTRIBUTE_VALUES_TLP TLP,
         ICX_CAT_PURCHASING_CAT_MAP_V ICXM, MTL_SYSTEM_ITEMS_B MTL
    WHERE   POH.po_header_id = ##$$DOCID$$##
        AND POL.CATEGORY_ID = ICXM.po_category_id
		AND POH.po_header_id = POL.po_header_id
        AND TLP.language = ''US''
		AND POH.org_id = ##$$ORGID$$##
		AND POH.org_id = mtl.organization_id
		AND TYPE_LOOKUP_CODE = ''BLANKET''
        AND POL.po_line_id = TLP.po_line_id
		AND pol.item_id = mtl.inventory_item_id
        order by pol.line_num ASC',
   'Items From SPECIFIC Blanket Orders Not Showing.',
   'RS',
   'This shows specific item details for a Invalid category mapping.',
   '<ul>
<li>Review the FIX_SINGLE_BPA.sql script(s) from [579294.1] </li>
   </ul>',
   'There appears to be no issues with category mappings for this one time item from blanket purchase agreements not showing in iProcurement.',
  'ALWAYS',
   'E',
   'Y');   
   

  -------------------------------------------  
-- Check to see if Specific Purchase order line specified is expired
  -------------------------------------------
 
 add_signature(   
    'IP_PO_DOCUMENT_ITEMS_NOT_SHOWING_BLANKET_EXPIRED',
   'SELECT POH.SEGMENT1, POL.po_line_id,
           mtl.segment1 "Item Number", pol.item_description, pol.expiration_date
    FROM PO_HEADERS_ALL POH, PO_LINES_ALL POL, MTL_SYSTEM_ITEMS_B MTL, FINANCIALS_SYSTEM_PARAMS_ALL FSP
    WHERE POH.po_header_id = POL.po_header_id  
	    AND POH.po_header_id = ##$$DOCID$$##
	    AND POH.org_id = ##$$ORGID$$##
		AND POH.org_id = FSP.ORG_ID
		AND FSP.INVENTORY_ORGANIZATION_ID = mtl.organization_id
		AND pol.item_id = mtl.inventory_item_id
		AND TYPE_LOOKUP_CODE = ''BLANKET''
        AND POL.line_num = ##$$RELID$$##
		AND pol.expiration_date < trunc(sysdate)',
   'Item From SPECIFIC Blanket Orders Not Showing Due To Expired Line.',
   'RS',
   'This shows specific item details for a expired Blanket line.',
   '<ul>
<li>Please remove the Expiration Date for the one time item to be seen in iProcurement</li>
   </ul>',
   'The Blanket Order line for this one time item is not expired.',
  'ALWAYS',
   'E',
   'Y');  
   

  -------------------------------------------  
-- Check to see if Specific Purchase order specified is in Approved Status
  -------------------------------------------
 
 add_signature(   
    'IP_PO_DOCUMENT_NOT_SHOWING_BLANKET_UNAPPROVED',
   'SELECT POH.SEGMENT1, POL.po_line_id,
           mtl.segment1 "Item Number", pol.item_description,  poh.authorization_status, pol.expiration_date
    FROM PO_HEADERS_ALL POH, PO_LINES_ALL POL, MTL_SYSTEM_ITEMS_B MTL, FINANCIALS_SYSTEM_PARAMS_ALL FSP
    WHERE POH.po_header_id = POL.po_header_id  
	    AND POH.po_header_id = ##$$DOCID$$##
	    AND POH.org_id = ##$$ORGID$$##
		AND POH.org_id = FSP.ORG_ID		
		AND POH.org_id = mtl.organization_id
		AND FSP.INVENTORY_ORGANIZATION_ID = mtl.organization_id
		AND pol.item_id = mtl.inventory_item_id
		AND POH.authorization_status <> ''APPROVED''
		AND TYPE_LOOKUP_CODE = ''BLANKET''',
   'Items From Blanket Orders Not Showing Due To Un-Approved PO.',
   'RS',
   'This shows specific item details for a Un-Approved Blanket Order.',
   '<ul>
<li>Please Approve the Purchase Order for the item(s) to be seen in iProcurement</li>
   </ul>',
   'The Blanket Order is Approved.',
  'ALWAYS',
   'E',
   'Y');  
   


   
  -------------------------------------------  
-- Check to see if Purchase order lines are expired
  -------------------------------------------
 
 add_signature(   
    'IP_ALL_PO_DOCUMENT_ITEMS_NOT_SHOWING_BLANKET_EXPIRED',
   'SELECT POH.SEGMENT1, POL.po_line_id,
           mtl.segment1 "Item Number", pol.item_description, pol.expiration_date
    FROM PO_HEADERS_ALL POH, PO_LINES_ALL POL, MTL_SYSTEM_ITEMS_B MTL, FINANCIALS_SYSTEM_PARAMS_ALL FSP
    WHERE  POH.po_header_id = POL.po_header_id
	    AND POH.org_id = ##$$ORGID$$##
		AND POH.org_id = FSP.ORG_ID
        AND FSP.INVENTORY_ORGANIZATION_ID = mtl.inventory_item_id
		AND TYPE_LOOKUP_CODE = ''BLANKET''
		AND pol.expiration_date < trunc(sysdate)',
   'Items From Blanket Orders Not Showing Due To Expired Line.',
   'RS',
   'This shows item details for expired Blanket lines.',
   '<ul>
<li>Please remove the Expiration Date for the one time item to be seen in iProcurement</li>
   </ul>',
   'There are no expired Blanket Orders that contain one time items.',
  'ALWAYS',
   'E',
   'Y');    


  -------------------------------------------  
-- Check to see if Purchase order is in Approved Status
  -------------------------------------------
 
 add_signature(   
    'IP_ALL_PO_DOCUMENT_NOT_SHOWING_BLANKET_UNAPPROVED',
   'SELECT POH.SEGMENT1, POL.po_line_id,
           mtl.segment1 "Item Number", pol.item_description,  poh.authorization_status, pol.expiration_date
    FROM PO_HEADERS_ALL POH, PO_LINES_ALL POL, MTL_SYSTEM_ITEMS_B MTL, FINANCIALS_SYSTEM_PARAMS_ALL FSP
    WHERE   POH.org_id = ##$$ORGID$$##
		AND POH.po_header_id = POL.po_header_id
		AND POH.org_id = FSP.ORG_ID
        AND FSP.INVENTORY_ORGANIZATION_ID = mtl.inventory_item_id
		AND POH.authorization_status <> ''APPROVED''
		AND TYPE_LOOKUP_CODE = ''BLANKET''',
   'Items From Blanket Orders Not Showing Due To Un-Approved PO.',
   'RS',
   'This shows item details for all Un-Approved Blanket Orders.',
   '<ul>
<li>Please Approve the Purchase Order for the item(s) to be seen in iProcurement</li>
   </ul>',
   'The Blanket Order is Approved.',
  'ALWAYS',
   'E',
   'Y');     
   
  
 -- Misc Scripts
 
  -------------------------------------------
  -- IP Items from a document that cannot be seen in IP due to POR: Autocreate Shopping Category and Mapping profile being set to No
  -------------------------------------------
  
 add_signature(
   'IP_DOCUMENT_ITEMS_NOT_SHOWING',
   'SELECT poh.segment1, pol.line_num, pol.po_line_id, 
       NVL (icxm.shopping_category_id, NULL) ip_cat_id, mtl.segment1 "Item Number",pol.item_description, pol.expiration_date
FROM   po_lines_all pol, po_headers_all poh,
       icx_cat_purchasing_cat_map_v icxm, 
       po_attribute_values_tlp tlp,
       MTL_SYSTEM_ITEMS_B MTL
WHERE  poh.po_header_id = pol.po_header_id
AND pol.po_header_id in (SELECT DISTINCT pha.po_header_id FROM po_headers_all pha, po_lines_all pla
                            WHERE pha.po_header_id = pla.po_header_id AND pla.ip_category_id = -2 AND pha.type_lookup_code = ''BLANKET'')
AND    pol.category_id = icxm.po_category_id
AND    pol.po_line_id = tlp.po_line_id
AND    POH.org_id = ##$$ORGID$$##
AND    POH.org_id = mtl.organization_id
AND    pol.ip_category_id = -2
order by po_line_id desc',
   'Items From Blanket Orders Not Showing due to no shopping category.',
   'RS',
   'This shows specific item details for a invalid Shopping Category Mapping.',
   '<ul>
<li>Review the FIX_ALL_BPA.sql script(s) from [579294.1] </li>
   </ul>',
   'There appears to be no issues with category mappings for these items from blanket purchase agreements not showing in iProcurement.',
  'ALWAYS',
   'E',
   'Y');
  
  

-- Store and Content Zone Scripts

  
  -------------------------------------------
  -- IP Store - All stores that neither have smart form nor content zone.
  ------------------------------------------

 add_signature(
   'IP_LIST_STORES',
   'SELECT stores.store_id "Store Id",
      stores.name "Store Name",
      stores.description "Store Description"
FROM ICX_CAT_SHOP_STORES_VL stores
WHERE NOT EXISTS(SELECT 1
                  FROM ICX_CAT_STORE_CONTENTS storecontents
                  WHERE   storecontents.STORE_ID = STORES.STORE_ID)
				  ORDER BY "Store Name"',
   'Store With No Smart Forms Or Content Zones.',
   'RS',
   'This shows stores that have neither a smart form nor a content zone assigned.',
  '<ul>
  <li>Review the settings indicated above.  No action is needed as this is only informational.</li>
  </ul>',
   'This shows stores that have neither a smart form nor a content zone assigned.',
  'ALWAYS',
   'I',
   'Y');
   
  -------------------------------------------
  -- IP Store - All stores that have either a smart form or a content zone.
  ------------------------------------------

 add_signature(
   'IP_STORES_WITH_DATA',
   'SELECT
      stores.store_id "Store Id",
      stores.name "Store Name",
      stores.description "Store Description",
      contents.name "Content ZONE Name",
      To_Char(NULL) "Smart FORM Name"
FROM
  ICX_CAT_SHOP_STORES_VL stores,
  ICX_CAT_STORE_CONTENTS storecontent,
  ICX_CAT_CONTENT_ZONES_VL contents
WHERE
  --storecontent.store_id = :1 AND
  stores.store_id = storecontent.store_id AND
  storecontent. content_TYPE <> ''SMART_FORM'' AND
  contents.ZONE_ID = storecontent.CONTENT_ID            
UNION ALL
SELECT
      stores.store_id "Store Id",
      stores.name "Store Name",
      stores.description "Store Description",
      To_Char(NULL) "Content ZONE Name",
      contents.template_name "Smart FORM Name"
FROM
  ICX_CAT_SHOP_STORES_VL stores,
  ICX_CAT_STORE_CONTENTS storecontent,
  POR_NONCAT_TEMPLATES_ALL_VL contents
WHERE
  --storecontent.store_id = :1 AND
  stores.store_id = storecontent.store_id AND
  storecontent. content_TYPE = ''SMART_FORM'' AND
  contents.TEMPLATE_ID = storecontent.CONTENT_ID
  ORDER BY "Store Name"',
   'Store Related information.',
   'RS',
   'All stores that have either a smart form or a content zone.',
   '<ul>
  <li>Review the settings indicated above.  No action is needed as this is only informational.</li>
   </ul>',
   null,
  'ALWAYS',
   'I',
   'RS',
   'Y');   
   
   
     -------------------------------------------
     -- IP Content zones detailed information
     -------------------------------------------

 add_signature(
   'IP_DETAILED_CONTENT_ZONE',
   'SELECT IcxCatContentZoneEO.ZONE_ID,
       IcxCatContentZoneEO.TYPE,
	   IcxCatContentZoneEO.NAME,
       IcxCatContentZoneEO.DESCRIPTION,
       IcxCatContentZoneEO.URL,
       IcxCatContentZoneEO.IMAGE,
       IcxCatContentZoneEO.SUPPLIER_ATTRIBUTE_ACTION_FLAG,
       IcxCatContentZoneEO.CATEGORY_ATTRIBUTE_ACTION_FLAG,
       IcxCatContentZoneEO.ITEMS_WITHOUT_SHOP_CATG_FLAG,
       IcxCatContentZoneEO.KEYWORDS,
       IcxCatContentZoneEO.SECURITY_ASSIGNMENT_FLAG,
DECODE(TYPE, ''LOCAL'', 1, 0) IS_LOCAL_ZONE,
               DECODE(TYPE, ''PUNCHOUT'', 1, 0) IS_PUNCHOUT_ZONE,
               DECODE(TYPE, ''TRANSPARENT_PUNCHOUT'', 1, 0) IS_TRANSPARENT_PUNCHOUT_ZONE,
               DECODE(TYPE, ''INFORMATIONAL'', 1, 0) IS_INFORMATIONAL_ZONE,
               DECODE(TYPE, ''PUNCHOUT'', DECODE(PROTOCOL_SUPPORTED,''VIA_EXCHANGE'',0,1),''TRANSPARENT_PUNCHOUT'', 1, 0) IS_PUNCHOUT_OR_TRANSPUNCH_ZONE,
               DECODE(PROTOCOL_SUPPORTED, ''CXML_SUPPLIER'', 1, ''TRANSPARENT_EXCHANGE'', 1, ''TRANSPARENT_SUPPLIER'', 1, 0) IS_COMMUNICATION_MODE_cXML,
               DECODE(PROTOCOL_SUPPORTED, ''CXML_SUPPLIER'', 0, ''TRANSPARENT_EXCHANGE'', 0, ''TRANSPARENT_SUPPLIER'', 0, 1) IS_COMMUNICATION_MODE_XML,
               DECODE(PROTOCOL_SUPPORTED, ''XML_SUPPLIER'', 1,''CXML_SUPPLIER'', 1, ''TRANSPARENT_SUPPLIER'', 1,''VIA_EXCHANGE'', 1, 0) IS_ZONE_FOR_SUPPLIER_SITE,
        DECODE(TYPE, ''PUNCHOUT'', DECODE(PROTOCOL_SUPPORTED, ''CXML_SUPPLIER'', 1, 0), ''TRANSPARENT_PUNCHOUT'', DECODE(PROTOCOL_SUPPORTED,''TRANSPARENT_SUPPLIER'',1,0), 0) IS_SUPPLIER_MODE_cXML,
               DECODE(TYPE, ''LOCAL'', 0,''PUNCHOUT'', DECODE(PROTOCOL_SUPPORTED,''VIA_EXCHANGE'',0,1),  1) IS_PUNCH_OR_TRANS_OR_INFO_ZONE,
               DECODE(TYPE, ''PUNCHOUT'', 1, ''INFORMATIONAL'', 1, 0) IS_PUNCH_OR_INFO_ZONE,
DECODE(IcxCatContentZoneEO.SUPPLIER_ATTRIBUTE_ACTION_FLAG, ''INCLUDE_ALL'', 0, ''EXCLUDE_ALL'', 0, 1) IS_SPECIFIC_SUPPL_ATTACHED,       
DECODE(IcxCatContentZoneEO.CATEGORY_ATTRIBUTE_ACTION_FLAG, ''INCLUDE_ALL'', 0, 1) IS_SPECIFIC_CATG_ATTACHED,
DECODE(IcxCatContentZoneEO.SECURITY_ASSIGNMENT_FLAG, ''OU_SECURED'', 1, 0) IS_SPECIFIC_OU_ATTACHED,
PunchoutDetails.NEGOTIATED_FLAG,
               DECODE(PROTOCOL_SUPPORTED,''EXCHANGE'',1,''TRANSPARENT_EXCHANGE'', 1, ''TRANSPARENT_SUPPLIER'', 1,0) IS_USER_NAME_REQUIRED,
               DECODE(PROTOCOL_SUPPORTED, ''XML_SUPPLIER'', 1, 0) IS_SUPPLIER_MODE_XML,
               DECODE(PROTOCOL_SUPPORTED, ''XML_SUPPLIER'', 1,''TRANSPARENT_SUPPLIER'', 1,0) IS_COMP_INFO_REQUIRED,
               DECODE(PROTOCOL_SUPPORTED, ''TRANSPARENT_EXCHANGE'', 1, 0 ) IS_EXCHANGE_NAME_REQUIRED,
               DECODE(PROTOCOL_SUPPORTED,''TRANSPARENT_SUPPLIER'',1,0) IS_SUPPLEMENTAL_INFO_REQUIRED,
               DECODE(PROTOCOL_SUPPORTED, ''EXCHANGE'', 1,''TRANSPARENT_EXCHANGE'', 1, 0) IS_ZONE_FOR_EXCHANGE_SITE,
               DECODE(IcxCatContentZoneEO.SECURITY_ASSIGNMENT_FLAG, ''RESP_SECURED'', 1, 0) IS_SPECIFIC_RESP_ATTATCHED,
               DECODE(PROTOCOL_SUPPORTED, ''VIA_EXCHANGE'', 1, 0) IS_VIA_EXCHANGE,
       IcxCatContentZoneEO.ITEMS_WITHOUT_SUPPLIER_FLAG,
       IcxCatContentZoneEO.SQE_SEQUENCE
FROM
               ICX_CAT_CONTENT_ZONES_VL IcxCatContentZoneEO,
               ICX_CAT_PUNCHOUT_ZONE_DETAILS PunchoutDetails
WHERE
     IcxCatContentZoneEO.ZONE_ID = PunchoutDetails.ZONE_ID (+)',
   'Content Zone Detailed Information.',
   'RS',
   'This shows content zone detailed information.',
   '<ul>
  <li>Review the settings indicated above.  No action is needed as this is only informational.</li>
   </ul>',
   'This shows content zone detailed information.',
  'ALWAYS',
   'I',
   'RS',
   'Y');
   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;

-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------

-- Verify approver moved above run sql due to required kluge
-- since verify_authority API cannot be run from a query

FUNCTION get_result RETURN VARCHAR2 IS
BEGIN
  return(g_app_results('STATUS')||':'||
    nvl(g_app_results('CODE'),'NULL'));
END get_result;

FUNCTION get_fail_msg RETURN VARCHAR2 IS
BEGIN
  return(g_app_results('FAIL_MSG'));
END get_fail_msg;

FUNCTION get_exc_msg RETURN VARCHAR2 IS
BEGIN
  return(g_app_results('EXC_MSG'));
END get_exc_msg;


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
PROCEDURE main (
      p_org_id          IN NUMBER   DEFAULT null,
	  p_user_name         IN VARCHAR2 DEFAULT null,
	  p_responsibility_id IN VARCHAR2 DEFAULT null,	  
      p_item_num        IN VARCHAR2 DEFAULT null,
      p_trx_num         IN VARCHAR2 DEFAULT null,
      p_line_num     IN NUMBER   DEFAULT null,
      p_from_date       IN DATE     DEFAULT sysdate - 90,
      p_max_output_rows IN NUMBER   DEFAULT 20,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);

BEGIN

  l_step := '10';
  initialize_files;

  l_step := '20';
  print_rep_title('iProcurement', 'iProcurement (IP) Item Analyzer');

  l_step := '30';
  validate_parameters(
      p_org_id,
	  p_user_name,
	  p_responsibility_id,	  
      p_item_num,
      p_trx_num,
      p_line_num,
      p_from_date,
      p_max_output_rows,
      p_debug_mode);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Report Summary');

  -- Proactive section
  l_step := '60';
  start_section('Proactive and Preventative Recommendations');
  l_step := '61';
     set_item_result(check_rec_patches);
  l_step := '62';
     set_item_result(run_stored_sig('IP_INVALIDS'));
  l_step := '63';
     set_item_result(run_stored_sig('IP_SPECIFIC_PROFILES'));	
  l_step := '64';
     set_item_result(run_stored_sig('IP_MOAC_PROFILE'));
  end_section;
  
  
  -- Single Item data validations


IF p_item_num IS NOT NULL THEN
  l_step := '70';
	start_section('Specific Item Checks');
    --  set_item_result(run_stored_sig('IP_SPECIFIC_ITEM_EXTRACT'));
	    set_item_result(run_stored_sig('IP_SPECIFIC_ITEM_EXTRACT_case1'));
		set_item_result(run_stored_sig('IP_SPECIFIC_ITEM_EXTRACT_case2'));
		set_item_result(run_stored_sig('IP_SPECIFIC_ITEM_EXTRACT_case3'));
		set_item_result(run_stored_sig('IP_SPECIFIC_ITEM_EXTRACT_case4'));
		set_item_result(run_stored_sig('IP_SPECIFIC_ITEM_EXTRACT_case5'));
    end_section;
END IF;

-- IF p_item_num IS NULL THEN  
	
-- END IF;	

  -- Single Po data validations
  
 /* 
IF p_trx_num IS NOT NULL THEN
  l_step := '72';
  -- Single trx document details
    start_section('Single Purchase Order Document Details');
   -- IF p_trx_type IN ('PO','ANY','RELEASE') THEN	
	set_item_result(run_stored_sig('IP_PO_DOCUMENT_ITEMS_NOT_SHOWING'));
	set_item_result(run_stored_sig('IP_PO_DOCUMENT_ITEMS_NOT_SHOWING_BLANKET_EXPIRED'));
	set_item_result(run_stored_sig('IP_PO_DOCUMENT_NOT_SHOWING_BLANKET_UNAPPROVED'));
    end_section;
END IF;	
*/
IF p_trx_num IS NOT NULL THEN
  l_step := '72';
  -- Single trx document details
    start_section('Single Purchase Order Document Details');
IF p_trx_num is not null and p_line_num is null THEN 
	set_item_result(run_stored_sig('IP_PO_DOCUMENT_ITEMS_NOT_SHOWING'));
	set_item_result(run_stored_sig('IP_PO_DOCUMENT_NOT_SHOWING_BLANKET_UNAPPROVED'));
ELSIF p_line_num IS NOT NULL THEN
	set_item_result(run_stored_sig('IP_PO_DOCUMENT_ITEMS_NOT_SHOWING_BLANKET_EXPIRED'));
    end_section;
END IF;	
END IF;	


  -- General PO data validations

IF p_trx_num IS NULL THEN	
  l_step := '73';
    start_section('General Purchase Order Documents Details');
	set_item_result(run_stored_sig('IP_ALL_PO_DOCUMENT_ITEMS_NOT_SHOWING_BLANKET_EXPIRED'));
	set_item_result(run_stored_sig('IP_ALL_PO_DOCUMENT_NOT_SHOWING_BLANKET_UNAPPROVED'));
	set_item_result(run_stored_sig('IP_DOCUMENT_ITEMS_NOT_SHOWING'));
    end_section;
END IF;	


  -- Single item & PO data validations
/*
IF p_item_num and p_trx_num IS NOT NULL THEN
    l_step := '74';
    start_section('Item and Purchase Order Documents Details');
  


*/
  -- misc data validations
  
  l_step := '74';
    start_section(initcap(g_app_method)||'All Non-Mapped Purchasing Categories');
      set_item_result(run_stored_sig('IP_NON_MAPPED_PO_CATEGORIES'));
    end_section;	

  l_step := '75';
    start_section('ALL Items with no Shopping Category Mapped');
	  set_item_result(run_stored_sig('IP_ALL_ITEM'));
    end_section;
	
  l_step := '78';
    start_section(initcap(g_app_method)||'Stores With No Smart Forms Or Content Zones');
      set_item_result(run_stored_sig('IP_LIST_STORES'));
    end_section;
	
   l_step := '80';
    start_section(initcap(g_app_method)||'Stores With Smart Forms Or Content Zones');
      set_item_result(run_stored_sig('IP_STORES_WITH_DATA'));
    end_section;
	
   l_step := '82';
    start_section(initcap(g_app_method)||'Content Zone Detailed Information');
      set_item_result(run_stored_sig('IP_DETAILED_CONTENT_ZONE'));
    end_section;

  l_step := '100';
  print_toc_contents('In This Report','Overall Health Status');

  close_files;
EXCEPTION WHEN others THEN
  g_retcode := '2';
  g_errbuf := ltrim(g_errbuf||' Error in main at step '||l_step||': '||
    sqlerrm);
  print_log(g_errbuf);
END main;

---------------------------------
-- MAIN ENTRY POINT FOR CONC PROC
---------------------------------
PROCEDURE main_cp(
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_org_id          IN NUMBER   DEFAULT null,
	  p_user_name         IN VARCHAR2 DEFAULT null,	  
	  p_responsibility_id IN VARCHAR2 DEFAULT null,	  
      p_item_num        IN VARCHAR2 DEFAULT null,
      p_trx_num          IN VARCHAR2 DEFAULT null,
      p_line_num     IN NUMBER   DEFAULT null,
      p_from_date       IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 20,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

l_trx_num   VARCHAR2(25);
l_item_num   VARCHAR2(20);
l_from_date DATE := fnd_conc_date.string_to_date(p_from_date);
l_step      VARCHAR2(5);

BEGIN
  l_step := '10';
  g_retcode := '0';
  g_errbuf := null;
  -- l_trx_num := nvl(p_po_num,0);
  l_trx_num := null;
  l_step := '20';
  main(
      p_org_id => p_org_id,
	  p_user_name => p_user_name,
	  p_responsibility_id => p_responsibility_id,
      p_item_num => p_item_num,
      p_trx_num => p_trx_num,
      p_line_num => p_line_num,
      p_from_date => l_from_date,
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode);
	  
  l_step := '30';
  retcode := g_retcode;
  errbuf  := g_errbuf;

EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp:'||l_step||' '||sqlerrm||' : '||g_errbuf;
END main_cp;

END ip_itemv1_analyzer_pkg;
/
show errors;
exit;
