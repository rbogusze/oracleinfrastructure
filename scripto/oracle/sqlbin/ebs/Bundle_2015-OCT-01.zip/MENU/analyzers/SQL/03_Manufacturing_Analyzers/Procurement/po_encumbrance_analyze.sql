REM $Id: po_encumbrance_analyze.sql,v 200.2 2015/15/05 23:27:42 vhle Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                                                                                                   
REM |                    Redwood Shores, California, USA                                                                                                         
REM |                         All rights reserved.                                                                                                                           
REM +=========================================================================+
REM | Framework 3.0.27                                                                                                                                                 
REM |                                                                                                                                                                               
REM | FILENAME                                                                                                                                                              
REM |    po_encumbrance_analyze.sql                                                                                                                               
REM |                                                                                                                                                                               
REM | DESCRIPTION                                                                                                                                                        
REM |    Wrapper SQL to submit the po_enc_analyzer_pkg.main procedure                                                                    
REM |                                                                                                                                                                             
REM | HISTORY                                                                                                                                                               
REM |  03-APR-2015 VHLE     First version created                                                                                                             
REM |                                                                                                                                                                               
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Procurement Encumbrance Accounting Analyzer
REM
REM MENU_START
REM
REM SQL: Run Procurement Encumbrance Accounting Analyzer
REM FNDLOAD: Load Procurement Encumbrance Accounting Analyzer
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  Procurement Encumbrance Accounting Analyzer [Doc ID: 1970384.1]
REM
REM  Compatible with: [12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package po_enc_analyzer_pkg.main as APPS to create an HTML report 
REM
REM    (2) Install Procurement Encumbrance Accounting Analyzer as a concurrent program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group Payables Reports Only
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: PO_TOP
REM DEF_REQ_GROUP: All Reports
REM PROG_NAME: PODIAGEA
REM APP_NAME: Purchasing
REM PROG_TEMPLATE: POEAAZ.ldt
REM PROD_SHORT_NAME: PO
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM po_encumbrance_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
--SET DEFINE "&"
SET DEFINE '~'

PROMPT
-- PSD #1
PROMPT Submitting EBS Procurement Encumbrance Accounting Analyzer for Standard Purchase Order or Requisition.
-- PSD #2
PROMPT ===========================================================================
PROMPT Enter the org_id for the operating unit.  This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT 1 NUMBER DEFAULT -1 -
       PROMPT 'Enter the org_id (required): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the document type.  This parameter is required.  Valid values are
PROMPT 'PO' for Standard Purchase Order or 'REQ' for Requisition.
PROMPT ===========================================================================
PROMPT
ACCEPT 2 CHAR -
       PROMPT 'Enter document type - PO or REQ - (required): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter document number. This parameter is required.  
PROMPT For example '12345'. 
PROMPT ===========================================================================
PROMPT
ACCEPT 3 CHAR -
       PROMPT 'Enter document number (required): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter document line number, or leave blank and hit enter for all lines.
PROMPT ===========================================================================
PROMPT
ACCEPT 4 CHAR -
       PROMPT 'Enter line number or press enter for all lines: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the date from which to begin validating transactions [sysdate-90].
PROMPT ===========================================================================
PROMPT
COLUMN date1 new_value curdate NOPRINT

ACCEPT 5 DATE FORMAT 'DD-MON-YYYY' DEFAULT '31-DEC-9999' -
       PROMPT 'Enter the start validation date in DD-MON-YYYY format [sysdate-90]: '
PROMPT ===========================================================================
PROMPT Enter the maximum number of rows to display on row limited queries.
PROMPT ===========================================================================
PROMPT
ACCEPT 6 NUMBER DEFAULT 50 -
       PROMPT 'Enter the maximum rows to display [50]: '
PROMPT
PROMPT

DECLARE
-- PSD #3
  l_org_id     NUMBER := '~1';
  l_doc_type   VARCHAR2(20) := '~2';
  l_doc_num    VARCHAR2(20) := '~3';
  l_line_num   VARCHAR2(20) := '~4';
  l_from_date  DATE := to_date('~5'); 
  l_max_rows   NUMBER := '~6';
  l_debug_mode VARCHAR2(1) := 'Y';

BEGIN

	IF l_org_id < 0 THEN
		l_org_id := null;
	END IF;


  IF l_max_rows < 0 THEN
    l_max_rows := 50;
  END IF;

  IF l_from_date is null or l_from_date = TO_DATE ('31-DEC-9999')
  THEN
    l_from_date := (sysdate-90);
  END IF;

-- PSD #4
		po_enc_analyzer_pkg.main(
		p_org_id => l_org_id,
		p_doc_type => l_doc_type,
		p_doc_num => l_doc_num,
		p_line_num => l_line_num,
		p_from_date => l_from_date,
		p_max_output_rows => 50,
		p_debug_mode => 'Y');

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
