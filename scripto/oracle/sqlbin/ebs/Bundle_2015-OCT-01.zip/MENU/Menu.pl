# $Id: Menu.pl 200.9 2015/10/01 10:03:18 kjharris $
# *===========================================================================+
# |  Copyright (c) 2014 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# |
# | FILENAME: Menu.pl
# |
# | 
# | PLATFORM
# |   Unix Generic
# |
# | NOTES
# |
# | HISTORY
# | 200.0 BETA (09-JAN-2015)
# | 200.2 Beta Bundle 2 
# | 200.4 Beta Bundle 3
# | 200.5 GA (04-SEP-2015) 
# | 200.6 GA (07-SEP-2015)  
# | 200.7 GA (17-SEP-2015) 
# | 200.8 Fixed AIX "-maxdepth" issue 
# | 200.8 Fixed directory listing issue resulting in blank menus 
# |   -- this was also due to the AIX fix implemented. 
# | 200.9 Unzip / Update Fixes 
# | -- Fixed exit code 2304 when unzipping (file not found) 
# | -- Added archive dir to update/archive and zips are moved to archive 
# |    dir after they are unzipped during an update. 
# +===========================================================================+
BEGIN
{ 
	require 5.8.0; 
	#Check for apps environment variables which should generally indicate we have an apps env file sourced 
	die "\n\n   ERROR: Apps Environment Required\n\n\n" if ! $ENV{APPL_TOP} && ! $ENV{ORACLE_HOME} && ! $ENV{ADJVAPRG}; 
	$libdir = './perlLib'; 
	push @INC, "$libdir";  
	
	die "\n\n   ERROR: 12.2 Requires Menu.pl be run in the \"RUN\" File System\n    and using the \"RUN\" Environment. \n\n\n" if $ENV{FILE_EDITION} =~ /patch/i; 
	
}

use strict; 
use POSIX; 
use POSIX qw(strftime);
use Term::ANSIColor qw(:constants);
	$Term::ANSIColor::AUTORESET='1'; 

use Cwd;
use File::Find;
use File::Copy; 
use File::Basename;
use Net::Domain qw(hostdomain);

#Menu libs 
use MENU::Analyzer;
use MENU::Load;
use MENU::Menu;
use MENU::SQL;  
use MENU::Update;  

#########
#########
my ($appsUser, $appsPass);  
system("clear"); 
print qq(\n\n   INFO: The "APPS" Database account/password is required and used by this\n    script for the following purposes:\n\n   o To query FND tables related to Concurrent Programs\n   o To run the API FNDLOAD, which loads Concurrent Program\n      data in a safe and supported manner\n   o To Load Analyzer-related Database Objects \n\n   Your account information is not stored, logged or displayed\n    in any way by this script.\n\n); 
	
#Determine if the args are valid
foreach ( @ARGV ) 
	{
		if ($_ =~ /au=(.+)/i || $_ =~ /ap=(.+)/i ) 
		{
			$appsUser=$+ if $_ =~ /au=(.+)/i; 
			$appsPass=$+ if $_ =~ /ap=(.+)/i; 
		}
		elsif ($_ =~ /\-{1,2}h\w+/) 
		{
			usage(); 
		} 
		else
		{
			print "  INFO: Unrecognized Option: $_ \n"; 
			usage(); 
			exit 1; 
		}
	}

#Process Args 
if (! grep(/au=/i, @ARGV)) 
	{
		my $cnt = 0; 
		until (length($appsUser) > 2 || $cnt > 2) 
		{
			print "   Enter your \'apps\' username: "; 
			chomp($appsUser=<STDIN>);
			$cnt++; 
		}
		
		die "\n\n   ERROR: No valid apps username entered" if $cnt > 2; 
	}
if (! grep(/ap=/i, @ARGV))
	{
		
		my $cnt = 0; 
		until (length($appsPass) > 0 || $cnt > 2) 
		{
			print "\n   Enter $appsUser\'s password: ";
			system('stty','-echo');
			chomp($appsPass=<STDIN>);
			system('stty','echo');
			$cnt++; 
		}
		die "\n\n   ERROR: No valid apps password entered" if $cnt > 2; 
	}

#test sql conn 
if (! -e "sql/testConn.sql") 
	{
		open (my $fh, '>', "sql/testConn.sql" ) || die "Cannot open \"sql/testConn.sql\" $! \n"; 
		
		print $fh qq(

        SET VERIFY OFF
        SET ECHO OFF
        exit; 
); 
		
		close $fh; 
	}

my $status = system("sqlplus -L -S $appsUser\/$appsPass  \@sql/testConn.sql");

	
	
if ($status == 0 && defined $status)
	{
		print "\n\n   INFO: SQLPLUS connection test exited with status: $status \n\n";
	}
elsif ($status != 0 && defined $status)
	{
		die "\n\n    ERROR: SQLPLUS connection test exited with status: $status \n\n    Check your username/password\n\n" if $status != 0;
	}
	
#Create an object with the connect string so that all subs can use getConnStrg(); 
$main::connStrg = connectStrg MENU::SQL($appsUser, $appsPass);
$main::log = 'logs/Menu.' . (strftime "%Y-%m-%d_%H%M%S", localtime) . '.log'; 

prnt2Log ("\n\n******Menu.pl Session Start", (strftime "%Y-%m-%d_%H%M%S", localtime), "******\n"); 


#update entry point 
#If we're doing an update, the "MENU/.update" file will be present. 
#when this file is detected, kick right into the update mode right after 
#the unzipping. This is a reboot to load up the new perl code into mem. 
# if (-f '.updateManual') 
# {
	# print "Manual update mode \n"; 
	# manualUpdate(); 
	# exit; 
# }
if (-f '.update') 
{
	prnt2Log "INFO: Resuming Update."; 
	print "   INFO: Update mode \n"; 
	beginUpdate('R'); 
}

#Main Menu entry point 
displayDirs('analyzers/SQL');  
# +---------------------------
# | sub usage 
# | -displays usage info in the case of bad args or 
# | if @ARGV contains "help" | --h | -h  
# +---------------------------
sub usage
{
	system("clear"); 
	printf "\n\n"; 
	printf BOLD WHITE ON_BLUE "    Perl Analyzer Bundle Usage", RESET; 
	printf "\n\n   perl Menu.pl [au=<apps user>] [ap=<apps password>] \n"; 
	printf "   Args \"au\" and \"ap=\" are optional, if left out you will be prompted \n\n"; 
	printf "   More information is available in Doc ID: 1939637.1\n\n\n"; 
	exit; 
}


__END__ 
