==============================================================================
Oracle Support Proactive Services Bundle Perl Menu (200.9) 
==============================================================================
 
Platform - UNIX Generic
Built    - 17-SEP-2015 
 
==============================================================================
Instructions 
==============================================================================

Installation / Updates 
-----------------------

1) Fresh Install (no prior Bundle) 
 
-Unzip the Bundle into any Directory 

2) Update (on top of an existing Bundle) 

-Place the zip into the MENU/updates/ directory and name it "bundle.zip". 
-Run perl Menu.pl and choose the Updates option from the main menu. 
 
 
To Start the Menu 
------------------
Execute the following commands to start the Menu:  
 
1. Source the Applications environment file
2. perl Menu.pl 
 
Removal
--------
1. Source the Applications environment file
2. perl Menu.pl 
 -> Choose [U] from Main Menu 
 
==============================================================================
More Information 
==============================================================================
 
Please See the following My Oracle Support Document for further information: 
 
E-Business Suite Support Analyzer Bundle Menu Tool [Doc ID 1939637.1]
 
==============================================================================
Description 
==============================================================================
 
Provides: 
-> Bundled zip of the Support Analyzers 
-> Menu interface for running and loading (single and bulk) Analyzers as Concurrent Programs 
-> Uninstallation option  for the Analyzers 
 
 
==============================================================================
Support for Bundle Perl Code  
==============================================================================
 
E-mail Kyle.Harris@Oracle.com, William.Burbage@Oracle.com for assistance
Check 1939637.1 for the Communities Analyzer Bundle Thread 
