SET DEFINE '~'
SET SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT

REM +===========================================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                                     |
REM |                    Redwood Shores, California, USA                                        |
REM |                         All rights reserved.                                              |
REM +===========================================================================================+
REM | Framework 3.0.27                                                                          |
REM |                                                                                           |
REM | FILENAME                                                                                  |
REM |    p2p_analyzer.sql                                                                       |
REM |                                                                                           |
REM | DESCRIPTION                                                                               |
REM |                                                                                           |
REM | HISTORY                                                                                   |
REM | 9/22/15 Created by Jeff McCall, Corina Gaspar, Arnab Mirta, Fabio Buitrago Gabriela Tofan | 
REM +===========================================================================================+

declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,2);
    
 -- Validation to verify analyzer is run on proper e-Business application version
 -- So will fail before package is created
 -- Update condition based on version your analyzer is valid for
 -- PSD #18	
 if apps_version < '12' then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'             ***');
    dbms_output.put_line('*** This Analyzer script must run in version 12 or above    ***');
    dbms_output.put_line('*** Note: the error below is intentional                    ***');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness Version 12 or higher');
 end if;

END;
/


-- PSD #1
CREATE OR REPLACE PACKAGE p2p_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_num    IS TABLE OF NUMBER INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);
TYPE hash_tbl_32k    IS TABLE OF VARCHAR2(32000) INDEX BY VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-- PSD #10
PROCEDURE main (
      p_mode            IN VARCHAR2 DEFAULT null,
      p_org_id          IN NUMBER   DEFAULT null,
      p_req_num         IN VARCHAR2 DEFAULT null,
      p_trx_type        IN VARCHAR2 DEFAULT null,
      p_po_num          IN VARCHAR2 DEFAULT null,
      p_release_num     IN NUMBER   DEFAULT null,
      p_invoice_num     IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 50,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y',
      p_calling_from    IN VARCHAR2 DEFAULT null);
      
PROCEDURE main_single(
      p_org_id          IN NUMBER   DEFAULT null,
      p_req_num         IN VARCHAR2 DEFAULT null,
      p_trx_type        IN VARCHAR2 DEFAULT null,
      p_po_num          IN VARCHAR2 DEFAULT null,
      p_release_num     IN NUMBER   DEFAULT null,
      p_invoice_num     IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 50,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y');     
      

PROCEDURE main_all(
      p_org_id          IN NUMBER   DEFAULT null,
      p_req_num         IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 50,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y');  
      

-- PSD #16	  
PROCEDURE main_cp (
      errbuf            OUT VARCHAR2, 
      retcode           OUT VARCHAR2,
      p_mode            IN VARCHAR2,  
      p_org_id          IN NUMBER,    
      p_req_num         IN VARCHAR2,
      p_dummy1          IN VARCHAR2,
      p_trx_type        IN VARCHAR2,
      p_dummy2          IN VARCHAR2,  
      p_po_num          IN VARCHAR2, 
      p_dummy3          IN VARCHAR2,  
      p_release_num     IN NUMBER,   
      p_dummy4          IN VARCHAR2,  
      p_invoice_num     IN VARCHAR2,  
      p_max_output_rows IN NUMBER,    
      p_debug_mode      IN VARCHAR2);       
      
      
      
      


FUNCTION get_result   RETURN VARCHAR2;
FUNCTION get_fail_msg RETURN VARCHAR2;
FUNCTION get_exc_msg  RETURN VARCHAR2;

-- PURCHASING SPECIFIC FUNCTIONS
FUNCTION get_doc_amts(p_amt_type IN VARCHAR2, p_trx_type IN VARCHAR2) RETURN NUMBER;

-- INVOICE SPECIFIC FUNCTIONS
FUNCTION uom_convert(p_from_unit  IN VARCHAR2,p_to_unit IN VARCHAR2, p_item_id IN NUMBER) RETURN NUMBER;
FUNCTION net_pp_app(p_event_id NUMBER) RETURN NUMBER;
FUNCTION net_pp_acct(p_event_id NUMBER,p_ledger_id NUMBER) RETURN NUMBER;
FUNCTION net_adj_acct(p_event_id NUMBER,p_ledger_id NUMBER) RETURN NUMBER;

-- OTHER P2P FUNCTIONS
FUNCTION get_file_ver(p_fileid NUMBER) RETURN VARCHAR2;

--PO CUSTOM START
g_reset_node           DBMS_XMLDOM.DOMNode;
--PO CUSTOM END

-- PSD #1
END p2p_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY p2p_analyzer_pkg AS
-- PSD #1a
-- $Id: p2p_analyzer.sql, 200.1 2015/15/01 jxmccall Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 50;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #15  
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=xxxxxxx.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;


g_app_method      VARCHAR2(15);
g_curr_empid      NUMBER;
g_app_results     HASH_TBL_2K;
g_doc_amts        HASH_TBL_NUM;
g_use_ame         BOOLEAN := false;
g_parent_sig_count NUMBER;
g_preserve_trailing_blanks BOOLEAN := false;

-- P2P Analyzer specific
g_purchase_orders           VARCHAR_TBL;
g_purchase_orders2          VARCHAR_TBL;
g_purchase_orders3          VARCHAR_TBL;
g_purchase_orders4          VARCHAR_TBL;
g_receipts                  VARCHAR_TBL;
g_invoices                  VARCHAR_TBL;
g_payments                  VARCHAR_TBL;
g_spaces_table              hash_tbl_32k;
----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'P2P_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'P2P_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Output Files are located on Host : '||l_host);
    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=2040474.1:SCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/p2p_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

----------------------------------------------------------------------
-- Diag specific procedure (kluge) has to be here because calling from
-- process_signature results 
----------------------------------------------------------------------

PROCEDURE verify_approver(p_empid IN NUMBER) IS
  l_return_status VARCHAR2(1);
  l_return_code   VARCHAR2(25);
  l_exception_msg VARCHAR2(2000);
  l_auth_fail_msg VARCHAR2(2000);
  l_doc_id        NUMBER;
BEGIN
  IF p_empid <> g_curr_empid OR g_curr_empid is null THEN
    IF g_sql_tokens('##$$TRXTP$$##') = 'RELEASE' THEN
      l_doc_id := to_number(g_sql_tokens('##$$RELID$$##'));
    ELSE
      l_doc_id := to_number(g_sql_tokens('##$$DOCID$$##'));
    END IF;
    g_curr_empid := p_empid;
    po_document_action_pvt.verify_authority(
      p_document_id => l_doc_id,
      p_document_type => g_sql_tokens('##$$TRXTP$$##'),
      p_document_subtype => g_sql_tokens('##$$SUBTP$$##'),
      p_employee_id => p_empid,
      x_return_status => l_return_status,
      x_return_code => l_return_code,
      x_exception_msg => l_exception_msg,
      x_auth_failed_msg  => l_auth_fail_msg);
    g_app_results('STATUS') := l_return_status;
    g_app_results('CODE') := l_return_code;
    g_app_results('EXC_MSG') := l_exception_msg;
    g_app_results('FAIL_MSG') := l_auth_fail_msg;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in verify_approver: '||sqlerrm);
  raise;
END verify_approver;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;

	 -- Rtrim the column value if blanks are not to be preserved	
          IF NOT g_preserve_trailing_blanks THEN			
            l_value := RTRIM(l_value, ' ');			
          END IF;			


         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
          
         -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks	
         -- this ensures trailing blanks added for padding are honored by browsers	
         -- affects only printing, DX summary handled separately	
         IF g_preserve_trailing_blanks THEN	
           l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),	
            -- pad length is the number of spaces existing times the length of &nbsp; => 6	
           (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),	
           '&nbsp;');	
         ELSE	
           l_curr_Val := RTRIM(l_curr_Val, ' ');	
         END IF;	

          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1.'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2.'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4.'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
            
           -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks	
           -- this ensures trailing blanks added for padding are honored by browsers	
           -- affects only printing, DX summary handled separately	
           IF g_preserve_trailing_blanks THEN	
             l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),	
              -- pad length is the number of spaces existing times the length of &nbsp; => 6	
             (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),	
             '&nbsp;');	
           ELSE	
             l_curr_Val := RTRIM(l_curr_Val, ' ');	
           END IF;	

            
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
-- AGL KLUGE FOR VERIFY AUTHORITY REMOVE IN TEMPLATES
        IF p_sig_id IN ('APP_SUP_HIERARCHY_MAIN','APP_POS_HIERARCHY_MAIN') THEN
          verify_approver(to_number(g_sql_tokens('##$$FK1$$##')));
        END IF;
-- END AGL KLUGE

        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

          IF l_result in ('W','E') THEN
              l_fail_flag := true;
            IF l_result = 'E' THEN
              l_error_type := 'E';
            ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
              l_error_type := 'W';
            END IF;
            g_family_result := l_error_type;
          END IF; 

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
-- PSD #4
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel       VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied			
    FROM Ad_Bugs Adb 			
    WHERE Adb.Bug_Number like p_ptch			
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';			

BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #4a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '20';
    l_rel := 'R12';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '8781255';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := ', Update Aug 2009 (12.0.x)';
    l_col_rows(5)(1) := '[1122052.1]';
 -- If want to go based on more e-Business Application version, just add for example:
 -- ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
  ELSE IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
    l_rel := 'R12';
  -- CG added the following line
    l_col_rows.extend(5);
        l_col_rows(1)(1) := '21198991';
        l_col_rows(2)(1) := 'No';
        l_col_rows(3)(1) := NULL;
        l_col_rows(4)(1) := 'Oracle Procurement Rollup patch (March 2015)';
        l_col_rows(5)(1) := '[1468883.1]';
        
        l_col_rows(1)(2) := '17755570';
        l_col_rows(2)(1) := 'No';
        l_col_rows(3)(2) := NULL;
        l_col_rows(4)(2) := '12.1.3 OKC RUP2';
        l_col_rows(5)(2) := '[1612432.1]';        
    
    ELSE -- R12.2
        l_step := '35';
        l_rel := 'R12';
        l_col_rows.extend(5);
    
        l_col_rows(1)(1) := '17947999';
        l_col_rows(2)(1) := 'No';
        l_col_rows(3)(1) := NULL;
        l_col_rows(4)(1) := 'Release 12.2.3 - provides R12.PRC_PF.B.delta.4';
        l_col_rows(5)(1) := '[222339.1]';
        
        l_col_rows(1)(2) := '17919161';
        l_col_rows(2)(2) := 'No';
        l_col_rows(3)(2) := NULL;
        l_col_rows(4)(2) := '12.2.4 -ORACLE E-BUSINESS SUITE 12.2.4 RELEASE UPDATE PACK';
        l_col_rows(5)(2) := '[1617458.1]';
    
    END IF;  
  END IF;        
  -- Check if applied
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i),l_rel);
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;

---------------------------------
-- Get AME Approvers List
---------------------------------

FUNCTION get_ame_approvers RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_approvers  AME_UTIL.APPROVERSTABLE2;
  l_complete   VARCHAR2(10);

BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(13);
  l_hdr(1) := 'Num';
  l_hdr(2) := 'Name';
  l_hdr(3) := 'Appr Ord#';
  l_hdr(4) := 'Member Ord#';
  l_hdr(5) := 'Item Class';
  l_hdr(6) := 'Item ID';
  l_hdr(7) := 'Auth';
  l_hdr(8) := 'Act Type ID';
  l_hdr(9) := 'Grp or Chain ID';
  l_hdr(10) := 'Appr Status';
  l_hdr(11) := 'Appr Cat';
  l_hdr(12) := 'Occur';
  l_hdr(13) := 'API Ins';

  l_step := '20';
  BEGIN
    ame_api2.getAllApprovers7(
      applicationIdIn => 201,
      transactionTypeIn => g_sql_tokens('##$$AMETRXTP$$##'),
      transactionIdIn => g_sql_tokens('##$$AMETRXID$$##'),
      approvalProcessCompleteYNOut => l_complete, 
      approversOut => l_approvers);
  EXCEPTION WHEN OTHERS THEN
-- AGL Temporary workaround for failure of the procedure for POs
    l_sig.problem_descr := sqlerrm;
  END;

  l_step := '30';
  l_col_rows.extend(13);
  FOR i in 1 .. l_approvers.count LOOP
    l_step := '30.1';
    l_col_rows(1)(i) := to_char(i);
    l_col_rows(2)(i) := l_approvers(i).name;
    l_col_rows(3)(i) := l_approvers(i).approver_order_number;
    l_col_rows(4)(i) := l_approvers(i).member_order_number;
    l_col_rows(5)(i) := l_approvers(i).item_class;
    l_col_rows(6)(i) := l_approvers(i).item_id;
    l_col_rows(7)(i) := l_approvers(i).authority;
    l_col_rows(8)(i) := to_char(l_approvers(i).action_type_id);
    l_col_rows(9)(i) := to_char(l_approvers(i).group_or_chain_id);
    l_col_rows(10)(i) := l_approvers(i).approval_status;
    l_col_rows(11)(i) := l_approvers(i).approver_category;
    l_col_rows(12)(i) := to_char(l_approvers(i).occurrence);
    l_col_rows(13)(i) := l_approvers(i).api_insertion;
  END LOOP;

  --Render
  l_step := '40';

  l_sig.title := 'AME Approvers List';
  l_sig.fail_condition := 'NRS';
-- AGL Temporary workaround for failure of the procedure for POs
  l_sig.problem_descr := 'No approvers found. '||l_sig.problem_descr;
  l_sig.solution := 'Review the AME configuration information to determine
    why there are no approvers.';
  l_sig.success_msg := 'Approval Complete: '||l_complete;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'E';
  l_sig.print_sql_output := 'RS';
  l_sig.limit_rows := 'N';

  l_step := '50';
  RETURN process_signature_results(
    'AME_APPROVER_LIST',   -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in get_ame_approvers at step '||l_step);
  raise;
END get_ame_approvers;






PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RSGT1 (RS greater than 1), RS (row selected), NRS (no row selected)
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') --should signature be included in DX Summary
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;
  l_key      VARCHAR2(255);  

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Clear FK values if the sig has children
  IF l_sig.child_sigs.count > 0 THEN
    l_key := g_sql_tokens.first;
    WHILE l_key is not null LOOP
      IF l_key like '##$$FK_$$##' THEN 
        g_sql_tokens.delete(l_key);
      END IF;
      l_key := g_sql_tokens.next(l_key);
    END LOOP;
  END IF;
  
  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;




--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters (
  p_mode            IN VARCHAR2,
  p_org_id          IN NUMBER,
  p_req_num         IN VARCHAR2,
  p_trx_type        IN VARCHAR2,
  p_po_num          IN VARCHAR2,
  -- p_release_num     IN VARCHAR2,
  p_release_num     IN NUMBER,
  p_invoice_num     IN VARCHAR2,
  p_max_output_rows IN NUMBER,
  p_debug_mode      IN VARCHAR2,
  p_calling_from    IN VARCHAR2) IS
  

  --Req
  l_req_num        VARCHAR2(25); 
  l_req_id         NUMBER;
  l_req_subtype    VARCHAR2(25);
  l_req_created_by NUMBER;
  l_req_item_type  WF_ITEMS.ITEM_TYPE%TYPE;
  l_req_item_key   WF_ITEMS.ITEM_KEY%TYPE;
  
    
  -- PO
  l_po_num        VARCHAR2(25); 
  l_po_id         NUMBER;
  p_po_id         NUMBER;
  l_po_rel_id     NUMBER;
  l_po_subtype    VARCHAR2(25);
  l_po_created_by NUMBER;
  l_po_item_type  WF_ITEMS.ITEM_TYPE%TYPE;
  l_po_item_key   WF_ITEMS.ITEM_KEY%TYPE;
  l_po_count         NUMBER;
  
-- Invoice  
  l_invoice_id    NUMBER(15);



-- Other  
  l_doc_id         NUMBER;
  l_rel_id         NUMBER;
  l_org_name       VARCHAR2(240);
  l_trx_type       VARCHAR2(20);
  l_doc_subtype    VARCHAR2(25);
  l_preparer_id    NUMBER;
  l_app_path_id    NUMBER;
  l_ame_trx_type   PO_DOCUMENT_TYPES_ALL.AME_TRANSACTION_TYPE%TYPE;
  l_ame_app_id     NUMBER;
  l_ame_po_appr_id NUMBER;
  l_ame_trx_id     NUMBER;
  l_ame_po         BOOLEAN := false;
  l_created_by     NUMBER;
  l_item_type      WF_ITEMS.ITEM_TYPE%TYPE;
  l_item_key       WF_ITEMS.ITEM_KEY%TYPE;
  l_key            VARCHAR2(255);
  l_wf_createdoc_itemtype VARCHAR2(8);
  
  l_run_date       VARCHAR2(30);
  l_date           DATE;
  l_step           VARCHAR2(5);
  l_counter        NUMBER;
  l_sql            VARCHAR2(4000);


  l_to_date     VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;

  invalid_parameters EXCEPTION;
  
  
  
  
 
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version

    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
  
  
  
  -- Check if customer has AME functionality for PO's
  IF l_apps_version like '12.1.3%' OR l_apps_version like '12.2%' THEN
    BEGIN
      SELECT count(*) INTO l_counter
      FROM dba_tab_columns
      WHERE table_name = 'PO_HEADERS_ALL'
      AND   column_name = 'AME_APPROVAL_ID';
    EXCEPTION WHEN OTHERS THEN
      l_counter := 0;
    END;
    IF l_counter > 0 THEN
      l_ame_po := true;
    END IF;
  END IF;
  
  
  l_step := '25';  
  IF p_mode is null THEN
    print_error('Invalid Analyzer usage.'||
      'Refer to Doc ID 2040474.1 to download latest Procure to Pay Analyzer and for complete usage details.');
    raise invalid_parameters;
  END IF;  
  
  l_step := '30';
    IF p_org_id is not null THEN
    BEGIN
      SELECT u.name
      INTO   l_org_name
      FROM   PO_SYSTEM_PARAMETERS_ALL SP, HR_OPERATING_UNITS U
      WHERE  u.organization_id = sp.org_id
      AND    sp.org_id = p_org_id;
    EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No operating unit organization ID specified. '||
      'The org_id parameter is mandatory.');
      raise invalid_parameters;
    END;    
	-- set org context here
	mo_global.set_policy_context('S',p_org_id);  
    ELSE
    print_log('No operating unit organization ID specified. '||
      'The org_id parameter is mandatory.');
    raise invalid_parameters;
  END IF;
  
  


 l_step := '40';
  IF (p_mode='SINGLE' AND nvl(p_trx_type,'XXX') NOT IN ('PA','PO','RELEASE')) THEN
    print_error('Invalid trx type specified.');
    print_error('Value should be one of PA, PO, or RELEASE');
    raise invalid_parameters;      
  END IF;


  l_step := '45';
  IF (p_mode='SINGLE' AND (p_po_num IS NULL OR p_po_num='')) THEN
    print_error('Invalid purchase order number specified.');
    print_error('Purchase order number must be entered');
    raise invalid_parameters;      
  END IF;

  
  l_step := '50';
  IF (p_mode='SINGLE' AND (p_release_num is not null AND
      (p_trx_type <> 'RELEASE' OR p_po_num is null)) OR
     ((p_release_num is null OR p_po_num is null) AND
      p_trx_type = 'RELEASE')) THEN
    print_error('Invalid combination. For a release the transaction type '||
      'should be RELEASE and the release number and PO number '||
      'must both be provided');
    raise invalid_parameters;
  END IF;


  IF p_release_num is not null THEN
    l_step := '60';
    BEGIN
      SELECT h.po_header_id, h.segment1, r.po_release_id, r.release_type,
             r.wf_item_type, r.wf_item_key, r.created_by
      INTO   l_po_id, l_po_num, l_po_rel_id, l_po_subtype,
             l_po_item_type, l_po_item_key, l_po_created_by
      FROM   po_headers_all h, po_releases_all r
      WHERE  h.segment1 = p_po_num
      AND    h.org_id = p_org_id
      AND    r.org_id = h.org_id
      AND    r.po_header_id = h.po_header_id
      AND    r.release_num = p_release_num;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      print_error('Invalid release, PO and org_id combination');
      print_error('No release document exists for values '||
        to_char(p_release_num)||'/'||p_po_num||'/'||to_char(p_org_id));
      raise invalid_parameters;
    END;
  ELSIF p_po_num is not null THEN
    IF p_trx_type is null OR p_trx_type = 'ANY' THEN
      print_error('You must specify the org_id and transaction type when '||
        'trx_number is specified.');
      raise invalid_parameters;
    ELSIF p_trx_type IN ('PA','PO') THEN
      l_step := '70';
      BEGIN
        IF l_ame_po THEN
          l_sql :=
            'SELECT po_header_id, segment1, type_lookup_code, created_by,
                    wf_item_type, wf_item_key,
                    ame_approval_id, ame_transaction_type
             FROM   po_headers_all
             WHERE  segment1 = :1
             AND    ((:2= ''PA'' AND
                      type_lookup_code IN (''BLANKET'',''CONTRACT'')) OR
                     (:3= ''PO'' AND
                      type_lookup_code IN (''STANDARD'',''PLANNED'')))
             AND    org_id = :4
             AND    rownum = 1';
          EXECUTE IMMEDIATE l_sql
            INTO l_po_id, l_po_num, l_po_subtype, l_po_created_by,
                 l_po_item_type, l_po_item_key,
                 l_ame_po_appr_id, l_ame_trx_type
            USING IN p_po_num, IN p_trx_type, IN p_trx_type, IN p_org_id;
        ELSE
          l_sql :=
            'SELECT po_header_id, segment1, type_lookup_code, created_by,
                    wf_item_type, wf_item_key
             FROM   po_headers_all
             WHERE  segment1 = :1
             AND    ((:2= ''PA'' AND
                      type_lookup_code IN (''BLANKET'',''CONTRACT'')) OR
                     (:3= ''PO'' AND
                      type_lookup_code IN (''STANDARD'',''PLANNED'')))
             AND    org_id = :4
             AND    rownum = 1';
          EXECUTE IMMEDIATE l_sql
            INTO l_po_id, l_po_num, l_po_subtype, l_po_created_by,
                 l_po_item_key, l_po_item_key
            USING IN p_po_num, IN p_trx_type, IN p_trx_type, IN p_org_id;
        END IF;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        print_error('Invalid transaction type, number, and org_id combination');
        print_error('No document exists for values '||p_trx_type||
          '/'||p_po_num||'/'||to_char(p_org_id));
        raise invalid_parameters;
      END;
  END IF;     
      
        
  END IF;
  
   
   
    IF p_req_num is not null THEN
      l_step := '80';
      BEGIN
        SELECT requisition_header_id, segment1, type_lookup_code,
               created_by, wf_item_type, wf_item_key
        INTO   l_req_id, l_req_num, l_req_subtype, l_req_created_by,
               l_req_item_type, l_req_item_key
        FROM   po_requisition_headers_all
        WHERE  segment1 = p_req_num
        AND    org_id = p_org_id;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        print_error('Invalid transaction type, number, and org_id combination');
        print_error('No document exists for values '||p_trx_type||
          '/'||p_req_num||'/'||to_char(p_org_id));
        raise invalid_parameters;
      END;

-- Code to Store wf_createdoc_itemtype      
    l_step := '82';
    BEGIN
        SELECT wf_createdoc_itemtype
        INTO   l_wf_createdoc_itemtype
        FROM   po_document_types_all
        WHERE  document_subtype = l_req_subtype
        AND    org_id = p_org_id;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        print_log('No Workflow Item Type exists for values '||p_po_num||'/'||to_char(p_org_id));
      END;   
    END IF;
   
   
  
-- Code to get invoice id if the user enters a PO #. We must therefore derive the po_header_id  

 IF p_invoice_num is not null THEN
    l_step := '85';
    BEGIN
      SELECT ai.invoice_id
      INTO l_invoice_id
      FROM ap_invoices_all ai 
      WHERE ai.org_id = p_org_id 
      AND invoice_num = p_invoice_num
      AND party_site_id in (
        SELECT party_site_id 
        FROM hz_party_sites 
        WHERE party_site_id in (
            SELECT party_site_id 
            FROM ap_supplier_sites_all 
            WHERE vendor_site_id in(
                SELECT vendor_site_id 
                FROM po_headers_all 
                WHERE po_header_id = l_po_id)))
      AND vendor_id = (
        SELECT vendor_id 
        FROM po_headers_all 
        WHERE po_header_id = l_po_id 
        AND org_id = p_org_id)
      AND exists 
        (SELECT 1 
        FROM ap_invoice_lines_all ail 
        WHERE ail.invoice_id = ai.invoice_id 
        AND ail.po_header_id = l_po_id);
 EXCEPTION WHEN NO_DATA_FOUND THEN
 print_log('No Invoice exists for '||p_po_num||'/'||to_char(p_org_id));
 raise invalid_parameters;
    END;
 END IF;  
      

  
  IF p_trx_type IN ('PA','PO') AND
  -- CG changed the following line
  -- l_doc_subtype IN ('CONTRACT','BLANKET') THEN
     l_po_subtype IN ('CONTRACT','BLANKET') THEN
    l_trx_type := 'PA';
  ELSE
    l_trx_type := p_trx_type;
  END IF;

  l_step := '90';
  IF l_doc_id is not null THEN
  -- Get the preparer employee ID and approval path from actions
    BEGIN
      SELECT employee_id, approval_path_id
      INTO   l_preparer_id, l_app_path_id
      FROM po_action_history
      WHERE object_id = l_doc_id
      AND   object_type_code = l_trx_type
      AND   action_code = 'SUBMIT'
      AND   sequence_num = (
              SELECT max(sequence_num)
              FROM po_action_history
              WHERE object_id = l_doc_id
              AND   object_type_code = l_trx_type
              AND   action_code = 'SUBMIT');
    EXCEPTION WHEN NO_DATA_FOUND THEN
      l_preparer_id := null;
    END;

    -- If not found use the created by on the document header
    l_step := '100';
    IF l_preparer_id is null THEN
      BEGIN
        SELECT employee_id INTO l_preparer_id
        FROM fnd_user
        WHERE user_id = l_created_by;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        l_preparer_id := null;
      END;
    END IF;

    -- Get the approval method
    l_step := '110';
    BEGIN
      SELECT decode(sp.use_positions_flag,
               'Y', 'POSITION',
               'N', 'SUPERVISOR',
               null)
      INTO g_app_method
      FROM financials_system_params_all sp
      WHERE sp.org_id = p_org_id;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      g_app_method := null;
    END;

    -- Get default approval path if not already populated
    l_step := '120';
    IF g_app_method = 'POSITION' AND l_app_path_id is null THEN
      BEGIN
        SELECT default_approval_path_id
        INTO   l_app_path_id
        FROM po_document_types_all
        WHERE org_id = p_org_id
        AND   document_type_code = l_trx_type
     -- CG Changed the following line   
     --   AND   document_subtype = l_doc_subtype;
        AND   document_subtype = l_po_subtype;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        l_app_path_id := null;
      END;
    END IF;

    -- Check if AME is in use for PO and REQUISITION documents
    -- Get the AME application ID for signature queries
    l_step := '130';
    g_use_ame := false;
    IF p_req_num is not null THEN
      BEGIN
        SELECT dt.ame_transaction_type, ca.application_id
        INTO l_ame_trx_type, l_ame_app_id
        FROM po_document_types_all dt,
             ame_calling_apps ca
        WHERE dt.org_id = p_org_id
        AND   dt.document_type_code = l_trx_type
        AND   dt.document_subtype = l_doc_subtype
        AND   ca.transaction_type_id = dt.ame_transaction_type
        AND   ca.fnd_application_id = 201
        AND   sysdate BETWEEN ca.start_date AND
                nvl(ca.end_date,sysdate);
      EXCEPTION WHEN NO_DATA_FOUND THEN
        l_ame_trx_type := null;
      END;
      IF (l_ame_trx_type is not null) THEN
        g_use_ame := true;
        l_ame_trx_id := l_doc_id;
      END IF;
    ELSIF (l_trx_type IN ('PA','PO') AND l_ame_po_appr_id is not null) THEN 
      g_use_ame := true;
      l_ame_trx_id := l_ame_po_appr_id;
      BEGIN
        SELECT ca.application_id INTO l_ame_app_id
        FROM ame_calling_apps ca
        WHERE ca.transaction_type_id = l_ame_trx_type
        AND   ca.fnd_application_id = 201
        AND   sysdate BETWEEN ca.start_date AND
                nvl(ca.end_date,sysdate);
      EXCEPTION WHEN NO_DATA_FOUND THEN
        l_ame_app_id := null; 
      END;
    END IF;
  END IF;



      
      
  
  
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.1 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2014/05/01 22:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #7
  g_rep_info('File Name') := 'p2p_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
-- PSD #7b
-- P2P Specific
  g_rep_info('Calling From') := p_calling_from;  
-- P2P Specific
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=2040474.1" target="_blank">(Note 2040474.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  

  -- Validation to verify analyzer is run on proper e-Business application version
  -- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  -- Update condition based on version your analyzer is valid for
  -- PSD #18
  IF substr(l_apps_version,1,2) < '12' THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script must run in version 12 or above.');
	raise invalid_parameters;
  END IF;
  
  -- PSD #8
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Mode') := p_mode;  
  -- g_parameters('2. Operating Unit') := p_org_id;
  g_parameters('2. Operating Unit') := l_org_name || ' ('|| p_org_id ||')';
  g_parameters('3. Requisition Number') := p_req_num;
  -- if multiple PO's exist for the Requisiton entered then display multiple otherwise display po #
   If l_po_count > 1 THEN
     g_parameters('4. Purchase Order Number') := 'Multiple ('|| l_po_count ||')' ;
   END IF; 
   IF (l_po_subtype IN ('CONTRACT','BLANKET') AND p_mode = 'SINGLE') THEN
   --IF (p_release_num IS NOT NULL AND p_mode = 'SINGLE') THEN
     g_parameters('4. Blanket Purchase Order Number') := p_po_num;
     g_parameters('5. Release Number') := p_release_num;
     g_parameters('6. Invoice Number') := p_invoice_num;
     g_parameters('7. Max Rows') := g_max_output_rows;
     g_parameters('8. Debug Mode') := p_debug_mode;
   ELSIF (l_po_subtype NOT IN ('CONTRACT','BLANKET') AND p_mode = 'SINGLE') THEN
   --ELSIF (p_release_num IS NULL AND p_mode = 'SINGLE') THEN 
    g_parameters('4. Standard Purchase Order Number') := p_po_num;
    g_parameters('5. Invoice Number') := p_invoice_num;
    g_parameters('6. Max Rows') := g_max_output_rows;
    g_parameters('7. Debug Mode') := p_debug_mode;
   ELSIF p_mode = 'ALL' THEN
    g_parameters('4. Max Rows') := g_max_output_rows;
    g_parameters('5. Debug Mode') := p_debug_mode;
   END IF; 


-- g_parameters('3. RFQ Number') := p_rfq_num;
  

  
  -- PSD #8a
  -- Create global hash of SQL token values
  g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');

  
 --Req  
  g_sql_tokens('##$$REQNUM$$##') := l_req_num;
  g_sql_tokens('##$$REQSUBTP$$##') := l_req_subtype; 
  g_sql_tokens('##$$REQID$$##') := nvl(to_char(l_req_id),'NULL'); 
  g_sql_tokens('##$$REQITMTYPE$$##') := l_req_item_type;
  g_sql_tokens('##$$REQITMKEY$$##') := l_req_item_key;
  
  
 -- PO
  g_sql_tokens('##$$PONUM$$##') := l_po_num;
  g_sql_tokens('##$$POSUBTP$$##') := l_po_subtype;
  g_sql_tokens('##$$POID$$##') := nvl(to_char(l_po_id),'NULL'); 
  g_sql_tokens('##$$POITMTYPE$$##') := l_po_item_type;
  g_sql_tokens('##$$POITMKEY$$##') := l_po_item_key;
  g_sql_tokens('##$$PORELID$$##') := nvl(to_char(l_po_rel_id),'NULL');
  g_sql_tokens('##$$PORELNUM$$##') := p_release_num;
  
 -- Receipts
  g_sql_tokens('##$$RVIEW$$##'):= 'SELECT transaction_id '||
               'FROM rcv_transactions '||
               'WHERE po_header_id = '||l_po_id||' '|| 
               'AND transaction_type in (''RECEIVE'',''MATCH'')';
 
 -- Invoice 
  g_sql_tokens('##$$INVOICEUM$$##') := p_invoice_num;
  g_sql_tokens('##$$IVIEW$$##'):= 'SELECT /*+ qb_name(iview) */ DISTINCT d.invoice_id '||
               'FROM ap_invoice_distributions_all d '||
               'WHERE d.invoice_id in ('||l_invoice_id||')';
               
               
-- Cursor 
  g_sql_tokens('##$$INVOICEID$$##') := l_invoice_id;


 -- Payments ( PosBVPaymentSummaryVO )
IF g_sql_tokens('##$$PORELNUM$$##') IS NULL THEN 
   g_sql_tokens('##$$CVIEW$$##'):= 'SELECT '||
                  'DISTINCT aip.check_id '|| 
               'FROM '||
                  'ap_invoice_lines_all ail, '||
                  'ap_invoice_payments_all aip '|| 
               'WHERE '||
                  'ail.invoice_id = aip.invoice_id '|| 
                  'AND ail.po_header_id = '||l_po_id||' '||
                  'and ail.po_release_id is null';                                           
ELSE
   g_sql_tokens('##$$CVIEW$$##'):= 'SELECT '||
                  'DISTINCT aip.check_id '|| 
               'FROM '||
                  'ap_invoice_lines_all ail, '||
                  'ap_invoice_payments_all aip '|| 
               'WHERE '||
                  'ail.invoice_id = aip.invoice_id '|| 
                  'AND ail.po_header_id = '||l_po_id||' '||
                  'AND ail.po_release_id = '||l_po_rel_id||'';
END IF;  
  
  
 -- Other 
   g_sql_tokens('##$$ORGID$$##') := to_char(p_org_id);
   g_sql_tokens('##$$DOCID$$##') := nvl(to_char(l_doc_id),'NULL');
   g_sql_tokens('##$$RELID$$##') := nvl(to_char(l_rel_id),'NULL');
   g_sql_tokens('##$$PREPID$$##') := nvl(to_char(l_preparer_id),'NULL');
   g_sql_tokens('##$$APPATH$$##') := nvl(to_char(l_app_path_id),'NULL');
   g_sql_tokens('##$$AMETRXTP$$##') := l_ame_trx_type;
   g_sql_tokens('##$$AMEAPPID$$##') := nvl(to_char(l_ame_app_id),'NULL');
   g_sql_tokens('##$$AMETRXID$$##') := nvl(to_char(l_ame_trx_id),'NULL');
   g_sql_tokens('##$$CREATEDOC$$##') := l_wf_createdoc_itemtype;
  
  
  IF (l_trx_type = 'REQUISITION') THEN
      g_sql_tokens('##$$DOCTYPESHORT$$##') := 'REQ';
  ELSIF (l_trx_type = 'PA') THEN
      g_sql_tokens('##$$DOCTYPESHORT$$##') := 'PO';
  ELSE
      g_sql_tokens('##$$DOCTYPESHORT$$##') := l_trx_type;
  END IF; 
  -- PSD #7a-end
  
  
   l_key := g_sql_tokens.first;
  -- Print token values to the log
 
   print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;

---------------------------------------------
-- Custom Cursors for this ANALYZER       --
---------------------------------------------


PROCEDURE populate_p2p_globals IS 

---------------------------------------------------------------
-- Custom cursor to return the all related purchase orders   -- 
---------------------------------------------------------------
CURSOR purchase_order_ids_c (l_req_id IN VARCHAR2) IS
  SELECT  DISTINCT p.po_header_id,p.segment1,p.type_lookup_code,d.po_release_id
  FROM    po_headers_all p, 
          po_distributions_all d,
          po_req_distributions_all rd, 
          po_requisition_lines_all rl,
          po_requisition_headers_all r 
  WHERE   p.po_header_id = d.po_header_id 
  AND     r.requisition_header_id =  g_sql_tokens('##$$REQID$$##') 
  AND d.req_distribution_id = rd.distribution_id 
  AND rd.requisition_line_id = rl.requisition_line_id 
  AND rl.requisition_header_id = r.requisition_header_id 
  AND p.org_id = g_sql_tokens('##$$ORGID$$##')
  ORDER BY p.segment1;


  
--------------------------------------------------------
-- Custom cursor to return the all related Receipts   -- 
-------------------------------------------------------- 
/*
CURSOR receipts_ids_c (l_po_id IN VARCHAR2) IS
  SELECT transaction_id
               FROM rcv_transactions
               WHERE po_header_id = g_sql_tokens('##$$POID$$##')
               AND transaction_type in ('RECEIVE','MATCH');
  */             
               
               
          

--------------------------------------------------------
-- Custom cursor to return the all related invoices   -- 
--------------------------------------------------------
/* CG Commenting these cursors as they are moved into the main procedure
CURSOR invoice_ids_c (l_po_id IN VARCHAR2) IS
  SELECT ai.invoice_id
      FROM ap_invoices_all ai 
      WHERE ai.org_id = g_sql_tokens('##$$ORGID$$##')
      AND party_site_id in (
        SELECT party_site_id 
        FROM hz_party_sites 
        WHERE party_site_id in (
            SELECT party_site_id 
            FROM ap_supplier_sites_all 
            WHERE vendor_site_id in(
                SELECT vendor_site_id 
                FROM po_headers_all 
                WHERE po_header_id = g_sql_tokens('##$$POID$$##'))))
      AND vendor_id = (
        SELECT vendor_id 
        FROM po_headers_all 
        WHERE po_header_id = g_sql_tokens('##$$POID$$##') 
        AND org_id = g_sql_tokens('##$$ORGID$$##'))
      AND exists 
        (SELECT * 
        FROM ap_invoice_lines_all ail 
        WHERE ail.invoice_id = ai.invoice_id 
        AND ail.po_header_id = g_sql_tokens('##$$POID$$##'));
CG */ 
  
BEGIN
-- PSD #9

-- Open Cursor to retrieve all purchase order id's
OPEN purchase_order_ids_c ('g_sql_tokens(##$$REQID$$##)');   
FETCH purchase_order_ids_c BULK COLLECT INTO g_purchase_orders,g_purchase_orders2,g_purchase_orders3,g_purchase_orders4;
CLOSE purchase_order_ids_c;

/* CG Commenting 
-- Open Cursor to retrieve all receipt id's
OPEN receipts_ids_c ('g_sql_tokens(##$$POID$$##)');   
FETCH receipts_ids_c BULK COLLECT INTO g_receipts;
CLOSE receipts_ids_c;

-- Open Cursor to retrieve all invoice id's
OPEN invoice_ids_c ('g_sql_tokens(##$$POID$$##)');   
FETCH invoice_ids_c BULK COLLECT INTO g_invoices;
CLOSE invoice_ids_c;
CG */


END populate_p2p_globals;



---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
  l_dynamic_SQL VARCHAR2(32000);
  l_counter NUMBER; 


BEGIN

/*#################################################
  #  P r o a c t i v e  S i g s                   #
  #################################################*/
  
  -------------------------------------------------------------------
  -- invalid objects
  -------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2

             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''PO%'' OR
         a.object_name like ''ECX%'' OR
         a.object_name like ''XLA%'' OR
         a.object_name like ''IBY%'' OR
         a.object_name like ''AP_%'' )
    AND a.status = ''INVALID''',
   'Procure to Pay Related Invalid Objects',
   'RS',
   'There exist invalid Purchasing / Payments/ Payables related objects',
   '<ul>
      <li>Recompile the individual objects or recompile the
          entire APPS schema with adadmin</li>
      <li>Review any error messages provided and see [1527251.1]
          for details on compiling these invalid objects.</li>
   </ul>',
   NULL,
   'ALWAYS',
   'E',
   p_include_in_dx_summary => 'Y');
   

  --------------------------------------------------------------------
  --  FND_DEVELOPER_MODE_PROFILE null verification
  --------------------------------------------------------------------
  l_info.delete;
  add_signature(
   'FND_DEVELOPER_MODE_PROFILE',
   'SELECT user_profile_option_name "Profile Option",
           a.profile_option_value "Profile Value",
           DECODE(a.level_id, 10001, ''Site'',
                              10002, ''Application'',
                              10003, ''Responsibility'',
                              10004, ''User'') "Level",
           DECODE(a.level_id, 10001, ''Site'', 10002, b.application_short_name, 10003, c.responsibility_name, 10004, d.user_name) "Level Value",
           c.responsibility_id
    FROM fnd_profile_option_values a,
         fnd_application b,
         fnd_responsibility_tl c,
         fnd_user d,
         fnd_profile_options e,
         fnd_profile_options_tl t
    WHERE a.profile_option_id  = e.profile_option_id
      AND a.level_value          = b.application_id(+)
      AND a.level_value          = c.responsibility_id(+)
      AND a.level_value          = d.user_id(+)
      AND t.profile_option_name  = e.profile_option_name
      AND t.LANGUAGE             = ''US''
      AND nvl(c.LANGUAGE,''US'') = ''US''
      AND e.profile_option_name IN (''FND_DEVELOPER_MODE'')
      AND a.profile_option_value = ''''
   ORDER BY e.profile_option_name,
            a.level_id DESC',
   'Profile FND: Developer Mode Is NULL',
   'RS',
   'This shows if the profile FND: Developer Mode is NULL.',
	'<ul>
		<li>Review - [393180.1] Purchasing Forms Opening With Error APP-FND-1388: Routine &ROUTINE Cannot Read Value For Profile Option Fnd_developer_mode.</li>
	</ul>',
   '<ul>
      <li>Profile FND: Developer Mode is set to a value other than NULL</li>
    </ul>',
	'ALWAYS',
	'E',
        'Y',
        'Y',
        p_include_in_dx_summary => 'Y');
        
  ------------------------------------------
  -- Max Tablespace Free
  ------------------------------------------
  add_signature(
   'TABLESPACE_CHECK',
   'SELECT a.TABLESPACE_NAME "TableSpace Name",
           round(a.BYTES / 1024 / 1024) "MB Allocated",
           round((a.BYTES-nvl(b.BYTES, 0)) / 1024 / 1024) "MB Used",
           nvl(round(b.BYTES / 1024 / 1024), 0) "MB Free",
           round(((a.BYTES-nvl(b.BYTES, 0))/a.BYTES)*100,2) "Pct Used",
           round((1-((a.BYTES-nvl(b.BYTES,0))/a.BYTES))*100,2) "Pct Free"
    FROM   (select   TABLESPACE_NAME,
                     sum(BYTES) BYTES
            from     sys.dba_data_files
            group by TABLESPACE_NAME) a,
           (select   TABLESPACE_NAME,
                     sum(BYTES) BYTES
            from     sys.dba_free_space
            group by TABLESPACE_NAME) b
  WHERE  a.TABLESPACE_NAME = b.TABLESPACE_NAME (+)
  AND (round((1-((a.BYTES-nvl(b.BYTES,0))/a.BYTES))*100,2) < 3)
  order  by ((a.BYTES-b.BYTES)/a.BYTES) desc',
   'Potential Tablespace Issues',
   'RS',
    'The objects listed above have 3% or less tablespace free.',
   '<ul> <li>Review items indicated and addadditional data 
   files to the tablespace as required</li></ul>',
   'No Potential Tablespace Issues Detected',
   'ALWAYS',
   'W',
   'Y',
   'Y');         
   
     

   
   
/*#################################################
  #  R e q u i s i t i o n  S i g s               #
  #################################################*/
   
  
  -------------------------------------------------------------------
  -- Requisition Header Details
  -------------------------------------------------------------------- 
  l_info.delete;
  add_signature(
   'REQUISITION_HEADER_DETAILS',
   'SELECT segment1 "Doc Number",
           description "Description",
           authorization_status "Status",
           type_lookup_code "Type",
           approved_date "Approved Date",
           interface_source_code "Interface Source Code",
           org_id "Org Id",
          p2p_analyzer_pkg.get_doc_amts(''NET_TOTAL'',''R'')
             document_net,
           p2p_analyzer_pkg.get_doc_amts(''TAX'',''R'')
             document_tax,
           p2p_analyzer_pkg.get_doc_amts(''TOTAL'',''R'')
             document_total,
           p2p_analyzer_pkg.get_doc_amts(''PRECISION'',''R'')
             currency_precision,
           p2p_analyzer_pkg.get_doc_amts(''EXT_PRECISION'',''R'')
             extended_precision,
           p2p_analyzer_pkg.get_doc_amts(''MIN_ACCT_UNIT'',''R'')
             min_accountable_unit,
           preparer_id,
           summary_flag,
           enabled_flag,
           closed_code,
           wf_item_type,
           wf_item_key,
           change_pending_flag,
           approved_date,
           first_approver_id,
           first_position_id,
           last_update_date,
           last_updated_by
    FROM po_requisition_headers_all
    WHERE segment1 = ''##$$REQNUM$$##''
    AND   org_id = ##$$ORGID$$##
    AND   authorization_status = ''APPROVED''',
   'Requisition Details',
   'NRS',
   'Requisition is not Approved',
   '<ul><li>Approve Requisition.</li></ul>',
   '<ul><li>Requisition is Approved.</li></ul>',
   'ALWAYS',
   'E',
   'RS',
   'N',
   l_info,
   VARCHAR_TBL('REQUISITION_LINE_DETAILS'),
     p_include_in_dx_summary => 'Y');
  
  
  -------------------------------------------------------------------
  -- Requisition Line Details
  --------------------------------------------------------------------

 l_info.delete;
  add_signature(
   'REQUISITION_LINE_DETAILS',
   'SELECT rl.line_num,
           rl.requisition_line_id,
           rl.requisition_line_id "##$$FK3$$##",
           rl.item_id,
           rl.item_description,
           rl.category_id,
           mca.concatenated_segments item_category,
           lt.line_type,
           lt.outside_operation_flag,
           rl.unit_price,
           rl.quantity,
           rl.unit_meas_lookup_code uom,
           rl.amount,
           rl.currency_code,
           rl.currency_amount,
           rl.need_by_date,
           rl.encumbered_flag,
           p1.full_name requestor,
           rl.to_person_id,
           rl.rate,
           rl.rate_type,
           rl.rate_date,
           rl.currency_unit_price,
           p2.full_name suggested_buyer,
           rl.suggested_buyer_id,
           rl.closed_code,
           rl.closed_date,
           rl.cancel_flag,
           rl.line_location_id,
           rl.parent_req_line_id,
           rl.purchasing_agent_id,
           rl.document_type_code,
           rl.tax_name,
           rl.tax_user_override_flag,
           rl.tax_code_id
    FROM po_requisition_lines_all rl,
         per_all_people_f p1,
         per_all_people_f p2,
         po_line_types lt,
         mtl_categories_kfv mca
    WHERE requisition_header_id = ##$$REQID$$##
    AND   p1.person_id = rl.to_person_id
    AND   trunc(sysdate) BETWEEN
            p1.effective_start_date AND p1.effective_end_date
    AND   p2.person_id (+) = rl.suggested_buyer_id
    AND   (p2.person_id is null OR
           trunc(sysdate) BETWEEN
             p2.effective_start_date AND p2.effective_end_date)
    AND   lt.line_type_id = rl.line_type_id
    AND   mca.category_id  = rl.category_id
    ORDER BY rl.line_num',
   'Requisition Line Details',
   'NRS',
   'No document lines found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('REQUISITION_DIST_DETAILS'),
     p_include_in_dx_summary => 'Y');
   
  
  -------------------------------------------------------------------
  -- Requisition Distribution Details
  --------------------------------------------------------------------

 l_info.delete;
  add_signature(
   'REQUISITION_DIST_DETAILS',
   'SELECT d.requisition_line_id,
           d.distribution_num,
           d.req_line_quantity,
           d.code_combination_id,
           substr(rtrim(g.segment1||''-''||g.segment2||''-''||
             g.segment3||''-''||g.segment4||''-''||
             g.segment5||''-''||g.segment6||''-''||
             g.segment7||''-''||g.segment8||''-''||
             g.segment9||''-''||g.segment10||''-''||
             g.segment11||''-''||g.segment12||''-''||
             g.segment13||''-''||g.segment14||''-''||
             g.segment15||''-''||g.segment16||''-''||
             g.segment17||''-''||g.segment18||''-''||
             g.segment19||''-''||g.segment20||''-''||
             g.segment21||''-''||g.segment22||''-''||
             g.segment23||''-''||g.segment24||''-''||
             g.segment25||''-''||g.segment26||''-''||
             g.segment27||''-''||g.segment28||''-''||
             g.segment29||''-''||g.segment30,''-'') ,1,100) charge_acct,
           d.encumbered_flag,
           d.gl_encumbered_date,
           d.gl_encumbered_period_name,
           d.gl_cancelled_date,
           d.failed_funds_lookup_code,
           d.encumbered_amount,
           d.budget_account_id,
           d.accrual_account_id,
           d.variance_account_id,
           d.prevent_encumbrance_flag,
           d.ussgl_transaction_code,
           d.government_context,
           d.project_id,
           d.task_id,
           d.expenditure_type,
           d.project_accounting_context,
           d.expenditure_organization_id,
           d.gl_closed_date,
           d.source_req_distribution_id,
           d.allocation_type,
           d.allocation_value,
           d.project_related_flag,
           d.expenditure_item_date
    FROM po_req_distributions_all d,
         gl_code_combinations g
    WHERE d.requisition_line_id = ##$$FK3$$##
    AND   d.code_combination_id = g.code_combination_id(+)
    ORDER BY d.requisition_line_id, d.distribution_num',
   'Requisition Distribution Details',
   'NRS',
   'No distributions found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');


 
  -------------------------------------------------------------------
  -- Requisition Approval History
  -------------------------------------------------------------------

 l_info.delete;
  add_signature(
   'REQUISITION_APPROVAL_HISTORY',
   'SELECT distinct(ppf.full_name), pah.*
    FROM po_action_history pah, 
         per_all_people_f ppf
    WHERE pah.employee_id = ppf.person_id
    AND object_id in (SELECT requisition_header_id 
                      FROM po_requisition_headers_all 
                      WHERE segment1 = ''##$$REQNUM$$##''
                      AND   org_id = ##$$ORGID$$##)
    AND object_type_code = ''REQUISITION''
    order by pah.sequence_num asc',
   'Requisition Approval History',
   'NRS',
   'No Approval History found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');


  -------------------------------------------------------------------
  -- Outstanding Supply/Demand for Requisition Lines
  -------------------------------------------------------------------     
    
  l_info.delete;
   add_signature(
   'PODATACORRUPTION_05',
   'SELECT    prl.requisition_header_id,
           prl.requisition_line_id,
           To_Number(NULL) line_location_id, 
           nvl(prl.quantity_delivered, 0),
           prl.quantity
    FROM      mtl_supply ms,
           po_requisition_lines_all prl
    WHERE     prl.requisition_header_id = ##$$REQID$$##
    and       ms.supply_type_code = ''REQ''  
    AND       prl.source_type_code=''INVENTORY''  
    AND       prl.requisition_line_id = ms.supply_source_id
    AND       nvl(prl.quantity_delivered,0) >= prl.quantity',
   'Outstanding Supply/demand for Requisition Lines',
   'RS',
   'Found pending supply for fully received internal requisition lines',
   'Solution is described in Note: [1220964.1]',
   'No pending supply for fully received internal requisition lines. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');
   

  -------------------------------------------------------------------
  -- Missing Requisitions in Autocreate
  -------------------------------------------------------------------   
   
   l_info.delete;
   add_signature(
   'PODATACORRUPTION_06',
   ' SELECT prha.requisition_header_id req_header_id
     , prha.segment1 req_number
     , prla.requisition_line_id req_line_id
     , prla.line_num req_line_num
     , prla.line_location_id req_line_loc
     , prla.reqs_in_pool_flag req_pool_flag
    FROM po_requisition_headers_all prha
     , po_requisition_lines_all prla
    WHERE prha.requisition_header_id = ##$$POID$$##
    AND prha.requisition_header_id = prla.requisition_header_id 
    AND prha.authorization_status = ''APPROVED'' 
    AND prla.reqs_in_pool_flag IS NULL 
    AND prla.line_location_id IS NOT NULL
    AND nvl(prla.closed_code, ''OPEN'') <> ''FINALLY CLOSED''
    AND nvl(prla.cancel_flag, ''N'') <> ''Y''
    AND prla.line_location_id NOT IN (SELECT line_location_id FROM po_line_locations_all)',
   'Missing Requisitions in Autocreate',
   'RS',
   'Found Approved requisitions not available in Autocreate form after associated purchase order is deleted',
   'Solution is described in Note: [1432915.1]',
   'No approved requisitions not available in autocreate found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');    
   
  -------------------------------------------------------------------
  -- Mulitple requisition lines association to PO lines
  ------------------------------------------------------------------- 

   l_info.delete;
   add_signature(
   'PODATACORRUPTION_14',
   'SELECT  podc.req_distribution_id,
        pd2.po_header_id,
        (select segment1 from po_headers_all where po_header_id = pd2.po_header_id) PONumber,
        pd2.po_distribution_id,
        pd2.line_location_id,
        pd2.req_distribution_id,
        nvl(pd2.encumbered_flag,''N''),
        (select Pll2.Closed_Code from po_line_locations_all pll2 where pd2.line_location_id = pll2.line_location_id) Closed_code
    from po_distributions_all pd2,
     (select pd.req_distribution_id
      from po_distributions_all pd,
      po_line_locations_all pll
      where pd.req_distribution_id in (select prd.distribution_id 
                                      from PO_REQ_DISTRIBUTIONS_ALL PRD,
                                           PO_REQUISITION_LINES_ALL PRL
                                      where prl.requisition_line_id = prd.requisition_line_id
                                      and   prl.requisition_header_id = ##$$REQID$$##)
      and   pd.line_location_id = pll.line_location_id
      and   pll.shipment_type <> ''SCHEDULED''
      group by pd.req_distribution_id
      having count(*) > 1) PODC
    where pd2.req_distribution_id = podc.req_distribution_id',
   'Mulitple Requisition Lines Association to PO Lines',
   'RS',
   'Found requisition distribution line(s) associated to multiple PO distribution lines',
   'Solution is described in Note: [1068077.1]',
   'No multiple association found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');  
   
   
  -------------------------------------------------------------------
  -- Mulitple requisition lines association to PO lines
  ------------------------------------------------------------------- 

   l_info.delete;
   add_signature(
   'PODATACORRUPTION_16',
   'select   prl.requisition_line_id,
           prl.source_type_code,
           prl.need_by_date,
           ms.receipt_date
    FROM      mtl_supply ms,
           po_requisition_lines_all prl, 
           po_requisition_headers_all prh
    where     prl.requisition_header_id = ##$$REQID$$##
    AND       ms.supply_type_code = ''REQ'' 
    and       ms.req_line_id = prl.requisition_line_id 
    and       prl.need_by_date is not null 
    and       ms.receipt_date is null',
   'Mulitple Requisition Lines Association to PO Lines.',
   'RS',
   'Internal requisition is not shown in supply demand screen even though there is supply of type ''REQ'' in mtl_supply',
   'Log a service request to get a datafix for this issue',
   'No missing supply for internal requisition found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');  
   
  -------------------------------------------------------------------
  -- Missing supply for requisition lines
  -------------------------------------------------------------------   

   l_info.delete;
   add_signature(
   'PODATACORRUPTION_18',
   'select distinct
       prl.requisition_header_id,
       prh.segment1,
       prl.requisition_line_id
   FROM   po_Requisition_Headers_all prh,
       po_requisition_lines_all prl
   where prl.requisition_header_id = ##$$REQID$$##
   AND prh.Requisition_Header_Id = prl.Requisition_Header_Id
   AND Nvl(prh.Closed_Code,''OPEN'') = ''OPEN''
   AND prh.Authorization_Status = ''APPROVED''
   AND Nvl(prh.Cancel_Flag,''N'') = ''N''
   AND Nvl(prl.Cancel_Flag,''N'') = ''N''
   AND Nvl(prl.Closed_Code,''OPEN'') = ''OPEN''
   AND prl.Quantity > Nvl(prl.Quantity_Received,0)
   AND prl.Quantity > Nvl(prl.Quantity_Delivered,0)
   AND prl.Line_Location_Id IS NULL
   AND NOT EXISTS (SELECT ''exists''
                FROM   mtl_Supply mtl
                WHERE  (mtl.Supply_Source_Id = prl.Requisition_Line_Id
                AND mtl.Supply_Type_Code = ''REQ'')
                                    OR (mtl.req_Line_Id = prl.Requisition_Line_Id
                                        and mtl.supply_type_code = ''SHIPMENT''))',
   'Missing Supply for Requisition Lines',
   'RS',
   'Found missing supply for requisition lines',
   'Log a service request to get a datafix for this issue',
   'Found no missing supply. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y'); 
   
   
  -------------------------------------------------------------------
  -- Unfrozen DFF that could cause PO Creation issues
  -------------------------------------------------------------------   

   l_info.delete;
   add_signature(
   'DFF_UNFROZEN',
   'SELECT * 
    FROM FND_DESCRIPTIVE_FLEXS 
    WHERE descriptive_flexfield_name like ''PO\_%''  ESCAPE ''\''
    AND freeze_flex_definition_flag = ''N''',
   'Found Requisition and Purchasing DFF That Are Not Frozen',
   'RS',
   'Found Requisition and Purchasing DFF that are not frozen.',
   'Freeze the returned DFF''s. For example see [1078882.1] - Error JBO-27122 When Trying To Create Requisitions In iProcurement ',
   'Found no DFF that are not frozen. Test passed',
   'ALWAYS',
   'E',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');    
   
        
  ---------------------------------------------------
  -- Cancelled Requisition Line Appearing Autocreate
  ---------------------------------------------------
  add_signature(
   'CANCELLED_REQ_LINE_AUTOCREATE',
   'SELECT prh.segment1,
           prl.requisition_header_id,
           prl.line_num,
           prl.item_description,
           prl.unit_meas_lookup_code,
           prl.unit_price,
           prl.quantity
    FROM po_requisition_lines_all prl,
         po_requisition_headers_all prh
    WHERE prh.requisition_header_id = ##$$REQID$$##
    AND   prh.requisition_header_id = prl.requisition_header_id
    AND   prl.REQS_IN_POOL_FLAG is not null
    AND   prl.CANCEL_FLAG = ''Y''',
   'Potential Data Corruption with Requisition Line and Autocreate',
   'RS',
    'The Requisition line listed is cancelled but will appear in the autocreate screen.',
    'See [1492372.1] - Autocreate Is Displaying Cancelled Requisition Lines for the solution ',
   'No Potential Issues Detected',
   'ALWAYS',
   'E',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');    
   


/*#################################################
  #  P O  S i g s                               #
  #################################################*/


  ------------------------------------
  -- Display PO Header Details
  ------------------------------------
  add_signature(
   'PO_HEADER_DETAILS',
   'SELECT po_header_id header_id,
           po_header_id "##$$FK1$$##",
           segment1 po_number,
           approved_flag,
           approved_date,
           approval_required_flag,
           authorization_status,
           cancel_flag,
           org_id,
           submit_date,
           p2p_analyzer_pkg.get_doc_amts(''NET_TOTAL'',''P'')
             document_net,
           p2p_analyzer_pkg.get_doc_amts(''TAX'',''P'')
             document_tax,
           p2p_analyzer_pkg.get_doc_amts(''TOTAL'',''P'')
             document_total,
           p2p_analyzer_pkg.get_doc_amts(''PRECISION'',''P'')
             currency_precision,
           p2p_analyzer_pkg.get_doc_amts(''EXT_PRECISION'',''P'')
             extended_precision,
           p2p_analyzer_pkg.get_doc_amts(''MIN_ACCT_UNIT'',''P'')
             min_accountable_unit,
           summary_flag,
           enabled_flag,
           vendor_id,
           currency_code,
           rate_type,
           rate_date,
           rate,
           blanket_total_amount,
           authorization_status,
           revision_num,
           revised_date,
           amount_limit,
           min_release_amount,
           closed_date,
           approval_required_flag,
           interface_source_code,
           wf_item_type,
           wf_item_key,
           global_agreement_flag,
           encumbrance_required_flag,
           document_creation_method,
           style_id,
           creation_date,
           last_update_date,
           last_updated_by
    FROM po_headers_all
    WHERE po_header_id = ##$$POID$$##
    AND   org_id = ##$$ORGID$$##
    AND   authorization_status = ''APPROVED''',
   'Purchase Order Details',
   'NRS',
   'Purchase Order is not Approved',
   '<ul><li>Approve Purchase Order.</li></ul>',
   '<ul><li>Purchase Order is Approved.</li></ul>',
   'ALWAYS',
   'E',
   'RS',
   'N',
   l_info,
   VARCHAR_TBL('PO_LINE_DETAILS'),
     p_include_in_dx_summary => 'Y');

  ------------------------------------
  -- CG Display PO Header Details starting from REQ
  ------------------------------------
  add_signature(
   'PO_HEADER_DETAILS2',
   'SELECT DISTINCT p.po_header_id header_id,
           p.po_header_id "##$$FK1$$##",
           p.segment1 po_number,
           p.approved_flag,
           p.approved_date,
           p.approval_required_flag,
           p.authorization_status,
           p.cancel_flag,
           p.org_id,
           p.submit_date,
           p2p_analyzer_pkg.get_doc_amts(''NET_TOTAL'',''P'')
             document_net,
           p2p_analyzer_pkg.get_doc_amts(''TAX'',''P'')
             document_tax,
           p2p_analyzer_pkg.get_doc_amts(''TOTAL'',''P'')
             document_total,
           p2p_analyzer_pkg.get_doc_amts(''PRECISION'',''P'')
             currency_precision,
           p2p_analyzer_pkg.get_doc_amts(''EXT_PRECISION'',''P'')
             extended_precision,
           p2p_analyzer_pkg.get_doc_amts(''MIN_ACCT_UNIT'',''P'')
             min_accountable_unit,
           p.summary_flag,
           p.enabled_flag,
           p.vendor_id,
           p.currency_code,
           p.rate_type,
           p.rate_date,
           p.rate,
           p.blanket_total_amount,
           p.authorization_status,
           p.revision_num,
           p.revised_date,
           p.amount_limit,
           p.min_release_amount,
           p.closed_date,
           p.approval_required_flag,
           p.interface_source_code,
           p.wf_item_type,
           p.wf_item_key,
           p.global_agreement_flag,
           p.encumbrance_required_flag,
           p.document_creation_method,
           p.style_id,
           p.creation_date,
           p.last_update_date,
           p.last_updated_by
    FROM   po_headers_all p, 
           po_distributions_all d,
           po_req_distributions_all rd, 
           po_requisition_lines_all rl,
           po_requisition_headers_all r 
    WHERE  p.po_header_id = d.po_header_id 
    AND    r.segment1 =  ''##$$REQNUM$$##''
    AND    d.req_distribution_id = rd.distribution_id 
    AND    rd.requisition_line_id = rl.requisition_line_id 
    AND    rl.requisition_header_id = r.requisition_header_id 
    AND    p.org_id = ##$$ORGID$$##           
    AND    p.authorization_status = ''APPROVED''',
   'Purchase Order Details',
   'NRS',
   'Purchase Order is not Approved',
   '<ul><li>Approve Purchase Order.</li></ul>',
   '<ul><li>Purchase Order is Approved.</li></ul>',
   'ALWAYS',
   'E',
   'RS',
   'N',
   l_info,
   VARCHAR_TBL('PO_LINE_DETAILS2'),
     p_include_in_dx_summary => 'Y');


  ------------------------------------
  -- Display PO Line Details
  ------------------------------------
  add_signature(
   'PO_LINE_DETAILS',
   'SELECT l.line_num,
           l.line_num "##$$FK4$$##",
           l.po_line_id,
           l.po_line_id "##$$FK5$$##",
           l.item_id,
           substr(msi.segment1,1,40) item_number,
           l.item_revision,
           l.item_description,
           l.category_id,
           mca.concatenated_segments item_category,
           lt.line_type,
           lt.outside_operation_flag,
           l.list_price_per_unit,
           l.unit_price,
           l.quantity,
           l.unit_meas_lookup_code,
           l.amount,
           l.taxable_flag,
           l.tax_name,
           l.closed_code,
           l.cancel_flag,
           l.closed_flag,
           l.cancelled_by,
           l.cancel_date,
           l.closed_code,
           l.not_to_exceed_price,
           l.allow_price_override_flag,
           l.price_break_lookup_code,
           l.tax_code_id,
           l.base_uom,
           l.base_qty,
           l.last_update_date,
           l.last_updated_by
    FROM po_lines_all l,
         po_line_types lt,
         mtl_system_items msi,
         financials_system_params_all fsp,
         mtl_categories_kfv mca
    WHERE l.po_header_id =  ##$$POID$$##
    AND   fsp.org_id = l.org_id
    AND   msi.inventory_item_id (+) = l.item_id
    AND   nvl(msi.organization_id, fsp.inventory_organization_id) =
            fsp.inventory_organization_id
    AND   lt.line_type_id = l.line_type_id
    AND   mca.category_id  = l.category_id
    ORDER BY l.line_num',
   'Purchase Order Line Details',
   'NRS',
   'No document lines found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('PO_LINE_LOCATIONS'),
     p_include_in_dx_summary => 'Y');


  ------------------------------------
  -- CG Display PO Line Details
  ------------------------------------
  add_signature(
   'PO_LINE_DETAILS2',
   'SELECT l.line_num,
           l.line_num "##$$FK4$$##",
           l.po_line_id,
           l.po_line_id "##$$FK5$$##",
           l.item_id,
           substr(msi.segment1,1,40) item_number,
           l.item_revision,
           l.item_description,
           l.category_id,
           mca.concatenated_segments item_category,
           lt.line_type,
           lt.outside_operation_flag,
           l.list_price_per_unit,
           l.unit_price,
           l.quantity,
           l.unit_meas_lookup_code,
           l.amount,
           l.taxable_flag,
           l.tax_name,
           l.closed_code,
           l.cancel_flag,
           l.closed_flag,
           l.cancelled_by,
           l.cancel_date,
           l.closed_code,
           l.not_to_exceed_price,
           l.allow_price_override_flag,
           l.price_break_lookup_code,
           l.tax_code_id,
           l.base_uom,
           l.base_qty,
           l.last_update_date,
           l.last_updated_by
    FROM po_lines_all l,
         po_line_types lt,
         mtl_system_items msi,
         financials_system_params_all fsp,
         mtl_categories_kfv mca
    WHERE l.po_header_id = ##$$FK1$$##
    AND   fsp.org_id = l.org_id
    AND   msi.inventory_item_id (+) = l.item_id
    AND   nvl(msi.organization_id, fsp.inventory_organization_id) =
            fsp.inventory_organization_id
    AND   lt.line_type_id = l.line_type_id
    AND   mca.category_id  = l.category_id
    ORDER BY l.line_num',
   'Purchase Order Line Details',
   'NRS',
   'No document lines found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('PO_LINE_LOCATIONS2'),
     p_include_in_dx_summary => 'Y');




  ------------------------------------
  -- Display PO Line Location Details
  ------------------------------------
  add_signature(
   'PO_LINE_LOCATIONS',
   'SELECT l.line_num po_line_num,
           ll.line_location_id,
           ll.shipment_num,
           ll.shipment_type,
           ll.quantity,
           ll.unit_meas_lookup_code uom,
           ll.price_override discounted_price,
           ll.taxable_flag,
           ll.tax_name,
           ll.tax_user_override_flag,
           ll.tax_code_id,
           ll.source_shipment_id,
           ll2.shipment_num source_shipment_num,
           ll.ship_to_organization_id,
           org.organization_code ship_to_organization_code,
           ll.ship_to_location_id,
           loc.location_code ship_to_location_code,
           ll.quantity_accepted,
           ll.quantity_billed,
           ll.quantity_cancelled,
           ll.quantity_received,
           ll.quantity_rejected,
           ll.amount,
           po_headers_sv3.get_currency_code(ll.po_header_id)
             currency_code,
           ll.last_accept_date,
           ll.need_by_date,
           ll.promised_date,
           ll.firm_status_lookup_code,
           ll.price_discount,
           ll.start_date,
           ll.end_date,
           ll.lead_time,
           ll.lead_time_unit,
           ll.terms_id,
           apt.name payment_terms_name,
           ll.freight_terms_lookup_code,
           ll.fob_lookup_code,
           ll.ship_via_lookup_code,
           ll.accrue_on_receipt_flag,
           ll.from_header_id,
           ll.from_line_id,
           ll.from_line_location_id,
           ll.encumbered_flag,
           ll.encumbered_date,
           ll.approved_flag,
           ll.approved_date,
           ll.closed_code,
           ll.cancel_flag,
           ll.cancel_date,
           ll.cancel_reason,
           ll.cancelled_by,
           ll.closed_flag,
           ll.closed_by,
           ll.closed_date,
           ll.closed_reason,
           ll.ussgl_transaction_code,
           ll.government_context,
           ll.match_option,
           ll.secondary_unit_of_measure,
           ll.secondary_quantity
    FROM po_line_locations_all ll,
         po_line_locations_all ll2,
         po_lines_all l,
         ap_terms apt,
         hr_locations_all_vl loc,
         org_organization_definitions org
    WHERE ll.po_header_id = ##$$POID$$##
    AND   l.po_line_id = ll.po_line_id
    AND   l.line_num  = ##$$FK4$$##
   /* AND ll.line_location_id in (
                         select rl.line_location_id from po_requisition_lines_all rl 
                         where requisition_header_id in (
                                               select requisition_header_id 
                                               from po_requisition_headers_all rh
                                               where segment1 = ''##$$REQNUM$$##''))    */
    AND ll.line_location_id in (SELECT line_location_id
                                FROM po_line_locations_all
                                WHERE po_header_id IN
                                  (SELECT po_header_id FROM po_headers_all WHERE po_header_id = ##$$POID$$##))    
    AND   apt.term_id (+) = ll.terms_id
    AND   loc.location_id (+) = ll.ship_to_location_id
    AND   org.organization_id(+) = ll.ship_to_organization_id
    AND   ll2.line_location_id (+) = ll.source_shipment_id
    ORDER BY l.line_num',
   'Purchase Order Line Location Details',
   'NRS',
   'No line location records found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('PO_DIST_DETAILS'),
     p_include_in_dx_summary => 'Y');


  ------------------------------------
  -- CG Display PO Line Location Details ( shipments)
  ------------------------------------
  add_signature(
   'PO_LINE_LOCATIONS2',
   'SELECT l.line_num po_line_num,
           ll.line_location_id,
           ll.line_location_id "##$$FK6$$##",
           ll.shipment_num,
           ll.shipment_type,
           ll.quantity,
           ll.unit_meas_lookup_code uom,
           ll.price_override discounted_price,
           ll.taxable_flag,
           ll.tax_name,
           ll.tax_user_override_flag,
           ll.tax_code_id,
           ll.source_shipment_id,
           ll2.shipment_num source_shipment_num,
           ll.ship_to_organization_id,
           org.organization_code ship_to_organization_code,
           ll.ship_to_location_id,
           loc.location_code ship_to_location_code,
           ll.quantity_accepted,
           ll.quantity_billed,
           ll.quantity_cancelled,
           ll.quantity_received,
           ll.quantity_rejected,
           ll.amount,
           po_headers_sv3.get_currency_code(ll.po_header_id)
             currency_code,
           ll.last_accept_date,
           ll.need_by_date,
           ll.promised_date,
           ll.firm_status_lookup_code,
           ll.price_discount,
           ll.start_date,
           ll.end_date,
           ll.lead_time,
           ll.lead_time_unit,
           ll.terms_id,
           apt.name payment_terms_name,
           ll.freight_terms_lookup_code,
           ll.fob_lookup_code,
           ll.ship_via_lookup_code,
           ll.accrue_on_receipt_flag,
           ll.from_header_id,
           ll.from_line_id,
           ll.from_line_location_id,
           ll.encumbered_flag,
           ll.encumbered_date,
           ll.approved_flag,
           ll.approved_date,
           ll.closed_code,
           ll.cancel_flag,
           ll.cancel_date,
           ll.cancel_reason,
           ll.cancelled_by,
           ll.closed_flag,
           ll.closed_by,
           ll.closed_date,
           ll.closed_reason,
           ll.ussgl_transaction_code,
           ll.government_context,
           ll.match_option,
           ll.secondary_unit_of_measure,
           ll.secondary_quantity
    FROM po_line_locations_all ll,
         po_line_locations_all ll2,
         po_lines_all l,
         ap_terms apt,
         hr_locations_all_vl loc,
         org_organization_definitions org
    WHERE ll.po_header_id = ##$$FK1$$##
    AND   l.po_line_id = ll.po_line_id
    AND   l.line_num = ##$$FK4$$##
    AND ll.shipment_type != ''PRICE BREAK''
    AND ll.line_location_id in (
                         select rl.line_location_id from po_requisition_lines_all rl 
                         where requisition_header_id in (
                                               select requisition_header_id 
                                               from po_requisition_headers_all rh
                                               where segment1 = ''##$$REQNUM$$##''))

    AND   apt.term_id (+) = ll.terms_id
    AND   loc.location_id (+) = ll.ship_to_location_id
    AND   org.organization_id(+) = ll.ship_to_organization_id
    AND   ll2.line_location_id (+) = ll.source_shipment_id
    ORDER BY l.line_num',
   'Purchase Order Line Location Details',
   'NRS',
   'No line location records found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('PO_DIST_DETAILS2'),
     p_include_in_dx_summary => 'Y');
   

  ------------------------------------
  -- Display PO Distribution Details
  ------------------------------------
  add_signature(
   'PO_DIST_DETAILS',
   'SELECT d.po_line_id,
           d.distribution_num,
           d.quantity_ordered,
           d.code_combination_id,
           substr(rtrim(g.segment1||''-''||g.segment2||''-''||
             g.segment3||''-''||g.segment4||''-''||
             g.segment5||''-''||g.segment6||''-''||
             g.segment7||''-''||g.segment8||''-''||
             g.segment9||''-''||g.segment10||''-''||
             g.segment11||''-''||g.segment12||''-''||
             g.segment13||''-''||g.segment14||''-''||
             g.segment15||''-''||g.segment16||''-''||
             g.segment17||''-''||g.segment18||''-''||
             g.segment19||''-''||g.segment20||''-''||
             g.segment21||''-''||g.segment22||''-''||
             g.segment23||''-''||g.segment24||''-''||
             g.segment25||''-''||g.segment26||''-''||
             g.segment27||''-''||g.segment28||''-''||
             g.segment29||''-''||g.segment30,''-''), 1, 100) charge_acct,
           creation_date,
           created_by,
           po_release_id,
           quantity_delivered,
           quantity_billed,
           quantity_cancelled,
           req_header_reference_num,
           req_line_reference_num,
           req_distribution_id,
           deliver_to_location_id,
           deliver_to_person_id,
           rate_date,
           rate,
           amount_billed,
           accrued_flag,
           encumbered_flag,
           encumbered_amount,
           unencumbered_quantity,
           unencumbered_amount,
           failed_funds_lookup_code,
           gl_encumbered_date,
           gl_encumbered_period_name,
           gl_cancelled_date,
           destination_type_code,
           destination_organization_id,
           destination_subinventory,
           budget_account_id,
           accrual_account_id,
           variance_account_id,
           prevent_encumbrance_flag,
           ussgl_transaction_code,
           government_context,
           destination_context,
           source_distribution_id,
           project_id,
           task_id,
           expenditure_type,
           project_accounting_context,
           expenditure_organization_id,
           gl_closed_date,
           accrue_on_receipt_flag,
           expenditure_item_date,
           mrc_rate_date,
           mrc_rate,
           mrc_encumbered_amount,
           mrc_unencumbered_amount,
           end_item_unit_number,
           tax_recovery_override_flag,
           recoverable_tax,
           nonrecoverable_tax,
           recovery_rate,
           oke_contract_line_id,
           oke_contract_deliverable_id,
           amount_ordered,
           amount_delivered,
           amount_cancelled,
           distribution_type,
           amount_to_encumber,
           invoice_adjustment_flag,
           dest_charge_account_id,
           dest_variance_account_id,
           quantity_financed,
           amount_financed,
           quantity_recouped,
           amount_recouped,
           retainage_withheld_amount,
           retainage_released_amount,
           wf_item_key,
           invoiced_val_in_ntfn,
           tax_attribute_update_code,
           interface_distribution_ref
    FROM po_distributions_all d,
         gl_code_combinations g
    WHERE d.po_header_id = ##$$POID$$##
    AND   d.po_line_id  = ##$$FK5$$##
    AND  d.line_location_id in (
                            /*select rl.line_location_id 
                            from po_requisition_lines_all rl 
                            where requisition_header_id in (
                                                  select requisition_header_id 
                                                  from po_requisition_headers_all rh
                                                  where segment1 = ''##$$REQNUM$$##''))    */
                                SELECT line_location_id
                                FROM po_line_locations_all
                                WHERE po_header_id IN
                                  (SELECT po_header_id FROM po_headers_all WHERE po_header_id = ##$$POID$$##))                                                  
    AND d.code_combination_id = g.code_combination_id(+)
    ORDER BY d.po_line_id, d.distribution_num',
   'Purchase Order Distribution Details',
   'NRS',
   'No distributions found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');


  ------------------------------------
  -- CG Display PO Distribution Details
  ------------------------------------
  add_signature(
   'PO_DIST_DETAILS2',
   'SELECT d.po_line_id,
           d.distribution_num,
           d.quantity_ordered,
           d.code_combination_id,
           substr(rtrim(g.segment1||''-''||g.segment2||''-''||
             g.segment3||''-''||g.segment4||''-''||
             g.segment5||''-''||g.segment6||''-''||
             g.segment7||''-''||g.segment8||''-''||
             g.segment9||''-''||g.segment10||''-''||
             g.segment11||''-''||g.segment12||''-''||
             g.segment13||''-''||g.segment14||''-''||
             g.segment15||''-''||g.segment16||''-''||
             g.segment17||''-''||g.segment18||''-''||
             g.segment19||''-''||g.segment20||''-''||
             g.segment21||''-''||g.segment22||''-''||
             g.segment23||''-''||g.segment24||''-''||
             g.segment25||''-''||g.segment26||''-''||
             g.segment27||''-''||g.segment28||''-''||
             g.segment29||''-''||g.segment30,''-''), 1, 100) charge_acct,
           d.creation_date,
           d.created_by,
           d.po_release_id,
           d.quantity_delivered,
           d.quantity_billed,
           d.quantity_cancelled,
           req_header_reference_num,
           req_line_reference_num,
           req_distribution_id,
           deliver_to_location_id,
           deliver_to_person_id,
           rate_date,
           rate,
           d.amount_billed,
           d.accrued_flag,
           d.encumbered_flag,
           d.encumbered_amount,
           d.unencumbered_quantity,
           unencumbered_amount,
           failed_funds_lookup_code,
           gl_encumbered_date,
           gl_encumbered_period_name,
           gl_cancelled_date,
           destination_type_code,
           destination_organization_id,
           destination_subinventory,
           budget_account_id,
           accrual_account_id,
           variance_account_id,
           prevent_encumbrance_flag,
           d.ussgl_transaction_code,
           d.government_context,
           destination_context,
           source_distribution_id,
           d.project_id,
           d.task_id,
           expenditure_type,
           project_accounting_context,
           expenditure_organization_id,
           gl_closed_date,
           d.accrue_on_receipt_flag,
           expenditure_item_date,
           mrc_rate_date,
           mrc_rate,
           mrc_encumbered_amount,
           mrc_unencumbered_amount,
           end_item_unit_number,
           tax_recovery_override_flag,
           recoverable_tax,
           nonrecoverable_tax,
           recovery_rate,
           oke_contract_line_id,
           oke_contract_deliverable_id,
           amount_ordered,
           d.amount_delivered,
           d.amount_cancelled,
           d.distribution_type,
           d.amount_to_encumber,
           d.invoice_adjustment_flag,
           d.dest_charge_account_id,
           d.dest_variance_account_id,
           d.quantity_financed,
           d.amount_financed,
           d.quantity_recouped,
           d.amount_recouped,
           d.retainage_withheld_amount,
           d.retainage_released_amount,
           d.wf_item_key,
           invoiced_val_in_ntfn,
           d.tax_attribute_update_code,
           interface_distribution_ref
    FROM po_distributions_all d,
         gl_code_combinations g
    WHERE d.po_header_id = ##$$FK1$$##
    AND   d.po_line_id  = ##$$FK5$$##
    AND  d.line_location_id in (
                            select rl.line_location_id 
                            from po_requisition_lines_all rl 
                            where requisition_header_id in (
                                                  select requisition_header_id 
                                                  from po_requisition_headers_all rh
                                                  where segment1 = ''##$$REQNUM$$##''))
    AND   d.code_combination_id = g.code_combination_id(+)
    ORDER BY d.po_line_id, d.distribution_num',
   'Purchase Order Distribution Details',
   'NRS',
   'No distributions found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');


  -------------------------------------------------------------------
  -- Purchase Order Approval History
  -------------------------------------------------------------------

 l_info.delete;
  add_signature(
   'PO_APPROVAL_HISTORY',
   'SELECT  ppf.full_name, 
            poa.object_type_code, 
            poa.object_sub_type_code, 
            poa.sequence_num,
            poa.action_code, 
            poa.creation_date,
            object_revision_num po_revision,
            poa.* 
    FROM po_action_history poa, hr_employees_current_v ppf
    WHERE object_id = ##$$POID$$##
    ANd ppf.employee_id(+) = poa.employee_id
    AND object_type_code = ''##$$DOCTYPESHORT$$##''
    order by poa.sequence_num asc',
   'Purchase Order Approval History',
   'NRS',
   'No Approval History found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');



--Jeff Testing match rules

  -------------------------------------------------------------------
  -- 2 Way Match check
  -------------------------------------------------------------------
 
 
 
  l_info.delete;
  add_signature(
   '2WAY_COUNT',
   'SELECT count(*) "No_of_Lines"
    FROM (SELECT l.line_num po_line_num,
           ll.line_location_id,
           ll.shipment_num,
           ll.shipment_type,
           decode(ll.INSPECTION_REQUIRED_FLAG,''N'',
           decode(ll.RECEIPT_REQUIRED_FLAG,''N'',''2 WAY'',''Y'',''3 WAY'',NULL),''Y'',
           decode(ll.RECEIPT_REQUIRED_FLAG,''Y'',''4 WAY'',NULL),NULL,
           decode(ll.RECEIPT_REQUIRED_FLAG,NULL,''2 WAY'',''Y'',''3 WAY'',NULL), NULL) MATCHING_PO,
           ll.RECEIVE_CLOSE_TOLERANCE,
           ll.invoice_CLOSE_TOLERANCE
    FROM po_line_locations_all ll,
         po_line_locations_all ll2,
         po_lines_all l,
         ap_terms apt,
         hr_locations_all_vl loc,
         org_organization_definitions org
    WHERE ll.po_header_id = ##$$POID$$##
    AND   l.po_line_id = ll.po_line_id
    AND ll.line_location_id in (
                         select rl.line_location_id from po_requisition_lines_all rl
                         where requisition_header_id in (
                                               select requisition_header_id
                                               from po_requisition_headers_all rh
                                               where segment1 = ''##$$REQNUM$$##''))
    AND   apt.term_id (+) = ll.terms_id
    AND   loc.location_id (+) = ll.ship_to_location_id
    AND   org.organization_id(+) = ll.ship_to_organization_id
    AND   ll2.line_location_id (+) = ll.source_shipment_id
    and   ll.RECEIVE_CLOSE_TOLERANCE < 100
    and   ((ll.inspection_required_flag=''Y'' and ll.receipt_required_flag =''Y'') 
          or (ll.inspection_required_flag is null and ll.receipt_required_flag =''Y''))  /* 2-way*/
    ORDER BY l.line_num)',
   '2 Way Matching with Receipt Close Tolerance < 100%',
   '[No_of_Lines] > [0]',
   'Purchase Order lines with 2 Way matching with receipt close tolerance < 100% detected',
   'Expand the output to see the line details',
   'No Possible Problems Found.',
   'ALWAYS',
    'W',
    'RS',
    'Y',
    l_info,
    VARCHAR_TBL('2WAY_COUNT_DETAILS'), p_include_in_dx_summary => 'Y');     
    
    
    
    
    
    
    

  -------------------------------------------------------------------
  -- 2 Way Match check details
  -------------------------------------------------------------------

  add_signature(
   '2WAY_COUNT_DETAILS',
   'SELECT l.line_num po_line_num,
           ll.line_location_id,
           ll.shipment_num,
           ll.shipment_type,
           decode(ll.INSPECTION_REQUIRED_FLAG,''N'',
           decode(ll.RECEIPT_REQUIRED_FLAG,''N'',''2 WAY'',''Y'',''3 WAY'',NULL),''Y'',
           decode(ll.RECEIPT_REQUIRED_FLAG,''Y'',''4 WAY'',NULL),NULL,
           decode(ll.RECEIPT_REQUIRED_FLAG,NULL,''2 WAY'',''Y'',''3 WAY'',NULL), NULL) MATCHING_PO,
           ll.RECEIVE_CLOSE_TOLERANCE,
           ll.invoice_CLOSE_TOLERANCE,
           ll.quantity,
           ll.unit_meas_lookup_code uom,
           ll.price_override discounted_price,
           ll.ship_to_organization_id,
           org.organization_code ship_to_organization_code,
           ll.ship_to_location_id,
           loc.location_code ship_to_location_code,
           ll.quantity_accepted,
           ll.quantity_billed,
           ll.quantity_cancelled,
           ll.quantity_received,
           ll.quantity_rejected,
           ll.amount,
           po_headers_sv3.get_currency_code(ll.po_header_id)
             currency_code,
           ll.last_accept_date,
           ll.need_by_date,
           ll.promised_date,
           ll.closed_reason,
           ll.match_option
    FROM po_line_locations_all ll,
         po_line_locations_all ll2,
         po_lines_all l,
         ap_terms apt,
         hr_locations_all_vl loc,
         org_organization_definitions org
    WHERE ll.po_header_id = ##$$POID$$##
    AND   l.po_line_id = ll.po_line_id
    AND ll.line_location_id in (
                         select rl.line_location_id from po_requisition_lines_all rl
                         where requisition_header_id in (
                                               select requisition_header_id
                                               from po_requisition_headers_all rh
                                               where segment1 = ''##$$REQNUM$$##''))
    AND   apt.term_id (+) = ll.terms_id
    AND   loc.location_id (+) = ll.ship_to_location_id
    AND   org.organization_id(+) = ll.ship_to_organization_id
    AND   ll2.line_location_id (+) = ll.source_shipment_id
    and   ll.RECEIVE_CLOSE_TOLERANCE < 100
    and   ((ll.inspection_required_flag=''Y'' and ll.receipt_required_flag =''Y'') 
          or (ll.inspection_required_flag is null and ll.receipt_required_flag =''Y''))  /* 2-way*/
    ORDER BY l.line_num',
   '2 Way Matching with Receipt Close Tolerance < 100%',
   'RS',
   'Purchase Order lines with 2 Way matching with receipt close tolerance < 100% detected',
   '<ul> See [1265680.1] How Are Purchase Orders Closed Automatically? Closed Status Rolled Up? PO''s Are Not Closing? for the detailed setup </ul>',
   'No Possible Problems Found.',
   'ALWAYS',
   'W',
   'RS',
    p_include_in_dx_summary => 'Y');    
    





        
  -------------------------------------------------------------
  --  Quantity/Amount billed mismatch on shipment/distribution
  -------------------------------------------------------------
  
  l_info.delete;
  add_signature(
   'PODATACORRUPTION_01',
   'SELECT poll.po_line_id,
       poll.line_location_id, 
       poll.po_release_id,
       pol.order_type_lookup_code,
       nvl(poll.quantity_billed,0) qtyamt_billed_on_po_line_loc,
       sum(nvl(pod.quantity_billed,0)) qtyamt_billed_on_po_dist
       from po_line_locations_all poll, 
       po_distributions_all pod,
       po_lines_all pol
       where poll.line_location_id=pod.line_location_id
       and pol.po_line_id= pod.po_line_id
       and pol.po_header_id = ##$$POID$$##
       and nvl(pol.order_type_lookup_code,''QUANTITY'') IN (''AMOUNT'',''QUANTITY'')
       and nvl(poll.cancel_flag,''N'') <> ''Y''
       and nvl(poll.closed_code,''OPEN'') <> ''FINALLY CLOSED''
       and poll.shipment_type in (''STANDARD'',''BLANKET'',''PLANNED'',''SCHEDULED'')
       group by
       poll.po_line_id,
       poll.line_location_id,
       poll.po_release_id,
       pol.order_type_lookup_code,
       nvl(poll.quantity_billed,0)
       having  round(nvl(poll.quantity_billed,0),15) <>  round(sum(nvl(pod.quantity_billed,0)),15)
       UNION ALL
       SELECT poll.po_line_id,
       poll.line_location_id,
       poll.po_release_id,
       pol.order_type_lookup_code,
       nvl(poll.amount_billed,0) qtyamt_billed_on_po_line_loc,
       sum(nvl(pod.amount_billed,0)) qtyamt_billed_on_po_dist
       from po_line_locations_all poll,
       po_distributions_all pod,
       po_lines_all pol
       where
       poll.line_location_id=pod.line_location_id
       and pol.po_line_id= pod.po_line_id
       and pol.po_header_id = ##$$POID$$##
       and nvl(pol.order_type_lookup_code,''QUANTITY'') IN (''FIXED PRICE'',''RATE'')
       and nvl(poll.cancel_flag,''N'') <> ''Y''
       and nvl(poll.closed_code,''OPEN'') <> ''FINALLY CLOSED''
       and poll.shipment_type in (''STANDARD'',''BLANKET'',''PLANNED'',''SCHEDULED'')
       group by
       poll.po_line_id,
       poll.line_location_id,
       poll.po_release_id,
       pol.order_type_lookup_code,
       nvl(poll.amount_billed,0)
       having  round(nvl(poll.amount_billed,0),15) <>  round(sum(nvl(pod.amount_billed,0)),15)',
   'Quantity/Amount Billed Mismatch on Shipment/Distribution',
   'RS',
   'Found mismatch of quantity billed or amount billed between the shipment and distribution',
   'Solution is described in [427917.1]',
   'No mismatch found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y'); 


  -------------------------------------
  --  PO/AP Quantity/Amount mismatch
  -------------------------------------
	 
    l_info.delete;
  add_signature(
   'PODATACORRUPTION_02',
   'select
		apd.po_release_id,
    apd.line_location_id,
		apd.po_distribution_id,
		NVL(apd.PO_QUANTITY,0),
		nvl(apd.po_amount,0),
		sum(nvl(apd.aid_quan,0)),
		SUM(NVL(apd.AID_AMT,0)),    
		3 MATCH_TYPE,
		apd.UOM_CODES,
		apd.process_flag
    from (
     select
		  pod.po_release_id po_release_id,
      pod.line_location_id  line_location_id,
		  pod.po_distribution_id po_distribution_id,
      pod.quantity_billed     po_quantity,
      pod.amount_billed       PO_AMOUNT,
		  decode( aid.dist_match_type,''PRICE_CORRECTION'', 0,''AMOUNT_CORRECTION'', 0,''ITEM_TO_SERVICE_PO'', 0, ''ITEM_TO_SERVICE_RECEIPT'', 0,
		          nvl( aid.corrected_quantity,0 ) +nvl( aid.quantity_invoiced,0 )
       ) * decode(nvl(aid.matched_uom_lookup_code,pll.unit_meas_lookup_code),
		       pll.unit_meas_lookup_code, 1 , nvl(ap_acctg_data_fix_pkg.uom_convert( nvl(aid.matched_uom_lookup_code, pll.unit_meas_lookup_code),
		       pll.unit_meas_lookup_code,rsl.item_id),0)
     ) AID_QUAN,
		 aid.amount            AID_AMT,
		 decode(nvl(ap_acctg_data_fix_pkg.uom_convert(nvl(aid.matched_uom_lookup_code, pll.unit_meas_lookup_code),pll.unit_meas_lookup_code, rsl.item_id),-999),-999,
		        aid.matched_uom_lookup_code||'' and ''||pll.unit_meas_lookup_code,''None'') uom_codes,
		 DECODE(NVL(AP_Acctg_Data_Fix_PKG.UOM_CONVERT(nvl(aid.matched_uom_lookup_code, pll.unit_meas_lookup_code),pll.unit_meas_lookup_code, rsl.item_id),-999),-999,''E'',''Y'') process_flag
		 from 
        po_distributions_all pod,
        po_line_locations_all pll,
		    ap_invoice_distributions_all aid,
		    ap_invoices_all ai,
		    financials_system_params_all fsp,
		    rcv_transactions rtxn,
		    rcv_shipment_lines rsl
		 where pod.po_header_id = ##$$POID$$##
     AND pod.po_distribution_id = aid.po_distribution_id
     AND pod.line_location_id = pll.line_location_id
     AND aid.invoice_id = ai.invoice_id
		 AND ai.org_id = fsp.org_id
		 AND ( NVL(fsp.purch_encumbrance_flag,''N'') = ''N'' or
                      (nvl(pll.approved_flag,''N'')=''Y'' and
                       nvl(pll.cancel_flag,''N'')=''N''  and
		                   NVL(pll.closed_code,'' '')<>''FINALLY CLOSED'')
            ) 
		   AND aid.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'', ''IPV'',''RETROACCRUAL'',''RETROEXPENSE'')
		   AND ai.invoice_type_lookup_code <> ''PREPAYMENT''
		   AND aid.rcv_transaction_id = RTXN.transaction_id (+)
		   and rtxn.shipment_line_id = rsl.shipment_line_id (+) ) apd
		 group by 
           apd.line_location_id,
		       apd.po_release_id,
		       apd.po_distribution_id,
		       apd.PO_QUANTITY,
		       apd.PO_AMOUNT,
		       apd.UOM_CODES,
		       apd.PROCESS_FLAG
		 HAVING  (Round(Nvl(apd.PO_QUANTITY,0),15) <> Round(Sum(nvl(apd.AID_QUAN,0)),15))
		 OR (Round(Nvl(apd.PO_AMOUNT,0),15) <> Round(Sum(nvl(apd.AID_AMT,0)),15))
   ',
   'PO/AP Quantity/Amount Mismatch',
   'RS',
   'Mismatch of quantity billed or amount billed between the shipment or distribution and the account payables invoice distribution',
   'Solution is described in Note: [454060.1]',
   'No mismatch found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y'); 
   
  --------------------------------------
  --  PO Shipments eligible to be closed
  --------------------------------------
  
    l_info.delete;
  add_signature(
   'PODATACORRUPTION_03',
   'select poll.po_line_id
   from   po_line_locations_all poll,
       PO_SYSTEM_PARAMETERS_all POSP
   where poll.shipment_type in (''STANDARD'',''BLANKET'') 
      and poll.po_release_id is null
      and poll.po_header_id = ##$$POID$$##
      and ((POLL.quantity - nvl(POLL.quantity_cancelled,0))
		     * (1 - nvl(POLL.receive_close_tolerance,
			    nvl(POSP.receive_close_tolerance,0))/100))
                            - decode(POSP.receive_close_code,
			    ''ACCEPTED'', nvl(POLL.quantity_accepted,0),
			     ''DELIVERED'', (select sum(nvl(POD1.quantity_delivered,0)) from
                              po_distributions_all pod1 where pod1.line_location_id=
                              poll.line_location_id), 
			      nvl(POLL.quantity_received,0))<=0.000000000000001
      and  ((POLL.quantity - nvl(poll.quantity_cancelled,0)) 
          *( 1 - nvl(POLL.invoice_close_tolerance,
		        nvl(POSP.invoice_close_tolerance,0))/100 ))
		        - nvl(poll.quantity_billed,0)<=0.000000000000001
     and nvl(poll.closed_code,''OPEN'') IN (''OPEN'',''CLOSED FOR RECEIVING'',
                                          ''CLOSED FOR INVOICE'')
   ',
   'PO Shipments Eligible to Be Closed',
   'RS',
   'Found shipment lines eligible for closing',
   'Solution is described in Note: [465068.1]',
   'No eligible shipment lines found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y'); 

  --------------------------------------------
  --  Outstanding Supply for Closed Documents
  --------------------------------------------
   
   -- TO BE verified!!!!
   l_info.delete;
   add_signature(
   'PODATACORRUPTION_04',
   'SELECT   pd.po_line_id,
         pd.line_location_id,
         pd.po_release_id,
         pd.po_distribution_id,
         pll.cancel_flag,
         pll.closed_code,
         pll.shipment_type
  FROM  po_line_locations_all pll,
        po_distributions_all pd
  WHERE pll.po_header_id =  ##$$POID$$##
  AND (Nvl(pll.closed_code,''OPEN'') IN 
                  (''CLOSED'',''FINALLY CLOSED'',''CLOSED FOR RECEIVING'')
           OR Nvl(pll.cancel_flag, ''N'') = ''Y'')
  AND pll.line_location_id = pd.line_location_id
  AND nvl(pll.approved_flag,''N'') = ''Y''
  AND pll.shipment_type IN (''STANDARD'',''BLANKET'',''SCHEDULED'', ''PLANNED'')
  AND  EXISTS 
            (SELECT 1 
             FROM mtl_supply ms
             WHERE pd.po_distribution_id = ms.supply_source_id
             AND ms.supply_type_code = ''PO'')
   ',
   'Outstanding Supply for Closed Documents',
   'RS',
   'Found PO Supply exists for PO whose closed code is in ''CLOSED'',''CLOSED FOR RECEIVING'',''FINALLY CLOSED'' 
   and PO is cancelled for following document types, Standard PO, Planned PO, Blanket Release, Scheduled Release',
   'Solution is described in Note: [402217.1]',
   'No outstanding demand found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y'); 
   

  --------------------------------------------
  --  PO UOM Mismatch
  --------------------------------------------
  
   l_info.delete;
   add_signature(
   'PODATACORRUPTION_07',
   'SELECT DISTINCT ph.po_header_id,  ph.type_lookup_code, pl.po_line_id, pll.line_location_id, pl.unit_meas_lookup_code, pll.unit_meas_lookup_code
    FROM   po_line_locations_all pll,
             po_lines_all pl,
             po_headers_all ph
    WHERE ph.po_header_id = ##$$POID$$##
    AND Nvl(pll.unit_meas_lookup_code, -1) <> Nvl(pl.unit_meas_lookup_code, -1)
    AND pll.po_line_id = pl.po_line_id
    AND pl.po_header_id = ph.po_header_id
    AND pll.unit_meas_lookup_code IS NOT NULL
    AND pl.unit_meas_lookup_code IS NOT NULL
    AND Nvl(pll.closed_code, ''OPEN'') <> ''FINALLY CLOSED''
    AND Nvl(pll.cancel_flag, ''N'') <> ''Y''
    AND ( ( ph.type_lookup_code = ''BLANKET''
                     AND pll.po_release_id IS NOT NULL )
                    OR ph.type_lookup_code <> ''BLANKET'' )
   ',
   'PO UOM Mismatch',
   'RS',
   'Found PO documents with UOM mismatch between Lines and Shipments',
   'Solution is described in Note: [1419114.1]',
   'No UOM mismatch found for PO documents. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');
   
   
  --------------------------------------------
  --  Cancel PO in requires re-approval status
  --------------------------------------------
  
   l_info.delete;
   add_signature(
   'PODATACORRUPTION_08',
   ' SELECT   po_header_id, 
         segment1, 
         org_id, 
         cancel_flag,
         authorization_status
    FROM po_headers_all ph
    where ph.po_header_id = ##$$POID$$##
    and nvl(Cancel_flag, ''N'') = ''Y''
    and authorization_status = ''REQUIRES REAPPROVAL''',
   'Canceled Purchase Order in Requires Re-approval Status',
   'RS',
   'Tax Error while approving document',
   'Solution is described in Note: [1379274.1]',
   'PO is in correct status. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');

  --------------------------------------------
  --  Tax exception 023 when approving
  --------------------------------------------
  
   l_info.delete;
   add_signature(
   'PODATACORRUPTION_09',
   'SELECT PLL.LINE_LOCATION_ID,
       PLL.SHIPMENT_NUM,
       PLL.TAX_ATTRIBUTE_UPDATE_CODE
    FROM   PO_LINE_LOCATIONS_ALL PLL
    WHERE PLL.PO_HEADER_ID = ##$$POID$$##
      AND NVL(PLL.TAX_ATTRIBUTE_UPDATE_CODE,''UPDATE'') <> ''UPDATE''
      AND EXISTS (SELECT 1 FROM ZX_LINES_DET_FACTORS
                  WHERE APPLICATION_ID = 201
                        AND ENTITY_CODE = ''PURCHASE_ORDER''
                        AND TRX_ID = PLL.PO_HEADER_ID
                        AND TRX_LINE_ID = PLL.LINE_LOCATION_ID)',
   'Tax Exception 023 When Approving',
   'RS',
   'Tax exception 023 (ORA-00001: unique constraint (ZX.ZX_LINES_DET_FACTORS_U1) violated") when approving',
   'Solution is described in Note: [1346647.1]',
   'No invalid tax constraint issue found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');


  --------------------------------------------
  --  Incorrect Requires Reapproval status
  --------------------------------------------
   
   l_info.delete;
   add_signature(
   'PODATACORRUPTION_10',
   'SELECT PH.PO_HEADER_ID,
       PH.SEGMENT1,                                                                                                                                  
       PH.AUTHORIZATION_STATUS
    FROM  po_headers_all PH
    where ph.PO_HEADER_ID = ##$$POID$$##
    and authorization_status = ''REQUIRES_REAPPROVAL''',
   'Incorrect Requires Reapproval Status.',
   'RS',
   'This PO has incorrect Requires Reapproval status',
   'Solution is described in Note: [1269228.1]',
   'Not invalid requires reapproval status. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');   
   
  --------------------------------------------
  --  Incorrect Requires Reapproval status
  --------------------------------------------
     
      l_info.delete;
   add_signature(
   'PODATACORRUPTION_11',
   'select distinct pha.po_header_id, 
                pha.segment1 "PO_Number",                                 
                pda.rate "PO_Dist_Rate",                                  
                pha.currency_code "PO Currency Code",                     
                prla.rate "Req Line Rate",                                
                prla.currency_code "Req Line Currency",                   
                pda.creation_date "PO Dist Creation Date",                
                pda.rate / prla.rate rate_ratio
     from po_distributions_all     pda,                                      
       po_req_distributions_all prda,                                     
       po_requisition_lines_all prla,                                     
       po_headers_all           pha                                       
     where pha.po_header_id = ##$$POID$$##
     and pda.req_distribution_id = prda.distribution_id                     
     and prla.requisition_line_id = prda.requisition_line_id                
     and prla.rate / pda.rate < 0.5                                         
     and pha.po_header_id = pda.po_header_id                                
     and pha.currency_code = prla.currency_code',
   'Foreign Currency Purchase Orders with Inverse Rate',
   'RS',
   'Foreign Currency Autocreated Purchase Orders Have Inverse Rate found',
   'Solution is described in Note: [756627.1]',
   'No invalid rate found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');   
   
   
  --------------------------------------------
  --  Ship To Organization mismatch 1
  --------------------------------------------
       
   l_info.delete;
    add_signature(
    'PODATACORRUPTION_12',
    'select pod.po_header_id,
        pod.po_distribution_id,
        pod.line_location_id,
        pod.destination_organization_id,
        poll.ship_to_organization_id
     from po_distributions_all pod,
      po_line_locations_all poll
     where poll.po_header_id = ##$$POID$$##
     and pod.line_location_id = poll.line_location_id
     and pod.po_header_id = poll.po_header_id
     and pod.destination_organization_id != poll.ship_to_organization_id
     and nvl(poll.closed_code,''OPEN'') != ''FINALLY CLOSED''
     and nvl(poll.cancel_flag,''N'') != ''Y''',
    'Ship to Organization Mismatch 1',
    'RS',
    'Shipment Ship To Organization does not match distribution Deliver To Organization',
    'Solution is described in Note: 1280061.1',
    'Not mismatch found. Test passed',
    'ALWAYS',
    'W',
    'RS',
    'Y',
    p_include_in_dx_summary => 'Y');

   
  --------------------------------------------
  --  Ship To Organization mismatch 2
  --------------------------------------------
     
   l_info.delete;
   add_signature(
    'PODATACORRUPTION_13',
    'select poll.po_header_id,
        poll.line_location_id,
        poll.ship_to_organization_id,
        mtl.to_organization_id,
        mtl.supply_source_id
     from mtl_supply mtl,
      po_line_locations_all poll
     where poll.po_header_id = ##$$POID$$##
     and mtl.supply_type_code = ''PO''
     and mtl.po_line_location_id = poll.line_location_id
     and mtl.po_header_id = poll.po_header_id
     and mtl.to_organization_id != poll.ship_to_organization_id
     and nvl(poll.closed_code,''OPEN'') != ''FINALLY CLOSED''
     and nvl(poll.cancel_flag,''N'') != ''Y''',
    'Ship to Organization Mismatch 2',
    'RS',
    'Shipment Ship To Organization does not match supply To Organization',
    'Solution is described in Note: 1280061.1',
    'Not mismatch found. Test passed',
    'ALWAYS',
    'W',
    'RS',
    'Y',
    p_include_in_dx_summary => 'Y');
  
    

   
  ----------------------------------------------
  --  Existing incorrect supply for PO documents
  ----------------------------------------------
   
   l_info.delete;
   add_signature(
   'PODATACORRUPTION_15',
   'select ph.segment1, 
       NULL, -- no release number
       pd.po_header_id,
       pd.po_line_id,
       pd.line_location_id,
       pd.po_release_id,
       pd.po_distribution_id,
       pll.cancel_flag,
       pll.closed_code,
       pll.shipment_type
    from   po_headers_all ph,
       po_line_locations_all pll,
       po_distributions_all pd
    where  ph.po_header_id = ##$$POID$$##
    AND ph.po_header_id = pll.po_header_id  -- Only Standard and Contracts
    AND (NVL(pll.closed_code,''OPEN'') IN (''CLOSED'',
                                        ''FINALLY CLOSED'',
                                        ''CLOSED FOR RECEIVING'')
             OR NVL(pll.cancel_flag,''N'') = ''Y'')
    AND pll.line_location_id = pd.line_location_id
    AND NVL(pll.approved_flag,''N'') = ''Y''
    and pll.shipment_type in (''STANDARD'',
                                 -- ''BLANKET'',   -- release for BPA
                                 -- ''SCHEDULED'', -- Release for Planned PO
                                 ''PLANNED'')  -- Planned PO 
    AND EXISTS (SELECT 1
                   FROM   mtl_supply ms
                   WHERE  PD.PO_DISTRIBUTION_ID = MS.SUPPLY_SOURCE_ID
                          and ms.supply_type_code = ''PO'')
    union all -- Check on Blanket releases and Planned releases
    select ph.segment1, 
       pr.release_num,
       pd.po_header_id,
       pd.po_line_id,
       pd.line_location_id,
       pd.po_release_id,
       pd.po_distribution_id,
       pll.cancel_flag,
       pll.closed_code,
       pll.shipment_type
    from   po_headers_all ph,
       po_releases_all pr,
       po_line_locations_all pll,
       po_distributions_all pd
    where ph.po_header_id = ##$$POID$$##
    AND ph.po_header_id = pll.po_header_id
    and pll.po_header_id = pr.po_header_id
    and pr.po_release_id = pll.po_release_id
    and pr.po_release_id = pd.po_release_id
    and pd.line_location_id = pll.line_location_id
    AND pr.authorization_status = ''APPROVED''
    AND (NVL(pll.closed_code,''OPEN'') IN (''CLOSED'',
                                        ''FINALLY CLOSED'',
                                        ''CLOSED FOR RECEIVING'')
             OR NVL(pll.cancel_flag,''N'') = ''Y'')
    and nvl(pll.approved_flag,''N'') = ''Y''
    AND pll.shipment_type IN (--''STANDARD'',
                                 ''BLANKET'',
                                 ''SCHEDULED''
                                 --''PLANNED''
                                 )
    AND EXISTS (SELECT 1
                   FROM   mtl_supply ms
                   where  pd.po_distribution_id = ms.supply_source_id
                          and ms.supply_type_code = ''PO'')',
   'Existing Incorrect Supply for Po Documents',
   'RS',
   'Found Supply for PO whose closed code is IN "CLOSED","CLOSED FOR RECEIVING","FINALLY CLOSED" or PO is cancelled',
   'Log a service request requesting datafix for this issue. Provide the output of this analyzer', -- to check on documentation
   'No incorrect supply found. Test passed', 
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');     
   
  

  ----------------------------------------------
  --  Incorrect contact id for PO
  ----------------------------------------------
    
   l_info.delete;
   add_signature(
   'PODATACORRUPTION_17',
   'select pha.po_header_id,	
       pha.segment1,
       pha.document_creation_method,
       pha.vendor_id,
       pha.vendor_site_id,
       pha.Vendor_Contact_Id	Wrong_Contact_Id,
       (
	      select min(prl.vendor_contact_id)
	      from po_line_locations_all pll,
		         po_requisition_lines_all prl
	      where pll.po_header_id = pha.po_header_id
	      and pll.line_location_id = prl.line_location_id
	      AND prl.vendor_id = pha.vendor_id
	      and prl.vendor_site_id = pha.vendor_site_id
	      and prl.vendor_contact_id is not null	     
       ) correct_contact_id
   FROM	 po_Headers_All pha,
	 po_Vendor_Sites_All pvsa,
	 po_vendor_contacts pvc
   where  pha.po_header_id = ##$$POID$$##
   AND pha.Type_LookUp_Code = ''STANDARD''
   AND pha.Vendor_Site_Id = pvsa.Vendor_Site_Id
   AND pha.Vendor_Contact_Id = pvc.Vendor_Contact_Id
   AND pha.Vendor_Site_Id != pvc.Vendor_Site_Id
   and exists ( select ''Req Exists''
       FROM po_line_locations_all pll,
			 po_requisition_lines_all prl
		   where pll.po_header_id = pha.po_header_id
	     and pll.line_location_id = prl.line_location_id )',
   'Incorrect Contact Id for Purchase Order',
   'RS',
   'PO contact id got currupted during autocreate',
   'Log a service request to get a datafix for this issue',
   'No invalid contact id found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');  
 
      
   
  ----------------------------------------------
  --  Quantity_commited wrongly defaulted
  ----------------------------------------------
             
      l_info.delete;
   add_signature(
   'PODATACORRUPTION_19',
   'SELECT  h.authorization_status,
            h.org_id,
            l.line_num,
            l.po_line_id,
            l.last_update_date,
            l.quantity_committed
        FROM    PO_LINES_ALL l,
                PO_HEADERS_ALL h
        WHERE   h.po_header_id                    = ##$$POID$$##
          AND h.po_header_id = l.po_header_id
          AND   l.quantity_committed IS NOT NULL
          AND   Nvl(l.Closed_Code,''OPEN'')         <> ''FINALLY CLOSED''
          AND   h.TYPE_LOOKUP_CODE                =   ''STANDARD''',
   'Quantity_commited Wrongly Defaulted',
   'RS',
   'Found lines with quantity_committed wrongly defaulted for SPO instead of leaving it NULL',
   'Problems is described in  [2041404.1]',
   'No issue found. Test passed',
   'ALWAYS',
   'W',
   'RS',
   'Y',
   p_include_in_dx_summary => 'Y');
   
   
  ----------------------------------------------
  --  Zero stamped amount or quantity PO distributions
  ----------------------------------------------
  
    l_info.delete;
    add_signature(
    'PODATACORRUPTION_20',
    'SELECT
     PO.PO_LINE_ID,
     PO.LINE_LOCATION_ID,
     PO.PO_DISTRIBUTION_ID
     FROM PO_DISTRIBUTIONS_ALL PO
     WHERE PO.PO_DISTRIBUTION_ID IN (
         SELECT POD.PO_DISTRIBUTION_ID
         FROM PO_LINE_LOCATIONS_ALL PLL, PO_DISTRIBUTIONS_ALL POD
         WHERE pod.po_header_id =  ##$$POID$$##
     and PLL.LINE_LOCATION_ID = POD.LINE_LOCATION_ID
         AND POD.DISTRIBUTION_TYPE = ''STANDARD''
         AND (
                 (PLL.MATCHING_BASIS = ''QUANTITY'' AND POD.QUANTITY_ORDERED = 0)
                 OR
                 (PLL.MATCHING_BASIS = ''AMOUNT'' AND POD.AMOUNT_ORDERED = 0)
             )
        )',
    'Zero Stamped Amount or Quantity Purchase Order Distributions',
    'RS',
    'Found distribution lines with quantity or amount stamped with zero',
    'Problems is described in [2049185.1]',
    'No issue found. Test passed',
    'ALWAYS',
    'W',
    'RS',
    'Y',
    p_include_in_dx_summary => 'Y');


  --------------------------------------------------
  -- Document Numbering setup preventing autocreate
  --------------------------------------------------
  
      l_info.delete;
    add_signature(
    'AUTOCREATE_NUMBERING',
    'SELECT decode(PoUniqueIdentifierContEO.TABLE_NAME,''PO_HEADERS'',''PO Number'') "Document",
         PoSystemParameterEO.USER_DEFINED_PO_NUM_CODE "Entry",
         PoSystemParameterEO.MANUAL_PO_NUM_TYPE "Type",
         PoUniqueIdentifierContEO.CURRENT_MAX_UNIQUE_IDENTIFIER "Current Number"
     FROM PO_UNIQUE_IDENTIFIER_CONT_ALL PoUniqueIdentifierContEO,
         PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO
     WHERE PoSystemParameterEO.org_id = ##$$ORGID$$##
     AND PoUniqueIdentifierContEO.ORG_ID = PoSystemParameterEO.org_id
     AND PoUniqueIdentifierContEO.table_name in (''PO_HEADERS'')
     AND PoSystemParameterEO.USER_DEFINED_PO_NUM_CODE = ''ALPHANUMERIC''
     AND PoSystemParameterEO.MANUAL_PO_NUM_TYPE = ''NUMERIC''',
    'Incorrect Purchasing Numbering Setup for Autocreate',
    'RS',
    'Found Incorrect Purchasing Numbering setup for Autocreate to be successful.',
    'Solution is described in [1409466.1]',
    'No issue found. Test passed',
    'ALWAYS',
    'E',
    'RS',
    'Y',
    p_include_in_dx_summary => 'Y');
  
  
  
    
  ---------------------------------------------
  -- Doc Standard Clause
  ---------------------------------------------
  l_info.delete;
  add_signature(
     'Doc_Standard_clauses', -- Unique Signature identifier
     'SELECT art.article_number "Clause Number"
            ,art.article_title  "Clause Title"
            ,ver.display_name   "Clause Name"
            ,NVL(edited_in_word, ''No'')     "Edited in Word?"
      FROM okc_articles_all art, okc_article_versions ver, okc_k_Articles_b  kart
      WHERE art.article_id = ver.article_id
      AND ver.article_version_id = kart.article_version_id
      AND art.standard_yn = ''Y''
      AND (kart.document_type   = ''PO_STANDARD'' or kart.document_type   = ''PA_BLANKET'')
      AND kart.document_id = ##$$POID$$##', -- The text of the signature query
      'Standard Clauses', -- Signature title
      'NRS',-- fail condition: RS, NRS, [col] operand [val]
      'Document Standard Clauses',     -- Problem description
      NULL,     -- Problem solution
     'Here is the list of document Standard Clauses',      -- Message on success
      'SUCCESS',  -- print condition: ALWAYS, SUCCESS, FAILURE, NEVER
      'I',       -- Warn(W), Err(E), Info(I)
      'RS',      -- Y/N/RS - when to print data;
      p_include_in_dx_summary => 'Y');



  ---------------------------------------------
  -- Non Standard Clause
  ---------------------------------------------
l_info.delete;
  add_signature(
   'Doc_NON_Standard_clauses', -- Unique Signature identifier
   'SELECT art.article_number "Clause Number"
          ,art.article_title  "Clause Title"
          ,ver.display_name   "Clause Name"
          ,NVL(edited_in_word, ''No'')     "Edited in Word?"
    FROM okc_articles_all art, okc_article_versions ver, okc_k_Articles_b  kart
    WHERE art.article_id = ver.article_id
    AND ver.article_version_id = kart.article_version_id
    AND art.standard_yn = ''N''
    AND (kart.document_type   = ''PO_STANDARD'' or kart.document_type   = ''PA_BLANKET'')
    AND kart.document_id = ##$$POID$$##', -- The text of the signature query
    'Non Standard Clauses', -- Signature title
    'NRS',-- fail condition: RS, NRS, [col] operand [val]
    'Document Non Standard Clauses',     -- Problem description
    NULL,     -- Problem solution
    'Here is the list of document Non-Standard Clauses',      -- Message on success
    'SUCCESS',  -- print condition: ALWAYS, SUCCESS, FAILURE, NEVER
    'I',       -- Warn(W), Err(E), Info(I)
    'RS',      -- Y/N/RS - when to print data;
    p_include_in_dx_summary => 'Y');

    
     
  -------------------------------------------------------------------
  -- Education Check - Createpo attributes check
  --------------------------------------------------------------------  

 l_info.delete;
 l_info('Details') := 'A Count of 3 means that all CREATEPO attributes have been set. The Purchase Order will automatically be created, approved and released'; 
  add_signature(
   'CREATEPO_ATTRIBUTES_CHECK',
   'SELECT  count (*) "NO_OF_ATTRIBUTES_SET_TO_YES"
    FROM (
                  select rtrim(w.name) name, 
                        w.text_default Value, 
                        rtrim(w.item_type) item_type, 
                        ''Should Workflow Create The Release?'' Attribute
                  from   wf_item_attributes w
                  where  w.NAME = ''CONT_WF_FOR_AC_REL_GEN''
                  and item_type = ''CREATEPO''
                  and w.text_default = ''Y''
                  union  
                  select rtrim(w.name) name, 
                        w.text_default Value, 
                        rtrim(w.item_type) item_type, 
                        ''Is Automatic Creation Allowed?'' Attribute
                  from wf_item_attributes w
                  where w.NAME = ''AUTOCREATE_DOC''
                  and item_type = ''CREATEPO''
                  and w.text_default = ''Y''
                  union 
                  select rtrim(w.name) name, 
                        w.text_default Value, 
                        rtrim(w.item_type) item_type, 
                        ''Is Automatic Approval Allowed?'' Attribute
                  from   wf_item_attributes w
                  where  w.NAME = ''AUTO_APPROVE_DOC''
                  and item_type = ''CREATEPO''
                  and w.text_default = ''Y''
        )',
   'CREATEPO Attributes Check',        
   '[NO_OF_ATTRIBUTES_SET_TO_YES] < [3]',
   'Createpo Attributes not all set to Yes.',
   '<ul>
   <li> Review Note - How To Diagnose Issues In Autocreate (CREATEPO) Workflow [559009.1]</li>
   </ul>',
   '<ul>
     <li> Currently your setup will allow for automatic PO creation/approval as all createpo attributes have been enabled and the autocreate workflow is setup for PO create documents.</li>
    </ul>',
   'ALWAYS',
    'E',
    'RS',
    'Y',
    l_info,
    VARCHAR_TBL('CREATEPO_ATTRIBUTES'),
    p_include_in_dx_summary => 'Y');
         

   
  
  -------------------------------------------------------------------
  -- Education Check - Createpo attributes details
  --------------------------------------------------------------------  

 l_info.delete;
  add_signature(
   'CREATEPO_ATTRIBUTES',
   'SELECT              rtrim(w.name) name, 
                        w.text_default Value, 
                        rtrim(w.item_type) item_type, 
                        ''Should Workflow Create The Release?'' Attribute
                  from   wf_item_attributes w
                  where  w.NAME = ''CONT_WF_FOR_AC_REL_GEN''
                  and item_type = ''CREATEPO''
                  union  
                  select rtrim(w.name) name, 
                        w.text_default Value, 
                        rtrim(w.item_type) item_type, 
                        ''Is Automatic Creation Allowed?'' Attribute
                  from wf_item_attributes w
                  where w.NAME = ''AUTOCREATE_DOC''
                  and item_type = ''CREATEPO''
                  union 
                  select rtrim(w.name) name, 
                        w.text_default Value, 
                        rtrim(w.item_type) item_type, 
                        ''Is Automatic Approval Allowed?'' Attribute
                  from   wf_item_attributes w
                  where  w.NAME = ''AUTO_APPROVE_DOC''
                  and item_type = ''CREATEPO''',
   'CREATEPO Attributes Details',                  
   'NRS',
   'Createpo Attributes not all set to Yes.',
   '<ul>
      <li> 1) if you want both Std POs or Blanket Releases created automatically, you have to have the following set to Y :   Is 
      Automatic Creation Allowed?  and Should Workflow Create The Release? </li>
      <li> 2) If you want Std POs created automatically but you dont want Blanekt Releases created automatically, you need to set  Is 
      Automatic Creation Allowed?  = Y  and Should Workflow Create The Release? = N </li>
      <li> 3) If you dont want any documents created automatically set them both to N  </li>
      <li> 4) Unfortunately, if you want Blanket Releases created automatically but you dont want Standard POs, its not possible.  This 
      would be setting Is Automatic Creation Allowed? = N and once that happens the worklfow ends without getting to 
      Should Workflow Create The Release?  </li>
      <li> 5) The last part is the automatic approval, which is an all or nothing setting (for Std POs and Blkt Releases) -- if you want  
       automatically created documents automatically submitted for approval, then set Is Automatic Approval Allowed? = Y , if  
       not set it to N (some customers dont want these created POs automatically submitted for approval)  </li>
   </ul>',
   'All Createpo Attributes Have Been Defined.',
   'ALWAYS',
    'I',
    'RS',
    'Y',
    p_include_in_dx_summary => 'Y');
  
  
  

/*#################################################
  #  R F Q  S i g s                               #
  #################################################*/

  
  ------------------------------------
  -- Display RFQ Header Details
  ------------------------------------
  l_info.delete;
  add_signature(
   'RFQ_HEADER_DETAILS',
   'SELECT po_header_id header_id,
           segment1 rfq_number,
           approved_flag,
           approved_date,
           approval_required_flag,
           authorization_status,
           cancel_flag,
           org_id,
           submit_date,
           summary_flag,
           enabled_flag,
           vendor_id,
           currency_code,
           rate_type,
           rate_date,
           rate,
           blanket_total_amount,
           authorization_status,
           revision_num,
           revised_date,
           amount_limit,
           min_release_amount,
           closed_date,
           approval_required_flag,
           interface_source_code,
           wf_item_type,
           wf_item_key,
           global_agreement_flag,
           encumbrance_required_flag,
           document_creation_method,
           style_id,
           creation_date,
           last_update_date,
           last_updated_by
    FROM po_headers_all
    WHERE po_header_id = ##$$RFQID$$##,
    AND   TYPE_LOOKUP_CODE = ''RFQ''',
   'RFQ Header Details',
   'NRS',
   'No document header found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'E',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('RFQ_LINE_DETAILS',
     'RFQ_LINE_LOCATIONS_DETAILS'),
     p_include_in_dx_summary => 'Y');
  
  
  ------------------------------------
  -- Display RFQ Line Details
  ------------------------------------
   l_info.delete;
  add_signature(
   'RFQ_LINE_DETAILS',
   'SELECT l.line_num,
           l.po_line_id,
           l.item_id,
           substr(msi.segment1,1,40) item_number,
           l.item_revision,
           l.item_description,
           l.category_id,
           mca.concatenated_segments item_category,
           lt.line_type,
           lt.outside_operation_flag,
           l.list_price_per_unit,
           l.unit_price,
           l.quantity,
           l.unit_meas_lookup_code,
           l.amount,
           l.taxable_flag,
           l.tax_name,
           l.closed_code,
           l.cancel_flag,
           l.closed_flag,
           l.cancelled_by,
           l.cancel_date,
           l.closed_code,
           l.not_to_exceed_price,
           l.allow_price_override_flag,
           l.price_break_lookup_code,
           l.tax_code_id,
           l.base_uom,
           l.base_qty,
           l.last_update_date,
           l.last_updated_by
    FROM po_lines_all l,
         po_line_types lt,
         mtl_system_items msi,
         financials_system_params_all fsp,
         mtl_categories_kfv mca
    WHERE l.po_header_id = ##$$RFQID$$##
    AND   fsp.org_id = l.org_id
    AND   msi.inventory_item_id (+) = l.item_id
    AND   nvl(msi.organization_id, fsp.inventory_organization_id) =
            fsp.inventory_organization_id
    AND   lt.line_type_id = l.line_type_id
    AND   mca.category_id  = l.category_id
    ORDER BY l.line_num',
   'RFQ Line Details',
   'NRS',
   'No document lines found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');
  
  
    ------------------------------------
  -- Display RFQ Line Location Details
  ------------------------------------
   l_info.delete;
  add_signature(
   'RFQ_LINE_LOCATIONS_DETAILS',
   'SELECT l.line_num po_line_num,
           ll.line_location_id,
           ll.shipment_num,
           ll.shipment_type,
           ll.quantity,
           ll.unit_meas_lookup_code uom,
           ll.price_override discounted_price,
           ll.taxable_flag,
           ll.tax_name,
           ll.tax_user_override_flag,
           ll.tax_code_id,
           ll.source_shipment_id,
           ll2.shipment_num source_shipment_num,
           ll.ship_to_organization_id,
           org.organization_code ship_to_organization_code,
           ll.ship_to_location_id,
           loc.location_code ship_to_location_code,
           ll.quantity_accepted,
           ll.quantity_billed,
           ll.quantity_cancelled,
           ll.quantity_received,
           ll.quantity_rejected,
           ll.amount,
           po_headers_sv3.get_currency_code(ll.po_header_id)
             currency_code,
           ll.last_accept_date,
           ll.need_by_date,
           ll.promised_date,
           ll.firm_status_lookup_code,
           ll.price_discount,
           ll.start_date,
           ll.end_date,
           ll.lead_time,
           ll.lead_time_unit,
           ll.terms_id,
           apt.name payment_terms_name,
           ll.freight_terms_lookup_code,
           ll.fob_lookup_code,
           ll.ship_via_lookup_code,
           ll.accrue_on_receipt_flag,
           ll.from_header_id,
           ll.from_line_id,
           ll.from_line_location_id,
           ll.encumbered_flag,
           ll.encumbered_date,
           ll.approved_flag,
           ll.approved_date,
           ll.closed_code,
           ll.cancel_flag,
           ll.cancel_date,
           ll.cancel_reason,
           ll.cancelled_by,
           ll.closed_flag,
           ll.closed_by,
           ll.closed_date,
           ll.closed_reason,
           ll.ussgl_transaction_code,
           ll.government_context,
           ll.match_option,
           ll.secondary_unit_of_measure,
           ll.secondary_quantity
    FROM po_line_locations_all ll,
         po_line_locations_all ll2,
         po_lines_all l,
         ap_terms apt,
         hr_locations_all_vl loc,
         org_organization_definitions org
    WHERE ll.po_header_id = ##$$RFQID$$##
    AND   l.po_line_id = ll.po_line_id
    AND   apt.term_id (+) = ll.terms_id
    AND   loc.location_id (+) = ll.ship_to_location_id
    AND   org.organization_id(+) = ll.ship_to_organization_id
    AND   ll2.line_location_id (+) = ll.source_shipment_id
    ORDER BY l.line_num',
   'RFQ Line Location Details',
   'NRS',
   'No line location records found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');
   
  
  -------------------------------------------------------------------
  -- RFQ Suppliers
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'RFQ_SUPPLIERS',
   'SELECT po_header_id,
           sequence_num,
           vendor_id,
           vendor_site_id,
           vendor_contact_id
    FROM PO_RFQ_VENDORS,
    WHERE po_header_id = ##$$RFQID$$##',
   'RFQ Vendors',
   'NRS',
   'No Vendors found for this RFQ',
   'Verify that Vendors have been invited',
   NULL,
   'ALWAYS',
   'E',
   p_include_in_dx_summary => 'Y');   


/*#################################################
  #  Q u o t a t i o n  S i g s                   #
  #################################################*/   

  ------------------------------------
  -- Display Quotation Header Details
  ------------------------------------
  l_info.delete;
  add_signature(
   'QUOTE_HEADER_DETAILS',
   'SELECT po_header_id header_id,
           segment1 rfq_number,
           approved_flag,
           approved_date,
           approval_required_flag,
           authorization_status,
           cancel_flag,
           org_id,
           submit_date,
           summary_flag,
           enabled_flag,
           vendor_id,
           currency_code,
           rate_type,
           rate_date,
           rate,
           blanket_total_amount,
           authorization_status,
           revision_num,
           revised_date,
           amount_limit,
           min_release_amount,
           closed_date,
           approval_required_flag,
           interface_source_code,
           wf_item_type,
           wf_item_key,
           global_agreement_flag,
           encumbrance_required_flag,
           document_creation_method,
           style_id,
           creation_date,
           last_update_date,
           last_updated_by
    FROM po_headers_all
    WHERE po_header_id = ##$$RFQID$$##,
    AND   TYPE_LOOKUP_CODE = ''QUOTATION''
    AND   FROM_TYPE_LOOKUP_CODE = ''RFQ''
    AND   STATUS_LOOKUP_CODE  IN (''I'', ''A'')',
   'Quote Header Details',
   'NRS',
   'No Active or incomplete Quote header found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'E',
   'RS',  
   'Y',
   l_info,
   VARCHAR_TBL('QUOTE_LINE_DETAILS',
     'QUOTE_LINE_LOCATIONS_DETAILS'),
     p_include_in_dx_summary => 'Y');





/*#################################################
  #  R e c e i p t  S i g s                       #
  #################################################*/   

  --------------------------------------------
  -- Display Receipt Details - PO with Release 12.2
  --------------------------------------------
  
  add_signature(
   'RECEIPT_DETAILS_REL_12_2',
   ' SELECT *
      FROM   (SELECT rsh.receipt_num,
              Decode(rsl.po_release_id, NULL, pha.clm_document_number,
                                  pha.clm_document_number
                                  || ''-''
                                  || pra.release_num) po_number,  
              pla.line_num,
              plla.shipment_num,
              CASE pla.order_type_lookup_code
                WHEN ''RATE'' THEN pj.name
                WHEN ''FIXED PRICE'' THEN pj.name
                ELSE (SELECT msi.concatenated_segments
                      FROM   mtl_system_items_kfv msi
                      WHERE  msi.inventory_item_id = rsl.item_id
                             AND msi.organization_id =
                                 plla.ship_to_organization_id)
              END                                           AS item,
              rsl.item_description,
              Decode(Nvl(plla.matching_basis, pla.matching_basis), ''AMOUNT'', pha.currency_code,
                                                                             rsl.unit_of_measure)  unit_of_measure,
              Decode(Nvl(plla.matching_basis, pla.matching_basis), ''AMOUNT'', (SELECT amount
                                                                              FROM po_line_locations_all
                                                                              WHERE line_location_id = rt.po_line_location_id),
                                                           ''QUANTITY'', (SELECT quantity
                                                                        FROM po_line_locations_all
                                                                        WHERE line_location_id = rt.po_line_location_id))   quantity_ordered, 
              ''''                                            AS RcptDtlsRetndSw,
              ''''                                            AS ReturnCode, 
              Decode(Nvl(plla.matching_basis, pla.matching_basis), ''AMOUNT'',
                                      (pos_po_rcv_qty.Get_net_rcv_amt(rt.shipment_line_id, rt.amount,rt.transaction_id) ),
                                       pos_po_rcv_qty.Get_net_qty_rcv(rt.shipment_line_id, rt.quantity,rt.transaction_id))     quantity_received,
              ''''                                            AS RcptDtlsDfctSw,
              ''''                                            AS DefectCode,  
              hrl1.location_code                            receipt_location,
              rt.transaction_date                           receipt_date,
              plla.promised_date,
              plla.need_by_date,
              Decode(Sign(Nvl(Trunc(plla.promised_date), Trunc(plla.need_by_date))
                  + plla.days_late_receipt_allowed - Trunc(rt.transaction_date)), -1,
                  fnd_message.Get_string(''PO'', ''PO_AC_LATE''),
              Decode (Sign(
                  ( Nvl(Trunc(plla.promised_date), Trunc(plla.need_by_date)) - plla.days_early_receipt_allowed ) -
                        Trunc(rt.transaction_date)), 1, fnd_message.Get_string(''POS'', ''POS_EARLY''),
                  fnd_message.Get_string(''POS'', ''POS_ONTIME''))) PerformanceCode,
              rsl.shipment_header_id,
              rsl.shipment_line_id,
              rsl.po_header_id,
              rsl.po_release_id,
              rsl.po_line_id,
              rsl.po_line_location_id,
              rsl.item_id,
              pha.vendor_id,
              pha.vendor_site_id,
              pha.vendor_contact_id,
              rsl.vendor_item_num,
              Nvl(plla.promised_date, plla.need_by_date)    due_date,
              plla.days_early_receipt_allowed,
              plla.days_late_receipt_allowed,
              rsl.po_distribution_id,
              ''''                                            AS RcptDtlsLLSsw,
              ''''                                            AS LLSCode,
              ''''                                            Invoice_num,
              rsl.requisition_line_id,
              rsl.category_id,
              mcv.concatenated_segments                     category,
              rsl.destination_type_code,
              rsl.to_subinventory                           subinventory,
              rsl.comments                                  shipment_receiver_notes,
              rsl.quantity_shipped,
              rsl.item_revision,
              rsl.vendor_lot_num,
              rsl.packing_slip,
              rsl.bar_code_label,
              ''''                                            Invoice_Id,
              ''''                                            Invoice_Switch,
              plla.ship_to_location_id,
              rt.transaction_id,
              rt.interface_transaction_id,
              pla.supplier_ref_number,
              Decode(PLA.clm_undef_flag, ''Y'', ''Undef'',
                                         ''Def'')             undef_sts,
              ''''                                            qty_ord_swr,
              pla.order_type_lookup_code
       FROM   rcv_shipment_lines rsl,
              po_headers_all pha,
              rcv_shipment_headers rsh,
              po_releases_all pra,
              po_lines_all pla,
              po_line_locations_all plla,
              mtl_categories_b_kfv mcv,
              hr_locations_all_tl hrl1,
              rcv_transactions rt,
              per_jobs pj
       WHERE  rt.shipment_line_id = rsl.shipment_line_id
              AND rsl.shipment_header_id = rsh.shipment_header_id
              AND rt.transaction_type IN ( ''RECEIVE'', ''MATCH'' )
              AND rsl.po_header_id = pha.po_header_id
              AND pra.po_release_id(+) = rt.po_release_id
              AND pla.po_line_id = rsl.po_line_id
              AND plla.line_location_id = rsl.po_line_location_id
              AND rsl.category_id = mcv.category_id
              AND hrl1.location_id (+) = rt.location_id
              AND hrl1.LANGUAGE (+) = Userenv(''LANG'')
              AND pj.job_id(+) = pla.job_id) QRSLT
      WHERE  ( po_header_id = ##$$POID$$##
               AND po_release_id = ##$$PORELID$$##)
               ORDER  BY line_num,shipment_num ASC',
   'Receipt Details',
   'NRS',
   'No receipt details found',
   NULL,
   'Receipt details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');   



  --------------------------------------------
  -- Display Receipt Details - PO with Release 12.1
  --------------------------------------------
  
  add_signature(
   'RECEIPT_DETAILS_REL_12_1',
   ' SELECT *
      FROM   (SELECT rsh.receipt_num,
                      rsl.shipment_header_id,
                      rsl.shipment_line_id,
                      rsl.po_header_id,
                      rsl.po_release_id,
                      rsl.po_line_id,
                      rsl.po_line_location_id,
                      rsl.item_id,
                      pla.line_num,
                      plla.shipment_num,
                      DECODE(rsl.PO_release_id,
                      null,
                      pha.segment1,
                      pha.segment1 || ''-'' || pra.release_num) po_number,
                      pha.vendor_id,
                      pha.vendor_site_id,
                      pha.vendor_contact_id,
                      CASE pla.order_type_lookup_code 
                         WHEN ''RATE'' THEN pj.name 
                         WHEN ''FIXED PRICE'' THEN pj.name 
                         ELSE (SELECT
                            msi.concatenated_segments 
                         FROM
                            mtl_system_items_kfv msi 
                         WHERE
                            msi.inventory_item_id = rsl.item_id 
                            AND msi.organization_id = plla.ship_to_organization_id ) 
                      END AS item,
                      rsl.item_description ,
                      rsl.vendor_item_num,
                      decode(nvl(plla.matching_basis,
                      pla.matching_basis),
                      ''AMOUNT'',
                      pha.currency_code,
                      rsl.unit_of_measure) unit_of_measure,
                      Decode(Nvl(plla.matching_basis,
                      pla.matching_basis),
                      ''AMOUNT'',
                      (SELECT
                         amount 
                      FROM
                         po_line_locations_all 
                      WHERE
                         line_location_id = rt.po_line_location_id),
                      ''QUANTITY'',
                      (SELECT
                         quantity 
                      FROM
                         po_line_locations_all 
                      WHERE
                         line_location_id = rt.po_line_location_id)) quantity_ordered,
                      Decode(Nvl(plla.matching_basis,
                      pla.matching_basis),
                      ''AMOUNT'',
                      (POS_PO_RCV_QTY.get_net_rcv_amt(rt.shipment_line_id,
                      rt.amount,
                      rt.transaction_id)),
                      POS_PO_RCV_QTY.get_net_qty_rcv(rt.shipment_line_id,
                      rt.quantity,
                      rt.transaction_id)) quantity_received,
                      nvl(plla.promised_date,
                      plla.need_by_date) due_date,
                      plla.days_early_receipt_allowed,
                      plla.days_late_receipt_allowed,
                      rt.Transaction_date receipt_date,
                      hrl1.location_code receipt_location,
                      rsl.po_distribution_id,
                      '''' as RcptDtlsRetndSw,
                      '''' as ReturnCode,
                      '''' as RcptDtlsDfctSw,
                      '''' as DefectCode,
                      '''' as RcptDtlsLLSsw,
                      '''' as LLSCode,
                      '''' Invoice_num,
                      '''' as Acceptedcode,
                      decode(sign(nvl(Trunc(plla.promised_date),
                      Trunc(plla.need_by_date))+plla.days_late_receipt_allowed - Trunc(rt.transaction_date)),
                      -1,
                      fnd_message.get_string(''PO'',
                      ''PO_AC_LATE''),
                      decode (sign((nvl(Trunc(plla.promised_date),
                      Trunc(plla.need_by_date)) - plla.days_early_receipt_allowed) - Trunc(rt.transaction_date)),
                      1,
                      fnd_message.get_string(''POS'',
                      ''POS_EARLY''),
                      fnd_message.get_string(''POS'',
                      ''POS_ONTIME''))) PerformanceCode,
                      rsl.requisition_line_id,
                      rsl.category_id,
                      mcv.concatenated_segments category,
                      rsl.destination_type_code,
                      rsl.to_subinventory subinventory,
                      rsl.comments shipment_receiver_notes,
                      rsl.quantity_shipped,
                      rsl.item_revision,
                      rsl.vendor_lot_num,
                      rsl.packing_slip,
                      rsl.bar_code_label,
                      '''' Invoice_Id,
                      '''' Invoice_Switch,
                      plla.ship_to_location_id,
                      plla.promised_date,
                      plla.need_by_date,
                      rt.transaction_id,
                      rt.interface_transaction_id,
                      pla.supplier_ref_number 
                   FROM
                      rcv_shipment_lines rsl,
                      po_headers_all pha,
                      rcv_shipment_headers rsh,
                      po_releases_all pra,
                      po_lines_all pla,
                      po_line_locations_all plla,
                      mtl_categories_b_kfv mcv,
                      hr_locations_all_tl hrl1,
                      rcv_transactions rt,
                      per_jobs pj 
                   WHERE
                      rt.shipment_line_id = rsl.shipment_line_id 
                      AND rsl.shipment_header_id = rsh.shipment_header_id 
                      AND rt.transaction_type in (
                         ''RECEIVE'',''MATCH''
                      ) 
                      AND rsl.po_header_id = pha.po_header_id 
                      AND pra.po_release_id(+) = rt.po_release_id 
                      AND pla.po_line_id = rsl.po_line_id 
                      AND plla.line_location_id = rsl.po_line_location_id 
                      AND rsl.category_id = mcv.category_id 
                      AND hrl1.location_id (+) = rt.location_id 
                      AND hrl1.language (+) = USERENV(''LANG'') 
                      AND pj.job_id(+) = pla.job_id
                   ) QRSLT 
                WHERE
                   (
                      PO_HEADER_ID = ##$$POID$$## 
                      and PO_RELEASE_ID = ##$$PORELID$$##)',
   'Receipt Details',
   'NRS',
   'No receipt details found',
   NULL,
   'Receipt details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');   


  ------------------------------------
  -- Display Receipt Details - STD PO 12.2
  ------------------------------------
  
  
  
  add_signature(
   'RECEIPT_DETAILS_STD_12_2',
   'SELECT *
    FROM   (SELECT rsh.receipt_num,
                      rsl.shipment_header_id,
                      rsl.shipment_line_id,
                      rsl.po_header_id,
                      rsl.po_release_id,
                      rsl.po_line_id,
                      rsl.po_line_location_id,
                      rsl.item_id,
                      pla.line_num,
                      plla.shipment_num,
                      DECODE(rsl.PO_release_id,
                      null,
                      pha.clm_document_number,
                      pha.clm_document_number || ''-'' || pra.release_num) po_number,
                      pha.vendor_id,
                      pha.vendor_site_id,
                      pha.vendor_contact_id,
                      CASE pla.order_type_lookup_code 
                          WHEN ''RATE'' THEN pj.name 
                          WHEN ''FIXED PRICE'' THEN pj.name 
                          ELSE (SELECT
                              msi.concatenated_segments 
                          FROM
                              mtl_system_items_kfv msi 
                          WHERE
                              msi.inventory_item_id = rsl.item_id 
                              AND msi.organization_id = plla.ship_to_organization_id ) 
                      END AS item,
                      rsl.item_description ,
                      rsl.vendor_item_num,
                      decode(nvl(plla.matching_basis,
                      pla.matching_basis),
                      ''AMOUNT'',
                      pha.currency_code,
                      rsl.unit_of_measure) unit_of_measure,
                      Decode(Nvl(plla.matching_basis,
                      pla.matching_basis),
                      ''AMOUNT'',
                      (SELECT
                          amount 
                      FROM
                          po_line_locations_all 
                      WHERE
                          line_location_id = rt.po_line_location_id),
                      ''QUANTITY'',
                      (SELECT
                          quantity 
                      FROM
                          po_line_locations_all 
                      WHERE
                          line_location_id = rt.po_line_location_id)) quantity_ordered,
                      Decode(Nvl(plla.matching_basis,
                      pla.matching_basis),
                      ''AMOUNT'',
                      (POS_PO_RCV_QTY.get_net_rcv_amt(rt.shipment_line_id,
                      rt.amount,
                      rt.transaction_id)),
                      POS_PO_RCV_QTY.get_net_qty_rcv(rt.shipment_line_id,
                      rt.quantity,
                      rt.transaction_id)) quantity_received,
                      nvl(plla.promised_date,
                      plla.need_by_date) due_date,
                      plla.days_early_receipt_allowed,
                      plla.days_late_receipt_allowed,
                      rt.Transaction_date receipt_date,
                      hrl1.location_code receipt_location,
                      rsl.po_distribution_id,
                      '''' as RcptDtlsRetndSw,
                      '''' as ReturnCode,
                      '''' as RcptDtlsDfctSw,
                      '''' as DefectCode,
                      '''' as RcptDtlsLLSsw,
                      '''' as LLSCode,
                      '''' Invoice_num,
                      decode(sign(nvl(Trunc(plla.promised_date),
                      Trunc(plla.need_by_date))+plla.days_late_receipt_allowed - Trunc(rt.transaction_date)),
                      -1,
                      fnd_message.get_string(''PO'',
                      ''PO_AC_LATE''),
                      decode (sign((nvl(Trunc(plla.promised_date),
                      Trunc(plla.need_by_date)) - plla.days_early_receipt_allowed) - Trunc(rt.transaction_date)),
                      1,
                      fnd_message.get_string(''POS'',
                      ''POS_EARLY''),
                      fnd_message.get_string(''POS'',
                      ''POS_ONTIME''))) PerformanceCode,
                      rsl.requisition_line_id,
                      rsl.category_id,
                      mcv.concatenated_segments category,
                      rsl.destination_type_code,
                      rsl.to_subinventory subinventory,
                      rsl.comments shipment_receiver_notes,
                      rsl.quantity_shipped,
                      rsl.item_revision,
                      rsl.vendor_lot_num,
                      rsl.packing_slip,
                      rsl.bar_code_label,
                      '' Invoice_Id,
                      '' Invoice_Switch,
                      plla.ship_to_location_id,
                      plla.promised_date,
                      plla.need_by_date,
                      rt.transaction_id,
                      rt.interface_transaction_id,
                      pla.supplier_ref_number,
                      Decode(PLA.CLM_UNDEF_FLAG,
                      ''Y'',
                      ''Undef'',
                      ''Def'') undef_sts,
                      '''' qty_ord_swr,
                      pla.order_type_lookup_code 
                  FROM
                      rcv_shipment_lines rsl,
                      po_headers_all pha,
                      rcv_shipment_headers rsh,
                      po_releases_all pra,
                      po_lines_all pla,
                      po_line_locations_all plla,
                      mtl_categories_b_kfv mcv,
                      hr_locations_all_tl hrl1,
                      rcv_transactions rt,
                      per_jobs pj 
                  WHERE
                      rt.shipment_line_id = rsl.shipment_line_id 
                      AND rsl.shipment_header_id = rsh.shipment_header_id 
                      AND rt.transaction_type in (
                          ''RECEIVE'',''MATCH''
                      ) 
                      AND rsl.po_header_id = pha.po_header_id 
                      AND pra.po_release_id(+) = rt.po_release_id 
                      AND pla.po_line_id = rsl.po_line_id 
                      AND plla.line_location_id = rsl.po_line_location_id 
                      AND rsl.category_id = mcv.category_id 
                      AND hrl1.location_id (+) = rt.location_id 
                      AND hrl1.language (+) = USERENV(''LANG'') 
                      AND pj.job_id(+) = pla.job_id
                  ) QRSLT 
              WHERE
                  (
                      PO_HEADER_ID = ##$$POID$$##)',
   'Receipt Details',
   'NRS',
   'No receipt details found',
   NULL,
   'Receipt details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');   



  ------------------------------------
  -- Display Receipt Details - STD PO 12.1
  ------------------------------------
  
  
  
  add_signature(
   'RECEIPT_DETAILS_STD_12_1',
   'SELECT *
    FROM   (SELECT  rsh.receipt_num,
                    rsl.shipment_header_id,
                    rsl.shipment_line_id,
                    rsl.po_header_id,
                    rsl.po_release_id,
                    rsl.po_line_id,
                    rsl.po_line_location_id,
                    rsl.item_id,
                    pla.line_num,
                    plla.shipment_num,
                    DECODE(rsl.PO_release_id,
                    null,
                    pha.segment1,
                    pha.segment1 || ''-'' || pra.release_num) po_number,
                    pha.vendor_id,
                    pha.vendor_site_id,
                    pha.vendor_contact_id,
                    CASE pla.order_type_lookup_code 
                       WHEN ''RATE'' THEN pj.name 
                       WHEN ''FIXED PRICE'' THEN pj.name 
                       ELSE (SELECT
                          msi.concatenated_segments 
                       FROM
                          mtl_system_items_kfv msi 
                       WHERE
                          msi.inventory_item_id = rsl.item_id 
                          AND msi.organization_id = plla.ship_to_organization_id ) 
                    END AS item,
                    rsl.item_description ,
                    rsl.vendor_item_num,
                    decode(nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    pha.currency_code,
                    rsl.unit_of_measure) unit_of_measure,
                    Decode(Nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    (SELECT
                       amount 
                    FROM
                       po_line_locations_all 
                    WHERE
                       line_location_id = rt.po_line_location_id),
                    ''QUANTITY'',
                    (SELECT
                       quantity 
                    FROM
                       po_line_locations_all 
                    WHERE
                       line_location_id = rt.po_line_location_id)) quantity_ordered,
                    Decode(Nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    (POS_PO_RCV_QTY.get_net_rcv_amt(rt.shipment_line_id,
                    rt.amount,
                    rt.transaction_id)),
                    POS_PO_RCV_QTY.get_net_qty_rcv(rt.shipment_line_id,
                    rt.quantity,
                    rt.transaction_id)) quantity_received,
                    nvl(plla.promised_date,
                    plla.need_by_date) due_date,
                    plla.days_early_receipt_allowed,
                    plla.days_late_receipt_allowed,
                    rt.Transaction_date receipt_date,
                    hrl1.location_code receipt_location,
                    rsl.po_distribution_id,
                    '''' as RcptDtlsRetndSw,
                    '''' as ReturnCode,
                    '''' as RcptDtlsDfctSw,
                    '''' as DefectCode,
                    '''' as RcptDtlsLLSsw,
                    '''' as LLSCode,
                    '''' Invoice_num,
                    '''' as Acceptedcode,
                    decode(sign(nvl(Trunc(plla.promised_date),
                    Trunc(plla.need_by_date))+plla.days_late_receipt_allowed - Trunc(rt.transaction_date)),
                    -1,
                    fnd_message.get_string(''PO'',
                    ''PO_AC_LATE''),
                    decode (sign((nvl(Trunc(plla.promised_date),
                    Trunc(plla.need_by_date)) - plla.days_early_receipt_allowed) - Trunc(rt.transaction_date)),
                    1,
                    fnd_message.get_string(''POS'',
                    ''POS_EARLY''),
                    fnd_message.get_string(''POS'',
                    ''POS_ONTIME''))) PerformanceCode,
                    rsl.requisition_line_id,
                    rsl.category_id,
                    mcv.concatenated_segments category,
                    rsl.destination_type_code,
                    rsl.to_subinventory subinventory,
                    rsl.comments shipment_receiver_notes,
                    rsl.quantity_shipped,
                    rsl.item_revision,
                    rsl.vendor_lot_num,
                    rsl.packing_slip,
                    rsl.bar_code_label,
                    '''' Invoice_Id,
                    '''' Invoice_Switch,
                    plla.ship_to_location_id,
                    plla.promised_date,
                    plla.need_by_date,
                    rt.transaction_id,
                    rt.interface_transaction_id,
                    pla.supplier_ref_number 
                 FROM
                    rcv_shipment_lines rsl,
                    po_headers_all pha,
                    rcv_shipment_headers rsh,
                    po_releases_all pra,
                    po_lines_all pla,
                    po_line_locations_all plla,
                    mtl_categories_b_kfv mcv,
                    hr_locations_all_tl hrl1,
                    rcv_transactions rt,
                    per_jobs pj 
                 WHERE
                    rt.shipment_line_id = rsl.shipment_line_id 
                    AND rsl.shipment_header_id = rsh.shipment_header_id 
                    AND rt.transaction_type in (
                       ''RECEIVE'',''MATCH''
                    ) 
                    AND rsl.po_header_id = pha.po_header_id 
                    AND pra.po_release_id(+) = rt.po_release_id 
                    AND pla.po_line_id = rsl.po_line_id 
                    AND plla.line_location_id = rsl.po_line_location_id 
                    AND rsl.category_id = mcv.category_id 
                    AND hrl1.location_id (+) = rt.location_id 
                    AND hrl1.language (+) = USERENV(''LANG'') 
                    AND pj.job_id(+) = pla.job_id
                 ) QRSLT 
              WHERE
                 (
                    PO_HEADER_ID = ##$$POID$$##)',
   'Receipt Details',
   'NRS',
   'No receipt details found',
   NULL,
   'Receipt details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');   



  ------------------------------------
  -- Mismatched shipment_header_id
  ------------------------------------
  
  add_signature(
   'MISMATCH_SHIPMENT_HEADER_ID',
   'SELECT distinct rsh1.*
    FROM   rcv_shipment_headers rsh1,
           rcv_shipment_headers rsh2
    WHERE  rsh1.receipt_source_code = rsh2.receipt_source_code
    AND    rsh1.receipt_source_code IN (''INTERNAL ORDER'',''INVENTORY'')
    AND    rsh1.ship_to_org_id = rsh2.ship_to_org_id
    AND    rsh1.shipment_num = rsh2.shipment_num
    AND    rsh1.shipment_header_id <> rsh2.shipment_header_id
    UNION
    SELECT distinct rsh.*
    FROM   rcv_transactions     rt,
           rcv_shipment_lines   rsl,
           rcv_shipment_headers rsh
    WHERE  rt.shipment_line_id = rsl.shipment_line_id
    AND    rsl.shipment_header_id = rsh.shipment_header_id
    AND    rsl.shipment_line_status_code IN (''FULLY RECEIVED'', ''PARTIALLY RECEIVED'')
    AND    rt.shipment_header_id <> rsl.shipment_header_id
    AND    NOT EXISTS (select 1 
                       from   rcv_shipment_headers rtrsh
                       where  rtrsh.shipment_header_id = rt.shipment_header_id
                       and    rtrsh.receipt_source_code = rsh.receipt_source_code
                       and    rtrsh.ship_to_org_id = rsh.ship_to_org_id)
    UNION                   
    SELECT distinct
           rsh.*
    FROM   rcv_shipment_headers      rsh,
           rcv_shipment_lines        rsl,
           mtl_material_transactions mmt
    WHERE  rsh.shipment_header_id = rsl.shipment_header_id
    AND    rsl.mmt_transaction_id = mmt.transaction_id
    AND    mmt.organization_id = rsl.from_organization_id
    AND    mmt.transfer_organization_id = rsl.to_organization_id
    AND    rsl.source_document_code in (''INVENTORY'' ,''REQ'')
    AND    ( rsh.receipt_source_code <> decode (rsl.source_document_code,''INVENTORY'',''INVENTORY'', ''REQ'', ''INTERNAL ORDER'')
             or
             rsh.ship_to_org_id <> rsl.to_organization_id 
             or
             rsh.organization_id <> rsl.from_organization_id)
    UNION
    SELECT rsh.*
    FROM   rcv_shipment_headers  rsh, 
           rcv_shipment_lines    rsl
    WHERE rsl.shipment_header_id = rsh.shipment_header_id
    AND   rsh.receipt_source_code <> decode (rsl.source_document_code,''RMA'',''CUSTOMER'',''PO'',''VENDOR'')',
   'Corrupted Records with Mismatched shipment_header_id',
   'RS',
   'Corrupted records with mismatched shipment_header_id have been found',
   '<ul>
      <li> For the datafix please see [1198144.1] - RCVTXERT APP-PO-14094 FRM-40212 Multiple Receipt For Intransit Shipment Gives Corrupted Shipment_Header_ID / Receipt Record Cannot be seen RCVRCVRC / Duplicate Shipment Number RCVTXERT</li>
   </ul>',
   'No Corrupted records with mismatched shipment_header_id found',
   'ALWAYS',
   'E',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y'); 
   
   
   

  ------------------------------------
  -- Matching basis = AMOUNT
  ------------------------------------
  
  add_signature(
   'MATCHING_BASIS_AMOUNT',
   'SELECT PLL.PO_HEADER_ID,
           PLL.LINE_LOCATION_ID,
           PLL.MATCHING_BASIS
    FROM PO_LINE_LOCATIONS_all PLL,
         PO_HEADERS_ALL PH
    WHERE PLL.PO_HEADER_ID = PH.PO_HEADER_id
    AND PH.SEGMENT1 = ''##$$PONUM$$##''
    AND PLL.MATCHING_BASIS = ''AMOUNT''',
   'Receipts/Return/Correction for Services',
   'RS',
   'Receipts/Return/Correction for services have been found',
   '<ul>
      <li> Receipts/Return/Correction for services will be allowed through only iProcurement application and not through core-applications receipt forms. </li>
      <li>See [399153.1] - APP-PO-14094: Not Able To Enter Receipts / Returns / Corrections For Amount Based Line Types or Rate Based Temp Labor PO 
   </ul>',
   'No Receipts/Return/Correction for services records found',
   'ALWAYS',
   'W',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y');    
   

  -----------------------------------------
  -- Encumbrance enabled after po approval - Standard PO
  -----------------------------------------
  
  add_signature(
   'ENCUMBRANCE_AFTER_PO_APPROVAL_STD',
   'SELECT HOU.name,
          FSP.PURCH_ENCUMBRANCE_FLAG,
          POH.SEGMENT1,
          POH.PO_HEADER_ID,
          POH.ORG_ID,
          POH.TYPE_LOOKUP_CODE,
          POH.APPROVED_FLAG "POH.APPROVED_FLAG",
          POH.AUTHORIZATION_STATUS "POH Status",
          POH.CANCEL_FLAG "POH.CANCEL_FLAG",
          POH.CHANGE_REQUESTED_BY "Change Req",
          POH.WF_ITEM_TYPE "Type",
          POH.WF_ITEM_KEY "Key",
          POR.PO_RELEASE_ID,
          POR.RELEASE_NUM,
          POR.APPROVED_FLAG "POR.APPROVED_FLAG",
          POL.PO_LINE_ID,
          POL.LINE_NUM,
          POL.MATCHING_BASIS,
          PLL.LINE_LOCATION_ID,
          PLL.SHIPMENT_NUM,
          PLL.APPROVED_FLAG "PLL.APPROVED_FLAG",
          PLL.QUANTITY "PLL.QTY",
          PLL.QUANTITY_RECEIVED "PLL.QTY RCVD",
          PLL.CANCEL_FLAG "PLL.CANCEL_FLAG",
          PLL.QUANTITY_CANCELLED,
          PLL.CLOSED_CODE,
          PLL.ENCUMBERED_FLAG,
          PLL.SHIP_TO_ORGANIZATION_ID,
          MP.ORGANIZATION_CODE,
          POD.PO_DISTRIBUTION_ID,
          POD.DISTRIBUTION_NUM,
          POD.DESTINATION_TYPE_CODE,
          POD.QUANTITY_ORDERED "POD.QTY",
          POD.QUANTITY_DELIVERED "POD.QTY DLVD"
   FROM PO_HEADERS_ALL POH,
          PO_LINES_ALL POL,
          PO_LINE_LOCATIONS_ALL PLL,
          PO_DISTRIBUTIONS_ALL POD,
          PO_RELEASES_ALL POR,
          FINANCIALS_SYSTEM_PARAMS_ALL FSP,
          HR_ORGANIZATION_UNITS HOU,
          MTL_PARAMETERS MP
   WHERE POH.TYPE_LOOKUP_CODE = ''STANDARD''  -- Comment if for a Release
   AND POH.SEGMENT1 = ''##$$PONUM$$##''
   AND POH.TYPE_LOOKUP_CODE = ''STANDARD''  -- Comment if for a Release
   AND POL.PO_HEADER_ID = POH.PO_HEADER_ID
   AND PLL.PO_LINE_ID = POL.PO_LINE_ID
   AND POD.LINE_LOCATION_ID = PLL.LINE_LOCATION_ID
   AND POR.PO_RELEASE_ID(+) = PLL.PO_RELEASE_ID
   AND POH.ORG_ID = FSP.ORG_ID
   AND FSP.ORG_ID = HOU.ORGANIZATION_ID
   AND POH.ORG_ID = HOU.ORGANIZATION_ID
   AND MP.ORGANIZATION_ID = PLL.SHIP_TO_ORGANIZATION_ID
   AND FSP.PURCH_ENCUMBRANCE_FLAG = ''Y''
   AND PLL.ENCUMBERED_FLAG = ''N''
   ORDER BY POH.ORG_ID, POH.PO_HEADER_ID, POL.PO_LINE_ID, PLL.LINE_LOCATION_ID, POD.PO_DISTRIBUTION_ID',
   'Encumbrance enabled after po approval - Standard PO',
   'RS',
   'Encumbrance Enabled after Purchase Order Approval',
   'This issue can occur when:
        <ol><li>Deliver a Purchase Order in Receiving Transactions form (RCVTXERT)</li>
            <li>Correct a Receiving Transaction using the Receiving Corrections form (RCVTXECO)</li>
            <li>Return an item in the Receiving Returns form (RCVTXERE)</li></ol>
    See [958816.1] - Receiving Forms (RCVTXERT RCVTXECO RCVTXERE) Return APP-PO-14094: No Record Meet Your Search Criteria',
   'Encumbrance was not enabled after po approval',
   'ALWAYS',
   'E',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y');  



  -----------------------------------------
  -- Encumbrance enabled after po approval -  PO with release
  -----------------------------------------
  
  add_signature(
   'ENCUMBRANCE_AFTER_PO_APPROVAL_REL',
   'SELECT HOU.name,
          FSP.PURCH_ENCUMBRANCE_FLAG,
          POH.SEGMENT1,
          POH.PO_HEADER_ID,
          POH.ORG_ID,
          POH.TYPE_LOOKUP_CODE,
          POH.APPROVED_FLAG "POH.APPROVED_FLAG",
          POH.AUTHORIZATION_STATUS "POH Status",
          POH.CANCEL_FLAG "POH.CANCEL_FLAG",
          POH.CHANGE_REQUESTED_BY "Change Req",
          POH.WF_ITEM_TYPE "Type",
          POH.WF_ITEM_KEY "Key",
          POR.PO_RELEASE_ID,
          POR.RELEASE_NUM,
          POR.APPROVED_FLAG "POR.APPROVED_FLAG",
          POL.PO_LINE_ID,
          POL.LINE_NUM,
          POL.MATCHING_BASIS,
          PLL.LINE_LOCATION_ID,
          PLL.SHIPMENT_NUM,
          PLL.APPROVED_FLAG "PLL.APPROVED_FLAG",
          PLL.QUANTITY "PLL.QTY",
          PLL.QUANTITY_RECEIVED "PLL.QTY RCVD",
          PLL.CANCEL_FLAG "PLL.CANCEL_FLAG",
          PLL.QUANTITY_CANCELLED,
          PLL.CLOSED_CODE,
          PLL.ENCUMBERED_FLAG,
          PLL.SHIP_TO_ORGANIZATION_ID,
          MP.ORGANIZATION_CODE,
          POD.PO_DISTRIBUTION_ID,
          POD.DISTRIBUTION_NUM,
          POD.DESTINATION_TYPE_CODE,
          POD.QUANTITY_ORDERED "POD.QTY",
          POD.QUANTITY_DELIVERED "POD.QTY DLVD"
   FROM PO_HEADERS_ALL POH,
          PO_LINES_ALL POL,
          PO_LINE_LOCATIONS_ALL PLL,
          PO_DISTRIBUTIONS_ALL POD,
          PO_RELEASES_ALL POR,
          FINANCIALS_SYSTEM_PARAMS_ALL FSP,
          HR_ORGANIZATION_UNITS HOU,
          MTL_PARAMETERS MP
  -- WHERE POH.TYPE_LOOKUP_CODE = ''STANDARD''  -- Comment if for a Release
   WHERE POH.SEGMENT1 = ''##$$PONUM$$##''
   AND POR.RELEASE_NUM = ##$$PORELNUM$$##  -- Uncomment for a specific Release
   -- AND POH.TYPE_LOOKUP_CODE = ''STANDARD''  -- Comment if for a Release
   AND POL.PO_HEADER_ID = POH.PO_HEADER_ID
   AND PLL.PO_LINE_ID = POL.PO_LINE_ID
   AND POD.LINE_LOCATION_ID = PLL.LINE_LOCATION_ID
   AND POR.PO_RELEASE_ID(+) = PLL.PO_RELEASE_ID
   AND POH.ORG_ID = FSP.ORG_ID
   AND FSP.ORG_ID = HOU.ORGANIZATION_ID
   AND POH.ORG_ID = HOU.ORGANIZATION_ID
   AND MP.ORGANIZATION_ID = PLL.SHIP_TO_ORGANIZATION_ID
   AND FSP.PURCH_ENCUMBRANCE_FLAG = ''Y''
   AND PLL.ENCUMBERED_FLAG = ''N''
   ORDER BY POH.ORG_ID, POH.PO_HEADER_ID, POL.PO_LINE_ID, PLL.LINE_LOCATION_ID, POD.PO_DISTRIBUTION_ID',
   'Encumbrance Enabled after Purchase Order Approval - Release',
   'RS',
   'Encumbrance Enabled after Purchase Order Approval - Release',
   'This issue can occur when:
        <ol><li>Deliver a Purchase Order in Receiving Transactions form (RCVTXERT)</li>
            <li>Correct a Receiving Transaction using the Receiving Corrections form (RCVTXECO)</li>
            <li>Return an item in the Receiving Returns form (RCVTXERE)</li></ol>
    See [958816.1] - Receiving Forms (RCVTXERT RCVTXECO RCVTXERE) Return APP-PO-14094: No Record Meet Your Search Criteria',
   'Encumbrance was not enabled after po approval',
   'ALWAYS',
   'E',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y'); 




  ------------------------------------
  -- Purchase Order Cannot be received due to shipment status - STD PO 
  ------------------------------------
  
  add_signature(
   'PO_RCV_FORM_STD',
   'SELECT ph.segment1 PO_NUMBER, 
       pl.line_num, pll.shipment_num, 
       pll.approved_flag, 
       nvl(pll.cancel_flag,''N''), 
       nvl(pll.closed_code,''N''), 
       ph.org_id, ph.po_header_id, 
       pl.po_line_id, pll.line_location_id 
  FROM po_headers_all ph, 
       po_lines_all pl, 
       po_line_locations_all pll
  WHERE ph.segment1 = ''##$$PONUM$$##''
  AND pl.po_header_id = ph.po_header_id
  AND pll.po_header_id = ph.po_header_id
  AND pl.po_line_id = pll.po_line_id
  AND pll.approved_flag IN (''N'',''R'','''')
  AND nvl(pll.cancel_flag,''N'') = ''Y''
  AND nvl(pll.closed_code,''N'') = ''FINALLY CLOSED''',
   'Purchase Order Cannot Be Retrieved in Receiving Form',
   'RS',
   'Purchase order shipment in status affecting receiving',
   '<ul>
      <li> The Receiving Find form RCVCOFND can retrieve po shipments for receiving activity as long as the PO shipment is Approved, not Finally Closed or not Canceled. </li>
      <li>If the approved_flag is Y in the po_line_locations and it is not Finally Closed or not Cancelled the Find form will retrieve the record.</li> 
      <li> See [551232.1] - Find PO - PO Status Affects Receiving Transactions (Receive, Deliver, Correct, Return, ASN) Error: APP-PO-14094 / FRM-40212 </li> 
   </ul>',
   'Purchase order can be retrieved in receiving form',
   'ALWAYS',
   'E',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y');    



  ------------------------------------
  -- Purchase Order Cannot be received due to shipment status - PO with release
  ------------------------------------
  
  add_signature(
   'PO_RCV_FORM_REL',
   'SELECT ph.segment1 PO_NUMBER, 
           ph.type_lookup_code, 
           pr.release_num, 
           pr.po_release_id, 
           pl.line_num, 
           pll.shipment_num, 
           pll.approved_flag, 
           nvl(pll.cancel_flag,''N''), 
           nvl(pll.closed_code,''N''), 
           ph.org_id, 
           ph.po_header_id, 
           pl.po_line_id, 
           pll.line_location_id
    FROM po_headers_all ph, 
         po_lines_all pl, 
         po_line_locations_all pll, 
         po_releases_all pr
    WHERE ph.segment1 = ''##$$PONUM$$##''
    AND pr.release_num = ##$$PORELNUM$$##
    AND pl.po_header_id = ph.po_header_id
    AND pll.po_header_id = ph.po_header_id
    AND pl.po_line_id = pll.po_line_id
    AND pr.po_header_id = ph.po_header_id
    AND pll.po_release_id = pr.po_release_id
    AND pll.approved_flag IN (''N'',''R'','''')
    AND nvl(pll.cancel_flag,''N'') = ''Y''
    AND nvl(pll.closed_code,''N'') = ''FINALLY CLOSED''',
   'Purchase Order Cannot Be Retrieved in Receiving Form',
   'RS',
   'Purchase Order shipment in status affecting receiving',
   '<ul>
      <li> The Receiving Find form RCVCOFND can retrieve po shipments for receiving activity as long as the PO shipment is Approved, not Finally Closed or not Canceled. </li>
      <li>If the approved_flag is Y in the po_line_locations and it is not Finally Closed or not Cancelled the Find form will retrieve the record.</li> 
      <li> See [551232.1] - Find PO - PO Status Affects Receiving Transactions (Receive, Deliver, Correct, Return, ASN) Error: APP-PO-14094 / FRM-40212 </li> 
   </ul>',
   'Purchase Order an be retrieved in receiving form',
   'ALWAYS',
   'E',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y');    


  ------------------------------------
  -- Purchase Order destination_organization_id is null
  ------------------------------------
  
  add_signature(
   'PO_DESTINATION_ORG_ID_NULL',
   'SELECT destination_organization_id 
    FROM po_distributions_all
    WHERE po_header_id = ##$$POID$$##
    AND destination_organization_id = ''''',
   'Purchase Order destination_organization_id Is NULL',
   'RS',
   'Purchase Order destination_organization_id Is NULL',
   '<ul>
      <li> A datafix will be needed. Please log a Service request for support to review your data.</li>
      <li> INTERNAL [1275159.1] - Possible Causes For Pre-Approved POs With The Error POXDM-280: RVSRQ-125: RVSUT-080: ORA-01403</li> 
   </ul>',
   'Purchase Order destination_organization_id Is Not NULL',
   'ALWAYS',
   'E',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y');   


  ------------------------------------
  -- Purchase Order ship_to_organization_id is null
  ------------------------------------
  
  add_signature(
   'PO_SHIP_TO_ORGANIZATION_ID_NULL',
   'SELECT ship_to_organization_id 
    FROM po_line_locations_all
    WHERE po_header_id = ##$$POID$$##
    AND ship_to_organization_id = ''''',
   'Purchase Ship_to_organization_id Is NULL',
   'RS',
   'Purchase Ship_to_organization_id Is NULL',
   '<ul>
      <li> A datafix will be needed. Please log a Service request for support to review your data.</li>
      <li> INTERNAL [1275159.1] - Possible Causes For Pre-Approved POs With The Error POXDM-280: RVSRQ-125: RVSUT-080: ORA-01403</li> 
   </ul>',
   'Purchase Order ship_to_organization_id Is Not NULL',
   'ALWAYS',
   'E',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y'); 
   
   
  ------------------------------------
  -- Purchase Order item is not assigned to the ship to organization
  ------------------------------------
  
  add_signature(
   'PO_ITEM_NO_SHIP_TO_ORGANIZATION',
   'SELECT pol.item_id
    FROM po_headers poh,
         po_lines pol,
         po_line_locations poll
    WHERE poh.po_header_id = pol.po_header_id
    AND pol.po_line_id = poll.po_line_id
    AND poh.segment1 = ''##$$PONUM$$##''
    AND not exists (SELECT ''1'' 
                    FROM mtl_system_items msi
                    WHERE msi.inventory_item_id = pol.item_id
                    AND msi.Organization_Id = poll.SHIP_TO_ORGANIZATION_ID)',
   'Purchase Order Item Is Not Assigned to Ship to Org',
   'RS',
   'Purchase Order Item Is Not Assigned to Ship to Org',
   '<ul>
      <li> A datafix will be needed. Please log a Service request for support to review your data.</li>
      <li> INTERNAL [1275159.1] - Possible Causes For Pre-Approved POs With The Error POXDM-280: RVSRQ-125: RVSUT-080: ORA-01403</li> 
   </ul>',
   'Purchase order item is assigned to ship to org',
   'ALWAYS',
   'W',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y');  
   
   
  ------------------------------------
  -- Receiving Transaction Manager Processes
  ------------------------------------
  
  add_signature(
   'RCV_TRANSACTION_MGR_PROCESSES',
   'SELECT fdg.data_group_name,
           user_concurrent_queue_name Manager,
           concurrent_queue_name,
           concurrent_queue_id,
           sleep_seconds,
           running_processes,
           max_processes,
           decode(NVL(control_code,''A''),
           ''A'',''Activate concurrent Manager'',
           ''D'',''Deactivate concurrent manager'',
           ''E'',''Deactivated'',
           ''N'',''Target node/queue unavailable'',
           ''R'',''Restart concurrent manager'',
           ''T'',''Terminate requests and deactivate manager'',
           ''U'',''Update concurrent manager env inf.'',
           ''V'',''Verify concurrent managers status'',
           ''X'',''Terminated'',
           ''Error control code'') CONTROL_CODE
    FROM    FND_CONCURRENT_QUEUES_VL FCQ,
            FND_CONCURRENT_PROCESSORS FCP,
            FND_DATA_GROUPS FDG
    WHERE FCQ.DATA_GROUP_ID = FDG.DATA_GROUP_ID
    AND FCP.CONCURRENT_PROCESSOR_ID = FCQ.CONCURRENT_PROCESSOR_ID
    AND FCP.CONCURRENT_PROCESSOR_NAME = ''RCVOLTM''
    AND max_processes < 10',
   'Number of Receiving Transaction Manager Processes Are Low',
   'RS',
   'Number of Receiving Transaction Manager Processes Are Low',
   '<ul>
      <li>There is no specific value to suggest for #processes; rather, the value must be calculated.</li>  
      <li>It is suggested to set to a minimum of 10 for production or high fidelity environments. #processes should be AT LEAST 3</li>
      <li>See [404336.1] - How Many Processes Should Be Set For The Receiving Transaction Manager</li> 
   </ul>',
   'Number of Receiving Transaction Manager Processes are acceptable',
   'ALWAYS',
   'W',
   'RS',   
   'N', 
   p_include_in_dx_summary => 'Y');    
   






/*#################################################
  #  I n v o i c e  S i g s                       #
  #################################################*/
  

  ------------------------------------
  -- Invoice Details for PO with Release
  ------------------------------------  
  
  add_signature(
 'INVOICE_DETAILS_REL',
 'SELECT *
  FROM   (SELECT DISTINCT AI.invoice_id,
                        AI.invoice_num,
                        AI.description,                        
                        AI.invoice_date,
                        AL.displayed_field
                               AS invoice_type_display,
                        PV.vendor_name,
                        PVS.vendor_site_code
                               VENDOR_SITE_CODE,
                        AI.invoice_currency_code,                               
                        /*As part of bug 8515470 added with holding tax at three places invoice_amount , invoice_amount_number , due_amount_number*/
                        To_char(AI.invoice_amount
                                + (SELECT Nvl(SUM(amount), 0)
                                   FROM   ap_invoice_lines_all
                                   WHERE  invoice_id = AI.invoice_id
                                          AND line_type_lookup_code = ''AWT''),
                        fnd_currency_cache.Get_format_mask(
                        AI.invoice_currency_code, 30
                        ))                            invoice_amount,
                        To_char(Nvl(AI.amount_paid, 0),
                        fnd_currency_cache.Get_format_mask(
                        AI.invoice_currency_code, 30))
                               AMOUNT_paid,
                        AI.invoice_amount - Nvl(AI.amount_paid, 0) -
                        Nvl(AI.discount_amount_taken, 0) +
                        (SELECT Nvl(SUM(amount), 0)
                        FROM   ap_invoice_lines_all
                        WHERE  invoice_id = AI.invoice_id
                        AND line_type_lookup_code = ''AWT'')
                               AS due_Amount_number,       
                        To_char(Nvl(AI.tax_amount, 0),
                        fnd_currency_cache.Get_format_mask(
                        AI.invoice_currency_code, 30))
                               TAX_AMOUNT,                         
                        Decode(AI.payment_status_flag, ''Y'',
                        fnd_message_cache.Get_string(''POS'', ''POS_PAID''),
                                                       ''N'',
                        fnd_message_cache.Get_string(''POS'', ''POS_NOT_PAID''),
                                                       ''P'',
                        fnd_message_cache.Get_string(''POS'', ''POS_PARTIALLY_PAID''))
                        PAYMENT_STATUS_displayed,       
                        APS.remit_to_supplier_name,
                        APS.remit_to_supplier_site,                                  
                        AI.vendor_id,
                        AI.vendor_site_id,
                        To_char(Nvl(AI.discount_amount_taken, 0),
                        fnd_currency_cache.Get_format_mask(
                        AI.invoice_currency_code, 30
                        ))
                                                      DISCOUNT_AMOUNT_TAKEN,
                        AI.creation_date,
                        AI.approval_status,        
                        AI.wfapproval_status,                  
                        PV.segment1
                               VENDOR_NUMBER,
                        AI.invoice_type_lookup_code,
                        HOU.name
                               AS ORG_NAME,
                        cancelled_date,
                        ai.voucher_num,
                        ai.invoice_amount
                       + (SELECT Nvl(SUM(amount), 0)
                       FROM   ap_invoice_lines_all
                       WHERE  invoice_id = AI.invoice_id
                              AND line_type_lookup_code = ''AWT'')
                           AS invoice_Amount_number,
                        AI.attribute_category,
                        ai.approval_ready_flag,
                        ai.source,
                        FNBA.batch_currency
                               RECKONING_CURRENCY,
                        FNAIA.netted_amt
                               NETTED_AMOUNT,
                        Decode(
                        ( fun_net_apar_utils_grp.Get_invoice_netted_status(AI.invoice_id) ), ''Y'', ''BVRepEnabled'',
                                                                            ''BVRepDisabled'')
                                                REPORT_SWITCHER,
                        APS.discount_date
                               DISCOUNT_DATE,
                        To_char(APS.discount_amount_available,
                        fnd_currency_cache.Get_format_mask(AI.invoice_currency_code, 30))
                               DISCOUNT_AMOUNT_AVAILABLE
                        FROM   ap_invoices AI,
                        ap_payment_schedules_all APS,
                        hr_all_organization_units_tl HOU,
                        po_vendors PV,
                        po_vendor_sites_all PVS,
                        ap_lookup_codes AL,
                        fun_net_batches_all FNBA,
                        fun_net_ap_invs_all FNAIA
                        WHERE  AI.invoice_id = APS.invoice_id
                        AND AI.vendor_site_id = PVS.vendor_site_id
                        AND AI.vendor_id = PV.vendor_id
                        AND HOU.organization_id (+) = AI.org_id
                        AND HOU.LANGUAGE (+) = Userenv(''LANG'')
                        AND AI.invoice_type_lookup_code = AL.lookup_code (+)
                        AND AL.lookup_type = ''INVOICE TYPE''
                        AND FNAIA.invoice_id (+) = AI.invoice_id
                        AND FNBA.batch_id (+) = FNAIA.batch_id) QRSLT
                        WHERE  ( invoice_id IN (SELECT DISTINCT ail.invoice_id
                                                FROM   ap_invoice_lines_all ail
                                                WHERE  ail.po_header_id = ##$$POID$$##
                                                       AND ail.po_release_id = ##$$PORELID$$##
                                                       AND Nvl(ail.discarded_flag, ''N'') = ''N'') )
                        ORDER  BY invoice_date DESC', 
  'Invoice Details',     -- Signature title
  'NRS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Invoice Exists',     -- Problem description
  null,     -- Problem solution
  'Invoice Details',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info); 
 
  
  
  ------------------------------
  -- Invoice Details for STD PO
  ------------------------------
  
  add_signature(
 'INVOICE_DETAILS_STD',
 'SELECT *  
 FROM   (select
        DISTINCT AI.INVOICE_ID,
        AI.INVOICE_NUM,
        /*As part of bug 8515470 added with holding tax at three places invoice_amount ,
        invoice_amount_number ,
        due_amount_number*/ TO_CHAR(AI.INVOICE_AMOUNT + (select
            nvl(sum(amount),
            0) 
        from
            ap_invoice_lines_All 
        where
            invoice_id = AI.INVOICE_ID 
            and LINE_TYPE_LOOKUP_CODE = ''AWT'') ,
        FND_CURRENCY_CACHE.GET_FORMAT_MASK( AI.INVOICE_CURRENCY_CODE,
        30)) invoice_amount,

        AI.INVOICE_DATE,
        TO_CHAR(nvl(AI.TAX_AMOUNT,
        0),
        FND_CURRENCY_CACHE.GET_FORMAT_MASK( AI.INVOICE_CURRENCY_CODE,
        30)) TAX_AMOUNT,
        AI.VENDOR_ID,
        AI.INVOICE_CURRENCY_CODE,
        AI.VENDOR_SITE_ID,
        TO_CHAR(nvl(AI.AMOUNT_PAID,
        0),
        FND_CURRENCY_CACHE.GET_FORMAT_MASK( AI.INVOICE_CURRENCY_CODE,
        30)) AMOUNT_paid,
        TO_CHAR(nvl(AI.DISCOUNT_AMOUNT_TAKEN,
        0),
        FND_CURRENCY_CACHE.GET_FORMAT_MASK( AI.INVOICE_CURRENCY_CODE,
        30)) DISCOUNT_AMOUNT_TAKEN,
        AI.DESCRIPTION,
        AI.CREATION_DATE,
        '''' as PO_HEADER_ID,
        AI.APPROVAL_STATUS,
        AI.ORG_ID,
        AI.WFAPPROVAL_STATUS,
        PVS.VENDOR_SITE_CODE VENDOR_SITE_CODE,
        PV.EMPLOYEE_ID,
        PV.VENDOR_NAME,
        PV.SEGMENT1 VENDOR_NUMBER,
        AI.INVOICE_TYPE_LOOKUP_CODE,
        AL.DISPLAYED_FIELD as invoice_type_display,
        AI.PAYMENT_STATUS_FLAG PAYMENT_STATUS,
        '''' PO_NUMBER ,
        '''' REL_NUMBER ,
        '''' PAYMENT_NUMBER,
        '''' receipt_number,
        HOU.NAME as ORG_NAME,
        '''' PACKING_SLIP,
        '''' as hold_status,
        '''' as receipt_id,
        '''' as po_release_id,
        '''' as check_id,
        CANCELLED_DATE,
        '''' as invoice_Status,
        '''' due_Date,
        decode(AI.PAYMENT_STATUS_FLAG,
        ''Y'',
        FND_MESSAGE_CACHE.GET_STRING(''POS'',
        ''POS_PAID''),
        ''N'',
        FND_MESSAGE_CACHE.GET_STRING(''POS'',
        ''POS_NOT_PAID''),
        ''P'',
        FND_MESSAGE_CACHE.GET_STRING(''POS'',
        ''POS_PARTIALLY_PAID'')) PAYMENT_STATUS_displayed,
        '''' as payment_Date,
        ai.VOUCHER_NUM,
        ai.invoice_amount + (select
            nvl(sum(amount),
            0) 
        from
            ap_invoice_lines_All 
        where
            invoice_id = AI.INVOICE_ID 
            and LINE_TYPE_LOOKUP_CODE = ''AWT'') as invoice_Amount_number,
        AI.INVOICE_AMOUNT-nvl(AI.AMOUNT_PAID,
        0)-nvl(AI.DISCOUNT_AMOUNT_TAKEN,
        0) + (select
            nvl(sum(amount),
            0) 
        from
            ap_invoice_lines_All 
        where
            invoice_id = AI.INVOICE_ID 
            and LINE_TYPE_LOOKUP_CODE = ''AWT'') as due_Amount_number,
        '''' as bv_po_switch,
        '''' as bv_pay_switch,
        '''' as bv_receipt_switch,
        '''' as bv_pay_Date_switch,
        '''' as bv_hold_switch,
        AI.ATTRIBUTE1,
        AI.ATTRIBUTE2,
        AI.ATTRIBUTE3,
        AI.ATTRIBUTE4,
        AI.ATTRIBUTE5,
        AI.ATTRIBUTE6,
        AI.ATTRIBUTE7,
        AI.ATTRIBUTE8,
        AI.ATTRIBUTE9,
        AI.ATTRIBUTE10,
        AI.ATTRIBUTE11,
        AI.ATTRIBUTE12,
        AI.ATTRIBUTE13,
        AI.ATTRIBUTE14,
        AI.ATTRIBUTE15,
        AI.ATTRIBUTE_CATEGORY,
        ai.approval_ready_flag,
        ai.source,
        FNBA.BATCH_CURRENCY RECKONING_CURRENCY,
        FNAIA.NETTED_AMT NETTED_AMOUNT,
        decode((FUN_NET_APAR_UTILS_GRP.GET_INVOICE_NETTED_STATUS(AI.INVOICE_ID)),
        ''Y'',
        ''BVRepEnabled'',
        ''BVRepDisabled'') REPORT_SWITCHER,
        APS.DISCOUNT_DATE DISCOUNT_DATE,
        TO_CHAR(APS.DISCOUNT_AMOUNT_AVAILABLE,
        FND_CURRENCY_CACHE.GET_FORMAT_MASK(AI.INVOICE_CURRENCY_CODE,
        30)) DISCOUNT_AMOUNT_AVAILABLE,
        APS.REMIT_TO_SUPPLIER_NAME,
        APS.REMIT_TO_SUPPLIER_SITE 
    from
        AP_INVOICES AI,
        AP_PAYMENT_SCHEDULES_ALL APS,
        HR_ALL_ORGANIZATION_UNITS_TL HOU,
        PO_VENDORS PV,
        PO_VENDOR_SITES_ALL PVS,
        AP_LOOKUP_CODES AL,
        FUN_NET_BATCHES_ALL FNBA,
        FUN_NET_AP_INVS_ALL FNAIA 
    where
        AI.INVOICE_ID = APS.INVOICE_ID 
        AND AI.VENDOR_SITE_ID = PVS.VENDOR_SITE_ID 
        AND AI.VENDOR_ID = PV.VENDOR_ID 
        AND HOU.ORGANIZATION_ID (+)= AI.ORG_ID 
        AND HOU.LANGUAGE (+)= USERENV(''LANG'') 
        AND AI.INVOICE_TYPE_LOOKUP_CODE = AL.LOOKUP_CODE (+) 
        AND AL.LOOKUP_TYPE = ''INVOICE TYPE''
        AND FNAIA.INVOICE_ID (+)=AI.INVOICE_ID 
        AND FNBA.BATCH_ID (+)=FNAIA.BATCH_ID
    ) QRSLT 
WHERE
    (
        INVOICE_ID in (
            SELECT
                DISTINCT ail.invoice_id 
            FROM
                ap_invoice_lines_all ail 
            WHERE
                ail.po_header_id = ##$$POID$$## 
                AND Nvl(ail.DISCARDED_FLAG,''N'') = ''N'' 
        )
    ) 
ORDER BY INVOICE_DATE DESC', 
  'Invoice Details',     -- Signature title
  'NRS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Invoice Exists',     -- Problem description
  null,     -- Problem solution
  'Invoice Details',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info);
  
  

  ------------------------------------
  -- PO / AP distributions mistmatch 
  ------------------------------------
  
add_signature(
 '1_MISMATCH_AP_PO_DISTRIBUTION',
  'SELECT /*+ ordered use_nl(ai2, aid2, pod2) */
            ai2.invoice_id,
            ai2.invoice_num,
            pod2.po_header_id,
            pod2.po_distribution_id,
            aid2.invoice_line_number,
            aid2.invoice_distribution_id,
            aid2.corrected_quantity,
            aid2.quantity_invoiced,
            aid2.matched_uom_lookup_code,
            aid2.amount aid_amt,
            fsp2.purch_encumbrance_flag,
            1 match_type
     FROM   (##$$IVIEW$$##
                  ) invs,
            ap_invoices_all ai2,
            ap_invoice_distributions_all aid2,
            po_distributions_all pod2,
            financials_system_params_all fsp2
     WHERE ai2.invoice_id = invs.invoice_id
     AND   aid2.invoice_id = ai2.invoice_id
     AND   aid2.invoice_id = ai2.invoice_id
     AND   ai2.org_id = fsp2.org_id
     AND   aid2.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'',
             ''IPV'',''RETROACCRUAL'',''RETROEXPENSE'')
     AND   ai2.invoice_type_lookup_code = ''PREPAYMENT''
     AND   pod2.po_distribution_id = aid2.po_distribution_id
     AND   EXISTS (
             SELECT 1 match_type
             FROM (
                    SELECT pod.po_header_id,
                           pod.po_line_id,
                           pod.line_location_id,
                           pod.po_release_id,
                           pod.po_distribution_id,
                           decode(aid.dist_match_type,
                             ''PRICE_CORRECTION'', 0,
                             ''AMOUNT_CORRECTION'', 0,
                             ''ITEM_TO_SERVICE_PO'', 0,
                             ''ITEM_TO_SERVICE_RECEIPT'', 0,
                             nvl(aid.corrected_quantity,0) +
                             nvl(aid.quantity_invoiced,0)) *
                             decode(nvl(aid.matched_uom_lookup_code,
                               pll.unit_meas_lookup_code),
                               pll.unit_meas_lookup_code, 1 ,
                               nvl(p2p_analyzer_pkg.uom_convert(
                                 nvl(aid.matched_uom_lookup_code,
                                   pll.unit_meas_lookup_code),
                                 pll.unit_meas_lookup_code,rsl.item_id),0)) aid_quan,
                           aid.amount aid_amt,
                           pod.quantity_financed po_quantity,
                           pod.amount_financed po_amount,
                           decode(nvl(p2p_analyzer_pkg.uom_convert(
                                        nvl(aid.matched_uom_lookup_code,
                                            pll.unit_meas_lookup_code),
                                        pll.unit_meas_lookup_code,
                                        rsl.item_id),-999),
                             -999, aid.matched_uom_lookup_code||'' and ''||
                               pll.unit_meas_lookup_code,
                             ''None'') uom_codes,
                           decode(nvl(p2p_analyzer_pkg.uom_convert(
                                        nvl(aid.matched_uom_lookup_code,
                                            pll.unit_meas_lookup_code),
                                        pll.unit_meas_lookup_code, rsl.item_id),-999),
                             -999,''E'',
                             ''N'') process_flag
                    FROM po_distributions_all pod,
                         ap_invoice_distributions_all aid,
                         po_lines_all pol,
                         po_line_locations_all pll,
                         ap_invoices_all ai,
                         financials_system_params_all fsp,
                         rcv_transactions rtxn,
                         rcv_shipment_lines rsl
                    WHERE pod.po_distribution_id = aid.po_distribution_id
                    AND   pod.line_location_id = pll.line_location_id
                    AND   pll.po_line_id = pol.po_line_id
                    AND   aid.invoice_id = ai.invoice_id
                    AND   ai.org_id = fsp.org_id
                    AND   (nvl(fsp.purch_encumbrance_flag,''N'') = ''N'' OR
                           (nvl(pll.approved_flag,''N'') = ''Y'' AND
                            nvl(pll.cancel_flag,''N'') = ''N''  AND
                            nvl(pll.closed_code,'' '') <> ''FINALLY CLOSED''))
                    AND   aid.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'',
                            ''IPV'',''RETROACCRUAL'',''RETROEXPENSE'')
                    AND   ai.invoice_type_lookup_code = ''PREPAYMENT''
                    AND   aid.rcv_transaction_id = RTXN.transaction_id (+)
                    AND   rtxn.shipment_line_id = rsl.shipment_line_id (+)
                  ) apd
             WHERE apd.po_distribution_id = aid2.po_distribution_id
             GROUP BY apd.po_header_id, apd.po_line_id, apd.line_location_id,
                      apd.po_release_id, apd.po_distribution_id,
                      apd.po_quantity, apd.po_amount, apd.uom_codes,
                      apd.process_flag
             HAVING ((round(nvl(apd.po_quantity,0),15) <>
                      round(sum(nvl(apd.aid_quan,0)),15) OR
                      round(nvl(apd.po_amount,0),15) <>
                      round(sum(nvl(apd.aid_amt,0)),15)) AND
                     ((round(sum(nvl(apd.aid_quan,0)),15) >= 0 AND
                       round(sum(nvl(apd.aid_amt,0)),15) >= 0) OR
                      apd.process_flag <> ''N'')))
     UNION ALL
     SELECT /*+ ordered use_nl(ai2, aid2, pod2) */
            ai2.invoice_id,
            ai2.invoice_num,
            pod2.po_header_id,
            pod2.po_distribution_id,
            aid2.invoice_line_number,
            aid2.invoice_distribution_id,
            aid2.corrected_quantity,
            aid2.quantity_invoiced,
            aid2.matched_uom_lookup_code,
            aid2.amount aid_amt,
            fsp2.purch_encumbrance_flag,
            2 match_type
     FROM   (##$$IVIEW$$##) invs,
            ap_invoices_all ai2,
            ap_invoice_distributions_all aid2,
            po_distributions_all pod2,
            financials_system_params_all fsp2
     WHERE ai2.invoice_id = invs.invoice_id
     AND   aid2.invoice_id = ai2.invoice_id
     AND   ai2.org_id = fsp2.org_id
     AND   aid2.line_type_lookup_code = ''PREPAY''
     AND   ai2.invoice_type_lookup_code <> ''PREPAYMENT''
     AND   pod2.po_distribution_id = aid2.po_distribution_id
     AND   EXISTS (
             SELECT 2 match_type
             FROM (
                    SELECT pod.po_header_id,
                           pod.po_line_id,
                           pod.line_location_id,
                           pod.po_release_id,
                           pod.po_distribution_id,
                           decode(aid.dist_match_type,
                             ''PRICE_CORRECTION'', 0,
                             ''AMOUNT_CORRECTION'', 0,
                             ''ITEM_TO_SERVICE_PO'', 0,
                             ''ITEM_TO_SERVICE_RECEIPT'', 0,
                             nvl(aid.corrected_quantity,0 ) +
                             nvl(aid.quantity_invoiced,0)) * -1 *
                             decode(nvl(aid.matched_uom_lookup_code,
                                    pll.unit_meas_lookup_code),
                                    pll.unit_meas_lookup_code, 1 ,
                                    nvl(p2p_analyzer_pkg.uom_convert(
                                      nvl(aid.matched_uom_lookup_code,
                                          pll.unit_meas_lookup_code),
                                   pll.unit_meas_lookup_code,
                                   rsl.item_id),0)) aid_quan,
                           aid.amount * -1 aid_amt,
                           pod.quantity_recouped  po_quantity,
                           pod.amount_recouped   po_amount,
                           decode(nvl(p2p_analyzer_pkg.uom_convert(
                                        nvl(aid.matched_uom_lookup_code,
                                            pll.unit_meas_lookup_code),
                                        pll.unit_meas_lookup_code,
                                        rsl.item_id), -999),
                             -999, aid.matched_uom_lookup_code||'' and ''||
                                     pll.unit_meas_lookup_code,
                             ''None'') uom_codes,
                           decode(nvl(p2p_analyzer_pkg.uom_convert(
                                       nvl(aid.matched_uom_lookup_code,
                                           pll.unit_meas_lookup_code),
                                       pll.unit_meas_lookup_code,
                                       rsl.item_id),-999),
                             -999,''E'',
                             ''N'') process_flag
                    FROM po_distributions_all pod,
                         ap_invoice_distributions_all aid,
                         po_lines_all pol,
                         po_line_locations_all pll,
                         ap_invoices_all ai,
                         financials_system_params_all fsp,
                         rcv_transactions rtxn,
                         rcv_shipment_lines rsl
                    WHERE pod.po_distribution_id = aid.po_distribution_id
                    AND   pod.line_location_id = pll.line_location_id
                    AND   pll.po_line_id = pol.po_line_id
                    AND   aid.invoice_id = ai.invoice_id
                    AND   ai.org_id = fsp.org_id
                    AND   (nvl(fsp.purch_encumbrance_flag,''N'') = ''N'' OR
                           (nvl(pll.approved_flag,''N'') = ''Y'' AND
                            nvl(pll.cancel_flag,''N'') = ''N''  AND
                            nvl(pll.closed_code,'' '') <> ''FINALLY CLOSED''))
                    AND   aid.line_type_lookup_code = ''PREPAY''
                    AND   ai.invoice_type_lookup_code <> ''PREPAYMENT''
                    AND   aid.rcv_transaction_id = rtxn.transaction_id (+)
                    AND   rtxn.shipment_line_id = rsl.shipment_line_id (+)
                  ) apd
             WHERE apd.po_distribution_id = aid2.po_distribution_id
             GROUP BY apd.po_header_id, apd.po_line_id, apd.line_location_id,
                      apd.po_release_id, apd.po_distribution_id, apd.po_quantity,
                      apd.po_amount, apd.uom_codes, apd.process_flag
             HAVING ((round(nvl(apd.po_quantity,0),15) <> -1 *
                        round(sum(nvl(apd.aid_quan,0)),15) OR
                      round(nvl(apd.po_amount,0),15) <> -1 *
                        round(sum(nvl(apd.aid_amt,0)),15))
              AND    (round(nvl(apd.po_quantity,0),15) <>
                        round(sum(nvl(apd.aid_quan,0)),15) OR
                      round(nvl(apd.po_amount,0),15) <>
                        round(sum(nvl(apd.aid_amt,0)),15))
              AND   ((round(sum(nvl(apd.aid_quan,0)),15) >= 0 AND
                       round(sum(nvl(apd.aid_amt,0)),15) >= 0) OR
                      apd.process_flag <> ''N'')))
     UNION ALL
     SELECT /*+ ordered use_nl(ai2, aid2, pod2) */
            ai2.invoice_id,
            ai2.invoice_num,
            pod2.po_header_id,
            pod2.po_distribution_id,
            aid2.invoice_line_number,
            aid2.invoice_distribution_id,
            aid2.corrected_quantity,
            aid2.quantity_invoiced,
            aid2.matched_uom_lookup_code,
            aid2.amount aid_amt,
            fsp2.purch_encumbrance_flag,
            3 match_type
     FROM   (##$$IVIEW$$##) invs,
            ap_invoices_all ai2,
            ap_invoice_distributions_all aid2,
            po_distributions_all pod2,
            financials_system_params_all fsp2
     WHERE ai2.invoice_id = invs.invoice_id
     AND   aid2.invoice_id = ai2.invoice_id
     AND   ai2.org_id = fsp2.org_id
     AND   aid2.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'',
             ''IPV'',''RETROACCRUAL'',''RETROEXPENSE'')
     AND   ai2.invoice_type_lookup_code <> ''PREPAYMENT''
     AND   pod2.po_distribution_id = aid2.po_distribution_id
     AND   EXISTS (
             SELECT 3 match_type
             FROM (
                    SELECT pod.po_header_id,
                           pod.po_line_id,
                           pod.line_location_id,
                           pod.po_release_id,
                           pod.po_distribution_id,
                           decode(aid.dist_match_type,
                             ''PRICE_CORRECTION'', 0,
                             ''AMOUNT_CORRECTION'', 0,
                             ''ITEM_TO_SERVICE_PO'', 0,
                             ''ITEM_TO_SERVICE_RECEIPT'', 0,
                             nvl(aid.corrected_quantity,0) +
                             nvl(aid.quantity_invoiced,0)) *
                             decode(nvl(aid.matched_uom_lookup_code,
                                        pll.unit_meas_lookup_code),
                               pll.unit_meas_lookup_code, 1,
                               nvl(p2p_analyzer_pkg.uom_convert(
                                     nvl(aid.matched_uom_lookup_code,
                                         pll.unit_meas_lookup_code),
                                     pll.unit_meas_lookup_code,
                                     rsl.item_id),0)) aid_quan,
                           aid.amount aid_amt,
                           pod.quantity_billed     po_quantity,
                           pod.amount_billed       po_amount,
                           decode(nvl(p2p_analyzer_pkg.uom_convert(
                                        nvl(aid.matched_uom_lookup_code,
                                            pll.unit_meas_lookup_code),
                                        pll.unit_meas_lookup_code,
                                        rsl.item_id),-999),
                             -999, aid.matched_uom_lookup_code||'' and ''||
                                     pll.unit_meas_lookup_code,
                             ''None'') uom_codes,
                           decode(nvl(p2p_analyzer_pkg.uom_convert(
                                        nvl(aid.matched_uom_lookup_code,
                                            pll.unit_meas_lookup_code),
                                        pll.unit_meas_lookup_code,
                                        rsl.item_id),-999),
                             -999,''E'',
                             ''N'') process_flag
                    FROM po_distributions_all pod,
                         ap_invoice_distributions_all aid,
                         po_lines_all pol,
                         po_line_locations_all pll,
                         ap_invoices_all ai,
                         financials_system_params_all fsp,
                         rcv_transactions rtxn,
                         rcv_shipment_lines rsl
                    WHERE pod.po_distribution_id = aid.po_distribution_id
                    AND   pod.line_location_id = pll.line_location_id
                    AND   pll.po_line_id = pol.po_line_id
                    AND   aid.invoice_id = ai.invoice_id
                    AND   ai.org_id = fsp.org_id
                    AND   (nvl(fsp.purch_encumbrance_flag,''N'') = ''N'' OR
                           (nvl(pll.approved_flag,''N'') = ''Y'' AND
                            nvl(pll.cancel_flag,''N'') = ''N''  AND
                            nvl(pll.closed_code,'' '') <> ''FINALLY CLOSED''))
                    AND   aid.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'',
                            ''IPV'',''RETROACCRUAL'',''RETROEXPENSE'')
                    AND   ai.invoice_type_lookup_code <> ''PREPAYMENT''
                    AND   aid.rcv_transaction_id = RTXN.transaction_id (+)
                    AND   RTXN.shipment_line_id = rsl.shipment_line_id (+)
                  ) apd
             WHERE apd.po_distribution_id = aid2.po_distribution_id
             GROUP BY apd.po_header_id, apd.po_line_id, apd.line_location_id,
                      apd.po_release_id, apd.po_distribution_id, apd.po_quantity,
                      apd.po_amount, apd.uom_codes,
                      apd.process_flag
             HAVING ((round(nvl(apd.po_quantity,0),15) <>
                        round(sum(nvl(apd.aid_quan,0)),15) OR
                      round(nvl(apd.po_amount,0),15) <>
                        round(sum(nvl(apd.aid_amt,0)),15)) AND
                      ((round(sum(nvl(apd.aid_quan,0)),15) >= 0 AND
                        round(sum(nvl(apd.aid_amt,0)),15) >= 0) OR
                       apd.process_flag <> ''N'')))', -- The text of the signature query
  'All PO Distributions That Have a Mismatch with AP Distributions for Quantity/Amount Billed Quantity/Amount Financed and Quantity/Amount Recouped',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'PO distributions that have a mismatch with AP distributions for quantity/amount billed quantity/amount financed and quatity/amount recouped',     -- Problem description
  'Apply the GDF patch(s) following the instructions provided in [1543361.1]',     -- Problem solution
  'PO Distribution is in sync with AP Distribution',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info);


  -----------------------------------------------------
  -- PO shipment qty/amount mistmatch on distributions
  -----------------------------------------------------
add_signature(
  '2_MISMATCH_PO_LOC_DISTRIBUTION', -- Unique Signature identifier
  'SELECT /*+ ordered use_nl(pll, pod) */
            pll.po_header_id,
            pll.org_id,
            pll.line_location_id,
            nvl(pll.quantity_billed,0) qty_billed,
            sum(nvl(pod.quantity_billed,0)) dist_qty_billed,
            nvl(pll.amount_billed,0) amt_billed,
            sum(nvl(pod.amount_billed,0)) dist_amt_billed,
            nvl(pll.quantity_financed,0) qty_financed,
            sum(nvl(pod.quantity_financed,0)) dist_qty_financed,
            nvl(pll.amount_financed,0) amt_financed,
            sum(nvl(pod.amount_financed,0)) dist_amt_financed,
            nvl(pll.quantity_recouped,0) qty_recouped,
            sum(nvl(pod.quantity_recouped,0)) dist_qty_recouped,
            nvl(pll.amount_recouped,0) amt_recouped,
            sum(nvl(pod.amount_recouped,0)) dist_amt_recouped
     FROM (
             SELECT /*+ no_merge ordered use_nl(ail) */ DISTINCT
                    ail.po_header_id
             FROM (
                    ##$$IVIEW$$##
                  ) invs,
                  ap_invoice_lines_all ail
             WHERE ail.invoice_id = invs.invoice_id
           ) pos,
          po_line_locations_all pll,
          po_distributions_all pod
     WHERE pll.line_location_id = pod.line_location_id
     AND   pll.po_header_id = pos.po_header_id
     GROUP BY pll.po_header_id, pll.org_id, pll.line_location_id,
              pll.quantity_billed,pll.amount_billed, pll.quantity_financed,
              pll.amount_financed, pll.quantity_recouped, pll.amount_recouped
     HAVING  (nvl(pll.quantity_billed,0) <> sum(nvl(pod.quantity_billed,0)) OR
              nvl(pll.amount_billed,0) <> sum(nvl(pod.amount_billed,0)) OR
              nvl(pll.quantity_financed,0) <> sum(nvl(pod.quantity_financed,0)) OR
              nvl(pll.amount_financed,0) <> sum(nvl(pod.amount_financed,0)) OR
              nvl(pll.quantity_recouped,0) <> sum(nvl(pod.quantity_recouped,0)) OR
              nvl(pll.amount_recouped,0) <> sum(nvl(pod.amount_recouped,0)))', -- The text of the signature query
  'All Purchase Order Shipments Which Have Quantity or Amount Data Which Does Not Match the Values on the Distributions',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Purchase order shipments which have quantity or amount data which does not match the values on the distributions',     -- Problem description
  'Apply the GDF patch following the instructions provided in [1322280.1]',     -- Problem solution
  'PO Distribution is in sync with PO Shipments',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info);



  -----------------------------------------------------
  -- Unmatched PO with Invoice qty / amounts
  -----------------------------------------------------
add_signature(
  '3_UNMATCHED_PO_WITH_INVOICE_QTY_AMT', -- Unique Signature identifier
  'SELECT /*+ parallel(pod,8) */
            ''MAT1.1'' category,
            pod.po_header_id,
            pod.po_line_id,
            pod.line_location_id,
            pod.po_distribution_id,
            pod.quantity_billed,
            pod.amount_billed,
            pod.quantity_financed,
            pod.amount_financed,
            pod.quantity_recouped,
            pod.amount_recouped,
            null rcv_transaction_id
     FROM po_distributions_all pod
     WHERE pod.po_header_id = ##$$POID$$##
     AND NOT EXISTS (
             SELECT 1
             FROM ap_invoice_distributions_all aid,
                  ap_invoices_all ai
             WHERE aid.po_distribution_id = pod.po_distribution_id
             AND   aid.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'')
             AND   ai.invoice_id = aid.invoice_id
             AND   ai.invoice_type_lookup_code <> ''PREPAYMENT'')
     AND   (nvl(pod.quantity_billed,0) <> 0 OR
            nvl(pod.amount_billed,0) <> 0 )
     UNION
     SELECT /*+ parallel(pod,8) */
            ''MAT1.2'',
            pod.po_header_id,
            pod.po_line_id,
            pod.line_location_id,
            pod.po_distribution_id,
            pod.quantity_billed,
            pod.amount_billed,
            pod.quantity_financed,
            pod.amount_financed,
            pod.quantity_recouped,
            pod.amount_recouped,
            null
     FROM po_distributions_all pod
     WHERE pod.po_header_id = ##$$POID$$##
     AND NOT EXISTS (
             SELECT 1
             FROM ap_invoice_distributions_all aid,
                  ap_invoices_all ai
             WHERE aid.po_distribution_id = pod.po_distribution_id
             AND   aid.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'')
             AND   ai.invoice_id = aid.invoice_id
             AND   ai.invoice_type_lookup_code = ''PREPAYMENT'')
     AND   (nvl(pod.quantity_financed,0) <> 0 OR
            nvl(pod.amount_financed,0) <> 0)
     UNION
     SELECT /*+ parallel(pod,8) */
            ''MAT1.3'',
            pod.po_header_id,
            pod.po_line_id,
            pod.line_location_id,
            pod.po_distribution_id,
            pod.quantity_billed,
            pod.amount_billed,
            pod.quantity_financed,
            pod.amount_financed,
            pod.quantity_recouped,
            pod.amount_recouped,
            null
    FROM po_distributions_all pod
    WHERE pod.po_header_id = ##$$POID$$##
    AND NOT EXISTS (
            SELECT 1
            FROM ap_invoice_distributions_all aid,
                 ap_invoices_all ai
            WHERE aid.po_distribution_id = pod.po_distribution_id
            AND   aid.line_type_lookup_code IN (''PREPAY'')
            AND   ai.invoice_id = aid.invoice_id
            AND   ai.invoice_type_lookup_code <> ''PREPAYMENT'')
     AND   (nvl(pod.quantity_recouped,0) <> 0 OR
            nvl(pod.amount_recouped,0) <> 0)', -- The text of the signature query
  'Unmatched Purchase Orders with Invoice Related Quantities and Amounts',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Unmatched Purchase Orders with invoice related quantities and amounts',     -- Problem description
  'Apply the GDF patch following the instructions provided in [1543361.1]',     -- Problem solution
  'There is no unmatched PO with Invoice Related Quantities or Amounts',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info);




  -----------------------------------------------------
  -- Unmatched Receipt with Invoice qty / amounts
  -----------------------------------------------------
add_signature(
  '3_UNMATCHED_RECEIPT_WITH_INVOICE_QTY_AMT', -- Unique Signature identifier
  'SELECT /*+ parallel(rt,8) */
              ''MAT5'',
              rt.po_header_id,
              rt.po_line_id,
              rt.po_line_location_id,
              rt.po_distribution_id,
              rt.quantity_billed,
              rt.amount_billed,
              null,
              null,
              null,
              null,
              rt.transaction_id
       FROM rcv_transactions rt
       WHERE rt.transaction_id in (##$$RVIEW$$##)
  AND NOT EXISTS (
               SELECT 1 FROM ap_invoice_distributions_all aid
               WHERE aid.rcv_transaction_id = rt.transaction_id)
       AND   NOT EXISTS (
               SELECT 1 FROM ap_invoice_lines_all ail
               WHERE ail.rcv_transaction_id = rt.transaction_id)
       AND   (nvl(rt.quantity_billed,0) <> 0 OR
              nvl(rt.amount_billed,0) <> 0)', -- The text of the signature query
    'Unmatched Receipts with Invoice Related Quantities and Amounts',     -- Signature title
    'RS',     -- fail condition: RS, NRS, [col] operand [val]
    'Unmatched Receipts with invoice related quantities and amounts',     -- Problem description
    'Apply the GDF patch following the instructions provided in [1543361.1]',     -- Problem solution
    'There is no unmatched Receipt with Invoice Related Quantities or Amounts',      -- Message on success
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
    'W',       -- Warn(W), Err(E), Info(I)
    'Y',      -- Y/N/RS - when to print data;
    'N', -- limit_rows Y/N
    l_info);


  -----------------------------------------------------
  -- Canceled invoice lines where qty invoiced <> 0
  -----------------------------------------------------
  add_signature(
  '4_AP_NOT_NULL_QTY_INV_SEL', -- Unique Signature identifier
  'SELECT ail.invoice_id,
            ail.org_id,
            ail.line_number,
            ail.historical_flag,
            ail.line_type_lookup_code,
            ail.discarded_flag,
            ail.cancelled_flag,
            ail.quantity_invoiced,
            ail.po_line_location_id
     FROM ap_invoice_lines_all ail,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE (nvl(discarded_flag,''N'') = ''Y'' OR
            nvl(cancelled_flag,''N'') = ''Y'')
     AND   po_line_location_id is not null
     AND   nvl(quantity_invoiced,0) <> 0
     AND   ail.invoice_id = invs.invoice_id', -- The text of the signature query
  'Canceled and Discarded Invoice Lines Where the Quantity Invoiced Has Not Been Set To 0',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Canceled and discarded invoice lines where the quantity invoiced has not been set to 0',     -- Problem description
  'Apply the GDF patch following the instructions provided in [1543361.1]',     -- Problem solution
  'Canceled and discarded invoice lines having quantity invoiced set to 0',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info);


  -----------------------------------------------------
  -- Invoice Matched to Planned PO Shipment APP-PO-14144
  -----------------------------------------------------
  add_signature(	
    'APP_PO_14144', -- Unique Signature identifier	
    'SELECT line_location_id,shipment_num	
     FROM  po_line_locations_all pol	
     WHERE po_header_id= ##$$POID$$##	
     AND shipment_type=''PLANNED''	
     AND NOT EXISTS (SELECT ''Scheduled Release''	
                     FROM po_line_locations_all porl	
                     WHERE porl.po_header_id=pol.po_header_id	
                     AND porl.SOURCE_SHIPMENT_ID =pol.line_location_id	
                     AND shipment_type =''SCHEDULED'')	
     AND EXISTS (SELECT ''Invoice Matched Shipment''	
     FROM ap_invoice_lines_all ail	
     WHERE ail.po_header_id=pol.po_header_id)', -- The text of the signature query	
     'Invoice Matched to Planned PO Shipment Cannot Be Validated Because of Error APP-PO-14144',     -- Signature title	
     'RS',     -- fail condition: RS, NRS, [col] operand [val]	
     'The invoice(s) matched to above shipments can not be validated because of Error APP-PO-14144.',     -- Problem description	
     'Refer Note- [1579786.1] and apply the solution ',     -- Problem solution	
     ' There is no invoice matched to planned shipments for which shipment releases were not created',      -- Message on success	
     'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER	
     'W',       -- Warn(W), Err(E), Info(I)	
     'Y',      -- Y/N/RS - when to print data;	
     'N', -- limit_rows Y/N	
     l_info,	
     p_include_in_dx_summary => 'Y');
     
     
  -----------------------------------------------------
  --  Receiving distributions out of synch with AP distributions for quantity or amount billed
  -----------------------------------------------------
  add_signature(	
  'ap_sync_po_qty_amt_sel_RCV', -- Unique Signature identifier	
  'SELECT /*+  ordered use_nl(aid, rcv) */	
            aid.invoice_id,	
            aid.rcv_transaction_id,	
            rcv.po_header_id,	
            nvl(rcv.amount_billed,0) rcv_amount,	
            nvl(rcv.quantity_billed,0) rcv_quantity	
     FROM (	
            ##$$IVIEW$$##	
          ) invs,	
          ap_invoice_distributions_all aid,	
          rcv_transactions rcv	
     WHERE aid.invoice_id = invs.invoice_id	
     AND   rcv.transaction_id = aid.rcv_transaction_id	
     AND   aid.rcv_transaction_id is not null	
     AND   aid.line_type_lookup_code IN (''ITEM'',''ACCRUAL'',''IPV'',''PREPAY'')	
     AND   EXISTS (	
             SELECT /*+ no_unnest ordered use_nl(aid2, rcv2) */ 1	
             FROM ap_invoice_distributions_all aid2,	
                  rcv_transactions rcv2	
             WHERE aid2.rcv_transaction_id = aid.rcv_transaction_id	
             AND   rcv2.transaction_id = aid2.rcv_transaction_id	
             AND   aid2.rcv_transaction_id is not null	
             AND   aid2.line_type_lookup_code IN (''ITEM'',''ACCRUAL'',''IPV'',''PREPAY'')	
             GROUP BY nvl(rcv2.quantity_billed,0), nvl(rcv2.amount_billed,0),	
                      aid2.rcv_transaction_id	
             HAVING ((sum(nvl(aid2.quantity_invoiced,0)) <> nvl(rcv2.quantity_billed,0) OR	
                      sum(nvl(aid2.amount,0)) <> nvl(rcv2.amount_billed,0))	
             AND     sum(nvl(aid2.quantity_invoiced,0)) >= 0	
             AND     sum(nvl(aid2.amount,0)) >=0 ))', -- The text of the signature query	
  'Receiving Distributions out of Synch with AP Distributions for Quantity or Amount Billed',     -- Signature title	
  'RS',     -- fail condition: RS, NRS, [col] operand [val]	
  'Receiving distributions out of synch with AP distributions for quantity or amount billed.',     -- Problem description	
  'Refer Note- [1543361.1] and apply the solution ',     -- Problem solution	
  ' There is no Receiving distributions out of synch with AP distributions for quantity or amount billed',      -- Message on success	
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER	
  'W',       -- Warn(W), Err(E), Info(I)	
  'Y',      -- Y/N/RS - when to print data;	
  'N', -- limit_rows Y/N	
  l_info,	
	p_include_in_dx_summary => 'Y');



  -----------------------------------------------------
  --  Checking if Invoice is matched to a Finally Closed PO
  -----------------------------------------------------

  add_signature(
  '5_PO_Finally_Closed', -- Unique Signature identifier
  'SELECT ail.invoice_id,ail.org_id,ail.po_line_location_id,ail.po_line_id,ail.po_header_id
          FROM   ap_invoice_lines_all AIL,
           po_line_locations_ALL PL,(
            ##$$IVIEW$$##
          ) invs
    WHERE  AIL.invoice_id = invs.invoice_id
    AND    AIL.po_line_location_id = PL.line_location_id
    AND    AIL.org_id = PL.org_id AND NVL(fnd_profile.value(''FV_ENABLED''), ''N'')=''N''
    AND    PL.closed_code = ''FINALLY CLOSED''', -- The text of the signature query
  'Invoice Is Matched to a Finally Closed PO',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since Invoice is matched to a Finally Closed PO.',     -- Problem description
  'You need to enter a Credit Memo with the same charge accounts that of invoice matched to Finally Closed PO and make a Zero payment selecting Credit memo and the invoice.
   If the standard invoice is already paid enter a Credit memo with the same charge accounts that of invoice matched to Finally Closed PO and take a Refund of the Payment. 
   Refer Note- [1561331.1] and follow Section C7 of CheckList for cancellation ',     -- Problem solution
  'The invoice is not matched to the Finally Closed PO',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
    p_include_in_dx_summary => 'Y');


  -----------------------------------------------------
  --  Checking if Invoice Cancelling will cause Negative Billing
  -----------------------------------------------------

add_signature(	
  '6_PO_Negative_Billed', -- Unique Signature identifier	
  'SELECT aiv.invoice_id,AIV.invoice_type_lookup_code,AID.po_distribution_id,count(*)	
   FROM ap_invoice_distributions_all AID,	
          po_distributions_ap_v POD,	
      po_line_locations_all PLL,	
      po_lines_all PL,	
          ap_invoices AIV,(	
            ##$$IVIEW$$##	
          ) invs	
    WHERE POD.po_distribution_id = AID.po_distribution_id	
      AND POD.line_location_id = PLL.line_location_id	
      AND PLL.po_line_id = PL.po_line_id	
      AND AIV.invoice_id=AID.invoice_id	
      AND NVL(AID.reversal_flag, ''N'') <> ''Y''	
      AND AID.invoice_id = invs.invoice_id	
       -- Bug 5590826. For amount related decode	
      AND AID.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'', ''IPV'')   	
   HAVING (DECODE(AIV.invoice_type_lookup_code,''PREPAYMENT'',	
             SUM(NVL(POD.quantity_financed, 0)),SUM(NVL(POD.quantity_billed, 0))	
       ) -	
             SUM(round(decode(AID.dist_match_type,	
                             ''PRICE_CORRECTION'', 0,	
                             ''AMOUNT_CORRECTION'', 0,	
                             ''ITEM_TO_SERVICE_PO'', 0,	
                             ''ITEM_TO_SERVICE_RECEIPT'', 0,	
                              nvl( AID.quantity_invoiced, 0 ) +	
                              nvl( AID.corrected_quantity,0 )	
                 ) *	
                   po_uom_s.po_uom_convert(AID.matched_uom_lookup_code,	
                                   nvl(PLL.unit_meas_lookup_code,	
                           PL.unit_meas_lookup_code),	
                       PL.item_id), 15)	
            ) < 0	
           OR DECODE(AIV.invoice_type_lookup_code,''PREPAYMENT'',	
              SUM(NVL(POD.amount_financed, 0)),SUM(NVL(POD.amount_billed, 0))) -	
              SUM(NVL(AID.amount, 0)) < 0 )	
    GROUP BY aiv.invoice_id,AIV.invoice_type_lookup_code,AID.po_distribution_id', -- The text of the signature query	
  'Invoice Cancelling Will Cause Negative Billing or Not in the Respective PO',     -- Signature title	
  '[count(*)] > [0]',     -- fail condition: RS, NRS, [col] operand [val]	
  'The above invoice(s) can not be cancelled since it will cause Quantity Billed or Amount Billed to less than 0',     -- Problem description	
  'You need to find all the invoices matched to the same PO. If there exists the Credit Memo you need to cancel the Credit Memo first and then try to cancel the Standard Invoice.	
  Refer Note- [1561331.1] and follow Section C8 of CheckList for cancellation ',     -- Problem solution	
  'The invoice cancellation activity will not cause Negative Billing',      -- Message on success	
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER	
  'W',       -- Warn(W), Err(E), Info(I)	
  'Y',      -- Y/N/RS - when to print data;	
  'N', -- limit_rows Y/N	
  l_info,	
	p_include_in_dx_summary => 'Y'); 


  -----------------------------------------------------
  --  Checking if invoice is matched to an unapproved PO whereas the encumbrance is on
  -----------------------------------------------------

add_signature(	
  '7_ENC_Unapproved_PO', -- Unique Signature identifier	
  'select aid.invoice_id,aid.po_distribution_id	
              from   po_headers_all POH,	
                 po_distributions_all POD,	
                 ap_invoice_distributions_all AID,	
                 ap_invoices_all AI,financials_system_params_all fsp,(	
            ##$$IVIEW$$##	
          ) invs	
          where  AI.invoice_id = AID.invoice_id	
          and    AI.invoice_id = invs.invoice_id	
          and    NVL(fsp.purch_encumbrance_flag,''N'')=''Y''	
          and    NVL(fsp.org_id, -99) = NVL(AI.org_id, -99)	
          and    AID.po_distribution_id = POD.po_distribution_id	
          and    POD.po_header_id = POH.po_header_id	
          and    POH.approved_flag <> ''Y''	
          and    rownum = 1', -- The text of the signature query	
  'Invoice Is Matched to an Unapproved Po Whereas the Encumbrance Is On',     -- Signature title	
  'RS',     -- fail condition: RS, NRS, [col] operand [val]	
  'The above invoice(s) can not be cancelled since invoice is matched to an unapproved PO whereas the encumbrance is on.',     -- Problem description	
  'You need to approve the PO and then try to cancel the Invoice.Refer Note- [1561331.1] and follow Section C9 of CheckList for cancellation ',     -- Problem solution	
  'The invoice is not matched to the unappoved PO while Encumbrance is on.',      -- Message on success	
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER	
  'W',       -- Warn(W), Err(E), Info(I)	
  'Y',      -- Y/N/RS - when to print data;	
  'N', -- limit_rows Y/N	
  l_info,	
	p_include_in_dx_summary => 'Y'); 


  -----------------------------------------------------
  --  Checking if invoice needs to be matched or not
  -----------------------------------------------------

  add_signature(	
    '10_PO_MATCHING_REQUIRED', -- Unique Signature identifier	
    'SELECT api.invoice_id,''PO REQUIRED''	
  FROM ap_invoices_all api, ap_supplier_sites_all pov,(	
              ##$$IVIEW$$##	
            ) invs	
  WHERE EXISTS (select /*+ index(apd AP_INVOICE_DISTRIBUTIONS_U1) */ ''X''	
  from ap_invoice_distributions_all apd	
  where apd.invoice_id = api.invoice_id	
  and apd.line_type_lookup_code in ( ''ITEM'', ''ACCRUAL'')	
  and apd.po_distribution_id is null	
  and apd.pa_addition_flag <> ''T'' and nvl(apd.reversal_flag,''N'')=''N'')	
  AND   nvl(pov.hold_unmatched_invoices_flag, ''X'') = ''Y''	
  AND   api.invoice_type_lookup_code not in (''PREPAYMENT'', ''INTEREST'')	
  AND   api.vendor_site_id = pov.vendor_site_id	
  AND   api.org_id = pov.org_id AND   api.invoice_id = invs.invoice_id', -- The text of the signature query	
    'Invoice Needs to Be Matched or Not',     -- Signature title	
    'RS',     -- fail condition: RS, NRS, [col] operand [val]	
    'The above invoice(s) can not be validated since it is not matched to PO or Receipt.',     -- Problem description	
    'Please refer section 4.4 Matchting Holds of Doc Id 1472606.1 and follow the Hold Removal(Fix) for MATCHING REQUIRED.',     -- Problem solution	
    'The invoice should not have PO REQUIRED or MATCHING REQUIRED Hold.',      -- Message on success	
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER	
    'W',       -- Warn(W), Err(E), Info(I)	
    'Y',      -- Y/N/RS - when to print data;	
    'N', -- limit_rows Y/N	
    l_info,	
          p_include_in_dx_summary => 'Y');




  -----------------------------------------------------
  -- Identify Invoice distributions linked to PO distributions which are flagged as Selected for price adjustment 
  -----------------------------------------------------

  add_signature(
    'ap_po_price_adj_flg_sel', -- Unique Signature identifier
    'SELECT aid.invoice_id,
                aid.org_id,
                po.po_header_id,
                po.po_line_id,
                po.line_location_id,
                po.po_distribution_id
         FROM po_distributions_all po,
              ap_invoice_distributions_all aid,
              (
                ##$$IVIEW$$##
              ) invs
         WHERE po.invoice_adjustment_flag = ''S''
         AND   po.po_distribution_id = aid.po_distribution_id
         AND   aid.invoice_id = invs.invoice_id' , -- The text of the signature query
      'Invoice Distributions Linked to Po Distributions Which Are Flagged as Selected for Price Adjustment',     -- Signature title
      'RS',     -- fail condition: RS, NRS, [col] operand [val]
      'Invoice distributions linked to PO distributions which are flagged as Selected for price adjustment',     -- Problem description
      'Generate the APLIST output for affected invoices and log a Service Request',     -- Problem solution
      'There is no Invoice distributions linked to PO distributions which are flagged as Selected for price adjustment. ',      -- Message on success
      'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
      'W',       -- Warn(W), Err(E), Info(I)
      'Y',      -- Y/N/RS - when to print data;
      'N', -- limit_rows Y/N
      l_info);


  -----------------------------------------------------
  --  Identify Upgraded invoices with missing rcv_shipment_line_id values on invoice lines
  -----------------------------------------------------

add_signature(
  'rcv_shpmt_miss_sel', -- Unique Signature identifier
  'SELECT ada.invoice_id  ada_inv_id,
              ada.org_id,
              ada.invoice_distribution_id,
              ada.rcv_transaction_id,
              ail.line_number,
              ail.rcv_shipment_line_id,
              ail.invoice_id,
              aid.old_distribution_id,
              ail.historical_flag
       FROM (
              ##$$IVIEW$$##
            ) invs,
            ap_invoice_lines_all ail,
            ap_invoice_distributions_all aid,
            ap_invoice_dists_arch ada
       WHERE ada.invoice_id = aid.invoice_id
       AND   ada.invoice_distribution_id = aid.old_distribution_id
       AND   aid.invoice_line_number = ail.line_number
       AND   aid.invoice_id = ail.invoice_id
       AND   ada.rcv_transaction_id is not null
       AND   ail.rcv_transaction_id is not null
       AND   ail.rcv_shipment_line_id is null
       AND   ail.historical_flag = ''Y''
       AND   ail.invoice_id = invs.invoice_id' , -- The text of the signature query
    'Upgraded Invoices with Missing rcv_shipment_line_id Values on Invoice Lines',     -- Signature title
    'RS',     -- fail condition: RS, NRS, [col] operand [val]
    'Upgraded invoices with missing rcv_shipment_line_id values on invoice lines',     -- Problem description
    'Generate the APLIST output for affected invoices and log a Service Request',     -- Problem solution
    'There is no Upgraded invoices with missing rcv_shipment_line_id values on invoice lines. ',      -- Message on success
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
    'W',       -- Warn(W), Err(E), Info(I)
    'Y',      -- Y/N/RS - when to print data;
    'N', -- limit_rows Y/N
    l_info);


  -----------------------------------------------------
  --  Identify Invoices having unit price null on distributions though it exists on the lines which can result in incorrect invoice price variance (IPV)
  -----------------------------------------------------

add_signature(
  'ap_null_unitprice_sel', -- Unique Signature identifier
  'SELECT aid.invoice_id,
              aid.invoice_line_number,
              aid.distribution_line_number,
              aid.invoice_distribution_id,
              aid.unit_price dist_price,
              ail.unit_price line_price
       FROM (
              ##$$IVIEW$$##
            ) invs,
            ap_invoice_lines_all ail,
            ap_invoice_distributions_all aid
       WHERE ail.invoice_id = invs.invoice_id
       AND   aid.invoice_id = ail.invoice_id
       AND   aid.invoice_line_number = ail.line_number
       AND   aid.po_distribution_id IS NOT NULL
       AND   aid.line_type_lookup_code in (''ITEM'',''ACCRUAL'')
       AND   aid.unit_price is null
       AND   ail.unit_price is not null' , -- The text of the signature query
    'Invoices Having Unit Price Null on Distributions Though It Exists on the Lines Which Can Result in Incorrect Invoice Price Variance (IPV).', -- Signature title
    'RS',     -- fail condition: RS, NRS, [col] operand [val]
    'Invoices having unit price null on distributions though it exists on the lines which can result in incorrect invoice price variance (IPV).',     -- Problem description
    'Generate the APLIST output for affected invoices and log a Service Request',     -- Problem solution
    'No Invoices having unit price null on distributions though it exists on the lines which can result in incorrect invoice price variance (IPV).',-- Message on success
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
    'W',       -- Warn(W), Err(E), Info(I)
    'Y',      -- Y/N/RS - when to print data;
    'N', -- limit_rows Y/N
    l_info);



  -----------------------------------------------------
  --  Identify Receipt number does not show up on correction lines of invoices correcting price quantity or amount
  -----------------------------------------------------

add_signature(
  'ap_rcpt_num_corr_inv_sel', -- Unique Signature identifier
  'SELECT ai.invoice_id,
              ai.invoice_num,
              ail.line_number,
              ail.rcv_transaction_id,
              ail.po_header_id,
              ail.match_type,
              ail.line_type_lookup_code
       FROM (
              ##$$IVIEW$$##
            ) invs,
            ap_invoices_all ai,
            ap_invoice_lines_all ail
       WHERE ai.invoice_id = invs.invoice_id
       AND   ail.invoice_id = ai.invoice_id
       AND   ail.rcv_shipment_line_id is null
       AND   ail.rcv_transaction_id is not null' , -- The text of the signature query
    'Receipt Number Does Not Show up on Correction Lines of Invoices Correcting Price Quantity or Amount.', -- Signature title
    'RS',     -- fail condition: RS, NRS, [col] operand [val]
    'Receipt number does not show up on correction lines of invoices correcting price quantity or amount.',     -- Problem description
    'Apply the root cause fix from bug 15946088 if you have not done so and log a Service Request to obtain the data fix',     -- Problem solution
    'Receipt number show up on correction lines of invoices correcting price quantity or amount.',-- Message on success
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
    'W',       -- Warn(W), Err(E), Info(I)
    'Y',      -- Y/N/RS - when to print data;
    'N', -- limit_rows Y/N
    l_info);



  -----------------------------------------------------
  --  Identify Invoices which have been matched to a PO are not showing the PO Number in PO Number field due to missing value for quick_po_header_id
  -----------------------------------------------------

add_signature(
  'ap_quick_po_update_sel', -- Unique Signature identifier
  'SELECT /*+ leading(invs) */
              ai.invoice_id,
              ai.org_id,
              ai.invoice_amount,
              ai.quick_po_header_id
       FROM (
              ##$$IVIEW$$##
            ) invs,
            ap_invoices_all ai
       WHERE ai.invoice_id = invs.invoice_id
       AND   EXISTS (
               SELECT d.invoice_id
               FROM ap_invoice_distributions_all d,
                    po_distributions_all pod
               WHERE d.invoice_id = ai.invoice_id
               AND   d.po_distribution_id = pod.po_distribution_id)
       AND   ai.quick_po_header_id is null
       AND   ai.cancelled_date is null
       AND   ai.invoice_amount <> 0
       AND   ai.historical_flag is null
       AND   1 = (
               SELECT count(*)
               FROM (
                      SELECT distinct
                             l.invoice_id,
                             ph.segment1,
                             ph.po_header_id,
                             nvl(sum(l.amount),0) line_matched_amt
                      FROM ap_invoice_lines_all l,
                           po_headers_all ph
                      WHERE l.po_header_id = ph.po_header_id
                      AND   l.match_type IN ( ''PRICE_CORRECTION'',
                              ''QTY_CORRECTION'',''ITEM_TO_PO'',
                              ''ITEM_TO_RECEIPT'', ''AMOUNT_CORRECTION'',
                              ''RETRO PRICE ADJUSTMENT'',''ITEM_TO_SERVICE_PO'',
                              ''ITEM_TO_SERVICE_RECEIPT'')
                      AND    NVL (l.discarded_flag, ''N'' ) <> ''Y''
                      AND    NVL (l.cancelled_flag, ''N'' ) <> ''Y''
                      GROUP BY ph.po_header_id, ph.segment1, l.invoice_id
                      HAVING (nvl(sum(l.amount), 0) <> 0 OR
                              nvl(sum(l.quantity_invoiced), 0) <> 0)
                    ) po,
                    (
                       SELECT ail.po_header_id,
                              ail.corrected_inv_id,
                              nvl(sum(ail.amount), 0) corrected_amt
                       FROM ap_invoice_lines_all ail
                       WHERE nvl(ail.discarded_flag, ''N'' ) <> ''Y''
                       AND   nvl(ail.cancelled_flag, ''N'' ) <> ''Y''
                       GROUP BY ail.po_header_id, ail.corrected_inv_id
                    ) l
              WHERE l.po_header_id = po.po_header_id
              AND   po.invoice_id = ai.invoice_id
              AND   l.corrected_inv_id = ai.invoice_id
              AND   (ai.invoice_type_lookup_code NOT IN (''CREDIT'',''DEBIT'') OR
                     ((-1)*l.corrected_amt < (-1)*po.line_matched_amt))
              AND   (nvl(ai.invoice_type_lookup_code,''CREDIT'') IN (
                       ''CREDIT'',''DEBIT'') OR
                     ((-1)*l.corrected_amt < po.line_matched_amt)))' , -- The text of the signature query
    'Invoices Which Have Been Matched to a PO Are Not Showing the PO Number in PO Number Field Due to Missing Value for Quick_po_header_id.', -- Signature title
    'RS',     -- fail condition: RS, NRS, [col] operand [val]
    'Invoices which have been matched to a PO are not showing the PO Number in PO Number field due to missing value for quick_po_header_id.',     -- Problem description
    ' Apply the root cause fix from bug 9508416 if you have not done so and log a Service Request to obtain the data fix. ',     -- Problem solution
    'No Invoices which have been matched to a PO are not showing the PO Number in PO Number field.',-- Message on success
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
    'W',       -- Warn(W), Err(E), Info(I)
    'Y',      -- Y/N/RS - when to print data;
    'N', -- limit_rows Y/N
    l_info);




  -----------------------------------------------------
  --  Identify quick matched Invoices populated with multiple precision on invoice lines and distributions causing hold with reason Quantity billed is more than quantity accepted.
  -----------------------------------------------------

add_signature(
  'quick_match_qty_rnd_sel', -- Unique Signature identifier
  'SELECT ai.invoice_id,
              ai.invoice_amount,
              ai.invoice_num,
              ai.vendor_id,
              ail.quantity_invoiced,
              ail.line_number,
              ail.line_type_lookup_code,
              ail.rcv_transaction_id,
              ail.po_distribution_id,
              ail.po_line_location_id,
              ail.po_line_id
       FROM (
              ##$$IVIEW$$##
            ) invs,
            ap_invoices_all ai,
            ap_invoice_lines_all ail,
            fnd_currencies fnc
       WHERE ai.invoice_id = invs.invoice_id
       AND   fnc.currency_code = ai.invoice_currency_code
       AND   ai.historical_flag is null
       AND   ai.quick_po_header_id is not null
       AND   ai.invoice_id = ail.invoice_id
      AND   ail.po_line_location_id is not null
       AND   upper(ail.unit_meas_lookup_code) = ''EACH''
       AND   ail.quantity_invoiced is not null
       AND   EXISTS (
               SELECT 1 FROM po_distributions_all pod
               WHERE pod.po_header_id = ail.po_header_id
               AND   ail.po_line_id = pod.po_line_id
               AND   ail.po_line_location_id = pod.line_location_id
               AND   ((round(pod.quantity_billed) = quantity_ordered AND
                       pod.quantity_billed <> quantity_ordered) OR
                      (round(pod.quantity_billed) = quantity_delivered AND
                       pod.quantity_billed <>  Quantity_delivered))
               AND   decode(instr(pod.quantity_billed, ''.'', 1, 1),
                       0, 0,
                       length(substr(pod.quantity_billed,
                         instr(pod.quantity_billed, ''.'', 1, 1) + 1)))
                        > fnc.precision)' , -- The text of the signature query
    'Quick Matched Invoices Populated with Multiple Precision on Invoice Lines and Distributions Causing Hold with Reason Quantity Billed Is More than Quantity Accepted', -- Signature title
    'RS',     -- fail condition: RS, NRS, [col] operand [val]
    'Quick matched Invoices populated with multiple precision on invoice lines and distributions causing hold with reason Quantity billed is more than quantity accepted.',     -- Problem description
    'Apply the root cause fix from bug 8973086 if you have not done so, and log a Service Request to obtain the data fix',     -- Problem solution
    'No Invoices populated with multiple precision on invoice lines and distributions causing hold with reason Quantity billed is more than quantity accepted.',-- Message on success
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
    'W',       -- Warn(W), Err(E), Info(I)
    'Y',      -- Y/N/RS - when to print data;
    'N', -- limit_rows Y/N
    l_info);




  -----------------------------------------------------
  --  Identify Invoice lines matched to blanket or planned PO with missing PO_RELEASE_ID causing APP-PO-14144 when trying to cancel or validate the invoice
  -----------------------------------------------------

 add_signature(
  'ap_sync_po_release_id_sel', -- Unique Signature identifier
  'SELECT
              ai.invoice_id,
              ai.invoice_num,
              ai.org_id,
              ail.line_number,
              ail.po_header_id,
              ail.po_line_location_id,
              ail.po_release_id  old_po_release_id,
              pll.po_release_id  new_po_release_id
       FROM ap_invoices_all ai,
            ap_invoice_lines_all  ail,
            po_line_locations_all pll,
            po_headers_all ph,
            (
              ##$$IVIEW$$##
            ) invs
       WHERE ail.invoice_id = ai.invoice_id
       AND   ail.po_header_id = ph.po_header_id
       AND  ((PH.type_lookup_code = ''BLANKET'' AND
              nvl( PH.global_agreement_flag, ''N'' ) = ''N'') OR
             PH.type_lookup_code = ''PLANNED'')
       AND   pll.line_location_id = ail.po_line_location_id
       AND   pll.po_release_id is not null
       AND   ail.po_release_id is null
       AND   ai.invoice_id = invs.invoice_id' , -- The text of the signature query
    'Invoice Lines Matched to Blanket or Planned Po with Missing Po_release_id Causing APP-PO-14144 When Trying to Cancel or Validate the Invoice', -- Signature title
    'RS',     -- fail condition: RS, NRS, [col] operand [val]
    'Invoice lines matched to blanket or planned PO with missing PO_RELEASE_ID causing APP-PO-14144 when trying to cancel or validate the invoice.',     -- Problem description
    'Apply the GDF patch following the instructions provided in note 1094274.1',     -- Problem solution
    'No Invoice lines matched to blanket or planned PO with missing PO_RELEASE_ID causing APP-PO-14144 when trying to cancel or validate the invoice.',-- Message on success
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
    'W',       -- Warn(W), Err(E), Info(I)
    'Y',      -- Y/N/RS - when to print data;
    'N', -- limit_rows Y/N
    l_info);



  -----------------------------------------------------
  --  Identify Various invoice matching related issues
  -----------------------------------------------------

add_signature(
  'ap_one_off_scripts_sel', -- Unique Signature identifier
  'SELECT /*+ ordered */
              ''MAT2'' Category,
              aid.invoice_id,
              aid.org_id,
              aid.invoice_line_number,
              aid.invoice_distribution_id,
              ail.po_line_location_id,
              aid.po_distribution_id,
              ''UOM codes in PO and AP do not match'' Issue
       FROM (
              ##$$IVIEW$$##
            ) invs,
            ap_invoice_lines_all ail,
            ap_invoice_distributions_all aid,
            po_line_locations_all pll
       WHERE ail.invoice_id = aid.invoice_id
       AND   ail.line_number = aid.invoice_line_number
       AND   ail.po_line_location_id is not null
       AND   ail.po_line_location_id = pll.line_location_id
       AND   aid.dist_match_type in (''ITEM_TO_PO'',''ITEM_TO_SERVICE_PO'')
       AND   ail.rcv_transaction_id is null
       AND   aid.rcv_transaction_id is null
       AND   aid.line_type_lookup_code IN (''ITEM'',''ACCRUAL'')
       AND   (nvl(ail.UNIT_MEAS_LOOKUP_CODE,-1) <> nvl(pll.UNIT_MEAS_LOOKUP_CODE,-1)
               OR nvl(aid.MATCHED_UOM_LOOKUP_CODE,-1) <> nvl(pll.UNIT_MEAS_LOOKUP_CODE,-1)
             OR nvl(ail.UNIT_MEAS_LOOKUP_CODE,-1) <> nvl(aid.MATCHED_UOM_LOOKUP_CODE,-1))
      AND   ail.invoice_id = invs.invoice_id
       UNION ALL
       SELECT /*+ ordered */
              ''MAT3'',
              ail.invoice_id,
              ail.org_id,
              ail.line_number,
              null,
              ail.po_line_location_id,
              ail.po_distribution_id,
              ''Quantity_invoiced mismatch on AP line and distribution''
       FROM (
              ##$$IVIEW$$##
            ) invs,
            ap_invoice_lines_all ail,
             ap_invoice_distributions_all aid
       WHERE ail.po_line_location_id is not null
       AND   nvl(ail.discarded_flag,''N'') <> ''Y''
       AND   nvl(ail.cancelled_flag,''N'') <> ''Y''
       AND   ail.line_type_lookup_code IN (''ITEM'',''ACCRUAL'')
       AND   ail.match_type NOT IN (''PRICE_CORRECTION'',''QTY_CORRECTION'')
       AND   aid.invoice_id = ail.invoice_id
       AND   aid.invoice_line_number = ail.line_number
       AND   ail.invoice_id = invs.invoice_id
       GROUP BY ail.invoice_id, ail.org_id, ail.line_number,
                ail.po_line_location_id, ail.po_distribution_id, ail.amount,
                ail.quantity_invoiced
       HAVING nvl(ail.quantity_invoiced,0) <> sum(nvl(aid.quantity_invoiced,0)) AND
              ail.amount = sum(aid.amount)
       UNION ALL
       SELECT /*+ ordered */
              ''MAT4'',
              ail.invoice_id,
              aid.org_id,
              aid.invoice_line_number,
              aid.invoice_distribution_id,
              ail.rcv_transaction_id,
              aid.rcv_transaction_id,
              ''Rcv_transaction_id missing on distributions matched to receipts''
       FROM (
              ##$$IVIEW$$##
            ) invs,
            ap_invoice_lines_all ail,
            ap_invoice_distributions_all aid
       WHERE ail.invoice_id = aid.invoice_id
       AND   ail.line_number = aid.invoice_line_number
       AND   ail.po_line_location_id is not null
       AND   aid.po_distribution_id is not null
       AND   nvl(ail.historical_flag,''N'') <> ''Y''
       AND   nvl(aid.historical_flag,''N'') <> ''Y''
       AND   (ail.line_type_lookup_code IN (''ITEM'',''PREPAY'',
                ''RETAINAGE RELEASE'',''RETROITEM'') OR
              (ail.line_type_lookup_code IN (''FREIGHT'',''MISCELLANEOUS'') AND
               nvl(ail.match_type,''NOT_MATCHED'') = ''OTHER_TO_RECEIPT''))
       AND   (aid.rcv_transaction_id is null AND
              ail.rcv_transaction_id is not null OR
              ail.rcv_transaction_id is null AND
              aid.rcv_transaction_id is not null)
       AND   ail.invoice_id = invs.invoice_id' , -- The text of the signature query
    'Various Invoice Matching Related Issues', -- Signature title
    'RS',     -- fail condition: RS, NRS, [col] operand [val]
    'Various invoice matching related issues. See problem description for each row and refer 1489862.1 for description of all issues covered.',-- Problem description
    'Apply the GDF patch following the instructions provided in note 1543361.1 ',     -- Problem solution
    'No matching related issues found mentioned in note 1489862.1.',-- Message on success
    'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
    'W',       -- Warn(W), Err(E), Info(I)
    'Y',      -- Y/N/RS - when to print data;
    'N', -- limit_rows Y/N
    l_info);
  
  

/*#################################################
  #  P a y m e n t  S i g s                       #
  #################################################*/   

  ----------------------------------------------
  -- Display Payment Details - PO with Release
  ----------------------------------------------
  
  add_signature(
   'PAYMENT_DETAILS_REL',
   'SELECT *
    FROM   (SELECT AC.check_number,  
               AC.check_date,
               AC.remit_to_supplier_name,
               AC.remit_to_supplier_site,
               ac.check_date                                AS check_date_from,
               AC.currency_code,
               To_char(AC.amount, fnd_currency.Safe_get_format_mask(
                                  AC.currency_code,
                                  30))
                                                            amount, 
               ac.bank_account_name,
               ac.payment_method                            AS payment_method_displayed,
               APLC.displayed_field                         status_displayed,
               Decode(ac.status_lookup_code, ''SPOILED'', AC.check_date,
                                             ''SET UP'', AC.check_date,
              ''UNCONFIRMED SET UP'', AC.check_date,
              ''OVERFLOW'', AC.check_date,
              ''NEGOTIABLE'', AC.check_date,
              ''ISSUED'', AC.check_date,
              ''STOP INITIATED'', AC.stopped_date,
              ''VOIDED'', AC.void_date,
              ''CLEARED'', AC.cleared_date,
              ''CLEARED BUT UNACCOUNTED'', AC.cleared_date,
              ''RECONCILED'', AC.cleared_date,
              ''RECONCILED UNACCOUNTED'', AC.cleared_date,
              To_date(NULL)) AS status_date,
              AC.city
              || '' ''
              || AC.state                                  address,
              ac.vendor_id,
              ac.vendor_site_id,
              ac.check_id,
              ac.current_vendor_site_code                  vendor_site_code,
              ac.vendor_name,
              ac.org_id,
              HOU.name                                     AS org_name,
              ac.amount                                    AS amount_number,
              ac.amount                                    AS amount_to,
              ac.check_date                                AS check_date_to,
              ac.payment_method_code                       Payment_Method_Lookup_Code,
              ac.check_voucher_num,
              AC.attribute_category,
              ac.payment_method_code
       FROM   ap_checks_v AC,
              ap_lookup_codes APLC,
              hr_all_organization_units_tl HOU,
              ap_lookup_codes APLC1
       WHERE  HOU.organization_id (+) = AC.org_id
       AND APLC.lookup_type = ''CHECK STATE''
       AND AC.status_lookup_code = APLC.lookup_code (+)
       AND HOU.LANGUAGE (+) = Userenv(''LANG'')
       AND APLC1.lookup_type(+) = ''PAYMENT METHOD''
       AND ac.payment_method_code = APLC1.lookup_code(+)) QRSLT
       WHERE  ( check_id IN (SELECT DISTINCT aip.check_id
                             FROM   ap_invoice_lines_all ail,
                                    ap_invoice_payments_all aip
                             WHERE  ail.invoice_id = aip.invoice_id
                                     AND ail.po_header_id = ##$$POID$$##
                                     AND ail.po_release_id = ##$$PORELID$$##) )
        ORDER  BY check_date DESC ',
   'Payment Details',
   'NRS',
   'No payment details found',
   NULL,
   'Payment details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');   
   
  

  ----------------------------------------------
  -- Display Payment Details - STD PO
  ----------------------------------------------
  
  add_signature(
   'PAYMENT_DETAILS_STD',
   'SELECT *
    FROM   (SELECT HOU.NAME as org_name,
                    AC.CHECK_NUMBER,
                    '''' as invoices,
                    AC.CHECK_DATE,
                    AC.CURRENCY_CODE,
                    ac.status_lookup_code,
                    APLC.DISPLAYED_FIELD status_displayed,
                    TO_CHAR(AC.AMOUNT,
                    FND_CURRENCY.SAFE_GET_FORMAT_MASK( AC.CURRENCY_CODE,
                    30)) amount,
                    decode(ac.status_lookup_code,
                    ''SPOILED'',
                    AC.CHECK_DATE,
                    ''SET UP'',
                    AC.CHECK_DATE,
                    ''UNCONFIRMED SET UP'',
                    AC.CHECK_DATE,
                    ''OVERFLOW'',
                    AC.CHECK_DATE,
                    ''NEGOTIABLE'',
                    AC.CHECK_DATE,
                    ''ISSUED'',
                    AC.CHECK_DATE,
                    ''STOP INITIATED'',
                    AC.STOPPED_DATE,
                    ''VOIDED'',
                    AC.VOID_DATE,
                    ''CLEARED'',
                    AC.CLEARED_DATE,
                    ''CLEARED BUT UNACCOUNTED'',
                    AC.CLEARED_DATE,
                    ''RECONCILED'',
                    AC.CLEARED_DATE,
                    ''RECONCILED UNACCOUNTED'',
                    AC.CLEARED_DATE,
                    to_date(null)) as status_date,
                    AC.CITY || '' '' || AC.STATE address,
                    ac.vendor_id,
                    ac.vendor_site_id,
                    ac.check_id,
                    ac.current_vendor_site_code vendor_site_code,
                    ac.vendor_name,
                    ac.org_id,
                    0 vendor_number,
                    ac.amount as amount_number,
                    ac.amount as amount_to,
                    ac.check_date as check_date_from,
                    ac.check_date as check_date_to,
                    ac.PAYMENT_METHOD_CODE Payment_Method_Lookup_Code,
                    ac.payment_method as payment_method_displayed,
                    0 DOC_SEQUENCE_VALUE,
                    ac.CHECK_VOUCHER_NUM,
                    ''BVPo_N'' as bv_po_switch,
                    '''' as po_number,
                    '''' as po_header_id,
                    '''' as po_release_id,
                    ''BVInv_N'' as bv_invoice_switch,
                    '''' as invoice_number,
                    '''' as invoice_id,
                    ac.bank_account_name,
                    AC.ATTRIBUTE1,
                    AC.ATTRIBUTE2,
                    AC.ATTRIBUTE3,
                    AC.ATTRIBUTE4,
                    AC.ATTRIBUTE5,
                    AC.ATTRIBUTE6,
                    AC.ATTRIBUTE7,
                    AC.ATTRIBUTE8,
                    AC.ATTRIBUTE9,
                    AC.ATTRIBUTE10,
                    AC.ATTRIBUTE11,
                    AC.ATTRIBUTE12,
                    AC.ATTRIBUTE13,
                    AC.ATTRIBUTE14,
                    AC.ATTRIBUTE15,
                    AC.ATTRIBUTE_CATEGORY,
                    ac.payment_method_code,
                    '''' rel_number,
                    AC.REMIT_TO_SUPPLIER_NAME,
                    AC.REMIT_TO_SUPPLIER_SITE 
                 FROM
                    AP_CHECKS_V AC ,
                    AP_LOOKUP_CODES APLC,
                    HR_ALL_ORGANIZATION_UNITS_TL HOU,
                    AP_LOOKUP_CODES APLC1 
                 WHERE
                    HOU.ORGANIZATION_ID (+) = AC.ORG_ID 
                    AND APLC.lookup_type = ''CHECK STATE'' 
                    AND AC.STATUS_LOOKUP_CODE = APLC.lookup_code (+) 
                    AND HOU.LANGUAGE (+)= USERENV(''LANG'') 
                    AND APLC1.lookup_type(+) = ''PAYMENT METHOD'' 
                    AND ac.payment_method_code = APLC1.lookup_code(+)) QRSLT 
              WHERE
                 (
                    CHECK_ID in (
                       SELECT
                          DISTINCT aip.check_id 
                       FROM
                          ap_invoice_lines_all ail,
                          ap_invoice_payments_all aip 
                       WHERE
                          ail.invoice_id = aip.invoice_id 
                          AND ail.po_header_id = ##$$POID$$## 
                          and ail.po_release_id is null 
                    )
                 ) 
              ORDER BY CHECK_DATE DESC',
   'Payment Details',
   'NRS',
   'No payment details found',
   NULL,
   'Payment details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');   
   


  ----------------------------------------------
  -- NULL payment_method_code in ap_checks_all
  ----------------------------------------------  

add_signature(
  'ap_payment_method_null_sel', -- Unique Signature identifier
  'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.vendor_name,
            ac.amount,
            ac.check_date,
            ac.checkrun_name,
            ac.status_lookup_code,
            ac.payment_id,
            ac.payment_method_code
     FROM ap_checks_all ac,
          (
            ##$$CVIEW$$##
          ) chks
     WHERE ac.payment_method_code IS NULL
     AND   ac.payment_id IS NOT NULL
     AND   ac.check_id = chks.check_id', -- The text of the signature query
  'Null Payment_method_code in Ap_checks_all Resulting out of Sync with IBY (Results in FRM-40735 Errors)',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'NULL payment_method_code in ap_checks_all and thus out of sync with IBY (results in FRM-40735 errors)',     -- Problem description
  'Refer Note- [985615.1] and apply the solution ',     -- Problem solution
  'There is no record having NULL payment_method_code in ap_checks_all',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

  -----------------------------------------------------------
  -- Foreign currency checks that are missing exchange rates
  -----------------------------------------------------------  
  

add_signature(
  'ap_rate_miss_sel', -- Unique Signature identifier
  'SELECT ac.check_id,
            ac.check_number,
            ac.vendor_name,
            ac.check_date,
            ac.amount,
            ac.org_id
     FROM ap_checks_all ac,
          ap_system_parameters_all asp,
          ap_payment_history_all ph,
          (
            ##$$CVIEW$$##
          ) chks
     WHERE ac.org_id = asp.org_id
     AND   ac.currency_code <> asp.base_currency_code
     AND   ph.check_id = ac.check_id
     AND   nvl(ph.historical_flag, ''N'') <> ''Y''
     AND   /* pmt created exchange rate */
           ((ph.transaction_type in (''PAYMENT CREATED'', ''REFUND RECORDED'',
                   ''MANUAL PAYMENT ADJUSTED'',
                   ''PAYMENT ADJUSTED'', ''REFUND ADJUSTED'',
                   ''PAYMENT CANCELLED'', ''REFUND CANCELLED'') AND
             ph.pmt_to_base_xrate is null AND
             ((nvl(ph.posted_flag,''N'') <> ''Y'' AND
               (decode(ph.pmt_to_base_xrate_type,
                  ''User'', null,
                  ph.pmt_to_base_xrate_type) is null OR
               ph.pmt_to_base_xrate_date is null OR
               EXISTS (
                 /*autorate will not pick it up if aip rate and base are populated */
                 SELECT 1 FROM ap_invoice_payments_all aip
                 WHERE aip.check_id = ph.check_id
                 AND   aip.posted_flag = ''N''
                 AND   aip.accounting_event_id = ph.accounting_event_id
                 AND   aip.invoice_base_amount is not null
                 AND   aip.exchange_rate is not null))) OR
              (ph.posted_flag = ''Y'' AND
               (ac.exchange_rate is null OR
                ph.trx_base_amount is null OR
                ap_utilities_pkg.ap_round_currency(
                  ph.trx_pmt_amount * ac.exchange_rate,
                  ph.pmt_currency_code) <> ph.trx_base_amount)))) OR
            /* pmt maturity exchange rate */
            (ph.transaction_type in (''PAYMENT MATURITY'',
                ''PAYMENT MATURITY ADJUSTED'', ''PAYMENT MATURITY REVERSAL'') AND
             ph.pmt_to_base_xrate is null AND
             (nvl(ph.posted_flag,''N'') <> ''Y'' AND
              (decode(ph.pmt_to_base_xrate_type,
                 ''User'', null,
                 ph.pmt_to_base_xrate_type) is null OR
               ph.pmt_to_base_xrate_date is null) OR
              (ph.posted_flag = ''Y'' AND
               (ac.maturity_exchange_rate is null OR
                ph.trx_base_amount is null OR
                ap_utilities_pkg.ap_round_currency(
                  ph.trx_pmt_amount * ac.maturity_exchange_rate,
                  ph.pmt_currency_code) <> ph.trx_base_amount)))) OR
            /* pmt clearing exchange rate */
            (ph.transaction_type in (''PAYMENT CLEARING'',
               ''PAYMENT CLEARING ADJUSTED'', ''PAYMENT UNCLEARING'') AND
             (ph.pmt_to_base_xrate is null AND
              (nvl(ph.posted_flag,''N'') <> ''Y'' OR
               (ph.posted_flag = ''Y'' AND
                (ac.cleared_exchange_rate is null OR
                 ph.trx_base_amount is null OR
                 ap_utilities_pkg.ap_round_currency(
                   ph.trx_pmt_amount * ac.cleared_exchange_rate,
                   ph.pmt_currency_code) <> ph.trx_base_amount)))) OR
                 (ph.bank_to_base_xrate is null AND
                  ph.bank_currency_code <> asp.base_currency_code)))
     AND   ac.check_id = chks.check_id', -- The text of the signature query
  'Foreign Currency Checks That Are Missing Exchange Rates Maturity Exchange Rates or Clearing Exchange Rates',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Foreign currency checks that are missing exchange rates maturity exchange rates or clearing exchange rates.',     -- Problem description
  'Refer Note- [1125533.1] and apply the solution ',     -- Problem solution
  'There is no Foreign currency check that are missing exchange rates maturity exchange rates or clearing exchange rates',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');  
        
        
        
  -------------------------------
  -- Incorrect check statuses
  ------------------------------- 
  
add_signature(
  'ap_wrgchksts_sel', -- Unique Signature identifier
  'SELECT /*+ leading(chks) */
            ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.check_date,
            ac.payment_method_lookup_code,
            ac.checkrun_name,
            ac.vendor_id,
            ac.vendor_site_id,
            ac.amount,
            ac.currency_code,
            ac.payment_type_flag,
            ac.cleared_amount,
            ac.status_lookup_code
     FROM (
            ##$$CVIEW$$##
          ) chks,
          ap_checks_all ac
     WHERE ac.check_id = chks.check_id
     AND   ac.status_lookup_code IN (
             ''CLEARED BUT UNACCOUNTED'',''RECONCILED UNACCOUNTED'')
     AND   NOT EXISTS (
             SELECT ''Check has no clearing event or accounted clearing ''||
                    ''event but check status is wrong''
             FROM ap_payment_history_all aph
             WHERE transaction_type   IN (
                    ''PAYMENT CLEARING'', ''PAYMENT UNCLEARING'',
                    ''PAYMENT CLEARING ADJUSTED'', ''PAYMENT UNCLEARING ADJUSTED'')
             AND   aph.check_id = ac.check_id
             AND   nvl(aph.posted_flag,''N'') ! = ''Y'')', -- The text of the signature query
  'Incorrect Check Statuses When Payables Accounting Option Account for Payment When Payment Clears Is Disabled. Payments Are Accounted but Appear as Unreconciled',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Incorrect check statuses when Payables accounting option Account for Payment When Payment Clears is disabled. Payments are accounted but appear as unreconciled',     -- Problem description
  'You need to enter a Credit Memo with the same charge accounts that of invoice matched to Finally Closed PO and make a Zero payment selecting Credit memo and the invoice.
If the standard invoice is already paid enter a Credit memo with the same charge accounts that of invoice matched to Finally Closed PO and take a Refund of the Payment. 
Refer Note- [1154813.1] and apply the solution ',     -- Problem solution
  'Correct check statuses when Payables accounting option Account for Payment',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');  
        
        
  -------------------------------
  -- Checks voided in Payments
  -------------------------------         


add_signature(
  'ap_negotiable_iby_void_sel', -- Unique Signature identifier
  'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.vendor_name,
            ac.bank_account_name,
            ac.amount,
            ac.check_date,
            ac.checkrun_name,
            ac.status_lookup_code,
            ac.payment_id,
            pay.void_date
     FROM ap_checks_all ac,
          iby_payments_all pay,
          ap_invoice_payments_all ip,
          (
            ##$$CVIEW$$##
          ) chks
     WHERE ip.check_id = ac.check_id
     AND   nvl(ip.reversal_flag, ''N'') ! = ''Y''
     AND   pay.payment_status = ''VOID''
     AND   ac.status_lookup_code in (''NEGOTIABLE'', ''ISSUED'')
     AND   ac.void_date is null
     AND   pay.payment_id = ac.payment_id
     AND   NOT EXISTS (
             SELECT 1 FROM ap_payment_history_all ph
             WHERE  ph.check_id = ac.check_id
             AND    ph.transaction_type = ''PAYMENT CANCELLED'')
     AND   ac.check_id = chks.check_id', -- The text of the signature query
  'Checks Voided in Payments but Still Negotiable in Payables',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Checks voided in Payments but still negotiable in Payables',     -- Problem description
  'Refer Note- [1206075.1] and apply the solution ',     -- Problem solution
  'Checks voided successfully',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y'); 
        
        
        
  ---------------------------------------------------------------
  -- Checks in functional currency with exchange rate information
  ---------------------------------------------------------------         

add_signature(
  'ap_checks_misc_sel_check_1', -- Unique Signature identifier
  'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.currency_code,
            aph.payment_history_id,
            aph.transaction_type,
            aph.trx_base_amount,
            aph.accounting_event_id,
            aph.pmt_to_base_xrate_type,
            aph.pmt_to_base_xrate_date,
            aph.pmt_to_base_xrate
     FROM ap_checks_all ac,
          ap_payment_history_all aph,
          ap_system_parameters_all asp,
          (
            ##$$CVIEW$$##
          ) chks
     WHERE ac.check_id = aph.check_id
     AND   asp.org_id = ac.org_id
     AND   asp.base_currency_code = ac.currency_code
     AND   (aph.pmt_to_base_xrate is not null OR
            ac.exchange_rate is not null)
     AND   ac.check_id = chks.check_id', -- The text of the signature query
  'Checks in Functional Currency with Exchange Rate Information Populated in ap_checks_all or ap_payment_history_all',     -- Problem description
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Checks in functional currency with exchange rate information populated in ap_checks_all or ap_payment_history_all.',     -- Problem description
  'Refer Note- [1264221.1] and apply the solution ',     -- Problem solution
  'Functional currency Checks having no exchange rate populated.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');         
        


  ---------------------------------------------------------------
  -- Voided checks with incorrect statuses in ap_checks_all
  ---------------------------------------------------------------   

add_signature(
  'ap_checks_misc_sel_check_2', -- Unique Signature identifier
  'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.status_lookup_code,
            ac.void_date
     FROM ap_checks_all ac,
          ap_payment_history_all aph,
          ap_invoice_payments_all aip,
          (
            ##$$CVIEW$$##
          ) chks
     WHERE ac.status_lookup_code NOT IN (''VOIDED'',''OVERFLOW'')
     AND   ac.check_id = aph.check_id
     AND   aph.transaction_type = ''PAYMENT CANCELLED''
     AND   aip.accounting_event_id = aph.accounting_event_id
     AND   aip.check_id = ac.check_id
     AND   aip.reversal_inv_pmt_id IS NOT NULL
     AND   ac.check_id = chks.check_id', -- The text of the signature query
  'Voided Checks with Incorrect Statuses in ap_checks_all',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Voided checks with incorrect statuses in ap_checks_all.',     -- Problem description
  'Refer Note- [1264221.1] and apply the solution ',     -- Problem solution
  'Voided checks with correct statuses in ap_checks_all.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


  ---------------------------------------------------------------
  -- Refund checks with maturity rate information populated
  ---------------------------------------------------------------   

add_signature(
  'ap_checks_misc_sel_check_3', -- Unique Signature identifier
  'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.status_lookup_code,
            ac.payment_type_flag,
            ac.maturity_exchange_date,
            ac.maturity_exchange_rate_type,
            ac.maturity_exchange_rate,
            ac.future_pay_due_date
     FROM ap_checks_all ac,
          (
            ##$$CVIEW$$##
          ) chks
     WHERE payment_type_flag = ''R''
     AND   (maturity_exchange_date is not null OR
            maturity_exchange_rate_type is not null OR
            maturity_exchange_rate is not null OR
            future_pay_due_date is not null OR
            EXISTS (
              SELECT 1 FROM ap_payment_history_all aph
              WHERE aph.check_id = ac.check_id
              AND   aph.transaction_type = ''PAYMENT MATURITY''))
     AND   EXISTS (
             SELECT 1 FROM ap_payment_history_all aph
             WHERE aph.check_id = ac.check_id
             AND   aph.transaction_type = ''REFUND RECORDED'')
     AND   ac.check_id = chks.check_id', -- The text of the signature query
  'Refund Checks with Maturity Rate Information Populated',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Refund checks with maturity rate information populated.',     -- Problem description
  'Refer Note- [1264221.1] and apply the solution ',     -- Problem solution
  'Refund checks without maturity rate information.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
        
        
  ---------------------------------------------------------------
  -- Checks which have been reconciled but which have a status of NEGOTIABLE in ap_checks_all
  ---------------------------------------------------------------   


add_signature(
  'ap_check_stat_incorrect_sel', -- Unique Signature identifier
  'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.check_date,
            ac.amount,
            ac.vendor_name,
            ac.status_lookup_code,
            ac.org_id,
            ac.cleared_amount,
            ac.cleared_date
     FROM ap_checks_all ac,
          ap_system_parameters_all asp,
          (
            ##$$CVIEW$$##
          ) chks
     WHERE ac.org_id = asp.org_id
     AND   asp.recon_accounting_flag = ''Y''
     AND   ac.status_lookup_code = ''NEGOTIABLE''
     AND   ac.check_id IN (
             SELECT aph.check_id FROM ap_payment_history_all aph
             WHERE aph.check_id = ac.check_id
             AND   aph.transaction_type = ''PAYMENT CLEARING''
             AND   aph.payment_history_id = (
                     SELECT max(aph2.payment_history_id) FROM ap_payment_history_all aph2
                     WHERE aph2.transaction_type in
                             (''PAYMENT CLEARING'',''PAYMENT UNCLEARING'')
                     AND   ac.check_id = aph2.check_id))
     AND   NOT EXISTS (
             SELECT ''1'' FROM ap_payment_history_all aph1
             WHERE ac.check_id = aph1.check_id
             AND   aph1.transaction_type = ''PAYMENT CANCELLED'')
     AND   ac.check_id = chks.check_id', -- The text of the signature query
  'Checks Which Have Been Reconciled but Which Have a Status of Negotiable in ap_checks_all',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Checks which have been reconciled but which have a status of NEGOTIABLE in ap_checks_all.',     -- Problem description
  'Refer Note- [1315138.1] and apply the solution ',     -- Problem solution
  'Checks successfully reconciled.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');  
        
        
        
  ---------------------------------------------------------------
  -- 'Checks with bills payable but missing payment maturity event
  ---------------------------------------------------------------         
        

add_signature(
  'ap_missing_mat_event_sel', -- Unique Signature identifier
  'SELECT ac.check_id ,
            ac.check_number,
            ac.org_id,
            ac.status_lookup_code,
            ac.payment_type_flag,
            ac.maturity_exchange_date,
            ac.maturity_exchange_rate_type,
            ac.maturity_exchange_rate,
            ac.future_pay_due_date,
            ac.cleared_date,
            ac.actual_value_date
     FROM ap_payment_history_all aph,
          ap_checks_all ac,
          iby_payments_all ibp,
          (
            ##$$CVIEW$$##
          ) chks
     WHERE aph.check_id = ac.check_id
     AND   ibp.payment_id = ac.payment_id
     AND   ibp.payment_method_code = ac.payment_method_code
     AND   nvl(ibp.bill_payable_flag,''N'')  = ''Y''
     AND   ac.future_pay_due_date is not null
     AND   ac.status_lookup_code <> ''ISSUED''
     AND   ac.void_date is null
     AND   aph.transaction_type = ''PAYMENT CREATED''
     AND   NOT EXISTS (
             SELECT 1 FROM ap_payment_history_all aph3
             WHERE aph.check_id = aph3.check_id
             AND aph3.transaction_type = ''PAYMENT MATURITY'')
     AND   ac.check_id = chks.check_id', -- The text of the signature query
  'Checks with Bills Payable but Missing Payment Maturity Event',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Checks with bills payable but missing payment maturity event.',     -- Problem description
  'Refer Note- [1309501.1] and apply the solution ',     -- Problem solution
  'Checks with bills payable having payment maturity event.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');        
        
        


/*#################################################
  #  S e t u p   S i g s                          #
  #################################################*/

  /*###########################
    #  Document Type Setup    #
    ###########################*/

  l_info.delete;
  add_signature(
   'ORG_DOC_TYPES',
   'SELECT dt.type_name document_type,
           dt.org_id,
           dt.document_type_code,
           dt.document_subtype,
           dt.can_preparer_approve_flag "Preparer Can Approve",
           dt.can_change_approval_path_flag "Change Approval Path",
           dt.can_approver_modify_doc_flag "Approver Can Modify Doc",
           dt.can_change_forward_from_flag "Change Forward From",
           dt.can_change_forward_to_flag "Change Forward To",
           dt.forwarding_mode_code forwarding_method,
           s.name hierarchy_name,
           dt.default_approval_path_id,
           wfit.display_name workflow_process,
           wfrp.display_name workflow_top_process,
           dt.wf_createdoc_itemtype,
           dt.wf_createdoc_process,
           dt.ame_transaction_type,
           dt.archive_external_revision_code,
           dt.quotation_class_code,
           dt.security_level_code,
           dt.access_level_code,
           dt.disabled_flag,
           dt.use_contract_for_sourcing_flag,
           dt.include_noncatalog_flag,
           dt.document_template_code,
           dt.contract_template_code
    FROM po_document_types_all dt,
         per_position_structures s,
         wf_item_types_vl wfit,
         wf_runnable_processes_v wfrp
    WHERE dt.org_id = ##$$ORGID$$##
    AND   dt.default_approval_path_id = s.position_structure_id(+)
    AND   dt.wf_approval_itemtype = wfit.name(+)
    AND   dt.wf_approval_process = wfrp.process_name(+)
    AND   dt.document_type_code IN (''PO'',''PA'',
            ''REQUISITION'',''RELEASE'')',
    'Organization Document Types Setup',
    'NRS',
    null,
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');
    
    
  
    
  ---------------------------------------------
  -- Line Type Setup
  ---------------------------------------------  
    
    
  l_info.delete;
  add_signature(
   'ORG_LINE_TYPES',
   'SELECT
       * 
    FROM
       (SELECT
          LINE_TYPE,
          DESCRIPTION,
          DISPLAYED_ORDER_TYPE AS VALUE_BASIS,
          PURCHASE_BASIS_DSP,
          INACTIVE_DATE,
          LINE_TYPE_ID "##$$FK1$$##"
       FROM
          PO_LINE_TYPES_V) QRSLT 
    ORDER BY
       LINE_TYPE',
    'Organization Line Types Setup',
    'NRS',
    null,
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
   l_info,
   VARCHAR_TBL('ORG_LINE_TYPES_DETAILS'),
     p_include_in_dx_summary => 'Y');
        


  -------------------------------------------------------------------
  -- Line Type Setup - Details
  -------------------------------------------------------------------- 
  l_info.delete;
  add_signature(
   'ORG_LINE_TYPES_DETAILS',
   'SELECT
       PoLineTypeEO.LINE_TYPE_ID,
      /* PoLineTypeEO.ATTRIBUTE3,
       PoLineTypeEO.ATTRIBUTE4,
       PoLineTypeEO.ATTRIBUTE5,
       PoLineTypeEO.ATTRIBUTE6,
       PoLineTypeEO.ATTRIBUTE7,
       PoLineTypeEO.ATTRIBUTE8,
       PoLineTypeEO.ATTRIBUTE9,
       PoLineTypeEO.ATTRIBUTE10,
       PoLineTypeEO.ATTRIBUTE11,
       PoLineTypeEO.ATTRIBUTE12,
       PoLineTypeEO.ATTRIBUTE13,
       PoLineTypeEO.ATTRIBUTE14,
       PoLineTypeEO.ATTRIBUTE15,*/
       PoLineTypeEO.OUTSIDE_OPERATION_FLAG,
       PoLineTypeEO.RECEIVE_CLOSE_TOLERANCE,
       PoLineTypeEO.ORDER_TYPE_LOOKUP_CODE,
       PoLineTypeEO.UNIT_OF_MEASURE,
       PoLineTypeEO.UNIT_PRICE,
       PoLineTypeEO.RECEIVING_FLAG,
       PoLineTypeEO.INACTIVE_DATE,
       PoLineTypeEO.ATTRIBUTE_CATEGORY,
     /*  PoLineTypeEO.ATTRIBUTE1,
       PoLineTypeEO.ATTRIBUTE2, */
       PoLineTypeEO.LINE_TYPE,
       PoLineTypeEO.PURCHASE_BASIS,
       PoLineTypeEO.CATEGORY_ID,
       PoLineTypeEO.DESCRIPTION
    /*   PoLineTypeEO.CLM_SEVERABLE_FLAG */
    FROM
       PO_LINE_TYPES_VL PoLineTypeEO 
    WHERE
       (
          LINE_TYPE_ID = ##$$FK1$$##
       )',
   'Organization Line Types Details',
    'NRS',
    null,
    null,
    null,
    'ALWAYS',
    'I',
      p_include_in_dx_summary => 'Y'); 

    
    
  ---------------------------------------------
  -- Financials Options Setup
  ---------------------------------------------
    
 l_info.delete;  
	add_signature(
   'FINANCIAL_OPTIONS_SETUP',
   'SELECT hr.name,
	  fsp.ORG_ID org_id,
	  fsp.SET_OF_BOOKS_ID SOB_ID,
	  fsp.INVENTORY_ORGANIZATION_ID,
	  fsp.REQ_ENCUMBRANCE_FLAG "Use Requisition Encumbrance",
	  fsp.RESERVE_AT_COMPLETION_FLAG "Reserve at Completion",
	  fsp.PURCH_ENCUMBRANCE_FLAG "Use PO Encumbrance",
	  fsp.REQ_ENCUMBRANCE_TYPE_ID req_encumbrance_type_id,
	  fsp.PURCH_ENCUMBRANCE_TYPE_ID po_encumbrance_type_id,
	  fsp.INV_ENCUMBRANCE_TYPE_ID
	FROM financials_system_params_all fsp,
	  hr_operating_units hr
	WHERE fsp.ORG_ID = hr.ORGANIZATION_ID
	AND org_id       = ##$$ORGID$$##',
	'Financial Options Setup',
	'RS',
	'Review data for detail setup of the Financial Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for financials options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        p_include_in_dx_summary => 'Y');    
    
    
  ---------------------------------------------
  -- Purchasing Options Setup 12.1
  ---------------------------------------------
  l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_SETUP_12_1',
   'SELECT ''Expand subsections below to see the PO Options'' "PO Options"
    FROM dual',
	'Purchasing Options Setup',
	'[count]<[0]',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
       '<ul>
          <li>Review data for detail setup of the Purchasing Options of the Operating Unit</li>
        </ul>',
	'ALWAYS',
	'I',
        'RS',
        'Y',
        l_info,
        VARCHAR_TBL('PURCHASING_OPTIONS_DOCUMENT_CONTROL_SETUP_12_1','PURCHASING_OPTIONS_DOCUMENT_DEFAULTS_12_1','PURCHASING_OPTIONS_RECEIPT_ACCOUNTING_12_1','PURCHASING_OPTIONS_DOCUMENT_NUMBERING'),   
        p_include_in_dx_summary => 'Y');  
        
  ---------------------------------------------
  -- Purchasing Options Setup 12.2
  ---------------------------------------------
  l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_SETUP_12_2',
   'SELECT ''Expand subsections below to see the PO Options'' "PO Options"
    FROM dual',
	'Purchasing Options Setup',
	'[count]<[0]',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
       '<ul>
          <li>Review data for detail setup of the Purchasing Options of the Operating Unit</li>
        </ul>',
	'ALWAYS',
	'I',
        'RS',
        'Y',
        l_info,
        VARCHAR_TBL('PURCHASING_OPTIONS_DOCUMENT_CONTROL_SETUP_12_2','PURCHASING_OPTIONS_DOCUMENT_DEFAULTS_12_2','PURCHASING_OPTIONS_RECEIPT_ACCOUNTING_12_2','PURCHASING_OPTIONS_DOCUMENT_NUMBERING'),   
        p_include_in_dx_summary => 'Y');         
        
        
        
        
  -----------------------------------------------
  -- Purchasing Options Setup - Document Control 12.2
  -----------------------------------------------       
   l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_DOCUMENT_CONTROL_SETUP_12_2',
   'SELECT
           PoSystemParameterEO.PRICE_CHANGE_ALLOWANCE "Price Tolerance (%)",
           PoSystemParameterEO.PRICE_CHANGE_AMOUNT "Price Tolernace Amount",
           PoSystemParameterEO.ENFORCE_FULL_LOT_QUANTITIES "Enforce Full Lot Quantity",   
           PoSystemParameterEO.RECEIVE_CLOSE_CODE "Receipt Close Point",
           decode(PoSystemParameterEO.CANCEL_REQS_ON_PO_CANCEL_FLAG,''O'',''Optionally'',''A'',''Always'',''N'',''Never'') "Cancel Requisitions", -- O - optional, A - Always, N - Never
           PoSystemParameterEO.BUYING_COMPANY_IDENTIFIER "SBI Buying Company Identifier",
           PoSystemParameterEO.PO_OUTPUT_FORMAT "Output Format",
           PoSystemParameterEO.MAX_ATTACHMENT_SIZE "Max Attachment Size (in MB)",
           PoSystemParameterEO.EMAIL_ATTACHMENT_FILENAME "Email Attachment Filename",
           PoSystemParameterEO.ENFORCE_PRICE_CHANGE_ALLOWANCE "Enforce Price Tolerance (%)",
           PoSystemParameterEO.ENFORCE_PRICE_CHANGE_AMOUNT "Enforce Price Tolerance Amount",
           PoSystemParameterEO.DISPOSITION_WARNING_FLAG "Display Disposition Messages",
           PoSystemParameterEO.NOTIFY_IF_BLANKET_FLAG "Notify if Blanket PO exists",
           PoSystemParameterEO.ALLOW_ITEM_DESC_UPDATE_FLAG "Allow Item Description Update",
           PoSystemParameterEO.ENFORCE_BUYER_NAME_FLAG "Enforce Buyer Name",
           PoSystemParameterEO.ENFORCE_VENDOR_HOLD_FLAG "Enforce Supplier Hold",
           PoSystemParameterEO.GAPLESS_INV_NUM_FLAG "Gapless Invoice Numbering",
           PoSystemParameterEO.RFQ_REQUIRED_FLAG "RFQ Required",
           PoSystemParameterEO.group_shipments_flag "Group Shipments"
        FROM
           PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO,
           oe_transaction_types ot,
           po_line_types_val_v pltv,
           per_position_structures pps,
           xdo_ds_definitions_vl xdd1,
           xdo_ds_definitions_vl xdd2,
           xdo_ds_definitions_vl xdd3,
           xdo_ds_definitions_vl xdd4,
           po_lookup_codes plc 
        where
           PoSystemParameterEO.org_id = ##$$ORGID$$## 
           and PoSystemParameterEO.ORDER_TYPE_ID = ot.transaction_type_id (+) 
           and PoSystemParameterEO.LINE_TYPE_ID = pltv.line_type_id (+) 
           and PoSystemParameterEO.SECURITY_POSITION_STRUCTURE_ID = pps.position_structure_id (+) --CLM Controls Project Changes 
           AND PoSystemParameterEO.FPDSNG_AWD_XML_SOURCE = xdd1.data_source_code (+) 
           AND PoSystemParameterEO.FPDSNG_IDV_XML_SOURCE = xdd2.data_source_code (+) 
           AND PoSystemParameterEO.FPDSNG_AWD_MOD_XML_SOURCE = xdd3.data_source_code (+) 
           AND PoSystemParameterEO.FPDSNG_IDV_MOD_XML_SOURCE = xdd4.data_source_code (+) 
           AND PoSystemParameterEO.FPDS_APPROV_NOTIF_TYPE = plc.LOOKUP_CODE (+) 
           AND plc.LOOKUP_TYPE (+) = ''PO_CLM_APPROVAL_NOTIF_TYPE''',
	'Document Control Setup',
	'RS',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for purchasing options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        p_include_in_dx_summary => 'Y');               
        
  -----------------------------------------------
  -- Purchasing Options Setup - Document Control 12.1
  -----------------------------------------------       
   l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_DOCUMENT_CONTROL_SETUP_12_1',
   'SELECT
           PoSystemParameterEO.PRICE_CHANGE_ALLOWANCE "Price Tolerance (%)",
           PoSystemParameterEO.PRICE_CHANGE_AMOUNT "Price Tolernace Amount",
           PoSystemParameterEO.ENFORCE_FULL_LOT_QUANTITIES "Enforce Full Lot Quantity",   
           PoSystemParameterEO.RECEIVE_CLOSE_CODE "Receipt Close Point",
           decode(PoSystemParameterEO.CANCEL_REQS_ON_PO_CANCEL_FLAG,''O'',''Optionally'',''A'',''Always'',''N'',''Never'') "Cancel Requisitions", -- O - optional, A - Always, N - Never
           PoSystemParameterEO.BUYING_COMPANY_IDENTIFIER "SBI Buying Company Identifier",
           PoSystemParameterEO.PO_OUTPUT_FORMAT "Output Format",
           PoSystemParameterEO.MAX_ATTACHMENT_SIZE "Max Attachment Size (in MB)",
           PoSystemParameterEO.EMAIL_ATTACHMENT_FILENAME "Email Attachment Filename",
           PoSystemParameterEO.ENFORCE_PRICE_CHANGE_ALLOWANCE "Enforce Price Tolerance (%)",
           PoSystemParameterEO.ENFORCE_PRICE_CHANGE_AMOUNT "Enforce Price Tolerance Amount",
           PoSystemParameterEO.DISPOSITION_WARNING_FLAG "Display Disposition Messages",
           PoSystemParameterEO.NOTIFY_IF_BLANKET_FLAG "Notify if Blanket PO exists",
           PoSystemParameterEO.ALLOW_ITEM_DESC_UPDATE_FLAG "Allow Item Description Update",
           PoSystemParameterEO.ENFORCE_BUYER_NAME_FLAG "Enforce Buyer Name",
           PoSystemParameterEO.ENFORCE_VENDOR_HOLD_FLAG "Enforce Supplier Hold",
           PoSystemParameterEO.GAPLESS_INV_NUM_FLAG "Gapless Invoice Numbering",
           PoSystemParameterEO.RFQ_REQUIRED_FLAG "RFQ Required",
           PoSystemParameterEO.group_shipments_flag "Group Shipments"
        FROM
           PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO,
           oe_transaction_types ot,
           po_line_types_val_v pltv,
           per_position_structures pps
        where
           PoSystemParameterEO.org_id = ##$$ORGID$$## 

        and PoSystemParameterEO.ORDER_TYPE_ID = ot.transaction_type_id (+) 
        and PoSystemParameterEO.LINE_TYPE_ID = pltv.line_type_id (+) 
        and PoSystemParameterEO.SECURITY_POSITION_STRUCTURE_ID = pps.position_structure_id (+)',
	'Document Control Setup',
	'RS',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for purchasing options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        p_include_in_dx_summary => 'Y');  

  -----------------------------------------------
  -- Purchasing Options Setup - Document Defaults 12.2
  -----------------------------------------------        
   l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_DOCUMENT_DEFAULTS_12_2',
   'SELECT
       PoSystemParameterEO.REQIMPORT_GROUP_BY_CODE "Requisition Import Group-By",
       PoSystemParameterEO.ORDER_TYPE_ID "Internal Req Order Type",
       PoSystemParameterEO.ORDER_SOURCE_ID "Internal Req Order Source",
       PoSystemParameterEO.RECEIVE_CLOSE_TOLERANCE "Receipt Close Tolerance (%)",
       PoSystemParameterEO.INVOICE_CLOSE_TOLERANCE "Invoice Close Tolerance (%)",
       PoSystemParameterEO.DEFAULT_QUOTE_WARNING_DELAY "Quote Warning Delay",
       decode(PoSystemParameterEO.ACCEPTANCE_REQUIRED_FLAG,''D'',''Document'',''N'',''None'',''P'',''Proxy Signature'',''S'',''Signature'',''Y'',''Docuement or Shipment'') "Acceptance Required Flag",
       pltv.line_type "Line Type",
       PoSystemParameterEO.DEFAULT_RATE_TYPE "Rate Type",
       PoSystemParameterEO.PRICE_BREAK_LOOKUP_CODE "Price Break Type",
       PoSystemParameterEO.PRICE_TYPE_LOOKUP_CODE "Price Type",
       PoSystemParameterEO.MIN_RELEASE_AMOUNT "Minimum Release Amount"
    FROM
       PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO,
       oe_transaction_types ot,
       po_line_types_val_v pltv,
       per_position_structures pps,
       xdo_ds_definitions_vl xdd1,
       xdo_ds_definitions_vl xdd2,
       xdo_ds_definitions_vl xdd3,
       xdo_ds_definitions_vl xdd4,
       po_lookup_codes plc 
    where
       PoSystemParameterEO.org_id = ##$$ORGID$$##
       and PoSystemParameterEO.ORDER_TYPE_ID = ot.transaction_type_id (+) 
       and PoSystemParameterEO.LINE_TYPE_ID = pltv.line_type_id (+) 
       and PoSystemParameterEO.SECURITY_POSITION_STRUCTURE_ID = pps.position_structure_id (+) --CLM Controls Project Changes 
       AND PoSystemParameterEO.FPDSNG_AWD_XML_SOURCE = xdd1.data_source_code (+) 
       AND PoSystemParameterEO.FPDSNG_IDV_XML_SOURCE = xdd2.data_source_code (+) 
       AND PoSystemParameterEO.FPDSNG_AWD_MOD_XML_SOURCE = xdd3.data_source_code (+) 
       AND PoSystemParameterEO.FPDSNG_IDV_MOD_XML_SOURCE = xdd4.data_source_code (+) 
       AND PoSystemParameterEO.FPDS_APPROV_NOTIF_TYPE = plc.LOOKUP_CODE (+) 
       AND plc.LOOKUP_TYPE (+) = ''PO_CLM_APPROVAL_NOTIF_TYPE''',
	'Document Defaults Setup',
	'RS',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for purchasing options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        p_include_in_dx_summary => 'Y');


  -----------------------------------------------
  -- Purchasing Options Setup - Document Defaults 12.1
  -----------------------------------------------        
   l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_DOCUMENT_DEFAULTS_12_1',
   'SELECT
       PoSystemParameterEO.REQIMPORT_GROUP_BY_CODE "Requisition Import Group-By",
       PoSystemParameterEO.ORDER_TYPE_ID "Internal Req Order Type",
       PoSystemParameterEO.ORDER_SOURCE_ID "Internal Req Order Source",
       PoSystemParameterEO.RECEIVE_CLOSE_TOLERANCE "Receipt Close Tolerance (%)",
       PoSystemParameterEO.INVOICE_CLOSE_TOLERANCE "Invoice Close Tolerance (%)",
       PoSystemParameterEO.DEFAULT_QUOTE_WARNING_DELAY "Quote Warning Delay",
       decode(PoSystemParameterEO.ACCEPTANCE_REQUIRED_FLAG,''D'',''Document'',''N'',''None'',''P'',''Proxy Signature'',''S'',''Signature'',''Y'',''Docuement or Shipment'') "Acceptance Required Flag",
       pltv.line_type "Line Type",
       PoSystemParameterEO.DEFAULT_RATE_TYPE "Rate Type",
       PoSystemParameterEO.PRICE_BREAK_LOOKUP_CODE "Price Break Type",
       PoSystemParameterEO.PRICE_TYPE_LOOKUP_CODE "Price Type",
       PoSystemParameterEO.MIN_RELEASE_AMOUNT "Minimum Release Amount"
    FROM
           PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO,
           oe_transaction_types ot,
           po_line_types_val_v pltv,
           per_position_structures pps
    where
           PoSystemParameterEO.org_id = ##$$ORGID$$## 
        and PoSystemParameterEO.ORDER_TYPE_ID = ot.transaction_type_id (+) 
        and PoSystemParameterEO.LINE_TYPE_ID = pltv.line_type_id (+) 
        and PoSystemParameterEO.SECURITY_POSITION_STRUCTURE_ID = pps.position_structure_id (+)',
	'Document Defaults Setup',
	'RS',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for purchasing options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        p_include_in_dx_summary => 'Y');

        
  ------------------------------------------------
  -- Purchasing Options Setup - Receipt Accounting 12.2
  ------------------------------------------------       
   l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_RECEIPT_ACCOUNTING_12_2',
   'SELECT
       PoSystemParameterEO.EXPENSE_ACCRUAL_CODE "Accrue Expense Items",
       PoSystemParameterEO.INVENTORY_ACCRUAL_CODE "Accrue Inventory Items",
       PoSystemParameterEO.AUTO_OFFSET_METHOD "Automatic Offet Method"
    FROM
       PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO,
       oe_transaction_types ot,
       po_line_types_val_v pltv,
       per_position_structures pps,
       xdo_ds_definitions_vl xdd1,
       xdo_ds_definitions_vl xdd2,
       xdo_ds_definitions_vl xdd3,
       xdo_ds_definitions_vl xdd4,
       po_lookup_codes plc 
    where
       PoSystemParameterEO.org_id = ##$$ORGID$$##
       and PoSystemParameterEO.ORDER_TYPE_ID = ot.transaction_type_id (+) 
       and PoSystemParameterEO.LINE_TYPE_ID = pltv.line_type_id (+) 
       and PoSystemParameterEO.SECURITY_POSITION_STRUCTURE_ID = pps.position_structure_id (+) --CLM Controls Project Changes 
       AND PoSystemParameterEO.FPDSNG_AWD_XML_SOURCE = xdd1.data_source_code (+) 
       AND PoSystemParameterEO.FPDSNG_IDV_XML_SOURCE = xdd2.data_source_code (+) 
       AND PoSystemParameterEO.FPDSNG_AWD_MOD_XML_SOURCE = xdd3.data_source_code (+) 
       AND PoSystemParameterEO.FPDSNG_IDV_MOD_XML_SOURCE = xdd4.data_source_code (+) 
       AND PoSystemParameterEO.FPDS_APPROV_NOTIF_TYPE = plc.LOOKUP_CODE (+) 
       AND plc.LOOKUP_TYPE (+) = ''PO_CLM_APPROVAL_NOTIF_TYPE''',
	'Accounting Setup',
	'RS',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for purchasing options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        p_include_in_dx_summary => 'Y');  
        
       
  ------------------------------------------------
  -- Purchasing Options Setup - Receipt Accounting 12.1
  ------------------------------------------------       
   l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_RECEIPT_ACCOUNTING_12_1',
   'SELECT
       PoSystemParameterEO.EXPENSE_ACCRUAL_CODE "Accrue Expense Items",
       PoSystemParameterEO.INVENTORY_ACCRUAL_CODE "Accrue Inventory Items",
       PoSystemParameterEO.AUTO_OFFSET_METHOD "Automatic Offet Method"
    FROM
           PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO,
           oe_transaction_types ot,
           po_line_types_val_v pltv,
           per_position_structures pps
    where
           PoSystemParameterEO.org_id = ##$$ORGID$$## 
        and PoSystemParameterEO.ORDER_TYPE_ID = ot.transaction_type_id (+) 
        and PoSystemParameterEO.LINE_TYPE_ID = pltv.line_type_id (+) 
        and PoSystemParameterEO.SECURITY_POSITION_STRUCTURE_ID = pps.position_structure_id (+)',
	'Accounting Setup',
	'RS',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for purchasing options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        p_include_in_dx_summary => 'Y');  
                
        
        
  ------------------------------------------------
  -- Purchasing Options Setup - Document Numbering
  ------------------------------------------------       
   l_info.delete;  
  add_signature(
   'PURCHASING_OPTIONS_DOCUMENT_NUMBERING',
   'SELECT decode(PoUniqueIdentifierContEO.TABLE_NAME,''PO_HEADERS_RFQ'',''RFQ Number'') "Document",
       PoSystemParameterEO.USER_DEFINED_RFQ_NUM_CODE "Entry",
       PoSystemParameterEO.MANUAL_RFQ_NUM_TYPE "Type",
       PoUniqueIdentifierContEO.CURRENT_MAX_UNIQUE_IDENTIFIER "Current Number"
       FROM PO_UNIQUE_IDENTIFIER_CONT_ALL PoUniqueIdentifierContEO,
       PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO
       where PoSystemParameterEO.org_id = ##$$ORGID$$##
       and PoUniqueIdentifierContEO.ORG_ID = PoSystemParameterEO.org_id 
       and PoUniqueIdentifierContEO.table_name in (''PO_HEADERS_RFQ'')
UNION
  SELECT decode(PoUniqueIdentifierContEO.TABLE_NAME,''PO_HEADERS_QUOTE'',''Quotation Number'') "Document",
       PoSystemParameterEO.USER_DEFINED_QUOTE_NUM_CODE "Entry",
       PoSystemParameterEO.MANUAL_QUOTE_NUM_TYPE "Type",
       PoUniqueIdentifierContEO.CURRENT_MAX_UNIQUE_IDENTIFIER "Current Number"
       FROM PO_UNIQUE_IDENTIFIER_CONT_ALL PoUniqueIdentifierContEO,
       PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO
       where PoSystemParameterEO.org_id = ##$$ORGID$$##
       and PoUniqueIdentifierContEO.ORG_ID = PoSystemParameterEO.org_id 
       and PoUniqueIdentifierContEO.table_name in (''PO_HEADERS_QUOTE'')
UNION
  SELECT decode(PoUniqueIdentifierContEO.TABLE_NAME,''PO_HEADERS'',''PO Number'') "Document",
       PoSystemParameterEO.USER_DEFINED_PO_NUM_CODE "Entry",
       PoSystemParameterEO.MANUAL_PO_NUM_TYPE "Type",
       PoUniqueIdentifierContEO.CURRENT_MAX_UNIQUE_IDENTIFIER "Current Number"
       FROM PO_UNIQUE_IDENTIFIER_CONT_ALL PoUniqueIdentifierContEO,
       PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO
       where PoSystemParameterEO.org_id = ##$$ORGID$$##
       and PoUniqueIdentifierContEO.ORG_ID = PoSystemParameterEO.org_id 
       and PoUniqueIdentifierContEO.table_name in (''PO_HEADERS'')
UNION
  SELECT decode(PoUniqueIdentifierContEO.TABLE_NAME,''PO_REQUISITION_HEADERS'',''Requisition Number'') "Document",
       PoSystemParameterEO.USER_DEFINED_REQ_NUM_CODE "Entry",
       PoSystemParameterEO.MANUAL_REQ_NUM_TYPE "Type",
       PoUniqueIdentifierContEO.CURRENT_MAX_UNIQUE_IDENTIFIER "Current Number"
       FROM PO_UNIQUE_IDENTIFIER_CONT_ALL PoUniqueIdentifierContEO,
       PO_SYSTEM_PARAMETERS_ALL PoSystemParameterEO
       where PoSystemParameterEO.org_id = ##$$ORGID$$##
       and PoUniqueIdentifierContEO.ORG_ID = PoSystemParameterEO.org_id 
       and PoUniqueIdentifierContEO.table_name in (''PO_REQUISITION_HEADERS'') ',
	'Document Numbering Setup',
	'RS',
	'Review data for detail setup of the Purchasing Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for purchasing options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        p_include_in_dx_summary => 'Y');          
        
        

  ---------------------------------------------
  -- Receiving Options Setup
  ---------------------------------------------
  l_info.delete;  
  add_signature(
   'RECEIVING_OPTIONS_SETUP',
   'SELECT hr.name,
         rp.ORGANIZATION_ID,
         rp.ENFORCE_SHIP_TO_LOCATION_CODE "Enforce Ship-To",
         rp.RECEIPT_ASN_EXISTS_CODE "ASN Control Action",
         rp.DAYS_EARLY_RECEIPT_ALLOWED "Receipt Days Early",
         rp.DAYS_LATE_RECEIPT_ALLOWED "Receipt Days Late",
         rp.RECEIPT_DAYS_EXCEPTION_CODE "Receipt Days Exceed-Action",
         rp.QTY_RCV_TOLERANCE "Over Receipt Tolerance (%)",
         rp.QTY_RCV_EXCEPTION_CODE "Over Receipt Action",
         decode(rp.RMA_RECEIPT_ROUTING_ID,1,''Standard Receipt'',2,''Inspection Required'',3,''Direct Delivery'',null) "RMA Receipt Routing",
         decode(rp.RECEIVING_ROUTING_ID,1,''Standard Receipt'',2,''Inspection Required'',3,''Direct Delivery'',null)  "Receipt Routing",
         rp.ALLOW_SUBSTITUTE_RECEIPTS_FLAG "Allow Substitute Receipts",
         rp.ALLOW_UNORDERED_RECEIPTS_FLAG "Allow Unordered Receipts",
         rp.ALLOW_EXPRESS_DELIVERY_FLAG "Allow Express Transactions",
         rp.ALLOW_CASCADE_TRANSACTIONS "Allow Cascade Transactions",
         rp.BLIND_RECEIVING_FLAG "Allow Blind Receiving",
         rp.ENFORCE_RMA_SERIAL_NUM "Validate Serial# RMA Receipt",
         rp.USER_DEFINED_RECEIPT_NUM_CODE "Receipt # Generation",
         rp.MANUAL_RECEIPT_NUM_TYPE "Receipt Number Type",
         rp.NEXT_RECEIPT_NUM "Last Used Receipt Number"
  FROM   rcv_parameters rp,
         hr_operating_units hr
  WHERE  rp.ORGANIZATION_ID = hr.ORGANIZATION_ID
  AND    rp.ORGANIZATION_ID   =  ##$$ORGID$$##',
  	'Receiving Options Setup',
	'RS',
	'Review data for detail setup of the Receiving Options of the Operating Unit',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
   '<ul>
      <li>No Data Found for Receiving options setup</li>
    </ul>',
	'ALWAYS',
	'I',
        'RS',
        p_include_in_dx_summary => 'Y');  
        
  ---------------------------------------------
  -- Display PO Style Details when AME is used
  ---------------------------------------------

  add_signature(
   'DOC_PO_STYLE_HEADER',
   'SELECT *
    FROM po_doc_style_headers
    ORDER BY style_name',
   'PO Style Header Details',
   'NRS',
   'The style header table data coult not be retrieved!',
   null,
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');   
            






   
/*#################################################
  #   R U P  L E V E L  S i g s #
  #################################################*/


     -------------------------------------------
     -- Release 12 RUP 
     -------------------------------------------
   
  l_info.delete;
  add_signature(
   'PROC_CODE_LEVEL_12_0',
   'SELECT distinct(bug_number), decode((bug_number),
      ''4440000'',''Release 12.0.0 - provides R12 baseline code for PRC_PF'',
      ''5082400'',''Release 12.0.1'',
      ''5484000'',''Release 12.0.2 - provides R12.PRC_PF.A.delta.2'',
      ''6141000'',''Release 12.0.3 - provides R12.PRC_PF.A.delta.3'',
      ''6435000'',''Release 12.0.4 - provides R12.PRC_PF.A.delta.4'',
      ''6728000'',''Release 12.0.6 - provides R12.PRC_PF.A.delta.6'',
      ''7015582'',''Procurement Release 12.0 Rollup Patch 5'',
      ''7218243'',''Procurement R12.0 Update July 2008'',
      ''7291462'',''Procurement R12.0 Update August 2008'',
      ''7355145'',''Procurement R12.0 Update Sept 2008'',
      ''7433336'',''Procurement R12.0 Update Oct 2008'',
      ''7505241'',''Procurement R12.0 Update Nov 2008'',
      ''7600636'',''Procurement R12.0 Update Dec 2008'',
      ''7691702'',''Procurement R12.0 Update Jan 2009'',
      ''8298073'',''Procurement R12.0 Update Mar 2009'',
      ''8392570'',''Procurement R12.0 Update Apr 2009'',
      ''8474052'',''Procurement R12.0 Update May 2009'',
      ''8555479'',''Procurement R12.0 Update Jun 2009'',
      ''8658242'',''Procurement R12.0 Update Jul 2009'',
      ''8781255'',''Procurement R12.0 Update Aug 2009'',
      ''Other'') "Description"
    FROM ad_bugs
    WHERE bug_number IN
      (''4440000'',''5082400'',''5484000'',''6141000'',''6435000'',
       ''6728000'',''7015582'',''7218243'',''7291462'',''7355145'',
       ''7433336'',''7505241'',''7600636'',''7691702'',''8298073'',
       ''8392570'',''8474052'',''8555479'',''8658242'',''8781255'')
    ORDER BY 2',
    'Patches Applied',
    'NRS',
    'No patches applied',
    'See [976188.1] R11i / R12 : Patch Wizard Utility [Video] on how to ensure you are on the latest patches ',
    'See [976188.1] R11i / R12 : Patch Wizard Utility [Video] on how to ensure you are on the latest patches ',
    'ALWAYS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');


     -------------------------------------------
     -- Release 12.1.x RUP 
     -------------------------------------------


    
  l_info.delete;
  add_signature(
   'PROC_CODE_LEVEL_12_1',
   'SELECT distinct(bug_number), decode((bug_number),
      ''7303030'',''Release 12.1.1 - provides R12.1 baseline code for PRC_PF'',
      ''7303033'',''Release 12.1.2 - provides R12.PRC_PF.B.delta.2'',
      ''9239090'',''Release 12.1.3 - provides R12.PRC_PF.B.delta.3'',
      ''8522002'',''R12.PRC_PF.B.delta.2'',
      ''9249354'',''R12.PRC_PF.B.delta.3'',
      ''10417963'',''Procurement R12.1.3 Update 2011/02 February 2011'',
      ''11817843'',''Procurement R12.1.3 Update 2011/04 April 2011'',
      ''12661793'',''Procurement R12.1.3 Update 2011/11 November 2011'',
      ''13984450'',''Procurement R12.1.3 Update 2012/06 June 2012'',
      ''14254641'',''Procurement R12.1.3 Update 2012/09 September 2012'',
      ''15843459'',''Procurement R12.1.3 Update 2013/03 March 2013'',
      ''17525552'',''Consolidated RUP covering iSupplier Portal Bug Fixes, Sourcing Bug Fixes post 12.1.3 and SLM new features'',
      ''17863140'',''Latest Recommended Patch Collection for Oracle Purchasing'',
      ''18120913'',''Procurement R12.1.3 Update 2014/01 January 2014'',
      ''17774755'',''Oracle E-Business Suite Release 12.1.3+ Recommended Patch Collection 1 [RPC1]'',
      ''18911810'',''Procurement R12.1.3 Update 2014/07 July 2014'',
      ''19030202'',''Oracle E-Business Suite Release 12.1.3+ Recommended Patch Collection 2 [RPC2]'',
      ''21198991'',''Procurement R12.1.3 Update 2015/03 March 2015'',
      ''Other'') "Description"
    FROM ad_bugs
    WHERE bug_number IN
      (''7303030'',''7303033'',''9239090'',''8522002'',''9249354'',
       ''10417963'',''11817843'',''12661793'',''13984450'',''14254641'',
       ''15843459'',''17525552'',''17863140'',''18120913'',''17774755'',
       ''18911810'',''19030202'',''21198991'')
    ORDER BY 2',
    'Patches Applied',
    'NRS',
    'No patches applied',
    'See [976188.1] R11i / R12 : Patch Wizard Utility [Video] on how to ensure you are on the latest patches ',
    'See [976188.1] R11i / R12 : Patch Wizard Utility [Video] on how to ensure you are on the latest patches ',
    'ALWAYS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');


     -------------------------------------------
     -- Release 12.2.x RUP 
     -------------------------------------------


  l_info.delete;
  add_signature(
   'PROC_CODE_LEVEL_12_2',
   'SELECT distinct(bug_number), decode((bug_number),
      ''16910001'',''Release 12.2.2 - provides R12.2 baseline code for PRC_PF'',
      ''17036666'',''Release 12.2.3 - provides R12.PRC_PF.B.delta.3'',
      ''17947999'',''Release 12.2.3 - provides R12.PRC_PF.B.delta.4'',
      ''17919161'',''12.2.4 -ORACLE E-BUSINESS SUITE 12.2.4 RELEASE UPDATE PACK'',
      ''Other'') "Description"
    FROM ad_bugs
    WHERE bug_number IN
      (''16910001'',''17036666'',''17947999'',''17919161'')
    ORDER BY 2',
    'Patches Applied',
    'NRS',
    'No patches applied',
    'See [976188.1] R11i / R12 : Patch Wizard Utility [Video] on how to ensure you are on the latest patches ',
    'See [976188.1] R11i / R12 : Patch Wizard Utility [Video] on how to ensure you are on the latest patches ',
    'ALWAYS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');   
    
    
   

/*#################################################
  #   D I A G  A P P S  C H E C K  S i g s #
  #################################################*/
  
  
   
  -------------------------------------------
  -- Diag Apps Check - File versions
  -------------------------------------------   
  
  l_info.delete;
  
  add_signature(
    'FILE_VERSIONS',
    'SELECT tl.Application_name, b.application_short_name,
            b.application_id "##$$FK1$$##",
            b.product_code "##$$FK2$$##"
       FROM fnd_application_tl tl, fnd_application b
      WHERE b.application_id in (401, 201, 178, 673, 203, 200)
        AND tl.application_id = b.application_id
        AND tl.language = ''US''
    ',
    'File versions',
    'NRS',
    'File versions',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    l_info,
     VARCHAR_TBL('PLSQL_FILE_VERSIONS', 'OTHER_FILE_VERSIONS'));      
  
  add_signature(
   'PLSQL_FILE_VERSIONS',
   'select
       o.object_name 
     , substr(ltrim(rtrim(substr(substr(s.text, instr(s.text,''Header: '')),
                                    instr(substr(s.text, instr(s.text,''Header: '')), '' '', 1, 1),
                                    instr(substr(s.text, instr(s.text,''Header: '')), '' '', 1, 2) -
                                    instr(substr(s.text, instr(s.text,''Header: '')), '' '', 1, 1) ))), 1, 25) "File Name"
     , substr(ltrim(rtrim(substr(substr(s.text, instr(s.text,''Header: '')),
                                    instr(substr(s.text, instr(s.text,''Header: '')), '' '', 1, 2),
                                    instr(substr(s.text, instr(s.text,''Header: '')), '' '', 1, 3) -
                                    instr(substr(s.text, instr(s.text,''Header: '')), '' '', 1, 2) ))), 1, 30) "File version"                               
     , decode(o.object_type, ''PACKAGE'' , ''SPEC'', ''PACKAGE BODY'', ''BODY'') type
     , o.object_type pkg_type
     , o.status status
     from  user_objects o , user_source s
     where s.name = o.object_name
     and   s.type = o.object_type
     and   o.object_type  in (''PACKAGE'' , ''PACKAGE BODY'')
     and   (o.object_name like ''##$$FK2$$##\_%'' escape ''\'') 
     and   s.line between 2 and 3
     and   s.text like ''%Header: %''
     order by 1, 3 desc, 5 desc',
    'Package versions',
    'NRS',
    'Package versions',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N');   
      
  l_info.delete;
  add_signature(
   'OTHER_FILE_VERSIONS',
   ' select distinct
           af.filename,
           substr(af.filename, instr(af.filename, ''.'')+1) ext
         , af.app_short_name
         , af.subdir
         , p2p_analyzer_pkg.get_file_ver(af.file_id)
      from   ad_files af, fnd_application fa
      where  af.app_short_name = fa.application_short_name
      and    fa.application_id = ##$$FK1$$##
      and    af.subdir not like ''admin%''
      and    af.subdir not like ''help%''
      and    af.subdir not like ''%driver%''
      and    af.subdir not like ''%readme%''
      and    substr(af.subdir, instr(af.subdir, ''/'', -1)+1) not in (select language_code
                                                                    from   fnd_languages
                                                                    where  installed_flag <> ''B'')
      and    af.filename not like ''%.txt''
      and    af.filename not like ''%.a''
      and    af.filename not like ''%.gif''
      and    af.filename not like ''%.htm''
      and    af.filename not like ''%.html''
      order by af.filename',
    'Other File versions',
    'NRS',
    'Could not find other file versions',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N');   
      
      
  -------------------------------------------         
  --  Profile Options
  -------------------------------------------   
    l_info.delete;
  
  add_signature(
    'PROFILE_OPTIONS',
    'SELECT tl.Application_name, b.application_short_name,
            b.application_id "##$$FK1$$##",
            b.product_code "##$$FK2$$##"
       FROM fnd_application_tl tl, fnd_application b
      WHERE b.application_id in (401, 201, 178, 673, 203, 200)
        AND tl.application_id = b.application_id
        AND tl.language = ''US''
    ',
    'Profile Options',
    'NRS',
    'Profile Options',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    l_info,
     VARCHAR_TBL('PRODUCT_PROFILE_VALUES')); 
     
     
  add_signature(
     'PRODUCT_PROFILE_VALUES',
     'SELECT user_profile_option_name "Profile Option",
             a.profile_option_value "Profile Value",
             DECODE(a.level_id, 10001, ''Site'',
                                10002, ''Application'',
                                10003, ''Responsibility'',
                                10004, ''User'') "Level",
             DECODE(a.level_id, 10001, ''Site'', 10002, b.application_short_name, 10003, c.responsibility_name, 10004, d.user_name) "Level Value",
             c.responsibility_id
      FROM fnd_profile_option_values a,
           fnd_application b,
           fnd_responsibility_tl c,
           fnd_user d,
           fnd_profile_options e,
           fnd_profile_options_tl t
      WHERE e.application_id like ##$$FK1$$## 
        AND a.profile_option_id  = e.profile_option_id
        AND a.level_value          = b.application_id(+)
        AND a.level_value          = c.responsibility_id(+)
        AND a.level_value          = d.user_id(+)
        AND t.profile_option_name  = e.profile_option_name
        AND t.LANGUAGE             = ''US''
        AND nvl(c.LANGUAGE,''US'') = ''US''      
     ORDER BY e.profile_option_name,
              a.level_id DESC',
      'Profile Values',
      'NRS',
      'Profile Values',
      null,
      null,
      'ALWAYS',
      'I',
      'RS',
      'N');        
     
     
  
      
  -------------------------------------------         
  --  Application Installation Details
  -------------------------------------------         
   
  l_info.delete;
  add_signature(
   'APPLICATION_INSTALL_DETAILS',
   'SELECT fav.application_name app_name, 
           fav.application_short_name app_s_name, 
           decode(fpi.status, ''I'', ''Yes'', 
                     ''S'', ''Shared'', 
                     ''N'', ''No'', fpi.status) inst_status, 
           fpi.product_version, 
           nvl(fpi.patch_level, ''Not Available'') patchset, 
           fav.application_id app_id
    FROM fnd_application_vl fav, fnd_product_installations fpi
    WHERE fav.application_id = fpi.application_id
    order by 3',
    'Application Installation Details',
    'NRS',
    'No products installed',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');  
      
      

  -------------------------------------------         
  --  Database Triggers
  -------------------------------------------         
   
  l_info.delete;
  add_signature(
   'DATABASE_TRIGGERS',
   'SELECT  atrg.table_owner, 
            atrg.table_name, 
            atrg.trigger_name, 
            atrg.trigger_type, 
            atrg.triggering_event, 
            atrg.status
    FROM  all_triggers atrg, fnd_application fa
    WHERE fa.application_id in (401, 201, 178, 673, 203, 200)
    AND   atrg.table_owner  = fa.application_short_name
    ORDER BY atrg.table_owner, atrg.table_name, atrg.trigger_type',
    'Database Triggers',
    'NRS',
    'No Database Triggers',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');  



  -------------------------------------------         
  --  Table Indexes
  -------------------------------------------         
   
  l_info.delete;
  add_signature(
   'TABLE_INDEXES',
   'SELECT iu.name table_owner,
           io.name table_name,
           o.name index_name,
           decode(bitand(i.property, 16), 0, '''', ''FUNCTION-BASED '') ||
           decode(i.type#, 1, ''NORMAL''||
           decode(bitand(i.property, 4), 0, '''', 4, ''/REV''),
                      2, ''BITMAP'', 3, ''CLUSTER'', 4, ''IOT - TOP'',
                      5, ''IOT - NESTED'', 6, ''SECONDARY'', 7, ''ANSI'', 8, ''LOB'',
                      9, ''DOMAIN'') index_type,
           to_char(i.analyzetime, ''DD-MON-RR HH:MI:SS'') last_analyzed,
           decode(bitand(i.property, 2), 2, ''N/A'',
           decode(bitand(i.flags, 1), 1, ''UNUSABLE'',
           decode(bitand(i.flags, 8), 8, ''INRPOGRS'', ''VALID''))) status
    FROM sys.user$ iu, 
         sys.obj$ io, 
         sys.user$ u, 
         sys.ind$ i, 
         sys.obj$ o, 
         fnd_application fa
    WHERE u.user# = o.owner#
    AND o.obj# = i.obj#
    AND i.bo# = io.obj#
    AND io.owner# = iu.user#
    AND io.type# = 2 -- tables
    AND i.type# in (1, 2, 3, 4, 6, 7, 9)
    AND fa.application_id in (401, 201, 178, 673, 203, 200)
    AND iu.name = fa.application_short_name 
    ORDER BY iu.name, io.name, o.name',
    'Table Indexes',
    'NRS',
    'No Table Indexes',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');  
     
   
   
/*#################################################
  #   D A T A  C O R U P T I O N                  #
  #################################################*/
  
  
  IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.0') OR (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN
  
  
  
  ---------------------------------------------
  -- All Trailing spaces
  ---------------------------------------------
  l_info.delete;  
  add_signature(
   'ALL_TRAILING_SPACES',
   'SELECT ''Expand subsections below to see the trailing space data corruption'' "Trailing Space Data Corruption"
    FROM dual',
	'Trailing Space Data Corruption',
	'[count]<[0]',
	'Review data for details related to the Procure to Pay Flow',
	'<ul>
		<li>Review - Note [1203796.1] - How To Troubleshoot FRM-40654 Errors On Purchasing Documents? .</li>
	</ul>',
       '<ul>
          <li>Review data for details related to the Procure to Pay Flow</li>
        </ul>',
	'ALWAYS',
	'I',
        'RS',
        'Y',
        l_info,
        VARCHAR_TBL('PO_HEADERS_TRAILING_SPACES','PO_LINES_TRAILING_SPACES','PO_LINE_LOCATIONS_TRAILING_SPACES','PO_DISTRIBUTIONS_TRAILING_SPACES',
        'PO_REQUISITION_HEADERS_TRAILING_SPACES','PO_REQUISITION_LINES_TRAILING_SPACES','PO_REQ_DISTRIBUTIONS_TRAILING_SPACES'),   
        p_include_in_dx_summary => 'Y'); 
   
  -------------------------------------------
  -- Trailing Spaces in table PO_HEADERS_ALL
  -------------------------------------------  

   add_signature(
     'PO_HEADERS_TRAILING_SPACES',
     g_spaces_table('PO_HEADERS_ALL'),
     'Trailing Spaces in Table PO_HEADERS_ALL',
     'RS',
     'Some columns in table PO_HEADERS_ALL have trailing spaces',
      '<ul>
          <li>Review - Note [1203796.1] - How To Troubleshoot FRM-40654 Errors On Purchasing Documents? .</li>
      </ul>',
     NULL,
     'FAILURE',
     'E',
     'RS',
     'N');


  ----------------------------------------
  -- Trailing Spaces in table PO_LINES_ALL
  ----------------------------------------   
  
   add_signature(
     'PO_LINES_TRAILING_SPACES',
     g_spaces_table('PO_LINES_ALL'),
     'Trailing Spaces in Table PO_LINES_ALL',
     'RS',
     'Some columns in table PO_LINES_ALL have trailing spaces',
      '<ul>
          <li>Review - Note [1203796.1] - How To Troubleshoot FRM-40654 Errors On Purchasing Documents? .</li>
      </ul>',
     NULL,
     'FAILURE',
     'E',
     'RS',
     'N');
   
  -------------------------------------------------
  -- Trailing Spaces in table PO_LINE_LOCATIONS_ALL
  -------------------------------------------------     
   add_signature(
     'PO_LINE_LOCATIONS_TRAILING_SPACES',
     g_spaces_table('PO_LINE_LOCATIONS_ALL'),
     'Trailing Spaces in Table PO_LINE_LOCATIONS_ALL',
     'RS',
     'Some columns in table PO_LINE_LOCATIONS_ALL have trailing spaces',
      '<ul>
          <li>Review - Note [1203796.1] - How To Troubleshoot FRM-40654 Errors On Purchasing Documents? .</li>
      </ul>',
     NULL,
     'FAILURE',
     'E',
     'RS',
     'N');

  -------------------------------------------------
  -- Trailing Spaces in table PO_DISTRIBUTIONS_ALL
  -------------------------------------------------    

   add_signature(
     'PO_DISTRIBUTIONS_TRAILING_SPACES',
     g_spaces_table('PO_DISTRIBUTIONS_ALL'),
     'Trailing Spaces in Table PO_DISTRIBUTIONS_ALL',
     'RS',
     'Some columns in table PO_DISTRIBUTIONS_ALL have trailing spaces',
      '<ul>
          <li>Review - Note [1203796.1] - How To Troubleshoot FRM-40654 Errors On Purchasing Documents? .</li>
      </ul>',
     NULL,
     'FAILURE',
     'E',
     'RS',
     'N');
   
  -------------------------------------------------------
  -- Trailing Spaces in table PO_REQUISITION_HEADERS_ALL
  -------------------------------------------------------   
  
   add_signature(
     'PO_REQUISITION_HEADERS_TRAILING_SPACES',
     g_spaces_table('PO_REQUISITION_HEADERS_ALL'),
     'Trailing Spaces in Table PO_REQUISITION_HEADERS_ALL',
     'RS',
     'Some columns in table PO_REQUISITION_HEADERS_ALL have trailing spaces',
      '<ul>
          <li>Review - Note [1203796.1] - How To Troubleshoot FRM-40654 Errors On Purchasing Documents? .</li>
      </ul>',
     NULL,
     'FAILURE',
     'E',
     'RS',
     'N');
   
  -------------------------------------------------------
  -- Trailing Spaces in table PO_REQUISITION_LINES_ALL
  -------------------------------------------------------   
   add_signature(
     'PO_REQUISITION_LINES_TRAILING_SPACES',
     g_spaces_table('PO_REQUISITION_LINES_ALL'),
     'Trailing Spaces in Table PO_REQUISITION_LINES_TRAILING_SPACES',
     'RS',
     'Some columns in table PO_REQUISITION_LINES_ALL have trailing spaces',
      '<ul>
          <li>Review - Note [1203796.1] - How To Troubleshoot FRM-40654 Errors On Purchasing Documents? .</li>
      </ul>',
     NULL,
     'FAILURE',
     'E',
     'RS',
     'N');
     
  -------------------------------------------------------
  -- Trailing Spaces in table PO_REQ_DISTRIBUTIONS_ALL
  -------------------------------------------------------      
   
   add_signature(
     'PO_REQ_DISTRIBUTIONS_TRAILING_SPACES',
     g_spaces_table('PO_REQ_DISTRIBUTIONS_ALL'),
     'Trailing Spaces in Table PO_REQ_DISTRIBUTIONS_TRAILING_SPACES',
     'RS',
     'Some columns in table PO_REQ_DISTRIBUTIONS_ALL have trailing spaces',
      '<ul>
          <li>Review - Note [1203796.1] - How To Troubleshoot FRM-40654 Errors On Purchasing Documents? .</li>
      </ul>',
     NULL,
     'FAILURE',
     'E',
     'RS',
     'N');

    END IF;






   



   
   
  -----------------------------------------
  -- Loop thru all Purchase Orders - BEGIN
  -----------------------------------------   
 IF  g_sql_tokens('##$$REQNUM$$##') IS NOT NULL THEN 

FOR i IN g_purchase_orders.FIRST .. g_purchase_orders.LAST
           LOOP


/* Testing */
  ---------------------------------------------
  -- All Data - STD PO
  ---------------------------------------------
  l_info.delete;  
  add_signature(
   'ALL_DATA_STD_'||i,
   'SELECT ''Expand subsections below to see the Procure to Pay Data'' "Procure to Pay Data"
    FROM dual',
	'Procure to Pay Related data for Purchase Order '|| g_purchase_orders2(i),
	'[count]<[0]',
	'Review data for details related to the Procure to Pay Flow',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
       '<ul>
          <li>Review data for details related to the Procure to Pay Flow</li>
        </ul>',
	'ALWAYS',
	'I',
        'RS',
        'Y',
        l_info,
        VARCHAR_TBL('ALL_PO_HEADER_DETAILS_'||i,'ALL_RECEIPT_DETAILS_STD_12_1'||i,'ALL_INVOICE'||i,'ALL_PAYMENT_DETAILS_STD'||i),   
        p_include_in_dx_summary => 'Y'); 


  ---------------------------------------------
  -- All Data - REL PO
  ---------------------------------------------
  l_info.delete;  
  add_signature(
   'ALL_DATA_REL_'||i,
   'SELECT ''Expand subsections below to see the Procure to Pay Data'' "Procure to Pay Data"
    FROM dual',
	'Procure to Pay Related data for Purchase Order '|| g_purchase_orders2(i),
	'[count]<[0]',
	'Review data for details related to the Procure to Pay Flow',
	'<ul>
		<li>Review - Impact of R12 Design in Procure To Pay Accounting Flow [429105.1] for additional information.</li>
	</ul>',
       '<ul>
          <li>Review data for details related to the Procure to Pay Flow</li>
        </ul>',
	'ALWAYS',
	'I',
        'RS',
        'Y',
        l_info,
        VARCHAR_TBL('ALL_PO_HEADER_DETAILS_'||i,'ALL_RECEIPT_DETAILS_REL_12_1'||i,'ALL_INVOICE'||i,'ALL_PAYMENT_DETAILS_REL'||i),   
        p_include_in_dx_summary => 'Y'); 





   
  ------------------------------------
  -- All PO Header Details Test
  ------------------------------------
  l_info.delete;
  add_signature(
   'ALL_PO_HEADER_DETAILS_'||i,
   'SELECT po_header_id header_id,
           po_header_id "##$$FK1$$##",
           segment1 po_number,
           approved_flag,
           approved_date,
           approval_required_flag,
           authorization_status,
           cancel_flag,
           org_id,
           submit_date,
           p2p_analyzer_pkg.get_doc_amts(''NET_TOTAL'',''P'')
             document_net,
           p2p_analyzer_pkg.get_doc_amts(''TAX'',''P'')
             document_tax,
           p2p_analyzer_pkg.get_doc_amts(''TOTAL'',''P'')
             document_total,
           p2p_analyzer_pkg.get_doc_amts(''PRECISION'',''P'')
             currency_precision,
           p2p_analyzer_pkg.get_doc_amts(''EXT_PRECISION'',''P'')
             extended_precision,
           p2p_analyzer_pkg.get_doc_amts(''MIN_ACCT_UNIT'',''P'')
             min_accountable_unit,
           summary_flag,
           enabled_flag,
           vendor_id,
           currency_code,
           rate_type,
           rate_date,
           rate,
           blanket_total_amount,
           authorization_status,
           revision_num,
           revised_date,
           amount_limit,
           min_release_amount,
           closed_date,
           approval_required_flag,
           interface_source_code,
           wf_item_type,
           wf_item_key,
           global_agreement_flag,
           encumbrance_required_flag,
           document_creation_method,
           style_id,
           creation_date,
           last_update_date,
           last_updated_by
    FROM po_headers_all
    WHERE po_header_id in ##$$POID$$##
    AND   org_id = ##$$ORGID$$##
    AND   authorization_status = ''APPROVED''',
   'Purchase Order Details for '|| g_purchase_orders2(i),
   'NRS',
   'Purchase Order is not Approved',
   '<ul><li>Approve Purchase Order.</li></ul>',
   '<ul><li>Purchase Order is Approved.</li></ul>',
   'ALWAYS',
   'E',
   'RS',
   'N',
   l_info,
   VARCHAR_TBL('ALL_PO_LINE_DETAILS'),
     p_include_in_dx_summary => 'Y');   

  ---------------------------------------
  -- Loop thru all Purchase Orders - END
  ---------------------------------------  
  
   

  ------------------------------------
  -- ALL Display Receipt Details - STD PO 12.1
  ------------------------------------
  
  
  
  add_signature(
   'ALL_RECEIPT_DETAILS_STD_12_1'||i,   
   'SELECT *
    FROM   (SELECT  rsh.receipt_num,
                    rsl.shipment_header_id,
                    rsl.shipment_line_id,
                    rsl.po_header_id,
                    rsl.po_release_id,
                    rsl.po_line_id,
                    rsl.po_line_location_id,
                    rsl.item_id,
                    pla.line_num,
                    plla.shipment_num,
                    DECODE(rsl.PO_release_id,
                    null,
                    pha.segment1,
                    pha.segment1 || ''-'' || pra.release_num) po_number,
                    pha.vendor_id,
                    pha.vendor_site_id,
                    pha.vendor_contact_id,
                    CASE pla.order_type_lookup_code 
                       WHEN ''RATE'' THEN pj.name 
                       WHEN ''FIXED PRICE'' THEN pj.name 
                       ELSE (SELECT
                          msi.concatenated_segments 
                       FROM
                          mtl_system_items_kfv msi 
                       WHERE
                          msi.inventory_item_id = rsl.item_id 
                          AND msi.organization_id = plla.ship_to_organization_id ) 
                    END AS item,
                    rsl.item_description ,
                    rsl.vendor_item_num,
                    decode(nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    pha.currency_code,
                    rsl.unit_of_measure) unit_of_measure,
                    Decode(Nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    (SELECT
                       amount 
                    FROM
                       po_line_locations_all 
                    WHERE
                       line_location_id = rt.po_line_location_id),
                    ''QUANTITY'',
                    (SELECT
                       quantity 
                    FROM
                       po_line_locations_all 
                    WHERE
                       line_location_id = rt.po_line_location_id)) quantity_ordered,
                    Decode(Nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    (POS_PO_RCV_QTY.get_net_rcv_amt(rt.shipment_line_id,
                    rt.amount,
                    rt.transaction_id)),
                    POS_PO_RCV_QTY.get_net_qty_rcv(rt.shipment_line_id,
                    rt.quantity,
                    rt.transaction_id)) quantity_received,
                    nvl(plla.promised_date,
                    plla.need_by_date) due_date,
                    plla.days_early_receipt_allowed,
                    plla.days_late_receipt_allowed,
                    rt.Transaction_date receipt_date,
                    hrl1.location_code receipt_location,
                    rsl.po_distribution_id,
                    '''' as RcptDtlsRetndSw,
                    '''' as ReturnCode,
                    '''' as RcptDtlsDfctSw,
                    '''' as DefectCode,
                    '''' as RcptDtlsLLSsw,
                    '''' as LLSCode,
                    '''' Invoice_num,
                    '''' as Acceptedcode,
                    decode(sign(nvl(Trunc(plla.promised_date),
                    Trunc(plla.need_by_date))+plla.days_late_receipt_allowed - Trunc(rt.transaction_date)),
                    -1,
                    fnd_message.get_string(''PO'',
                    ''PO_AC_LATE''),
                    decode (sign((nvl(Trunc(plla.promised_date),
                    Trunc(plla.need_by_date)) - plla.days_early_receipt_allowed) - Trunc(rt.transaction_date)),
                    1,
                    fnd_message.get_string(''POS'',
                    ''POS_EARLY''),
                    fnd_message.get_string(''POS'',
                    ''POS_ONTIME''))) PerformanceCode,
                    rsl.requisition_line_id,
                    rsl.category_id,
                    mcv.concatenated_segments category,
                    rsl.destination_type_code,
                    rsl.to_subinventory subinventory,
                    rsl.comments shipment_receiver_notes,
                    rsl.quantity_shipped,
                    rsl.item_revision,
                    rsl.vendor_lot_num,
                    rsl.packing_slip,
                    rsl.bar_code_label,
                    '''' Invoice_Id,
                    '''' Invoice_Switch,
                    plla.ship_to_location_id,
                    plla.promised_date,
                    plla.need_by_date,
                    rt.transaction_id,
                    rt.interface_transaction_id,
                    pla.supplier_ref_number 
                 FROM
                    rcv_shipment_lines rsl,
                    po_headers_all pha,
                    rcv_shipment_headers rsh,
                    po_releases_all pra,
                    po_lines_all pla,
                    po_line_locations_all plla,
                    mtl_categories_b_kfv mcv,
                    hr_locations_all_tl hrl1,
                    rcv_transactions rt,
                    per_jobs pj 
                 WHERE
                    rt.shipment_line_id = rsl.shipment_line_id 
                    AND rsl.shipment_header_id = rsh.shipment_header_id 
                    AND rt.transaction_type in (
                       ''RECEIVE'',''MATCH''
                    ) 
                    AND rsl.po_header_id = pha.po_header_id 
                    AND pra.po_release_id(+) = rt.po_release_id 
                    AND pla.po_line_id = rsl.po_line_id 
                    AND plla.line_location_id = rsl.po_line_location_id 
                    AND rsl.category_id = mcv.category_id 
                    AND hrl1.location_id (+) = rt.location_id 
                    AND hrl1.language (+) = USERENV(''LANG'') 
                    AND pj.job_id(+) = pla.job_id
                 ) QRSLT 
              WHERE
                 (
                    PO_HEADER_ID = ##$$POID$$##)
                    ORDER BY LINE_NUM ASC',
   'Receipt Details for Purchase Order '|| g_purchase_orders2(i),
   'NRS',
   'No receipt details found',
   NULL,
   'Receipt details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');    
  
  
  

  ------------------------------------
  -- ALL Display Receipt Details - Blanket PO 12.1
  ------------------------------------
  
  
  
  add_signature(
   'ALL_RECEIPT_DETAILS_REL_12_1'||i, 
   'SELECT *
    FROM   (SELECT  rsh.receipt_num,
                    rsl.shipment_header_id,
                    rsl.shipment_line_id,
                    rsl.po_header_id,
                    rsl.po_release_id,
                    rsl.po_line_id,
                    rsl.po_line_location_id,
                    rsl.item_id,
                    pla.line_num,
                    plla.shipment_num,
                    DECODE(rsl.PO_release_id,
                    null,
                    pha.segment1,
                    pha.segment1 || ''-'' || pra.release_num) po_number,
                    pha.vendor_id,
                    pha.vendor_site_id,
                    pha.vendor_contact_id,
                    CASE pla.order_type_lookup_code 
                       WHEN ''RATE'' THEN pj.name 
                       WHEN ''FIXED PRICE'' THEN pj.name 
                       ELSE (SELECT
                          msi.concatenated_segments 
                       FROM
                          mtl_system_items_kfv msi 
                       WHERE
                          msi.inventory_item_id = rsl.item_id 
                          AND msi.organization_id = plla.ship_to_organization_id ) 
                    END AS item,
                    rsl.item_description ,
                    rsl.vendor_item_num,
                    decode(nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    pha.currency_code,
                    rsl.unit_of_measure) unit_of_measure,
                    Decode(Nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    (SELECT
                       amount 
                    FROM
                       po_line_locations_all 
                    WHERE
                       line_location_id = rt.po_line_location_id),
                    ''QUANTITY'',
                    (SELECT
                       quantity 
                    FROM
                       po_line_locations_all 
                    WHERE
                       line_location_id = rt.po_line_location_id)) quantity_ordered,
                    Decode(Nvl(plla.matching_basis,
                    pla.matching_basis),
                    ''AMOUNT'',
                    (POS_PO_RCV_QTY.get_net_rcv_amt(rt.shipment_line_id,
                    rt.amount,
                    rt.transaction_id)),
                    POS_PO_RCV_QTY.get_net_qty_rcv(rt.shipment_line_id,
                    rt.quantity,
                    rt.transaction_id)) quantity_received,
                    nvl(plla.promised_date,
                    plla.need_by_date) due_date,
                    plla.days_early_receipt_allowed,
                    plla.days_late_receipt_allowed,
                    rt.Transaction_date receipt_date,
                    hrl1.location_code receipt_location,
                    rsl.po_distribution_id,
                    '''' as RcptDtlsRetndSw,
                    '''' as ReturnCode,
                    '''' as RcptDtlsDfctSw,
                    '''' as DefectCode,
                    '''' as RcptDtlsLLSsw,
                    '''' as LLSCode,
                    '''' Invoice_num,
                    '''' as Acceptedcode,
                    decode(sign(nvl(Trunc(plla.promised_date),
                    Trunc(plla.need_by_date))+plla.days_late_receipt_allowed - Trunc(rt.transaction_date)),
                    -1,
                    fnd_message.get_string(''PO'',
                    ''PO_AC_LATE''),
                    decode (sign((nvl(Trunc(plla.promised_date),
                    Trunc(plla.need_by_date)) - plla.days_early_receipt_allowed) - Trunc(rt.transaction_date)),
                    1,
                    fnd_message.get_string(''POS'',
                    ''POS_EARLY''),
                    fnd_message.get_string(''POS'',
                    ''POS_ONTIME''))) PerformanceCode,
                    rsl.requisition_line_id,
                    rsl.category_id,
                    mcv.concatenated_segments category,
                    rsl.destination_type_code,
                    rsl.to_subinventory subinventory,
                    rsl.comments shipment_receiver_notes,
                    rsl.quantity_shipped,
                    rsl.item_revision,
                    rsl.vendor_lot_num,
                    rsl.packing_slip,
                    rsl.bar_code_label,
                    '''' Invoice_Id,
                    '''' Invoice_Switch,
                    plla.ship_to_location_id,
                    plla.promised_date,
                    plla.need_by_date,
                    rt.transaction_id,
                    rt.interface_transaction_id,
                    pla.supplier_ref_number 
                 FROM
                    rcv_shipment_lines rsl,
                    po_headers_all pha,
                    rcv_shipment_headers rsh,
                    po_releases_all pra,
                    po_lines_all pla,
                    po_line_locations_all plla,
                    mtl_categories_b_kfv mcv,
                    hr_locations_all_tl hrl1,
                    rcv_transactions rt,
                    per_jobs pj 
                 WHERE
                    rt.shipment_line_id = rsl.shipment_line_id 
                    AND rsl.shipment_header_id = rsh.shipment_header_id 
                    AND rt.transaction_type in (
                       ''RECEIVE'',''MATCH''
                    ) 
                    AND rsl.po_header_id = pha.po_header_id 
                    AND pra.po_release_id(+) = rt.po_release_id 
                    AND pla.po_line_id = rsl.po_line_id 
                    AND plla.line_location_id = rsl.po_line_location_id 
                    AND rsl.category_id = mcv.category_id 
                    AND hrl1.location_id (+) = rt.location_id 
                    AND hrl1.language (+) = USERENV(''LANG'') 
                    AND pj.job_id(+) = pla.job_id
                 ) QRSLT 
              WHERE
                 (
                    PO_HEADER_ID = ##$$POID$$##
                    AND PO_RELEASE_ID = ##$$PORELID$$## 
                    )
              ORDER BY LINE_NUM ASC',
   'Receipt Details for Purchase Order '|| g_purchase_orders2(i),
   'NRS',
   'No receipt details found',
   NULL,
   'Receipt details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');    
  
  ---------------------------------------
  -- Loop thru all Receipts - END
  ---------------------------------------  
  
  
  

  -------------------------------------------
  -- All Invoice Test
  -------------------------------------------   
   l_info.delete;
  add_signature(
   'ALL_INVOICE'||i,  
   'SELECT *  
    FROM   (select
        DISTINCT AI.INVOICE_ID,
        AI.INVOICE_NUM,
        /*As part of bug 8515470 added with holding tax at three places invoice_amount ,
        invoice_amount_number ,
        due_amount_number*/ TO_CHAR(AI.INVOICE_AMOUNT + (select
            nvl(sum(amount),
            0) 
        from
            ap_invoice_lines_All 
        where
            invoice_id = AI.INVOICE_ID 
            and LINE_TYPE_LOOKUP_CODE = ''AWT'') ,
        FND_CURRENCY_CACHE.GET_FORMAT_MASK( AI.INVOICE_CURRENCY_CODE,
        30)) invoice_amount,
        AI.INVOICE_DATE,
        TO_CHAR(nvl(AI.TAX_AMOUNT,
        0),
        FND_CURRENCY_CACHE.GET_FORMAT_MASK( AI.INVOICE_CURRENCY_CODE,
        30)) TAX_AMOUNT,
        AI.VENDOR_ID,
        AI.INVOICE_CURRENCY_CODE,
        AI.VENDOR_SITE_ID,
        TO_CHAR(nvl(AI.AMOUNT_PAID,
        0),
        FND_CURRENCY_CACHE.GET_FORMAT_MASK( AI.INVOICE_CURRENCY_CODE,
        30)) AMOUNT_paid,
        TO_CHAR(nvl(AI.DISCOUNT_AMOUNT_TAKEN,
        0),
        FND_CURRENCY_CACHE.GET_FORMAT_MASK( AI.INVOICE_CURRENCY_CODE,
        30)) DISCOUNT_AMOUNT_TAKEN,
        AI.DESCRIPTION,
        AI.CREATION_DATE,
        '''' as PO_HEADER_ID,
        AI.APPROVAL_STATUS,
        AI.ORG_ID,
        AI.WFAPPROVAL_STATUS,
        PVS.VENDOR_SITE_CODE VENDOR_SITE_CODE,
        PV.EMPLOYEE_ID,
        PV.VENDOR_NAME,
        PV.SEGMENT1 VENDOR_NUMBER,
        AI.INVOICE_TYPE_LOOKUP_CODE,
        AL.DISPLAYED_FIELD as invoice_type_display,
        AI.PAYMENT_STATUS_FLAG PAYMENT_STATUS,
        '''' PO_NUMBER ,
        '''' REL_NUMBER ,
        '''' PAYMENT_NUMBER,
        '''' receipt_number,
        HOU.NAME as ORG_NAME,
        '''' PACKING_SLIP,
        '''' as hold_status,
        '''' as receipt_id,
        '''' as po_release_id,
        '''' as check_id,
        CANCELLED_DATE,
        '''' as invoice_Status,
        '''' due_Date,
        decode(AI.PAYMENT_STATUS_FLAG,
        ''Y'',
        FND_MESSAGE_CACHE.GET_STRING(''POS'',
        ''POS_PAID''),
        ''N'',
        FND_MESSAGE_CACHE.GET_STRING(''POS'',
        ''POS_NOT_PAID''),
        ''P'',
        FND_MESSAGE_CACHE.GET_STRING(''POS'',
        ''POS_PARTIALLY_PAID'')) PAYMENT_STATUS_displayed,
        '''' as payment_Date,
        ai.VOUCHER_NUM,
        ai.invoice_amount + (select
            nvl(sum(amount),
            0) 
        from
            ap_invoice_lines_All 
        where
            invoice_id = AI.INVOICE_ID 
            and LINE_TYPE_LOOKUP_CODE = ''AWT'') as invoice_Amount_number,
        AI.INVOICE_AMOUNT-nvl(AI.AMOUNT_PAID,
        0)-nvl(AI.DISCOUNT_AMOUNT_TAKEN,
        0) + (select
            nvl(sum(amount),
            0) 
        from
            ap_invoice_lines_All 
        where
            invoice_id = AI.INVOICE_ID 
            and LINE_TYPE_LOOKUP_CODE = ''AWT'') as due_Amount_number,
        '''' as bv_po_switch,
        '''' as bv_pay_switch,
        '''' as bv_receipt_switch,
        '''' as bv_pay_Date_switch,
        '''' as bv_hold_switch,
        AI.ATTRIBUTE1,
        AI.ATTRIBUTE2,
        AI.ATTRIBUTE3,
        AI.ATTRIBUTE4,
        AI.ATTRIBUTE5,
        AI.ATTRIBUTE6,
        AI.ATTRIBUTE7,
        AI.ATTRIBUTE8,
        AI.ATTRIBUTE9,
        AI.ATTRIBUTE10,
        AI.ATTRIBUTE11,
        AI.ATTRIBUTE12,
        AI.ATTRIBUTE13,
        AI.ATTRIBUTE14,
        AI.ATTRIBUTE15,
        AI.ATTRIBUTE_CATEGORY,
        ai.approval_ready_flag,
        ai.source,
        FNBA.BATCH_CURRENCY RECKONING_CURRENCY,
        FNAIA.NETTED_AMT NETTED_AMOUNT,
        decode((FUN_NET_APAR_UTILS_GRP.GET_INVOICE_NETTED_STATUS(AI.INVOICE_ID)),
        ''Y'',
        ''BVRepEnabled'',
        ''BVRepDisabled'') REPORT_SWITCHER,
        APS.DISCOUNT_DATE DISCOUNT_DATE,
        TO_CHAR(APS.DISCOUNT_AMOUNT_AVAILABLE,
        FND_CURRENCY_CACHE.GET_FORMAT_MASK(AI.INVOICE_CURRENCY_CODE,
        30)) DISCOUNT_AMOUNT_AVAILABLE,
        APS.REMIT_TO_SUPPLIER_NAME,
        APS.REMIT_TO_SUPPLIER_SITE 
    from
        AP_INVOICES AI,
        AP_PAYMENT_SCHEDULES_ALL APS,
        HR_ALL_ORGANIZATION_UNITS_TL HOU,
        PO_VENDORS PV,
        PO_VENDOR_SITES_ALL PVS,
        AP_LOOKUP_CODES AL,
        FUN_NET_BATCHES_ALL FNBA,
        FUN_NET_AP_INVS_ALL FNAIA 
    where
        AI.INVOICE_ID = APS.INVOICE_ID 
        AND AI.VENDOR_SITE_ID = PVS.VENDOR_SITE_ID 
        AND AI.VENDOR_ID = PV.VENDOR_ID 
        AND HOU.ORGANIZATION_ID (+)= AI.ORG_ID 
        AND HOU.LANGUAGE (+)= USERENV(''LANG'') 
        AND AI.INVOICE_TYPE_LOOKUP_CODE = AL.LOOKUP_CODE (+) 

        AND AL.LOOKUP_TYPE = ''INVOICE TYPE''
        AND FNAIA.INVOICE_ID (+)=AI.INVOICE_ID 
        AND FNBA.BATCH_ID (+)=FNAIA.BATCH_ID
    ) QRSLT 
WHERE
    (
        INVOICE_ID in ##$$INVOICEID2$$## 
    ) 
ORDER BY INVOICE_DATE DESC', 
  'Invoice Details for Purchase Order '|| g_purchase_orders2(i),
  'NRS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Invoice Exists',     -- Problem description
  null,     -- Problem solution
  'Invoice Details',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info);
    

  ---------------------------------------
  -- Loop thru all Invoices - END
  ---------------------------------------    



  ----------------------------------------------
  -- Display Payment Details - PO with Release
  ----------------------------------------------
  
  add_signature(
   'ALL_PAYMENT_DETAILS_REL'||i,
   'SELECT *
    FROM   (SELECT AC.check_number,  
               AC.check_date,
               AC.remit_to_supplier_name,
               AC.remit_to_supplier_site,
               ac.check_date                                AS check_date_from,
               AC.currency_code,
               To_char(AC.amount, fnd_currency.Safe_get_format_mask(
                                  AC.currency_code,
                                  30))
                                                            amount, 
               ac.bank_account_name,
               ac.payment_method                            AS payment_method_displayed,
               APLC.displayed_field                         status_displayed,
               Decode(ac.status_lookup_code, ''SPOILED'', AC.check_date,
                                             ''SET UP'', AC.check_date,
              ''UNCONFIRMED SET UP'', AC.check_date,
              ''OVERFLOW'', AC.check_date,
              ''NEGOTIABLE'', AC.check_date,
              ''ISSUED'', AC.check_date,
              ''STOP INITIATED'', AC.stopped_date,
              ''VOIDED'', AC.void_date,
              ''CLEARED'', AC.cleared_date,
              ''CLEARED BUT UNACCOUNTED'', AC.cleared_date,
              ''RECONCILED'', AC.cleared_date,
              ''RECONCILED UNACCOUNTED'', AC.cleared_date,
              To_date(NULL)) AS status_date,
              AC.city
              || '' ''
              || AC.state                                  address,
              ac.vendor_id,
              ac.vendor_site_id,
              ac.check_id,
              ac.current_vendor_site_code                  vendor_site_code,
              ac.vendor_name,
              ac.org_id,
              HOU.name                                     AS org_name,
              ac.amount                                    AS amount_number,
              ac.amount                                    AS amount_to,
              ac.check_date                                AS check_date_to,
              ac.payment_method_code                       Payment_Method_Lookup_Code,
              ac.check_voucher_num,
              AC.attribute_category,
              ac.payment_method_code
       FROM   ap_checks_v AC,
              ap_lookup_codes APLC,
              hr_all_organization_units_tl HOU,
              ap_lookup_codes APLC1
       WHERE  HOU.organization_id (+) = AC.org_id
       AND APLC.lookup_type = ''CHECK STATE''
       AND AC.status_lookup_code = APLC.lookup_code (+)
       AND HOU.LANGUAGE (+) = Userenv(''LANG'')
       AND APLC1.lookup_type(+) = ''PAYMENT METHOD''
       AND ac.payment_method_code = APLC1.lookup_code(+)) QRSLT
       WHERE  ( check_id IN (SELECT DISTINCT aip.check_id
                             FROM   ap_invoice_lines_all ail,
                                    ap_invoice_payments_all aip
                             WHERE  ail.invoice_id = aip.invoice_id
                                     AND ail.po_header_id = ##$$POID$$##
                                     AND ail.po_release_id = ##$$PORELID$$##) )
        ORDER  BY check_date DESC ',
   'Payment Details',
   'NRS',
   'No payment details found',
   NULL,
   'Payment details for Purchase Order '|| g_purchase_orders2(i),
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');   
   
  

  ----------------------------------------------
  -- Display Payment Details - STD PO
  ----------------------------------------------
  
  add_signature(
   'ALL_PAYMENT_DETAILS_STD'||i,
   'SELECT *
    FROM   (SELECT HOU.NAME as org_name,
                    AC.CHECK_NUMBER,
                    '''' as invoices,
                    AC.CHECK_DATE,
                    AC.CURRENCY_CODE,
                    ac.status_lookup_code,
                    APLC.DISPLAYED_FIELD status_displayed,
                    TO_CHAR(AC.AMOUNT,
                    FND_CURRENCY.SAFE_GET_FORMAT_MASK( AC.CURRENCY_CODE,
                    30)) amount,
                    decode(ac.status_lookup_code,
                    ''SPOILED'',
                    AC.CHECK_DATE,
                    ''SET UP'',
                    AC.CHECK_DATE,
                    ''UNCONFIRMED SET UP'',
                    AC.CHECK_DATE,
                    ''OVERFLOW'',
                    AC.CHECK_DATE,
                    ''NEGOTIABLE'',
                    AC.CHECK_DATE,
                    ''ISSUED'',
                    AC.CHECK_DATE,
                    ''STOP INITIATED'',
                    AC.STOPPED_DATE,
                    ''VOIDED'',
                    AC.VOID_DATE,
                    ''CLEARED'',
                    AC.CLEARED_DATE,
                    ''CLEARED BUT UNACCOUNTED'',
                    AC.CLEARED_DATE,
                    ''RECONCILED'',
                    AC.CLEARED_DATE,
                    ''RECONCILED UNACCOUNTED'',
                    AC.CLEARED_DATE,
                    to_date(null)) as status_date,
                    AC.CITY || '' '' || AC.STATE address,
                    ac.vendor_id,
                    ac.vendor_site_id,
                    ac.check_id,
                    ac.current_vendor_site_code vendor_site_code,
                    ac.vendor_name,
                    ac.org_id,
                    0 vendor_number,
                    ac.amount as amount_number,
                    ac.amount as amount_to,
                    ac.check_date as check_date_from,
                    ac.check_date as check_date_to,
                    ac.PAYMENT_METHOD_CODE Payment_Method_Lookup_Code,
                    ac.payment_method as payment_method_displayed,
                    0 DOC_SEQUENCE_VALUE,
                    ac.CHECK_VOUCHER_NUM,
                    ''BVPo_N'' as bv_po_switch,
                    '''' as po_number,
                    '''' as po_header_id,
                    '''' as po_release_id,
                    ''BVInv_N'' as bv_invoice_switch,
                    '''' as invoice_number,
                    '''' as invoice_id,
                    ac.bank_account_name,
                    AC.ATTRIBUTE1,
                    AC.ATTRIBUTE2,
                    AC.ATTRIBUTE3,
                    AC.ATTRIBUTE4,
                    AC.ATTRIBUTE5,
                    AC.ATTRIBUTE6,
                    AC.ATTRIBUTE7,
                    AC.ATTRIBUTE8,
                    AC.ATTRIBUTE9,
                    AC.ATTRIBUTE10,
                    AC.ATTRIBUTE11,
                    AC.ATTRIBUTE12,
                    AC.ATTRIBUTE13,
                    AC.ATTRIBUTE14,
                    AC.ATTRIBUTE15,
                    AC.ATTRIBUTE_CATEGORY,
                    ac.payment_method_code,
                    '''' rel_number,
                    AC.REMIT_TO_SUPPLIER_NAME,
                    AC.REMIT_TO_SUPPLIER_SITE 
                 FROM
                    AP_CHECKS_V AC ,
                    AP_LOOKUP_CODES APLC,
                    HR_ALL_ORGANIZATION_UNITS_TL HOU,
                    AP_LOOKUP_CODES APLC1 
                 WHERE
                    HOU.ORGANIZATION_ID (+) = AC.ORG_ID 
                    AND APLC.lookup_type = ''CHECK STATE'' 
                    AND AC.STATUS_LOOKUP_CODE = APLC.lookup_code (+) 
                    AND HOU.LANGUAGE (+)= USERENV(''LANG'') 
                    AND APLC1.lookup_type(+) = ''PAYMENT METHOD'' 
                    AND ac.payment_method_code = APLC1.lookup_code(+)) QRSLT 
              WHERE
                 (
                    CHECK_ID in (
                       SELECT
                          DISTINCT aip.check_id 
                       FROM
                          ap_invoice_lines_all ail,
                          ap_invoice_payments_all aip 
                       WHERE
                          ail.invoice_id = aip.invoice_id 
                          AND ail.po_header_id = ##$$POID$$## 
                          and ail.po_release_id is null 
                    )
                 ) 
              ORDER BY CHECK_DATE DESC',
   'Payment Details for Purchase Order '|| g_purchase_orders2(i),
   'NRS',
   'No payment details found',
   NULL,
   'Payment details',
   'ALWAYS',
   'W',
   'Y',   
   'N', 
   p_include_in_dx_summary => 'Y');   


   
          END LOOP;      
   
END IF;

  ------------------------------------
  -- Display ALL PO Line Details
  ------------------------------------
  add_signature(
   'ALL_PO_LINE_DETAILS',
   'SELECT l.line_num,
           l.line_num "##$$FK4$$##",
           l.po_line_id,
           l.po_line_id "##$$FK5$$##",
           l.item_id,
           substr(msi.segment1,1,40) item_number,
           l.item_revision,
           l.item_description,
           l.category_id,
           mca.concatenated_segments item_category,
           lt.line_type,
           lt.outside_operation_flag,
           l.list_price_per_unit,
           l.unit_price,
           l.quantity,
           l.unit_meas_lookup_code,
           l.amount,
           l.taxable_flag,
           l.tax_name,
           l.closed_code,
           l.cancel_flag,
           l.closed_flag,
           l.cancelled_by,
           l.cancel_date,
           l.closed_code,
           l.not_to_exceed_price,
           l.allow_price_override_flag,
           l.price_break_lookup_code,
           l.tax_code_id,
           l.base_uom,
           l.base_qty,
           l.last_update_date,
           l.last_updated_by
    FROM po_lines_all l,
         po_line_types lt,
         mtl_system_items msi,
         financials_system_params_all fsp,
         mtl_categories_kfv mca
    WHERE l.po_header_id =  ##$$POID$$##
    AND   fsp.org_id = l.org_id
    AND   msi.inventory_item_id (+) = l.item_id
    AND   nvl(msi.organization_id, fsp.inventory_organization_id) =
            fsp.inventory_organization_id
    AND   lt.line_type_id = l.line_type_id
    AND   mca.category_id  = l.category_id
    ORDER BY l.line_num',
   'PO Line Details',
   'NRS',
   'No document lines found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
    VARCHAR_TBL('ALL_PO_LINE_LOCATIONS'),
     p_include_in_dx_summary => 'Y');
   
   
------------------------------------
  -- Display ALL PO Line Location Details
  ------------------------------------
  add_signature(
   'ALL_PO_LINE_LOCATIONS',
   'SELECT l.line_num po_line_num,
           ll.line_location_id,
           ll.shipment_num,
           ll.shipment_type,
           ll.quantity,
           ll.unit_meas_lookup_code uom,
           ll.price_override discounted_price,
           ll.taxable_flag,
           ll.tax_name,
           ll.tax_user_override_flag,
           ll.tax_code_id,
           ll.source_shipment_id,
           ll2.shipment_num source_shipment_num,
           ll.ship_to_organization_id,
           org.organization_code ship_to_organization_code,
           ll.ship_to_location_id,
           loc.location_code ship_to_location_code,
           ll.quantity_accepted,
           ll.quantity_billed,
           ll.quantity_cancelled,
           ll.quantity_received,
           ll.quantity_rejected,
           ll.amount,
           po_headers_sv3.get_currency_code(ll.po_header_id)
             currency_code,
           ll.last_accept_date,
           ll.need_by_date,
           ll.promised_date,
           ll.firm_status_lookup_code,
           ll.price_discount,
           ll.start_date,
           ll.end_date,
           ll.lead_time,
           ll.lead_time_unit,
           ll.terms_id,
           apt.name payment_terms_name,
           ll.freight_terms_lookup_code,
           ll.fob_lookup_code,
           ll.ship_via_lookup_code,
           ll.accrue_on_receipt_flag,
           ll.from_header_id,
           ll.from_line_id,
           ll.from_line_location_id,
           ll.encumbered_flag,
           ll.encumbered_date,
           ll.approved_flag,
           ll.approved_date,
           ll.closed_code,
           ll.cancel_flag,
           ll.cancel_date,
           ll.cancel_reason,
           ll.cancelled_by,
           ll.closed_flag,
           ll.closed_by,
           ll.closed_date,
           ll.closed_reason,
           ll.ussgl_transaction_code,
           ll.government_context,
           ll.match_option,
           ll.secondary_unit_of_measure,
           ll.secondary_quantity
    FROM po_line_locations_all ll,
         po_line_locations_all ll2,
         po_lines_all l,
         ap_terms apt,
         hr_locations_all_vl loc,
         org_organization_definitions org
    WHERE ll.po_header_id = ##$$POID$$##
    AND   l.po_line_id = ll.po_line_id
    AND   l.line_num  = ##$$FK4$$##
    AND ll.line_location_id in (
                         select rl.line_location_id from po_requisition_lines_all rl 
                         where requisition_header_id in (
                                               select requisition_header_id 
                                               from po_requisition_headers_all rh
                                               where segment1 = ''##$$REQNUM$$##''))    
    AND   apt.term_id (+) = ll.terms_id
    AND   loc.location_id (+) = ll.ship_to_location_id
    AND   org.organization_id(+) = ll.ship_to_organization_id
    AND   ll2.line_location_id (+) = ll.source_shipment_id
    ORDER BY l.line_num',
   'PO Line Location Details',
   'NRS',
   'No line location records found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('ALL_PO_DIST_DETAILS'),
     p_include_in_dx_summary => 'Y');   
   
  ------------------------------------
  -- Display ALL PO Distribution Details
  ------------------------------------
  add_signature(
   'ALL_PO_DIST_DETAILS',
   'SELECT d.po_line_id,
           d.distribution_num,
           d.quantity_ordered,
           d.code_combination_id,
           substr(rtrim(g.segment1||''-''||g.segment2||''-''||
             g.segment3||''-''||g.segment4||''-''||
             g.segment5||''-''||g.segment6||''-''||
             g.segment7||''-''||g.segment8||''-''||
             g.segment9||''-''||g.segment10||''-''||
             g.segment11||''-''||g.segment12||''-''||
             g.segment13||''-''||g.segment14||''-''||
             g.segment15||''-''||g.segment16||''-''||
             g.segment17||''-''||g.segment18||''-''||
             g.segment19||''-''||g.segment20||''-''||
             g.segment21||''-''||g.segment22||''-''||
             g.segment23||''-''||g.segment24||''-''||
             g.segment25||''-''||g.segment26||''-''||
             g.segment27||''-''||g.segment28||''-''||
             g.segment29||''-''||g.segment30,''-''), 1, 100) charge_acct,
           creation_date,
           created_by,
           po_release_id,
           quantity_delivered,
           quantity_billed,
           quantity_cancelled,
           req_header_reference_num,
           req_line_reference_num,
           req_distribution_id,
           deliver_to_location_id,
           deliver_to_person_id,
           rate_date,
           rate,
           amount_billed,
           accrued_flag,
           encumbered_flag,
           encumbered_amount,
           unencumbered_quantity,
           unencumbered_amount,
           failed_funds_lookup_code,
           gl_encumbered_date,
           gl_encumbered_period_name,
           gl_cancelled_date,
           destination_type_code,
           destination_organization_id,
           destination_subinventory,
           budget_account_id,
           accrual_account_id,
           variance_account_id,
           prevent_encumbrance_flag,
           ussgl_transaction_code,
           government_context,
           destination_context,
           source_distribution_id,
           project_id,
           task_id,
           expenditure_type,
           project_accounting_context,
           expenditure_organization_id,
           gl_closed_date,
           accrue_on_receipt_flag,
           expenditure_item_date,
           mrc_rate_date,
           mrc_rate,
           mrc_encumbered_amount,
           mrc_unencumbered_amount,
           end_item_unit_number,
           tax_recovery_override_flag,
           recoverable_tax,
           nonrecoverable_tax,
           recovery_rate,
           oke_contract_line_id,
           oke_contract_deliverable_id,
           amount_ordered,
           amount_delivered,
           amount_cancelled,
           distribution_type,
           amount_to_encumber,
           invoice_adjustment_flag,
           dest_charge_account_id,
           dest_variance_account_id,
           quantity_financed,
           amount_financed,
           quantity_recouped,
           amount_recouped,
           retainage_withheld_amount,
           retainage_released_amount,
           wf_item_key,
           invoiced_val_in_ntfn,
           tax_attribute_update_code,
           interface_distribution_ref
    FROM po_distributions_all d,
         gl_code_combinations g
    WHERE d.po_header_id = ##$$POID$$##
    AND   d.po_line_id  = ##$$FK5$$##
    AND  d.line_location_id in (
                            select rl.line_location_id 
                            from po_requisition_lines_all rl 
                            where requisition_header_id in (
                                                  select requisition_header_id 
                                                  from po_requisition_headers_all rh
                                                  where segment1 = ''##$$REQNUM$$##''))    
    AND d.code_combination_id = g.code_combination_id(+)
    ORDER BY d.po_line_id, d.distribution_num',
   'PO Distribution Details',
   'NRS',
   'No distributions found for this document',
   'Verify that the document exists in this operating unit',
   null,
   'ALWAYS',
   'I',
   'RS',
    p_include_in_dx_summary => 'Y');   
   
   
   
 
   


   
  
  
   
   
-- To Be Determined if this analyzer will do approval's.

  
  
  

/*#################################################
  #   A p p r o v a l  H i e r a r c h y  S i g s #
  #################################################*/

/*
  l_info.delete;
  add_signature(
   'APP_POS_HIERARCHY_MAIN',
   'SELECT /*+ ordered use_nl(eh, p, a, pos, poss) */ /*
           p.full_name,
           eh.superior_id person_id,
           eh.superior_id "##$$FK1$$##",
           eh.superior_level,
           pos.position_id,
           pos.position_id "##$$FK2$$##",
           pos.name position_name,
           poss.name hierarchy_name,
           poss.position_structure_id hierarchy_id
    FROM --hr_employees_current_v ec,
         --po_employees_current_x ec,
         po_employee_hierarchies_all eh,
         per_all_people_f p,
         per_all_assignments_f a,
         per_all_positions pos,
         per_position_structures poss
    WHERE eh.position_structure_id = ##$$APPATH$$##
    AND   eh.employee_id = ##$$PREPID$$##
    AND   eh.business_group_id IN (
            SELECT fsp.business_group_id
            FROM financials_system_params_all fsp
            WHERE fsp.org_id = ##$$ORGID$$##)
    AND   p.person_id = eh.superior_id
    AND   (eh.superior_level > 0 OR
           eh.superior_id = eh.employee_id)
    AND   a.person_id = p.person_id
    AND   a.primary_flag = ''Y''
    AND   trunc(sysdate) BETWEEN p.effective_start_date AND
            p.effective_end_date
    AND   trunc(sysdate) BETWEEN a.effective_start_date AND
            a.effective_end_date
    AND   (nvl(p.current_employee_flag, ''N'') = ''Y'' OR
           nvl(p.current_npw_flag, ''N'') = ''Y'')
    AND   a.assignment_type in (''E'',
            decode(nvl(fnd_profile.value(''HR_TREAT_CWK_AS_EMP''), ''N''),
              ''Y'', ''C'',
              ''E''))
    AND   pos.position_id (+) = a.position_id
    AND   poss.position_structure_id (+) = eh.position_structure_id
   UNION
   SELECT /*+ ordered use_nl(poeh, cwk, a, ps, pos, poss) */ /*
          cwk.full_name,
          poeh.superior_id person_id,
          poeh.superior_id "##$$FK1$$##",
          poeh.superior_level,
          pos.position_id,
          pos.position_id "##$$FK2$$##",
          pos.name position_name,
          poss.name hierarchy_name,
          poss.position_structure_id hierarchy_id
   FROM po_employee_hierarchies_all poeh,
        per_all_people_f cwk,
        per_all_assignments_f a,
        per_periods_of_service ps,
        per_all_positions pos,
        per_position_structures poss
   WHERE poeh.position_structure_id = ##$$APPATH$$##
   AND   poeh.employee_id = ##$$PREPID$$##
   AND   poeh.business_group_id IN (
           SELECT fsp.business_group_id
           FROM financials_system_params_all fsp
           WHERE fsp.org_id = ##$$ORGID$$##)
   AND   cwk.person_id = poeh.superior_id
   AND   (poeh.superior_level > 0 OR
          poeh.superior_id = poeh.employee_id)
   AND   nvl(fnd_profile.value(''HR_TREAT_CWK_AS_EMP''),''N'') = ''Y''
   AND   a.person_id = cwk.person_id
   AND   a.person_id = ps.person_id
   AND   a.assignment_type=''E''
   AND   cwk.employee_number is not null
   AND   a.period_of_service_id = ps.period_of_service_id
   AND   a.primary_flag = ''Y''
   AND   trunc(sysdate) BETWEEN cwk.effective_start_date AND
           cwk.effective_end_date
   AND   trunc(sysdate) BETWEEN a.effective_start_date AND
           a.effective_end_date
   AND    (ps.actual_termination_date >= trunc(sysdate) OR
           ps.actual_termination_date is null)
   AND   poss.position_structure_id (+) = poeh.position_structure_id
   AND   pos.position_id (+) = a.position_id
   UNION
   SELECT /*+ ordered use_nl(poeh, cwk, a, pp, pos, poss) */ /*
          cwk.full_name,
          poeh.superior_id ,
          poeh.superior_id "##$$FK1$$##",
          poeh.superior_level,
          pos.position_id,
          pos.position_id "##$$FK2$$##",
          pos.name position_name,
          poss.name hierarchy_name,
          poss.position_structure_id hierarchy_id
   FROM per_all_people_f cwk,
        po_employee_hierarchies poeh,
        per_all_assignments_f a,
        per_periods_of_placement pp,
        per_all_positions pos,
        per_position_structures poss
   WHERE poeh.position_structure_id = ##$$APPATH$$##
   AND   poeh.employee_id = ##$$PREPID$$##
   AND   cwk.person_id = poeh.superior_id
   AND   (poeh.superior_level > 0 OR
          poeh.superior_id = poeh.employee_id)
   AND   nvl(fnd_profile.value(''HR_TREAT_CWK_AS_EMP''),''N'') = ''Y''
   AND   a.person_id = cwk.person_id
   AND   a.person_id = pp.person_id
   AND   a.assignment_type = ''C''
   AND   cwk.npw_number is not null
   AND   a.period_of_placement_date_start = pp.date_start
   AND   a.primary_flag = ''Y''
   AND   trunc(sysdate) BETWEEN cwk.effective_start_date AND
           cwk.effective_end_date
   AND   trunc(sysdate) BETWEEN a.effective_start_date AND
           a.effective_end_date
   AND   (pp.actual_termination_date >= trunc(sysdate) OR
          pp.actual_termination_date is null)
   AND   poss.position_structure_id (+) = poeh.position_structure_id
   AND   pos.position_id (+) = a.position_id
   ORDER BY 4, 1',
   'Approving Employee',
   'NRS',
   'No approvers found for approval hierarchy ID: '||
    g_sql_tokens('##$$APPATH$$##')||' or no default approval hierarchy found',
   'If the approval hierarchy ID is NULL make sure the document type has
    a default approval path:
    <ol><li>Go to the document types form. (Navigation: 
        PO Responsibility > Setup > Purchasing > Document Types)</li>
     <li>Query the specific document type i.e. Purchase Order</li>
     <li>Associate a default hierarchy.</li></ol>',
   null,
   'ALWAYS',
    'W',
    'RS',
    'Y',
    l_info,
    VARCHAR_TBL('APP_HIER_CHECK2', 'APP_HIER_CHECK3',
      'APP_HIER_CHECK4', 'APP_HIER_CHECK5', 'APP_HIER_CHECK6'
      ));

  l_info.delete;
  add_signature(
   'APP_SUP_HIERARCHY_MAIN',
   'SELECT p1.full_name employee_name,
           h.employee_id,
           h.employee_id "##$$FK1$$##",
           p2.full_name supervisor_name,
           h.supervisor_id,
           j.name job_name,
           h.job_id,
           h.job_id "##$$FK2$$##",
           h.hier_level lvl,
           h.loop
    FROM per_all_people_f p1,
         per_all_people_f p2,
         per_jobs j,
         (
           SELECT a.person_id employee_id,
                  a.assignment_id,
                  a.effective_start_date,
                  a.effective_end_date,
                  a.supervisor_id,
                  a.job_id,
                  level hier_level,
                  decode(connect_by_iscycle,
                    0, ''No'',
                    ''Yes'') loop
           FROM per_assignments_f a
           WHERE EXISTS (
                   SELECT ''1''
                   FROM per_people_f p, per_assignments_f a1
                   WHERE trunc(sysdate) BETWEEN p.effective_start_date AND
                           p.effective_end_date
                   AND   p.person_id = a.person_id
                   AND   a1.person_id = p.person_id
                   AND   trunc(sysdate) BETWEEN a1.effective_start_date AND
                           a1.effective_end_date
                   AND   a1.primary_flag = ''Y''
                   AND   a1.ASSIGNMENT_TYPE IN (''E'',''C'')
                   AND   EXISTS (
                         SELECT ''1''
                         FROM per_person_types pt,
                              per_person_type_usages_f ptu
                         WHERE ptu.person_id = p.person_id
                         AND   pt.system_person_type IN (''EMP'',''EMP_APL'',''CWK'')
                         AND   pt.person_type_id = ptu.person_type_id))
           START WITH a.person_id = ##$$PREPID$$##
                AND   trunc(sysdate) BETWEEN a.effective_start_date AND
                        a.effective_end_date
                AND   a.primary_flag = ''Y''
                AND   a.ASSIGNMENT_TYPE IN (''E'',''C'')
           CONNECT BY NOCYCLE PRIOR a.supervisor_id = a.person_id
                AND   trunc(sysdate) BETWEEN a.effective_start_date AND
                        a.effective_end_date
                AND   a.primary_flag = ''Y''
                AND   a.ASSIGNMENT_TYPE IN (''E'',''C'')
         ) h
    WHERE p1.person_id = h.employee_id
    AND   trunc(sysdate) BETWEEN p1.effective_start_date AND
                         p1.effective_end_date
    AND   p2.person_id (+) = h.supervisor_id
    AND   trunc(sysdate) BETWEEN p2.effective_start_date (+) AND
                         p2.effective_end_date (+)
    AND   j.job_id = h.job_id
    ORDER BY h.hier_level',
    'Approving Employee',
    '[LOOP]=[Yes]',
    'There is a loop in the employee/supervisor hierarchy',
    'Review the list of approvers shown above and modify the approval hierarchy so there is no loop in the employee/supervisor hierarchy.',
    NULL,
    'ALWAYS',
    'W',
    'RS',
    'Y',
    l_info,
    VARCHAR_TBL('APP_HIER_CHECK1', 'APP_HIER_CHECK3',
      'APP_HIER_CHECK4', 'APP_HIER_CHECK5', 'APP_HIER_CHECK6'
      ),
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'APP_HIER_CHECK1',
   'SELECT pc.org_id,
           cf.control_function_name,
           cg.control_group_name,
           cr.rule_type_code,
           cr.object_code ,
           to_char(cr.amount_limit) amount_limit,
           (cr.segment1_low||''.''||cr.segment2_low||''.''||
             cr.segment3_low||''.''||cr.segment4_low||''.''||
             cr.segment5_low||''.''||cr.segment6_low||''.''||
             cr.segment7_low||''.''||cr.segment8_low||''.''||
             cr.segment9_low||''.''||cr.segment10_low||''.''||
             cr.segment11_low||''.''||cr.segment12_low) Account_Range_Low,
           (cr.segment1_high||''.''||cr.segment2_high||''.''||
             cr.segment3_high||''.''||cr.segment4_high||''.''||
             cr.segment5_high||''.''||cr.segment6_high||''.''||
             cr.segment7_high||''.''||cr.segment8_high||''.''||
             cr.segment9_high||''.''||cr.segment10_high||''.''||
             cr.segment11_high||''.''||cr.segment12_high) Account_Range_High
    FROM po_position_controls_all pc,
         po_control_groups_all cg,
         po_control_functions cf,
         po_control_rules cr
    WHERE pc.control_group_id = cg.control_group_id
    AND   cr.control_group_id = pc.control_group_id
    AND   pc.control_function_id = cf.control_function_id
    AND   pc.org_id = ##$$ORGID$$##
    AND   pc.job_id = ##$$FK2$$##
    AND   cf.document_type_code = ''##$$TRXTP$$##''
    AND   cf.document_subtype = ''##$$SUBTP$$##''
    AND   trunc(sysdate) BETWEEN pc.start_date AND nvl(pc.end_date,sysdate+1)
    AND   cf.enabled_flag = ''Y''
    AND   cg.enabled_flag = ''Y''
    ORDER BY pc.control_function_id, pc.control_group_id,
             cr.object_code, cr.rule_type_code desc',
    'Job Approval Assignments',
    'NRS',
    'No approval assignments found for this document type and job.',
    'Assign an approval group to this document type and job if needed.
     (Navigation: PO Responsibility > Setup > Approvals > Approval Assignments.)',
    null,
    'ALWAYS',
    'W',
    'RS',
    p_include_in_dx_summary => 'Y');

  add_signature(
   'APP_HIER_CHECK2',
   'SELECT pc.org_id,
           cf.control_function_name,
           cg.control_group_name,
           cr.rule_type_code,
           cr.object_code,
           to_char(cr.amount_limit) amount_limit,
           (cr.segment1_low||''.''||cr.segment2_low||''.''||
            cr.segment3_low||''.''||cr.segment4_low||''.''||
            cr.segment5_low||''.''||cr.segment6_low||''.''||
            cr.segment7_low||''.''||cr.segment8_low||''.''||
            cr.segment9_low||''.''||cr.segment10_low||''.''||
            cr.segment11_low||''.''||cr.segment12_low) account_range_low,
           (cr.segment1_high||''.''||cr.segment2_high||''.''||
           cr.segment3_high||''.''||cr.segment4_high||''.''||
           cr.segment5_high||''.''||cr.segment6_high||''.''||
           cr.segment7_high||''.''||cr.segment8_high||''.''||
           cr.segment9_high||''.''||cr.segment10_high||''.''||
           cr.segment11_high||''.''||cr.segment12_high) account_range_high
    FROM po_position_controls_all pc,
         po_control_groups_all cg,
         po_control_functions cf,
         po_control_rules cr
    WHERE pc.control_group_id = cg.control_group_id
    AND   pc.control_function_id = cf.control_function_id
    AND   pc.org_id = ##$$ORGID$$##
    AND   cf.document_type_code = ''##$$TRXTP$$##''
    AND   cf.document_subtype = ''##$$SUBTP$$##''
    AND   pc.position_id = ##$$FK2$$##
    AND   trunc(sysdate) BETWEEN pc.start_date AND nvl(pc.end_date,sysdate+1)
    AND   cr.control_group_id = pc.control_group_id
    AND   cf.enabled_flag = ''Y''
    AND   cg.enabled_flag = ''Y''
    ORDER BY pc.control_function_id, pc.control_group_id,
             cr.object_code, cr.rule_type_code DESC',
    'Position Approval Assignments',
    'NRS',
    'No approval assignments found for this document type and position.',
    'Assign an approval group to this document type and position if needed.
     (Navigation: PO Responsibility > Setup > Approvals > Approval Assignments.)',
    null,
    'ALWAYS',
    'W',
    'RS',
    p_include_in_dx_summary => 'Y');

  add_signature(
   'APP_HIER_CHECK3',
   'SELECT p2p_analyzer_pkg.get_result result_code,
           p2p_analyzer_pkg.get_fail_msg failure_message,
           p2p_analyzer_pkg.get_exc_msg exception_message
    FROM dual',
    'Does Employee Have Authority to Approve',
    '[result_code]<>[S:NULL]',
    'This employee is not authorized to approve this document',
    'Review the failure and exception messages above to determine the reason',
    'This employee does have authority to approve the document',
    'ALWAYS',
    'I',
    'N');

  add_signature(
   'APP_HIER_CHECK4',
   'SELECT rownum num,
           fu.employee_id,
           fu.user_id,
           fu.user_name,
           fu.email_address,
           fu.start_date,
           fu.end_date
    FROM fnd_user fu
    WHERE employee_id = ##$$FK1$$##
    AND   trunc(sysdate) BETWEEN fu.start_date AND
            nvl(fu.end_date, sysdate+1)',
    'Application User',
    '[num]>[1]',
    'This employee is assigned to multiple applications users',
    'Please ensure the employee is associated to only one application user: 
     <ol><li>Go to the Define Users form. (Navigation:
             System Administrator Responsibility > Security > Users > Define</li>
        <li>Use the employee name to find the user records</li>
        <li>Reassign or disable the users to ensure that only one active user
            is associated to the employee</li>
        <li>Save changes</li></ol>',
    null,
    'FAILURE',
    'E',
    'RS',
    p_include_in_dx_summary => 'Y');

  add_signature(
   'APP_HIER_CHECK5',
   'SELECT rownum num,
           fu.employee_id,
           fu.user_id,
           fu.user_name,
           fu.email_address,
           fu.start_date,
           fu.end_date
    FROM fnd_user fu
    WHERE employee_id = ##$$FK1$$##
    AND   trunc(sysdate) BETWEEN fu.start_date AND
            nvl(fu.end_date, sysdate+1)',
    'Application User',
    'NRS',
    'This employee is not assigned to any active applications user.',
    'Please make sure employee is assigned to a valid applications
     user and verify the start and end dates include the current date: 
     <ol><li>Go to the Define Users form. (Navigation:
             System Administrator Responsibility > Security > Users > Define</li>
        <li>Use the employee name to find the user record</li>
        <li>If no user is found, one should be created for the employee
        <li>If a user is found, ensure that it is not end dated
           (i.e., the effective end date is null or
            later than current date). The user will be automatically
            end-dated when password expires depending on the password
            expiration settings defined in the Define Users form.</li>
        <li>Save all changes</li></ol>',
    null,
    'FAILURE',
    'E',
    'RS',
    p_include_in_dx_summary => 'Y');

  add_signature(
   'APP_HIER_CHECK6',
   'SELECT name,
           display_name,
           notification_preference,
           email_address,
           status,
           start_date,
           expiration_date
    FROM wf_users
    WHERE orig_system_id = ##$$FK1$$##
    AND orig_system = ''PER''
    AND status = ''ACTIVE''',
    'Workflow User',
    'NRS',
    'This employee does not exist in the workflow tables (WF_USERS)',
    'Follow these steps to create the user: 
        <ol>
        <li>Go to the Define Users form. (Navigation:
          System Administrator Responsibility > Security > Users > Define</li>
        <li>Query the applications user for this employee</li>
        <li>Remove values from person name and email address and save changes</li>
        <li>Re-Query the user</li>
        <li>Re-add the data in the person region and save the changes</li></ol>',
    null,
    'FAILURE',
    'E',
    'RS',
    p_include_in_dx_summary => 'Y');    

    

  /*###########################
    #  AME Setup Information  #
    ###########################*/
/*
  l_info.delete;
  add_signature(
   'AME_MANDATORY_ATTR',
  'SELECT atr.attribute_id,
          atr.name,
          atu.query_string,
          atr.description,
          atu.is_static
   FROM ame_attributes atr,
        ame_attribute_usages atu
   WHERE atr.attribute_id = atu.attribute_id
   AND   atu.application_id = ##$$AMEAPPID$$##
   AND   sysdate between atr.start_date AND
           nvl(atr.end_date - (1/86400),sysdate)
   AND   sysdate between atu.start_date AND
            nvl(atu.end_date - (1/86400),sysdate)
   AND   atr.attribute_id IN (
           SELECT attribute_id
           FROM ame_mandatory_attributes man
           WHERE man.action_type_id = -1
           AND   sysdate between man.start_date AND
                   nvl(man.end_date - (1/86400),sysdate))
   ORDER BY atr.name',
    'AME Mandatory Attributes',
    'NRS',
    'No mandatory attributes found',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'AME_ITEM_CLASSES',
  'SELECT icu.item_class_order_number "Order Number",
          ic.name,
          ic.item_class_id,
          icu.item_id_query,
          decode(icu.item_class_par_mode,
            ''S'', ''Serial'' ,
            ''P'' ,''Parallel'',
            icu.item_class_par_mode) par_mode,
          decode(icu.item_class_sublist_mode,
            ''S'',''Serial'',
            ''P'',''Parallel'',
            ''R'',''pre-approvers first, then authority and post-approvers'',
            ''A'',''pre-approvers and authority approvers first, then post-approvers'',
            icu.item_class_sublist_mode) sublist_mode
   FROM ame_item_classes ic,
        ame_item_class_usages icu
   WHERE ic.item_class_id = icu.item_class_id
   AND   icu.application_id = ##$$AMEAPPID$$##
   AND   sysdate BETWEEN ic.start_date AND nvl(ic.end_date - (1/86400),sysdate)
   AND   sysdate BETWEEN icu.start_date AND nvl(icu.end_date - (1/86400),sysdate)
   ORDER BY icu.item_class_order_number',
    'AME Item Classes',
    'NRS',
    'No item classes found for this this transaction type',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'Y',
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'AME_IC_ATTR',
  'SELECT ic.name "Item Class",
          a.attribute_id,
          a.name,
          a.attribute_type,
          au.query_string,
          a.description,
          au.is_static
   FROM ame_attributes a,
        ame_attribute_usages au,
        ame_item_classes ic
   WHERE a.attribute_id = au.attribute_id
   AND   au.application_id = ##$$AMEAPPID$$##
   AND   a.item_class_id = ic.item_class_id
   AND   sysdate BETWEEN ic.start_date AND nvl(ic.end_date - (1/86400),sysdate)
   AND   sysdate BETWEEN a.start_date AND nvl(a.end_date - (1/86400),sysdate)
   AND   sysdate BETWEEN au.start_date AND nvl(au.end_date - (1/86400),sysdate)
   AND   a.attribute_id NOT IN (
           SELECT attribute_id
           FROM ame_mandatory_attributes ma
           WHERE ma.action_type_id = -1
           AND   sysdate BETWEEN ma.start_date AND
                   nvl(ma.end_date - (1/86400),sysdate))
   ORDER BY decode(ic.name,''header'',1,''line item'',2,''distribution'',3,4),
            a.name',
    'AME Item Class Attributes',
    'NRS',
    'No attributes these item classes',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'Y',
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'AME_RULES',
   'SELECT ic.name item_class,
           ic.name "##$$FK2$$##",
           decode(r.rule_type,
             1, ''Combination'',
             2, ''List Creation'',
             3, ''List Creation Exception'',
             4, ''List Modification'',
             5, ''Substitution'',
             6, ''Pre-list'',
             7, ''Post-list'',
             8, ''Production'',
             r.rule_type) "Rule Type",
           r.rule_id, r.rule_id "##$$FK1$$##",
           r.description,
           r.rule_key,
           r.start_date,
           r.end_date,
           nvl(to_char(ru.priority),''Disabled'') "priority",
           decode(ru.approver_category,
             ''A'', ''Action'',
             ''F'', ''FYI'',
             ru.approver_category) "Approver Category"
    FROM ame_rules r,
         ame_rule_usages ru,
         (
           SELECT ic.name, ic.item_class_id,
                  icu.item_class_order_number, icu.item_class_id item_clsid
            FROM ame_item_classes ic,
                 ame_item_class_usages icu                 
            WHERE ic.item_class_id = icu.item_class_id
            AND   icu.application_id = ##$$AMEAPPID$$##
            AND   sysdate BETWEEN ic.start_date AND
                    nvl(ic.end_date - (1/86400),sysdate)
            AND   sysdate BETWEEN icu.start_date AND
                    nvl(icu.end_date - (1/86400),sysdate)
         ) ic
    WHERE r.rule_type BETWEEN 1 and 8
    AND   ic.item_class_id (+) = r.item_class_id
    AND   (r.rule_type IN (3, 4) OR
           ic.item_class_id is not null)
    AND   r.rule_id = ru.rule_id
    AND   ru.item_id = ##$$AMEAPPID$$##
    AND   (sysdate between r.start_date AND nvl(r.end_date - (1/86400),sysdate) OR
           (r.start_date > sysdate AND
             (r.end_date is null OR r.end_date > r.start_date)))
    AND   (sysdate between ru.start_date AND nvl(ru.end_date - (1/86400),sysdate) OR
           (ru.start_date > sysdate AND
             (ru.end_date is null OR ru.end_date > ru.start_date)))
    ORDER BY ic.item_class_order_number,
    item_clsid,
    r.rule_type, 
    r.rule_id',
    'AME Rules',
    'NRS',
    'No Rules found.',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    l_info,
    VARCHAR_TBL('AME_RULE_CONDITIONS','AME_RULE_ACTIONS','AME_LINE_RULE'),
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'AME_RULE_CONDITIONS',
   'SELECT c.condition_id,
           decode(c.condition_type,
             ''auth'','' '',
             ''pre'', ''Exception : '',
             ''post'', ''List-Modification : '') "Condition Type",
             ame_condition_pkg.getDescription(c.condition_id) Description
    FROM ame_condition_usages cu,
         ame_conditions c
    WHERE cu.rule_id = ##$$FK1$$##
    AND   c.condition_id = cu.condition_id
    AND   sysdate between c.start_date AND nvl(c.end_date - (1/86400),sysdate)
    AND   (sysdate between cu.start_date AND nvl(cu.end_date - (1/86400),sysdate) OR
           (cu.start_date > sysdate AND
            (cu.end_date is null OR cu.end_date > cu.start_date)))',
    'AME Rule Conditions',
    'NRS',
    'No Rules Conditions found.',
    null,
    null,
    'SUCCESS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'AME_RULE_ACTIONS',
   'SELECT a.action_id,
           ame_action_pkg.getDescription(a.action_id) "Description"
    FROM ame_action_usages au,
         ame_actions a
    WHERE au.rule_id = ##$$FK1$$##
    AND   a.action_id = au.action_id
    AND   sysdate between a.start_date AND nvl(a.end_date - (1/86400),sysdate)
    AND   (sysdate between au.start_date AND nvl(au.end_date - (1/86400),sysdate) OR
           (au.start_date > sysdate AND
            (au.end_date is null OR au.end_date > au.start_date)))',
    'AME Rule Actions',
    'NRS',
    'No Rules Actions found.',
    null,
    null,
    'SUCCESS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');

    
  l_info.delete;
  add_signature(
   'AME_LINE_RULE',
   'SELECT ''Line Item Rule detected!''
    FROM dual
    WHERE lower(''##$$FK2$$##'') = ''line item'' ',
    'AME Line Item Rule',
    'RS',
    'Line Item Rule detected!',
    'Oracle Purchasing does not support Line Item level approvals in AME. Please review the above rule and move the condition at Header level.',
    null,
    'FAILURE',
    'E',
    'N',
    'N',
    p_include_in_dx_summary => 'Y');    
    
    
-- 5 to go in here

  l_info.delete;
  add_signature(
   'AME_ACTION_TYPES',
   'SELECT atc.order_number,
           at.name,
           at.action_type_id, at.action_type_id "##$$FK1$$##",
           decode(atc.voting_regime,
             ''S'', ''Serial'',
             ''C'', ''Consensus'',
             ''F'', ''First Responder Wins'',
             atc.voting_regime) "Voting Regime",
           decode(atc.chain_ordering_mode,
             ''S'', ''Serial'',
             ''P'', ''Parallel'',
             atc.chain_ordering_mode) "Chain Order Mode",
           decode(atu.rule_type,2,1,atu.rule_type)
    FROM ame_action_type_config atc,
         ame_action_types at,
         ame_action_type_usages atu
    WHERE atc.application_id = ##$$AMEAPPID$$##
    AND   at.action_type_id = atc.action_type_id
    AND   at.action_type_id = atu.action_type_id
    AND   sysdate between at.start_date and nvl(at.end_date - (1/86400),sysdate)
    AND   sysdate between atu.start_date and nvl(atu.end_date - (1/86400),sysdate)
    AND   sysdate between atc.start_date and nvl(atc.end_date - (1/86400),sysdate)
    ORDER BY atu.rule_type,atc.order_number
    ',
    'AME Action Types',
    'NRS',
    'No Action Types found.',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'N',
    l_info,
    VARCHAR_TBL('AME_ACTION_TP_REQ_ATTR','AME_ACTION_TP_ACTIONS'),
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'AME_ACTION_TP_REQ_ATTR',
   'SELECT atr.name,
           atr.attribute_type
    FROM ame_attributes atr
    WHERE sysdate BETWEEN atr.start_date AND nvl(atr.end_date - (1/86400),sysdate)
    AND   atr.attribute_id IN (
            SELECT attribute_id FROM ame_mandatory_attributes ma
            WHERE ma.action_type_id = ##$$FK1$$##
            AND   sysdate BETWEEN ma.start_date AND
                    nvl(ma.end_date - (1/86400),sysdate))',
    'AME Action Type Required Attributes',
    'NRS',
    'No Required Attributes found.',
    null,
    null,
    'SUCCESS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
    'AME_ACTION_TP_ACTIONS',
    'SELECT act.action_id,
           act.parameter,
           act.parameter_two,
           act.description
    FROM ame_actions act
    WHERE act.action_type_id = ##$$FK1$$##
    AND   sysdate BETWEEN act.start_date AND nvl(act.end_date - (1/86400),sysdate)
    AND   act.created_by NOT IN (1,120)',
    'AME Action Type Actions',
    'NRS',
    'No Actions found.',
    null,
    null,
    'SUCCESS',
    'I',
    'RS',
    'N',
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'AME_APPR_GROUPS',
   'SELECT agf.order_number,
           agr.approval_group_id, agr.approval_group_id "##$$FK1$$##",
           agr.name,
           decode(agf.voting_regime,
             ''S'',''Serial'',
             ''C'', ''Consensus'',
             ''F'', ''First Responder Wins'',
             ''O'', ''Order Number'',
             agf.voting_regime) "Voting Regime",
           agr.description,
           agr.query_string,
           agr.is_static
    FROM ame_approval_group_config agf,
         ame_approval_groups agr
    WHERE agf.application_id = ##$$AMEAPPID$$##
    AND   agr.approval_group_id = agf.approval_group_id
    AND   sysdate BETWEEN agr.start_date AND nvl(agr.end_date - (1/86400),sysdate)
    AND   sysdate BETWEEN agf.start_date AND nvl(agf.end_date - (1/86400),sysdate)
    ORDER BY agf.order_number, agr.approval_group_id',
    'AME Approval Groups',
    'NRS',
    'No approval groups found.',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'Y',
    l_info,
    VARCHAR_TBL('AME_APPR_GROUP_ITEMS'),
    p_include_in_dx_summary => 'Y');

  l_info.delete;
  add_signature(
   'AME_APPR_GROUP_ITEMS',
   'SELECT agi.order_number,
           agi.approval_group_item_id "Item ID",
           decode(agi.parameter_name,
             ''OAM_group_id'', ''AME Group'',
             ''wf_roles_name'', ''WF Role'',
             agi.parameter_name) "Parameter Name",
           agi.parameter
    FROM ame_approval_group_items agi
    WHERE agi.approval_group_id = ##$$FK1$$##
    AND   sysdate BETWEEN agi.start_date AND nvl(agi.end_date - (1/86400),sysdate)
    ORDER BY agi.order_number',
    'Approval Group Items',
    'NRS',
    'No items found for this approval group.',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    p_include_in_dx_summary => 'Y');

   

  l_info.delete;
  add_signature(
   'AME_CONFIG_VARS',
  'SELECT cfg.variable_name,
          cfg.variable_value
   FROM ame_config_vars cfg
   WHERE cfg.application_id IN (0, ##$$AMEAPPID$$##)
   AND   sysdate BETWEEN cfg.start_date AND
           nvl(cfg.end_date - (1/86400),sysdate)
   ORDER BY cfg.variable_name',
    'AME Configuration Variables',
    'NRS',
    'No configuration variables found',
    null,
    null,
    'ALWAYS',
    'I',
    'RS',
    'Y',
    p_include_in_dx_summary => 'Y'); */
   
  -------------------------------------------
  -- Example signatures
  -- PSD #9b
  -------------------------------------------
/*
  l_info.delete;
  l_info('Doc ID') := '390023.1'; -- example using l_info
  l_info('Bug Number') := '9707155'; -- example using l_info
  add_signature(
   'Note390023.1_case_GEN4',
   'SELECT ''PO/PA'' "Doc Type",
           h.segment1 "Doc Number",
           h.po_header_id "Doc ID",
           h.org_id,
           null "Release Num",
           null "PO Release ID",
           h.type_lookup_code "Type Code",
           h.authorization_status "Athorization Status",
           nvl(h.cancel_flag,''N'') canceled,
           nvl(h.closed_code,''OPEN'') "Closed Code",
           h.change_requested_by "Change Requested By",
           h.revision_num,
           h.wf_item_type, h.wf_item_type "##$$FK1$$##",
           h.wf_item_key, h.wf_item_key "##$$FK2$$##",
           h.approved_date "Approved Date"
    FROM po_headers_all h
    WHERE to_date(''##$$FDATE$$##'') <= (
            SELECT max(ah.action_date) FROM po_action_history ah
            WHERE ah.object_id = h.po_header_id
            AND   ah.object_type_code IN (''PO'',''PA'')
            AND   ah.action_code = ''SUBMIT''
            AND   ah.object_sub_type_code = h.type_lookup_code)
    AND   h.org_id = ##$$ORGID$$##
    AND   h.authorization_status IN (''IN PROCESS'', ''PRE-APPROVED'')
    AND   nvl(h.cancel_flag,''N'') <> ''Y''
    AND   nvl(h.closed_code,''OPEN'') <> ''FINALLY CLOSED''
    AND   nvl(h.change_requested_by,''NONE'') NOT IN (''REQUESTER'',''SUPPLIER'')
    AND   (nvl(h.ENCUMBRANCE_REQUIRED_FLAG, ''N'') <> ''Y'' OR
           h.type_lookup_code <> ''BLANKET'')
    AND   NOT EXISTS (
            SELECT null
            FROM wf_item_activity_statuses ias,
                 wf_notifications n
            WHERE ias.notification_id is not null
            AND   ias.notification_id = n.group_id
            AND   n.status = ''OPEN''
            AND   ias.item_type = ''POAPPRV''
            AND   ias.item_key IN (
                    SELECT i.item_key FROM wf_items i
                    START WITH i.item_type = ''POAPPRV''
                    AND        i.item_key = h.wf_item_key
                    CONNECT BY PRIOR i.item_type = i.parent_item_type
                    AND        PRIOR i.item_key = i.parent_item_key
                    AND     nvl(i.end_date,sysdate+1) >= sysdate))
    ORDER BY 1,2',
   'Recent Documents - Candidates for Reset',
   'RS',
   'Recent documents exist which are candidates for reset.  The documents
    listed are all IN PROCESS or PRE-APPROVED approval status
    and do not have an open workflow notification.',
   '<ul><li>Review the results in the Workflow Activity section
         for the documents.</li>
      <li>If multiple documents are stuck with errors in the same
         workflow activity then try the Mass Retry in [458216.1].</li>
      <li>For all other document see [390023.1] for details on
         how to reset these documents if needed.</li>
      <li>To obtain a summary count for all such documents in your 
         system by document type, refer to [1584264.1]</li></ul>',
   null,
   'FAILURE',
   'W',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('Note390023.1_case_GEN4_CHILD1',
     'Note390023.1_case_GEN4_CHILD2')); 

	 
    l_info.delete;
    add_signature(
     'Note390023.1_case_GEN4_CHILD1',
     'SELECT DISTINCT
             ac.name Activity,
             ias.activity_result_code Result,
             ias.error_name ERROR_NAME,
             ias.error_message ERROR_MESSAGE,
             ias.error_stack ERROR_STACK
      FROM wf_item_activity_statuses ias,
           wf_process_activities pa,
           wf_activities ac,
           wf_activities ap,
           wf_items i
      WHERE ias.item_type = ''##$$FK1$$##''
      AND   ias.item_key  = ''##$$FK2$$##''
      AND   ias.activity_status     = ''ERROR''
      AND   ias.process_activity    = pa.instance_id
      AND   pa.activity_name        = ac.name
      AND   pa.activity_item_type   = ac.item_type
      AND   i.item_type             = ias.item_type
      AND   i.item_key              = ias.item_key
      AND   i.begin_date            >= ac.begin_date
      AND   i.begin_date            < nvl(ac.end_date, i.begin_date+1)
      AND   (ias.error_name is not null OR
             ias.error_message is not null OR
             ias.error_stack is not null)
      ORDER BY 1,2',
     'WF Activity Errors for This Document',
     'NRS',
     'No errored WF activities found for the document',
     null,
     null,
     'SUCCESS',
     'I',
     'RS',
	 l_info,
	 p_include_in_dx_summary => 'Y'); -- this is will add DX Summary in HTML Output as hidden
*/
    -------------------------------------------
    -- End of example signatures
    -------------------------------------------	 
    -- PSD #9b-end	 

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;


---------------------------------
-- PURCHASING SPECIFIC FUNCTIONS
---------------------------------

FUNCTION get_result RETURN VARCHAR2 IS
BEGIN
  return(g_app_results('STATUS')||':'||
    nvl(g_app_results('CODE'),'NULL'));
END get_result;

FUNCTION get_fail_msg RETURN VARCHAR2 IS
BEGIN
  return(g_app_results('FAIL_MSG'));
END get_fail_msg;

FUNCTION get_exc_msg RETURN VARCHAR2 IS
BEGIN
  return(g_app_results('EXC_MSG'));
END get_exc_msg;

FUNCTION get_doc_amts(p_amt_type IN VARCHAR2, p_trx_type IN VARCHAR2)
  RETURN NUMBER IS
  l_currency      VARCHAR2(15);
  l_precision     NUMBER(1);
  l_ext_precision NUMBER(2);
  l_min_acct_unit NUMBER;
  l_net_total     NUMBER;
  l_doc_subtype   VARCHAR2(50);
  --l_docid         NUMBER;
  l_reqid         NUMBER;
  l_poid          NUMBER;
  l_code          VARCHAR2(1);
  l_tax           NUMBER;
  l_step          VARCHAR2(5);
BEGIN
  l_step := '10';
  -- CG Changed the following lines
  --  l_doc_subtype := g_sql_tokens('##$$SUBTP$$##');
  IF ((g_sql_tokens('##$$REQID$$##') is not null) AND (g_sql_tokens('##$$REQID$$##') != 'NULL')) THEN
     l_reqid := to_number(g_sql_tokens('##$$REQID$$##'));
  END IF;
  IF ((g_sql_tokens('##$$POID$$##') is not null) AND (g_sql_tokens('##$$POID$$##') != 'NULL')) THEN
     l_poid  := to_number(g_sql_tokens('##$$POID$$##')); 
  END IF; 
  -- CG End Changes

  -- l_docid := to_number(g_sql_tokens('##$$DOCID$$##'));
 

  IF NOT g_doc_amts.exists('NET_TOTAL') THEN
    -- Get currency
    -- If transaction is a PO
    IF p_trx_type = 'P' THEN
    -- CG Added below condition
    if (g_sql_tokens.exists('##$$POSUBTP$$##')) then
        l_doc_subtype := g_sql_tokens('##$$POSUBTP$$##');
    end if;
    -- CG End changes

      l_step := '20';
      BEGIN
        SELECT currency_code INTO l_currency
        FROM po_headers_all 
        WHERE po_header_id = l_poid;
      EXCEPTION WHEN OTHERS THEN 
        l_currency := null;
      END;
    -- If transaction is a Requisition  
    ELSIF p_trx_type = 'R' THEN
    -- CG Added below condition
    if (g_sql_tokens.exists('##$$REQSUBTP$$##')) then
        l_doc_subtype := g_sql_tokens('##$$REQSUBTP$$##');
    end if;
    -- CG End changes

    l_step := '30';
      BEGIN
        SELECT max(currency_code) INTO l_currency
        FROM po_requisition_lines_all 
        WHERE requisition_header_id = l_reqid;
      EXCEPTION WHEN OTHERS THEN 
        l_currency := null;
      END;
    END IF;

    IF l_currency is null THEN
      l_currency := 'USD';
    END IF;

    l_step := '40';
    
    fnd_currency.get_info(l_currency, l_precision, l_ext_precision,
      l_min_acct_unit);

    g_doc_amts('PRECISION') := l_precision;
    g_doc_amts('EXT_PRECISION') := l_ext_precision;
    g_doc_amts('MIN_ACCT_UNIT') := l_min_acct_unit;

    -- Get net_total pull code from po_notifications_sv3.get_doc_total
    -- since that uses operating unit striped views
    l_step := '50';
    IF l_doc_subtype IN ('BLANKET', 'CONTRACT') THEN
      SELECT blanket_total_amount INTO l_net_total
      FROM po_headers_all ph
      WHERE ph.po_header_id = l_poid;
    ELSE
      IF (l_doc_subtype IN ('PLANNED', 'STANDARD')) THEN
        l_code := 'H';
      ELSIF (l_doc_subtype IN ('RELEASE', 'SCHEDULED')) THEN
        l_code := 'R';
      ELSIF (l_doc_subtype IN ('INTERNAL', 'PURCHASE')) THEN
        l_code := 'E';
      END IF;
      l_net_total := po_core_s.get_total(l_code, l_poid);
    END IF;

    g_doc_amts('NET_TOTAL') := l_net_total;

    IF p_trx_type = 'P' THEN
      l_step := '60';
      IF l_min_acct_unit > 0 THEN
        l_step := '70';
        SELECT nvl(sum(round(d.nonrecoverable_tax *
                 decode(nvl(d.quantity_ordered,0),
                   0, decode(nvl(d.amount_ordered,0),
                        0, 0,
                        (nvl(d.amount_ordered,0) - nvl(d.amount_cancelled,0)) /
                          d.amount_ordered),
                   (nvl(d.quantity_ordered,0) - nvl(d.quantity_cancelled,0)) /
                     d.quantity_ordered)
                 / l_min_acct_unit) * l_min_acct_unit), 0) tax
        INTO l_tax
        FROM po_distributions d
        WHERE po_header_id = to_number(g_sql_tokens('##$$POID$$##'));
      ELSE
        l_step := '80';
        SELECT nvl(sum(round(d.nonrecoverable_tax *
                 decode(nvl(d.quantity_ordered,0),
                   0, decode(nvl(d.amount_ordered,0),
                        0, 0,
                        (nvl(d.amount_ordered,0) - nvl(d.amount_cancelled,0)) /
                          d.amount_ordered),
                   (nvl(d.quantity_ordered,0) - nvl(d.quantity_cancelled,0)) /
                     d.quantity_ordered),
                 l_precision)), 0) tax
        INTO l_tax
        FROM po_distributions_all d      
        WHERE po_header_id = to_number(g_sql_tokens('##$$POID$$##'));
      END IF;
    ELSIF p_trx_type = 'R' THEN
      l_step := '110';
      SELECT nvl(sum(nonrecoverable_tax), 0) tax
      INTO l_tax
      FROM po_requisition_lines_all rl,
           po_req_distributions_all rd
      WHERE rl.requisition_header_id = to_number(g_sql_tokens('##$$REQID$$##'))
      AND   rd.requisition_line_id = rl.requisition_line_id
      AND   nvl(rl.cancel_flag,'N') = 'N'
      AND   nvl(rl.modified_by_agent_flag, 'N') = 'N' ;
    END IF;

    l_step := '120';
    g_doc_amts('TAX') := l_tax;
    g_doc_amts('TOTAL') := g_doc_amts('NET_TOTAL') + g_doc_amts('TAX');
  END IF;
  l_step := '130';
  RETURN(g_doc_amts(p_amt_type));

EXCEPTION WHEN OTHERS THEN
  print_log('Error in get_doc_amts:'||l_step||': '||sqlerrm);
  raise;
END get_doc_amts;


PROCEDURE chk_trail_space IS
   l_column_name           varchar2(30);
   l_column_name_c         char(30);
   l_space_count           number;
   l_ret                   number; -- temp holder for above
   l_initial_space_counter number;
   dyn_cursor              number;
   
   l_dynamic_SQL           VARCHAR2(32000);
   l_tables_tbl            varchar_tbl;
   l_table_name            VARCHAR2(255);
   l_step                  VARCHAR2(10);
  
   CURSOR COLUMN1 (p_table_name VARCHAR2) IS
    SELECT distinct(column_name)
     FROM ALL_TAB_COLUMNS
      WHERE table_name = p_table_name
        AND data_type = 'VARCHAR2';
   
BEGIN

   l_step := '10';
   l_tables_tbl := varchar_tbl('PO_HEADERS_ALL', 'PO_LINES_ALL', 'PO_LINE_LOCATIONS_ALL', 'PO_DISTRIBUTIONS_ALL', 'PO_REQUISITION_HEADERS_ALL', 'PO_REQUISITION_LINES_ALL', 'PO_REQ_DISTRIBUTIONS_ALL');
     
    
   FOR i IN l_tables_tbl.FIRST .. l_tables_tbl.LAST
   LOOP
      l_step := '20';
     
      l_dynamic_SQL := '';
      l_initial_space_counter := 0;
      
      OPEN COLUMN1 (l_tables_tbl(i));
      LOOP
         fetch COLUMN1 into l_column_name;
      
         l_step := '30';

         IF (COLUMN1%NOTFOUND) THEN
            EXIT;
         END IF;
         
         dyn_cursor := DBMS_SQL.OPEN_CURSOR;
         DBMS_SQL.PARSE
           (dyn_cursor,
               'SELECT COUNT(*) ' ||
               'FROM ' || l_tables_tbl(i) ||
               ' WHERE ' || l_column_name || ' LIKE ''% ''',
               DBMS_SQL.NATIVE);
               
         l_step := '40';
         DBMS_SQL.define_column (dyn_cursor, 1, l_space_count);
           l_ret := DBMS_SQL.EXECUTE(dyn_cursor);
           if DBMS_SQL.fetch_rows(dyn_cursor) > 0 then
             DBMS_SQL.column_value (dyn_cursor, 1, l_space_count);
           end if;
         
         l_step := '50';
         DBMS_SQL.CLOSE_CURSOR(dyn_cursor);
         
         IF (NVL(l_space_count, 0) > 0) THEN
             IF (l_initial_space_counter > 0) THEN
                 l_dynamic_SQL := l_dynamic_SQL || ' UNION ';
             END IF;     

             l_dynamic_SQL := l_dynamic_SQL || 'SELECT ''' || l_column_name || ''' "COLUMN NAME", count(*) "COUNT" FROM ' || l_tables_tbl(i) || ' WHERE ' || l_column_name || ' LIKE ''% ''';
             l_initial_space_counter := NVL(l_initial_space_counter, 0) + 1;
         END IF;

         l_step := '60';
      end loop;
      close column1;
      
      l_step := '70';

      IF (l_dynamic_SQL IS NOT NULL) THEN
         g_spaces_table(l_tables_tbl(i)) := l_dynamic_SQL;
      ELSE       
         g_spaces_table(l_tables_tbl(i)) := 'SELECT 1 FROM DUAL WHERE 1=0';
      END IF;
            
   END LOOP;
   RETURN;

   EXCEPTION WHEN OTHERS THEN
      print_log ('Exception in chk_trail_space at step ' || l_step);
      raise;
   
END chk_trail_space;


---------------------------------
-- INVOICE SPECIFIC FUNCTIONS
---------------------------------


FUNCTION uom_convert (
  p_from_unit  IN VARCHAR2,
  p_to_unit    IN VARCHAR2,
  p_item_id    IN NUMBER) RETURN NUMBER IS

  l_rate NUMBER;

BEGIN
  -- This function is added to remove dependency on AP_Acctg_Data_Fix_PKG
  l_rate := po_uom_s.po_uom_convert(p_from_unit,p_to_unit,p_item_id);
  return l_rate;
EXCEPTION WHEN OTHERS THEN
  return null;
END uom_convert;

FUNCTION net_pp_app(
  p_event_id NUMBER) RETURN NUMBER IS
  
  l_total_prepay_amt NUMBER := -99;

BEGIN
  SELECT NVL((SUM(AID.Amount)), 0)   --bug12764043, removed ABS
  INTO l_total_prepay_amt
  FROM ap_invoice_distributions_all aid
  WHERE aid.line_type_lookup_code IN ('PREPAY','REC_TAX','NONREC_TAX')
  AND aid.prepay_distribution_id  IS NOT NULL
  AND aid.accounting_event_id = P_Event_ID;

  RETURN(l_total_prepay_amt);

EXCEPTION WHEN OTHERS THEN
  RETURN -99;
END net_pp_app;

FUNCTION net_pp_acct(
    p_event_id NUMBER,
    p_ledger_id NUMBER) RETURN NUMBER IS

  l_total_prepay_acct NUMBER := -100;

BEGIN
  SELECT NVL((sum(nvl(xal.entered_dr, 0) - nvl(xal.entered_cr, 0))), 0)
  INTO l_total_prepay_acct
  FROM xla_ae_lines xal,
       xla_ae_headers xah
  WHERE xal.application_id = 200
  AND   xah.application_id = 200
  AND   xah.balance_type_code = 'A'
  AND   xah.ae_header_id = xal.ae_header_id
  AND   xal.accounting_class_code = 'PREPAID_EXPENSE'
  AND   xah.event_id = p_event_id
  AND   xah.ledger_id = p_ledger_id;

  RETURN(l_total_prepay_acct);

EXCEPTION WHEN OTHERS THEN
  RETURN(-100);
END net_pp_acct;

FUNCTION net_adj_acct(
    p_event_id NUMBER,
    p_ledger_id NUMBER) RETURN NUMBER IS

  l_total_prepay_acct NUMBER := -101;

BEGIN
  SELECT NVL((sum(nvl(xal.entered_dr, 0) - nvl(xal.entered_cr, 0))), 0)
  INTO l_total_prepay_acct
  FROM xla_ae_lines xal,
       xla_ae_headers xah
  WHERE xal.application_id = 200
  AND   xah.application_id = 200
  AND   xah.balance_type_code = 'A'
  AND   xah.ae_header_id = xal.ae_header_id
  AND   xal.accounting_class_code = 'PREPAID_EXPENSE'
  AND   xah.event_id IN (
          SELECT /*+ push_subq */
                 apph.accounting_event_id
          FROM ap_prepay_history_all apph
          WHERE apph.related_prepay_app_event_id = p_event_id
          AND   apph.transaction_type = 'PREPAYMENT APPLICATION ADJ')
  AND   xah.ledger_id = P_Ledger_ID;

  RETURN(l_total_prepay_acct);

EXCEPTION WHEN OTHERS THEN
    RETURN(-101);
END net_adj_acct;



------------------------------------------
-- OTHER P2P SPECIFIC FUNCTIONS / CURSORS
------------------------------------------


--------------------------------------------------
-- Custom function to return the file version   -- 
--------------------------------------------------

FUNCTION get_file_ver (p_fileid NUMBER) return VARCHAR2 IS

   CURSOR file_ver_c (p_file_id NUMBER) IS
         select version, to_number(version_segment1) vs1, to_number(version_segment2) vs2, to_number(version_segment3) vs3, to_number(version_segment4) vs4, 
                to_number(version_segment5) vs5, to_number(version_segment6) vs6, to_number(version_segment7) vs7, to_number(version_segment2) vs8,
                to_number(version_segment9) vs9, to_number(version_segment10) vs10
           from ad_file_versions where file_id = p_file_id
          order by vs1 desc, vs2 desc, vs3 desc, vs4 desc, vs5 desc, vs6 desc, vs7 desc, vs8 desc, vs9 desc, vs10 desc;

    l_version VARCHAR2(150);      
    l_vs1 NUMBER;
    l_vs2 NUMBER;
    l_vs3 NUMBER;
    l_vs4 NUMBER;
    l_vs5 NUMBER;
    l_vs6 NUMBER;
    l_vs7 NUMBER;
    l_vs8 NUMBER;
    l_vs9 NUMBER;
    l_vs10 NUMBER;
    
BEGIN

    OPEN file_ver_c (p_fileid);
    
    FETCH file_ver_c INTO
          l_version, l_vs1, l_vs2, l_vs3, l_vs4, l_vs5, l_vs6, l_vs7, l_vs8, l_vs9, l_vs10;

    CLOSE file_ver_c;
    RETURN l_version;
    
END get_file_ver;




---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main_single (
      p_org_id          IN NUMBER   DEFAULT null,
      p_req_num         IN VARCHAR2 DEFAULT null,
      p_trx_type        IN VARCHAR2 DEFAULT null,
      p_po_num          IN VARCHAR2 DEFAULT null,
      p_release_num     IN NUMBER   DEFAULT null,
      p_invoice_num     IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 50,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS
      
      

BEGIN


  main(
      p_mode   => 'SINGLE',
      p_org_id => p_org_id,
      p_req_num => p_req_num,
      p_trx_type => p_trx_type,
      p_po_num => p_po_num,
      p_release_num => p_release_num,
      p_invoice_num => p_invoice_num,
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode,
      p_calling_from => 'sql script');



END main_single;


PROCEDURE main_all(
      p_org_id          IN NUMBER   DEFAULT null,
      p_req_num         IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 50,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

BEGIN

  main(
      p_mode   => 'ALL',  
      p_org_id => p_org_id,
      p_req_num => p_req_num,
      p_trx_type => 'ANY',
      p_po_num => null,
      p_release_num => null,
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode,
      p_calling_from => 'sql script');

END main_all;

PROCEDURE main (
      p_mode            IN VARCHAR2 DEFAULT null,  
      p_org_id          IN NUMBER   DEFAULT null,
      p_req_num         IN VARCHAR2 DEFAULT null,
      p_trx_type        IN VARCHAR2 DEFAULT null,
      p_po_num          IN VARCHAR2 DEFAULT null,
      p_release_num     IN NUMBER   DEFAULT null,
      p_invoice_num     IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 50,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y',
      p_calling_from    IN VARCHAR2 DEFAULT null) IS

  l_sql_result  VARCHAR2(1);
  l_step        VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;
  l_key         VARCHAR2(100);  -- CG Added new var
  l_invoice_id  NUMBER;
  l_receipt_id  NUMBER;
  l_check_id  NUMBER;
  
  

-----------------------------------------------------------------------------
-- Custom cursor to return the all related Receipts for REL  -- 
-----------------------------------------------------------------------------  
CURSOR receipts_ids_rel_c IS
  SELECT transaction_id
               FROM rcv_transactions
               WHERE po_header_id = g_sql_tokens('##$$POID$$##')
               AND  po_release_id = g_sql_tokens('##$$PORELID$$##')
               AND transaction_type in ('RECEIVE','MATCH');




-------------------------------------------------------------------------
-- Custom cursor to return the all related Receipts for STD   -- 
-------------------------------------------------------------------------  
CURSOR receipts_ids_std_c IS
  SELECT transaction_id
               FROM rcv_transactions
               WHERE po_header_id = g_sql_tokens('##$$POID$$##')
               AND transaction_type in ('RECEIVE','MATCH');
                   
               
               

-----------------------------------------------------------
-- Custom cursor to return the all related invoices REL  -- 
-----------------------------------------------------------

CURSOR invoice_ids_c_rel IS
SELECT DISTINCT ail.invoice_id
FROM   ap_invoice_lines_all ail
WHERE  ail.po_header_id = g_sql_tokens('##$$POID$$##')
AND ail.po_release_id = g_sql_tokens('##$$PORELID$$##') 
AND Nvl(ail.discarded_flag, 'N') = 'N';


-----------------------------------------------------------
-- Custom cursor to return the all related invoices STD  -- 
-----------------------------------------------------------

CURSOR invoice_ids_c_std IS
SELECT DISTINCT ail.invoice_id
FROM   ap_invoice_lines_all ail
WHERE  ail.po_header_id = g_sql_tokens('##$$POID$$##')
AND Nvl(ail.discarded_flag, 'N') = 'N';


        
        
--------------------------------------------------------------
-- Custom cursor to return the all related payments  STD PO -- 
--------------------------------------------------------------        
CURSOR check_ids_c_std IS
SELECT DISTINCT aip.check_id  
FROM ap_invoice_lines_all ail, 
     ap_invoice_payments_all aip 
WHERE ail.invoice_id = aip.invoice_id 
AND ail.po_header_id = g_sql_tokens('##$$POID$$##')
AND ail.po_release_id IS NULL;  

--------------------------------------------------------------
-- Custom cursor to return the all related payments  REL PO -- 
--------------------------------------------------------------        
CURSOR check_ids_c_rel IS
SELECT DISTINCT aip.check_id  
FROM ap_invoice_lines_all ail, 
     ap_invoice_payments_all aip 
WHERE ail.invoice_id = aip.invoice_id 
AND ail.po_header_id = g_sql_tokens('##$$POID$$##')
AND ail.po_release_id = g_sql_tokens('##$$PORELID$$##');  

BEGIN


  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
  
  -- PSD #11
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Procure to Pay';

  l_step := '20';
 -- PSD #12
  validate_parameters(
      p_mode,
      p_org_id,
      p_req_num,
      p_trx_type,
      p_po_num,
      p_release_num,
      p_invoice_num,
      p_max_output_rows,
      p_debug_mode,
      p_calling_from);
      

  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '35';
  -- Call cursors to populate all derived data
 IF  g_sql_tokens('##$$REQNUM$$##') IS NOT NULL THEN   
  populate_p2p_globals;
 END IF;  
    -- Check if any of the tables has columns with trailing spaces and populate corresponding global hash (g_spaces_table)
  IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.0') OR (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN
    chk_trail_space;
  END If;
   
  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #13
  start_section('Proactive Recommendations');
     set_item_result(check_rec_patches);
     set_item_result(run_stored_sig('INVALIDS'));
     set_item_result(run_stored_sig('FND_DEVELOPER_MODE_PROFILE'));
     set_item_result(run_stored_sig('TABLESPACE_CHECK')); 
  IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.0') OR (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN   
     set_item_result(run_stored_sig('ALL_TRAILING_SPACES'));
  END IF;   
  end_section;
  /*
 -- Approval Hierarchy / AME Validations
  l_step := '65';
 -- IF p_trx_num IS NOT NULL THEN

   IF g_use_ame THEN
      start_section('AME Setup Information');
        set_item_result(get_ame_approvers);
        set_item_result(run_stored_sig('AME_RULES'));
        set_item_result(run_stored_sig('AME_APPR_GROUPS'));
        set_item_result(run_stored_sig('AME_MANDATORY_ATTR'));
        set_item_result(run_stored_sig('AME_ITEM_CLASSES'));
        set_item_result(run_stored_sig('AME_IC_ATTR'));
        set_item_result(run_stored_sig('AME_ACTION_TYPES'));
        set_item_result(run_stored_sig('AME_CONFIG_VARS'));
      end_section;
    ELSE
    start_section(initcap(g_app_method)||' Hierarchy Approver List Validation');
      IF g_app_method = 'POSITION' THEN
        set_item_result(run_stored_sig('APP_POS_HIERARCHY_MAIN'));
      ELSE
        set_item_result(run_stored_sig('APP_SUP_HIERARCHY_MAIN'));
      END IF;
      end_section;
    END IF;
 -- END IF;  
  */
  
  l_step := '70';
 IF  g_sql_tokens('##$$REQNUM$$##') IS NOT NULL THEN 
  start_section('Requisition Details');
  set_item_result(run_stored_sig('REQUISITION_HEADER_DETAILS'));
  set_item_result(run_stored_sig('REQUISITION_APPROVAL_HISTORY'));
    set_item_result(run_stored_sig('PODATACORRUPTION_05')); 
    set_item_result(run_stored_sig('PODATACORRUPTION_06')); 
    set_item_result(run_stored_sig('PODATACORRUPTION_14')); 
   -- 11.5.10 set_item_result(run_stored_sig('PODATACORRUPTION_16'));
    set_item_result(run_stored_sig('PODATACORRUPTION_18'));
  set_item_result(run_stored_sig('DFF_UNFROZEN'));
  set_item_result(run_stored_sig('CANCELLED_REQ_LINE_AUTOCREATE'));
  end_section;
 END If;  
 /*
   l_step := '75';
  start_section('RFQ Details');
  set_item_result(run_stored_sig('RFQ_HEADER_DETAILS'));
  set_item_result(run_stored_sig('RFQ_SUPPLIERS'));
  end_section;
  
  l_step := '80';
  start_section('Quote Details');
  set_item_result(run_stored_sig('QUOTE_HEADER_DETAILS'));
  end_section;
  */
  
  /*CG Reset the g_doc_amts hash table, so we can populate it with values specific to PO */
  l_key := g_doc_amts.first;
  WHILE (l_key is not null) LOOP
        g_doc_amts.delete(l_key);
        l_key := g_doc_amts.next(l_key);
  END LOOP;
  -- CG END
  
 
  l_step := '85';
  IF (g_sql_tokens('##$$PONUM$$##') IS NOT NULL) THEN 
  start_section('Purchase Order Details');
   set_item_result(run_stored_sig('PO_HEADER_DETAILS')); 
  -- This sig PO_HEADER_DETAILS2 is to gather all PO's related to req. Shipments and distributions not working correctly due to rownum not incrementing.
  -- set_item_result(run_stored_sig('PO_HEADER_DETAILS2'));
   set_item_result(run_stored_sig('PO_APPROVAL_HISTORY'));
   set_item_result(run_stored_sig('PODATACORRUPTION_01'));
   set_item_result(run_stored_sig('PODATACORRUPTION_02'));
   set_item_result(run_stored_sig('PODATACORRUPTION_03')); 
   set_item_result(run_stored_sig('PODATACORRUPTION_04'));
   set_item_result(run_stored_sig('PODATACORRUPTION_07'));
   set_item_result(run_stored_sig('PODATACORRUPTION_08'));
   set_item_result(run_stored_sig('PODATACORRUPTION_09'));
   set_item_result(run_stored_sig('PODATACORRUPTION_10'));
   set_item_result(run_stored_sig('PODATACORRUPTION_11'));
   set_item_result(run_stored_sig('PODATACORRUPTION_12'));
   set_item_result(run_stored_sig('PODATACORRUPTION_13'));
 -- 11.5.10  set_item_result(run_stored_sig('PODATACORRUPTION_15'));
 -- 11.5.10  set_item_result(run_stored_sig('PODATACORRUPTION_17'));
   set_item_result(run_stored_sig('PODATACORRUPTION_19'));
   set_item_result(run_stored_sig('PODATACORRUPTION_20'));   
   set_item_result(run_stored_sig('Doc_Standard_clauses'));
   set_item_result(run_stored_sig('Doc_NON_Standard_clauses'));
   set_item_result(run_stored_sig('2WAY_COUNT'));
   set_item_result(run_stored_sig('AUTOCREATE_NUMBERING'));
  IF (g_sql_tokens('##$$CREATEDOC$$##') = 'CREATEPO') THEN
    set_item_result(run_stored_sig('CREATEPO_ATTRIBUTES_CHECK'));
  END IF; 
  end_section;

  
    l_step := '90';
    start_section('Receipt Details');
IF g_sql_tokens('##$$PORELNUM$$##') IS NOT NULL THEN 
  IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN 
    set_item_result(run_stored_sig('RECEIPT_DETAILS_REL_12_1'));
    set_item_result(run_stored_sig('ENCUMBRANCE_AFTER_PO_APPROVAL_REL'));
    set_item_result(run_stored_sig('PO_RCV_FORM_REL')); 
  ELSIF	(substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.2') THEN
    set_item_result(run_stored_sig('RECEIPT_DETAILS_REL_12_2'));
    set_item_result(run_stored_sig('ENCUMBRANCE_AFTER_PO_APPROVAL_REL'));
    set_item_result(run_stored_sig('PO_RCV_FORM_REL'));  
  END IF; 
ELSIF g_sql_tokens('##$$PORELNUM$$##') IS NULL THEN
  IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN  	  
    set_item_result(run_stored_sig('RECEIPT_DETAILS_STD_12_1'));
    set_item_result(run_stored_sig('ENCUMBRANCE_AFTER_PO_APPROVAL_STD'));
    set_item_result(run_stored_sig('PO_RCV_FORM_STD')); 
  ELSIF	(substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.2') THEN
    set_item_result(run_stored_sig('RECEIPT_DETAILS_STD_12_2'));
    set_item_result(run_stored_sig('ENCUMBRANCE_AFTER_PO_APPROVAL_STD'));
    set_item_result(run_stored_sig('PO_RCV_FORM_STD'));  
  END IF; 
END IF;   
    set_item_result(run_stored_sig('MISMATCH_SHIPMENT_HEADER_ID'));
    set_item_result(run_stored_sig('MATCHING_BASIS_AMOUNT'));
    set_item_result(run_stored_sig('PO_DESTINATION_ORG_ID_NULL'));
    set_item_result(run_stored_sig('PO_SHIP_TO_ORGANIZATION_ID_NULL'));
    set_item_result(run_stored_sig('PO_ITEM_NO_SHIP_TO_ORGANIZATION'));
    set_item_result(run_stored_sig('RCV_TRANSACTION_MGR_PROCESSES'));
  end_section;
END If; 
   
  l_step := '95';
  IF (g_sql_tokens('##$$INVOICEUM$$##') IS NOT NULL) THEN    
    start_section('Invoice Details');
  IF g_sql_tokens('##$$PORELNUM$$##') IS NOT NULL THEN 
    set_item_result(run_stored_sig('INVOICE_DETAILS_REL'));
  ELSE
    set_item_result(run_stored_sig('INVOICE_DETAILS_STD'));
  END IF;      
    set_item_result(run_stored_sig('1_MISMATCH_AP_PO_DISTRIBUTION'));
    set_item_result(run_stored_sig('2_MISMATCH_PO_LOC_DISTRIBUTION'));
    set_item_result(run_stored_sig('3_UNMATCHED_PO_WITH_INVOICE_QTY_AMT'));
    set_item_result(run_stored_sig('3_UNMATCHED_RECEIPT_WITH_INVOICE_QTY_AMT'));
    set_item_result(run_stored_sig('4_AP_NOT_NULL_QTY_INV_SEL'));
    set_item_result(run_stored_sig('APP_PO_14144'));
    set_item_result(run_stored_sig('ap_sync_po_qty_amt_sel_RCV'));
    set_item_result(run_stored_sig('5_PO_Finally_Closed'));
    set_item_result(run_stored_sig('6_PO_Negative_Billed'));
    set_item_result(run_stored_sig('7_ENC_Unapproved_PO'));
    set_item_result(run_stored_sig('10_PO_MATCHING_REQUIRED'));
    set_item_result(run_stored_sig('ap_po_price_adj_flg_sel'));
    set_item_result(run_stored_sig('rcv_shpmt_miss_sel'));
    set_item_result(run_stored_sig('ap_null_unitprice_sel'));
    set_item_result(run_stored_sig('ap_rcpt_num_corr_inv_sel'));
    set_item_result(run_stored_sig('ap_quick_po_update_sel'));
    set_item_result(run_stored_sig('quick_match_qty_rnd_sel'));
    set_item_result(run_stored_sig('ap_sync_po_release_id_sel'));
    set_item_result(run_stored_sig('ap_one_off_scripts_sel'));
    
    end_section;   
  END IF;  
  
  l_step := '96';
  IF (g_sql_tokens('##$$INVOICEUM$$##') IS NOT NULL) THEN    
    start_section('Payment Details');
  IF g_sql_tokens('##$$PORELNUM$$##') IS NOT NULL THEN 
    set_item_result(run_stored_sig('PAYMENT_DETAILS_REL'));
  ELSE
    set_item_result(run_stored_sig('PAYMENT_DETAILS_STD'));
  END IF; 
    set_item_result(run_stored_sig('ap_payment_method_null_sel'));
    set_item_result(run_stored_sig('ap_rate_miss_sel'));
    set_item_result(run_stored_sig('ap_wrgchksts_sel'));
    set_item_result(run_stored_sig('ap_negotiable_iby_void_sel'));
    set_item_result(run_stored_sig('ap_checks_misc_sel_check_1'));
    set_item_result(run_stored_sig('ap_checks_misc_sel_check_2'));
    set_item_result(run_stored_sig('ap_checks_misc_sel_check_3'));
    set_item_result(run_stored_sig('ap_check_stat_incorrect_sel'));
    set_item_result(run_stored_sig('ap_missing_mat_event_sel'));  
    end_section;   
  END IF;    
  
  
  l_step := '100';
  start_section('Setup');
  set_item_result(run_stored_sig('ORG_DOC_TYPES'));
  set_item_result(run_stored_sig('ORG_LINE_TYPES'));
  set_item_result(run_stored_sig('FINANCIAL_OPTIONS_SETUP'));
 IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN  
  set_item_result(run_stored_sig('PURCHASING_OPTIONS_SETUP_12_1'));
 ELSIF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.2') THEN 
  set_item_result(run_stored_sig('PURCHASING_OPTIONS_SETUP_12_2'));
 END IF;  
  set_item_result(run_stored_sig('RECEIVING_OPTIONS_SETUP'));
  
  IF g_use_ame THEN
    set_item_result(run_stored_sig('DOC_PO_STYLE_HEADER'));  
  END IF;             
   end_section; 


   l_step := '132';
  
  start_section('Procurement Code Level');
    IF (g_sql_tokens('##$$REL$$##') IS NOT NULL) THEN
       IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.0') THEN
          set_item_result(run_stored_sig('PROC_CODE_LEVEL_12_0'));
       ELSIF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN
          set_item_result(run_stored_sig('PROC_CODE_LEVEL_12_1'));
       ELSE
          set_item_result(run_stored_sig('PROC_CODE_LEVEL_12_2'));    
       END IF;
    END IF;   
   end_section;  
   
   l_step := '150';
   
   start_section('Diag Apps Check');
          set_item_result(run_stored_sig('FILE_VERSIONS'));
          set_item_result(run_stored_sig('PROFILE_OPTIONS'));
          set_item_result(run_stored_sig('APPLICATION_INSTALL_DETAILS'));
          set_item_result(run_stored_sig('DATABASE_TRIGGERS'));
          set_item_result(run_stored_sig('TABLE_INDEXES'));
   end_section;  
   
   l_step := '160';

/* moved trailing spaces to proactive recommendations for now
/*  start_section('Corruption');
  IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.0') OR (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN
     set_item_result(run_stored_sig('PO_HEADERS_TRAILING_SPACES'));    
     set_item_result(run_stored_sig('PO_LINES_TRAILING_SPACES'));     
     set_item_result(run_stored_sig('PO_LINE_LOCATIONS_TRAILING_SPACES'));    
     set_item_result(run_stored_sig('PO_DISTRIBUTIONS_TRAILING_SPACES'));    
     set_item_result(run_stored_sig('PO_REQUISITION_HEADERS_TRAILING_SPACES'));    
     set_item_result(run_stored_sig('PO_REQUISITION_LINES_TRAILING_SPACES'));    
     set_item_result(run_stored_sig('PO_REQ_DISTRIBUTIONS_TRAILING_SPACES'));  
  END IF;       
  end_section; 
*/


   l_step := '170';

IF p_mode='ALL' THEN
   
   start_section('TESTING'); 
       
      IF (g_purchase_orders.COUNT > 0) THEN 
         FOR i IN g_purchase_orders.FIRST .. g_purchase_orders.LAST
           LOOP
             g_sql_tokens('##$$POID$$##') := g_purchase_orders(i);
             g_sql_tokens('##$$PONUM$$##') := g_purchase_orders2(i);
             g_sql_tokens('##$$POTYPE$$##') := g_purchase_orders3(i);             
             g_sql_tokens('##$$PORELID$$##') := g_purchase_orders4(i);
             -- Get All Purchase Orders
             set_item_result(run_stored_sig('ALL_PO_HEADER_DETAILS_'||i));              
             -- Get All Receipts & all Details. Running The STD Receipt Signature As We Want All Releases
              print_log('Receipt Cursor start');
              print_log('PO ID '||g_sql_tokens('##$$POID$$##'));
              print_log('PO Number '||g_sql_tokens('##$$PONUM$$##'));
              print_log('PO Type '||g_sql_tokens('##$$POTYPE$$##'));
              print_log('PO Release ID '||g_sql_tokens('##$$PORELID$$##'));            
            IF g_sql_tokens('##$$POTYPE$$##') IN ('BLANKET','CONTRACT') THEN 
                         -- Open Cursor to retrieve all receipt id's             
                         OPEN receipts_ids_rel_c;  
                         LOOP              
                             FETCH receipts_ids_rel_c INTO l_receipt_id; 
                             EXIT WHEN receipts_ids_rel_c%NOTFOUND;
                    --           print_log('JM receipt id: ' || to_char(l_receipt_id));
                         END LOOP;             
                         CLOSE receipts_ids_rel_c;
                         
                         set_item_result(run_stored_sig('ALL_RECEIPT_DETAILS_REL_12_1'||i));
            ELSE 
                         OPEN receipts_ids_std_c;  
                         LOOP              
                             FETCH receipts_ids_std_c INTO l_receipt_id; 
                             EXIT WHEN receipts_ids_std_c%NOTFOUND;
                      --         print_log('JM receipt id: ' || to_char(l_receipt_id));
                         END LOOP;             
                         CLOSE receipts_ids_std_c;
                         
                         set_item_result(run_stored_sig('ALL_RECEIPT_DETAILS_STD_12_1'||i));
            END IF;             
             
             -- set_item_result(run_stored_sig('ALL_RECEIPT_DETAILS_STD_12_1'||i));
             -- Get All Invoice
             -- Open Cursor to retrieve all invoice id's
              --print_log('Invoice 1 Cursor start');
              --print_log('PO ID '||g_sql_tokens('##$$POID$$##'));
              --print_log('PO Number '||g_sql_tokens('##$$PONUM$$##'));
              --print_log('PO Type '||g_sql_tokens('##$$POTYPE$$##'));
              --print_log('PO Release ID '||g_sql_tokens('##$$PORELID$$##'));
    IF g_sql_tokens('##$$POTYPE$$##') IN ('BLANKET','CONTRACT') THEN               
             OPEN invoice_ids_c_rel ;   
             LOOP
             --print_log('Invoice Cursor loop start');
                 FETCH invoice_ids_c_rel INTO l_invoice_id;
               --  print_log('Invoice Cursor fetch start');
                 EXIT WHEN invoice_ids_c_rel%NOTFOUND;                
                 g_sql_tokens('##$$INVOICEID2$$##') := l_invoice_id;
                 --print_log('JM invoice id: ' || to_char(l_invoice_id));
--                 set_item_result(run_stored_sig('ALL_INVOICE'||i));  
             END LOOP;   
             CLOSE invoice_ids_c_rel;  
  ELSE
             OPEN invoice_ids_c_std ;   
             LOOP
             --print_log('Invoice 2 Cursor loop start');
                 FETCH invoice_ids_c_std INTO l_invoice_id;
               --  print_log('Invoice Cursor fetch start');
                 EXIT WHEN invoice_ids_c_std%NOTFOUND;                
                 g_sql_tokens('##$$INVOICEID2$$##') := l_invoice_id;
                -- print_log('JM invoice id: ' || to_char(l_invoice_id));
--                 set_item_result(run_stored_sig('ALL_INVOICE'||i));  
             END LOOP;   
             CLOSE invoice_ids_c_std;   
  
  END IF;
             --print_log('Invoice Cursor end');
             set_item_result(run_stored_sig('ALL_INVOICE'||i));             

           
             -- CG end changes
             
          END LOOP;
      END IF;    
      
    
  end_section; 

 /* Jeff Testing all in one sig */
   l_step := '175';
   start_section('TESTING2');   
      IF (g_purchase_orders.COUNT > 0) THEN 
         FOR i IN g_purchase_orders.FIRST .. g_purchase_orders.LAST
           LOOP
             g_sql_tokens('##$$POID$$##') := g_purchase_orders(i);
             g_sql_tokens('##$$PONUM$$##') := g_purchase_orders2(i);
             g_sql_tokens('##$$POTYPE$$##') := g_purchase_orders3(i);             
             g_sql_tokens('##$$PORELID$$##') := g_purchase_orders4(i);   
            IF g_sql_tokens('##$$POTYPE$$##') IN ('BLANKET','CONTRACT') THEN 
                         -- Open Cursor to retrieve all receipt id's             
                         OPEN receipts_ids_rel_c;  
                         LOOP              
                             FETCH receipts_ids_rel_c INTO l_receipt_id; 
                             EXIT WHEN receipts_ids_rel_c%NOTFOUND;
               --                print_log('JM receipt id: ' || to_char(l_receipt_id));
                         END LOOP;             
                         CLOSE receipts_ids_rel_c;
                         
                         OPEN invoice_ids_c_rel ;   
                         LOOP
                 --        print_log('Invoice Cursor loop start');
                             FETCH invoice_ids_c_rel INTO l_invoice_id;
                   --          print_log('Invoice Cursor fetch start');
                             EXIT WHEN invoice_ids_c_rel%NOTFOUND;                
                             g_sql_tokens('##$$INVOICEID2$$##') := l_invoice_id;
                     --        print_log('JM invoice id: ' || to_char(l_invoice_id));
                         END LOOP;   
                         CLOSE invoice_ids_c_rel;
                         
                         OPEN check_ids_c_rel ;   
                         LOOP
                   --      print_log('Payment Cursor loop start');
                             FETCH check_ids_c_rel INTO l_check_id;
                     --        print_log('Payment Cursor fetch start');
                             EXIT WHEN check_ids_c_rel%NOTFOUND;                
                        --     g_sql_tokens('##$$INVOICEID2$$##') := l_invoice_id;
                       --      print_log('JM check id: ' || to_char(l_check_id));
                         END LOOP;   
                         CLOSE check_ids_c_rel;                         
                         
                         
                         set_item_result(run_stored_sig('ALL_DATA_REL_'||i));
            ELSE 
                         OPEN receipts_ids_std_c;  
                         LOOP              
                             FETCH receipts_ids_std_c INTO l_receipt_id; 
                             EXIT WHEN receipts_ids_std_c%NOTFOUND;
                         --      print_log('JM receipt id: ' || to_char(l_receipt_id));
                         END LOOP;             
                         CLOSE receipts_ids_std_c;
                         
                        OPEN invoice_ids_c_std ;   
                         LOOP
            --             print_log('Invoice 2 Cursor loop start');
                             FETCH invoice_ids_c_std INTO l_invoice_id;
              --               print_log('Invoice Cursor fetch start');
                             EXIT WHEN invoice_ids_c_std%NOTFOUND;                
                             g_sql_tokens('##$$INVOICEID2$$##') := l_invoice_id;
                --             print_log('JM invoice id: ' || to_char(l_invoice_id));
                         END LOOP;   
                         CLOSE invoice_ids_c_std;
                         
                         OPEN check_ids_c_std ;   
                         LOOP
                  --       print_log('Payment Cursor loop start');
                             FETCH check_ids_c_std INTO l_check_id;
                    --         print_log('Payment Cursor fetch start');
                             EXIT WHEN check_ids_c_std%NOTFOUND;                
                        --     g_sql_tokens('##$$INVOICEID2$$##') := l_invoice_id;
                      --       print_log('JM check id: ' || to_char(l_check_id));
                         END LOOP;   
                         CLOSE check_ids_c_std;
                         
                         
                         
                         
                         set_item_result(run_stored_sig('ALL_DATA_STD_'||i));
            END IF;     
       END LOOP;
      END IF;  
      
   end_section;
 END IF; -- End P_mode = All
 
  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '200';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/thread/3800635" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

-------------------------------------------
-- MAIN ENTRY POINT FOR CONCURRENT PROCESS
-- uncomment to run from concurrent program
-- edit list of variables to match MAIN
-- <package>.main_cp will be what you define program to call
-------------------------------------------
-- PSD #16	
PROCEDURE main_cp(
      errbuf            OUT VARCHAR2, 
      retcode           OUT VARCHAR2,
      p_mode            IN VARCHAR2,  
      p_org_id          IN NUMBER,    
      p_req_num         IN VARCHAR2,
      p_dummy1          IN VARCHAR2,
      p_trx_type        IN VARCHAR2,
      p_dummy2          IN VARCHAR2,  
      p_po_num          IN VARCHAR2, 
      p_dummy3          IN VARCHAR2,  
      p_release_num     IN NUMBER,   
      p_dummy4          IN VARCHAR2,  
      p_invoice_num     IN VARCHAR2,  
      p_max_output_rows IN NUMBER,    
      p_debug_mode      IN VARCHAR2) IS

l_trx_type  VARCHAR2(30);
l_trx_num   VARCHAR2(25);
l_step      VARCHAR2(5);

BEGIN
  l_step := '10';
  g_retcode := '0';
  g_errbuf := null;
  l_trx_type := p_trx_type;  
  l_trx_num := nvl(p_po_num, p_req_num);  
  l_step := '20';
  

  IF (l_trx_type IS NULL) THEN
     l_trx_type := 'ANY';
  END IF;
  
  main(
      p_mode => p_mode,  
      p_org_id => p_org_id,
      p_req_num => p_req_num,
      p_trx_type => p_trx_type,
      p_po_num => p_po_num,
      p_release_num => p_release_num,
      p_invoice_num => p_invoice_num,
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode,
      p_calling_from => 'Concurrent Program');

  l_step := '30';
  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp:'||l_step||' '||sqlerrm||' : '||g_errbuf;
END main_cp;


-- PSD #1
END p2p_analyzer_pkg;
/
show errors
exit;
