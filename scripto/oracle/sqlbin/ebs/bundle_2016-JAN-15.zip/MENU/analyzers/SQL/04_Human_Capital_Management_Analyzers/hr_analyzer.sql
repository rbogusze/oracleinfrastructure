SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE '~'
SET ESCAPE ON
WHENEVER SQLERROR EXIT

REM $Id: hr_analyzer.sql, 200.56 2016/01/15 10:26:28 simona.elena.ionescu@oracle.com Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.35                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    hr_analyzer.sql                                                      |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+
REM REM
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2
REM 
REM MENU_TITLE: HR Technical Analyzer
REM
REM MENU_START
REM
REM SQL: Run HR Technical Analyzer
REM FNDLOAD: Load HR Technical Analyzer as a Concurrent Program
REM
REM MENU_END 
REM
REM 
REM HELP_START  
REM 
REM  HR Technical Analyzer Help [Doc ID: 1562530.1]
REM
REM  Compatible with: [11i|12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs hr_analyzer.sql as APPS user to create an HTML report
REM
REM    (2) Install HR Technical Analyzer as Concurrent Program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group: "Global HRMS Reports & Process"
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: PER_TOP
REM PROG_NAME: HCM_ANALYZER_SQL
REM DEF_REQ_GROUP: Global HRMS Reports & Process
REM PROG_TEMPLATE: HRTECHNICALAZ.ldt
REM PROD_SHORT_NAME: PER 
REM CP_FILE: hr_analyzer_cp.sql
REM APP_NAME: Human Resources
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM  
REM
REM DEPENDENCIES_END
REM
REM OUTPUT_TYPE: UTL_FILE 
REM
REM ANALYZER_BUNDLE_END

alter session set nls_date_format = 'DD-MON-YYYY';

declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,4);
 
 -- Validation to verify analyzer is run on proper e-Business application version
 if apps_version NOT IN ('11.5','12.0','12.1','12.2') then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'           ');
    dbms_output.put_line('*** This Analyzer script is compatible for following version(s): ');
	dbms_output.put_line('***   11i,12.0,12.1,12.2 ');
    dbms_output.put_line('*** Note: the error below is intentional                    ');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness versions 11i,12.0,12.1,12.2');
 end if;

END;
/


PROMPT



DECLARE
   l_debug_mode VARCHAR2(1) := 'Y';




TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1562530.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

    l_log_file := 'HRTECHNICAL_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'HRTECHNICAL_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>HRTECHNICAL Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
              'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfL'||
              'T8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

-- Print title
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">EBS '|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1562530.1:SQL">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/hcm_technical_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\\2">Patch \\2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\\[)([0-9]*\\.[0-9])(\\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\\2">Doc ID \\2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
	-- removed initCap per Standardization team in 3.0.34
    l_col_headings(i) := replace(l_desc_rec_tbl(i).col_name,'|','<br>');
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_sigxinfo_element     XMLDOM.DOMElement;
l_sigxinfo_node        XMLDOM.DOMNode;
l_xinfo_element        XMLDOM.DOMElement;
l_xinfo_node           XMLDOM.DOMNode;
l_xinfo_name_attr      XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);
   
   IF p_sig.extra_info.count > 0 THEN
      l_sigxinfo_element := XMLDOM.createElement(l_hidden_xml_doc,'sigxinfo');      
      l_sigxinfo_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_sigxinfo_element));      
      l_key := p_sig.extra_info.first;
      WHILE l_key IS NOT NULL LOOP
         l_xinfo_element := XMLDOM.createElement(l_hidden_xml_doc,'info');      
         l_xinfo_node := XMLDOM.appendChild(l_sigxinfo_node,XMLDOM.makeNode(l_xinfo_element));      
         l_xinfo_name_attr := XMLDOM.setAttributeNode(l_xinfo_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name')); 
         XMLDOM.setAttribute(l_xinfo_element, 'name',l_key);
         l_node := XMLDOM.appendChild(l_xinfo_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,p_sig.extra_info(l_key))));         
         l_key := p_sig.extra_info.next(l_key);
      END LOOP;
   END IF;   
   
   IF p_sig.include_in_xml='Y' THEN

      IF p_sig.limit_rows='Y' THEN
         l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
      ELSE
         l_rows := least(p_col_rows(1).COUNT,50);
      END IF;
   
      FOR i IN 1..l_rows LOOP

         l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
         l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
         l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
         XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
         FOR j IN 1..p_col_headings.count LOOP
 
            l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
            l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
            l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
            XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
            l_value := p_col_rows(j)(i);

            IF p_sig_id = 'REC_PATCH_CHECK' THEN
               IF p_col_headings(j) = 'Patch' THEN
                  l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
               ELSIF p_col_headings(j) = 'Note' THEN
                  l_value := replace(replace(p_col_rows(j)(i),'['),']');
               END IF;
            END IF;
		 
		    -- Rtrim the column value if blanks are not to be preserved
             IF NOT g_preserve_trailing_blanks THEN
               l_value := RTRIM(l_value, ' ');
             END IF;

            l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

          END LOOP;

       END LOOP;
     
     END IF;  --p_sig.include_in_xml='Y'            
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml IN ('Y','P')) THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  	
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;		  
		  
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
			
       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;			
			
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);
		-- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;
		 
          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;
	
  END IF;	
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div><br>');
END print_rep_subsection_end;


-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------



-------------------------
-- Recommended patches 
-------------------------

FUNCTION check_rec_patches_1 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_1');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21327657';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'NO: Half tax calculation';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21327657';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'NO: Half tax calculation';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '16077077';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '14177955';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Delivers the K27 reimbursement file upload';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '14171993';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Delivers the K27 reimbursement file upload';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12807777';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Norway mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_NO',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_1');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_1 at step '||l_step);
  raise;
END check_rec_patches_1;

FUNCTION check_rec_patches_2 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_2');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22311680';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'IRAS SPECIFICATION FOR YA 2016';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22311680';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'IRAS SPECIFICATION FOR YA 2016';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20055967';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'IRAS and IR21 CHANGES EOY 2014';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16077077';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17188127';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'SG.35 SINGAPORE CONSOLIDATED PATCH';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12807777';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Singapore mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_SG',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_2');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_2 at step '||l_step);
  raise;
END check_rec_patches_2;

FUNCTION check_rec_patches_3 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_3');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22123865';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'EMPLOYEE AND EMPLOYER UIF CONTRIBUTIONS FOR WEEKLY PAYROLLS';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '21966943';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'CHANGES FOR BANK ACCOUNT NUMBER VALIDATION';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '19193000';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22123865';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'EMPLOYEE AND EMPLOYER UIF CONTRIBUTIONS FOR WEEKLY PAYROLLS';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '21966943';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'CHANGES FOR BANK ACCOUNT NUMBER VALIDATION';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '20000288';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19544341';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ZA: AUGTYE14 REPORTING CHANGES';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16077077';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17366859';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ZA : Tax Audit report';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12807777';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'South Africa mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_ZA',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_3');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_3 at step '||l_step);
  raise;
END check_rec_patches_3;

FUNCTION check_rec_patches_4 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_4');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20000288';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16741703';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Prevent Tax payable when under One Yuan (RMB)';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '13715802';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '16077077';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '13715802';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '14625844';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Prevent Tax Payable when under One YUAN (RMB)';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '13717027';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '12807777';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(3) := '';

END IF;

   l_sig.title := 'China mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches ';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_CN',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_4');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_4 at step '||l_step);
  raise;
END check_rec_patches_4;

FUNCTION check_rec_patches_5 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_5');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21033080';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'PENSIONS AUTOMATIC ENROLMENT/RE-ENROLMENT LEGISLATIVE CHANGES';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20888184';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'TAX YEAR END BUG FIXES';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '20692428';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'TAX YEAR END BUG FIXES';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '20591016';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'SHARED PARENTAL LEAVE AND PAY CHANGES';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '20513833';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'RTI GB UPDATE NI CATEGORY ERRORS';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '20314902';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'YEAR END 2014-15 / START OF YEAR 2015-16';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '20201659';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'UK YEAR END 2014-15 / START OF YEAR 2015-16';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '20066028';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'PENSERVER LEGISLATIVE CHANGES';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '20000288';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '19223877';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'P11D LEGISLATIVE CHANGES for 2014-15';
   l_col_rows(5)(10) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '18972503';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '18776254';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'RTI CONSOLIDATED PATCH: SEPTEMBER 2014';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '18693666';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'DIRECT EARNINGS ATTACHMENT CHANGES: PHASE2';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '18453569';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '18333366';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'DIRECT EARNINGS ATTACHMENT CHANGES';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '18293592';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '18285764';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/LGPS CHANGES';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '18100149';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '17274247';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '16077077';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(10) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '18972450';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '18776031';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'RTI CONSOLIDATED PATCH: SEPTEMBER 2014';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '18449320';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '18333164';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'DIRECT EARNINGS ATTACHMENT CHANGES';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '18305045';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '18293579';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /P11D/LGPS CHANGES';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '18285780';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /LGPS CHANGES';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '18100105';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '18032762';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014:PHASE2 PATCH';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '17964873';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'UK TAX YEAR END CHANGES 2013 - 2014';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '17774746';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'HR_PF.K.RUP.9';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '17274234';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := 'RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH';
   l_col_rows(5)(12) := '';

END IF;

   l_sig.title := 'United Kingdom mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_UK',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_5');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_5 at step '||l_step);
  raise;
END check_rec_patches_5;

FUNCTION check_rec_patches_6 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_6');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22371111';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 2 Q4 2015 and Year Begin 2016 Statutory Updates';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '21911111';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '21664392';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'Q3 2015 SQWL and JIT STATUTORY UPDATE';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '19193000';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(4) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22371111';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 2 Q4 2015 and Year Begin 2016 Statutory Updates';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '21911111';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '21664392';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'Q3 2015 SQWL and JIT STATUTORY UPDATE';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '20000288';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(4) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20365000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2014 Phase 3';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20212223';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'End of Year 2014 Phase 2';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '19701971';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'End of Year 2014 Phase 1';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '19507770';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'Q3 2014 Statutory and JIT Update';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '16077077';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(5) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '22371110';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 2 and Q4 2015 Statutory Updates';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '22371100';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Year Begin 2016 Statutory Update';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '22233434';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'NACHA PROGRAM FOR CHILD SUPPORT EFT PAYMENT METHOD FAILING WITH ERROR';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '21911110';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '21664379';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'Q3 2015 SQWL and JIT STATUTORY UPDATE';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '17774746';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'HR_PF.K.RUP.9';
   l_col_rows(5)(6) := '';

END IF;

   l_sig.title := 'United States mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_US',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_6');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_6 at step '||l_step);
  raise;
END check_rec_patches_6;

FUNCTION check_rec_patches_7 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_7');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22305187';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Danish Legislative Changes 2016';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20218977';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'ABP PGGM Calculation Changes 2015';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '20000288';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22305187';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Danish Legislative Changes 2016';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20218977';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'ABP PGGM Calculation Changes 2015';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '16077077';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '16002352';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Danish Legislative Changes 2013 Part-3';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '15945507';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Danish Legislative Changes 2013 Part 1, 2';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '13500283';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'Danish Legislative Changes 2012';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '12807777';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(4) := '';

END IF;

   l_sig.title := 'Denmark mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_DK',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_7');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_7 at step '||l_step);
  raise;
END check_rec_patches_7;

FUNCTION check_rec_patches_8 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_8');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.delta.6';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17909898';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.delta.5';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '17050005';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.C.Delta.4';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '17001123';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.HR_PF.C.delta.3';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '16169935';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.HR_PF.C.delta.2';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '14040707';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.HR_PF.C.delta.1';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '10124646';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'R12.HR_PF.C';
   l_col_rows(5)(7) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20000288';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '18004477';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.7';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '16000686';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.B.delta.6';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '13418800';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.HR_PF.B.delta.5';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '10281212';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.HR_PF.B.delta.4';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '9114911';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.HR_PF.B.delta.3';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '8337373';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'R12.HR_PF.B.delta.2';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '7446767';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'R12.HR_PF.B.delta.1';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '6603330';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'R12.HR_PF.B';
   l_col_rows(5)(9) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '16077077';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '13774477';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.10';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '10281209';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.A.delta.9';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '9301208';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.HR_PF.A.delta.8';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '7577660';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.HR_PF.A.delta.7';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '7004477';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.HR_PF.A.delta.6';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '6610000';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'R12.HR_PF.A.delta.5';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '6494646';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'R12.HR_PF.A.delta.4';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '6196269';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'R12.HR_PF.A.delta.3';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '5997278';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'R12.HR_PF.A.delta.2';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '5881943';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'R12.HR_PF.A.delta.1';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '4719824';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := 'R12.HR_PF.A';
   l_col_rows(5)(12) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17774746';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'HR_PF.K.RUP.9';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '14488556';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.8';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '12807777';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '10015566';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'HR_PF.K.RUP.6';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '9062727';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'HR_PF.K.RUP.5';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '7666111';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'HR_PF.K.RUP.4';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '6699770';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'HR_PF.K.RUP.3';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '5337777';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'HR_PF.K.RUP.2';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '5055050';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'HR_PF.K.RUP.1';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '3500000';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'HRMS_PF.K';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '3333633';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'HRMS_PF.J';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '3233333';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := 'HRMS_PF.H';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '3127777';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := 'HRMS_PF.I';
   l_col_rows(5)(13) := '';

   l_col_rows(1)(14) := '3116666';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := 'HRMS_PF.G';
   l_col_rows(5)(14) := '';

   l_col_rows(1)(15) := '2968701';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := 'HRMS_PF.F';
   l_col_rows(5)(15) := '';

   l_col_rows(1)(16) := '2803988';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := 'HRMS_PF.E';
   l_col_rows(5)(16) := '';

END IF;

   l_sig.title := 'RUP patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please check if any RUP patches were not applied in this instance';
   l_sig.solution := 'Please review list above and schedule to apply any unappplied patches as soon as possible.';
   l_sig.success_msg := 'Latest RUP applied.';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'RUP',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_8');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_8 at step '||l_step);
  raise;
END check_rec_patches_8;

FUNCTION check_rec_patches_9 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_9');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20075576';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'UAE National identifier validation changes and Formula Result rule for KW SI';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19900524';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'UAE National identifier validation changes';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '19193000';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20000288';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19900524';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'UAE National identifier validation changes';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '19819953';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'ROUTING NUMBER IN UAE LEGISLATION';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19900524';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'UAE National identifier validation changes';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19819953';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'ROUTING NUMBER IN UAE LEGISLATION';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '16077077';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '12807777';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(1) := '';

END IF;

   l_sig.title := 'United Arab Emirates mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_AE',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_9');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_9 at step '||l_step);
  raise;
END check_rec_patches_9;

FUNCTION check_rec_patches_10 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_10');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21778035';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'KOREA CUMULATIVE RELEASE PATCH - KR.76';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21778035';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'KOREA CUMULATIVE RELEASE PATCH - KR.76';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20533775';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'KOREA CUMULATIVE RELEASE PATCH - KR.73';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16077077';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '18107426';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'KOREA 2013 YEA CHANGES: SINGLE PARENT EXEMPTION';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17446056';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'KOREA 2013 YEA CHANGES: RENT EXEMPTION,MAXIMUM SPECIAL EXEMPTION LIMIT';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '16518233';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'KOREA CUMULATIVE RELEASE PATCH - 11i.KR.69';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '12807777';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(4) := '';

END IF;

   l_sig.title := 'Korea mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_Korea',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_10');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_10 at step '||l_step);
  raise;
END check_rec_patches_10;

FUNCTION check_rec_patches_11 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_11');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20000288';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12793751';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Delivers the Finland legislative changes for 2011 Part-I';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '16077077';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12793751';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Delivers the Finland legislative changes for 2011 Part-I';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '12807777';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '10393363';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Delivers the Finland legislative changes for 2011 Part-I';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Finland mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_FI',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_11');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_11 at step '||l_step);
  raise;
END check_rec_patches_11;

FUNCTION check_rec_patches_12 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_12');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20331815';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Change in employee social insurance contributions for Kuwait';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20331815';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Change in employee social insurance contributions for Kuwait';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19009589';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'KW Unemployment Insurance';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16787133';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Kuwait SI changes 2013';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '16077077';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '15934773';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'KUWAIT Report changes';
   l_col_rows(5)(4) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '16806105';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Kuwait SI changes 2013';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '15934061';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'KUWAIT Report changes';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '12807777';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(3) := '';

END IF;

   l_sig.title := 'Kuwait mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_KW',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_12');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_12 at step '||l_step);
  raise;
END check_rec_patches_12;

FUNCTION check_rec_patches_13 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_13');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22371111';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 2 Q4 2015 and Year Begin 2016 Statutory Updates';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '21911111';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '19193000';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22371111';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 2 Q4 2015 and Year Begin 2016 Statutory Updates';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '21911111';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '20000288';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20365000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2014 Phase 3';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20212223';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'End of Year 2014 Phase 2';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '19701971';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'End of Year 2014 Phase 1';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '16077077';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(4) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '22371110';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 2 and Q4 2015 Statutory Updates';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '22371100';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Year Begin 2016 Statutory Update';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '21911110';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '17774746';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'HR_PF.K.RUP.9';
   l_col_rows(5)(4) := '';

END IF;

   l_sig.title := 'Canada mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_CA',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_13');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_13 at step '||l_step);
  raise;
END check_rec_patches_13;

FUNCTION check_rec_patches_14 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_14');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22460469';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Dutch Legislation - LHD and ABP Changes 2016';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22460469';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Dutch Legislation - LHD and ABP Changes 2016';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20279973';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ABP PGGM Calculation Changes 2015';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16077077';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17558120';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Delivers changes to Dutch Annual Tax Statement for the Employee Report effective 2013';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12807777';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Netherlands mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_NL',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_14');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_14 at step '||l_step);
  raise;
END check_rec_patches_14;

FUNCTION check_rec_patches_15 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_15');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20699005';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20699005';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '16077077';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '13697009';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.PER.A - NZ STATUTORY UPDATES 2012';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '11867792';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.PER.A - NEW ZEALAND CUMULATIVE RELEASE R12.NZ.08';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '13627558';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'NZ STATUTORY UPDATES 2012';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12807777';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '11867781';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'NEW ZEALAND CUMULATIVE RELEASE 11i.NZ.08';
   l_col_rows(5)(3) := '';

END IF;

   l_sig.title := 'New Zealand mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_NZ',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_15');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_15 at step '||l_step);
  raise;
END check_rec_patches_15;

FUNCTION check_rec_patches_16 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_16');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20979690';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'US HR 2015 ANNUAL STATUTORY PATCH FOR RELEASE 12.2';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '18844524';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'US HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 12.2.3 or Higher';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20979690';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'US HR 2015 ANNUAL STATUTORY PATCH FOR RELEASE 12.2';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '18844524';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'US HR 2014 ANNUAL STATUTORY PATCH';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '18844524';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'US HR 2014 ANNUAL STATUTORY PATCH';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '20979676';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'US HR 2015 ANNUAL STATUTORY PATCH';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '18844514';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'US HR 2014 ANNUAL STATUTORY PATCH';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'United States HR mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_US_PER',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_16');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_16 at step '||l_step);
  raise;
END check_rec_patches_16;

FUNCTION check_rec_patches_17 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_17');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20000288';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17015507';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'APANESE HRMS CONSOLIDATED PATCH R121.JP.13';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '16077077';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '13743712';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'H24 UNEMPLOYMENT INSURANCE RATE';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '13330458';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'JAPANESE HRMS CONSOLIDATED PATCH R12.JP.12';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17015482';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'JAPANESE HRMS CONSOLIDATED UPDATE R115.JP.13';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12807777';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Japan mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_Japan',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_17');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_17 at step '||l_step);
  raise;
END check_rec_patches_17;

FUNCTION check_rec_patches_18 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_18');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21238399';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21267565';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19764591';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'AU.22 AUSTRALIA CONSOLIDATED PATCH';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16077077';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17314780';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '11I.AU.21 AUSTRALIA CUMULATIVE RELEASE';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '14488556';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.8';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Australia mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches ';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_AU',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_18');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_18 at step '||l_step);
  raise;
END check_rec_patches_18;

FUNCTION check_rec_patches_19 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_19');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22501143';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Ireland Electronic P60 Changes';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '22367634';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'USC Week 53 Changes';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '22273305';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12-TYE-2015:Ireland Post EAP Patch';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '21909181';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'Ireland Pension Tracing Number Changes';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '21499442';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'Ireland P35 Version 12 Reporting Changes';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '19193000';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(6) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22501143';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Ireland Electronic P60 Changes';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '22367634';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'USC Week 53 Changes';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '21909181';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'Ireland Pension Tracing Number Changes';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '21499442';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'Ireland P35 Version 12 Reporting Changes';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '20000288';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(5) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20255656';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Employer PAYE Reference Reporting Changes';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20235946';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Employers PAYE Reference Increased To 9 Characters';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '20210371';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'USC On Tax Information Screen';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '20073662';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'Ireland Budget Changes Effective 01-JAN-2015';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '19820820';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'Ireland EIR Code Address Changes For 2015';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '19684111';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'Ireland P60 Reporting Changes 2014 Onwards';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '19068744';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'IE SEPA BANK OF IRELAND (BOI) CHANGES';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '19060389';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'Ireland P35 Version 11 Reporting Changes';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '18510224';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'IE MEDICAL INSURANCE CHANGES 2014';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '16077077';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(10) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17775887';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'IRELAND SEPA CHANGES: HSBC FORMAT: FEEDBACK FROM HSBC';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17731547';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'EAP NOVEMBER 2013 ISSUES: P35 XML REPORT CHANGES';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '17592973';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'Generating SEPA File For PayPath Payment Method';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '17573671';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'IE SEPA ULSTER BANK CHANGES';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '17542073';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'IE SEPA HSBC BANK CHANGES';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '17180755';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'IE SEPA FURTHER CHANGES: AIB FORMAT';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '16999708';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'LPT Deducing From Statutory Redundancy';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '16976741';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'IE P30 Paper Report Not Reporting Non Zero USC/LPT';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '16925013';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'LPT Deducting Over 5 Not 6 Months From July 2013';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '16905146';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'Ireland Local Property Tax P30 Paper Report Changes';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '16811068';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'Ireland Local Property Tax And Report Changes';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '12807777';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(12) := '';

END IF;

   l_sig.title := 'Ireland mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_IE',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_19');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_19 at step '||l_step);
  raise;
END check_rec_patches_19;

FUNCTION check_rec_patches_20 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_20');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20768287';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20768287';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '17385401';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013 1 JUN 2014';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16077077';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17539543';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12807777';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Hong Kong mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_HK',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_20');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_20 at step '||l_step);
  raise;
END check_rec_patches_20;

FUNCTION check_rec_patches_21 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_21');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21543732';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'INDIA HRMS CONSOLIDATED PATCH IN.12';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19193000';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21543732';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'INDIA HRMS CONSOLIDATED PATCH IN.12';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19856359';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'INDIA HRMS CONSOLIDATED UPDATE R12.IN.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16077077';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '16669518';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Madhya Pradesh Professional Tax Changes Effective 01-APR-2013';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16520998';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'India Budget Changes Gujarat Professional Tax Changes Effective 01-APR-2013';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '16359871';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'Andhra Pradesh professional Tax changes Effective 06-FEB-2013';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '14351973';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'India Budget Changes for Section 80CCG and Section 80TTA';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '13914662';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'INDIA HRMS CONSOLIDATED UPDATE 11i.IN.08';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '13870875';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'Form 24Q E-TDS Regular Changes';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '12807777';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(7) := '';

END IF;

   l_sig.title := 'India mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_IN',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_21');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_21 at step '||l_step);
  raise;
END check_rec_patches_21;

FUNCTION check_rec_patches_22 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_22');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '18723486';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'SA Unemployment insurance changes';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20000288';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19054295';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Can not create absence';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '18723486';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'SA Unemployment insurance changes';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '18760981';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'SA Unemployment insurance changes';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '16077077';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '12807777';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(1) := '';

END IF;

   l_sig.title := 'Saudi Arabia mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_SA',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_22');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_22 at step '||l_step);
  raise;
END check_rec_patches_22;

FUNCTION check_rec_patches_23 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_23');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.Delta.6';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20000288';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '16077077';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '12589129';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Delivers the Sweden legislative changes for 2011';
   l_col_rows(5)(2) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '12807777';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '10393370';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Delivers the Sweden legislative changes for 2011';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Sweden mandatory patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please schedule to apply unappplied mandatory patches';
   l_sig.solution := '';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'E';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'MAND_SE',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_23');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_23 at step '||l_step);
  raise;
END check_rec_patches_23;

FUNCTION check_rec_patches_24 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_24');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19245366';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.ATG_PF.C.delta.5';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17909318';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.ATG_PF.C.delta.4';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '17007206';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.ATG_PF.C.delta.3';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '15890638';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.ATG_PF.C.delta.2';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '14222219';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.ATG_PF.C.delta.1';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '10110982';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.ATG_PF.C';
   l_col_rows(5)(6) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '8919491';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.ATG_PF.B.delta.3';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '7651091';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.ATG_PF.B.delta.2';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '7307198';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.ATG_PF.B.delta.1';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '6430106';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.ATG_PF.B';
   l_col_rows(5)(4) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '7237006';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.ATG_PF.A.delta.6';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '6594849';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.ATG_PF.A.delta.5';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '6272680';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.ATG_PF.A.delta.4';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '6077669';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.ATG_PF.A.delta.3';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '5917344';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.ATG_PF.A.delta.2';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '5907545';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.ATG_PF.A.delta.1';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '4461237';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'R12.ATG_PF.A';
   l_col_rows(5)(7) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '6241631';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '11i.ATG_PF.H RUP7';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '5903765';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '11i.ATG_PF.H RUP6';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '5473858';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '11i.ATG_PF.H RUP5';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '4676589';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '11i.ATG_PF.H RUP4';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '4334965';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '11i.ATG_PF.H RUP3';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '4125550';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '11i.ATG_PF.H RUP2';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '4017300';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '11i.ATG_PF.H RUP1';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '3438354';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '11i.ATG_PF.H';
   l_col_rows(5)(8) := '';

END IF;

   l_sig.title := 'ATG Patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please check if any of the patches were not applied in this instance';
   l_sig.solution := 'Please review list above and schedule to apply any unappplied patches as soon as possible.';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'ATGforHCM',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_24');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_24 at step '||l_step);
  raise;
END check_rec_patches_24;

FUNCTION check_rec_patches_25 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_25');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21276246';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ANNUAL GEOCODE UPDATE - 2015';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21276246';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ANNUAL GEOCODE UPDATE - 2015';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19139617';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ANNUAL GEOCODE UPDATE - 2014';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '21276241';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ANNUAL GEOCODE UPDATE - 2015';
   l_col_rows(5)(1) := '';

END IF;

   l_sig.title := 'Geocode patch';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please check if any of the recommended patches were not applied in this instance';
   l_sig.solution := 'Please review list above and schedule to apply any unappplied patches as soon as possible';
   l_sig.success_msg := 'Latest patches applied.';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'Geocode_patch',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_25');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_25 at step '||l_step);
  raise;
END check_rec_patches_25;

FUNCTION check_rec_patches_26 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_26');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21911111';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21911111';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '21911110';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'End of Year 2015 Phase 1';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '19701971';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'End of Year 2014 Phase 1';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'Quantum Patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please check if any of the recommended patches were not applied in this instance';
   l_sig.solution := '<ul><li>Please periodically review: [224273.1] Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations>/li>
<li>Vertex is a third party product used by Oracle Payroll and delivers the Quantum product.</li>
<li>Quantum is required only for a full installation of Oracle Payroll.  This is the tax engine. </li>
<li>Please periodically review: [224273.1] Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations</li>
<li>In order to identify Monthly Quantum file you have installed, use [272429.1] How to Obtain the File Version of Monthly qfpt.dat for Quantum Used in Payroll </li></ul>';
   l_sig.success_msg := '<ul><li>Latest patches applied.</li>
<li>Vertex is a third party product used by Oracle Payroll and delivers the Quantum product.</li>
<li>Quantum is required only for a full installation of Oracle Payroll.  This is the tax engine. </li>
<li>Please periodically review: [224273.1] Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations</li>
<li>In order to identify Monthly Quantum file you have installed, use [272429.1] How to Obtain the File Version of Monthly qfpt.dat for Quantum Used in Payroll </li></ul>';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'Quantum_patch',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_26');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_26 at step '||l_step);
  raise;
END check_rec_patches_26;

FUNCTION check_rec_patches_27 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_27');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21664392';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Q3 2015 SQWL and JIT STATUTORY UPDATE';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '21664392';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Q3 2015 SQWL and JIT STATUTORY UPDATE';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19507770';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Q3 2014 Statutory and JIT Update';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '21664379';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Q3 2015 SQWL and JIT STATUTORY UPDATE';
   l_col_rows(5)(1) := '';

END IF;

   l_sig.title := 'JIT patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'JIT patch not applied';
   l_sig.solution := '';
   l_sig.success_msg := 'JIT patch applied';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'JIT_patch',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_27');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_27 at step '||l_step);
  raise;
END check_rec_patches_27;

FUNCTION check_rec_patches_28 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_28');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '13691576';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Organization Chart in Oracle SSHR';
   l_col_rows(5)(1) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '13691576';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Organization Chart in Oracle SSHR';
   l_col_rows(5)(1) := '';

END IF;

   l_sig.title := 'Organization Chart Feature';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Feature not available';
   l_sig.solution := '<ul><li>Organization Chart in Oracle SSHR not available.</li><li>Please ignore this warning if you are not using Organization Chart Feature as per [1408355.1] Using the Organization Chart Feature in Oracle SSHR.</li></ul>';
   l_sig.success_msg := 'Organization_Chart feature available';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'Organization_Chart',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_28');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_28 at step '||l_step);
  raise;
END check_rec_patches_28;




-------------------------
-- Signatures
-------------------------



PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;
  l_key      VARCHAR2(255);

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Clear FK values if the sig has children
  IF l_sig.child_sigs.count > 0 THEN
    l_key := g_sql_tokens.first;
    WHILE l_key is not null LOOP
      IF l_key like '##$$FK_$$##' THEN 
        g_sql_tokens.delete(l_key);
      END IF;
      l_key := g_sql_tokens.next(l_key);
    END LOOP;
  END IF;
  
  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--#######################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
PROCEDURE validate_parameters(
            p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_revision                  VARCHAR2(25);
  l_date_char                 VARCHAR2(30);
  l_instance                  V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version              FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host                      V$INSTANCE.HOST_NAME%TYPE;
  l_key                       VARCHAR2(255);
  l_system_function_var       VARCHAR2(2000);
  l_index                     NUMBER:=1;

  invalid_parameters EXCEPTION;

l_date varchar2(30);
v_hr_status varchar2(50);
v_exists number;
l_retval varchar2(4000);
l_url varchar(2000);
geom     MDSYS.SDO_GEOMETRY;

l_exists_val       VARCHAR2(2000);



FUNCTION get_china
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: china');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'CN'  and status='I';
return v_exists;
debug('end sql token function: china');
END get_china;

FUNCTION get_danemarca
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: danemarca');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'DK'  and status='I';
return v_exists;
debug('end sql token function: danemarca');
END get_danemarca;

FUNCTION get_finland
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: finland');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'FI'  and status='I';
return v_exists;
debug('end sql token function: finland');
END get_finland;

FUNCTION get_hong
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: hong');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'HK'  and status='I';
return v_exists;
debug('end sql token function: hong');
END get_hong;

FUNCTION get_ireland
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: ireland');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';
return v_exists;
debug('end sql token function: ireland');
END get_ireland;

FUNCTION get_mexic
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: mexic');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'MX'  and status='I';
return v_exists;
debug('end sql token function: mexic');
END get_mexic;

FUNCTION get_EXTNET
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: EXTNET');
l_retval:='No response';
l_retval:=substr(UTL_HTTP.REQUEST(url   => 'http://www.google.com/',
                            proxy => hr_util_web.proxyforURL('http://www.google.com/')),0,128);
return replace(replace(replace(l_retval,'<',' '),'>',' '),'''',' ');
exception
  when others then
    return 'Error: '|| replace(replace(replace(substr(sqlerrm,0,128),'<',' '),'>',' '),'''',' ');


debug('end sql token function: EXTNET');
END get_EXTNET;

FUNCTION get_INTNET
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: INTNET');
l_retval:='No response';
l_url:=fnd_profile.value('APPS_FRAMEWORK_AGENT')||'/OA_HTML/JobPositionSeeker.xsl';
  if(lower(substr(l_url,1,5))='https') then
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url
                           ,proxy => hr_util_web.proxyforURL(substr(l_url,1,2000))
                           ,wallet_path=>'file:'||fnd_profile.value('FND_DB_WALLET_DIR')
                           ,wallet_password=>fnd_preference.eget('#INTERNAL','WF_WEBSERVICES','EWALLETPWD', 'WFWS_PWD')
                           ),0,128);
  else
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url
                           ,proxy => hr_util_web.proxyforURL(substr(l_url,1,2000))
                           ),0,128);
  end if;
return replace(replace(replace(l_retval,'<',' '),'>',' '),'''',' ');
exception
  when others then
    return 'Error: '|| replace(replace(replace(substr(sqlerrm,0,128),'<',' '),'>',' '),'''',' ');
debug('end sql token function: INTNET');
END get_INTNET;

FUNCTION get_korea
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: korea');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KR'  and status='I';
return v_exists;
 
debug('end sql token function: korea');
END get_korea;

FUNCTION get_hr_status
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: hr_status');
SELECT L.MEANING  into v_hr_status FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '800') AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
return v_hr_status;
EXCEPTION WHEN NO_DATA_FOUND THEN
return null;
debug('end sql token function: hr_status');
END get_hr_status;

FUNCTION get_australia
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: australia');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AU'  and status='I';
return v_exists;
debug('end sql token function: australia');
END get_australia;

FUNCTION get_usa
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: usa');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'US'  and status='I';
return v_exists;
debug('end sql token function: usa');
END get_usa;

FUNCTION get_canada
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: canada');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'CA'  and status='I';
return v_exists;
debug('end sql token function: canada');
END get_canada;

FUNCTION get_LDATE
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: LDATE');
 SELECT  LAST_UPDATE_DATE into l_date from
(select '12.2' release , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(SELECT to_char(max(to_number(adb.bug_number)))  FROM ad_bugs adb
WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646'))
and rownum < 2
union
select '12.1' release , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330'))
and rownum < 2
union
SELECT '12.0' release , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824'))
and rownum < 2
union
SELECT '11.5' release ,LAST_UPDATE_DATE
                          FROM ad_bugs
                          WHERE BUG_NUMBER = (select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633','3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746'))
and rownum < 2
)
where release in (select substr(release_name,1,4) from fnd_product_groups);
return l_date;
EXCEPTION WHEN others THEN
return null;
debug('end sql token function: LDATE');
END get_LDATE;

FUNCTION get_india
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: india');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IN'  and status='I';
return v_exists;
debug('end sql token function: india');
END get_india;

FUNCTION get_japan
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: japan');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'JP'  and status='I';
return v_exists;
debug('end sql token function: japan');
END get_japan;

FUNCTION get_kuwait
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: kuwait');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KW'  and status='I';
return v_exists;
debug('end sql token function: kuwait');
END get_kuwait;

FUNCTION get_BACKNET
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: BACKNET');
l_retval:='No response';
l_url:=fnd_profile.value('IRC_BACKGROUND_CHECK_VENDOR_URL');
l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url,
                            proxy => hr_util_web.proxyforURL(l_url)),0,128);
return replace(replace(replace(l_retval,'<',' '),'>',' '),'''',' ');
exception
  when others then
    return 'Error: '|| replace(replace(replace(substr(sqlerrm,0,128),'<',' '),'>',' '),'''',' ');


debug('end sql token function: BACKNET');
END get_BACKNET;

FUNCTION get_ELOCATIONY
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: ELOCATIONY');
geom := irc_location_utility.address2geometry(address_line1 => '500 Oracle pky'
                             ,address_line2=> 'redwood city'
                             ,address_line3 => 'CA'
                            ,country=>'US');
return geom.SDO_POINT.y;
exception
  when others then
    return 'Error: '|| replace(replace(replace(substr(sqlerrm,0,128),'<',' '),'>',' '),'''',' ');
debug('end sql token function: ELOCATIONY');
END get_ELOCATIONY;

FUNCTION get_ELOCATIONX
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: ELOCATIONX');
geom := irc_location_utility.address2geometry(address_line1 => '500 Oracle pky'
                             ,address_line2=> 'redwood city'
                             ,address_line3 => 'CA'
                            ,country=>'US');
return geom.SDO_POINT.x;
exception
  when others then
    return 'Error: '|| replace(replace(replace(substr(sqlerrm,0,128),'<',' '),'>',' '),'''',' ');
debug('end sql token function: ELOCATIONX');
END get_ELOCATIONX;

FUNCTION get_Cust
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: Cust');
l_url := fnd_profile.value_specific(name=>'FND_MIGRATED_TO_JRAD',application_id=>800);
return l_url;
exception
  when others then
    return 0;

debug('end sql token function: Cust');
END get_Cust;

FUNCTION get_ae
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: ae');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AE'  and status='I';
return v_exists;
debug('end sql token function: ae');
END get_ae;

FUNCTION get_IRC_GEOCODE
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: IRC_GEOCODE');
select length(fnd_profile.value('IRC_GEOCODE_HOST')) into v_exists from dual;
return v_exists;
exception
  when others then
    return 0;


debug('end sql token function: IRC_GEOCODE');
END get_IRC_GEOCODE;

FUNCTION get_no
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: no');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NO'  and status='I';
return v_exists;
debug('end sql token function: no');
END get_no;

FUNCTION get_nz
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: nz');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NZ'  and status='I';
return v_exists;
debug('end sql token function: nz');
END get_nz;

FUNCTION get_sg
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: sg');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SG'  and status='I';
return v_exists;
debug('end sql token function: sg');
END get_sg;

FUNCTION get_za
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: za');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'ZA'  and status='I';
return v_exists;
debug('end sql token function: za');
END get_za;

FUNCTION get_IRC_BACKGROUND
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: IRC_BACKGROUND');
select length(fnd_profile.value('IRC_BACKGROUND_CHECK_VENDOR_URL')) into v_exists from dual;
return v_exists;
exception
  when others then
    return 0;
debug('end sql token function: IRC_BACKGROUND');
END get_IRC_BACKGROUND;

FUNCTION get_IRC_RESUME
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: IRC_RESUME');
select length(fnd_profile.value('IRC_RESUME_PARSING_VENDOR_URL')) into v_exists from dual;
return v_exists;
exception
  when others then
    return 0;
debug('end sql token function: IRC_RESUME');
END get_IRC_RESUME;

FUNCTION get_nl
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: nl');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NL'  and status='I';
return v_exists;
debug('end sql token function: nl');
END get_nl;

FUNCTION get_sa
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: sa');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SA'  and status='I';
return v_exists;
debug('end sql token function: sa');
END get_sa;

FUNCTION get_se
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: se');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SE'  and status='I';
return v_exists;
debug('end sql token function: se');
END get_se;

FUNCTION get_gb
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: gb');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'GB'  and status='I';
return v_exists;
debug('end sql token function: gb');
END get_gb;

FUNCTION get_hrper
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: hrper');
select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PER'
     and  Legislation_code = 'US'  and status='I';
return v_exists;
debug('end sql token function: hrper');
END get_hrper;

FUNCTION get_RESUMENET
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: RESUMENET');
l_retval:='No response';
l_url:=fnd_profile.value('IRC_RESUME_PARSING_VENDOR_URL');
l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url,
                            proxy => hr_util_web.proxyforURL(l_url)),0,128);
return replace(replace(replace(l_retval,'<',' '),'>',' '),'''',' ');
exception
  when others then
    return 'Error: '|| replace(replace(replace(substr(sqlerrm,0,128),'<',' '),'>',' '),'''',' ');
debug('end sql token function: RESUMENET');
END get_RESUMENET;

FUNCTION get_REL
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: REL');
SELECT max(release_name) INTO v_hr_status
    FROM fnd_product_groups;
return v_hr_status;
EXCEPTION WHEN NO_DATA_FOUND THEN
return null;
debug('end sql token function: REL');
END get_REL;


  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
  l_revision := rtrim(replace('$Revision: 200.56 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2016/01/15 10:26:21 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_rep_info('File Name') := 'hr_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'); 
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1562530.1" target="_blank">(Note 1562530.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------

-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  IF substr(l_apps_version,1,4) NOT IN ('11.5','12.0','12.1','12.2') THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script is compatible for following version(s): 11i,12.0,12.1,12.2');
	raise invalid_parameters;
  END IF;
  

  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');






  -- Create global hash for parameters. Numbers required for the output order

debug('begin populate parameters hash table');
   g_parameters(l_index||'. Maximum Rows to Display') := p_max_output_rows;
   l_index:=l_index+1;
   g_parameters(l_index||'. Debug Mode') := p_debug_mode;
   l_index:=l_index+1;
debug('end populate parameters hash table');



  l_key := g_parameters.first;
  -- Print parameters to the log
  print_log('Parameter Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_parameters(l_key));
    l_key := g_parameters.next(l_key);
  END LOOP;
  
  -- Create global hash of SQL token values

debug('begin populate sql tokens hash table');
   g_sql_tokens('##$$china$$##') := get_china();
   l_system_function_var := null;
   g_sql_tokens('##$$danemarca$$##') := get_danemarca();
   l_system_function_var := null;
   g_sql_tokens('##$$finland$$##') := get_finland();
   l_system_function_var := null;
   g_sql_tokens('##$$hong$$##') := get_hong();
   l_system_function_var := null;
   g_sql_tokens('##$$ireland$$##') := get_ireland();
   l_system_function_var := null;
   g_sql_tokens('##$$mexic$$##') := get_mexic();
   l_system_function_var := null;
   g_sql_tokens('##$$EXTNET$$##') := get_EXTNET();
   l_system_function_var := null;
   g_sql_tokens('##$$INTNET$$##') := get_INTNET();
   l_system_function_var := null;
   g_sql_tokens('##$$korea$$##') := get_korea();
   l_system_function_var := null;
   g_sql_tokens('##$$hr_status$$##') := get_hr_status();
   l_system_function_var := null;
   g_sql_tokens('##$$australia$$##') := get_australia();
   l_system_function_var := null;
   g_sql_tokens('##$$usa$$##') := get_usa();
   l_system_function_var := null;
   g_sql_tokens('##$$canada$$##') := get_canada();
   l_system_function_var := null;
   g_sql_tokens('##$$LDATE$$##') := get_LDATE();
   l_system_function_var := null;
   g_sql_tokens('##$$india$$##') := get_india();
   l_system_function_var := null;
   g_sql_tokens('##$$japan$$##') := get_japan();
   l_system_function_var := null;
   g_sql_tokens('##$$kuwait$$##') := get_kuwait();
   l_system_function_var := null;
   g_sql_tokens('##$$BACKNET$$##') := get_BACKNET();
   l_system_function_var := null;
   g_sql_tokens('##$$ELOCATIONY$$##') := get_ELOCATIONY();
   l_system_function_var := null;
   g_sql_tokens('##$$ELOCATIONX$$##') := get_ELOCATIONX();
   l_system_function_var := null;
   g_sql_tokens('##$$Cust$$##') := get_Cust();
   l_system_function_var := null;
   g_sql_tokens('##$$ae$$##') := get_ae();
   l_system_function_var := null;
   g_sql_tokens('##$$IRC_GEOCODE$$##') := get_IRC_GEOCODE();
   l_system_function_var := null;
   g_sql_tokens('##$$no$$##') := get_no();
   l_system_function_var := null;
   g_sql_tokens('##$$nz$$##') := get_nz();
   l_system_function_var := null;
   g_sql_tokens('##$$sg$$##') := get_sg();
   l_system_function_var := null;
   g_sql_tokens('##$$za$$##') := get_za();
   l_system_function_var := null;
   g_sql_tokens('##$$IRC_BACKGROUND$$##') := get_IRC_BACKGROUND();
   l_system_function_var := null;
   g_sql_tokens('##$$IRC_RESUME$$##') := get_IRC_RESUME();
   l_system_function_var := null;
   g_sql_tokens('##$$nl$$##') := get_nl();
   l_system_function_var := null;
   g_sql_tokens('##$$sa$$##') := get_sa();
   l_system_function_var := null;
   g_sql_tokens('##$$se$$##') := get_se();
   l_system_function_var := null;
   g_sql_tokens('##$$gb$$##') := get_gb();
   l_system_function_var := null;
   g_sql_tokens('##$$hrper$$##') := get_hrper();
   l_system_function_var := null;
   g_sql_tokens('##$$RESUMENET$$##') := get_RESUMENET();
   l_system_function_var := null;
   g_sql_tokens('##$$REL$$##') := get_REL();
   l_system_function_var := null;
debug('end populate sql tokens hash table');



  l_key := g_sql_tokens.first;
  -- Print token values to the log
 
  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;


EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN

   null;



debug('begin add_signature: OVERVIEWHCM');
  add_signature(
      p_sig_id                 => 'OVERVIEWHCM',
      p_sig_sql                => 'select ''Instance Name          = ''|| upper(instance_name) "Instance Summary" from v$instance
                                union
                  select ''Host Name              = ''|| host_name from v$instance
                  union
                                select ''Applications           = ''|| release_name from fnd_product_groups
                                union
                                select ''Instance Creation Date = '' || created from v$database
                                union
                                select ''Database               = '' || banner db_version from v$version where rownum = 1
                                union
                                                                                select ''Platform               = '' || SUBSTR(REPLACE(REPLACE(pcv1.product, ''TNS for ''), '':'' )||pcv2.status, 1, 80)
                    FROM product_component_version pcv1,product_component_version pcv2  WHERE UPPER(pcv1.product) LIKE ''%TNS%'' AND UPPER(pcv2.product) LIKE ''%ORACLE%'' AND ROWNUM = 1
                    union
                                                                                select ''Language               = '' || VALUE FROM V$NLS_PARAMETERS WHERE parameter = ''NLS_LANGUAGE''
                                                                                union
                                                                                select ''Character Set          = '' || VALUE FROM V$NLS_PARAMETERS WHERE parameter = ''NLS_CHARACTERSET''
                                union
                                SELECT ''Product status: PER/HR = '' || L.MEANING
                  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
                  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
                                AND (b.APPLICATION_ID = ''800'')
                                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
                                AND (L.LOOKUP_CODE = I.Status)
                                AND t.language = ''US''    AND l.language = ''US''
                                union
                  SELECT ''Product status: PAY    = '' || L.MEANING
                  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
                  WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
                    AND b.application_id = t.application_id
                                AND (b.APPLICATION_ID = ''801'')
                                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
                                AND (L.LOOKUP_CODE = I.Status)
                                AND t.language = ''US''    AND l.language = ''US''
                                union
                  SELECT ''Multi Org              = '' || MULTI_ORG_FLAG FROM FND_PRODUCT_GROUPS
                                union
                  SELECT ''Multi Currency         = '' || MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS
                  union
                  SELECT ''RUP Level              = ''|| RUP_LEVEL || '' applied on '' || LAST_UPDATE_DATE from
(select ''12.2'' release , DECODE(bug_number
                  ,''17001123'', ''17001123 R12.HR_PF.C.delta.3''
                  , ''16169935'', ''16169935 R12.HR_PF.C.delta.2''
                  ,''14040707'', ''14040707 R12.HR_PF.C.delta.1''
                  ,''10124646'', ''10124646 R12.HR_PF.C''
                                  ,''17050005'', ''17050005 R12.HR_PF.C.Delta.4''
                                  ,''17909898'', ''17909898 R12.HR_PF.C.delta.5''
                  ,''19193000'', ''19193000 R12.HR_PF.C.Delta.6''
                   ) RUP_LEVEL , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(SELECT to_char(max(to_number(adb.bug_number)))  FROM ad_bugs adb
WHERE adb.bug_number in (''19193000'',''17909898'',''17050005'',''17001123'',''16169935'',''14040707'',''10124646''))
and rownum < 2
union
select ''12.1'' release ,DECODE(BUG_NUMBER
                  ,''20000288'',''20000288 R12.HR_PF.B.delta.8''
                                  ,''18004477'', ''18004477 R12.HR_PF.B.delta.7''
                                  ,''16000686'', ''16000686 R12.HR_PF.B.delta.6''
                  , ''13418800'', ''13418800 R12.HR_PF.B.delta.5''
                  ,''10281212'', ''10281212 R12.HR_PF.B.delta.4''
                  ,''9114911'', ''9114911 R12.HR_PF.B.delta.3''
                  ,''8337373'', ''8337373 R12.HR_PF.B.delta.2''
                  ,''7446767'', ''7446767 R12.HR_PF.B.delta.1''
                  ,''6603330'', ''6603330 R12.HR_PF.B''
                   ) RUP_LEVEL
                , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''20000288'',''18004477'',''16000686'',''13418800'',''10281212'',''9114911'',''8337373'', ''7446767'', ''6603330''))
and rownum < 2
union
SELECT ''12.0'' release ,DECODE(BUG_NUMBER
                  , ''16077077'', ''16077077 R12.HR_PF.A.delta.11''
                  , ''13774477'', ''13774477 R12.HR_PF.A.delta.10''
                  , ''10281209'', ''10281209 R12.HR_PF.A.delta.9''
                  , ''9301208'', ''9301208 R12.HR_PF.A.delta.8''
                  , ''7577660'', ''7577660 R12.HR_PF.A.delta.7''
                  , ''7004477'', ''7004477 R12.HR_PF.A.delta.6''
                  , ''6610000'', ''6610000 R12.HR_PF.A.delta.5''
                  , ''6494646'', ''6494646 R12.HR_PF.A.delta.4''
                  , ''6196269'', ''6196269 R12.HR_PF.A.delta.3''
                  , ''5997278'', ''5997278 R12.HR_PF.A.delta.2''
                  , ''5881943'', ''5881943 R12.HR_PF.A.delta.1''
                  , ''4719824'', ''4719824 R12.HR_PF.A'') RUP_LEVEL
                  , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''16077077'',''13774477'',''10281209'',''9301208'',''7577660'', ''7004477'', ''6610000'', ''6494646'', ''6196269'', ''5997278'', ''5881943'', ''4719824''))
and rownum < 2
union
SELECT ''11.5'' release ,DECODE(BUG_NUMBER
                           , ''2803988'', ''2803988 HRMS_PF.E''
                           , ''2968701'', ''2968701 HRMS_PF.F''
                           , ''3116666'', ''3116666 HRMS_PF.G''
                           , ''3233333'', ''3233333 HRMS_PF.H''
                           , ''3127777'', ''3127777 HRMS_PF.I''
                           , ''3333633'', ''3333633 HRMS_PF.J''
                           , ''3500000'', ''3500000 HRMS_PF.K''
                           , ''5055050'', ''5055050 HR_PF.K.RUP.1''
                           , ''5337777'', ''5337777 HR_PF.K.RUP.2''
                           , ''6699770'', ''6699770 HR_PF.K.RUP.3''
                           , ''7666111'', ''7666111 HR_PF.K.RUP.4''
                           , ''9062727'', ''9062727 HR_PF.K.RUP.5''
                           , ''10015566'', ''10015566 HR_PF.K.RUP.6''
                           , ''12807777'', ''12807777 HR_PF.K.RUP.7''
                           , ''14488556'', ''14488556 HR_PF.K.RUP.8''
                                                   ,''17774746'', ''17774746 HR_PF.K.RUP.9''
                            ) RUP_LEVEL
                        , LAST_UPDATE_DATE
                          FROM ad_bugs
                          WHERE BUG_NUMBER = (select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''2803988'',''2968701'',''3116666'',''3233333'',''3127777'',''3333633'',''3500000'',''5055050'',''5337777'',''6699770'',''7666111'',''9062727'',''10015566'',''12807777'',''14488556'',''17774746''))
and rownum < 2
)
where release in (select substr(release_name,1,4) from fnd_product_groups)
',
      p_title                  => 'Instance Summary',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Instance Summary',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: OVERVIEWHCM');





debug('begin add_signature: Profiles_values');
  add_signature(
      p_sig_id                 => 'Profiles_values',
      p_sig_sql                => 'select decode(to_char(pov.level_id),''10001'', ''Site'',''10002'', ''Application'',''10003'', ''Responsibility'',''10005'', ''Server'',''10006'', ''Org'',''10007'', ''Servresp'',''10004'', ''User'', ''???'') "Level" ,
       decode(to_char(pov.level_id),''10001'', ''Site'',
              ''10002'', nvl(app.application_short_name,to_char(pov.level_value)),''10003'', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              ''10005'', svr.node_name,''10006'', org.name,''10007'', pov.level_value ||'', ''|| pov.level_value_application_id ||'', ''|| pov.level_value2,
              ''10004'', nvl(usr.user_name,to_char(pov.level_value)),''???'') "Context", pov.profile_option_value "Profile Value"
        from   fnd_profile_options po,fnd_profile_option_values pov,fnd_profile_options_tl n,
               fnd_user usr,fnd_application app,fnd_responsibility_vl rsp,fnd_nodes svr,hr_operating_units org
        where  po.profile_option_name =''##$$FK1$$##''
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
	and    n.language=''US''
        order by pov.level_id',
      p_title                  => 'Show values',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No value defined.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Profiles_values');

debug('begin add_signature: Profiles');
  add_signature(
      p_sig_id                 => 'Profiles',
      p_sig_sql                => 'select distinct po.profile_option_name "##$$FK1$$##",n.user_profile_option_name "Long Name",
      po.profile_option_name "Short Name"
          from   fnd_profile_options po,fnd_profile_option_values pov,fnd_profile_options_tl n
        where  po.profile_option_name in (
''PER_SECURITY_PROFILE_ID'',''PER_BUSINESS_GROUP_ID'',''HR_CROSS_BUSINESS_GROUP'',''HR_USER_TYPE'',
''ORG_ID'',''HR_LOCAL_OR_GLOBAL_NAME_FORMAT'',''PER_NATIONAL_IDENTIFIER_VALIDATION'',''PER_USE_TITLE_IN_FULL_NAME'',''PER_ENABLE_DTW4'',''DATETRACK:ENABLED'',
''HR_ALLOW_NEG_ABS_BAL'',''PER_ABSENCE_DURATION_AUTO_OVERWRITE'',''HR_VIEWS_LAYOUT_ABSENCE'',''HR_SCH_BASED_ABS_CALC'',''PER_GLOBAL_APL_NUM'',''PER_GLOBAL_CWK_NUM'',
''PER_GLOBAL_EMP_NUM'',''PER_EX_SECURITY_PROFILE'',''HR_CANCEL_APPLICATION'',''HR_PROPAGATE_DATA_CHANGES'',''HR_LOCAL_OR_GLOBAL_NAME_FORMAT'',''PAY_USE_FF_PTO'',
''HZ_DQM_ENABLED_FLAG'',''HZ_DQM_IGNORE_CONC_LIMITS'',''HZ_DQM_ENABLE_REALTIME_SYNC'',''AR_CHANGE_CUST_NAME'',''HR_APPRAISEE_ADD_PARTICIPANTS'',
''HR_WORKER_APPRAISALS_MENU'',''HR_MANAGER_APPRAISALS_MENU'',''HR_APPLY_COMPETENCIES_TO_PERSON'', ''HR_TALENT_MGMT_SRC_TYPE'',
''HR_SAVE_STAY_APPRAISALS_PAGE'',''HR_ALLOW_UPDATES_TO_OBJECTIVE_DETAILS_ADDED_BY_APPRAISEE'',''HR_TOTAL_COMP_OBJ_PRECESION'',
''HR_ALLOW_APPRAISALS_CROSS_BG'',''PER_WPM_APPRAISAL_UPDATE_AFTER_PERIOD'',''PER_VIEW_HISTORICAL_PLANS'',''HR_ENABLE_TALENT_PROFILE'',
''HR_SELF_SERVICE_HR_LICENSED'',''HR_SUCCESSION_MGMT_LICENSED'',''BEN_CWB_LICENSE_CHECK'',''OTA_ORACLE_ILEARNING_LICENSED'',''AME_INSTALLED_FLAG'',
''AME_INSTALLATION_LEVEL'',''HR_ABS_OTL_INTEGRATION'',''FND_EXTERNAL_ADF_URL'',''PQH_ALLOW_APPROVER_TO_EDIT_TXN'',''HR_EVAL_USER_ACCESS_MIN_CACHE'',
''HR_DEFER_UPDATE'',''HR_SUPERVISOR_HIERARCHY_USAGE'',''HR_VIEW_TERM_PEOPLE_INSRCH'',''ENABLE_SECURITY_GROUPS'') 
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
       	and    n.language=''US''',
      p_title                  => 'Profiles',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No profile defined',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('Profiles_values'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Profiles');



debug('begin add_signature: HRinvalidnew');
  add_signature(
      p_sig_id                 => 'HRinvalidnew',
      p_sig_sql                => 'select a.owner,a.object_name,b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (object_name like ''PER%'' or object_name like ''HR%'')   
    AND a.status = ''INVALID''
    and ROWNUM<2000
    order by a.object_name',
      p_title                  => 'HR/PER Invalid objects',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'HR/PER invalid objects found.',
      p_solution               => 'Advice: Please run adadmin -> Compile apps schema. If you still have invalids review steps from: [1325394.1] Troubleshooting Guide - invalid objects in the E-Business Suite Environment 11i and 12',
      p_success_msg            => 'No HR/PER invalid objects.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HRinvalidnew');



debug('begin add_signature: HRinvalidothers');
  add_signature(
      p_sig_id                 => 'HRinvalidothers',
      p_sig_sql                => 'select a.owner,a.object_name,b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND (object_name not like ''PER%'' and object_name not like ''HR%'')   
    AND a.status = ''INVALID''
    and ROWNUM<2000
    order by a.object_name',
      p_title                  => 'Other Invalid objects',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invalid objects identified.',
      p_solution               => 'Advice: Please run adadmin -> Compile apps schema. If you still have invalids review steps from: [1325394.1] Troubleshooting Guide - invalid objects in the E-Business Suite Environment 11i and 12',
      p_success_msg            => 'No invalid object.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HRinvalidothers');



debug('begin add_signature: HR_MANAGER_APPRAISALS_MENU 1');
  add_signature(
      p_sig_id                 => 'HR_MANAGER_APPRAISALS_MENU 1',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where  po.profile_option_name =''HR_MANAGER_APPRAISALS_MENU'' and pov.level_id=''10001'' and pov.profile_option_value is null
and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id',
      p_title                  => 'Profile HR_MANAGER_APPRAISALS_MENU null',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Profile "HR: Manager Appraisals Menu" is not set as Manager Appraisals Menu, this may case issues when working with custom responsibility/menu.',
      p_solution               => 'Review: [796769.1] Appraisal Not Being Created When Performance Management Plan Is Published',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_MANAGER_APPRAISALS_MENU 1');



debug('begin add_signature: HR_MANAGER_APPRAISALS_MENU 2');
  add_signature(
      p_sig_id                 => 'HR_MANAGER_APPRAISALS_MENU 2',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where  po.profile_option_name =''HR_MANAGER_APPRAISALS_MENU'' and pov.level_id=''10001'' 
and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id
',
      p_title                  => 'Profile HR_MANAGER_APPRAISALS_MENU null',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Profile "HR: Manager Appraisals Menu" is not set as Manager Appraisals Menu, this may case issues when working with custom responsibility/menu.',
      p_solution               => 'Review: [796769.1] Appraisal Not Being Created When Performance Management Plan Is Published',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_MANAGER_APPRAISALS_MENU 2');



debug('begin add_signature: HR_MANAGER_APPRAISALS_MENU 3');
  add_signature(
      p_sig_id                 => 'HR_MANAGER_APPRAISALS_MENU 3',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where  po.profile_option_name =''HR_MANAGER_APPRAISALS_MENU'' and pov.level_id=''10001'' and pov.profile_option_value <>''HR_MANAGER_APPRAISALS_MENU''
and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id
',
      p_title                  => 'Profile HR_MANAGER_APPRAISALS not set as Manager Appraisals Menu',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Profile "HR: Manager Appraisals Menu" is not set as Manager Appraisals Menu, Custom menu is set here, please make sure it follows the same structure of seeded menu. ',
      p_solution               => 'Review: [796769.1] Appraisal Not Being Created When Performance Management Plan Is Published',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_MANAGER_APPRAISALS_MENU 3');



debug('begin add_signature: Intermedia_all');
  add_signature(
      p_sig_id                 => 'Intermedia_all',
      p_sig_sql                => 'select index_name, status, domidx_status, domidx_opstatus
from dba_indexes
where index_name in (''HR_LOCATIONS_N1'', ''HR_LOCATIONS_SPT'',''IRC_DOCUMENTS_CTX'',
''IRC_DOCUMENTS_CTX1'', ''IRC_POSTING_CON_TL_CTX'', ''IRC_SEARCH_CRITERIA_CTX'',
''PER_ADDRESSES_N4'', ''PER_EMPDIR_PEOPLE_N1'', ''PER_ADDRESSES_SPT'')',
      p_title                  => 'Special / Intermedia indexes',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No special / intermedia indexes available',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Intermedia_all');



debug('begin add_signature: HR_WORKER_APPRAISALS_MENU');
  add_signature(
      p_sig_id                 => 'HR_WORKER_APPRAISALS_MENU',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where po.profile_option_name =''HR_WORKER_APPRAISALS_MENU'' and pov.level_id=''10001'' and pov.profile_option_value is null 
and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id ',
      p_title                  => 'Profile HR_WORKER_APPRAISALS_MENU null',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Profile "HR: Worker Appraisals Menu" is not set at Site level, this may case issues when working with custom responsibility/menu.',
      p_solution               => 'Review: [796769.1] Appraisal Not Being Created When Performance Management Plan Is Published',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_WORKER_APPRAISALS_MENU');



debug('begin add_signature: Invalid_intermedia');
  add_signature(
      p_sig_id                 => 'Invalid_intermedia',
      p_sig_sql                => 'select index_name, status, domidx_status, domidx_opstatus
from dba_indexes
where index_name in (''HR_LOCATIONS_N1'', ''HR_LOCATIONS_SPT'',''IRC_DOCUMENTS_CTX'',
''IRC_DOCUMENTS_CTX1'', ''IRC_POSTING_CON_TL_CTX'', ''IRC_SEARCH_CRITERIA_CTX'',
''PER_ADDRESSES_N4'', ''PER_EMPDIR_PEOPLE_N1'', ''PER_ADDRESSES_SPT'')
and (status!=''VALID'' or domidx_status!=''VALID'' or domidx_opstatus!=''VALID'')',
      p_title                  => 'Invalid Special / Intermedia Indexes',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invalid Special / Intermedia Indexes identified.',
      p_solution               => '<ul><li>Please rebuild these indexes.</li>
<li>For R12: 743720.1 Oracle Text: Re-installation and Rebuilding of Applications R12 Oracle Text Indexes</li>
<li>For 11i: 312640.1 Oracle Text: Re-installation of Applications 11i Oracle Text Indexes</li></ul>',
      p_success_msg            => 'No invalid intermedia index.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Invalid_intermedia');



debug('begin add_signature: HR_WORKER_APPRAISALS_MENU 2');
  add_signature(
      p_sig_id                 => 'HR_WORKER_APPRAISALS_MENU 2',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where po.profile_option_name =''HR_WORKER_APPRAISALS_MENU'' and pov.level_id=''10001''  
and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id 
',
      p_title                  => 'Profile HR_WORKER_APPRAISALS_MENU null',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Profile "HR: Worker Appraisals Menu" is not set at Site level, this may case issues when working with custom responsibility/menu.
',
      p_solution               => 'Review: [796769.1] Appraisal Not Being Created When Performance Management Plan Is Published',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_WORKER_APPRAISALS_MENU 2');



debug('begin add_signature: HR_WORKER_APPRAISALS_MENU 3');
  add_signature(
      p_sig_id                 => 'HR_WORKER_APPRAISALS_MENU 3',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where  po.profile_option_name =''HR_WORKER_APPRAISALS_MENU'' and pov.level_id=''10001'' and pov.profile_option_value <>''HR_EMPLOYEE_APPRAISALS_MENU'' and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id',
      p_title                  => 'Profile HR_WORKER_APPRAISALS_MENU ',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Profile "HR: Worker Appraisals Menu" is not set as Employee Appraisals Menu, Custom menu is set here, please make sure it follows the same structure of seeded menu.',
      p_solution               => 'Review: [796769.1] Appraisal Not Being Created When Performance Management Plan Is Published',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_WORKER_APPRAISALS_MENU 3');



debug('begin add_signature: ProfileFND_DISABLE_OA_CUSTOMIZATIONS');
  add_signature(
      p_sig_id                 => 'ProfileFND_DISABLE_OA_CUSTOMIZATIONS',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where  po.profile_option_name =''FND_DISABLE_OA_CUSTOMIZATIONS''   and pov.profile_option_value=''N''
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id',
      p_title                  => 'Profile FND_DISABLE_OA_CUSTOMIZATIONS',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Profile "Disable Self-Service Personal" is set to N at one/several levels, so personalization/OA page customization is used. This can cause issues in system behavior (caused by custom personalization). If you have issues in web pages, before raising an Service Request, please turn this profile to Y (to disable all personalizations) and retest. If the issue is not reproducible, then it is caused by customization.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ProfileFND_DISABLE_OA_CUSTOMIZATIONS');



debug('begin add_signature: ProfileFND_OA_ENABLE_DEFAULTS');
  add_signature(
      p_sig_id                 => 'ProfileFND_OA_ENABLE_DEFAULTS',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where  po.profile_option_name =''FND_OA_ENABLE_DEFAULTS''   and pov.profile_option_value=''N''
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id ',
      p_title                  => 'Profile FND_OA_ENABLE_DEFAULTS',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Profile "FND:OA:Enable Defaults" is set to N at one/several levels, so default values specified in personalizations and base meta data applied to your pages will not be displayed.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ProfileFND_OA_ENABLE_DEFAULTS');



debug('begin add_signature: Complete_defunct_HR');
  add_signature(
      p_sig_id                 => 'Complete_defunct_HR',
      p_sig_sql                => 'SELECT substr(UPPER(ARGUMENT_TEXT),1,3) "Schema", ACTUAL_COMPLETION_DATE "Complation Date", ARGUMENT_TEXT
	FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R, FND_LOOKUP_VALUES STAT, FND_LOOKUP_VALUES PHAS
	WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID
	AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID
	AND PT.LANGUAGE = ''US'' and
	STAT.LOOKUP_CODE = R.STATUS_CODE AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE'' AND PHAS.LOOKUP_CODE = R.PHASE_CODE
	AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE'' and PHAS.language=''US'' and STAT.language=''US'' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
	AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE ''COMPLETE DEFUNCT HR WORKFLOW%''
	and PHAS.MEANING=''Completed'' and STAT.MEANING=''Normal'' and ACTUAL_COMPLETION_DATE>sysdate-180
	ORDER BY 2 desc',
      p_title                  => 'Complete Defunct HR Workflow Processes',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Complete Defunct HR Workflow Processes not performed in last 6 months.',
      p_solution               => '',
      p_success_msg            => 'Complete Defunct HR Workflow Processes performed in last 6 months.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Complete_defunct_HR');



debug('begin add_signature: RESUME_NET');
  add_signature(
      p_sig_id                 => 'RESUME_NET',
      p_sig_sql                => 'select substr(''##$$RESUMENET$$##'',1,5) "Setup", ''##$$RESUMENET$$##'' "Results" from dual',
      p_title                  => 'Resume Parsing Network Test',
      p_fail_condition         => '[Setup] = [Error]',
      p_problem_descr          => 'You are not able to successfully communicate from the database to the resume parsing vendor. This is a strong indication that you will not be able to connect from the middle tier.',
      p_solution               => '',
      p_success_msg            => 'OK! You are able to successfully communicate from the database to the resume parsing vendor. This is a good indication, but not a guarantee, that you will be able to connect from the middle tier.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: RESUME_NET');



debug('begin add_signature: ELOCATION');
  add_signature(
      p_sig_id                 => 'ELOCATION',
      p_sig_sql                => 'select substr(''##$$ELOCATIONX$$##'',1,5) "Setup", ''##$$ELOCATIONY$$##'' "Latitude", ''##$$ELOCATIONX$$##'' "Longitude" from dual
',
      p_title                  => 'eLocation Test',
      p_fail_condition         => '[Setup] = [Error]',
      p_problem_descr          => 'You have not successfully communicated with the eLocation server. You will not be able to search by distance to location',
      p_solution               => '',
      p_success_msg            => 'OK! You have successfully communicated with the eLocation server.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ELOCATION');



debug('begin add_signature: Customization');
  add_signature(
      p_sig_id                 => 'Customization',
      p_sig_sql                => 'select jdr_mds_internal.getDocumentName(cl1.path_docid) docName,jda.att_value developerMode
from jdr_paths cl1
,    jdr_paths bm1
,    jdr_paths cl2
,    jdr_paths bm2
,    jdr_paths cl3
,    jdr_paths bm3
,    jdr_attributes jda,
(select path_docid from jdr_paths
  where ((path_type = ''DOCUMENT'' AND path_seq = -1) OR
    (path_type = ''PACKAGE'' AND path_seq = 0))
  start with path_owner_docid = jdr_mds_internal.getDocumentId(''/oracle/apps/per/irc'')
  connect by prior path_docid = path_owner_docid) docs
where cl1.path_name=bm1.path_name
and bm1.path_docid=docs.path_docid
and bm1.path_docid!=cl1.path_docid
and cl2.path_name=bm2.path_name
and cl1.path_owner_docid=cl2.path_docid
and bm1.path_owner_docid=bm2.path_docid
and cl2.path_name=bm2.path_name
and cl1.path_owner_docid=cl2.path_docid
and bm1.path_owner_docid=bm2.path_docid
and cl3.path_name=bm3.path_name
and cl2.path_owner_docid=cl3.path_docid
and bm2.path_owner_docid=bm3.path_docid
and jda.att_comp_docid=cl1.path_docid
and att_name=''developerMode''',
      p_title                  => 'Customizations',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Customization available in this instance.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Customization');



debug('begin add_signature: Database details');
  add_signature(
      p_sig_id                 => 'Database details',
      p_sig_sql                => 'select ''Hostname ='' || host_name
    FROM v$instance
union
SELECT  ''Platform ='' ||SUBSTR(REPLACE(REPLACE(pcv1.product, ''TNS for ''), '':'' )||pcv2.status, 1, 80)
    FROM product_component_version pcv1,
    product_component_version pcv2
    WHERE UPPER(pcv1.product) LIKE ''%TNS%''
    AND UPPER(pcv2.product) LIKE ''%ORACLE%''
    AND ROWNUM = 1
union
SELECT ''SID ='' ||instance_name from v$instance
union
SELECT ''Database version ='' ||banner from V$VERSION WHERE ROWNUM = 1
union
SELECT ''Language  =''||value FROM V$NLS_PARAMETERS WHERE parameter in (''NLS_LANGUAGE'',''NLS_CHARACTERSET'') 
union
SELECT ''Character set  =''||value FROM V$NLS_PARAMETERS WHERE parameter in (''NLS_LANGUAGE'',''NLS_CHARACTERSET'') ',
      p_title                  => 'Database details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Database settings',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Database details');



debug('begin add_signature: BACK_NET');
  add_signature(
      p_sig_id                 => 'BACK_NET',
      p_sig_sql                => 'select substr(''##$$BACKNET$$##'',1,5) "Setup", ''##$$BACKNET$$##'' "Results" from dual',
      p_title                  => 'Background Check Network Test',
      p_fail_condition         => '[Setup] = [Error]',
      p_problem_descr          => 'You are not able to successfully communicate from the database to the background check vendor. This is a strong indication that you will not be able to connect from the middle tier.',
      p_solution               => '',
      p_success_msg            => 'OK! You are able to successfully communicate from the database to the background check vendor. This is a good indication, but not a guarantee, that you will be able to connect from the middle tier. Also, if you are using the background check functionality be sure that this site can connect from all nodes (middle tiers and database).',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BACK_NET');



debug('begin add_signature: PER_Packages');
  add_signature(
      p_sig_id                 => 'PER_Packages',
      p_sig_sql                => 'SELECT name,decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) Type,
ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1)
               ))) Filename,
               ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 3) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2)
               ))) Version
				 FROM dba_source c
				 WHERE owner = ''APPS''
				 AND    name like ''PER%'' 
				AND   type in (''PACKAGE BODY'',''PACKAGE'')
				AND   line = 2
				AND   text like ''%$Header%''
				order by name',
      p_title                  => 'PER packages',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No package available',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PER_Packages');



debug('begin add_signature: NOTE1320920');
  add_signature(
      p_sig_id                 => 'NOTE1320920',
      p_sig_sql                => 'SELECT als.text
    FROM all_source als
    Where  
    FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                '' '',1,1)-1),''120.2.12010000.6'') = ''<''              
    And   Als.Type = ''PACKAGE BODY''
    And   Als.Name = ''HR_TERMINATION_SS''
    And   Als.Text Like ''%$Header%''',
      p_title                  => 'Patch for termination issue (when terminate the manager and direct reports on the same day)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: You can assign all Direct reports to the same new manager or make individual manager assignments below.',
      p_solution               => 'Follow [1320920.1] Not Able To Terminate The Manager And Direct Reports On The Same Day',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: NOTE1320920');



debug('begin add_signature: HR_Gather');
  add_signature(
      p_sig_id                 => 'HR_Gather',
      p_sig_sql                => 'SELECT substr(UPPER(ARGUMENT_TEXT),1,3) "Schema", ACTUAL_COMPLETION_DATE "Complation Date", ARGUMENT_TEXT
	FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R, FND_LOOKUP_VALUES STAT, FND_LOOKUP_VALUES PHAS
	WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID
	AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID
	AND PT.LANGUAGE = ''US'' and
	STAT.LOOKUP_CODE = R.STATUS_CODE AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE'' AND PHAS.LOOKUP_CODE = R.PHASE_CODE
	AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE'' and PHAS.language=''US'' and STAT.language=''US'' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
	AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE ''GATHER SCHEMA%''
	AND substr(UPPER(ARGUMENT_TEXT),1,3) in (''ALL'',''HR,'')
	and PHAS.MEANING=''Completed'' and STAT.MEANING=''Normal'' and ACTUAL_COMPLETION_DATE>sysdate-30
	ORDER BY 2 desc',
      p_title                  => 'Gather Schema Statistics',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Gather schema statistics never performed for ALL or HR in last month',
      p_solution               => 'In order to schedule use [419728.1] Concurrent Processing - How To Gather Statistics On Oracle Applications Release 11i and/or Release 12 - Concurrent Process,Temp Tables, Manually. Note! You can ignore the warning if you are manually gathering statistics using FND_STATS.GATHER_SCHEMA_STATS.',
      p_success_msg            => 'Gather statistics performed in last month.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_Gather');



debug('begin add_signature: ProfilePER_GLOBAL_EMP_NUM');
  add_signature(
      p_sig_id                 => 'ProfilePER_GLOBAL_EMP_NUM',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov   
where  po.profile_option_name =''PER_GLOBAL_EMP_NUM''  and  pov.profile_option_value=''Y'' 
and pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id',
      p_title                  => 'Global Numbering Profile',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'For Oracle Support: Profile "HR:Use Global Employee Numbering" is set to Yes. This note was followed: [259160.1] Step By Step Instructions For Implementing Global Sequencing. Once a customer implements Global Numbering, they cannot go backwards and revert back to Automatic or Manual Numbering via Business Group Info. They must continue to use Global Numbering. Global Numbering is a functionality which is supported by Oracle Human Resources support.',
      p_solution               => '',
      p_success_msg            => 'OK! Profile "HR:Use Global Employee Numbering" is set to No.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ProfilePER_GLOBAL_EMP_NUM');



debug('begin add_signature: Date_track_Shared');
  add_signature(
      p_sig_id                 => 'Date_track_Shared',
      p_sig_sql                => 'select 
    decode(to_char(fpov.level_id),
                  ''10001'', ''Site'',
                  ''10002'', ''Application'') ,
    fpo.APPLICATION_ID,
    fpov.LEVEL_VALUE,
     decode(to_char(fpov.level_id),
                  ''10001'', ''Site'',
                  ''10002'', nvl(app.application_short_name,to_char(fpov.level_value))),
    DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',
    DECODE(fpov.PROFILE_OPTION_VALUE,''N'',''No'',
    fpov.PROFILE_OPTION_VALUE)) 
    from FND_PROFILE_OPTIONS fpo,
    FND_PROFILE_OPTIONS_TL fpotl,
    FND_PROFILE_OPTION_VALUES fpov,
    FND_APPLICATION app
    where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME
    and    app.application_id (+) = fpov.level_value
    and fpo.PROFILE_OPTION_NAME like ''DATETRACK:ENABLED''
    and fpotl.PROFILE_OPTION_NAME like ''DATETRACK:ENABLED''
    and fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
    and fpotl.LANGUAGE = ''US''
    and fpov.PROFILE_OPTION_ID = 1208
    and fpov.LEVEL_ID IN (10001,10002)
    and   fpov.LEVEL_VALUE != ''804''',
      p_title                  => 'DateTrack:Enabled',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Incorrect profile value for DateTrack:Enabled for above levels.',
      p_solution               => '<ul><li>Please raise a service request with Oracle Support and refer to this section of output</li>
<li>Profiles ''DateTrack:Enabled'' and ''HR: Enable DTW4 defaulting'' are not allowed to be active in a shared HR installed environment.</li>
<li>These profiles are only allowed to be active and used within fully installed Oracle Human Resources environments.</li>
<li>Leaving these profiles Enabled can cause datetrack records to be created, which is data corruption in shared HR.</li>
<li>Please see the following note and correct the settings for these profiles.</li>
<li>[1075831.1] Within ''Shared HR'' Environments What Types of Records Would You Expect to See in HR tables ?</li>
<li>To correct profile ''DateTrack:Enabled''  run the following against each of your instances.</li>
<li>UPDATE FND_PROFILE_OPTION_VALUES</li>
<li>SET PROFILE_OPTION_VALUE = NULL</li>
<li>where APPLICATION_ID = 803</li>
<li>and PROFILE_OPTION_ID = 1208</li>
<li>and LEVEL_ID IN (10001,10002)</li>
<li>and LEVEL_VALUE IN (0,800,801,802,803,805,808,809,810,833,8301,8302,8303)</li>
<li>commit</li> </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Date_track_Shared');



debug('begin add_signature: DATABASE_INITIALIZATION_12');
  add_signature(
      p_sig_id                 => 'DATABASE_INITIALIZATION_12',
      p_sig_sql                => 'select name, nvl(value,''null'') "Value" from v$parameter order by name',
      p_title                  => 'Database Initialization Parameters',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Database Initialization Parameters',
      p_solution               => '',
      p_success_msg            => '<ul><li>If you have performance issue please ensure you have correct database initialization parameters as per [396009.1] Database Initialization Parameters for Oracle E-Business Suite Release 12</li>
<li>Use [174605.1] bde_chk_cbo.sql - EBS initialization parameters - Healthcheck</li>
<li>This will help you to identify the difference between actual values and required values. Verify that all Mandatory Parameters - MP are set correctly</li></ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DATABASE_INITIALIZATION_12');



debug('begin add_signature: Disabled_Triggers');
  add_signature(
      p_sig_id                 => 'Disabled_Triggers',
      p_sig_sql                => 'select owner, table_name, trigger_name
from dba_triggers
where status = ''DISABLED''
and table_owner in (''HR'',''HXT'',''HXC'',''HRI'',''BEN'')
and TRIGGER_NAME not like ''ALR%''
order by 1, 2, 3',
      p_title                  => 'Disabled Triggers',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You have disabled trigger(s).',
      p_solution               => 'In order to re-enable use command: alter trigger trigger_name enable',
      p_success_msg            => 'No disabled trigger.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Disabled_Triggers');



debug('begin add_signature: DATABASE_INITIALIZATION_11i');
  add_signature(
      p_sig_id                 => 'DATABASE_INITIALIZATION_11i',
      p_sig_sql                => 'select name, nvl(value,''null'') "Value" from v$parameter order by name',
      p_title                  => 'Database Initialization Parameters',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Database Initialization Parameters',
      p_solution               => '',
      p_success_msg            => '<ul><li>If you have performance issue please ensure you have correct database initialization parameters as per [216205.1] Database Initialization Parameters for Oracle E-Business Suite Release 11i</li>
<li>Use [174605.1] bde_chk_cbo.sql - EBS initialization parameters - Healthcheck</li>
<li>This will help you to identify the difference between actual values and required values. Verify that all Mandatory Parameters - MP are set correctly</li></ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DATABASE_INITIALIZATION_11i');





debug('begin add_signature: IRC Profiles Values');
  add_signature(
      p_sig_id                 => 'IRC Profiles Values',
      p_sig_sql                => 'select decode(to_char(pov.level_id),''10001'', ''Site'',''10002'', ''Application'',''10003'', ''Responsibility'',''10005'', ''Server'',''10006'', ''Org'',''10007'', ''Servresp'',''10004'', ''User'', ''???'') "Level" ,
       decode(to_char(pov.level_id),''10001'', ''Site'',
              ''10002'', nvl(app.application_short_name,to_char(pov.level_value)),''10003'', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              ''10005'', svr.node_name,''10006'', org.name,''10007'', pov.level_value ||'', ''|| pov.level_value_application_id ||'', ''|| pov.level_value2,
              ''10004'', nvl(usr.user_name,to_char(pov.level_value)),''???'') "Context", pov.profile_option_value "Profile Value"
        from   fnd_profile_options po,fnd_profile_option_values pov,fnd_profile_options_tl n,
               fnd_user usr,fnd_application app,fnd_responsibility_vl rsp,fnd_nodes svr,hr_operating_units org
        where  po.profile_option_name =''##$$FK2$$##''
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
	and    n.language=''US''
        order by pov.level_id',
      p_title                  => 'Show values',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No setting.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC Profiles Values');

debug('begin add_signature: IRC Profiles');
  add_signature(
      p_sig_id                 => 'IRC Profiles',
      p_sig_sql                => 'select distinct po.profile_option_name "##$$FK2$$##",n.user_profile_option_name "Long Name",
      po.profile_option_name "Short Name"
          from   fnd_profile_options po,fnd_profile_option_values pov,fnd_profile_options_tl n
        where po.profile_option_name like ''IRC%''
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
       	and    n.language=''US''',
      p_title                  => 'IRec Profiles',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No profile set',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('IRC Profiles Values'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC Profiles');



debug('begin add_signature: ProfileENABLE_SECURITY_GROUPS');
  add_signature(
      p_sig_id                 => 'ProfileENABLE_SECURITY_GROUPS',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
WHERE   po.profile_option_name = ''ENABLE_SECURITY_GROUPS''
         AND     po.application_id = 0
         AND     po.profile_option_id = pov.profile_option_id
         AND     po.application_id = pov.application_id
         AND     (pov.level_id = 10002  AND  hr_general.chk_application_id (pov.level_value) = ''TRUE'')
         AND     pov.profile_option_value = ''Y''',
      p_title                  => 'Multiple Security Group',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Multiple Security Group is enabled.',
      p_solution               => '',
      p_success_msg            => 'Multiple Security Group is NOT enabled.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ProfileENABLE_SECURITY_GROUPS');



debug('begin add_signature: AR_CHANGE_CUST_NAME');
  add_signature(
      p_sig_id                 => 'AR_CHANGE_CUST_NAME',
      p_sig_sql                => 'select  po.profile_option_name "Profile", 
decode(pov.level_id, 10001, ''Site'',
        10002, ''Application'',
        10003, ''Responsibility'',
        10004, ''User'') "Level",
pov.profile_option_value "Value" from   fnd_profile_options po,  fnd_profile_option_values pov
where  po.profile_option_name =''AR_CHANGE_CUST_NAME''  and pov.level_id = 10001 and (pov.profile_option_value is null or pov.profile_option_value=''N'') and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id',
      p_title                  => 'Profile AR_CHANGE_CUST_NAME',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Profile "HZ: Change Party Name" shoud be set to Yes at Site level.',
      p_solution               => 'Review [732008.1] Modify Employee Information and Receive Error APP-PER_289974',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AR_CHANGE_CUST_NAME');



debug('begin add_signature: VO substitutions');
  add_signature(
      p_sig_id                 => 'VO substitutions',
      p_sig_sql                => 'select COMP_SEQ,COMP_LEVEL,COMP_GROUPING,COMP_ELEMENT  from JDR_COMPONENTS where comp_element = ''replace'' and COMP_DOCID in (select path_docid from jdr_paths
  where ((path_type = ''DOCUMENT'' AND path_seq = -1) OR
    (path_type = ''PACKAGE'' AND path_seq = 0))
  start with path_owner_docid = jdr_mds_internal.getDocumentId(''/oracle/apps/per/irc'')
  connect by prior path_docid = path_owner_docid)',
      p_title                  => 'VO substitutions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'VO substitutions available in this instance',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: VO substitutions');



debug('begin add_signature: NOTE1402698');
  add_signature(
      p_sig_id                 => 'NOTE1402698',
      p_sig_sql                => 'SELECT als.text "Incorrect Version"
    FROM all_source als
    Where  
    ((''12.0'' = substr(''##$$REL$$##'',1,4) AND
            FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                '' '',1,1)-1),''120.11.12000000.13'') = ''<'' ) 
              Or
           (''12.1'' = substr(''##$$REL$$##'',1,4) AND
            FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, instr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                '' '',1,1)-1),''120.20.12010000.13'') = ''<'' ))   
    And   Als.Type = ''PACKAGE BODY''
    And   Als.Name = ''HR_ASSIGNMENT_API''
    And   Als.Text Like ''%$Header%''',
      p_title                  => 'Patch for termination issue (APP-PER-449043)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: APP-PER-449043: You can set the projected assignment end date for contingent worker assignment only. It cannot be earlier than the assignment start date.',
      p_solution               => 'Review Note 1402698.1 APP-PER-449043 You can set the projected assignment end date for contingent worker assignment only. It cannot be earlier than the assignment start date.',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: NOTE1402698');



debug('begin add_signature: HR_Packages');
  add_signature(
      p_sig_id                 => 'HR_Packages',
      p_sig_sql                => 'SELECT name,decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) Type,
ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1)
               ))) Filename,
               ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 3) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2)
               ))) Version
				 FROM dba_source c
				 WHERE owner = ''APPS''
				 AND    name like ''HR%'' 
				AND   type in (''PACKAGE BODY'',''PACKAGE'')
				AND   line = 2
				AND   text like ''%$Header%''
				order by name',
      p_title                  => 'HR packages',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No package available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_Packages');



debug('begin add_signature: PER_ENABLE_DTW4');
  add_signature(
      p_sig_id                 => 'PER_ENABLE_DTW4',
      p_sig_sql                => 'select 
    decode(to_char(fpov.level_id),
                  ''10001'', ''Site'',
                  ''10002'', ''Application'') ,
    fpo.APPLICATION_ID ,
    fpov.LEVEL_VALUE,
     decode(to_char(fpov.level_id),
                  ''10001'', ''Site'',
                  ''10002'', nvl(app.application_short_name,to_char(fpov.level_value))),
    DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',
    DECODE(fpov.PROFILE_OPTION_VALUE,''N'',''No'',
    fpov.PROFILE_OPTION_VALUE)) 
    from FND_PROFILE_OPTIONS fpo,
    FND_PROFILE_OPTIONS_TL fpotl,
    FND_PROFILE_OPTION_VALUES fpov,
    FND_APPLICATION app
    where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
    and    app.application_id (+) = fpov.level_value
    and   fpotl.PROFILE_OPTION_NAME = ''PER_ENABLE_DTW4'' 
    and   fpo.PROFILE_OPTION_NAME = ''PER_ENABLE_DTW4''
    and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
    and   fpov.LEVEL_ID IN (10001,10002) 
    and   fpotl.LANGUAGE = ''US'' 
    and   fpo.APPLICATION_ID = 800',
      p_title                  => 'HR: Enable DTW4 defaulting',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Incorrect profile value for HR: Enable DTW4 defaulting for above levels.',
      p_solution               => '<ul><li>Please raise a service request with Oracle Support and refer to this section of output</li>
<li>Profiles ''DateTrack:Enabled'' and ''HR: Enable DTW4 defaulting'' are not allowed to be active in a shared HR installed environment.</li>
<li>These profiles are only allowed to be active and used within fully installed Oracle Human Resources environments.</li>
<li>Leaving these profiles Enabled can cause datetrack records to be created, which is data corruption in shared HR.</li>
<li>Please see the following note and correct the settings for these profiles.</li>
<li>[1075831.1] Within ''Shared HR'' Environments What Types of Records Would You Expect to See in HR tables ?</li>
<li>To correct profile ''HR: Enable DTW4 defaulting'' perform the following against each of your instances.</li>
<li>navigate to </li>
<li>System Administrator responsibility ></li>
<li>Profile ></li>
<li> System ></li>
<li>query for the profile and set it to  ''No''  at Site  level > </li>
<li>Save</li> </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PER_ENABLE_DTW4');



debug('begin add_signature: HRglobal');
  add_signature(
      p_sig_id                 => 'HRglobal',
      p_sig_sql                => 'SELECT to_char(pr.end_date,''DD-MON-YY HH24:MI:SS'' ) "Date" , pr.PATCH_ACTION_OPTIONS FROM ad_patch_runs pr
 WHERE pr.PATCH_TOP LIKE (SELECT 
(CASE
WHEN RELEASE_NAME like ''12%'' THEN ''%/per/12.0.0/patch/115/driver''
WHEN RELEASE_NAME like ''11.5%'' THEN ''%/per/11.5.0/patch/115/driver''
else ''none''
end) patch
from FND_PRODUCT_GROUPS)
AND pr.SUCCESS_FLAG = ''Y''
AND pr.end_date =(
 SELECT MAX(pr.end_date)
 FROM ad_patch_runs pr
  WHERE pr.PATCH_TOP LIKE (SELECT 
(CASE
WHEN RELEASE_NAME like ''12%'' THEN ''%/per/12.0.0/patch/115/driver''
WHEN RELEASE_NAME like ''11.5%'' THEN ''%/per/11.5.0/patch/115/driver''
else ''none''
end) patch
from FND_PRODUCT_GROUPS)
AND pr.SUCCESS_FLAG = ''Y'')',
      p_title                  => 'Last successful run of hrglobal.drv',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No successful run of hrglobal.drv',
      p_solution               => '',
      p_success_msg            => 'If you need hrglobal.drv version then run the following command in database server: strings -a $PER_TOP/patch/115/driver/hrglobal.drv | grep Header',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HRglobal');



debug('begin add_signature: OVN_Triggers');
  add_signature(
      p_sig_id                 => 'OVN_Triggers',
      p_sig_sql                => 'select TABLE_NAME,TRIGGER_NAME,STATUS from all_triggers where OWNER like ''APPS%''
and (trigger_name like ''HR%OVN%'' or trigger_name like ''PER%OVN%'') order by owner, table_name',
      p_title                  => 'OVN Triggers',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No OVN triggers identified.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OVN_Triggers');





debug('begin add_signature: Workflow_errors_details');
  add_signature(
      p_sig_id                 => 'Workflow_errors_details',
      p_sig_sql                => 'select p.activity_name, substr(s.error_message,1,200) "Error", count(s.ITEM_KEY) "Count (ITEM_KEY)"
FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
WHERE p.instance_id = s.process_activity
and wi.item_type = s.item_type
and wi.item_key = s.item_key
and activity_status = ''ERROR''
AND p.PROCESS_ITEM_TYPE  =''##$$FK3$$##''
group by p.activity_name, substr(s.error_message,1,200)',
      p_title                  => 'Show values',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No row.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Workflow_errors_details');

debug('begin add_signature: Workflow_errors');
  add_signature(
      p_sig_id                 => 'Workflow_errors',
      p_sig_sql                => 'select distinct p.process_item_type "##$$FK3$$##", p.process_item_type
FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
WHERE p.instance_id = s.process_activity
and wi.item_type = s.item_type
and wi.item_key = s.item_key
and activity_status = ''ERROR''
AND p.PROCESS_ITEM_TYPE in  (''BENCWBFY'', ''SSBEN'', ''GHR_SF52'', ''HXCEMP'', ''HXCSAW'', ''IRC_NTF'', ''IRCOFFER'', ''IRC_WF'',''IRC_REG'',''OTWF'', ''HRCKLTSK'', ''HRSSA'', ''HRSFL'',''HRWPM'', ''HRRIRPRC'', ''PSPERAVL'')
order by p.process_item_type',
      p_title                  => 'Workflows with errors',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Workflows with errors identified.',
      p_solution               => '<ul><li>Please review the table and run the wfstat.sql command to take details.</li>
<li>1. Go to script directory: $FND_TOP/sql</li>
<li>2. Connect to sqlplus: sqlplus apps/apps_password</li>
<li>3. Spool the upcoming output to your $HOME directory: SQL> spool $HOME/wf_oracle_stat.txt</li>
<li>4. Execute wfstat.sql as adviced in the table: SQL> @wfstat.sql ITEM_TYPE ITEM_KEY</li>
<li>5. Turn spool off: SQL> spool off</li></ul>',
      p_success_msg            => 'No workflow in error.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('Workflow_errors_details'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Workflow_errors');



debug('begin add_signature: Application Details');
  add_signature(
      p_sig_id                 => 'Application Details',
      p_sig_sql                => 'select ''Instance Name          = ''|| upper(instance_name) "Instance Summary" from v$instance
                                union
                                select ''Applications           = ''|| release_name from fnd_product_groups
                                union
                                select ''Instance Creation Date = '' || created from v$database
                                union
                                SELECT ''Product status: PER/HR = '' || L.MEANING
                  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
                  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
                                AND (b.APPLICATION_ID = ''800'')
                                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
                                AND (L.LOOKUP_CODE = I.Status)
                                AND t.language = ''US''    AND l.language = ''US''
                                union
                  SELECT ''Product status: PAY    = '' || L.MEANING
                  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
                  WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
                    AND b.application_id = t.application_id
                                AND (b.APPLICATION_ID = ''801'')
                                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
                                AND (L.LOOKUP_CODE = I.Status)
                                AND t.language = ''US''    AND l.language = ''US''                              
                    union
                                SELECT ''Multi Org              = '' || MULTI_ORG_FLAG FROM FND_PRODUCT_GROUPS
                                union
                  SELECT ''Multi Currency         = '' || MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS
                  union
                  SELECT ''RUP Level              = ''|| RUP_LEVEL || '' applied on '' || LAST_UPDATE_DATE from
(select ''12.2'' release , DECODE(bug_number
                  ,''17001123'', ''17001123 R12.HR_PF.C.delta.3''
                  , ''16169935'', ''16169935 R12.HR_PF.C.delta.2''
                  ,''14040707'', ''14040707 R12.HR_PF.C.delta.1''
                  ,''10124646'', ''10124646 R12.HR_PF.C''
                                  ,''17050005'', ''17050005 R12.HR_PF.C.Delta.4''
                                  ,''17909898'', ''17909898 R12.HR_PF.C.delta.5''
                  ,''19193000'', ''19193000 R12.HR_PF.C.Delta.6''
                   ) RUP_LEVEL , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(SELECT to_char(max(to_number(adb.bug_number)))  FROM ad_bugs adb
WHERE adb.bug_number in (''19193000'',''17909898'',''17050005'',''17001123'',''16169935'',''14040707'',''10124646''))
and rownum < 2
union
select ''12.1'' release ,DECODE(BUG_NUMBER
                  ,''20000288'',''20000288 R12.HR_PF.B.delta.8''
                                  ,''18004477'', ''18004477 R12.HR_PF.B.delta.7''
                                  ,''16000686'', ''16000686 R12.HR_PF.B.delta.6''
                  , ''13418800'', ''13418800 R12.HR_PF.B.delta.5''
                  ,''10281212'', ''10281212 R12.HR_PF.B.delta.4''
                  ,''9114911'', ''9114911 R12.HR_PF.B.delta.3''
                  ,''8337373'', ''8337373 R12.HR_PF.B.delta.2''
                  ,''7446767'', ''7446767 R12.HR_PF.B.delta.1''
                  ,''6603330'', ''6603330 R12.HR_PF.B''
                   ) RUP_LEVEL
                , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''20000288'',''18004477'',''16000686'',''13418800'',''10281212'',''9114911'',''8337373'', ''7446767'', ''6603330''))
and rownum < 2
union
SELECT ''12.0'' release ,DECODE(BUG_NUMBER
                  , ''16077077'', ''16077077 R12.HR_PF.A.delta.11''
                  , ''13774477'', ''13774477 R12.HR_PF.A.delta.10''
                  , ''10281209'', ''10281209 R12.HR_PF.A.delta.9''
                  , ''9301208'', ''9301208 R12.HR_PF.A.delta.8''
                  , ''7577660'', ''7577660 R12.HR_PF.A.delta.7''
                  , ''7004477'', ''7004477 R12.HR_PF.A.delta.6''
                  , ''6610000'', ''6610000 R12.HR_PF.A.delta.5''
                  , ''6494646'', ''6494646 R12.HR_PF.A.delta.4''
                  , ''6196269'', ''6196269 R12.HR_PF.A.delta.3''
                  , ''5997278'', ''5997278 R12.HR_PF.A.delta.2''
                  , ''5881943'', ''5881943 R12.HR_PF.A.delta.1''
                  , ''4719824'', ''4719824 R12.HR_PF.A'') RUP_LEVEL
                  , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''16077077'',''13774477'',''10281209'',''9301208'',''7577660'', ''7004477'', ''6610000'', ''6494646'', ''6196269'', ''5997278'', ''5881943'', ''4719824''))
and rownum < 2
union
SELECT ''11.5'' release ,DECODE(BUG_NUMBER
                           , ''2803988'', ''2803988 HRMS_PF.E''
                           , ''2968701'', ''2968701 HRMS_PF.F''
                           , ''3116666'', ''3116666 HRMS_PF.G''
                           , ''3233333'', ''3233333 HRMS_PF.H''
                           , ''3127777'', ''3127777 HRMS_PF.I''
                           , ''3333633'', ''3333633 HRMS_PF.J''
                           , ''3500000'', ''3500000 HRMS_PF.K''
                           , ''5055050'', ''5055050 HR_PF.K.RUP.1''
                           , ''5337777'', ''5337777 HR_PF.K.RUP.2''
                           , ''6699770'', ''6699770 HR_PF.K.RUP.3''
                           , ''7666111'', ''7666111 HR_PF.K.RUP.4''
                           , ''9062727'', ''9062727 HR_PF.K.RUP.5''
                           , ''10015566'', ''10015566 HR_PF.K.RUP.6''
                           , ''12807777'', ''12807777 HR_PF.K.RUP.7''
                           , ''14488556'', ''14488556 HR_PF.K.RUP.8''
                                                   ,''17774746'', ''17774746 HR_PF.K.RUP.9''
                            ) RUP_LEVEL
                        , LAST_UPDATE_DATE
                          FROM ad_bugs
                          WHERE BUG_NUMBER = (select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''2803988'',''2968701'',''3116666'',''3233333'',''3127777'',''3333633'',''3500000'',''5055050'',''5337777'',''6699770'',''7666111'',''9062727'',''10015566'',''12807777'',''14488556'',''17774746''))
and rownum < 2
)
where release in (select substr(release_name,1,4) from fnd_product_groups)
',
      p_title                  => 'Application details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No information available',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Application Details');



debug('begin add_signature: OAFrameworkforHCM');
  add_signature(
      p_sig_id                 => 'OAFrameworkforHCM',
      p_sig_sql                => ' SELECT OA_Framework || '' applied on '' || LAST_UPDATE_DATE "Version" from
(select ''12.2'' release , decode(bug_number,''10110982'',''OA Framework 12.2'',''14222219'',''OA Framework 12.2.1'',''15890638'',''OA Framework 12.2.2'' ,''17007206'',''OA Framework 12.2.3'',''17909318'',''OA Framework 12.2.4'',''OA Framework 12.2'') OA_Framework , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(SELECT to_char(max(to_number(adb.bug_number)))  FROM ad_bugs adb
WHERE adb.bug_number in (''10110982'', ''14222219'',''15890638'', ''17007206'', ''17909318''))
and rownum < 2
union
select ''12.1'' release ,DECODE(BUG_NUMBER
                  ,''17774755'',''OA Framework 12.1.3.2 RPC1'',''15880118'',''OA Framework 12.1.3.2'',''11894708'',''OA Framework 12.1.3.1'' ,''9239090'',''OA Framework 12.1.3'',''8919491'',''OA Framework 12.1.3'') OA_Framework
                , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''17774755'',''15880118'',''11894708'',''9239090'',''8919491''))
and rownum < 2
union
SELECT ''12.0'' release ,DECODE(BUG_NUMBER
                  , ''6728000'',''OA Framework 12.0.6'',''6435000'',''OA Framework 12.0.4'',''6141000'',''OA Framework 12.0.3'' ,''5484000'',''OA Framework 12.0.2'',''5082400'',''OA Framework 12.0.1'') OA_Framework, LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''5082400'', ''5484000'' ,''6141000'',''6435000'',''6728000''))
and rownum < 2
union
SELECT ''11.5'' release ,DECODE(BUG_NUMBER,''2085104'',''OA Framework 5.5.2C'',''2227335'',''OA Framework 5.5.2E'',''2278688'',''OA Framework 5.6.0E'' ,''2771817'',''OA Framework 5.7.0H'',''3875569'',''OA Framework 11.5.10'',
			 ''4017300'', ''OA Framework 11.5.10 ATG_PF.H RUP1'',
			 ''4125550'', ''OA Framework 11.5.10 ATG_PF.H RUP2'',
			 ''4334965'', ''OA Framework 11.5.10 ATG_PF.H RUP3'',
			 ''4676589'', ''OA Framework 11.5.10 ATG_PF.H RUP4'',
			 ''5473858'', ''OA Framework 11.5.10 ATG_PF.H RUP5'',
			 ''5903765'', ''OA Framework 11.5.10 ATG_PF.H RUP6'',
			 ''6241631'', ''OA Framework 11.5.10 ATG_PF.H RUP7'') OA_Framework, LAST_UPDATE_DATE
                          FROM ad_bugs
                          WHERE BUG_NUMBER = (select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''2085104'',''2227335'',''2278688'',''2771817'',''3061106'',''3875569'',''4017300'', ''4125550'',''4334965'', ''4676589'',''5473858'',''5903765'',''6241631''))
and rownum < 2
)
where release in (select substr(release_name,1,4) from fnd_product_groups)
',
      p_title                  => 'OA Framework',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Unknown level.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OAFrameworkforHCM');



debug('begin add_signature: Business Group');
  add_signature(
      p_sig_id                 => 'Business Group',
      p_sig_sql                => 'SELECT o.business_group_id BG_ID,otl.name ORG_Name,o.organization_id ORG_ID,o3.ORG_INFORMATION9 Legislation_code
,hr_general_utilities.get_lookup_meaning(''EMP_NUM_GEN_METHOD'',o3.org_information2) Empl_numb_gen
,hr_general_utilities.get_lookup_meaning(''APL_NUM_GEN_METHOD'',o3.org_information3) Appl_numb_gen
,hr_general_utilities.get_lookup_meaning(''CWK_NUM_GEN_METHOD'',o3.org_information16) Contingent_numb_gen
,o3.ORG_INFORMATION10 currency,o4.ORG_INFORMATION2 Enabled ,to_char(o.date_from , ''DD-MON-YYYY'') Date_from,to_char(o.date_to, ''DD-MON-YYYY'') Date_to
FROM HR_ALL_ORGANIZATION_UNITS O , 
HR_ALL_ORGANIZATION_UNITS_TL OTL , 
HR_ORGANIZATION_INFORMATION O2 ,
HR_ORGANIZATION_INFORMATION O3 , 
HR_ORGANIZATION_INFORMATION O4
WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID
AND O3.ORG_INFORMATION_CONTEXT = ''Business Group Information'' 
AND O2.ORG_INFORMATION_CONTEXT (+) = ''Work Day Information'' 
AND O4.ORG_INFORMATION_CONTEXT = ''CLASS'' 
AND O4.ORG_INFORMATION1 = ''HR_BG'' AND O4.ORG_INFORMATION2 = ''Y'' 
AND OTL.LANGUAGE = ''US''
ORDER BY   1


',
      p_title                  => 'Business Group Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Business Groups defined.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: Business Group');



debug('begin add_signature: OVN_triggers_disabled');
  add_signature(
      p_sig_id                 => 'OVN_triggers_disabled',
      p_sig_sql                => 'select TABLE_NAME,TRIGGER_NAME,STATUS from all_triggers where OWNER like ''APPS%''
and (trigger_name like ''HR%OVN%'' or trigger_name like ''PER%OVN%'') 
and STATUS <> ''ENABLED''
order by owner, table_name',
      p_title                  => 'Disabled OVN triggers',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Disabled OVN triggers identified',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OVN_triggers_disabled');



debug('begin add_signature: PRODUCTS_INSTALL');
  add_signature(
      p_sig_id                 => 'PRODUCTS_INSTALL',
      p_sig_sql                => 'select t.application_name application, b.application_short_name "Short Name"
		  , to_char(t.application_id) "Application ID"
		  , l.meaning Status
		  , decode(i.patch_level, null, ''11i.'' || b.application_short_name || ''.?'', i.patch_level) "Patch Level"
		  from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
		  where (t.application_id = i.application_id)
		  AND b.application_id = t.application_id
		  and (b.application_id in (''0'', ''50'', ''101'',''178'', ''203'', ''231'', ''275'', ''426'', ''453'', ''800'', ''801'',
			  ''802'', ''803'', ''804'', ''805'', ''808'', ''809'', ''810'', ''821'', ''8301'', ''8302'', ''8303'',''8401'',''8403''))
		  and (l.lookup_type = ''FND_PRODUCT_STATUS'')
		  and (l.lookup_code = i.status )
		  AND t.language = ''US'' AND l.language = ''US'' order by upper(t.application_name)',
      p_title                  => 'Products Install Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No product installed.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PRODUCTS_INSTALL');



debug('begin add_signature: Currency_not_USD');
  add_signature(
      p_sig_id                 => 'Currency_not_USD',
      p_sig_sql                => 'select o3.ORG_INFORMATION10 currency
            FROM HR_ALL_ORGANIZATION_UNITS O , 
				HR_ALL_ORGANIZATION_UNITS_TL OTL , 
				HR_ORGANIZATION_INFORMATION O2 ,
				HR_ORGANIZATION_INFORMATION O3 , 
				HR_ORGANIZATION_INFORMATION O4 
				WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
				AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
				AND O3.ORG_INFORMATION_CONTEXT = ''Business Group Information'' 
				AND O2.ORG_INFORMATION_CONTEXT (+) = ''Work Day Information'' 
				AND O4.ORG_INFORMATION_CONTEXT = ''CLASS'' 
				AND O4.ORG_INFORMATION1 = ''HR_BG'' AND O4.ORG_INFORMATION2 = ''Y'' 
				AND OTL.LANGUAGE = ''US''
				and O.ORGANIZATION_ID=0',
      p_title                  => 'Currency of the Setup Business Group',
      p_fail_condition         => '[currency]<>[USD]',
      p_problem_descr          => 'Current currency is not USD. Changing the Currency of the Setup Business Group is never allowed under any condition!',
      p_solution               => '<ul><li>Please raise a service request with Oracle Support and refer to this section of output.</li>
<li>Please review: [815934.1] After Upgrade - Setup Business Group Name Reverts Back To Setup Business Group</li>
<li>[796593.1]Can the Setup Business Group name be Changed? </li>
</ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Currency_not_USD');



debug('begin add_signature: IRC_package');
  add_signature(
      p_sig_id                 => 'IRC_package',
      p_sig_sql                => 'SELECT name,decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) Type,
ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1)
               ))) Filename,
               ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 3) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2)
               ))) Version
				 FROM dba_source c
				 WHERE owner = ''APPS''
				 AND    name like ''IRC%'' 
				AND   type in (''PACKAGE BODY'',''PACKAGE'')
				AND   line = 2
				AND   text like ''%$Header%''
				order by name',
      p_title                  => 'IRC packages',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No package available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_package');



debug('begin add_signature: NOTE1402798');
  add_signature(
      p_sig_id                 => 'NOTE1402798',
      p_sig_sql                => 'SELECT Adf.Filename||'' ''|| Adfv.Version "Incorrect version"
    FROM Ad_Files Adf, Ad_File_Versions Adfv
    Where  
    Adf.File_Id = Adfv.File_Id
and FND_IREP_LOADER_PRIVATE.compare_versions(
Adfv.Version,''120.0.12010000.3'') = ''<''
And Adf.App_Short_Name = ''PER''
And Adf.Filename like  ''EmpRevTermReviewVOImpl.class''
And Adfv.File_Version_Id = (Select Max(adfv2.File_Version_Id) from ad_file_versions adfv2 where Adf.File_Id = Adfv2.File_Id)',
      p_title                  => 'Patch for termination issue (when reversing a termination which has comments)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: oracle.apps.fnd.framework.OAException: java.sql.SQLDataException: ORA-01858: a non-numeric character was found where a numeric was expected ORA-06512: at line 1',
      p_solution               => 'Review [1402798.1] Reverse Termination Error ORA-01858 a non-numeric character was found where a numeric was expected',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: NOTE1402798');



debug('begin add_signature: IRC_Proxy');
  add_signature(
      p_sig_id                 => 'IRC_Proxy',
      p_sig_sql                => 'select ''WEB_PROXY_HOST: ''|| nvl(rtrim(fnd_profile.value(''WEB_PROXY_HOST'')),''Null value'') "Settings" from dual
union
select ''WEB_PROXY_PORT: ''|| nvl(rtrim(fnd_profile.value(''WEB_PROXY_PORT'')),''Null value'') from dual
union
select ''WEB_PROXY_BYPASS_DOMAINS: ''|| nvl(rtrim(fnd_profile.value(''WEB_PROXY_BYPASS_DOMAINS'')),''Null value'') from dual
union
select ''APPS_FRAMEWORK_AGENT: ''|| nvl(rtrim(fnd_profile.value(''APPS_FRAMEWORK_AGENT'')),''Null value'') from dual
',
      p_title                  => 'Proxy Profile Option Analysis',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No settings.',
      p_solution               => '',
      p_success_msg            => 'Advice: If using a proxy server, be sure all of these 3 system profiles (WEB_PROXY_HOST, WEB_PROXY_PORT, WEB_PROXY_BYPASS_DOMAINS) are setup correctly. The WEB_PROXY_BYPASS_DOMAINS to define the proxy exclusion list must be in the following format *.mydomain1.com;*.mydomain2.com (Note the * asterisk in front and ; semi colon as the separator).',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_Proxy');



debug('begin add_signature: OTA_packages');
  add_signature(
      p_sig_id                 => 'OTA_packages',
      p_sig_sql                => 'SELECT name,decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) Type,
ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1)
               ))) Filename,
               ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 3) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2)
               ))) Version
				 FROM dba_source c
				 WHERE owner = ''APPS''
				 AND    name like ''OTA%'' 
				AND   type in (''PACKAGE BODY'',''PACKAGE'')
				AND   line = 2
				AND   text like ''%$Header%''
				order by name',
      p_title                  => 'OTA packages',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No package available',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OTA_packages');



debug('begin add_signature: Legislations');
  add_signature(
      p_sig_id                 => 'Legislations',
      p_sig_sql                => 'select decode(legislation_code,null,''global'',legislation_code) "Legislation code"
, decode(application_short_name
, ''PER'', ''Human Resources''
, ''PAY'', ''Payroll''
, ''GHR'', ''Federal Human Resources''
, ''CM'', ''College Data''
, application_short_name) "Application"
, application_short_name "Application Short Name"
,decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'') "Action"
, to_char(last_update_date,''DD-MON-YY HH24:MI:SS'' ) "Last update"
from hr_legislation_installations
where status = ''I''
order by legislation_code',
      p_title                  => 'Legislations installed',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Legislations installed.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: Legislations');



debug('begin add_signature: NOTE1421727');
  add_signature(
      p_sig_id                 => 'NOTE1421727',
      p_sig_sql                => 'SELECT als.text "Incorrect Version"
    FROM all_source als
    Where  
    FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                '' '',1,1)-1),''120.17.12010000.24'') = ''<''              
    And   Als.Type = ''PACKAGE BODY''
    And   Als.Name = ''HR_UTIL_MISC_SS''
    And   Als.Text Like ''%$Header%''',
      p_title                  => 'Patch for termination issue (when attempting to terminate a secondary assignment the acting Manager)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: The selected action is not available as you do not have access to the primary assignment of this person',
      p_solution               => 'Review [1421727.1] Secondary Assignment Termination Errors: The selected action is not available as you do not have access to the primary assignment of this person',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: NOTE1421727');



debug('begin add_signature: WHO_triggers');
  add_signature(
      p_sig_id                 => 'WHO_triggers',
      p_sig_sql                => 'select TABLE_NAME,TRIGGER_NAME,STATUS from all_triggers where UPPER(table_name) in
( ''PER_ALL_PEOPLE_F'', ''PER_ALL_ASSIGNMENTS_F'', ''PER_PERIODS_OF_SERVICE'', ''PER_PERSON_TYPE_USAGES_F'', ''PER_ADDRESSES''
, ''HR_LOCATIONS_ALL'', ''HR_LOCATIONS_ALL_TL'', ''HR_ALL_ORGANIZATION_UNITS'', ''HR_ALL_ORGANIZATION_UNITS_TL'', ''HR_ALL_POSITIONS_F''
, ''HR_ALL_POSITIONS_F_TL'', ''PER_ALL_POSITIONS'', ''PER_JOBS'', ''PER_JOBS_TL'')
and TRIGGER_NAME like ''%WHO%'' and OWNER like ''APPS%'' order by table_name, trigger_name',
      p_title                  => 'WHO Triggers',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No trigger available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: WHO_triggers');



debug('begin add_signature: Legislation_not_US');
  add_signature(
      p_sig_id                 => 'Legislation_not_US',
      p_sig_sql                => 'select o3.ORG_INFORMATION9 legislation FROM HR_ALL_ORGANIZATION_UNITS O , 
				HR_ALL_ORGANIZATION_UNITS_TL OTL , 
				HR_ORGANIZATION_INFORMATION O2 ,
				HR_ORGANIZATION_INFORMATION O3 , 
				HR_ORGANIZATION_INFORMATION O4 
				WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
				AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
				AND O3.ORG_INFORMATION_CONTEXT = ''Business Group Information'' 
				AND O2.ORG_INFORMATION_CONTEXT (+) = ''Work Day Information'' 
				AND O4.ORG_INFORMATION_CONTEXT = ''CLASS'' 
				AND O4.ORG_INFORMATION1 = ''HR_BG'' AND O4.ORG_INFORMATION2 = ''Y'' 
				AND OTL.LANGUAGE = ''US''
				and O.ORGANIZATION_ID=0',
      p_title                  => 'Legislation of the Setup Business Group',
      p_fail_condition         => '[legislation] <> [US]',
      p_problem_descr          => 'Legislation of the Setup Business Group is not US. Changing the Legislation of the Setup Business Group is never allowed under any condition!',
      p_solution               => '<ul><li>Please raise a service request with Oracle Support and refer to this section of output.</li>
<li>Please review: [815934.1] After Upgrade - Setup Business Group Name Reverts Back To Setup Business Group</li>
<li>[796593.1]Can the Setup Business Group name be Changed? </li>
</ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Legislation_not_US');



debug('begin add_signature: Newlegislations');
  add_signature(
      p_sig_id                 => 'Newlegislations',
      p_sig_sql                => 'SELECT date_of_import "Date Imported"
           , PACKAGE_NAME "Package/Export Date"
           , decode(legislation_code, NULL, ''Core'', ''ZZ'', ''Intl. Payroll'',legislation_code) Legislation
           , status
      FROM HR_STU_HISTORY
      WHERE TO_NUMBER(TO_CHAR(date_of_import, ''yyyy'')) >= TO_NUMBER(TO_CHAR(SYSDATE, ''yyyy'')) - 1
      ORDER BY 1 DESC',
      p_title                  => 'New legislation installed during past year',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No new legislation.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Newlegislations');



debug('begin add_signature: WHO_triggers_disabled');
  add_signature(
      p_sig_id                 => 'WHO_triggers_disabled',
      p_sig_sql                => 'select TABLE_NAME,TRIGGER_NAME,STATUS from all_triggers where UPPER(table_name) in
( ''PER_ALL_PEOPLE_F'', ''PER_ALL_ASSIGNMENTS_F'', ''PER_PERIODS_OF_SERVICE'', ''PER_PERSON_TYPE_USAGES_F'', ''PER_ADDRESSES''
, ''HR_LOCATIONS_ALL'', ''HR_LOCATIONS_ALL_TL'', ''HR_ALL_ORGANIZATION_UNITS'', ''HR_ALL_ORGANIZATION_UNITS_TL'', ''HR_ALL_POSITIONS_F''
, ''HR_ALL_POSITIONS_F_TL'', ''PER_ALL_POSITIONS'', ''PER_JOBS'', ''PER_JOBS_TL'')
and TRIGGER_NAME like ''%WHO%'' and OWNER like ''APPS%'' and STATUS <>''ENABLED'' order by table_name, trigger_name',
      p_title                  => 'Disabled WHO Triggers',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Disabled WHO triggers identified',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: WHO_triggers_disabled');



debug('begin add_signature: Setup_Name');
  add_signature(
      p_sig_id                 => 'Setup_Name',
      p_sig_sql                => 'select otl.name name, 
             o3.ORG_INFORMATION9 legislation, 
             o3.ORG_INFORMATION10 currency
            FROM HR_ALL_ORGANIZATION_UNITS O , 
				HR_ALL_ORGANIZATION_UNITS_TL OTL , 
				HR_ORGANIZATION_INFORMATION O2 ,
				HR_ORGANIZATION_INFORMATION O3 , 
				HR_ORGANIZATION_INFORMATION O4 
				WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
				AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
				AND O3.ORG_INFORMATION_CONTEXT = ''Business Group Information'' 
				AND O2.ORG_INFORMATION_CONTEXT (+) = ''Work Day Information'' 
				AND O4.ORG_INFORMATION_CONTEXT = ''CLASS'' 
				AND O4.ORG_INFORMATION1 = ''HR_BG'' AND O4.ORG_INFORMATION2 = ''Y'' 
				AND OTL.LANGUAGE = ''US''
				and O.ORGANIZATION_ID=0',
      p_title                  => 'Setup Business Group Name',
      p_fail_condition         => '[name] <> [Setup Business Group]',
      p_problem_descr          => 'Current organization name for Setup Business Group is not Setup Business Group). Setup Business Group Name should not be changed!',
      p_solution               => '<ul><li>Please raise a service request with Oracle Support and refer to this section of output.</li>
<li>Please review: [815934.1] After Upgrade - Setup Business Group Name Reverts Back To Setup Business Group</li>
<li>[796593.1]Can the Setup Business Group name be Changed? </li>
</ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Setup_Name');



debug('begin add_signature: Data_Install');
  add_signature(
      p_sig_id                 => 'Data_Install',
      p_sig_sql                => 'select decode(hli.legislation_code
                   ,null,''global''
                   ,hli.legislation_code) "Legislation"
           , hli.application_short_name                  
           , hli.action                                 
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name
      order by legislation_code desc, application_short_name asc',
      p_title                  => 'DataInstaller Actions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You have legislations currently selected for install by the DataInstall.',
      p_solution               => 'Please resolve hrglobal issues in order to install/upgrade all legislative data selected during DataInstaller.<br>
Please review: [140511.1]  How to Install HRMS Legislative Data Using Data Installer and hrglobal.drv',
      p_success_msg            => 'No issues found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Data_Install');



debug('begin add_signature: PER_java');
  add_signature(
      p_sig_id                 => 'PER_java',
      p_sig_sql                => 'select que.filename, que.version
from (
select files.filename filename,files.subdir subdir,
file_version.version version,
rank()over(partition by files.filename
order by file_version.version_segment1 desc,
file_version.version_segment2 desc,file_version.version_segment3 desc,
file_version.version_segment4 desc,file_version.version_segment5 desc,
file_version.version_segment6 desc,file_version.version_segment7 desc,
file_version.version_segment8 desc,file_version.version_segment9 desc,
file_version.version_segment10 desc,
file_version.translation_level desc) as rank1
from ad_file_versions file_version,
(
select filename, app_short_name, subdir, file_id
from ad_files
where app_short_name=''PER'' and upper(filename) like upper(''%.class'')
) files
where files.file_id = file_version.file_id
) que
where rank1 = 1
order by 1',
      p_title                  => 'PER java classes',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No class available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PER_java');



debug('begin add_signature: IRC_Proxy_issue1');
  add_signature(
      p_sig_id                 => 'IRC_Proxy_issue1',
      p_sig_sql                => 'select count (1) Incorrect_setup from dual where
rtrim(fnd_profile.value(''WEB_PROXY_HOST'')) is not null and rtrim(fnd_profile.value(''WEB_PROXY_PORT'')) is null',
      p_title                  => 'Proxy host / port',
      p_fail_condition         => '[Incorrect_setup]>[0]',
      p_problem_descr          => 'You have specified a proxy server, but not a proxy port.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_Proxy_issue1');



debug('begin add_signature: NOTE1569684');
  add_signature(
      p_sig_id                 => 'NOTE1569684',
      p_sig_sql                => 'SELECT als.text "Incorrect Version"
    FROM all_source als
    Where  
    FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                '' '',1,1)-1),''120.0.12010000.2'') = ''<''              
    And   Als.Type = ''PACKAGE BODY''
    And   Als.Name = ''HR_APPROVAL_WF''
    And   Als.Text Like ''%$Header%''
union
SELECT als.text
    FROM all_source als
    Where  
    FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                '' '',1,1)-1),''120.22.12010000.37'') = ''<''              
    And   Als.Type = ''PACKAGE BODY''
    And   Als.Name = ''HR_APPROVAL_SS''
    And   Als.Text Like ''%$Header%''',
      p_title                  => 'Patch for termination issue (when terminating employee via Manager Self Service)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: The Server encounter an internal error or misconfiguration and was unable to complete your request',
      p_solution               => 'Review [1569684.1] Internal Server Error On The Termination Confirmation Page Through Manager Self-Service',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: NOTE1569684');



debug('begin add_signature: LANGUAGES_INSTALLED_DETAILS');
  add_signature(
      p_sig_id                 => 'LANGUAGES_INSTALLED_DETAILS',
      p_sig_sql                => 'SELECT rpad(language_code, 30, '' '') "Language Code             ",
           rpad(decode(INSTALLED_FLAG ,''B'',''Base Installed Language'',''I'',''Additional Installed Language'',''D'',''Not Installed''), 30, '' '') "          Type          ",
           rpad(nls_language, 30, '' '') "     Language     ",
           rpad(nls_territory, 30, '' '') "     Territory    "
      FROM FND_LANGUAGES
      where INSTALLED_FLAG in (''B'',''I'')
      order by LANGUAGE_CODE',
      p_title                  => 'Languages installed',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'This section lists Languages Installed',
      p_solution               => '',
      p_success_msg            => 'Advice: Periodically check if you NLS level is in sync with US level:<br>
Follow [252422.1] Requesting Translation Synchronization Patches<br>
-> this will synchronize your languages with actual US level<br>
Note! This is just an advice. This does not mean your NLS is not synchronized! Follow this step ONLY if you have translation issues.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: LANGUAGES_INSTALLED_DETAILS');



debug('begin add_signature: IRC_Java');
  add_signature(
      p_sig_id                 => 'IRC_Java',
      p_sig_sql                => 'select que.filename, que.version
from (
select files.filename filename,files.subdir subdir,
file_version.version version,
rank()over(partition by files.filename
order by file_version.version_segment1 desc,
file_version.version_segment2 desc,file_version.version_segment3 desc,
file_version.version_segment4 desc,file_version.version_segment5 desc,
file_version.version_segment6 desc,file_version.version_segment7 desc,
file_version.version_segment8 desc,file_version.version_segment9 desc,
file_version.version_segment10 desc,
file_version.translation_level desc) as rank1
from ad_file_versions file_version,
(
select filename, app_short_name, subdir, file_id
from ad_files
where app_short_name=''IRC'' and upper(filename) like upper(''%.class'')
) files
where files.file_id = file_version.file_id
) que
where rank1 = 1
order by 1',
      p_title                  => 'IRC java classes',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No version available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_Java');



debug('begin add_signature: NOTE1664437');
  add_signature(
      p_sig_id                 => 'NOTE1664437',
      p_sig_sql                => 'SELECT als.text "Incorrect Version"
    FROM all_source als
    Where  
    FND_IREP_LOADER_PRIVATE.compare_versions(
              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                '' '',1,1)-1),''120.9.12010000.6'') = ''<''     
    And   Als.Type = ''PACKAGE BODY''
    And   Als.Name = ''HR_EX_EMPLOYEE_API''
    And   Als.Text Like ''%$Header%''',
      p_title                  => 'Patch for termination issue (APP-PAY-07400)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: APP-PAY-07400: You cannot delete an assignment that has events linked to it',
      p_solution               => 'Review [1664437.1] Error : APP-PAY-07400: You cannot delete an assignment that has events linked to it. While Attempting to Terminate an Employee',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: NOTE1664437');



debug('begin add_signature: Custome_Number_generation');
  add_signature(
      p_sig_id                 => 'Custome_Number_generation',
      p_sig_sql                => 'select OWNER, NAME, TEXT   from   ALL_SOURCE
		   where  UPPER(NAME) like UPPER(''%NUMBER_GENERATION%'')
		   and    OWNER = ''APPS''   and    TEXT like ''%$Header%''
		   order  by NAME',
      p_title                  => 'Custom Number Generation Packages',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Custom Number Generation Package available!',
      p_solution               => 'Custom Number Generation Using FastFormula is used as per internal Doc ID 279458.1 How To Implement Custom Person Numbering Using FastFormula. DISCLAIMER: While this functionality was released by Oracle HR Development with 11i.HR_PF.H patch 3233333 any implementation making use of this feature is purely a Customization. Oracle Support Services will not support these FF Fast Formulas nor the associated Functions. It is up to the customer to create and diagnose any code used to implement this functionality.',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Custome_Number_generation');



debug('begin add_signature: IRC_Proxy_issue2');
  add_signature(
      p_sig_id                 => 'IRC_Proxy_issue2',
      p_sig_sql                => 'select count (1) Incorrect_setup from dual where
instr(rtrim(fnd_profile.value(''APPS_FRAMEWORK_AGENT'')),rtrim(fnd_profile.value(''WEB_PROXY_HOST'')))>0',
      p_title                  => 'Incorrect proxy server',
      p_fail_condition         => '[Incorrect_setup] > [0]',
      p_problem_descr          => 'You appear to have your proxy server set to be your application server. Set the correct proxy server.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_Proxy_issue2');



debug('begin add_signature: Discrepancies');
  add_signature(
      p_sig_id                 => 'Discrepancies',
      p_sig_sql                => 'select count(1) "Discrepancies"
     from sys.obj$ do, sys.dependency$ d, sys.obj$ po
     where p_obj#=po.obj#(+)
     and d_obj#=do.obj#
     and do.status=1
     and po.status=1
     and po.stime!=p_timestamp
     and do.type# not in (28,29,30)
     and po.type# not in (28,29,30)',
      p_title                  => 'Potential database errors ORA-03113 or ORA-01041',
      p_fail_condition         => '[Discrepancies] > [0]',
      p_problem_descr          => 'You have dependency timestamp discrepancies between the database objects. This may cause intermittent errors like: ORA-03113: end-of-file on communication channel 
ORA-01041: internal error',
      p_solution               => 'Please follow [1303973.1]  ORA-03113: end-of-file on communication channel',
      p_success_msg            => 'No discrepancy found.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Discrepancies');



debug('begin add_signature: Statutory_exception');
  add_signature(
      p_sig_id                 => 'Statutory_exception',
      p_sig_sql                => 'select table_name , surrogate_id , true_key, exception_text from hr_stu_exceptions',
      p_title                  => 'Statutory exceptions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You have statutory exceptions',
      p_solution               => 'In order to solve please review: [101351.1] HRGLOBAL.DRV:DIAGNOSING PROBLEMS WITH LEGISLATIVE UPDATES - HR_LEGISLATION.INSTALL',
      p_success_msg            => 'No statutory exceptions found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Statutory_exception');



debug('begin add_signature: ONEOFF');
  add_signature(
      p_sig_id                 => 'ONEOFF',
      p_sig_sql                => 'select distinct PATCH_TYPE,PATCH_NAME,max(trunc(LAST_UPDATE_DATE)) "Applied date" 
from ad_applied_patches where last_update_date> to_date(''##$$LDATE$$##'') group by PATCH_TYPE,PATCH_NAME order by max(trunc(LAST_UPDATE_DATE))
',
      p_title                  => 'List of applied patches after latest HRMS RUP',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No patch applied after RUP.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ONEOFF');



debug('begin add_signature: IRC_Proxy_issue3');
  add_signature(
      p_sig_id                 => 'IRC_Proxy_issue3',
      p_sig_sql                => 'select count (1) Incorrect_setup from dual where
rtrim(fnd_profile.value(''WEB_PROXY_HOST'')) is null',
      p_title                  => 'Proxy server',
      p_fail_condition         => '[Incorrect_setup] > [0]',
      p_problem_descr          => 'You do not have a proxy server set. This is generally incorrect.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_Proxy_issue3');



debug('begin add_signature: OTA_Java');
  add_signature(
      p_sig_id                 => 'OTA_Java',
      p_sig_sql                => 'select que.filename, que.version
from (
select files.filename filename,files.subdir subdir,
file_version.version version,
rank()over(partition by files.filename
order by file_version.version_segment1 desc,
file_version.version_segment2 desc,file_version.version_segment3 desc,
file_version.version_segment4 desc,file_version.version_segment5 desc,
file_version.version_segment6 desc,file_version.version_segment7 desc,
file_version.version_segment8 desc,file_version.version_segment9 desc,
file_version.version_segment10 desc,
file_version.translation_level desc) as rank1
from ad_file_versions file_version,
(
select filename, app_short_name, subdir, file_id
from ad_files
where app_short_name=''OTA'' and upper(filename) like upper(''%.class'')
) files
where files.file_id = file_version.file_id
) que
where rank1 = 1
order by 1',
      p_title                  => 'OTA java classes',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No versiolem_desc#99#',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OTA_Java');



debug('begin add_signature: Custom_FF');
  add_signature(
      p_sig_id                 => 'Custom_FF',
      p_sig_sql                => 'select FUNCTION_ID,CLASS,NAME,BUSINESS_GROUP_ID,DATA_TYPE,DEFINITION,LAST_UPDATED_BY,LAST_UPDATE_DATE,LEGISLATION_CODE,DESCRIPTION  from FF_FUNCTIONS_V 
where UPPER(DATA_TYPE) = UPPER(''number'') 
and UPPER(DEFINITION) like UPPER(''%NUM%GEN%'')',
      p_title                  => 'Custom Number Generation FF Fast Formula',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Custom Number Generation FF FAST FORMULA available!',
      p_solution               => 'Custom Number Generation Using FastFormula is used as per internal Doc ID 279458.1 How To Implement Custom Person Numbering Using FastFormula. DISCLAIMER: While this functionality was released by Oracle HR Development with 11i.HR_PF.H patch 3233333 any implementation making use of this feature is purely a Customization. Oracle Support Services will not support these FF Fast Formulas nor the associated Functions. It is up to the customer to create and diagnose any code used to implement this functionality.',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Custom_FF');



debug('begin add_signature: Geocode_date');
  add_signature(
      p_sig_id                 => 'Geocode_date',
      p_sig_sql                => 'SELECT max(applied_date) FROM pay_patch_status WHERE patch_name LIKE ''GEOCODE_ANNUAL_2015%''
 AND status = ''C''',
      p_title                  => 'GEOCODE_ANNUAL_2015 information',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'If you are maintaining tax records be aware GEOCODE_ANNUAL_2015 information are not applied!',
      p_solution               => '<ul><li>Please review </li>
<li>12.2: [2038283.1]</li>
<li>12.1: [2038282.1]</li>
<li>12.0: [1912683.1]</li>
<li>11.5: [1562530.1]</li>
<li>Oracle US and Canada Payroll - 2014 Annual Geocode Readme</li>
</ul>',
      p_success_msg            => 'GEOCODE_ANNUAL_2015 information applied',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Geocode_date');



debug('begin add_signature: Next_sequence');
  add_signature(
      p_sig_id                 => 'Next_sequence',
      p_sig_sql                => 'SELECT BUSINESS_GROUP_ID, TYPE, NEXT_VALUE 
		   FROM PER_NUMBER_GENERATION_CONTROLS
		   WHERE TYPE IN (''EMP'',''APL'', ''CWK'')
		   order by 1,2',
      p_title                  => 'Next sequence number used to create a new employee number',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No next sequence number available',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Next_sequence');



debug('begin add_signature: IRC_Proxy_issue4');
  add_signature(
      p_sig_id                 => 'IRC_Proxy_issue4',
      p_sig_sql                => 'select count (1) Incorrect_setup from dual where
fnd_profile.value(''WEB_PROXY_BYPASS_DOMAINS'') is null',
      p_title                  => 'Proxy bypass domains',
      p_fail_condition         => '[Incorrect_setup] > [0]',
      p_problem_descr          => 'You do not have an proxy bypass domains set. This is generally incorrect.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_Proxy_issue4');



debug('begin add_signature: Geocode_Upgrade_manager');
  add_signature(
      p_sig_id                 => 'Geocode_Upgrade_manager',
      p_sig_sql                => 'SELECT substr(UPPER(ARGUMENT_TEXT),1,3) "Schema", ACTUAL_COMPLETION_DATE "Completion Date", ARGUMENT_TEXT
	FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R, FND_LOOKUP_VALUES STAT, FND_LOOKUP_VALUES PHAS
	WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID
	AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID
	AND PT.LANGUAGE = ''US'' and
	STAT.LOOKUP_CODE = R.STATUS_CODE AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE'' AND PHAS.LOOKUP_CODE = R.PHASE_CODE
	AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE'' and PHAS.language=''US'' and STAT.language=''US'' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
	AND UPPER(USER_CONCURRENT_PROGRAM_NAME) like ''GEOCODE UPGRADE MANAGER%''	
	and PHAS.MEANING=''Completed'' and STAT.MEANING=''Normal'' and ACTUAL_COMPLETION_DATE>
(select LAST_UPDATE_DATE from ad_bugs where bug_number in 
(SELECT 
(CASE
WHEN RELEASE_NAME like ''12.2%'' THEN ''21276246''
WHEN RELEASE_NAME like ''12.1%'' THEN ''21276246''
WHEN RELEASE_NAME like ''12.0%'' THEN ''19139617''
WHEN RELEASE_NAME like ''15.1%'' THEN ''21276241''
else ''none''
end) patch
from FND_PRODUCT_GROUPS)
and rownum < 2)
ORDER BY 2 desc',
      p_title                  => 'Geocode Upgrade Manager process',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Geocode Upgrade Manager process was not Completed Normal after the Geocode patch!',
      p_solution               => 'If you are maintaining tax records be aware you did not performed Geocode Upgrade Manager process after the Geocode patch!',
      p_success_msg            => 'Geocode Upgrade Manager process was not Completed Normal after the Geocode patch.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Geocode_Upgrade_manager');



debug('begin add_signature: IRC_Proxy_issue5');
  add_signature(
      p_sig_id                 => 'IRC_Proxy_issue5',
      p_sig_sql                => 'select count (1) Incorrect_setup from dual where
fnd_profile.value(''WEB_PROXY_HOST'') is not null and substr(fnd_profile.value(''WEB_PROXY_BYPASS_DOMAINS''),1,1)!=''*''',
      p_title                  => 'Proxy server bypass domains',
      p_fail_condition         => '[Incorrect_setup] > [0]',
      p_problem_descr          => 'Your proxy server bypass domains are of the wrong format. They must start with *. e.g. *.oracle.com',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_Proxy_issue5');



debug('begin add_signature: Max_Values_Employee');
  add_signature(
      p_sig_id                 => 'Max_Values_Employee',
      p_sig_sql                => 'SELECT 	MAX(TO_CHAR(employee_number)) "Employee_number", MAX(TO_CHAR(applicant_number)) "Applicant_number",MAX(TO_CHAR(npw_number)) "Npw_number"
FROM PER_ALL_PEOPLE_F',
      p_title                  => 'Max values for Employee/Applicant/NPW numbers',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No max values available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Max_Values_Employee');



debug('begin add_signature: GUEST');
  add_signature(
      p_sig_id                 => 'GUEST',
      p_sig_sql                => 'select substrb(fnd_profile.value(''GUEST_USER_PWD''),0,instrb(fnd_profile.value(''GUEST_USER_PWD''),''/'')-1) "Guest_user" from dual',
      p_title                  => 'Guest user',
      p_fail_condition         => '[Guest_user] <> [GUEST]',
      p_problem_descr          => 'Your guest user is not named GUEST. This is not supported from 11.5.10 onwards.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: GUEST');



debug('begin add_signature: Guest values');
  add_signature(
      p_sig_id                 => 'Guest values',
      p_sig_sql                => 'select RESPONSIBILITY_NAME,responsibility_key,resp.start_date,resp.end_date,secg.security_group_key
,rol.EXPIRATION_DATE
,urol.EXPIRATION_DATE user_expiration_date
from fnd_responsibility resp, fnd_responsibility_tl respname
,fnd_user_resp_groups rg
,fnd_user usr
,wf_local_roles rol
,fnd_security_groups secg
,wf_local_user_roles urol
where usr.user_name=''GUEST''
and resp.RESPONSIBILITY_ID=respname.RESPONSIBILITY_ID and resp.APPLICATION_ID=respname.APPLICATION_ID and respname.language=''US''
and rg.user_id=usr.user_id
and rg.responsibility_id=resp.responsibility_id
and rg.responsibility_application_id=resp.application_id
and sysdate between usr.start_date and nvl(usr.end_date,sysdate)
and sysdate between rg.start_date and nvl(rg.end_date,sysdate)
and sysdate between resp.start_date and nvl(resp.end_date,sysdate)
and secg.security_group_id=rg.security_group_id
and rol.name=''FND_RESP|PER|''||resp.responsibility_key||''|''||secg.security_group_key
and urol.user_name=''GUEST''
and urol.role_name=''FND_RESP|PER|''||resp.responsibility_key||''|''||secg.security_group_key
order by responsibility_key',
      p_title                  => 'Guest user',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No row available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Guest values');



debug('begin add_signature: Guest_expiration_date');
  add_signature(
      p_sig_id                 => 'Guest_expiration_date',
      p_sig_sql                => 'select RESPONSIBILITY_NAME,responsibility_key,resp.start_date,resp.end_date,secg.security_group_key
,rol.EXPIRATION_DATE
,urol.EXPIRATION_DATE user_expiration_date
from fnd_responsibility resp, fnd_responsibility_tl respname
,fnd_user_resp_groups rg
,fnd_user usr
,wf_local_roles rol
,fnd_security_groups secg
,wf_local_user_roles urol
where usr.user_name=''GUEST''
and rol.EXPIRATION_DATE >=trunc(sysdate)
and resp.RESPONSIBILITY_ID=respname.RESPONSIBILITY_ID and resp.APPLICATION_ID=respname.APPLICATION_ID and respname.language=''US''
and rg.user_id=usr.user_id
and rg.responsibility_id=resp.responsibility_id
and rg.responsibility_application_id=resp.application_id
and sysdate between usr.start_date and nvl(usr.end_date,sysdate)
and sysdate between rg.start_date and nvl(rg.end_date,sysdate)
and sysdate between resp.start_date and nvl(resp.end_date,sysdate)
and secg.security_group_id=rg.security_group_id
and rol.name=''FND_RESP|PER|''||resp.responsibility_key||''|''||secg.security_group_key
and urol.user_name=''GUEST''
and urol.role_name=''FND_RESP|PER|''||resp.responsibility_key||''|''||secg.security_group_key
order by responsibility_key',
      p_title                  => 'Guest responsibilities expired',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You have guest responsibilities expired.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Guest_expiration_date');



debug('begin add_signature: Guest_user_expiration_date');
  add_signature(
      p_sig_id                 => 'Guest_user_expiration_date',
      p_sig_sql                => 'select RESPONSIBILITY_NAME,responsibility_key,resp.start_date,resp.end_date,secg.security_group_key
,rol.EXPIRATION_DATE
,urol.EXPIRATION_DATE user_expiration_date
from fnd_responsibility resp, fnd_responsibility_tl respname
,fnd_user_resp_groups rg
,fnd_user usr
,wf_local_roles rol
,fnd_security_groups secg
,wf_local_user_roles urol
where usr.user_name=''GUEST''
and urol.EXPIRATION_DATE>=trunc(sysdate)
and resp.RESPONSIBILITY_ID=respname.RESPONSIBILITY_ID and resp.APPLICATION_ID=respname.APPLICATION_ID and respname.language=''US''
and rg.user_id=usr.user_id
and rg.responsibility_id=resp.responsibility_id
and rg.responsibility_application_id=resp.application_id
and sysdate between usr.start_date and nvl(usr.end_date,sysdate)
and sysdate between rg.start_date and nvl(rg.end_date,sysdate)
and sysdate between resp.start_date and nvl(resp.end_date,sysdate)
and secg.security_group_id=rg.security_group_id
and rol.name=''FND_RESP|PER|''||resp.responsibility_key||''|''||secg.security_group_key
and urol.user_name=''GUEST''
and urol.role_name=''FND_RESP|PER|''||resp.responsibility_key||''|''||secg.security_group_key
order by responsibility_key',
      p_title                  => 'Guest - user role expired',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'User roles expired',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Guest_user_expiration_date');



debug('begin add_signature: Security_profile');
  add_signature(
      p_sig_id                 => 'Security_profile',
      p_sig_sql                => 'select security_profile_id, nvl(security_profile_name,''null'') Security_Profile_Name from PER_SECURITY_PROFILES 
	order by upper(security_profile_name)',
      p_title                  => 'Security Profiles (PER_SECURITY_PROFILES)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No security profile defined',
      p_solution               => '',
      p_success_msg            => 'Useful documentation [394083.1] Understanding and Using HRMS Security in Oracle HRMS; 
[1266051.1] Troubleshooting eBusiness Suite HRMS Security Issues; 
[1385633.1] Security, MultiOrg, and Multi Org Access Control(MOAC) support in relation to Oracle Human Resources applications',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Security_profile');



debug('begin add_signature: IRC_EXEMP');
  add_signature(
      p_sig_id                 => 'IRC_EXEMP',
      p_sig_sql                => 'select menu_name,fme.grant_flag
from fnd_menu_entries fme
,fnd_menus fm
,fnd_form_functions ff
where fme.function_id=ff.function_id
and ff.function_name=''IRC_EX_EMP_REGISTRATION''
and fme.MENU_ID=fm.MENU_ID',
      p_title                  => 'Ex-employee registration check',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No row available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_EXEMP');



debug('begin add_signature: IRC_BG');
  add_signature(
      p_sig_id                 => 'IRC_BG',
      p_sig_sql                => 'select org.name Name
,hoi.org_information1 Code
,hoi.org_information3 ||'' ''|| hoi.org_information6 Openings
,hoi.org_information4 Org
,hoi.org_information5 Loc
,hoi2.org_information3 apl_numbering
,ast.user_status || '' (''|| ast.external_status||'')'' Status
,ppttl.user_person_type Cand_Type
,hoi.org_information9 Excluded
from hr_organization_information hoi
,hr_all_organization_units org
,per_assignment_status_types_tl ast
,per_person_types_tl ppttl
,hr_organization_information hoi2
where hoi.organization_id=org.organization_id
and org.organization_id=org.business_group_id
and hoi.org_information_context=''BG Recruitment''
and hoi.org_information7=ast.assignment_status_type_id(+)
and hoi2.ORG_INFORMATION_CONTEXT = ''Business Group Information''
and hoi2.organization_id=org.organization_id
and ast.language(+)=USERENV(''LANG'')
and hoi.org_information8=ppttl.person_type_id(+)
and ppttl.language(+)=USERENV(''LANG'')',
      p_title                  => 'iRec Business Group settings',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No information available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: IRC_BG');



debug('begin add_signature: QUANTUM_CR');
  add_signature(
      p_sig_id                 => 'QUANTUM_CR',
      p_sig_sql                => 'SELECT substr(UPPER(ARGUMENT_TEXT),1,3) "Schema", ACTUAL_COMPLETION_DATE "Complation Date", ARGUMENT_TEXT
	FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R, FND_LOOKUP_VALUES STAT, FND_LOOKUP_VALUES PHAS
	WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID
	AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID
	AND PT.LANGUAGE = ''US'' and
	STAT.LOOKUP_CODE = R.STATUS_CODE AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE'' AND PHAS.LOOKUP_CODE = R.PHASE_CODE
	AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE'' and PHAS.language=''US'' and STAT.language=''US'' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
	AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE ''QUANTUM DATA UPDATE INSTAL%''
	and PHAS.MEANING=''Completed'' and STAT.MEANING=''Normal'' and ACTUAL_COMPLETION_DATE>sysdate-31
	ORDER BY 2 desc',
      p_title                  => 'Quantum Data Update Installer',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Your last run of Quantum Data Update Installer was more than 30 days ago.',
      p_solution               => 'Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this error. Please verify with System Administrator.',
      p_success_msg            => 'OK! Quantum Data Update Installer performed in last 30 days',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: QUANTUM_CR');



debug('begin add_signature: International');
  add_signature(
      p_sig_id                 => 'International',
      p_sig_sql                => 'SELECT LEGISLATION_CODE, RULE_TYPE, RULE_MODE
      FROM PAY_LEGISLATION_RULES 
      where LEGISLATION_CODE = ''ZZ'' 
      order by LEGISLATION_CODE, RULE_TYPE',
      p_title                  => 'International HR and / or Payroll Usage',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No International used',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: International');





debug('begin add_signature: Flex_Context_Values');
  add_signature(
      p_sig_id                 => 'Flex_Context_Values',
      p_sig_sql                => 'select fdfc.APPLICATION_COLUMN_NAME 
,fdfc.END_USER_COLUMN_NAME 
,fdfc.ENABLED_FLAG 
,fdfc.DISPLAY_FLAG 
,fdfc.REQUIRED_FLAG 
,fdfc.default_value
,ffvs.FLEX_VALUE_SET_NAME 
from FND_DESCR_FLEX_COL_USAGE_VL fdfc
,FND_FLEX_VALUE_SETS ffvs
where fdfc.DESCRIPTIVE_FLEXFIELD_NAME = ''IRC_SEARCH_CRITERIA''
and fdfc.DESCRIPTIVE_FLEX_CONTEXT_CODE=  ''##$$FK4$$##''
and fdfc.application_id=800
and fdfc.FLEX_VALUE_SET_ID =ffvs.FLEX_VALUE_SET_ID 
order by fdfc.COLUMN_SEQ_NUM',
      p_title                  => 'Show values',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No value',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Flex_Context_Values');

debug('begin add_signature: FLEX_Context');
  add_signature(
      p_sig_id                 => 'FLEX_Context',
      p_sig_sql                => 'select DESCRIPTIVE_FLEX_CONTEXT_CODE "##$$FK4$$##", DESCRIPTIVE_FLEX_CONTEXT_CODE 
from FND_DESCR_FLEX_CONTEXTS 
where DESCRIPTIVE_FLEXFIELD_NAME = ''IRC_SEARCH_CRITERIA''
and application_id=800
order by decode(DESCRIPTIVE_FLEX_CONTEXT_CODE,''Global Data Elements'',''1'',DESCRIPTIVE_FLEX_CONTEXT_CODE)',
      p_title                  => 'Flex Context',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No flex context available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('Flex_Context_Values'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: FLEX_Context');



debug('begin add_signature: EXT_NET');
  add_signature(
      p_sig_id                 => 'EXT_NET',
      p_sig_sql                => 'select substr(''##$$EXTNET$$##'',1,5) "Setup", ''##$$EXTNET$$##'' "Results" from dual',
      p_title                  => 'External Network Test',
      p_fail_condition         => '[Setup] = [Error]',
      p_problem_descr          => 'The external network test failed. This means that you can not make external network connections from the database, e.g. for location searching. You may also be unable to make external network connections from the middle tier, e.g. for resume parsing or background checking',
      p_solution               => '',
      p_success_msg            => 'OK! The external network test was a success. This means that you can make external network connections from the database',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: EXT_NET');



debug('begin add_signature: INT_NET');
  add_signature(
      p_sig_id                 => 'INT_NET',
      p_sig_sql                => 'select substr(''##$$INTNET$$##'',1,5) "Setup", ''##$$INTNET$$##'' "Results" from dual',
      p_title                  => 'Internal Network Test',
      p_fail_condition         => '[Setup] = [Error]',
      p_problem_descr          => 'The internal network test failed. This means that you can not make network connections from the database to the middle tier. This will stop functionality like background checking, resume generation and job postings from working.',
      p_solution               => '',
      p_success_msg            => 'OK! The internal network test was a success. This means that you can make network connections from the database to the middle tier. You need to make sure the network facilitates network connectivity on all nodes (data base and middle tiers). If you use SSL (https), then verify that your wallet manager is configured according to [123718.1].',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INT_NET');



debug('begin add_signature: SSP_TEMP_AFFECTED_ROWS');
  add_signature(
      p_sig_id                 => 'SSP_TEMP_AFFECTED_ROWS',
      p_sig_sql                => 'select count(1) v_rows from ssp_temp_affected_rows',
      p_title                  => 'SSP_TEMP_AFFECTED_ROWS',
      p_fail_condition         => '[v_rows] > [0]',
      p_problem_descr          => 'For Oracle Support: SSP_TEMP_AFFECTED_ROWS table has rows.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SSP_TEMP_AFFECTED_ROWS');



debug('begin add_signature: Customizations in forms');
  add_signature(
      p_sig_id                 => 'Customizations in forms',
      p_sig_sql                => 'select a.form_name, a.function_name, a.sequence, a.description,
 a.rule_type, a.enabled, a.trigger_event, a.trigger_object,
 a.condition, t.sequence action_sequences, t.action_type,
 t.enabled action_enabled, t.object_type, t.message_type,
 t.target_object, t.builtin_arguments 
from applsys.fnd_form_custom_actions t,
fnd_form_custom_rules a
where t.rule_id=a.id
and ( a.form_name like ''PER%'' 
or a.form_name like ''PAY%'')
order by a.form_name,a.sequence,t.sequence',
      p_title                  => 'Forms Personalization',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Form Personalization Details ( Oracle Applications )  from Database',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Customizations in forms');



debug('begin add_signature: Comment_PER');
  add_signature(
      p_sig_id                 => 'Comment_PER',
      p_sig_sql                => 'select ppf.person_id
, to_char(ppf.effective_start_date,''DD-MON-YYYY'')  Effective_Start
, to_char(ppf.effective_end_date,''DD-MON-YYYY'')    Effective_End
, ppf.COMMENT_ID
from PER_ALL_PEOPLE_F ppf
where ppf.COMMENT_ID IS NOT NULL
and NOT EXISTS(
SELECT 1
FROM HR_COMMENTS HC
WHERE HC.COMMENT_ID = ppf.COMMENT_ID)
order by 1,2',
      p_title                  => 'Comment available in PER_ALL_PEOPLE_F and not in HR_COMMENTS',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Person records with COMMENT_ID in PER_ALL_PEOPLE_F and NO matching rows found in table HR_COMMENTS',
      p_solution               => '',
      p_success_msg            => 'No issue found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Comment_PER');



debug('begin add_signature: PROJECTED_ASSIGNMENT_END');
  add_signature(
      p_sig_id                 => 'PROJECTED_ASSIGNMENT_END',
      p_sig_sql                => 'select paaf.person_id
, paaf.assignment_id
, to_char(paaf.effective_start_date,''DD-MON-YYYY'') effective_start_date
, to_char(paaf.effective_end_date,''DD-MON-YYYY'') effective_end_date
, paaf.assignment_type
, to_char(paaf.projected_assignment_end,''DD-MON-YYYY'') projected_assignment_end
from PER_ALL_ASSIGNMENTS_F paaf
where paaf.projected_assignment_end IS NOT NULL
and paaf.assignment_type = ''E''
order by 1,2,3',
      p_title                  => 'Employee Assignments with PROJECTED_ASSIGNMENT_END details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'PROJECTED_ASSIGNMENT_END is not allowed to be populated for Employee Assignment records.
PROJECTED_ASSIGNMENT_END is only allowed to be populated for Contingent Worker Assignment records.',
      p_solution               => '',
      p_success_msg            => 'No issue found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PROJECTED_ASSIGNMENT_END');



debug('begin add_signature: XMLParser');
  add_signature(
      p_sig_id                 => 'XMLParser',
      p_sig_sql                => 'select ecx_utils.XMLVersion from dual',
      p_title                  => 'XMLParser version',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No XMLParser version',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: XMLParser');

    

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
PROCEDURE main(
            p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;
  l_completion_status  BOOLEAN;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;

  IF g_is_concurrent THEN
     g_rep_info('Calling From'):='Concurrent Program';
  ELSE
     g_rep_info('Calling From'):='SQL Script';
  END IF;
  
  l_step := '10';
  initialize_files;
 
-- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'HR Technical';

  l_step := '20';

   validate_parameters(
     p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );


  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');

debug('begin section: OVERVIEW');
start_section('Instance Overview');
   set_item_result(run_stored_sig('OVERVIEWHCM'));
   set_item_result(run_stored_sig('Database details'));
   set_item_result(run_stored_sig('Application Details'));
   set_item_result(run_stored_sig('OAFrameworkforHCM'));
   set_item_result(run_stored_sig('PRODUCTS_INSTALL'));
   set_item_result(run_stored_sig('Legislations'));
   set_item_result(run_stored_sig('Newlegislations'));
   set_item_result(run_stored_sig('LANGUAGES_INSTALLED_DETAILS'));
end_section;
debug('end section: OVERVIEW');

debug('begin section: PATCHING');
start_section('Patching');
   set_item_result(check_rec_patches_8);
   set_item_result(run_stored_sig('HRglobal'));
   set_item_result(run_stored_sig('Data_Install'));
   set_item_result(run_stored_sig('Statutory_exception'));
   set_item_result(run_stored_sig('ONEOFF'));
   set_item_result(check_rec_patches_24);
   set_item_result(check_rec_patches_25);
   set_item_result(run_stored_sig('Geocode_date'));
   set_item_result(run_stored_sig('Geocode_Upgrade_manager'));
   set_item_result(check_rec_patches_26);
   set_item_result(run_stored_sig('QUANTUM_CR'));
   set_item_result(check_rec_patches_27);
   IF g_rep_info('Apps Version') like '12.1%' THEN
      set_item_result(run_stored_sig('NOTE1320920'));
      set_item_result(run_stored_sig('NOTE1402698'));
      set_item_result(run_stored_sig('NOTE1402798'));
      set_item_result(run_stored_sig('NOTE1421727'));
      set_item_result(run_stored_sig('NOTE1569684'));
      set_item_result(run_stored_sig('NOTE1664437'));
   END IF;
   set_item_result(check_rec_patches_28);
   IF g_sql_tokens('##$$australia$$##') >0 THEN
      set_item_result(check_rec_patches_18);
   END IF;
   IF g_sql_tokens('##$$china$$##') >0 THEN
      set_item_result(check_rec_patches_4);
   END IF;
   IF g_sql_tokens('##$$canada$$##') > 0 THEN
      set_item_result(check_rec_patches_13);
   END IF;
   IF g_sql_tokens('##$$danemarca$$##') > 0 THEN
      set_item_result(check_rec_patches_7);
   END IF;
   IF g_sql_tokens('##$$finland$$##') >0 THEN
      set_item_result(check_rec_patches_11);
   END IF;
   IF g_sql_tokens('##$$hong$$##')>0 THEN
      set_item_result(check_rec_patches_20);
   END IF;
   IF g_sql_tokens('##$$ireland$$##') >0 THEN
      set_item_result(check_rec_patches_19);
   END IF;
   IF g_sql_tokens('##$$india$$##') >0 THEN
      set_item_result(check_rec_patches_21);
   END IF;
   IF g_sql_tokens('##$$japan$$##') >0 THEN
      set_item_result(check_rec_patches_17);
   END IF;
   IF g_sql_tokens('##$$korea$$##') >0 THEN
      set_item_result(check_rec_patches_10);
   END IF;
   IF g_sql_tokens('##$$kuwait$$##') > 0 THEN
      set_item_result(check_rec_patches_12);
   END IF;
   IF g_sql_tokens('##$$nl$$##') >0 THEN
      set_item_result(check_rec_patches_14);
   END IF;
   IF g_sql_tokens('##$$no$$##') >0 THEN
      set_item_result(check_rec_patches_1);
   END IF;
   IF g_sql_tokens('##$$nz$$##') >0 THEN
      set_item_result(check_rec_patches_15);
   END IF;
   IF g_sql_tokens('##$$sa$$##') >0 THEN
      set_item_result(check_rec_patches_22);
   END IF;
   IF g_sql_tokens('##$$se$$##') >0 THEN
      set_item_result(check_rec_patches_23);
   END IF;
   IF g_sql_tokens('##$$sg$$##') >0 THEN
      set_item_result(check_rec_patches_2);
   END IF;
   IF g_sql_tokens('##$$ae$$##') >0 THEN
      set_item_result(check_rec_patches_9);
   END IF;
   IF g_sql_tokens('##$$gb$$##') >0 THEN
      set_item_result(check_rec_patches_5);
   END IF;
   IF g_sql_tokens('##$$usa$$##') > 0 THEN
      set_item_result(check_rec_patches_6);
   END IF;
   IF g_sql_tokens('##$$hrper$$##') >0 THEN
      set_item_result(check_rec_patches_16);
   END IF;
   IF g_sql_tokens('##$$za$$##') >0 THEN
      set_item_result(check_rec_patches_3);
   END IF;
end_section;
debug('end section: PATCHING');

debug('begin section: SETTINGS');
start_section('Settings');
   set_item_result(run_stored_sig('Profiles'));
   set_item_result(run_stored_sig('HR_MANAGER_APPRAISALS_MENU 1'));
   set_item_result(run_stored_sig('HR_MANAGER_APPRAISALS_MENU 2'));
   set_item_result(run_stored_sig('HR_MANAGER_APPRAISALS_MENU 3'));
   set_item_result(run_stored_sig('HR_WORKER_APPRAISALS_MENU'));
   set_item_result(run_stored_sig('HR_WORKER_APPRAISALS_MENU 2'));
   set_item_result(run_stored_sig('HR_WORKER_APPRAISALS_MENU 3'));
   set_item_result(run_stored_sig('ProfileFND_DISABLE_OA_CUSTOMIZATIONS'));
   set_item_result(run_stored_sig('ProfileFND_OA_ENABLE_DEFAULTS'));
   set_item_result(run_stored_sig('ProfilePER_GLOBAL_EMP_NUM'));
   set_item_result(run_stored_sig('ProfileENABLE_SECURITY_GROUPS'));
   set_item_result(run_stored_sig('AR_CHANGE_CUST_NAME'));
   set_item_result(run_stored_sig('Business Group'));
   set_item_result(run_stored_sig('Currency_not_USD'));
   IF g_sql_tokens('##$$hr_status$$##') ='Shared' THEN
      set_item_result(run_stored_sig('Date_track_Shared'));
      set_item_result(run_stored_sig('PER_ENABLE_DTW4'));
   END IF;
   set_item_result(run_stored_sig('Legislation_not_US'));
   set_item_result(run_stored_sig('Setup_Name'));
   set_item_result(run_stored_sig('Custome_Number_generation'));
   set_item_result(run_stored_sig('Custom_FF'));
   set_item_result(run_stored_sig('Next_sequence'));
   set_item_result(run_stored_sig('Max_Values_Employee'));
   set_item_result(run_stored_sig('Security_profile'));
   set_item_result(run_stored_sig('International'));
   set_item_result(run_stored_sig('SSP_TEMP_AFFECTED_ROWS'));
   set_item_result(run_stored_sig('Customizations in forms'));
   set_item_result(run_stored_sig('Comment_PER'));
   set_item_result(run_stored_sig('PROJECTED_ASSIGNMENT_END'));
end_section;
debug('end section: SETTINGS');

debug('begin section: PERFORMANCE');
start_section('Performance');
   IF g_rep_info('Apps Version') like '12%' THEN
      set_item_result(run_stored_sig('DATABASE_INITIALIZATION_12'));
   END IF;
   set_item_result(run_stored_sig('HR_Gather'));
   IF g_rep_info('Apps Version') like '11%' THEN
      set_item_result(run_stored_sig('DATABASE_INITIALIZATION_11i'));
   END IF;
end_section;
debug('end section: PERFORMANCE');

debug('begin section: DATABASE');
start_section('Database objects');
   set_item_result(run_stored_sig('HRinvalidnew'));
   set_item_result(run_stored_sig('HRinvalidothers'));
   set_item_result(run_stored_sig('Intermedia_all'));
   set_item_result(run_stored_sig('Invalid_intermedia'));
   set_item_result(run_stored_sig('Disabled_Triggers'));
   set_item_result(run_stored_sig('OVN_Triggers'));
   set_item_result(run_stored_sig('OVN_triggers_disabled'));
   set_item_result(run_stored_sig('WHO_triggers'));
   set_item_result(run_stored_sig('WHO_triggers_disabled'));
   set_item_result(run_stored_sig('Discrepancies'));
end_section;
debug('end section: DATABASE');

debug('begin section: WORKFLOW');
start_section('Workflow Details');
   set_item_result(run_stored_sig('Complete_defunct_HR'));
   set_item_result(run_stored_sig('Workflow_errors'));
end_section;
debug('end section: WORKFLOW');

debug('begin section: VERSIONS');
start_section('Files Versions');
   set_item_result(run_stored_sig('PER_Packages'));
   set_item_result(run_stored_sig('HR_Packages'));
   set_item_result(run_stored_sig('IRC_package'));
   set_item_result(run_stored_sig('OTA_packages'));
   set_item_result(run_stored_sig('PER_java'));
   set_item_result(run_stored_sig('IRC_Java'));
   set_item_result(run_stored_sig('OTA_Java'));
end_section;
debug('end section: VERSIONS');

debug('begin section: IRC');
start_section(' IRecruitment Setup');
   set_item_result(run_stored_sig('IRC Profiles'));
   set_item_result(run_stored_sig('IRC_Proxy'));
   set_item_result(run_stored_sig('IRC_Proxy_issue1'));
   set_item_result(run_stored_sig('IRC_Proxy_issue2'));
   set_item_result(run_stored_sig('IRC_Proxy_issue3'));
   set_item_result(run_stored_sig('IRC_Proxy_issue4'));
   set_item_result(run_stored_sig('IRC_Proxy_issue5'));
   set_item_result(run_stored_sig('GUEST'));
   set_item_result(run_stored_sig('Guest values'));
   set_item_result(run_stored_sig('Guest_expiration_date'));
   set_item_result(run_stored_sig('Guest_user_expiration_date'));
   set_item_result(run_stored_sig('IRC_EXEMP'));
   set_item_result(run_stored_sig('IRC_BG'));
   set_item_result(run_stored_sig('FLEX_Context'));
   set_item_result(run_stored_sig('EXT_NET'));
   set_item_result(run_stored_sig('INT_NET'));
   IF g_sql_tokens('##$$IRC_BACKGROUND$$##')>1 THEN
      set_item_result(run_stored_sig('BACK_NET'));
   END IF;
   IF g_sql_tokens('##$$IRC_RESUME$$##')>1 THEN
      set_item_result(run_stored_sig('RESUME_NET'));
   END IF;
   IF g_sql_tokens('##$$IRC_GEOCODE$$##')>1 THEN
      set_item_result(run_stored_sig('ELOCATION'));
   END IF;
   set_item_result(run_stored_sig('XMLParser'));
   IF g_sql_tokens('##$$Cust$$##')<>'N' THEN
      set_item_result(run_stored_sig('Customization'));
      set_item_result(run_stored_sig('VO substitutions'));
   END IF;
end_section;
debug('end section: IRC');



  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  print_out('<a href="https://community.oracle.com/message/12181012" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 

  IF g_is_concurrent THEN
     l_completion_status:=FND_CONCURRENT.SET_COMPLETION_STATUS('NORMAL','');
  END IF;
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);

  IF g_is_concurrent THEN
     l_completion_status:=FND_CONCURRENT.SET_COMPLETION_STATUS('ERROR',g_errbuf);
  END IF; 
   
END main;


BEGIN
 
   null;



   main(  );


EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);



END;

/
show errors
exit; 
-- Exit required for bundling project so do not remove
