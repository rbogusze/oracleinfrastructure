REM $Id: ar_autoaccounting_analyze.sql, 200.3 2016/01/06 14:21:14 victoria.crisostomo@oracle.com Exp $
REM +==================================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                            |
REM |                    Redwood Shores, California, USA                               |
REM |                         All rights reserved.                                     |
REM +==================================================================================+
REM |                                                                                  |
REM | FILENAME                                                                         |
REM |    ar_autoaccounting_analyze.sql                                                 |
REM |                                                                                  |
REM | DESCRIPTION                                                                      |
REM |    Wrapper SQL to submit the ar_autoacc_analyzer_pkg.main procedure                      |
REM |                                                                                  |
REM | HISTORY                                                                          |
REM |                                                                                  |
REM +==================================================================================+
REM
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2
REM 
REM MENU_TITLE: Oracle Receivables AutoAccounting Analyzer
REM
REM MENU_START
REM
REM SQL: Run Oracle Receivables AutoAccounting Analyzer
REM FNDLOAD: Load Oracle Receivables AutoAccounting Analyzer as a Concurrent Program
REM
REM MENU_END 
REM
REM 
REM HELP_START  
REM 
REM  Oracle Receivables AutoAccounting Analyzer Help [Doc ID: 1904785.1]
REM
REM  Compatible with: [11i|12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs ar_autoaccounting_analyze.sql as APPS user to create an HTML report
REM
REM    (2) Install Oracle Receivables AutoAccounting Analyzer as Concurrent Program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group: "Receivables All"
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: AR_TOP
REM PROG_NAME: ARAUTOACC
REM DEF_REQ_GROUP: Receivables All
REM PROG_TEMPLATE: AR_AUTOACCAZ.ldt
REM PROD_SHORT_NAME: AR 
REM CP_FILE: 
REM APP_NAME: Receivables
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ar_autoaccounting_analyzer.sql 
REM
REM DEPENDENCIES_END
REM
REM OUTPUT_TYPE: UTL_FILE 
REM
REM ANALYZER_BUNDLE_END


SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "~"
PROMPT
PROMPT Submitting Oracle Receivables AutoAccounting.

PROMPT ===========================================================================
PROMPT Enter the org_id for the operating unit. This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT p_org_id NUMBER  DEFAULT '-1' PROMPT 'Enter the org_id: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the account type for which you are getting errors, valid values are: REC (Receivable), REV (Revenue) or OFFSET (for Unearned Revenue, Unbilled Receivable or AutoInvoice Clearing). This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT p_account_type_in CHAR   PROMPT 'Enter the Account type with missing segment: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter number associated to missing segment This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT p_missing_seg NUMBER  DEFAULT '-1' PROMPT 'Enter the Missing segment number: '
PROMPT
PROMPT ===========================================================================
PROMPT Location of AutoAccounting error, valid values are: AUTOINV (AutoInvoice) or TRXFORM (Transaction form) This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT p_where CHAR   PROMPT 'Enter the Location of error: '
PROMPT
PROMPT ===========================================================================
PROMPT If location of error = TRXFORM, enter a value for CUSTOMER_TRX_ID, otherwise enter 0. 
PROMPT ===========================================================================
PROMPT
ACCEPT p_customer_trx_id NUMBER  DEFAULT '0' PROMPT 'Enter the Customer Trx ID: '
PROMPT
PROMPT ===========================================================================
PROMPT If location of error = AUTOINV, enter interface line ID, otherwise enter 0. 
PROMPT ===========================================================================
PROMPT
ACCEPT p_interface_line_id NUMBER  DEFAULT '0' PROMPT 'Enter the Interface Line ID: '
PROMPT
PROMPT
DECLARE
   p_org_id                       NUMBER         := '~p_org_id';
   p_account_type_in              VARCHAR2(240)  := '~p_account_type_in';
   p_missing_seg                  NUMBER         := '~p_missing_seg';
   p_where                        VARCHAR2(240)  := '~p_where';
   p_customer_trx_id              NUMBER         := '~p_customer_trx_id';
   p_interface_line_id            NUMBER         := '~p_interface_line_id';

BEGIN
IF p_org_id = -1 THEN
   p_org_id := NULL;
END IF;
IF p_missing_seg = -1 THEN
   p_missing_seg := NULL;
END IF;

   ar_autoacc_analyzer_pkg.main(
     p_org_id                       => p_org_id
    ,p_account_type_in              => p_account_type_in
    ,p_missing_seg                  => p_missing_seg
    ,p_where                        => p_where
    ,p_customer_trx_id              => p_customer_trx_id
    ,p_interface_line_id            => p_interface_line_id  );

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);

END;
/
exit;