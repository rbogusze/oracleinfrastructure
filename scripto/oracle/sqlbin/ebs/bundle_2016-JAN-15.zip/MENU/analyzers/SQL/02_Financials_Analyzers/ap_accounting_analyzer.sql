SET DEFINE '~'
WHENEVER SQLERROR EXIT

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.29                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ap_accounting_analyzer.sql                                           |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+

declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,2);
    
 -- Validation to verify analyzer is run on proper e-Business application version
 -- So will fail before package is created
 if apps_version < '12' then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'             ***');
    dbms_output.put_line('*** This Analyzer script must run in version 12 or above    ***');
    dbms_output.put_line('*** Note: the error below is intentional                    ***');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness Version 12 or higher');
 end if;

END;
/

-- PSD #1
CREATE OR REPLACE PACKAGE ap_accounting_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-- PSD #10

PROCEDURE main 
(            p_invoice_id                   IN NUMBER      DEFAULT NULL
           ,p_check_id                     IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 10
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')
;

-- PSD #16	  
PROCEDURE main_cp (
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
           ,p_invoice_id                   IN NUMBER      DEFAULT NULL
           ,p_check_id                     IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 10
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y'
);

-- PSD #1
END ap_accounting_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY ap_accounting_analyzer_pkg AS
-- PSD #1a
-- $Id: ap_accounting_analyzer.sql, 200.4 2015/10/23 10:41:02 ARNAL.ROBERT Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #15  
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1665706.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'AP_Create_Acctg_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'AP_Create_Acctg_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>AP_Create_Acctg Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {

  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1665706.1:ACCOUNTINGANALYZER">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/ap_acct_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
		 
		 -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
	   -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;

       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;			
			
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div><br>');
END print_rep_subsection_end;


-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------



-------------------------
-- Recommended Patches
-------------------------

FUNCTION check_rec_patches_1 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_1');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,2) = '12' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '13563472';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'Payables Core RPC 1';
   l_col_rows(5)(1) := '[1397581.1]';

   l_col_rows(1)(2) := '14273383';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'Payables Core RPC 2';
   l_col_rows(5)(2) := '[1397581.1]';

   l_col_rows(1)(3) := '16213642';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'Payables Core RPC 3';
   l_col_rows(5)(3) := '[1397581.1]';

   l_col_rows(1)(4) := '16060007';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'Subledger Accounting RPC 2';
   l_col_rows(5)(4) := '[1481222.1]';

   l_col_rows(1)(5) := '19018767';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'Payables Core RPC 5';
   l_col_rows(5)(5) := '[1397581.1]';

   l_col_rows(1)(6) := '14082924';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'Consolidated GDF Pre-Req for Undo Acctg';
   l_col_rows(5)(6) := '[1397581.1]';

   l_col_rows(1)(7) := '14284509';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'Subledger Accounting RPC 1';
   l_col_rows(5)(7) := '[1481222.1]';

   l_col_rows(1)(8) := '17176017';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'Payables Core RPC 4';
   l_col_rows(5)(8) := '[1397581.1]';

END IF;

   l_sig.title := 'Recommended Patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please check if any of the recommended patches were not applied in this instance.';
   l_sig.solution := '<ul><li>Please review list above and schedule to apply any unappplied patches as soon as possible</li><li>Refer to the note indicated for more information about each patch</li></ul>';
   l_sig.success_msg := 'Recommended patches are applied.';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'create_acctg_check_rec_patches',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_1');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_1 at step '||l_step);
  raise;
END check_rec_patches_1;




-------------------------
-- Signatures
-------------------------


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters(
            p_invoice_id                   IN NUMBER      DEFAULT NULL
           ,p_check_id                     IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 10
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_revision                  VARCHAR2(25);
  l_date_char                 VARCHAR2(30);
  l_instance                  V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version              FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host                      V$INSTANCE.HOST_NAME%TYPE;
  l_key                       VARCHAR2(255);
  l_system_function_var       VARCHAR2(2000);
  l_index                     NUMBER:=1;

  invalid_parameters EXCEPTION;

l_org_list     VARCHAR2(150);
g_org_ids      varchar2(240);

l_exists_val       VARCHAR2(2000);





BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.4  $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/10/23 10:40:51 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #7
  g_rep_info('File Name') := 'ap_accounting_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
-- PSD #7b
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1665706.1" target="_blank">(Note 1665706.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------

-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  IF substr(l_apps_version,1,2) < '12' THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script must run in version 12 or above.');
	raise invalid_parameters;
  END IF;
  

  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');

debug('begin parameter validation: p_invoice_id');
IF p_invoice_id IS NOT NULL AND p_invoice_id <> '' THEN
BEGIN
SELECT INVOICE_ID
INTO l_exists_val
FROM AP_INVOICES_ALL
WHERE INVOICE_ID = p_invoice_id;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('Invalid invoice id specified.');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_invoice_id');

debug('begin parameter validation: p_check_id');
IF p_check_id IS NOT NULL AND p_check_id <> '' THEN
BEGIN
SELECT CHECK_ID
INTO l_exists_val
FROM AP_CHECKS_ALL
WHERE CHECK_ID = p_check_id;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('Invalid check id specified.');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_check_id');




debug('begin Additional Code: Additional Validation');
--one of the two parameters must be entered
IF p_check_id IS NULL and p_invoice_id IS NULL THEN
  print_log('Error: No parameter has been entered. Check or Invoice must be entered.');
  raise invalid_parameters;
END IF;



IF (p_invoice_id is not null OR
        p_check_id is not null ) THEN

-- validation for invoice  
   IF p_invoice_id is not null THEN
        BEGIN
          SELECT to_char(org_id) INTO l_org_list
          FROM   ap_invoices_all
          WHERE  invoice_id = p_invoice_id;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            print_log('Error: '||sqlerrm||'. Invoice id ('||
              to_char(p_invoice_id)||') does not exist.  '||
              'Please provide a valid invoice id parameter value.');
            raise invalid_parameters;
          WHEN OTHERS THEN
            print_log('Error: '||sqlerrm||' validating invoice id: '||
              to_char(p_invoice_id));
            raise invalid_parameters;
        END;
   END IF;


-- validation for check
   IF p_check_id is not null THEN
        BEGIN
          SELECT decode(l_org_list,
                   null,to_char(org_id),
                   to_char(org_id), l_org_list,
                   l_org_list||','||to_char(org_id))
          INTO   l_org_list
          FROM   ap_checks_all
          WHERE  check_id = p_check_id;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            print_log('Error: '||sqlerrm||'. Check id ('||
              to_char(p_check_id)||') does not exist.  '||
              'Please provide a valid check id parameter value.');
            raise invalid_parameters;
          WHEN OTHERS THEN
            print_log('Error: '||sqlerrm||' validating check id: '||
              to_char(p_check_id));
            raise invalid_parameters;
        END;
    END IF;

      l_org_list := nvl(l_org_list, 'SELECT org_id FROM ap_system_parameters_all');
      g_org_ids := l_org_list;

END IF;debug('end Additional Code: Additional Validation');



  -- PSD #8
  -- Create global hash for parameters. Numbers required for the output order
debug('begin populate parameters hash table');
   g_parameters(l_index||'. Invoice ID') := p_invoice_id;
   l_index:=l_index+1;
   g_parameters(l_index||'. Check ID') := p_check_id;
   l_index:=l_index+1;
   g_parameters(l_index||'. Maximum Rows to Display') := p_max_output_rows;
   l_index:=l_index+1;
   g_parameters(l_index||'. Debug Mode') := p_debug_mode;
   l_index:=l_index+1;
debug('end populate parameters hash table');



  l_key := g_parameters.first;
  -- Print parameters to the log
  print_log('Parameter Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_parameters(l_key));
    l_key := g_parameters.next(l_key);
  END LOOP;
  
  -- PSD #8a
  -- Create global hash of SQL token values
debug('begin populate sql tokens hash table');
   g_sql_tokens('##$$INVID$$##') := nvl(to_char(p_invoice_id),'NULL');
   g_sql_tokens('##$$CHKID$$##') := nvl(to_char(p_check_id),'NULL');
   g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');
   g_sql_tokens('##$$ORGS$$##') := g_org_ids;
   g_sql_tokens('##$$IVIEW$$##') := 'SELECT DISTINCT d.invoice_id, d.invoice_distribution_id '||                'FROM ap_invoice_distributions_all d '||                'WHERE d.invoice_id = '||nvl(p_invoice_id,-99)||'';
debug('end populate sql tokens hash table');



  l_key := g_sql_tokens.first;
  -- Print token values to the log

  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;

  -- PSD #7a-end

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN

null;
-- PSD #9
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------


debug('begin add_signature: INV_SUMMARY');
  add_signature(
      p_sig_id                 => 'INV_SUMMARY',
      p_sig_sql                => 'select  ai.org_id, aid.set_of_books_id, ai.invoice_id,        ai.invoice_num,          ai.invoice_date,     ai.invoice_amount,
            aid.accounting_date,  aid.period_name,         aid.posted_flag,     aid.accrual_posted_flag,
            aid.cash_posted_flag, aid.accounting_Event_id, aid.historical_flag, aid.match_status_flag
    from    ap_invoice_distributions_all aid, 
            ap_invoices_all ai
    where 1=1
    and ai.invoice_id = aid.invoice_id
    and aid.invoice_id = NVL(##$$INVID$$##, -99)
    group by  ai.org_id, aid.set_of_books_id,ai.invoice_id,        ai.invoice_num,         ai.invoice_date,    ai.invoice_amount,
              aid.accounting_date,  aid.period_name,        aid.posted_flag,    aid.accrual_posted_flag,
              aid.cash_posted_flag, aid.accounting_Event_id,aid.historical_flag, aid.match_status_flag',
      p_title                  => 'Invoice Summary',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Invoice Summary',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INV_SUMMARY');



debug('begin add_signature: PAY_SUMMARY');
  add_signature(
      p_sig_id                 => 'PAY_SUMMARY',
      p_sig_sql                => 'select  ac.check_id,          ac.check_number,      ac.vendor_name,   ac.check_date,
            ac.amount,            aph.transaction_type, aph.posted_flag,  aph.accounting_event_id,
            aph.related_event_id, aph.historical_flag,  aph.invoice_adjustment_event_id
    from    ap_payment_history_all aph,
            ap_checks_all ac
    where   1=1
    and     ac.check_id   = aph.check_id
    and     aph.check_id  = NVL(##$$CHKID$$##,-99)
    group by  ac.check_id,          ac.check_number,      ac.vendor_name,   ac.check_date,
              ac.amount,            aph.transaction_type, aph.posted_flag,  aph.accounting_event_id,
              aph.related_event_id, aph.historical_flag,  aph.invoice_adjustment_event_id',
      p_title                  => 'Payment Summary',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Payment Summary',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PAY_SUMMARY');



debug('begin add_signature: AUTORATE_INVOICE');
  add_signature(
      p_sig_id                 => 'AUTORATE_INVOICE',
      p_sig_sql                => 'select  ai.invoice_id,            ai.invoice_num,       ai.invoice_date, 
            ai.invoice_currency_code, asp.base_currency_code
    from    ap_invoices_all ai,
            ap_system_parameters_all asp,
            (
            ##$$IVIEW$$##
            ) invs
    where   ai.org_id = asp.org_id
    and     asp.base_currency_code != ai.invoice_currency_code 
    and     ai.invoice_id           = invs.invoice_id
    and     nvl(ai.exchange_rate,0) = 0',
      p_title                  => 'Check Autorate For Invoice',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The conversion rate for the relevant currencies and conversion date was missing in General Ledger',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [834251.1] </li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AUTORATE_INVOICE');



debug('begin add_signature: mgd_sig_102');
  add_signature(
      p_sig_id                 => 'mgd_sig_102',
      p_sig_sql                => 'WITH invs AS (
         select ##$$INVID$$## invoice_id from dual
        )
        SELECT /*+ ordered no_unnest use_nl(ai xte xe xah) */
               ''EVENT'' orphan_type,
               ''N'' processed_flag,
               ai.invoice_id,
               ai.invoice_num,
               ai.org_id,
               xe.event_id,
               xe.event_status_code,
               xe.process_status_code,
               xah.ae_header_id,
               xte.source_id_int_1 source_id,
               xte.entity_code source_table,
               xe.event_date,
               xe.entity_id,
               xe.event_type_code,
               xe.budgetary_control_flag,
               xe.upg_batch_id
        FROM invs,
             ap_invoices_all ai,
             xla_transaction_entities_upg xte,
             xla_events xe,
             xla_ae_headers xah
        WHERE xe.application_id = xte.application_id
        AND   xe.event_status_code <> ''P''
        AND   xe.event_id = xah.event_id (+)
        AND   xah.application_id(+) = xe.application_id
        AND   xte.entity_id = xe.entity_id
        AND   xte.application_id = 200
        AND   xte.entity_code = ''AP_INVOICES''
        AND   xte.ledger_id = ai.set_of_books_id
        AND   NOT EXISTS (
                SELECT ''No Invoice rows exist for this event''
                FROM ap_invoice_distributions_all aid
                WHERE aid.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No Distributions exist for the bc_event_id''
                FROM ap_invoice_distributions_all aid
                WHERE aid.bc_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No payment rows exist for this event''
                FROM ap_invoice_payments_all aip
                WHERE aip.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No payment history rows exists for this event''
                FROM ap_payment_history_all aph
                WHERE aph.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No self assessed tax rows exists for this event''
                FROM ap_self_assessed_tax_dist_all asatd
                WHERE asatd.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No self assessed tax rows exists for the bc_event_id''
                FROM ap_self_assessed_tax_dist_all asatd
                WHERE asatd.bc_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No prepay history rows exists for this event''
                FROM ap_prepay_history_all aprh
                WHERE aprh.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No prepayment history rows exists for the bc_event_id''
                FROM ap_prepay_history_all apph
                WHERE apph.bc_event_id = xe.event_id)
        AND   xe.event_type_code NOT IN
                (''MANUAL'', ''REVERSAL'',''PREPAYMENT APPLICATION ADJ'')
        AND   (xe.upg_batch_id is NULL OR
               xe.upg_batch_id = -9999)
        AND   NOT EXISTS (
                SELECT ''No final accounted headers''
                FROM xla_ae_headers xah
                WHERE xah.event_id = xe.event_id
                AND   xah.application_id = 200
                AND   xah.entity_id = xte.entity_id
                AND   xah.accounting_entry_status_code = ''F''
                AND   xah.gl_transfer_status_code = ''Y'')
        AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
        AND   ai.invoice_id = invs.invoice_id
        UNION ALL
        SELECT /*+ ordered no_unnest use_nl(ai xte xah) */
               ''HEADER'',
               ''N'',
               ai.invoice_id,
               ai.invoice_num,
               ai.org_id,
               xah.event_id,
               null,
               null,
               xah.ae_header_id,
               xte.source_id_int_1,
               xte.entity_code,
               xah.accounting_date,
               xah.entity_id,
               xah.event_type_code,
               null,
               xah.upg_batch_id
        FROM invs,
             ap_invoices_all ai,
             xla_transaction_entities_upg xte,
             xla_ae_headers xah
        WHERE xah.application_id = xte.application_id
        AND   xte.entity_id = xah.entity_id
        AND   xte.application_id = 200
        AND   xte.entity_code = ''AP_INVOICES''
        AND   xte.ledger_id = ai.set_of_books_id
        AND   NOT EXISTS (
                SELECT ''No Invoice rows exist for this event''
                FROM ap_invoice_distributions_all aid
                WHERE aid.accounting_event_id = xah.event_id)
        AND   NOT EXISTS (
                SELECT ''No Distributions exist for the bc_event_id''
                FROM ap_invoice_distributions_all aid
                WHERE aid.bc_event_id = xah.event_id)
        AND   NOT EXISTS (
                SELECT ''No payment rows exist for this event''
                FROM ap_invoice_payments_all aip
                WHERE aip.accounting_event_id = xah.event_id)
        AND   NOT EXISTS (
                SELECT ''No payment history rows exists for this event''
                FROM ap_payment_history_all aph
                WHERE aph.accounting_event_id = xah.event_id)
        AND   NOT EXISTS (
                SELECT ''No self assessed tax rows exists for this event''
                FROM ap_self_assessed_tax_dist_all asatd
                WHERE asatd.accounting_event_id = xah.event_id)
        AND   NOT EXISTS (
                SELECT ''No self assessed tax rows exists for the bc_event_id''
                FROM ap_self_assessed_tax_dist_all asatd
                WHERE asatd.bc_event_id = xah.event_id)
        AND   NOT EXISTS (
                SELECT ''No prepay history rows exists for this event''
                FROM ap_prepay_history_all aprh
                WHERE aprh.accounting_event_id = xah.event_id)
        AND   NOT EXISTS (
                SELECT ''No prepayment history rows exists for the bc_event_id''
                FROM ap_prepay_history_all apph
                WHERE apph.bc_event_id = xah.event_id)
        AND   NOT EXISTS (
                SELECT '' Event for this header does not exist''
                FROM xla_events xe
                WHERE xe.application_id = xah.application_id
                AND   xe.event_id = xah.event_id)
        AND   xah.event_type_code NOT IN
                (''MANUAL'', ''REVERSAL'', ''PREPAYMENT APPLICATION ADJ'')
        AND   (xah.upg_batch_id is NULL OR
               xah.upg_batch_id = -9999)
        AND   nvl(xah.gl_transfer_status_code, ''X'') <> ''Y''
        AND   nvl(xah.accounting_entry_status_code, ''X'') <> ''F''
        AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
        AND   ai.invoice_id = invs.invoice_id
        UNION ALL
        SELECT /*+ ordered no_unnest use_nl(ai xte xe xah) */
               ''EVENT'' orphan_type,
               ''Y'' processed_flag,
               ai.invoice_id,
               ai.invoice_num,
               ai.org_id,
               xe.event_id,
               xe.event_status_code,
               xe.process_status_code,
               xah.ae_header_id,
               xte.source_id_int_1 source_id,
               xte.entity_code source_table,
               xe.event_date,
               xe.entity_id,
               xe.event_type_code,
               xe.budgetary_control_flag,
               xe.upg_batch_id
        FROM invs,
             ap_invoices_all ai,
             xla_transaction_entities_upg xte,
             xla_events xe,
             xla_ae_headers xah
        WHERE xe.application_id = 200
        AND   xe.event_status_code = ''P''
        AND   xah.event_id = xe.event_id
        AND   xah.application_id = 200
        AND   xte.entity_id = xe.entity_id
        AND   xte.application_id = 200
        AND   xte.entity_code = ''AP_INVOICES''
        AND   xte.ledger_id = ai.set_of_books_id
        AND   NOT EXISTS (
                SELECT ''No Invoice rows exist for this event''
                FROM ap_invoice_distributions_all aid
                WHERE aid.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No Distributions exist for the bc_event_id''
                FROM ap_invoice_distributions_all aid
                WHERE aid.bc_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No payment rows exist for this event''
                FROM ap_invoice_payments_all aip
                WHERE aip.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No payment history rows exists for this event''
                FROM ap_payment_history_all aph
                WHERE aph.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No self assessed tax rows exists for this event''
                FROM ap_self_assessed_tax_dist_all asatd
                WHERE asatd.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No self assessed tax rows exists for the bc_event_id''
                FROM ap_self_assessed_tax_dist_all asatd
                WHERE asatd.bc_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No prepay history rows exists for this event''
                FROM ap_prepay_history_all aprh
                WHERE aprh.accounting_event_id = xe.event_id)
        AND   NOT EXISTS (
                SELECT ''No prepayment history rows exists for the bc_event_id''
                FROM ap_prepay_history_all apph
                WHERE apph.bc_event_id = xe.event_id)
        AND   xe.event_type_code NOT IN
                (''MANUAL'', ''REVERSAL'', ''PREPAYMENT APPLICATION ADJ'')
        AND   (xe.upg_batch_id is NULL OR
               xe.upg_batch_id = -9999)
        AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Orphan Invoice Accounting Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Orphan accounting events exist in the XLA tables',
      p_solution               => '<ul>
   <li>These orphan records have to be deleted to sucessfully close the period</li>
   <li>Follow the instructions provided in [788135.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: mgd_sig_102');



debug('begin add_signature: CREATE_ACCTG_FILE_VERSIONS');
  add_signature(
      p_sig_id                 => 'CREATE_ACCTG_FILE_VERSIONS',
      p_sig_sql                => 'SELECT name , text
    FROM dba_source
    WHERE name in (''XLA_ACCOUNTING_ENGINE_PKG'',''XLA_ACCOUNTING_PKG'', ''XLA_ACCOUNTING_PUB_PKG'', 
            ''XLA_EVENTS_PKG'', ''XLA_AE_HEADER_PKG'', ''XLA_AE_JOURNAL_ENTRY_PKG'', 
            ''XLA_AE_LINES_PKG'', ''XLA_UTILITY_PKG'', ''XLA_TRANSFER_PKG'',
            ''AP_ACCOUNTING_EVENTS_PKG'',''AP_ACCOUNTING_PAY_PKG'',''AP_ACCTG_PAY_DIST_PKG'', 
            ''AP_ACCTG_PAY_ROUND_PKG'',''AP_ACCTG_PREPAY_DIST_PKG'',''AP_RECONCILIATION_PKG'')
    AND   type = ''PACKAGE BODY''
    and   line = 2
    AND   text like ''%$Header%''
    Union all
    select  upper(af.filename)     FileName , 
            av.version   FileVersion
    from    ad_files af,
            ad_file_versions av
    where   af.file_id= av.file_id
    and     lower(af.filename) in (''sqlapxlaaad.ldt'',''apxlaaad.ldt'')
                            /*,''xlajeaex.pkb'',''xlaapeng.pkb'',
                            ''xlaappub.pkb'', ''xlaevevt.pkb'', ''xlajehdr.pkb'', ''xlajejex.pkb'',
                            ''xlajelns.pkb'', ''xlacmutl.pkb'', ''xlaaptrn.pkb'', ''apeventb.pls'',
                            ''apacpayb.pls'', ''appaydib.pls'', ''apacrndb.pls'', ''appredib.pls'',''apreconb.pls''
                            )*/
    and     version=(select max(version) from ad_file_versions afv  where afv.file_id=af.file_id)
    Order by  text, name',
      p_title                  => 'File versions of accounting packages',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'File versions of accounting packages',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CREATE_ACCTG_FILE_VERSIONS');



debug('begin add_signature: mgd_sig_141');
  add_signature(
      p_sig_id                 => 'mgd_sig_141',
      p_sig_sql                => 'WITH chks AS (
	   select ##$$CHKID$$## check_id from dual
	        )
	        SELECT ''EVENT'' orphan_type,
	               ''N'' processed_flag,
	               ac.check_id,
	               ac.check_number,
	               ac.org_id,
	               xe.event_id,
	               xe.event_status_code,
	               xe.process_status_code,
	               xah.ae_header_id,
	               xte.source_id_int_1 source_id,
	               xte.entity_code source_table,
	               xe.event_date,
	               xe.entity_id,
	               xe.event_type_code,
	               xe.budgetary_control_flag,
	               xe.upg_batch_id
	        FROM chks,
	             ap_checks_all ac,
	             ap_system_parameters_all asp,
	             xla_transaction_entities_upg xte,
	             xla_events xe,
	             xla_ae_headers xah
	        WHERE xe.application_id = xte.application_id
	        AND   xe.event_status_code <> ''P''
	        AND   xe.event_id = xah.event_id (+)
	        AND   xah.application_id(+) = xe.application_id
	        AND   xte.entity_id = xe.entity_id
	        AND   xte.application_id = 200
	        AND   xte.entity_code = ''AP_PAYMENTS''
	        AND   NOT EXISTS (
	                SELECT ''No Inv rows for event'' FROM ap_invoice_distributions_all aid
	                WHERE aid.accounting_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No Dists for bc_event_id'' FROM ap_invoice_distributions_all aid
	                WHERE aid.bc_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No pmt rows for event'' FROM ap_invoice_payments_all aip
	                WHERE aip.accounting_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No pmt hist rows for event'' FROM ap_payment_history_all aph
	                WHERE aph.accounting_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No self assessed tax rows for event''
	                FROM ap_self_assessed_tax_dist_all asatd
	                WHERE asatd.accounting_event_id = xe.event_id)
	        AND    NOT EXISTS (
	                SELECT ''No self assessed tax rows  for bc_event_id''
	                FROM   ap_self_assessed_tax_dist_all asatd
	                WHERE  asatd.bc_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No prepay hist rows for event''
	                FROM ap_prepay_history_all aprh
	                WHERE aprh.accounting_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No prepayment hist rows for bc_event_id''
	                FROM   ap_prepay_history_all apph
	                WHERE  apph.bc_event_id = xe.event_id)
	        AND   xe.event_type_code NOT IN
	                (''MANUAL'', ''REVERSAL'', ''PREPAYMENT APPLICATION ADJ'')
	        AND   (xe.upg_batch_id is null OR xe.upg_batch_id = -9999)
	        AND   NOT EXISTS (
	                SELECT ''No final accounted headers'' FROM   xla_ae_headers xah
	                WHERE  xah.event_id = xe.event_id
	                AND    xah.application_id = 200
	                AND    xah.entity_id = xte.entity_id
	                AND    xah.accounting_entry_status_code = ''F''
	                AND    xah.gl_transfer_status_code = ''Y'')
	        AND   xte.ledger_id = asp.set_of_books_id
	        AND   nvl(xte.source_id_int_1, -99) = ac.check_id
	        AND   asp.org_id = ac.org_id
	        AND   ac.check_id = chks.check_id
	        UNION ALL
	        SELECT ''HEADER'',
	               ''N'',
	               ac.check_id,
	               ac.check_number,
	               ac.org_id,
	               xah.event_id,
	               null,
	               null,
	               xah.ae_header_id,
	               xte.source_id_int_1 source_id,
	               xte.entity_code source_table,
	               xah.accounting_date,
	               xah.entity_id,
	               xah.event_type_code,
	               null,
	               xah.upg_batch_id
	        FROM chks,
	             ap_checks_all ac,
	             ap_system_parameters_all asp,
	             xla_transaction_entities_upg xte,
	             xla_ae_headers xah
	        WHERE xah.application_id = xte.application_id
	        AND   xte.entity_id = xah.entity_id
	        AND   xte.application_id = 200
	        AND   xte.entity_code = ''AP_PAYMENTS''
	        AND   NOT EXISTS (
	                SELECT ''No Invoice rows exist for this event''
	                FROM ap_invoice_distributions_all aid
	                WHERE aid.accounting_event_id = xah.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No Distributions exist for the bc_event_id''
	                FROM ap_invoice_distributions_all aid
	                WHERE aid.bc_event_id = xah.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No payment rows exist for this event''
	                FROM ap_invoice_payments_all aip
	                WHERE aip.accounting_event_id = xah.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No payment history rows exists for this event''
	                FROM ap_payment_history_all aph
	                WHERE aph.accounting_event_id = xah.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No self assessed tax rows exists for this event''
	                FROM ap_self_assessed_tax_dist_all asatd
	                WHERE asatd.accounting_event_id = xah.event_id)
	        AND    NOT EXISTS (
	                SELECT ''No self assessed tax rows exists for the bc_event_id''
	                FROM ap_self_assessed_tax_dist_all asatd
	                WHERE  asatd.bc_event_id = xah.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No prepay history rows exists for this event''
	                FROM ap_prepay_history_all aprh
	                WHERE aprh.accounting_event_id = xah.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No prepayment history rows exists for the bc_event_id''
	                FROM ap_prepay_history_all apph
	                WHERE apph.bc_event_id = xah.event_id)
	        AND   NOT EXISTS (
	                SELECT '' Event for this header does not exist''
	                FROM xla_events xe
	                WHERE xe.application_id = xah.application_id
	                AND   xe.event_id = xah.event_id)
	        AND   xah.event_type_code NOT IN
	                (''MANUAL'', ''REVERSAL'', ''PREPAYMENT APPLICATION ADJ'')
	        AND   (xah.upg_batch_id is null OR xah.upg_batch_id = -9999)
	        AND   nvl(xah.gl_transfer_status_code, ''X'') <> ''Y''
	        AND   nvl(xah.accounting_entry_status_code, ''X'') <> ''F''
	        AND   xte.ledger_id = asp.set_of_books_id
	        AND   nvl(xte.source_id_int_1, -99) = ac.check_id
	        AND   asp.org_id = ac.org_id
	        AND   ac.check_id = chks.check_id
	        UNION ALL
	        SELECT ''EVENT'' orphan_type,
	               ''Y'' processed_flag,
	               ac.check_id,
	               ac.check_number,
	               ac.org_id,
	               xe.event_id,
	               xe.event_status_code,
	               xe.process_status_code,
	               xah.ae_header_id,
	               xte.source_id_int_1 source_id,
	               xte.entity_code source_table,
	               xe.event_date,
	               xe.entity_id,
	               xe.event_type_code,
	               xe.budgetary_control_flag,
	               xe.upg_batch_id
	        FROM chks,
	             ap_checks_all ac,
	             ap_system_parameters_all asp,
	             xla_transaction_entities_upg xte,
	             xla_events xe,
	             xla_ae_headers xah
	        WHERE xe.application_id = 200
	        AND   xe.event_status_code = ''P''
	        AND   xah.application_id = 200
	        AND   xah.event_id = xe.event_id
	        AND   xte.entity_id = xe.entity_id
	        AND   xte.application_id = 200
	        AND   xte.entity_code = ''AP_PAYMENTS''
	        AND   NOT EXISTS (
	                SELECT ''No Inv rows for event'' FROM ap_invoice_distributions_all aid
	                WHERE aid.accounting_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No Dists for bc_event_id'' FROM ap_invoice_distributions_all aid
	                WHERE aid.bc_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No pmt rows for event'' FROM ap_invoice_payments_all aip
	                WHERE aip.accounting_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No pmt hist rows for event'' FROM ap_payment_history_all aph
	                WHERE aph.accounting_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No self assessed tax rows for event''
	                FROM ap_self_assessed_tax_dist_all asatd
	                WHERE asatd.accounting_event_id = xe.event_id)
	        AND    NOT EXISTS (
	                SELECT ''No self assessed tax rows  for bc_event_id''
	                FROM   ap_self_assessed_tax_dist_all asatd
	                WHERE  asatd.bc_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No prepay hist rows for event''
	                FROM ap_prepay_history_all aprh
	                WHERE aprh.accounting_event_id = xe.event_id)
	        AND   NOT EXISTS (
	                SELECT ''No prepayment hist rows for bc_event_id''
	                FROM   ap_prepay_history_all apph
	                WHERE  apph.bc_event_id = xe.event_id)
	        AND   xe.event_type_code NOT IN
	                (''MANUAL'', ''REVERSAL'', ''PREPAYMENT APPLICATION ADJ'')
	        AND   (xe.upg_batch_id is null OR xe.upg_batch_id = -9999)
	        AND   xte.ledger_id = asp.set_of_books_id
	        AND   nvl(xte.source_id_int_1, -99) = ac.check_id
	        AND   asp.org_id = ac.org_id
	        AND   ac.check_id = chks.check_id',
      p_title                  => 'Orphan Payment Accounting Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Orphan accounting events exist in the XLA tables',
      p_solution               => '<ul>
      <li>These orphan records have to be deleted to sucessfully close the period</li>
      <li>Follow the instructions provided in [788135.1]</li>
      </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: mgd_sig_141');



debug('begin add_signature: GL_LEDGERS');
  add_signature(
      p_sig_id                 => 'GL_LEDGERS',
      p_sig_sql                => 'SELECT distinct gl.* 
    FROM  gl_ledgers gl
          , gl_ledger_relationships glr1
          , gl_ledger_relationships glr2
          , gl_ledger_relationships glr3 
    where glr3.source_ledger_id = glr2.primary_ledger_id 
          and glr2.target_ledger_id = glr1.primary_ledger_id 
          and gl.ledger_id = glr1.source_ledger_id 
          and gl.ledger_id IN ( SELECT  asp.set_of_books_id
                          FROM    ap_invoices_all ai,
                                  ap_system_parameters_all asp
                          WHERE   ai.org_id     = asp.org_id 
                          and     ai.invoice_id = NVL(##$$INVID$$##, -99)
                         UNION    
                          SELECT  asp.set_of_books_id
                          FROM    ap_checks_all ac,
                                  ap_system_parameters_all asp
                          WHERE   ac.org_id   = asp.org_id
                          AND     ac.check_id = NVL(##$$CHKID$$##,-99))',
      p_title                  => 'General Ledger Information',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'General Ledger Information',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: GL_LEDGERS');



debug('begin add_signature: mgd_sig_138');
  add_signature(
      p_sig_id                 => 'mgd_sig_138',
      p_sig_sql                => 'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.amount,
            ac.status_lookup_code,
            aph.accounting_event_id,
            aph.posted_flag,
            ac.vendor_id,
            ac.vendor_site_id,
            ac.payment_id,
            ac.payment_document_id
     FROM ap_checks_all ac,
          ap_payment_history_all aph,
          (
            select ##$$CHKID$$## check_id from dual
          ) chks
     WHERE ac.payment_id is null
     AND   ac.status_lookup_code NOT IN (''OVERFLOW'',''SET UP'',''SPOILED'')
     AND   ac.check_id = aph.check_id
     AND   nvl(aph.historical_flag,''N'') <> ''Y''
     AND   aph.posted_flag <> ''Y''
     AND   NOT EXISTS (
             SELECT 1 FROM ap_invoice_payments_all aip
             WHERE aip.check_id = ac.check_id)
     AND   EXISTS  (
             SELECT 1
             FROM ap_invoice_payments_all aip1,
                  ap_checks_all ac1
             WHERE aip1.check_id = ac1.check_id
             AND   ac.org_id = ac1.org_id
             AND   ((ac.vendor_id = ac1.vendor_id AND
                     ac.vendor_site_id = ac1.vendor_site_id) OR
                    ac.payment_document_id = ac1.payment_document_id)
             AND   Ac.check_number = ac1.check_number )
     AND   ac.check_id = chks.check_id',
      p_title                  => 'Orphan Checks',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The orphan checks not paying any invoice and where another check exist with the same check number and vendor information or payment document',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1291659.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: mgd_sig_138');



debug('begin add_signature: GL_PERIOD');
  add_signature(
      p_sig_id                 => 'GL_PERIOD',
      p_sig_sql                => 'SELECT  distinct 
          gps.ledger_id,
          gps.application_id,
          gps.closing_status,
          gps.period_name,
          gps.start_date,
          gps.migration_status_code
            FROM     GL_PERIOD_STATUSES gps,         
                   ( SELECT   distinct accounting_date, set_of_books_id         
                     FROM     AP_INVOICE_DISTRIBUTIONS_ALL         
                     WHERE    invoice_id = nvl(##$$INVID$$##,-99)
                     UNION         
                     SELECT   distinct accounting_date,  set_of_books_id         
                     FROM     AP_INVOICE_PAYMENTS_ALL         
                     WHERE    check_id = nvl(##$$CHKID$$##,-99)
                     UNION         
                     SELECT   distinct accounting_date, -1         
                     FROM     AP_PAYMENT_HISTORY_ALL         
                     WHERE    check_id = nvl(##$$CHKID$$##,-99)
                     ) atg_date         
            WHERE   atg_date.accounting_date between gps.start_date and gps.end_date         
            AND     gps.application_id in (101,200)         
            AND     gps.set_of_books_id = atg_date.set_of_books_id',
      p_title                  => 'GL and AP Period Status Check',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'GL and AP Period Status Check',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: GL_PERIOD');



debug('begin add_signature: XLA_EVENTS_INV');
  add_signature(
      p_sig_id                 => 'XLA_EVENTS_INV',
      p_sig_sql                => 'SELECT xte.ledger_id        LEDGER_ID,
       xte.source_id_int_1      SOURCE_ID_INT_1,
       xte.security_id_int_1    SECURITY_ID_INT_1,
       xte.entity_code          ENTITY_CODE,
       xte.legal_entity_id      LEGAL_ENTITY_ID,
       xle.event_status_code    EVENT_STATUS_CODE,
       xle.process_status_code  PROCESS_STATUS_CODE,
       xle.application_id       APPLICATION_ID,
       xle.event_id             EVENT_ID,
       xle.event_number         EVENT_NUMBER,
       xle.on_hold_flag         ON_HOLD_FLAG,
       xle.event_type_code      EVENT_TYPE_CODE,
       xle.event_date           EVENT_DATE,
       xte.transaction_number   TRANSACTION_NUMBER,
       xle.last_update_date     LAST_UPDATE_DATE ,
       xle.creation_date        CREATION_DATE,
       xle.transaction_date     TRANSACTION_DATE
  FROM   xla_events xle,
       xla.xla_transaction_entities xte,
       xla_ledger_options xlo,
        (
        ##$$IVIEW$$##
        ) invs
  WHERE  xle.entity_id = xte.entity_id
       AND xle.application_id = xte.application_id
       and xte.source_id_int_1 = invs.invoice_id
       AND xle.application_id = 200
       AND xle.event_status_code IN (''I'',''U'')
       AND xle.process_status_code IN (''I'',''U'',''R'',''D'',''E'')
       AND xle.application_id = xlo.application_id
       AND xlo.capture_event_flag = ''Y''
       AND EXISTS (SELECT 1
                   FROM   gl_ledger_relationships glr1,
                          gl_ledger_relationships glr2
                   WHERE  glr1.target_ledger_id = xlo.ledger_id
                          AND glr2.target_ledger_id in ( SELECT set_of_books_id 
                          FROM   AP_SYSTEM_PARAMETERS_ALL WHERE  org_id in (##$$ORGS$$##))
                          AND glr2.source_ledger_id = glr1.source_ledger_id
                          AND glr2.application_id = glr1.application_id
                          AND (glr1.target_ledger_id = xte.ledger_id
                                OR glr1.primary_ledger_id = xte.ledger_id)
                          AND (glr1.relationship_type_code = ''SUBLEDGER''
                                OR (glr1.target_ledger_category_code = ''PRIMARY''
                                    AND glr1.relationship_type_code = ''NONE''))
                          AND glr2.application_id = 101)
       AND xte.application_id = 200',
      p_title                  => 'Unaccounted Invoices',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unaccounted invoices exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the event(s).</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: XLA_EVENTS_INV');



debug('begin add_signature: AP_INVOICE_DISTRIBUTIONS_ALL_O');
  add_signature(
      p_sig_id                 => 'AP_INVOICE_DISTRIBUTIONS_ALL_O',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            ai.invoice_date,
            asu.vendor_name,
            assi.vendor_site_code,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.line_type_lookup_code,
            aid.invoice_distribution_id,
            aid.amount,
            aid.base_amount,
            aid.accounting_event_id,
            aid.posted_flag,
            aid.detail_tax_dist_id,
            aid.set_of_books_id
     FROM ap_invoice_distributions_all aid,
          ap_invoices_all ai,
          ap_suppliers asu,
          ap_supplier_sites_all assi,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE nvl(aid.historical_flag, ''N'') = ''N''
     AND   aid.invoice_id = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   (NOT EXISTS (
               SELECT 1 FROM ap_invoice_lines_all l
               WHERE l.invoice_id = aid.invoice_id
               AND   l.line_number = aid.invoice_line_number) OR
            aid.parent_reversal_id IN (
               SELECT p.invoice_distribution_id FROM ap_invoice_distributions_all p
               WHERE NOT EXISTS (
                 SELECT 1 FROM ap_invoice_lines_all l
                 WHERE l.invoice_id = p.invoice_id
                 AND   l.line_number = p.invoice_line_number)))
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Orphan Invoice Distributions With No Corresponding Invoice Line',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The Invoice distributions(both Posted/Unposted) which do not have corresponding invoice lines',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1060644.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_INVOICE_DISTRIBUTIONS_ALL_O');



debug('begin add_signature: EVENT_SUMMARY');
  add_signature(
      p_sig_id                 => 'EVENT_SUMMARY',
      p_sig_sql                => 'select  xte.entity_id,        xte.entity_code,        xte.source_id_int_1,  xte.transaction_number, 
               xte.ledger_id,        xte.security_id_int_1,  xe.event_id,          xe.event_date, 
               xe.event_type_code,   xe.event_status_code,   xe.process_status_code,xe.upg_batch_id, 
               xe.budgetary_control_flag
       from    xla_events xe, 
               xla.xla_transaction_entities xte
       where   xte.application_id  = 200
       and     xe.application_id   = 200
       and     xte.application_id  = xe.application_id
       and     xte.entity_id       = xe.entity_id
       and     xte.entity_code     = ''AP_PAYMENTS''
       and     xte.source_id_int_1 = ##$$CHKID$$##
   UNION
   select  xte.entity_id,        xte.entity_code,        xte.source_id_int_1,  xte.transaction_number, 
               xte.ledger_id,        xte.security_id_int_1,  xe.event_id,          xe.event_date, 
               xe.event_type_code,   xe.event_status_code,   xe.process_status_code,xe.upg_batch_id, 
               xe.budgetary_control_flag
       from    xla_events xe, 
               xla.xla_transaction_entities xte
       where   xte.application_id  = 200
       and     xe.application_id   = 200
       and     xte.application_id  = xe.application_id
       and     xte.entity_id       = xe.entity_id
       and     xte.entity_code     = ''AP_INVOICES''
       and     xte.source_id_int_1 = ##$$INVID$$##
    order by 2',
      p_title                  => 'Event Summary',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Event Summary',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: EVENT_SUMMARY');



debug('begin add_signature: SLAM');
  add_signature(
      p_sig_id                 => 'SLAM',
      p_sig_sql                => 'SELECT distinct xam.* FROM xla_acctg_methods_fvl xam
    where  xam.accounting_method_code in (SELECT gl.sla_accounting_method_code
                                      FROM    gl.gl_ledgers gl
                                      WHERE   gl.ledger_id in 
                                      (SELECT asp.set_of_books_id
                                      FROM    ap_invoices_all ai,
                                              ap_system_parameters_all asp
                                      WHERE   ai.org_id     = asp.org_id 
                                      AND     ai.invoice_id = NVL(##$$INVID$$##, -99)
                                      UNION
                                      SELECT  asp.set_of_books_id
                                      FROM    ap_checks_all ac,
                                              ap_system_parameters_all asp
                                      WHERE   ac.org_id   = asp.org_id
                                      AND     ac.check_id = NVL(##$$CHKID$$##,-99)
                                      ))',
      p_title                  => 'SubLedger Accounting Method (SLAM)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'SubLedger Accounting Method (SLAM)',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SLAM');



debug('begin add_signature: ap_orphan_upg_events_sel');
  add_signature(
      p_sig_id                 => 'ap_orphan_upg_events_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai, xte, xe) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xe.event_type_code,
            xe.event_status_code,
            xe.process_status_code,
            xe.event_date,
            xte.entity_id,
            xte.source_id_int_1,
            fsp.purch_encumbrance_flag
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          financials_system_params_all fsp,
          xla_transaction_entities_upg xte,
          xla_events xe
     WHERE xe.application_id = 200
     AND   xe.application_id = xte.application_id
     AND   xe.event_type_code IN (''INVOICE VALIDATED'',
             ''INVOICE ADJUSTED'', ''INVOICE ADJUSTMENT'',
             ''INVOICE CANCELLED'', ''PREPAYMENT VALIDATED'',
             ''PREPAYMENT ADJUSTED'', ''PREPAYMENT CANCELLED'',
             ''DEBIT MEMO VALIDATED'', ''DEBIT MEMO ADJUSTED'',
             ''DEBIT MEMO CANCELLED'', ''CREDIT MEMO VALIDATED'',
             ''CREDIT MEMO ADJUSTED'', ''CREDIT MEMO CANCELLED'')
     AND   xe.event_type_code NOT IN (''MANUAL'', ''REVERSAL'')
     AND   xe.upg_batch_id is not null
     AND   xe.upg_batch_id <> -9999
     AND   nvl(xe.budgetary_control_flag, ''N'') = ''N''
     AND   xe.entity_id = xte.entity_id
     AND   xte.entity_code = ''AP_INVOICES''
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   ai.set_of_books_id = xte.ledger_id
     AND   ai.set_of_books_id = fsp.set_of_books_id
     AND   ai.org_id = fsp.org_id
     AND   NOT EXISTS (
             SELECT ''missing acctg evt for aprvd dists''
             FROM ap_invoice_distributions_all aid
             WHERE aid.invoice_id = ai.invoice_id
             AND   aid.historical_flag = ''Y''
             AND   aid.accounting_event_id is null
             AND   (aid.match_status_flag = ''A'' OR
                    (aid.match_status_flag IN (''A'', ''T'') AND
                     purch_encumbrance_flag = ''N'')))
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */
                    ''No Invoice rows exist for this event''
             FROM ap_invoice_distributions_all aid
             WHERE aid.accounting_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */
                    ''No Distributions exist for the bc_event_id''
             FROM ap_invoice_distributions_all aid
             WHERE aid.bc_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */
                    ''No payment rows exist for this event''
             FROM ap_invoice_payments_all aip
             WHERE aip.accounting_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */
                    ''No payment history rows exist for this event''
             FROM ap_payment_history_all aph
             WHERE aph.accounting_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */
                    ''No self assessed tax rows exist for this event''
             FROM ap_self_assessed_tax_dist_all asatd
             WHERE asatd.accounting_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */
                    ''No self assessed tax rows exist for the bc_event_id''
             FROM ap_self_assessed_tax_dist_all asatd
             WHERE asatd.bc_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */
                    ''No prepay history rows exist for this event''
             FROM ap_prepay_history_all aprh
             WHERE aprh.accounting_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */
                    ''No prepayment history rows exist for the bc_event_id''
             FROM ap_prepay_history_all apph
             WHERE apph.bc_event_id = xe.event_id)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Orphan Upgraded Invoice Accounting Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Orphan upgraded invoice accounting events not associated to any transaction',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1333548.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_orphan_upg_events_sel');



debug('begin add_signature: AADS');
  add_signature(
      p_sig_id                 => 'AADS',
      p_sig_sql                => 'select  distinct xpr.*, DOB.owner,  dob.object_name,  dob.status,             dob.last_ddl_time
       FROM    xla_product_rules_fvl xpr,   dba_objects dob
       where   dob.object_name like ''XLA_00200_AAD_%_''||lpad(xpr.product_rule_hash_id,6,0)||''_PKG''
       and     xpr.application_id = 200
       and     object_type = ''PACKAGE BODY''
       and     xpr.product_rule_code in (select xamr.product_rule_code
                                     from    xla_acctg_method_rules_fvl xamr
                                     where   application_id = 200
                                     and     sysdate <= nvl(end_date_active, sysdate)
                                     and     amb_context_code = ''DEFAULT''
                                     and     xamr.accounting_method_code in
                                     (select  gl.sla_accounting_method_code
                                     from    gl.gl_ledgers gl
                                     where   gl.ledger_id in 
                                     ( SELECT  asp.set_of_books_id
                                       FROM    ap_invoices_all ai,
                                               ap_system_parameters_all asp
                                       WHERE   ai.org_id     = asp.org_id 
                                       and     ai.invoice_id = NVL(##$$INVID$$##, -99)
                                      UNION    
                                       SELECT  asp.set_of_books_id
                                       FROM    ap_checks_all ac,
                                               ap_system_parameters_all asp
                                       WHERE   ac.org_id   = asp.org_id
                                       AND     ac.check_id = NVL(##$$CHKID$$##,-99))))',
      p_title                  => 'Payables Application Accounting Definition assigned to SLAM',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Payables Application Accounting Definition assigned to SLAM',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AADS');



debug('begin add_signature: AUTORATE_PAYMENT');
  add_signature(
      p_sig_id                 => 'AUTORATE_PAYMENT',
      p_sig_sql                => 'select  aph.PAYMENT_HISTORY_ID,         aph.CHECK_ID,               aph.ACCOUNTING_DATE, 
            aph.TRANSACTION_TYPE,           aph.POSTED_FLAG,            aph.PMT_CURRENCY_CODE, 
            asp.base_currency_code,         aph.PMT_TO_BASE_XRATE_TYPE, aph.PMT_TO_BASE_XRATE_DATE, 
            aph.PMT_TO_BASE_XRATE,          ac.check_number,            ac.vendor_name, 
            ac.check_date
    from    AP_PAYMENT_HISTORY_ALL aph,
            ap_checks_all ac,
            ap_system_parameters_all asp
    where   aph.pmt_currency_code         != asp.base_currency_code
    and     asp.org_id                    = aph.org_id
    and     aph.check_id                  = ac.check_id
    and     ac.check_id                   = NVL(##$$CHKID$$##,-99)
    and     nvl(aph.pmt_to_base_xrate,0)  = 0',
      p_title                  => 'Check Autorate For Payment',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The conversion rate for the relevant currencies and conversion date is missing in General Ledger',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [834251.1] </li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AUTORATE_PAYMENT');



debug('begin add_signature: XLA_AE_ERRORS_INV');
  add_signature(
      p_sig_id                 => 'XLA_AE_ERRORS_INV',
      p_sig_sql                => 'SELECT aeh.ledger_id           LEDGER_ID,
       aeh.ae_header_id        AE_HEADER_ID,
       xte.source_id_int_1     SOURCE_ID_INT_1,
       aeh.ACCOUNTING_DATE     ACCOUNTING_DATE,
       xte.entity_code         ENTITY_CODE,
       xte.security_id_int_1   SECURITY_ID_INT_1,
       xte.transaction_number  TRANSACTION_NUMBER,
       xte.entity_id           ENTITY_ID,
       xte.legal_entity_id     LEGAL_ENTITY_ID,
       xle.event_type_code     EVENT_TYPE_CODE,
       xle.event_date          EVENT_DATE,
       xle.last_update_date    LAST_UPDATE_DATE ,
       xle.creation_date       CREATION_DATE,
       xle.transaction_date    TRANSACTION_DATE,
       aeh.event_id            EVENT_ID,
       aeh.application_id      APPLICATION_ID,
       aeh.accounting_entry_status_code            ACCOUNTING_ENTRY_STATUS_CODE,
       aeh.gl_transfer_status_code                 GL_TRANSFER_STATUS_CODE,
       xae.ENCODED_MSG  ACCOUNTING_ERROR_MESSAGE
      FROM   xla_ae_headers aeh,
             xla_events xle,
             xla_accounting_errors xae,
             xla.xla_transaction_entities xte,
            (
            ##$$IVIEW$$##
            ) invs
      WHERE  EXISTS (SELECT 1
                     FROM   gl_ledger_relationships glr1,
                            gl_ledger_relationships glr2
                     WHERE  aeh.ledger_id = glr2.target_ledger_id
                            AND glr2.source_ledger_id = glr1.source_ledger_id
                            AND glr2.application_id = glr1.application_id
                      AND glr1.target_ledger_id in ( SELECT set_of_books_id
                                                           FROM   AP_SYSTEM_PARAMETERS_ALL
                                                            WHERE  org_id in (##$$ORGS$$##))
                    AND glr1.application_id = 101)
             AND xte.entity_id = aeh.entity_id
             and aeh.ae_header_id(+)=xae.ae_header_id
             AND xte.application_id = aeh.application_id
             AND aeh.accounting_entry_status_code !=  (''F'')
             AND xle.Process_status_code = ''I''
             AND xle.event_id = aeh.event_id
             AND xle.application_id = aeh.application_id
             and xte.source_id_int_1 = invs.invoice_id      
             AND xte.application_id = 200',
      p_title                  => 'Invoice with Accounting Errors',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Transactions with accounting errors',
      p_solution               => '<ul>
   <li>Review each error message and follow instructions to resolve if provided.</li>
   <li>Review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: XLA_AE_ERRORS_INV');



debug('begin add_signature: out_of_sync_pay');
  add_signature(
      p_sig_id                 => 'out_of_sync_pay',
      p_sig_sql                => 'select distinct aip.check_id,aip.ACCOUNTING_date aip_accounting_date,
                       XE.EVENT_DATE XE_ACCOUNTING_DATE,XE.EVENT_ID xe_accounting_event_id
                       ,AH.accounting_date xla_header_date
                       ,AH.period_name xla_header_period
                  from AP_INVOICE_PAYMENTS_ALL aip
                       ,XLA_EVENTS XE
                       ,XLA_AE_HEADERS AH
              where aip.ACCOUNTING_EVENT_ID = XE.EVENT_ID
                  and xe.application_id = 200
                  and xe.event_id = AH.event_id (+)
                  and trunc(aip.ACCOUNTING_date) <> trunc(XE.EVENT_DATE)
                AND    aip.check_id = NVL(##$$CHKID$$##,-99)
                and ah.accounting_entry_status_code<>''F''',
      p_title                  => 'Date Out-of-sync(Payments)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment records where the accounting date is different from the date on the accounting event',
      p_solution               => '<ul>
   <li>If the accounting date is in the current period, and the item is not accounted, it may cause a problem with closing</li>
   <li>Follow the instructions provided in [874904.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: out_of_sync_pay');



debug('begin add_signature: CUSTOM_AAD');
  add_signature(
      p_sig_id                 => 'CUSTOM_AAD',
      p_sig_sql                => 'select  distinct xpr.* from xla_product_rules_fvl xpr 
       where   xpr.application_id = 200
       and   product_rule_type_code    != ''S''
       and     xpr.product_rule_code in (select xamr.product_rule_code
                                     from    xla_acctg_method_rules_fvl xamr
                                     where   application_id = 200
                                     and     sysdate <= nvl(end_date_active, sysdate)
                                     and     amb_context_code = ''DEFAULT''
                                     and     xamr.accounting_method_code in 
                                     (select  gl.sla_accounting_method_code
                                     from    gl.gl_ledgers gl
                                     where   gl.ledger_id IN 
                                    (SELECT  asp.set_of_books_id
                                     FROM    ap_invoices_all ai,
                                             ap_system_parameters_all asp
                                     WHERE   ai.org_id     = asp.org_id 
                                     and     ai.invoice_id = NVL(##$$INVID$$##, -99)
                                    UNION    
                                     SELECT  asp.set_of_books_id
                                     FROM    ap_checks_all ac,
                                             ap_system_parameters_all asp
                                     WHERE   ac.org_id   = asp.org_id
                                  AND     ac.check_id = NVL(##$$CHKID$$##,-99))))',
      p_title                  => 'Custom/Modified Application Accounting Definition (AAD)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'A non-seeded subLedger accounting method has been detected',
      p_solution               => '<ul>
   <li>The accounting issue may be due to incorrect setup of the non-seeded AAD or bug fix delivered for seeded SLA setup e.g.  JLD, JLT, ADR, etc... that are not included in the corresponding non-seeded/copied version. </li>
   <li>For solution:  If accounting is in error or is created incorrectly, you need to review any of your modifications that may have caused this, try accounting using seeded AAD on test instance if applicable.</li>
   <li>Also, review Doc ID [1359966.1] to look for any manual bug updates needed for copied SLA setup e.g.  JLD, JLT, ADR, etc...</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CUSTOM_AAD');



debug('begin add_signature: AP_INVOICE_PAYMENTS_ALL');
  add_signature(
      p_sig_id                 => 'AP_INVOICE_PAYMENTS_ALL',
      p_sig_sql                => 'SELECT  aip.invoice_payment_id,
            ac.check_number,
            aip.accounting_event_id,
            aip.accounting_date,
            aip.check_id,
            aip.amount,
            aip.org_id,
            ac.exchange_rate,
            ac.check_date,
            ac.legal_entity_id,
            ac.vendor_name,
            ac.bank_account_name,
            ac.amount,
            ac.currency_code,
            ac.status_lookup_code,
            ac.party_id,
            ac.vendor_id
    FROM    ap_invoice_payments_all aip,
            ap_checks_All ac
    WHERE   aip.posted_flag IN (''N'',''S'')
    AND     ac.check_id = aip.check_id
    and     ac.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Unposted Payments',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unaccounted payments exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the payment event(s).</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_INVOICE_PAYMENTS_ALL');



debug('begin add_signature: out_of_sync_pay_hist');
  add_signature(
      p_sig_id                 => 'out_of_sync_pay_hist',
      p_sig_sql                => 'select distinct aph.check_id,aph.ACCOUNTING_date aph_accounting_date,
                       XE.EVENT_DATE XE_ACCOUNTING_DATE,XE.EVENT_ID xe_accounting_event_id
                       ,AH.accounting_date xla_header_date
                       ,AH.period_name xla_header_period
         from AP_PAYMENT_HISTORY_ALL aph,XLA_EVENTS XE
              ,XLA_AE_HEADERS AH
        where aph.ACCOUNTING_EVENT_ID = XE.EVENT_ID
          and xe.application_id = 200
          and xe.event_id = AH.event_id (+)
          and trunc(aph.ACCOUNTING_date) <> trunc(XE.EVENT_DATE)
        AND aph.check_id = NVL(##$$CHKID$$##,-99)
        and ah.accounting_entry_status_code<>''F''',
      p_title                  => 'Dates Out-of-sync (Payment History)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accounting date in transactional table is not in sync with the events table',
      p_solution               => '<ul>
   <li>If the accounting date is in the current period, and the item is not accounted, it may cause a problem with closing</li>
   <li>Follow the instructions provided in [874904.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: out_of_sync_pay_hist');



debug('begin add_signature: XLA_AE_HEADERS_INV');
  add_signature(
      p_sig_id                 => 'XLA_AE_HEADERS_INV',
      p_sig_sql                => 'SELECT aeh.ledger_id           LEDGER_ID,
       aeh.ae_header_id        AE_HEADER_ID,
       xte.source_id_int_1     SOURCE_ID_INT_1,
       aeh.ACCOUNTING_DATE     ACCOUNTING_DATE,
       xte.entity_code         ENTITY_CODE,
       xte.security_id_int_1   SECURITY_ID_INT_1,
       xte.transaction_number  TRANSACTION_NUMBER,
       xte.entity_id           ENTITY_ID,
       xte.legal_entity_id     LEGAL_ENTITY_ID,
       xle.event_type_code     EVENT_TYPE_CODE,
       xle.event_date          EVENT_DATE,
       xle.last_update_date    LAST_UPDATE_DATE ,
       xle.creation_date       CREATION_DATE,
       xle.transaction_date    TRANSACTION_DATE,
       aeh.event_id            EVENT_ID,
       aeh.application_id      APPLICATION_ID,
       aeh.accounting_entry_status_code            ACCOUNTING_ENTRY_STATUS_CODE,
       aeh.gl_transfer_status_code                 GL_TRANSFER_STATUS_CODE
      FROM   xla_ae_headers aeh,
             xla_events xle,
             xla.xla_transaction_entities xte,
            (
            ##$$IVIEW$$##
            ) invs
      WHERE  EXISTS (SELECT 1
                     FROM   gl_ledger_relationships glr1,
                            gl_ledger_relationships glr2
                     WHERE  aeh.ledger_id = glr2.target_ledger_id
                            AND glr2.source_ledger_id = glr1.source_ledger_id
                            AND glr2.application_id = glr1.application_id
                            AND glr1.target_ledger_id in ( SELECT set_of_books_id
                                                             FROM   AP_SYSTEM_PARAMETERS_ALL
                                                            WHERE  org_id in (##$$ORGS$$##))
                            AND glr1.application_id = 101)
             AND xte.entity_id = aeh.entity_id
             AND xte.application_id = aeh.application_id
             AND aeh.gl_transfer_status_code IN (''N'',''E'')
             AND xle.event_status_code = ''P''
             AND xle.event_id = aeh.event_id
             AND xle.application_id = aeh.application_id
             and xte.source_id_int_1 = invs.invoice_id
             AND xte.application_id = 200',
      p_title                  => 'Unposted Invoice Accounting Headers',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accounted invoices which are not transferred to General Ledger',
      p_solution               => '<ul>
   <li>If the transactions listed are final accounted, then please run Transfer to General Ledger process and post these items to GL.</li>
   <li>If the accounting of these transactions are unsuccessful, then the Subledger Accounting Program Report should show the reasons why accounting failed.</li>
   <li>Follow the instructions provided in [560378.1] for more information on sweeping process</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: XLA_AE_HEADERS_INV');



debug('begin add_signature: AP_SELF_ASSESSED_TAX_DIST_ALL_O');
  add_signature(
      p_sig_id                 => 'AP_SELF_ASSESSED_TAX_DIST_ALL_O',
      p_sig_sql                => 'select *
       from ap.ap_self_assessed_tax_dist_all satd
      where not exists (select 1
                        from ap.ap_invoice_distributions_all aid,
                         (
                          ##$$IVIEW$$##
                          ) invs
                         where aid.invoice_distribution_id = satd.charge_applicable_to_dist_id
                         and  aid.invoice_id    = invs.invoice_id)
        and satd.org_id in (##$$ORGS$$##)',
      p_title                  => 'Orphan Self Assessed Tax',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The self assessed tax distribution lines without a corresponding parent record exist in the ap_invoice_distributions_all table',
      p_solution               => '<ul>
   <li>Please run the AP Data Validation Report for the transactions listed</li>
   <li>Follow the instructions provided in [1360390.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_SELF_ASSESSED_TAX_DIST_ALL_O');



debug('begin add_signature: SHOW_AAD');
  add_signature(
      p_sig_id                 => 'SHOW_AAD',
      p_sig_sql                => 'select  distinct xpr.* from xla_product_rules_fvl xpr 
    where   xpr.application_id = 200
    and     compile_status_code in (''N'',''E'')
    and     xpr.product_rule_code in (select xamr.product_rule_code
                                  from    xla_acctg_method_rules_fvl xamr
                                  where   application_id = 200
                                  and     sysdate <= nvl(end_date_active, sysdate)
                                  and     amb_context_code = ''DEFAULT''
                                  and     xamr.accounting_method_code in 
                                  (select gl.sla_accounting_method_code
                                  from    gl.gl_ledgers gl
                                  where   gl.ledger_id in 
                                  (SELECT  asp.set_of_books_id
                                  FROM    ap_invoices_all ai,
                                          ap_system_parameters_all asp
                                  WHERE   ai.org_id     = asp.org_id 
                                  and     ai.invoice_id = NVL(##$$INVID$$##, -99)
                                 UNION    
                                  SELECT  asp.set_of_books_id
                                  FROM    ap_checks_all ac,
                                          ap_system_parameters_all asp
                                  WHERE   ac.org_id   = asp.org_id
                                  AND     ac.check_id = NVL(##$$CHKID$$##,-99))))',
      p_title                  => 'Application Accounting Definition',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Application accounting definition is not validated or invalid',
      p_solution               => '<ul>
   <li>Please run the Validate Application Accounting Definitions program</li>
   <li>Follow the instructions provided in [1406203.1] </li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHOW_AAD');



debug('begin add_signature: AP_INVOICE_DIST_ALL');
  add_signature(
      p_sig_id                 => 'AP_INVOICE_DIST_ALL',
      p_sig_sql                => 'select     ai.invoice_id
                ,ai.invoice_num
                ,aid.invoice_distribution_id
                ,aid.awt_invoice_payment_id 
                ,aid.accounting_event_id
                ,AP_INVOICES_PKG.GET_APPROVAL_STATUS
            (
             ai.INVOICE_ID
            ,ai.INVOICE_AMOUNT
            ,ai.PAYMENT_STATUS_FLAG
            ,ai.INVOICE_TYPE_LOOKUP_CODE
            ) Approval_Status
                ,aid.accounting_date
                ,aid.org_id
                ,ai.invoice_currency_code
                    ,ai.party_id
                ,ai.vendor_id
                ,ai.doc_sequence_value
                ,ai.voucher_num
                ,ai.invoice_date
                ,ai.invoice_amount
                ,ai.cancelled_date
                ,aid.match_status_flag
                ,ai.legal_entity_id
                ,aid.po_distribution_id
                ,aid.amount
                ,aid.detail_tax_dist_id
                   ,aid.invoice_line_number
      from
                ap_invoices_all ai,
                ap_invoice_distributions_all aid,
                (
                ##$$IVIEW$$##
                ) invs
      where ai.invoice_id = aid.invoice_id
        and aid.invoice_distribution_id = invs.invoice_distribution_id
        and     ai.approval_ready_flag <> ''S''
        and     aid.posted_flag  in (''N'' , ''S'', ''P'')',
      p_title                  => 'Unposted Invoices Distributions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unposted invoice distributions exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the distribution(s).</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_INVOICE_DIST_ALL');



debug('begin add_signature: missing_XDL_pay');
  add_signature(
      p_sig_id                 => 'missing_XDL_pay',
      p_sig_sql                => 'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            xe.event_id,
            xte.entity_id,
            xah.ae_header_id,
            xte.source_id_int_1 transaction_id,
            xte.transaction_number,
            xte.entity_code,
            xte.ledger_id
     FROM xla_events xe,
          xla_transaction_entities_upg xte,
          ap_checks_all ac,
          gl_period_statuses upg,
          ap_system_parameters_all asp,
          xla_ae_headers xah,
          xla_ae_lines xal
     WHERE xe.application_id = 200
     AND   xe.event_status_code = ''P''
     AND   xe.upg_batch_id is not null
     AND   xe.upg_batch_id <> - 9999
     AND   xah.application_id = 200
     AND   xal.application_id = 200
     AND   xah.event_id = xe.event_id
     AND   xah.ae_header_id = xal.ae_header_id
     AND   xah.upg_batch_id is not null
     AND   xte.application_id = 200
     AND   xte.ledger_id = xah.ledger_id
     AND   xte.entity_code = ''AP_PAYMENTS''
     AND   xte.entity_id = xe.entity_id
     AND   ac.check_id = nvl(xte.source_id_int_1,-99)
     AND   upg.application_id = xte.application_id
     AND   upg.ledger_id = xte.ledger_id
     AND   upg.set_of_books_id = asp.set_of_books_id
     AND   asp.set_of_books_id = xte.ledger_id
     AND   asp.org_id = ac.org_id
     AND   ac.check_date BETWEEN upg.start_date AND upg.end_date
     AND   upg.migration_status_code = ''U''
     AND   upg.closing_status in (''O'' ,''C'',''P'')
     AND   trunc(upg.start_date) < (
             SELECT min(trunc(creation_date)) FROM ad_applied_patches
             WHERE patch_type = ''MAINTENANCE-PACK''
             AND   maint_pack_level LIKE ''12.%'')
     AND   EXISTS (
             SELECT 1 FROM ap_invoice_payments_all aip
             WHERE aip.check_id = ac.check_id)
     AND   NOT EXISTS (
             SELECT 1 FROM xla_distribution_links xdl
             WHERE xdl.application_id = 200
             AND   xdl.ae_header_id = xah.ae_header_id
             AND   xdl.ae_line_num = xal.ae_line_num)
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Missing Records in XDL - Payments',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Missing records exist in XLA_DISTRIBUTION_LINKS for migrated transactions',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1054299.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: missing_XDL_pay');



debug('begin add_signature: out_of_sync');
  add_signature(
      p_sig_id                 => 'out_of_sync',
      p_sig_sql                => 'select distinct aid.invoice_id
                    ,aid.ACCOUNTING_date aid_accounting_date
                    ,aid.period_name aid_period_name
                    ,XE.EVENT_DATE xla_event_date
                    ,XE.EVENT_ID xe_accounting_event_id
                    ,AH.accounting_date xla_header_date
                    ,AH.period_name xla_header_period
               from AP_INVOICE_DISTRIBUTIONS_ALL aid
                    ,XLA_EVENTS XE
                    ,XLA_AE_HEADERS AH,
                    (
                    ##$$IVIEW$$##
                    ) invs
              where aid.ACCOUNTING_EVENT_ID = XE.EVENT_ID
                and aid.invoice_distribution_id = invs.invoice_distribution_id
                and xe.event_id = AH.event_id (+)
                and xe.application_id = 200
                and trunc(aid.ACCOUNTING_date) <> trunc(XE.EVENT_DATE)
                and AH.accounting_entry_status_code<>''F''',
      p_title                  => 'Dates Out-of-sync(Distributions)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice distribution records where the accounting date is different from the date on the accounting event',
      p_solution               => '<ul>
   <li>If the accounting date is in the current period, and the item is not accounted, it may cause a problem with closing</li>
   <li>Follow the instructions provided in [874904.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: out_of_sync');



debug('begin add_signature: AP_PAYMENT_HISTORY_ALL');
  add_signature(
      p_sig_id                 => 'AP_PAYMENT_HISTORY_ALL',
      p_sig_sql                => 'SELECT  aph.payment_history_id,
            ac.check_number,
            aph.accounting_event_id,
            aph.accounting_date,
            aph.check_id,
            aph.transaction_type,
            aph.org_id,
            ac.exchange_rate,
            ac.check_date,
            ac.legal_entity_id,
              ac.vendor_name,
            ac.bank_account_name,
                ac.amount,
            ac.currency_code,
              ac.party_id,
            ac.vendor_id
    FROM    ap_payment_history_all aph,
            ap_checks_all ac
    WHERE  aph.posted_flag IN (''N'',''S'')
    AND    ac.check_id = aph.check_id
    AND    ac.check_id =  NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Unposted Payment Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unaccounted payment events exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the payment event(s).</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_PAYMENT_HISTORY_ALL');



debug('begin add_signature: STUCK_AAD');
  add_signature(
      p_sig_id                 => 'STUCK_AAD',
      p_sig_sql                => 'select  distinct xpr.* from xla_product_rules_fvl xpr 
    where   xpr.application_id = 200
    and     compile_status_code = ''R''
    and     xpr.product_rule_code in (select xamr.product_rule_code
                                  from    xla_acctg_method_rules_fvl xamr
                                  where   application_id = 200
                                  and     sysdate <= nvl(end_date_active, sysdate)
                                  and     amb_context_code = ''DEFAULT''
                                  and     xamr.accounting_method_code in 
                                  (select gl.sla_accounting_method_code
                                  from    gl.gl_ledgers gl
                                  where   gl.ledger_id in 
                                  (SELECT  asp.set_of_books_id
                                  FROM    ap_invoices_all ai,
                                          ap_system_parameters_all asp
                                  WHERE   ai.org_id     = asp.org_id 
                                  and     ai.invoice_id = NVL(##$$INVID$$##, -99)
                                 UNION    
                                  SELECT  asp.set_of_books_id
                                  FROM    ap_checks_all ac,
                                          ap_system_parameters_all asp
                                  WHERE   ac.org_id   = asp.org_id
                                  AND     ac.check_id = NVL(##$$CHKID$$##,-99))))',
      p_title                  => 'Application Accounting Definitions Stuck In Validating',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'AAD is stuck in validation status',
      p_solution               => '<ul>
   <li>Please run the Validate Application Accounting Definitions program</li>
   <li>Follow the instructions provided in [1406203.1] </li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: STUCK_AAD');



debug('begin add_signature: AP_INVOICE_DIST_ALL_E');
  add_signature(
      p_sig_id                 => 'AP_INVOICE_DIST_ALL_E',
      p_sig_sql                => 'select     ai.invoice_id
                ,ai.invoice_num
                ,aid.invoice_distribution_id
                    ,aid.awt_invoice_payment_id 
                    ,aid.accounting_event_id
                ,aid.accounting_date
                ,aid.org_id
                ,ai.invoice_currency_code
                    ,ai.party_id
                ,ai.vendor_id
                ,ai.doc_sequence_value
                ,ai.voucher_num
                ,ai.invoice_date
                ,ai.invoice_amount
                ,ai.cancelled_date
                ,aid.match_status_flag
                ,ai.legal_entity_id
                ,aid.po_distribution_id
                ,aid.amount
                ,aid.detail_tax_dist_id
                ,aid.invoice_line_number
      from
                ap_invoices_all ai,
                ap_invoice_distributions_all aid,
                (
                ##$$IVIEW$$##
                ) invs
      where ai.invoice_id = aid.invoice_id
        and aid.invoice_distribution_id = invs.invoice_distribution_id
        and     aid.bc_event_id is not null
        and     nvl(aid.encumbered_flag, ''N'') in (''N'', ''H'', ''P'')
        and     ai.approval_ready_flag <> ''S''
        and     aid.posted_flag  in (''N'' , ''S'', ''P'')',
      p_title                  => 'Unposted Invoices Distributions - Encumbrance',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unposted invoice distributions - encumbrance exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the distribution(s).</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_INVOICE_DIST_ALL_E');



debug('begin add_signature: ap_out_of_sync_checks_sel');
  add_signature(
      p_sig_id                 => 'ap_out_of_sync_checks_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(aip, ai) */
            aip.check_id             correct_check_id,
            aip.org_id               org_id,
            aip.accounting_event_id  inv_pmt_acctg_event_id,
            aip.posted_flag          inv_pmt_posted_flag,
            ac.vendor_name           vendor_name,
            ai.vendor_id             vendor_id,
            ac.vendor_site_code      vendor_site_code,
            ai.vendor_site_id        vendor_site_id,
            ac.check_id              wrong_check_id,
            ac.check_number          wrong_check_number,
            ac.amount                wrong_chk_amount,
            ac.payment_id            wrong_chk_payment_id,
            ac.status_lookup_code    wrong_chk_status,
            ac.currency_code         wrong_chk_currency,
            aph2.transaction_type    wrong_pmt_hist_trx_type,
            aph2.posted_flag         wrong_pmt_hist_posted_flag,
            aph2.accounting_event_id wrong_ph_acctg_event_id
     FROM ap_invoice_payments_all aip,
          ap_invoices_all ai,
          all_sequences seq,
          ap_checks_all ac,
          ap_payment_history_all aph2
     WHERE ai.invoice_id = aip.invoice_id
     AND   ai.org_id = aip.org_id
     AND   nvl(aip.reversal_flag,''N'') <> ''Y''
     AND   NOT EXISTS (
             SELECT 1 FROM ap_checks_all ac1
             WHERE ac1.check_id = aip.check_id)
     AND   ac.status_lookup_code NOT IN (''OVERFLOW'',''SET UP'',''SPOILED'')
     AND   nvl(aph2.historical_flag,''N'') <> ''Y''
     AND   ac.check_id = aph2.check_id(+)
     AND   ac.org_id = aip.org_id
     AND   ac.vendor_id = ai.vendor_id
     AND   ac.vendor_site_id = ai.vendor_site_id
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_payments_all aip1
             WHERE ac.check_id = aip1.check_id)
     AND   ac.creation_date > (
             SELECT MIN(creation_date) FROM ad_bugs
             WHERE aru_release_name = ''R12'')
     AND   seq.sequence_name = ''AP_CHECKS_S''
     AND   seq.sequence_owner = ''AP''
     AND   ac.check_id BETWEEN (aip.check_id - (seq.cache_size + 1)) AND
                               (aip.check_id + (seq.cache_size + 1))
     AND   aip.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Check id Mismatch',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Out-of-sync Check Ids between AP_CHECKS_ALL and AP_INVOICE_PAYMENTS_ALL',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [985607.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_out_of_sync_checks_sel');



debug('begin add_signature: missing_XDL');
  add_signature(
      p_sig_id                 => 'missing_XDL',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai, xte, xe) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xte.entity_id,
            xah.ae_header_id,
            xte.source_id_int_1 transaction_id,
            xte.transaction_number,
            xte.entity_code,
            xte.ledger_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          ap_system_parameters_all asp,
          gl_period_statuses upg,
          xla_transaction_entities_upg xte,
          xla_events xe,
          xla_ae_headers xah,
          xla_ae_lines xal
     WHERE xe.application_id = 200
     AND   xe.event_status_code = ''P''
     AND   xe.entity_id = xte.entity_id
     AND   xe.upg_batch_id is not null
     AND   xe.upg_batch_id <> - 9999
     AND   xah.application_id = 200
     AND   xal.application_id = 200
     AND   xte.application_id = 200
     AND   upg.application_id = 200
     AND   xah.event_id = xe.event_id
     AND   xah.ledger_id = xte.ledger_id
     AND   xal.ae_header_id = xah.ae_header_id
     AND   xah.upg_batch_id is not null
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.ledger_id = upg.ledger_id
     AND   nvl(xte.source_id_int_1,-99) = ai.invoice_id
     AND   asp.set_of_books_id = xte.ledger_id
     AND   upg.set_of_books_id = asp.set_of_books_id
     AND   asp.org_id = ai.org_id
     AND   ai.gl_date BETWEEN upg.start_date AND upg.end_date
     AND   upg.migration_status_code = ''U''
     AND   upg.closing_status in (''O'',''C'',''P'')
     AND   trunc(upg.start_date) < (
             SELECT min(trunc(creation_date)) FROM ad_applied_patches
             WHERE patch_type = ''MAINTENANCE-PACK''
             AND   maint_pack_level LIKE ''12.%'')
     AND   EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aid
             WHERE aid.invoice_id = ai.invoice_id
             AND   aid.accounting_event_id = xe.event_id
             AND   aid.Historical_flag = ''Y'')
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ 1 FROM xla_distribution_links xdl
             WHERE xdl.application_id = 200
             AND   xdl.ae_header_id = xah.ae_header_id
             AND   xdl.ae_line_num = xal.ae_line_num)
          AND   ai.invoice_id = aid.invoice_id        
     AND   aid.invoice_distribution_id = invs.invoice_distribution_id',
      p_title                  => 'Missing Records in XDL - Invoices',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Missing records exist in XLA_DISTRIBUTION_LINKS for migrated transactions',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1054299.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: missing_XDL');



debug('begin add_signature: PAYABLES_AAD_INVALID');
  add_signature(
      p_sig_id                 => 'PAYABLES_AAD_INVALID',
      p_sig_sql                => 'select  DOB.owner,  dob.object_name,  dob.status,             dob.last_ddl_time, 
            dob.created,dob.timestamp,    xpr.product_rule_code,  xpr.application_id, 
            xpr.product_rule_hash_id,     xpr.compile_status_code,xpr.name
    FROM    xla_product_rules_vl xpr,   dba_objects dob
    where   dob.object_name like ''XLA_00200_AAD_%_''||lpad(xpr.product_rule_hash_id,6,0)||''_PKG''
    and     xpr.application_id = 200
    and     object_type = ''PACKAGE BODY''
--    and     xpr.compile_status_code = ''Y''
    and     dob.status  = ''INVALID''
    and     xpr.product_rule_code in (select xamr.product_rule_code
                                  from    xla_acctg_method_rules_fvl xamr
                                  where   application_id = 200
                                  and     sysdate <= nvl(end_date_active, sysdate)
                                  and     amb_context_code = ''DEFAULT''
                                  and     xamr.accounting_method_code in
                                  (select  gl.sla_accounting_method_code
                                  from    gl.gl_ledgers gl
                                  where   gl.ledger_id in 
                                  ( SELECT  asp.set_of_books_id
                                    FROM    ap_invoices_all ai,
                                            ap_system_parameters_all asp
                                    WHERE   ai.org_id     = asp.org_id 
                                    and     ai.invoice_id = NVL(##$$INVID$$##, -99)
                                   UNION    
                                    SELECT  asp.set_of_books_id
                                    FROM    ap_checks_all ac,
                                            ap_system_parameters_all asp
                                    WHERE   ac.org_id   = asp.org_id
                                    AND     ac.check_id = NVL(##$$CHKID$$##,-99))))',
      p_title                  => 'Payables Application Accounting Definitions With Invalid Packages',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invalid packages exist in payables application accounting definitions',
      p_solution               => '<ul>
   <li>Please run the Validate Application Accounting Definitions program</li>
   <li>Follow the instructions provided in [1406203.1] </li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PAYABLES_AAD_INVALID');



debug('begin add_signature: XLA_EVENTS_PAY');
  add_signature(
      p_sig_id                 => 'XLA_EVENTS_PAY',
      p_sig_sql                => 'SELECT xte.ledger_id        LEDGER_ID,
       xte.source_id_int_1      SOURCE_ID_INT_1,
       xte.security_id_int_1    SECURITY_ID_INT_1,
       xte.entity_code          ENTITY_CODE,
       xte.legal_entity_id      LEGAL_ENTITY_ID,
       xle.event_status_code    EVENT_STATUS_CODE,
       xle.process_status_code  PROCESS_STATUS_CODE,
       xle.application_id       APPLICATION_ID,
       xle.event_id             EVENT_ID,
       xle.event_number         EVENT_NUMBER,
       xle.on_hold_flag         ON_HOLD_FLAG,
       xle.event_type_code      EVENT_TYPE_CODE,
       xle.event_date           EVENT_DATE,
       xte.transaction_number   TRANSACTION_NUMBER,
       xle.last_update_date     LAST_UPDATE_DATE ,
       xle.creation_date        CREATION_DATE,
       xle.transaction_date     TRANSACTION_DATE
  FROM    xla_events xle,
          xla.xla_transaction_entities xte,
          xla_ledger_options xlo
  WHERE   xle.entity_id = xte.entity_id
       AND xle.application_id = xte.application_id
       and xte.source_id_int_1 = NVL(##$$CHKID$$##,-99)
       AND xle.application_id = 200
       AND xle.event_status_code IN (''I'',''U'')
       AND xle.process_status_code IN (''I'',''U'',''R'',''D'',''E'')
       AND xle.application_id = xlo.application_id
       AND xlo.capture_event_flag = ''Y''
       AND EXISTS (SELECT 1
                   FROM   gl_ledger_relationships glr1,
                          gl_ledger_relationships glr2
                   WHERE  glr1.target_ledger_id = xlo.ledger_id
                          AND glr2.target_ledger_id in ( SELECT set_of_books_id 
                          FROM   AP_SYSTEM_PARAMETERS_ALL WHERE  org_id in (##$$ORGS$$##))
                          AND glr2.source_ledger_id = glr1.source_ledger_id
                          AND glr2.application_id = glr1.application_id
                          AND (glr1.target_ledger_id = xte.ledger_id
                                OR glr1.primary_ledger_id = xte.ledger_id)
                          AND (glr1.relationship_type_code = ''SUBLEDGER''
                                OR (glr1.target_ledger_category_code = ''PRIMARY''
                                    AND glr1.relationship_type_code = ''NONE''))
                          AND glr2.application_id = 101)
       AND xte.application_id = 200',
      p_title                  => 'Unaccounted Payment Transactions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unaccounted payment transactions exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the payment event(s).</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: XLA_EVENTS_PAY');



debug('begin add_signature: ap_rate_miss_sel');
  add_signature(
      p_sig_id                 => 'ap_rate_miss_sel',
      p_sig_sql                => 'SELECT ac.check_id,
            ac.check_number,
            ac.vendor_name,
            ac.check_date,
            ac.amount,
            ac.org_id
     FROM ap_checks_all ac,
          ap_system_parameters_all asp,
          ap_payment_history_all ph
     WHERE ac.org_id = asp.org_id
     AND   ac.currency_code <> asp.base_currency_code
     AND   ph.check_id = ac.check_id
     AND   nvl(ph.historical_flag, ''N'') <> ''Y''
     AND   /* pmt created exchange rate */
           ((ph.transaction_type in (''PAYMENT CREATED'', ''REFUND RECORDED'',
                   ''MANUAL PAYMENT ADJUSTED'',
                   ''PAYMENT ADJUSTED'', ''REFUND ADJUSTED'',
                   ''PAYMENT CANCELLED'', ''REFUND CANCELLED'') AND
             ph.pmt_to_base_xrate is null AND
             ((nvl(ph.posted_flag,''N'') <> ''Y'' AND
               (decode(ph.pmt_to_base_xrate_type,
                  ''User'', null,
                  ph.pmt_to_base_xrate_type) is null OR
               ph.pmt_to_base_xrate_date is null OR
               EXISTS (
                 /*autorate will not pick it up if aip rate and base are populated */
                 SELECT 1 FROM ap_invoice_payments_all aip
                 WHERE aip.check_id = ph.check_id
                 AND   aip.posted_flag = ''N''
                 AND   aip.accounting_event_id = ph.accounting_event_id
                 AND   aip.invoice_base_amount is not null
                 AND   aip.exchange_rate is not null))) OR
              (ph.posted_flag = ''Y'' AND
               (ac.exchange_rate is null OR
                ph.trx_base_amount is null OR
                ap_utilities_pkg.ap_round_currency(
                  ph.trx_pmt_amount * ac.exchange_rate,
                  ph.pmt_currency_code) <> ph.trx_base_amount)))) OR
            /* pmt maturity exchange rate */
            (ph.transaction_type in (''PAYMENT MATURITY'',
                ''PAYMENT MATURITY ADJUSTED'', ''PAYMENT MATURITY REVERSAL'') AND
             ph.pmt_to_base_xrate is null AND
             (nvl(ph.posted_flag,''N'') <> ''Y'' AND
              (decode(ph.pmt_to_base_xrate_type,
                 ''User'', null,
                 ph.pmt_to_base_xrate_type) is null OR
               ph.pmt_to_base_xrate_date is null) OR
              (ph.posted_flag = ''Y'' AND
               (ac.maturity_exchange_rate is null OR
                ph.trx_base_amount is null OR
                ap_utilities_pkg.ap_round_currency(
                  ph.trx_pmt_amount * ac.maturity_exchange_rate,
                  ph.pmt_currency_code) <> ph.trx_base_amount)))) OR
            /* pmt clearing exchange rate */
            (ph.transaction_type in (''PAYMENT CLEARING'',
               ''PAYMENT CLEARING ADJUSTED'', ''PAYMENT UNCLEARING'') AND
             (ph.pmt_to_base_xrate is null AND
              (nvl(ph.posted_flag,''N'') <> ''Y'' OR
               (ph.posted_flag = ''Y'' AND
                (ac.cleared_exchange_rate is null OR
                 ph.trx_base_amount is null OR
                 ap_utilities_pkg.ap_round_currency(
                   ph.trx_pmt_amount * ac.cleared_exchange_rate,
                   ph.pmt_currency_code) <> ph.trx_base_amount)))) OR
                 (ph.bank_to_base_xrate is null AND
                  ph.bank_currency_code <> asp.base_currency_code)))
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Missing Exchange Rates',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Missing exchange rates, maturity exchange rates, or clearing exchange rates',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1125533.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_rate_miss_sel');



debug('begin add_signature: ap_trx_missing_event_sel');
  add_signature(
      p_sig_id                 => 'ap_trx_missing_event_sel',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            aid.invoice_distribution_id,
            aid.cancellation_flag cancellation_flag,
            aid.prepay_distribution_id prepay_distribution_id,
            aid.parent_reversal_id parent_reversal_id,
            ai.invoice_date,
            asu.vendor_name,
            assi.vendor_site_code,
            ap_invoices_utility_pkg.get_approval_status(
              ai.invoice_id,
              ai.invoice_amount,
              ai.payment_status_flag,
              ai.invoice_type_lookup_code) invoice_status,
            ''Invoice Distribution'' distribution_type,
            aid.accounting_event_id
     FROM invs,
          ap_invoices_all ai,
          ap_suppliers asu,
          ap_supplier_sites_all assi,
          ap_invoice_distributions_all aid,
          financials_system_params_all fsp
     WHERE aid.invoice_id = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   fsp.org_id = aid.org_id
     AND   ((fsp.purch_encumbrance_flag = ''Y'' AND
             aid.match_status_flag = ''A'') OR
            (fsp.purch_encumbrance_flag = ''N'' AND
             aid.match_status_flag IN (''A'',   ''T'')))
     AND   nvl(aid.posted_flag,   ''N'') <> ''Y''
     AND   aid.accounting_event_id is null
     AND   NOT EXISTS (
             SELECT 1
             FROM ap_accounting_events_all aae,
                  ap_invoices_all ai2
             WHERE ai2.invoice_id = ai.invoice_id
             AND   ai2.historical_flag = ''Y''
             AND   aae.source_id = ai2.invoice_id
             AND   aae.source_table IN (''AP_INVOICES'', ''AP_INVOICES_ALL'')
  	   AND   NOT EXISTS (
                     SELECT 1 FROM ap_invoice_distributions_all aid2
  	           WHERE aid2.invoice_id = ai2.invoice_id
  	           AND   aid2.accounting_event_id = aae.accounting_event_id))
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            asad.invoice_distribution_id,
            asad.cancellation_flag cancellation_flag,
            asad.prepay_distribution_id prepay_distribution_id,
            asad.parent_reversal_id parent_reversal_id,
            ai.invoice_date,
            asu.vendor_name,
            assi.vendor_site_code,
            ap_invoices_utility_pkg.get_approval_status(
              ai.invoice_id, ai.invoice_amount, ai.payment_status_flag,
              ai.invoice_type_lookup_code) invoice_status,
            ''Self Assessed Tax Distribution'' distribution_type,
            asad.accounting_event_id
     FROM invs,
          ap_invoices_all ai,
          ap_suppliers asu,
          ap_supplier_sites_all assi,
          ap_self_assessed_tax_dist_all asad,
          financials_system_params_all fsp
     WHERE asad.invoice_id = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   fsp.org_id = asad.org_id
     AND   ((fsp.purch_encumbrance_flag = ''Y'' AND
             asad.match_status_flag = ''A'') OR
            (fsp.purch_encumbrance_flag = ''N'' AND
             asad.match_status_flag IN (''A'',   ''T'')))
     AND   nvl(asad.posted_flag,   ''N'') <> ''Y''
     AND   asad.accounting_event_id is null
     AND   NOT EXISTS (
             SELECT 1
             FROM ap_accounting_events_all aae,
                  ap_invoices_all ai2
             WHERE ai2.invoice_id = ai.invoice_id
             AND   ai2.historical_flag = ''Y''
             AND   aae.source_id = ai2.invoice_id
             AND   aae.source_table IN (''AP_INVOICES'', ''AP_INVOICES_ALL'')
  	   AND   NOT EXISTS (
                     SELECT 1 FROM ap_invoice_distributions_all aid2
  	           WHERE aid2.invoice_id = ai2.invoice_id
  	           AND   aid2.accounting_event_id = aae.accounting_event_id))
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Missing Accounting_Event_ID',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Missing Accounting_Event_ID for approved invoice or payments distributions',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [972261.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_trx_missing_event_sel');



debug('begin add_signature: AP_self_assessed_tax_dist_all');
  add_signature(
      p_sig_id                 => 'AP_self_assessed_tax_dist_all',
      p_sig_sql                => 'select     ai.invoice_id
                ,ai.invoice_num
                ,astd.invoice_distribution_id
                    ,astd.accounting_event_id
                ,astd.accounting_date
                ,astd.org_id
                ,ai.invoice_currency_code
                    ,ai.party_id
                ,ai.vendor_id
                ,ai.doc_sequence_value
                ,ai.voucher_num
                ,ai.invoice_date
                ,ai.invoice_amount
                ,ai.cancelled_date
                ,astd.match_status_flag
                ,ai.legal_entity_id
                ,astd.po_distribution_id
                ,astd.amount
                ,astd.detail_tax_dist_id
      from       ap_invoices_all ai,
                 ap_self_assessed_tax_dist_all astd,
                (
                ##$$IVIEW$$##
                ) invs
      where ai.invoice_id = astd.invoice_id
      and   ai.invoice_id = invs.invoice_id     
      and   ai.approval_ready_flag <> ''S''
      and   astd.posted_flag  in (''N'' , ''S'', ''P'') -- N=Not Accounted, S=Selected for Accounting, P=Partially Accounted for CASH based accounting',
      p_title                  => 'Unposted Self Assessed Tax Distributions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unposted self assessed tax distributions exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the distribution(s).</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_self_assessed_tax_dist_all');



debug('begin add_signature: SHOW_EVENTCLASS_AAD');
  add_signature(
      p_sig_id                 => 'SHOW_EVENTCLASS_AAD',
      p_sig_sql                => 'select  xpa.*
    from    xla_prod_acct_headers_fvl  xpa
    where   xpa.application_id = 200
    --and     validation_status_code in (''N'',''E'')
    and     xpa.product_rule_code in (select  xamr.product_rule_code
                                  from    xla_acctg_method_rules_fvl xamr
                                  where   application_id = 200
                                  and     sysdate <= nvl(end_date_active, sysdate)
                                  and     amb_context_code = ''DEFAULT''
                                  and     xamr.accounting_method_code in 
                                  (select  gl.sla_accounting_method_code
                                  from    gl.gl_ledgers gl
                                  where   gl.ledger_id in 
                                  (SELECT  asp.set_of_books_id
                                  FROM    ap_invoices_all ai,
                                          ap_system_parameters_all asp
                                  WHERE   ai.org_id     = asp.org_id 
                                  and     ai.invoice_id = NVL(##$$INVID$$##, -99)
                                 UNION    
                                  SELECT  asp.set_of_books_id
                                  FROM    ap_checks_all ac,
                                          ap_system_parameters_all asp
                                  WHERE   ac.org_id   = asp.org_id
                                  AND     ac.check_id = NVL(##$$CHKID$$##,-99))))',
      p_title                  => 'Event Class Assignment For Payables AAD',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Event Class Assignment For Payables AAD',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('SUCCESS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHOW_EVENTCLASS_AAD');



debug('begin add_signature: XLA_AE_ERRORS_PAY');
  add_signature(
      p_sig_id                 => 'XLA_AE_ERRORS_PAY',
      p_sig_sql                => 'SELECT aeh.ledger_id           LEDGER_ID,
       aeh.ae_header_id        AE_HEADER_ID,
       xte.source_id_int_1     SOURCE_ID_INT_1,
       aeh.ACCOUNTING_DATE     ACCOUNTING_DATE,
       xte.entity_code         ENTITY_CODE,
       xte.security_id_int_1   SECURITY_ID_INT_1,
       xte.transaction_number  TRANSACTION_NUMBER,
       xte.entity_id           ENTITY_ID,
       xte.legal_entity_id     LEGAL_ENTITY_ID,
       xle.event_type_code     EVENT_TYPE_CODE,
       xle.event_date          EVENT_DATE,
       xle.last_update_date    LAST_UPDATE_DATE ,
       xle.creation_date       CREATION_DATE,
       xle.transaction_date    TRANSACTION_DATE,
       aeh.event_id            EVENT_ID,
       aeh.application_id      APPLICATION_ID,
       aeh.accounting_entry_status_code            ACCOUNTING_ENTRY_STATUS_CODE,
       aeh.gl_transfer_status_code                 GL_TRANSFER_STATUS_CODE,
       xae.ENCODED_MSG  ACCOUNTING_ERROR_MESSAGE
      FROM   xla_ae_headers aeh,
             xla_events xle,
             xla_accounting_errors xae,
             xla.xla_transaction_entities xte
      WHERE  EXISTS (SELECT 1
                     FROM   gl_ledger_relationships glr1,
                            gl_ledger_relationships glr2
                     WHERE  aeh.ledger_id = glr2.target_ledger_id
                            AND glr2.source_ledger_id = glr1.source_ledger_id
                            AND glr2.application_id = glr1.application_id
                      AND glr1.target_ledger_id in ( SELECT set_of_books_id
                                                           FROM   AP_SYSTEM_PARAMETERS_ALL
                                                            WHERE  org_id in (##$$ORGS$$##))
                    AND glr1.application_id = 101)
             AND xte.entity_id = aeh.entity_id
             and aeh.ae_header_id(+)=xae.ae_header_id
             AND xte.application_id = aeh.application_id
             AND aeh.accounting_entry_status_code !=  (''F'')
             AND xle.Process_status_code = ''I''
             AND xle.event_id = aeh.event_id
             AND xle.application_id = aeh.application_id
             and xte.source_id_int_1 = NVL(##$$CHKID$$##,-99)     
             AND xte.application_id = 200',
      p_title                  => 'Payment With Accounting Errors',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payments with accounting errors',
      p_solution               => '<ul>
   <li>Review each error message and follow instructions to resolve if provided.</li>
   <li>Review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: XLA_AE_ERRORS_PAY');



debug('begin add_signature: VERIFY_EVENTCLASS_STATUS');
  add_signature(
      p_sig_id                 => 'VERIFY_EVENTCLASS_STATUS',
      p_sig_sql                => 'select  xpa.*
    from    xla_prod_acct_headers_fvl  xpa
    where   xpa.application_id = 200
    and     validation_status_code in (''N'',''E'')
    and     xpa.product_rule_code in (select  xamr.product_rule_code
                                  from    xla_acctg_method_rules_fvl xamr
                                  where   application_id = 200
                                  and     sysdate <= nvl(end_date_active, sysdate)
                                  and     amb_context_code = ''DEFAULT''
                                  and     xamr.accounting_method_code in 
                                  (select  gl.sla_accounting_method_code
                                  from    gl.gl_ledgers gl
                                  where   gl.ledger_id in 
                                  (SELECT  asp.set_of_books_id
                                  FROM    ap_invoices_all ai,
                                          ap_system_parameters_all asp
                                  WHERE   ai.org_id     = asp.org_id 
                                  and     ai.invoice_id = NVL(##$$INVID$$##, -99)
                                 UNION    
                                  SELECT  asp.set_of_books_id
                                  FROM    ap_checks_all ac,
                                          ap_system_parameters_all asp
                                  WHERE   ac.org_id   = asp.org_id
                                  AND     ac.check_id = NVL(##$$CHKID$$##,-99))))',
      p_title                  => 'Verify the event class status for Payables AAD',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'One or more event classes have an Invalid or Not Validated status',
      p_solution               => '<ul>
      <li>Please run the Validate Application Accounting Definitions program</li>
      <li>Follow the instructions provided in [1406203.1] </li>
      </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: VERIFY_EVENTCLASS_STATUS');



debug('begin add_signature: ap_pay_acctng_event_id_null_sel');
  add_signature(
      p_sig_id                 => 'ap_pay_acctng_event_id_null_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ac, aph, aip) */
            ac.check_id,
            ac.check_number,
            ac.org_id,
            aip.accounting_event_id,
            aip.accounting_date
     FROM ap_checks_all ac,
          ap_payment_history_all aph,
          ap_invoice_payments_all aip
     WHERE aph.check_id = ac.check_id
     AND   aip.check_id = aph.check_id
     AND   aip.accounting_event_id is not null
     AND   aip.accounting_event_id = aph.accounting_event_id
     AND   aph.transaction_type = ''PAYMENT CREATED''
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)
     AND   aip.reversal_inv_pmt_id is null
     AND   EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_payments_all aip1
             WHERE  aip.check_id = aip1.check_id
             AND   aip1.accounting_event_id is null)',
      p_title                  => 'Accounting Event Id is Null In AP_INVOICE_PAYMENTS_ALL',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Checks with null accounting_event_id in ap_invoice_payments_all',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1540095.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_pay_acctng_event_id_null_sel');



debug('begin add_signature: AP_self_assessed_tax_dist_all_E');
  add_signature(
      p_sig_id                 => 'AP_self_assessed_tax_dist_all_E',
      p_sig_sql                => 'select     ai.invoice_id
                ,ai.invoice_num
                ,astd.invoice_distribution_id
                ,astd.accounting_event_id
                ,astd.accounting_date
                ,astd.org_id
                ,ai.invoice_currency_code
                    ,ai.party_id
                ,ai.vendor_id
                ,ai.doc_sequence_value
                ,ai.voucher_num
                ,ai.invoice_date
                ,ai.invoice_amount
                ,ai.cancelled_date
                ,astd.match_status_flag
                ,ai.legal_entity_id
                ,astd.po_distribution_id
                ,astd.amount
                ,astd.detail_tax_dist_id
      from      ap_invoices_all ai,
                ap_self_assessed_tax_dist_all astd,
                (
                ##$$IVIEW$$##
                ) invs
      where     ai.invoice_id = astd.invoice_id
        and     ai.invoice_id = invs.invoice_id          
        and     ai.approval_ready_flag <> ''S''
        and     astd.bc_event_id is not null
        and     nvl(astd.encumbered_flag, ''N'') in (''N'', ''H'', ''P'')
        and     astd.posted_flag  in (''N'' , ''S'', ''P'')-- N=Not Accounted, S=Selected for Accounting, P=Partially Accounted for CASH based accounting',
      p_title                  => 'Unposted Invoices Distributions - Encumbrance',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unposted invoice distributions - encumbrance exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the distribution(s).</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_self_assessed_tax_dist_all_E');



debug('begin add_signature: ap_trx_missing_xdl');
  add_signature(
      p_sig_id                 => 'ap_trx_missing_xdl',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai, xte, xe) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xte.entity_id,
            xah.ae_header_id,
            xte.source_id_int_1 transaction_id,
            xte.transaction_number,
            xte.entity_code,
            xte.ledger_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp,
          gl_period_statuses upg,
          xla_transaction_entities_upg xte,
          xla_events xe,
          xla_ae_headers xah,
          xla_ae_lines xal
     WHERE xe.application_id = 200
     AND   xe.event_status_code = ''P''
     AND   xe.entity_id = xte.entity_id
     AND   xe.upg_batch_id is not null
     AND   xe.upg_batch_id <> - 9999
     AND   xah.application_id = 200
     AND   xal.application_id = 200
     AND   xte.application_id = 200
     AND   upg.application_id = 200
     AND   xah.event_id = xe.event_id
     AND   xah.ledger_id = xte.ledger_id
     AND   xal.ae_header_id = xah.ae_header_id
     AND   xah.upg_batch_id is not null
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.ledger_id = upg.ledger_id
     AND   nvl(xte.source_id_int_1,-99) = ai.invoice_id
     AND   asp.set_of_books_id = xte.ledger_id
     AND   upg.set_of_books_id = asp.set_of_books_id
     AND   asp.org_id = ai.org_id
     AND   ai.gl_date BETWEEN upg.start_date AND upg.end_date
     AND   upg.migration_status_code = ''U''
     AND   upg.closing_status in (''O'',''C'',''P'')
     AND   trunc(upg.start_date) < (
             SELECT min(trunc(creation_date)) FROM ad_applied_patches
             WHERE patch_type = ''MAINTENANCE-PACK''
             AND   maint_pack_level LIKE ''12.%'')
     AND   EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aid
             WHERE aid.invoice_id = ai.invoice_id
             AND   aid.accounting_event_id = xe.event_id
             AND   aid.Historical_flag = ''Y'')
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ 1 FROM xla_distribution_links xdl
             WHERE xdl.application_id = 200
             AND   xdl.ae_header_id = xah.ae_header_id
             AND   xdl.ae_line_num = xal.ae_line_num)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Missing records in XLA_DISTRIBUTION_LINKS',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Missing records exist in XLA_DISTRIBUTION_LINKS for migrated transactions',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1054299.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_trx_missing_xdl');



debug('begin add_signature: XLA_AE_HEADERS_PAY');
  add_signature(
      p_sig_id                 => 'XLA_AE_HEADERS_PAY',
      p_sig_sql                => 'SELECT aeh.ledger_id           LEDGER_ID,
       aeh.ae_header_id        AE_HEADER_ID,
       xte.source_id_int_1     SOURCE_ID_INT_1,
       aeh.ACCOUNTING_DATE     ACCOUNTING_DATE,
       xte.entity_code         ENTITY_CODE,
       xte.security_id_int_1   SECURITY_ID_INT_1,
       xte.transaction_number  TRANSACTION_NUMBER,
       xte.entity_id           ENTITY_ID,
       xte.legal_entity_id     LEGAL_ENTITY_ID,
       xle.event_type_code     EVENT_TYPE_CODE,
       xle.event_date          EVENT_DATE,
       xle.last_update_date    LAST_UPDATE_DATE ,
       xle.creation_date       CREATION_DATE,
       xle.transaction_date    TRANSACTION_DATE,
       aeh.event_id            EVENT_ID,
       aeh.application_id      APPLICATION_ID,
       aeh.accounting_entry_status_code            ACCOUNTING_ENTRY_STATUS_CODE,
       aeh.gl_transfer_status_code                 GL_TRANSFER_STATUS_CODE
      FROM   xla_ae_headers aeh,
             xla_events xle,
             xla.xla_transaction_entities xte
      WHERE  EXISTS (SELECT 1
                     FROM   gl_ledger_relationships glr1,
                            gl_ledger_relationships glr2
                     WHERE  aeh.ledger_id = glr2.target_ledger_id
                            AND glr2.source_ledger_id = glr1.source_ledger_id
                            AND glr2.application_id = glr1.application_id
                            AND glr1.target_ledger_id in ( SELECT set_of_books_id
                                                             FROM   AP_SYSTEM_PARAMETERS_ALL
                                                            WHERE  org_id in (##$$ORGS$$##))
                            AND glr1.application_id = 101)
             AND xte.entity_id = aeh.entity_id
             AND xte.application_id = aeh.application_id
             AND aeh.gl_transfer_status_code IN (''N'',''E'')
             AND xle.event_status_code = ''P''
             AND xle.event_id = aeh.event_id
             AND xle.application_id = aeh.application_id
             and xte.source_id_int_1 = NVL(##$$CHKID$$##,-99)
             AND xte.application_id = 200',
      p_title                  => 'Unposted Payment Accounting Headers',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accounted payment which are not transferred to General Ledger',
      p_solution               => '<ul>
   <li>If the transactions listed are final accounted, then please run Transfer to General Ledger process and post these items to GL</li>
   <li>If the accounting of these transactions are unsuccessful, then the Subledger Accounting Program Report should show the reasons why accounting failed</li>
   <li>Follow the instructions provided in [560378.1] for more information on sweeping process</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: XLA_AE_HEADERS_PAY');



debug('begin add_signature: ap_aip_aph_diff_event_sel');
  add_signature(
      p_sig_id                 => 'ap_aip_aph_diff_event_sel',
      p_sig_sql                => 'SELECT ac1.check_id check_id_1,
            ac1.check_number check_num_1,
            ac1.org_id org_id_1,
            aph1.accounting_event_id event_id_1,
            aph1.posted_flag posted_flag_1,
            aph1.org_id org_id_1,
            aph1.payment_history_id payment_history_id_1,
            xe1.entity_id entity_id_1,
            aph2.check_id check_id_2,
            ac2.check_number check_num_2,
            ac2.org_id  org_id_2,
            aph2.accounting_event_id event_id_2,
            aph2.posted_flag posted_flag_2,
            aph2.org_id org_id_2,
            aph2.payment_history_id payment_history_id_2,
            xe2.entity_id entity_id_2
     FROM ap_checks_all ac1,
          xla_transaction_entities_upg xte1,
          ap_invoice_payments_all aip1,
          ap_payment_history_all aph1,
          xla_events xe1,
          ap_checks_all ac2,
          xla_transaction_entities_upg xte2,
          ap_payment_history_all aph2,
          xla_events xe2
     WHERE nvl(xte1.source_id_int_1, -99) = ac1.check_id
     AND   nvl(xte1.security_id_int_1, -99) = ac1.org_id
     AND   xte1.entity_code = ''AP_PAYMENTS''
     AND   xte1.application_id = xte2.application_id
     AND   aph1.check_id = ac1.check_id
     AND   aph1.transaction_type in ( ''PAYMENT CREATED'',''REFUND RECORDED'')
     AND   aph1.accounting_event_id = xe1.event_id
     AND   xe1.event_type_code in ( ''PAYMENT CREATED'',''REFUND RECORDED'')
     AND   xte1.entity_id = xe1.entity_id
     AND   xe1.application_id = xte2.application_id
     AND   nvl(xte2.source_id_int_1, -99) = ac2.check_id
     AND   nvl(xte2.security_id_int_1, -99) = ac2.org_id
     AND   xte2.entity_code = ''AP_PAYMENTS''
     AND   xte2.application_id = xte2.application_id
     AND   aph2.check_id = ac2.check_id
     AND   aph2.transaction_type in ( ''PAYMENT CREATED'',''REFUND RECORDED'')
     AND   aph2.accounting_event_id = xe2.event_id
     AND   xe2.event_type_code in ( ''PAYMENT CREATED'',''REFUND RECORDED'')
     AND   xte2.entity_id = xe2.entity_id
     AND   xe2.application_id = xte2.application_id
     AND   aip1.check_id = ac1.check_id
     AND   NOT EXISTS (
             SELECT ''invoice_payments'' FROM ap_invoice_payments_all aip2
             WHERE aip2.check_id = ac2.check_id)
     AND   xe1.event_id <> aip1.accounting_event_id
     AND   xe2.event_id = aip1.accounting_event_id
     AND   xe1.event_status_code = ''U''
     AND   xe1.process_status_code = ''U''
     AND   aph1.posted_flag in (''N'', ''S'')
     AND   ac1.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Event id Mismatch In Invoice Payments and Payment History Records',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Event_id mismatch between ap_invoice_payments_all and ap_payment_history_all',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1125724.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_aip_aph_diff_event_sel');



debug('begin add_signature: ap_pay_hold');
  add_signature(
      p_sig_id                 => 'ap_pay_hold',
      p_sig_sql                => 'SELECT xe.event_id,xe.event_date,xe.event_status_code,xe.process_status_code,xe.event_type_code,xte.entity_code,xte.source_id_int_1 source_id,
       xte.transaction_number,xe.budgetary_control_flag,xte.security_id_int_1,xte.ledger_id,aip.check_id, ac.check_number, 
       ai.invoice_id, ai.invoice_num,  ''Release Invoice Hold''
    FROM    ap_invoice_payments_all aip,
            ap_checks_all ac,
            ap_invoices_all ai,
            xla_events xe,
             xla_transaction_entities_upg xte
    WHERE xte.entity_id=xe.entity_id
         AND xte.application_id=200
         AND xe.application_id=200
         AND xe.event_status_code=''I''
         and xte.source_id_int_1 = ac.check_id
         and ac.check_id = aip.check_id
         and ac.check_id = NVL(##$$CHKID$$##,-99)
         and aip.invoice_id = ai.invoice_id
         AND xte.entity_code = ''AP_PAYMENTS''
         AND exists (SELECT 1
                     FROM ap_holds_all AH
                     WHERE invoice_id=ai.invoice_id
                     AND AH.RELEASE_LOOKUP_CODE is null)
UNION
  SELECT xe.event_id,xe.event_date,xe.event_status_code,xe.process_status_code,xe.event_type_code,xte.entity_code,xte.source_id_int_1 source_id,
         xte.transaction_number,xe.budgetary_control_flag,xte.security_id_int_1,xte.ledger_id,aip.check_id, ac.check_number, 
         ai.invoice_id, ai.invoice_num, ''Run Autorate''
  FROM  ap_invoice_payments_all aip,
        ap_checks_all ac,
        ap_invoices_all ai,
        xla_events xe,
        xla_transaction_entities_upg xte
  WHERE xte.entity_id=xe.entity_id
         AND xte.application_id=200
         AND xe.application_id=200
         AND xe.event_status_code=''I''
         and xte.source_id_int_1 = ac.check_id
         and ac.check_id = aip.check_id
         and ac.check_id = NVL(##$$CHKID$$##,-99)
         and aip.invoice_id = ai.invoice_id
         AND xte.entity_code = ''AP_PAYMENTS''
         AND exists (SELECT 1
                    FROM ap_payment_history_all aph,
                        ap_system_parameters_all asp
                    WHERE asp.org_id = aph.org_id
                    AND aph.pmt_currency_code <> asp.base_currency_code
                    AND aph.pmt_to_base_xrate is null
                    AND aph.check_id = ac.check_id
                    AND xte.entity_code = ''AP_PAYMENTS'')
UNION
   SELECT xe.event_id,xe.event_date,xe.event_status_code,xe.process_status_code,xe.event_type_code,xte.entity_code,xte.source_id_int_1 source_id,
          xte.transaction_number,xe.budgetary_control_flag,xte.security_id_int_1,xte.ledger_id,aip.check_id, ac.check_number, 
          ai.invoice_id, ai.invoice_num, ''Validate Invoice''
  FROM  ap_invoice_payments_all aip,
        ap_checks_all ac,
        ap_invoices_all ai,
        xla_events xe,
        xla_transaction_entities_upg xte
       WHERE xte.entity_id=xe.entity_id
         AND xte.application_id=200
         AND xe.application_id=200
         AND xe.event_status_code=''I''
         and xte.source_id_int_1 = ac.check_id
         and ac.check_id = aip.check_id
         and ac.check_id = NVL(##$$CHKID$$##,-99)
         and aip.invoice_id = ai.invoice_id
         AND xte.entity_code = ''AP_PAYMENTS''
        AND exists (SELECT 1
               FROM ap_invoice_distributions_all aid,
                    financials_system_params_all fsp
               WHERE aip.invoice_id = aid.invoice_id
               AND aid.org_id = fsp.org_id
               AND aid.set_of_books_id = fsp.set_of_books_id
               AND ( (NVL(fsp.purch_encumbrance_flag,''N'') = ''N''
                      AND aid.match_Status_flag NOT IN (''T'',''A'') )
                      OR ((NVL(fsp.purch_encumbrance_flag,''N'') = ''Y''
                           AND aid.match_Status_flag != ''A''))))
                           order by 12,15',
      p_title                  => 'Unaccounted Payment Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unaccounted payment events with event_status_code as I',
      p_solution               => '<ul>
   <li>Release Invoice Hold - Refer Doc id [1417598.2] Use tab > Validation and Holds link</li>
   <li>Run Autorate - Follow the instructions provided in [834251.1]</li>
   <li>Validate Invoice - Refer Doc id [1417598.2] Use tab > Validation and Holds link</li>   
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_pay_hold');



debug('begin add_signature: ap_psa_cleanup_s_1');
  add_signature(
      p_sig_id                 => 'ap_psa_cleanup_s_1',
      p_sig_sql                => 'SELECT aid.invoice_id,
            aid.org_id,
            aid.invoice_line_number,
            aid.invoice_distribution_id parent_inv_dist_id,
            aid.distribution_line_number parent_dist_line_num,
            aid.line_type_lookup_code parent_line_type,
            aid.amount parent_amount,
            aid.base_amount parent_base_amount,
            aid.bc_event_id parent_bc_event_id,
            xe.event_status_code parent_event_status,
            aid.encumbered_flag parent_encumbered_flag,
            aid.posted_flag parent_posted_flag,
            aidr.invoice_distribution_id reversal_inv_dist_id,
            aidr.distribution_line_number reversal_dist_line_num,
            aidr.line_type_lookup_code reversal_line_type,
            aidr.amount reversal_amount,
            aidr.base_amount reversal_base_amount,
            aidr.bc_event_id reversal_bc_event_id,
            xer.event_status_code reversal_event_status,
            aidr.encumbered_flag reversal_encumbered_flag,
            aidr.posted_flag reversal_posted_flag
     FROM ap_invoice_distributions_all aid,
          ap_invoice_distributions_all aidr,
          financials_system_params_all fsp,
          xla_events xe,
          xla_events xer,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE aid.bc_event_id = xe.event_id(+)
     AND   aidr.bc_event_id = xer.event_id(+)
     AND   xe.application_id(+) = 200
     AND   xer.application_id(+) = 200
     AND   xe.budgetary_control_flag(+) = ''Y''
     AND   xer.budgetary_control_flag(+) = ''Y''
     AND   aid.invoice_distribution_id = aidr.parent_reversal_id
     AND   nvl(aid.historical_flag, ''N'') <> ''Y''
     AND   nvl(aidr.historical_flag, ''N'') <> ''Y''
     AND   nvl(aid.reversal_flag,   ''N'') = ''Y''
     AND   nvl(aidr.reversal_flag,   ''N'') = ''Y''
     AND   aid.invoice_id = aidr.invoice_id
     AND   aid.org_id = fsp.org_id
     AND   fsp.purch_encumbrance_flag = ''Y''
     AND   aid.invoice_line_number = aidr.invoice_line_number
     AND   (nvl(xe.event_id,  -99) = -99 OR xe.event_status_code <> ''P'')
     AND   (nvl(xer.event_id, -99) = -99 OR xer.event_status_code <> ''P'')
     AND   (nvl(xe.event_id,  -99) <> -99 OR nvl(xer.event_id, -99) <> -99)
     AND   aid.invoice_id = invs.invoice_id',
      p_title                  => 'Reversing Distribution Pairs',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Reversing distribution pairs which have not been encumbered but which have been stamped with BC_EVENT_ID',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [985228.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_psa_cleanup_s_1');



debug('begin add_signature: ap_prepay_history_all');
  add_signature(
      p_sig_id                 => 'ap_prepay_history_all',
      p_sig_sql                => 'select      ai.invoice_id
                ,ai.invoice_num
                ,apph.accounting_event_id
                ,apph.accounting_date
                ,ai.org_id
                ,ai.invoice_currency_code
                ,ai.party_id
                ,ai.vendor_id
                ,ai.doc_sequence_value
                ,ai.voucher_num
                ,ai.invoice_date
                ,ai.invoice_amount
                ,ai.cancelled_date
                ,ai.legal_entity_id
      from       ap_invoices_all ai
                ,ap_prepay_history_all apph,
                (
                ##$$IVIEW$$##
                ) invs
      where     ai.invoice_id = apph.invoice_id
        and     ai.invoice_id = invs.invoice_id     
        and     apph.posted_flag  in (''N'' , ''S'', ''P'') -- N=Not Accounted, S=Selected for Accounting, P=Partially Accounted for CASH based accounting
        and apph.accounting_event_id IS NOT NULL',
      p_title                  => 'Unposted Prepayments',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unposted prepayment invoices exist',
      p_solution               => '<ul>
   <li>Please run the Create Accounting process to account the prepay event(s) for this invoice.</li>
   <li>If there are accounting errors or the accounting is not picked up, review the analyzer output for other errors/warnings.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prepay_history_all');



debug('begin add_signature: ap_hold');
  add_signature(
      p_sig_id                 => 'ap_hold',
      p_sig_sql                => 'SELECT  ah.held_by, ah.hold_date, ah.hold_lookup_code, substr(ah.hold_reason,1,25) hold_reason, 
            ah.invoice_id, ah.release_lookup_code, substr(ah.release_reason,1,25) release_reason, 
            ah.status_flag, ah.org_id
    FROM 	  AP_HOLDS_ALL ah,
            ap_hold_codes ahc
    WHERE   ahc.hold_lookup_code = ah.hold_lookup_code
    and     nvl(ahc.postable_flag,''N'') = ''N''
    and     ah.invoice_id                = NVL(##$$INVID$$##, -99)
    and     ah.release_lookup_code is NULL',
      p_title                  => 'Invoice has a non-postable hold',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice has a non-postable hold',
      p_solution               => '<ul>
   <li>Invoice has a non-postable hold that must be resolved before accounting can be created</li>
   <li>Review and fix the hold from the Invoice Workbench</li>   
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_hold');



debug('begin add_signature: ap_psa_cleanup_s_2');
  add_signature(
      p_sig_id                 => 'ap_psa_cleanup_s_2',
      p_sig_sql                => 'SELECT aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.line_type_lookup_code,
            aid.amount,
            aid.base_amount,
            aid.match_status_flag,
            aid.bc_event_id,
            xe.event_status_code,
            xe.process_status_code,
            aid.encumbered_flag,
            aid.accounting_event_id,
            aid.posted_flag,
            aid.po_distribution_id
     FROM ap_invoice_distributions_all aid,
          xla_events xe,
          financials_system_params_all fsp,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE nvl(aid.historical_flag,   ''N'') = ''N''
     AND   nvl(aid.posted_flag, ''N'') <> ''Y''
     AND   aid.po_distribution_id is null
     AND   aid.org_id = fsp.org_id
     AND   nvl(fsp.purch_encumbrance_flag, ''N'') = ''Y''
     AND   aid.encumbered_flag = ''Y''
     AND   aid.match_status_flag = ''A''
     AND   aid.bc_event_id = xe.event_id(+)
     AND   xe.application_id(+) = 200
     AND   (nvl(xe.event_id, -99) = -99 OR
            (nvl(xe.event_id, -99) <> -99 AND
             xe.event_status_code <> ''P''))
     AND   nvl(aid.reversal_flag,   ''N'') <> ''Y''
     AND   aid.invoice_id = invs.invoice_id',
      p_title                  => 'Approved Distributions Containing Unprocessed Budgetary Control Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Approved distributions containing unprocessed budgetary control events causing the actual accounting of the invoice to fail',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [985228.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_psa_cleanup_s_2');



debug('begin add_signature: ap_del_pay_clr_sel');
  add_signature(
      p_sig_id                 => 'ap_del_pay_clr_sel',
      p_sig_sql                => 'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.check_date,
            aph.payment_history_id,
            aph.transaction_type,
            aph.accounting_event_id
     FROM ap_payment_history_all aph,
          ap_checks_all ac,
          xla_events xe
     WHERE ac.check_id = aph.check_id
     AND   xe.event_id = aph.accounting_event_id
     AND   aph.posted_flag <> ''Y''
     AND   aph.transaction_type like ''%CLEARING''
     AND   xe.event_status_code NOT IN (''N'',''P'')
     AND   xe.application_id = 200
     AND   EXISTS (
             SELECT 1
             FROM ap_payment_history_all h2,
                  xla_ae_headers xh,
                  xla_ae_lines xl
             WHERE h2.check_id = aph.check_id
             AND   h2.transaction_type IN
                     (''PAYMENT CREATED'',''REFUND RECORDED'',
                      ''PAYMENT MATURITY'')
             AND   h2.posted_flag = ''Y''
             AND   xh.event_id = h2.accounting_event_id
             AND   xl.ae_header_id = xh.ae_header_id
             AND   xl.application_id = 200
             AND   xh.application_id = 200
             AND   xl.accounting_class_code = ''CASH'')
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Payment Clearing Event Not Accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment clearing event do not get accounted when recon_accounting_flag is changed after payment accounting',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1146638.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_del_pay_clr_sel');



debug('begin add_signature: ap_inv_hold');
  add_signature(
      p_sig_id                 => 'ap_inv_hold',
      p_sig_sql                => 'SELECT xe.event_id, xe.event_date, xe.event_status_code, xe.process_status_code,xe.event_type_code,xte.entity_code,xte.source_id_int_1 source_id,
	     xte.transaction_number,xe.budgetary_control_flag,xte.security_id_int_1,xte.ledger_id, ''Release Invoice Hold''
  FROM xla_events xe,
       xla_transaction_entities_upg xte
  WHERE xte.entity_id=xe.entity_id
  AND xte.application_id=200
  AND xe.application_id=200
  AND xe.event_status_code=''I''
  and xte.source_id_int_1 = NVL(##$$INVID$$##, -99)
  AND xte.entity_code = ''AP_INVOICES''
  AND exists (SELECT 1
                          FROM ap_holds_all AH
                          WHERE invoice_id=xte.source_id_int_1
                          AND xte.ENTITY_CODE=''AP_INVOICES''
           AND AH.RELEASE_LOOKUP_CODE is null)
    UNION
    SELECT xe.event_id,xe.event_date,xe.event_status_code,xe.process_status_code,xe.event_type_code,xte.entity_code,xte.source_id_int_1 source_id,
          xte.transaction_number,xe.budgetary_control_flag,xte.security_id_int_1,xte.ledger_id,''Validate Invoice''
    FROM xla_events xe,
         xla_transaction_entities_upg xte
    WHERE xte.entity_id=xe.entity_id
   AND xte.application_id=200
   AND xe.application_id=200
   AND xe.event_status_code=''I''
   and xte.source_id_int_1 = NVL(##$$INVID$$##, -99)
   AND xte.entity_code = ''AP_INVOICES''
   AND exists (SELECT 1
         FROM ap_invoice_distributions_all aid,
              financials_system_params_all fsp
         WHERE aid.invoice_id = NVL(XTE.source_id_int_1, -99)
         AND xte.entity_code = ''AP_INVOICES''
         AND xte.ledger_id = aid.set_of_books_id
         AND aid.org_id = fsp.org_id
         AND aid.set_of_books_id = fsp.set_of_books_id
         AND ( (NVL(fsp.purch_encumbrance_flag,''N'') = ''N''
                AND aid.match_Status_flag NOT IN (''T'',''A'') )
                OR ((NVL(fsp.purch_encumbrance_flag,''N'') = ''Y''
                     AND aid.match_Status_flag != ''A''))))',
      p_title                  => 'Unaccounted Invoice Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unaccounted invoice events with event_status_code as I',
      p_solution               => '<ul>
    <li>Release invoice hold refer Doc id [1417598.2] Use tab > Validation and Holds link</li>
   <li>Validate invoice refer Doc id [1417598.2] Use tab > Validation and Holds link</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_inv_hold');



debug('begin add_signature: ap_AcctgDateOutOfSynch_sel');
  add_signature(
      p_sig_id                 => 'ap_AcctgDateOutOfSynch_sel',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT /*+ ordered use_nl(ai, aid, xe) */
            ai.invoice_id,
            ai.invoice_num,
            aid.org_id,
            to_char(aid.accounting_date, ''DD-MON-YY HH24:MI:SS'') accounting_date,
            to_char(xe.event_date, ''DD-MON-YY HH24:MI:SS'') event_date,
            xe.event_id,
            aid.posted_flag,
            aid.invoice_distribution_id,
            null rec_nrec_tax_dist_id,
            null prepay_history_id,
            ''Invoice Distribution'' trx_type
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          xla_events xe
     WHERE aid.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   ai.invoice_id = aid.invoice_id
     AND   aid.accounting_date <> xe.event_date
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, aid, xe) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            to_char(aid.accounting_date, ''DD-MON-YY HH24:MI:SS''),
            to_char(xe.event_date, ''DD-MON-YY HH24:MI:SS''),
            xe.event_id,
            aid.posted_flag,
            aid.invoice_distribution_id,
            null,
            null,
            ''Self Assessed Tax Dist''
     FROM invs,
          ap_invoices_all ai,
          ap_self_assessed_tax_dist_all aid,
          xla_events xe
     WHERE aid.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   ai.invoice_id = aid.invoice_id
     AND   aid.accounting_DATE <> xe.event_date
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, aid, zrnd, xe) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            to_char(zrnd.gl_date, ''DD-MON-YY HH24:MI:SS''),
            to_char(xe.event_date, ''DD-MON-YY HH24:MI:SS''),
            xe.event_id,
            aid.posted_flag,
            null,
            zrnd.rec_nrec_tax_dist_id,
            null,
            ''Tax Detail For Inv Dist''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          zx_rec_nrec_dist zrnd,
          xla_events xe
     WHERE aid.accounting_event_id = xe.event_id
     AND   aid.detail_tax_dist_id = zrnd.rec_nrec_tax_dist_id
     AND   zrnd.application_id = 200
     AND   zrnd.entity_code = ''AP_INVOICES''
     AND   zrnd.event_class_code IN (''STANDARD INVOICES'',
             ''PREPAYMENT INVOICES'', ''EXPENSE REPORTS'')
     AND   zrnd.trx_id = aid.invoice_id
     AND   aid.invoice_id = ai.invoice_id
     AND   xe.application_id = 200
     AND   zrnd.gl_date <> xe.event_date
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            to_char(zrnd.gl_date, ''DD-MON-YY HH24:MI:SS''),
            to_char(xe.event_date, ''DD-MON-YY HH24:MI:SS''),
            xe.event_id,
            aid.posted_flag,
            null,
            zrnd.rec_nrec_tax_dist_id,
            null,
            ''Tax Detail for Self Assessed Tax Dist''
     FROM invs,
          ap_invoices_all ai,
          ap_self_assessed_tax_dist_all aid,
          zx_rec_nrec_dist zrnd,
          xla_events xe
     WHERE aid.accounting_event_id = xe.event_id
     AND   aid.detail_tax_dist_id = zrnd.rec_nrec_tax_dist_id
     AND   zrnd.application_id = 200
     AND   zrnd.entity_code = ''AP_INVOICES''
     AND   zrnd.event_class_code IN (''STANDARD INVOICES'',
             ''PREPAYMENT INVOICES'', ''EXPENSE REPORTS'')
     AND   zrnd.trx_id = aid.invoice_id
     AND   aid.invoice_id = ai.invoice_id
     AND   xe.application_id = 200
     AND   zrnd.gl_date <> xe.event_date
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            to_char(apph.accounting_date, ''DD-MON-YY HH24:MI:SS''),
            to_char(xe.event_date, ''DD-MON-YY HH24:MI:SS''),
            xe.event_id,
            apph.posted_flag,
            null,
            null,
            apph.prepay_history_id,
            ''Prepay History''
     FROM invs,
          ap_invoices_all ai,
          ap_prepay_history_all apph,
          xla_events xe
     WHERE apph.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   ai.invoice_id = apph.invoice_id
     AND   apph.accounting_date <> xe.event_date
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Out-of-sync Accounting dates',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accounting date in transactional table is not in sync with the events table',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [874904.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_AcctgDateOutOfSynch_sel');



debug('begin add_signature: ap_payDistsMissInPrior_sel');
  add_signature(
      p_sig_id                 => 'ap_payDistsMissInPrior_sel',
      p_sig_sql                => 'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            aip.invoice_id,
            aph.transaction_type,
            aph.accounting_event_id,
            aid.invoice_distribution_id
     FROM ap_checks_all ac,
          ap_payment_history_all aph,
          ap_invoice_payments_all aip,
          ap_invoice_distributions_all aid,
          xla_ae_headers xah
     WHERE ac.check_id = NVL(##$$CHKID$$##,-99)
     AND   aid.invoice_id = aip.invoice_id
     AND   aip.check_id = aph.check_id
     AND   aph.accounting_event_id = xah.event_id
     AND   aph.check_id = ac.check_id
     AND   nvl(aid.awt_invoice_payment_id, aip.invoice_payment_id) =
             aip.invoice_payment_id
     AND   ac.void_date is null
     AND   aip.reversal_inv_pmt_id is null
     AND   aid.set_of_books_id = xah.ledger_id
     AND   xah.application_id = 200
     AND   aph.transaction_type IN (''PAYMENT CREATED'',
             ''REFUND RECORDED'' ,''MANUAL PAYMENT ADJUSTED'',
             ''MANUAL REFUND ADJUSTED'')
     AND   aid.last_update_date > xah.creation_date
     AND   aid.posted_flag = ''Y''
     AND   aph.posted_flag = ''Y''
     AND   NVL (aph.historical_flag, ''N'') = ''N''
     AND   NOT EXISTS (
             SELECT 1 FROM ap_payment_history_all aph1
             WHERE aph1.check_id = aph.check_id
             AND   aph1.invoice_adjustment_event_id = aid.accounting_event_id)
     AND   NOT EXISTS (
             SELECT 1 FROM ap_payment_hist_dists aphd
             WHERE aphd.accounting_event_id = aph.accounting_event_id
             AND   aphd.invoice_payment_id = aip.invoice_payment_id
             AND   aphd.invoice_distribution_id = aid.invoice_distribution_id)
     UNION ALL
     SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            aip.invoice_id,
            aph.transaction_type,
            aph.accounting_event_id,
            aid.invoice_distribution_id
     FROM ap_checks_all ac,
          ap_payment_history_all aph,
          ap_invoice_payments_all aip,
          ap_invoice_distributions_all aid,
          xla_ae_headers xah
     WHERE ac.check_id = NVL(##$$CHKID$$##,-99)
     AND   aid.invoice_id = aip.invoice_id
     AND   aip.check_id = aph.check_id
     AND   aph.accounting_event_id = xah.event_id
     AND   aph.check_id = ac.check_id
     AND   ac.void_date is null
     AND   aip.reversal_inv_pmt_id is null
     AND   aid.set_of_books_id = xah.ledger_id
     AND   xah.application_id = 200
     AND   aph.transaction_type IN (
             ''PAYMENT ADJUSTED'', ''REFUND ADJUSTED'')
     AND   aph.invoice_adjustment_event_id = aid.accounting_event_id
     AND   aid.last_update_date > xah.creation_date
     AND   aid.posted_flag = ''Y''
     AND   aph.posted_flag = ''Y''
     AND   NVL (aph.historical_flag, ''N'') = ''N''
     AND   NOT EXISTS (
             SELECT 1 FROM ap_payment_hist_dists aphd
             WHERE aphd.accounting_event_id = aph.accounting_event_id
             AND aphd.invoice_payment_id = aip.invoice_payment_id
             AND aphd.invoice_distribution_id = aid.invoice_distribution_id)',
      p_title                  => 'Payment Clearing Event Cannot Be Accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment clearing event cannot be Accounted with error 0 because the Related payment created/maturity/adjusted/Maturity Adjusted events are not prorated across all invoice distributions',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1177653.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_payDistsMissInPrior_sel');



debug('begin add_signature: ap_unacct_trx_closed_prd_sel');
  add_signature(
      p_sig_id                 => 'ap_unacct_trx_closed_prd_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai, xte, xe) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xe.event_type_code event_type,
            xe.event_date,
            xte.entity_code,
            xte.ledger_id,
            xte.source_id_int_1 transaction_id,
            xte.transaction_number,
            xte.Security_Id_Int_1 transaction_org_id,
            ''Run fix script'' sweep_to_date
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          xla_transaction_entities_upg xte,
          xla_events xe,
          ap_system_parameters_all asp,
          gl_period_statuses gps
     WHERE xe.application_id = 200
     AND   xte.application_id = 200
     AND   xe.entity_id = xte.entity_id
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.ledger_id = ai.set_of_books_id
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   xe.event_status_code IN (''I'',''U'')
     AND   xe.process_status_code IN (''I'',''U'',''R'')
     AND   xte.security_id_int_1 = asp.org_id
     AND   gps.application_id = 200
     AND   gps.set_of_books_id = asp.set_of_books_id
     AND   trunc(xe.event_date) between gps.start_date and gps.end_date
     AND   gps.closing_status not in (''O'',''F'')
     AND   nvl(adjustment_period_flag, ''N'') = ''N''
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Unaccounted Payables Transactions In A Closed Period',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unaccounted accounting events having event dates in closed periods.',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [875012.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_unacct_trx_closed_prd_sel');



debug('begin add_signature: ap_PayWrongEvtId_sel');
  add_signature(
      p_sig_id                 => 'ap_PayWrongEvtId_sel',
      p_sig_sql                => 'SELECT ''Type 1'' corruption_type,
            aip.check_id,
            aip.org_id ,
            aip.accounting_event_id wrong_event_id,
            aph.accounting_event_id correct_event_id,
            aph.accounting_date correct_date,
            aip.posted_flag aip_posted_flag
     FROM ap_payment_history_all aph,
          ap_invoice_payments_all aip
     WHERE aph.check_id = aip.check_id
     AND   aph.transaction_type in (''PAYMENT CREATED'', ''REFUND RECORDED'')
     AND   aph.accounting_event_id != aip.accounting_event_id
     AND   aph.posted_flag != ''Y''
     AND   aip.posted_flag = ''Y''
     AND   aip.reversal_inv_pmt_id is null
     AND   aph.check_id = NVL(##$$CHKID$$##,-99)
     UNION ALL
     SELECT ''Type 2'',
             aip.check_id,
             aip.org_id ,
             aip.accounting_event_id wrong_event_id,
             aph.accounting_event_id correct_event_id,
             aph.accounting_date correct_date,
             aip.posted_flag
     FROM  ap_invoice_payments_all aip,
           ap_payment_history_all aph
     WHERE aph.check_id = aip.check_id
     AND   aph.transaction_type in (''PAYMENT CREATED'', ''REFUND RECORDED'')
     AND   aph.accounting_event_id != aip.accounting_event_id
     AND   aph.posted_flag != ''Y''
     AND   aip.posted_flag != ''Y''
     AND   aip.reversal_inv_pmt_id is null
     AND   aip.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Accounting Event Id is Out-of-sync',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accounting_event_id is out-of-sync between AP_Invoice_Payments_all and AP_Payment_History_All tables',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1264147.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_PayWrongEvtId_sel');



debug('begin add_signature: ap_inv_event_status_code_sel');
  add_signature(
      p_sig_id                 => 'ap_inv_event_status_code_sel',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xe.event_date,
            xe.event_status_code,
            xe.process_status_code,
            xe.budgetary_control_flag,
            xte.entity_code,
            xte.source_id_int_1 source_id,
            xte.ledger_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          xla_transaction_entities_upg xte,
          xla_events xe
     WHERE ai.invoice_id = invs.invoice_id
     AND   xte.entity_id = xe.entity_id
     AND   xte.application_id = 200
     AND   xe.application_id = 200
     AND   xe.event_status_code = ''I''
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.ledger_id = ai.set_of_books_id
     AND   NOT EXISTS (
             SELECT 1 FROM ap_holds_all ah
             WHERE ah.invoice_id = xte.source_id_int_1
             AND   xte.entity_code = ''AP_INVOICES''
             AND   ah.release_lookup_code is null)
     AND   NOT EXISTS (
             SELECT 1
             FROM ap_invoice_distributions_all aid,
                  financials_system_params_all fsp
             WHERE aid.invoice_id = nvl(xte.source_id_int_1, -99)
             AND   xte.entity_code = ''AP_INVOICES''
             AND   xte.ledger_id = aid.set_of_books_id
             AND   aid.org_id = fsp.org_id
             AND   aid.set_of_books_id = fsp.set_of_books_id
             AND   ((nvl(fsp.purch_encumbrance_flag,''N'') = ''N'' AND
                     aid.match_status_flag NOT IN (''T'',''A'')) OR
                    (nvl(fsp.purch_encumbrance_flag,''N'') = ''Y'' AND
                     aid.match_Status_flag != ''A'')))
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id',
      p_title                  => 'Accounting Events Marked As Incomplete',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accounting Events marked as Incomplete in the Accounting events table even though the Invoices related to the event do not contain any Non-Postable holds',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [742429.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_inv_event_status_code_sel');



debug('begin add_signature: ap_posted_flag_out_sync_sel');
  add_signature(
      p_sig_id                 => 'ap_posted_flag_out_sync_sel',
      p_sig_sql                => 'SELECT ''AP_INVOICE_PAYMENTS_ALL'' transaction_table,
            ac.check_id,
            ac.check_number,
            ac.org_id,
            invoice_payment_id transaction_id,
            posted_flag,
            event_id,
            event_status_code,
            decode(event_status_code, ''P'',''Y'',''N'') events_posted_flag,
            aip.invoice_id,
            invoice_num
     FROM ap_checks_all ac,
          ap_invoice_payments_all aip,
          xla_events xe,
          ap_invoices_all ai
     WHERE aip.posted_flag = ''S''
     AND   xe.application_id = 200
     AND   xe.event_id = aip.accounting_event_id
     AND   ac.check_id = aip.check_id
     AND   ai.invoice_id = aip.invoice_id
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)
     UNION ALL
     SELECT ''AP_PAYMENT_HISTORY_ALL'',
            ac.check_id,
            ac.check_number,
            ac.org_id,
            payment_history_id,
            posted_flag,
            event_id ,
            event_status_code,
            decode(event_status_code, ''P'',''Y'',''N'') events_posted_flag,
            null,
            null
     FROM ap_checks_all ac,
          ap_payment_history_all aph,
          xla_events xe
     WHERE aph.posted_flag = ''S''
     AND   xe.application_id = 200
     AND   xe.event_id = aph.accounting_event_id
     AND   ac.check_id = aph.check_id
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Transaction Stuck In Posted Flag Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Posted Flag stuck in status ''S'' on transaction tables',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1088872.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_posted_flag_out_sync_sel');



debug('begin add_signature: ap_incorrect_posted_flag_sel');
  add_signature(
      p_sig_id                 => 'ap_incorrect_posted_flag_sel',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT ai.invoice_id,
            ai.invoice_num,
            aid.org_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            ''ap_invoice_distributions_all'' trx_table,
            aid.invoice_distribution_id trx_id,
            aid.posted_flag,
            aid.accrual_posted_flag,
            aid.cash_posted_flag,
            xe.event_id,
            aid.set_of_books_id ledger_id
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          xla_events xe,
          gl_ledgers gl
     WHERE (aid.posted_flag = ''N'' OR
            (aid.accrual_posted_flag = ''N'' AND
             nvl(gl.sla_ledger_cash_basis_flag, ''N'') <> ''Y''))
     AND   ai.set_of_books_id = gl.ledger_id
     AND   xe.process_status_code = ''P''
     AND   xe.event_status_code   IN (''N'',''P'')
     AND   ai.invoice_id = aid.invoice_id
     AND   xe.event_id = aid.accounting_event_id
     AND   xe.application_id = 200
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            astd.invoice_line_number,
            astd.distribution_line_number,
            ''ap_self_assessed_tax_dist_all'' trx_table,
            astd.invoice_distribution_id trx_id,
            astd.posted_flag,
            astd.accrual_posted_flag,
            astd.cash_posted_flag,
            xe.event_id,
            astd.set_of_books_id ledger_id
     FROM invs,
          ap_invoices_all ai,
          ap_self_assessed_tax_dist_all astd,
          xla_events xe,
          gl_ledgers gl
     WHERE (astd.posted_flag = ''N'' OR
            (astd.accrual_posted_flag = ''N'' AND
             nvl(gl.sla_ledger_cash_basis_flag, ''N'') <> ''Y''))
     AND   ai.set_of_books_id = gl.ledger_id
     AND   xe.process_status_code = ''P''
     AND   xe.event_status_code   IN (''N'',''P'')
     AND   ai.invoice_id = astd.invoice_id
     AND   xe.event_id = astd.accounting_event_id
     AND   xe.application_id = 200
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            aph.prepay_line_num,
            NULL,
            ''ap_prepay_history_all'' trx_table,
            aph.prepay_history_id trx_id,
            aph.posted_flag,
            null,
            null,
            xe.event_id,
            xte.ledger_id ledger_id
     FROM invs,
          ap_invoices_all ai,
          ap_prepay_history_all aph,
          xla_events xe,
          xla_transaction_entities_upg xte
     WHERE posted_flag = ''N''
     AND   process_status_code = ''P''
     AND   xe.event_status_code   IN (''N'',''P'')
     AND   ai.invoice_id = aph.prepay_invoice_id
     AND   xte.security_id_int_1 = aph.org_id
     AND   xe.event_id = aph.accounting_event_id
     AND   xe.entity_id = xte.entity_id
     AND   xe.application_id = xte.application_id
     AND   xte.application_id = 200
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Out-of-sync Posting Status Between The Accounting Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Out-of-sync posting status between the accounting events in the events tables and the transaction tables',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1071876.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_incorrect_posted_flag_sel');



debug('begin add_signature: ap_xla_ae_x_bcc_sel');
  add_signature(
      p_sig_id                 => 'ap_xla_ae_x_bcc_sel',
      p_sig_sql                => 'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.amount ,
            ac.vendor_name supplier,
            aph.transaction_type event_type,
            aph.accounting_event_id event_id,
            xal.accounting_class_code,
            xal.business_class_code,
            xah.ae_header_id
     FROM ap_checks_all ac,
  	ap_payment_history_all aph,
          xla_ae_headers xah,
          xla_ae_lines xal
     WHERE aph.accounting_event_id = xah.event_id
     AND   aph.check_id in (
             SELECT distinct h1.check_id
             FROM ap_payment_history_all h1,
                  ap_payment_history_all h2
             WHERE  h1.historical_flag = ''Y''
             AND    h1.transaction_type = ''PAYMENT CREATED''
             AND    h1.posted_flag = ''Y''
             AND    h2.check_id = h1.check_id
             AND    h2.posted_flag = ''N''
             AND    h2.transaction_type = ''PAYMENT MATURITY'')
     AND   xah.application_id = 200
     AND   xah.ae_header_id = xal.ae_header_id
     AND   xal.application_id = 200
     AND   aph.posted_flag = ''Y''
     AND   aph.transaction_type  IN(''MANUAL PAYMENT ADJUSTED'',
             ''PAYMENT CREATED'',''PAYMENT ADJUSTED'')
     AND   xal.accounting_class_code = ''FUTURE_DATED_PMT''
     AND   xal.business_class_code like ''AP_FUTURE_DTD_PMT''
     AND   ac.check_id = aph.check_id
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Incorrect Business Class Codes For Upgraded Future Dated Payments',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Upgraded future dated paymenst with incorrect business class codes in xla_ae_lines',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1370114.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_xla_ae_x_bcc_sel');



debug('begin add_signature: ap_xdl_pop_sel');
  add_signature(
      p_sig_id                 => 'ap_xdl_pop_sel',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT /*+ ordered */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xte.entity_id,
            xah.ae_header_id,
            xte.source_id_int_1 transaction_id,
            xte.transaction_number,
            xte.entity_code,
            xte.ledger_id,
            ai.gl_date transaction_date,
            (
              SELECT migration_status_code
              FROM gl_period_statuses upg
              WHERE upg.application_id = 200
              AND   upg.adjustment_period_flag=''N''
              AND   upg.closing_status in (''O'',''C'',''P'')
              AND   ai.gl_date BETWEEN upg.start_date AND upg.end_date
              AND   upg.ledger_id = xte.ledger_id
            ) migration_status_code
     FROM invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp,
          ap_invoice_distributions_all aid,
          xla_transaction_entities_upg xte,
          xla_events xe,
          xla_ae_headers xah,
          xla_distribution_links xdl
     WHERE aid.posted_flag = ''N''
     AND   aid.org_id = asp.org_id
     AND   aid.invoice_id = ai.invoice_id
     AND   ai.historical_flag = ''Y''
     AND   ai.invoice_id = nvl(xte.source_id_int_1,-99)
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.application_id = 200
     AND   xte.entity_id = xe.entity_id
     AND   xe.application_id = 200
     AND   xe.event_status_code = ''P''
     AND   xe.upg_batch_id is not null
     AND   xe.upg_batch_id <> - 9999
     AND   xah.application_id = 200
     AND   xah.event_id = xe.event_id
     AND   xah.upg_batch_id is not null
     AND   xte.ledger_id = xah.ledger_id
     AND   asp.org_id = ai.org_id
     AND   asp.set_of_books_id = xte.ledger_id
     AND   xah.ae_header_id = xdl.ae_header_id (+)
     AND   xdl.ae_header_id is null
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xte.entity_id,
            xah.ae_header_id,
            xte.source_id_int_1 transaction_id,
            xte.transaction_number,
            xte.entity_code,
            xte.ledger_id,
            ai.gl_date transaction_date,
            (
              SELECT migration_status_code
              FROM gl_period_statuses upg
              WHERE upg.application_id = 200
              AND   upg.adjustment_period_flag=''N''
              AND   upg.closing_status in (''O'',''C'',''P'')
              AND   ai.gl_date BETWEEN upg.start_date AND upg.end_date
              AND   upg.ledger_id = xte.ledger_id
            ) migration_status_code
     FROM invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp,
          ap_prepay_history_all aph,
          ap_invoice_distributions_all aid,
          xla_transaction_entities_upg xte,
          xla_events xe,
          xla_ae_headers xah,
          xla_distribution_links xdl
     WHERE aid.posted_flag = ''N''
     AND   aid.prepay_distribution_id is not null
     AND   aid.org_id = asp.org_id
     AND   aid.accounting_event_id = aph.accounting_event_id
     AND   aid.invoice_id = aph.invoice_id
     AND   aph.prepay_invoice_id = ai.invoice_id
     AND   ai.invoice_id = nvl(xte.source_id_int_1,-99)
     AND   ai.historical_flag = ''Y''
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.application_id = 200
     AND   xte.entity_id = xe.entity_id
     AND   xe.application_id = 200
     AND   xe.event_status_code = ''P''
     AND   xe.upg_batch_id is not null
     AND   xe.upg_batch_id <> - 9999
     AND   xah.application_id = 200
     AND   xah.event_id = xe.event_id
     AND   xah.upg_batch_id is not null
     AND   xte.ledger_id = xah.ledger_id
     AND   asp.org_id = ai.org_id
     AND   asp.set_of_books_id = xte.ledger_id
     AND   xah.ae_header_id = xdl.ae_header_id (+)
     AND   xdl.ae_header_id is null
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xte.entity_id,
            xah.ae_header_id,
            xte.source_id_int_1 transaction_id,
            xte.transaction_number,
            xte.entity_code,
            xte.ledger_id,
            ai.gl_date transaction_date,
            (
              SELECT migration_status_code
              FROM gl_period_statuses upg
              WHERE upg.application_id = 200
              AND   upg.adjustment_period_flag=''N''
              AND   upg.closing_status in (''O'',''C'',''P'')
              AND   ai.gl_date BETWEEN upg.start_date AND upg.end_date
              AND   upg.ledger_id = xte.ledger_id
            ) migration_status_code
     FROM invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp,
          ap_invoice_payments_all aip,
          xla_transaction_entities_upg xte,
          xla_events xe,
          xla_ae_headers xah,
          xla_distribution_links xdl
     WHERE aip.accrual_posted_flag = ''N''
     AND   aip.org_id=asp.org_id
     AND   aip.invoice_id = ai.invoice_id
     AND   ai.historical_flag=''Y''
     AND   ai.invoice_id = nvl(xte.source_id_int_1,-99)
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.application_id = 200
     AND   xte.entity_id = xe.entity_id
     AND   xe.application_id = 200
     AND   xe.event_status_code = ''P''
     AND   xe.upg_batch_id is not null
     AND   xe.upg_batch_id <> - 9999
     AND   xah.application_id = 200
     AND   xah.upg_batch_id is not null
     AND   xah.event_id = xe.event_id
     AND   xte.ledger_id = xah.ledger_id
     AND   asp.org_id = ai.org_id
     AND   asp.set_of_books_id = xte.ledger_id
     AND   xah.ae_header_id = xdl.ae_header_id (+)
     AND   xdl.ae_header_id is null
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Historical Upgraded Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Historical upgraded events which are missing in xla_distribution_links causing errors when accounting downstream transactions',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1054322.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_xdl_pop_sel');



debug('begin add_signature: ap_x_posted_flag_sel');
  add_signature(
      p_sig_id                 => 'ap_x_posted_flag_sel',
      p_sig_sql                => 'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.vendor_name Supplier,
            aph.posted_flag,
            xe.event_id,
            xe.event_status_code
     FROM ap_payment_history_all aph,
          ap_checks_all ac,
          xla_events xe,
          ap_system_parameters_all asp
     WHERE aph.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   aph.posted_flag = ''Y''
     AND   ac.check_id = aph.check_id
     AND   xe.event_status_code = ''U''
     AND   asp.org_id = aph.org_id
     AND   xe.event_type_code = ''PAYMENT CREATED''
     AND   asp.when_to_account_pmt = ''CLEARING ONLY''
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'Incorrect Posted Flag In ap_payment_history_all',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Incorrect posted flag exist in ap_payment_history_all for payments set to account at clearing only',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1388157.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_x_posted_flag_sel');



debug('begin add_signature: xla_mulent_sel');
  add_signature(
      p_sig_id                 => 'xla_mulent_sel',
      p_sig_sql                => 'SELECT /*+ leading(invs) use_nl(ai, xte2) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xte2.application_id,
            xte2.entity_id,
            xte2.ledger_id,
            xte2.entity_code,
  	  xte2.source_id_int_1,
            xte2.transaction_number,
            count(DISTINCT xe2.event_id) event_count
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          xla_transaction_entities_upg xte2,
          xla_events xe2
     WHERE 1 < (
             SELECT count(*)
             FROM xla_transaction_entities_upg xte
             WHERE xte.application_id = xte2.application_id
             AND   xte.ledger_id = xte2.ledger_id
             AND   xte.entity_code = xte2.entity_code
             AND   nvl(xte.source_id_int_1,-99) = xte2.source_id_int_1)
     AND   xe2.application_id(+) = xte2.application_id
     AND   xe2.entity_id(+) = xte2.entity_id
     AND   xte2.ledger_id = ai.set_of_books_id
     AND   xte2.application_id = 200
     AND   xte2.entity_code = ''AP_INVOICES''
     AND   nvl(xte2.source_id_int_1, -99) = ai.invoice_id
     AND   ai.invoice_id = invs.invoice_id
     GROUP BY ai.invoice_id, ai.invoice_num, ai.org_id,
              xte2.application_id, xte2.entity_id, xte2.ledger_id,
              xte2.entity_code, xte2.source_id_int_1, xte2.transaction_number',
      p_title                  => 'Multiple Entities Created For Payments Or Invoices',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoices with multiple transaction entity records exist in SLA',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1133423.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: xla_mulent_sel');



debug('begin add_signature: ap_all_upg_pay_cancel_sel');
  add_signature(
      p_sig_id                 => 'ap_all_upg_pay_cancel_sel',
      p_sig_sql                => 'SELECT aph.check_id,
            aph.org_id,
            aph.payment_history_id,
            aph.accounting_event_id,
            aph.accounting_date,
            aph.transaction_type,
            aph.related_event_id,
            aph.rev_pmt_hist_id
     FROM ap_payment_history_all aph,
          xla_events xe
     WHERE aph.historical_flag     = ''Y''
     AND transaction_type IN(''REFUND CANCELLED'', ''PAYMENT CANCELLED'')
     AND (aph.related_event_id IS NULL OR aph.rev_pmt_hist_id IS NULL)
     AND aph.accounting_event_id = xe.event_id
     AND xe.application_id       = 200
     AND xe.upg_batch_id        IS NOT NULL
     AND EXISTS (
             SELECT 1 FROM ap_payment_history_all aph2
             WHERE aph.check_id = aph2.check_id
             AND aph2.transaction_type IN(''PAYMENT CREATED'', ''REFUND RECORDED''))
     AND   aph.check_id = NVL(##$$CHKID$$##,-99)
     UNION ALL
     SELECT aph1.check_id,
            aph1.org_id,
            aph1.payment_history_id,
            aph1.accounting_event_id,
            aph1.accounting_date,
            aph1.transaction_type,
            aph1.related_event_id,
            aph1.rev_pmt_hist_id
     FROM ap_payment_history_all aph1,
          ap_payment_history_all aph2,
          xla_ae_headers xeh
     WHERE aph1.check_id = NVL(##$$CHKID$$##,-99)
     AND   aph1.posted_flag = ''N''
     AND   aph1.transaction_type IN (''REFUND CANCELLED'', ''PAYMENT CANCELLED'')
     AND   aph1.related_event_id = xeh.event_id
     AND   xeh.application_id = 200
     AND   xeh.upg_batch_id is not null
     AND   aph1.check_id = aph2.check_id
     AND   aph1.rev_pmt_hist_id = aph2.payment_history_id
     AND   aph1.related_event_id = aph2.accounting_event_id
     AND   aph2.transaction_type  IN  (''PAYMENT CREATED'', ''REFUND RECORDED'')
     AND   EXISTS (
             SELECT 1 FROM ap_payment_hist_dists aphd
             WHERE aphd.payment_history_id  = aph2.payment_history_id
             AND aphd.accounting_event_id = aph2.accounting_event_id
             AND aphd.reversal_flag = ''Y'')',
      p_title                  => 'Upgraded Payment Events Is Missing',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Upgraded payment events have null values in related_event_id or rev_pmt_hist_id columns for refund or payment cancellations',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1457624.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_all_upg_pay_cancel_sel');



debug('begin add_signature: ap_inv_pay_missing_cancel_check_sel');
  add_signature(
      p_sig_id                 => 'ap_inv_pay_missing_cancel_check_sel',
      p_sig_sql                => 'SELECT aph.check_id,
            aph.accounting_event_id,
            aph.transaction_type,
            aph.accounting_date,
            aph.posted_flag,
            aph.org_id
     FROM ap_checks_all ac,
          ap_payment_history_all aph
     WHERE ac.check_id = NVL(##$$CHKID$$##,-99)
     AND   ac.status_lookup_code = ''NEGOTIABLE''
     AND   aph.check_id = ac.check_id
     AND   aph.transaction_type = ''PAYMENT CANCELLED''
     AND   NOT EXISTS (
             SELECT 1 FROM ap_invoice_payments_all p
             WHERE p.check_id = ac.check_id
             AND   (p.accounting_event_id = aph.accounting_event_id OR
                    p.reversal_inv_pmt_id is not null))
     AND   EXISTS (
             SELECT 1 FROM ap_invoice_payments_all p2
             WHERE p2.check_id = ac.check_id
             AND   p2.reversal_inv_pmt_id is null)',
      p_title                  => 'Payment Cancelations Not Accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment cancelations are not being accounted because of missing invoice payment rows',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_inv_pay_missing_cancel_check_sel');



debug('begin add_signature: AP_AWT_RELATED_ID_SEL');
  add_signature(
      p_sig_id                 => 'AP_AWT_RELATED_ID_SEL',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     ),
     man_nonrev_awt_on_rev_itm AS (
       SELECT /*+ leading(invs) use_nl(aid, aid_item) */
              aid.invoice_id,
              aid.invoice_line_number,
              aid.invoice_distribution_id,
              aid.amount,
              sum(aid.amount)
                over(partition by aid.invoice_id, aid.invoice_line_number)
                line_wise_sum
       FROM invs,
            ap_invoice_distributions_all aid,
            ap_invoice_distributions_all aid_item
       WHERE aid.invoice_id = invs.invoice_id
       AND   aid.invoice_id = aid_item.invoice_id
       AND   aid.awt_related_id = aid_item.invoice_distribution_id
       AND   aid.line_type_lookup_code = ''AWT''
       AND   aid.awt_flag = ''M''
       AND   nvl(aid.historical_flag, ''N'') = ''N''
       AND   aid.awt_related_id is not null
       AND   nvl(aid.reversal_flag, ''N'') = ''N''
       AND   aid_item.reversal_flag = ''Y''
     ),
     zero_amt_awt_no_nonrev_itm as (
       SELECT /*+ leading(invs) use_nl(aid) */
              aid.invoice_id,
              aid.invoice_line_number,
              aid.invoice_distribution_id,
              aid.amount,
              sum(aid.amount)
                over(partition by aid.invoice_id, aid.invoice_line_number)
                line_wise_sum,
              sum(aid.amount)
                over(partition by aid.invoice_id)
                inv_wise_sum
       FROM invs,
            ap_invoice_distributions_all aid
       WHERE aid.invoice_id = invs.invoice_id
       AND   aid.line_type_lookup_code = ''AWT''
       AND   aid.awt_related_id is null
       AND   aid.historical_flag = ''Y''
       AND   nvl(aid.reversal_flag, ''N'') = ''N''
       AND   NOT EXISTS (
               SELECT 1 FROM ap_invoice_distributions_all aidx
               WHERE aidx.invoice_id = aid.invoice_id
               AND   aidx.line_type_lookup_code not in (''AWT'',''ERV'',''TERV'')
               AND   aidx.prepay_distribution_id is null
               AND   nvl(aidx.reversal_flag, ''N'') = ''N''
               AND   sign(aidx.amount) <> sign(aid.amount)
               AND   abs(aidx.amount) >= abs(aid.amount))
     )
     SELECT /*+ ordered use_nl(aid) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null related_id,
            aid.awt_invoice_payment_id,
            ''1'' category
     FROM invs,
          ap_invoice_distributions_all aid
     WHERE aid.line_type_lookup_code = ''AWT''
     AND   nvl(aid.historical_flag,''N'') = ''N''
     AND   aid.awt_related_id is null
     AND   aid.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, aid) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null,
            aid.awt_invoice_payment_id,
            ''2''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid
     WHERE aid.line_type_lookup_code = ''AWT''
     AND   aid.historical_flag = ''Y''
     AND   aid.awt_related_id is null
     AND   ai.invoice_id = aid.invoice_id
     AND   ai.payment_status_flag IN (''N'',''P'')
     AND   ai.historical_flag = ''Y''
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, aid) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null,
            aid.awt_invoice_payment_id,
            ''3''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid
     WHERE ai.invoice_id = invs.invoice_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   aid.historical_flag = ''Y''
     AND   aid.awt_related_id is null
     AND   ai.invoice_id = aid.invoice_id
     AND   ai.payment_status_flag = ''Y''
     AND   ai.historical_flag = ''Y''
     AND   EXISTS (
             SELECT /*+ no_unnest ordered use_nl(aph, xe) */ 1
             FROM ap_invoice_payments_all aip,
                  ap_payment_history_all aph,
                  xla_events xe
             WHERE  aip.invoice_id = ai.invoice_id
             AND   aip.check_id = aph.check_id
             AND   xe.event_id = aph.accounting_event_id
             AND   xe.application_id = 200
             AND   (aph.posted_flag = ''N'' OR
                    (aph.posted_flag = ''Y'' AND
                     EXISTS (
                       SELECT 1 FROM xla_ae_headers xh
                       WHERE xh.event_id = xe.event_id
                       AND   xh.application_id = 200
                       AND   nvl(xh.upg_batch_id, -9999) = -9999))))
     UNION ALL
     SELECT /*+ ordered use_nl(aid) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null,
            aid.awt_invoice_payment_id,
            ''4''
     FROM invs,
          ap_invoice_distributions_all aid
     WHERE aid.line_type_lookup_code = ''AWT''
     AND   nvl(aid.historical_flag,''N'') = ''N''
     AND   aid.awt_related_id is not null
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aid_parent
             WHERE aid_parent.invoice_id = aid.invoice_id
             AND   aid.awt_related_id = aid_parent.invoice_distribution_id)
     AND   aid.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(aid, aid_item) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null,
            aid.awt_invoice_payment_id,
            ''5''
     FROM invs,
          ap_invoice_distributions_all aid,
          ap_invoice_distributions_all aid_item
     WHERE aid.invoice_id = aid_item.invoice_id
     AND   aid.awt_related_id = aid_item.invoice_distribution_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   aid.awt_flag = ''A''
     AND   nvl(aid.historical_flag, ''N'') = ''N''
     AND   aid.awt_related_id is not null
     AND   nvl(aid.reversal_flag, ''N'') = ''N''
     AND   aid_item.reversal_flag = ''Y''
     AND   aid.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(aid, aid_erv) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            aid_erv.related_id,
            aid.awt_invoice_payment_id,
            ''6''
     FROM invs,
          ap_invoice_distributions_all aid,
          ap_invoice_distributions_all aid_erv
     WHERE aid.invoice_id = aid_erv.invoice_id
     AND   aid.awt_related_id = aid_erv.invoice_distribution_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   aid.awt_flag = ''A''
     AND   nvl(aid.historical_flag, ''N'') = ''N''
     AND   aid_erv.line_type_lookup_code in (''TERV'', ''ERV'')
     AND   aid.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, aid_awt, aid_item, xe_item) */
            aid_awt.invoice_id,
            aid_awt.org_id,
            aid_awt.invoice_distribution_id,
            aid_awt.invoice_line_number,
            aid_awt.distribution_line_number,
            aid_awt.posted_flag,
            aid_awt.awt_flag,
            null related_id,
            aid_awt.awt_invoice_payment_id,
            ''7''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid_awt,
          ap_invoice_distributions_all aid_item,
          xla_events xe_item,
          ap_system_parameters_all param
     WHERE aid_awt.line_type_lookup_code = ''AWT''
     AND   aid_item.invoice_distribution_id = aid_awt.awt_related_id
     AND   ai.invoice_id = aid_awt.invoice_id
     AND   ai.invoice_id = aid_item.invoice_id
     AND   xe_item.event_id = aid_item.accounting_event_id
     AND   xe_item.application_id = 200
     AND   (nvl(ai.payment_status_flag, ''N'') <> ''Y'' OR
            EXISTS (
              SELECT /*+ no_unnest ordered use_nl(aip, aph, xe) */ 1
              FROM ap_invoice_payments_all aip,
                   ap_payment_history_all aph,
                   xla_events xe
              WHERE aip.invoice_id = ai.invoice_id
              AND   aip.check_id = aph.check_id
              AND   xe.event_id = aph.accounting_event_id
              AND   xe.application_id = 200
              AND   (aph.posted_flag = ''N'' OR
                     (aph.posted_flag = ''Y'' AND
                      EXISTS (
                        SELECT 1 FROM xla_ae_headers xh
                        WHERE xh.event_id = xe.event_id
                        AND   xh.application_id = 200
                        AND   nvl(xh.upg_batch_id, -9999) = -9999)))))
     AND   xe_item.event_type_code like ''%ADJUSTED''
     AND   ai.historical_flag = ''Y''
     AND   param.org_id = ai.org_id
     AND   aid_awt.parent_reversal_id is null
     AND   param.automatic_offsets_flag = ''N''
     AND   EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aidx
             WHERE aidx.accounting_event_id = xe_item.event_id
             AND   aidx.invoice_id = aid_item.invoice_id
             HAVING sum(aidx.amount) = 0)
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null related_id,
            aid.awt_invoice_payment_id,
            ''8''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid
     WHERE ai.invoice_id = invs.invoice_id
     AND   aid.invoice_id = ai.invoice_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   aid.awt_related_id is null
     AND   ai.cancelled_date is null
     AND   (aid.awt_flag = ''M'' OR
            (aid.awt_flag = ''A'' AND aid.historical_flag = ''Y''))
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aidx
             WHERE aidx.invoice_id = aid.invoice_id
             AND   aidx.line_type_lookup_code not in (''AWT'',''ERV'',''TERV'')
             AND   aidx.prepay_distribution_id is null
             AND   abs(aidx.amount) >= abs(aid.amount))
     AND   (nvl(ai.payment_status_flag, ''N'') <> ''Y'' OR
            EXISTS (
              SELECT /*+ no_unnest */ 1
              FROM ap_invoice_payments_all aip,
                   ap_payment_history_all aph,
                   xla_events xe
              WHERE  aip.invoice_id = ai.invoice_id
              AND   aip.check_id = aph.check_id
              AND   xe.event_id = aph.accounting_event_id
              AND   xe.application_id = 200
              AND   (aph.posted_flag = ''N'' OR
                     (aph.posted_flag = ''Y'' AND
                      EXISTS (
                        SELECT 1 FROM xla_ae_headers xh
                        WHERE xh.event_id = xe.event_id
                        AND   xh.application_id = 200
                        AND   nvl(xh.upg_batch_id, -9999) = -9999)))))
     UNION
     SELECT aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null related_id,
            aid.awt_invoice_payment_id,
            ''9''
     FROM ap_invoice_distributions_all aid
     WHERE aid.invoice_distribution_id IN (
             SELECT invoice_distribution_id FROM man_nonrev_awt_on_rev_itm
             WHERE line_wise_sum = 0)
     UNION
     SELECT aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null related_id,
            aid.awt_invoice_payment_id,
            ''10''
     FROM ap_invoice_distributions_all aid
     WHERE aid.invoice_distribution_id IN (
             SELECT invoice_distribution_id FROM zero_amt_awt_no_nonrev_itm
             WHERE (line_wise_sum = 0 OR
                    inv_wise_sum = 0))',
      p_title                  => 'Missing OR Incorrect AWT_RELATED_ID',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Automatic withholding tax (AWT) distributions with missing AWT_RELATED_ID',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1061563.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_AWT_RELATED_ID_SEL');



debug('begin add_signature: ap_msng_inv_hdr_ccid_sel');
  add_signature(
      p_sig_id                 => 'ap_msng_inv_hdr_ccid_sel',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.vendor_id,
            ai.vendor_site_id,
            ai.accts_pay_code_combination_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai
     WHERE nvl(ai.accts_pay_code_combination_id,-1) = -1
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Invoices Accounting Fails Due to Missing Liability Account',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoices which cannot be accounted due to missing liability account on the invoice header',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1072747.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_msng_inv_hdr_ccid_sel');



debug('begin add_signature: ap_event_x_seq_sel');
  add_signature(
      p_sig_id                 => 'ap_event_x_seq_sel',
      p_sig_sql                => 'SELECT
            aph.check_id,
            aph.org_id,
            aph.transaction_type,
            aph.accounting_event_id,
            aph.related_event_id,
            xe.entity_id
     FROM ap_payment_history_all aph,
          xla_events xe
     WHERE aph.check_id = NVL(##$$CHKID$$##,-99)
     AND   aph.accounting_event_id < aph.related_event_id
     AND   aph.posted_flag <> ''Y''
     AND   aph.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   ((aph.transaction_type in (''PAYMENT CANCELLED'', ''REFUND CANCELLED'') AND
             NOT EXISTS (
               SELECT 1 FROM xla_events xe2
               WHERE xe2.entity_id = xe.entity_id
               AND   xe2.process_status_code = ''P''
               AND   xe2.application_id = 200)) OR
            (aph.transaction_type IN (''PAYMENT UNCLEARING'') AND
             NOT EXISTS (
               SELECT 1 FROM xla_events xe2
               WHERE xe2.event_id = aph.related_event_id
               AND   xe2.process_status_code = ''P''
               AND   xe2.application_id = 200)))',
      p_title                  => 'Unable to account Payment/Refund Cancelled or Payment Unclearing events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unable to account Payment/Refund Cancelled or Payment Unclearing events when the Payment/Refund Cancelled event_id is less than the Payment Created event_id or the Payment Unclearing event_id is less than the Payment Clearing event_id causing the events to be processed in the wrong order.',
      p_solution               => '<ul>
   <li>Apply the root cause fix from bug 9784405 if you have not done so, and log a Service Request to obtain the data fix.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_event_x_seq_sel');



debug('begin add_signature: Check_Migration_Status');
  add_signature(
      p_sig_id                 => 'Check_Migration_Status',
      p_sig_sql                => 'SELECT glps.period_name,
            glps.start_date,
            glps.end_date,
            asp.set_of_books_id,
            glps.application_id,
            glps.adjustment_period_flag
     FROM ap_checks_all ac,
          ap_system_parameters_all asp,
          gl_period_statuses glps
     WHERE ac.org_id = asp.org_id
     AND   EXISTS (
             SELECT 1
             FROM ap_payment_history_all aph,
                  xla_ae_headers xah
             WHERE aph.check_id = ac.check_id
             AND   aph.historical_flag = ''Y''
             AND   aph.accounting_event_id = xah.event_id
             AND   xah.accounting_entry_status_code = ''F''
             AND   xah.application_id = 200
             AND   xah.upg_batch_id is not null
             AND   xah.upg_batch_id <> -9999)
     AND   ac.check_date BETWEEN glps.start_date AND glps.end_date
     AND   glps.set_of_books_id = asp.set_of_books_id
     AND   nvl(glps.adjustment_period_flag, ''N'') = ''N''
     AND   glps.application_id = 200
     AND   glps.migration_status_code is null
     AND   ac.check_id = NVL(##$$CHKID$$##,-99)',
      p_title                  => 'SLA Upgrade',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Periods containing selected transactions for which the XLA hot patch has not been run, potentially resulting in the accounting error ''Error 0 - This line cannot be Accounted till the line it references has been Accounted''',
      p_solution               => '<ul>
   <li>If your selected transactions or related transactions are encountering the error described, please run the XLA hot patch for the appropriate periods.  
   See [604893.1] for full details of the SLA Upgrade process, including the SLA Hotpatch</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Check_Migration_Status');



debug('begin add_signature: ap_func_curr_inv_with_base_amt_sel');
  add_signature(
      p_sig_id                 => 'ap_func_curr_inv_with_base_amt_sel',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code invoice_type,
            ai.source,
            asp.base_currency_code base_currency,
            ai.invoice_currency_code invoice_currency,
            ai.exchange_rate,
            ai.exchange_rate_type,
            ai.exchange_date,
            ai.invoice_amount,
            ai.base_amount invoice_base_amt,
            aid.invoice_line_number,
            aid.line_type_lookup_code,
            aid.distribution_line_number,
            aid.invoice_distribution_id,
            aid.posted_flag,
            aid.accounting_event_id event_id,
            aid.bc_event_id bc_event_id,
            aid.amount distribution_amt,
            aid.base_amount dist_base_amt,
            decode(aid.posted_flag,
              ''Y'',''Accounted'',
              ''Not Accounted'') accounting_status,
            decode(ai.attribute15,
              ''DUMMY_9884253'', ai.attribute15,
              '' '') error_message,
            decode((SELECT tax.invoice_distribution_id
                    FROM ap_invoice_distributions_all tax
                    WHERE tax.line_type_lookup_code in (''NONREC_TAX'',''REC_TAX'',
                            ''TRV'',''TIPV'',''TERV'')
                    AND   ai.invoice_id = tax.invoice_id(+)
                    AND   rownum < 2),
              null, ''N'',
              ''Y'') tax_dists_exists,
            decode((SELECT tax.invoice_distribution_id
                    FROM ap_self_assessed_tax_dist_all tax
                    WHERE ai.invoice_id = tax.invoice_id(+)
                    AND   rownum < 2),
              null, ''N'',
              ''Y'') self_assess_tax_exists,
            decode((SELECT ipv.invoice_distribution_id
                    FROM ap_invoice_distributions_all ipv
                    WHERE ipv.line_type_lookup_code in (''IPV'')
                    AND   ipv.corrected_invoice_dist_id IS NULL
                    AND   ai.invoice_id = ipv.invoice_id(+)
                    AND   rownum < 2),
              null, ''N'',
              ''Y'') ipv_dists_exists
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          ap_system_parameters_all asp
     WHERE ai.invoice_id = aid.invoice_id
     AND   ai.invoice_type_lookup_code <> ''EXPENSE REPORT''
     AND   ai.source <> ''ERS''
     AND   asp.org_id = ai.org_id
     AND   ai.invoice_currency_code = asp.base_currency_code
     AND   (aid.line_type_lookup_code NOT IN (''NONREC_TAX'',''REC_TAX'',
             ''TRV'',''TIPV'',''TERV'', ''IPV'', ''ERV'', ''AWT'') OR
            (aid.line_type_lookup_code = ''IPV'' AND
             aid.corrected_invoice_dist_id IS NOT NULL))
     AND   ((aid.base_amount  is not null AND
             aid.amount <> aid.base_amount) OR (
            EXISTS (
              SELECT 1 FROM ap_invoice_distributions_all aid1
              WHERE aid.invoice_id = aid1.invoice_id
              AND   aid1.line_type_lookup_code = ''ERV'')))
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Functional Currency Invoices Created With Base Amount',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Functional currency invoices created through import/quick invoicing which have BASE_AMOUNT populated causing incorrect accounting entries to be created.',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1272497.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_func_curr_inv_with_base_amt_sel');



debug('begin add_signature: ap_11i_chk_missg_adj_event_sel');
  add_signature(
      p_sig_id                 => 'ap_11i_chk_missg_adj_event_sel',
      p_sig_sql                => 'SELECT aph.check_id,
            aph.transaction_type,
            aph.posted_flag,
            aph.payment_history_id
     FROM  ap_payment_history_all aph,
         ap_payment_hist_dists aphd,
         ap_invoice_distributions_all aid
     WHERE aph.check_id = NVL(##$$CHKID$$##,-99)
     AND   aph.transaction_type in (''PAYMENT CLEARING'',''PAYMENT MATURITY'')
     AND   aph.posted_flag <> ''Y''
     AND   aph.payment_history_id = aphd.payment_history_id
     AND   aphd.invoice_distribution_id = aid.invoice_distribution_id
     AND   NOT EXISTS (
             SELECT 1
             FROM ap_payment_hist_dists aphd2,
                  ap_payment_history_all aph2
             WHERE aphd2.payment_history_id = aph2.payment_history_id
             AND   aph2.check_id = aph.check_id
             AND   aph2.transaction_type IN (''PAYMENT CREATED'',
                     ''PAYMENT ADJUSTED'',''REFUND ADJUSTED'')
             AND   aph2.posted_flag = ''Y''
             AND   aphd2.invoice_distribution_id = aphd.invoice_distribution_id)
     AND   EXISTS (
             SELECT 1 FROM ap_payment_history_all aph3
             WHERE aph3.check_id = aph.check_id
             AND   aph3.transaction_type IN (''PAYMENT CREATED'',''REFUND RECORDED'')
             AND   nvl(aph3.historical_flag,''N'') = ''Y''
             AND   aph3.posted_flag = ''Y'')
     AND   NOT EXISTS (
             SELECT 1 FROM ap_payment_history_all aph4
             WHERE aph4.check_id = aph.check_id
             AND   aph4.transaction_type IN (''PAYMENT CANCELLED'',''REFUND CANCELLED''))',
      p_title                  => 'Upgraded checks adjusted in R12 did not have a Payment Adjusted event',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Upgraded checks adjusted in R12 did not have a Payment Adjusted event created causing Payment Clearing events not to be accounted with the message "This line cannot be accounted until the accounting event that it references has been fully accounted."',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_11i_chk_missg_adj_event_sel');



debug('begin add_signature: ap_wrong_bal_segment_sel');
  add_signature(
      p_sig_id                 => 'ap_wrong_bal_segment_sel',
      p_sig_sql                => 'SELECT a.invoice_id,
            a.invoice_num,
            a.org_id,
            a.invoice_line_number,
            a.invoice_distribution_id,
            a.line_type_lookup_code,
            a.posted_flag,
            a.accounting_date,
            a.period_name,
            a.chart_of_accounts_id,
            a.set_of_books_id,
            a.dist_match_type,
            a.po_distribution_id,
            a.rcv_transaction_id,
            a.detail_tax_dist_id,
            a.detail_posting_allowed_flag,
            a.enabled_flag,
            a.account_type,
            a.summary_flag,
            a.old_code_combid,
            a.new_code_combid,
            a.old_balancing_seg_value,
            a.new_balancing_seg_value,
            a.old_concat_account,
            a.new_concat_account,
            a.error_message,
            a.bal_seg_valid
     FROM (
            SELECT /*+ leading(invs) */
                   ai.org_id,
                   ai.invoice_num,
                   ai.invoice_id,
                   aid.invoice_line_number,
                   aid.invoice_distribution_id,
                   aid.line_type_lookup_code,
                   aid.posted_flag,
                   aid.accounting_date,
                   aid.period_name,
                   gsb.chart_of_accounts_id,
                   aid.set_of_books_id,
                   aid.dist_match_type,
                   aid.po_distribution_id,
                   aid.rcv_transaction_id,
                   aid.detail_tax_dist_id,
                   gcc.detail_posting_allowed_flag,
                   gcc.enabled_flag,
                   gcc.account_type,
                   gcc.summary_flag,
                   nvl((SELECT ''1'' /*+cardinality(glsv 1)*/
                        FROM gl_ledger_segment_values glsv
                        WHERE glsv.segment_value =
                                ap_invoice_distributions_pkg.get_balancing_segment_value(
                                  aid.dist_code_combination_id,
                                  aid.set_of_books_id)
                        AND glsv.segment_type_code = ''B''
                        AND glsv.ledger_id = aid.set_of_books_id
                        AND aid.accounting_date BETWEEN
                              nvl(glsv.start_date, aid.accounting_date) AND
                              nvl(glsv.end_date, aid.accounting_date)
                        AND rownum = 1), 0) "BAL_SEG_VALID",
                   ap_invoice_distributions_pkg.get_balancing_segment_value(
                     aid.dist_code_combination_id,
                     aid.set_of_books_id) "OLD_BALANCING_SEG_VALUE",
                   decode(gcc.segment1,
                     ''DUMMY'',gcc.segment1,
                     '''') "NEW_BALANCING_SEG_VALUE",
                   aid.dist_code_combination_id "OLD_CODE_COMBID",
                   decode(gcc.code_combination_id,
                     000000,gcc.code_combination_id,
                     null) "NEW_CODE_COMBID",
                   fnd_flex_ext.get_segs(''SQLGL'', ''GL#'', gsb.chart_of_accounts_id,
                     aid.dist_code_combination_id) "OLD_CONCAT_ACCOUNT",
                     decode(aid.global_attribute_category,
                       ''DUMMY'',aid.global_attribute_category,
                       '''') "NEW_CONCAT_ACCOUNT",
                   decode(aid.global_attribute1,
                     ''DUMMY'',aid.global_attribute1,
                     '''') "ERROR_MESSAGE"
            FROM (
                   ##$$IVIEW$$##
                 ) invs,
                 ap_invoices_all              ai,
                 ap_invoice_distributions_all aid,
                 ap_system_parameters_all     asp,
                 gl_code_combinations         gcc,
                 gl_ledgers                   gl,
                 gl_sets_of_books             gsb
            WHERE ai.invoice_id = invs.invoice_id
            AND   aid.invoice_id = ai.invoice_id
            AND   aid.dist_code_combination_id = gcc.code_combination_id
            AND   aid.set_of_books_id = gl.ledger_id
            AND   aid.historical_flag is null
            AND   aid.posted_flag <> ''Y''
            AND   nvl(gl.bal_seg_value_option_code, ''A'') <> ''A''
            AND   ai.org_id = asp.org_id
            AND   asp.set_of_books_id = gsb.set_of_books_id
            UNION ALL
            SELECT /*+ leading(invs) */
                   ai.org_id,
                   ai.invoice_num,
                   ai.invoice_id,
                   aid.invoice_line_number,
                   aid.invoice_distribution_id,
                   aid.line_type_lookup_code,
                   aid.posted_flag,
                   aid.accounting_date,
                   aid.period_name,
                   gsb.chart_of_accounts_id,
                   aid.set_of_books_id,
                   aid.dist_match_type,
                   aid.po_distribution_id,
                   aid.rcv_transaction_id,
                   aid.detail_tax_dist_id,
                   gcc.detail_posting_allowed_flag,
                   gcc.enabled_flag,
                   gcc.account_type,
                   gcc.summary_flag,
                   nvl((
                     SELECT ''1'' /*+cardinality(glsv 1)*/
                     FROM gl_ledger_segment_values glsv
                     WHERE glsv.segment_value =
                             ap_invoice_distributions_pkg.get_balancing_segment_value(
                               aid.dist_code_combination_id,
                               aid.set_of_books_id)
                     AND   glsv.segment_type_code = ''B''
                     AND   glsv.ledger_id = aid.set_of_books_id
                     AND   aid.accounting_date BETWEEN
                             nvl(glsv.start_date, aid.accounting_date) AND
                             nvl(glsv.end_date, aid.accounting_date)
                     AND   rownum = 1), 0) "BAL_SEG_VALID",
                   ap_invoice_distributions_pkg.get_balancing_segment_value(
                     aid.dist_code_combination_id,
                     aid.set_of_books_id) "OLD_BALANCING_SEG_VALUE",
                   decode(gcc.segment1,
                     ''DUMMY'',gcc.segment1,'''') "NEW_BALANCING_SEG_VALUE",
                   aid.dist_code_combination_id "OLD_CODE_COMBID",
                   decode(gcc.code_combination_id,
                     000000,gcc.code_combination_id,null) "NEW_CODE_COMBID",
                   fnd_flex_ext.get_segs(''SQLGL'',
                     ''GL#'',
                     gsb.chart_of_accounts_id,
                     aid.dist_code_combination_id) "OLD_CONCAT_ACCOUNT",
                     decode(aid.global_attribute_category,
                       ''DUMMY'',aid.global_attribute_category,'''') "NEW_CONCAT_ACCOUNT",
                   decode(aid.global_attribute1,
                       ''DUMMY'',aid.global_attribute1,'''') "ERROR_MESSAGE"
            FROM (
                   ##$$IVIEW$$##
                 ) invs,
                 ap_invoices_all ai,
                 ap_self_assessed_tax_dist_all aid,
                 gl_ledgers gl,
                 gl_code_combinations gcc,
                 ap_system_parameters_all asp,
                 gl_sets_of_books gsb
            WHERE ai.invoice_id = invs.invoice_id
            AND   ai.historical_flag is null
            AND   aid.invoice_id = ai.invoice_id
            AND   aid.posted_flag <> ''Y''
            AND   aid.dist_code_combination_id = gcc.code_combination_id
            AND   aid.set_of_books_id = gl.ledger_id
            AND   nvl(gl.bal_seg_value_option_code, ''A'') <> ''A''
            AND   ai.org_id = asp.org_id
            AND   asp.set_of_books_id = gsb.set_of_books_id
          ) a
     WHERE a.bal_seg_valid = 0',
      p_title                  => 'Incorrect Balancing Segment Values In The Distribution Account',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoices which are not part of the legal entity or ledger context of the balancing segment values of its account code combinations result in error# 95311 during accounting',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1272440.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_wrong_bal_segment_sel');



debug('begin add_signature: ap_clr_adj_bank_amt_null');
  add_signature(
      p_sig_id                 => 'ap_clr_adj_bank_amt_null',
      p_sig_sql                => 'SELECT aph1.check_id clr_check_id,
            aph1.transaction_type,
            aip1.invoice_id,
            aph2.check_id clr_adj_check_id,
            aph2.bank_currency_code,
            aph2.accounting_event_id adj_event_id
     FROM ap_payment_history_all aph1,
          ap_payment_history_all aph2,
          ap_invoice_payments_all aip1,
          ap_invoice_payments_all aip2
     WHERE aph1.check_id = NVL(##$$CHKID$$##,-99)
     AND   aph1.posted_flag = ''N''
     AND   aph1.transaction_type like ''PAYMENT%CLEARING%''
     AND   aph1.check_id = aip1.check_id
     AND   aip1.invoice_id = aip2.invoice_id
     AND   aip2.check_id = aph2.check_id
     AND   aph2.transaction_type = ''PAYMENT CLEARING ADJUSTED''
     AND   aph2.bank_currency_code is not null
     AND   aph2.posted_flag = ''Y''
     AND   nvl (aph2.historical_flag, ''N'') = ''N''
     AND   EXISTS (
             SELECT 1 FROM ap_payment_hist_dists aphd
             WHERE aphd.accounting_event_id = aph2.accounting_event_id
             AND   aphd.pay_dist_lookup_code= ''DISCOUNT''
             AND   aphd.bank_curr_amount is null)',
      p_title                  => 'Payment clearing events are not accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment clearing events are not accounting because the related invoice has a prior payment clearing adjusted event which is incorrectly accounted. The failure message is "The subledger journal entry does not balance in the entered currency."',
      p_solution               => '<ul>
   <li>Apply the root cause fix from bug 10623466 if you have not done so, and log a Service Request to obtain the data fix.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_clr_adj_bank_amt_null');



debug('begin add_signature: ap_wrong_base_amt_sel');
  add_signature(
      p_sig_id                 => 'ap_wrong_base_amt_sel',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT /*+ ordered use_nl(ai) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.cancelled_date,
            ''header base amount issue'' reason
     FROM invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp
     WHERE ai.exchange_rate is not null
     AND   ai.org_id = asp.org_id
     AND   ap_utilities_pkg.ap_round_currency(
              invoice_amount * exchange_rate, base_currency_code)
              <> base_amount
     AND   ai.invoice_currency_code <> asp.base_currency_code
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered us_nl(ai) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.cancelled_date,
            ''lines base amount issue''
     FROM  invs,
           ap_invoices_all ai,
           ap_system_parameters_all asp
     WHERE ai.exchange_rate is not null
     AND   ai.org_id = asp.org_id
     AND   ai.invoice_currency_code <> asp.base_currency_code
     AND   ap_invoices_utility_pkg.get_approval_status(
             ai.invoice_id,ai.invoice_amount, ai.payment_status_flag,
             ai.invoice_type_lookup_code) <> ''NEVER APPROVE''
     AND   ai.invoice_type_lookup_code <> ''PO PRICE ADJUST''
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ ''Adjustment corrections exists''
             FROM ap_invoice_distributions_all aid
             WHERE aid.invoice_id = ai.invoice_id
             AND   aid.dist_match_type=''ADJUSTMENT_CORRECTION'')
     AND   ai.invoice_amount = (
             SELECT sum(ail.amount) +
                      decode(nvl(ai.net_of_retainage_flag,''N''),
                        ''Y'',sum(nvl(retained_amount,0)),0)
             FROM ap_invoice_lines_all ail
             WHERE ail.invoice_id = ai.invoice_id
             AND   ail.line_type_lookup_code <> ''AWT''
             AND   ((ail.prepay_invoice_id is not null AND
                     nvl(ail.invoice_includes_prepay_flag, ''N'') = ''Y'') OR
                    ail.prepay_invoice_id is null))
     AND   nvl(ai.base_amount,0) <> (
             SELECT sum(nvl(base_amount,0))  +
                      decode(nvl(ai.net_of_retainage_flag,''N''),
                        ''Y'',ap_utilities_pkg.ap_round_currency(
                        sum(nvl(retained_amount,0))*ai.exchange_rate,
                        asp.base_currency_code), 0)
             FROM ap_invoice_lines_all ail
             WHERE ail.invoice_id = ai.invoice_id
             AND   ail.line_type_lookup_code <> ''AWT''
             AND   ((ail.prepay_invoice_id is not null AND
                     nvl(ail.invoice_includes_prepay_flag, ''N'') = ''Y'') OR
                    ail.prepay_invoice_id is null))
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, ail) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.cancelled_date,
            ''dists base amount issue''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_lines_all ail,
          ap_system_parameters_all asp
     WHERE ai.exchange_rate is not null
     AND   ai.invoice_id = ail.invoice_id
     AND   ai.org_id = asp.org_id
     AND   ai.invoice_currency_code <> asp.base_currency_code
     AND   ail.base_amount is not null
     AND   ai.invoice_type_lookup_code <> ''PO PRICE ADJUST''
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ ''unvalidated dists exists''
             FROM ap_invoice_distributions_all aid1
             WHERE aid1.invoice_id = ai.invoice_id
             AND   (aid1.dist_match_type=''ADJUSTMENT_CORRECTION'' OR
                    nvl(aid1.match_status_flag,''N'') = ''N''))
     AND   ail.amount = (
             SELECT /*+ no_unnest */ sum(aid2.amount)
             FROM ap_invoice_distributions_all aid2
             WHERE aid2.invoice_id = ail.invoice_id
             AND   aid2.invoice_line_number = ail.line_number)
     AND   (ail.line_type_lookup_code in (''ITEM'',''FREIGHT'',''MISCELLANEOUS'') OR
            ai.cancelled_date is not null)
     AND   ail.base_amount <> (
             SELECT /*+ no_unnest */ sum(nvl(aid.base_amount,0))
             FROM ap_invoice_distributions_all aid
             WHERE aid.invoice_id = ail.invoice_id
             AND   aid.invoice_line_number = ail.line_number)
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.cancelled_date,
            ''opposite signs''
     FROM invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp
     WHERE ai.exchange_rate is not null
     AND   ai.org_id = asp.org_id
     AND   ai.invoice_currency_code <> asp.base_currency_code
     AND   ai.invoice_type_lookup_code <> ''PO PRICE ADJUST''
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ ''Adjustment corrections exists''
             FROM ap_invoice_distributions_all aid1
             WHERE aid1.invoice_id = ai.invoice_id
             AND   aid1.dist_match_type=''ADJUSTMENT_CORRECTION'')
     AND   EXISTS(
             SELECT /*+ no_unnest */ ''opposite signs''
             FROM ap_invoice_distributions_all aid
             WHERE aid.invoice_id = ai.invoice_id
             AND aid.base_amount is not null
             AND ((aid.amount > 0 AND aid.base_amount <0) OR
                  (aid.amount < 0 AND aid.base_amount >0)))
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.cancelled_date,
            ''wrong variance''
     FROM invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp
     WHERE nvl(ai.historical_flag,''N'') <> ''Y''
     AND   ai.exchange_rate is not null
     AND   ai.cancelled_date is null
     AND   ai.org_id = asp.org_id
     AND   ai.invoice_currency_code <> asp.base_currency_code
     AND   ai.invoice_type_lookup_code <> ''PO PRICE ADJUST''
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ ''Adjustment corrections exists''
             FROM ap_invoice_distributions_all aid1
             WHERE aid1.invoice_id = ai.invoice_id
             AND   aid1.dist_match_type=''ADJUSTMENT_CORRECTION'')
     AND   EXISTS (
             SELECT /*+ no_unnest */ ''wrong variance''
             FROM ap_invoice_distributions_all aid
             WHERE aid.invoice_id = ai.invoice_id
             AND   (aid.po_distribution_id is not null OR
                    aid.rcv_transaction_id is not null)
             AND   nvl(aid.dist_match_type,''NOT_MATCHED'') IN
                     (''ITEM_TO_PO'',''ITEM_TO_RECEIPT'',
                      ''ITEM_TO_SERVICE_PO'',''ITEM_TO_SERVICE_RECEIPT'',
                      ''QTY_CORRECTION'',''AMOUNT_CORRECTION'')
             AND   nvl(aid.reversal_flag,''N'') <> ''Y''
             AND   aid.line_type_lookup_code in (''ITEM'',''ACCRUAL'')
             AND   abs(aid.base_amount -
                     (SELECT /*+ no_unnest */ ap_utilities_pkg.ap_round_currency(
                               aid1.amount * nvl(rt.currency_conversion_rate,pod.rate),
                               asp.base_currency_code)
                      FROM ap_invoice_distributions_all aid1,
                           po_distributions_all pod,
                           rcv_transactions rt,
                           ap_system_parameters_all asp
                      WHERE aid1.invoice_distribution_id = aid.invoice_distribution_id
                      AND aid1.po_distribution_id = pod.po_distribution_id
                      AND aid1.rcv_transaction_id = rt.transaction_id (+)
                      AND aid1.org_id = asp.org_id))
                     > .99 )
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Invoice Distributions Where Amount And Base Amount Have Different Sign',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Identifies a series of invoice related issues with amounts and base amounts. See [1276043.1] for the complete list of issues addressed in this query',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1276043.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_wrong_base_amt_sel');



debug('begin add_signature: ap_ret_dist_id_on_rev_dist_sel');
  add_signature(
      p_sig_id                 => 'ap_ret_dist_id_on_rev_dist_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai, aid, aid2) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.invoice_distribution_id,
            aid.parent_reversal_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          ap_invoice_distributions_all aid2
     WHERE ai.invoice_type_lookup_code = ''RETAINAGE RELEASE''
     AND   nvl(ai.historical_flag,''N'') <> ''Y''
     AND   ai.invoice_id = aid.invoice_id
     AND   aid.line_type_lookup_code = ''RETAINAGE''
     AND   aid.parent_reversal_id is not null
     AND   aid.retained_invoice_dist_id is null
     AND   aid2.invoice_id = aid.invoice_id
     AND   aid.parent_reversal_id = aid2.invoice_distribution_id
     AND   aid2.retained_invoice_dist_id is not null
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Retained Invoice Distribution Id Is Null',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoices with cancelled or reversed retainage release distributions which have a null retainage_invoice_id causing errors when creating accounting.',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1404696.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_ret_dist_id_on_rev_dist_sel');



debug('begin add_signature: ap_paycreate_np_to_ui_sel');
  add_signature(
      p_sig_id                 => 'ap_paycreate_np_to_ui_sel',
      p_sig_sql                => 'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            aph.accounting_event_id
     FROM ap_checks_all ac,
          ap_system_parameters_all asp,
          ap_payment_history_all aph,
          xla_events xe
     WHERE ac.check_id = NVL(##$$CHKID$$##,-99)
     AND   ac.void_date is null
     AND   asp.org_id = ac.org_id
     AND   aph.check_id = ac.check_id
     AND   nvl(asp.when_to_account_pmt, ''X'') != ''CLEARING ONLY''
     AND   aph.transaction_type = ''PAYMENT CREATED''
     AND   aph.posted_flag = ''Y''
     AND   xe.event_id = aph.accounting_event_id
     AND   xe.event_status_code = ''N''
     AND   EXISTS (
             SELECT 1
             FROM ap_payment_history_all aph1,
                  xla_events xe1
             WHERE aph1.check_id = ac.check_id
             AND   xe1.event_id = aph1.accounting_event_id
             AND   aph1.transaction_type = ''PAYMENT CLEARING''
             AND   aph1.posted_flag = ''N''
             AND   xe1.event_id = aph1.accounting_event_id
             AND   xe1.event_status_code = ''U'')
     UNION  -- Setup was changed after accounting of pay created.
     SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            aph.accounting_event_id
     FROM ap_checks_all ac,
          ap_system_parameters_all asp,
          ap_payment_history_all aph,
          xla_events xe
     WHERE ac.check_id = NVL(##$$CHKID$$##,-99)
     AND   ac.void_date is not null
     AND   asp.org_id = ac.org_id
     AND   aph.check_id = ac.check_id
     AND   nvl(asp.when_to_account_pmt, ''X'') = ''CLEARING ONLY''
     AND   aph.transaction_type IN (''PAYMENT CANCELLED'' ,
             ''REFUND CANCELLED'')
     AND   aph.posted_flag = ''Y''
     AND   xe.event_id = aph.accounting_event_id
     AND   xe.event_status_code = ''N''
     AND   EXISTS (
             SELECT 1
             FROM ap_payment_history_all aph1,
                  xla_events xe1
             WHERE aph1.check_id = ac.check_id
             AND   xe1.event_id = aph1.accounting_event_id
             AND   aph1.transaction_type IN (''PAYMENT CREATED'',
                     ''REFUND RECORDED'')
             AND   aph1.posted_flag = ''Y''
             AND   aph.related_event_id = aph1.accounting_event_id
             AND   xe1.event_status_code = ''P''
             AND   xe1.application_id = 200)',
      p_title                  => 'Payment Created Events With Incorrect Status Code',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment created events with event_status_code/process_status_code of N/P (No Action/Processed) cause successive events to fail accounting. This can occur if payment accounting setup has been changed from "Clearing Only" to "Always"',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_paycreate_np_to_ui_sel');



debug('begin add_signature: ap_asatd_no_liab_sel');
  add_signature(
      p_sig_id                 => 'ap_asatd_no_liab_sel',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            sd.invoice_distribution_id,
            zxd.gl_date,
            zxd.tax_rate_id,
            zxd.recovery_rate_id,
            zxd.self_assessed_flag,
            zxd.recoverable_flag,
            zxd.tax_jurisdiction_id,
            zxd.tax_regime_id,
            zxd.tax_id,
            sd.org_id,
            zxd.tax_status_id,
            sd.dist_code_combination_id,
            zxd.account_source_tax_rate_id,
            sd.detail_tax_dist_id,
            sd.self_assessed_tax_liab_ccid
     FROM ap_invoices_all ai,
          ap_self_assessed_tax_dist_all sd,
          zx_rec_nrec_dist zxd,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE ai.invoice_id = sd.invoice_id
     AND   zxd.rec_nrec_tax_dist_id = sd.detail_tax_dist_id
     AND   sd.posted_flag IN (''N'', ''S'')
     AND   sd.self_assessed_tax_liab_ccid is null
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Self Assessed Tax Distributions With Missing Liability Account',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Self assessed tax distributions with missing liability account cause accounting to fail with error 95353',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [975162.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_asatd_no_liab_sel');



debug('begin add_signature: ap_ref_adj_x_evt_type_sel');
  add_signature(
      p_sig_id                 => 'ap_ref_adj_x_evt_type_sel',
      p_sig_sql                => 'SELECT ac.check_id,
            aph.payment_history_id,
            aph.accounting_event_id
     FROM ap_checks_all ac,
          ap_payment_history_all aph
     WHERE ac.check_id = NVL(##$$CHKID$$##,-99)
     AND   aph.check_id = ac.check_id
     AND   ac.payment_type_flag = ''R''
     AND   aph.transaction_type = ''MANUAL PAYMENT ADJUSTED''
     AND   aph.posted_flag = ''N''',
      p_title                  => 'Adjustments Made To Manual Refunds Cannot Be Accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Adjustments made to manual refunds cannot be accounted because they have an incorrect event type.',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_ref_adj_x_evt_type_sel');



debug('begin add_signature: ap_x_pay_clr_adj_sel');
  add_signature(
      p_sig_id                 => 'ap_x_pay_clr_adj_sel',
      p_sig_sql                => 'SELECT h1.check_id,
            h1.org_id,
            h1.accounting_event_id,
            h1.payment_history_id
     FROM  ap_payment_history_all h1, 
           xla_events xe
     WHERE h1.check_id = NVL(##$$CHKID$$##,-99)
     AND   h1.transaction_type like ''%CLEARING%ADJUSTED''
     AND   nvl(h1.posted_flag,''N'') != ''Y''
     AND   xe.event_id = h1.accounting_event_id
     AND   xe.event_status_code != ''P''
     AND   xe.application_id =200
     AND   EXISTS (
             SELECT 1 from ap_payment_history_all h2
             WHERE h1.check_id = h2.check_id
             AND   h2.transaction_type like ''%CANCELLED''
             AND   h2.posted_flag = ''Y'')
     AND   NOT EXISTS (
             SELECT 1 from ap_payment_history_all h3
             WHERE h3.check_id = h1.check_id
             AND   h3.transaction_type = ''PAYMENT ADJUSTED''
             AND   h3.invoice_adjustment_event_id = h1.invoice_adjustment_event_id)',
      p_title                  => 'Payment Clearing Adjusted Events Cannot Be Accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Payment clearing adjusted events will not account because the corresponding payment adjusted event is missing.',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_x_pay_clr_adj_sel');



debug('begin add_signature: ap_bc_on_rectax_dist_sel');
  add_signature(
      p_sig_id                 => 'ap_bc_on_rectax_dist_sel',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            asu.vendor_name,
            assi.vendor_site_code,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.line_type_lookup_code,
            aid.accounting_date,
            aid.amount,
            aid.base_amount,
            aid.posted_flag,
            aid.bc_event_id,
            aid.encumbered_flag,
            xe.event_status_code,
            xe.process_status_code,
            xe.budgetary_control_flag,
            xe.upg_batch_id
     FROM ap_invoice_distributions_all aid,
          ap_invoices_all ai,
          gl_ledgers gl,
          ap_suppliers asu,
          ap_supplier_sites_all assi,
          xla_events xe,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE ai.invoice_id = aid.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   aid.line_type_lookup_code = ''REC_TAX''
     AND   aid.prepay_distribution_id is null
     AND   xe.application_id = 200
     AND   xe.event_id = aid.bc_event_id
     AND   aid.bc_event_id is not null
     AND   ai.set_of_books_id = gl.ledger_id
     AND   (nvl(aid.posted_flag, ''N'') <> ''Y'' OR
            EXISTS (
              SELECT 1 FROM ap_invoice_payments_all aip
              WHERE aip.invoice_id = aid.invoice_id
              AND   nvl(aip.posted_flag, ''N'') <> ''Y''
              AND   gl.sla_ledger_cash_basis_flag = ''Y''
              UNION
              SELECT 1
              FROM ap_invoice_payments_all aip,
                   ap_payment_history_all aph,
                   ap_system_parameters_all asp
              WHERE aip.invoice_id = aid.invoice_id
              AND   aip.check_id = aph.check_id
              AND   aph.org_id = asp.org_id
              AND   nvl(aph.posted_flag, ''N'') <> ''Y''
              AND   gl.sla_ledger_cash_basis_flag = ''Y''
              AND   aph.org_id = asp.org_id
              AND   aph.transaction_type like ''PAYMENT%CLEAR%''
              AND   asp.when_to_account_pmt like ''CLEARING ONLY''))
     AND   NOT EXISTS (
             SELECT 1
             FROM xla_distribution_links xdl,
                  xla_ae_headers xah
             WHERE xdl.application_id = 200
             AND   xah.application_id = 200
             AND   xdl.ae_header_id = xah.ae_header_id
             AND   xah.event_id = aid.bc_event_id
             AND   xah.balance_type_code = ''E''
             AND   xdl.source_distribution_type = ''AP_INV_DIST''
             AND   xdl.source_distribution_id_num_1 = aid.invoice_distribution_id)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Budgetary Control Events Stamped On Recoverable Tax Distributions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Budgetary control events stamped on recoverable tax distributions',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [982795.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_bc_on_rectax_dist_sel');



debug('begin add_signature: ap_prepay_upg_unapply_sel');
  add_signature(
      p_sig_id                 => 'ap_prepay_upg_unapply_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai_std aida aidu aidp) */
            ai_std.invoice_id               std_invoice_id,
            ai_std.invoice_num              std_invoice_num,
            ai_std.org_id                   org_id,
            ai_std.invoice_date             std_invoice_date,
            ai_std.invoice_type_lookup_code std_invoice_type,
            ai_prepay.invoice_id            prepay_invoice_id,
            ai_prepay.invoice_num           prepay_invoice_num,
            ai_prepay.invoice_date          prepay_invoice_date,
            aida.invoice_line_number        prepay_app_line_num,
            aida.invoice_distribution_id    prepay_app_dist_id,
            aida.distribution_line_number   prepay_app_dist_num,
            aida.line_type_lookup_code      prepay_app_line_type,
            aida.match_status_flag          prepay_app_match_status,
            aida.accounting_date            prepay_app_acct_date,
            xea.event_type_code             prepay_app_event_type,
            aida.accounting_event_id        prepay_app_event_id,
            aida.posted_flag                prepay_app_posted_flag,
            aida.amount                     prepay_app_amount,
            aida.base_amount                prepay_app_base_amount,
            aida.historical_flag            prepay_app_hist_flag,
            aidu.invoice_distribution_id    prepay_unapp_dist_id,
            aidu.distribution_line_number   prepay_unapp_dist_num,
            aidu.line_type_lookup_code      prepay_unapp_line_type,
            aidu.match_status_flag          prepay_unapp_match_status,
            aidu.accounting_date            prepay_unapp_acct_date,
            xeu.event_type_code             prepay_unapp_event_type,
            aidu.posted_flag                prepay_unapp_posted_flag,
            aidu.accounting_event_id        prepay_unapp_event_id,
            aidu.amount                     prepay_unapp_amount,
            aidu.base_amount                prepay_unapp_base_amount,
            aidu.historical_flag            prepay_unapp_hist_flag,
            ai_std.set_of_books_id          sob_id,
            ai_std.gl_date,
            glps.period_name,
            glps.migration_status_code
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai_std,
          gl_period_statuses glps,
          ap_invoice_distributions_all aida,
          ap_invoice_distributions_all aidu,
          ap_invoice_distributions_all aidp,
          ap_invoices_all ai_prepay,
          xla_events xea,
          xla_events xeu
     WHERE aida.invoice_id = aidu.invoice_id
     AND   aida.invoice_id = ai_std.invoice_id
     AND   glps.application_id = 200
     AND   nvl(glps.adjustment_period_flag, ''N'') = ''N''
     AND   glps.set_of_books_id = ai_std.set_of_books_id
     AND   ai_std.gl_date BETWEEN glps.start_date AND glps.end_date
     AND   aida.invoice_distribution_id = aidu.parent_reversal_id
     AND   aida.prepay_distribution_id = aidu.prepay_distribution_id
     AND   aidp.invoice_distribution_id = aida.prepay_distribution_id
     AND   aidp.invoice_id = ai_prepay.invoice_id
     AND   nvl(aida.reversal_flag, ''N'') = ''Y''
     AND   nvl(aidu.reversal_flag, ''N'') = ''Y''
     AND   aida.prepay_distribution_id is not null
     AND   aidu.prepay_distribution_id is not null
     AND   aida.amount < 0
     AND   aidu.amount > 0
     AND   aida.posted_flag = ''Y''
     AND   aidu.posted_flag <> ''Y''
     AND   aida.accounting_event_id is not null
     AND   aida.accounting_event_id = xea.event_id
     AND   xea.application_id = 200
     AND   xea.event_type_code = ''PREPAYMENT APPLIED''
     AND   xea.upg_batch_id is not null
     AND   xea.upg_batch_id <> -9999
     AND   xea.event_status_code = ''P''
     AND   aidu.accounting_event_id is not null
     AND   aidu.accounting_event_id = xeu.event_id
     AND   xeu.application_id = 200
     AND   xeu.event_type_code = ''PREPAYMENT UNAPPLIED''
     AND   xeu.event_status_code <> ''P''
     AND   ai_std.invoice_id = invs.invoice_id',
      p_title                  => 'Incorrect Source Distribution Type For Prepayment Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Incorrect source_distribution_type, side of the debit and credit entries, and amounts in XLA_Distribution_links for upgraded prepayment application events.',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1275451.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prepay_upg_unapply_sel');



debug('begin add_signature: ap_unacc_prep_unapp_sel');
  add_signature(
      p_sig_id                 => 'ap_unacc_prep_unapp_sel',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            aph_pu.accounting_event_id unapplied_event,
            aph_pu.posted_flag unappld_event_posted_flag,
            aph_adj.accounting_event_id event_id,
            aph_adj.posted_flag adj_event_posted_flag
     FROM ap_prepay_history_all aph_pu,
          ap_prepay_history_all aph_adj,
          ap_invoices_all ai,
          ap_prepay_app_dists apad_pu,
          ap_prepay_app_dists apad_adj,
          xla_events xe_pu,
          xla_events xe_adj,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE aph_pu.transaction_type = ''PREPAYMENT UNAPPLIED''
     AND   aph_pu.posted_flag = ''N''
     AND   aph_pu.invoice_id = aph_adj.invoice_id
     AND   aph_adj.transaction_type = ''PREPAYMENT APPLICATION ADJ''
     AND   aph_adj.posted_flag = ''Y''
     AND   aph_pu.related_prepay_app_event_id = aph_adj.related_prepay_app_event_id
     AND   ai.invoice_id = aph_pu.invoice_id
     AND   apad_pu.accounting_event_id = aph_pu.accounting_event_id
     AND   apad_adj.accounting_event_id = aph_adj.accounting_event_id
     AND   apad_adj.reversed_prepay_app_dist_id = apad_pu.reversed_prepay_app_dist_id
     AND   xe_pu.event_id = aph_pu.accounting_event_id
     AND   xe_pu.application_id = 200
     AND   xe_pu.event_status_code = ''U''
     AND   xe_pu.process_status_code in (''U'',''I'')
     AND   xe_adj.event_id = aph_adj.accounting_event_id
     AND   xe_adj.application_id = 200
     AND   xe_adj.event_status_code = ''P''
     AND   xe_adj.process_status_code = ''P''
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Prepayment Unapplication Not Getting Accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment unapplication not getting accounted because of a related prepayment application adjusted event which reverses the accounting for the corresponding prepayment application',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1273125.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_unacc_prep_unapp_sel');



debug('begin add_signature: ap_awt_on_prepay_sel');
  add_signature(
      p_sig_id                 => 'ap_awt_on_prepay_sel',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_currency_code
     FROM ap_invoice_distributions_all aid_awt,
          ap_invoice_distributions_all aid_prepay,
          xla_events xe,
          ap_invoices_all ai,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE aid_prepay.invoice_id = aid_awt.invoice_id
     AND   ai.invoice_id = aid_awt.invoice_id
     AND   aid_prepay.invoice_distribution_id = aid_awt.awt_related_id
     AND   aid_prepay.prepay_distribution_id is not null
     AND   xe.event_id = aid_awt.accounting_event_id
     AND   xe.event_status_code IN (''U'',''I'')
     AND   xe.application_id = 200
     AND   nvl(aid_awt.posted_flag,''N'') <> ''Y''
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Payment Accounting Failed',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'AWT distributions related to prepayment application/unapplication distributions causing the invoice or its payment to remain unaccounted',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1264239.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_awt_on_prepay_sel');



debug('begin add_signature: ap_apad_cancelled_dist_sel');
  add_signature(
      p_sig_id                 => 'ap_apad_cancelled_dist_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai, aid, aid1, xe) parallel(apad,6) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_date,
            apad.prepay_app_dist_id,
            apad.accounting_event_id,
            aid.invoice_distribution_id,
            aid.line_type_lookup_code,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.amount,
            xe.event_type_code
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          ap_prepay_app_dists apad,
          ap_invoice_distributions_all aid1,
          xla_events xe
     WHERE xe.event_id = apad.accounting_event_id
     AND   xe.application_id = 200
     AND   (xe.upg_batch_id is null OR
            xe.upg_batch_id = ''-9999'')
     AND   xe.event_type_code IN (''PREPAYMENT APPLIED'',''PREPAYMENT UNAPPLIED'')
     AND   apad.prepay_app_distribution_id = aid.invoice_distribution_id
     AND   aid.posted_flag <> ''Y''
     AND   nvl(aid.historical_flag, ''N'') <> ''Y''
     AND   aid.line_type_lookup_code IN (''PREPAY'', ''REC_TAX'', ''NONREC_TAX'')
     AND   aid.prepay_distribution_id is not null
     AND   aid.invoice_id = ai.invoice_id
     AND   apad.invoice_distribution_id = aid1.invoice_distribution_id
     AND   aid1.line_type_lookup_code NOT IN (''AWT'',''PREPAY'')
     AND   aid1.cancellation_flag = ''Y''
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Prepayment Applied/Unapplied Events Cannot be Accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment application/unapplication distributions prorated to cancelled invoice distributions causing accounting error ''This line cannot be accounted...''',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [982075.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_apad_cancelled_dist_sel');



debug('begin add_signature: ap_prep_apld_noitmdist_sel');
  add_signature(
      p_sig_id                 => 'ap_prep_apld_noitmdist_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai, aid) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.invoice_distribution_id,
            aid.parent_reversal_id,
            xe.event_type_code,
            aid.accounting_event_id,
            aid.bc_event_id,
            aid.amount,
            aid.base_amount
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          xla_events xe
     WHERE aid.invoice_id = ai.invoice_id
     AND   aid.prepay_distribution_id is not null
     AND   aid.accounting_event_id = xe.event_id (+)
     AND   nvl(aid.posted_flag, ''N'') <> ''Y''
     AND   nvl(aid.reversal_flag, ''N'') = ''Y''
     AND   nvl(xe.application_id, -99) = 200
     AND   nvl(xe.event_status_code, ''N'') <> ''P''
     AND   ai.cancelled_date is not null
     AND   ai.invoice_amount = 0
     AND   EXISTS (
             SELECT /*+ no_unnest no_expand */ 1
             FROM ap_invoice_distributions_all aid1
             WHERE aid1.invoice_id = aid.invoice_id
             AND   aid1.prepay_distribution_id is not null
             AND   nvl(aid1.reversal_flag, ''N'') = ''Y''
             AND   (aid.parent_reversal_id = aid1.invoice_distribution_id OR
                    aid.invoice_distribution_id = aid1.parent_reversal_id)
             AND   nvl(aid1.posted_flag, ''N'') <> ''Y'')
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aid2
             WHERE aid2.invoice_id = ai.invoice_id
             AND   aid2.prepay_distribution_id is null)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Unaccounted Prepay Events For Cancelled Invoices',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment application/unapplication events not getting accounted because the corresponding standard invoice is canceled and does not contain any item or charge distributions',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1194913.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prep_apld_noitmdist_sel');



debug('begin add_signature: ap_prepay_bus_code_s');
  add_signature(
      p_sig_id                 => 'ap_prepay_bus_code_s',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai xte xe xah xal) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            xe.event_id,
            xah.ae_header_id,
            xal.ae_line_num,
            xal.accounting_class_code,
            xal.entered_dr,
            xal.entered_cr,
            xal.accounted_dr,
            xal.accounted_cr
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          xla_transaction_entities_upg xte,
          xla_events xe,
          xla_ae_headers xah,
          xla_ae_lines xal
     WHERE xe.event_id = xah.event_id
     AND   xah.ae_header_id = xal.ae_header_id
     AND   xah.application_id = 200
     AND   xe.application_id = 200
     AND   xal.application_id = 200
     AND   xe.entity_id = xte.entity_id
     AND   xte.application_id = 200
     AND   xte.entity_code = ''AP_INVOICES''
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   ai.invoice_type_lookup_code = ''PREPAYMENT''
     AND   ai.historical_flag = ''Y''
     AND   xe.event_type_code like ''PREPAYMENT%''
     AND   xe.event_status_code = ''P''
     AND   (xal.accounting_class_code LIKE ''%EXPENSE%'' OR
            xal.accounting_class_code LIKE ''%TAX%'' OR
            xal.accounting_class_code LIKE ''%ACCRUAL%'')
     AND   xal.accounting_class_code NOT LIKE ''%LIAB%''
     AND   xe.upg_batch_id is not null
     AND   xe.upg_batch_id <> -9999
     AND   xah.upg_batch_id is not null
     AND   xah.upg_batch_id <> -9999
     AND   xal.upg_batch_id is not null
     AND   xal.upg_batch_id <> -9999
     AND   xal.business_class_code is null
     AND   xte.ledger_id = ai.set_of_books_id
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Accounting Lines for Prepayment Invoices Missing Business Class Code',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Upgraded prepayment invoice accounting is missing business class code for prepaid_expense accounting lines',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1109933.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prepay_bus_code_s');



debug('begin add_signature: ap_prepay_pay_cancel_s');
  add_signature(
      p_sig_id                 => 'ap_prepay_pay_cancel_s',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(aid ppd) no_merge(iview) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            ai.invoice_date,
            ai.invoice_amount,
            aid.invoice_distribution_id,
            aid.line_type_lookup_code,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.accounting_event_id event_id,
            aid.posted_flag,
            aid.parent_reversal_id,
            aid.reversal_flag,
            xe.event_type_code,
            ai_prepay.invoice_id   prepay_invoice_id,
            ai_prepay.invoice_num  prepay_invoice_num,
            ai_prepay.invoice_date prepay_invoice_date,
            ail.prepay_line_number prepay_line_number,
            ai.set_of_books_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_lines_all ail,
          ap_invoice_distributions_all aid,
          ap_invoice_distributions_all ppd,
          ap_invoices_all ai_prepay,
          xla_events xe
     WHERE xe.application_id = 200
     AND   xe.event_id = aid.accounting_event_id
     AND   aid.invoice_line_number = ail.line_number
     AND   aid.invoice_id = ail.invoice_id
     AND   ail.invoice_id = ai.invoice_id
     AND   aid.prepay_distribution_id = ppd.invoice_distribution_id
     AND   ppd.invoice_id = ai_prepay.invoice_id
     AND   aid.posted_flag <> ''Y''
     AND   xe.event_status_code <> ''P''
     AND   NOT EXISTS (
             SELECT 1 FROM ap_invoice_payments_all aip
             WHERE aip.invoice_id = ai_prepay.invoice_id
             AND   nvl(aip.reversal_flag, ''N'') <> ''Y'')
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Prepay Unapplication Not Getting Accounted',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment application or unapplication events are not getting accounted because all payments for the corresponding prepayment invoice have been cancelled',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1284158.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prepay_pay_cancel_s');



debug('begin add_signature: ap_corrupt_prepay_adj_s1');
  add_signature(
      p_sig_id                 => 'ap_corrupt_prepay_adj_s1',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_date,
            ai.invoice_type_lookup_code,
            asu.vendor_name,
            assi.vendor_site_id,
            apph.prepay_history_id,
            apph.accounting_date,
            apph.accounting_event_id event_id,
            apph.bc_event_id,
            apph.posted_flag,
            apph.transaction_type,
            apph.invoice_line_number,
            apph.prepay_line_num,
            apph.prepay_invoice_id,
            apph.invoice_adjustment_event_id,
            apph.related_prepay_app_event_id,
            ai.set_of_books_id
     FROM ap_prepay_history_all apph,
          ap_invoices_all ai,
          ap_suppliers asu,
          ap_supplier_sites_all assi,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE apph.transaction_type = ''PREPAYMENT APPLICATION ADJ''
     AND   apph.related_prepay_app_event_id is null
     AND   nvl(apph.historical_flag,   ''N'') <> ''Y''
     AND   apph.posted_flag <> ''Y''
     AND   apph.invoice_id = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Corruptions On Prepayment Application Adjustment Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment application adjustment events generated with a NULL Related_prepay_app_event_ID, causing create accounting to error out',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1326703.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_corrupt_prepay_adj_s1');



debug('begin add_signature: ap_corrupt_prepay_adj_s2');
  add_signature(
      p_sig_id                 => 'ap_corrupt_prepay_adj_s2',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_date,
            ai.invoice_type_lookup_code,
            asu.vendor_name,
            assi.vendor_site_id,
            apph.prepay_history_id,
            apph.accounting_date,
            apph.accounting_event_id event_id,
            apph.bc_event_id,
            apph.posted_flag,
            apph.transaction_type,
            apph.invoice_line_number,
            apph.prepay_line_num,
            apph.prepay_invoice_id,
            apph.invoice_adjustment_event_id,
            apph.related_prepay_app_event_id,
            ai.set_of_books_id
     FROM ap_prepay_history_all apph,
          ap_invoices_all ai,
          ap_suppliers asu,
          ap_supplier_sites_all assi,
          xla_events xe,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE apph.transaction_type = ''PREPAYMENT APPLICATION ADJ''
     AND   apph.invoice_adjustment_event_id = xe.event_id
     AND   apph.invoice_adjustment_event_id is not null
     AND   xe.event_type_code LIKE ''PREPAY%''
     AND   nvl(apph.historical_flag,   ''N'') <> ''Y''
     AND   apph.posted_flag <> ''Y''
     AND   apph.invoice_id = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Corruptions On Prepayment Application Adjustment Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment application adjustment events generated with a NULL Related_prepay_app_event_ID, causing create accounting to error out',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1326703.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_corrupt_prepay_adj_s2');



debug('begin add_signature: ap_orphan_xdl_s');
  add_signature(
      p_sig_id                 => 'ap_orphan_xdl_s',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT /*+ leading(invs) use_nl(ai, xte, xe, xah, xll, xdl) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            ai.invoice_amount,
            ai.invoice_currency_code,
            ai.invoice_date,
            xe.event_id,
            xe.event_type_code,
            xe.event_status_code,
            xe.process_status_code,
            xah.ae_header_id,
            xah.gl_transfer_status_code,
            decode(xah.balance_type_code,
              ''A'', ''Actual'',
              ''E'', ''Encumbrance'') balance_type,
            xe.event_date,
            ai.set_of_books_id
     FROM invs,
          ap_invoices_all ai,
          xla_transaction_entities_upg xte,
          xla_events xe,
          xla_ae_headers xah,
          xla_ae_lines xll,
          xla_distribution_links xdl
     WHERE xe.application_id = 200
     AND   xdl.application_id = 200
     AND   xll.application_id = 200
     AND   xah.application_id = 200
     AND   xte.application_id = 200
     AND   xe.event_status_code = ''P''
     AND   nvl(xe.budgetary_control_flag, ''N'') = ''N''
     AND   xe.event_type_code NOT IN (''PREPAYMENT APPLIED'',
                ''PREPAYMENT UNAPPLIED'',
                ''PREPAYMENT APPLICATION ADJ'')
     AND   xe.event_id = xah.event_id
     AND   xe.entity_id = xte.entity_id
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.ledger_id = ai.set_of_books_id
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   xah.ae_header_id = xll.ae_header_id
     AND   xah.balance_type_code = ''A''
     AND   (xah.upg_batch_id is null OR
            xah.upg_batch_id = -9999)
     AND   xll.accounting_class_code = ''LIABILITY''
     AND   xdl.ae_header_id = xll.ae_header_id
     AND   xdl.ae_line_num = xll.ae_line_num
     AND   xdl.source_distribution_type LIKE ''AP_INV_DIST''
     AND   xe.event_type_code <> ''MANUAL''
     AND   EXISTS (
             SELECT 1 FROM ap_invoice_distributions_all AID
             WHERE aid.accounting_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT ''inv dist'' FROM ap_invoice_distributions_all aid
             WHERE aid.invoice_distribution_id = xdl.source_distribution_id_num_1
             AND   aid.accounting_event_id = xe.event_id)
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ leading(invs) use_nl(ai, xte, xe, xah, xll, xdl) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            ai.invoice_amount,
            ai.invoice_currency_code,
            ai.invoice_date,
            xe.event_id,
            xe.event_type_code,
            xe.event_status_code,
            xe.process_status_code,
            xah.ae_header_id,
            xah.gl_transfer_status_code,
            decode(xah.balance_type_code,
              ''A'', ''Actual'',
              ''E'', ''Encumbrance'') balance_type,
            xe.event_date,
            ai.set_of_books_id
     FROM invs,
          ap_invoices_all ai,
          xla_transaction_entities_upg xte,
          xla_events xe,
          xla_ae_headers xah,
          xla_ae_lines xll,
          xla_distribution_links xdl
     WHERE xe.application_id = 200
     AND   xdl.application_id = 200
     AND   xll.application_id = 200
     AND   xah.application_id = 200
     AND   xte.application_id = 200
     AND   xe.event_status_code = ''P''
     AND   nvl(xe.budgetary_control_flag, ''N'') = ''N''
     AND   xe.event_type_code NOT IN (''PREPAYMENT APPLIED'',
             ''PREPAYMENT UNAPPLIED'', ''PREPAYMENT APPLICATION ADJ'')
     AND   xe.event_id = xah.event_id
     AND   xe.entity_id = xte.entity_id
     AND   xte.ledger_id = ai.set_of_books_id
     AND   xte.entity_code = ''AP_INVOICES''
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   xah.ae_header_id = xll.ae_header_id
     AND   xah.balance_type_code = ''A''
     AND   (xah.upg_batch_id is null OR xah.upg_batch_id = -9999)
     AND   xll.accounting_class_code = ''SELF_ASSESSED_TAX_LIAB''
     AND   xdl.ae_header_id = xll.ae_header_id
     AND   xdl.ae_line_num = xll.ae_line_num
     AND   xdl.source_distribution_type LIKE ''AP_INV_DIST''
     AND   xe.event_type_code <> ''MANUAL''
     AND   EXISTS (
             SELECT  1 FROM ap_self_assessed_tax_dist_all aid
            WHERE aid.accounting_event_id = xe.event_id)
     AND   NOT EXISTS (
             SELECT ''inv dist'' FROM ap_self_assessed_tax_dist_all aid
             WHERE aid.invoice_distribution_id = xdl.source_distribution_id_num_1
             AND   aid.accounting_event_id = xe.event_id)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Orphan Payables Distributions In Subledger Accounting',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Records in xla_distribution_links which do not tie back to a valid record in ap_invoice_distributions_all or ap_self_assessed_tax_dists_all tables',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1291521.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_orphan_xdl_s');



debug('begin add_signature: ap_posted_flag_out_sync_sel_2');
  add_signature(
      p_sig_id                 => 'ap_posted_flag_out_sync_sel_2',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT ''INV DISTRIBUTION'' trx_type,
            ai.invoice_id,
            ai.invoice_num,
            aid.org_id,
            aid.invoice_line_number,
            aid.invoice_distribution_id,
            aid.distribution_line_number,
            null prepay_history_id,
            aid.posted_flag,
            xe.event_status_code,
            xe.event_id,
            decode(xe.event_status_code, ''P'',''Y'',''N'') events_posted_flag
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          xla_events xe
     WHERE aid.posted_flag = ''S''
     AND   xe.application_id = 200
     AND   xe.event_id = aid.accounting_event_id
     AND   ai.invoice_id = aid.invoice_id
     AND   ai.invoice_id = invs.invoice_id
     UNION
     SELECT ''PREPAY HISTORY'',
            ai.invoice_id,
            ai.invoice_num,
            aph.org_id,
            null,
            null,
            null,
            aph.prepay_history_id,
            aph.posted_flag,
            xe.event_status_code,
            xe.event_id ,
            decode(xe.event_status_code, ''P'',''Y'',''N'') events_posted_flag
     FROM invs,
          ap_invoices_all ai,
          ap_prepay_history_all aph,
          xla_events xe
     WHERE ai.invoice_id = invs.invoice_id
     AND   aph.posted_flag = ''S''
     AND   xe.application_id = 200
     AND   xe.event_id = aph.accounting_event_id
     AND   ai.invoice_id = aph.invoice_id',
      p_title                  => 'Posted Flag Stuck In Transaction Tables',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Posted flag stuck in status ''S'' on transaction tables',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1088872.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_posted_flag_out_sync_sel_2');



debug('begin add_signature: ApAppAccUnappNoActionSel');
  add_signature(
      p_sig_id                 => 'ApAppAccUnappNoActionSel',
      p_sig_sql                => 'SELECT ''Primary Prepay Events'' category,
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            aidp.invoice_line_number prepay_app_line_num,
            aidp.distribution_line_number prepay_app_dist_num,
            aidp.invoice_distribution_id prepay_app_distribution_id,
            aidp.line_type_lookup_code prepay_app_dist_type,
            aidp.amount prepay_app_amount,
            aidp.base_amount prepay_app_base_amount,
            aidp.posted_flag prepay_app_posted_flag,
            aidp.accounting_date prepay_app_accounting_date,
            aidp.accounting_event_id prepay_app_event_id,
            aidp.accounting_event_id event_id,
            xep.event_status_code prepay_app_event_status,
            xep.process_status_code prepay_app_process_status,
            aidu.distribution_line_number prepay_unapp_dist_num,
            aidu.invoice_distribution_id prepay_unapp_distribution_id,
            aidu.posted_flag prepay_unapp_posted_flag,
            aidu.accounting_date prepay_unapp_accounting_date,
            aidu.accounting_event_id prepay_unapp_event_id,
            xeu.event_status_code prepay_unapp_event_status,
            xeu.process_status_code prepay_unapp_process_status,
            aidp.set_of_books_id
     FROM ap_invoice_distributions_all aidp,
          ap_invoice_distributions_all aidu,
          ap_invoices_all ai,
          ap_suppliers asu,
          ap_supplier_sites_all assi,
          xla_events xep,
          xla_events xeu,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE aidp.invoice_id = aidu.invoice_id
     AND   aidp.invoice_id = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   aidp.invoice_distribution_id = aidu.parent_reversal_id
     AND   aidp.prepay_distribution_id is not null
     AND   aidu.prepay_distribution_id is not null
     AND   aidp.posted_flag = ''Y''
     AND   aidu.posted_flag = ''Y''
     AND   aidp.accounting_event_id = xep.event_id
     AND   xep.application_id = 200
     AND   aidu.accounting_event_id = xeu.event_id
     AND   xeu.application_id = 200
     AND   xep.event_status_code = ''P''
     AND   xep.process_status_code = ''P''
     AND   xep.upg_batch_id is null
     AND   xeu.event_status_code = ''N''
     AND   xeu.process_status_code = ''P''
     AND   xeu.upg_batch_id is null
     AND   xep.event_type_code = ''PREPAYMENT APPLIED''
     AND   xeu.event_type_code = ''PREPAYMENT UNAPPLIED''
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Prepayment Unapplication Event In a NO Action Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment unapplication event in a NO Action status, even though the prepayment application event is accounted',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1315907.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ApAppAccUnappNoActionSel');



debug('begin add_signature: ap_prepay_incorr_posted_s1');
  add_signature(
      p_sig_id                 => 'ap_prepay_incorr_posted_s1',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai aid xe) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.invoice_distribution_id,
            ai.invoice_type_lookup_code,
            ai.invoice_date,
            ai.invoice_amount,
            aid.line_type_lookup_code,
            aid.amount,
            aid.base_amount,
            aid.match_status_flag,
            aid.accounting_event_id,
            aid.posted_flag,
            aid.accrual_posted_flag,
            aid.cash_posted_flag,
            xe.event_status_code,
            xe.process_status_code,
            gl.sla_ledger_cash_basis_flag,
            aid.set_of_books_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          gl_ledgers gl,
          xla_events xe
     WHERE aid.invoice_id = ai.invoice_id
     AND   ai.set_of_books_id = gl.ledger_id
     AND   aid.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   xe.event_type_code IN (''PREPAYMENT APPLIED'',
             ''PREPAYMENT UNAPPLIED'')
     AND   aid.prepay_distribution_id is not null
     AND   xe.event_status_code IN (''N'',''P'')
     AND   xe.process_status_code = ''P''
     AND   (nvl(aid.posted_flag, ''N'') <> ''Y'' OR
            (gl.sla_ledger_cash_basis_flag = ''Y'' AND
             nvl(aid.cash_posted_flag, ''N'') <> ''Y'') OR
            (gl.sla_ledger_cash_basis_flag = ''N'' AND
             nvl(aid.accrual_posted_flag, ''N'') <> ''Y''))
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Prepayment Event Has Incorrect Posted Flags',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accrual posted flag and cash posted flag as ''N'' on AP distributions for prepayment application and unapplication dists even though the corresponding events have been accounted',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1335562.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prepay_incorr_posted_s1');



debug('begin add_signature: ap_prepay_incorr_posted_s2');
  add_signature(
      p_sig_id                 => 'ap_prepay_incorr_posted_s2',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            ai.invoice_date,
            ai.invoice_amount,
            apph.invoice_line_number,
            apph.transaction_type,
            apph.prepay_history_id,
            apph.prepay_invoice_id,
            apph.prepay_line_num,
            apph.accounting_event_id,
            apph.posted_flag,
            xe.event_status_code,
            xe.process_status_code,
            gl.sla_ledger_cash_basis_flag,
            ai.set_of_books_id
     FROM ap_prepay_history_all apph,
         ap_invoices_all ai,
         ap_suppliers asu,
         ap_supplier_sites_all assi,
         gl_ledgers gl,
         xla_events xe,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE apph.invoice_id = ai.invoice_id
     AND   ai.set_of_books_id = gl.ledger_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   apph.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   xe.event_type_code IN (''PREPAYMENT APPLIED'',
             ''PREPAYMENT UNAPPLIED'',''PREPAYMENT APPLICATION ADJ'')
     AND   xe.event_status_code IN (''N'',''P'')
     AND   xe.process_status_code = ''P''
     AND   nvl(apph.posted_flag, ''N'') <> ''Y''
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Prepayment Event Has Incorrect Posted Flags',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accrual posted flag and cash posted flag as ''N'' on AP distributions for prepayment application and unapplication dists even though the corresponding events have been accounted',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1335562.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prepay_incorr_posted_s2');



debug('begin add_signature: ap_prepay_apply_unapply_sel');
  add_signature(
      p_sig_id                 => 'ap_prepay_apply_unapply_sel',
      p_sig_sql                => 'SELECT /*+ ordered use_nl(ai, aid, xe, xe2) */
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.invoice_distribution_id,
            aid.parent_reversal_id,
            xe.event_type_code,
            aid.accounting_event_id,
            aid.bc_event_id,
            aid.amount,
            aid.base_amount
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          xla_events xe,
          xla_events xe2
     WHERE aid.invoice_id = ai.invoice_id
     AND   ai.cancelled_date is not null
     AND   ai.invoice_amount = 0
     AND   aid.prepay_distribution_id is not null
     AND   nvl(aid.reversal_flag, ''N'') = ''Y''
     AND   nvl(aid.posted_flag, ''N'')  <> ''Y''
     AND   aid.accounting_event_id = xe.event_id (+)
     AND   nvl(xe.application_id, 200) = 200
     AND   nvl(xe.event_status_code, ''N'') <> ''P''
     AND   nvl(aid.encumbered_flag, ''N'') <> ''Y''
     AND   aid.bc_event_id = xe2.event_id (+)
     AND   nvl(xe2.application_id, 200) = 200
     AND   nvl(xe2.event_status_code, ''N'') <> ''P''
     AND   EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aid1
             WHERE aid1.invoice_id = aid.invoice_id
             AND   aid1.prepay_distribution_id IS NOT NULL
             AND   nvl(aid1.reversal_flag, ''N'') = ''Y''
             AND   (aid.parent_reversal_id = aid1.invoice_distribution_id OR
                    aid.invoice_distribution_id = aid1.parent_reversal_id)
             AND   nvl(aid1.posted_flag, ''N'') <> ''Y''
             AND   nvl(aid1.encumbered_flag, ''N'') <> ''Y'')
     AND EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aid2
             WHERE aid2.invoice_id = ai.invoice_id
             AND aid2.prepay_distribution_id is null)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Unaccounted Prepay Events For Cancelled Invoice',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Unaccounted prepay apply and unapply events exist for canceled invoices',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [970912.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prepay_apply_unapply_sel');



debug('begin add_signature: ap_prepay_adj_orphan_s');
  add_signature(
      p_sig_id                 => 'ap_prepay_adj_orphan_s',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_date,
            ai.invoice_amount,
            ai.invoice_type_lookup_code,
            ai.set_of_books_id,
            xe.event_id,
            xe.event_type_code,
            xe.event_date,
            xe.creation_date,
            asu.vendor_name,
            assi.vendor_site_code
     FROM xla_events xe,
          xla_transaction_entities_upg xte,
          ap_invoices_all ai,
          ap_suppliers asu,
          ap_supplier_sites_all assi,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE xe.application_id = 200
     AND   xe.event_status_code IN (''I'',''U'')
     AND   xe.event_type_code = ''PREPAYMENT APPLICATION ADJ''
     AND   NOT EXISTS (
             SELECT 1 FROM ap_prepay_history_all apph
             WHERE apph.accounting_event_id = xe.event_id)
     AND   xe.entity_id = xte.entity_id
     AND   xte.application_id = 200
     AND   xte.entity_code = ''AP_INVOICES''
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Orphan Prepayment Application Adjustment Accounting Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Orphan prepayment application adjustment accounting events with no corresponding record in ap_prepay_history_all',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1317827.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prepay_adj_orphan_s');



debug('begin add_signature: ap_prep_np_unapp_unacc_sel');
  add_signature(
      p_sig_id                 => 'ap_prep_np_unapp_unacc_sel',
      p_sig_sql                => 'SELECT /*+  ordered use_nl(app_aid, xe_app, unapp_aid, xe_unapp) */
            app_aid.invoice_id,
            app_aid.org_id,
            app_aid.invoice_line_number app_line_number,
            app_aid.line_type_lookup_code app_line_type,
            app_aid.invoice_distribution_id app_dist_id,
            app_aid.accounting_Event_id app_event_id,
            app_aid.posted_flag app_posted_flag,
            unapp_aid.invoice_line_number unapp_line_number,
            unapp_aid.line_type_lookup_code unapp_line_type,
            unapp_aid.invoice_distribution_id unapp_dist_id,
            unapp_aid.accounting_Event_id unapp_event_id,
            unapp_aid.posted_flag unapp_posted_flag
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoice_distributions_all app_aid,
          xla_events xe_app,
          ap_invoice_distributions_all unapp_aid,
          xla_events xe_unapp
     WHERE app_aid.prepay_distribution_id is not null
     AND app_aid.posted_flag = ''Y''
     AND app_aid.accounting_event_id = xe_app.event_id
     AND xe_app.application_id = 200
     AND xe_app.event_type_code = ''PREPAYMENT APPLIED''
     AND xe_app.event_status_code = ''N''
     AND xe_app.process_status_code = ''P''
     AND unapp_aid.invoice_id = app_aid.invoice_id
     AND unapp_aid.prepay_distribution_id is not null
     AND unapp_aid.parent_reversal_id is not null
     AND app_aid.invoice_distribution_id = unapp_aid.parent_reversal_id
     AND unapp_aid.posted_flag = ''N''
     AND unapp_aid.accounting_event_id = xe_unapp.event_id
     AND xe_unapp.event_type_code = ''PREPAYMENT UNAPPLIED''
     AND xe_unapp.application_id = 200
     AND xe_unapp.event_status_code = ''U''
     AND app_aid.invoice_id = invs.invoice_id',
      p_title                  => 'Prepayment Application Event In No Action',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Events for prepayment unapplication will not account because the corresponding prepayment application event is flagged for no action (EVENT_STATUS_CODE=N)',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1460855.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prep_np_unapp_unacc_sel');



debug('begin add_signature: ApIncorrEventTypeSel');
  add_signature(
      p_sig_id                 => 'ApIncorrEventTypeSel',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT /*+ ordered use_nl(ai, xte, xe) */
            xe.event_id,
            xe.event_type_code,
            decode(xe.event_type_code,
              ''INVOICE VALIDATED'', decode(ai.invoice_type_lookup_code,
                                     ''DEBIT'', ''DEBIT MEMO VALIDATED'',
                                     ''CREDIT'', ''CREDIT MEMO VALIDATED'',
                                     ''PREPAYMENT'',''PREPAYMENT VALIDATED'',
                                     xe.event_type_code),
              ''INVOICE ADJUSTED'',  decode(ai.invoice_type_lookup_code,
                                     ''DEBIT'', ''DEBIT MEMO ADJUSTED'',
                                     ''CREDIT'', ''CREDIT MEMO ADJUSTED'',
                                     ''PREPAYMENT'', ''PREPAYMENT ADJUSTED'',
                                     xe.event_type_code),
              ''INVOICE CANCELLED'', decode(ai.invoice_type_lookup_code,
                                     ''DEBIT'', ''DEBIT MEMO CANCELLED'',
                                     ''CREDIT'', ''CREDIT MEMO CANCELLED'',
                                     ''PREPAYMENT'',''PREPAYMENT CANCELLED'',
                                     xe.event_type_code),
              xe.event_type_code) proposed_event_type,
            xe.event_date,
            xe.entity_id,
            xe.event_status_code,
            xe.process_status_code,
            xe.upg_batch_id,
            to_char(null) old_event_type,
            ai.invoice_id,
            ai.invoice_num,
            ai.invoice_date,
            ai.invoice_amount,
            ai.invoice_type_lookup_code,
            ai.org_id,
            ai.set_of_books_id
     FROM invs,
          ap_invoices_all ai,
          xla_transaction_entities_upg xte,
          xla_events xe
     WHERE ai.invoice_id = invs.invoice_id
     AND   xte.application_id = 200
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   nvl(xte.security_id_int_1, -99) = ai.org_id
     AND   xte.ledger_id = ai.set_of_books_id
     AND   ai.invoice_type_lookup_code IN (''CREDIT'', ''DEBIT'', ''PREPAYMENT'')
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.application_id = 200
     AND   xe.entity_id = xte.entity_id
     AND   xe.event_type_code LIKE ''INVOICE%''
     AND   xe.application_id = 200
     UNION ALL
     SELECT /*+ ordered use_nl(ai, xte, xe, aae) */
            xe.event_id,
            xe.event_type_code,
            decode(ai.invoice_type_lookup_code,
              ''DEBIT'', ''DEBIT MEMO ADJUSTED'',
              ''CREDIT'', ''CREDIT MEMO ADJUSTED'',
              ''PREPAYMENT'', ''PREPAYMENT ADJUSTED'',
              ''INVOICE ADJUSTED'') proposed_event_type,
            xe.event_date,
            xe.entity_id,
            xe.event_status_code,
            xe.process_status_code,
            xe.upg_batch_id,
            aae.event_type_code old_event_type,
            ai.invoice_id,
            ai.invoice_num,
            ai.invoice_date,
            ai.invoice_amount,
            ai.invoice_type_lookup_code,
            ai.org_id,
            ai.set_of_books_id
     FROM invs,
          ap_invoices_all ai,
          xla_transaction_entities_upg xte,
          xla_events xe,
          ap_accounting_events_all aae
     WHERE ai.invoice_id = invs.invoice_id
     AND   nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   nvl(xte.security_id_int_1, -99) = ai.org_id
     AND   xte.ledger_id = ai.set_of_books_id
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.application_id = 200
     AND   xe.entity_id = xte.entity_id
     AND   xe.event_type_code not LIKE ''%ADJUSTED%''
     AND   aae.event_type_code LIKE ''%ADJUST%''
     AND   xe.event_id = aae.accounting_event_id
     AND   xe.application_id = 200',
      p_title                  => 'Incorrect Invoice Event Types For Upgraded Prepayment, Credit Memo And Debit Memo',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Incorrect invoice event types for upgraded prepayment, credit memo, and debit memo invoices resulting in accounting error due to imbalanced journal entry in the subledger.',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1336255.1]</li>
   </ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ApIncorrEventTypeSel');



debug('begin add_signature: orphan_self_assess_tax_inv_dists_sel');
  add_signature(
      p_sig_id                 => 'orphan_self_assess_tax_inv_dists_sel',
      p_sig_sql                => 'SELECT aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.line_type_lookup_code,
            aid.accrual_posted_flag,
            aid.amount
     FROM ap_invoice_distributions_all aid,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE aid.invoice_line_number is null
     AND   aid.line_type_lookup_code in (''REC_TAX'', ''NONREC_TAX'', ''TRV'',
             ''TIPV'', ''TERV'')
     AND   EXISTS (
             SELECT ''Tax Distributions'' FROM zx_rec_nrec_dist zd
             WHERE zd.rec_nrec_tax_dist_id = aid.detail_tax_dist_id
             AND   nvl(SELF_ASSESSED_FLAG, ''N'') = ''Y'')
     AND   EXISTS (
             SELECT ''self assessed tax'' FROM AP_SELF_ASSESSED_TAX_DIST_ALL asat
             WHERE asat.invoice_id = aid.invoice_id
             AND   asat.detail_tax_dist_id = aid.detail_tax_dist_id)
     AND   aid.invoice_id = invs.invoice_id',
      p_title                  => 'Orphan Non-Recoverable Tax Distributions',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Orphan non-recoverable tax distributions created due to bug 7422547, where a normal tax line is modified to be self-assessed',
      p_solution               => '<ul>
   <li>Generate the APLIST output for affected invoices and log a Service Request</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: orphan_self_assess_tax_inv_dists_sel');



debug('begin add_signature: AMT_NULL_MTCHD_DIST_SEL');
  add_signature(
      p_sig_id                 => 'AMT_NULL_MTCHD_DIST_SEL',
      p_sig_sql                => 'SELECT aid.invoice_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.invoice_distribution_id,
            ai.cancelled_date,
            ai.invoice_currency_code,
            asp.base_currency_code
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoice_distributions_all aid,
          ap_invoices_all ai,
          ap_system_parameters_all asp
     WHERE ai.invoice_id = invs.invoice_id
     AND   aid.invoice_id = ai.invoice_id
     AND   aid.po_distribution_id IS NOT NULL
     AND   aid.line_type_lookup_code in (''ITEM'',''ACCRUAL'')
     AND   aid.amount is null
     AND   asp.org_id = ai.org_id',
      p_title                  => 'Matched Invoice Distributions Have a NULL Amount',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Matched invoice distributions have a NULL amount preventing the invoice from accounting.',
      p_solution               => '<ul>
   <li>Apply the fix for root cause bug 9445201 if you have not done so, and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AMT_NULL_MTCHD_DIST_SEL');



debug('begin add_signature: ap_inv_dist_null_amt');
  add_signature(
      p_sig_id                 => 'ap_inv_dist_null_amt',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.invoice_type_lookup_code,
            ai.invoice_date,
            ai.invoice_amount,
            asu.vendor_name,
            assi.vendor_site_code,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.line_type_lookup_code,
            aid.amount,
            aid.base_amount,
            aid.accounting_event_id,
            aid.invoice_distribution_id,
            ai.org_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          ap_suppliers asu,
          ap_supplier_sites_all assi
     WHERE ai.invoice_id = invs.invoice_id
     AND   aid.invoice_id = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   amount is null',
      p_title                  => 'Invoice Distributions With A Null Amount',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice distributions with a null amount causing them not to be accounted.',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_inv_dist_null_amt');



debug('begin add_signature: ap_remtchdist_cnclinv_sel');
  add_signature(
      p_sig_id                 => 'ap_remtchdist_cnclinv_sel',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.cancelled_date,
            aid.invoice_line_number,
            aid.invoice_distribution_id,
            aid.creation_date dist_creation_date,
            aid.po_distribution_id,
            aid.accounting_event_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid
     WHERE ai.invoice_id = invs.invoice_id
     AND   ai.cancelled_date is not null
     AND   aid.invoice_id = ai.invoice_id
     AND   aid.creation_date > ai.cancelled_date
     AND   aid.po_distribution_id is not null
     AND   aid.accounting_event_id is null',
      p_title                  => 'Cancelled Invoices Are Rematched',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Cancelled invoices are rematched after the match option is changed on the invoice header.',
      p_solution               => '<ul>
   <li>Apply the root cause fix from bug 16841130 if you have not done so, and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_remtchdist_cnclinv_sel');



debug('begin add_signature: upg_awt_base_amt_null_sel');
  add_signature(
      p_sig_id                 => 'upg_awt_base_amt_null_sel',
      p_sig_sql                => 'WITH invs AS (
       ##$$IVIEW$$##
     )
     SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            aid.invoice_distribution_id,
            aid.line_type_lookup_code,
            aid.historical_flag,
            aid.base_amount
     FROM invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp,
          ap_invoice_distributions_all aid,
          ap_payment_hist_dists aphd,
          xla_events xe
     WHERE ai.invoice_id = invs.invoice_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   ai.invoice_id = aid.invoice_id
     AND   ai.invoice_currency_code = asp.invoice_currency_code
     AND   ai.org_id = asp.org_id
     AND   aid.base_amount is null
     AND   aid.awt_invoice_payment_id is not null
     AND   aid.historical_flag = ''Y''
     AND   aphd.invoice_distribution_id = aid.invoice_distribution_id
     AND   aphd.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   (nvl(xe.upg_batch_id,-9999) = -9999 OR
            xe.event_status_code <> ''P'')
     UNION
     SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            aid.invoice_distribution_id,
            aid.line_type_lookup_code,
            aid.historical_flag,
            aid.base_amount
     FROM invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp,
          ap_invoice_distributions_all aid
     WHERE ai.invoice_id = invs.invoice_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   ai.invoice_id = aid.invoice_id
     AND   ai.invoice_currency_code = asp.invoice_currency_code
     AND   ai.org_id = asp.org_id
     AND   aid.base_amount is null
     AND   aid.awt_invoice_payment_id is not null
     AND   aid.historical_flag = ''Y''
     AND   (ai.payment_status_flag IN (''N'',''P'') OR
            aid.posted_flag <> ''Y'')',
      p_title                  => 'Base Amount Is Null On Unpaid, Unaccounted, Upgraded AWT Invoice',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Base Amount is null on unpaid, unaccounted, upgraded AWT invoice distributions causing payments to be stuck in accounting and the invoices to remain on the trial balance.',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: upg_awt_base_amt_null_sel');



debug('begin add_signature: aid_event_missing_in_xe');
  add_signature(
      p_sig_id                 => 'aid_event_missing_in_xe',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_date,
            ai.invoice_amount,
            aid.invoice_distribution_id,
            aid.accounting_date,
            aid.posted_flag,
            aid.accounting_event_id
     FROM ap_invoice_distributions_all aid,
          ap_invoices_all ai,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE aid.posted_flag <> ''Y''
     AND   aid.invoice_id = ai.invoice_id
     AND   aid.accounting_event_id is not null
     AND   NOT EXISTS (
             SELECT 1 FROM xla_events xe
             WHERE xe.event_id = aid.accounting_event_id
             AND   xe.application_id = 200)
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Invoice Distributions With Accounting_event_id Values Which Are Not Present In XLA',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invoice distributions with accounting_event_id values which are not present in XLA',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: aid_event_missing_in_xe');



debug('begin add_signature: ap_incor_inv_event_type');
  add_signature(
      p_sig_id                 => 'ap_incor_inv_event_type',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_type_lookup_code,
            xe.event_id,
            xe.event_type_code
     FROM xla_transaction_entities_upg xte,
          xla_events xe,
          ap_invoices_all ai,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE nvl(xte.source_id_int_1, -99) = ai.invoice_id
     AND   nvl(xte.security_id_int_1, -99) = ai.org_id
     AND   xte.ledger_id = ai.set_of_books_id
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.application_id = 200
     AND   ai.invoice_type_lookup_code IN (''CREDIT'', ''DEBIT'')
     AND   xe.entity_id = xte.entity_id
     AND   xe.event_type_code LIKE ''INVOICE%''
     AND   xe.application_id = 200
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'Debit or Credit Memo Invoices With Events Having Incorrect Event Types',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Debit or credit memo invoices with events having incorrect event types',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_incor_inv_event_type');



debug('begin add_signature: Invoice_Migration_Status');
  add_signature(
      p_sig_id                 => 'Invoice_Migration_Status',
      p_sig_sql                => 'SELECT glps.period_name,
            glps.start_date,
            glps.end_date,
            glps.set_of_books_id,
            glps.application_id,
            glps.adjustment_period_flag
     FROM ap_invoices_all ai,
          gl_period_statuses glps,
          (
            ##$$IVIEW$$##
          ) invs
     WHERE ai.historical_flag = ''Y''
     AND   EXISTS (
             SELECT 1
             FROM ap_invoice_distributions_all aid,
                  xla_ae_headers xah
             WHERE aid.invoice_id = ai.invoice_id
             AND   aid.historical_flag = ''Y''
             AND   aid.accounting_event_id = xah.event_id
             AND   xah.accounting_entry_status_code = ''F''
             AND   xah.application_id = 200
             AND   xah.upg_batch_id is not null
             AND   xah.upg_batch_id <> -9999)
     AND   ai.gl_date BETWEEN glps.start_date AND glps.end_date
     AND   glps.set_of_books_id = ai.set_of_books_id
     AND   glps.application_id = 200
     AND   nvl(glps.adjustment_period_flag, ''N'') = ''N''
     AND   glps.migration_status_code is null
     AND   ai.invoice_id = invs.invoice_id',
      p_title                  => 'SLA Upgrade',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Periods containing selected transactions for which the XLA hot patch has not been run, potentially resulting in the accounting error ''Error 0 - This line cannot be Accounted till the line it references has been Accounted''',
      p_solution               => '<ul>
   <li>If your selected transactions or related transactions are encountering the error described, 
   Please run the XLA hot patch for the appropriate periods.  
   See [604893.1] for full details of the SLA Upgrade process, including the SLA Hotpatch</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Invoice_Migration_Status');



debug('begin add_signature: sig_1546653_1');
  add_signature(
      p_sig_id                 => 'sig_1546653_1',
      p_sig_sql                => 'WITH invs AS
          (
            ##$$IVIEW$$##
          )
     SELECT ''INVOICE'' category,
            aid.invoice_id,
            aid.description,
            aid.dist_code_combination_id,
            aid.line_type_lookup_code,
            aid.accounting_event_id,
            sum(aid.amount) amount,
            sum(aid.base_amount) base_amount
     FROM ap_invoice_distributions_all aid
     WHERE (nvl(aid.description,'' ''), aid.dist_code_combination_id,
             aid.line_type_lookup_code, aid.accounting_event_id) IN (
               SELECT nvl(aid2.description,'' ''), aid2.dist_code_combination_id,
                      aid2.line_type_lookup_code, aid2.accounting_event_id
               FROM invs,
                    ap_invoice_distributions_all aid2
               WHERE aid2.invoice_id = invs.invoice_id
               AND   aid2.posted_flag <> ''Y''
               GROUP BY nvl(aid2.description,'' ''), aid2.dist_code_combination_id,
                        aid2.line_type_lookup_code, aid2.accounting_event_id
               HAVING   sum(aid2.amount) * sum(aid2.base_amount) < 0 )
     AND   NOT EXISTS (
             SELECT ''No opp. sign dists'' FROM ap_invoice_distributions_all
             WHERE invoice_id = aid.invoice_id
             AND (amount * base_amount) < 0)
     GROUP BY aid.invoice_id, aid.description,
            aid.dist_code_combination_id, aid.line_type_lookup_code,
            aid.accounting_event_id
     UNION
     SELECT ''TAX'',
            aid.invoice_id,
            aid.description,
            aid.dist_code_combination_id,
            aid.line_type_lookup_code,
            aid.accounting_event_id,
            sum(aid.amount) amount,
            sum(aid.base_amount) base_amount
     FROM ap_self_assessed_tax_dist_all aid
     WHERE (nvl(aid.description,'' ''), aid.dist_code_combination_id,
             aid.line_type_lookup_code, aid.accounting_event_id) IN (
               SELECT nvl(aid2.description,'' ''), aid2.dist_code_combination_id,
                      aid2.line_type_lookup_code, aid2.accounting_event_id
               FROM invs,
                    ap_self_assessed_tax_dist_all aid2
               WHERE aid2.invoice_id = invs.invoice_id
               AND   aid2.posted_flag <> ''Y''
               GROUP BY nvl(aid2.description,'' ''), aid2.dist_code_combination_id,
                        aid2.line_type_lookup_code, aid2.accounting_event_id
               HAVING sum(aid2.amount) * sum(aid2.base_amount) < 0 )
     AND   NOT EXISTS (
             SELECT ''No opp. sign dists''
             FROM ap_self_assessed_tax_dist_all
             WHERE invoice_id=aid.invoice_id
             AND (amount * base_amount) < 0)
     GROUP BY aid.invoice_id, aid.description,
            aid.dist_code_combination_id, aid.line_type_lookup_code,
            aid.accounting_event_id',
      p_title                  => 'Create Accounting For Invoices Fails With Error Number 95314',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Create accounting for invoices fails with error number 95314: The entered amount and accounted amount for line xx are not on the same side.',
      p_solution               => '<ul>
   <li>Follow the instructions provided in [1546653.1]</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: sig_1546653_1');



debug('begin add_signature: ap_prep_apad_terv_sel');
  add_signature(
      p_sig_id                 => 'ap_prep_apad_terv_sel',
      p_sig_sql                => 'SELECT apph.invoice_id,
            apph.transaction_type,
            apph.accounting_event_id,
            apph.posted_flag,
            apph.invoice_line_number,
            apph.prepay_invoice_id,
            apph.prepay_line_num
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoice_distributions_all aid,
          ap_prepay_app_dists apad,
          ap_prepay_history_all apph
     WHERE aid.invoice_id = invs.invoice_id
     AND   apad.prepay_history_id = apph.prepay_history_id
     AND   apph.posted_flag <> ''Y''
     AND   apad.invoice_distribution_id = aid.invoice_distribution_id
     AND   aid.line_type_lookup_code = ''TERV''',
      p_title                  => 'Accounting Fails For Prepayment Application Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Accounting fails for prepayment application events if prepay application distributions are prorated against tax exchange rate variance lines (TERV).',
      p_solution               => '<ul>
   <li>Apply the root cause fix from bug 10181254 if you have not done so, and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prep_apad_terv_sel');



debug('begin add_signature: ap_prep_cash_bzns_code_sel');
  add_signature(
      p_sig_id                 => 'ap_prep_cash_bzns_code_sel',
      p_sig_sql                => 'SELECT aip_prepay.invoice_id,
         xal.ae_header_id,
         xal.ae_line_num,
         xal.accounting_class_code,
         xal.business_class_code,
         xal.accounting_date,
         xal.ledger_id,
         xal.gl_sl_link_id,
         xal.party_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_prepay_history_all aph,
          ap_invoices_all ai_prepay,
          ap_invoice_distributions_all aid_prepay,
          ap_invoice_payments_all aip_prepay,
          gl_ledgers gl,
          xla_ae_headers xah,
          xla_ae_lines xal
     WHERE ai_prepay.invoice_id = invs.invoice_id
     AND   aph.posted_flag <>''Y''
     AND   aph.prepay_invoice_id = aid_prepay.invoice_id
     AND   aph.prepay_invoice_id = ai_prepay.invoice_id
     AND   ai_prepay.invoice_type_lookup_code = ''PREPAYMENT''
     AND   aid_prepay.posted_flag = ''Y''
     AND   aid_prepay.invoice_id = aip_prepay.invoice_id
     AND   aip_prepay.posted_flag = ''Y''
     AND   aip_prepay.accounting_event_id = xah.event_id
     AND   xah.application_id = 200
     AND   xal.application_id = 200
     AND   xah.ae_header_id = xal.ae_header_id
     AND   xal.accounting_class_code IN (''NRTAX'',''RTAX'',
             ''PREPAID_EXPENSE'')
     AND   xal.business_class_code is null
     AND   xah.ledger_id = gl.ledger_id
     AND   gl.sla_accounting_method_code like ''%CASH%''',
      p_title                  => 'For Cash Basis Accounting, Tax Jurnal Lines Created',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'For cash basis accounting, tax journal lines created for the payment accounting of the prepayment invoice are missing the business class code, causing issues while accounting the prepayment application events.',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prep_cash_bzns_code_sel');



debug('begin add_signature: ap_prep_unap_apd_invld_sel');
  add_signature(
      p_sig_id                 => 'ap_prep_unap_apd_invld_sel',
      p_sig_sql                => 'SELECT apphu.invoice_id,
            apphu.prepay_invoice_id,
            apphu.accounting_event_id,
            apphu.prepay_history_id,
            appha.accounting_event_id app_acct_event_id,
            appha.prepay_history_id  app_prepay_hist_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_prepay_history_all appha,
          ap_prepay_history_all apphu,
          ap_prepay_app_dists apada,
          ap_prepay_app_dists apadu,
          xla_events xea,
          xla_events xeu
     WHERE appha.invoice_id = invs.invoice_id
     AND   apphu.prepay_history_id = apadu.prepay_history_id
     AND   appha.prepay_history_id = apada.prepay_history_id
     AND   apphu.invoice_id = appha.invoice_id
     AND   apphu.invoice_line_number = appha.invoice_line_number
     AND   appha.transaction_type = ''PREPAYMENT APPLIED''
     AND   apphu.transaction_type = ''PREPAYMENT UNAPPLIED''
     AND   appha.accounting_event_id = xea.event_id
     AND   xea.application_id = 200
     AND   apphu.accounting_event_id = xeu.event_id
     AND   xeu.application_id = 200
     AND   xea.event_status_code = ''P''
     AND   xeu.event_status_code <> ''P''
     AND   apadu.reversed_prepay_app_dist_id = apada.prepay_app_dist_id
     AND   NOT EXISTS (
             SELECT 1 FROM xla_distribution_links xdl
             WHERE xdl.application_id = 200
             AND   xdl.source_distribution_type = ''AP_PREPAY''
             AND   xdl.source_distribution_id_num_1 = apada.prepay_app_dist_id
             AND xdl.event_id = apada.accounting_event_id)',
      p_title                  => 'Prepayment Unapplication Events Will Not Account',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepayment unapplication events will not account because the prepay application distributions for the corresponding application have been deleted and recreated after they were accounted. This causes the line level reversal for the prepayment unapplication to fail to account.',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prep_unap_apd_invld_sel');



debug('begin add_signature: ap_prep_xal_no_desc_sel');
  add_signature(
      p_sig_id                 => 'ap_prep_xal_no_desc_sel',
      p_sig_sql                => 'SELECT xah.event_id,
            xah.event_type_code,
            xal.ae_header_id,
            xal.ae_line_num,
            xal.accounting_class_code,
            xal.description accounting_line_desc,
            xal.entered_dr,
            xal.entered_cr,
            xal.accounted_dr,
            xal.accounted_cr,
            aid.invoice_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.amount,
            aid.base_amount,
            aid.description inv_dist_desc,
            xah.upg_batch_id,
            aid.historical_flag
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoice_distributions_all aid,
          xla_ae_lines xal,
          xla_ae_headers xah,
          xla_distribution_links xdl,
          ap_prepay_app_dists apad
     WHERE aid.invoice_id = invs.invoice_id
     AND   xal.application_id = 200
     AND   xal.accounting_class_code IN (''PREPAID_EXPENSE'',
             ''RTAX'', ''NRTAX'')
     AND   xal.description is null
     AND   xah.application_id = xal.application_id
     AND   xah.ae_header_id = xal.ae_header_id
     AND   xah.event_type_code IN (''PREPAYMENT APPLIED'',
             ''PREPAYMENT UNAPPLIED'', ''PREPAYMENT APPLICATION ADJ'')
     AND   xal.ae_header_id = xdl.ae_header_id
     AND   xal.ae_line_num = xdl.ae_line_num
     AND   xdl.application_id = xal.application_id
     AND   xdl.source_distribution_type = ''AP_PREPAY''
     AND   xdl.source_distribution_id_num_1 = apad.prepay_app_dist_id
     AND   apad.prepay_app_distribution_id = aid.invoice_distribution_id
     AND   decode(xal.accounting_class_code,
             ''PREPAID_EXPENSE'', ''PREPAY'',
             ''RTAX'', ''REC_TAX'',
             ''NRTAX'', ''NONREC_TAX'') = aid.line_type_lookup_code
     AND   aid.description is not null',
      p_title                  => 'Prepay Event Accounting Lines Are Missing',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepay event accounting lines are missing descriptions though these are present on the distributions.',
      p_solution               => '<ul>
   <li>Apply the root cause fix from bug 13012493 (12.0) or 13839833 (12.1) if you have not done so, and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prep_xal_no_desc_sel');



debug('begin add_signature: ap_prep_x_fnl_appl_rnd_sel');
  add_signature(
      p_sig_id                 => 'ap_prep_x_fnl_appl_rnd_sel',
      p_sig_sql                => 'SELECT aid.invoice_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.accounting_event_id,
            aid.line_type_lookup_code,
            aid.amount,
            aid.base_amount,
            apad.prepay_dist_lookup_code,
            apad.prepay_app_dist_id,
            apad.amount prepay_app_dist_amt,
            apad.base_amount prepay_app_dist_base_amt,
            apad.base_amt_at_prepay_xrate
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_prepay_app_dists apad,
          ap_invoice_distributions_all aid,
          ap_prepay_history_all apph
     WHERE aid.invoice_id = invs.invoice_id
     AND   apad.prepay_dist_lookup_code LIKE ''FINAL APPL ROUNDING''
     AND   apad.prepay_history_id = apph.prepay_history_id
     AND   abs(apad.base_amt_at_prepay_xrate) > 5
     AND   apad.prepay_app_distribution_id = aid.invoice_distribution_id
     AND   aid.prepay_distribution_id is not null
     AND   aid.line_type_lookup_code IN (''PREPAY'',
             ''REC_TAX'', ''NONREC_TAX'')
     AND   aid.invoice_id = apph.invoice_id
     AND   aid.invoice_line_number = apph.invoice_line_number
     AND   aid.accounting_event_id = apph.accounting_event_id
     AND   EXISTS (
             SELECT 1
             FROM ap_prepay_app_dists apad_old,
                  ap_invoice_distributions_all aid_old,
                  ap_prepay_history_all apph_old
             WHERE apad_old.prepay_history_id = apph_old.prepay_history_id
             AND   apph_old.prepay_invoice_id = apph.prepay_invoice_id
             AND   apph_old.prepay_line_num = apph.prepay_line_num
             AND   apph_old.invoice_id = aid_old.invoice_id
             AND   apph_old.invoice_line_number = aid_old.invoice_line_number
             AND   apph_old.accounting_event_id = aid_old.accounting_event_id
             AND   aid_old.prepay_distribution_id is not null
             AND   aid_old.line_type_lookup_code IN (''PREPAY'',
                     ''REC_TAX'',''NONREC_TAX'')
             AND   aid.prepay_distribution_id = aid_old.prepay_distribution_id
             AND   apad_old.base_amt_at_prepay_xrate is null
             AND   nvl(aid_old.historical_flag, ''N'') = ''Y''
             AND   nvl(apph_old.historical_flag, ''N'') = ''Y'')',
      p_title                  => 'Very Large Rounding Lines Incorrectly Created',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Very large rounding lines incorrectly created during final application for prepay events.',
      p_solution               => '<ul>
   <li>Apply the root cause fixes from bugs 9256922 and 10183934 if you have not done so, and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_prep_x_fnl_appl_rnd_sel');



debug('begin add_signature: ap_fnl_apl_rndg_def_tx_sel');
  add_signature(
      p_sig_id                 => 'ap_fnl_apl_rndg_def_tx_sel',
      p_sig_sql                => 'SELECT apad.prepay_app_dist_id,
            apph.invoice_id,
            apad.prepay_dist_lookup_code,
            xal.ae_header_id,
            xal.ae_line_num,
            xal.code_combination_id,
            xal.accounting_class_code,
            xdl.source_distribution_id_num_1,
            xdl.source_distribution_type,
            xdl.accounting_line_code,
            apad.amount,
            apad.base_amount,
            apad.base_amt_at_prepay_xrate,
            zxd.rec_nrec_tax_dist_id,
            zxd.def_rec_settlement_option_code
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoice_distributions_all aidp,
          ap_prepay_app_dists apad,
          ap_prepay_history_all apph,
          xla_distribution_links xdl,
          xla_ae_lines xal,
          zx_rec_nrec_dist zxd
     WHERE aidp.invoice_id = invs.invoice_id
     AND   apad.prepay_app_dist_id = xdl.source_distribution_id_num_1
     AND   apad.prepay_dist_lookup_code = ''FINAL APPL ROUNDING''
     AND   apad.prepay_history_id = apph.prepay_history_id
     AND   apph.posted_flag <> ''Y''
     AND   xdl.source_distribution_type = ''AP_PREPAY''
     AND   xdl.application_id = 200
     AND   xdl.application_id = xal.application_id
     AND   xal.ae_header_id = xdl.ae_header_id
     AND   xal.ae_line_num = xdl.ae_line_num
     AND   xal.application_id = xdl.application_id
     AND   xal.accounting_class_code = ''PREPAID_EXPENSE''
     AND   xal.code_combination_id = -1
     AND   apad.prepay_app_distribution_id = aidp.invoice_distribution_id
     AND   apad.accounting_event_id = aidp.accounting_event_id
     AND   aidp.line_type_lookup_code = ''REC_TAX''
     AND   zxd.application_id = 200
     AND   zxd.event_class_code IN (''STANDARD INVOICES'',''EXPENSE REPORTS'')
     AND   zxd.entity_code = ''AP_INVOICES''
     AND   zxd.rec_nrec_tax_dist_id = aidp.detail_tax_dist_id
     AND   zxd.def_rec_settlement_option_code = ''DEFERRED''',
      p_title                  => 'Prepay Application Accounting Fails',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Prepay application accounting fails when final application rounding has been calculated on a deferred recoverable tax distribution and it is unable to find a required business flow item on the prepayment invoice''s payment.',
      p_solution               => '<ul>
   <li>Apply the root cause fix from bug 13705794 (on 12.1) or bug 14113056 (on 12.0) if you have not done so, and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_fnl_apl_rndg_def_tx_sel');



debug('begin add_signature: ap_orphan_prep_events_sel');
  add_signature(
      p_sig_id                 => 'ap_orphan_prep_events_sel',
      p_sig_sql                => 'SELECT aph.invoice_id,
            aph.org_id,
            aph.invoice_line_number,
            aph.prepay_invoice_id,
            aph.prepay_line_num,
            aph.accounting_date,
            aph.historical_flag,
            aph.accounting_event_id,
            aph.invoice_adjustment_event_id,
            aph.related_prepay_app_event_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_prepay_history_all aph
     WHERE aph.invoice_id = invs.invoice_id
     AND   aph.transaction_type IN (''PREPAYMENT APPLIED'', ''PREPAYMENT UNAPPLIED'')
     AND   aph.posted_flag <> ''Y''
     AND   NOT EXISTS (
             SELECT ''no event'' FROM xla_events xe
             WHERE application_id = 200
             AND xe.event_id = aph.accounting_event_id)
     AND   NOT EXISTS (
             SELECT ''no event''
             FROM ap_invoice_distributions_all aid
             WHERE aid.accounting_event_id = aph.accounting_event_id)',
      p_title                  => 'Orphan Prepay Application Or Unapplication Events',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Orphan prepay application or unapplication events in ap_prepay_history_all which do not exist in xla_events or ap_invoice_distributions_all.',
      p_solution               => '<ul>
   <li>Generate the APList output for the affected invoices and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_orphan_prep_events_sel');



debug('begin add_signature: ap_inv_enc_acc_setup_change');
  add_signature(
      p_sig_id                 => 'ap_inv_enc_acc_setup_change',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.invoice_type_lookup_code,
            ai.invoice_date,
            ai.invoice_amount,
            asu.vendor_name,
            assi.vendor_site_code,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.line_type_lookup_code,
            aid.amount,
            aid.base_amount,
            aid.accounting_event_id,
            aid.invoice_distribution_id,
            ai.org_id,
            xe.event_id,
            xe.event_type_code,
            xte.source_id_int_1 invoice_id,
            xte.transaction_number,
            xe.transaction_date,
            xte.entity_code source_type,
            xte.ledger_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          xla_events xe,
          xla_transaction_entities_upg xte,
          gl_ledgers gl,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          ap_suppliers asu,
          ap_supplier_sites_all assi
     WHERE ai.invoice_id = invs.invoice_id
     AND   xe.application_id    =200
     AND   xe.event_type_code LIKE ''INVOICE%CANCELLED''
     AND   xe.event_status_code <> ''P''
     AND   xe.budgetary_control_flag = ''N''
     AND   xte.application_id = xe.application_id
     AND   xe.entity_id = xte.entity_id
     AND   xte.entity_code = ''AP_INVOICES''
     AND   xte.ledger_id = gl.ledger_id
     AND   nvl(gl.sla_ledger_cash_basis_flag, ''N'') = ''N''
     AND   aid.invoice_id = ai.invoice_id
     AND   ai.vendor_id = asu.vendor_id(+)
     AND   ai.vendor_site_id = assi.vendor_site_id(+)
     AND   EXISTS (
             SELECT 1 FROM xla_events xe1
             WHERE xe1.application_id = 200
             AND   xe1.event_type_code LIKE ''INVOICE%VALIDATED''
             AND   xe1.entity_id = xe.entity_id
             AND   xe1.budgetary_control_flag = ''N''
             AND   xe1.event_status_code = ''P''
             AND   EXISTS (
                     SELECT 1 FROM ap_invoice_distributions_all aid
                     WHERE aid.accounting_event_id = xe1.event_id
                     AND   aid.cash_posted_flag = ''Y'')
             AND   NOT EXISTS (
                     SELECT 1 FROM xla_ae_headers xah1
                     WHERE xah1.application_id = 200
                     AND   xah1.event_id = xe1.event_id
                     AND   xah1.accounting_entry_status_code = ''F''))',
      p_title                  => 'Invoice Validation Event Is Accounted Using Encumbrance Cash Accounting Setup',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'An invoice validation event is accounted using Encumbrance Cash accounting setup. Subsequently the setup is changed to use Accrual Basis accounting and the invoice is cancelled. Since there are no parent distributions links in XLA_DISTRIBUTION_LINKS for the original validation event, the cancelled event fails to get accounted.',
      p_solution               => '<ul>
   <li>Diagnostic information only. Please generate the APLIST output for affected invoices and log a Service Request</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ap_inv_enc_acc_setup_change');



debug('begin add_signature: AP_MAN_RR_CANC_INV_SEL');
  add_signature(
      p_sig_id                 => 'AP_MAN_RR_CANC_INV_SEL',
      p_sig_sql                => 'SELECT ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.cancelled_date,
            ail.line_number,
            ail.line_type_lookup_code,
            ail.line_source,
            aid.invoice_distribution_id,
            aid.reversal_flag,
            aid.retained_invoice_dist_id
     FROM (
            ##$$IVIEW$$##
          ) invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid,
          ap_invoice_lines_all ail
     WHERE ai.invoice_id = invs.invoice_id
     AND   ai.invoice_type_lookup_code = ''RETAINAGE RELEASE''
     AND   ai.cancelled_date is not null
     AND   ai.invoice_id = ail.invoice_id
     AND   ail.invoice_id = aid.invoice_id
     AND   ail.line_number = aid.invoice_line_number
     AND   nvl(ai.historical_flag,''N'') <> ''Y''
     AND   ail.line_type_lookup_code = ''RETAINAGE RELEASE''
     AND   ail.line_source = ''MANUAL LINE ENTRY''
     AND   aid.reversal_flag = ''Y''
     AND   aid.retained_invoice_dist_id is null',
      p_title                  => 'Retainage Release Lines Created Manually',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Retainage Release lines created manually do not hold Retainage details and therefore cannot be accounted.',
      p_solution               => '<ul>
   <li>Apply the root cause fix from bug 11716947 if you have not done so, and log a Service Request to obtain the data fix.</li></ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: AP_MAN_RR_CANC_INV_SEL');

  

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main(
            p_invoice_id                   IN NUMBER      DEFAULT NULL
           ,p_check_id                     IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 10
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

 IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;

  IF g_is_concurrent THEN
     g_rep_info('Calling From'):='Concurrent Program';
  ELSE
     g_rep_info('Calling From'):='SQL Script';
  END IF;

  l_step := '10';
  initialize_files;
  
  -- PSD #11
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Payables Create Accounting';

  l_step := '20';
 -- PSD #12

   validate_parameters(
     p_invoice_id                   => p_invoice_id
    ,p_check_id                     => p_check_id
    ,p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );



  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #13
debug('begin section: Proactive and Preventative Recommendations');
start_section('Proactive and Preventative Recommendations');
   set_item_result(check_rec_patches_1);
end_section;
debug('end section: Proactive and Preventative Recommendations');

debug('begin section: Ledger and Subledger Details');
start_section('Ledger and Subledger Details');
   set_item_result(run_stored_sig('GL_LEDGERS'));
   set_item_result(run_stored_sig('GL_PERIOD'));
   set_item_result(run_stored_sig('SLAM'));
   set_item_result(run_stored_sig('AADS'));
   set_item_result(run_stored_sig('CUSTOM_AAD'));
   set_item_result(run_stored_sig('SHOW_AAD'));
   set_item_result(run_stored_sig('STUCK_AAD'));
   set_item_result(run_stored_sig('PAYABLES_AAD_INVALID'));
   set_item_result(run_stored_sig('SHOW_EVENTCLASS_AAD'));
   set_item_result(run_stored_sig('VERIFY_EVENTCLASS_STATUS'));
end_section;
debug('end section: Ledger and Subledger Details');

debug('begin section: Transaction/Event Summary');
start_section('Transaction/Event Summary');
   IF p_check_id is not null THEN
      set_item_result(run_stored_sig('PAY_SUMMARY'));
      set_item_result(run_stored_sig('EVENT_SUMMARY'));
      set_item_result(run_stored_sig('AUTORATE_PAYMENT'));
      set_item_result(run_stored_sig('AP_INVOICE_PAYMENTS_ALL'));
      set_item_result(run_stored_sig('AP_PAYMENT_HISTORY_ALL'));
      set_item_result(run_stored_sig('XLA_EVENTS_PAY'));
      set_item_result(run_stored_sig('XLA_AE_ERRORS_PAY'));
      set_item_result(run_stored_sig('XLA_AE_HEADERS_PAY'));
      set_item_result(run_stored_sig('ap_pay_hold'));
   END IF;
      IF p_invoice_id is not null THEN
         set_item_result(run_stored_sig('INV_SUMMARY'));
         set_item_result(run_stored_sig('AUTORATE_INVOICE'));
         set_item_result(run_stored_sig('XLA_EVENTS_INV'));
         set_item_result(run_stored_sig('XLA_AE_ERRORS_INV'));
         set_item_result(run_stored_sig('XLA_AE_HEADERS_INV'));
         set_item_result(run_stored_sig('AP_INVOICE_DIST_ALL'));
         set_item_result(run_stored_sig('AP_INVOICE_DIST_ALL_E'));
         set_item_result(run_stored_sig('AP_self_assessed_tax_dist_all'));
         set_item_result(run_stored_sig('AP_self_assessed_tax_dist_all_E'));
         set_item_result(run_stored_sig('ap_prepay_history_all'));
         set_item_result(run_stored_sig('ap_hold'));
         set_item_result(run_stored_sig('ap_inv_hold'));
      END IF;
end_section;
debug('end section: Transaction/Event Summary');

debug('begin section: Data Integrity Issues');
start_section('Data Integrity Issues');
   IF p_invoice_id is not null THEN
      set_item_result(run_stored_sig('mgd_sig_102'));
      set_item_result(run_stored_sig('AP_INVOICE_DISTRIBUTIONS_ALL_O'));
      set_item_result(run_stored_sig('ap_orphan_upg_events_sel'));
      set_item_result(run_stored_sig('AP_SELF_ASSESSED_TAX_DIST_ALL_O'));
      set_item_result(run_stored_sig('out_of_sync'));
      set_item_result(run_stored_sig('missing_XDL'));
      set_item_result(run_stored_sig('ap_trx_missing_event_sel'));
      set_item_result(run_stored_sig('ap_trx_missing_xdl'));
      set_item_result(run_stored_sig('ap_psa_cleanup_s_1'));
      set_item_result(run_stored_sig('ap_psa_cleanup_s_2'));
      set_item_result(run_stored_sig('ap_AcctgDateOutOfSynch_sel'));
      set_item_result(run_stored_sig('ap_unacct_trx_closed_prd_sel'));
      set_item_result(run_stored_sig('ap_inv_event_status_code_sel'));
      set_item_result(run_stored_sig('ap_incorrect_posted_flag_sel'));
      set_item_result(run_stored_sig('ap_xdl_pop_sel'));
      set_item_result(run_stored_sig('xla_mulent_sel'));
      set_item_result(run_stored_sig('AP_AWT_RELATED_ID_SEL'));
      set_item_result(run_stored_sig('ap_msng_inv_hdr_ccid_sel'));
      set_item_result(run_stored_sig('ap_func_curr_inv_with_base_amt_sel'));
      set_item_result(run_stored_sig('ap_wrong_bal_segment_sel'));
      set_item_result(run_stored_sig('ap_wrong_base_amt_sel'));
      set_item_result(run_stored_sig('ap_ret_dist_id_on_rev_dist_sel'));
      set_item_result(run_stored_sig('ap_asatd_no_liab_sel'));
      set_item_result(run_stored_sig('ap_bc_on_rectax_dist_sel'));
      set_item_result(run_stored_sig('ap_prepay_upg_unapply_sel'));
      set_item_result(run_stored_sig('ap_unacc_prep_unapp_sel'));
      set_item_result(run_stored_sig('ap_awt_on_prepay_sel'));
      set_item_result(run_stored_sig('ap_apad_cancelled_dist_sel'));
      set_item_result(run_stored_sig('ap_prep_apld_noitmdist_sel'));
      set_item_result(run_stored_sig('ap_prepay_bus_code_s'));
      set_item_result(run_stored_sig('ap_prepay_pay_cancel_s'));
      set_item_result(run_stored_sig('ap_corrupt_prepay_adj_s1'));
      set_item_result(run_stored_sig('ap_corrupt_prepay_adj_s2'));
      set_item_result(run_stored_sig('ap_orphan_xdl_s'));
      set_item_result(run_stored_sig('ap_posted_flag_out_sync_sel_2'));
      set_item_result(run_stored_sig('ApAppAccUnappNoActionSel'));
      set_item_result(run_stored_sig('ap_prepay_incorr_posted_s1'));
      set_item_result(run_stored_sig('ap_prepay_incorr_posted_s2'));
      set_item_result(run_stored_sig('ap_prepay_apply_unapply_sel'));
      set_item_result(run_stored_sig('ap_prepay_adj_orphan_s'));
      set_item_result(run_stored_sig('ap_prep_np_unapp_unacc_sel'));
      set_item_result(run_stored_sig('ApIncorrEventTypeSel'));
      set_item_result(run_stored_sig('orphan_self_assess_tax_inv_dists_sel'));
      set_item_result(run_stored_sig('AMT_NULL_MTCHD_DIST_SEL'));
      set_item_result(run_stored_sig('ap_inv_dist_null_amt'));
      set_item_result(run_stored_sig('ap_remtchdist_cnclinv_sel'));
      set_item_result(run_stored_sig('upg_awt_base_amt_null_sel'));
      set_item_result(run_stored_sig('aid_event_missing_in_xe'));
      set_item_result(run_stored_sig('ap_incor_inv_event_type'));
      set_item_result(run_stored_sig('Invoice_Migration_Status'));
      set_item_result(run_stored_sig('sig_1546653_1'));
      set_item_result(run_stored_sig('ap_prep_apad_terv_sel'));
      set_item_result(run_stored_sig('ap_prep_cash_bzns_code_sel'));
      set_item_result(run_stored_sig('ap_prep_unap_apd_invld_sel'));
      set_item_result(run_stored_sig('ap_prep_xal_no_desc_sel'));
      set_item_result(run_stored_sig('ap_prep_x_fnl_appl_rnd_sel'));
      set_item_result(run_stored_sig('ap_fnl_apl_rndg_def_tx_sel'));
      set_item_result(run_stored_sig('ap_orphan_prep_events_sel'));
      set_item_result(run_stored_sig('ap_inv_enc_acc_setup_change'));
      set_item_result(run_stored_sig('AP_MAN_RR_CANC_INV_SEL'));
   END IF;
      IF p_check_id is not null THEN
         set_item_result(run_stored_sig('mgd_sig_141'));
         set_item_result(run_stored_sig('mgd_sig_138'));
         set_item_result(run_stored_sig('out_of_sync_pay'));
         set_item_result(run_stored_sig('out_of_sync_pay_hist'));
         set_item_result(run_stored_sig('missing_XDL_pay'));
         set_item_result(run_stored_sig('ap_out_of_sync_checks_sel'));
         set_item_result(run_stored_sig('ap_rate_miss_sel'));
         set_item_result(run_stored_sig('ap_pay_acctng_event_id_null_sel'));
         set_item_result(run_stored_sig('ap_aip_aph_diff_event_sel'));
         set_item_result(run_stored_sig('ap_del_pay_clr_sel'));
         set_item_result(run_stored_sig('ap_payDistsMissInPrior_sel'));
         set_item_result(run_stored_sig('ap_PayWrongEvtId_sel'));
         set_item_result(run_stored_sig('ap_posted_flag_out_sync_sel'));
         set_item_result(run_stored_sig('ap_xla_ae_x_bcc_sel'));
         set_item_result(run_stored_sig('ap_x_posted_flag_sel'));
         set_item_result(run_stored_sig('ap_all_upg_pay_cancel_sel'));
         set_item_result(run_stored_sig('ap_inv_pay_missing_cancel_check_sel'));
         set_item_result(run_stored_sig('ap_event_x_seq_sel'));
         set_item_result(run_stored_sig('Check_Migration_Status'));
         set_item_result(run_stored_sig('ap_11i_chk_missg_adj_event_sel'));
         set_item_result(run_stored_sig('ap_clr_adj_bank_amt_null'));
         set_item_result(run_stored_sig('ap_paycreate_np_to_ui_sel'));
         set_item_result(run_stored_sig('ap_ref_adj_x_evt_type_sel'));
         set_item_result(run_stored_sig('ap_x_pay_clr_adj_sel'));
      END IF;
end_section;
debug('end section: Data Integrity Issues');

debug('begin section: Accounting Packages and File Versions');
start_section('Accounting Packages and File Versions');
   set_item_result(run_stored_sig('CREATE_ACCTG_FILE_VERSIONS'));
end_section;
debug('end section: Accounting Packages and File Versions');



  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/thread/3677671" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;


PROCEDURE main_cp(
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
           ,p_invoice_id                   IN NUMBER      DEFAULT NULL
           ,p_check_id                     IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 10
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y'
)
 IS

BEGIN
  g_retcode := 0;
  g_errbuf := null;

-- PSD #17  

   main(
     p_invoice_id                   => p_invoice_id
    ,p_check_id                     => p_check_id
    ,p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );


  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


-- PSD #1
END ap_accounting_analyzer_pkg;
/
show errors
exit;
-- Exit required for bundling project so do not remove