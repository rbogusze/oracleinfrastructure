SET DEFINE '~'

REM +======================================================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                                                |
REM |                    Redwood Shores, California, USA                                                   |
REM |                         All rights reserved.                                                         |
REM +======================================================================================================+
REM | Framework 3.0.29                                                                                     |
REM |                                                                                                      |
REM | FILENAME                                                                                             |
REM |    inv_trans_analyzer.sql                                                                            |
REM |                                                                                                      |
REM | DESCRIPTION                                                                                          |
REM | The EBS Inventory Transactions Analyzer reviews the status of transactions set-ups, tables, and      | 
REM | provides solutions to common/known transactions data issues.                                         |                                                                                                     |
REM |                                                                                                      |
REM | HISTORY                                                                                              |
REM |                                                                                                      |
REM | Version   /   When    /   Who   /   What                                                             |
REM | 200.1  / 10/27/2015  / tacerny  /  Made Doc ID 1966170.1 template FW changes from v 3.0.24 to 3.0.29 |       
REM | 200.6  / 11/16/2015  / tacerny  /  Synched version to take over previous analyzer version in Bundle  |                                                                                                     |
REM |                                                                                                      |
REM |                                                                                                      |
REM |                                                                                                      |
REM +======================================================================================================+

-- PSD #1
CREATE OR REPLACE PACKAGE inv_trans_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-- PSD #10
PROCEDURE main (
      p_org_id            IN NUMBER   DEFAULT null,
      p_user_name         IN VARCHAR2 DEFAULT null,
      p_responsibility_id IN VARCHAR2 DEFAULT null,	 
      p_from_date         IN DATE     DEFAULT sysdate - 90,
      p_end_date          IN DATE     DEFAULT sysdate - 90,
      p_max_output_rows   IN NUMBER   DEFAULT 50,
      p_debug_mode        IN VARCHAR2 DEFAULT 'Y');

-- PSD #16	  
PROCEDURE main_cp (
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_org_id          IN NUMBER   DEFAULT null,
      p_user_name         IN VARCHAR2 DEFAULT null,
      p_responsibility_id IN VARCHAR2 DEFAULT null,	
      p_from_date         IN VARCHAR2 DEFAULT NULL,
      p_end_date          IN VARCHAR2 DEFAULT NULL);
-- PSD #1
END inv_trans_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY inv_trans_analyzer_pkg AS
-- PSD #1a
-- $Id: inv_trans_analyzer.sql, 200.6 2015/15/01 arobert Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #15  
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1499475.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;

----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'INV_TRANS_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'INV_TRANS_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;
    
    dbms_output.put_line('Output Files are located on Host : '||l_host);
    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1499475.1:SCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/inv_trans_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
         
          -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
          
           -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
           -- this ensures trailing blanks added for padding are honored by browsers
           -- affects only printing, DX summary handled separately
           IF g_preserve_trailing_blanks THEN
             l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
             -- pad length is the number of spaces existing times the length of &nbsp; => 6
             (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
             '&nbsp;');
           ELSE
             l_curr_Val := RTRIM(l_curr_Val, ' ');
           END IF;
           
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
            
           -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
           -- this ensures trailing blanks added for padding are honored by browsers
           -- affects only printing, DX summary handled separately
           IF g_preserve_trailing_blanks THEN
             l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
             -- pad length is the number of spaces existing times the length of &nbsp; => 6
             (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
             '&nbsp;');
           ELSE
             l_curr_Val := RTRIM(l_curr_Val, ' ');
           END IF;
           
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
    IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div><br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
-- PSD #4
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel       VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
  SELECT Max(Last_Update_Date) as date_applied
  FROM Ad_Bugs Adb 
  WHERE Adb.Bug_Number like p_ptch
  AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
    
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #4a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '20';
    l_rel := 'R12';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '8478486';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'Oracle Inventory and Receiving (PO): Release 12.0, Rollup Patch 7';
    l_col_rows(5)(1) := '[845539.1]';
 -- If want to go based on more e-Business Application version, just add for example:
 -- ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
 -- There are no RUP patches for Inventory R12.2, so removed R12.2 below
    ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN	
	    l_rel := 'R12'; 
		l_col_rows.extend(5);
        l_col_rows(1)(1) := '22086747';
        l_col_rows(2)(1) := 'No';
        l_col_rows(3)(1) := NULL;
        l_col_rows(4)(1) := 'Inventory Consolidated RUP13 (VERSION 12.1.3 [RELEASE 12.1])';
        l_col_rows(5)(1) := '[2018001.1]';
        l_col_rows(1)(2) := '22086754';
        l_col_rows(2)(2) := 'No';
        l_col_rows(3)(2) := NULL;
        l_col_rows(4)(2) := 'Logistics Consolidated RUP13 (VERSION 12.1.1 TO 12.1.3 [RELEASE 12.1])';
        l_col_rows(5)(2) := '[2018001.1]';
        l_col_rows(1)(3) := '21198991';
        l_col_rows(2)(3) := 'No';
        l_col_rows(3)(3) := NULL;
        l_col_rows(4)(3) := 'Oracle Procurement Rollup patch (March 2015)';
        l_col_rows(5)(3) := '[1354793.1]';
	ELSE -- 11i
        l_rel := '11i'; 
		l_col_rows.extend(5);
        l_col_rows(1)(1) := '10111967'; 
        l_col_rows(2)(1) := 'No';
        l_col_rows(3)(1) := NULL;
        l_col_rows(4)(1) := 'INV Rollup 23';
        l_col_rows(5)(1) := '';
		l_col_rows(1)(2) := '10129740'; 
        l_col_rows(2)(2) := 'No';
        l_col_rows(3)(2) := NULL;
        l_col_rows(4)(2) := 'WMS RUP 20';
        l_col_rows(5)(2) := '';	
  -- PSD #4a-end

  END IF;
  -- Check if applied
  IF l_col_rows.exists(1) THEN
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i),l_rel);
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;
  END IF;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters (
  p_org_id            IN NUMBER,
  p_user_name         IN VARCHAR2,  
  p_responsibility_id IN NUMBER, 
  p_from_date         IN DATE,
  p_end_date          IN DATE,    
  p_max_output_rows   IN NUMBER,
  p_debug_mode        IN VARCHAR2) IS

  l_user_name         VARCHAR2(20);
  l_responsibility_id VARCHAR2(30);
  l_from_date         VARCHAR2(25);
  l_end_date          VARCHAR2(25);
  l_revision          VARCHAR2(25);
  l_date_char         VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;

  invalid_parameters EXCEPTION;
  
  -- PSD #7a

  l_key          VARCHAR2(255);
  

  -- PSD #7a-end
  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.6 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2014/05/01 22:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #7
  g_rep_info('File Name') := 'inv_trans_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
-- PSD #7b
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1499475.1" target="_blank">(Note 1499475.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  
  -- PSD #7a
  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');

  IF p_org_id is null THEN
    print_log('No organization ID specified. '||
      'The org_id parameter is mandatory.');
    raise invalid_parameters;
  END IF;
  
  l_from_date := to_char(nvl(p_from_date,sysdate-90),'DD-MON-YYYY');

  l_end_date := to_char(nvl(p_end_date,sysdate-90),'DD-MON-YYYY');

  l_key := g_sql_tokens.first;
  -- Print token values to the log
 
  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  
  -- PSD #8
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Organization ID') := p_org_id;
  g_parameters('2. Login Name') := p_user_name;
  g_parameters('3. Responsibility ID') := p_responsibility_id;  
  g_parameters('4. From Date') := l_from_date;
  g_parameters('5. End Date') := l_end_date;
  g_parameters('6. Max Rows') := g_max_output_rows;
  g_parameters('7. Debug Mode') := p_debug_mode;
  
  -- PSD #8a
  -- Create global hash of SQL token values
  g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');
  g_sql_tokens('##$$ORGID$$##') := to_char(p_org_id);
  g_sql_tokens('##$$FDATE$$##') := l_from_date;
  
  -- Transactions Anlyzer specific --
  g_sql_tokens('##$$USERNAME$$##') := to_char(p_user_name);
  g_sql_tokens('##$$RESPID$$##') := to_char(p_responsibility_id);
  
  -- PSD #7a-end

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN
-- PSD #9
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------
  
  -------------------------------------------------------------------
  -- Invalid Objects
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''INV%'' OR
         a.object_name like ''MTL_%'' OR 
         a.object_name like ''WMS_%'' OR
         a.object_name like ''EGO_%'' OR
         a.object_name like ''CST_%'')
    AND a.status = ''INVALID''',
   'Invalid Inventory related Objects',
   'RS',
   'Invalid Inventory related objects exist',
   '<ul><li>Recompile the individual objects manually or recompile the entire APPS schema with adadmin utility</li>
      <li>Review any error messages provided</li></ul>',
   'No invalid objects indicated. All objects beginning with INV, MTL_, WMS_, EGO_, and CST_, were validated',
   'ALWAYS',
   'W',
   'Y',
   'N',
   p_include_in_dx_summary => 'Y');

  -------------------------------------------------------------------
  -- Inventory Code Levels 12.0+
  -------------------------------------------------------------------
  
  add_signature(
   'INV_CODE_LEVEL_12_0',
   'SELECT distinct(bug_number), decode((bug_number),
      ''4440000'',''Release 12.0.0 - provides R12 baseline code for PRC_PF'',
      ''5082400'',''Release 12.0.1'',
      ''5484000'',''Release 12.0.2 - provides R12.PRC_PF.A.delta.2'',
      ''6141000'',''Release 12.0.3 - provides R12.PRC_PF.A.delta.3'',
      ''6435000'',''Release 12.0.4 - provides R12.PRC_PF.A.delta.4'',
      ''6728000'',''Release 12.0.6 - provides R12.PRC_PF.A.delta.6'',
      ''8478486'',''R12 INV/RCV RUP7'',
      ''Other'') "Description"
    FROM ad_bugs
    WHERE bug_number IN
      (''4440000'',''5082400'',''5484000'',''6141000'',''6435000'',''6728000'',''8478486'')
    ORDER BY 2',
    'Patches Applied',
    'NRS',
    'No patches applied',
    null,
    null,
    'ALWAYS',
    'I',
    'Y',
    'N',
    p_include_in_dx_summary => 'Y');
  
  -------------------------------------------------------------------
  -- Inventory Code Levels 12.1+
  -------------------------------------------------------------------
  
 add_signature(
 'INV_CODE_LEVEL_12_1',
 'SELECT distinct(bug_number), decode((bug_number),
 ''7303030'',''Release 12.1.1 - provides R12.1 baseline code for PRC_PF'',
 ''7303033'',''Release 12.1.2 - provides R12.PRC_PF.B.delta.2'',
 ''9239090'',''Release 12.1.3 - provides R12.PRC_PF.B.delta.3'',
 ''8522002'',''R12.PRC_PF.B.delta.2'',
 ''9249354'',''R12.PRC_PF.B.delta.3'',
 ''12916273'',''R12.1+ INV Dual UOM related fixes 3'',
 ''13885374'',''R12.1+ INV Dual UOM related fixes 4'',
 ''14586882'',''R12.1+ INV RUP 5'', 
 ''16328540'',''R12.1+ INV RUP 6'', 
 ''16826285'',''R12.1+ INV RUP 7 (Requires RUP6)'',
 ''17512558'',''R12.1+ INV RUP 7 Consolidated'',
 ''18076740'',''R12.1+ INV RUP 8'',
 ''18615837'',''R12.1+ INV RUP 9'',
 ''19447776'',''R12.1+ INV RUP 10'',
 ''20187255'',''R12.1+ INV RUP 11'',
 ''21218468'',''R12.1+ INV RUP 12'',
 ''22086747'',''R12.1+ INV RUP 13'',
 ''Other'') "Description"
 FROM ad_bugs
 WHERE bug_number IN
 (''7303030'',''7303033'',''9239090'',''8522002'',''9249354'',''12916273'',''13885374'',''14586882'',''16328540'',''16826285'',''17512558'',''18076740'',''18615837'',''19447776'',''20187255'',''21218468'',''22086747'')
 ORDER BY 2',
 'Patches Applied',
 'NRS',
 'No patches applied',
 null,
 null,
 'ALWAYS',
 'I',
 'Y',
 'N',
 p_include_in_dx_summary => 'Y');
  
  -------------------------------------------------------------------
  -- Inventory Code Levels 12.2+
  -------------------------------------------------------------------
  
  add_signature(
   'INV_CODE_LEVEL_12_2',
   'SELECT distinct(bug_number), decode((bug_number),
      ''16910001'',''Release 12.2.2 - provides R12.2 baseline code for PRC_PF'',
      ''17036666'',''Release 12.2.3 - provides R12.PRC_PF.B.delta.3'',
      ''17947999'',''Release 12.2.3 - provides R12.PRC_PF.B.delta.4'',
      ''17919161'',''12.2.4 -ORACLE E-BUSINESS SUITE 12.2.4 RELEASE UPDATE PACK'',
      ''Other'') "Description"
    FROM ad_bugs
    WHERE bug_number IN
      (''16910001'',''17036666'',''17947999'',''17919161'')
    ORDER BY 2',
    'Patches Applied',
    'NRS',
    'No patches applied',
    null,
    null,
    'ALWAYS',
    'I',
    'Y',
    'N',
    p_include_in_dx_summary => 'Y'); 
 
  -------------------------------------------------------------------
  -- WMS Enabled Organizations
  -------------------------------------------------------------------
  
    add_signature(
   'WMS_Enabled_Orgs',  -- Unique Signature identifier
   'Select organization_id, 
    organization_code
    from mtl_parameters 
    where wms_enabled_flag = ''Y''', -- The signature sql query
   'Organizations that are WMS Enabled',  -- Signature title
   'RS',  -- Fail condition
   'All returned organizations are WMS enabled.',  -- Problem description 
   '<ul><li>See [2059642.1] - How To Determine if an Inventory Organization is WMS Enabled</li></ul>', -- Problem solution
   'All the below listed organizations, are all of the organizations that are WMS enabled.',  -- Message on success
   'ALWAYS',  
   'I',
   'Y',
   'N',
    p_include_in_dx_summary => 'Y'); 
  
  -------------------------------------------------------------------
  -- Project Manufacturing (PJM) Enabled Organizations
  -------------------------------------------------------------------
  
    add_signature(
   'PJM_Enabled_Orgs',  -- Unique Signature identifier
   'SELECT organization_id, 
    organization_code
    FROM mtl_parameters
    WHERE project_reference_enabled = ''1''', -- The signature sql query
   'Organizations that are Project Manufacturing (PJM) enabled.',  -- Signature title
   'RS',  -- Fail condition
   'All returned organizations are Project Manufacturing (PJM) enabled',  -- Problem description 
   '<ul>
      <li>See [1447832.1] - How to Check if an Inventory Organization is Project Reference Enabled or Not?</li>
   </ul>',  -- Problem solution
   'All the below listed organizations, are all of the organizations that are Project Manufacturing (PJM) enabled.',  -- Message on success
   'ALWAYS',  
   'I',
   'Y',
   'N',
   p_include_in_dx_summary => 'Y');
   
  -------------------------------------------------------------------
  -- Oracle Process Manaufacturing (OPM) Enabled Organizations
  -------------------------------------------------------------------
 
 add_signature(
 'OPM_Enabled_Orgs',  -- Unique Signature identifier
 'select organization_id,
  organization_code  
  from mtl_parameters  
  where PROCESS_ENABLED_FLAG = ''Y''', -- Signature Sql  
 'OPM Enabled Organizations', -- Signature title
 'RS',  -- Fail condition
 'All returned organizations are OPM Enabled',  -- Problem description 
 '<ul><li>See [2061642.1] - How to Check if an Inventory Organization is OPM Enabled</li></ul>',  -- Problem solution
 'All the below listed organizations, are all of the organizations that are OPM enabled.',  -- Message on success
 'ALWAYS', -- Print condition 
 'I', -- Fail type
 'Y', -- Print sql output
 'N', -- Print limit rows
 p_include_in_dx_summary => 'Y');
 
 -------------------------------------------------------------------
  -- Negative Balances Not Allowed Organizations
 -------------------------------------------------------------------
 
   add_signature(
   'Neg_Bal_Orgs',  -- Unique Signature identifier
   'select organization_id, 
    organization_code
    from mtl_parameters
    where NEGATIVE_INV_RECEIPT_CODE = ''1''', -- The signature sql query
   'Organizations that allow Negative Balances',  -- Signature title
   'RS',  -- Fail condition
   'All returned organizations allow Negative Balances',  -- Problem description 
   '<ul>
      <li>See [2061158.1] - How to Check if an Inventory Organization Allows Negative Balances</li>
   </ul>',  -- Problem solution
   'All the below listed organizations, are all of the organizations that allow Negative Balances',  -- Message on success
   'ALWAYS',  
   'I',
   'Y',
   'N',
   p_include_in_dx_summary => 'Y');
   
  -------------------------------------------------------------------
  -- Status of the Inventory Transaction Managers
  -------------------------------------------------------------------
  
    add_signature(
   'Inv_Trans_Managers',  -- Unique Signature identifier
   'Select process_name,
    process_app_short_name,
    process_interval,
    worker_rows,
    process_status, decode(process_status, 1, ''Active'', 2, ''Inactive'') meaning
    From mtl_interface_proc_controls',   -- The signature sql query
   'Process Transaction Interface (Transaction Managers)',  -- Signature title
   'RS',  -- Fail condition
   'Status of Inventory related Transaction Managers, Active or Inactive.',  -- Problem description 
   '<ul>
      <li>See the Solution in [1631453.1] - INCTCM / INCTCW : How to Schedule Inventory Transaction    Manager (Process Transaction Interface) When Inactive</li>
   </ul>',  -- Problem solution
   'Status of Inventory related Transaction Managers, Active or Inactive.',  -- Message on success
   'ALWAYS',  
   'I',
   'Y',
   'N',
   p_include_in_dx_summary => 'Y');
  
  ------------------------------------------------------------------------------------------
  -- Setting of the Profile Option INV:Batch Size - Keeping As Example of Single Profile Sig
  ------------------------------------------------------------------------------------------
  
   /*
     add_signature(
   'Inv_Batch_Size',  -- Unique Signature identifier
   'select fpo.profile_option_name, fpovl.USER_PROFILE_OPTION_NAME,
    NVL((select to_char(fpov.PROFILE_OPTION_VALUE) from FND_PROFILE_OPTION_VALUES fpov
    where fpo.profile_option_id = fpov.profile_option_id), ''Not Set'') PROFILE_OPTION_VALUE
    from fnd_profile_options fpo, fnd_profile_options_vl fpovl
    where fpo.profile_option_id = fpovl.profile_option_id
    and fpo.profile_option_name like ''INV_BATCH_SIZE''', -- The signature sql query
   'Setting of the Profile Option INV:Batch Size',  -- Signature title
   'RS',  -- Fail condition
   'Setting of the Profile Option INV:Batch Size',  -- Problem description 
   '<ul>
      <li>See Doc ID 1075935.1 - Performance of Interface Trip Stop is Slow for Internal sales orders</li>
   </ul>',  -- Problem solution
   'Results of the Profile Option INV:Batch Size.',  -- Message on success
   'ALWAYS',  
   'E',
   'Y',
   p_include_in_dx_summary => 'Y');
   */
   
-------------------------------------------------------------------
-- Key Inventory Transactions Related Profile Options
-------------------------------------------------------------------
  
  add_signature(
   'Inv_Trans_Specific_Profiles',
   'SELECT user_profile_option_name "Profile Option",
           a.profile_option_value "Profile Value",
           DECODE(a.level_id, 10001, ''Site'',
                              10002, ''Application'',
                              10003, ''Responsibility'',
                              10004, ''User'') "Level",
           DECODE(a.level_id, 10001, ''Site'', 10002, b.application_short_name, 10003, c.responsibility_name, 10004, 
           d.user_name) "Level Value",
           c.responsibility_id
    FROM fnd_profile_option_values a,
         fnd_application b,
         fnd_responsibility_tl c,
         fnd_user d,
         fnd_profile_options e,
         fnd_profile_options_tl t
    WHERE a.profile_option_id  = e.profile_option_id
      AND a.level_value          = b.application_id(+)
      AND a.level_value          = c.responsibility_id(+)
      AND a.level_value          = d.user_id(+)
      AND t.profile_option_name  = e.profile_option_name
      AND t.LANGUAGE             = ''US''
      AND nvl(c.LANGUAGE,''US'') = ''US''
      AND e.profile_option_name IN (''AFLOG_ENABLED'',
                                    ''INV_DEBUG_TRACE'',
                                    ''INV_DEBUG_FILE'',
				    ''INV_DEBUG_LEVEL'',
				    ''INV_BATCH_SIZE'',
				    ''INV_MATERIAL_STATUS'')
	  AND ((a.level_id = 10003 AND a.level_value = ##$$RESPID$$##) 
      OR   (a.level_id = 10004 AND d.user_name = ''##$$USERNAME$$##'')
      OR   (a.level_id = 10001 ))						      
      ORDER BY e.profile_option_name,
            a.level_id DESC',
   'Inventory Transactions Key Profile Options.',
   'RS',
   'The results show key Inventory transactions related profile options.',
   '<ul>
   <li>Follow the information provided in [2053996.1] for descriptions of Inventory profile options and the default settings.</li>
   </ul>',
    null,
  'ALWAYS',
   'I',
   'RS',
   p_include_in_dx_summary => 'Y');
  
-------------------------------------------------------------------
-- MTL_TRANSACTIONS_INTERFACE MTI Error Summary
-------------------------------------------------------------------
  
 add_signature(
 'MTI_Trans_Errors',  -- Unique Signature identifier
 'SELECT TRANSACTION_TYPE_ID, 
 TRANSACTION_ACTION_ID,
 LOCK_FLAG,
 PROCESS_FLAG,
 TRANSACTION_MODE, 
 ERROR_CODE, 
 ERROR_EXPLANATION, COUNT(*)
 FROM MTL_TRANSACTIONS_INTERFACE
 GROUP BY
 TRANSACTION_TYPE_ID,
 TRANSACTION_ACTION_ID,
 LOCK_FLAG,
 PROCESS_FLAG,
 TRANSACTION_MODE,
 ERROR_CODE,  
 ERROR_EXPLANATION',   -- The signature sql query
 'Transactions Interface (MTL_TRANSACTIONS_INTERFACE MTI)',  -- Signature title
 'RS',  -- Fail condition
 'There are unprocessed transactions in the Transactions Interface (MTL_TRANSACTIONS_INTERFACE MTI). These may be valid transactions that simply need to be processed by the transactions manager. Problem transactions typically have ERROR_CODEs and ERROR_EXPLANATIONs',  -- Problem description 
 '<ul><li>See the Solutions in [1063689.1] - Transactions Interface MTL_TRANSACTIONS_INTERFACE MTI Error Messages, Meanings, and Solutions</li></ul>',  -- Problem solution
 'There are no unprocessed transactions in the Transactions Interface (MTL_TRANSACTIONS_INTERFACE MTI).',  -- Message on success
 'ALWAYS',  
 'W',
 'RS',
 'N',
 p_include_in_dx_summary => 'Y');
  
-------------------------------------------------------------------
-- MTL_MATERIAL_TRANSACTIONS_TEMP MMTT Error Summary
-------------------------------------------------------------------
  
 add_signature(
 'MMTT_Trans_Errors',  -- Unique Signature identifier
 'SELECT TRANSACTION_TYPE_ID, 
 TRANSACTION_ACTION_ID,
 LOCK_FLAG,
 PROCESS_FLAG,
 TRANSACTION_MODE,
 TRANSACTION_STATUS, 
 ERROR_CODE, 
 ERROR_EXPLANATION, COUNT(*)
 FROM MTL_MATERIAL_TRANSACTIONS_TEMP
 GROUP BY
 TRANSACTION_TYPE_ID,
 TRANSACTION_ACTION_ID,
 LOCK_FLAG,
 PROCESS_FLAG,
 TRANSACTION_MODE,
 TRANSACTION_STATUS,
 ERROR_CODE,  
 ERROR_EXPLANATION',   -- The signature sql query
 'Pending Transactions (MTL_MATERIAL_TRANSACTIONS_TEMP MMTT)',  -- Signature title
 'RS',  -- Fail condition
 'There are unprocessed transactions in Pending Transactions (MTL_MATERIAL_TRANSACTIONS_TEMP MMTT). These may be valid transactions that simply need to be processed by the transactions manager. Problem transactions typically have ERROR_CODEs and ERROR_EXPLANATIONs',  -- Problem description 
 '<ul><li>See the Solutions in [1070343.1] - Pending Transactions MTL_MATERIAL_TRANSACTIONS_TEMP MMTT Error Messages, Meanings and Solutions</li></ul>',  -- Problem solution
 'There are no unprocessed transactions in Pending Transactions (MTL_MATERIAL_TRANSACTIONS_TEMP MMTT).',  -- Message on success
 'ALWAYS',  
 'W',
 'RS',
 'N',
 p_include_in_dx_summary => 'Y');
   
-------------------------------------------------------------------
-- MTL_MATERIAL_TRANSACTIONS MMT Error Summary
-------------------------------------------------------------------
  
 add_signature(
 'MMT_Trans_Errors',  -- Unique Signature identifier
 'SELECT TRANSACTION_TYPE_ID, 
 TRANSACTION_ACTION_ID,
 COSTED_FLAG, 
 ERROR_CODE, 
 ERROR_EXPLANATION, COUNT(*)
 FROM MTL_MATERIAL_TRANSACTIONS
 WHERE COSTED_FLAG IS NOT NULL
 GROUP BY 
 TRANSACTION_TYPE_ID,
 TRANSACTION_ACTION_ID,
 COSTED_FLAG,
 ERROR_CODE,
 ERROR_EXPLANATION',   -- The signature sql query
 'Material Transactions (MTL_MATERIAL_TRANSACTIONS MMT)',  -- Signature title
 'RS',  -- Fail condition
 'There are transactions that need review in Material Transactions (MTL_MATERIAL_TRANSACTIONS MMT). Problem transactions typically have ERROR_CODEs and ERROR_EXPLANATIONs',  -- Problem description 
 '<ul><li>See the Solutions in [865438.1] How to resolve Costing Errors & Problems</li></ul>',  -- Problem solution
 'There are no transactions that need review in Material Transactions (MTL_MATERIAL_TRANSACTIONS MMT).',  -- Message on success
 'ALWAYS',  
 'W',
 'RS',
 'N',
 p_include_in_dx_summary => 'Y');

-------------------------------------------------------------------
-- MOQD Onhand Mismatch SDF #1 - This sig could have performance issues
-------------------------------------------------------------------
  
add_signature(
 'MOQD_Mismatch',
 'SELECT TXN.organization_id org_id, TXN.inventory_item_id item_id, 
  TXN.subinventory_code sub, TXN.mmt_qty mmt_qty, 
  ONHAND.qty onhand_qty, (TXN.mmt_qty - NVL(ONHAND.qty,0)) qty_diff 
 FROM 
  (SELECT mmt.organization_id, mmt.inventory_item_id, 
  mmt.subinventory_code, sum(mmt.primary_quantity) mmt_qty 
 FROM mtl_material_transactions mmt, 
  mtl_secondary_inventories mse 
 WHERE mse.organization_id=mmt.organization_id 
 AND mse.secondary_inventory_name=mmt.subinventory_code 
 AND mse.quantity_tracked=1 
 AND mmt.transaction_action_id not in (5,6,24,30,50,51,52,55,26,7,11,17,10,9,13,14,15,22)
 AND Nvl(mmt.logical_transaction, -1) <> 1
 AND mmt.lpn_id is null AND mmt.transfer_lpn_id is null 
 AND mmt.content_lpn_id is null 
 GROUP BY mmt.organization_id, mmt.inventory_item_id, 
  mmt.subinventory_code) TXN, 
  (SELECT moq.organization_id, moq.inventory_item_id, 
  moq.subinventory_code, sum(moq.primary_transaction_quantity) qty 
 FROM  mtl_onhand_quantities_detail moq, 
 mtl_secondary_inventories mse 
 WHERE moq.organization_id=mse.organization_id 
 AND mse.secondary_inventory_name=moq.subinventory_code 
 AND mse.quantity_tracked=1 
 AND nvl(moq.containerized_flag,2) = 2 
 GROUP BY moq.organization_id, moq.inventory_item_id, 
 moq.subinventory_code) ONHAND 
 WHERE TXN.inventory_item_id = ONHAND.inventory_item_id (+) 
 AND TXN.organization_id   = ONHAND.organization_id (+) 
 AND TXN.subinventory_code = ONHAND.subinventory_code (+) 
 AND abs(TXN.mmt_qty - NVL(ONHAND.qty,0)) > 0 
 AND exists (select 1 from mtl_parameters 
  where organization_id = TXN.organization_id 
  and wms_enabled_flag = ''N'')',
 'MOQD Mismatch',
 'RS',
 'A mismatch exists between onhand quantity and the material transactions table. Note: if your organization(s) are WMS 
 enabled or you have ever run the transactions purge process, you can ignore these results',
 '<ul>
 <li>See the Solution in [279205.1] - Current Onhand Quantity and Total Transactions History Quantity 
  Mismatch Diagnosis.</li>
 </ul>',
 'A mismatch does not exist between the onhand quantity and the transactions table.',
 'ALWAYS',
 'W',
 'RS',
 'Y',
 p_include_in_dx_summary => 'Y');
   
-------------------------------------------------------------------
-- Closed Move Orders SDF #2
-------------------------------------------------------------------
   
add_signature(
 'Closed_Move_Order_Lines',
 'select  mtrh.request_number "Move Order Number", mtrl.quantity Quantity
 from mtl_txn_request_lines MTRL,
  mtl_txn_request_headers MTRH,
  wsh_Delivery_Details wdd,
  oe_order_lines_All oel
  where wdd.released_Status = ''S''
    and     wdd.move_order_line_id = mtrl.line_id 
    and     wdd.move_order_line_id is not null
    and     wdd.source_line_id  = mtrl.txn_source_line_id 
    and     mtrh.header_id = mtrl.header_id
    and     oel.line_id = wdd.source_line_id 
    and     wdd.source_code = ''OE''
    and     mtrl.line_Status = 5 
    and     not exists (
          select ''x'' from mtl_material_transactions  mmt
          where  mmt.move_order_line_id = mtrl.line_id and 
                 mmt.move_order_line_id is not null)',
   'Closed Move Order Lines',
   'RS',
   'There are Closed Move Order lines where the corresponding Sales Orders are Released to Warehouse.',
   '<ul>
      <li>See the Solution in [1471929.1] - Inventory Standard Datafix Instruction #2: Fixing Closed Move Orders </li>
   </ul>',
   'There are no Closed Move Order lines where the corresponding Sales Orders are Released to Warehouse.',
   'ALWAYS',
   'E',
   'RS',
   'N',
   p_include_in_dx_summary => 'Y');  

-------------------------------------------------------------------
-- Missing Move Order SDF #3
-------------------------------------------------------------------

--Need signature to check on patch level. There is no diagnosis sql for this issue.

-------------------------------------------------------------------
-- Serial Numbers Locked By Invalid Mark ID's SDF #4 
-------------------------------------------------------------------

 add_signature(
 'Serial_Invalid_Mark_IDs',
 'SELECT msn.serial_number,
  msn.inventory_item_id,
  msn.current_organization_id,
  msn.current_subinventory_code,
  msn.group_mark_id,
  msn.line_mark_id,
  msn.lot_line_mark_id
 FROM mtl_serial_numbers msn
 WHERE(msn.group_mark_id IS NOT NULL
   AND msn.group_mark_id <> -1)
 AND NOT EXISTS
  (SELECT 1
  FROM mtl_serial_numbers_temp msnt
  WHERE msn.group_mark_id = msnt.transaction_temp_id OR msn.group_mark_id = msnt.group_header_id)
 AND NOT EXISTS
  (SELECT 1
  FROM wsh_delivery_details wdd
  WHERE wdd.inv_interfaced_flag <> ''Y''
  AND wdd.released_status IN(''Y'',    ''C'')
  AND wdd.transaction_temp_id IS NOT NULL
  AND msn.group_mark_id = wdd.transaction_temp_id)
 AND NOT EXISTS
  (SELECT 1
  FROM wsh_delivery_details wdd
  WHERE wdd.inv_interfaced_flag <> ''Y''
  AND wdd.released_status IN(''Y'',    ''C'')
  AND msn.inventory_item_id = wdd.inventory_item_id
  AND msn.serial_number = wdd.serial_number)
 AND NOT EXISTS
  (SELECT 1
  FROM mtl_cycle_count_entries mcce
  WHERE mcce.cycle_count_header_id = msn.group_mark_id
  AND mcce.cycle_count_entry_id = msn.line_mark_id
  AND mcce.entry_status_code IN(1,2))',
 'Locked Serial Numbers',
 'RS',
 'There are serial numbers that are locked so other processes cannot use them.',
 '<ul>
  <li>See the Solution in [1472005.1] - Inventory Standard Datafix Instruction #4: Fixing Marked Serial 
  Numbers (MSN), Orphan Pending Serials (MSNT), and Orphan Status 6 Serials</li>
  </ul>',
 'There are no serial numbers locked so other processes cannot use them.',
 'ALWAYS',
 'E',
 'RS',
 'N',
 p_include_in_dx_summary => 'Y');

----------------------------------------------------------------------------
-- Serial Numbers Locked By Orphaned Serial Number Temp Records SDF #4 Con't 
----------------------------------------------------------------------------

add_signature(
 'Orphan_Serial_Number_Temp_Records',
 'SELECT msnt.fm_serial_number, msnt.to_serial_number, msnt.TRANSACTION_TEMP_ID
 FROM mtl_serial_numbers_temp msnt
 WHERE   NOT EXISTS (SELECT 1 FROM mtl_material_transactions_temp mmtt
  WHERE  mmtt.transaction_temp_id = msnt.transaction_temp_id)
 AND NOT EXISTS (SELECT 1 FROM MTL_TRANSACTION_LOTS_TEMP mtlt
  WHERE  mtlt.SERIAL_TRANSACTION_TEMP_ID = msnt.transaction_temp_id)
 AND NOT EXISTS (SELECT 1 FROM wsh_delivery_details wdd
  WHERE  wdd.transaction_temp_id IS NOT NULL
  AND wdd.transaction_temp_id = msnt.transaction_temp_id
  AND wdd.released_status in (''Y'',''C'')
  AND wdd.inv_interfaced_flag <> ''Y'')
  AND NOT EXISTS (SELECT 1 FROM rcv_transactions_interface rti
  WHERE interface_transaction_id = msnt.transaction_temp_id)',
 'Serials Locked By Orphan Serial Temp Records',
 'RS',
 'There are orphaned pending serial number records.',
 '<ul>
 <li>See the Solution in [1472005.1] - Inventory Standard Datafix Instruction #4: Fixing Marked Serial 
 Numbers (MSN), Orphan Pending Serials (MSNT), and Orphan Status 6 Serials (MSN) [Video]</li>
 </ul>',
 'Orphaned pending serial number records do not exist.',
 'ALWAYS',
 'E',
 'RS',
 'N',
 p_include_in_dx_summary => 'Y');

-------------------------------------------------------------------
-- Serial Number With Leading/Trailing Spaces SDF #5 Parent
-------------------------------------------------------------------

add_signature(
'All_Serial_Numbers_Trailing_Spaces',
'SELECT ''Expand subsections below to see the trailing space data corruption'' "Trailing Space Data Corruption"
FROM dual',
'Serial number Leading/Trailing Space Data Corruption',
'[count]<[0]',
'Review data for serial numbers with leading/trailing spaces',
'<ul><li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces.</li></ul>',
'If there is an error in one of the child checks, please review. Otherwise, no data returned.',
'ALWAYS',
'I',
'RS',
'N',
l_info,
VARCHAR_TBL('Serial_Number_Leading_Trailing_MSN_1','Serial_Number_Leading_Trailing_MSN_2',  
'Serial_Number_Leading_Trailing_MUT_1', 'Serial_Number_Leading_Trailing_MUT_2', 'Serial_Number_Leading_Trailing_MSNI', 
'Serial_Number_Leading_Trailing_MSNT', 'Serial_Number_Leading_Trailing_WSH', 'Serial_Number_Leading_Trailing_RSS', 
'Serial_Number_Leading_Trailing_RSI', 'Serial_Number_Leading_Trailing_RST', 'Serial_Number_Leading_Trailing_MCCE', 
'Serial_Number_Leading_Trailing_MPIT', 'Serial_Number_Leading_Trailing_MPA', 'Serial_Number_Leading_Trailing_MD', 
'Serial_Number_Leading_Trailing_MR', 'Serial_Number_Leading_Trailing_MTRL'), 
p_include_in_dx_summary => 'Y'); 

-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 1 MSN 1
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MSN_1',
 'select * 
 from mtl_serial_numbers 
 where length(serial_number) != length(trim(serial_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_SERIAL_NUMBERS',
 'RS',
 'Some columns in table MTL_SERIAL_NUMBERS MSN have leading or trailing spaces',
 '<ul><li>Review - Note [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li></ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
 p_include_in_dx_summary => 'Y');
 

-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 2 MSN 2
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MSN_2',
 'select * from mtl_serial_numbers
  where serial_number In 
       (select trim(serial_number)
         from mtl_serial_numbers 
         where length(serial_number) != length(trim(serial_number)))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_SERIAL_NUMBERS',
 'RS',
 'Some columns in table MTL_SERIAL_NUMBERS MSN have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
  
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 3 MUT 1
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MUT_1',
 'select * 
 from mtl_unit_transactions 
 where length(serial_number) != length(trim(serial_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_UNIT_TRANSACTIONS',
 'RS',
 'Some columns in table MTL_UNIT_TRANSACTIONS MUT have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
 -------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 4 MUT 2
--------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MUT_2',
 'select * from mtl_unit_transactions
  where serial_number In 
       (select trim(serial_number)
        from mtl_unit_transactions
        where length(serial_number) != length(trim(serial_number))
       )',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_UNIT_TRANSACTIONS',
 'RS',
 'Some columns in table MTL_UNIT_TRANSACTIONS MUT have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 5 MSNI
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MSNI',
 'select * from 
  mtl_serial_numbers_interface 
  where length(FM_serial_number) != length(trim(FM_serial_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_SERIAL_NUMBERS',
 'RS',
 'Some columns in table MTL_SERIAL_NUMBERS_INTERFACE MSNI have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 6 MSNT
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MSNT',
 'select * from 
  mtl_serial_numbers_temp 
  where length(FM_serial_number) != length(trim(FM_serial_number))',
 'Serial Number(s) With Leading/Trailing Spaces in Table MTL_SERIAL_NUMBERS_TEMP',
 'RS',
 'Some columns in table MTL_SERIAL_NUMBERS_TEMP MSNT have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 7 WSH
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_WSH',
 'select * from wsh_serial_numbers 
  where length(fm_serial_number) != length(trim(fm_serial_number))',
 'Serial Number(s) With Leading/Trailing Spaces in Table WSH_SERIAL_NUMBERS',
 'RS',
 'Some columns in table WSH_SERIAL_NUMBERS WSN have serial numbers with leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 8 RSS
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_RSS',
 'select * from rcv_serials_supply 
  where length(serial_num) != length(trim(serial_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_SERIALS_SUPPLY',
 'RS',
 'Some columns in table RCV_SERIALS_SUPPLY RSS have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 9 RSI
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_RSI',
 'select * from rcv_serials_interface
  where length(fm_serial_num) != length(trim(fm_serial_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_SERIALS_INTERFACE',
 'RS',
 'Some columns in table RCV_SERIALS_INTERFACE RSI have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 10 RST
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_RST',
 'select * from rcv_serial_transactions
  where length(serial_num) <>length(trim(serial_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_SERIAL_TRANSACTIONS',
 'RS',
 'Some columns in table RCV_SERIAL_TRANSACTIONS RST have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 11 MCCE
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MCCE',
 'select * from mtl_cycle_count_entries 
  where length(serial_number) != length(trim(serial_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_CYCLE_COUNT_ENTRIES',
 'RS',
 'Some columns in table MTL_CYCLE_COUNT_ENTRIES MCCE have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 12 MPIT
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MPIT',
 'select * from  mtl_physical_inventory_tags
  where length(serial_num) != length(trim(serial_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_PHYSICAL_INVENTORY_TAGS',
 'RS',
 'Some columns in table MTL_PHYSICAL_INVENTORY_TAGS MSN have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 13 MPA
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MPA',
 'select * from mtl_physical_adjustments
  where length(serial_number) != length(trim(serial_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_PHYSICAL_ADJUSTMENTS',
 'RS',
 'Some columns in table MTL_PHYSICAL_ADJUSTMENTS MPA have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 14 MD
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MD',
 'select * from mtl_demand
  where length(serial_number) != length(trim(serial_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_DEMAND',
 'RS',
 'Some columns in table MTL_DEMAND MD have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 15 MR
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MR',
 'select * from mtl_reservations
  where length(serial_number) != length(trim(serial_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_RESERVATIONS',
 'RS',
 'Some columns in table MTL_RESERVATIONS RS have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
 
 
-------------------------------------------------------------------
-- Serial Numbers With Leading/Trailing Spaces SDF #5 Child 16 MTRL
-------------------------------------------------------------------

 add_signature(
 'Serial_Number_Leading_Trailing_MTRL',
 'select * from mtl_txn_request_lines
  where length(serial_number_start) != length(trim(serial_number_start))
   or
  length(serial_number_end) != length(trim(serial_number_end))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_TXN_REQUEST_LINES',
 'RS',
 'Some columns in table MTL_TXN_REQUEST_LINES MTRL have leading or trailing spaces',
 '<ul>
 <li>Review [1376548.1] - Inventory Standard Datafix Instruction #5: Fixing Serial Numbers With Leading Or Trailing Spaces .</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'Y',
 'N', 
  p_include_in_dx_summary => 'Y');
  
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Parent
-------------------------------------------------------------------

l_info.delete; 
add_signature(
'All_Lot_Numbers_Trailing_Spaces',
'SELECT ''Expand subsections below to see lot numbers leading/trailing space data corruption'' "Trailing Space Data Corruption"
FROM dual',
'Lot number Leading/Trailing Space Data Corruption',
'[count]<[0]',
'Review data for lot numbers with leading/trailing spaces',
'<ul><li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces .</li></ul>',
'If there is an error in one of the child checks, please review. Otherwise, no data returned.',
'ALWAYS',
'I',
'RS',
'N',
l_info,
VARCHAR_TBL('Lot_Number_Leading_Trailing_MLN', 'Lot_Number_Leading_Trailing_MTLN', 'Lot_Number_Leading_Trailing_MOQD', 
'Lot_Number_Leading_Trailing_MTLT', 'Lot_Number_Leading_Trailing_MTLI', 'Lot_Number_Leading_Trailing_MPIT', 
'Lot_Number_Leading_Trailing_MPA', 'Lot_Number_Leading_Trailing_MCCE', 'Lot_Number_Leading_Trailing_MD', 
'Lot_Number_Leading_Trailing_MR', 'Lot_Number_Leading_Trailing_MTRL', 'Lot_Number_Leading_Trailing_MSN', 
'Lot_Number_Leading_Trailing_RLT', 'Lot_Number_Leading_Trailing_RLI', 'Lot_Number_Leading_Trailing_RLS', 
'Lot_Number_Leading_Trailing_RSS', 'Lot_Number_Leading_Trailing_RST', 'Lot_Number_Leading_Trailing_RSI', 
'Lot_Number_Leading_Trailing_WDD', 'Lot_Number_Leading_Trailing_MLN2', 'Lot_Number_Leading_Trailing_MLN3'), 
p_include_in_dx_summary => 'Y');

-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 1 MLN
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MLN',
 'select * from mtl_lot_numbers 
  where lot_number<> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_LOT_NUMBERS',
 'RS',
 'Some columns in table MTL_LOT_NUMBERS MLN have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 2 MTLN
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MTLN',
 'select * from mtl_transaction_lot_numbers 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_TRANSACTION_LOT_NUMBERS',
 'RS',
 'Some columns in table MTL_TRANSACTION_LOT_NUMBERS MTLN have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 3 MOQD
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MOQD',
 'select * from mtl_onhand_quantities_detail 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_ONHAND_QUANTITIES_DETAIL',
 'RS',
 'Some columns in table MTL_ONHAND_QUANTITIES_DETAIL MOQD have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
 -------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 4 MTLT
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MTLT',
 'select * from mtl_transaction_lots_temp 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_TRANSACTION_LOTS_TEMP',
 'RS',
 'Some columns in table MTL_TRANSACTION_LOTS_TEMP MTLT have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 5 MTLI
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MTLI',
 'select * from mtl_transaction_lots_interface 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_TRANSACTION_LOTS_INTERFACE',
 'RS',
 'Some columns in table MTL_TRANSACTION_LOTS_INTERFACE MTLI have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 6 MPIT
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MPIT',
 'select * from mtl_physical_inventory_tags 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_PHYSICAL_INVENTORY_TAGS',
 'RS',
 'Some columns in table MTL_PHYSICAL_INVENTORY_TAGS MPIT have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 7 MPA
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MPA',
 'select * from mtl_physical_adjustments 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_PHYSICAL_ADJUSTMENTS',
 'RS',
 'Some columns in table MTL_PHYSICAL_ADJUSTMENTS MPA have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 8 MCCE
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MCCE',
 'select * from mtl_cycle_count_entries 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_CYCLE_COUNT_ENTRIES',
 'RS',
 'Some columns in table MTL_CYCLE_COUNT_ENTRIES MCCE have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 9 MD
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MD',
 'select * from mtl_demand 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_DEMAND',
 'RS',
 'Some columns in table MTL_DEMAND MD have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 10 MR
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MR',
 'select * from mtl_reservations 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_RESERVATIONS',
 'RS',
 'Some columns in table MTL_RESERVATIONS MR have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 11 MTRL
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MTRL',
 'select * from mtl_txn_request_lines 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_TXN_REQUEST_LINES',
 'RS',
 'Some columns in table MTL_TXN_REQUEST_LINES MTRL have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 12 MSN
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MSN',
 'select * from mtl_serial_numbers 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_SERIAL_NUMBERS',
 'RS',
 'Some columns in table MTL_SERIAL_NUMBERS MSN have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 13 RLT
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_RLT',
 'select * from rcv_lot_transactions 
  where lot_num <> ltrim(rtrim(lot_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_LOT_TRANSACTIONS',
 'RS',
 'Some columns in table RCV_LOT_TRANSACTIONS RLT have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 14 RLI
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_RLI',
 'select * from rcv_lots_interface 
  where lot_num <> ltrim(rtrim(lot_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_LOTS_INTERFACE',
 'RS',
 'Some columns in table RCV_LOTS_INTERFACE RLI have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 15 RLS
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_RLS',
 'select * from rcv_lots_supply 
  where lot_num <> ltrim(rtrim(lot_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_LOTS_SUPPLY',
 'RS',
 'Some columns in table RCV_LOTS_SUPPLY RLS MLN have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 16 RSS
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_RSS',
 'select * from rcv_serials_supply 
  where lot_num <> ltrim(rtrim(lot_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_SERIALS_SUPPLY',
 'RS',
 'Some columns in table RCV_SERIALS_SUPPLY RSS have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 17 RST
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_RST',
 'select * from  rcv_serial_transactions 
  where lot_num <> ltrim(rtrim(lot_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_SERIAL_TRANSACTIONS',
 'RS',
 'Some columns in table RCV_SERIAL_TRANSACTIONS RST have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 18 RSI
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_RSI',
 'select * from rcv_serials_interface 
  where lot_num <> ltrim(rtrim(lot_num))',
 'Serial Number(s) Leading/Trailing Spaces in Table RCV_SERIALS_INTERFACE',
 'RS',
 'Some columns in table RCV_SERIALS_INTERFACE RSI have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 19 WDD
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_WDD',
 'select * from wsh_delivery_details 
  where lot_number <> ltrim(rtrim(lot_number))',
 'Serial Number(s) Leading/Trailing Spaces in Table WSH_DELIVERY_DETAILS',
 'RS',
 'Some columns in table WSH_DELIVERY_DETAILS WDD have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 20 MLN2
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MLN2',
 'select mln1.* 
  from mtl_lot_numbers mln1 
  where  mln1.lot_number in 
  (select ltrim(rtrim(mln2.lot_number))
 from mtl_lot_numbers mln2
 where mln2.lot_number<> ltrim(rtrim(mln2.lot_number)))',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_LOT_NUMBERS',
 'RS',
 'Some columns in table MTL_LOT_NUMBERS MLN have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Lot Numbers With Leading/Trailing Spaces SDF #6 Child 21 MLN3
-------------------------------------------------------------------

 add_signature(
 'Lot_Number_Leading_Trailing_MLN3',
 'select trim(lot_number),INVENTORY_ITEM_ID,ORGANIZATION_ID,count(*) cnt
 from mtl_lot_numbers   
 group by trim(lot_number),INVENTORY_ITEM_ID,ORGANIZATION_ID
 having count(*) >1',
 'Serial Number(s) Leading/Trailing Spaces in Table MTL_LOT _NUMBERS',
 'RS',
 'Some columns in table MTL_LOT_NUMBERS MLN have leading or trailing spaces',
 '<ul>
 <li>Review [1451566.1] - Inventory Standard Datafix Instruction #6: Fixing Lot Numbers With Leading or Trailing Spaces.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Corrupted Onhand Related To Lots SDF #7 Parent
-------------------------------------------------------------------

 l_info.delete; 
 add_signature(
 'Corrupt_Lots_Onhand',
 'SELECT ''Expand subsections below to see lot numbers with corrupt onhand'' "Onhand Lot Data Corruption"
  FROM dual',
 'Corrupted Onhand Related to Lot Numbers',
 '[count]<[0]',
 'Review data for corrupted onhand related to Lot numbers',
 '<ul><li>This is a datafix delivered by Support via a Service Request (SR). Review the SR DATAFIXES #7 in [568012.1] - FAQ: Inventory Standard Datafixes.</li></ul>',
 'If there is an error in one of the child checks, please review. Otherwise, no data returned.',
 'ALWAYS',
 'I',
 'RS',
 'Y',
 l_info,
 VARCHAR_TBL('Lot_Controlled_No_Lot_Onhand', 'No_Lot_Control_Lot_Onhand'), 
 p_include_in_dx_summary => 'Y'); 

--------------------------------------------------------------------------------
-- Corrupted Onhand Related To Lots SDF #7 Child 1 Lot Controlled No Lots Onhand
--------------------------------------------------------------------------------

 add_signature(
 'Lot_Controlled_No_Lot_Onhand',
 'select moq.inventory_item_id,
 moq.organization_id,
 moq.subinventory_code,
 moq.revision,
 moq.locator_id,
 moq.primary_transaction_quantity,
 msi.primary_uom_code,
 moq.lot_number
 from inv.mtl_onhand_quantities_detail moq,inv.mtl_system_items_b msi
 where moq.organization_id = msi.organization_id
 and moq.inventory_item_id = msi.inventory_item_id
 and msi.LOT_CONTROL_CODE = 2
 and moq.LOT_NUMBER IS NULL
 and nvl(moq.containerized_flag,2) = 2
 and project_id is null',
 'Lot Number(s) With Corrupt Onhand Quantity',
 'RS',
 'Corrupt onhand exists, the item is lot controlled but onhand does not have lot numbers',
 '<ul>
 <li>This is a datafix delivered by Support via a Service Request (SR). Review the SR DATAFIXES #7 in [568012.1] - FAQ: Inventory Standard Datafixes.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');

--------------------------------------------------------------------------------
-- Corrupted Onhand Related To Lots SDF #7 Child 2 No Lot Control Lots Onhand
--------------------------------------------------------------------------------

 add_signature(
 'No_Lot_Control_Lot_Onhand',
 'select moq.inventory_item_id,
 moq.organization_id,
 moq.subinventory_code,
 moq.revision,
 moq.locator_id,
 moq.primary_transaction_quantity,
 msi.primary_uom_code,
 moq.lot_number
 from inv.mtl_onhand_quantities_detail moq,inv.mtl_system_items_b msi
 where moq.organization_id = msi.organization_id
 and moq.inventory_item_id = msi.inventory_item_id
 and msi.LOT_CONTROL_CODE = 1
 and moq.LOT_NUMBER IS NOT NULL
 and nvl(moq.containerized_flag,2) = 2
 and project_id is null',
 'Corrupt Onhand Quantity With Lot Numbers',
 'RS',
 'Corrupt onhand exists, the item is not lot controlled but onhand quanity has lot numbers',
 '<ul>
 <li>This is a datafix delivered by Support via a Service Request (SR). Review the SR DATAFIXES #7 in [568012.1] - FAQ: Inventory Standard Datafixes.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------
-- Physical Inventory Adjustment Errors SDF #8 
-------------------------------------------------------------------

/*
-   No SDF yet for this issue - Holding spot
*/

-------------------------------------------------------------------------
-- Sales Order Reservations Created with Zero Demand Header SDF #9 Parent
-------------------------------------------------------------------------

 l_info.delete; 
 add_signature(
 'Sales_Order_Zero_Demand_Header',
 'SELECT ''Expand subsections below to see to find demand/reservations that have zero demand_source_header_id'' "SO Res demand_source_header_id"
 FROM dual',
 'Sales Order Reservations Created with Zero Demand Header',
 '[count]<[0]',
 'Review data for sales order reservations created with zero demand header',
 '<ul><li>Review [1471942.1] - Inventory Standard Datafix Instruction #9: Fixing Sales Order Reservations created with Zero Demand Header.</li></ul>',
 null,
 'ALWAYS',
 'I',
 'RS',
 'N',
 l_info,
 VARCHAR_TBL('Reservations_Demand_Source_Header_ID', 'Demand_Demand_Source_Header_ID'), 
 p_include_in_dx_summary => 'Y'); 

--------------------------------------------------------------------------------
-- Sales Order Reservations Created with Zero Demand Header SDF #9 Child 1 
--------------------------------------------------------------------------------

 add_signature(
 'Reservations_Demand_Source_Header_ID',
 'SELECT MR.RESERVATION_ID RSV_ID,
  MR.DEMAND_SOURCE_LINE_ID ORDER_LINE_ID,
  MR.INVENTORY_ITEM_ID ITEM_ID,
       MR.ORGANIZATION_ID ORG_ID,
  MR.PRIMARY_RESERVATION_QUANTITY PRSV_QTY 
  FROM  MTL_RESERVATIONS MR
  WHERE DEMAND_SOURCE_TYPE_ID IN (2,8)
  AND NVL(DEMAND_SOURCE_HEADER_ID, 0) = 0
  AND SUPPLY_SOURCE_TYPE_ID = 13',
 'Reservation Details With no DEMAND_SOURCE_HEADER_ID',
 'RS',
 'Corrupt reservations details exist with no DEMAND_SOURCE_HEADER_ID',
 '<ul>
 <li>Review [1471942.1] - Inventory Standard Datafix Instruction #9: Fixing Sales Order Reservations created with Zero Demand Header.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');

--------------------------------------------------------------------------------
-- Sales Order Demand Created with Zero Demand Header SDF #9 Child 2
--------------------------------------------------------------------------------

 add_signature(
 'Demand_Demand_Source_Header_ID',
 'SELECT MD.DEMAND_ID DEMD_ID,
 MD.DEMAND_SOURCE_LINE ORDER_LINE_ID,
 MD.INVENTORY_ITEM_ID ITEM_ID,
       MD.ORGANIZATION_ID ORG_ID,
 MD.PRIMARY_UOM_QUANTITY PDEMD_QTY
 FROM  MTL_DEMAND MD
 WHERE DEMAND_SOURCE_TYPE IN (2,8)
 AND NVL(DEMAND_SOURCE_HEADER_ID, 0) = 0
  AND NVL(SUPPLY_SOURCE_TYPE, 13) = 13',
 'Demand Details With no DEMAND_SOURCE_HEADER_ID',
 'RS',
 'Corrupt demand exists with no DEMAND_SOURCE_HEADER_ID',
 '<ul>
 <li>Review [1471942.1] - Inventory Standard Datafix Instruction #9: Fixing Sales Order Reservations created with Zero Demand Header.</li>
 </ul>',
 NULL,
 'FAILURE',
 'E',
 'RS',
 'N', 
  p_include_in_dx_summary => 'Y');

---------------------------------------------------------------------
-- CST_INVALID_TXFR Error While Costing Material Transactions SDF #10
---------------------------------------------------------------------

/*
Leaving costing SDF's for Costing Analyzer
*/

-------------------------------------------------------------------
-- Reservations on SO's With Incorrect Demand Header ID SDF #11
-------------------------------------------------------------------

 add_signature(
 'Incorrect_Demand_Header_ID',  -- Unique Signature identifier
 'select * 
 from mtl_reservations 
 where demand_source_type_id in (2,8)
 and (demand_source_header_id = 0
 or demand_source_header_id 
 not in
 (select sales_order_id from mtl_sales_orders))',   -- The signature sql query
 'Reservations with Incorrect DEMAND_HEADER_ID for Sales Orders',  -- Signature title
 'RS',  -- Fail condition
 'Reservations exist with Incorrect DEMAND_HEADER_ID for Sales Orders.',  -- Problem description 
 '<ul><li>See the Solution in [1471944.1] - Inventory Standard Datafix Instruction #11: Fixing Incorrect Demand header id</li></ul>',  -- Problem solution
 'No Reservations for Sales Orders exist with an incorrect DEMAND_SOURCE_HEADER_ID.',  -- Message on success
 'ALWAYS',  
 'E',
 p_include_in_dx_summary => 'Y');
   
----------------------------------------------------------------------------------------------------
--  Onhand Records With Locator Populated When Subinventory Is Not Locator Controlled SDF #12 Parent
----------------------------------------------------------------------------------------------------

l_info.delete;   
add_signature( 
'Loc_Onhand_Mismatch', 
'SELECT ''Expand subsections below to see locators with the issue'' "Loc onhand mismatch" FROM dual', 
'Locator and Onhand Subinventory Do Not Match', 
'[count]<[0]', 
'Locator and Onhand Subinventory Do Not Match', 
'<ul><li>Review [282480.1] - Inventory Standard Datafix Instruction #12,13,14: Cannot Issue Locator Controlled Item.</li></ul>', 
'If there is an error in one of the child checks, please review. Otherwise, no data returned.', 
'ALWAYS', 
'I', 
'RS', 
'Y', 
l_info, 
VARCHAR_TBL('Loc_Null_Item', 'Loc_Null_Ohand', 'Loc_Org_Sub_Crntl', 'Loc_Non_Matching_Onhand'),    
p_include_in_dx_summary => 'Y');  

-----------------------------------------------------------------------------------------------------
--  Onhand Records With Locator Populated When Subinventory Is Not Locator Controlled SDF #12 Child 1 Non-matching Locators Onhand
-----------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Loc_Non_Matching_Onhand', -- Signature identifier
 'select moqd.ORGANIZATION_ID, moqd.SUBINVENTORY_CODE, moqd.INVENTORY_ITEM_ID, moqd.LOT_NUMBER,  moqd.REVISION, moqd.LOCATOR_ID, count(*)
 from MTL_ONHAND_QUANTITIES_DETAIL moqd
 where moqd.LOCATOR_ID is not null
 and not exists (select 1 from MTL_ITEM_LOCATIONS mil
 where mil.ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and  mil.SUBINVENTORY_CODE = moqd.SUBINVENTORY_CODE
 and  mil.INVENTORY_LOCATION_ID = moqd.LOCATOR_ID)
 and exists (select 1 from MTL_SECONDARY_INVENTORIES
 where SECONDARY_INVENTORY_NAME = moqd.subinventory_code
 and   ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and   LOCATOR_TYPE in (2, 3) )
 and exists (select 1 from MTL_PARAMETERS
 where ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and  STOCK_LOCATOR_CONTROL_CODE = 4
 and  NOT (WMS_ENABLED_FLAG = ''Y'' OR PROCESS_ENABLED_FLAG = ''Y''))
 and exists (select 1 from MTL_SYSTEM_ITEMS msit
 where msit.ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and   msit.INVENTORY_ITEM_ID = moqd.INVENTORY_ITEM_ID
 and   msit.SERIAL_NUMBER_CONTROL_CODE in (1, 6) )
 group by moqd.ORGANIZATION_ID, moqd.SUBINVENTORY_CODE, moqd.INVENTORY_ITEM_ID, moqd.LOT_NUMBER,  moqd.REVISION, moqd.LOCATOR_ID', -- Signature sql
 'Check for non-matching locators in the onhand quantity.', -- Signature title
 'RS', -- Fail condition
 'Check for Non-matching Locators in the Onhand Quantity.', -- Problem description
 '<ul><li>Review [282480.1] - Identification Script #1</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'RS', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');


-----------------------------------------------------------------------------------------------------
--  Onhand Records With Locator Populated When Subinventory Is Not Locator Controlled SDF #12 Child 2 Control Level
-----------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Loc_Org_Sub_Crntl', -- Signature identifier
 'select moqd.ORGANIZATION_ID, moqd.SUBINVENTORY_CODE, moqd.INVENTORY_ITEM_ID, moqd.LOCATOR_ID,  moqd.LOT_NUMBER, moqd.REVISION, count(*)
 from MTL_ONHAND_QUANTITIES_DETAIL moqd
 where LOCATOR_ID is not null
 and exists (select 1 from MTL_SECONDARY_INVENTORIES msi
 where msi.SECONDARY_INVENTORY_NAME = moqd.SUBINVENTORY_CODE
 and   msi.ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and   msi.LOCATOR_TYPE = 1)
 and exists (select 1 from MTL_PARAMETERS
 where ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and  STOCK_LOCATOR_CONTROL_CODE in (1, 4)
 and  NOT (WMS_ENABLED_FLAG = ''Y'' OR PROCESS_ENABLED_FLAG = ''Y''))
 and exists (select 1 from MTL_SYSTEM_ITEMS msit
 where msit.ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and   msit.INVENTORY_ITEM_ID = moqd.INVENTORY_ITEM_ID
 and   msit.SERIAL_NUMBER_CONTROL_CODE in (1, 6) )
 group by moqd.ORGANIZATION_ID, moqd.SUBINVENTORY_CODE, moqd.INVENTORY_ITEM_ID, moqd.LOCATOR_ID,  moqd.LOT_NUMBER, moqd.REVISION', -- Signature sql
 'Check if organization locator control is None or Determined at Subinventory level and the locator control at subinventory level is None', -- Signature title
 'RS', -- Fail condition
 'Check if organization locator control is None or Determined at Subinventory level and the locator control at subinventory level is None', -- Problem description
 '<ul><li>Review [282480.1] - Identification Script #2.</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'RS', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

-----------------------------------------------------------------------------------------------------
--  Onhand Records With Locator Populated When Subinventory Is Not Locator Controlled SDF #12 Child 3a Null Locator Onhand
-----------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Loc_Null_Ohand', -- Signature identifier
 'select moqd.ORGANIZATION_ID, moqd.SUBINVENTORY_CODE, moqd.INVENTORY_ITEM_ID, moqd.LOT_NUMBER,  moqd.REVISION, moqd.LOCATOR_ID, count(*)
  from MTL_ONHAND_QUANTITIES_DETAIL moqd
  where LOCATOR_ID is null
  and exists (select 1 from MTL_SECONDARY_INVENTORIES msi
  where msi.SECONDARY_INVENTORY_NAME = moqd.SUBINVENTORY_CODE
  and  msi.ORGANIZATION_ID = moqd.ORGANIZATION_ID
  and  msi.LOCATOR_TYPE in (2,3) )
  and exists (select 1 from MTL_PARAMETERS
  where ORGANIZATION_ID = moqd.ORGANIZATION_ID
  and  STOCK_LOCATOR_CONTROL_CODE = 4
  and  NOT (WMS_ENABLED_FLAG = ''Y'' OR PROCESS_ENABLED_FLAG = ''Y''))
  and exists (select 1 from MTL_SYSTEM_ITEMS msit
  where msit.ORGANIZATION_ID = moqd.ORGANIZATION_ID
  and  msit.INVENTORY_ITEM_ID = moqd.INVENTORY_ITEM_ID
  and  msit.SERIAL_NUMBER_CONTROL_CODE in (1, 6) )
  group by moqd.ORGANIZATION_ID, moqd.SUBINVENTORY_CODE, moqd.INVENTORY_ITEM_ID, moqd.LOT_NUMBER,  moqd.REVISION, moqd.LOCATOR_ID', -- Signature sql
 'Onhand records with Null Locator when Subinventory is Locator Controlled.', -- Signature title
 'RS', -- Fail condition
 'Onhand records with Null Locator when Subinventory is Locator Controlled.', -- Problem description
 '<ul><li>Review [282480.1] - Identification Script #3a.</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'RS', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

-----------------------------------------------------------------------------------------------------
--  Onhand Records With Locator Populated When Subinventory Is Not Locator Controlled SDF #12 Child 3b Null Locator Item Level
-----------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Loc_Null_Item', -- Signature identifier
 'SELECT
 moqd.ORGANIZATION_ID org,
 moqd.SUBINVENTORY_CODE sub,
 moqd.INVENTORY_ITEM_ID item,
 moqd.LOT_NUMBER,
 moqd.REVISION,
 moqd.LOCATOR_ID,
 sum(PRIMARY_TRANSACTION_QUANTITY) trx_qty
 from MTL_ONHAND_QUANTITIES_DETAIL moqd
 where LOCATOR_ID is null
 AND PLANNING_ORGANIZATION_ID = ORGANIZATION_ID
 AND OWNING_ORGANIZATION_ID = ORGANIZATION_ID
 AND PLANNING_TP_TYPE = 2
 AND OWNING_TP_TYPE = 2
 AND NVL(SECONDARY_TRANSACTION_QUANTITY,0) = 0
 and exists (select 1 from MTL_SECONDARY_INVENTORIES msi
 where msi.SECONDARY_INVENTORY_NAME = moqd.SUBINVENTORY_CODE
 and   msi.ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and   msi.LOCATOR_TYPE = 5 )
 and exists (select 1 from MTL_PARAMETERS
 where ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and  STOCK_LOCATOR_CONTROL_CODE = 4
 AND  NOT (WMS_ENABLED_FLAG = ''Y'' OR PROCESS_ENABLED_FLAG = ''Y''))
 and exists (select 1 from MTL_SYSTEM_ITEMS msit
 where msit.ORGANIZATION_ID = moqd.ORGANIZATION_ID
 and   msit.INVENTORY_ITEM_ID = moqd.INVENTORY_ITEM_ID
 and   msit.SERIAL_NUMBER_CONTROL_CODE in (1, 6)
 and   msit.LOCATION_CONTROL_CODE in (2,3) )
 group by moqd.ORGANIZATION_ID, moqd.SUBINVENTORY_CODE, moqd.INVENTORY_ITEM_ID,  moqd.LOT_NUMBER,moqd.REVISION,moqd.LOCATOR_ID', -- Signature sql
 'Null Locator Onhand when Locator Control is Enabled at the Item Level', -- Signature titl e
 'RS', -- Fail condition
 'Onhand have records with Null Locator when the locator control is enabled at the item level where the organization control and subinventory level controls indicate item level control.', -- Problem description
 '<ul><li>Review [282480.1] - Identification Script #3b.</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'RS', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

----------------------------------------------------------------------------------------------------------
-- Locator Stamped On Onhand Record Is Different From The One Existing In MIL For The Subinventory SDF #13
----------------------------------------------------------------------------------------------------------

/*
SDF #13 is handled in the signature for SDF #12
*/

----------------------------------------------------------------------------------------
-- Onhand Have Records With Null Locator When Subinventory Is Locator Controlled SDF #14
----------------------------------------------------------------------------------------

/*
SDF #14 is handled in the signature for SDF #12
*/

-------------------------------------------------------------------------------------------------------------
-- The Update Standard Costs Fails With Invalid value for INTRANSIT_OWNING_ORG_ID in table MTL_SUPPLY SDF #15
-------------------------------------------------------------------------------------------------------------

/*
Leaving costing SDF's for Costing Analyzer
*/

--------------------------------------------------------------------------------------------------
-- 'Error occurred while relieving reservations' Due To Incorrect Or Negative Availability SDF #16
--------------------------------------------------------------------------------------------------

 add_signature(
 'Error_Occur_Reserv',  -- Unique Signature identifier
 'select organization_id,
 inventory_item_id,
 process_flag, 
 lock_flag,
 transaction_type_id,
 transaction_mode, 
 error_code, 
 error_explanation, 
 transaction_quantity, 
 transaction_date
 from mtl_transactions_interface
 where error_code like ''%Error Occurred While Relieving Reservations%''',   -- The signature sql query
 'Error Occurred While Relieving Reservations',  -- Signature title
 'RS',  -- Fail condition
 'Error Occurred While Relieving Reservations error for Tranactions.',  -- Problem description 
 '<ul><li>As there are rows retruned, see [1471606.1] for a more detailed diagnosis and a solution </li></ul>',  -- Problem solution
 'There are no issues with errors while relieving reservations.', -- Message on success 
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'Y', -- Print sql output
 'N', -- Print limit rows
 p_include_in_dx_summary => 'Y');

------------------------------------------------------------------------------------------------------------------
-- Duplicate Transactions in MTI Already Posted in MMTT and MMT and in MMTT Already Posted Into MMT SDF #17 Parent
------------------------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Dupes_MTI_MMTT_MMT',  -- Signature Identifier
 'SELECT ''Expand subsections below to see if there are duplicates in the transactions tables''   "Dupe trans data corruption"
 FROM dual',  -- Signature sql, Very import to watch single and double quotes
 'Check for Duplicate Transactions in the MTI, MMTT, or MMT Tables.', -- Signature Title
 '[count]<[0]', -- Fail condition
 'Do Duplicate Transactions Exist in the MTI, MMTT, or, MMT Tables?', -- Problem Description
 '<ul><li>Review [1472074.1] - Inventory Standard Datafix Instruction #17: HowTo Find and Fix Duplicate Sales Order Transactions In MTI, MMTT and MMT.</li></ul>', -- Problem Solution
 'If there is an error in one of the child checks, please review. Otherwise, no data returned.', -- Message on success
 'ALWAYS', -- Print condition
 'I', -- Fail type
 'RS', -- Print sql output
 'N', -- Print limit rows
 l_info,
 VARCHAR_TBL('Dupes_MMT_MTI', 'Dupes_MMTT_MTI', 'Dupes_MMT_MMTT'), -- Children to call
 p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------------------------------------------------------
-- Duplicate Transactions in MTI Already Posted in MMTT and MMT and in MMTT Already Posted Into MMT SDF #17 Child 1 MMT - MTI
-------------------------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Dupes_MMT_MTI', -- Signature identifier
 'select count(*) from  mtl_material_transactions b, 
 mtl_transactions_interface a 
 where a.picking_line_id = b.picking_line_id 
 and a.trx_source_line_id = b.trx_source_line_id 
 and a.inventory_item_id = b.inventory_item_id 
 and b.transaction_type_id = a.transaction_type_id 
 and b.transaction_source_type_id in (2,8)
 and b.picking_line_id is not null', -- Signature sql
 'Check for Duplicate Transactions in MMT and MTI', -- Signature title
 '[count(*)] > [0]', -- Fail condition
 'Check for Duplicate Transactions in MMT and MTI', -- Problem description
 '<ul><li>If there are more than zero rows retruned, see [1472074.1] for a more detailed diagnosis and a solution.</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'Y', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

-------------------------------------------------------------------------------------------------------------------
-- Duplicate Transactions in MTI Already Posted in MMTT and MMT and in MMTT Already Posted Into MMT SDF #17 Child 2 MMTT - MTI
-------------------------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Dupes_MMTT_MTI', -- Signature identifier
 'select count(*) from 
 mtl_material_transactions_temp b,  mtl_transactions_interface a 
 where a.picking_line_id = b.picking_line_id 
 and a.trx_source_line_id = b.trx_source_line_id 
 and a.inventory_item_id = b.inventory_item_id 
 and b.transaction_type_id = a.transaction_type_id 
 and b.transaction_source_type_id in (2,8)
 and b.picking_line_id is not null', -- Signature sql
 'Check for Duplicate Transactions in MMTT and MTI', -- Signature title
 '[count(*)] > [0]', -- Fail condition
 'Check for Duplicate Transactions in MMTT and MTI', -- Problem description
 '<ul><li>If there are more than zero rows retruned, see [1472074.1] for a more detailed diagnosis and a solution.</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'Y', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

-------------------------------------------------------------------------------------------------------------------
-- Duplicate Transactions in MTI Already Posted in MMTT and MMT and in MMTT Already Posted Into MMT SDF #17 Child 3 MMT - MMTT
-------------------------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Dupes_MMT_MMTT', -- Signature identifier
 'select count(*) from 
 mtl_material_transactions b,  mtl_material_transactions_temp a 
 where a.picking_line_id = b.picking_line_id 
 and a.trx_source_line_id = b.trx_source_line_id 
 and a.inventory_item_id = b.inventory_item_id 
 and b.transaction_type_id = a.transaction_type_id 
 and b.transaction_source_type_id in ( 2,8) 
 and b.picking_line_id is not null', -- Signature sql
 'Check for Duplicate Transactions in MMT and MMTT', -- Signature title
 '[count(*)] > [0]', -- Fail condition
 'Check for Duplicate Transactions in MMT and MMTT', -- Problem description
 '<ul><li>If there are more than zero rows retruned, see [1472074.1] for a more detailed diagnosis and a solution.</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'Y', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

-------------------------------------------------------------------------------------------------------------------
-- View material transactions screen raise error APP-FND-00756:CANNOT FIND COMBINATION CCID=40225 CODE=MKTS SDF #18 Parent
-------------------------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'MMT_Source_Types',  -- Signature Identifier
 'SELECT ''Expand subsections below to see Material Transactions that could Raise Error APP-FND-00756'' "APP-FND-00756"
  FROM dual',  -- Signature sql, Very import to watch single and double quotes
 'Material Transactions APP-FND-00756 Error', -- Signature Title
 '[count]<[0]', -- Fail condition
 'Identify the transactions where in MTL_MATERIAL_TRANSACTIONS that do not have source type of Internal requistion for Internal order sub-transfer.', -- Problem Description
 '<ul><li>Review [1471880.1] - Inventory Standard Datafix Instruction #18: Fixing View Material Transactions Screen Raise Error APP-FND-00756:CANNOT FIND COMBINATION CCID=40225 CODE=MKTS.</li></ul>', -- Problem Solution
 'If there is an error in one of the child checks, please review. Otherwise, no data returned.', -- Message on success
 'ALWAYS', -- Print condition
 'I', -- Fail type
 'RS', -- Print sql output
 'N', -- Print limit rows
 l_info,
 VARCHAR_TBL('Sales_Order_Greater_Zero', 'Sales_Order_No_Ref'), -- Children to call
 p_include_in_dx_summary => 'Y');
 
-------------------------------------------------------------------------------------------------------------------
-- View material transactions screen raise error APP-FND-00756:CANNOT FIND COMBINATION CCID=40225 CODE=MKTS SDF #18 Child 1
-------------------------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Sales_Order_Greater_Zero', -- Signature identifier
 'SELECT * FROM mtl_material_transactions
  WHERE transaction_source_type_id = 8
  AND transaction_id in 
  (SELECT transfer_transaction_id 
  FROM mtl_material_transactions
  WHERE transaction_Source_type_id=8 
  AND transaction_action_id=2
  AND transaction_type_id=50 
  AND primary_quantity < 0)', -- Signature sql
 'Find Sales Order Transactions Where Quantity is Greater Than Zero', -- Signature title
 'RS', -- Fail condition
 'Find Sales Order Transactions Where Quantity is Greater Than Zero', -- Problem description
 '<ul><li>If there are more than zero rows retruned, see [1471880.1] for a more detailed diagnosis and solution.</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'Y', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

-------------------------------------------------------------------------------------------------------------------
-- View material transactions screen raise error APP-FND-00756:CANNOT FIND COMBINATION CCID=40225 CODE=MKTS SDF #18 Child 2
-------------------------------------------------------------------------------------------------------------------

 l_info.delete;
 add_signature(
 'Sales_Order_No_Ref', -- Signature identifier
 'SELECT * 
  FROM mtl_material_transactions
  WHERE transaction_source_type_id=8
  AND transaction_quantity >0
  AND transaction_action_id in (3,12)
  AND not exists 
  (SELECT 1 FROM mtl_sales_orders WHERE sales_order_id=transaction_source_id)', -- Signature sql
 'Sales Order Transactions Without Valid Sales Order Reference', -- Signature title
 'RS', -- Fail condition
 'Sales Order Transactions Without Valid Sales Order Reference', -- Problem description
 '<ul><li>If there are more than zero rows retruned, see [1471880.1] for a more detailed diagnosis and solution.</li></ul>', -- Problem solution
 null, -- Message on success
 'ALWAYS', -- Print condition
 'E', -- Fail type
 'Y', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

---------------------------------------------------------------------------------------------------------
-- Negative TRANSACTION_SOURCE_ID in the inventory transactions table (MTL_MATERIAL_TRANSACTIONS) SDF #19
---------------------------------------------------------------------------------------------------------

 add_signature(
 'Neg_Trans_Srce_MMT',  -- Unique Signature identifier
 'SELECT
 MMT.organization_id,
 MTT.TRANSACTION_TYPE_NAME,
 COUNT(*) "Total"
 FROM mtl_material_transactions MMT ,   MTL_TRANSACTION_TYPES MTT
 WHERE MMT.transaction_source_id < 0 
 AND MMT.costed_flag IN (''E'',''N'')  
 AND MMT.TRANSACTION_TYPE_ID = MTT.TRANSACTION_TYPE_ID
 GROUP BY MTT.TRANSACTION_TYPE_NAME, 
 MMT.organization_id',   -- The signature sql query
 'Negative TRANSACTION_SOURCE_ID in the MTL_MATERIAL_TRANSACTIONS MMT table',  -- Signature title
 'RS',  -- Fail condition
 'There is a Negative TRANSACTION_SOURCE_ID in the MTL_MATERIAL_TRANSACTIONS MMT table.',  -- Problem description 
 '<ul><li>See the solution in [1471862.1] - Inventory Standard Datafix Instruction #19: Fixing Negative TRANSACTION_SOURCE_ID In The Inventory Transactions Table (MTL_MATERIAL_TRANSACTIONS)</li></ul>',  -- Problem solution
 'There is no Negative TRANSACTION_SOURCE_ID in the MTL_MATERIAL_TRANSACTIONS MMT table.',  -- Message on success  
 'ALWAYS', -- Print condition  
 'E', -- Fail type
 'Y', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

---------------------------------------------------------------------------
-- 'CST_INVALID_INTERORG' Error While Posting Material Transactions SDF #20
---------------------------------------------------------------------------

/*
Leaving costing SDF's for Costing Analyzer
*/

-------------------------------------------------------------------------------------------------------
-- SO Issue Missing in MTI and MMT for Drop Ship PO Receipt And SO Line Shipped Qty Not Updated SDF #21
-------------------------------------------------------------------------------------------------------

/*
There is only a ident sql for this issue and there is no solution note or SDF for this issue. Hold spot for fix
*/

-------------------------------------------------------------------
-- Missing Move Order Header SDF #22
-------------------------------------------------------------------

 add_signature(
 'Pick_Move_Header',  -- Unique Signature identifier
 'SELECT mtrl.header_id, 
  wdd.organization_id, 
  enforce_ship_set_and_smc, 
  wpb.pick_grouping_rule_id, 
  wpb.name
  FROM wsh_delivery_details wdd, 
  wsh_shipping_parameters wsp, 
  mtl_txn_request_lines mtrl, 
  wsh_picking_batches wpb
  WHERE line_id = move_order_line_id
  AND source_code = ''OE''
  AND wdd.move_order_line_id IS NOT NULL
  AND wsp.organization_id = wdd.organization_id
  AND wdd.batch_id = wpb.batch_id
  AND released_status = ''S''
  AND NOT EXISTS ( SELECT 1
  FROM mtl_txn_request_headers mtrh
  WHERE mtrh.header_id = mtrl.header_id )',   -- The signature sql query
 'Unable to Pick Move Order Lines Due to Missing Move Order Header Row',  -- Signature title
 'RS',  -- Fail condition
 'Unable to Pick Move Order Lines Due to Missing Move Order Header Row.',  -- Problem description 
 '<ul><li>See the Solution in [1119934.1] - Unable to Pick Move Order due to Missing Move Order Header Row in MTL_TXN_REQUEST_HEADERS</li></ul>',  -- Problem solution
 'There is no missing pick move order header Row in MTL_TXN_REQUEST_HEADERS.',  -- Message on success  
 'ALWAYS', -- Print condition  
 'E', -- Fail type
 'Y', -- Print sql output
 'Y', -- Print limit rows
 p_include_in_dx_summary => 'Y');

  -------------------------------------------
  -- Example signatures
  -- PSD #9b
  -------------------------------------------
/*
  l_info.delete;
  l_info('Doc ID') := '390023.1'; -- example using l_info
  l_info('Bug Number') := '9707155'; -- example using l_info
  add_signature(
   'Note390023.1_case_GEN4',
   'SELECT ''PO/PA'' "Doc Type",
           h.segment1 "Doc Number",
           h.po_header_id "Doc ID",
           h.org_id,
           null "Release Num",
           null "PO Release ID",
           h.type_lookup_code "Type Code",
           h.authorization_status "Athorization Status",
           nvl(h.cancel_flag,''N'') canceled,
           nvl(h.closed_code,''OPEN'') "Closed Code",
           h.change_requested_by "Change Requested By",
           h.revision_num,
           h.wf_item_type, h.wf_item_type "##$$FK1$$##",
           h.wf_item_key, h.wf_item_key "##$$FK2$$##",
           h.approved_date "Approved Date"
    FROM po_headers_all h
    WHERE to_date(''##$$FDATE$$##'') <= (
            SELECT max(ah.action_date) FROM po_action_history ah
            WHERE ah.object_id = h.po_header_id
            AND   ah.object_type_code IN (''PO'',''PA'')
            AND   ah.action_code = ''SUBMIT''
            AND   ah.object_sub_type_code = h.type_lookup_code)
    AND   h.org_id = ##$$ORGID$$##
    AND   h.authorization_status IN (''IN PROCESS'', ''PRE-APPROVED'')
    AND   nvl(h.cancel_flag,''N'') <> ''Y''
    AND   nvl(h.closed_code,''OPEN'') <> ''FINALLY CLOSED''
    AND   nvl(h.change_requested_by,''NONE'') NOT IN (''REQUESTER'',''SUPPLIER'')
    AND   (nvl(h.ENCUMBRANCE_REQUIRED_FLAG, ''N'') <> ''Y'' OR
           h.type_lookup_code <> ''BLANKET'')
    AND   NOT EXISTS (
            SELECT null
            FROM wf_item_activity_statuses ias,
                 wf_notifications n
            WHERE ias.notification_id is not null
            AND   ias.notification_id = n.group_id
            AND   n.status = ''OPEN''
            AND   ias.item_type = ''POAPPRV''
            AND   ias.item_key IN (
                    SELECT i.item_key FROM wf_items i
                    START WITH i.item_type = ''POAPPRV''
                    AND        i.item_key = h.wf_item_key
                    CONNECT BY PRIOR i.item_type = i.parent_item_type
                    AND        PRIOR i.item_key = i.parent_item_key
                    AND     nvl(i.end_date,sysdate+1) >= sysdate))
    ORDER BY 1,2',
   'Recent Documents - Candidates for Reset',
   'RS',
   'Recent documents exist which are candidates for reset.  The documents
    listed are all IN PROCESS or PRE-APPROVED approval status
    and do not have an open workflow notification.',
   '<ul><li>Review the results in the Workflow Activity section
         for the documents.</li>
      <li>If multiple documents are stuck with errors in the same
         workflow activity then try the Mass Retry in [458216.1].</li>
      <li>For all other document see [390023.1] for details on
         how to reset these documents if needed.</li>
      <li>To obtain a summary count for all such documents in your 
         system by document type, refer to [1584264.1]</li></ul>',
   null,
   'FAILURE',
   'W',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('Note390023.1_case_GEN4_CHILD1',
     'Note390023.1_case_GEN4_CHILD2')); 

	 
    l_info.delete;
    add_signature(
     'Note390023.1_case_GEN4_CHILD1',
     'SELECT DISTINCT
             ac.name Activity,
             ias.activity_result_code Result,
             ias.error_name ERROR_NAME,
             ias.error_message ERROR_MESSAGE,
             ias.error_stack ERROR_STACK
      FROM wf_item_activity_statuses ias,
           wf_process_activities pa,
           wf_activities ac,
           wf_activities ap,
           wf_items i
      WHERE ias.item_type = ''##$$FK1$$##''
      AND   ias.item_key  = ''##$$FK2$$##''
      AND   ias.activity_status     = ''ERROR''
      AND   ias.process_activity    = pa.instance_id
      AND   pa.activity_name        = ac.name
      AND   pa.activity_item_type   = ac.item_type
      AND   i.item_type             = ias.item_type
      AND   i.item_key              = ias.item_key
      AND   i.begin_date            >= ac.begin_date
      AND   i.begin_date            < nvl(ac.end_date, i.begin_date+1)
      AND   (ias.error_name is not null OR
             ias.error_message is not null OR
             ias.error_stack is not null)
      ORDER BY 1,2',
     'WF Activity Errors for This Document',
     'NRS',
     'No errored WF activities found for the document',
     null,
     null,
     'SUCCESS',
     'I',
     'RS',
	 l_info,
	 p_include_in_dx_summary => 'Y'); -- this is will add DX Summary in HTML Output as hidden
*/
    -------------------------------------------
    -- End of example signatures
    -------------------------------------------	 
    -- PSD #9b-end	 

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;



---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main (
      p_org_id            IN NUMBER   DEFAULT null,
      p_user_name         IN VARCHAR2 DEFAULT null,
      p_responsibility_id IN VARCHAR2 DEFAULT null,	
      p_from_date         IN DATE     DEFAULT sysdate - 90,
      p_end_date          IN DATE     DEFAULT sysdate - 90,
      p_max_output_rows   IN NUMBER   DEFAULT 50,
      p_debug_mode        IN VARCHAR2 DEFAULT 'Y') IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
  
  -- PSD #11
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Inventory Transactions';

  l_step := '20';
 -- PSD #12
  validate_parameters(
      p_org_id,
      p_user_name,
      p_responsibility_id,
      p_from_date,
      p_end_date,
      p_max_output_rows,
      p_debug_mode);

  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  
  -- PSD #13
  
l_step := '70';
  start_section('Proactive Recommendations');
     set_item_result(check_rec_patches);
      set_item_result(run_stored_sig('INVALIDS'));
end_section;
  
l_step := '80';
  start_section('Inventory Code Level');
    IF (g_sql_tokens('##$$REL$$##') IS NOT NULL) THEN
       IF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.0') THEN
          set_item_result(run_stored_sig('INV_CODE_LEVEL_12_0'));
       ELSIF (substr(g_sql_tokens('##$$REL$$##'),1,4) = '12.1') THEN
          set_item_result(run_stored_sig('INV_CODE_LEVEL_12_1'));
       ELSE
          set_item_result(run_stored_sig('INV_CODE_LEVEL_12_2'));    
       END IF;
    END IF;   
end_section;

l_step := '90';
 start_section('Inventory Administration');
  set_item_result(run_stored_sig('WMS_Enabled_Orgs'));
   set_item_result(run_stored_sig('PJM_Enabled_Orgs'));
    set_item_result(run_stored_sig('OPM_Enabled_Orgs'));
     set_item_result(run_stored_sig('Neg_Bal_Orgs'));
      set_item_result(run_stored_sig('Inv_Trans_Managers'));
end_section;
  
 l_step := '100'; 
  start_section('Profiles');
   set_item_result(run_stored_sig('Inv_Trans_Specific_Profiles'));
end_section;
  
l_step := '110';  
 start_section('Transactions Summary');
  set_item_result(run_stored_sig('MTI_Trans_Errors'));
   set_item_result(run_stored_sig('MMTT_Trans_Errors'));
    set_item_result(run_stored_sig('MMT_Trans_Errors'));
end_section;
  
l_step := '120';
 start_section('Common Data Issues');
  set_item_result(run_stored_sig('MOQD_Mismatch'));
   set_item_result(run_stored_sig('Closed_Move_Order_Lines'));
    set_item_result(run_stored_sig('Serial_Invalid_Mark_IDs'));
     set_item_result(run_stored_sig('Orphan_Serial_Number_Temp_Records'));
      set_item_result(run_stored_sig('All_Lot_Numbers_Trailing_Spaces'));
       set_item_result(run_stored_sig('All_Serial_Numbers_Trailing_Spaces'));  
        set_item_result(run_stored_sig('Corrupt_Lots_Onhand'));      
         set_item_result(run_stored_sig('Incorrect_Demand_Header_ID'));
          set_item_result(run_stored_sig('Loc_Onhand_Mismatch'));
           set_item_result(run_stored_sig('Error_Occur_Reserv'));
            set_item_result(run_stored_sig('Dupes_MTI_MMTT_MMT'));
             set_item_result(run_stored_sig('MMT_Source_Types'));
              set_item_result(run_stored_sig('Neg_Trans_Srce_MMT'));
               set_item_result(run_stored_sig('Pick_Move_Header'));
end_section;
  
  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/message/12784460#12784460" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

-------------------------------------------
-- MAIN ENTRY POINT FOR CONCURRENT PROCESS
-- uncomment to run from concurrent program
-- edit list of variables to match MAIN
-- <package>.main_cp will be what you define program to call
-------------------------------------------
-- PSD #16	
PROCEDURE main_cp(
      errbuf              OUT VARCHAR2,
      retcode             OUT VARCHAR2,
      p_org_id            IN NUMBER   DEFAULT null,
      p_user_name         IN VARCHAR2 DEFAULT null,
      p_responsibility_id IN VARCHAR2 DEFAULT null,	
	  p_from_date         IN VARCHAR2 DEFAULT NULL,
      p_end_date          IN VARCHAR2 DEFAULT NULL) IS
	  
l_from_date DATE;
l_end_date DATE;
	  
BEGIN
  g_retcode := 0;
  g_errbuf := null;
  
  l_from_date := fnd_conc_date.string_to_date(p_from_date);
  l_end_date := fnd_conc_date.string_to_date(p_end_date);

-- PSD #17  
  main(
      p_org_id => p_org_id,
	  p_user_name => p_user_name,
	  p_responsibility_id => p_responsibility_id,
	  p_from_date => l_from_date,
	  p_end_date => l_end_date
);

  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


-- PSD #1
END inv_trans_analyzer_pkg;
/
show errors
exit;