SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE '~'

REM $Id: hcm_person_analyzer.sql, 200.18 2016/01/14 23:27:42 nragavar Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.21                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    hcm_person_analyzer.sql                                              |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Consolidated script to diagnose issues that can cause problems in    |
REM |       your HCM - Person(s) on an environment.                           |
REM | HISTORY                                                                 |
REM |                                                                         |
REM | 01-May-2014  nragavar  created         Initial Version                  |
REM |                                                                         |
REM | 23-Jun-2014  nragavar  Added           Added check for Application Version 
REM |                                        and minor changes.               
REM | 14-Jul-2014  nragavar  Added           added column SEX and titled column 'Gender'
REM | 27-Jan-2015  nragavar  Added           added column SPECIAL_CEILING_STEP_ID to Assignment details section
REM |                                        Updated 'Payroll Element Entries' section for duplicate rows
REM | 06-Feb-2015  nragavar  Added           Added new section 'PAYE and NI aggregation Details' 
REM | 12-Mar-2015  nragavar  Added           Updated section 'Assignment Action Details'
REM | 01-Apr-2015  nragavar  Added           Updated section 'Assignment Action Details' and 'line_out' procedure
REM |                                          Code changes to handle error : ERROR: ORA-06502: PL/SQL: numeric or value 
REM |                                            error: host bind array too small ORA-06512: at line 1 ERROR: ORA-06502: PL/SQL: numeric or value 
REM |                                            error: host bind array too small ORA-06512: at line 1
REM | 03-Apr-2015  nragavar  Added           Added new section 'Business Group Details' 
REM | 27-Apr-2015  nragavar  Update          Updated section 'Business Group Details'
REM |                                          and $Header to $Id
REM | 27-Apr-2015  nragavar  Update          Major changes for new Analyzer standards    
REM | 19-Jun-2015  nragavar  Update          Added sections PERSON_ISSUE1,PERSON_ISSUE2,PERSON_ISSUE3
REM |                                          ASSIGNMENT_ISSUE1,ASSIGNMENT_ISSUE2,ASSIGNMENT_ISSUE3,
REM |                                          Shared HR customers only section added.
REM | 22-Jul-2015  nragavar  Update          Added multiple sections for DX summary. 
REM |                                          Copy and paste for Person and Assignment details and issues
REM | 31-Aug-2015  nragavar  Update  200.13  Added multiple sections for PERSONS_CWK_ISSUE1, PERSONS_PEE_ISSUE2. 
REM | 04-Sep-2015  nragavar  Update  200.14  Added Analyzer Bundle.
REM | 14-Sep-2015  nragavar  Update  200.15  Latest Version image file change
REM |                                        Copy and paste for Person and Assignment details and issues - Further Changes
REM | 14-Sep-2015  nragavar  Update  200.16  Devided to more sub-sections, feedback from multiple people implemented 
REM |                                        Changes for Bundle.
REM | 07-Jan-2016  nragavar  Update  200.17  Added section 'Termination' and moved two signatures from Proactive 
REM |                                        Termination section
REM | 08-Jan-2016  nragavar  Update  200.18  Added signatures 'comment_PER' and 'Comment_ASG' as per Andrea request
REM | 14-Jan-2016  nragavar  Update          Added signature 'NOTE1209323' as per Andrea request
REM | 14-Jan-2016  nragavar  Update          Added signatures 'NOTE402472' and 'NOTE1566082' For Terminations                                        
REM |                                       
REM +=========================================================================+
REM
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2
REM 
REM MENU_TITLE: HCM: Person Analyzer
REM
REM MENU_START
REM
REM SQL: Run (HCM) Person Analyzer 
REM FNDLOAD: Load (HCM) Person Analyzer as a Concurrent Program 
REM 
REM MENU_END 
REM
REM HELP_START  
REM 
REM  EBS Human Capital Management (HCM) Person Analyzer (Doc ID 1675487.1)
REM
REM  Compatible: 11i 12.0 12.1 12.2
REM 
REM  Explanation of available options:
REM  
REM    (1) Run HCM Person Analyzer
REM        o Runs person_analyzer.sql as APPS
REM        o Creates an HTML report file in MENU/output/ 
REM
REM    (2) Install HCM Person Analyzer as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: 
REM          "Global HRMS Reports & Process"
REM
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: PER_TOP
REM PROG_NAME: PERSON_ANALYZER_SQL
REM DEF_REQ_GROUP: Global HRMS Reports & Process
REM PROG_TEMPLATE: hcm_person_analyzer_R12.ldt
REM PROD_SHORT_NAME: PER
REM CP_FILE: hcm_person_analyzer_cp.sql
REM APP_NAME: Human Resources 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT 
REM
REM ANALYZER_BUNDLE_END

-- PROMPTS/ACCEPTS are to be used if running from SQL*Plus
-- If submitting analyzer as a concurrent process (cp), then need to remove/comment below ACCEPTS/PROMPTS section
-- Variables below when accepting parameters are numbers because this is needed when running as a cp, but can be change if running from SQL*Plus
-- So 2 files would be needed (one to be run from SQL*Plus, other for CP)

PROMPT
-- PSD #1
PROMPT Submitting Person Analyzer.
PROMPT ===========================================================================
PROMPT Enter the Person Id.  This parameter is required.
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 1 CHAR DEFAULT -1 -
       PROMPT 'Enter the person_id(required): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the date from which to begin validating transactions(default sysdate-90)
PROMPT ===========================================================================
COLUMN date1 new_value curdate NOPRINT
-- PSD #2
ACCEPT 2 DATE FORMAT 'RRRR/MM/DD' DEFAULT '9999/12/31' -
       PROMPT 'Enter the START DATE YYYY/MM/DD (default sysdate-90): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the maximum number of rows to display on row limited queries
PROMPT ===========================================================================
-- PSD #2
ACCEPT 3 NUMBER DEFAULT 50 -
       PROMPT 'Enter the maximum rows to display [50]: '
PROMPT
PROMPT

DECLARE
-- PSD #3
  l_person_id  VARCHAR2(250) := '~1';
  l_from_date  DATE := to_date('~2','RRRR/MM/DD'); 
  l_max_rows   NUMBER := '~3';
  l_debug_mode VARCHAR2(1) := 'Y';

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER := 0,
  warn_count     NUMBER := 0,
  success_count  NUMBER := 0,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #17
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=xxxxxxx.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;

g_preserve_trailing_blanks BOOLEAN := true;

/*-- Custom Procedure
-- Show required date format 

FUNCTION format_date( p_date   varchar2) RETURN VARCHAR2 IS
BEGIN
  RETURN (TO_CHAR(P_DATE,'DD-Mon-YYYY'));
END format_date; 
*/
----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;

PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

-- PSD #4
    l_log_file := 'Person_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'Person_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);	
    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>HCM Person Analyzer</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide Extra Info","Show Extra Info");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show Extra Info","Hide Extra Info");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide Extra Info","Show Extra Info");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show Extra Info","Hide Extra Info");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
              'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfL'||
              'T8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the background color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

-- Print title
-- PSD #5  
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1675487.1:PER_ANA_SCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/hcm_per_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
--print_out('error count'||l_cnt_err);
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
--print_out('error count'||l_cnt_err);
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show Extra Info","Hide Extra Info"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide Extra Info","Show Extra Info");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">DocId \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','S','I') THEN
    IF result = 'S' THEN
      g_sections(g_sections.last).result := 'S';
    ELSE
      g_sections(g_sections.last).result := result;
    END IF;
  ELSIF g_sections(g_sections.last).result = 'W' THEN
    IF result = 'E' THEN
      g_sections(g_sections.last).result := result;
    END IF;
  END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
		 
		 -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
  l_step := 'Validate parameters';
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  	
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show Extra Info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
          -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
          -- this ensures trailing blanks added for padding are honored by browsers
          -- affects only printing, DX summary handled separately
          IF g_preserve_trailing_blanks THEN
		  
		     l_html := l_html || '
                       <th>'||RPAD(RTRIM(p_col_headings(i),' '), 
                                -- pad length is the number of spaces existing times the length of &nbsp; => 6
                               (length(p_col_headings(i)) - length(RTRIM(p_col_headings(i),' '))) * 6 
							   + length(RTRIM(p_col_headings(i),' ')),'&nbsp;');  
          ELSE
             l_html := l_html || '
                       <th>'||nvl(RTRIM(p_col_headings(i),' '),'&nbsp;')||'</th>';
          END IF;
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
		  END IF;
		  
		  -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
          -- this ensures trailing blanks added for padding are honored by browsers
          -- affects only printing, DX summary handled separately

          IF g_preserve_trailing_blanks THEN
            l_curr_Val := RPAD(RTRIM(l_curr_Val,' '), 
                                -- pad length is the number of spaces existing times the length of &nbsp; => 6
                               (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
                               '&nbsp;');
          ELSE
            l_curr_Val := RTRIM(l_curr_Val, ' ');
          END IF;
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i), l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);
/* commenting this as each has its own failure the parent should fail based on its own 
   criteria
           IF l_result in ('W','E') THEN
             l_fail_flag := true;
           END IF;
*/

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF l_sig_fail THEN
		  IF p_sig.fail_type ='E' THEN 
		  g_section_toc := g_section_toc || '<img class="error_ico">';       
		  ELSIF p_sig.fail_type ='W' THEN
			g_section_toc := g_section_toc ||'<img class="warn_ico">';   	 
		   end if;
	   end if;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF l_sig_fail THEN
		  IF p_sig.fail_type ='E' THEN 
		  g_section_toc := g_section_toc || '<img class="error_ico">';       
		  ELSIF p_sig.fail_type ='W' THEN
			g_section_toc := g_section_toc ||'<img class="warn_ico">';   	 
		   end if;
	   end if;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;
	
  END IF;	
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div><br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
-- PSD #6  
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;

  CURSOR get_app_date(p_ptch VARCHAR2) IS
  SELECT to_char(max(pr.start_date),'DD-Mon-YYYY') app_date
  FROM ad_patch_runs pr
  WHERE pr.patch_run_id in (
          SELECT prb.patch_run_id
          FROM   ad_bugs b,
                 ad_patch_run_bugs prb
          WHERE  b.bug_number = p_ptch
          AND    prb.bug_id = b.bug_id
          UNION
          SELECT pr2.patch_run_id
          FROM ad_applied_patches ap,
               ad_patch_drivers pd,
               ad_patch_runs pr2
          WHERE ap.patch_name = p_ptch
          AND   pd.applied_patch_id = ap.applied_patch_id
          AND   pr2.patch_driver_id = pd.patch_driver_id);
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #6a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'

--print_out(g_rep_info('Apps Version'));
	     
  IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN
    l_step := '20';
    l_col_rows.extend(5); 

    l_col_rows(1)(1) := '19193000';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.HR_PF.C.delta.6';
    l_col_rows(5)(1) := '[1992120.1]';

    l_col_rows(1)(2) := '17909898';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'R12.HR_PF.C.delta.5';
    l_col_rows(5)(2) := '[1644357.1]';

    l_col_rows(1)(3) := '17050005';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'R12.HR_PF.C.delta.4';
    l_col_rows(5)(3) := '[1665609.1]';

    l_col_rows(1)(4) := '17001123';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'R12.HR_PF.C.delta.3';
    l_col_rows(5)(4) := '[]';

    l_col_rows(1)(5) := '16169935';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'R12.HR_PF.C.delta.2';
    l_col_rows(5)(5) := '[]';

    l_col_rows(1)(6) := '14040707';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.HR_PF.C.delta.1';
    l_col_rows(5)(6) := '[]';

    l_col_rows(1)(7) := '10124646';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'R12.HR_PF.C';
    l_col_rows(5)(7) := '[]';
    
	
  ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN 
    l_step := '25';
    l_col_rows.extend(5); 

    l_col_rows(1)(1) := '20000288';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'Release 12.1 HRMS RUP8';
    l_col_rows(5)(1) := '[1989740.1]';

    l_col_rows(1)(2) := '18004477';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'Release 12.1 HRMS RUP7';
    l_col_rows(5)(2) := '[1645859.1]';

    l_col_rows(1)(3) := '16000686';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'Release 12.1 HRMS RUP6';
    l_col_rows(5)(3) := '[1549442.1]';

    l_col_rows(1)(4) := '13418800';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'Release 12.1 HRMS RUP5';
    l_col_rows(5)(4) := '[1456556.1]';

    l_col_rows(1)(5) := '10281212';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'Release 12.1 HRMS RUP4';
    l_col_rows(5)(5) := '[1313891.1]';

    l_col_rows(1)(6) := '9114911';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'Oracle Human Resource Management System 12.1.3 Product Family Release Update Pack';
    l_col_rows(5)(6) := '[1081427.1]';

    l_col_rows(1)(7) := '8337373';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Oracle Human Resource Management System Release Update Pack 2 for 12.1 (R12.HR_PF.B.DELTA.2)';
    l_col_rows(5)(7) := '[949437.1]';
    
    l_col_rows(1)(8) := '7446767';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'Release 12.1 HRMS RUP1';
    l_col_rows(5)(8) := '[]';

    l_col_rows(1)(9) := '6603330';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'R12 HRMS FAMILY PACK B';
    l_col_rows(5)(9) := '[]';
	
 -- If want to go based on more e-Business Application version, just add for example:
 -- ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
  ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN 
    l_step := '30';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '16077077';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'Oracle HRMS Release Update Pack 11 for 12.0 (R12.HR_PF.A.DELTA.11)';
    l_col_rows(5)(1) := '[1564126.1]';

    l_col_rows(1)(2) := '13774477';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'Oracle HRMS Release Update Pack 10 for 12.0 (R12.HR_PF.A.DELTA.10)';
    l_col_rows(5)(2) := '[1468789.1]';

    l_col_rows(1)(3) := '10281209';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'Oracle HRMS Release Update Pack 9 for 12.0 (R12.HR_PF.A.DELTA.9)';
    l_col_rows(5)(3) := '[1338475.1]';

    l_col_rows(1)(4) := '9301208';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'Oracle HRMS Release Update Pack 8 for 12.0 (R12.HR_PF.A.DELTA.8)';
    l_col_rows(5)(4) := '[1097842.1]';

    l_col_rows(1)(5) := '7577660';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'Oracle HRMS Release Update Pack 7 for 12.0 (R12.HR_PF.A.DELTA.7)';
    l_col_rows(5)(5) := '[818408.1]';

    l_col_rows(1)(6) := '7004477';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.HR_PF.A.DELTA.6';
    l_col_rows(5)(6) := '[744036.1]';

    l_col_rows(1)(7) := '6610000';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Oracle HRMS Release Update Pack 5 for 12.0 (R12.HR_PF.A.DELTA.5)';
    l_col_rows(5)(7) := '[565977.1]';

    l_col_rows(1)(8) := '6494646';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'R12.HR_PF.A.DELTA.4';
    l_col_rows(5)(8) := '[466091.1]';

    l_col_rows(1)(9) := '6196269';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Oracle HRMS Release Update Pack 3 for 12.0 (R12.HR_PF.A.DELTA.3)';
    l_col_rows(5)(9) := '[452716.1]';
    
    l_col_rows(1)(10) := '5997278';
    l_col_rows(2)(10) := 'No';
    l_col_rows(3)(10) := NULL;
    l_col_rows(4)(10) := 'Oracle HRMS Release Update Pack 2 for 12.0 (R12.HR_PF.A.DELTA.2)';
    l_col_rows(5)(10) := '[430740.1]';
    
    l_col_rows(1)(11) := '5881943';
    l_col_rows(2)(11) := 'No';
    l_col_rows(3)(11) := NULL;
    l_col_rows(4)(11) := 'Oracle HRMS Release Update Pack 1 for 12.0 (R12.HR_PF.A.DELTA.1)';
    l_col_rows(5)(11) := '[417916.1]';        
  
  ELSIF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2' THEN 
    l_step := '30';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '16077077';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'Oracle HRMS Release Update Pack 11 for 12.0 (R12.HR_PF.A.DELTA.11)';
    l_col_rows(5)(1) := '[]';

    l_col_rows(1)(2) := '13774477';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'Oracle HRMS Release Update Pack 10 for 12.0 (R12.HR_PF.A.DELTA.10)';
    l_col_rows(5)(2) := '[]';

    l_col_rows(1)(3) := '10281209';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'Oracle HRMS Release Update Pack 9 for 12.0 (R12.HR_PF.A.DELTA.9)';
    l_col_rows(5)(3) := '[]';

    l_col_rows(1)(4) := '9301208';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'Oracle HRMS Release Update Pack 8 for 12.0 (R12.HR_PF.A.DELTA.8)';
    l_col_rows(5)(4) := '[1097842.1]';

    l_col_rows(1)(5) := '7577660';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'Oracle HRMS Release Update Pack 7 for 12.0 (R12.HR_PF.A.DELTA.7)';
    l_col_rows(5)(5) := '[818408.1]';

    l_col_rows(1)(6) := '7004477';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.HR_PF.A.DELTA.6';
    l_col_rows(5)(6) := '[744036.1]';

    l_col_rows(1)(7) := '6610000';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Oracle HRMS Release Update Pack 5 for 12.0 (R12.HR_PF.A.DELTA.5)';
    l_col_rows(5)(7) := '[565977.1]';

    l_col_rows(1)(8) := '6494646';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'R12.HR_PF.A.DELTA.4';
    l_col_rows(5)(8) := '[466091.1]';

    l_col_rows(1)(9) := '6196269';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Oracle HRMS Release Update Pack 3 for 12.0 (R12.HR_PF.A.DELTA.3)';
    l_col_rows(5)(9) := '[452716.1]';
     
  -- PSD #6a-end

  END IF;
  
  -- Check if applied
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i));
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date,'DD-Mon-YYYY');
    END IF;
  END LOOP;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;

PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RSGT1 (RS greater than 1), RS (row selected), NRS (no row selected)
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') --should signature be included in DX Summary
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #7
PROCEDURE validate_parameters (
  p_person_id       IN NUMBER,
  p_from_date       IN DATE,
  p_max_output_rows IN NUMBER,
  p_debug_mode      IN VARCHAR2) IS

  l_from_date    VARCHAR2(25);
  l_to_date      VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;

  invalid_parameters EXCEPTION;
  
  -- PSD #9a
  l_person_id_1  NUMBER := NULL;
  l_chk_id_1     NUMBER := NULL;
  l_ppr_id       NUMBER := NULL; 
  l_federal      VARCHAR2(30);
  l_ss           VARCHAR2(255);
  l_key          VARCHAR2(255);
  
  cursor cur_person_id(p_person_id varchar2) is
    Select count(1) 
    from   per_all_people_f 
    where  person_id = p_person_id and rownum = 1;

  -- PSD #9a-end
  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #8  
  l_revision := rtrim(replace('$Revision: 200.18 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2016/01/14 22:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #9  
  g_rep_info('File Name') := 'hcm_person_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  
  -- PSD #9a
  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');

  IF p_person_id is null THEN
    print_log('No Person ID specified. '||
      'The Person Id parameter is mandatory.');
    raise invalid_parameters;
  END IF;
  
  l_from_date := to_char(nvl(p_from_date,sysdate-90),'DD-MON-YYYY');

  l_to_date  := to_char((sysdate),'DD-MON-YYYY');


  g_sql_tokens('##$$cur_person_id$$##') := l_ss;
  print_log('cur_person_id = '||l_ss);

  l_ss := null;
  if (l_chk_id_1 is not null) then
    l_ss := to_char(l_chk_id_1);
  end if;  

  l_key := g_sql_tokens.first;
  -- Print token values to the log
 
  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  
  -- PSD #10
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Person Id') := p_person_id;
  g_parameters('4. From Date') := l_from_date;
  g_parameters('5. Max Rows') := 	g_max_output_rows;
  g_parameters('6. Debug Mode') := p_debug_mode;
  
  -- PSD #10a
  -- Create global hash of SQL token values
  g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');
  g_sql_tokens('##$$PERID$$##') := to_char(p_person_id);
  g_sql_tokens('##$$FDATE$$##') := l_from_date;
  -- PSD #9a-end

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;

---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info       HASH_TBL_4K;
  l_inst_name  varchar2(20);
  l_host_name  varchar2(50); 
  l_rel_name   varchar2(50);
  l_created    date;
  l_wf_ver     varchar2(100);
  l_db_version varchar2(250);
  l_hr_status  varchar2(50);
  l_pay_status varchar2(50);
  l_multorg    FND_PRODUCT_GROUPS.MULTI_ORG_FLAG%type;
  l_multiCurr  FND_PRODUCT_GROUPS.MULTI_CURRENCY_FLAG%type;
  l_step       VARCHAR2(5);
  l_overview   varchar2(3000);
  
  Cursor cur_rup_level is
      select 'RUP Level              = '|| RUP_LEVEL || ' applied on ' || LAST_UPDATE_DATE "Instance Summary"
         from
          (select '12.2' release 
                ,DECODE(bug_number
                 ,'17001123', '17001123 R12.HR_PF.C.delta.3'
                 ,'16169935', '16169935 R12.HR_PF.C.delta.2'
                 ,'14040707', '14040707 R12.HR_PF.C.delta.1'
                 ,'10124646', '10124646 R12.HR_PF.C'
                 ,'17050005', '17050005 R12.HR_PF.C.Delta.4'
                 ,'17909898', '17909898 R12.HR_PF.C.delta.5'
                 ,'19193000', '19193000 R12.HR_PF.C.Delta.6'
                 ) RUP_LEVEL 
                , LAST_UPDATE_DATE
           FROM ad_bugs
           WHERE BUG_NUMBER = (SELECT to_char(max(to_number(adb.bug_number))) FROM ad_bugs adb
        WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646'))
        and rownum < 2
      union
        select '12.1' release 
               ,DECODE(BUG_NUMBER
                 ,'20000288','20000288 R12.HR_PF.B.delta.8'
                 ,'18004477', '18004477 R12.HR_PF.B.delta.7'
                 ,'16000686', '16000686 R12.HR_PF.B.delta.6'
                 ,'13418800', '13418800 R12.HR_PF.B.delta.5'
                 ,'10281212', '10281212 R12.HR_PF.B.delta.4'
                 ,'9114911', '9114911 R12.HR_PF.B.delta.3'
                 ,'8337373', '8337373 R12.HR_PF.B.delta.2'
                 ,'7446767', '7446767 R12.HR_PF.B.delta.1'
                 ,'6603330', '6603330 R12.HR_PF.B'
                ) RUP_LEVEL
               , LAST_UPDATE_DATE
        FROM ad_bugs
        WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) 
                           from ad_bugs 
                           WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800'
                                               ,'10281212','9114911','8337373', '7446767', '6603330'))
        and rownum < 2
      union
        SELECT '12.0' release 
               ,DECODE(BUG_NUMBER
                 , '16077077', '16077077 R12.HR_PF.A.delta.11'
                 , '13774477', '13774477 R12.HR_PF.A.delta.10'
                 , '10281209', '10281209 R12.HR_PF.A.delta.9'
                 , '9301208', '9301208 R12.HR_PF.A.delta.8'
                 , '7577660', '7577660 R12.HR_PF.A.delta.7' 
                 , '7004477', '7004477 R12.HR_PF.A.delta.6'
                 , '6610000', '6610000 R12.HR_PF.A.delta.5'
                 , '6494646', '6494646 R12.HR_PF.A.delta.4'
                 , '6196269', '6196269 R12.HR_PF.A.delta.3'
                 , '5997278', '5997278 R12.HR_PF.A.delta.2'
                 , '5881943', '5881943 R12.HR_PF.A.delta.1'
                 , '4719824', '4719824 R12.HR_PF.A') RUP_LEVEL
                 , LAST_UPDATE_DATE
        FROM ad_bugs
        WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) 
                           from ad_bugs 
                           WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660'
                                               ,'7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824'))
        and rownum < 2
      union
        SELECT '11.5' release 
               ,DECODE(BUG_NUMBER
                 , '2803988', '2803988 HRMS_PF.E'
                 , '2968701', '2968701 HRMS_PF.F'
                 , '3116666', '3116666 HRMS_PF.G'
                 , '3233333', '3233333 HRMS_PF.H'
                 , '3127777', '3127777 HRMS_PF.I'
                 , '3333633', '3333633 HRMS_PF.J'
                 , '3500000', '3500000 HRMS_PF.K'
                 , '5055050', '5055050 HR_PF.K.RUP.1'
                 , '5337777', '5337777 HR_PF.K.RUP.2'
                 , '6699770', '6699770 HR_PF.K.RUP.3'
                 , '7666111', '7666111 HR_PF.K.RUP.4'
                 , '9062727', '9062727 HR_PF.K.RUP.5'
                 , '10015566', '10015566 HR_PF.K.RUP.6'
                 , '12807777', '12807777 HR_PF.K.RUP.7'
                 , '14488556', '14488556 HR_PF.K.RUP.8'
                 , '17774746', '17774746 HR_PF.K.RUP.9'
                ) RUP_LEVEL
               , LAST_UPDATE_DATE
        FROM ad_bugs
        WHERE BUG_NUMBER = (select to_char(max(to_number(bug_number))) 
                            from ad_bugs 
                            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777'
                                                ,'3333633','3500000','5055050','5337777','6699770'
                                                ,'7666111','9062727','10015566','12807777','14488556','17774746'))
        and rownum < 2)
      where release in (select substr(release_name,1,4) from fnd_product_groups);
      
  l_rup_level   varchar2(250);  
  
BEGIN
-- PSD #11
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------
  
  -------------------------------------------------------------------
  -- Example signature that can be used to check for invalid objects
  --------------------------------------------------------------------
  -- Signature for Invalid objects
  -- PSD #11a
  add_signature(
   'INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    -- AND (a.object_name like ''HR%'' OR a.object_name like ''PER_%'' )
    AND a.status = ''INVALID''',
   'Invalid Objects',
   'RS',
   'All Invalid objects in APPS schema',
   '<ul>
      <li>Recompile the individual objects manually or recompile the
          entire APPS schema with adadmin utility</li>
      <li>Review any error messages provided</li>
   </ul>',
   'No invalid objects exists in APPS schema',
   'SUCCESS',
   'E');  
  
   
  l_step := '44';
  -- signature for person issue - where person exists dates with gap or overlap of person record
  --   
  -- PSD #12a
  add_signature(
   'PERSONS_CWK_ISSUE1',
   'select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(to_char(effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
		  ,rpad(to_char(effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
		  ,rpad(nvl(current_npw_flag,''-''), 13, '' '') "Curr NPW Flag"
		  ,rpad(nvl(npw_number,''-''), 10, '' '') "NPW Number"
	 from   per_all_people_f 
	 where  (npw_number is null
	        or
		      current_npw_flag is null)
   and    person_type_id in (select person_type_id 
                             from   per_person_types 
                             where  (system_person_type like ''%CWK%''))
   ',
   'Contingent worker with improper setup (PER_ALL_PEOPLE_F)',
   'RS',
   'There is a possible problem with contingent workers (CWK) that have a null CURRENT_NPW_FLAG or NPW_NUMBER columns <br>
    See Note:  Terminate Contingent Worker - APP-PAY-07092 The action is invalid for this record - [1339204.1]',
   'Please open a new service request with Oracle Human Resources support with Person Analyzer Note - [1675487.1] output uploaded',
   'Contingent worker setup with NPW_NUMBER and CURRENT_NPW_FLAG are set',
   'FAILURE',
   'W',
   'RS',
   'Y',
   l_info,
   p_include_in_dx_summary => 'Y'); 

  l_step := '44';
  -- signature for persons issue - Persons element entry with start date is > end date
  --   
  -- PSD #12a
  add_signature(
   'PERSONS_PEE_ISSUE2',
   'select distinct rpad(pee.element_entry_id, 12,'' '') "Ele Entry ID" 
           ,rpad(pee.assignment_id, 12,'' '') "Assig ID    " 
           ,rpad(pet.element_name,28,'' '') "Element Name                "
           ,rpad(decode(pet.processing_type,''R'',''Recurring'', ''Non-Recurring''),13,'' '') Processing
           ,rpad(pee.element_link_id,12,'' '') "Ele Link ID " 
           ,rpad(to_char(pee.effective_start_date,''DD-Mon-YYYY''),11,''-'') "Effe Str Dt"
           ,rpad(to_char(pee.effective_end_date,''DD-Mon-YYYY''),11,''-'') "Effe End Dt"
    from   pay_element_entries_f pee, 
           pay_element_types_f pet, 
           per_all_assignments_f paa
    where  pee.effective_start_date > pee.effective_end_date
    and    pee.element_type_id = pet.element_type_id
    and    pee.assignment_id = paa.assignment_id
    Order by "Assig ID    "
   ',
   'Person / Assignment ids with Elements entries that have an End Date before Start Date <br> (PAY_ELEMENT_ENTRIES_F, PAY_ELEMENT_TYPES_F, PER_ALL_ASSIGNMENTS_F)',
   'RS',
   'There is a possible data issue where Person / Assignment ids have Elements entries that have an end date before start date.<br>
    See note - [340188.1] Reverse Termination - APP-PAY-51058 ''An Error Occurred in hrentmnt.validate_adjust_entry''',
   'Please open a new service request with Oracle Human Resources support with Person Analyzer Note - [1675487.1] ouput uploaded',
   'Element entries Start Date is <= End Date',
   'FAILURE',
   'E',
   'RS',
   'Y',
   l_info,
   p_include_in_dx_summary => 'Y'); 
   
   --
   -- Using cursor to select the latest RUP applied. This is required as
   --   cursor is too big for load_signatures procedure
   --  
   Open  cur_rup_level;
   fetch cur_rup_level into l_rup_level; 
   close cur_rup_level;   
   
   
  l_overview := '	select '' Instance Name          = ''|| upper(instance_name) "Instance Summary" from v$instance
              		union
                    select '' Host Name              = ''|| host_name from v$instance
                  union
              		  select '' Applications           = ''|| release_name from fnd_product_groups
              		union
              		  select '' Instance Creation Date = '' || to_char(created,''DD-Mon-YYYY'') from v$database
              		union
              		  select '' Database               = '' || banner db_version from v$version where rownum = 1
              		union
                    select '' Workflow Version       = '' || text from wf_resources 
                    where type = ''WFTKN'' and name = ''WF_VERSION'' and language = ''US''
              		union
              		  SELECT '' PER / HR Status        = '' || L.MEANING 
              	    FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
              	    WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
              		  AND (b.APPLICATION_ID = ''800'')
              		  AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
              		  AND (L.LOOKUP_CODE = I.Status)
              		  AND t.language = ''US''	AND l.language = ''US''
              		union
              	    SELECT '' PAY Status             = '' || L.MEANING 
              	    FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
              	    WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
              	    AND b.application_id = t.application_id
              	  	AND (b.APPLICATION_ID = ''801'')
              		  AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
              		  AND (L.LOOKUP_CODE = I.Status)
              		  AND t.language = ''US''	AND l.language = ''US''
              		union
              		  SELECT '' Multi Org              = '' || MULTI_ORG_FLAG FROM FND_PRODUCT_GROUPS
              		union
                    SELECT '' Multi Currency         = '' || MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS
				          union
					          select '' '||l_rup_level||' '' from dual
                ';
  
  add_signature(
   'OVERVIEW',
   l_overview,   
   'Instance Details',
   'RS',
   'Basic Instance details',
   null,
   'Basic Instance details are not available',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');


  -- signature for Installed languages (NLS) - Common to all Persons
  -- PSD #12b
  add_signature(
   'LANGUAGES_INSTALLED_DETAILS',
   'SELECT language_code "Language Code",  
           decode(INSTALLED_FLAG ,''B'',''Base Installed Language'',''I'',''Additional Installed Language'',''D'',''Not Installed'') "Installed Flag",
           nls_language "NLS Language", 
           nls_territory "NLS Territory"
      FROM FND_LANGUAGES 
      where INSTALLED_FLAG in (''B'',''I'')
      order by LANGUAGE_CODE',
   'Languages Installed Details (FND_LANGUAGES)',
   'RS',
   'List of Languages Installed',
   '',
   'No Installed Languages details Available',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

   
  -- signature for Legislations Installed
  -- PSD #12a
  add_signature(
   'INSTALLED_LEGISLATIONS',
   'select  rpad(decode(legislation_code,null,''global'',legislation_code),16,'' '') "Legislation Code", 
            rpad(decode(application_short_name , ''PER'', ''Human Resources'' , ''PAY'', ''Payroll'' , ''GHR'',
                   ''Federal Human Resources'' , ''CM'',  ''College Data'' , application_short_name),16,'' '') "Application Name",
            rpad(application_short_name,16,'' '') "Application Code",
            rpad(decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'',''-''),13,'' '') "Action       ",
            rpad(to_char(last_update_date,''DD-Mon-YYYY''),12,'' '') "Applied Date"
    from hr_legislation_installations
    where status = ''I'' 
    order by legislation_code',
   'Installed Legislations (HR_LEGISLATION_INSTALLATIONS)',
   'RS',
   'All legislations installed',
   '',
   'No Installed Legislations information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');

	
  l_step := '43';
  -- signature for product_detail
  -- PSD #11a
  
  l_info.delete;
  l_info(' ') :=  'The following table lists the installation status of HRMS related
                   Products and their patch set level. If the patch set is not stored in the
                   database a ? will be substituted for the patch set letter.
                  '; -- example using l_info  
  
  add_signature(
   'PRODUCTS_INSTALL',
   'select t.application_name application, b.application_short_name "Short Name"
      , to_char(t.application_id) "Application ID"
      , l.meaning Status
      , decode(i.patch_level, null, ''11i.'' || b.application_short_name || ''.?'', i.patch_level) "Patch Level"
      from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
      where (t.application_id = i.application_id)
      AND b.application_id = t.application_id
      and (b.application_id in (''0'', ''50'', ''101'',''178'', ''203'', ''231'', ''275'', ''426'', ''453'', ''603'', ''800'', ''801'',
          ''802'', ''803'', ''804'', ''805'', ''808'', ''809'', ''810'', ''821'', ''8301'', ''8302'', ''8303'',''8401'',''8403''))
      and (l.lookup_type = ''FND_PRODUCT_STATUS'')
      and (l.lookup_code = i.status )
      AND t.language = ''US'' AND l.language = ''US'' order by upper(t.application_name)',   
   'Applications Installation Status (FND_APPLICATION, FND_PRODUCT_INSTALLATIONS)',
   'RS',
   'The above table is the installation status of HRMS related Products and their patch set level.
    If the patch set is not stored in the database a ''?'' is substituted for the patch set letter.',
   '',
   'No product information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
  l_info.delete; 
  
  -- signature for Business groups
  -- PSD #12a
  add_signature(
   'BUSINESS_GROUPS',
   'SELECT  rpad(o.business_group_id,10,'' '') "Bus Grp ID"
            ,rpad(otl.name,20,'' '') "Organization Name   "
			,rpad(o.organization_id,6,'' '')  "Org Id"
			,rpad(o3.ORG_INFORMATION9,8,'' '') "Leg Code"
  			,rpad(hr_general_utilities.get_lookup_meaning(''EMP_NUM_GEN_METHOD'',o3.org_information2),11,'' '') "Emp Num Gen"
  			,rpad(hr_general_utilities.get_lookup_meaning(''APL_NUM_GEN_METHOD'',o3.org_information3),12,'' '') "Appl Num Gen"
  			,rpad(hr_general_utilities.get_lookup_meaning(''CWK_NUM_GEN_METHOD'',o3.org_information16),14,'' '') "Contig Num Gen"
  			,rpad(o3.org_information10,8,'' '') "Currency"
			,rpad(o4.org_information2,7,'' '') "Enabled"
			,rpad(to_char(o.date_from,''DD-Mon-YYYY''),11,'' '') "Date From  "
			,rpad(nvl(to_char(o.date_to,''DD-Mon-YYYY''),''-''),11,'' '') "Date To    "
  		from hr_all_organization_units o , 
  			hr_all_organization_units_tl otl , 
  			hr_organization_information o2 ,
  			hr_organization_information o3 , 
  			hr_organization_information o4 
  		where o.organization_id = otl.organization_id 
  			and o.organization_id = o2.organization_id (+) 
  			and o.organization_id = o3.organization_id 
  			and o.organization_id = o4.organization_id 
  			and o3.org_information_context = ''Business Group Information'' 
  			and o2.org_information_context (+) = ''Work Day Information'' 
  			and o4.org_information_context = ''CLASS'' 
  			and o4.org_information1 = ''HR_BG'' and o4.org_information2 = ''Y'' 
  			and otl.language = ''US''
  			order by   1',
   'Business Group Details (HR_ALL_ORGANIZATION_UNITS )',
   'RS',
   'All business groups details',
   '',
   'No Business Groups exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');

  -- signature for Trading Community Architecture (TCA) for HZ patches
  -- PSD #12a
  l_info.delete;
  l_info(' ') :=  'Trading Community Architecture (TCA) is how other applications 
                   outside of HRMS track Persons and Organizations and Locations.<br>
				   Trading Community Architecture (TCA) is owned by Accounts Receivable (AR).<br>
				   It is important to know what TCA Patchset is installed on an instance.<br>
				   TCA patchsets are designated with the initials HZ.
                  '; -- example using l_info
						
  add_signature(
   'TCA_AR',
   'SELECT bug_number "Patch Number"
             , DECODE(bug_number
				 , ''4442901'', ''R12.HZ.A''
				 , ''5884333'', ''R12.HZ.A.delta.1''
				 , ''6000271'', ''R12.HZ.A.delta.2''
				 , ''6262395'', ''R12.HZ.A.delta.3''
				 , ''6496858'', ''R12.HZ.A.delta.4''
				 , ''7299997'', ''R12.HZ.A.delta.5''
				 , ''7300355'', ''R12.HZ.A.delta.6''
				 , ''4565315'', ''R12.HZ.B''
				 , ''7389406'', ''R12.HZ.B.delta.1''
				 , ''8521996'', ''R12.HZ.B.delta.2''
				 , ''9249344'', ''R12.HZ.B.delta.3''
				 )  patchName
           , to_char(LAST_UPDATE_DATE,''DD-Mon-YYYY'') "Date Applied"
       FROM ad_bugs
       WHERE bug_number in 
             (''4442901'',''5884333'',''6000271'',''6262395'',''6496858'',''7299997'',''7300355'',
              ''4565315'',''7389406'',''8521996'',''9249344'')
       ORDER BY 1
    ',
   'Trading Community Architecture hz patches (owned by AR)',
   'RS',
   'Installed Trading Community Architecture hz patches (owned by AR)',
   '',
   'Trading Community Architecture hz patches (owned by AR) are not installed',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;


  -- signature for Shared HR installed customers ONLY
  -- PSD #12a
  l_info(' ') :=  'Profiles Enabled in shared HR that are not allowed Enabled in shared HR environments'; -- example using l_info
				  
  add_signature(
   'SHARED_HR',
   'select rpad(fpotl.USER_PROFILE_OPTION_NAME,30,'' '') "User Profile Option Name      ",
		   fpov.LEVEL_ID, 
		   fpo.APPLICATION_ID, 
		   DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',''N'',''No'',
			 fpov.PROFILE_OPTION_VALUE) "Profile Option value", 
		   fpov.LEVEL_VALUE 
	from FND_PROFILE_OPTIONS fpo, 
		 FND_PROFILE_OPTIONS_TL fpotl, 
		 FND_PROFILE_OPTION_VALUES fpov
	where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
	and   fpo.PROFILE_OPTION_NAME = ''DATETRACK:ENABLED'' 
	and   fpotl.PROFILE_OPTION_NAME = ''DATETRACK:ENABLED'' 
	and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
	and   fpotl.LANGUAGE = ''US'' 
	and   fpov.PROFILE_OPTION_ID = 1208
	and   fpov.LEVEL_ID IN (10001,10002) 
	and   fpov.LEVEL_VALUE != ''804''
	union
	select fpotl.USER_PROFILE_OPTION_NAME "User Profile Option Name", 
		   fpov.LEVEL_ID lid, 
		   fpo.APPLICATION_ID ,
		   DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',''N'',''No'',
			 fpov.PROFILE_OPTION_VALUE) "Profile Option value", 
		   fpov.level_value  
	from   FND_PROFILE_OPTIONS fpo, 
		   FND_PROFILE_OPTIONS_TL fpotl, 
		   FND_PROFILE_OPTION_VALUES fpov
	where  fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
	and    fpotl.PROFILE_OPTION_NAME = ''PER_ENABLE_DTW4'' 
	and    fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
	and    fpov.LEVEL_ID IN (10001,10002) 
	and    fpotl.LANGUAGE = ''US'' 
	and    fpo.APPLICATION_ID = 800
    ',
   'Shared HR installed customers ONLY',
   'RS',
   'Profiles Enabled in shared HR that needs to be Disabled in shared HR environments <br>',
   'Profiles ''DateTrack:Enabled'' and ''HR: Enable DTW4 defaulting'' are not allowed to be active in a shared HR installed environment. <br>
	These profiles are only allowed to be active and used within fully installed Oracle Human Resources environments.<br>
    <br>
	Leaving these profiles Enabled can cause datetrack records to be created, which is data corruption in shared HR.<br>
    <br>
	Please see the following note and correct the settings for these profiles. <br>
	Note - [1075831.1] - Within ''Shared HR'' Environments What Types of Records Would You Expect to See in HR tables ? <br>
    <br>
	<br>
	To correct profile ''DateTrack:Enabled''  run the following against each of your instances.<br>
    <br>
	UPDATE FND_PROFILE_OPTION_VALUES <br>
	SET PROFILE_OPTION_VALUE = NULL <br>
	where APPLICATION_ID = 803 <br>
	and PROFILE_OPTION_ID = 1208 <br>
	and LEVEL_ID IN (10001,10002) <br>
	and LEVEL_VALUE IN (0,800,801,805,808,809,810,833,8301,8302,8303) <br>
    <br>
	commit<br>
    <br>
    <br>
	To correct profile ''HR: Enable DTW4 defaulting'' perform the following against each of your instances. <br>
    <br>
	navigate to <br>
	System Administrator responsibility ><br>
	Profile ><br>
	System ><br>
	query for the profile and set it to  ''No''  at Site  level > <br>
	Save<br>
    ',
   'Profiles for Shared HR are not available',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  l_step := '44';
  -- signature for person_details
  -- PSD #12a
  -- replace(rpad(ppf.effective_start_date, 11, '' ''), '' '', ''&nbsp;'')
  l_info.delete;
  l_info('Legend') :=  'This section lists the People details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>
						This section lists the Person Name, Type and Party Id for each Effective Date Range.<br>
                        <br>
						Column Meanings<br>
						=================<br>
						A   = CURRENT_APPLICANT_FLAG<br>
						EA  = CURRENT_EMP_OR_APL_FLAG<br>
						E   = CURRENT_EMPLOYEE_FLAG<br>
						NPW = CURRENT_NPW_FLAG (CONTINGENT WORKER)'; -- example using l_info  
  
  add_signature(
   'PERSON_DETAILS',
   'select 
		   rpad(to_char(ppf.effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
         , rpad(to_char(ppf.effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt"
		 , rpad(ppf.full_name, 30, '' '') "Full Name                     "
		 , rpad(ppf.person_id, 9, '' '') "Person Id"
         , rpad(nvl(ppf.employee_number,''-''), 10, '' '') "Emp Number"
         , rpad(nvl(ppf.applicant_number,''-''), 10, '' '') "App Number"
         , rpad(nvl(ppf.npw_number,''-''), 10, '' '') "NPW Number"
         , rpad(ppt.system_person_type || '' - '' || ppt.user_person_type|| '' ('' || ppt.person_type_id || '')'',27,'' '') "Person Type (ID)           "
         , rpad(nvl(ppf.attribute_category,''-''), 10, '' '')      "Attr Categ"
         , rpad(ppf.party_id, 8, '' '')                 "Party ID"
         , rpad(ppf.business_group_id, 10, '' '')       "Bus Grp ID"
         , rpad(nvl(ppf.current_applicant_flag,''-''), 1, '' '')  "A"
         , rpad(nvl(ppf.current_emp_or_apl_flag,''-''), 2, '' '') "EA"
         , rpad(nvl(ppf.current_employee_flag,''-''), 1, '' '')   "E"
         , rpad(nvl(ppf.current_npw_flag,''-''), 3, '' '')        "NPW"
         , rpad(decode(to_char(ppf.SEX),''F'',''(F) Female'',''M'',''(M) Male'',''N'',''(N) Unspecified'',''U'',''(U) Unknown''), 15, '' '')  "Gender         " 
         , rpad(nvl(ppf.email_address,''-''), 30, '' '')          "Email Address                 "
         , rpad(to_char(ppf.start_date,''DD-Mon-YYYY''), 11, '' '')            "Start Date "
         , rpad(nvl(to_char(ppf.original_date_of_hire,''DD-Mon-YYYY''),''-''), 14, '' '')  "Ori Dt of Hire"
         , rpad(nvl(to_char(ppf.comment_id),''-''), 10, '' '')            "Comment ID"
         , rpad(ppf.object_version_number, 7, '' '')  "Obj Ver"
         , rpad(decode(to_char(nvl(ppf.expense_check_send_to_address,''-'')),''h'',''home'', ''o'',''office'',''p'',''provisional'',''-''), 11, '' '')  "Mail To    "
         , rpad(ppf.created_by, 10, '' '')        "Created By"
         , rpad(to_char(ppf.creation_date,''DD-Mon-YYYY''), 13, '' '')     "Creation Date"
         , rpad(ppf.last_updated_by, 11, '' '')   "Last Upd By"
         , rpad(to_char(ppf.last_update_date,''DD-Mon-YYYY''), 13, '' '') "Last Upd Date"
      from
           per_person_types         ppt
         , per_all_people_f         ppf
      where ppf.person_id = ##$$PERID$$##
        and ppf.person_type_id = ppt.person_type_id',
   'Person Details (PER_ALL_PEOPLE_F)',
   'RS',
   'Lists the People details for each Effective Date Range for Person. Also lists the Person Name, Type and Party Id for each Effective Date Range',
   '',
   'No Person details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');
   l_info.delete;
  
  l_step := '44';
  -- signature for person issue - where person exists without effective end date '4712 Dec 31'
  --  replace(rpad(ppf.effective_start_date, 11, '' ''), '' '', ''&nbsp;'') 
  -- PSD #12a
  add_signature(
   'PERSON_ISSUE1',
   'select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(to_char(effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
		  ,rpad(to_char(effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
    from  per_all_people_f
    where person_id = ##$$PERID$$##
    and   not exists (
              select person_id
			        ,count(to_char(effective_end_date,''YYYYMMDD'')) l_end_date
 			  from  per_all_people_f where person_id = ##$$PERID$$## 
			  and   to_char(effective_end_date,''yyyymmdd'') = ''47121231''
              group by Person_id
              having count(to_char(effective_end_date,''YYYYMMDD'')) = 1
			union
			  select person_id, count(to_char(effective_end_date,''YYYYMMDD'')) l_end_date 
              from   per_all_people_f 
			  where  person_id = ##$$PERID$$##
              and    to_char(effective_end_date,''yyyymmdd'') = ''47121231''
              group by Person_id
              having count(to_char(effective_end_date,''YYYYMMDD'')) > 1)',
   'Person Record - issue with Effective End Date (PER_ALL_PEOPLE_F)',
   'RS',
   'This section lists the People details for which there data corruption with 
    no record end dating with 31st Dec 4712 or two records with Effective end date as 31st Dec 4712',
   'Correct the Dates for the Person',
   'No person with this issue of missing person with end dating 31st Dec 4712 or multiple Effective end date with 31s Dec 4712.',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');   

  l_step := '44';
  -- signature for person issue - where person exists dates with gap or overlap of person record
  --   
  -- PSD #12a
  add_signature(
   'PERSON_ISSUE2',
   'select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(to_char(effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
		  ,rpad(to_char(effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
    from  per_all_people_f c
    where person_id = ##$$PERID$$##
    and exists ( select a.person_id,a.effective_start_date, a.effective_end_date,count(a.person_id) 
	             from per_all_people_f a, per_all_people_f b
                 where a.person_id = b.person_id 
                 and a.person_id = c.person_id
                 and trunc(a.effective_end_date) >= trunc(b.effective_start_date+1)
                 and trunc(a.effective_end_date) <= trunc(b.effective_end_date)
                 group by  a.person_id,a.effective_start_date, a.effective_end_date
                 having count(a.person_id) > 1
				)
	union
    select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(to_char(effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
		  ,rpad(to_char(effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
    from  per_all_people_f e
    where person_id = ##$$PERID$$##	
	AND NOT EXISTS (SELECT person_id
                    FROM per_all_people_f c
                    WHERE person_id = e.person_id
                    AND e.person_id = c.person_id
                    AND (SELECT COUNT(*)
                         FROM
                          (SELECT a.person_id,
                                  TO_CHAR(TRUNC(a.effective_start_date),''yyyymmdd''),
                                  TO_CHAR(TRUNC(a.effective_end_date),''yyyymmdd''),
                                  b.effective_start_date,
                                  b.effective_end_date,
                                  COUNT(a.person_id)
                          FROM per_all_people_f a,
                               per_all_people_f b
                          WHERE a.person_id  = b.person_id
                          AND a.person_id    = ##$$PERID$$##
                          AND TRUNC(a.effective_start_date)-1 = TRUNC(b.effective_end_date)
                          AND a.effective_start_date          > b.effective_end_date
                          GROUP BY a.person_id,
                                TO_CHAR(TRUNC(a.effective_start_date),''yyyymmdd''),
                                TO_CHAR(TRUNC(a.effective_end_date),''yyyymmdd''),
                                b.effective_start_date,
                                b.effective_end_date
                          HAVING COUNT(a.person_id) =1
                         ) )  =  (SELECT COUNT(person_id)-1
                                  FROM per_all_people_f d
                                  WHERE d.person_id = c.person_id )
                   )
   ',
   'Person Record - Overlap or Gap in effective dates (PER_ALL_PEOPLE_F)',
   'RS',
   'This section lists the People details for which there data corruption with <br>
    1) Person record with overlapping dates <br> 2) Person Record with gap in effective dates ',
   'Correct the Dates for the Person',
   'No person with this issue with overlapping effective dates or gap in effective dates.',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');   

  l_step := '44';
  -- signature for person issue - where person exists dates with gap or overlap of person record
  --   
  -- PSD #12a
  add_signature(
   'PERSON_ISSUE3',
   'select rpad(person_id, 9, '' '') "Person ID"
          ,rpad(to_char(effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
		  ,rpad(to_char(effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt" 
		  ,rpad(full_name, 30, '' '') "Full Name                     "
		  ,rpad(person_id, 10, '' '') "Person Id"
		  ,rpad(nvl(employee_number,''-''), 10, '' '') "Emp Number"
	from per_all_people_f 
	where person_id = ##$$PERID$$##
	and   date_of_birth is null
   ',
   'Person Record - Missing Date of Birth',
   'RS',
   'Date of Birth missing for person. An Employee cannot be entered on a Payroll without a Date of Birth.',
   '',
   'Person is with Date of Birth data (PER_ALL_PEOPLE_F)',
   'FAILURE',
   'W',
   'RS',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y'); 
   
  l_step := '45';
  -- signature for fnd_user_details
  -- PSD #12a
  add_signature(
   'FND_USER_DETAILS',
   'select rpad(fu.user_name, 20, '' '') "FND User            "
           , rpad(fu.user_id, 15, '' '') "User ID        "
           , rpad(fu.email_address, 30, '' '') "Email Address                 "
           , rpad(to_char(fu.start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
           , rpad(to_char(fu.end_date,''DD-Mon-YYYY''), 11, '' '') "End Date   "
      from fnd_user fu                                                        
      where fu.employee_id in                                                 
           (select papf.person_id                                             
            from per_all_people_f papf                                        
            where papf.person_id = ##$$PERID$$##                                
            and papf.effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY''))',
   'FND User Details (FND_USER)',
   'RS',
   'This section lists defined FND User for PERSON_ID = '||l_person_id,
   '',
   'No FND User details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
  l_step := '46'; 
  
  -- signature for fnd_user_resp_details
  -- PSD #12b
  l_info.delete;
  l_info('Legend') :=  'This section lists the assigned Responsibilities to PERSON_ID = '||l_person_id; -- example using l_info
  
  add_signature(
   'FND_USER_RESP_DETAILS',
   'select rpad(frtl.responsibility_name, 30, '' '') "Responsibility Name           "
           ,rpad(furg.responsibility_id, 10, '' '') "Resp ID   "
           ,rpad(furg.user_id, 10, '' '') "User ID   " 
           ,rpad(to_char(furg.start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date " 
           ,rpad(to_char(furg.end_date,''DD-Mon-YYYY''), 11, '' '') "End date   "
      from fnd_user_resp_groups furg, 
           fnd_responsibility_tl frtl 
      where furg.responsibility_id = frtl.responsibility_id                
      and   user_id in                                                       
            (select user_id                                                   
             from FND_USER FU                                                    
             where fu.employee_id = ##$$PERID$$##)
      order by frtl.responsibility_name',
   'Responsibilities assigned to FND User (FND_USER_RESP_GROUPS,FND_RESPONSIBILITY_TL)',
   'RS',
   '',
   '',
   'No FND User responsibility details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   

  l_info.delete;
  l_info('Legend') :=  'Column Meanings<br>
						=================<br>
						P   = PRIMARY_CONTACT_FLAG<br>
						D   = DEPENDENT_FLAG<br>
						B   = BENEFICIARY_FLAG<br>
						S   = SHARED RESIDENCE<br>
						PF  = PERSONAL RELATIONSHIP<br>
						PR  = PAYMENT RECIPIENT'; -- example using l_info
   
  l_step := '47';
  -- signature for contact_details
  -- PSD #12b
  add_signature(
   'CONTACT_DETAILS',
   'select rpad(to_char(ppf.effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
         , rpad(to_char(ppf.effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt"
		 , rpad(ppf.full_name, 28, '' '') "Full Name                   "
		 , rpad(con.contact_person_id, 11, '' '') "Cont Per ID"
         , rpad(c.meaning, 20, '' '') "Contact Type        "
         , rpad(con.primary_contact_flag, 5, '' '') "P    "
		 , rpad(con.dependent_flag, 5, '' '') "D    "
		 , rpad(con.beneficiary_flag, 5, '' '') "B    "
		 , rpad(con.rltd_per_rsds_w_dsgntr_flag, 5, '' '') "S    "
         , rpad(con.personal_flag, 5, '' '') "PF   "
         , rpad(con.third_party_pay_flag, 5, '' '') "PR   "
         , rpad(con.created_by, 10, '' '') "Created By"
         , rpad(con.last_updated_by,10, '' '') "Updated By"
      from  hr_lookups c, 
            per_contact_relationships con,
            per_all_people_f ppf 
      where c.lookup_type = ''CONTACT''             
      and   c.lookup_code = con.contact_type      
      and   con.contact_person_id = ppf.person_id 
      and   con.person_id = ##$$PERID$$##',
   'Contact details (PER_CONTACT_RELATIONSHIPS)',
   'RS',
   'This section lists Employee Contact details',
   '',
   ' No Contact details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   
  l_info.delete;
   
  l_step := '48';
  
  -- signature for PAYE and NI Aggregation Details
  -- PSD #12b
  add_signature(
   'PAYE_NI_DETAILS',
   'select rpad(to_char(effective_start_date,''DD-Mon-YYYY''),11, '' '') "Start Date "
           , rpad(to_char(effective_end_date,''DD-Mon-YYYY''),11, '' '') "End Date   "
           , rpad(nvl(ppf.per_information2,''-''),11, '' '') "Director   "
           , rpad(nvl(ppf.per_information9,''-''),15, '' '') "NI             "
           , rpad(nvl(ppf.per_information10,''-''),15, '' '') "PAYE           "
      from   per_all_people_f ppf
      where  ppf.person_id = ##$$PERID$$##',
   'Get Aggregation Details (PER_ALL_PEOPLE_F)',
   'RS',
   'This section lists PAYE and NI aggregation details',
   '',
   'No PAYE and NI Aggregation details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   

  l_info.delete;
  l_info('Legend') :=  'This section lists the Assignment details for each Effective Date Range for PERSON_ID = '||l_person_id||'<br>
                        Column Meanings<br>
						=================<br>
						Pri = PRIMARY_FLAG<br>
						AS  = ASSIGNMENT_SEQUENCE<br>
						E   = CURRENT_EMPLOYEE_FLAG<br>
						NPW = CURRENT_NPW_FLAG (CONTINGENT WORKER)'; -- example using l_info

  l_step := '49';
  -- signature for Assignment Details
  -- PSD #12b 
  -- replace(rpad(ppf.effective_start_date, 11, '' ''), '' '', ''&nbsp;'')
  add_signature(
   'ASSIGNMENT_DETAILS',
   'select
          rpad(to_char(paf.effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
        , rpad(to_char(paf.effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt"
        , rpad(to_char(paf.assignment_id), 9, '' '') "Asg ID"
        , rpad(nvl(paf.assignment_number,''-''), 10, '' '') "Asg Number"
        , rpad(nvl(hr_general.decode_lookup(''YES_NO'',paf.primary_flag),''-''), 3, '' '') "Pri"
        ,rpad(nvl(to_char(paf.assignment_sequence),''-''), 7, '' '') "Asg Seq" 
        , rpad(decode(to_char(paf.assignment_type),''A'',''Applicant'',''B'',''Benefits'',''C'',''Contingent'',''E'',''Employee'')
          || '' ('' || paf.assignment_status_type_id || '')'', 20, '' '')     "Asg Type(Type ID)   "
        , rpad(nvl(hr_general.decode_lookup(''PER_ASS_SYS_STATUS'',past.per_system_status),''-''), 20, '' '')  "Asg Status          "
        , rpad(nvl(to_char(paf.organization_id),''-''), 6, '' '') "Org ID"
        , rpad(nvl(to_char(paf.location_id),''-''), 6, '' '') "Loc ID"
        , rpad(nvl(to_char(paf.job_id),''-''), 6, '' '') "Job ID"
        , rpad(nvl(to_char(paf.position_id),''-''), 11, '' '') "Position ID"
        , rpad(nvl(to_char(paf.grade_id),''-''), 8, '' '') "Grade ID"
        , rpad(nvl(to_char(paf.period_of_service_id),''-''), 10, '' '') "PO Serv-ID"
        , rpad(nvl(to_char(paf.business_group_id),''-''), 8, '' '') "BG ID   "
        , rpad(nvl(to_char(paf.pay_basis_id),''-''), 10, '' '') "Pay Bas ID"
        , rpad(nvl(to_char(paf.payroll_id),''-''), 10, '' '') "Payroll ID"
        , rpad(nvl(to_char(paf.supervisor_id),''-''), 10, '' '') "Suprv ID  "
        , rpad(nvl(to_char(paf.vacancy_id),''-''), 10, '' '') "Vacancy ID"
        , rpad(nvl(to_char(paf.object_version_number),''-''), 3, '' '') "OVN"
        , rpad(nvl(to_char(paf.projected_assignment_end) ,''-''), 12, '' '') "Proj Asg End"
        , rpad(paf.created_by, 10, '' '') "Created By"
        , rpad(to_date(paf.creation_date,''DD-Mon-YYYY''), 12, '' '') "Created Date"
        , rpad(paf.last_updated_by, 14, '' '') "Last Update By"
        , rpad(to_char(paf.last_update_date,''DD-Mon-YYYY''), 16, '' '') "Last Update Date"
        , rpad(nvl(to_char(paf.special_ceiling_step_id),'' ''), 20, '' '') "Spec Ceiling Step ID"
      from per_assignments_f          paf
        , per_assignment_status_types past 
      where paf.person_id = ##$$PERID$$##
      and past.assignment_status_type_id = paf.assignment_status_type_id
      order by assignment_id, effective_start_date',
   'Assignment Details (PER_ALL_ASSIGNMENTS_F)',
   'RS',
   'This section lists Employee Assignment details',
   '',
   'No Assignment details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');  
   
  l_info.delete; 

  l_step := '49';
  -- signature for Assignment - More than 1 Primary assignment
  -- PSD #12b
  add_signature(
   'ASSIGNMENT_ISSUE1',
   'select rpad(a.assignment_id, 13, '' '') "Assignment ID"
          ,rpad(nvl(a.assignment_number,''-''), 10, '' '') "Assign Num"
          ,rpad(a.person_id, 9, '' '') "Person ID"
          ,rpad(to_char(a.effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
          ,rpad(to_char(a.effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt"
		  ,rpad(a.primary_flag, 9, '' '') "Prim Flag" 
    from per_all_assignments_f a, per_all_assignments_f b
    where a.assignment_id <> b.assignment_id
    and   (a.effective_start_date between b.effective_start_date and b.effective_end_date
           or
           a.effective_end_date between b.effective_start_date and b.effective_end_date)
    and   a.primary_flag = ''Y'' and b.primary_flag = ''Y''       
    and   a.person_id = b.person_id
    and   a.person_id = ##$$PERID$$##',
   'Assignments Issue - Primary Flag',
   'RS',
   'This section lists the Assignment with two Primary Assignments active at the same point of time.',
   '',
   'No Assignment with multiple Primary Flag (PER_ALL_ASSIGNMENTS_F)',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');  

  l_step := '49';
  -- signature for Assignment - Overlap of active primary assignment
  -- PSD #12b
  add_signature(
   'ASSIGNMENT_ISSUE2',
   'select rpad(c.assignment_id, 13, '' '') "Assignment ID"
          ,rpad(nvl(c.assignment_number,''-''), 10, '' '') "Assign Num"
          ,rpad(c.person_id, 9, '' '') "Person ID"
          ,rpad(to_char(c.effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
          ,rpad(to_char(c.effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Effe End Dt"
		  ,rpad(nvl(to_char(c.assignment_status_type_id),''-''), 14, '' '') "Asg St Type ID" 
		  ,rpad(nvl(d.user_status,''-''), 22, '' '') "Assignment User Status" 
    from per_all_assignments_f c, per_assignment_status_types  d
    where c.person_id = ##$$PERID$$##
    and c.assignment_status_type_id = d.assignment_status_type_id
    and c.Primary_flag = ''Y''
    and c.assignment_status_type_id = 1
    and exists (select a.person_id,a.effective_start_date, a.effective_end_date,count(a.person_id) 
	             from per_all_assignments_f a, per_all_assignments_f b
                 where a.person_id = b.person_id 
                 and a.person_id = c.person_id
                 and trunc(a.effective_end_date) >= trunc(b.effective_start_date+1)
                 and trunc(a.effective_end_date) <= trunc(b.effective_end_date)
                 and a.assignment_id = b.assignment_id
                 and a.assignment_id = c.assignment_id
                 group by  a.person_id,a.effective_start_date, a.effective_end_date
                 having count(a.person_id) > 1
            )
	',
   'Assignments Issue - Overlap effective date (PER_ALL_ASSIGNMENTS_F)',
   'RS',
   'This section lists the Assignment with Primary Active Assignment with overlap of effective date.',
   '',
   'No Assignment with Overlap of effective date ',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y'); 

  l_info.delete;
  l_info('Legend') :=  'This section lists Assignment records if any Gap in Primary Assignment is found for PERSON_ID = '||l_person_id||' <br>
						No rows means no gaps found in Primary Assignment.<br> '; -- example using l_info
						   
  -- signature for Assignment - Gap of active primary assignment details
  -- PSD #12b
  add_signature(
   'ASSIGNMENT_ISSUE3',
   'SELECT distinct rpad(papf.person_id, 9, '' '') "Person ID"
          ,rpad(paaf.assignment_id, 9, '' '') "Assign ID"
          ,rpad(to_char(paaf.effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
          ,rpad(to_char(paaf.effective_end_date,''DD-Mon-YYYY''), 11, '' '') "End Date   "
		  ,rpad(decode(to_char(paaf.assignment_type),''A'',''Applicant'',''B'',''Benefits'',''C'',''Contingent'',''E'',''Employee'')
                  || '' ('' || paaf.assignment_status_type_id || '')'', 20, '' '') "Assignment Type (id)"
		  ,rpad(nvl(HR_GENERAL.DECODE_LOOKUP(''PER_ASS_SYS_STATUS'',past.per_system_status),''-''), 17, '' '') "Assignment Status" 
      FROM apps.per_all_people_f papf,
           apps.per_all_assignments_f  paaf,
           apps.per_assignment_status_types past
      WHERE papf.person_id = ##$$PERID$$##
      AND paaf.person_id = papf.person_id
      AND paaf.primary_flag = ''Y''
      AND(paaf.effective_start_date BETWEEN papf.effective_start_date AND papf.effective_end_date
      OR  paaf.effective_end_date BETWEEN papf.effective_start_date AND papf.effective_end_date)
      AND past.assignment_status_type_id = paaf.assignment_status_type_id
      AND paaf.person_id IN
            (SELECT a.person_id
             FROM apps.per_all_assignments_f a
             WHERE a.primary_flag = ''Y''
             AND exists
                (SELECT asub.assignment_id
                 FROM apps.per_all_assignments_f asub
                 WHERE asub.primary_flag = ''Y''
                 and asub.person_id = a.person_id
                 AND asub.effective_start_date > a.effective_end_date)  
             AND NOT exists
                (SELECT asub1.assignment_id
                 FROM apps.per_all_assignments_f asub1
                 WHERE asub1.primary_flag = ''Y''
                 AND asub1.person_id = a.person_id
                 AND asub1.effective_start_date = a.effective_end_date + 1))
      ORDER BY 1, 2, 3
	',
   'Gaps in Primary Assignment details (PER_ALL_ASSIGNMENTS_F)',
   'RS',
   'This section lists Assignment records if any Gap in Primary Assignment is found for PERSON_ID = '||l_person_id,
   '',
   'No gaps found in Primary Assignment',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');    
   l_info.delete;
   
   l_step := '491';
  
  -- signature for Payroll PAYE Reference Details
  -- PSD #12b
  add_signature(
   'PAYROLL_PAYE_DETAILS',
   'SELECT rpad(papf.payroll_id,10,'' '') "Payroll ID",
           rpad(papf.payroll_name,30,'' '') "Payroll Name                  ",
           rpad(to_char(papf.effective_start_date,''DD-Mon-YYYY''),20,'' '') "Effective Start Date",
           rpad(to_char(papf.effective_end_date,''DD-Mon-YYYY''),18,'' '') "Effective End Date",
           rpad(flex.segment1,11,'' '') "Payee Refe ",
           rpad(flex.segment10,11,'' '') "Unique ID  ",
           rpad(flex.segment14,20,'' '') "ECON                ",
           rpad(flex.segment4,7,'' '') MAX_HOL,
           rpad(flex.segment9,4,'' '') BACS
      FROM hr_soft_coding_keyflex flex, 
           pay_all_payrolls_f papf 
      WHERE papf.soft_coding_keyflex_id = flex.soft_coding_keyflex_id 
      AND EXISTS (SELECT 1 FROM per_all_assignments_f paaf            
                  WHERE person_id = ##$$PERID$$##
                  AND paaf.payroll_id = papf.payroll_id)              
      ORDER BY papf.payroll_id,                                       
               papf.payroll_name,                                     
               to_date(papf.effective_start_date,''DD-MON-YYYY'')',
   'Payroll PAYE Ref details (PAY_ALL_PAYROLLS_F, HR_SOFT_CODING_KEYFLEX)',
   'RS',
   'This section lists the Person Type Usage for each Effective Date Range for PERSON_ID = '||l_person_id,
   '',
   'No Payroll PAYE reference details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  l_info.delete;
  l_info('Legend') :=  'This section lists the Assignment Action details for PERSON_ID = '||l_person_id||' <br>
						<br>
						Payroll Action STATUS<br>
						=====================<br>
						U   unprocessed<br>
                        P   processed<br>
                        M   marked for retry<br>
                        C   complete<br>
                        E   error'; -- example using l_info  
     
  l_step := '492';
  -- signature for Assignment Action Details
  -- PSD #12b
  add_signature(
   'ASG_ACT_DETAILS',
   'SELECT DISTINCT
		rpad(nvl(( SELECT DISTINCT fcp.user_concurrent_program_name
		  FROM fnd_concurrent_programs_tl fcp
		  WHERE source_lang = ''US''
		  AND fcp.concurrent_program_id =
			  ( SELECT DISTINCT fcr.concurrent_program_id
			    FROM fnd_concurrent_requests fcr
			    WHERE fcr.request_id =
					  ( SELECT DISTINCT ppa.request_id
					    FROM pay_payroll_actions ppa
					    WHERE ppa.payroll_action_id = pact.payroll_action_id))),''-''),30,'' '') "Conc Prog Name"
	  ,rpad(act.assignment_id, 9, '' '') "Assign ID"
	  ,rpad(to_char(pact.effective_date,''DD-Mon-YYYY''), 11, '' '') "Effec Date "
	  ,rpad(decode(pact.action_type
			  ,''A'',''Cash''
			  ,''B'',''Bal Adj''
			  ,''C'',''Costing''
			  ,''CP'',''Cost Pay''
			  ,''H'',''Cheq writ''
			  ,''L'',''Retro by Ele''
			  ,''M'',''Mag txr''
			  ,''O'',''Retropay''
			  ,''P'',''Prepay''
			  ,''Q'',''Quickpay''
			  ,''R'',''Payroll Run''
			  ,''S'',''Retro Cost''
			  ,''T'',''Tfr to GL''
			  ,''U'',''Quick Prepay''
			  ,''V'',''Reversal''
			  ,''X'',''Mag Rept''
			  ,pact.action_type), 11, '' '') "Action Type"
	  ,rpad(act.action_sequence, 10, '' '') "Action Seq"
	  ,rpad(act.assignment_action_id, 10, '' '') "Ass Act ID"
	  ,rpad(act.source_action_id, 9, '' '') "Source   "
	  ,rpad(act.action_status, 14, '' '') "Ass Act Status"
	  ,rpad(pact.action_status, 14, '' '') "Pay Act Status"
	  ,rpad(pact.payroll_action_id, 10, '' '') "Pay Act ID"
	  ,rpad(to_char(pact.start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
	  ,rpad(to_char(pact.end_date,''DD-Mon-YYYY''), 11, '' '') "End Date   "
	  ,rpad(pact.legislative_parameters, 11, '' '') "Leg Params "
	  ,rpad(to_char(pact.creation_date,''DD-Mon-YYYY''), 11, '' '') "Creation Dt"
    FROM pay_payroll_actions pact
		,pay_assignment_actions act
	 	,per_all_assignments_f paaf
	 WHERE act.payroll_action_id = pact.payroll_action_id
	 AND act.assignment_id = paaf.assignment_id
	 AND paaf.person_id = ##$$PERID$$##
	 ORDER BY "Assign ID", "Effec Date " DESC, "Action Seq" DESC',
   'Assignment Action Details (PAY_PAYROLL_ACTIONS, PAY_ASSIGNMENT_ACTIONS, PER_ALL_ASSIGNMENTS_F)',
   'RS',
   'This section lists the Assignment Action details for PERSON_ID ='||l_person_id,
   '',
   'No Assignment Action details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   
   l_info.delete;
  
  -- signature for Grade Details
  -- PSD #12b
  
  l_info.delete;
  l_info('Legend') :=  'This section lists the Grade Step details for PERSON_ID = '||l_person_id||' <br>';

  add_signature(
   'GRADE_DETAILS',
   'select distinct                                        
        rpad(to_char(pspf.effective_start_date,''DD-Mon-YYYY''),11, '' '') "Start Date ",
        rpad(to_char(pspf.effective_end_date,''DD-Mon-YYYY''),11, '' '') "End Date   ",
        rpad(pg.grade_id, 9, '' '') "Grade ID",
        rpad(pg.name, 20, '' '') "Grade Name          ",
        rpad(pps.name, 20, '' '') "Spine Name          ",
        rpad(pspf.step_id, 7, '' '') "Step ID",
        rpad(psp.spinal_point, 12, '' '') "Spinal Point",
        rpad(pspsf.sequence, 4, '' '') Step
    from                                                   
        per_all_people_f ppf,                              
        per_all_assignments_f paf,                         
        per_spinal_point_placements_f pspf,                
        per_spinal_point_steps_f pspsf,                    
        per_grade_spines_f pgs,                            
        per_grades pg,                                     
        per_spinal_points psp,                             
        per_parent_spines pps                              
    where pg.grade_id =  paf.grade_id                      
    and ppf.person_id = ##$$PERID$$##
    and ppf.person_id = paf.person_id
    and paf.assignment_id = pspf.assignment_id             
    and pgs.parent_spine_id = pspf.parent_spine_id         
    and pg.grade_id = pgs.grade_id                         
    and pps.parent_spine_id = pgs.parent_spine_id          
    and pspsf.spinal_point_id = psp.spinal_point_id
    and pspsf.spinal_point_id = psp.spinal_point_id
    and pspsf.grade_spine_id = pgs.grade_spine_id
    and pspsf.step_id = pspf.step_id 
    order by "Start Date "',
   'Grade Step details <br> (PER_SPINAL_POINT_PLACEMENTS_F, PER_SPINAL_POINT_STEPS_F, <br> PER_GRADE_SPINES_F, PER_GRADES,PER_SPINAL_POINTS, PER_PARENT_SPINES)',
   'RS',
   '',
   '',
   'No Grade Step details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Absence Details
  -- PSD #12b

  l_info.delete;
  l_info('Legend') :=  'This section lists the Absence details for PERSON_ID = '||l_person_id||' <br>
						'; -- example using l_info    
    
  add_signature(
   'ABSENCE_DETAILS',
   'select                                                                                                            
          rpad(to_char(nvl(paa.date_start,paa.DATE_PROJECTED_START),''DD-Mon-YYYY''), 11,'' '') "Start Date ",
          rpad(to_char(nvl(paa.date_end,paa.date_projected_end),''DD-Mon-YYYY''),11,'' '') "End Date   ",
          rpad(decode(nvl(paa.date_start,''01-JAN-4712''),
                to_date(''01-JAN-4712'',''DD-MON-YYYY''),''Projected'',''Actual''),8,'' '') "Act/Proj",
          rpad(pat.name,25,'' '') "Reason                   ",
          rpad(paa.absence_days,6,'' '') "Days  ",
          rpad(paa.absence_hours,6,'' '') "Hours ",
          rpad(paa.occurrence,10,'' '') "Occurrence",
          rpad(paa.object_version_number, 4,'' '') "OVN "
    from  per_absence_attendances paa,
          per_absence_attendance_types pat 
    where paa.person_id = ##$$PERID$$##
    and   paa.absence_attendance_type_id = pat.absence_attendance_type_id
    order by "Start Date "',
   'Absence details (PER_ABSENCE_ATTENDANCES,PER_ABSENCE_ATTENDANCE_TYPES)',
   'RS',
   'This section lists the Absence details',
   '',
   'No Absence details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Event Details
  -- PSD #12b

  l_info.delete;
  l_info('Legend') :=  'This section lists the EVENT details for PERSON_ID = '||l_person_id||' <br>
						'; -- example using l_info      
    
  add_signature(
   'EVENT_DETAILS',
   'select distinct                                          
           rpad(assignment_id, 9,'' '') "Assign ID"
           ,rpad(event_id, 9,'' '') "Event ID "
           ,rpad(to_char(date_start,''DD-Mon-YYYY''), 11,'' '') "Event Start"
           ,rpad(to_char(date_end,''DD-Mon-YYYY''), 11,'' '') "Event End  "                  
           ,rpad(type, 10,'' '') "Event Type"                    
           ,rpad(event_or_interview, 18,'' '') "Event Or Interview"
        from per_events pe                                       
        where assignment_id in                                   
              (select distinct paf.assignment_id                     
               from per_all_assignments_f paf, per_all_people_f ppf  
               where ppf.person_id = ##$$PERID$$##                     
               and paf.person_id = ppf.person_id)                    
        order by "Assign ID","Event Start"',
   'Event Details (PER_EVENTS)',
   'RS',
   'This section lists the EVENT details',
   '',
   'No Event details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Application Details
  -- PSD #12b
  
  l_info('Legend') :=  'This section lists the Application details for PERSON_ID = '||l_person_id||' <br>
						'; -- example using l_info       
  
  add_signature(
   'APPL_DETAILS',
   'select distinct                                          
           rpad(application_id, 9,'' '') "Appl ID  "
           ,rpad(business_group_id, 9,'' '') "BG ID    "
           ,rpad(to_char(date_received,''DD-Mon-YYYY''), 13,'' '') "Date Received"
           ,rpad(to_char(date_end,''DD-Mon-YYYY''), 11,'' '') "Date End  "
           ,rpad(object_version_number, 3,'' '') "OVN"
           ,rpad(created_by, 10,'' '') "Created By"
           ,rpad(last_updated_by, 11,'' '') "Updated By "
        from per_applications                                        
        where person_id = ##$$PERID$$##',
   'Application Details (PER_APPLICATIONS)',
   'RS',
   'This section lists the Application details',
   '',
   'No Application details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for People Reporting Details
  -- PSD #12b
  
  l_info('Legend') :=  'This section lists the people reporting to PERSON_ID = '||l_person_id||' <br>
						'; -- example using l_info      
  
  add_signature(
   'PPL_REPORT_DETAILS',
   'select distinct
           rpad(full_name, 30, '' '') "Full Name                     "
           ,rpad(employee_number, 11, '' '') "Emp Number "
           ,rpad(person_id, 9, '' '') "Person ID"
    from per_all_people_f
    where person_id in (
           select paf.person_id
           from  per_all_assignments_f paf
           start with paf.person_id = ##$$PERID$$##
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           connect by PRIOR paf.person_id = paf.supervisor_id
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           minus
           select paf.person_id
           from  per_all_assignments_f paf
           where paf.person_id =  ##$$PERID$$## )
           and sysdate between effective_start_date and effective_end_date',
   'People Reporting To This Person',
   'RS',
   'This section lists the people reporting',
   '',
   'No People reporting to this person exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Person Reporting Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists who PERSON_ID = '||l_person_id||' reports to <br> '; -- example using l_info      
  
  add_signature(
   'PERSON_REPORT_DETAILS',
   'select distinct
           rpad(full_name, 35, '' '') "Full Name"
           ,rpad(employee_number, 11, '' '') "Emp Number "
           ,rpad(person_id, 9, '' '') "Person ID"
    from per_all_people_f
    where person_id in (
           select paf.person_id
           from  per_all_assignments_f paf
           start with paf.person_id = ##$$PERID$$##
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           connect by PRIOR paf.supervisor_id = paf.person_id
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           minus
           select paf.person_id
           from  per_all_assignments_f paf
           where paf.person_id = ##$$PERID$$## )
           and sysdate between effective_start_date and effective_end_date',
   'Who This Person Reports To',
   'RS',
   'This section lists who this person reports to',
   '',
   'This Person does not reports to other person',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Person Security Profiles assigned Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Security Profiles assigned to PERSON_ID = '||l_person_id||' <br> '; 
  
  add_signature(
   'PER_SEC_PROF_DETAILS',
   'select rpad(pspa.user_id , 10, '' '') "User ID   "
           ,rpad(pspa.sec_profile_assignment_id, 15, '' '') "Sec Prof Asg ID"
           ,rpad(pspa.security_group_id, 10, '' '') "Sec Grp ID"
           ,rpad(pspa.security_profile_id, 11, '' '') "Sec Prof ID"
           ,rpad(pspa.responsibility_id, 10, '' '') "Resp ID   "
           ,rpad(pspa.responsibility_application_id, 12, '' '') "Resp Appl ID"
           ,rpad(to_char(pspa.start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
           ,rpad(to_char(pspa.end_date,''DD-Mon-YYYY''), 11, '' '') "End Date   "
           ,rpad(frtl.responsibility_name, 30, '' '') "Responsibility Name           "
    from per_sec_profile_assignments pspa,              
         fnd_responsibility_tl frtl                     
    where pspa.user_id =                                
         (select fuser.user_id from fnd_user fuser      
          where fuser.employee_id = ##$$PERID$$##)        
    and pspa.responsibility_id = frtl.responsibility_id 
    and frtl.language = ''US''                            
    order by "Start Date ", "Responsibility Name           "',
   'PER Security Profile Assigned to Employee details (PER_SEC_PROFILE_ASSIGNMENTS)',
   'RS',
   'This section lists the Security Profiles assigned',
   '',
   'No Person Security Profiles assigned to employee',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Employee Supplier Details
  -- PSD #12b
  -- If 11i release, ap_suppliers table does not exists. 
  --    instead use the table 
  l_info('Legend') :=  'This section lists the Employee Supplier record for PERSON_ID = '||l_person_id||' within 
                        table AP_SUPPLIERS column EMPLOYEE_ID = PERSON_ID <br> '; 
  
  if g_rep_info('Apps Version') like '11.5%' then
    add_signature(
     'EMP_SUPL_DETAILS',
     'select rpad(vendor_id, 10, '' '') "Vendor ID "
             ,rpad(vendor_name, 30, '' '') "Vendor Name                   "
             ,rpad(employee_id, 11, '' '') "Employee ID"
             ,rpad(to_char(start_date_active,''DD-Mon-YYYY''), 11, '' '') "Start Date "
             ,rpad(to_char(end_date_active,''DD-Mon-YYYY''), 11, '' '') "End Date   "
             ,rpad(created_by, 10, '' '') "Created By"
             ,rpad(to_char(creation_date,''DD-Mon-YYYY''), 11, '' '') "Created    "
             ,rpad(last_updated_by, 11, '' '') "Updated By "
             ,rpad(to_char(last_update_date,''DD-Mon-YYYY''), 11, '' '') "Updated    "
      from  po_vendors 
      where employee_id = to_char(##$$PERID$$##)',
     'Employee Supplier Details (AP_SUPPLIERS)',
     'RS',
     'This section lists the Employee Supplier record. Within table AP_SUPPLIERS column EMPLOYEE_ID = PERSON_ID ',
     '',
     'No Employee Supplier details exists',
     'ALWAYS',
     'I',
     'Y',
     'N',
     l_info);
  else 
    add_signature(
     'EMP_SUPL_DETAILS',
     'select rpad(vendor_id, 10, '' '') "Vendor ID "
             ,rpad(vendor_name, 30, '' '') "Vendor Name                   "
             ,rpad(employee_id, 11, '' '') "Employee ID"
             ,rpad(to_char(start_date_active,''DD-Mon-YYYY''), 11, '' '') "Start Date "
             ,rpad(to_char(end_date_active,''DD-Mon-YYYY''), 11, '' '') "End Date   "
             ,rpad(created_by, 10, '' '') "Created By"
             ,rpad(to_char(creation_date,''DD-Mon-YYYY''), 11, '' '') "Created    "
             ,rpad(last_updated_by, 11, '' '') "Updated By "
             ,rpad(to_char(last_update_date,''DD-Mon-YYYY''), 11, '' '') "Updated    "
             ,rpad(party_id, 8, '' '') "Party ID"
      from  ap_suppliers 
      where employee_id = to_char(##$$PERID$$##)',
     'Employee Supplier Details (AP_SUPPLIERS)',
     'RS',
     'This section lists the Employee Supplier record. Within table AP_SUPPLIERS column EMPLOYEE_ID = PERSON_ID ',
     '',
     'No Employee Supplier details exists',
     'ALWAYS',
     'I',
     'Y',
     'N',
     l_info);
  end if;
  l_info.delete;
  
  -- signature for Location Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Location details for each distinct active assignment record <br> '; 
  
  add_signature(
   'LOC_DETAILS',
   'select rpad(paf.assignment_number, 10, '' '') "Asg Number"
           ,rpad(paf.location_id, 6, '' '') "Loc ID"
           ,rpad(hla.style, 8, '' '') "Style   "
           ,rpad(hla.description, 30, '' '') "Description                   "
           ,rpad(to_char(hla.creation_date,''DD-Mon-YYYY''), 13, '' '') "Creation Date" 
           ,rpad(to_char(hla.inactive_date,''DD-Mon-YYYY''), 13, '' '') "Inactive Date"
      from per_all_assignments_f paf, 
           hr_locations_all hla
      where paf.person_id = ##$$PERID$$##
      and   paf.assignment_status_type_id = 1
      and   paf.location_id = hla.location_id
      and   paf.effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY'')
      order by paf.assignment_number',
   'Location Details (HR_LOCATIONS_ALL)',
   'RS',
   'This section lists the Location details for each distinct active assignment record',
   '',
   'No Location details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Period of Service Details 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Periods of Service details for each Effective Date Range for PERSON_ID = '||l_person_id ||'<br> '; 
  
  add_signature(
   'PERIOD_SER_DETAILS',
   'select  rpad(period_of_service_id, 16, '' '') "Period of Ser ID"
           ,rpad(business_group_id, 7, '' '') "BG ID  "
           ,rpad(to_char(date_start,''DD-Mon-YYYY''), 11, '' '') "Date Start "
           ,rpad(to_char(accepted_termination_date,''DD-Mon-YYYY''), 13, '' '') "Acptd Term Dt"
           ,rpad(to_char(actual_termination_date,''DD-Mon-YYYY''), 11, '' '') "Act Term Dt"
           ,rpad(to_char(final_process_date,''DD-Mon-YYYY''), 13, '' '') "Final Proc Dt"
           ,rpad(to_char(notified_termination_date,''DD-Mon-YYYY''), 16, '' '') "Notified Term Dt"
           ,rpad(leaving_reason, 15, '' '') "Leaving Reason "
           ,rpad(nvl(to_char(last_standard_process_date,''DD-Mon-YYYY''),''-''), 17, '' '') "Last Stnd Proc Dt"
           ,rpad(nvl(to_char(adjusted_svc_date,''DD-Mon-YYYY''),''-''), 11, '' '') "Adj Serv Dt"
           ,rpad(created_by, 10, '' '') "Created By"
           ,rpad(to_char(creation_date,''DD-Mon-YYYY''), 12, '' '') "Created Date"
           ,rpad(last_updated_by, 11, '' '') "Last Upd By"
           ,rpad(to_char(last_update_date,''DD-Mon-YYYY''), 13, '' '') "Last Upd Date"
           ,rpad(object_version_number, 3, '' '') "OVN"
    from  per_periods_of_service
    where person_id = ##$$PERID$$##
    order by period_of_service_id',
   'Periods of Service Details (PER_PERIODS_OF_SERVICE)',
   'RS',
   'This section lists the Periods of Service details for each effective date range',
   '',
   'No Periods of Service details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Period of Placements Details 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Periods of Placement details for each Effective Date Range for PERSON_ID = '||l_person_id ||'
                        PER_PERIODS_OF_PLACEMENT is used for CONTINGENT WORKER records in place of table PER_PERIODS_OF_SERVICE <br> '; 
  
  add_signature(
   'PERIOD_PLACEMENTS_DETAILS',
   'select rpad(period_of_placement_id, 9, '' '') "Period Of Plac ID"
         , rpad(to_char(date_start,''DD-Mon-YYYY''), 11, '' '') "Date Start "
         , rpad(to_char(last_standard_process_date,''DD-Mon-YYYY''), 17, '' '') "Last Stnd Proc Dt"
         , rpad(to_char(actual_termination_date,''DD-Mon-YYYY''), 11, '' '') "Act Term Dt"
         , rpad(to_char(final_process_date,''DD-Mon-YYYY''), 13, '' '') "Final Proc Dt"
         , rpad(created_by, 10, '' '') "Created By"
         , rpad(last_updated_by, 10, '' '') "Updated By"
    from per_periods_of_placement
    where person_id = ##$$PERID$$##
    order by 1,2',
   'Period of Placements Details (PER_PERIODS_OF_PLACEMENT)',
   'RS',
   'This section lists the Periods of Placement details for each Effective Date Range.
   PER_PERIODS_OF_PLACEMENT is used for CONTINGENT WORKER records in place of table PER_PERIODS_OF_SERVICE',
   '',
   'No Period of Placements details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Person Type Usage Details 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Person Type Usage for each Effective Date Range for PERSON_ID = '||l_person_id ||' <br> '; 
						
  add_signature(
   'PER_TYPE_USAGE_DETAILS',
   'select   rpad(ptu.person_type_usage_id, 10, '' '') "Per Type Usage ID"
           , rpad(to_char(ptu.effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Eff Strt Dt"
           , rpad(to_char(ptu.effective_end_date,''DD-Mon-YYYY''), 11, '' '') "Eff End Dt "
           , rpad(ppt.system_person_type || '' - '' || ppt.user_person_type 
		     || '' ('' || ptu.person_type_id || '')'' , 30, '' '') "Per Type                      "
           , rpad(ptu.object_version_number, 3, '' '') "OVN"
           , rpad(ptu.created_by, 10, '' '') "Created By"
           , rpad(to_char(ptu.creation_date,''DD-Mon-YYYY''), 12, '' '') "Created Date"
           , rpad(ptu.last_updated_by, 10, '' '') "Updated By"
           , rpad(to_char(ptu.last_update_date,''DD-Mon-YYYY''), 12, '' '') "Updated Date"
    from   per_person_type_usages_f ptu
           , per_person_types ppt
    where    ptu.person_id = ##$$PERID$$##
    and      ptu.person_type_id = ppt.person_type_id
    order by 1,2',
   'Person Type Usage Details (PER_PERSON_TYPE_USAGES_F)',
   'RS',
   'This section lists the Person Type Usage for each Effective Date Range',
   '',
   'No Person Type Usage details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;
   
  -- signature for Person Address Details 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Person Type Usage for each Effective Date Range for PERSON_ID = '||l_person_id ||' <br> '; 
  
  add_signature(
   'PER_ADDRESS_DETAILS',
   'select rpad(address_id, 10, '' '') "Address ID"
         , rpad(business_group_id, 7, '' '') "BG ID  "
         , rpad(style, 10, '' '') "Style     "
         , rpad(to_char(date_from,''DD-Mon-YYYY''), 11, '' '') "Date From  "
         , rpad(to_char(date_to,''DD-Mon-YYYY''), 11, '' '') "Date To    "
         , rpad(hr_general.decode_lookup(''YES_NO'',primary_flag), 8, '' '') "Pri Flag"
         , rpad(party_id, 8, '' '') "Party ID"
         , rpad(town_or_city, 20, '' '') "Town or City        "
         , rpad(region_1, 20, '' '') "County              "
         , rpad(region_2, 6, '' '') "State"
         , rpad(postal_code, 11, '' '') "Postal Code"
         , rpad(created_by, 10, '' '') "Created By"
         , rpad(last_updated_by, 10, '' '') "Updated By"
         , rpad(add_dtls.meaning, 30, '' '') "Address Type                  "
    from per_addresses, 
         (select lookup_type,language,lookup_code,meaning, enabled_flag,start_date_active,end_date_active 
          from fnd_lookup_values 
          where lookup_type = ''ADDRESS_TYPE'' and language = ''US'' ) add_dtls
    where person_id = ##$$PERID$$##
    and   add_dtls.lookup_code = address_type
    order by 4',
   'Person Address Details (PER_ADDRESSES)',
   'RS',
   'This section lists the Address details for each effective date range',
   '',
   'No Person Address details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Address validation table counts 
  -- PSD #12b
  add_signature(
   'ADDRESS_VALID_TABLE_COUNTS',
   'SELECT ''PAY_US_CITY_NAMES row count = ''|| count(*) "Address Validation Counts"
    FROM PAY_US_CITY_NAMES 
    union
    SELECT ''PAY_US_COUNTIES   row count = ''|| count(*)
    FROM PAY_US_COUNTIES 
    union
    SELECT ''PAY_US_STATES     row count = ''|| count(*)
    FROM PAY_US_STATES 
    union
    SELECT ''PAY_US_ZIP_CODES  row count = ''|| count(*)
    FROM PAY_US_ZIP_CODES',
   'Address validation table counts (PAY_US_CITY_NAMES  PAY_US_COUNTIES  PAY_US_STATES  PAY_US_ZIP_CODES)',
   'RS',
   'This section lists a count for each Geocode Address table',
   '',
   '',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
     
  -- signature for Address Styles Details 
  -- PSD #12b
  add_signature(
   'ADDRESS_STYLE_DETAILS',
   'select style,
           count(*) "Count"
    from per_addresses
    group by style',
   'Address Styles (PER_ADDRESSES)',
   'RS',
   'This section lists a count of each address style from table PER_ADDRESSES',
   '',
   'No Address Styles details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Person Analysis Details 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Person Analysis details for each Effective Date Range for PERSON_ID = '||l_person_id ||' <br> '; 
  
  add_signature(
   'PERSON_ANALYSIS_DETAILS',
   'select rpad(person_analysis_id, 15, '' '') "Per Analysis ID"
         , rpad(business_group_id, 7, '' '') "BG ID  "
         , rpad(analysis_criteria_id, 15, '' '') "Analysis Cri ID"
         , rpad(to_char(date_from,''DD-Mon-YYYY''), 11, '' '') "Date from  "
         , rpad(to_char(date_to,''DD-Mon-YYYY''), 11, '' '') "Date To    "
         , rpad(object_version_number, 3, '' '') "OVN"
         , rpad(party_id, 8, '' '') "Party ID"
         , rpad(created_by, 10, '' '') "Created By"
         , rpad(last_updated_by, 10, '' '') "Updated By"
    from per_person_analyses
    where person_id = ##$$PERID$$##
    order by 4',
   'Person Analysis Details (PER_PERSON_ANALYSES)',
   'RS',
   'This section lists the Person Analysis details for each Effective Date Range',
   '',
   'No Person Analysis details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Benefits Payroll Details 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Benefits Payroll details for PERSON_ID = '||l_person_id ||' <br> '; 
  
  add_signature(
   'BENEFITS_PAYROLL_DETAILS',
   'select distinct rpad(ppf.payroll_name, 30, '' '') "Default Benefits Payroll      "
      from
         hr_organization_information hoi,
         pay_payrolls_f ppf,
         per_all_people_f pf,
         per_organization_units pou
      where hoi.organization_id = pou.organization_id
      and pf.business_group_id = pou.business_group_id
      and hoi.org_information_context like ''Benefit%''
      and ppf.payroll_id = hoi.org_information2
      and pf.person_id = ##$$PERID$$##',
   'Benefits Payroll details <br> (PAY_PAYROLLS_F,PER_ALL_PEOPLE_F, PER_ORGANIZATION_UNITS, HR_ORGANIZATION_INFORMATION)',
   'RS',
   'This section lists the Benefits Payroll details',
   '',
   'No Benefits Payroll details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for WF Local Roles 
  -- PSD #12b
  l_info.delete;
  l_info('Legend') :=  'This section lists the WF_LOCAL_ROLES details for PERSON_ID = '||l_person_id||' <br>
                        The corresponding PERSON_ID column in table WF_LOCAL_ROLES is ORIG_SYSTEM_ID <br> <br> 
						Records listed under column ''Originating System'' in table WF_LOCAL_ROLES: <br><br>

						<ul>
						  <li>PER_ROLE - HR apps creates this record when EMP is hired. </li>
						  <li>PER      - ATG apps creates this record when FND_USER is attached to an employee</li>
						  <li>HZ_PARTY - AP apps creates this record when an AP vendor is created</li>
						  <li>POS      - POS approver type record is created when a Position is assigned to an Employee who is attached to an FND user</li> 
						</ul>
						HR support is ONLY responsible for the data stored in the PER_ROLE and POS records in this table.<br> 
						'; -- example using l_info  
  add_signature(
   'WF_LOCAL_ROLES_DETAILS',
   'Select rpad(name, 20, '' '') "Name                "
         , rpad(display_name, 20, '' '') "Display Name        "
         , rpad(nvl(email_address,''-''), 30, '' '') "Email Adress                  "
         , rpad(orig_system, 18, '' '') "Originating System"
         , rpad(orig_system_id, 11, '' '') "Orig Sys ID"
         , rpad(nvl(to_char(start_date,''DD-Mon-YYYY''),''-''), 11, '' '') "Start Date "
         , rpad(nvl(to_char(expiration_date,''DD-Mon-YYYY''),''-''), 11, '' '') "Expira Date"
         , rpad(status, 10, '' '') "Asg Status"
         , rpad(nvl(to_char(created_by),''-''), 10, '' '') "Created By"
         , rpad(nvl(to_char(last_updated_by),''-''), 10, '' '') "Updated By"
    from wf_local_roles 
    where orig_system_id = ##$$PERID$$##
    order by "Name                "',
   'Workflow Local Roles Details (WF_LOCAL_ROLES)',
   'RS',
   'Workflow Local Roles deails',
   '',
   'No WF Local Roles information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  l_info('Legend') :=  'This section lists the WF_USER_ROLES details for PERSON_ID = '||l_person_id||' <br>
                        The corresponding PERSON_ID column in table WF_USER_ROLES is USER_ORIG_SYSTEM_ID. <br>
                        The HRMS application ''does not populate this table data''.
						'; -- example using l_info  

  -- signature for WF User Roles 
  -- PSD #12b
  add_signature(
   'WF_USER_ROLES_DETAILS',
   'select rpad(user_name, 20, '' '') "Name                "
          , rpad(user_orig_system_id, 16, '' '') "User Orig Sys ID"
          , rpad(user_orig_system, 13, '' '') "User Orig Sys"
          , rpad(role_orig_system, 13, '' '') "Role Orig Sys"
          , rpad(to_char(start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
          , rpad(to_char(expiration_date,''DD-Mon-YYYY''), 11, '' '') "Expi Date  "
    from wf_user_roles 
    where user_orig_system_id = ##$$PERID$$## 
    and expiration_date is not null 
    order by 1,3,4',
   'WF_USER_ROLES details (WF_USER_ROLES) <br> where EXPIRATION_DATE IS NOT NULL',
   'RS',
   'Workflow User Roles details',
   '',
   'No Workflow User Roles details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for WF Local User Roles 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the WF_LOCAL_USER_ROLES details for PERSON_ID = '||l_person_id||' <br>
                        The corresponding PERSON_ID column in table WF_LOCAL_USER_ROLES is USER_ORIG_SYSTEM_ID <br> <br>
                        The HRMS application ''does not populate this table data''.
						'; -- example using l_info  
  add_signature(
   'WF_LOCAL_USER_ROLES_DETAILS',
   'select rpad(user_name, 20, '' '') "Name                "
          , rpad(user_orig_system_id, 16, '' '') "User Orig Sys ID"
          , rpad(user_orig_system, 13, '' '') "User Orig Sys"
          , rpad(role_orig_system, 13, '' '') "Role Orig Sys"
          , rpad(to_char(start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
          , rpad(to_char(expiration_date,''DD-Mon-YYYY''), 11, '' '') "Expi Date  "
          , rpad(created_by, 10, '' '') "Created By"
          , rpad(last_updated_by, 10, '' '') "Updated By"
    from wf_local_user_roles 
    where user_orig_system_id = ##$$PERID$$## 
    and expiration_date is not null 
    order by 1,3,4',
   'WF_LOCAL_USER_ROLES details (WF_LOCAL_USER_ROLES) <br> where EXPIRATION_DATE IS NOT NULL',
   'RS',
   'Workflow Local User Roles details',
   '',
   'No WF Local User Roles information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;
  
  -- signature for WF User Role Assignments 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the WF_USER_ROLE_ASSIGNMENTS details for PERSON_ID = '||l_person_id||' <br>
                        The corresponding PERSON_ID column in table WF_USER_ROLE_ASSIGNMENTS is USER_ORIG_SYSTEM_ID <br> <br>
                        The HRMS application ''does not populate this table data''.
						'; -- example using l_info  
						
  add_signature(
   'WF_USER_ROLE_ASG_DETAILS',
   'select rpad(user_name, 20, '' '') "Name                "
          , rpad(user_orig_system_id, 16, '' '') "User Orig Sys ID"
          , rpad(user_orig_system, 13, '' '') "User Orig Sys"
          , rpad(role_orig_system, 13, '' '') "Role Orig Sys"
          , rpad(to_char(start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
          , rpad(created_by, 10, '' '') "Created By"
          , rpad(last_updated_by, 10, '' '') "Updated By"
    from wf_user_role_assignments 
    where user_orig_system_id = ##$$PERID$$## 
    and end_date is not null 
    order by 1,3,4',
   'WF_USER_ROLE_ASSIGNMENTS details (WF_USER_ROLE_ASSIGNMENTS) <br> where END_DATE IS NOT NULL',
   'RS',
   'This section lists the WF_USER_ROLE_ASSIGNMENTS details where END_DATE IS NOT NULL',
   '',
   'No Workflow User Roles Assignments details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;
  
  -- signature for HZ Parties 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the HZ_PARTIES details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br><br>
                        The corresponding PERSON_ID column in table HZ_PARTIES is PERSON_IDENTIFIER <br><br>
                        Records listed under column ''Party Type'' in table HZ_PARTIES:<br><br>
                        PERSON - this record is created when an EMPLOYEE is hired<br><br>
                        HR is not responsible for any other records created in this table.</b>
						'; -- example using l_info    
  add_signature(
   'HZ_PARTIES',
   'select
         rpad(person_identifier, 9, '' '') "Person ID"
       , rpad(party_id, 10, '' '') "Party ID  "
       , rpad(party_name, 30, '' '') "Party Name                    "
       , rpad(party_type, 14, '' '') "Party Type    "
       , rpad(orig_system_reference, 12, '' '') "Orgi Sys Ref"
       , rpad(to_char(creation_date,''DD-Mon-YYYY''), 13, '' '') "Creation Date"
       , rpad(status, 6, '' '') "Status"
       , rpad(nvl(email_address,''-''), 30, '' '') "Email Address                 "
       , rpad(created_by, 10, '' '') "Created By"
       , rpad(last_updated_by, 10, '' '') "Updated By"
    from hz_parties
    where person_identifier = to_char(##$$PERID$$##)',
   'HZ Parties Details (HZ_PARTIES)',
   'RS',
   'HZ Parties details',
   '',
   'No HZ Parties details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for HZ Person Profiles 
  -- PSD #12b
  l_info('Legend') :=  'This section lists the HZ_PERSON_PROFILES details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>
                        The corresponding PERSON_ID column in table HZ_PERSON_PROFILES is PERSON_IDENTIFIER <br><br>
                        <b>HR is not responsible for any other records created in this table.</b>
						'; -- example using l_info      
    
  add_signature(
   'HZ_PERSON_PROFILES',
   'select
           rpad(person_identifier, 10, '' '') "Party ID  "
         , rpad(party_id, 10, '' '') "Party ID  "
         , rpad(person_name, 30, '' '') "Person Name                   "
         , rpad(to_char(effective_start_date,''DD-Mon-YYYY''), 12, '' '') "Eff Start Dt"
         , rpad(nvl(to_char(effective_end_date,''DD-Mon-YYYY''),''-''), 12, '' '') "Eff End Date"
         , rpad(created_by, 10, '' '') "Created By"
         , rpad(last_updated_by, 10, '' '') "Updated By"
      from hz_person_profiles
      where person_identifier = to_char(##$$PERID$$##)',
   'HZ Person Profiles Details (HZ_PERSON_PROFILES)',
   'RS',
   'HZ Person Profiles details',
   '',
   'No HZ Person Profiles details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;
   
  -- signature for Salary Administration Analysis (PER_ALL_ASSIGNMENTS_F)
  -- PSD #12b
  add_signature(
   'SAL_ADMIN_ANALYSIS',
   'SELECT rpad(paaf.assignment_id, 13, '' '') "Assignment ID"
           , rpad(to_char(paaf.effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
           , rpad(to_char(paaf.effective_end_date,''DD-Mon-YYYY''), 11, '' '') "End Date   "
           , rpad(decode(to_char(paaf.assignment_type),''A'',''Applicant'',''B'',''Benefits'',''C'',''Contingent'',''E'',''Employee'')
           || ''('' || paaf.assignment_status_type_id || '')'', 14, '' '') "Asg Status(ID)"
           , rpad(HR_GENERAL.DECODE_LOOKUP(''PER_ASS_SYS_STATUS'',past.per_system_status), 20, '' '') "Assignment Status   " 
           , rpad(paaf.payroll_id, 10, '' '') "Payroll ID"
           , rpad(paaf.pay_basis_id, 12, '' '') "Pay Basis ID"
           , rpad(paaf.created_by, 10, '' '') "Created By"
           , rpad(paaf.last_updated_by, 10, '' '') "Updated By"
    FROM per_all_assignments_f paaf,
         per_assignment_status_types past
    WHERE paaf.person_id = ##$$PERID$$##
    and past.assignment_status_type_id = paaf.assignment_status_type_id
    and paaf.assignment_type = ''E''
    and paaf.effective_end_date = ''31-DEC-4712''
    and paaf.period_of_service_id IS NOT NULL
    and paaf.pay_basis_id IS NOT NULL
    ORDER BY "Assignment ID"',
   'Salary Administration analysis (PER_ALL_ASSIGNMENTS_F)',
   'RS',
   'Salary Administration analysis - Assignments',
   '',
   'There are no Salary Proposal records for this employee',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for Salary Administration Analysis (PER_PAY_PROPOSALS)
  -- PSD #12b
  add_signature(
   'SAL_ADMIN_ANALYSIS_1',
   'SELECT rpad(assignment_id, 13, '' '') "Assignment ID"
           ,rpad(pay_proposal_id, 15, '' '') "Pay Proposal ID"
           ,rpad(to_char(change_date,''DD-Mon-YYYY''), 13, '' '') "Change Date"
           ,rpad(to_char(date_to,''DD-Mon-YYYY''), 13, '' '') "Date To    "
           ,rpad(nvl(to_char(last_change_date,''DD-Mon-YYYY''),''-''), 14, '' '') "Last Change Dt"
           ,rpad(approved, 8, '' '') "Approved"
           ,rpad(created_by, 10, '' '') "Created By"
           ,rpad(last_updated_by, 10, '' '') "Updated By"
    FROM per_pay_proposals 
    WHERE assignment_id  in                                                          
         (SELECT paaf1.assignment_id                                           
          FROM   per_all_assignments_f paaf1,                                  
                 per_assignment_status_types past1                             
          WHERE paaf1.person_id = ##$$PERID$$##
          and past1.assignment_status_type_id = paaf1.assignment_status_type_id
          and paaf1.assignment_type = ''E''                                      
          and paaf1.effective_end_date = ''31-DEC-4712''                         
          and paaf1.period_of_service_id IS NOT NULL                           
          and paaf1.pay_basis_id IS NOT NULL)                                  
    ORDER BY "Assignment ID", "Change Date"',
   'Salary Administration analysis (PER_PAY_PROPOSALS)',
   'RS',
   'Salary Administration Analysis - Pay Proposals',
   '',
   'No Salary Administration Analysis details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  -- signature for Salary Administration Analysis (PER_PAY_BASIS and PAY_INPUT_VALUES_F)
  -- PSD #12b
  add_signature(
   'SAL_ADMIN_ANALYSIS_2',
   'SELECT  rpad(ppb.pay_basis_id, 12, '' '') "Pay Basis ID" 
            ,rpad(piv.element_type_id, 15, '' '') "Element Type ID"
            ,rpad(ppb.input_value_id, 14, '' '') "Input Value ID"
    FROM  per_pay_bases ppb, 
          pay_input_values_f piv 
    WHERE ppb.pay_basis_id in  
         (SELECT paaf1.pay_basis_id
          FROM   per_all_assignments_f paaf1,
                 per_assignment_status_types past1
          WHERE paaf1.person_id = ##$$PERID$$##
          and past1.assignment_status_type_id = paaf1.assignment_status_type_id 
          and paaf1.assignment_type = ''E''
          and paaf1.effective_end_date = ''31-DEC-4712'' 
          and paaf1.period_of_service_id IS NOT NULL 
          and paaf1.pay_basis_id IS NOT NULL)
    and ppb.input_value_id = piv.input_value_id 
    and SYSDATE BETWEEN piv.effective_start_date AND piv.effective_end_date',
   'Salary Administration analysis (PER_PAY_BASES, PAY_INPUT_VALUES_F)',
   'RS',
   'Salary Administration Analysis - Pay Basis and Pay Input Values',
   '',
   'No Salary Administration Analysis Details - Pay Basis and Input Values exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  -- signature for Salary Administration Analysis (PAY_ELEMENT_ENTRIES_F)
  -- PSD #12b

  l_info('Legend') :=  'This section lists the HZ_PERSON_PROFILES details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>
                        There exist Salary Administration Analysis Details - Pay Element Entries.<br>
					    Creator Type<br>
					    ==========<br>
					    If Creator Type = ''SP'' then this salary was entered via Salary Admin screen <br>
					    If Creator Type = ''F'' then this salary was entered via API <br>
					    If Creator Type = ''B'' then this salary was entered via Compensation Workbench
						'; -- example using l_info
						
  add_signature(
   'SAL_ADMIN_ANALYSIS_3',
   'select rpad(element_entry_id, 16, '' '') "Element Entry ID"
           ,rpad(element_type_id, 15, '' '') "Element Type ID" 
           ,rpad(element_link_id, 15, '' '') "Element Link ID" 
           ,rpad(to_char(effective_start_date,''DD-Mon-YYYY''), 11, '' '') "Start Date "
           ,rpad(to_char(effective_end_date,''DD-Mon-YYYY''), 11, '' '') "End Date   " 
           ,rpad(creator_type, 12, '' '') "Creator Type" 
           ,rpad(creator_id, 10, '' '') "Created ID" 
           ,rpad(entry_type, 10, '' '') "Entry Type" 
           ,rpad(created_by, 10, '' '') "Created By" 
           ,rpad(last_updated_by, 10, '' '') "Updated By"
    from pay_element_entries_f 
    where assignment_id in 
         (select paaf1.assignment_id
          from   per_all_assignments_f paaf1,
                 per_assignment_status_types past1
          where paaf1.person_id = ##$$PERID$$##
          and past1.assignment_status_type_id = paaf1.assignment_status_type_id 
          and paaf1.assignment_type = ''E''
          and paaf1.effective_end_date = ''31-DEC-4712'' 
          and paaf1.period_of_service_id IS NOT NULL 
          and paaf1.pay_basis_id IS NOT NULL)
    and element_type_id in  
         (select piv.element_type_id
          from  per_pay_bases ppb, 
                pay_input_values_f piv 
          where ppb.pay_basis_id in  
               (select paaf1.pay_basis_id
                from   per_all_assignments_f paaf1,
                       per_assignment_status_types past1
                where paaf1.person_id = ##$$PERID$$##
                and past1.assignment_status_type_id = paaf1.assignment_status_type_id 
                and paaf1.assignment_type = ''E''
                and paaf1.effective_end_date = ''31-DEC-4712'' 
                and paaf1.period_of_service_id IS NOT NULL 
                and paaf1.pay_basis_id IS NOT NULL)
          and ppb.input_value_id = piv.input_value_id 
          and sysdate between piv.effective_start_date and piv.effective_end_date)
    order by "Element Type ID", "Start Date ", "End Date   "',
   'Salary Administration analysis (PAY_ELEMENT_ENTRIES_F)',
   'RS',
   'Salary Administration Analysis - Pay Element Entries',
   '',
   'No Salary Administration Analysis Details - Pay Element Entries',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
  l_info.delete; 

  -- signature for Object Version Number is null on PER_ALL_PEOPLE_F, 
  --    PER_ALL_ASSIGNMENTS_F, PER_PERIODS_OF_SERVICE, PAY_ELEMENT_ENTRIES_F, 
  --    PAY_ELEMENT_LINKS_F, PER_PAY_PROPOSALS
  -- PSD #12b
  l_info('Legend') :=  'CHECK STATUS OF ''OVN'' (OBJECT_VERSION_NUMBER) TRIGGERS for table PER_ALL_PEOPLE_F <br>
                        for TERMINATE Employee error <br>
					    APP-PAY-07207: The Mandatory Argument Object_version_number Value Cannot Be Null
						'; -- example using l_info
						
  add_signature(
   'OVN_DETAILS_PAPF',
   'select rpad(person_id,9,'' '') "Person ID",
           rpad(to_char(effective_start_date,''DD-Mon-YYYY''),20,'' '') "Effective Start Date",
           rpad(to_char(effective_end_date,''DD-Mon-YYYY''),18,'' '') "Effective End Date"
    from per_all_people_f
    where person_id = ##$$PERID$$##
    and object_version_number is null',
   'Object Version Number (OVN) is null - PER_ALL_PEOPLE_F',
   'RS',
   'Records from PER_ALL_PEOPLE_F where OVN is NULL for this employee',
   '',
   'No record from per_all_people_f with OVN is null',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info);
   l_info.delete;
   
   l_info('Legend') :=  'CHECK STATUS OF ''OVN'' (OBJECT_VERSION_NUMBER) TRIGGERS for table PER_ALL_ASSIGNMENTS_F <br>
                        for TERMINATE Employee error <br>
					    APP-PAY-07207: The Mandatory Argument Object_version_number Value Cannot Be Null
						'; -- example using l_info        
	  
  add_signature(
   'OVN_DETAILS_PAAF',
   'select rpad(person_id,9,'' '') "Person ID",
           rpad(to_char(effective_start_date,''DD-Mon-YYYY''),20,'' '') "Effective Start Date",
           rpad(to_char(effective_end_date,''DD-Mon-YYYY''),18,'' '') "Effective End Date"
    from   per_all_assignments_f
    where  person_id = ##$$PERID$$##
    and    object_version_number is null',
   'Object Version Number (OVN) is null - PER_ALL_ASSIGNMENTS_F',
   'RS',
   'Records from PER_ALL_ASSIGNMENTS_F where OVN is NULL for this employee',
   '',
   'No record from per_all_assignments_f with OVN is null',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info);
   l_info.delete;
   
   l_info('Legend') :=  'CHECK STATUS OF ''OVN'' (OBJECT_VERSION_NUMBER) TRIGGERS for table PER_PERIODS_OF_SERVICE <br>
                        for TERMINATE Employee error <br>
					    APP-PAY-07207: The Mandatory Argument Object_version_number Value Cannot Be Null
						'; -- example using l_info        
   
  add_signature(
   'OVN_DETAILS_PPOS',
   'select rpad(person_id,9,'' '') "Person ID",
           rpad(period_of_service_id,16,'' '') "Period of Ser ID",
           rpad(to_char(date_start,''DD-Mon-YYYY''),11,'' '') "Date Start "
    from   per_periods_of_service
    where  person_id = ##$$PERID$$##
    and    object_version_number is null',
   'Object Version Number (OVN) is null - PER_PERIODS_OF_SERVICE',
   'RS',
   'per_periods_of_service records with OVN is null',
   '',
   'No record from per_periods_of_service with OVN is null',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info);
   l_info.delete;
   
   l_info('Legend') :=  'CHECK STATUS OF ''OVN'' (OBJECT_VERSION_NUMBER) TRIGGERS for table PAY_ELEMENT_ENTRIES_F <br>
                        for TERMINATE Employee error <br>
					    APP-PAY-07207: The Mandatory Argument Object_version_number Value Cannot Be Null
						'; -- example using l_info           

  add_signature(
   'OVN_DETAILS_PEEF',
   'select rpad(peef.assignment_id, 13, '' '') "Assignment ID"
           ,rpad(peef.element_entry_id, 16, '' '') "Element Entry ID"
           ,rpad(peef.element_link_id, 15, '' '') "Element Link ID"
           ,rpad(peef.element_type_id, 15, '' '') "Element Type ID"
           ,rpad(to_char(peef.effective_start_date,''DD-Mon-YYYY''), 14, '' '') "Eff Start Date"
           ,rpad(to_char(peef.effective_end_date,''DD-Mon-YYYY''), 12, '' '') "Eff End Date"
      from pay_element_entries_f peef
      where peef.object_version_number is null 
      and peef.assignment_id in 
           (select paaf.assignment_id
            from per_all_assignments_f paaf 
            where paaf.person_id = ##$$PERID$$##)
      order by peef.assignment_id, peef.effective_start_date',
   'Object Version Number (OVN) is null - PAY_ELEMENT_ENTRIES_F',
   'RS',
   'pay_element_entries_f records with OVN is null',
   '',
   'No record from pay_element_entries_f with OVN is null',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info); 
   l_info.delete;

   l_info('Legend') :=  'CHECK STATUS OF ''OVN'' (OBJECT_VERSION_NUMBER) TRIGGERS for table PAY_ELEMENT_LINKS_F <br>
                        for TERMINATE Employee error <br>
					    APP-PAY-07207: The Mandatory Argument Object_version_number Value Cannot Be Null
						'; -- example using l_info              
      
  add_signature(
   'OVN_DETAILS_PELF',
   'select rpad(pelf.element_link_id,12,'' '') "Ele Link ID ", 
           rpad(to_char(pelf.effective_start_date,''DD-Mon-YYYY''),20,'' '') "Effective Start Date",  
           rpad(to_char(pelf.effective_end_date,''DD-Mon-YYYY''),18,'' '') "Effective End Date"
      from pay_element_links_f pelf
      where pelf.object_version_number is null 
      and pelf.element_link_id in 
           (select peef.element_link_id
            from pay_element_entries_f peef
            where peef.assignment_id in 
              (select paaf.assignment_id
               from per_all_assignments_f paaf 
               where paaf.person_id = ##$$PERID$$##)) 
      order by pelf.element_link_id, pelf.effective_start_date',
   'Object Version Number (OVN) is null - PAY_ELEMENT_LINKS_F',
   'RS',
   'pay_element_links_f records with OVN is null',
   '',
   'No record from pay_element_links_f with OVN is null',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info);
   l_info.delete;
   
   l_info('Legend') :=  'CHECK STATUS OF ''OVN'' (OBJECT_VERSION_NUMBER) TRIGGERS for table PER_PAY_PROPOSALS <br>
                        for TERMINATE Employee error <br>
					    APP-PAY-07207: The Mandatory Argument Object_version_number Value Cannot Be Null
						'; -- example using l_info   
						
  add_signature(
   'OVN_DETAILS_PPP',
   'select rpad(ppp.assignment_id,12,'' '') "Assign ID   ", 
           rpad(ppp.pay_proposal_id,12,'' '') "Pay Prop ID ",
           rpad(to_char(ppp.creation_date,''DD-Mon-YYYY''),13,'' '') "Creation Date"
      from per_pay_proposals ppp 
      where ppp.object_version_number is null 
      and ppp.assignment_id in 
           (select paaf.assignment_id
            from per_all_assignments_f paaf 
            where paaf.person_id = ##$$PERID$$##) 
      order by ppp.assignment_id, ppp.pay_proposal_id, ppp.creation_date',
   'Object Version Number (OVN) is null - PER_PAY_PROPOSALS',
   'RS',
   'per_pay_proposals records with OVN is null',
   '',
   'No record from per_pay_proposals with OVN is null',
   'FAILURE',
   'E',
   'RS',
   'N',
   l_info);
   l_info.delete;
   
  -- signature for Person Payroll Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Payroll details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>
                        '; -- example using l_info              

  add_signature(
   'PER_PAYROLL_DETAILS',
   'select                                                             
         rpad(to_char(paf.effective_start_date,''DD-Mon-YYYY''),12,'' '')  "Eff Start Dt"
       , rpad(to_char(paf.effective_end_date,''DD-Mon-YYYY''),12,'' '')  "Eff End Date"
       , rpad(paf.assignment_id,13,'' '')  "Assignment ID"
       , rpad(paf.organization_id,7,'' '')  "Org ID"
       , rpad(papf.business_group_id,7,'' '')  "BG ID  "
       , rpad(papf.payroll_name,20,'' '')  "Payroll Name        "
       , rpad(ppb.name,14,'' '')  "Pay Basis Name"
       , rpad(hr_key.concatenated_segments,30,'' '')  "Statutory Information         "
    from per_assignments_f            paf
       , per_assignment_status_types  past
       , per_pay_bases                ppb
       , hr_soft_coding_keyflex       hr_key
       , pay_all_payrolls_f           papf
    where paf.person_id = ##$$PERID$$## 
    and  past.assignment_status_type_id = paf.assignment_status_type_id
    and  paf.payroll_id = papf.payroll_id
    and  paf.pay_basis_id = ppb.pay_basis_id
    and  paf.soft_coding_keyflex_id = hr_key.soft_coding_keyflex_id
    order by 1',
   'Person Payroll details (PAY_ALL_PAYROLLS_F)',
   'RS',
   'Person Payroll details for each Effective Date Range',
   '',
   'No Person Payroll Details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -- signature for US Federal Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Federal details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>'; -- example using l_info              

  add_signature(
   'US_FEDERAL_DETAILS',
   'select 
         rpad(to_char(effective_start_date,''DD-Mon-YYYY''),12 ,'' '')  "Eff Start Dt"
       , rpad(to_char(effective_end_date,''DD-Mon-YYYY''),12,'' '')    "Eff End Date"
       , sui_jurisdiction_code "Jurisdiction Code"
    from  pay_us_emp_fed_tax_rules_f
    where assignment_id in (select assignment_id from per_all_assignments_f where person_id = ##$$PERID$$##)
    order by 1
    ',
   'Federal details (PAY_US_EMP_FED_TAX_RULES_F)',
   'RS',
   '',
   '',
   'This section lists the Federal details',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for US State Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists the State details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>'; -- example using l_info              

  add_signature(
   'US_STATE_DETAILS',
   'SELECT 
           rpad(to_char(sr.effective_start_date,''DD-Mon-YYYY''),12,'' '') "Eff Start Dt"
         , rpad(to_char(sr.effective_end_date,''DD-Mon-YYYY''),12,'' '') "Eff End Date"
         , rpad(sr.jurisdiction_code,17,'' '') "Jurisdiction Code"
         , s.STATE_NAME            State
    FROM PAY_US_EMP_STATE_TAX_RULES_F SR
         , PAY_US_STATES s
    where assignment_id in (select assignment_id from per_all_assignments_f where person_id = ##$$PERID$$##)
    and   s.STATE_CODE = sr.STATE_CODE
    order by 1
    ',
   'State details (PAY_US_EMP_STATE_TAX_RULES_F)',
   'RS',
   '',
   '',
   'This section lists the State details',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for US State Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists the State details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>'; -- example using l_info              

  add_signature(
   'US_COUNTY_DETAILS',
   'select 
           rpad(to_char(cr.effective_start_date,''DD-Mon-YYYY''),12,'' '') "Eff Start Dt"
         , rpad(to_char(cr.effective_end_date,''DD-Mon-YYYY''),12,'' '') "Eff End Date"
         , rpad(cr.jurisdiction_code,17,'' '')                 "Jurisdiction Code"
         , s.STATE_NAME || ''-'' || c.COUNTY_NAME State_County
      from PAY_US_EMP_COUNTY_TAX_RULES_F        cr
         , PAY_US_STATES                        s
         , PAY_US_COUNTIES                      c
      where assignment_id in (select assignment_id from per_all_assignments_f where person_id = ##$$PERID$$##)
        and s.STATE_CODE = c.STATE_CODE
        and cr.STATE_CODE = c.STATE_CODE
        and cr.COUNTY_CODE = c.COUNTY_CODE 
      order by 1
    ',
   'County details (PAY_US_EMP_COUNTY_TAX_RULES_F)',
   'RS',
   '',
   '',
   'County details',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for US City Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists the City details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>'; -- example using l_info

  add_signature(
   'US_CITY_DETAILS',
   'select
           rpad(to_char(ctr.effective_start_date,''DD-Mon-YYYY''),12,'' '') "Eff Start Dt"
         , rpad(to_char(ctr.effective_end_date,''DD-Mon-YYYY''),12,'' '') "Eff End Date"
         , rpad(ctr.jurisdiction_code,17,'' '')    "Jurisdiction Code" 
         , rpad(ctr.school_district_code,16,'' '') "School Dist Code"
         , pus.state_name || ''-'' || pucnty.county_name || ''-'' || pucity.city_name "State-County-City" 
      from 
        pay_us_emp_city_tax_rules_f ctr
      , pay_us_states               pus
      , pay_us_counties             pucnty
      , pay_us_city_names           pucity
      , hr_lookups                  hrl
      , pay_us_city_school_dsts     psd
      where ctr.assignment_id in (select assignment_id from per_all_assignments_f where person_id = ##$$PERID$$##)
        and ctr.state_code = pus.state_code 
        and ctr.state_code = pucnty.state_code 
        and ctr.county_code = pucnty.county_code 
        and ctr.state_code = pucity.state_code 
        and ctr.county_code = pucity.county_code 
        and ctr.city_code = pucity.city_code 
        AND ( PUCITY.PRIMARY_FLAG = ''Y'' or SUBSTR(PUCITY.CITY_CODE,1,1) = ''U'') 
        AND CTR.FILING_STATUS_CODE = HRL.LOOKUP_CODE 
        AND HRL.LOOKUP_TYPE = ''US_LIT_FILING_STATUS'' 
        AND CTR.STATE_CODE = PSD.STATE_CODE(+) 
        AND CTR.COUNTY_CODE = PSD.COUNTY_CODE(+) 
        AND CTR.CITY_CODE = PSD.CITY_CODE(+) 
        AND CTR.SCHOOL_DISTRICT_CODE = PSD.SCHOOL_DST_CODE(+)
      order by 1
    ',
   'City details (PAY_US_EMP_CITY_TAX_RULES_F)',
   'RS',
   '',
   '',
   'City details',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for US State Details
  -- PSD #12b
  l_info('Legend') :=  'This section lists the State details for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>'; -- example using l_info              

  add_signature(
   'US_VERTEX_ELE_ENTRIES',
   'select 
           rpad(to_char(pev.effective_start_date,''DD-Mon-YYYY''),12,'' '') "Eff Start Dt"
         , rpad(to_char(pev.effective_end_date,''DD-Mon-YYYY''),12,'' '') "Eff End Date"
         , rpad(to_char(pef.assignment_id),9,'' '') "Assign ID"
         , rpad(to_char(pev.element_entry_id),16,'' '')   "Element Entry id"
         , to_char(pev.screen_entry_value) "Screen Entry Value"
      from 
           pay_element_entry_values_f      pev
        ,  pay_element_entries_f           pef
        ,  pay_element_links_f             pel
        ,  pay_element_types_f             pet
      where pev.screen_entry_value is not null 
        and pef.assignment_id in (select assignment_id from per_all_assignments_f where person_id = ##$$PERID$$##)
        and pef.element_entry_id = pev.element_entry_id
        and pef.effective_start_date = pev.effective_start_date
        and pef.effective_end_date = pev.effective_end_date
        and pel.element_link_id = pef.element_link_id
        and pet.element_type_id = pel.element_type_id
        and pet.element_name = ''VERTEX''
      ORDER BY 1,2,3
    ',
   'VERTEX Element Entries <br> (PAY_ELEMENT_ENTRIES_F, PAY_ELEMENT_ENTRY_VALUES_F, PAY_ELEMENT_LINKS_F, PAY_ELEMENT_TYPES_F)',
   'RS',
   '',
   '',
   'List of VERTEX Element Entries',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for Workers Compensation Element Entries
  -- PSD #12b
  l_info('Legend') :=  'This section lists the Workers Compensation Element Entries for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>'; -- example using l_info              

  add_signature(
   'US_WORKER_COMP_ELE_ENTR',
   '      select 
           rpad(to_char(pev.effective_start_date,''DD-Mon-YYYY''),12,'' '') "Eff Start Dt"
         , rpad(to_char(pev.effective_end_date,''DD-Mon-YYYY''),12,'' '') "Eff End Date"
         , rpad(to_char(pef.assignment_id),9,'' '') "Assign ID"
         , rpad(to_char(pev.element_entry_id),16,'' '')   "Element Entry id"
         , to_char(pev.screen_entry_value) "Screen Entry Value"
      from 
            pay_element_entry_values_f     pev
         ,  pay_element_entries_f          pef
         ,  pay_element_links_f            pel
         ,  pay_element_types_f            pet
      where pev.screen_entry_value is not null 
        and pef.assignment_id in (select assignment_id from per_all_assignments_f where person_id = ##$$PERID$$##)
        and pef.element_entry_id = pev.element_entry_id
        and pef.effective_start_date = pev.effective_start_date
        and pef.effective_end_date = pev.effective_end_date
        and pel.element_link_id = pef.element_link_id
        and pet.element_type_id = pel.element_type_id
        and pet.element_name = ''Workers Compensation''
      ORDER BY 1,2,3
    ',
   'Workers Compensation Element Entries <br> (PAY_ELEMENT_ENTRIES_F PAY_ELEMENT_ENTRY_VALUES_F PAY_ELEMENT_LINKS_F PAY_ELEMENT_TYPES_F)',
   'RS',
   '',
   '',
   'This section lists the State details',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
   
  -- signature for Payroll Element Entries
  -- PSD #12b
  l_info.delete;
  l_info('Legend') :=  'This section lists the Payroll Element Entries for each Effective Date Range for PERSON_ID = '||l_person_id||' <br>
						There may appear to be duplicate rows, since a record is shown for each element with a non null value
                        even though the values are not displayed.<br>
						'; -- example using l_info  
						  
  add_signature(
   'PAYROLL_ELEMENT_ENTRIES',
   'SELECT  rpad(to_char(pef.effective_start_date,''DD-Mon-YYYY''),12,'' '')  "Eff Start Dt"
          , rpad(to_char(pef.effective_end_date,''DD-Mon-YYYY''),12,'' '')  "Eff End Date"
          , rpad(pef.assignment_id,13,'' '')  "Assignment ID"
          , rpad(pef.element_entry_id,16,'' '')  "Element Entry ID"
          , rpad(pef.element_link_id,15,'' '')  "Element Link ID"
          , rpad(pet.element_name,30,'' '')  "Element Name                  "
          , rpad(pet.element_type_id,15,'' '')  "Element Type ID"
          , rpad(HR_GENERAL.DECODE_LOOKUP(''ENTRY_TYPE'', pef.Entry_type),15,'' '')  "Entry Type     "
          , rpad(HR_GENERAL.DECODE_LOOKUP(''CREATOR_TYPE'', pef.creator_type),30,'' '')  "Creator Type                  "
    from pay_element_entries_f      pef
          --, pay_element_entry_values_f pev
          , pay_element_links_f        pel
          , pay_element_types_f        pet 
    WHERE pef.assignment_id IN (SELECT assignment_id FROM per_all_assignments_f WHERE person_id = ##$$PERID$$##) 
    AND pef.element_link_id = pel.element_link_id 
    AND pel.element_type_id = pet.element_type_id  
    AND pef.effective_start_date >= pet.effective_start_date
    AND pef.effective_end_date <= pet.effective_end_date	  
    ORDER BY pef.effective_start_date,pef.effective_end_date,3,4,5',
   'Payroll Element Entries <br> (PAY_ELEMENT_ENTRIES_F PAY_ELEMENT_ENTRY_VALUES_F PAY_ELEMENT_LINKS_F PAY_ELEMENT_TYPES_F)',
   'RS',
   'This section lists the Payroll Element Entries for each Effective Date Range.
    There may appear to be duplicate rows, since a record is shown for each element 
      with a non null value even though the values are not displayed.',
   '',
   'No Payroll Element Entries exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   l_info.delete;

  -- signature for PAYE and NI Aggregation Details
  -- PSD #12b
  add_signature(
   'AGGREGATION_DETAILS',
   'select rpad(to_char(EFFECTIVE_START_DATE,''DD-Mon-YYYY''),11, '' '') "Start Date "
           , rpad(to_char(EFFECTIVE_END_DATE,''DD-Mon-YYYY''),11, '' '') "End Date   "
           , rpad(nvl(ppf.per_information2,''-''),11, '' '') "Director   "
           , rpad(nvl(ppf.per_information9,''-''),15, '' '') "NI             "
           , rpad(nvl(ppf.per_information10,''-''),15, '' '') "PAYE           "
      from   per_all_people_f ppf
      where  ppf.person_id = ##$$PERID$$##',
   'Get Aggregation Details (PER_ALL_PEOPLE_F)',
   'RS',
   'This section lists PAYE and NI aggregation details',
   '',
   'No PAYE and NI Aggregation details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);    

  -- signature for PAYE Element Entry details
  -- PSD #12b
  add_signature(
   'PAYE_ELEMENT_ENTRIES',
   'SELECT rpad(paaf.assignment_id,9,'' '') "Assign ID",
           rpad(peef.element_entry_id,12,'' '') "Ele Entry ID",
             rpad(peef.effective_start_date,12,'' '') "Eff Start Dt",
             rpad(to_char(peef.effective_end_date,''DD-Mon-YYYY''),12,'' '') "Eff End Date",
             rpad(peef.entry_type,4,'' '') "Type",
             rpad(peev1.screen_entry_value,4,'' '') "Tax ",
             rpad(peev2.screen_entry_value,2,'' '') "BS",
             rpad(peev3.screen_entry_value,8,'' '') "Pay Prev",
             rpad(peev4.screen_entry_value,8,'' '') "Tax Prev",
             rpad(peev5.screen_entry_value,6,'' '') "Ref   ",
             rpad(peev6.screen_entry_value,4,'' '') "Auth"
      FROM pay_element_entry_values_f peev1,
           pay_element_entry_values_f peev2,
           pay_element_entry_values_f peev3,
           pay_element_entry_values_f peev4,
           pay_element_entry_values_f peev5,
           pay_element_entry_values_f peev6,
           pay_element_entries_f peef,
           pay_input_values_f piv1,
           pay_input_values_f piv2,
           pay_input_values_f piv3,
           pay_input_values_f piv4,
           pay_input_values_f piv5,
           pay_input_values_f piv6,
           pay_element_types_f pet,
           per_all_assignments_f paaf,
           per_all_people_f papf
      Where pet.element_name = ''PAYE Details''
      and pet.effective_end_date = to_date(''31-12-4712'', ''DD-MM-YYYY'')
      and piv1.name = ''Tax Code''
      and piv2.name = ''Tax Basis''
      and piv3.name = ''Pay Previous''
      and piv4.name = ''Tax Previous''
      and piv5.name = ''Refundable'' 
      and piv6.name = ''Authority''
      and pet.element_type_id = piv1.element_type_id
      and pet.element_type_id = piv2.element_type_id
      and pet.element_type_id = piv3.element_type_id
      and pet.element_type_id = piv4.element_type_id
      and pet.element_type_id = piv5.element_type_id
      and pet.element_type_id = piv6.element_type_id
      and pet.effective_start_date between piv1.effective_start_date and piv1.effective_end_date
      and pet.effective_start_date between piv2.effective_start_date and piv2.effective_end_date
      and pet.effective_start_date between piv3.effective_start_date and piv3.effective_end_date
      and pet.effective_start_date between piv4.effective_start_date and piv4.effective_end_date
      and pet.effective_start_date between piv5.effective_start_date and piv5.effective_end_date
      and pet.effective_start_date between piv6.effective_start_date and piv6.effective_end_date
      and pet.element_type_id = peef.element_type_id
      and peef.element_entry_id = peev1.element_entry_id
      and peef.element_entry_id = peev2.element_entry_id
      and peef.element_entry_id = peev3.element_entry_id
      and peef.element_entry_id = peev4.element_entry_id
      and peef.element_entry_id = peev5.element_entry_id
      and peef.element_entry_id = peev6.element_entry_id
      and peef.effective_start_date between peev1.effective_start_date and peev1.effective_end_date
      and peef.effective_start_date between peev2.effective_start_date and peev2.effective_end_date
      and peef.effective_start_date between peev3.effective_start_date and peev3.effective_end_date
      and peef.effective_start_date between peev4.effective_start_date and peev4.effective_end_date
      and peef.effective_start_date between peev5.effective_start_date and peev5.effective_end_date
      and peef.effective_start_date between peev6.effective_start_date and peev6.effective_end_date
      and piv1.input_value_id = peev1.input_value_id
      and piv2.input_value_id = peev2.input_value_id
      and piv3.input_value_id = peev3.input_value_id
      and piv4.input_value_id = peev4.input_value_id
      and piv5.input_value_id = peev5.input_value_id
      and piv6.input_value_id = peev6.input_value_id
      and peef.assignment_id = paaf.assignment_id
      and peef.effective_start_date between paaf.effective_start_date and paaf.effective_end_date
      and paaf.person_id = papf.person_id
      and paaf.effective_start_date between papf.effective_start_date and papf.effective_end_date
      and papf.person_id = ##$$PERID$$## 
      order by paaf.assignment_id, peef.element_entry_id, peef.effective_start_date, peef.entry_type
   ',
   'PAYE Element Entry Details <br> (PAY_ELEMENT_ENTRIES_F,PAY_INPUT_VALUES_F,PAYELEMENT_TYPES_F,PER_ALL_ASSIGNMENTS_F,PER_ALL_PEOPLE_F)',
   'RS',
   'NI Element Entries details',
   '',
   'No PAYE Element Entries exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
  -- signature for NI Element Entry details
  -- PSD #12b
  add_signature(
   'NI_ELEMENT_ENTRIES',
   'SELECT rpad(paaf.assignment_id,13,'' '') "Assignment ID"
           ,rpad(peef.element_entry_id,16,'' '') "Element Entry ID"
           ,rpad(to_char(peef.effective_start_date,''DD-Mon-YYYY''),12,'' '') "Eff Start Dt"
           ,rpad(to_char(peef.effective_end_date,''DD-Mon-YYYY''),12,'' '') "Eff End Date"
           ,rpad(peef.entry_type,10,'' '') "Entry Type"
           ,rpad(max(decode(piv.name,''Category'',peev1.screen_entry_value)), 6,'' '') "NI Cat"
           ,rpad(max(decode(piv.name,''Pension'',peev1.screen_entry_value)), 6,'' '') "Pension"
           ,rpad(max(decode(piv.name,''Certificate'',peev1.screen_entry_value)), 4,'' '') "Cert"
           ,rpad(max(decode(piv.name,''Process Type'',peev1.screen_entry_value)), 12,'' '') "Process Type"
           ,rpad(max(decode(piv.name,''Periods'',peev1.screen_entry_value)), 7,'' '') "Periods"
           ,rpad(max(decode(piv.name,''Date of Renewal'',peev1.screen_entry_value)), 15,'' '') "Date of renewal"
           ,rpad(max(decode(piv.name,''Priority Period Type'',peev1.screen_entry_value)), 16,'' '') "Prio Period Type"
           ,rpad(max(decode(piv.name,''SCON'',peev1.screen_entry_value)),8,'' '') "SCON    "
      FROM pay_element_entry_values_f peev1,
           pay_element_entries_f peef,
           pay_input_values_f piv,
           pay_element_types_f pet,
           per_all_assignments_f paaf,
           per_all_people_f papf
      WHERE pet.element_name = ''NI''
      and  pet.effective_end_date = to_date(''31-12-4712'', ''DD-MM-YYYY'')
      and  pet.element_type_id = piv.element_type_id
      and  pet.effective_start_date between piv.effective_start_date and piv.effective_end_date
      and  pet.element_type_id = peef.element_type_id
      and  peef.element_entry_id = peev1.element_entry_id
      and  peef.effective_start_date between peev1.effective_start_date and peev1.effective_end_date
      and  piv.input_value_id = peev1.input_value_id
      and  peef.assignment_id = paaf.assignment_id
      and  peef.effective_start_date between paaf.effective_start_date and paaf.effective_end_date
      and  paaf.person_id = papf.person_id
      and  paaf.effective_start_date between papf.effective_start_date and papf.effective_end_date
      and  papf.person_id = ##$$PERID$$## 
      group by 
           paaf.assignment_id,
           peef.element_entry_id,
           peef.effective_start_date,
           peef.effective_end_date,
           peef.entry_type
      order by "Assignment ID",
           peef.element_entry_id,
           "Element Entry ID",
           "Eff Start Dt",
           "Eff End Date"',
   'NI Element Entry details <br> (PAY_ELEMENT_ENTRY_VALUES_F, PAY_ELEMENT_ENTRIES_F, PAY_INPUT_VALUES_F, <br> PAY_ELEMENT_TYPES_F, PER_ALL_ASSIGNMENTS_F, PER_ALL_PEOPLE_F)',
   'RS',
   'NI Element Entries details',
   '',
   'No NI Element Entries exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

   -- End of Person details
   -- Legislations specific details
   -- India
   
   -- signature for India Legislative specific info.
  -- PSD #12b
  add_signature(
   'IN_STATU_INFO',
   'select rpad(paaf.person_id,9,'' '') "Person ID"
         , rpad(paaf.assignment_id,13,'' '') "Assignment ID"
		 , rpad(nvl(hsck.segment1,''-''),13,'' '') "GRE (Tax Org)"
		 , rpad(nvl(hsck.segment2,''-''),8,'' '') "PF Org  "
		 , rpad(nvl(hsck.segment3,''-''),12,'' '') "Prof Tax Org"
		 , rpad(nvl(hsck.segment4,''-''),7,'' '') "ESI Org"
		 , rpad(nvl(hsck.segment5,''-''),7,'' '') "Factory"
		 , rpad(nvl(hsck.segment6,''-''),13,'' '') "Establishment"
		 , rpad(nvl(hsck.segment8,''-''),12,'' '')  "Gratuity Act"
		 , rpad(nvl(hsck.segment9,''-''),20,'' '') "Substantial Interest"
		 , rpad(nvl(hsck.segment10,''-''),8,'' '') "Director"
		 , rpad(nvl(hsck.segment11,''-''),13,'' '') "Specified Emp"
		 , rpad(nvl(hsck.segment12,''-''),31,'' '') "PF/EPS Contri"
		 , hsck.concatenated_segments  "Concatenated Segments"  -- As we need Complete value size of 700
	from   hr_soft_coding_keyflex  hsck,                                   
		   per_all_assignments_f paaf                                      
	where  hsck.soft_coding_keyflex_id = paaf.soft_coding_keyflex_id       
	   and paaf.person_id = ##$$PERID$$##',
   'India Legislation Statutory Information',
   'RS',
   'Statutory Information for the Employee',
   '',
   'No Statutory information created for this person',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info,
   p_include_in_dx_summary => 'Y');
   
  -- signature for Payroll Details - Common to all Persons
  -- PSD #12b
  add_signature(
   'PAYROLL_DETAILS',
   'select rpad(payroll_id,10,'' '') "Payroll ID"
         , rpad(payroll_name,30,'' '') "Payroll Name                  "
         , rpad(to_char(effective_start_date,''DD-Mon-YYYY''),14,'' '') "Eff Start Date"
         , rpad(To_char(effective_end_date,''DD-Mon-YYYY''),12,'' '') "Eff End Date"
         , rpad(business_group_id,6,'' '') "BG ID "
         , rpad(object_version_number,3,'' '') "OVN"
    from pay_all_payrolls_f
    order by payroll_id,effective_start_date',
   'Payroll details (PAY_ALL_PAYROLLS_F) - All',
   'RS',
   'This section lists the Payroll details for each Effective Date range for PAYROLL_ID',
   '',
   'No Payroll details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

-- signature for Status of OVN Triggers - Common to all Persons
  -- PSD #12b
  add_signature(
   'STATUS_OF_OVN_TRIGGERS',
   'select rpad(table_name,30,'' '') "Table Name                    "
           ,rpad(trigger_name,30,'' '') "Trigger Name                  "
           ,rpad(status,8,'' '') "Status  "
    from all_triggers 
    where upper(table_name) in
       (''PER_ALL_PEOPLE_F'',
        ''PER_ALL_ASSIGNMENTS_F'',
        ''PER_PERIODS_OF_SERVICE'',
        ''PAY_ELEMENT_ENTRIES_F'',
        ''PAY_ELEMENT_LINKS_F'',
        ''PAY_ELEMENT_TYPES_F'',
        ''PER_PAY_PROPOSALS'')
    and upper(trigger_name) like upper(''%OVN%'')
    order by table_name, trigger_name',
   'Status of OVN Triggers Details',
   'RS',
   'Status of ''OVN'' Triggers details',
   '',
   'No Status of ''OVN'' Triggers exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);


  -- signature for Status of OVN Triggers - Common to all Persons
  -- PSD #12b
  add_signature(
   'STATUS_OF_OVN_TRIGGERS_HR_PER',
   'select rpad(owner,8,'' '') "Owner   " 
           ,rpad(table_name,30,'' '') "Table Name                    "
           ,rpad(trigger_name,30,'' '') "Trigger Name                  "
           ,rpad(status,8,'' '') "Status  "
    from all_triggers 
    where owner = ''APPS''
    and trigger_name like ''HR%OVN%'' or trigger_name like ''PER%OVN%''
    order by owner, table_name',
   'OVN Triggers Status - HR and PER tables',
   'RS',
   'Status of ''OVN'' Triggers information',
   '',
   'No Status of ''OVN'' Triggers information exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  
  -- signature for Person Types - Common to all Persons
  -- PSD #12b
  l_info.delete;
  l_info('Legend') :=  'customer defined Person Types via Business Group id <br>
						and <br>
                        system seeded Person Types (no Business Group id value)<br>
						'; -- example using l_info  
  add_signature(
   'PERSON_TYPES',
   'select                                                                  
          rpad(business_group_id, 5,'' '') "BG ID"
        , rpad(person_type_id, 11,'' '') "Per Type ID"
        , rpad(active_flag, 6,'' '') "Active"
        , rpad(default_flag, 7,'' '') "Default"
        , system_person_type || ''--'' || user_person_type
     from per_person_types                                                   
     union all
     select distinct ''-    '',''-          '',''-     '',''-      '', SYSTEM_PERSON_TYPE||''--''||USER_PERSON_TYPE
     from per_person_types
     order by 1 desc,5',
   'Person Types detail (PER_PERSON_TYPES)',
   'RS',
   'This section display Customer defined Person Types (via Business Group id) and system seeded Person Types (no Business Group id)',
   '',
   'No Person Types details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);   
   l_info.delete;
   
  -- signature for Assignment status Types - Common to all Persons
  -- PSD #12b
  add_signature(
   'ASSIGNMENT_STATUS_TYPES',
   'select rpad(assignment_status_type_id,14,'' '') "Asg St Type ID"
           ,rpad(nvl(to_char(business_group_id),''-''),5,'' '') "BG ID"
           ,rpad(active_flag,6,'' '') "Active"
           ,rpad(default_flag,7,'' '') "Default"
           ,rpad(primary_flag,7,'' '') "Primary"
           ,rpad(user_status,30,'' '') "User Status                   "
           ,rpad(per_system_status,15,'' '') "System Status  "
    from per_assignment_status_types
    order by "Asg St Type ID"',
   'Assignment Status Types detail (PER_ASSIGNMENT_STATUS_TYPES)',
   'RS',
   'Assignment Status Types details',
   '',
   'No Assignment Status Types details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);
   
   -- signature for Status of 'WHO' Triggers of HR tables - Common to all Persons
  -- PSD #12b
  add_signature(
   'WHO_TRIGGERS_HR',
   'select rpad(owner, 8,'' '') "Owner   "
           ,rpad(table_name, 30,'' '') "Table Name                    "
           ,rpad(trigger_name,  30,'' '') "Trigger Name                  "
           ,rpad(status,8, '' '') "Status  "
    from all_triggers 
    where UPPER(table_name) in 
       ( ''PER_ALL_PEOPLE_F''
       , ''PER_ALL_ASSIGNMENTS_F''
       , ''PER_PERIODS_OF_SERVICE''
       , ''PER_PERSON_TYPE_USAGES_F''
       , ''PER_ADDRESSES''
       , ''HR_LOCATIONS_ALL''
       , ''HR_LOCATIONS_ALL_TL''
       , ''HR_ALL_ORGANIZATION_UNITS''
       , ''HR_ALL_ORGANIZATION_UNITS_TL''
       , ''HR_ALL_POSITIONS_F''
       , ''HR_ALL_POSITIONS_F_TL''
       , ''PER_ALL_POSITIONS''
       , ''PER_JOBS''
       , ''PER_JOBS_TL'')
    and trigger_name like ''%WHO%'' 
    order by table_name, trigger_name',
   'WHO Triggers Status - HR Tables',
   'RS',
   'Status of ''WHO'' Triggers of HR tables details',
   '',
   'No ''WHO'' Triggers of HR tables details exists',
   'ALWAYS',
   'I',
   'Y',
   'N',
   l_info);

  -------------------------------------------
  -- Terminations section
  -------------------------------------------
  
  debug('begin add_signature: NOTE1320920');
  add_signature(
      p_sig_id                 => 'NOTE1320920',
      p_sig_sql                => 'SELECT als.text "Incorrect version"
                                  FROM all_source als
                                  Where  
                                  FND_IREP_LOADER_PRIVATE.compare_versions(
                                            substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                                              1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                                              '' '',1,1)-1),''120.2.12010000.6'') = ''<''              
                                  And   Als.Type = ''PACKAGE BODY''
                                  And   Als.Name = ''HR_TERMINATION_SS''
                                  And   Als.Text Like ''%$Header%''',
      p_title                  => 'Issue when terminate the manager and direct reports on the same day',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: You can assign all Direct reports to the same new manager or make individual manager assignments below.',
      p_solution               => 'Follow [1320920.1] Not Able To Terminate The Manager And Direct Reports On The Same Day',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: NOTE1320920');

  debug('begin add_signature: NOTE1402798');
    add_signature(
        p_sig_id                 => 'NOTE1402798',
        p_sig_sql                => ' SELECT Adf.Filename||'' ''|| Adfv.Version "Incorrect version"
                                      FROM   Ad_Files Adf, Ad_File_Versions Adfv
                                      Where  Adf.File_Id = Adfv.File_Id
                                      and    FND_IREP_LOADER_PRIVATE.compare_versions(
                                                Adfv.Version,''120.0.12010000.3'') = ''<''
                                      And Adf.App_Short_Name = ''PER''
                                      And Adf.Filename like  ''EmpRevTermReviewVOImpl.class''
                                      And Adfv.File_Version_Id = (Select Max(adfv2.File_Version_Id) 
                                                                  from ad_file_versions adfv2 
                                                                  where Adf.File_Id = Adfv2.File_Id)',
        p_title                  => 'Issue when reversing a termination which has comments via Manager Self-Service',
        p_fail_condition         => 'RS',
        p_problem_descr          => 'You may experience this error: oracle.apps.fnd.framework.OAException: java.sql.SQLDataException: ORA-01858: a non-numeric character was found where a numeric was expected ORA-06512: at line 1',
        p_solution               => 'Review [1402798.1] Reverse Termination Error ORA-01858 a non-numeric character was found where a numeric was expected',
        p_success_msg            => 'OK! Correct version of files available.',
        p_print_condition        => nvl('FAILURE','ALWAYS'),
        p_fail_type              => nvl('W','W'),
        p_print_sql_output       => nvl('RS','RS'),
        p_limit_rows             => nvl('Y','Y'),
        p_extra_info             => l_info,
        p_child_sigs             => VARCHAR_TBL(),
        p_include_in_dx_summary  => nvl('Y','N')
        );
     l_info.delete;
  debug('end add_signature: NOTE1402798');
  
  debug('begin add_signature: NOTE1421727');
  add_signature(
      p_sig_id                 => 'NOTE1421727',
      p_sig_sql                => ' SELECT als.text "Incorrect Version"
                                    FROM all_source als
                                    Where  
                                    FND_IREP_LOADER_PRIVATE.compare_versions(
                                              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                                                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                                                '' '',1,1)-1),''120.17.12010000.24'') = ''<''              
                                    And   Als.Type = ''PACKAGE BODY''
                                    And   Als.Name = ''HR_UTIL_MISC_SS''
                                    And   Als.Text Like ''%$Header%''',
      p_title                  => 'Issue when attempting to terminate a secondary assignment the acting Manager',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: The selected action is not available as you do not have access to the primary assignment of this person',
      p_solution               => 'Review [1421727.1] Secondary Assignment Termination Errors: The selected action is not available as you do not have access to the primary assignment of this person',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: NOTE1421727');
   
  debug('begin add_signature: NOTE1569684');
  add_signature(
      p_sig_id                 => 'NOTE1569684',
      p_sig_sql                => ' SELECT als.text "Incorrect Version"
                                    FROM all_source als
                                    Where  
                                    FND_IREP_LOADER_PRIVATE.compare_versions(
                                              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                                                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                                                '' '',1,1)-1),''120.0.12010000.2'') = ''<''              
                                    And   Als.Type = ''PACKAGE BODY''
                                    And   Als.Name = ''HR_APPROVAL_WF''
                                    And   Als.Text Like ''%$Header%''
                                    union
                                    SELECT als.text
                                    FROM all_source als
                                    Where  
                                    FND_IREP_LOADER_PRIVATE.compare_versions(
                                              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                                                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                                                '' '',1,1)-1),''120.22.12010000.37'') = ''<''              
                                    And   Als.Type = ''PACKAGE BODY''
                                    And   Als.Name = ''HR_APPROVAL_SS''
                                    And   Als.Text Like ''%$Header%''',
      p_title                  => 'Issue when attempting to terminate a employee through Manager Self Service',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: The Server encounter an internal error or misconfiguration and was unable to complete your request',
      p_solution               => 'Review [1569684.1] Internal Server Error On The Termination Confirmation Page Through Manager Self-Service',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: NOTE1569684');

  debug('begin add_signature: NOTE1664437');
  add_signature(
      p_sig_id                 => 'NOTE1664437',
      p_sig_sql                => ' SELECT als.text "Incorrect Version"
                                    FROM all_source als
                                    Where  
                                    FND_IREP_LOADER_PRIVATE.compare_versions(
                                              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                                                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                                                '' '',1,1)-1),''120.9.12010000.6'') = ''<''     
                                    And   Als.Type = ''PACKAGE BODY''
                                    And   Als.Name = ''HR_EX_EMPLOYEE_API''
                                    And   Als.Text Like ''%$Header%''',
      p_title                  => 'APP-PAY-07400: You cannot delete an assignment that has events linked to it',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: APP-PAY-07400: You cannot delete an assignment that has events linked to it',
      p_solution               => 'Review [1664437.1] Error : APP-PAY-07400: You cannot delete an assignment that has events linked to it. While Attempting to Terminate an Employee',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: NOTE1664437');

  debug('begin add_signature: NOTE1402698');
  add_signature(
      p_sig_id                 => 'NOTE1402698',
      p_sig_sql                => ' SELECT als.text "Incorrect Version"
                                    FROM all_source als
                                    Where  
                                    ((''12.0'' = substr(''##$$REL$$##'',1,4) AND
                                            FND_IREP_LOADER_PRIVATE.compare_versions(
                                              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                                                1, Instr(Substr(Als.Text,Regexp_Instr(Als.Text,''  *[0-9]'',1,1,1) - 1),
                                                '' '',1,1)-1),''120.11.12000000.13'') = ''<'' ) 
                                              Or
                                           (''12.1'' = substr(''##$$REL$$##'',1,4) AND
                                            FND_IREP_LOADER_PRIVATE.compare_versions(
                                              substr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                                                1, instr(substr(als.text,regexp_instr(als.text,''  *[0-9]'',1,1,1)-1),
                                                '' '',1,1)-1),''120.20.12010000.13'') = ''<'' ))   
                                    And   Als.Type = ''PACKAGE BODY''
                                    And   Als.Name = ''HR_ASSIGNMENT_API''
                                    And   Als.Text Like ''%$Header%''',
      p_title                  => 'APP-PER-449043: You can set the projected assignment end date for contingent worker assignment only',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'You may experience this error: APP-PER-449043: You can set the projected assignment end date for contingent worker assignment only. It cannot be earlier than the assignment start date.',
      p_solution               => 'Review Note 1402698.1 APP-PER-449043 You can set the projected assignment end date for contingent worker assignment only. It cannot be earlier than the assignment start date.',
      p_success_msg            => 'OK! Correct version of files available.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: NOTE1402698');

  
  
  -- Added as per request from Andrea. 20160106
  
  debug('begin add_signature: Comment_PER');
  add_signature(
      p_sig_id                 => 'Comment_PER',
      p_sig_sql                => ' select ppf.person_id
                                         , to_char(ppf.effective_start_date,''DD-MON-YYYY'')  Effective_Start
                                         , to_char(ppf.effective_end_date,''DD-MON-YYYY'')    Effective_End
                                         , ppf.COMMENT_ID
                                    from PER_ALL_PEOPLE_F ppf
                                    where ppf.COMMENT_ID IS NOT NULL
                                    and NOT EXISTS(
                                            SELECT 1
                                            FROM HR_COMMENTS HC
                                            WHERE HC.COMMENT_ID = ppf.COMMENT_ID)
                                    order by 1,2',
      p_title                  => 'Comment available in PER_ALL_PEOPLE_F and not in HR_COMMENTS',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Person records with COMMENT_ID in PER_ALL_PEOPLE_F and NO matching rows found in table HR_COMMENTS',
      p_solution               => 'Review Note 858257.1 Terminating Employee errors: APP-PAY-07202 Cannot Select Comment Text',
      p_success_msg            => 'No issue found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: Comment_PER');

  debug('begin add_signature: Comment_ASG');
  add_signature(
      p_sig_id                 => 'Comment_ASG',
      p_sig_sql                => ' select paaf.person_id
                                         , to_char(paaf.effective_start_date,''DD-MON-YYYY'')  Effective_Start
                                         , to_char(paaf.effective_end_date,''DD-MON-YYYY'')    Effective_End
                                         , paaf.COMMENT_ID
                                    from PER_ALL_ASSIGNMENTS_F paaf
                                    where paaf.COMMENT_ID IS NOT NULL
                                    and NOT EXISTS(
                                            SELECT 1
                                            FROM HR_COMMENTS HC
                                            WHERE HC.COMMENT_ID = paaf.COMMENT_ID)
                                    order by 1,2',
      p_title                  => 'Comment available in PER_ALL_ASSIGNMENTS_F and not in HR_COMMENTS',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Assigment records with COMMENT_ID in PER_ALL_ASSIGNMENTS_F and NO matching rows found in table HR_COMMENTS',
      p_solution               => 'Review Note 858257.1 Terminating Employee errors: APP-PAY-07202 Cannot Select Comment Text',
      p_success_msg            => 'No issue found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: Comment_PER');

  debug('begin add_signature: NOTE1209323');
  add_signature(
      p_sig_id                 => 'NOTE1209323',
      p_sig_sql                => ' SELECT peef.assignment_id,
                                           peef.element_entry_id,
                                           TO_CHAR(peef.effective_start_date,''DD-MON-YYYY'') "Eff Start Dt",
                                           TO_CHAR(peef.effective_end_date,''DD-MON-YYYY'') "Eff End Dt",
                                           peef.element_link_id
                                    FROM
                                          (SELECT  element_entry_id,
                                                   effective_start_date,
                                                   COUNT(*)
                                          FROM     pay_element_entries_f
                                          GROUP BY element_entry_id,
                                                   effective_start_date
                                          HAVING COUNT(*)>1
                                          UNION
                                          SELECT element_entry_id,
                                                 effective_end_date,
                                                 COUNT(*)
                                          FROM   pay_element_entries_f
                                          GROUP BY element_entry_id,
                                                   effective_end_date
                                          HAVING COUNT(*)>1
                                          ) Data_Corrupted,
                                          pay_element_entries_f peef
                                    WHERE Data_Corrupted.element_entry_id = peef.element_entry_id
                                    order by 1,3',
      p_title                  => 'Elementry Entry (PAY_ELEMENT_ENTRIES_F) having same START or END date',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are records in table PAY_ELEMENT_ENTRIES_F for the same element entry with same Start or 
                                   End dates may cause Error APP-PAY-06513: System Error: Procedure hr_entry_api.delete_element_entry at Step 2, while entering ''Final Process'' date',
      p_solution               => 'Review Note 1209323.1 APP-PAY-06153 When Trying To Enter Final Process Date For Terminated Employee',
      p_success_msg            => 'No issue found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: NOTE1209323');   

  debug('begin add_signature: NOTE402472');
  add_signature(
      p_sig_id                 => 'NOTE402472',
      p_sig_sql                => 'SELECT paaf.assignment_id,
                                          peef.element_link_id,
                                          to_char(MIN(peef.EFFECTIVE_START_DATE),''DD-MON-YYYY'') "EE Eff Start Dt",
                                          to_char(MAX(peef.EFFECTIVE_END_DATE),''DD-MON-YYYY'') "EE Eff End Dt",
                                          to_char(MIN(paaf.EFFECTIVE_START_DATE),''DD-MON-YYYY'') "ASG Eff Start Dt",
                                          to_char(MAX(paaf.EFFECTIVE_END_DATE),''DD-MON-YYYY'') "ASG Eff End Dt"
                                   FROM   pay_element_entries_f peef,
                                          per_all_assignments_f paaf
                                  WHERE   peef.assignment_id = paaf.assignment_id
                                  GROUP BY paaf.assignment_id,
                                           peef.element_link_id
                                  HAVING TRUNC(MIN(peef.EFFECTIVE_START_DATE))< TRUNC(MIN(paaf.EFFECTIVE_START_DATE))
                                  OR TRUNC(MAX(peef.EFFECTIVE_END_DATE))      > TRUNC(MAX(paaf.EFFECTIVE_END_DATE))',
      p_title                  => 'Elementry Entry having Start Date before Assignment or END Date after Assignment',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are records in table PAY_ELEMENT_ENTRIES_F which Starts before Assignment or 
                                   End after Assignment may cause Error ORA-06502: PL/SQL: numeric or value error ORA-06512: at APPS.PER_PERIODS_OF_SERVICE_PKG, line 1066, while Reverse Termination',
      p_solution               => 'Review Note 402472.1 Reverse Termination error - ORA-06502: PL/SQL: numeric or value error ORA-06512: at APPS.PER_PERIODS_OF_SERVICE_PKG, line 1066',
      p_success_msg            => 'No issue found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: NOTE402472');  

  debug('begin add_signature: NOTE1566082');
  add_signature(
      p_sig_id                 => 'NOTE1566082',
      p_sig_sql                => 'SELECT   absence_attendance_id,
                                            person_id,
                                            to_char(date_start,''DD-MON-YYYY'') Date_start,
                                            to_char(date_end,''DD-MON-YYY'') Date_end,
                                            to_char(date_notification,''DD-MON-YYY'') Date_Notification,
                                            to_char(date_projected_start,''DD-MON-YYY'') Date_projected_start,
                                            to_char(date_projected_end,''DD-MON-YYY'') Date_projected_end
                                    FROM    per_absence_attendances
                                    WHERE   date_end IS NULL
                                    ORDER BY person_id, date_start',
      p_title                  => 'Persons with open ended Absences',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Attempting to terminate an employee having open ended absence gives following error ''This person has an open ended absence, please end the absence before terminating'' ',
      p_solution               => 'Review Note 1566082.1 PERWSTEM Unable to Terminate an Employee - Open Ended Absence',
      p_success_msg            => 'No issue found.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
   debug('end add_signature: NOTE1566082');  

  -------------------------------------------
  -- End of Terminations section
  -------------------------------------------
                      
  -------------------------------------------
  -- Example signatures
  -- PSD #11b
  -------------------------------------------

  l_info.delete;
  l_info('Doc ID') := '390023.1'; -- example using l_info
  l_info('Bug Number') := '9707155'; -- example using l_info
  add_signature(
   'Note390023.1_case_GEN4',
   'SELECT ''PO/PA'' "Doc Type",
           h.segment1 "Doc Number",
           h.po_header_id "Doc ID",
           h.org_id,
           null "Release Num",
           null "PO Release ID",
           h.type_lookup_code "Type Code",
           h.authorization_status "Athorization Status",
           nvl(h.cancel_flag,''N'') canceled,
           nvl(h.closed_code,''OPEN'') "Closed Code",
           h.change_requested_by "Change Requested By",
           h.revision_num,
           h.wf_item_type, h.wf_item_type "##$$FK1$$##",
           h.wf_item_key, h.wf_item_key "##$$FK2$$##",
           h.approved_date "Approved Date"
    FROM po_headers_all h
    WHERE to_date(''##$$FDATE$$##'') <= (
            SELECT max(ah.action_date) FROM po_action_history ah
            WHERE ah.object_id = h.po_header_id
            AND   ah.object_type_code IN (''PO'',''PA'')
            AND   ah.action_code = ''SUBMIT''
            AND   ah.object_sub_type_code = h.type_lookup_code)
    AND   h.org_id = ##$$PERID$$##
    AND   h.authorization_status IN (''IN PROCESS'', ''PRE-APPROVED'')
    AND   nvl(h.cancel_flag,''N'') <> ''Y''
    AND   nvl(h.closed_code,''OPEN'') <> ''FINALLY CLOSED''
    AND   nvl(h.change_requested_by,''NONE'') NOT IN (''REQUESTER'',''SUPPLIER'')
    AND   (nvl(h.ENCUMBRANCE_REQUIRED_FLAG, ''N'') <> ''Y'' OR
           h.type_lookup_code <> ''BLANKET'')
    AND   NOT EXISTS (
            SELECT null
            FROM wf_item_activity_statuses ias,
                 wf_notifications n
            WHERE ias.notification_id is not null
            AND   ias.notification_id = n.group_id
            AND   n.status = ''OPEN''
            AND   ias.item_type = ''POAPPRV''
            AND   ias.item_key IN (
                    SELECT i.item_key FROM wf_items i
                    START WITH i.item_type = ''POAPPRV''
                    AND        i.item_key = h.wf_item_key
                    CONNECT BY PRIOR i.item_type = i.parent_item_type
                    AND        PRIOR i.item_key = i.parent_item_key
                    AND     nvl(i.end_date,sysdate+1) >= sysdate))
    ORDER BY 1,2',
   'Recent Documents - Candidates for Reset',
   'RS',
   'Recent documents exist which are candidates for reset.  The documents
    listed are all IN PROCESS or PRE-APPROVED approval status
    and do not have an open workflow notification.',
   '<ul><li>Review the results in the Workflow Activity section
         for the documents.</li>
      <li>If multiple documents are stuck with errors in the same
         workflow activity then try the Mass Retry in [458216.1].</li>
      <li>For all other document see [390023.1] for details on
         how to reset these documents if needed.</li>
      <li>To obtain a summary count for all such documents in your 
         system by document type, refer to [1584264.1]</li></ul>',
   null,
   'ALWAYS',
   'I',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('Note390023.1_case_GEN4_CHILD1',
     'Note390023.1_case_GEN4_CHILD2'));

    l_info.delete;
    add_signature(
     'Note390023.1_case_GEN4_CHILD1',
     'SELECT DISTINCT
             ac.name Activity,
             ias.activity_result_code Result,
             ias.error_name ERROR_NAME,
             ias.error_message ERROR_MESSAGE,
             ias.error_stack ERROR_STACK
      FROM wf_item_activity_statuses ias,
           wf_process_activities pa,
           wf_activities ac,
           wf_activities ap,
           wf_items i
      WHERE ias.item_type = ''##$$FK1$$##''
      AND   ias.item_key  = ''##$$FK2$$##''
      AND   ias.activity_status     = ''ERROR''
      AND   ias.process_activity    = pa.instance_id
      AND   pa.activity_name        = ac.name
      AND   pa.activity_item_type   = ac.item_type
      AND   i.item_type             = ias.item_type
      AND   i.item_key              = ias.item_key
      AND   i.begin_date            >= ac.begin_date
      AND   i.begin_date            < nvl(ac.end_date, i.begin_date+1)
      AND   (ias.error_name is not null OR
             ias.error_message is not null OR
             ias.error_stack is not null)
      ORDER BY 1,2',
     'WF Activity Errors for This Document',
     'RS',
     'No errored WF activities found for the document',
     null,
     null,
     'ALWAYS',
     'I',
     'RS');
	 
    -------------------------------------------
    -- End of example signatures
    -------------------------------------------	 
    -- PSD #11b-end

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;





---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #12
PROCEDURE main (
      p_person_id       IN NUMBER   DEFAULT null,
      p_from_date       IN DATE     DEFAULT sysdate - 90,
      p_max_output_rows IN NUMBER   DEFAULT 50,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;
  l_tab_exists number;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
 
-- PSD #13
-- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'Person';

  l_step := '20';
  validate_parameters(
      p_person_id,
      p_from_date,
      p_max_output_rows,
      p_debug_mode);

  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  
  select count(*) 
  into   l_tab_exists
  from   all_objects 
  where  object_name in ('DBA_OBJECTS','DBA_ERRORS') 
  and    owner = 'PUBLIC' and object_type = 'SYNONYM';
  
  -- PSD #14 -- Decided not to have Proactive Recommendations section 20160112
  --start_section('Proactive Recommendations');  
     
  --end_section;
  start_section('Instance Overview');
     set_item_result(run_stored_sig('OVERVIEW'));
     set_item_result(check_rec_patches);
     set_item_result(run_stored_sig('LANGUAGES_INSTALLED_DETAILS'));
     set_item_result(run_stored_sig('INSTALLED_LEGISLATIONS'));
     set_item_result(run_stored_sig('PRODUCTS_INSTALL'));
     set_item_result(run_stored_sig('BUSINESS_GROUPS'));
	   set_item_result(run_stored_sig('SHARED_HR'));
     if l_tab_exists > 1 then
        set_item_result(run_stored_sig('INVALIDS'));
     end if;
	   set_item_result(run_stored_sig('WHO_TRIGGERS_HR'));
	   print_rep_subsection('Object Version(OVN)');	 
	     set_item_result(run_stored_sig('STATUS_OF_OVN_TRIGGERS'));
       set_item_result(run_stored_sig('STATUS_OF_OVN_TRIGGERS_HR_PER'));
		   set_item_result(run_stored_sig('OVN_DETAILS_PAPF'));
		   set_item_result(run_stored_sig('OVN_DETAILS_PAAF'));
		   set_item_result(run_stored_sig('OVN_DETAILS_PPOS'));
		   set_item_result(run_stored_sig('OVN_DETAILS_PEEF'));
		   set_item_result(run_stored_sig('OVN_DETAILS_PELF'));
		   set_item_result(run_stored_sig('OVN_DETAILS_PPP'));
     print_rep_subsection_end;
  end_section;
  
  start_section('Trading Community Architecture(TCA) Owned by AR');
     set_item_result(run_stored_sig('TCA_AR'));
     set_item_result(run_stored_sig('EMP_SUPL_DETAILS'));
     set_item_result(run_stored_sig('HZ_PARTIES'));
     set_item_result(run_stored_sig('HZ_PERSON_PROFILES'));
  end_section;
  
  start_section('Terminations');
      set_item_result(run_stored_sig('PERSONS_CWK_ISSUE1'));
      set_item_result(run_stored_sig('PERSONS_PEE_ISSUE2'));
      set_item_result(run_stored_sig('NOTE1320920'));
      set_item_result(run_stored_sig('NOTE1402798'));
      set_item_result(run_stored_sig('NOTE1421727'));
      set_item_result(run_stored_sig('NOTE1569684'));
      set_item_result(run_stored_sig('NOTE1664437'));
      set_item_result(run_stored_sig('NOTE1402698'));
      set_item_result(run_stored_sig('Comment_PER'));
      set_item_result(run_stored_sig('Comment_ASG')); 
      set_item_result(run_stored_sig('NOTE1209323'));   
      set_item_result(run_stored_sig('NOTE402472'));
      set_item_result(run_stored_sig('NOTE1566082'));
   end_section;	   
    
  start_section('Person and Assignment Details');
     --print_rep_subsection('Person Details');
     set_item_result(run_stored_sig('PERSON_DETAILS'));
     set_item_result(run_stored_sig('PERSON_TYPES'));
     set_item_result(run_stored_sig('PER_TYPE_USAGE_DETAILS'));
	   set_item_result(run_stored_sig('PERSON_ISSUE1'));
	   set_item_result(run_stored_sig('PERSON_ISSUE2'));
	   set_item_result(run_stored_sig('PERSON_ISSUE3'));
     set_item_result(run_stored_sig('ASSIGNMENT_DETAILS'));
     set_item_result(run_stored_sig('ASSIGNMENT_STATUS_TYPES'));
	   set_item_result(run_stored_sig('ASSIGNMENT_ISSUE1'));
	   set_item_result(run_stored_sig('ASSIGNMENT_ISSUE2'));
	   set_item_result(run_stored_sig('ASSIGNMENT_ISSUE3'));
     set_item_result(run_stored_sig('PERIOD_SER_DETAILS'));
  end_section;
  
  start_section('Person Other Information');	 
     set_item_result(run_stored_sig('APPL_DETAILS'));
     set_item_result(run_stored_sig('PERIOD_PLACEMENTS_DETAILS'));
     set_item_result(run_stored_sig('CONTACT_DETAILS'));
	   print_rep_subsection('Address');	 
		   set_item_result(run_stored_sig('PER_ADDRESS_DETAILS'));
		   set_item_result(run_stored_sig('ADDRESS_STYLE_DETAILS'));
     print_rep_subsection_end;
	   set_item_result(run_stored_sig('LOC_DETAILS'));
     set_item_result(run_stored_sig('ABSENCE_DETAILS'));
	   set_item_result(run_stored_sig('GRADE_DETAILS'));
     set_item_result(run_stored_sig('EVENT_DETAILS'));
	   print_rep_subsection('Reporting and Security');
		   set_item_result(run_stored_sig('PPL_REPORT_DETAILS'));
		   set_item_result(run_stored_sig('PERSON_REPORT_DETAILS'));
		   set_item_result(run_stored_sig('PER_SEC_PROF_DETAILS'));
     print_rep_subsection_end;
     set_item_result(run_stored_sig('PERSON_ANALYSIS_DETAILS'));
	   set_item_result(run_stored_sig('AGGREGATION_DETAILS'));
     set_item_result(run_stored_sig('FND_USER_DETAILS'));
     set_item_result(run_stored_sig('FND_USER_RESP_DETAILS'));
  end_section;	 
  start_section('Salary Administration');
     set_item_result(run_stored_sig('SAL_ADMIN_ANALYSIS'));
     set_item_result(run_stored_sig('SAL_ADMIN_ANALYSIS_1'));
     set_item_result(run_stored_sig('SAL_ADMIN_ANALYSIS_2'));
     set_item_result(run_stored_sig('SAL_ADMIN_ANALYSIS_3'));
  end_section;
  start_section('Person Payroll Details');
     set_item_result(run_stored_sig('ASG_ACT_DETAILS'));
     set_item_result(run_stored_sig('PER_PAYROLL_DETAILS'));
	   set_item_result(run_stored_sig('PAYROLL_DETAILS'));
     set_item_result(run_stored_sig('PAYROLL_ELEMENT_ENTRIES'));
     set_item_result(run_stored_sig('BENEFITS_PAYROLL_DETAILS'));	
  end_section;
  
  -- Legislation specific information.
  -- India 
  start_section('India Legislation');
	   set_item_result(run_stored_sig('IN_STATU_INFO'));
  end_section;
  -- End of India

  start_section('UK Legislation');
     set_item_result(run_stored_sig('PAYE_ELEMENT_ENTRIES'));
	   set_item_result(run_stored_sig('PAYROLL_PAYE_DETAILS'));
     set_item_result(run_stored_sig('NI_ELEMENT_ENTRIES'));
  end_section;
  -- End of UK
  -- US
  start_section('US Legislation');
	 set_item_result(run_stored_sig('US_FEDERAL_DETAILS'));
	 set_item_result(run_stored_sig('US_STATE_DETAILS'));
	 set_item_result(run_stored_sig('US_CITY_DETAILS'));
	 set_item_result(run_stored_sig('US_COUNTY_DETAILS'));
	 set_item_result(run_stored_sig('US_VERTEX_ELE_ENTRIES'));
	 set_item_result(run_stored_sig('US_WORKER_COMP_ELE_ENTR'));
	 set_item_result(run_stored_sig('ADDRESS_VALID_TABLE_COUNTS'));
  end_section;
  -- End of US
  start_section('WorkFlow');
     set_item_result(run_stored_sig('WF_LOCAL_ROLES_DETAILS'));
     set_item_result(run_stored_sig('WF_USER_ROLES_DETAILS'));
     set_item_result(run_stored_sig('WF_LOCAL_USER_ROLES_DETAILS'));
     set_item_result(run_stored_sig('WF_USER_ROLE_ASG_DETAILS'));
  end_section;  
  
  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #15
  print_out('<a href="https://community.oracle.com/thread/3577897" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

---------------------------------
-- MAIN ENTRY POINT FOR CONC PROC
-- only needed if passing parameters
---------------------------------
-- PSD #18
/*PROCEDURE main_cp(
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_org_id          IN NUMBER   DEFAULT null,
      p_trx_type        IN VARCHAR2 DEFAULT 'PO',
      p_po_num          IN VARCHAR2 DEFAULT null,
      p_req_num         IN VARCHAR2 DEFAULT null,
      p_release_num     IN NUMBER   DEFAULT null,
      p_from_date       IN VARCHAR2 DEFAULT null,
      p_max_output_rows IN NUMBER   DEFAULT 20,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

l_trx_num VARCHAR2(25);

BEGIN
  g_retcode := 0;
  g_errbuf := null;
  l_trx_num := nvl(p_po_num, p_req_num);
-- PSD #19  
  main(
      p_org_id => p_org_id,
      p_trx_type => p_trx_type,
      p_trx_num => l_trx_num,
      p_release_num => p_release_num,
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode);

  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;*/


BEGIN

  IF l_person_id is not null THEN
    
    IF l_max_rows < 0 THEN
      l_max_rows := 50;
    END IF;
  
    IF l_from_date is null or l_from_date = TO_DATE ('31-DEC-9999')
    THEN
      l_from_date := (sysdate-90);
    END IF;
  
  -- PSD #16
     main(
        p_person_id => l_person_id,      
        p_from_date => l_from_date,
        p_max_output_rows => l_max_rows,
        p_debug_mode => 'Y');
      
  END IF;  
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;