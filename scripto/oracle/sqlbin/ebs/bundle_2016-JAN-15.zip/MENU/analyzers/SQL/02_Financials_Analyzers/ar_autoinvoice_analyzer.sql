SET DEFINE '~'

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.25                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ar_autoinvoice_analyzer.sql                                          |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+

-- PSD #1
CREATE OR REPLACE PACKAGE ar_autoinvoice_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-- PSD #10
PROCEDURE main (
    p_org_id          IN NUMBER,
    p_request_id      IN NUMBER DEFAULT 0,
    p_resp_id         IN NUMBER);

-- PSD #16	  
PROCEDURE main_cp (
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,    
      p_org_id          IN NUMBER,
      p_request_id      IN NUMBER DEFAULT 0,
      p_resp_id         IN NUMBER DEFAULT 0);

-- PSD #1
END ar_autoinvoice_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY ar_autoinvoice_analyzer_pkg AS
-- PSD #1a
-- $Id: ar_autoinvoice_analyzer_pkg.sql, 200.3 2015/10/19 vcrisost Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #15  
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1523525.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;

-- AutoInvoice variables
g_request_id      NUMBER;
g_org_id          NUMBER;
g_resp_id         NUMBER;
g_select          VARCHAR2(32767);
g_tax             VARCHAR2(32767);
g_apps_version    VARCHAR2(2);


----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'AR_AutoInvoice_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'AR_AutoInvoice_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Browser tab title
  -- PSD #2a: 
  -- Example: '<TITLE>WF Analyzer Report</TITLE>'
  print_out('<TITLE>EBS Oracle Receivables AutoInvoice Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1523525.1:AR_AUTOINV_200_1">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/ar_autoinv_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;

EXCEPTION
WHEN OTHERS THEN
   null;

END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
 
	 IF nvl(sig_count,0) > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
-- PSD #4
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;

  CURSOR get_app_date(p_ptch VARCHAR2) IS
  SELECT max(pr.start_date) app_date
  FROM ad_patch_runs pr
  WHERE pr.patch_run_id in (
          SELECT prb.patch_run_id
          FROM   ad_bugs b,
                 ad_patch_run_bugs prb
          WHERE  b.bug_number = p_ptch
          AND    prb.bug_id = b.bug_id
          UNION
          SELECT pr2.patch_run_id
          FROM ad_applied_patches ap,
               ad_patch_drivers pd,
               ad_patch_runs pr2
          WHERE ap.patch_name = p_ptch
          AND   pd.applied_patch_id = ap.applied_patch_id
          AND   pr2.patch_driver_id = pd.patch_driver_id);
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #4a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,2) = '12' THEN
    l_step := '20';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := 'N/A';
    l_col_rows(2)(1) := 'N/A';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'FOR REVIEW: R12.0 Oracle Receivables Critical & Recommended Patches';
    l_col_rows(5)(1) := '[1473872.1]';

    l_step := '30';
    l_col_rows.extend(5);
    l_col_rows(1)(2) := '2134094';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'R12.1: Receivables Recommended Patch Collection (AR RPC), Aug 2015';
    l_col_rows(5)(2) := '[2042517.1]';

    l_col_rows(1)(3) := '21213464';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'R12.1: E-Business Tax Recommended Patch Collection (ZX), Aug 2015';
    l_col_rows(5)(3) := '[1481235.1]';

    l_col_rows(1)(4) := '21276870';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'R12.1: E-Business Tax Reporting Ledger Recommended Patch Collection (ZX), Aug 2015';
    l_col_rows(5)(4) := '[1481235.1]';

  -- PSD #4a-end


  END IF;
  -- Check if applied
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i));
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'Y') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters (
    p_org_id          IN VARCHAR2,
    p_request_id      IN NUMBER,
    p_resp_id         IN NUMBER) IS


  l_from_date    VARCHAR2(25);
  l_to_date      VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;

  -- AI params
  invalid_parameters EXCEPTION;

begin

 -- get the applications version
  BEGIN
    SELECT max(release_name)
    INTO   l_apps_version
    FROM   fnd_product_groups;
    
    SELECT instance_name, host_name
      INTO l_instance, l_host
      FROM v$instance;
      
  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '||sqlerrm);
    raise invalid_parameters;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.3 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/10/19 14:28:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_apps_version := substrb(l_apps_version,1,2);
  
-- PSD #7
  g_rep_info('File Name') := 'ar_autoinvoice_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1523525.1" target="_blank">(Note 1523525.1)</a> ' || ' is a self-service health-check script that reviews your AutoInvoice Interface data and the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');
  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------

  print_log('ar_autoinvoice_analyzer.sql');
  print_log('File Version = ' || l_revision);   
  print_log('Execution Date = ' || to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'));
  print_log('--------------------------------------------------------------');
  print_log('Parameters passed in are: ');
  print_log('   p_org_id = ' || p_org_id);
  print_log('   p_request_id = ' || p_request_id);
  print_log('   p_resp_id = ' || p_resp_id);
  print_log('--------------------------------------------------------------');
  print_log('Validating parameters');
  
  -- PSD #7a
  -- Validate p_org_id
  IF p_org_id is not null THEN
     BEGIN
        -- check if this org has interface rows to process
        
        select organization_id 
        into   g_org_id
        from   hr_operating_units
        where  p_org_id = organization_id
        and    p_org_id in
          (SELECT DISTINCT il.org_id
           FROM ra_interface_lines_all il
           WHERE il.interface_line_id IS NOT NULL
           UNION
           SELECT DISTINCT il.org_id
           FROM  ra_interface_errors_all il
           UNION
           SELECT DISTINCT il.org_id
           FROM ra_interface_salescredits_all il
           WHERE il.interface_salescredit_id IS NOT NULL
           UNION
           SELECT DISTINCT il.org_id
           FROM ra_interface_distributions_all il
           WHERE il.interface_distribution_id IS NOT NULL);    

        print_log('1. g_org_id = ' || g_org_id || ' has interface rows to process. Setting org context');                 
     EXCEPTION
     WHEN NO_DATA_FOUND then
        BEGIN     
           -- validate if this org is valid at all
           select org_id
           into   g_org_id
           from   ar_system_parameters_all
           where  org_id = p_org_id
           and    rownum < 2;

           print_log('1. g_org_id = ' || g_org_id || ' is a valid ORG_ID. Setting org context');        
        EXCEPTION
        WHEN NO_DATA_FOUND then
            
           -- this org has no interface lines to process and does NOT exist in param table
           print_log('Error invalid value for p_org_id = ' || p_org_id);       
           RAISE invalid_parameters;
        END;
     END;
     mo_global.set_policy_context('S', g_org_id); 
     arp_global.init_global;
  ELSE
     print_log('Error invalid value for p_org_id = ' || p_org_id);
     RAISE invalid_parameters;
  END IF;
  
     
  -- validate p_request_id
  IF nvl(p_request_id, 0) <> 0 then
     BEGIN
        select request_id
        into g_request_id
        from ra_customer_trx_all
        where org_id = g_org_id
        and   request_id = p_request_id
        and rownum < 2;
     EXCEPTION
     WHEN NO_DATA_FOUND then      
        print_log('Error invalid value for p_request_id = ' || p_request_id || ' no interface records exist for this request_id. Setting default value to 0.'); 
        g_request_id := 0;
     END;
  ELSE
     -- p_request_id = 0 means you are not running it against a particular request id
    g_request_id := 0;   
  END IF;
  print_log('2. g_request_id = ' || g_request_id);   
  
  IF p_resp_id <> 0 then
     begin
        -- RESP_ID should be a RECEIVABLES responsibility 
        select responsibility_id
        into g_resp_id
        from fnd_responsibility
        where responsibility_id = p_resp_id
        and application_id = 222;        
     EXCEPTION
     WHEN NO_DATA_FOUND THEN
        print_log('Invalid Receivables Responsibility ID. Process cannot continue.');
        RAISE invalid_parameters;
     END;
  END IF;  
  print_log('3. g_resp_id = ' || g_resp_id);
  
  -- Create global hash for parameters. Numbers required for the output order
  G_PARAMETERS('1. Org ID') := g_org_id;
  G_PARAMETERS('2. Request Id') := g_request_id;
  G_PARAMETERS('3. Resp Id') := g_resp_id;
  
  -- Create global hash of SQL token values
  g_sql_tokens('##$$ORG_ID$$##') := g_org_id;
  g_sql_tokens('##$$REQUEST_ID$$##') := g_request_id;
  g_sql_tokens('##$$RESP_ID$$##') := g_resp_id;

/*  
  -- errors from the AutoInvoice validation engine
  -- this is the ORIG select with many fields, eliminated many of them in the select used for SIGs
  
  g_select :=  'SELECT intferr.message_text,
    intferr.invalid_value,
    intferr.org_id, 
    intfline.batch_source_name,
    intfline.interface_line_id,
    intfline.interface_line_context,
    intferr.interface_salescredit_id,
    intferr.interface_distribution_id,
    intfline.last_update_date last_processed_date,
    intfline.interface_line_attribute1,
    intfline.interface_line_attribute2,
    intfline.interface_line_attribute3,
    intfline.interface_line_attribute4,
    intfline.interface_line_attribute5,
    intfline.interface_line_attribute6,
    intfline.interface_line_attribute7,
    intfline.interface_line_attribute8,
    intfline.interface_line_attribute9,
    intfline.interface_line_attribute10,
    intfline.interface_line_attribute11,
    intfline.interface_line_attribute12,
    intfline.interface_line_attribute13,
    intfline.interface_line_attribute14,
    intfline.interface_line_attribute15,
    (SELECT user_name
    FROM fnd_user
    WHERE user_id = intfline.last_updated_by
    AND rownum    < 2
    ) last_processed_by,
    intfline.sales_order,
    intfline.sales_order_line,
    intfline.sales_order_date,
    intfline.sales_order_source,
    intfline.sales_order_revision,
    intfline.cust_trx_type_name,
    intfline.cust_trx_type_id,
    intfline.orig_system_bill_customer_ref,
    intfline.orig_system_bill_customer_id,
    intfline.orig_system_bill_address_ref,
    intfline.orig_system_bill_address_id,
    intfline.orig_system_bill_contact_ref,
    intfline.orig_system_bill_contact_id,
    intfline.orig_system_ship_customer_ref,
    intfline.orig_system_ship_customer_id,
    intfline.orig_system_ship_address_ref,
    intfline.orig_system_ship_address_id,
    intfline.orig_system_ship_contact_ref,
    intfline.orig_system_ship_contact_id,
    intfline.gl_date,
    intfline.trx_date,
    intfline.ship_date_actual,
    intfline.trx_number,
    intfline.line_type,
    intfline.inventory_item_id,
    intfline.description,
    intfline.tax_regime_code,
    intfline.tax,
    intfline.tax_status_code,
    intfline.tax_rate_code,
    intfline.tax_jurisdiction_code,
    intfline.request_id
  FROM ra_interface_errors_all intferr,
    ra_interface_lines_all intfline,
    fnd_new_messages msg
  where msg.message_text = intferr.message_text
  AND msg.language_code = ''US''
  AND intferr.interface_line_id = intfline.interface_line_id
  AND intferr.org_id  IN (##$$ORG_ID$$##)';
*/

  if g_apps_version = '12' then
     -- errors from the AutoInvoice validation engine
     g_select :=  'SELECT 
       intfline.request_id,
       intfline.interface_line_id,
       intfline.line_type,
       intfline.set_of_books_id,
       intfline.batch_source_name,
       intfline.gl_date,
       intfline.trx_date,
       intfline.amount,
       intfline.currency_code,
       intfline.conversion_type,
       intfline.uom_name,
       intfline.uom_code,
       intfline.description,
       intfline.interface_line_context,
       intferr.message_text,
       intferr.invalid_value,
       intfline.sales_order,
       intferr.interface_salescredit_id,
       intferr.interface_distribution_id,
       intfline.primary_salesrep_number,                                                                                                                                                                                  
       intfline.primary_salesrep_id,
       intfline.cust_trx_type_name,
       intfline.cust_trx_type_id,
       intfline.orig_system_bill_customer_ref,
       intfline.orig_system_bill_customer_id,
       intfline.orig_system_bill_address_ref,
       intfline.orig_system_bill_address_id,
       intfline.orig_system_bill_contact_ref,
       intfline.orig_system_bill_contact_id,
       intfline.orig_system_ship_customer_ref,
       intfline.orig_system_ship_customer_id,
       intfline.orig_system_ship_address_ref,
       intfline.orig_system_ship_address_id,
       intfline.orig_system_ship_contact_ref,
       intfline.orig_system_ship_contact_id,
       intfline.tax_regime_code,
       intfline.tax,
       intfline.tax_status_code,
       intfline.tax_rate_code,
       intfline.tax_jurisdiction_code,
       intfline.fob_point,
       intfline.ship_via,
       intfline.accounting_rule_name,
       intfline.accounting_rule_id,
       intfline.agreement_name,
       intfline.agreement_id
     FROM ra_interface_errors_all intferr,
       ra_interface_lines_all intfline,
       fnd_new_messages msg
     where msg.message_text = intferr.message_text
      AND msg.language_code = ''US''
      AND intferr.interface_line_id = intfline.interface_line_id
      AND intferr.org_id  IN (##$$ORG_ID$$##)';
  else
     g_select :=  'SELECT 
       intfline.request_id,
       intfline.interface_line_id,
       intfline.line_type,
       intfline.set_of_books_id,
       intfline.batch_source_name,
       intfline.gl_date,
       intfline.trx_date,
       intfline.amount,
       intfline.currency_code,
       intfline.conversion_type,
       intfline.uom_name,
       intfline.uom_code,
       intfline.description,
       intfline.interface_line_context,
       intferr.message_text,
       intferr.invalid_value,
       intfline.sales_order,
       intferr.interface_salescredit_id,
       intferr.interface_distribution_id,
       intfline.primary_salesrep_number,                                                                                                                                                                                  
       intfline.primary_salesrep_id,
       intfline.cust_trx_type_name,
       intfline.cust_trx_type_id,
       intfline.orig_system_bill_customer_ref,
       intfline.orig_system_bill_customer_id,
       intfline.orig_system_bill_address_ref,
       intfline.orig_system_bill_address_id,
       intfline.orig_system_bill_contact_ref,
       intfline.orig_system_bill_contact_id,
       intfline.orig_system_ship_customer_ref,
       intfline.orig_system_ship_customer_id,
       intfline.orig_system_ship_address_ref,
       intfline.orig_system_ship_address_id,
       intfline.orig_system_ship_contact_ref,
       intfline.orig_system_ship_contact_id,
       intfline.tax_rate,
       intfline.tax_code,
       intfline.fob_point,
       intfline.ship_via,
       intfline.accounting_rule_name,
       intfline.accounting_rule_id,
       intfline.agreement_name,
       intfline.agreement_id
     FROM ra_interface_errors_all intferr,
       ra_interface_lines_all intfline,
       fnd_new_messages msg
     where msg.message_text = intferr.message_text
      AND msg.language_code = ''US''
      AND intferr.interface_line_id = intfline.interface_line_id
      AND intferr.org_id  IN (##$$ORG_ID$$##)';
  end if;
  

  -- errors from the Tax validation engine
  g_tax :=  'SELECT intferr.org_id, 
    msg.message_name,
    intfline.batch_source_name,
    intfline.interface_line_id,
    intfline.interface_line_context,
    intferr.interface_salescredit_id,
    intferr.interface_distribution_id,
    intfline.last_update_date last_processed_date,
    intfline.interface_line_attribute1,
    intfline.interface_line_attribute2,
    intfline.interface_line_attribute3,
    intfline.interface_line_attribute4,
    intfline.interface_line_attribute5,
    intfline.interface_line_attribute6,
    intfline.interface_line_attribute7,
    intfline.interface_line_attribute8,
    intfline.interface_line_attribute9,
    intfline.interface_line_attribute10,
    intfline.interface_line_attribute11,
    intfline.interface_line_attribute12,
    intfline.interface_line_attribute13,
    intfline.interface_line_attribute14,
    intfline.interface_line_attribute15,
    (SELECT user_name
    FROM fnd_user
    WHERE user_id = intfline.last_updated_by
    AND rownum    < 2
    ) last_processed_by,
    intfline.sales_order,
    intfline.sales_order_line,
    intfline.sales_order_date,
    intfline.sales_order_source,
    intfline.sales_order_revision,
    intfline.cust_trx_type_name,
    intfline.cust_trx_type_id,
    intfline.orig_system_bill_customer_ref,
    intfline.orig_system_bill_customer_id,
    intfline.orig_system_bill_address_ref,
    intfline.orig_system_bill_address_id,
    intfline.orig_system_bill_contact_ref,
    intfline.orig_system_bill_contact_id,
    intfline.orig_system_ship_customer_ref,
    intfline.orig_system_ship_customer_id,
    intfline.orig_system_ship_address_ref,
    intfline.orig_system_ship_address_id,
    intfline.orig_system_ship_contact_ref,
    intfline.orig_system_ship_contact_id,
    intfline.gl_date,
    intfline.trx_date,
    intfline.ship_date_actual,
    intfline.trx_number,
    intfline.line_type,
    intfline.inventory_item_id,
    intfline.description,
    intfline.tax_regime_code,
    intfline.tax,
    intfline.tax_status_code,
    intfline.tax_rate_code,
    intfline.tax_jurisdiction_code,
    intfline.request_id,
    NULL,
    NULL,
    intferr.message_text,
    intferr.invalid_value,
    NULL,
    intferr.message_text,
    NULL,
    NULL,
    NULL,
    NULL
  FROM ra_interface_errors intferr,
    ra_interface_lines intfline,
    fnd_new_messages msg
  WHERE intferr.message_text    = msg.message_text
  AND intferr.interface_line_id = intfline.interface_line_id
  AND msg.language_code         = ''US''
  AND msg.message_name like ''ZX%''  
  AND intferr.org_id = ##$$ORG_ID$$##';

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;



---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN
-- PSD #9
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------
  
  -------------------------------------------------------------------
  -- Example signature that can be used to check for invalid objects
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''AR%'')
    AND a.status = ''INVALID''',
   'Receivables Related Invalid Objects',
   'RS',
   'There exist invalid Receivables related objects.',
   '<ul>
      <li>Recompile the individual objects manually or recompile the entire APPS schema with adadmin utility.</li>
      <li>Review any error messages provided.</li>
   </ul>',
   'No Receivables related invalid objects exists in the database.',
   'ALWAYS',
   'E'
   );

-----------------------------Orphan records in interface tables ---------------------------------------  
add_signature
('ORPHAN_ERR',
 'SELECT DECODE(interface_line_id, NULL,
  DECODE(interface_salescredit_id, NULL, ''Interface Distributions (RA_INTERFACE_DISTRIBUTIONS_ALL)'',
  ''Interface Salescredits (RA_INTERFACE_SALESCREDITS_ALL)''), ''Interface Lines (RA_INTERFACE_LINES_ALL)'') interface_table,
  NVL(interface_line_id, NVL(interface_salescredit_id,interface_salescredit_id)) Missing_Record_interface_ID
  FROM ra_interface_errors_all err 
  WHERE 
  ((interface_line_id IS NOT NULL
    AND NOT EXISTS
    (SELECT interface_line_id
     FROM ra_interface_lines_all
     WHERE interface_line_id = err.interface_line_id
    ))
    OR 
    (interface_salescredit_id IS NOT NULL
     AND NOT EXISTS
      (SELECT interface_salescredit_id
       FROM ra_interface_salescredits_all
       WHERE interface_salescredit_id = err.interface_salescredit_id))
    OR 
    (interface_distribution_id IS NOT NULL 
     AND NOT EXISTS
      (SELECT interface_distribution_id
       FROM ra_interface_distributions_all
       WHERE interface_distribution_id = err.interface_distribution_id
     )))
  AND err.org_id = ##$$ORG_ID$$##
  ORDER BY 1,2',
'Orphan Records in AutoInvoice Interface Errors Table',
'RS',
'This is an Information Check, to inform you that there are some orphan records in the RA_INTERFACE_ERRORS_ALL table. Orphan records are those for which a corresponding record does not exist in the RA_INTERFACE_LINES_ALL/ RA_INTERFACE_SALESCREDITS_ALL/ RA_INTERFACE_DISTRIBUTIONS_ALL.',
'It is advisible to delete such orphan records from the RA_INTERFACE_ERRORS_ALL table to ensure the table size does not increase with unwanted records. <br>
 You can use the below script to DELETE the orphan records:<br>
 <blockquote>
 DELETE ra_interface_errors_all err<br>
 WHERE (interface_line_id IS NOT NULL<br>
 AND NOT EXISTS<br>
 (SELECT interface_line_id<br>
 FROM ra_interface_lines_all<br>
 WHERE interface_line_id = err.interface_line_id))<br>
 OR (interface_salescredit_id IS NOT NULL<br>
 AND NOT EXISTS<br>
 (SELECT interface_salescredit_id<br>
  FROM ra_interface_salescredits_all<br>
  WHERE interface_salescredit_id = err.interface_salescredit_id))<br>
  OR (interface_distribution_id IS NOT NULL<br>
  AND NOT EXISTS<br>
 (SELECT interface_distribution_id<br>
  FROM ra_interface_distributions_all<br>
  WHERE interface_distribution_id = err.interface_distribution_id));<br>
  COMMIT;</blockquote>',
'No Orphan Records in Interface Errors Table.',
'FAILURE',
'W',
'RS',
'Y');

add_signature
('ORPHAN_DIST',
'SELECT intfdist.org_id,
        intfdist.account_class,
        intfdist.amount,
        intfdist.percent,
        intfdist.code_combination_id,
        intfdist.segment1,
        intfdist.segment2,
        intfdist.segment3,
        intfdist.segment4,
        intfdist.segment5,
        intfdist.interface_line_context,
        intfdist.interface_line_attribute1,
        intfdist.interface_line_attribute2,
        intfdist.interface_line_attribute3,
        intfdist.interface_line_attribute4,
        intfdist.interface_line_attribute5
FROM ra_interface_distributions intfdist
WHERE intfdist.org_id = ##$$ORG_ID$$##
AND NOT EXISTS
        (SELECT interface_line_id
         FROM ra_interface_lines intfline
         WHERE intfline.interface_line_context = intfdist.interface_line_context
          AND NVL(intfline.interface_line_attribute1,''~'') = NVL(intfdist.interface_line_attribute1 ,''~'')
          AND NVL(intfline.interface_line_attribute2,''~'') = NVL(intfdist.interface_line_attribute2 ,''~'')
          AND NVL(intfline.interface_line_attribute3,''~'') = NVL(intfdist.interface_line_attribute3,''~'')
          AND NVL(intfline.interface_line_attribute4,''~'') = NVL(intfdist.interface_line_attribute4 ,''~'')
          AND NVL(intfline.interface_line_attribute5,''~'') = NVL(intfdist.interface_line_attribute5 ,''~'')
          AND NVL(intfline.interface_line_attribute6,''~'') = NVL(intfdist.interface_line_attribute6 ,''~'')
          AND NVL(intfline.interface_line_attribute7,''~'') = NVL(intfdist.interface_line_attribute7 ,''~'')
          AND NVL(intfline.interface_line_attribute8,''~'') = NVL(intfdist.interface_line_attribute8 ,''~'')
          AND NVL(intfline.interface_line_attribute9,''~'') = NVL(intfdist.interface_line_attribute9 ,''~'')
          AND NVL(intfline.interface_line_attribute10,''~'') = NVL(intfdist.interface_line_attribute10,''~'')
          AND NVL(intfline.interface_line_attribute11,''~'') = NVL(intfdist.interface_line_attribute11 ,''~'')
          AND NVL(intfline.interface_line_attribute12,''~'') = NVL(intfdist.interface_line_attribute12 ,''~'')
          AND NVL(intfline.interface_line_attribute13,''~'') = NVL(intfdist.interface_line_attribute13 ,''~'')
          AND NVL(intfline.interface_line_attribute14,''~'') = NVL(intfdist.interface_line_attribute14,''~'')
          AND NVL(intfline.interface_line_attribute15,''~'') = NVL(intfdist.interface_line_attribute15,''~'') )',
          'Orphan Interface Account Distributions Records',
'RS',
'Orphan Records in Interface Distributions table',
'Ideally, if you want to pass account distributions for an Interface Lines record, you should provide the account related info in the Interface Distributions Table. To identify for which line you are providing the account distributions, you should make sure that the INTERFACE_LINE_CONTEXT and INTERFACE_LINE_ATTRIBUTE1-15 columns in the Interface Distributions Table are the same as line record  in the Interface Lines table. <br>
If there is an issue with your pre-processor logic that populates the Interface Distributions table, you should correct it first.<br>
You can then choose to edit the Interface Distributions table entries to match the line entry, or delete the existing invalid entries from Interface Distributions table and re-run the logic to populate the records correctly.',
'No Orphan Records in Interface Account Distributions Table.',
'FAILURE',
'W',
'RS',
'Y');

add_signature(
'ORPHAN_SALES',
'SELECT intfsales.org_id,
        intfsales.salesrep_number,
        intfsales.salesrep_id,
        intfsales.sales_credit_type_name,
        intfsales.sales_credit_type_id,
        intfsales.sales_credit_amount_split,
        intfsales.sales_credit_percent_split,
        intfsales.salesgroup_id,
        intfsales.interface_line_context,
        intfsales.interface_line_attribute1,
        intfsales.interface_line_attribute2,
        intfsales.interface_line_attribute3,
        intfsales.interface_line_attribute4,
        intfsales.interface_line_attribute5
      FROM ra_interface_salescredits intfsales
      WHERE intfsales.org_id = ##$$ORG_ID$$##
      AND NOT EXISTS
        (SELECT interface_line_id
         FROM ra_interface_lines intfline
         WHERE intfline.interface_line_context = intfsales.interface_line_context
          AND NVL(intfline.interface_line_attribute1,''~'') = NVL(intfsales.interface_line_attribute1 ,''~'')
          AND NVL(intfline.interface_line_attribute2,''~'') = NVL(intfsales.interface_line_attribute2 ,''~'')
          AND NVL(intfline.interface_line_attribute3,''~'') = NVL(intfsales.interface_line_attribute3,''~'')
          AND NVL(intfline.interface_line_attribute4,''~'') = NVL(intfsales.interface_line_attribute4 ,''~'')
          AND NVL(intfline.interface_line_attribute5,''~'') = NVL(intfsales.interface_line_attribute5 ,''~'')
          AND NVL(intfline.interface_line_attribute6,''~'') = NVL(intfsales.interface_line_attribute6 ,''~'')
          AND NVL(intfline.interface_line_attribute7,''~'') = NVL(intfsales.interface_line_attribute7 ,''~'')
          AND NVL(intfline.interface_line_attribute8,''~'') = NVL(intfsales.interface_line_attribute8 ,''~'')
          AND NVL(intfline.interface_line_attribute9,''~'') = NVL(intfsales.interface_line_attribute9 ,''~'')
          AND NVL(intfline.interface_line_attribute10,''~'') = NVL(intfsales.interface_line_attribute10,''~'')
          AND NVL(intfline.interface_line_attribute11,''~'') = NVL(intfsales.interface_line_attribute11 ,''~'')
          AND NVL(intfline.interface_line_attribute12,''~'') = NVL(intfsales.interface_line_attribute12 ,''~'')
          AND NVL(intfline.interface_line_attribute13,''~'') = NVL(intfsales.interface_line_attribute13 ,''~'')
          AND NVL(intfline.interface_line_attribute14,''~'') = NVL(intfsales.interface_line_attribute14,''~'')
          AND NVL(intfline.interface_line_attribute15,''~'') = NVL(intfsales.interface_line_attribute15,''~'') )',
'Orphan Interface SalesCredit Records',
'RS',
'This section lists all the Interface Salescredits table that do have a corresponding record in the Interface Lines table.',
'Ideally, if you want to pass Sales Credits for an Interface Lines table record, you should provide the Sales Credit info in the Interface SalesCredits Table. To identify for which line you are providing the salescredits, you should make sure that the INTERFACE_LINE_CONTEXT and INTERFACE_LINE_ATTRIBUTE1-15 columns in the Interface SalesCredits Table are the same as line record  in the Interface Lines table. <br>
If there is an issue with your pre-processor logic that populates the Interface SalesCredits table, you should correct it first.<br>
You can then choose to edit the Interface SalesCredits table entries to match the line entry, or delete the existing invalid entries from Interface SalesCredits table and re-run the logic to populate the records correctly.',
'No Orphan Records in Interface SalesCredits Table.',
'FAILURE',
'W',
'RS',
'Y');

/*add_signature('AutoInvoice Master Program Status','SELECT parent_request_id,
  ''AutoInvoice Master Program'',
  phase_lkp.meaning,
  status_lkp.meaning,
  config.failure_short_message,
  config.failure_message,
  config.doc_id,
  config.doc_descr
FROM
  (SELECT req.request_id,
    parent_req.request_id parent_request_id,
    parent_req.phase_code,
    parent_req.status_code
  FROM fnd_concurrent_requests parent_req,
    fnd_concurrent_programs prog ,
    fnd_concurrent_requests req
  WHERE parent_req.concurrent_program_id = prog.concurrent_program_id
  AND prog.concurrent_program_name       = ''RAXMTR''
  AND parent_req.request_id              = req.parent_request_id
  UNION
  SELECT request_id child_req,
    request_id master_req,
    phase_code,
    status_code
  FROM fnd_concurrent_requests parent_req,
    fnd_concurrent_programs prog
  WHERE parent_req.concurrent_program_id = prog.concurrent_program_id
  AND prog.concurrent_program_name       = ''RAXMTR''
  ) ai_req,
  ra_interface_postproc_config config,
  fnd_lookups status_lkp,
  fnd_lookups phase_lkp
WHERE config.check_number  = :p_check_number
AND ai_req.phase_code      = phase_lkp.lookup_code
AND phase_lkp.lookup_type  = ''CP_PHASE_CODE''
AND ai_req.status_code     = status_lkp.lookup_code
AND status_lkp.lookup_type = ''CP_STATUS_CODE''
AND ai_req.request_id      = :p_request_id
AND (ai_req.status_code <> ''C'' OR ai_req.phase_code <> ''C'')','AutoInvoice Master Program Request Validation','RS','<p>The  AutoInvoice Master Program accepts parameters for selection of interfaced records to process. Based on the volume of records to process, the AutoInvoice Master program may submit one or more AutoInvoice Import program. </p>
<p>The AutoInvoice Master Program may crash out for various reasons. Or,  it may complete successfully, but may not submit AutoInvoice Import programs thus leaving interfaced records unprocessed. For troubleshooting such issues, refer to this Document: </p>
<ul>
  <li>  [1094863.1] Troubleshooting AutoInvoice Master Program Issues including Errors, Warnings and When No Data Imports</li>
</ul>','<p>The  AutoInvoice Master Program accepts parameters for selection of interfaced records to process. Based on the volume of records to process, the AutoInvoice Master program may submit one or more AutoInvoice Import program. </p>
<p> If the AutoInvoice Master Program request complets with Status =<em>Error</em> then you can use the suggested Knowledge Article for finding the root cause of the error. Please refer to Log file of the concurrent request for clues on what is wrong.</p>
<p>The  document also has some useful tips on resolving issues with stuck interface records. If you find that the AutoInvoice Master program completed without any error, but the log contains <em><strong>No data found</strong></em> error, you can refer to the section <em>3. AutoInvoice Completes With No Data Found And AutoInvoice Import Is Not Spawned</em>.</p>
',' ',
'FAILURE',
   'N',
   'W',
   'RS',
   'Y');

/* add_signature('Performance Improvement Patches for AutoInvoice','SELECT patch_number,
  CASE WHEN bug_number IS NULL THEN ''Not Applied''
       ELSE ''Applied'' END patch_applied
FROM
  (SELECT patch_number ,
    apps_release
  FROM ra_interface_pp_patches
  WHERE check_number = 0.73
  ) perf_patches,
  (SELECT bug_number FROM ad_bugs
  UNION
  SELECT patch_name FROM ad_applied_patches
  ) applied_patches,
  (SELECT
    CASE
      WHEN MAX(release_name) LIKE ''12%''
      THEN ''R12''
      WHEN MAX(release_name) LIKE ''11.5%''
      THEN ''11i''
    END app_rel
  FROM fnd_product_groups
  ) apps_release
WHERE perf_patches.patch_number = applied_patches.bug_number (+)
AND perf_patches.apps_release   = apps_release.app_rel
','Performance Patches','RS','<p> This check  is to verify if the patches that are related to improving the AutoInvoice Performance are applied. </p>','<ol>
  <li>Check the Readme of the suggested patch and verify if this matches your requirement</li>
  <li>If yes, then apply the patch on a TEST instance and verify the results mathc your expectations</li>
  <li>Roll out the changes to a production instance once you complete the test successfully </li>
</ol>
',' ',
'FAILURE',
   'N',
   'W',
   'RS',
   'Y');

add_signature('Patches recently released for AutoInvoice','SELECT patch_number,
  CASE WHEN bug_number IS NULL THEN ''Not Applied''
       ELSE ''Applied'' END patch_applied
FROM
  (SELECT patch_number ,
    apps_release
  FROM ra_interface_pp_patches
  WHERE check_number = 0.74
  ) perf_patches,
  (SELECT bug_number FROM ad_bugs
  UNION
  SELECT patch_name FROM ad_applied_patches
  ) applied_patches,
  (SELECT
    CASE
      WHEN MAX(release_name) LIKE ''12%''
      THEN ''R12''
      WHEN MAX(release_name) LIKE ''11.5%''
      THEN ''11i''
    END app_rel
  FROM fnd_product_groups
  ) apps_release
WHERE perf_patches.patch_number = applied_patches.bug_number (+)
AND perf_patches.apps_release   = apps_release.app_rel
','Recent Patches','RS','<p> This check  is to verify if the patches that were released for AutoInvoice code changes to fix some issues. </p>','<ol>
  <li>Check the Readme of the suggested patch and verify if this matches your requirement</li>
  <li>If yes, then apply the patch on a TEST instance and verify the results mathc your expectations</li>
  <li>Roll out the changes to a production instance once you complete the test successfully </li>
</ol>
',' ',
'FAILURE',
   'N',
   'W',
   'RS',
   'Y');
   
-- VC: are we still capable of doing this if there is no longer ra_interface_postproc_config??
add_signature(
'List All the Checks',
'SELECT check_category,
 ai_error_text error_message,
 NVL(ai_error_code,NVL(sql_query, api_name)) error_code,
 failure_short_message check_details_impact,
 failure_message recommendation,
 CASE
    WHEN doc_id IS NULL
    THEN ''
    ELSE ''<a href="https://support.oracle.com/oip/faces/secure/km/DocumentDisplay.jspx?id=''
      || doc_id
      || ''"" > ''
      || doc_id
      || ''</a>: ''
      || doc_descr
  END knowledge_article
FROM ra_interface_postproc_config
WHERE check_type IS NULL
ORDER BY 1,3',
'List All checks',
'RS',
'',
'',
' ',
'FAILURE',
'W',
'RS',
'Y');


*/



add_signature(
'Interface Records with NULL ORG_ID',
'SELECT batch_source_name,  COUNT(*)
FROM ra_interface_lines_all
WHERE ORG_ID IS NULL
GROUP BY batch_source_name',
'ORG_ID is Null',
'RS',
'These records with ORG_ID = NULL will never be picked up for processed by AutoInvoice.',
'Make sure that there are no records in the Interface Lines table with NULL ORG_ID. If the records were wrongly populated:
<ul>
  <li>Update the records to have a correct ORG_ID </li>
  <li>Delete the records with a NULL ORG_ID using the script below:<br>
    DELETE ra_interface_lines_all<br>
    WHERE ORG_ID IS NULL;<br>
    <br>
  COMMIT; </li>
</ul>',
'No Interface Records with ORG_ID = NULL.',
'FAILURE',
'W',
'RS',
'Y');


add_signature(
'Processed Records Not Purged',
'SELECT DISTINCT batch_source_name, ''Yes'' Processed_records_exist
FROM ra_interface_lines il
WHERE il.org_id = (##$$ORG_ID$$##)
AND EXISTS
  (SELECT customer_trx_id
  FROM ra_interface_lines
  WHERE interface_status = ''P''
  AND customer_trx_id   IS NOT NULL
  )',
'Processed Records Not Purged',
'RS',
'If the processed records are not purged, the Interface tables size keeps growing. As the table size increases, the AutoInvoice Performance starts degrading.',
'There are two steps to be followed for a complete solution: <br>
<ol>
  <li>Check whether the System Option Purge Interface Table
has been set to Yes. If not, set it to Yes. This will make sure that  in future, AutoInvoice purges records after processing.</li>
  <li> Delete all the processed records from Interface Tables. If for some business requirement you need to store the processed records, you can archive them in a different table for record purpose. </li>
</ol>',
'There are no processed records to be purged.',
'FAILURE',
'W',
'RS',
'Y');


add_signature(
'TRANS_REQID',
'SELECT  ct.org_id,
  ct.request_id,
  bs.name,
  ct.trx_number,
  ps.payment_schedule_id,
  ps.status,
  DECODE( bs.default_reference,
                  1, ct.interface_header_attribute1,
                  2, ct.interface_header_attribute2,
                  3, ct.interface_header_attribute3,
                  4, ct.interface_header_attribute4,
                  5, ct.interface_header_attribute5,
                  6, ct.interface_header_attribute6,
                  7, ct.interface_header_attribute7,
                  8, ct.interface_header_attribute8,
                  9, ct.interface_header_attribute9,
                  10, ct.interface_header_attribute10,
                  11, ct.interface_header_attribute11,
                  12, ct.interface_header_attribute12,
                  13, ct.interface_header_attribute13,
                  14, ct.interface_header_attribute14,
                  15, ct.interface_header_attribute15) transaction_orig_sys_ref,
  DECODE (ctt.type, ''INV'',''Invoice'',''CM'',''Credit Memo'',''DM'',''Debit Memo'',ctt.type ) transaction_type,
  ctt.name transaction_type_name,
  ct.trx_date,
  DECODE(ct.complete_flag,''Y'',''Yes'',''No'') complete_flag,
  cust.orig_system_reference customer_original_sys_ref,
  ct.bill_to_customer_id,
  site_use.orig_system_reference site_use_original_sys_ref,
  ct.bill_to_site_use_id,
  site_use.site_use_code,
  site_use.location,
  ct.invoice_currency_code,
  ct.doc_sequence_value,
  ps.amount_due_original,
  ps.amount_due_remaining,
  ct.interface_header_context,
  CASE
    WHEN ct.printing_count > 0
    THEN ''Yes''
    ELSE ''No''
  END transaction_printed
FROM ra_customer_trx ct,
  ar_payment_schedules ps,
  ra_batch_sources bs,
  ra_cust_trx_types ctt,
  hz_cust_accounts cust,
  hz_cust_site_uses site_use
WHERE ct.customer_trx_id   = ps.customer_trx_id (+)
AND ct.batch_source_id     = bs.batch_source_id
AND ct.org_id = bs.org_id
AND ct.cust_trx_type_id = ctt.cust_trx_type_id
AND ct.org_id = ctt.org_id
AND ct.bill_to_customer_id = cust.cust_account_id
AND ct.bill_to_site_use_id = site_use.site_use_id
AND ct.request_id          = ##$$REQUEST_ID$$##
AND ct.org_id = ##$$ORG_ID$$##
ORDER BY 1,3,4,5,6',
'Transactions For Request ID',
'RS',
'The above lists transactions successfully created for Request ID provided',
'',
' ',
'FAILURE',
'I',
'RS',
'Y');

add_signature(
'AutoInvoice Interface Records Status',
'SELECT Batch_source_name,
  COUNT(request_id) Lines_Interfaced,
  interface_status
FROM ra_interface_lines il
WHERE NVL(interface_status,''~'')  <> ''P''
AND request_id IS NULL
AND il.org_id IN (##$$ORG_ID$$##)
group by Batch_source_name, interface_status',
'AutoInvoice Interface Records Status',
'RS',
'This check does not necessarily signify a failure. It is an Information Check, giving you an overall picture about the status of Interface Lines table.',
'Use this information to get a bigger picture of how much, and what type of data exists in the Interface Lines table. ',
' ',
'FAILURE',
'W',
'RS',
'Y');

add_signature('India Localization Issue',
'SELECT No_of_error_records
FROM
  (SELECT COUNT(*) No_of_error_records
  FROM JAI_AR_TRX_INS_LINES_T
  WHERE ERR_MESG=''Invoice has already been revenue recognized. Taxes related to invoice cannot be processed''
  AND ERROR_FLAG=''R''
  )
WHERE No_of_error_records > 0 ',
'India Localization Issue',
'RS',
'This check is to warn you about a possible failure of Create Accounting program at a later stage. This is observed in India Localization installation.',
'Please refer to the suggested Knowledge Article for further information on correcting this issue.',
-- VC: there is no note reference here??
' ',
'FAILURE',
'W',
'RS',
'Y');

--------------------Validation Errors Check

add_signature
('AG',
g_select || ' and msg.message_name = ''AG''',
'Not all AutoAccounting types are defined',
'RS',
'The setup of AutoAccounting is incomplete.',
'The validation code (in arcdsu.lpc) checks that the setup for the following account types have been defined:<br>
<ol><li>Freight (FREIGHT)</li>
<li>Receivable (REC)</li>
<li>Revenue (REV)</li>
<li>AutoInvoice Clearing (SUSPENSE)</li>
<li>Tax (TAX)</li>
<li>Unbilled Receivables (UNBILL)</li>
<li>Unearned Revenue (UNEARN)</li></ol>
Even if you do not plan to use one or more of above mentioned account classes, you still need to configure values for all these accounts. 
For accounts you do not plan to use, you can hard code the segments to a Constant value.<br><br>
For more information, read: [1344503.1] AutoInvoice Error: Not all AutoAccounting types are defined', 
' ',
'FAILURE',   
'E',   
'RS',   
'Y');


add_signature(
'AR_AUTOACC_COMPLETE_OFFSET',
g_select || ' and msg.message_name = ''AR_AUTOACC_COMPLETE_OFFSET''',
'Please complete the offset account assignments',
'RS',
'AutoAccounting was not able to derive the Unearned Revenue or Unbilled Receivable account. These two accounts are referred to as Offset accounts here.',
'This typically happens due to incorrect/incomplete setup. You should verify the following:<br>
<ol>
<li><b>Best Option:</b>: Use the AutoAccounting Analyzer to assist in identifying the cause of your AutoAccounting Error: [1904785.1] EBS Oracle Receivables AutoAccounting Analyzer</li>
  <li>Otherwise, manually check the setup of AutoAccounting as follows: <br>
   <b>  Responsibility:</b> Receivables Manager<br>
   <b>  Navigation:</b> Setup > Transactions > AutoAccounting<br>
    Search for Unearned Revenue or Unbilled Receivable Account type and see how you have set up the system to derive the Unearned Revenue or Unbilled Receivable Account.
You can select to source from a constant, customer bill-to site, salesperson, transaction type, and standard item values.<br>
If you select standard item, Receivables uses the Revenue Flexfield that you specified in the setup window. If you select salesperson, Receivables uses the salesperson''s Receivable Flexfield. </li>
  <li>Now check whether you have all the necessary setup in place for AutoAccounting to derive the Unearned Revenue or Unbilled Receivable Account. For example, if your AutoAccounting setup is such that one of the segments is derived from standard item, then verify if the Revenue Flexfield Account is specified for that item.<br>
   <b>  Responsibility:</b> Receivables Manager<br>
   <b>  Navigation:</b> Setup > Transactions > Items > Define Items<br>
    Query up the item on the interface line.</li>
  <li>If you find that all the setup is in place, and AutoAccounting was able to derive all segments values, then verify if there exists a valid Code Combination ID for the segments derived.<br>
   <b>  Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > Financials > Accounting > GL Accounts </li>
<li>For more information, read: [436831.1]  Autoinvoice errors with: Please complete the offset account assignments</li></ol>', 
' ',
'FAILURE',   
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1669',
g_select || ' and msg.message_name = ''AR_RAXTRX-1669''',
'The valid account class for this line type is CHARGES',
'RS',
'You are trying to import Account Distributions for a line type = CHARGES, but the Account Class supplied in the Interface Distributions table is not set to CHARGES.',
'Make sure that the value in RA_INTERFACE_LINES_ALL.LINE_TYPE = CHARGES.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error',
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );


add_signature(
'AR_RAXTRX-1670',
g_select || ' and msg.message_name = ''AR_RAXTRX-1670''',
'You must supply a charges account for your CHARGES line',
'RS','You must supply a Charges Account for your Charges Line if you have not set up AutoAccounting for Revenue Account.',
'Verify your setup of AutoAccounting. Make sure that you have completed the setup for the Revenue Account which will be used by Charges.<br>
<br>If you do not wish to use AutoAccounting for Charges, then you must provide a corresponding record in RA_INTERFACE_DISTRIBUTIONS_ALL and supply a value in CODE_COMBINATION_ID or the corresponding SEGMENT* fields for the CHARGES distribution.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1671', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1671''',
'Invalid account class (ACCOUNT_CLASS)',
'RS',
'You are trying to import Account Distributions and populated Interface Distributions table for transaction with Invoicing Rules and Accounting Rules. But the Account Class field has values that AutoInvoice does not recognize. The only valid values that will be accepted in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS are REV, FREIGHT, TAX, REC, UNBILL (for Arrears), UNEARN (for Advance), CHARGES.',
'Provide a valid value in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS. The valid values for a transaction with Rules are:<br>
REV, FREIGHT, TAX, REC, UNBILL (for Arrears), UNEARN (for Advance), CHARGES.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1672', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1672''',
'The valid account classes are: REV, FREIGHT, TAX and REC',
'RS',
'The only valid values that will be accepted in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS are REV, FREIGHT, TAX, REC, UNBILL (for Arrears), UNEARN (for Advance), CHARGES.',
'Provide a valid value in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS: REV, FREIGHT, TAX, REC.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the table above to find the distribution rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1673', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1673''',
'The valid account classes are: REV, FREIGHT, TAX, REC and UNEARN',
'RS',
'You populated Interface Distributions table, for a transaction with Bill in Advance Invoicing Rule. But the Account Class field has values that AutoInvoice does not recognize. <br>
The only valid values that will be accepted in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS are: REV, FREIGHT, TAX, REC, UNEARN (for Advance), CHARGES.',
'Correct the values provided in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS. The valid values are:<br>
REV, FREIGHT, TAX, REC, UNEARN (for Advance), CHARGES.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature
('AR_RAXTRX-1674', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1674''',
'The valid account classes are: REV, FREIGHT, TAX, REC and UNBILL',
'RS',
'You populated Interface Distributions table, for a transaction with Bill in Arrears Invoicing Rule. But the Account Class field has values that AutoInvoice does not recognize. <br>
The only valid values that will be accepted in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS are: REV, FREIGHT, TAX, REC, UNBILL (for Arrears), CHARGES.',
'Correct  the values provided in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS. The valid values for a transaction with Bill In Arrears as Invoicing rules are:<br>
REV, FREIGHT, TAX, REC, UNBILL (for Arrears), CHARGES.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1675', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1675''',
'The total of distribution amounts for a transaction line must equal the transaction amount',
'RS','The sum total of RA_INTERFACE_DISTRIBUTIONS_ALL.AMOUNT for a specific INTERFACE_LINE_ID value must match the value in RA_INTERFACE_LINES_ALL.AMOUNT.',
'Check that the sum of RA_INTERFACE_DISTRIBUTIONS_ALL.AMOUNT for a specific INTERFACE_LINE_ID value matches the value in RA_INTERFACE_LINES_ALL.AMOUNT.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1676', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1676''',
'The total distribution percent for a transaction line must be 100 for each account class',
'RS',
'The sum total of RA_INTERFACE_DISTRIBUTIONS_ALL.PERCENT for a specific INTERFACE_LINE_ID value is NOT equal to 100%.',
'Check that the sum of RA_INTERFACE_DISTRIBUTIONS_ALL.PERCENT for a specific INTERFACE_LINE_ID, ACCOUNT_CLASS and ORG_ID is 100%.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1677', g_select || ' and msg.message_name = ''AR_RAXTRX-1677''','You can only supply one freight account for a transaction of line type = FREIGHT','RS',
'You are providing multiple Account Distributions for Line type = FREIGHT.',
'You can at the most define only one Account or record in Interface Distributions table for Freight type of Line. If you have supplied multiple accounts, verify which one is correct and delete the rest.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1678', g_select || ' and msg.message_name = ''AR_RAXTRX-1678''','You must supply a value for the distribution amount','RS',
'You provided the Account Distributions, but you have not supplied any information for the column RA_INTERFACE_DISTRIBUTIONS_ALL.AMOUNT.',
'If you intend to pass in the distributions you want the transactions to use, check that you have provided a non-null value for RA_INTERFACE_DISTRIBUTIONS_ALL.AMOUNT.<br>
On the other hand, if you would like AutoInvoice to derive all the GL distributions from the AutoAccounting setup, then make sure you are not passing any rows in the RA_INTERFACE_DISTRIBUTIONS_ALL table.</p>
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1679', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1679''',
'Missing Distribution Percentage',
'RS',
'You must supply a distribution percentage when your batch source indicates you supply percentages, or when your transaction uses an accounting rule.',
'Ensure that you provide a value in RA_INTERFACE_DISTRIBUTIONS.PERCENT when your invoice has an Accounting Rule or the ACCOUNT_CLASS = REC.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1680', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1680''',
'The valid account classes for this line type are: REV, UNBILL and REC',
'RS',
'You are trying to import Account Distributions and populated Interface Distributions table, for a transaction with Invoicing Rule of Bill In Arrears.<br>
The Interface distribution record is for a record in Interface Lines table, with Line Type = LINE.
But the Account Class field in Account Distributions table for this record, has values that AutoInvoice does not recognize. 
The only valid values that will be accepted in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS are: REV, UNBILL and REC.',
'Correct  the values provided in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS to any of these values, as the case may be. The valid values are  REV, UNBILL and REC.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1681', g_select || ' and msg.message_name = ''AR_RAXTRX-1681''',
'The valid account classes for this line type are: REV, UNEARN and REC','RS',
'You are trying to import Account Distributions and populated Interface Distributions table, for a transaction with Invoicing Rule of Bill In Advance. <br>
The Interface distribution record is for a record in Interface Lines table, with Line Type = LINE. But the Account Class field in Account Distributions table for this record, has values that AutoInvoice does not recognize. 
The only valid values that will be accepted in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS are: REV, UNEARN and REC.',
'Correct the values provided in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS to any of these values, as the case may be. The valid values are  REV, UNEARN and REC.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1772', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1772''',
'Incorrect credit memo bill to customer',
'RS',
'Incorrect credit memo bill to customer.',
'Please check the following:<br>
<ol>
  <li>The Invoice was raised for Customer A and an attempt is being made to apply the credit memo to Customer B. </li>
  <li>An RMA is created by copying an invoice and changing the address.   AutoInvoice requires that the Address on the Invoice and Credit Memo be the same.</li>
  <li>If importing transactions from OKS: wrong population of Bill To customer id on Interface Lines record. </li>
</ol>
<br><br>For more information, read: [413607.1]  AutoInvoice Error: The Bill To Customer Of Your Credit Memo Transaction Must Be The Same Or Related To The One Of The Invoice It Is Crediting', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

----- BILL TO
-------------
add_signature('C-1603', g_select || ' and msg.message_name = ''C-1603''',
'Invalid bill to customer id (ORIG_SYSTEM_BILL_CUSTOMER_ID)','RS','The data provided as bill to customer ID does not exist in Receivables.',
'Verify if this bill to customer exists in your system. Value entered must exist in HZ_CUST_ACCOUNTS.CUST_ACCOUNT_ID.
<br><br>For more information, read: [1097862.1] AutoInvoice Error: Invalid bill to customer id (ORIG_SYSTEM_BILL_CUSTOMER_ID)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1602', g_select || ' and msg.message_name = ''C-1602''',
'Invalid bill to customer reference (ORIG_SYSTEM_BILL_CUSTOMER_REF)','RS','The data provided as bill to customer reference does not exist in Receivables.',
'Verify if this bill to customer reference exists in your system. Value entered must exist in HZ_CUST_ACCOUNTS.ORIG_SYSTEM_REFERENCE.
<br><br>For more information, read: [1097846.1] AutoInvoice Error: Invalid bill to customer reference (ORIG_SYSTEM_BILL_CUSTOMER_REF)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1605', g_select || ' and msg.message_name = ''C-1605''',
'Invalid bill to customer address (ORIG_SYSTEM_BILL_ADDRESS_ID)','RS','The data provided as bill to address ID does not exist in Receivables.',
'Verify if this bill to customer address exists for the Bill to customer you provided. Value entered must exist in HZ_CUST_ACCT_SITE.CUSTOMER_SITE_ID.
<br><br>For more information, read: [1097925.1] AutoInvoice Error: The Bill To address id must exist in Oracle Receivables, and it must be assigned to the Bill To customer ORIG_SYSTEM_BILL_ADDRESS_ID', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1604', g_select || ' and msg.message_name = ''C-1604''',
'Invalid bill to address reference (ORIG_SYSTEM_BILL_ADDRESS_REF)','RS','The data provided as bill to address reference does not exist in Receivables.',
'Verify if this bill to customer address exists in your system. Value entered must exist in HZ_PARTY_SITES.ORIG_SYSTEM_REFERENCE.
<br><br>For more information, read: [365287.1] AutoInvoice Error: The Bill To Address Reference Must Exist In Receivables, And It Must Be Assigned To The Bill To Customer (ORIG_SYSTEM_BILL_ADDRESS_REF)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1607', g_select || ' and msg.message_name = ''C-1607''',
'Invalid bill to contact id (ORIG_SYSTEM_BILL_CONTACT_ID)','RS',
'The data provided as bill to Contact ID does not exist in Receivables.',
'Verify if this bill to Contact ID exists for the Bill to customer you provided. Value entered must exist in RA_CONTACTS.CONTACT_ID.
<br><br>For more information, read: [747900.1] AutoInvoice Error: The Bill To Contact Id Must Exist In Oracle Receivables, And It Must Be Assigned to the Bill To customer (ORIG_SYSTEM_BILL_CONTACT_ID)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1606', g_select || ' and msg.message_name = ''C-1606''',
'Invalid bill to contact reference (ORIG_SYSTEM_BILL_CONTACT_REF)','RS',
'The data provided as bill to Contact Reference does not exist in Receivables.',
'Verify if this bill to Contact Reference exists for the Bill to customer you provided. Value entered must exist in RA_CONTACTS.ORIG_SYSTEM_REFERENCE.
<br><br>For more information, read: [747900.1] AutoInvoice Error: The Bill To Contact Id Must Exist In Oracle Receivables, And It Must Be Assigned to the Bill To customer (ORIG_SYSTEM_BILL_CONTACT_ID)', ' ','FAILURE', 'E',   'RS',   'Y' );

------ SHIP TO
--------------
add_signature('C-1609', g_select || ' and msg.message_name = ''C-1609''',
'Invalid ship to customer id (ORIG_SYSTEM_SHIP_CUSTOMER_ID)','RS','The data provided as ship to customer id does not exist in Receivables.',
'Verify if this ship to customer exists in your system. Value entered here must exist in HZ_CUST_ACCOUNTS.CUST_ACCOUNT_ID.
<br><br>For more information, read: [1097660.1] Troubleshooting AutoInvoice Customer, Address and Contact Errors and Exceptions', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1608', g_select || ' and msg.message_name = ''C-1608''',
'Invalid ship to customer reference (ORIG_SYSTEM_SHIP_CUSTOMER_REF)','RS','The data provided as ship to customer reference does not exist in Receivables.',
'Verify if this ship to customer reference exists in your system. Value entered must exist in HZ_CUST_ACCOUNTS.ORIG_SYSTEM_REFERENCE.
<br><br>For more information, read: [1097660.1] Troubleshooting AutoInvoice Customer, Address and Contact Errors and Exceptions', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1611', g_select || ' and msg.message_name = ''C-1611''','Invalid ship to address id (ORIG_SYSTEM_SHIP_ADDRESS_ID)','RS',
'The data provided as ship to address id does not exist in Receivables.',
'Verify if this ship to address id exists for the Ship to customer you provided. Value entered must exist in HZ_CUST_ACCT_SITE.CUSTOMER_SITE_ID.
<br><br>For more information, read: [262735.1] AutoInvoice Error: The supplied ship to address id must exist in Oracle Receivables, and it must agree with the supplied ship to customer', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1610', g_select || ' and msg.message_name = ''C-1610''','Invalid ship to address reference (ORIG_SYSTEM_SHIP_ADDRESS_REF)','RS',
'The data provided as Ship To Address Reference does not exist in Receivables.',
'Verify if this Ship To Address Reference exists in your system for the Ship to Customer you provided. Value entered must exist in HZ_PARTY_SITES.ORIG_SYSTEM_REFERENCE.
<br><br>For more information, read: [219868.1] AutoInvoice Error: The Supplied Ship To Address Reference Must Exist In Oracle Receivables And It Must Agree With The Supplied Ship To Customer(ORIG_SYSTEM_SHIP_ADDRESS_REF)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1613', g_select || ' and msg.message_name = ''C-1613''','Invalid ship to contact id (ORIG_SYSTEM_SHIP_CONTACT_ID)','RS',
'The data provided as ship to contact id does not exist in Receivables.',
'Verify if this customer contact exists for the Ship to customer you provided. Value entered must exist in RA_CONTACTS.CONTACT_ID.
<br><br>For more information, read: [747900.1] AutoInvoice Error: The Bill To Contact Id Must Exist In Oracle Receivables, And It Must Be Assigned to the Bill To customer (ORIG_SYSTEM_BILL_CONTACT_ID)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1612', g_select || ' and msg.message_name = ''C-1612''',
'Invalid ship to contact reference (ORIG_SYSTEM_SHIP_CONTACT_REF)','RS','The data provided as Ship To Contact Reference (ORIG_SYSTEM_SHIP_CONTACT_REF) does not exist in Receivables.',
'Verify if a Ship To Contact Rreference exists in your system. Value entered must exist in RA_CONTACTS.ORIG_SYSTEM_REFERENCE.
<br><br>For more information, read: [1097660.1] Troubleshooting AutoInvoice Customer, Address and Contact Errors and Exceptions', ' ','FAILURE', 'E',   'RS',   'Y' );

----- SOLD TO
-------------
add_signature('C-1601', g_select || ' and msg.message_name = ''C-1601''',
'Invalid sold to customer id (ORIG_SYSTEM_SOLD_CUSTOMER_ID)','RS','The data provided as sold to customer id does not exist in Receivables.',
'Verify if this sold to customer exists in your system. Value entered here must exist in HZ_CUST_ACCOUNTS.CUST_ACCOUNT_ID.
<br><br>For more information, read: [1161925.1] AutoInvoice Error: Invalid sold to customer reference (ORIG_SYSTEM_SOLD_CUSTOMER_REF)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1600', g_select || ' and msg.message_name = ''C-1600''',
'Invalid sold to customer reference (ORIG_SYSTEM_SOLD_CUSTOMER_REF)','RS','The data provided as sold to customer reference does not exist in Receivables.',
'Verify if this sold to customer reference exists in your system. Value entered must exist in HZ_CUST_ACCOUNTS.ORIG_SYSTEM_REFERENCE.
<br><br>For more information, read: [1161925.1] AutoInvoice Error: Invalid sold to customer reference (ORIG_SYSTEM_SOLD_CUSTOMER_REF)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1614', g_select || ' and msg.message_name = ''AR_RAXTRX-1614''','Mismatched Bill To customer','RS','The bill to customer of invoice and the credit memo to it should match or be related.',
'Check the Bill-To customer associated, if this is for a Credit Memo, the Bill-To customer must match or must be related to the Bill-To customer of the invoice being credited.
<br><br>For more information, read: [1138254.1]  Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1615', g_select || ' and msg.message_name = ''AR_RAXTRX-1615''',
'Mismatched bill to customer','RS','The bill to customer of your transaction must be the same or related to the one of the commitment.','Check the Bill-To customer of the transaction being associated to the  commitment, they must match or must be related.
<br><br>For more information, read: [1138254.1]  Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'1350',
g_select || ' and msg.message_name = ''1350''',
'Please correct the receivable account assignment',
'RS',
'AutoAccounting was not able to derive the Receivable (REC) account. ',
'This typically happens due to incorrect/incomplete setup. You should verify the following:<br>
<ol>
<li><b>Best Option:</b>: Use the AutoAccounting Analyzer to assist in identifying the cause of your AutoAccounting Error: [1904785.1]  EBS Oracle Receivables AutoAccounting Analyzer</li>
  <li>Otherwise, manually check the setup of AutoAccounting as follows: <br>
   <b>  Responsibility:</b> Receivables Manager<br>
   <b>  Navigation:</b> Setup > Transactions > AutoAccounting<br>
    Search for Receivable Account type and see how you have set up the system to derive Receivable Account.
You can use transaction types, customer bill-to sites, salespeople, and constant values to specify your receivable account. </li>
  <li>Now check whether you have all the necessary setup in place for AutoAccounting to derive the Receivable Account. For example, if your AutoAccounting setup is such that one of the segments is derived from Transaction Type, then verify if the Receivable Account is specified for that transaction type.<br>
   <b>  Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > Transactions > Transaction Types.  </li>
  <li>If you find that all the setup is in place, and AutoAccounting was able to derive all segments values, then verify if there exists a valid Code Combination ID for the segments derived.<br>
   <b>  Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > Financials > Accounting > GL Accounts </li>
<li>For more information, read: [1088218.1]  APP-11526: Please Correct The Receivable Account Assignment</li></ol>', ' ','FAILURE', 'E',   'RS',   'Y' );


add_signature(
'1360',
g_select || ' and msg.message_name = ''1360''',
'Please correct the revenue account assignment',
'RS',
'AutoAccounting was not able to derive the Revenue (REV) account.',
'This typically happens due to incorrect/incomplete setup. You should verify following:<br>
<ol>
<li><b>Best Option:</b>: Use the AutoAccounting Analyzer to assist in identifying the cause of your AutoAccounting Error: [1904785.1]  EBS Oracle Receivables AutoAccounting Analyzer</li>
<li>Otherwise, manually check the setup of AutoAccounting as follows: <br>
   <b>  Responsibility:</b> Receivables Manager<br>
   <b>  Navigation:</b> Setup > Transactions > AutoAccounting<br>
    Search for Revenue Account type and see how you have set up the system to derive Revenue Account.
    You can use transaction types, customer bill-to sites, standard items, salespeople, and constant values to specify your revenue account.</li>
<li>Now check whether you have all the necessary setup in place for AutoAccounting to derive the Revenue Account. For example, if your AutoAccounting setup is such that one of the segments is derived from standard item, then verify if the Receivable Account is specified for that item.<br>
   <b>  Responsibility:</b> Receivables Manager<br>
   <b>  Navigation:</b> Setup > Transactions > Items > Define Items<br>
    Query up the item on the interface line<br></li>
<li>If you find that all the setup is in place, and AutoAccounting was able to derive all segments values, then verify if there exists a valid Code Combination ID for the segments derived.<br>
   <b>  Responsibility:</b> Receivables Manager<br>
   <b>  Navigation:</b> Setup > Financials > Accounting > GL Accounts </li>
<li>For more information, read: [1088251.1]  Please correct the revenue account assignment</li></ol>', ' ','FAILURE', 'E',   'RS',   'Y' );
    
add_signature(
'1370',
g_select || ' and msg.message_name = ''1370''',
'Please correct the freight account assignment',
'RS',
'AutoAccounting was not able to derive the Freight account. ',
'This typically happens due to incorrect/incomplete setup. You should verify the following:<br>
<ol>
  <li>Check the setup of AutoAccounting. <br>
   <b>  Responsibility:</b> Receivables Manager<br>
   <b>  Navigation:</b> Setup > Transactions > AutoAccounting<br>
    Search for Freight Account type and see how you have set up the system to derive the Freight Account.
You can use transaction types, customer bill-to sites, standard items, salespeople, and constant values to specify your freight account.<br>
  </li>
  <li>Now check whether you have all the necessary setup in place for AutoAccounting to derive the Freight Account. For example, if your AutoAccounting setup is such that one of the segments is derived from standard item, then verify if the Receivable Account is specified for that item.<br>
   <b>  Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > Transactions > Items > Define Items<br>
Query up the item on the interface line<br></li>
  <li>Lastly, if you find that all the setup is in place, and AutoAccounting was able to derive all segments values, then verify if there exists a valid Code Combination ID for the segments derived.<br>
   <b>  Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > Financials > Accounting > GL Accounts </li>
<li>For more information, read: [1096942.1]  How To Setup and Troubleshoot Freight In AutoInvoice and The Transactions Form</li></ol>',
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_INVALID_PRIMARY_SALESREP', g_select || ' and msg.message_name = ''AR_INVALID_PRIMARY_SALESREP''','Primary salesperson is invalid with current transaction date','RS','If  the system option<em> Require Salesperson</em> is set to <em>Yes</em>, 
but you do not populate a salesperson in the RA_INTERFACE_SALESCREDITS_ALL table, then you will encounter this error.',
'Either set the system option<em> Require Salesperson</em>  to <em>No</em>, or populate a salesperson in the RA_INTERFACE_SALESCREDITS_ALL table.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.
<br><br>For more information, read: [244957.1] AutoInvoice Error: Primary salesperson is invalid with current transaction date', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1620',
g_select || ' and msg.message_name = ''AR_RAXTRX-1620''',
'You must supply a sales credit percentage when your batch source indicates you supply percentages',
'RS',
'You are interfacing the sales credits data and your batch source setup indicates that you will be supplying the sales credits percentage but RA_INTERFACE_SALESCREDITS.SALES_CREDIT_PERCENT_SPLIT is null.',
'You can change the batch source setup if you do not want to populate the percentage. Alternatively, you can make sure you populate RA_INTERFACE_SALESCREDITS.SALES_CREDIT_PERCENT_SPLIT.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.',
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1621',
g_select || ' and msg.message_name = ''AR_RAXTRX-1621''',
'Invalid salesrep number (SALESREP_NUMBER)','RS','Invalid salesrep number (SALESREP_NUMBER).',
'These are the common causes for this validation error:<br>
<ul><li>If the system option <em>Require Salesperson</em> is set to <em>Yes</em>, but you do not populate RA_INTERFACE_SALESCREDITS.SALESREP_NUMBER, then you will encounter this error.</li>
<li>The column SALESREP_NUMBER was not provided.</li>
<li>The value passed does not exist in RA_SALESREPS.NAME.</li>
<li>Transaction Source Setup mismatch. The setup indicates Salesperson = Number, but instead you are providing ID.</li></ul><br>
Check your setup:<br>
<ul><li><b>Navigation:</b> Setup > Transactions > Sources</li>
<li>Go to the Sales Credit Validation tab</li>
<li>Review settings for Salesperson: Number or ID</li>
<li>Ensure you are passing the required data and that it exists in RA_SALESREPS table. </li></ul>
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.
<br><br>For more information, read: [1112705.1] AutoInvoice Error: Invalid Salesrep Number (SALESREP_NUMBER)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1622',
g_select || ' and msg.message_name = ''AR_RAXTRX-1622''',
'Invalid salesrep id (SALESREP_ID)','RS','Invalid salesrep id (SALESREP_ID)',
'These are the common causes for this validation error:<br>
<ul><li>If the system option <em>Require Salesperson</em> is set to <em>Yes</em>, but you do not populate RA_INTERFACE_SALESCREDITS.SALESREP_ID, then you will encounter this error.</li>
<li>The column SALESREP_ID was not provided.</li>
<li>The value passed does not exist in RA_SALESREPS.SALESREP_ID.</li>
<li>Transaction Source Setup mismatch. The setup indicates Salesperson = ID, but instead you are providing Number.</li></ul><br>
Check your setup:<br>
<ul><li><b>Navigation:</b> Setup > Transactions > Sources</li>
<li>Go to the Sales Credit Validation tab</li>
<li>Review settings for Salesperson: Number or ID</li>
<li>Ensure you are passing the required data and that it exists in RA_SALESREPS table. </li></ul>
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.
<br><br>For more information, read: [1112672.1]  AutoInvoice Error: Invalid Salesrep id (SALESREP_ID)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1623',
g_select || ' and msg.message_name = ''AR_RAXTRX-1623''',
'Invalid sales credit type id (SALES_CREDIT_TYPE_ID)','RS','Invalid sales credit type id (SALES_CREDIT_TYPE_ID)',
'The values passed does not exist in SO_SALES_CREDIT_TYPES.CREDIT_TYPE_ID. Ensure that the value you are passing to RA_INTERFACE_SALESCREDITS.SALES_CREDIT_TYPE_ID, exists as a value in SO_SALES_CREDIT_TYPES.CREDIT_TYPE_ID.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.
<br><br>For more information, read: [1112672.1]  AutoInvoice Error: Invalid Salesrep id (SALESREP_ID)', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1624',
g_select || ' and msg.message_name = ''AR_RAXTRX-1624''',
'Your sales credit assignment must be for a transaction of line type = LINE',
'RS',
'Your data in Salescredits table, maps to a record in Interafce Lines table record which has Line Type <> LINE.',
'You can provide salescredits information only for the Interface Lines with Line type = LINE. Check the INTERFACE_LINE_CONTEXT and INTERFACE_LINE_ATTTRIBUTE1-15 on the Interface Salescredits record and map it to the Interface Line with Line type = LINE.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1625', g_select || ' and msg.message_name = ''AR_RAXTRX-1625''','Please enter quota sales credits that equal the line amount','RS',
'Your Transaction Source is defined such that the sales credits are validated based on Percent.  With such a setup the percentage amounts for each transaction must total 100%. ',
'Verify the percentage total is 100%.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.
<br><br>For more information, read: [1117668.1] AutoInvoice Error: Please Enter Quota Sales Credit Percentages That Equal 100 Percent', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1626',
g_select || ' and msg.message_name = ''AR_RAXTRX-1626''',
'Invalid sales credit type name (SALES_CREDIT_TYPE_NAME)','RS','Invalid sales credit type name (SALES_CREDIT_TYPE_NAME)',
'These are the possible reasons for the validation error:<br>
<ul>
  <li>The columns SALESREP_NUMBER and/or SALES_CREDIT_TYPES_NAME value was incorrectly passed as Null in the Interface table</li>
  <li>The values passed do not exist in RA_SALESREPS.SALESREP_NUMBER and/or SO_SALES_CREDIT_TYPES.NAME</li>
  <li>Transaction Source is set up to expect ID and yet you provided Value instead</li>
  <li>Potential Code Issue</li>
</ul><br>
Cross-check your transaction source setup with the data you are passing in and ensure they match.
<br><br>For more information, read: [1112705.1]  AutoInvoice Error: Invalid Salesrep Number (SALESREP_NUMBER)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1627',
g_select || ' and msg.message_name = ''AR_RAXTRX-1627''',
'Sales credit percentages must equal 100 percent for this line',
'RS',
'The Transaction Source setup indicates sales credits percent will be provided. This requires the percentage amounts for each transaction to total 100%. <br>
This error is raised if the sum of SALES_CREDIT_PERCENT_SPLIT for a given INTERFACE_LINE_ID do not total 100%.',
'1. Verify the percentage total is 100% by executing the following:<br>
<blockquote>
    SELECT SC.INTERFACE_LINE_ID, SUM(SC.SALES_CREDIT_PERCENT_SPLIT)<br>
    FROM RA_INTERFACE_SALESCREDITS_ALL SC, SO_SALES_CREDIT_TYPES CR<br>
    WHERE REQUEST_ID = &request_id<br>
    AND SC.SALES_CREDIT_TYPE_ID = CR.SALES_CREDIT_TYPE_ID<br>
    GROUP BY INTERFACE_LINE_ID<br>
    HAVING SUM(DECODE(CR.QUOTA_FLAG, <br> ''Y'', SC.SALES_CREDIT_PERCENT_SPLIT,<br> ''N'', 0, NULL, 0)) != 100;
</blockquote><br>
2. Review the data returned, for each INTERFACE_LINE_ID value, the sum of SALES_CREDIT_PERCENT_SPLIT should be 100%.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.
<br><br>For more information, read: [1117668.1]  AutoInvoice Error: Please Enter Quota Sales Credit Percentages That Equal 100 Percent', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1628',
g_select || ' and msg.message_name = ''AR_RAXTRX-1628''',
'You must supply a value for the sales credit amount',
'RS','You must supply a value for the sales credit amount',
'<p>Verify the following:</p>
<ol>
  <li>Check your Transaction Source Setup, identify if Sales Credit is defined as Amount or Percent. If it is set to Amount, and you have passed Percent instead, you will get this error.</li>
  <li>The columns SALES_CREDIT_AMOUNT_SPLIT is Null </li>
</ol><br>
Either correct Batch Source setup or correct the incorrect data and re-run AutoInvoice program.
<br><br>For more information, read: [1116984.1]  AutoInvoice Error: You Must Supply a Value For The Sales Credit Amount', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1629',
g_select || ' and msg.message_name = ''AR_RAXTRX-1629''',
'Missing sales credit assignments',
'RS',
'If the System Option <em>Require Salesperson</em> is set to <em>Yes</em>, and  you do not provide a Salesrep ID on all the interface lines you populate, you will encounter this error.',
'Verify the following:<br>
<ol>
  <li>If your business does not require salesperson to be mandatory, then you can change the System Option <em>Require Salesperson</em> to No.</li>
  <li>If your business requires salesperson to be provided on all transactions, then you need to provide a value for Salesrep ID, and you need to provide salescredit assignments as well. </li>
</ol>
<br><br>For more information, read: [1117036.1] AutoInvoice Error: You Must Supply Sales Credit Assignments For This Transaction Because The System Option Require Salesreps Is Set To Yes', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('C-1634', g_select || ' and msg.message_name = ''C-1634''','Invalid primary salesrep number (PRIMARY_SALESREP_NUMBER)','RS','Invalid primary salesrep number (PRIMARY_SALESREP_NUMBER).',
'These are the common causes for this validation error:<br>
<ul><li>If the system option <em>Require Salesperson</em> is set to <em>Yes</em>, but you do not populate RA_INTERFACE_LINES_ALL.PRIMARY_SALESREP_NUMBER, then you will encounter this error.</li>
<li>The column PRIMARY_SALESREP_NUMBER was not provided.</li>
<li>The value passed does not exist in RA_SALESREPS.SALESREP_NUMBER.</li>
<li>Transaction Source Setup mismatch. The setup indicates Salesperson = Number, but instead you are providing ID.</li></ul>
Check your setup:<br>
<ul><li><b>Navigation:</b> Setup > Transactions > Sources</li>
<li>Go to the Sales Credit Validation tab</li>
<li>Review settings for Salesperson: Number or ID</li>
<li>Ensure you are passing the required data and that it exists in RA_SALESREPS table. </li></ul>', ' ','FAILURE', 'E',   'RS',   'Y' );


add_signature('C-1635', g_select || ' and msg.message_name = ''C-1635''','Invalid primary salesrep id (PRIMARY_SALESREP_ID)','RS','Invalid primary salesrep id (PRIMARY_SALESREP_ID)',
'These are the common causes for this validation error:<br>
<ul><li>If the system option <em>Require Salesperson</em> is set to <em>Yes</em>, but you do not populate RA_INTERFACE_LINES_ALL.SALESREP_ID, then you will encounter this error.</li>
<li>The column SALESREP_ID was not provided.</li>
<li>The value passed does not exist in RA_SALESREPS.SALESREP_ID.</li>
<li>Transaction Source Setup mismatch. The setup indicates Salesperson = ID, but instead you are providing Number.</li></ul>
Check your setup:<br><br>
If you need to get the salesrep number from an ID value, please do the following:<br>
select salesrep_number from ra_salesreps where salesrep_id = &Salesrep_ID;<br><br>
<ul><li><b>Navigation:</b> Setup > Transactions > Sources</li>
<li>Go to the Sales Credit Validation tab</li>
<li>Review settings for Salesperson: Number or ID</li>
<li>Ensure you are passing the required data and that it exists in RA_SALESREPS table. </li></ul>', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_SALESREP_INACTIVE',
g_select || ' and msg.message_name = ''AR_RAXTRX_SALESREP_INACTIVE''',
'Primary sales representative not active',
'RS',
'Please check the setup for the primary sales representative used in this invoice line <br>
If you need to get the salesrep number from an ID value, please do the following:<br>
select salesrep_number from ra_salesreps where salesrep_id = &Salesrep_ID; <br><br>
   
    <b>Responsibility:</b> CRM Resource Manager<br>
    <b>Navigation:</b> Maintain Resources > Resources
    <ol><li>Query for Number shown above </li>
        <li>Click on Resource Details button </li>
        <li>Navigate to the Receivables tab </li>
        <li>Review the values in Effective Date: Start and End fields </li>
  
    </ol>',
'',
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1630', g_select || ' and msg.message_name = ''AR_RAXTRX-1630''','Invalid sales group ID (SALESGROUP_ID)','RS','Invalid sales group ID (SALESGROUP_ID)',
'You are interfacing the sales credits data via the Interface Salescredits table, and you have supplied Sales Group ID that does not exist in the system. 
Verify the value you supplied for sales group ID. 
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1666',g_select || ' and msg.message_name = ''AR_RAXTRX-1666''','You can only credit an invoice or a debit memo line','RS',
'You are trying to import a credit memo, and you have provided invalid information as reference to the transaction to be credited.',
'You can credit only an invoice or a debit memo. Check the values in RA_INTERFACE_LINES_ALL REFERENCE_LINE_ATTRIBUTE1-15 and REFERENCE_LINE_CONTEXT, and make sure that they point to an Invoice or a Debit Memo.<br><br>
For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1667',
g_select || ' and msg.message_name = ''AR_RAXTRX-1667''',
'Invalid data for debit memo',
'RS',
'Debit memos should not have values in RA_INTERFACE_LINES_ALL.REFERENCE_LINE_ATTRIBUTE1-15 and/or REFERENCE_LINE_CONTEXT',
'The REFERENCE_LINE_ATTRIBUTE1-15 columns provide reference to a transaction. For a Debit Memo being imported, you cannot provide reference to any commitment (Deposit or guarantee) or a credit memo. 
NULL out the values from REFERENCE_LINE_CONTEXT and the REFERENCE_LINE_ATTRIBUTE1-15 columns.<br><br>
For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1695', 
g_select || ' and msg.message_name = ''AR_RAXTRX-1695''',
'Negative Amount applications',
'RS',
'Applying a negative amount to a transaction that already has a negative balance moves the transaction amount farther from zero, and the transaction type setup may not allow this.',
'If you really want to allow application of credits (or receipts) exceeding the remaining amount of an invoice, such that the invoice balance goes negative, 
check the settings of the Transaction Type:<br>
<strong>Responsibility: </strong>Receivables Manager<br>
  <strong>Navigation:</strong> Setup > Transactions > Transaction Type<br>
  <br>
Check the settings:<br>
<ul>
  <li> Allow Overapplication = Checked</li>
  <li> Natural Application Only = Unchecked</li>
</ul>
<br><br>For more information, read: [1174659.1]  AutoInvoice Error: You cannot apply a transaction with a negative amount to another transaction with a negative balance and vice versa.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1633', g_select || ' and msg.message_name = ''C-1633''',
'Invalid reason code (REASON_CODE)','RS',
'Value provided for REASON_CODE is invalid.',
'The reason code used must exist in Receivables Lookup form.<br><br>
<b>Navigation:</b> Setup > System > Quick Codes <br>
Query for lookup type = CREDIT_MEMO_REASON, and review the valid values in the Code Column.<br>
You can use the Interface Lines form to update this field.',
'','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1705', g_select || ' and msg.message_name = ''AR_RAXTRX-1705''',
'Invalid credit method for installments (CREDIT_METHOD_FOR_INSTALLMENTS)','RS',
'When the invoice being credited has multiple installments, you need to provide a value in RA_INTERFACE_LINES.CREDIT_METHOD_FOR_INSTALLMENTS.',
'Valid values are:<br>
<ul> <li> PRORATE, will split up the credit amount equally across all installments</li> 
<li> LIFO, will apply the credit amounts starting from the last installment</li> 
<li> FIFO, will apply the credit amounts starting from the first installment</li> </ul> 
<br><br>For more information, read: [1110573.1] Troubleshooting Credit Memos in the Transaction Workbench and AutoInvoice in Receivables', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1717', g_select || ' and msg.message_name = ''AR_RAXTRX-1717''','Invoicing and Accounting rules are not allowed on on-account credit memos','RS',
'You cannot associate Accounting/Invoicing rules to On-Account credit memos',
'An on-account credit memo has not yet identified the invoice it will credit. Since it can be applied to either an invoice with or without rules, you are not allowed to provide an invoicing rule to it.<br>
Either you null out the Invoicing rule information you provided, or you identify the invoice with rules that you are crediting via the REFERENCE* fields.
<br><br>For more information, read: [1110573.1] Troubleshooting Credit Memos in the Transaction Workbench and AutoInvoice in Receivables', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1718', g_select || ' and msg.message_name = ''AR_RAXTRX-1718''','Invalid RELATED* fields for credit memo transactions','RS',
'For Credit Memos, the fields: RELATED_BATCH_SOURCE_NAME, RELATED_TRX_NUMBER, RELATED_CUSTOMER_TRX_ID must be null.',
'Ensure there is a null value in the following fields: RA_INTERFACE_LINES_ALL.RELATED_BATCH_SOURCE_NAME, RA_INTERFACE_LINES_ALL.RELATED_TRX_NUMBER, RA_INTERFACE_LINES_ALL.RELATED_CUSTOMER_TRX_ID.<br>
You can update this in the Interface Lines form
<br><br>For more information, read: [1195997.1] R12 How To Bring In (and Troubleshoot) Manual Tax Lines Through Autoinvoice and E-Business Tax (EBTax)', ' ','FAILURE', 'E',   'RS',   'Y' );


add_signature('AR_RAXTRX-1719', g_select || ' and msg.message_name = ''AR_RAXTRX-1719''',
'You must supply a reason code for your credit memo transaction','RS',
'The value of RA_INTERFACE_LINES_ALL.REASON_CODE is NULL. This field must be populated',
'Enter a reason code in RA_INTERFACE_LINES_ALL.REASON_CODE. Valid entries are  available in Receivables Lookup form, with a lookup type of CREDIT_MEMO_REASON.
You can use the Interface Lines form to update this field.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1720', g_select || ' and msg.message_name = ''AR_RAXTRX-1720''',
'Mismatched Open Receivable flag','RS',
'You are importing a Credit Memo to be applied to an Invoice and the Open Receivable flag setup does not match. 
The credit memo and invoice transaction types must have the same setting for <em>Open Receivable</em>.',
'<b>Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > Transactions > Transaction Type
<br><br>Review the <em>Open Receivable</em> field, it should be the same value for the Credit Memo and the invoice it is crediting.
<br><br>For more information, read: [1122984.1]  AutoInvoice Error: The Open Receivable Flag Of Your Credit Memo Must Match The Flag Of The Transaction You Are Crediting', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1632', g_select || ' and msg.message_name = ''C-1632''',
'Invalid reason code meaning (REASON_CODE_MEANING)','RS', 'Invalid reason code meaning (REASON_CODE_MEANING)',
'The reason code meaning used must exist in Receivables Lookup form.<br>
<b>Navigation:</b> Setup > System > Quick Codes <br>
Query for lookup type = CREDIT_MEMO_REASON, and review the valid values in the Meaning Column.<br>
You can use the Interface Lines form to update this field.',
'','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1770', g_select || ' and msg.message_name = ''AR_RAXTRX-1770''',
'Credit memo GL date earlier than invoice GL date','RS',
'The credit memo has a GL date that is earlier than the GL Date of the invoice it is crediting',
'Check the value in RA_INTERFACE_LINES_ALL.GL_DATE and compare it to the Invoice GL_DATE as referred to by the values in REFERENCE_* fields. 
Ensure the credit memo''s GL_DATE comes on or after the invoice''s GL_DATE.<br>
For more information on how GL Dates are derived, read: [1110573.1] Troubleshooting Credit Memos in the Transaction Workbench and AutoInvoice in Receivables<br>
If you are interfacing RMAs from Order Management, read: [1294916.1] RMA Credit Memos Error In Autoinvoice Import With Invalid Future GL Dates
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_CM_TAX_FLAG_ERR',
g_select || ' and msg.message_name = ''AR_RAXTRX_CM_TAX_FLAG_ERR''',
'System Options Tax Calculation flag not set',
'RS',
'In Release 11i, you specify whether you want to calculate tax on credit memos in AutoInvoice. This setting has not been applied.',
'Please navigate to the System Options form and set the Tax Calculation flag<br><br>
For more information, read: [1110573.1] Troubleshooting Credit Memos in the Transaction Workbench and AutoInvoice in Receivables', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1773', g_select || ' and msg.message_name = ''AR_RAXTRX-1773''',
'Invalid account assignment for your credit memo','RS',
'When the profile option Use Invoice Accounting For Credit Memos = Yes, you should not provide distributions for the credit memo.<br>
You may encounter this error if you are importing  credit memos sourced from Oracle Projects too.',
'Either remove the distribution records from the table RA_INTERFACE_DISTRIBUTIONS_ALL, or change the profile <em>AR: Use Invoice Accounting For Credit Memos</em> to <em>No</em>.<br>
If importing CMs from Oracle Projects: Set the profile option, <em>AR: Use Invoice Accounting For Credit Memos</em> to <em>No</em>.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1122964.1]  AutoInvoice Error: You Cannot Supply Any Account Assignment For Your Credit Memo Transaction When The System Option Use Invoice Accounting For Credit Memos is Yes', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1774', g_select || ' and msg.message_name = ''AR_RAXTRX-1774''','Invalid credit method for accounting rule','RS',
'The invoice being credited has Invoicing Rules and you have not provided a value in RA_INTERFACE_LINES.CREDIT_METHOD_FOR_ACCT_RULE, to indicate how you want the credit to impact the revenue schedule of the invoice. The valid values for credit method for accounting rule are: PRORATE, LIFO and UNIT.',
'If this field was populated incorrectly, you can run an update statement like the following to fix incorrect data:<br>
<blockquote>
  <p>UPDATE  RA_INTERFACE_LINES_ALL<br>
  SET credit_method_for_acct_rule = &correct_value<br>
  WHERE interface_line_id = &enter_your_interface_line_id;<br>
  COMMIT;<br>
</blockquote>
Alternatively, you can use the Interface Lines form to fix the value in this field.
<br><br>For more information, read: [1149363.1]  AutoInvoice Error: The valid values for credit method for accounting rule are PRORATE, LIFO and UNIT.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1775', g_select || ' and msg.message_name = ''AR_RAXTRX-1775''','Invalid credit method for installments',
'RS',
'When the invoice being credited has multiple installments, you need to provide a value in RA_INTERFACE_LINES.CREDIT_METHOD_FOR_INSTALLMENTS.  Valid values are PRORATE, LIFO and FIFO',
'If this field is populated incorrectly, you can use the Interface Lines form to clear out the value in this field, or populate it with correct values.<br>
<b>Responsibility:</b> Receivables Manager  <br>
<b>Navigation:</b> Control > AutoInvoice > Interface Lines<br>
Alternatively, you can run an UPDATE statement like the following to clear out or update the incorrect data:<br>
<blockquote>
  UPDATE ra_interface_lines_all<br>
  SET credit_method_for_installments = NULL          <br>
  WHERE interface_line_id = &enter_interface_line_id;<br>
  COMMIT;<br>
</blockquote>
<br><br>For more information, read: [1110573.1] Troubleshooting Credit Memos in the Transaction Workbench and AutoInvoice in Receivables', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_UNIT_OVERAPP', g_select || ' and msg.message_name = ''AR_RAXTRX_UNIT_OVERAPP''',
'Invalid unit selling price','RS','The value in RA_INTERFACE_LINES_ALL. UNIT_SELLING_PRICE for the credit memo is greater than the value of the UNIT_SELLING_PRICE of the Invoice.',
'Update RA_INTERFACE_LINES_ALL.UNIT_SELLING_PRICE for the credit memo so that the value is less than or equal to the Invoice''s UNIT_SELLING_PRICE. <br>
You can do this via the Interface Lines form
<br><br>For more information, read: [1145259.1]  AutoInvoice Error: Please enter a unit selling price for this credit line that is less than the unit selling price for its target invoice line', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1777', g_select || ' and msg.message_name = ''AR_RAXTRX-1777''',
'Mismatched currency code','RS','The currency code of the credit memo transaction you are trying to import, does not match the currency code of the invoice line or debit memo line you are crediting','Check that the currency of the credit memo matches the currency of the invoice it is crediting.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_CONV_CM',
g_select || ' and msg.message_name = ''AR_RAXTRX_CONV_CM''',
'National Currency Units Converted to Euro',
'RS',
'This error message relates to the conversion of National Currency Units (eg. Greek Drachma, French Franc, etc) into Euros',
'The transaction, which was previously showing an NCU currency, has been converted into Euro.   It will be imported as an on-account credit memo when AutoInvoice is next run.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'I',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1779', g_select || ' and msg.message_name = ''AR_RAXTRX-1779''',
'Credit memo charges lines can only be applied to debit memo charges lines','RS','Credit memo charges lines can only be applied to debit memo charges lines','Records with RA_INTERFACE_LINES_ALL.LINE_TYPE = CHARGES should have the REFERENCE_* fields pointing to a Debit Memo''s record which also has LINE_TYPE = CHARGES.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_DUPLICATE_CM_LINE',
g_select || ' and msg.message_name = ''AR_RAXTRX_DUPLICATE_CM_LINE''',
'Separate lines on the same credit memo cannot credit an invoice line more than once',
'RS',
'AutoInvoice does not allow CMs with multiple lines against a single invoice line.',
'If you are importing transactions from Oracle Contracts which allows multi-line CM, you need to apply Patch 10359523 and Patch 6027573 to get the correct functionality.
<br><br>For more information, read: [1322932.1] Autoinvoice Error: Separate Lines On Same Credit Memo Cannot Credit Invoice Line More Than Once', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1771', g_select || ' and msg.message_name = ''AR_RAXTRX-1771''',
'CM date cannot precede the date of the transaction being credited','RS',
'You are trying to import a credit memo, and you have provided a Transaction Date for the CM which is earlier than the Transaction Date of the Invoice being credited.',
'Check the value in RA_INTERFACE_LINES_ALL.TRX_DATE and cross-check against the Invoice''s TRX_DATE as referred to by the values in  REFERENCE_* fields and ensure the credit memo''s TRX_DATE comes on or after the TRX_DATE of the invoice.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1767', g_select || ' and msg.message_name = ''AR_RAXTRX-1767''','Unit credit memos can only be applied to invoices that use rules','RS','You are trying to import a credit memo against an invoice that has NO invoicing rules and accounting rules, but you have populated CREDIT_METHOD_FOR_ACCT_RULE column','Remove the information populated in the field CREDIT_METHOD_FOR_ACCT_RULE if the invoice you are trying to credit does not have rules.<br><br>For more information, read: [1110573.1] Troubleshooting Credit Memos in the Transaction Workbench and AutoInvoice in Receivables', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1624_G', g_select || ' and msg.message_name = ''AR_RAXTRX-1624_G''','Your credit assignment must be for line type = LINE','RS',
'The Salescredit Assignment is linked to a record in RA_INTERFACE_LINES_ALL which has LINE_TYPE <> LINE.',
'Check the values in RA_INTERFACE_SALESCREDITS_ALL.INTERFACE_LINE_CONTEXT and INTERFACE_LINE_ATTRIBUTE* and ensure the values are pointing to a record in RA_INTERFACE_LINES_ALL where LINE_TYPE = LINE.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_CKAP_OVERAPP',
g_select || ' and msg.message_name = ''AR_CKAP_OVERAPP''',
'You cannot over apply this transaction',
'RS',
'You are encountering this error for a Credit Memo you are trying to import. Typically, this happens due to Transaction Type setup of the invoice you are trying to credit.',
'These are the steps to identify the reason for the error:<br />
<ol><li>Identify the invoice you are trying to credit, and note the open balance on the invoice.</li>
<li>Check if there are any activities (like receipt application, adjustment, another credit memo etc.) on the invoice to determine what is impacting the open balance.</li>
<li>Take note of the transaction type used for the invoice you are trying to credit.</li>
<li>Review the setting for that transaction type: <br>
<b>Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > Transactions > Transaction Types <br>
Search for the Transaction Type<br>
Review the setting for Allow Overapplication flag setting.</li>
<li>Next, verify the amount you specified on the interface lines record and check if it is less than, or equal to open balance on the invoice.</li></ol><br /><br />
Following are your options to correct the problem:<br />
<ol>
<li>If you think the amount you are trying to credit, is right and the invoice should be overapplied, then change the Transaction Type setup to Allow Overapplication</li>
<li>If the invoice Transaction Type setup is correct to not allow overapplication, then update the amount in interface lines table to not over apply</li>
<li>If the overapplication is resulting because there was a receipt application to the invoice, and you want that the system to automatically handle this by 
un-applying the receipt application and proceeding to create the transaction, you will need to do some setup. 
Please review Receivables User Guide and search for Automated Receipt Handling for Credits</li></ol>
<br><br>For more information, read: [1147943.1]  AutoInvoice Error: You cannot over apply this transaction.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_MAECM_LINE_OVERAPPLIED', g_select || ' and msg.message_name = ''AR_MAECM_LINE_OVERAPPLIED''',
'You can not apply more than the original line amount',
'RS',
'You are encountering this error for a Credit Memo you are trying to import. Typically this happens due to Transaction Type setup, of the invoice you are trying to credit.',
'These are the steps to identify the reason for the error:<br>
<ol>
  <li>Find out the invoice you are trying to credit, and note the open balance on the invoice. Also check if there are any activities (like receipt application, adjustment, another credit memo etc.) on the invoice.</li>
  <li>Get the Transaction Type used for the invoice and search for the Transaction Type and check the Allow Overapplication flag setting.
  <b>Responsibility:</b> Receivables Manager
<b>Navigation:</b> Setup > Transactions > Transaction Types <br>
Search for the Transaction Type<br>
Review the setting for Allow Overapplication flag setting.</li>
  <li>Next, verify the amount you specified on the interface lines record and check if it is less than, or equal to open balance on the invoice.</li>
</ol><br>
You have three options to correct the problem:<br>
<ol>
  <li> If you think the amount you are trying to credit, is right and the invoice should be overapplied, then change the Transaction Type setup.</li>
  <li> If the invoice Transaction Type setup is correct, then update the amount in interface lines table.</li>
  <li> If the overapplication is resulting because there was a receipt application to the invoice, and you want that the system automatically handle this by un-applying the receipt application and proceeding to create the transaction, you will need to do some setup. Please review Receivables User Guide and search for Automated Receipt Handling for Credits</li>
</ol>
<br><br>For more information, read: [1122945.1]  AutoInvoice Error: You Can Not Apply More Than The Original Line Amount', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1661', g_select || ' and msg.message_name = ''AR_RAXTRX-1661''','Invalid reference line id (REFERENCE_LINE_ID)','RS','The value passed as REFERENCE_LINE_ID does not match with values in RA_CUSTOMER_TRX_LINES_ALL.CUSTOMER_TRX_LINE_ID',
'Ensure that the value passed in RA_INTERFACE_LINES_ALL.REFERENCE_LINE_ID exists in RA_CUSTOMER_TRX_LINES_ALL.CUSTOMER_TRX_LINE_ID.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1662',
g_select || ' and msg.message_name = ''AR_RAXTRX-1662''',
'Invalid reference line attribute value (REFERENCE_LINE_ATTRIBUTE1-15)',
'RS',
'The values passed as REFERENCE_LINE_ATTRIBUTE1-15 do not match with values in the RA_CUSTOMER_TRX_LINES_ALL.INTERFACE_LINE_ATTRIBUTE1-15',
'Ensure the values passed in RA_INTERFACE_LINES_ALL.REFERENCE_LINE_ATTRIBUTE1-15 exists in RA_CUSTOMER_TRX_LINES_ALL.INTERFACE_LINE_ATTRIBUTE1-15<br><br>
For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1682', g_select || ' and msg.message_name = ''AR_RAXTRX-1682''',
'The valid account class for this line type is TAX','RS','
You populated Interface Distributions table, for an interface lines record with Line Type = TAX. But the Account Class field in Account Distributions table for this record is incorrect. 
The only valid value that will be accepted in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS is TAX.',
'Correct the value provided in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS to TAX.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1683', g_select || ' and msg.message_name = ''AR_RAXTRX-1683''',
'The valid account class for this line type is FREIGHT','RS',
'You populated populated Interface Distributions table, for an interface line record with Line Type = FREIGHT. But the Account Class field in Account Distributions table for this record is incorrect. 
The only valid value that will be accepted in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS is FREIGHT.',
'Correct the value provided in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS to FREIGHT.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1685', g_select || ' and msg.message_name = ''AR_RAXTRX-1685''',
'Missing freight account for your freight line','RS',
'You must supply a Freight Account for your Freight Line if you have not set up AutoAccounting for Revenue Account.',
'Verify your setup of AutoAccounting. Make sure that you have completed the setup for the Freight Account.<br><br>
If you do not wish to use AutoAccounting for Freight, then you must provide a corresponding record in RA_INTERFACE_DISTRIBUTIONS_ALL and supply a value in CODE_COMBINATION_ID or the corresponding SEGMENT* fields for the FREIGHT distribution.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1686', g_select || ' and msg.message_name = ''AR_RAXTRX-1686''',
'Missing tax account for your tax line','RS','You must supply a Tax Account for your Tax Line if you have not set up AutoAccounting for Tax Account.',
'Verify your setup of AutoAccounting. Make sure that you have completed the setup for the Tax Account.<br><br>
If you do not wish to use AutoAccounting for Tax then you must provide a corresponding record in RA_INTERFACE_DISTRIBUTIONS_ALL and supply a value in CODE_COMBINATION_ID or the corresponding SEGMENT* fields for the TAX distribution.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1687', g_select || ' and msg.message_name = ''AR_RAXTRX-1687''',
'Missing receivables account','RS',
'You must supply a Receivable Account for your transaction if you have not set up AutoAccounting for Receivable Account.',
'Verify your setup of AutoAccounting. Make sure that you have completed the setup for the Receivable Account.<br>
You can use [1904785.1] EBS Oracle Receivables AutoAccounting Analyzer, to assist in identifying what is missing in your AutoAccounting setup.<br><br>
If you do not wish to use AutoAccounting for Receivable then you must provide a corresponding record in RA_INTERFACE_DISTRIBUTIONS_ALL and supply a value in CODE_COMBINATION_ID or the corresponding SEGMENT* fields for the Receivable distribution.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1688', g_select || ' and msg.message_name = ''AR_RAXTRX-1688''',
'Missing revenue account','RS',
'You must supply a Revenue Account for your transaction if you have not set up AutoAccounting for Revenue Account.',
'Verify your setup of AutoAccounting. Make sure that you have completed the setup for the Revenue Account.<br>
You can use [1904785.1] EBS Oracle Receivables AutoAccounting Analyzer, to assist in identifying what is missing in your AutoAccounting setup.<br><br>
If you do not wish to use AutoAccounting for Revenue account then you must provide a corresponding record in RA_INTERFACE_DISTRIBUTIONS_ALL and supply a value in CODE_COMBINATION_ID or the corresponding SEGMENT* fields for the Revenue distribution.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1689', g_select || ' and msg.message_name = ''AR_RAXTRX-1689''',
'Missing unbilled account','RS',
'You must supply a Unbilled Receivable Account for your transaction if you have not set up AutoAccounting for Revenue Account.',
'Verify your setup of AutoAccounting. Make sure that you have completed the setup for the Unbilled Receivable Account.<br>
You can use [1904785.1] EBS Oracle Receivables AutoAccounting Analyzer, to assist in identifying what is missing in your AutoAccounting setup.<br><br>
If you do not wish to use AutoAccounting for Revenue account then you must provide a corresponding record in RA_INTERFACE_DISTRIBUTIONS_ALL and supply a value in CODE_COMBINATION_ID or the corresponding SEGMENT* fields for the Revenue distribution.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1691', g_select || ' and msg.message_name = ''AR_RAXTRX-1691''',
'Missing unearned account','RS',
'You must supply a Unearned Account for your transaction if you have not set up AutoAccounting for Unearned  Account.',
'Verify your setup of AutoAccounting. Make sure that you have completed the setup for the Unearned Account.<br>
You can use [1904785.1] EBS Oracle Receivables AutoAccounting Analyzer, to assist in identifying what is missing in your AutoAccounting setup.<br><br>
If you do not wish to use AutoAccounting for Unearned account then you must provide a corresponding record in RA_INTERFACE_DISTRIBUTIONS_ALL and supply a value in CODE_COMBINATION_ID or the corresponding SEGMENT* fields for the Unearned distribution.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1710', g_select || ' and msg.message_name = ''AR_RAXTRX-1710''',
'Supplied accounted amount <> calculated amount','RS','Supplied accounted amount <> calculated amount',
'The supplied accounted amount does not match the amount calculated by AutoInvoice within the specified tolerance. Check the value in RA_INTERFACE_DISTRIBUTIONS.ACCTD_AMOUNT and verify if this value when rounded using the currency precision or the minimum accountable unit of the currency will still yield the same amount.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1823', g_select || ' and msg.message_name = ''AR_RAXTRX-1823''',
'Adjustment/Application Accounting: Code combination id not setup for Tax Account','RS',
'Either Transaction type or Receivable activity does not have tax account assigned',
'Review the setup for Transaction Type or Receivable Activity used by this interface record and ensure a Tax account is defined.<br>
<b>Navigation:</b> Setup > Transactions > Transaction Type<br>
or<br>
<b>Navigation:</b> Setup > Receipts > Receivable Activities', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1827', g_select || ' and msg.message_name = ''AR_RAXTRX-1827''',
'Adjustment/Application Accounting: Others exception','RS','An unhandled exception has been raised in the tax engine.',
'To help pinpoint cause of error provide a tax debug log using review [417238.1] How to obtain debug logfile for R12 E-Business Tax', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1825', g_select || ' and msg.message_name = ''AR_RAXTRX-1825''',
'Adjustment/Application Accounting: Line, Tax Amount allocated over 0 base','RS','Adjustment/Application Accounting: Line, Tax Amount allocated over 0 base',
'To help pinpoint cause of error provide a tax debug log using review [417238.1] How to obtain debug logfile for R12 E-Business Tax
<br><br>For more information, read: [745968.1] R12: Troubleshooting AutoInvoice Tax Issues with R12 E-Business Tax (EBTax)<br>
 Release 11i: [1086146.1] Troubleshooting AutoInvoice Tax Issues with R11.5 (11i) Receivables Tax Engine', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1824', g_select || ' and msg.message_name = ''AR_RAXTRX-1824''',
'Adjustment/Application Accounting: Rounding error','RS','Adjustment/Application Accounting: Rounding error',
'To help pinpoint cause of error provide a tax debug log using review [417238.1] How to obtain debug logfile for R12 E-Business Tax<br><br>
For more information, read: [745968.1] R12: Troubleshooting AutoInvoice Tax Issues with R12 E-Business Tax (EBTax),  Release 11i: [1086146.1] Troubleshooting AutoInvoice Tax Issues with R11.5 (11i) Receivables Tax Engine', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1793', g_select || ' and msg.message_name = ''AR_RAXTRX-1793''',
'Missing AutoInvoice Clearing account','RS','You must set up AutoAccounting for AutoInvoice Clearing account if your batch source allows AutoInvoice clearing','Check that you have completed the AutoAccounting setup for AutoInvoice Clearing, please review details in [1069052.1] Setting Up AutoAccounting Rules In Receivables [Video]', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_BAD_ACC_CLASS',
g_select || ' and msg.message_name = ''AR_RAXTRX_BAD_ACC_CLASS''',
'The accounting distributions for this transaction are linked to the wrong type of line',
'RS',
'You have used a wrong line type on the distributions',
'Check the value in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCOUNT_CLASS matches the value for the corresponding row in RA_INTERFACE_LINES_ALL.LINE_TYPE.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1698', g_select || ' and msg.message_name = ''AR_RAXTRX-1698''',
'Mismatched receivables account','RS',
'The Receivables account of your credit transaction must be the same as that of the transaction being credited, if the credit transaction has the Open Receivables Flag set to No. You have different CODE_COMBINATION_IDs on the Credit Memo from the Invoice.','The CODE_COMBINATION_ID values used for the REC account for both credit memo and invoice have to match when Open Receivables Flag = No.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1616', g_select || ' and msg.message_name = ''AR_RAXTRX-1616''',
'Mismatched currency code','RS','The currency code of your transaction must be the same as the currency code of the commitment.','Check the currency code of the transaction being associated to the  commitment, the currency codes must match.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1709', g_select || ' and msg.message_name = ''AR_RAXTRX-1709''',
'Incorrect currency precision on entered amount','RS',
'The entered amount does not have the correct currency precision.',
'Check the precision of the value in RA_INTERFACE_LINES_ALL and RA_INTERFACE_DISTRIBUTIONS_ALL AMOUNT has a decimal precision that matches the currency''s precision.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1713', g_select || ' and msg.message_name = ''AR_RAXTRX-1713''',
'Amount <> unit selling price * quantity','RS','You have configured the system to NOT use the AutoInvoice Clearing (suspense) account, but the data you have populated is incorrect for this setup. 
If you do not use the AutoInvoice Clearing (suspense) account, then the supplied amount must match unit selling price times the quantity.','Correct the Amount Column in the Interface Lines table<br><br>For more information, read: [1111566.1]  AutoInvoice Error: The supplied amount must match unit selling price times the quantity when you do not use an AutoInvoice Clearing account.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1725', g_select || ' and msg.message_name = ''AR_RAXTRX-1725''',
'Missing conversion rate for conversion type = User','RS',
'The system is trying to apply a User Type conversion rate, but you have not populated RA_INTERFACE_LINES_ALL.CONVERSION_RATE',
'Update RA_INTERFACE_LINES_ALL.CONVERSION_RATE with a valid conversion rate, using the Interface Lines form.
<br><br>For more information, read: [1075757.1] Troubleshooting AutoInvoice for Oracle Receivables Release 11.5 Through 12', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1726', g_select || ' and msg.message_name = ''AR_RAXTRX-1726''',
'Incorrectly provided conversion rate for conversion type <> User','RS','You should not populate the conversion rate when the conversion type <> User.',
'Either change the conversion type to User, or remove the value from conversion rate column.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1745', g_select || ' and msg.message_name = ''AR_RAXTRX-1745''',
'Incorrect currency precision for accounted amount','RS','The accounted amount does not have the correct currency precision.',
'Check the value in RA_INTERFACE_DISTRIBUTIONS_ALL.ACCTD_AMOUNT and ensure the currency precision matches the definition for the currency code.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.',' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1749', g_select || ' and msg.message_name = ''AR_RAXTRX-1749''',
'Missing realized gains account and realized losses account','RS',
'You cannot supply any transactions in a non-functional currency if you have not set up both realized gains account and realized losses account.',
'Check that you have setup the Realized Gain/Losses accounts in System Options.<br>
<b>Navigation:</b> Setup > System > System Options (in Accounting tab)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1815', g_select || ' and msg.message_name = ''AR_RAXTRX-1815''',
'Entered amount <> accounted amount for functional currency transaction','RS',
'The distributions for this transaction are in the functional currency, but the entered amount does not equal the accounted amount. <br>
Please correct the accounted amount for this transaction and resubmit AutoInvoice. Entered and accounted amounts should be the same because the transaction is in functional currency.',
'Check the values in RA_INTERFACE_DISTRIBUTIONS.AMOUNT and ACCTD_AMOUNT, these values should match since the transaction is in the functional currency.
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1753',
g_select || ' and msg.message_name = ''AR_RAXTRX-1753''',
'Missing conversion rate','RS',
'A conversion rate for the correct combination of date, currency, ledger and conversion type is missing.',
'Check the conversion rates table and ensure you have a record setup for the date, currency code, ledger and conversion type required.<br> <br> 
<strong>Navigation:</strong> Setup > Financials > Accounting > Currencies > Rates > Daily
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1654', g_select || ' and msg.message_name = ''C-1654''',
'Invalid conversion type (CONVERSION_TYPE)','RS','Invalid conversion type (CONVERSION_TYPE)',
'Check that the value you populated into the field CONVERSION_TYPE on this line, exists in GL_DAILY_CONVERSION_TYPES.CONVERSION_TYPE', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1653', g_select || ' and msg.message_name = ''C-1653''',
'Invalid currency code (CURRENCY_CODE)','RS','Invalid currency code (CURRENCY_CODE)',
'Check that the value you populated into RA_INTERFACE_LINES_ALL.CURRENCY_CODE exists in FND_CURRENCIES.CURRENCY_CODE', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1693', g_select || ' and msg.message_name = ''AR_RAXTRX-1693''',
'Total amount should be negative','RS',
'The document created must have a negative total amount because the creation sign for your transaction type is Negative. The issue may be caused by changing the pricing rounding methodology and/or setup between when the Sales order was raised and when the subsequent RMA was created.',
'Ensure any price and/or currency rounding setup changes are only done during an appropriate freeze window when no further (linked) RMA are to be created.<br> 
If you need to Adjust the invoice, read: [431587.1] Projects Credit - Autoinvoice Error: You can not apply more than the original line amount.
<br><br>For more information, read: [392856.1] Total amount of credit memo cannot exceed the balance of the debit item it is crediting', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1694', g_select || ' and msg.message_name = ''AR_RAXTRX-1694''',
'Credit memo amount exceeds the item it is crediting','RS',
'The issue may be caused by changing the pricing rounding methodology and/or setup between when the Sales order was raised and when the subsequent RMA was created.',
'Ensure any price and/or currency rounding setup changes are only done during an appropriate freeze window when no further (linked) RMA are to be created.<br> 
If you need to Adjust the invoice, read: [431587.1] Projects Credit - Autoinvoice Error: You can not apply more than the original line amount.
<br><br>For more information, read: [392856.1] Total amount of credit memo cannot exceed the balance of the debit item it is crediting', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1711', g_select || ' and msg.message_name = ''AR_RAXTRX-1711''',
'Invalid ledger id (SET_OF_BOOKS_ID)','RS','The set_of_books_id in RA_INTERFACE_LINES_ALL is populated with invalid value.',
'The set_of_books_id must match the Set of Books associated to the Operating Unit you are running AutoInvoice. You can run the following to get the right value:<br><br>
select set_of_books_id from ar_system_parameters_all<br>
where org_id = &enter_orgid;<br><br>
Use the value returned to populate RA_INTERFACE_LINES_ALL.SET_OF_BOOKS_ID.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1712', g_select || ' and msg.message_name = ''AR_RAXTRX-1712''',
'Tax information should not be provided','RS','You cannot supply tax and related information when the Tax Calculation option for your transaction type is No.',
'Check setup of Transaction Type setup', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1715', g_select || ' and msg.message_name = ''AR_RAXTRX-1715''',
'You cannot supply tax precedence number when you disable compound tax','RS',
'You cannot supply tax precedence number.','The manual tax lines with compound tax are not supported. This functionality is not feasible for implementation in the 11i product
line. ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1692', g_select || ' and msg.message_name = ''AR_RAXTRX-1692''',
'Total amount should be positive','RS','The document created must have a non-negative total amount because the creation sign for your transaction type is Positive. The Creation Sign of the Transaction type used by this transaction, and the total of RA_INTERFACE_LINES_ALL.EXTENDED_AMOUNT for this transaction must match. The Creation Sign is set to Positive, but you have supplied a negative amount for the total of RA_INTERFACE_LINES_ALL.EXTENDED_AMOUNT for this transaction.',
'There are several options to fix this issue, and you need to determine which fits your business needs:<br>
<ul>
  <li>If the amount really needs to be negative you can either associate the transaction to another transaction type that allows negative amounts or change the transaction type definition to Any Sign. </li>
  <li>If the amount is incorrect, you can fix the amount so it does not violate the requirement that the total is Positive.</li>
</ul>
You can make changes via SQL*Plus, or use the Interface Correction form <br>
<strong>Navigation</strong>: Control > Autoinvoice > Interface lines<br>
Query up the order that is failing<br>
If the field you want to edit is not available, place the cursor in one Line Type column, then use the menu item: Folder > Show Field and add the field you want to edit.
<br><br>For more information, read: [568095.1] AutoInvoice Error: The document created must have a non-negative total amount because the creation sign for your transaction type is Positive', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_LINE_OVERAPP',
g_select || ' and msg.message_name = ''AR_RAXTRX_LINE_OVERAPP''',
'Overapplication is not allowed',
'RS',
'A credit memo is attempting to overapply a specific transaction line, but overapplication is not allowed.',
'Validate the Creation Sign of the Transaction type used by this transaction, read [1067797.1]. <br>
If the creation sign is defined as Positive Sign, then the total of RA_INTERFACE_LINES_ALL.EXTENDED_AMOUNT for this transaction must be a positive amount.<br>
There are several options to fix this issue, and you need to determine which fits your business needs:<br />
<ul><li>If the amount really needs to be negative you can either associate the transaction to another transaction type that allows negative amounts or change the transaction type definition to Any Sign.</li> 
<li>If the amount is incorrect, you can fix the amount so it does not violate the requirement that the total is Positive.<br> <br> 
You can make changes via SQL*Plus, or use the Interface Correction form</li> 
</ul>
<strong>Navigation</strong>: Control > Autoinvoice > Interface lines <br>
Query up the order that is failing.<br>
If the field you want to edit is not available, place the cursor in one Line Type column, then use the menu item: Folder > Show Field and add the field you want to edit.
<br><br>For more information, read: [1122945.1] AutoInvoice Error: You Can not Apply More Than The Original Line Amount or The total amount of your credit memo cannot exceed the balance of the debit item it is crediting', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1821', g_select || ' and msg.message_name = ''AR_RAXTRX-1821''',
'Mismatched Post to GL setup','RS','You cannot create a nonpostable credit memo against a postable invoice. Transaction Type is Setup with Post to GL = N',
'Check the setup of the transaction type, read: [1090878.1] and review value in Post to GL, the value for the setup at the credit memo should match the setup of the invoice it is crediting.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1785', g_select || ' and msg.message_name = ''AR_RAXTRX-1785''',
'Invalid GL Date','RS',
'You cannot supply a GL date if the Post To GL option for your transaction type is No. Transaction Type setup show Post to GL = N',
'Check the setup of the transaction type, read: [1090878.1] Troubleshooting Transaction Types In Oracle Receivables, and review the value in Post to GL. 
You should not pass in a GL_DATE if Post to GL is unchecked for your transaction type.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1649', g_select || ' and msg.message_name = ''C-1649''',
'You cannot supply freight charges when the Allow Freight option for your transaction type is No','RS',
'You have supplied a Transaction Type that does not allow Freight, but you are interfacing Freight charges',
'If the Transaction Type setup is correct, then you should remove this line from Interface Lines table.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1631', g_select || ' and msg.message_name = ''C-1631''',
'Invalid transaction type id (CUST_TRX_TYPE_ID)','RS','Invalid transaction type id (CUST_TRX_TYPE_ID).',
'These are the common causes for this validation error:
<ul>
  <li>The column CUST_TRX_TYPE_ID was not provided. </li>
  <li>The ID passed does not exist in RA_CUST_TRX_TYPES_ALL.CUST_TRX_TYPE_ID. </li>
  <li>Transaction Source Setup mismatch. The setup indicates Transaction Type = ID, but instead you are providing value.</li>
</ul><br>
Check your setup:<br>
<b>Navigation:</b> Setup > Transactions > Sources <br>
Go to the Other Information tab<br>
Review settings for Transaction Type: Value or ID.<br>
Ensure you are passing the required data and that it exists in RA_CUST_TRX_TYPES table.
<br><br>For more information, read: [1116093.1] AutoInvoice Error: Invalid Transaction Type id (CUST_TRX_TYPE_ID)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1630', g_select || ' and msg.message_name = ''C-1630''',
'Invalid transaction type name (CUST_TRX_TYPE_NAME)','RS','Invalid transaction type name (CUST_TRX_TYPE_NAME)',
'These are the common causes for this validation error: <br>
<ul>
  <li>The column CUST_TRX_TYPE_NAME was not provided.</li>
  <li>The value passed does not exist in RA_CUST_TRX_TYPES_ALL.NAME.</li>
  <li>Transaction Source Setup mismatch. The setup indicates Transaction Type = Value, but instead you are providing ID.</li>
</ul><br>
Check your setup:<br>
<b>Navigation:</b> Setup > Transactions > Sources <br>
Go to the Other Information tab<br>
Review settings for Transaction Type: Value or ID.<br>
Ensure you are passing the required data and that it exists in RA_CUST_TRX_TYPES table.
<br><br>For more information, read: [1112634.1] AutoInvoice Error: Invalid Transaction Type Name (CUST_TRX_TYPE_NAME)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1648', g_select || ' and msg.message_name = ''C-1648''','Invalid printing option (PRINTING_OPTION)','RS','Invalid printing option (PRINTING_OPTION)',
'The only valid values that are allowed for this field (PRINTING_OPTION) are those that exist as a LOOKUP_CODE in AR_LOOKUPS for LOOKUP_TYPE = INVOICE_PRINT_OPTIONS. Verify if the value you have supplied exists in the lookup. ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1783', g_select || ' and msg.message_name = ''AR_RAXTRX-1783''',
'Not all periods are defined','RS','Accounting Periods are not properly defined.',
'Please define all periods in which revenue is to be recognized or credited. Note that revenue cannot be recognized or credited in closed and close pending periods. 
Verify whether you have the GL Periods  defined in your system. Also check the status of the Period in which the GL Date of your Interface Line falls.<br>
<br><br>For more information, read: [455691.1]  Error: Please Define All Periods In Which Revenue Is To Be Recognized Or Credited (AutoInvoice and Transaction Workbench)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1784', g_select || ' and msg.message_name = ''AR_RAXTRX-1784''','Overlapping periods for the accounting rule and first GL date exist','RS',
'Overlapping periods for the accounting rule and first GL date exist.',
'Check the GL periods defined and ensure there are no overlapping dates. Read [1069057.1] How To Manage Receivables Accounting Periods 
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1791', g_select || ' and msg.message_name = ''AR_RAXTRX-1791''',
'Unable to adjust gl date, no open period','RS',
'AutoInvoice is attempting to adjust the gl date you provided because it falls into a closed period. However, it is unable to locate an open period to move it to.',
'Check your GL periods to ensure that there is at least one open period that comes after the GL_DATE.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1792', g_select || ' and msg.message_name = ''AR_RAXTRX-1792''',
'Unable to derive a gl date for your transaction','RS',
'Unable to derive a gl date for your transaction. Either the AutoInvoice was not able to derive GL Date, or the GL Date that was derived, is not in Open period',
'Typically this happens due to Transaction Source setup. Check whether you have set up the Transaction Source to Derive GL Date. You can change the Transaction source definition and re-submit the AutoInvoice program.
Another common reason for this error, is the GL Period Status. Check the GL Date that was derived or supplied and verify if the GL Period in which it falls, is in Open status. You can set the period status to Open and re-submit the AutoInvoice program. <br>
There are other reasons too, like supplying Invoicing Rule and Accounting Rule information for Credit memo. 
<br><br>For more information, read: [1122898.1] AutoInvoice Error: Unable To Derive A GL Date For Your Transaction. Please Ensure That Your Transaction Is In A GL Period Which You Have Defined.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1782', g_select || ' and msg.message_name = ''AR_RAXTRX-1782''',
'You must define a period for this GL date','RS',
'You must define a period for this GL date',
'Check that the GL_DATE you provided falls in a valid GL period. 
<br><br>For more information, read: [1069057.1] How To Manage Receivables Accounting Periods', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1790', g_select || ' and msg.message_name = ''AR_RAXTRX-1790''',
'Unable to adjust GL date, multiple open periods','RS',
'Unable to adjust the GL date to an open or future enterable period because there is more than one subsequent period open.',
'Set period to future enterable instead of open.<br><br>
<strong>Responsibility:</strong> Receivables Manager<br> 
<strong>Navigation:</strong> Control > Accounting > Open/Close periods<br>', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('C-1652', g_select || ' and msg.message_name = ''C-1652''',
'The supplied gl date is in a closed period','RS',
'The supplied gl date is in a closed period',
'First, note down the GL_DATE that you provided on this line.<br>
Next, validate that status of the period. The status should not be closed.
<br><br>For more information, read: [1069057.1] How To Manage Receivables Accounting Periods', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR-SURUL-NO_CASH_RULES', g_select || ' and msg.message_name = ''AR-SURUL-NO_CASH_RULES''','You cannot define rules when your Accounting Method is Cash Basis','RS',
'You cannot define rules when your Accounting Method is Cash Basis',
'If you use Cash Basis Accounting, you have to remove the accounting rules specified in the Interface Lines table.
<br><br>For more information, read: [369508.1] You cannot define rules when your Accounting Method is Cash Basis.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1617', g_select || ' and msg.message_name = ''AR_RAXTRX-1617''','Only debit memos and credit memos may have a line type of CHARGES','RS','You are importing an Invoice and have entered a record with LINE_TYPE = ''CHARGES''.','Validate the LINE_TYPE you have associated with the Invoice you are importing. The LINE_TYPE = CHARGES is only allowed for  Debit Memo and Credit Memo transactions. For Invoices, you can only use LINE_TYPE = LINE , TAX or FREIGHT. ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1668',
g_select || ' and msg.message_name = ''AR_RAXTRX-1668''',
'An invoice can only reference a commitment',
'RS',
'You have populated REFERENCE_LINE_CONTEXT and REFERENCE_LINE_ATTRBUTE1-15 columns for an Invoice you are trying to import, however, these REFERENCE* columns are not pointing to a commitment (i.e. a transaction with class of Deposit or Guarantee).',
'Decide what type of transaction you want to interface.<br>
<ul>
  <li>If you meant to interface an Invoice, then the record pointed to by the REFERENCE_* fields should point to a Commitment or a Guarantee. If not, then you should check the INTERFACE_LINE_ATTRIBUTE* values or CUSTOMER_TRX_LINE_ID of the correct commitment or guarantee to use and correct the data. If you don''t want the invoice to draw from a commitment or guarantee then you should NULL out the REFERENCE fields.</li>
  <li>If you meant to interface an Applied Credit Memo, then ensure that the CUST_TRX_TYPE_ID value used is for a credit memo, and that the REFERENCE* fields point to the invoice that you want to credit.</li>
</ul>
<br><br>For more information, read: [755834.1] AutoInvoice Error - An Invoice Can Only Reference A Commitment', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1707', g_select || ' and msg.message_name = ''AR_RAXTRX-1707''','Invalid memo line name (MEMO_LINE_NAME)','RS',
'The value in MEMO_LINE_NAME does not exist in AR_MEMO_LINES.',
'The value you populated in MEMO_LINE_NAME should be a value that exists in AR_MEMO_LINES.NAME.
You can maintain this via:<br>
<b>Navigation:</b> Setup > Transactions > Memo Lines<br>
Query up the Memo Line Name.<br><br>
Alternatively, you can check data by running the following query:<br>
select * from ar_memo_lines<br>
where org_id = &enter_org_id; <br>', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1708', g_select || ' and msg.message_name = ''AR_RAXTRX-1708''','Invalid memo line id (MEMO_LINE_ID)','RS',
'The value in MEMO_LINE_ID does not exist in AR_MEMO_LINES.',
'The value you populated in MEMO_LINE_ID should be a value that exists in AR_MEMO_LINES.MEMO_LINE_ID.
You can check data in this table by running the following query:<br><br>
select * from ar_memo_lines<br>
where org_id = &enter_org_id; <br>', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1723', g_select || ' and msg.message_name = ''AR_RAXTRX-1723''','You cannot supply system items for your debit memo transaction','RS','This could be caused by the invalid data or a bug if you are importing transactions from Trade Management',
'For more information, read: [1265765.1] AutoInvoice Error: You cannot supply system items for your debit memo transaction', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1729', g_select || ' and msg.message_name = ''AR_RAXTRX-1729''',
'Mismatched unit of measure class','RS','The supplied unit of measure and the primary unit of measure of your system item must share the same unit of measure class.',
'For more information, read: [1132807.1]  Troubleshooting Unit of Measure Issues with AutoInvoice', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1731', g_select || ' and msg.message_name = ''AR_RAXTRX-1731''','You must supply the amount for this transaction','RS',
'The AutoInvoice validation code is expecting a non-null value to be provided for amount, but the Interface Lines record value is null.',
'For more information, read: [370557.1]  AutoInvoice Error: You Must Supply The Amount For This Transaction ( Nil )', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1732', g_select || ' and msg.message_name = ''AR_RAXTRX-1732''','You cannot link a transaction whose line type is LINE or CHARGES to another transaction','RS','You have incorrectly populated the LINK_TO* fields for a record that has LINE_TYPE = LINE or CHARGES.','Records with LINE_TYPE = LINE or CHARGES should not be linked to any record. Do not populate the LINK_TO* fields for records with LINE_TYPE = LINE or CHARGES.<br><br>For more information, read: [1068344.1] Setting Up Receivables Descriptive Flexfields [Video] ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1733', g_select || ' and msg.message_name = ''AR_RAXTRX-1733''','You must link the transaction of line type TAX to a transaction of line type LINE','RS','You have not populated the LINK_TO* fields for a record that has LINE_TYPE = TAX.','The LINK_TO* fields tell Autoinvoice what lines this TAX record is associated to. You should populate the LINK_TO* fields of the TAX record to point to a record that has RA_INTERFACE_LINES.LINE_TYPE = LINE.
<br><br>For more information of how to use LINK_* fields, read: [1068344.1] Setting Up Receivables Descriptive Flexfields [Video] ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1734', g_select || ' and msg.message_name = ''AR_RAXTRX-1734''','Quantity, unit_selling_price, and amount must be null or zero for tax-only and freight-only lines','RS','You have incorrectly populated one or all of the following fields: QUANTITY, UNIT_SELLING_PRICE, AMOUNT for a record that has LINE_TYPE = TAX or FREIGHT.','For records with RA_INTERFACE_LINES.LINE_TYPE = TAX or FREIGHT,  the following columns: QUANTITY, UNIT_SELLING_PRICE, AMOUNT should be null or zero.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1740', g_select || ' and msg.message_name = ''AR_RAXTRX-1740''','Invalid related document value (RELATED_TRX_NUMBER)','RS','The value entered for RELATED_TRX_NUMBER and RELATED_BATCH_SOURCE_NAME are not synchronized with what is stored in RA_CUSTOMER_TRX  and RA_BATCH_SOURCES.','Find the record where RA_CUSTOMER_TRX.TRX_NUMBER = RA_INTERFACE_LINES.RELATED_TRX_NUMBER, then check the value in RA_CUSTOMER_TRX.BATCH_SOURCE_ID and cross reference this value to RA_BATCH_SOURCES.BATCH_SOURCE_ID. The value in RA_BATCH_SOURCES.NAME  has to match what was passed in RA_INTERFACE_LINES.RELATED_BATCH_SOURCE_NAME.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1741', g_select || ' and msg.message_name = ''AR_RAXTRX-1741''','Invalid related document id (RELATED_CUSTOMER_TRX_ID)','RS','The value entered for RELATED_CUSTOMER_TRX_ID was not found in RA_CUSTOMER_TRX.','Check the value in RA_INTERFACE_LINES.RELATED_CUSTOMER_TRX_ID, you should be able to locate a record in RA_CUSTOMER_TRX where CUSTOMER_TRX_ID = RELATED_CUSTOMER_TRX_ID<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1746', g_select || ' and msg.message_name = ''AR_RAXTRX-1746''','The two linked transactions must have the same ledger id','RS',
'You have linked one transaction to another via REFERENCE_* fields but they do not belong to the same Ledger.',
'Check the value used in RA_INTERFACE_LINES.SET_OF_BOOKS_ID  for the records with REFERENCE_* populated. 
Then locate the record that the REFERENCE_* fields is pointing to and ensure that it has the same value in RA_INTERFACE_LINES.SET_OF_BOOKS_ID.
<br><br>For more information of how to use REFERENCE_* fields, read: [1068344.1] Setting Up Receivables Descriptive Flexfields [Video] ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1747', g_select || ' and msg.message_name = ''AR_RAXTRX-1747''','The two linked transactions must have the same currency code','RS',
'You have linked one transaction to another via REFERENCE_* fields but they do not have the same currency code.',
'Check the value used in RA_INTERFACE_LINES.CURENCY_CODE  for the records with REFERENCE_* populated. 
Then locate the record that the REFERENCE_* fields is pointing to and ensure that it has the same value in RA_INTERFACE_LINES.CURRENCY_CODE. 
<br><br>For more information of how to use REFERENCE_* fields, read: [1068344.1] Setting Up Receivables Descriptive Flexfields [Video] ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1748', g_select || ' and msg.message_name = ''AR_RAXTRX-1748''','The transaction to which you link this transaction must have the line type LINE','RS',
'You are linking  to a record via the LINK_TO* fields and the record you are pointing to does not have LINE_TYPE = LINE.',
'Check that the record pointed to by the values in LINK_TO_* fields has RA_CUSTOMER_TRX_LINES.LINE_TYPE = LINE.
<br><br>For more information of how to use LINK_TO* fields, read: [1068344.1] Setting Up Receivables Descriptive Flexfields [Video] ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1756', g_select || ' and msg.message_name = ''AR_RAXTRX-1756''',
'Invalid Inventory Item setup',
'RS','This inventory item has Invoice Enabled flag set to No.  Please set the Invoice Enabled flag in the Items window to Yes for this inventory item.','Start with checking the setup of the Master Item. <br>
<blockquote>
  <b>Responsibilty:</b> Oracle Inventory <br>
  <b>Navigation:</b> Master Items  <br>
  Query for the Inventory Item<br>
  Go to Invoicing Tab and make sure the following properties are set correctly: Invoiceable Item = Y and Invoice Enabled = Y<br>
</blockquote>
If this is not the issue, then the next thing to validate is as follows:<br>
<blockquote>
  <b>Responsibility:</b> Order Management <br>
  <b>Navigation:</b> Setup > Parameters<br>
  Verify the values that you have set for:<br>
  <ol>
    <li>Operating Unit</li>
    <li>Item validation Organization.</li>
  </ol>
Please check that the Item Validation Organization is the same as the Organization above whose item has the invoice enabled flag and invoiceable item flag to yes. 
AutoInvoice validates the item associated with the warehouse id or the Master Organization ID for checking the Invoice Enabled flag.</blockquote>
<br><br>For more information, read: [549203.1] Autoinvoice Error: This Inventory Item Has Invoice Enabled Flag Set To No', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1665',
g_select || ' and msg.message_name = ''AR_RAXTRX-1665''',
'Duplicate Transaction Flexfield in Lines table',
'RS',
'This line has the same transaction flexfield as another invoice within Receivables. For each transaction line in Receivables, the combination of INTERFACE_LINE_CONTEXT and INTERFACE_LINE_ATTRIBUTE1-15 values must be unique.',
'Check that the combination of values in RA_INTERFACE_LINES_ALL.INTERFACE_LINE_CONTEXT + INTERFACE_LINE_ATTRIBUTE1-15 does not yet exist in RA_CUSTOMER_TRX_LINES_ALL<br><br>
For more information, read: [1339318.1] Autoinvoice Error: This line has the same transaction flexfield as another row in the interface table', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1514', g_select || ' and msg.message_name = ''AR_RAXTRX-1514''',
'Transaction flexfield context has no enabled segments','RS',
'None of the transaction flexfield contexts you have provided for this request have enabled segments. <br>This error is raised in the log file of RAXTRX module: AutoInvoice Import Program when the Transaction Flexfield context you are using in the interface table does not have any segments enabled.',
'Review the Flexfield setup:<br>
<strong>Responsibility: </strong>Receivables Manager<br>
    <strong>Navigation:</strong> Setup > Financials > Descriptive > Segments
    <ol>
      <li>Query for Application = <em>Receivables</em>, Title = <em>Line Transaction Flexfield</em></li>
      <li>In the Context field section, under Code, place the cursor on the record that matches the value shown in INTERFACE_LINE_CONTEXT above</li>
      <li>Click on Segments button</li>
      <li>Ensure that at least one segment exists and is enabled</li>
    </ol></li>
</ul>
<br><br>For more information, read: [1077555.1] Troubleshooting Transaction Flexfields in AutoInvoice (Step 1c)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1664',
g_select || ' and msg.message_name = ''AR_RAXTRX-1664''',
'All enabled segments of Transaction Flexfield must have a value',
'RS',
'This error is raised when you do not provide values for the complete set of segments associated with the context you specified in the interface lines table.',
'Use the value in INTERFACE_LINE_CONTEXT listed above to run a query in the form:<br>
  <br>
  <strong>Responsibility:</strong> Receivables Manger<br>
  <strong>Navigation:</strong> Setup > Financials > Flexfields > Descriptive > Segments<br>
Query on Title = <em>Line Transaction Flexfield</em><br>
Navigate to the Context Field Values of the form, and in the Context field, locate the record with the value that matches INTERFACE_LINE_CONTEXT above.<br>
Click on Segments, paying attention to which segments are enabled, then make sure these same segments are provided in the Interface table.
<br><br>For more information, read: [1077555.1] Troubleshooting Transaction Flexfields in AutoInvoice (Step 1d)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1778', g_select || ' and msg.message_name = ''AR_RAXTRX-1778''','You cannot supply territory flexfield data because the territory flexfield is not defined','RS','You cannot supply territory flexfield data because the territory flexfield is not defined.','Check that the territory flexfield is active and frozen.<br><br>For more information, read: [432817.1] Is The Territory Flexfield Required', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1665A',
g_select || ' and msg.message_name = ''AR_RAXTRX-1665A''',
'Duplicate Transaction Flexfield in Interface table',
'RS',
'This line has the same transaction flexfield as another row in the interface table.  For each transaction line, the combination of INTERFACE_LINE_CONTEXT and INTERFACE_LINE_ATTRIBUTE1-15 values must be unique.',
'Check that the combination of values in RA_INTERFACE_LINES_ALL INTERFACE_LINE_CONTEXT + INTERFACE_LINE_ATTRIBUTE1-15 is unique.
<br><br>For more information, read: [1339318.1] Autoinvoice Error: This line has the same transaction flexfield as another row in the interface table.', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1665B',
g_select || ' and msg.message_name = ''AR_RAXTRX-1665B''',
'Duplicate Transaction Flexfield in Lines table',
'RS',
'This line has the same transaction flexfield as another invoice within Receivables. The combination of INTERFACE_LINE_CONTEXT and INTERFACE_LINE_ATTRIBUTE1-15 values must be unique',
'Check that the combination of values in RA_INTERFACE_LINES_ALL INTERFACE_LINE_CONTEXT + INTERFACE_LINE_ATTRIBUTE* does not yet exist in RA_CUSTOMER_TRX_LINES_ALL<br><br>
For more information, read: [1339318.1] Autoinvoice Error: This line has the same transaction flexfield as another row in the interface table', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1699', g_select || ' and msg.message_name = ''AR_RAXTRX-1669''',
'Freight exists at multiple levels','RS','You can have at most one Freight transaction line at either the line level or the invoice level, but not at both levels.','If you need to create an invoice with Freight, ensure that you provide a FREIGHT line either at the RA_INTERFACE_LINES_ALL level or the RA_INTERFACE_DISTRIBUTIONS_ALL level and not both. If provided at the distribution level, each transaction can only have one freight distribution.<br><br>For more information, read: [1138254.1] Error: You can have at most one Freight transaction line at either the line level or the invoice level, but not at both levels.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_FRM_FRT_ERR', g_select || ' and msg.message_name = ''AR_RAXTRX_FRM_FRT_ERR''','Freight Errors','RS','APP-AR-11389: The Carrier Is Invalid With The Current Transaction Date.','This error is raised if the record associated to the freight carrier is not enabled, or if the DISABLE_DATE comes prior to the transaction date of the transaction using it.<br><br>For more information, read: [1315056.1] Error: APP-AR-11389: The Carrier Is Invalid With The Current Transaction Date.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_FRM_FRT_DIST',
g_select || ' and msg.message_name = ''AR_RAXTRX_FRM_FRT_DIST''',
'Freight Distribution Errors',
'RS',
'Invalid SHIP_VIA Error',
'This error occurs when the validation for freight carrier in the shipping organization fails. This error is raised when RA_INTERFACE_LINES_ALL.SHIP_VIA is populated, but RA_INTERFACE_LINES_ALL.WAREHOUSE_ID is empty, or 
there is no record in ORG_FREIGHT for the organization = WAREHOUSE_ID<br><br>
For more information, read: [1315056.1] Error: Invalid SHIP_VIA Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1650', g_select || ' and msg.message_name = ''C-1650''','Invalid FOB point (FOB_POINT)','RS','Invalid FOB point (FOB_POINT).',
'Verify whether the value that you have populated on this record in FOB_POINT exists as a LOOKUP_CODE in AR_LOOKUPS for LOOKUP_TYPE = FOB.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1651', g_select || ' and msg.message_name = ''C-1651''','Invalid ship via (SHIP_VIA)','RS','Invalid FOB point (SHIP_VIA).',
'Check that the value you populated into RA_INTERFACE_LINES_ALL.SHIP_VIA exists in ORG_FREIGHT.FREIGHT_CODE for the organization id you are using.
<br><br>For more information, read: [274785.1] Autoinvoice Error: Invalid Ship Via (Ship_Via) (Ship_Via)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1618', g_select || ' and msg.message_name = ''AR_RAXTRX-1618''','Rules are not allowed on line type CHARGES','RS',
'You are interfacing a record with Line type = CHARGES. But you have supplied invoicing and accounting rule information.',
'Remove the Invoicing and Accounting Rule information from the record. You can supply the Invoicing and Accounting Rule information only for lines with Line Type = Line.', 
' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1704', g_select || ' and msg.message_name = ''AR_RAXTRX-1704''',
'Invalid credit method for accounting rule (CREDIT_METHOD_FOR_ACCT_RULE)','RS',
'When you credit an invoice that has accounting rules, the credit memo will inherit the same rules. The value you provide for the Rules method in the Credit memo form or in RA_INTERFACE_LINES_ALL.CREDIT_METHOD_FOR_ACCT_RULE, 
will determine how the credit will be distributed against the invoice''s revenue schedule.',
'Valid values for CREDIT_METHOD_FOR_ACCT_RULE are:<br>
<ul>
<li>PRORATE, will split up the credit amount equally across all revenue periods.</li>
<li>LIFO, will apply the credit amounts starting from the last period.</li>
<li>UNIT, the credit amount will be based on quantity associated to each line.</li></ul>
<br><br>For more information, read: [1110573.1] Troubleshooting Credit Memos in the Transaction Workbench and AutoInvoice in Receivables', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1728', g_select || ' and msg.message_name = ''AR_RAXTRX-1728''',
'Missing accounting rule duration','RS',
'You must supply an accounting rule duration when you supply an accounting rule of type Variable Duration.',
'When using a fixed duration rule, there is no need to populate ACCOUNTING_RULE_DURATION. When using variable duration rule, you must supply a value in ACCOUNTING_RULE_DURATION.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1735', g_select || ' and msg.message_name = ''AR_RAXTRX-1735''','Accounting rule duration must be a positive integer','RS','
 Accounting rule duration must be a positive integer','Check that RA_INTERFACE_LINES_ALL.ACCOUNTING_RULE_DURATION is not a negative number.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1766', g_select || ' and msg.message_name = ''AR_RAXTRX-1766''',
'Invalid Last Period to Credit','RS',
'The Last Period to Credit must be greater than 0 but less than the accounting rule duration of the invoice line you are crediting.',
'Check the value in RA_INTERFACES_LINES_ALL.LAST_PERIOD_TO_CREDIT has to be a value between 1 and the total number of durations of the invoice being credited.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1795', g_select || ' and msg.message_name = ''AR_RAXTRX-1795''',
'Incorrect rule start date','RS',
'Ensure that rule start date will generate GL Dates that are in Open or Future periods when the <em>GL Date in a Closed Period</em> option is set to Reject in the Transaction Sources window.',
'The code is unable to derive a GL Date, please review [201241.1] Troubleshooting AutoInvoice Date Derivation: GL Date, Invoice Date, Due Date, Ship Date, Billing Date, Rule Date.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_RSD_LT_RED', g_select || ' and msg.message_name = ''AR_RAXTRX_RSD_LT_RED''','A rule''s end date cannot precede its start date','RS','  A rule''s end date cannot precede its start date.','Check that the RULE_END_DATE comes after the RULE_START_DATE<br><br>For more information, read: [1116934.1] How To Setup And Troubleshoot Invoicing Rules and Accounting Rules', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_INV_WAREHOUSE', g_select || ' and msg.message_name = ''AR_RAXTRX_INV_WAREHOUSE''','Invalid Warehouse ID (WAREHOUSE_ID)','RS','The validation of the WAREHOUSE_ID has failed.','There are multiple causes for this error to be raised. Typically, it is due to setup.<br><br>For more information, read: [1089026.1] AutoInvoice Error: Invalid Warehouse ID (WAREHOUSE_ID) (xxx)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_REJECTED_INV', g_select || ' and msg.message_name = ''AR_RAXTRX_REJECTED_INV''','The related invoice has validation errors','RS','This is a generic error raised when an invoice has validation errors.','The validation code has hit errors while checking the data associated to the REFERENCE_* fields. A more specific list of errors is provided in the RA_INTERFACE_ERRORS table.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1780', g_select || ' and msg.message_name = ''AR_RAXTRX-1780''',
'Mismatched USSGL transaction code','RS',
'You are linking one record to another via the LINK_TO* fields and the USSGL_TRANSACTION value you have populated into these related records does not match.',
'For the 2 records you are linking via the LINK_TO* fields ensure that the records have the same value in USSGL_TRANSACTION.
<br><br>For more information of how to use LINK_TO* fields, read: [1068344.1] Setting Up Receivables Descriptive Flexfields [Video] ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1724', g_select || ' and msg.message_name = ''AR_RAXTRX-1724''','You must supply related batch source name when you supply related invoice number','RS','You entered a value in RELATED_TRX_NUMBER but did not provide a value in RELATED_BATCH_SOURCE_NAME.','Find the record where RA_CUSTOMER_TRX.TRX_NUMBER = RA_INTERFACE_LINES.RELATED_TRX_NUMBER, then check the value in RA_CUSTOMER_TRX.BATCH_SOURCE_ID and cross reference this value to RA_BATCH_SOURCES.BATCH_SOURCE_ID. The value in RA_BATCH_SOURCES.NAME  has to match what was passed in RA_INTERFACE_LINES.RELATED_BATCH_SOURCE_NAME.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1620_G', g_select || ' and msg.message_name = ''AR_RAXTRX-1620_G''','You must supply a credit percentage when your batch source indicates you supply percentages','RS',
'When you defined your batch source, you indicated that you would provide percentages, for sales credits, however, you did not provide a value in RA_INTERFACE_SALESCREDITS.SALES_CREDIT_PERCENT_SPLIT.',
'Check whether you have set Amount or Percent for Sales Credit in your Batch Source, then provide the value in the interface table.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.
<br><br>For more information, read: [1068008.1] Creating Transaction Sources Used For AutoInvoice and the Transactions Workbench [Video], specifically the section on Creating a Batch Source for use in Autoinvoice where the Sales Credit Validation tab is discussed', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1642', g_select || ' and msg.message_name = ''C-1642''','Invalid agreement name (AGREEMENT_NAME)','RS','Invalid agreement name (AGREEMENT_NAME)',
'Check your setup:<br>
<b>Navigation:</b> Setup > Transactions > Sources<br>
Go to the Other Information tab, and review you settings for Agreement: Id or Value.<br>
Then ensure you populate either AGREEMENT_ID or AGREEMENT_NAME depending on your setup. <br>
Next, verify the data: Check that the value you have provided, exists in SO_AGREEMENTS.NAME.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1643', g_select || ' and msg.message_name = ''C-1643''','Invalid agreement id (AGREEMENT_ID)','RS','Invalid agreement name (AGREEMENT_ID)',
'Check you transaction source setup:<br>
<b>Navigation:</b> Setup > Transactions > Sources<br><br>
In the Other Information tab review Agreement, for whether you have set Id or Value. You should populate the ID or the Value according to the setup.<br>
Next, check that the value provided exists in SO_AGREEMENTS.AGREEMENT_ID.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1515',
g_select || ' and msg.message_name = ''AR_RAXTRX-1515''',
'Missing value in column INTERFACE_LINE_CONTEXT.',
'RS',
'The INTERFACE_LINE_CONTEXT column is mandatory; AutoInvoice uses this field to understand the context of the data passed into the INTERFACE_LINE_ATTRIBUTE* fields. ',
'The value you provide here should exist as a Context Flexfield Code in the Descriptive Flexfields form.<br>
<b>Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > Financials > Flexfields > Descriptive > Segments <br>
Query for Application = Receivables, Title = Line Transaction Flexfield to see valid values.<br><br>For more information, read: [1195997.1] R12 How To Bring In (and Troubleshoot) Manual Tax Lines Through Autoinvoice and E-Business Tax (EBTax)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1628_G',
g_select || ' and msg.message_name = ''AR_RAXTRX-1628_G''',
'You must supply a value for the credit amount',
'RS',
'Your batch source setup indicates that you will provide an amount for Sales credits, but RA_INTERFACE_SALESCREDITS_ALL SALES_CREDIT_AMOUNT_SPLIT is null.',
'Ensure you are passing a non-null value in RA_INTERFACE_SALESCREDITS_ALL.SALES_CREDIT_AMOUNT_SPLIT.
<br><br>Use the value in INTERFACE_SALESCREDIT_ID in the list above to locate the RA_INTERFACE_SALESCREDITS_ALL rows in error.', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1768', g_select || ' and msg.message_name = ''AR_RAXTRX-1768''','You must supply a quantity to credit when passing Unit credit memos','RS',
'If RA_INTERFACE_LINES_ALL.CREDIT_METHOD_FOR_ACCT_RULE = UNIT then RA_INTERFACE_LINES_ALL.QUANTITY is mandatory. Additionally, if LINE_TYPE = CHARGES, set quantity to 1 or -1.',
'Enter a value in RA_INTERFACE_LINES_ALL.QUANTITY. You can use the Interface Lines form.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1801', g_select || ' and msg.message_name = ''AR_RAXTRX-1801''',
'Invoice is locked by another user','RS',
'Cannot apply the credit memo because the invoice you are crediting may be locked by another user.',
'For more information, read: [1087146.1] AutoInvoice Error: Cannot apply the credit memo because the invoice is locked by another user. Please try again later.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1800', g_select || ' and msg.message_name = ''AR_RAXTRX-1800''',
'Invoice status is Incomplete','RS',
'The credit memo cannot be applied because the invoice it is crediting has a status of Incomplete.',
'Query the invoice being credited, and ensure status is set to Complete by clicking the Complete button.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1776', g_select || ' and msg.message_name = ''AR_RAXTRX-1776''','Mismatched line types','RS',
'The value in RA_INTERFACE_LINES.LINE_TYPE for the credit memo must be the same as the value in RA_CUSTOMER_TRX_LINES_ALL.LINE_TYPE for the invoice or debit memo line you are crediting.',
'Valid values are: LINE, TAX, FREIGHT or CHARGES.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1690', g_select || ' and msg.message_name = ''AR_RAXTRX-1690''',
'Multiple Receivables account','RS',
'If you are passing distributions manually via the RA_INTERFACE_DISTRIBUTIONS_ALL table, the code expects only one REC distribution for each transaction.',
'Check that you have not passed multiple REC rows:<br>
<b>Navigation:</b> Control > Autoinvoice > Interface lines
<ol>
  <li>Query up the sales order that is raising the error</li>
  <li>Click the acccounting button and review the distributions provided for account = REC. There should be only one REC row.</li>
  <li> If there is more than one, delete the ''extra'' rows, save and re-try AutoInvoice.</li>
</ol>
<br><br>Use the value in INTERFACE_DISTRIBUTION_ID in the list above to locate the RA_INTERFACE_DISTRIBUTIONS_ALL rows in error.
<br><br>For more information, read: [1146563.1]  AutoInvoice Error: You can supply at most one Receivables account for a transaction (an invoice,a debit memo or a credit memo)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1812', g_select || ' and msg.message_name = ''AR_RAXTRX-1812''',
'Grouping Rule issue: Bill-to address','RS','All of the transactions in a single group must be for the same Bill-to address.','Check the value in RA_INTERFACE_LINES_ALL.CONS_BILLING_NUMBER and ensure that rows having identical values all have the same value in ORIG_SYSTEM_BILL_ADDRESS_ID<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1796', g_select || ' and msg.message_name = ''AR_RAXTRX-1796''',
'Grouping Rule issue: Document number split','RS','Invoice lines with the same document number have been separated by the grouping process, causing duplicate document numbers.',
'Check the grouping rules you have defined, and check why records with common document number values ended up getting split up into multiple invoices instead of being created as one invoice.
<br><br>For more information, read: [1084554.1] Troubleshooting Grouping Rules In AutoInvoice', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1810', g_select || ' and msg.message_name = ''AR_RAXTRX-1810''',
'Grouping Rule issue: Bill-to Customer','RS','  All of the transactions in a single group must be for the same Bill-to Customer.','Check the value in RA_INTERFACE_LINES_ALL.CONS_BILLING_NUMBER and ensure that rows having identical values all have the same value in  ORIG_SYSTEM_BILL_CUSTOMER_ID<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1797', g_select || ' and msg.message_name = ''AR_RAXTRX-1797''',
'Grouping Rule issue: Transaction number split','RS','Transaction lines with the same transaction number have been separated by the grouping process, causing duplicate transaction numbers.','Check the grouping rules you have defined  and check why records with common transaction number values ended up getting split up into multiple invoices instead of being created as one invoice.<br><br>For more information, read: [1084554.1] Troubleshooting Grouping Rules In AutoInvoice', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1700', g_select || ' and msg.message_name = ''AR_RAXTRX-1700''',
'Invalid receipt method name (RECEIPT_METHOD_NAME)','RS',
'A receipt method is required when a payment extension entity is passed.',
'If you are providing a value for RA_INTERFACE_LINES.PAYMENT_TRXN_EXTENSION_ID, then you must also provide a corresponding value for RECEIPT_METHOD_NAME.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1701', g_select || ' and msg.message_name = ''AR_RAXTRX-1701''',
'Invalid receipt method id (RECEIPT_METHOD_ID)','RS','Invalid receipt method id (RECEIPT_METHOD_ID).',
'If the Receipt Method ID is 0 (zero) then refer to the suggested knowledge article. Otherwise, check if an active receipt method exists for the ID that was specified on this record.
<br><br>For more information, read: [1379823.1] AutoInvoice: Invalid receipt methoid id (RECEIPT_METHOD_ID) = 0 for a Order with payment type = Credit Card.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1702', g_select || ' and msg.message_name = ''AR_RAXTRX-1702''','Invalid customer bank account name (CUSTOMER_BANK_ACCOUNT_NAME)','RS','Invalid customer bank account name (CUSTOMER_BANK_ACCOUNT_NAME)',
'<p>For release 11i, AutoInvoice validates that the supplied customer bank account belongs to one of the following, otherwise the line is rejected:</p>
<ul>
  <li>Bank account assigned to the primary site for the parent</li>
  <li>Bank account assigned to the parent customer</li>
  <li>Bank account assigned to the bill-to site for the line</li>
  <li>Bank account assigned to the bill-to customer for the line</li>
</ul><br>
You should populate the customer bank account name information only for the ''LINE'' type interface lines. Providing this info on a TAX line will also cause the line to be rejected. <br>
For R12, the field customer bank account name is obsolete.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1703', g_select || ' and msg.message_name = ''AR_RAXTRX-1703''',
'The supplied customer bank account (CUSTOMER_BANK_ACCOUNT_ID) must be both valid and active.','RS',
'The Customer Bank Account is not valid/active as of Transaction Date derived or supplied.',
'For records coming from Order Management: AutoInvoice creates the customer bank account with <em>Effective Date</em> as SYSDATE (system date). 
Whereas the Transaction Date is set to the Sales Order Date, which may have been before SYSDATE. This typically happens for non shippable lines.
<br><br>For more information, read: [438237.1] AutoInvoice Error : The Supplied Cust Bank account (Customer_bank_account_id) Must Be Valid And Active', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1760', g_select || ' and msg.message_name = ''AR_RAXTRX-1760''',
'Receipt Method is Manual, do not supply the customer bank account','RS',
'You cannot supply the customer bank account when the supplied or defaulted receipt method is of type Manual.',
'Remove the customer bank account supplied.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1761', g_select || ' and msg.message_name = ''AR_RAXTRX-1761''',
'Inactive or missing receipt method','RS',
'The supplied receipt method must be defined and active for the bill-to customer or site',
'Following are some reasons that cause this error:<br>
<ul>
  <li>Receipt method manually entered into AutoInvoice, but not assigned to the customer.</li>
  <li>The Payment Method assignment start date at customer and/or site level is later then the trx_date of the imported transaction.</li>
  <li>A remittance bank account named Credit Card was not defined for the operating unit.</li>
  <li>The receipt method related information was provided for interface line with line type <> ''LINE''.</li>
  <li>If error is for lines being imported from Order Management: Profile option ''OM: Number of Days to Backdate Bank Account Creation'' is not set properly causing trx date to fall before bank account start date</li>
</ul>
<br><br>For more information on debugging the issue, read: [1058782.1] The supplied payment method must be defined and active for the bill-to customer or site', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1762', g_select || ' and msg.message_name = ''AR_RAXTRX-1762''',
'Currency used is not associated with the receipt method','RS',
'Your transaction currency must match one of the currencies which are associated with the receipt method. ',
'Check the currencies associated to the banks used by the receipt method and ensure the currency you are passing is valid.
<br><br>For more information, read: [217545.1] AutoInvoice Error: Your Transaction Currency Must Match One Of The Currencies Which Are Associated With The Payment Method', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1763', g_select || ' and msg.message_name = ''AR_RAXTRX-1763''',
'Missing bank account','RS',
'When the receipt method is of type Automatic, you must either supply a valid bank account or ensure that a primary bank account for the currency code of the transaction has been set up for the Bill To customer.<br>
<ul>
  <li>It could be a code issue, and you may need to apply patch(es) to resolve the error</li>
  <li>The Start date of the Receipt Method and the Bank attached to the Receipt Method must be earlier than the transaction date in AutoInvoice</li>
  <li>The Receipt Method may not have been  marked as Primary</li>
  <li>No bank account defined at the Customer Account Level or Bill To Site level </li>
  <li>Data corruption  </li>
</ul>',
'The solutions vary, depending on the root cause of the error.<br>
<ul>
  <li>Make sure that the Start date of the Receipt Method and the Bank attached to the Receipt Method is <em>earlier than</em> the Transaction Date in AutoInvoice Interface Lines table. </li>
  <li>Make sure that the Receipt Method is  marked as Primary</li>
  <li>Set up a Bank Account  at the Customer Account Level or Bill To Site level as per your business needs </li>
  <li>If none of the above steps help resolve the issue, log a Service Request to get a confirmation on Data corruption and a proper data fix script</li>
</ul><br><br>For more information, read: [1072672.1] AutoInvoice Error: When the receipt method is of type Automatic, you must either supply a valid bank account or ensure that a primary bank account for the currency code of the transaction has been set', ' ','FAILURE', 'E',   'RS',   'Y' );

/* no longer in code, and not in FND_NEW_MESSAGES

add_signature('AR_RAXTRX-1631', g_select || ' and msg.message_name = ''AR_RAXTRX-1631''','Manual Receipt Method cannot be associated for a transaction if the Payment Transaction Extension id is provided.
','RS','','<p>Follow these steps to overcome this error:</p>
<ol>
  <li>Verify if the Receipt method information you supplied is of Manual type.</li>
  <li> If the Receipt Method is Manual, you should check if this is the actual receipt method you want to use.</li>
  <li> You can change the receipt method information on the Interface Lines to a receipt method of type Automatic.</li>
  <li> Alternatively You can remove the receipt method information from the Interface Lines and make sure that you have the setup such that there is a Receipt method defined as Primary on the Customer Account or Site level.</li>
</ol>
', ' ','FAILURE', 'E',   'RS',   'Y' );
*/


add_signature('AR_RAXTRX-1716', g_select || ' and msg.message_name = ''AR_RAXTRX-1716''','You cannot supply payment terms for your credit memo transaction','RS',
'You are interfacing a transaction with Type = Credit Memo and you are providing TERM_ID or TERM_NAME.',
'When interfacing a credit memo, you should not provide a value in RA_INTERFACE_LINES.TERM_ID or TERM_NAME because credit memos do not expect payment.<br><br>
Check whether you incorrectly provided a value in either of these fields.<br>
<br>
If this field was populated incorrectly, you can run an update statement like the following to fix incorrect data, you may also change the where condition to use the INTERFACE_LINE_ATTRIBUTE* fields to identify the specific row you want to update:</p>
<blockquote>
    Update RA_INTERFACE_LINES_ALL<br>
    Set TERM_ID = null<br>
    Where interface_line_id = &enter_interface_line_id;
</blockquote>
Alternatively, you can use the Interface Lines form to fix the value in this field, see instructions provided below.
<blockquote>
  <b>Responsibility:</b> Receivables Manager<br>
  <b>Navigation:</b> Control > Autoinvoice > Interface Lines<br>
  <ul>
  <li>Query all lines in the interface tables getting the reported validation error</li>
  <li>Place cursor in the field Line Type, go to Menubar > Folder > Show Field</li>
  <li>Select the column Term Id and/ or Term Name and NULL out the value for all affected rows</li>
  </ul>
</blockquote>
<br><br>For more information, read: [1174094.1] AutoInvoice Error: You cannot supply payment terms for your credit memo transaction', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1722', g_select || ' and msg.message_name = ''AR_RAXTRX-1722''','You must supply payment terms for your non-credit transaction','RS','Payment term related information should be populated for transactions except for Credit Memos',
'If you are interfacing a non-credit memo transaction, ensure you provide a payment term. 
<br><br>For more information, read: [1171284.1] AutoInvoice Error: You Must Supply Payment Terms For Your Non-credit Transaction', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1638', g_select || ' and msg.message_name = ''C-1638''','Invalid payment terms name (TERM_NAME)','RS','Invalid payment terms name (TERM_NAME).',
'Check your setup:<br>
<b>Navigation:</b> Setup > Transactions > Sources<br>
Go to the Accounting Information tab, and review you settings for Payment terms: Id or Value.<br>
Then ensure you populate either TERM_ID or TERM_NAME.<br>
Then ensure the value provided exists in RA_TERMS.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1639', g_select || ' and msg.message_name = ''C-1639''','Invalid payment terms id (TERM_ID)','RS','Invalid payment terms id (TERM_ID).',
'Check your setup:<br>
<b>Navigation:</b> Setup > Transactions > Sources<br>
Go to the Accounting Information tab, and review you settings for Payment terms: Id or Value.<br>
Then ensure you populate either TERM_ID or TERM_NAME.<br>
Then ensure the value provided exists in RA_TERMS.
<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1714', g_select || ' and msg.message_name = ''AR_RAXTRX-1714''',
'Incorrect Invoice number','RS','Incorrect Invoice number',
'Verify your configuration of the Transaction Source. It should match the data being imported.
<ul>
  <li>If you have Invoice Numbering Method set to Manual on your Transaction Source then you must populate the TRX_NUMBER field in the Interface Lines table.   </li>
  <li>If you have Invoice Numbering Method set to Automatic, then TRX_NUMBER must be null so that  Autoinvoice generates and populates the transaction number automatically.</li>
</ul>
<br><br>For more information, read: [277086.1] You must supply an invoice number when your batch source indicates manual invoice numbering; otherwise you must leave invoice number blank.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1743', g_select || ' and msg.message_name = ''AR_RAXTRX-1743''','Duplicate document number','RS',
'This error is raised when there exists a duplicate document number under a different request id, check the value in RA_INTERFACE_LINES_ALL.DOCUMENT_NUMBER.',
'Check that the document number you are passing does not yet exist in RA_INTERFACE_LINES_ALL.DOCUMENT_NUMBER or in RA_CUSTOMER_TRX.DOCUMENT_NUMBER. The value you are passing has to be unique.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1744', g_select || ' and msg.message_name = ''AR_RAXTRX-1744''',
'Missing document number','RS','You must enter a document number',
'You need to provide a value in RA_INTERFACE_LINES_ALL.DOCUMENT_NUMBER. <br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1757', g_select || ' and msg.message_name = ''AR_RAXTRX-1757''',
'Automatic document sequence is missing for this document category and date','RS',
'The document sequencing feature is enabled, but no ''Automatic'' document sequence exists within Oracle Receivables for this document category and date.',
'The System Profile Option: Sequential Numbering is set to Always Used, but there is no Automatic Sequence defined. <br><br>For more information, read: [1086565.1] How To Setup Document Sequences In Receivables', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1742', g_select || ' and msg.message_name = ''AR_RAXTRX-1742''','Duplicate invoice number','RS',
'This is generally caused due to improper Grouping Rules. The Mandatory Grouping Attributes are not consistent for single transaction with multiple rows in the Interface Lines table.
  Therefore, Autoinvoice attempts to create multiple transactions using the same TRX_NUMBER value in the
   Interface Lines table, resulting in duplicate invoice number validation error. The system will not allow duplicate transaction numbers within the same organization for the same batch source.',
'<ol>
  <li>If you have supplied the transaction number in the Interface Lines table, and it is not unique, then you can correct the TRX_NUMBER so that it is a unique value for the batch source.  Note that the TRX_NUMBER should be unique not only in the Interface Lines table, but also it should NOT be already existing in the RA_CUSTOMER_TRX_ALL.TRX_NUMBER.<br>
  For more on invoice numbering, refer to [1224285.1] How Invoice Numbers are Assigned in Receivables.</li>
  <li> If your grouping rules are defined such that records having different (more than one) TRX_NUMBER are forming a transaction, then make sure that all mandatory grouping attribute columns are consistent for each line for a single transaction in the RA_INTERFACE_LINES_ALL table. </li>
</ol>
<br><br>For more information, read: [130377.1] AutoInvoice Error: APP-11948 Duplicate invoice number', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1802', g_select || ' and msg.message_name = ''AR_RAXTRX-1802''','The tax line of the credit memo does not have a link to the invoice','RS',
'The credit memo''s tax line is not properly linked to the invoice''s tax line.',
'For more information, read: [1286966.1] AutoInvoice Error: The tax line of the credit memo does not have a link to the invoice.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1654',
g_select || ' and msg.message_name = ''AR_RAXTRX-1654''',
'Invalid tax exempt flag (TAX_EXEMPT_FLAG)',
'RS',
'Invalid tax exempt flag',
'If the profile option Tax: Allow Override = No, then TAX_EXEMPT_FLAG = S is the only valid value.<br> 
For more information, read: [1086586.1] AutoInvoice Error: Invalid tax exempt flag (TAX_EXEMPT_FLAG)', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1655',
g_select || ' and msg.message_name = ''AR_RAXTRX-1655''',
'Invalid tax exempt reason code (TAX_EXEMPT_REASON_CODE)',
'RS',
'Ensure that the value you are passing for TAX_EXEMPT_REASON_CODE exists in FND_LOOKUP_VALUES where lookup_type = ZX_EXEMPTION_REASON_CODE. If despite verifying this you get the error, check that you have the patch referenced in the note below.',
'For more information, read: [1374624.1] AutoInvoice Error: Invalid Tax Exempt Reason Code', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1656',
g_select || ' and msg.message_name = ''AR_RAXTRX-1656''',
'Invalid tax exempt reason code meaning (TAX_EXEMPT_REASON_CODE_MEANING)',
'RS',
'The value in TAX_EXEMPT_REASON_CODE_MEANING must exist in FND_LOOKUP_VALUES.MEANING for LOOKUP_TYPE = TAX_REASON.',
'<ul><li>If importing a credit memo, TAX_EXEMPT_REASON_CODE_MEANING should be null</li>
<li>If importing an invoice and your transaction source setup for Memo Reason = Value, then for interface records with LINE_TYPE = LINE and TAX_EXEMPT_FLAG = E, 
you need to pass a valid reason for the exemption. </li>
</ul><br><br>
For more information, read: [1195997.1] Description and Usage of Fields in RA_INTERFACE_LINES Table', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX-1657',
g_select || ' and msg.message_name = ''AR_RAXTRX-1657''',
'Invalid tax exempt flag (TAX_EXEMPT_FLAG)','RS',
'Incorrect tax exempt flag. If the system option Allow Exemptions = No then valid values are S or R, otherwise the valid values are S, R or E',
'For more information, read: [1086586.1] AutoInvoice Error: Invalid tax exempt flag (TAX_EXEMPT_FLAG)', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1658', g_select || ' and msg.message_name = ''AR_RAXTRX-1658''',
'You must supply a tax exempt reason for tax exempt lines','RS','You must supply a tax exempt reason for tax-exempt lines.',
'For more information, read line #4 in <br>[1086586.1] AutoInvoice Error: Invalid tax exempt flag (TAX_EXEMPT_FLAG)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1659', g_select || ' and msg.message_name = ''AR_RAXTRX-1659''','Tax code must be active, adhoc, and of type VAT or SALES TAX','RS','Incorrect TAX setup',
'For more information, read: [405051.1] 11i Autoinvoice Exception: Tax code must be active, adhoc, and of type VAT or SALES TAX', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1706', g_select || ' and msg.message_name = ''AR_RAXTRX-1706''',
'Invalid tax code (TAX_CODE)','RS','Invalid tax code (TAX_CODE)','Verify the existence of the value you provided in AR_VAT_TAX.TAX_CODE.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1730', g_select || ' and msg.message_name = ''AR_RAXTRX-1730''','You must supply either tax amount or tax rate when passing tax lines','RS',
'You are passing TAX lines manually to AutoInvoice, and you have incorrectly populated both the tax amount as well as tax rate.','You should only populate one of these fields and not both.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1826', g_select || ' and msg.message_name = ''AR_RAXTRX-1826''',
'No data found Exception from Tax Engine','RS','No Data Found exception occured in Tax Accounting routine during Adjustment/Application Accounting',
'To help pinpoint cause of error provide a tax debug log using review [417238.1] How to obtain debug logfile for R12 E-Business Tax', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_INVAL_EXEMPT',
g_select || ' and msg.message_name = ''AR_RAXTRX_INVAL_EXEMPT''',
'Tax exemption Issues',
'RS','You can enter E (exempt) in the tax_exempt_flag column only if a value exists in the tax_exempt_number column and the eBTax Product Options allow override of customer exemptions.','Check the value in TAX_EXEMPT_FLAG_COLUMN.<br>
<br>
Also verify the following setup: <br>
<strong>Responsibility:</strong> Tax Managers<br>
<strong>Navigation:</strong> Defaults and Controls > Application Tax Options<br>
<ol>
<li>Search for Application name = Receivables, Click Go</li>
<li>Select the appropriate Operating Unit from the retrieved list, and click on the Update icon.</li>
<li>In the Others section, ensure the check box <em>Allow Override and Entry of Customer Exemptions</em> is checked.</li>
<li>Apply<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error </li></ol>', 
' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_INV_INCL_FLAG_GRP', g_select || ' and msg.message_name = ''AR_RAXTRX_INV_INCL_FLAG_GRP''','You cannot set the amount includes tax flag when using a Tax Group','RS',
'You cannot set AMOUNT_INCLUDES_TAX_FLAG if using a Tax group.',
'Remove the value populated in the field AMOUNT_INCLUDES_TAX_FLAG.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_INV_INCL_FLAG_MAN', g_select || ' and msg.message_name = ''AR_RAXTRX_INV_INCL_FLAG_MAN''','You cannot import manual tax lines with tax inclusive amounts','RS','Importing Manual tax lines is not allowed if tax code is for Inclusive tax.','Either do not pass the Manual tax line (and thus allow the Tax Engine to calculate tax), or modify the tax code in the interface line you are passing for the tax, to some other tax code that is not for inclusive tax.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1706B', g_select || ' and msg.message_name = ''AR_RAXTRX-1706B''',
'Incomplete tax information provided','RS',
'For each manual tax line, you must include either a tax code, or a combination of the tax regime, tax, tax status, tax jurisdiction, and tax rate code.',
'For RA_INTERFACE_LINES_ALL.LINE_TYPE = ''TAX'', check that you have provided either a tax code, or a combination of the tax regime, tax, tax status, tax jurisdiction, and tax rate code.<br><br>For more information, read: [731149.1] R12 How To Bring In (and Troubleshoot) Manual Tax Lines Through Autoinvoice and E-Business Tax (EBTax)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_INV_INCL_FLAG_CODE', g_select || ' and msg.message_name = ''AR_RAXTRX_INV_INCL_FLAG_CODE''','The Tax Code does not allow override of the amount includes tax flag','RS','You cannot set AMOUNT_INCLUDES_TAX_FLAG to a value that contradicts the setup in AR_VAT_TAX.AMOUNT_INCLUDE_TAX_FLAG for the TAX_CODE used.','Check the setup of the field on the tax code, and make sure that you pass the same value in Interface table', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_EXEMPT_NOT_ALLOW', g_select || ' and msg.message_name = ''AR_RAXTRX_EXEMPT_NOT_ALLOW''','You cannot provide a tax_exempt_number for a non-exempt line','RS','Incorrect TAX setup','Refer to line#4 in Knowledge Article <br>[1086586.1] AutoInvoice Error: Invalid tax exempt flag (TAX_EXEMPT_FLAG)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1647', g_select || ' and msg.message_name = ''C-1647''','Invalid line type (LINE_TYPE)','RS','You have populated LINE_TYPE with an invalid value.','The valid values for LINE_TYPE are: LINE, TAX, FREIGHT, CHARGES. Please ensure that you have used one of these values.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1820', g_select || ' and msg.message_name = ''AR_RAXTRX-1820''','Please do not supply a GL date when the invoicing rule is Bill in Arrears','RS','Please do not supply a GL date when the invoicing rule is Bill in Arrears.','If INVOICING_RULE_ID = -3 you should not provide a GL_DATE.<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_RULE_END_DATE_VAL', g_select || ' and msg.message_name = ''AR_RAXTRX_RULE_END_DATE_VAL''','A rule end date is required when using the Daily Revenue Rate rule','RS','A rule end date is required when using the Daily Revenue Rate rule.','  When using an Accounting rule associated with Daily Revenue Rate, you need to provide a value in RULE_END_DATE<br><br>For more information, read: [1138254.1] Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_RULE_START_DT_NULL', g_select || ' and msg.message_name = ''AR_RAXTRX_RULE_START_DT_NULL''','A rule start date is required when using the Daily Revenue Rate rule','RS','  A rule start date is required when using the Daily Revenue Rate rule.','When using an Accounting rule associated with Daily Revenue Rate, you need to provide a value in RULE_START_DATE<br><br>For more information, read: [201241.1] Troubleshooting AutoInvoice Date Derivation: GL Date, Invoice Date, Due Date, Ship Date, Billing Date, Rule Date', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1727', g_select || ' and msg.message_name = ''AR_RAXTRX-1727''','Please supply both an invoicing rule and an accounting rule for this invoice','RS',
'This error is encountered if either the Invoicing Rule or the Accounting Rule is not specified. AutoInvoice expects both fields to be populated or both fields to be null. 
You have populated only one of the two values.',
'Fix the issue as follows:<br>
<ul>
  <li>You have populated only one of the two fields: either Invoicing Rule or the Accounting Rule, whereas you are expected to provide both.</li>
  <li><b>Navigation:</b> Setup > Transactions > Sources</li>
  <li>Go to Accounting Information tab, review Invoicing Rule and Accounting Rule settings: Value or ID or None.</li>
  <li>Then check the data in RA_INTERFACE_LINES_ALL to ensure that you populated the right fields with proper data. It may have happened that your Transaction Source setup indicates you would provide 
  a value but you actually populated ID and AutoInvoice did not recognize the value you passed.</li>
  <li>Correct the data or the setup, and re-interface the records. </li>
</ul>
<br><br>For more information, read: [1116934.1]  How To Setup And Troubleshoot Invoicing Rules and Accounting Rules (under section 5.j)', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1644', g_select || ' and msg.message_name = ''C-1644''','Invalid accounting rule name (ACCOUNTING_RULE_NAME)','RS',
'Invalid accounting rule name (ACCOUNTING_RULE_NAME)',
'Start with checking the setup:<br>
<b>Navigation:</b> Setup > Transactions > Sources<br>
Go to the Accounting Information tab, review setting for Accounting Rule: Id or Value.<br>
Provide the required data in your interface record.<br>
The value provided must exist in RA_RULES.NAME for TYPE = I.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1645', g_select || ' and msg.message_name = ''C-1645''',
'Invalid accounting rule id (ACCOUNTING_RULE_ID)','RS','Invalid accounting rule id (ACCOUNTING_RULE_ID)',
'Check your setup: <br><br>
<b>Navigation:</b> Setup > Transactions > Sources<br>
Go to the Accounting Information tab, and review setting for Accounting Rule, for whether you have set Id or Value. 
You should populate the ID or the Value according to the setup. <br>
Next, check that the value provided exists in RA_RULES.RULE_ID for Type = A.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1636', g_select || ' and msg.message_name = ''C-1636''','Invalid invoicing rule name (INVOICING_RULE_NAME)','RS',
'Invalid invoicing rule name (INVOICING_RULE_NAME)',
'Check your setup: <br><br>
<b>Navigation:</b> Setup > Transactions > Sources<br>
Go to the Accounting Information tab, and review setting for Invoicing Rule, for whether you have set Id or Value. 
You should populate the ID or the Value according to the setup. <br>
Next, check that the value provided exists in RA_RULES.NAME for Type = I.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1637', g_select || ' and msg.message_name = ''C-1637''',
'Invalid invoicing rule id (INVOICING_RULE_ID)','RS','Invalid invoicing rule id (INVOICING_RULE_ID)',
'Check your setup: <br><br>
<b>Navigation:</b> Setup > Transactions > Sources<br>
Go to the Accounting Information tab, and review setting for Invoicing Rule, for whether you have set Id or Value. 
You should populate the ID or the Value according to the setup. <br>
Next, check that the value provided exists in RA_RULES.RULE_ID for Type = I.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX-1619',
g_select || ' and msg.message_name = ''AR_RAXTRX-1619''',
'Unit of measure is not allowed for line type CHARGES',
'RS',
'This line has LINE_TYPE = CHARGES but a value of Unit of Measure is not allowed for lines of this type.',
'Ensure there is a null value in RA_INTERFACE_LINES_ALL.UOM_CODE and RA_INTERFACE_LINES_ALL.UOM_NAME. You can update this in the Interface Lines form.',
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1721', g_select || ' and msg.message_name = ''AR_RAXTRX-1721''',
'You must supply unit of measure for transactions with items','RS',
'You have not supplied unit of measure for transactions with items.',
'It is mandatory to pass a value for Unit of Measure, if the transaction has items.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1640', g_select || ' and msg.message_name = ''C-1640''','Invalid unit of measure name (UOM_NAME)','RS',
'Invalid unit of measure name (UOM_NAME).',
'Start with checking the setup:<br>
<ul>
<li><b>Navigation:</b>Setup > Transactions > Source</li>
<li>Go to the Other Information tab, and review the settings for Unit of Measure: Id or Value</li>
<li>Check in RA_INTERFACE_LINES_ALL that you provided the expected value as per your setup</li>
<li>Next, check that the value provided exists in MTL_UNITS_OF_MEASURE.UNIT_OF_MEASURE</li>
</ul>', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('C-1641', g_select || ' and msg.message_name = ''C-1641''','Invalid unit of measure code (UOM_CODE)','RS','Invalid unit of measure code (UOM_CODE)',
'Start with checking the setup:<br>
<ul>
<li><b>Navigation:</b>Setup > Transactions > Source</li>
<li>Go to the Other Information tab, and review the settings for Unit of Measure: Id or Value</li>
<li>Check in RA_INTERFACE_LINES_ALL that you provided the expected value  as per your setup</li>
<li>Next, check that the value provided exists in MTL_UNITS_OF_MEASURE.UOM_CODE</li>
</ul>', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1813', g_select || ' and msg.message_name = ''AR_RAXTRX-1813''',
'Importing bills not allowed when consolidated billing is enabled','RS',
'Consolidated billing is enabled for this customer or bill-to site, therefore you cannot import bills.',
'You can only import a value in RA_INTERFACE_LINES_ALL.CONS_BILLING_NUMBER if the Bill Type is Imported.
<br><br>For more information, read: [761180.1] Consolidated billing is enabled for this customer or bill-to site, therefore you cannot import bills.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1819', g_select || ' and msg.message_name = ''AR_RAXTRX-1819''',
'Invoices within this consolidated bill have errors ',
'RS',
'Please review all invoices that share this invoice''s consolidated billing number and correct any errors before resubmitting AutoInvoice.',
'There are other interface records that have already been tagged with errors that have the same value in CONS_BILLING_NUMBER as this row, 
you are advised to review and correct these records prior to re-running AutoInvoice.
<br><br>For more information, read: [761180.1] Error Please review all invoices that share this invoice''s consolidated billing number and correct any errors before resubmitting AutoInvoice.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1814', g_select || ' and msg.message_name = ''AR_RAXTRX-1814''','Customer or Bill-to must be enabled to import billing number','RS','Customer or Bill-to must be enabled to import billing number.','Ensure that the customer is consolidated billing (for Release 11.5) or balance forward billing enabled (for Release 12).<br><br>For more information, read: [761180.1] Customer or Bill-to must be enabled to import billing number.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1811', g_select || ' and msg.message_name = ''AR_RAXTRX-1811''',
'Billing Number already exists','RS',
'The Imported Billing Number you entered already exists in the system. Please enter a unique Imported Billing Number.',
'Check the value in RA_INTERFACE_LINES_ALL.CONS_BILLING_NUMBER and ensure that it does not yet exist in AR_CONS_INV_ALL or another record in the interface table.
<br><br>For more information, read: [761180.1] The Imported Billing Number you entered already exists in the system. Please enter a unique Imported Billing Number.', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_BFB_TERM_BILL_LEVEL_WRONG',
g_select || ' and msg.message_name = ''AR_BFB_TERM_BILL_LEVEL_WRONG''',
'Balance forward billing is enabled for this customer at the account level, but is either disabled or not defined at site level.',
'RS','This is due to a missing setup step.<br><br>
When you define your Account level profile and indicate that Bill Level = Account, you are expecting this setting to cascade to all the sites under that account. However, the code still expects a site level profile to be associated with each site, because this is where it is going to pick up the Balance Forawrd Billing payment term from.',
'First, check to see if the proper Payment Term was used, by  following these steps:<br>
<strong>Responsibility</strong>: Receivables Manager<br>
<strong>Navigation:</strong> Control > Autoinvoice > Interface Lines
<ol>
  <li>Query the problem interface line </li>
  <li>Place cursor in any right-hand column </li>
  <li>Go to Folder, Show Field, select Term ID </li>
  <li>You can modify value to another payment term id.</li>
</ol>
If it is the wrong setup, read: [1053006.1] Error "Balance forward billing is enabled for this customer but disabled at the account site level" is raised when creating transactions for Balance Forward enabled customers', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX_ZERO_VS_COMMIT', g_select || ' and msg.message_name = ''AR_RAXTRX_ZERO_VS_COMMIT''',
'Invoice amount to commitment is zero','RS',
'You cannot import this invoice because the invoice amount that is allocated to the specified commitment is zero.',
'Check the AMOUNT associated with the invoice being drawn against a commitment and ensure it is more than zero.
<br><br>For more information, read: [1138254.1]  Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1764', g_select || ' and msg.message_name = ''AR_RAXTRX-1764''',
'Invalid GL date of invoice against a commitment','RS',
'The GL date of your invoice against a commitment cannot be prior to the GL date of the commitment itself.',
'Check the value in RA_INTERFACE_LINES_ALL.GL_DATE and cross-check against the Commitment''s GL_DATE as referred to by the values in REFERENCE_* fields and ensure the Invoice''s GL_DATE comes on or after the GL_DATE of the commitment.
<br><br>For more information, read: [1138254.1]  Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1765', g_select || ' and msg.message_name = ''AR_RAXTRX-1765''',
'Invalid transaction date of invoice invoice against a commitment','RS',
'The transaction date of an invoice drawn against a commitment cannot be prior to the transaction date of the commitment.',
'Check the value in RA_INTERFACE_LINES_ALL.TRX_DATE and cross-check against the Commitment''s TRX_DATE as referred to by the values in REFERENCE_* fields and ensure the Invoice''s TRX_DATE 
comes on or after the TRX_DATE of the commitment.
<br><br>For more information, read: [1138254.1]  Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_OPEN_DEPOSIT',
g_select || ' and msg.message_name = ''AR_RAXTRX_OPEN_DEPOSIT''',
'Deposit or Guarantee is not complete',
'RS',
'Please complete the deposit or guarantee for this line and run the AutoInvoice process again.',
'Check that COMPLETE_FLAG = Y for the commitment/deposit referenced by the values in REFERENCE_*.
<br><br>For more information, read: [1138254.1]  Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error ',
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature('AR_RAXTRX-1697', g_select || ' and msg.message_name = ''AR_RAXTRX-1697''',
'An invoice against a commitment cannot have a negative total amount','RS',
'An invoice against a commitment cannot have a negative total amount.',
'You cannot interface an invoice with a negative amount that draws from a commitment. You can either null out the REFERENCE* fields so that it does not draw from a commitment, or you need to fix the amount so that it is not negative.
<br><br>For more information, read: [1138254.1]  Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1696', g_select || ' and msg.message_name = ''AR_RAXTRX-1696''',
'Invalid positive credit memo against a commitment','RS',
'You cannot interface a credit memo with a positive amount and use it to credit an invoice which is against a commitment.',
'AutoInvoice will not allow you to "positive-credit" an invoice drawn against a commitment which effectively makes it balance bigger.
<br><br>For more information, read: [1138254.1]  Listing of AutoInvoice Error Messages and Troubleshooting Tips to Resolve each Error ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1817', g_select || ' and msg.message_name = ''AR_RAXTRX-1817''',
'Non-invoice has payment set ID','RS','Only invoices can be associated with a payment set ID. Please remove the ID associated with this transaction. ','The transaction type associated to the record for which you have provided a PAYMENT_SET_ID value must have type = INV<br><br>For more information, read: [1138254.1] Only invoices can be associated with a payment set ID. Please remove the ID associated with this transaction. ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature('AR_RAXTRX-1816', g_select || ' and msg.message_name = ''AR_RAXTRX-1816''',
'Invalid payment set ID','RS','The payment set ID is invalid because it was not generated by the Receipt API ','The value provided in RA_INTERFACE_LINES_ALL.PAYMENT_SET_ID must exist in AR_RECEIVABLE_APPLICATIONS_ALL.PAYMENT_SET_ID<br><br>For more information, read: [1138254.1] Error: The payment set ID is invalid because it was not generated by the Receipt API ', ' ','FAILURE', 'E',   'RS',   'Y' );

add_signature(
'AR_RAXTRX_PROFILE_ERR',
'SELECT substr(po.user_profile_option_name,1,50) Profile_Name,
              DECODE (TO_CHAR (pov.level_id), ''10001'', ''SITE'', ''10002'', ''APP'', 10003, ''RESP'') Level_Setting,
              pov.profile_option_value Profile_Value
       FROM fnd_profile_options_vl po,
            fnd_profile_option_values pov
       WHERE pov.application_id = po.application_id
       AND   pov.profile_option_id = po.profile_option_id
       AND   po.user_profile_option_name = ''Sequential Numbering'' 
       AND   ((pov.level_id = ''10001'') OR
              (pov.level_id = ''10002'' AND pov.level_value = 222) OR
              (pov.level_id = ''10003'' AND pov.level_value = ##$$RESP_ID$$##))
       AND exists (select ''X''
                   from ra_interface_errors intferr, fnd_new_messages msg 
                   where msg.message_text = intferr.message_text
                   and message_name = ''AR_RAXTRX_PROFILE_ERR''
                   and msg.language_code = ''US'')
UNION ALL        
SELECT substr(po.user_profile_option_name,1,50) Profile_Name,
              DECODE (TO_CHAR (pov.level_id), ''10001'', ''SITE'', ''10002'', ''APP'', 10003, ''RESP'') Level_Setting,
              pov.profile_option_value Profile_Value
       FROM fnd_profile_options_vl po,
            fnd_profile_option_values pov
       WHERE pov.application_id = po.application_id
       AND   pov.profile_option_id = po.profile_option_id
       AND   po.user_profile_option_name = ''AR: Use Invoice Accounting For Credit Memos'' 
       AND   ((pov.level_id = ''10001'') OR
              (pov.level_id = ''10002'' AND pov.level_value = 222) OR
              (pov.level_id = ''10003'' AND pov.level_value = ##$$RESP_ID$$##))
       AND exists (select ''X''
                   from ra_interface_errors intferr, fnd_new_messages msg 
                   where msg.message_text = intferr.message_text
                   and message_name = ''AR_RAXTRX_PROFILE_ERR''
                   and msg.language_code = ''US'')',
'Profile options not defined',
'RS',
'System Profile options are not setup and a value is required. Please check if <b>ANY</b> of the following conditions exist:<br>
<ul>
<li>For Profile_Name = ''Sequential Numbering'', there is <b>no row</b> where Profile_Value = ''P'' or ''A'' </li>
<li>For Profile Name = ''AR: Use Invoice Accounting For Credit Memos'', there is <b>no row</b> where Profile_Value = ''Y''</li>
</ul>
If any of the above conditions are identifies, you need to check the Profile Option settings, because AutoInvoice requires ''Sequential Numbering'' to be either Partially Used or Always Used, and ''AR: Use Invoice Accounting For Credit Memos'' to be Yes.',
'Verify System Options setup:<br>
<b>Responsibility:</b> Receivables Manager<br />
<b>Navigation:</b> Setup > System > System Options<br>
<ul><li>Query for Profile Name = Sequential Numbering, and check setup</li>
<li>Query for Profile Name = AR: Use Invoice Accounting For Credit Memos, and check setup</li></ul>', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

add_signature(
'AR_RAXTRX_PROFILE_WARN',
'select ''Max Memory (in bytes)'' Profile_Name,
        ''System Parameter'' Level_Setting,
        to_char(nvl(ai_max_memory_in_bytes,0)) Profile_Value
    FROM AR_SYSTEM_PARAMETERS
    WHERE nvl(ai_max_memory_in_bytes,0) < 3000000
    and exists (select ''X''
                   from ra_interface_errors intferr, fnd_new_messages msg 
                   where msg.message_text = intferr.message_text
                   and message_name = ''AR_RAXTRX_PROFILE_WARN''
                   and msg.language_code = ''US'')
 UNION
 SELECT substr(po.user_profile_option_name,1,50) Profile_Name,
        DECODE (TO_CHAR (pov.level_id), ''10001'', ''SITE'', ''10002'', ''APP'', 10003, ''RESP'') Level_Setting,
        pov.profile_option_value Profile_Value
       FROM fnd_profile_options_vl po,
            fnd_profile_option_values pov
       WHERE pov.application_id = po.application_id
       AND   pov.profile_option_id = po.profile_option_id
       AND   po.user_profile_option_name in (''AR:Maximum lines per AutoInvoice worker'',''AR: Use Parallel Hints'')
       AND   ((pov.level_id = ''10001'') OR
              (pov.level_id = ''10002'' AND pov.level_value = 222) OR
              (pov.level_id = ''10003'' AND pov.level_value = ##$$RESP_ID$$##))
       AND exists (select ''X''
                   from ra_interface_errors intferr, fnd_new_messages msg 
                   where msg.message_text = intferr.message_text
                   and message_name = ''AR_RAXTRX_PROFILE_WARN''
                   and msg.language_code = ''US'')',                        
'You have not assigned a value for profile options that impact AutoInvoice performance. The default value will be used.',
'RS',
'Profile options that impact AutoInvoice performance are not set, default values will be used.<br>',
'Verify System Options setup:<br>
<ol><li><b>Responsibility:</b> Receivables<br>
<b>Navigation:</b> Setup > System > System Options</li>
<li>Check the values for: Max Memory, suggested value is 3000000.</li></il><br>
Verify Profile Options setup:<br>
<ol><li><b>Responsibility:</b> Receivables Manager<br>
<b>Navigation:</b> Setup > System > System Options</li>
<li>Query for Profile Name = AR: Maximum lines per AutoInvoice worker, and check setup</li>
<li>Query for Profile Name = AR: Use Parallel Hints, and check setup</li></ol><br>
For more information, read: [1083467.1] How To Setup AutoInvoice For Optimal Performance', 
' ',
'FAILURE', 
'W',   
'RS',   
'Y' );

add_signature(
'TAX_ISSUES',
g_tax,
'Tax Errors in Interface Table',
'RS',
'There are tax-related errors for your interface data',
'The one-stop resource for all your TAX issues is the Information Center:<br><br>
 [1336674.2] Information Center: Oracle E-Business Tax Release 12<br><br>
 To know about the basic functionality and setup, access documentation, and How-To documents, use the Overview section of the Information Center.<br><br>
 If you are done with the setup and are encountering an issue from TAX engine, then refer to Troubleshoot tab.', 
' ',
'FAILURE', 
'E',   
'RS',   
'Y' );

--------------------Performance checks ----------------------------
add_signature('SYS_MEMORY','SELECT ai_max_memory_in_bytes
FROM AR_SYSTEM_PARAMETERS
WHERE ai_max_memory_in_bytes < 3145728 AND ROWNUM < 2 ','System Options Setup: Maximum Memory','RS','This is the maximum amount of memory used for AutoInvoice validation. If the Max Memory allocated for AutoInvoice is set to a lower value, and you try to interface high volume of interface data, you will encounter degraded AutoInvoice performance.<br><br>
System Options should be set correctly for deriving the best performance out of AutoInvoice program. 
<br><br> For more information, read: [1083467.1] How To Setup AutoInvoice For Optimal Performance','The recommended Max Memory setting for AutoInvoice is 3MB or higher, if the machine has enough memory.', ' ','FAILURE',      'W',   'RS',   'Y' );

add_signature('SYS_PURGE','SELECT ai_purge_interface_tables_flag
FROM AR_SYSTEM_PARAMETERS
WHERE ai_purge_interface_tables_flag <> ''Y''  AND ROWNUM < 2 ','System Options Setup: Purge Interface Tables','RS','The interface tables are not meant to store data beyond processing transactions in AutoInvoice. If you set this option to No, AutoInvoice will not delete the interfaced records even after processing them successfully. This will increase the volume of interface tables, and decrease the processing time of AutoInvoice program.<br><br>
System Options should be set correctly for deriving the best performance out of AutoInvoice program. 
<br><br>For more information, read: [1083467.1] How To Setup AutoInvoice For Optimal Performance','Set the option to Yes. This setting only purges data that has been processed.  Data resulting in error can still be corrected and re-processed.', ' ','FAILURE',      'W',   'RS',   'Y' );

add_signature('SYS_MESSAGE_LEVEL','SELECT AI_LOG_FILE_MESSAGE_LEVEL
FROM ar_system_parameters
WHERE AI_LOG_FILE_MESSAGE_LEVEL > 0  AND ROWNUM < 2 ','System Options Setup: AutoInvoice Log File Message Level','RS','When the Log File Message Level is set to a higher value, more detailed debug messages get logged in the log file. This add to the processing time, thus hampering the performance.<br><br>
System Options should be set correctly for deriving the best performance out of AutoInvoice program.
<br><br>For more information, read: [1083467.1] How To Setup AutoInvoice For Optimal Performance','Setting the log file message level to 0 provides the least detailed debug messages but still includes errors and warning messages.  After you have completed the setup of AutoInvoice, you should need only minimal messages in the log file.', ' ','FAILURE',      'W',   'RS',   'Y' );

add_signature('SYS_MAX_LINES','SELECT OPT.PROFILE_OPTION_ID,
  ''AR:Maximum lines per AutoInvoice worker'' profile_option_name,
  CASE PROFILE_OPTION_VALUE
    WHEN ''N''
    THEN ''no''
    WHEN ''Y''
    THEN ''Yes''
    ELSE profile_option_value
  END profile_option_value
FROM fnd_profile_options opt,
  FND_PROFILE_OPTION_VALUES val
WHERE OPT.PROFILE_OPTION_ID = VAL.PROFILE_OPTION_ID
AND opt.profile_option_name = ''AR_MAX_LINES_PER_AI_WORKER''
AND OPT.APPLICATION_ID      = 222
AND val.level_id            = 10001','Profile Options Setup: AR:Maximum lines per AutoInvoice worker','RS','The lines per worker setting is a guideline and not a hard and fast rule.<br><br>
Profile Options should be set correctly for deriving the best performance out of AutoInvoice program. 
<br><br>For more information, read: [1083467.1] How To Setup AutoInvoice For Optimal Performance','This profile option should be set if you are running AutoInvoice Master with multiple workers and your transactions typically have a large number of lines. Setting this profile option will help AutoInvoice determine the maximum number of lines to assign to an AutoInvoice worker. <BR><BR> For example, if you typically process invoices with approximately 10,000 lines per invoice, then set the value = 10,000. If you are unsure, or if the number of lines per transaction are low or varied, you should not enter a value for this profile option.', ' ','FAILURE',      'W',   'RS',   'Y' );

add_signature('SYS_GATHER_STATS','SELECT OPT.PROFILE_OPTION_ID,
  ''AR: AutoInvoice Gather Statistics'' profile_option_name,
  CASE PROFILE_OPTION_VALUE
    WHEN ''N''
    THEN ''no''
    WHEN ''Y''
    THEN ''Yes''
    ELSE profile_option_value
  END profile_option_value
FROM fnd_profile_options opt,
  FND_PROFILE_OPTION_VALUES val
WHERE OPT.PROFILE_OPTION_ID = VAL.PROFILE_OPTION_ID
AND opt.profile_option_name = ''AR_GATHER_STATS''
AND OPT.APPLICATION_ID      = 222
AND val.level_id            = 10001','Profile Options Setup: AR: AutoInvoice Gather Statistics','RS','This profile option determines if the AutoInvoice Master program analyzes and gathers information about the interface tables each time AutoInvoice is run. Analyzing tables ties up system resources.<br><br>If the value for this profile option is set to Yes, or is null, AutoInvoice analyzes the interface tables and gathers statistics.<br><br>If the value is set to No, AutoInvoice does not analyze the interface tables.<br><br>
Profile Options should be set correctly for deriving the best performance out of AutoInvoice program. 
<br><br>For more information, read: [1083467.1] How To Setup AutoInvoice For Optimal Performance','The recommended setting is Y (Yes) at the Site level. Setting this profile will gather statistics on the interface and appropriate application tables before running AutoInvoice.', ' ','FAILURE',      'W',   'RS',   'Y' );

add_signature(
'AI_INDEXES',
'SELECT table_name,
  interface_line_context,
  sequence_number,
  column_name,
  interface_line_attrib_col,
  NVL(index_exists, ''No'') index_exists
FROM
  (SELECT ''RA_INTERFACE_LINES_ALL'' table_name,
    descriptive_flex_context_code interface_line_context ,
    column_seq_num sequence_number,
    end_user_column_name column_name,
    application_column_name interface_line_attrib_col,
    (SELECT NVL(''Yes'', ''No'')
    FROM all_ind_columns
    WHERE table_name = ''RA_INTERFACE_LINES_ALL''
    AND column_name  = application_column_name
    ) index_exists
  FROM FND_DESCR_FLEX_COL_USAGE_VL
  WHERE application_id               = 222
  AND descriptive_flexfield_name     = ''RA_INTERFACE_LINES''
  AND descriptive_flex_context_code IN
    ( SELECT DISTINCT interface_line_context FROM ra_interface_lines_all
    )
  UNION ALL
  SELECT ''RA_CUSTOMER_TRX_ALL'' table_name,
    descriptive_flex_context_code,
    column_seq_num sequence_number,
    end_user_column_name column_name,
    application_column_name interface_line_attrib_col,
    (SELECT ''Yes''
    FROM all_ind_columns
    WHERE table_name = ''RA_CUSTOMER_TRX_ALL''
    AND column_name  = application_column_name
    ) index_exists
  FROM FND_DESCR_FLEX_COL_USAGE_VL
  WHERE application_id               = 222
  AND descriptive_flexfield_name     = ''RA_INTERFACE_LINES''
  AND descriptive_flex_context_code IN
    ( SELECT DISTINCT interface_line_context FROM ra_interface_lines_all
    )
  UNION ALL
  SELECT ''RA_CUSTOMER_TRX_LINES_ALL'' table_name,
    descriptive_flex_context_code,
    column_seq_num sequence_number,
    end_user_column_name column_name,
    application_column_name interface_line_attrib_col,
    (SELECT ''Yes''
    FROM all_ind_columns
    WHERE table_name = ''RA_CUSTOMER_TRX_LINES_ALL''
    AND column_name  = application_column_name
    ) index_exists
  FROM FND_DESCR_FLEX_COL_USAGE_VL
  WHERE application_id               = 222
  AND descriptive_flexfield_name     = ''RA_INTERFACE_LINES''
  AND descriptive_flex_context_code IN
    ( SELECT DISTINCT interface_line_context FROM ra_interface_lines_all
    )
  )
ORDER BY 1,2,3',
'Index on RA_INTERFACE_LINES Columns',
'RS',
'<p>You must define the Line Transaction Flexfield if you are implementing AutoInvoice.</p>',
'<p>Line Transaction Flexfields are unique for each record in the interface table and therefore can be used as record identifiers. For optimal performance of AutoInvoice, you should create  concatenated UNIQUE indexes, based on your Line Transaction Flexfield contexts definition. Please refer to this Knowledge Article to know more about this topic: </p>
<ul>
  <li> [1083467.1] How To Setup AutoInvoice For Optimal Performance</li>
</ul>
<p>It is recommended that the indexes  be created as UNIQUE indexes. But AutoInvoice does not validate or require a unique Line Transaction Flexfield. If you receive errors stating that the indexes cannot be created because of duplicate keys, then you should create non-unique indexes by removing the UNIQUE constraint from the CREATE INDEX statement. <strong>Unique indexes will provide better performance results</strong>.</p>
<p>Consider using <strong>NOLOGGING</strong> for these indexes if ARCHIVING is enabled on your database. NOLOGGING should reduce the amount of time to create the index and will save space in the redo log files. Indexes created using NOLOGGING are not archived. Therefore, you should perform a backup after you create the indexes.The DBAs are advised to review whether NOLOGGING is appropriate for your environment.</p>',
' ',
'FAILURE',
'W',
'RS',
'Y');



EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;





---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main (
    p_org_id          IN NUMBER,
    p_request_id      IN NUMBER DEFAULT 0,
    p_resp_id         IN NUMBER) IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
  
-- PSD #11
-- Title of analyzer output!! - do not add word 'analyzer' at the end as it is appended in code in PSD #5
-- So title will be what you define here for analyzer_title plus Analyzer Report
-- Example: If you assign 'AP Core' to analyzer_title, then title of output will be "AP Core Analyzer Report"
  analyzer_title := 'EBS Oracle Receivables AutoInvoice';

  l_step := '20';
  
 -- PSD #12
  validate_parameters(
      p_org_id,
      p_request_id,
      p_resp_id);

  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #13
 
  -- the following signatures are run regardless of whether request_id parameter is provided or not
  start_section('Proactive Recommendations');
     if g_apps_version = '12' then
        set_item_result(check_rec_patches);
     end if;
     set_item_result(run_stored_sig('INVALIDS'));
  end_section;
  
  start_section('AutoInvoice Performance');
     set_item_result(run_stored_sig('SYS_MEMORY'));
     set_item_result(run_stored_sig('SYS_PURGE'));
     set_item_result(run_stored_sig('SYS_MESSAGE_LEVEL'));
     set_item_result(run_stored_sig('SYS_MAX_LINES'));
     set_item_result(run_stored_sig('SYS_GATHER_STATS'));
     set_item_result(run_stored_sig('AI_INDEXES'));
  end_section;
  
  if g_apps_version = '12' then
     start_section('Orphan Records');
       set_item_result(run_stored_sig('ORPHAN_ERR'));
       set_item_result(run_stored_sig('ORPHAN_DIST'));
       set_item_result(run_stored_sig('ORPHAN_SALES'));
     end_section;
  end if;

  start_section('Profile/System Options');          
    set_item_result(run_stored_sig('AR_RAXTRX_PROFILE_ERR'));
    set_item_result(run_stored_sig('AR_RAXTRX_PROFILE_WARN'));
  end_section;  
  

  -- if request ID is provided only show the transactions created for that request ID
  if g_request_id <> 0 then
    start_section('Transactions successfully created by AutoInvoice');
       set_item_result(run_stored_sig('TRANS_REQID'));
    end_section;
  else
  -- if request ID is not provided, run all the validation checks

    start_section('Accounting Errors');
      set_item_result(run_stored_sig('AG'));
      set_item_result(run_stored_sig('AR_AUTOACC_COMPLETE_OFFSET'));
      set_item_result(run_stored_sig('AR_RAXTRX-1669'));
      set_item_result(run_stored_sig('AR_RAXTRX-1670'));
      set_item_result(run_stored_sig('AR_RAXTRX-1671'));
      set_item_result(run_stored_sig('AR_RAXTRX-1672'));
      set_item_result(run_stored_sig('AR_RAXTRX-1673'));
      set_item_result(run_stored_sig('AR_RAXTRX-1674'));
      set_item_result(run_stored_sig('AR_RAXTRX-1675'));
      set_item_result(run_stored_sig('AR_RAXTRX-1676'));
      set_item_result(run_stored_sig('AR_RAXTRX-1677'));
      set_item_result(run_stored_sig('AR_RAXTRX-1678'));
      set_item_result(run_stored_sig('AR_RAXTRX-1679'));
      set_item_result(run_stored_sig('AR_RAXTRX-1680'));
      set_item_result(run_stored_sig('AR_RAXTRX-1681'));
      set_item_result(run_stored_sig('1350'));
      set_item_result(run_stored_sig('1360'));
      set_item_result(run_stored_sig('1370'));
      set_item_result(run_stored_sig('AR_RAXTRX-1682'));
      set_item_result(run_stored_sig('AR_RAXTRX-1683'));
      set_item_result(run_stored_sig('AR_RAXTRX-1685'));
      set_item_result(run_stored_sig('AR_RAXTRX-1686'));
      set_item_result(run_stored_sig('AR_RAXTRX-1687'));
      set_item_result(run_stored_sig('AR_RAXTRX-1688'));
      set_item_result(run_stored_sig('AR_RAXTRX-1689'));
      set_item_result(run_stored_sig('AR_RAXTRX-1691'));
      set_item_result(run_stored_sig('AR_RAXTRX-1710'));
      set_item_result(run_stored_sig('AR_RAXTRX-1823'));
      set_item_result(run_stored_sig('AR_RAXTRX-1827'));
      set_item_result(run_stored_sig('AR_RAXTRX-1825'));
      set_item_result(run_stored_sig('AR_RAXTRX-1824'));
      set_item_result(run_stored_sig('AR_RAXTRX-1793'));
      set_item_result(run_stored_sig('AR_RAXTRX_BAD_ACC_CLASS'));
      set_item_result(run_stored_sig('AR_RAXTRX-1698'));
    end_section;

    start_section('Accounting Period Errors');
      set_item_result(run_stored_sig('AR_RAXTRX-1783'));
      set_item_result(run_stored_sig('AR_RAXTRX-1784'));
      set_item_result(run_stored_sig('AR_RAXTRX-1791'));
      set_item_result(run_stored_sig('AR_RAXTRX-1792'));
      set_item_result(run_stored_sig('AR_RAXTRX-1782'));
      set_item_result(run_stored_sig('AR_RAXTRX-1790'));
      set_item_result(run_stored_sig('C-1652'));
    end_section;
   
    start_section('Balance Forward Billing');          
      set_item_result(run_stored_sig('AR_RAXTRX-1813'));
      set_item_result(run_stored_sig('AR_RAXTRX-1819'));
      set_item_result(run_stored_sig('AR_RAXTRX-1814'));
      set_item_result(run_stored_sig('AR_RAXTRX-1811'));
      set_item_result(run_stored_sig('AR_BFB_TERM_BILL_LEVEL_WRONG'));
    end_section;  
      
    start_section('Credit Memo Errors');      
      set_item_result(run_stored_sig('AR_RAXTRX-1666'));
      set_item_result(run_stored_sig('AR_RAXTRX-1667'));
      set_item_result(run_stored_sig('AR_RAXTRX-1695'));
      set_item_result(run_stored_sig('C-1633'));
      set_item_result(run_stored_sig('AR_RAXTRX-1705'));
      set_item_result(run_stored_sig('AR_RAXTRX-1717'));
      set_item_result(run_stored_sig('AR_RAXTRX-1718'));
      set_item_result(run_stored_sig('AR_RAXTRX-1719'));
      set_item_result(run_stored_sig('AR_RAXTRX-1720'));
      set_item_result(run_stored_sig('C-1632'));
      set_item_result(run_stored_sig('AR_RAXTRX-1770'));
      set_item_result(run_stored_sig('AR_RAXTRX_CM_TAX_FLAG_ERR'));
      set_item_result(run_stored_sig('AR_RAXTRX-1773'));
      set_item_result(run_stored_sig('AR_RAXTRX-1774'));
      set_item_result(run_stored_sig('AR_RAXTRX-1775'));
      set_item_result(run_stored_sig('AR_RAXTRX_UNIT_OVERAPP'));
      set_item_result(run_stored_sig('AR_RAXTRX_LINE_OVERAPP'));
      set_item_result(run_stored_sig('AR_RAXTRX-1777'));
      set_item_result(run_stored_sig('AR_RAXTRX_CONV_CM'));
      set_item_result(run_stored_sig('AR_RAXTRX-1779'));
      set_item_result(run_stored_sig('AR_RAXTRX_DUPLICATE_CM_LINE'));
      set_item_result(run_stored_sig('AR_RAXTRX-1771'));
      set_item_result(run_stored_sig('AR_RAXTRX-1767'));
      set_item_result(run_stored_sig('AR_RAXTRX-1624_G'));
      set_item_result(run_stored_sig('AR_CKAP_OVERAPP'));
      set_item_result(run_stored_sig('AR_MAECM_LINE_OVERAPPLIED'));
      set_item_result(run_stored_sig('AR_RAXTRX-1661'));
      set_item_result(run_stored_sig('AR_RAXTRX-1662'));
      set_item_result(run_stored_sig('AR_RAXTRX-1628_G'));
      set_item_result(run_stored_sig('AR_RAXTRX-1768'));
      set_item_result(run_stored_sig('AR_RAXTRX-1801'));
      set_item_result(run_stored_sig('AR_RAXTRX-1800'));
      set_item_result(run_stored_sig('AR_RAXTRX-1776'));
    end_section;
   
    start_section('Currency Errors');
      set_item_result(run_stored_sig('AR_RAXTRX-1709'));
      set_item_result(run_stored_sig('AR_RAXTRX-1713'));
      set_item_result(run_stored_sig('AR_RAXTRX-1725'));
      set_item_result(run_stored_sig('AR_RAXTRX-1726'));
      set_item_result(run_stored_sig('AR_RAXTRX-1745'));
      set_item_result(run_stored_sig('AR_RAXTRX-1749'));
      set_item_result(run_stored_sig('AR_RAXTRX-1815'));
      set_item_result(run_stored_sig('AR_RAXTRX-1753'));
      set_item_result(run_stored_sig('C-1654'));
      set_item_result(run_stored_sig('C-1653'));
    end_section;
  
    start_section('Customer, Address and Contact Errors');
    set_item_result(run_stored_sig('AR_RAXTRX-1772'));
    set_item_result(run_stored_sig('C-1601'));
    set_item_result(run_stored_sig('C-1602'));
    set_item_result(run_stored_sig('C-1603'));
    set_item_result(run_stored_sig('C-1605'));
    set_item_result(run_stored_sig('C-1606'));
    set_item_result(run_stored_sig('C-1607'));
    set_item_result(run_stored_sig('C-1609'));
    set_item_result(run_stored_sig('C-1611'));
    set_item_result(run_stored_sig('C-1613'));
    set_item_result(run_stored_sig('C-1600'));
    set_item_result(run_stored_sig('C-1604'));
    set_item_result(run_stored_sig('C-1608'));
    set_item_result(run_stored_sig('C-1610'));
    set_item_result(run_stored_sig('C-1612'));
    set_item_result(run_stored_sig('AR_RAXTRX-1614'));
    end_section;
  
    if g_apps_version = '12' then
       start_section('EBTAX Issues');          
          set_item_result(run_stored_sig('TAX_ISSUES'));
       end_section;  
    end if;

    start_section('Freight Issues');  
    set_item_result(run_stored_sig('AR_RAXTRX-1699'));
    set_item_result(run_stored_sig('AR_RAXTRX_FRM_FRT_ERR'));
    set_item_result(run_stored_sig('AR_RAXTRX_FRM_FRT_DIST'));
    set_item_result(run_stored_sig('C-1650'));
    set_item_result(run_stored_sig('C-1651'));
    end_section;
  
    start_section('Grouping Rule Errors');    
    set_item_result(run_stored_sig('AR_RAXTRX-1690'));
    set_item_result(run_stored_sig('AR_RAXTRX-1812'));
    set_item_result(run_stored_sig('AR_RAXTRX-1796'));
    set_item_result(run_stored_sig('AR_RAXTRX-1810'));
    set_item_result(run_stored_sig('AR_RAXTRX-1797'));
    end_section;
  
    start_section('Invoicing and Accounting Rules');  
    set_item_result(run_stored_sig('AR_RAXTRX-1618'));
    set_item_result(run_stored_sig('AR_RAXTRX-1704'));
    set_item_result(run_stored_sig('AR_RAXTRX-1728'));
    set_item_result(run_stored_sig('AR_RAXTRX-1735'));
    set_item_result(run_stored_sig('AR_RAXTRX-1766'));
    set_item_result(run_stored_sig('AR_RAXTRX-1795'));
    set_item_result(run_stored_sig('AR_RAXTRX_RSD_LT_RED'));
    set_item_result(run_stored_sig('AR_RAXTRX-1820'));
    set_item_result(run_stored_sig('AR_RAXTRX_RULE_END_DATE_VAL'));
    set_item_result(run_stored_sig('AR_RAXTRX_RULE_START_DT_NULL'));
    set_item_result(run_stored_sig('AR_RAXTRX-1727'));
    set_item_result(run_stored_sig('C-1644'));
    set_item_result(run_stored_sig('C-1645'));
    set_item_result(run_stored_sig('C-1636'));
    set_item_result(run_stored_sig('C-1637'));
    end_section;

    start_section('Invoice/Transaction Numbering');        
    set_item_result(run_stored_sig('AR_RAXTRX-1714'));
    set_item_result(run_stored_sig('AR_RAXTRX-1743'));
    set_item_result(run_stored_sig('AR_RAXTRX-1744'));
    set_item_result(run_stored_sig('AR_RAXTRX-1757'));
    set_item_result(run_stored_sig('AR_RAXTRX-1742'));
    end_section; 
  
    start_section('Miscellaneous Data Validation Errors');
    set_item_result(run_stored_sig('AR-SURUL-NO_CASH_RULES'));
    set_item_result(run_stored_sig('AR_RAXTRX-1617'));
    set_item_result(run_stored_sig('AR_RAXTRX-1668'));
    set_item_result(run_stored_sig('AR_RAXTRX-1707'));
    set_item_result(run_stored_sig('AR_RAXTRX-1708'));
    set_item_result(run_stored_sig('AR_RAXTRX-1723'));
    set_item_result(run_stored_sig('AR_RAXTRX-1729'));
    set_item_result(run_stored_sig('AR_RAXTRX-1731'));
    set_item_result(run_stored_sig('AR_RAXTRX-1732'));
    set_item_result(run_stored_sig('AR_RAXTRX-1733'));
    set_item_result(run_stored_sig('AR_RAXTRX-1734'));
    set_item_result(run_stored_sig('AR_RAXTRX-1740'));
    set_item_result(run_stored_sig('AR_RAXTRX-1741'));
    set_item_result(run_stored_sig('AR_RAXTRX-1746'));
    set_item_result(run_stored_sig('AR_RAXTRX-1747'));
    set_item_result(run_stored_sig('AR_RAXTRX-1748'));
    set_item_result(run_stored_sig('AR_RAXTRX-1756'));
    set_item_result(run_stored_sig('AR_RAXTRX_INV_WAREHOUSE'));
    set_item_result(run_stored_sig('AR_RAXTRX_REJECTED_INV'));
    set_item_result(run_stored_sig('AR_RAXTRX-1780'));
    set_item_result(run_stored_sig('AR_RAXTRX-1724'));
    set_item_result(run_stored_sig('AR_RAXTRX-1620_G'));
    set_item_result(run_stored_sig('C-1642'));
    set_item_result(run_stored_sig('C-1643'));
    set_item_result(run_stored_sig('C-1647'));
    end_section;
   
    start_section('Payment Terms Errors');      
    set_item_result(run_stored_sig('AR_RAXTRX-1716'));
    set_item_result(run_stored_sig('AR_RAXTRX-1722'));
    set_item_result(run_stored_sig('C-1638'));
    set_item_result(run_stored_sig('C-1639'));
    end_section; 
  
    start_section('Pre-payments');          
    set_item_result(run_stored_sig('AR_RAXTRX-1817'));
    set_item_result(run_stored_sig('AR_RAXTRX-1816'));
    end_section;  
  
    start_section('Receipt, Payment Method and Bank Errors');    
    set_item_result(run_stored_sig('AR_RAXTRX-1700'));
    set_item_result(run_stored_sig('AR_RAXTRX-1701'));
    set_item_result(run_stored_sig('AR_RAXTRX-1702'));
    set_item_result(run_stored_sig('AR_RAXTRX-1703'));
    set_item_result(run_stored_sig('AR_RAXTRX-1760'));
    set_item_result(run_stored_sig('AR_RAXTRX-1761'));
    set_item_result(run_stored_sig('AR_RAXTRX-1762'));
    set_item_result(run_stored_sig('AR_RAXTRX-1763'));
    -- set_item_result(run_stored_sig('AR_RAXTRX-1631')); this message no longer referenced in code, nor does it exist in FND_NEW_MESSAGES
    end_section;  
  
    start_section('Sales Credit Errors');    
    set_item_result(run_stored_sig('AR_INVALID_PRIMARY_SALESREP'));
    set_item_result(run_stored_sig('AR_RAXTRX-1620'));
    set_item_result(run_stored_sig('AR_RAXTRX-1621'));
    set_item_result(run_stored_sig('AR_RAXTRX-1622'));
    set_item_result(run_stored_sig('AR_RAXTRX-1623'));
    set_item_result(run_stored_sig('AR_RAXTRX-1624'));
    set_item_result(run_stored_sig('AR_RAXTRX-1625'));
    set_item_result(run_stored_sig('AR_RAXTRX-1626'));
    set_item_result(run_stored_sig('AR_RAXTRX-1627'));
    set_item_result(run_stored_sig('AR_RAXTRX-1628'));
    set_item_result(run_stored_sig('AR_RAXTRX-1629'));
    set_item_result(run_stored_sig('C-1634'));
    set_item_result(run_stored_sig('AR_RAXTRX_SALESREP_INACTIVE'));
    set_item_result(run_stored_sig('C-1635'));
    set_item_result(run_stored_sig('AR_RAXTRX-1630'));
    end_section;

    start_section('Tax Errors');          
    set_item_result(run_stored_sig('AR_RAXTRX-1802'));
    set_item_result(run_stored_sig('AR_RAXTRX-1654'));
    set_item_result(run_stored_sig('AR_RAXTRX-1655'));
    set_item_result(run_stored_sig('AR_RAXTRX-1656'));
    set_item_result(run_stored_sig('AR_RAXTRX-1657'));
    set_item_result(run_stored_sig('AR_RAXTRX-1658'));
    set_item_result(run_stored_sig('AR_RAXTRX-1659'));
    set_item_result(run_stored_sig('AR_RAXTRX-1706'));
    set_item_result(run_stored_sig('AR_RAXTRX-1730'));
    set_item_result(run_stored_sig('AR_RAXTRX-1826'));
    set_item_result(run_stored_sig('AR_RAXTRX_INVAL_EXEMPT'));
    set_item_result(run_stored_sig('AR_RAXTRX_INV_INCL_FLAG_GRP'));
    set_item_result(run_stored_sig('AR_RAXTRX_INV_INCL_FLAG_MAN'));
    set_item_result(run_stored_sig('AR_RAXTRX-1706B'));
    set_item_result(run_stored_sig('AR_RAXTRX_INV_INCL_FLAG_CODE'));
    set_item_result(run_stored_sig('AR_RAXTRX_EXEMPT_NOT_ALLOW'));
    end_section;  

    start_section('Transactions against Commitments');          
    set_item_result(run_stored_sig('AR_RAXTRX_ZERO_VS_COMMIT'));
    set_item_result(run_stored_sig('AR_RAXTRX-1764'));
    set_item_result(run_stored_sig('AR_RAXTRX-1765'));
    set_item_result(run_stored_sig('AR_RAXTRX_OPEN_DEPOSIT'));
    set_item_result(run_stored_sig('AR_RAXTRX-1697'));
    set_item_result(run_stored_sig('AR_RAXTRX-1696'));
    set_item_result(run_stored_sig('AR_RAXTRX-1615'));
    set_item_result(run_stored_sig('AR_RAXTRX-1616'));
    end_section; 

    start_section('Transaction Flexfield Errors');  
    set_item_result(run_stored_sig('AR_RAXTRX-1665'));
    set_item_result(run_stored_sig('AR_RAXTRX-1514'));
    set_item_result(run_stored_sig('AR_RAXTRX-1664'));
    set_item_result(run_stored_sig('AR_RAXTRX-1778'));
    set_item_result(run_stored_sig('AR_RAXTRX-1665A'));
    set_item_result(run_stored_sig('AR_RAXTRX-1665B'));
    set_item_result(run_stored_sig('AR_RAXTRX-1515'));
    end_section;
  
    start_section('Transaction Type Errors');
    set_item_result(run_stored_sig('AR_RAXTRX-1693'));
    set_item_result(run_stored_sig('AR_RAXTRX-1694'));
    set_item_result(run_stored_sig('AR_RAXTRX-1711'));
    set_item_result(run_stored_sig('AR_RAXTRX-1712'));
    set_item_result(run_stored_sig('AR_RAXTRX-1715'));
    set_item_result(run_stored_sig('AR_RAXTRX-1692'));
    set_item_result(run_stored_sig('AR_RAXTRX-1821'));
    set_item_result(run_stored_sig('AR_RAXTRX-1785'));
    set_item_result(run_stored_sig('C-1649'));
    set_item_result(run_stored_sig('C-1631'));
    set_item_result(run_stored_sig('C-1630'));
    set_item_result(run_stored_sig('C-1648'));
    end_section;
  
    start_section('Unit Of Measure issue');          
    set_item_result(run_stored_sig('AR_RAXTRX-1619'));
    set_item_result(run_stored_sig('AR_RAXTRX-1721'));
    set_item_result(run_stored_sig('C-1640'));
    set_item_result(run_stored_sig('C-1641'));
    end_section;  
   end if;
   
   
  
  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/message/13280792" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

-------------------------------------------
-- MAIN ENTRY POINT FOR CONCURRENT PROCESS
-- uncomment to run from concurrent program
-- edit list of variables to match MAIN
-- <package>.main_cp will be what you define program to call
-------------------------------------------
-- PSD #16	

PROCEDURE main_cp (
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,    
      p_org_id          IN NUMBER,
      p_request_id      IN NUMBER DEFAULT 0,
      p_resp_id         IN NUMBER DEFAULT 0) IS

BEGIN
  g_retcode := 0;
  g_errbuf := null;

print_log('p_resp_id = ' || p_resp_id);


  main(
      p_org_id => p_org_id,
      p_request_id => p_request_id,
      p_resp_id => p_resp_id);

  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


-- PSD #1
END ar_autoinvoice_analyzer_pkg;
/
show errors
exit; 
-- Exit required for bundling project so do not remove
