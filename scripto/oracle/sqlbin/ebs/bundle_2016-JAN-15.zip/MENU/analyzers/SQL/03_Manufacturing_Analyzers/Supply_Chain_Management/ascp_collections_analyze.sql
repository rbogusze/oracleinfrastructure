REM $Id: ascp_collections_analyze.sql, 200.2 2015/15/01 23:27:42 jxmccall Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ascp_collections_analyze.sql                                         |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the ascp_collections_pkg.main procedure        |
REM |                                                                         |
REM | HISTORY                                                                 |
REM |   28-Oct-2015 Converted to the Analyzer Framework 3.0.29                |
REM +=========================================================================+
REM
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2 
REM 
REM MENU_TITLE: ASCP Data Collections Analyzer
REM
REM MENU_START
REM
REM SQL: Run ASCP Data Collections Analyzer
REM FNDLOAD: ASCP Data Collections Analyzer as a Concurrent Program
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  ASCP Data Collections Analyzer Help [Doc ID: 1596457.1] 
REM
REM  Compatible: 11i|12.0|12.1|12.2 
REM
REM  Explanation of available options:
REM
REM    (1) Run ASCP Data Collections Analyzer
REM        o Runs ascp_collection_analyzer.sql as APPS 
REM        o Creates an HTML output 
REM
REM    (2)  Install ASCP Data Collections Analyzer as a Concurrent Program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "All MSC Reports" 
REM
REM 
REM HELP_END 
REM
REM FNDLOAD_START 
REM
REM PROD_TOP: MSC_TOP
REM PROG_NAME: MSCACA_SQL
REM APP_NAME: Advanced Supply Chain Planning
REM DEF_REQ_GROUP: All MSC Reports
REM PROG_TEMPLATE: MSCACA_SQL.ldt
REM PROD_SHORT_NAME: MSC
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ascp_collections_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
-- PSD #1

PROMPT
PROMPT Submitting ASCP Data Collections Analyzer.
PROMPT ===========================================================================
PROMPT Enter the instance_code to analyze.  This parameter is required.
PROMPT
PROMPT After entering the instance_code, press enter.  The analyzer will automatically 
PROMPT begin to gather the data points.
PROMPT
PROMPT ===========================================================================
PROMPT
PROMPT Choose the INSTANCE_CODE from the following:
column instance_code format a13
select instance_id, instance_code 
from msc_apps_instances;

ACCEPT inst_code CHAR

DECLARE
l_instance_code         VARCHAR2(3) := upper('&inst_code');
p_instance_id           number;

BEGIN
  
  select instance_id
  into p_instance_id
  from msc_apps_instances
  where instance_code = l_instance_code;
--  where exists
--  (select instance_code from msc_apps_instances where instance_code = l_instance_code);
  

-- PSD #4
  ascp_collections_pkg.main(
  p_instance_id => p_instance_id);

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Instance Code Parameter Error Encountered: '||sqlerrm);
END;
/
exit;
