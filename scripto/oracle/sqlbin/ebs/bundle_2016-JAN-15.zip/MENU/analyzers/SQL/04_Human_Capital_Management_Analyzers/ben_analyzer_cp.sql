SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE '~'
SET ESCAPE OFF
WHENEVER SQLERROR EXIT

REM $Id: ben_analyzer_cp.sql, 200.7 2016/01/13 04:13:39 simona.elena.ionescu@oracle.com Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.35                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ben_analyzer_cp.sql                                                  |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+
REM 

alter session set nls_date_format = 'DD-MON-YYYY';

declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,4);
 
 -- Validation to verify analyzer is run on proper e-Business application version
 if apps_version NOT IN ('11.5','12.0','12.1','12.2') then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'           ');
    dbms_output.put_line('*** This Analyzer script is compatible for following version(s): ');
	dbms_output.put_line('***   11i,12.0,12.1,12.2 ');
    dbms_output.put_line('*** Note: the error below is intentional                    ');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness versions 11i,12.0,12.1,12.2');
 end if;

END;
/





DECLARE
   l_debug_mode VARCHAR2(1) := 'Y';
   p_person_id                    NUMBER         := '~1';
   p_max_output_rows              NUMBER         := '~2';
   p_debug_mode                   VARCHAR2(240)  := '~3';




TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=2025944.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

    l_log_file := 'BEN_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'BEN_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>BEN Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
              'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfL'||
              'T8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

-- Print title
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">EBS '|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=2025944.1:SQLSCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/hcm_ben_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\\2">Patch \\2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\\[)([0-9]*\\.[0-9])(\\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\\2">Doc ID \\2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
	-- removed initCap per Standardization team in 3.0.34
    l_col_headings(i) := replace(l_desc_rec_tbl(i).col_name,'|','<br>');
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_sigxinfo_element     XMLDOM.DOMElement;
l_sigxinfo_node        XMLDOM.DOMNode;
l_xinfo_element        XMLDOM.DOMElement;
l_xinfo_node           XMLDOM.DOMNode;
l_xinfo_name_attr      XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);
   
   IF p_sig.extra_info.count > 0 THEN
      l_sigxinfo_element := XMLDOM.createElement(l_hidden_xml_doc,'sigxinfo');      
      l_sigxinfo_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_sigxinfo_element));      
      l_key := p_sig.extra_info.first;
      WHILE l_key IS NOT NULL LOOP
         l_xinfo_element := XMLDOM.createElement(l_hidden_xml_doc,'info');      
         l_xinfo_node := XMLDOM.appendChild(l_sigxinfo_node,XMLDOM.makeNode(l_xinfo_element));      
         l_xinfo_name_attr := XMLDOM.setAttributeNode(l_xinfo_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name')); 
         XMLDOM.setAttribute(l_xinfo_element, 'name',l_key);
         l_node := XMLDOM.appendChild(l_xinfo_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,p_sig.extra_info(l_key))));         
         l_key := p_sig.extra_info.next(l_key);
      END LOOP;
   END IF;   
   
   IF p_sig.include_in_xml='Y' THEN

      IF p_sig.limit_rows='Y' THEN
         l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
      ELSE
         l_rows := least(p_col_rows(1).COUNT,50);
      END IF;
   
      FOR i IN 1..l_rows LOOP

         l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
         l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
         l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
         XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
         FOR j IN 1..p_col_headings.count LOOP
 
            l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
            l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
            l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
            XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
            l_value := p_col_rows(j)(i);

            IF p_sig_id = 'REC_PATCH_CHECK' THEN
               IF p_col_headings(j) = 'Patch' THEN
                  l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
               ELSIF p_col_headings(j) = 'Note' THEN
                  l_value := replace(replace(p_col_rows(j)(i),'['),']');
               END IF;
            END IF;
		 
		    -- Rtrim the column value if blanks are not to be preserved
             IF NOT g_preserve_trailing_blanks THEN
               l_value := RTRIM(l_value, ' ');
             END IF;

            l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

          END LOOP;

       END LOOP;
     
     END IF;  --p_sig.include_in_xml='Y'            
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml IN ('Y','P')) THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  	
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;		  
		  
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.7'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
			
       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;			
			
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);
		-- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;
		 
          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;
	
  END IF;	
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div><br>');
END print_rep_subsection_end;


-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------



-------------------------
-- Recommended patches 
-------------------------

FUNCTION check_rec_patches_1 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_1');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22141344';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ACA PHASE II PATCH ';
   l_col_rows(5)(1) := '[2089776.1]';

   l_col_rows(1)(2) := '21162146';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'ACA PHASE-1 PATCH';
   l_col_rows(5)(2) := '[2051649.1]';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '22141344';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ACA PHASE II PATCH ';
   l_col_rows(5)(1) := '[2089776.1]';

   l_col_rows(1)(2) := '21162146';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'ACA PHASE-1 PATCH';
   l_col_rows(5)(2) := '[2031930.1]';

   l_col_rows(1)(3) := '16000686';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.B.delta.6';
   l_col_rows(5)(3) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '21611812';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'ACA PHASE-1 PATCH';
   l_col_rows(5)(1) := '[2051732.1]';

   l_col_rows(1)(2) := '17774746';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.9';
   l_col_rows(5)(2) := '';

END IF;

   l_sig.title := 'ACA Recommended Patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'Please check if any of the recommended patches were not applied in this instance';
   l_sig.solution := 'Please review list above and schedule to apply any unappplied patches as soon as possible.';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'ACAPATCH',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_1');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_1 at step '||l_step);
  raise;
END check_rec_patches_1;

FUNCTION check_rec_patches_2 RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL  := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;  -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel        VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN

debug('Begin recommended patches signature: check_rec_patches_2');

  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';
  l_col_rows.extend(5);

IF substr(g_rep_info('Apps Version'),1,4) = '12.2' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '19193000';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.C.delta.6';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '17909898';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.C.delta.5';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '17050005';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.B.delta.4';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '17001123';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'R12.HR_PF.B.delta.3';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '16169935';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.HR_PF.B.delta.2';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '14040707';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.HR_PF.B.delta.1';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '10124646';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'R12.HR_PF.C';
   l_col_rows(5)(7) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '20806064';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := '12.1.7 and 12.1.8: PARTICIPATION PROCESS: SCHEDULED ERRORS WITH FDPSTP';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '20000288';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'R12.HR_PF.B.delta.8';
   l_col_rows(5)(2) := '[20000288]';

   l_col_rows(1)(3) := '19130718';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := '12.1.7: ADDING ATTACHMENT IN SSBEN, FORMS PAPER CLIP DOESNT CHANGE';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '18923176';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '12.1.7: COLLAPSE OF PLAN TYPE IN SSBEN CLEARS SELECTED ENROLLMENT';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '18004477';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'R12.HR_PF.B.delta.7';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '17425199';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := '12.1.5 and 12.1.6: LIFE EVENT REASON NOT AVAILABLE IN PERSON ACTION TABLE IN SSBEN';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '17355424';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '12.1.6: RECEIVING APP-PAY-33681 ERROR ON PROCESSING LIFE EVENT';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '16068560';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := '12.1.6: APP-BEN-93448 ERROR WHEN CHANGING BENEFIT AMOUNT';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '16000686';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'R12.HR_PF.B.delta.6';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '14559387';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := '12.1.5: RECEIVING APP-BEN-91711 ERROR WHEN CLOSING OPEN LE';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '14496319';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := '12.1.4 and 12.1.5: AFTER RUP5, FLEX CREDITS DUPLICATE';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '14298342';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := '12.1.3: OAB VARIABLE RATES NOT SENDING THE CORRECT AMOUNTS TO PAYROLL ELEMENT ENTRIES';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '13982715';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := '12.1.3: APP-BEN-91333: CALLING BEN_GENERATE_COMMUNICATIONS WHEN TRYING TO UPDATE BENEFITS';
   l_col_rows(5)(13) := '';

   l_col_rows(1)(14) := '13855370';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := '12.1.4: HIRE AN EMPLOYEE LIFE EVENT IS NOT TRIGGERING IN OAB';
   l_col_rows(5)(14) := '';

   l_col_rows(1)(15) := '13418800';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := 'R12.HR_PF.B.delta.5';
   l_col_rows(5)(15) := '';

   l_col_rows(1)(16) := '13059935';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := '12.1.4: LE NOT TRIGGERING WHEN ASSIGNMENT DATA IS CHANGED';
   l_col_rows(5)(16) := '';

   l_col_rows(1)(17) := '12871602';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := '12.1.3: REINSTATE IF ELECTABILITY EXISTS FOR BACKED OUT RESULT';
   l_col_rows(5)(17) := '';

   l_col_rows(1)(18) := '12810996';
   l_col_rows(2)(18) := 'No';
   l_col_rows(3)(18) := NULL;
   l_col_rows(4)(18) := '12.1.4: APP-BEN-91333 ERROR AFTER APPLYING REL12.1 RUP 4 PATCH';
   l_col_rows(5)(18) := '';

   l_col_rows(1)(19) := '12664112';
   l_col_rows(2)(19) := 'No';
   l_col_rows(3)(19) := NULL;
   l_col_rows(4)(19) := '12.1.4: FIX BUG 11071616 DOES NOT COVER SECONDARY ASSIGNMENT BECOMING PRIMARY';
   l_col_rows(5)(19) := '';

   l_col_rows(1)(20) := '10281212';
   l_col_rows(2)(20) := 'No';
   l_col_rows(3)(20) := NULL;
   l_col_rows(4)(20) := 'R12.HR_PF.B.delta.4';
   l_col_rows(5)(20) := '';

   l_col_rows(1)(21) := '10180700';
   l_col_rows(2)(21) := 'No';
   l_col_rows(3)(21) := NULL;
   l_col_rows(4)(21) := '12.1.4: FF OF TYPE PERSON CHANGE CAUSES LIFE EVENT NOT WORKING';
   l_col_rows(5)(21) := '';

   l_col_rows(1)(22) := '10152981';
   l_col_rows(2)(22) := 'No';
   l_col_rows(3)(22) := NULL;
   l_col_rows(4)(22) := '12.1.4: FF OF TYPE PERSON CHANGE CAUSES LIFE EVENT IS PASSING WRONG ASSIGMENT_ID';
   l_col_rows(5)(22) := '';

   l_col_rows(1)(23) := '9114911';
   l_col_rows(2)(23) := 'No';
   l_col_rows(3)(23) := NULL;
   l_col_rows(4)(23) := 'R12.HR_PF.B.delta.3';
   l_col_rows(5)(23) := '';

   l_col_rows(1)(24) := '8337373';
   l_col_rows(2)(24) := 'No';
   l_col_rows(3)(24) := NULL;
   l_col_rows(4)(24) := 'R12.HR_PF.B.delta.2';
   l_col_rows(5)(24) := '';

   l_col_rows(1)(25) := '7446767';
   l_col_rows(2)(25) := 'No';
   l_col_rows(3)(25) := NULL;
   l_col_rows(4)(25) := 'R12.HR_PF.B.delta.1';
   l_col_rows(5)(25) := '';

   l_col_rows(1)(26) := '6603330';
   l_col_rows(2)(26) := 'No';
   l_col_rows(3)(26) := NULL;
   l_col_rows(4)(26) := 'R12.HR_PF.B';
   l_col_rows(5)(26) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN

   l_rel := 'R12';
   l_col_rows(1)(1) := '16077077';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'R12.HR_PF.A.delta.11';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '14077548';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := '12.0.4: VARIABLE RATES NOT UPDATING ELEMENT ENTRY';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '13774477';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'R12.HR_PF.A.delta.10';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '13024736';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := '12.0.4: HRMSR12: FWD PORT OF 12703190';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '12417510';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := '12.0.4: OAB VARIABLE RATES NOT SENDING THE CORRECT AMOUNTS TO PAYROLL ELEMENT ENTRIES';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '10281209';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'R12.HR_PF.A.delta.9';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '9937161';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := '12.0.4: FWD PORT OF 9818852';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '9301208';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'R12.HR_PF.A.delta.8';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '9143371';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := '12.0.4: MAINTAIN DESIGNEE ELIGIBILITY CONCURRENT PROGRAM ENDED ALL THE DEPENDENTS';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '8640300';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := '12.0.4: HR_7215_DT_CHILD_EXISTS AFTER RUNNING RECALCULATE PARTICIPANT VALUES';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '7577660';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'R12.HR_PF.A.delta.7';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '7004477';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := 'R12.HR_PF.A.delta.6';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '6610000';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := 'R12.HR_PF.A.delta.5';
   l_col_rows(5)(13) := '';

   l_col_rows(1)(14) := '6494646';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := 'R12.HR_PF.A.delta.4';
   l_col_rows(5)(14) := '';

   l_col_rows(1)(15) := '6196269';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := 'R12.HR_PF.A.delta.3';
   l_col_rows(5)(15) := '';

   l_col_rows(1)(16) := '5997278';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := 'R12.HR_PF.A.delta.2';
   l_col_rows(5)(16) := '';

   l_col_rows(1)(17) := '5881943';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := 'R12.HR_PF.A.delta.1';
   l_col_rows(5)(17) := '';

   l_col_rows(1)(18) := '4719824';
   l_col_rows(2)(18) := 'No';
   l_col_rows(3)(18) := NULL;
   l_col_rows(4)(18) := 'R12.HR_PF.A';
   l_col_rows(5)(18) := '';

END IF;

IF substr(g_rep_info('Apps Version'),1,4) = '11.5' THEN

   l_rel := '11i';
   l_col_rows(1)(1) := '17774746';
   l_col_rows(2)(1) := 'No';
   l_col_rows(3)(1) := NULL;
   l_col_rows(4)(1) := 'HR_PF.K.RUP.9';
   l_col_rows(5)(1) := '';

   l_col_rows(1)(2) := '14488556';
   l_col_rows(2)(2) := 'No';
   l_col_rows(3)(2) := NULL;
   l_col_rows(4)(2) := 'HR_PF.K.RUP.8';
   l_col_rows(5)(2) := '';

   l_col_rows(1)(3) := '14117798';
   l_col_rows(2)(3) := 'No';
   l_col_rows(3)(3) := NULL;
   l_col_rows(4)(3) := 'HR_PF K RUP 5 : INCORRECT CALCULATION OF PER PAY COMMUNICATED AMOUNT OF PLANS OF WEEKY EMPLOYEES';
   l_col_rows(5)(3) := '';

   l_col_rows(1)(4) := '12807777';
   l_col_rows(2)(4) := 'No';
   l_col_rows(3)(4) := NULL;
   l_col_rows(4)(4) := 'HR_PF.K.RUP.7';
   l_col_rows(5)(4) := '';

   l_col_rows(1)(5) := '12703190';
   l_col_rows(2)(5) := 'No';
   l_col_rows(3)(5) := NULL;
   l_col_rows(4)(5) := 'HR_PF K RUP 5 MANDATORY: APP-BEN-91711 SAVING SUPP LIFE ON CERTAIN DAYS FOR NEW HIRE LE';
   l_col_rows(5)(5) := '';

   l_col_rows(1)(6) := '10051048';
   l_col_rows(2)(6) := 'No';
   l_col_rows(3)(6) := NULL;
   l_col_rows(4)(6) := 'HR_PF K RUP 4 and 5 MANDATORY: ADDING DEPENDENTS BACK MAKES COVERAGE START DATE GO TO ORIGINAL START';
   l_col_rows(5)(6) := '';

   l_col_rows(1)(7) := '10015566';
   l_col_rows(2)(7) := 'No';
   l_col_rows(3)(7) := NULL;
   l_col_rows(4)(7) := 'HR_PF.K.RUP.6';
   l_col_rows(5)(7) := '';

   l_col_rows(1)(8) := '9818852';
   l_col_rows(2)(8) := 'No';
   l_col_rows(3)(8) := NULL;
   l_col_rows(4)(8) := 'HR_PF K RUP 5 : BACKING OUT LE ERRORS WITH APP-PAY-07155 HR OBJECT IS INVALID';
   l_col_rows(5)(8) := '';

   l_col_rows(1)(9) := '9774358';
   l_col_rows(2)(9) := 'No';
   l_col_rows(3)(9) := NULL;
   l_col_rows(4)(9) := 'HR_PF K RUP 5 MANDATORY: RUP5 ERROR CANNOT CALCULATE THE DATE CODE : ALDPPPY';
   l_col_rows(5)(9) := '';

   l_col_rows(1)(10) := '9612828';
   l_col_rows(2)(10) := 'No';
   l_col_rows(3)(10) := NULL;
   l_col_rows(4)(10) := 'HR_PF K RUP 4 : DEPENDENTS COVERAGE HAS WRONG END DATE AFTER PROCESSING OPEN LE';
   l_col_rows(5)(10) := '';

   l_col_rows(1)(11) := '9575477';
   l_col_rows(2)(11) := 'No';
   l_col_rows(3)(11) := NULL;
   l_col_rows(4)(11) := 'HR_PF K RUP 4 and 5 : REPROCESSING LIFE EVENT ERRORS WITH BEN_92968_PL_ENRD_GT_MX_ALWD';
   l_col_rows(5)(11) := '';

   l_col_rows(1)(12) := '9557222';
   l_col_rows(2)(12) := 'No';
   l_col_rows(3)(12) := NULL;
   l_col_rows(4)(12) := 'HR_PF K RUP 4 : AUTOMATIC ENROLLMENT RATES ARE NOT DISPLAYED ON SELECTIONS PAGE';
   l_col_rows(5)(12) := '';

   l_col_rows(1)(13) := '9062727';
   l_col_rows(2)(13) := 'No';
   l_col_rows(3)(13) := NULL;
   l_col_rows(4)(13) := 'HR_PF.K.RUP.5';
   l_col_rows(5)(13) := '';

   l_col_rows(1)(14) := '9033589';
   l_col_rows(2)(14) := 'No';
   l_col_rows(3)(14) := NULL;
   l_col_rows(4)(14) := 'HR_PF K RUP 3 and 4 : VAPRO IS NOT BEING PASSED AFTER PROCESSING LIFE EVENT';
   l_col_rows(5)(14) := '';

   l_col_rows(1)(15) := '9021884';
   l_col_rows(2)(15) := 'No';
   l_col_rows(3)(15) := NULL;
   l_col_rows(4)(15) := 'HR_PF K RUP 4 : SEVERE SYSTEM SLOWNESS WHEN PROCESSING LIFE EVENTS AFTER RUP4';
   l_col_rows(5)(15) := '';

   l_col_rows(1)(16) := '8930024';
   l_col_rows(2)(16) := 'No';
   l_col_rows(3)(16) := NULL;
   l_col_rows(4)(16) := 'HR_PF K RUP 4 and 3 : RUP4 APP-PAY-07188-CANT PROCESS LES ON SOME EMPS--RANDOM';
   l_col_rows(5)(16) := '';

   l_col_rows(1)(17) := '8916420';
   l_col_rows(2)(17) := 'No';
   l_col_rows(3)(17) := NULL;
   l_col_rows(4)(17) := 'HR_PF K RUP 4 : AFTER RUP4, MISSING JOIN IN THE CURSOR IN THE PACKAGE BEN_ELECTION_INFORMATION';
   l_col_rows(5)(17) := '';

   l_col_rows(1)(18) := '8872583';
   l_col_rows(2)(18) := 'No';
   l_col_rows(3)(18) := NULL;
   l_col_rows(4)(18) := 'HR_PF K RUP 4 : RUP 4 CONTRIBUTION AMT IS INCORRECT WHEN FSA AMT CHANGES';
   l_col_rows(5)(18) := '';

   l_col_rows(1)(19) := '8872544';
   l_col_rows(2)(19) := 'No';
   l_col_rows(3)(19) := NULL;
   l_col_rows(4)(19) := 'HR_PF K RUP 4 : CONTINGENT PERCENT IS NOT APPEARING ON CURRENT BENEFIT FORM IN SELF SERVICE';
   l_col_rows(5)(19) := '';

   l_col_rows(1)(20) := '8798020';
   l_col_rows(2)(20) := 'No';
   l_col_rows(3)(20) := NULL;
   l_col_rows(4)(20) := 'HR_PF K RUP 4 : ELEMENT CHAIN PATCH FOR BUGS 8798020 and 8773398';
   l_col_rows(5)(20) := '';

   l_col_rows(1)(21) := '8669907';
   l_col_rows(2)(21) := 'No';
   l_col_rows(3)(21) := NULL;
   l_col_rows(4)(21) := 'HR_PF K RUP 4 : NO COVERAGE EOI PLANS ARE REQUIRING CERTIFICATIONS';
   l_col_rows(5)(21) := '';

   l_col_rows(1)(22) := '8567963';
   l_col_rows(2)(22) := 'No';
   l_col_rows(3)(22) := NULL;
   l_col_rows(4)(22) := 'HR_PF K RUP 3 and 4 : UNABLE TO VIEW ENROLLMENT IN BENEFIT ENROLLMENTS PAGE';
   l_col_rows(5)(22) := '';

   l_col_rows(1)(23) := '8549599';
   l_col_rows(2)(23) := 'No';
   l_col_rows(3)(23) := NULL;
   l_col_rows(4)(23) := 'HR_PF K RUP 3 : ACTION ITEM OPEN EVEN AFTER DESIGNATING THE DEPENDENT';
   l_col_rows(5)(23) := '';

   l_col_rows(1)(24) := '8542643';
   l_col_rows(2)(24) := 'No';
   l_col_rows(3)(24) := NULL;
   l_col_rows(4)(24) := 'HR_PF K RUP 3 and 4 : LIFE EVENT TREATMENT CODE-DO NOT DETECT PAST TEMPORAL EVENTS NOT WORKING';
   l_col_rows(5)(24) := '';

   l_col_rows(1)(25) := '8531750';
   l_col_rows(2)(25) := 'No';
   l_col_rows(3)(25) := NULL;
   l_col_rows(4)(25) := 'HR_PF K RUP 3 and 4 : INTERIM COVERAGE DISAPPEARS WITH LATER LES AFTER RUP3';
   l_col_rows(5)(25) := '';

   l_col_rows(1)(26) := '8528791';
   l_col_rows(2)(26) := 'No';
   l_col_rows(3)(26) := NULL;
   l_col_rows(4)(26) := 'HR_PF K RUP 4 : A SUSPENDED RECORD IS CREATED WITHOUT ANY INTERIM';
   l_col_rows(5)(26) := '';

   l_col_rows(1)(27) := '8488400';
   l_col_rows(2)(27) := 'No';
   l_col_rows(3)(27) := NULL;
   l_col_rows(4)(27) := 'HR_PF K RUP 3 and 4 : COV AND RATE OVERLAP ON RECEIVING CERT AND BACKOUT REPROCESSING';
   l_col_rows(5)(27) := '';

   l_col_rows(1)(28) := '8399189';
   l_col_rows(2)(28) := 'No';
   l_col_rows(3)(28) := NULL;
   l_col_rows(4)(28) := 'HR_PF K RUP 3 and 4 : FTE SALARY SETS TO 0 ZERO WHEN THERE IS FUTURE-DATED SALARY CHANGE';
   l_col_rows(5)(28) := '';

   l_col_rows(1)(29) := '8364720';
   l_col_rows(2)(29) := 'No';
   l_col_rows(3)(29) := NULL;
   l_col_rows(4)(29) := 'HR_PF K RUP 3 and 4 : THE PARTICIPATION PROCESS IS NOT FINDING THE ELIG CORRECTLY FOR A PGM';
   l_col_rows(5)(29) := '';

   l_col_rows(1)(30) := '7718592';
   l_col_rows(2)(30) := 'No';
   l_col_rows(3)(30) := NULL;
   l_col_rows(4)(30) := 'HR_PF K RUP 3 : MAINTAIN DESIGNEE PROCESS NOT WORKING AFTER FPK RUP3';
   l_col_rows(5)(30) := '';

   l_col_rows(1)(31) := '7718194';
   l_col_rows(2)(31) := 'No';
   l_col_rows(3)(31) := NULL;
   l_col_rows(4)(31) := 'HR_PF K RUP 3 : SERVICE AREA ELIGIBILITY CRITERIA IS NOT WORKING';
   l_col_rows(5)(31) := '';

   l_col_rows(1)(32) := '7700173';
   l_col_rows(2)(32) := 'No';
   l_col_rows(3)(32) := NULL;
   l_col_rows(4)(32) := 'HR_PF K RUP 3 : BEPG ONLINE OPEN BENMNGLE PERF ISSUE';
   l_col_rows(5)(32) := '';

   l_col_rows(1)(33) := '7679297';
   l_col_rows(2)(33) := 'No';
   l_col_rows(3)(33) := NULL;
   l_col_rows(4)(33) := 'HR_PF K RUP 3 : RECEIVE ERROR BEN_94596 WHEN TRYING TO RE-PROCESS OPEN LE';
   l_col_rows(5)(33) := '';

   l_col_rows(1)(34) := '7666111';
   l_col_rows(2)(34) := 'No';
   l_col_rows(3)(34) := NULL;
   l_col_rows(4)(34) := 'HR_PF.K.RUP.4';
   l_col_rows(5)(34) := '';

   l_col_rows(1)(35) := '7623319';
   l_col_rows(2)(35) := 'No';
   l_col_rows(3)(35) := NULL;
   l_col_rows(4)(35) := 'HR_PF K RUP 3 : BEN_91711 ERROR WHEN PROCESSING LIFE EVENTS';
   l_col_rows(5)(35) := '';

   l_col_rows(1)(36) := '7597154';
   l_col_rows(2)(36) := 'No';
   l_col_rows(3)(36) := NULL;
   l_col_rows(4)(36) := 'HR_PF K RUP 3 : HIGH DEDUTIBLE ELEMENT ENTRY IS POPULATING NULL UNDER AMOUNT FIELD';
   l_col_rows(5)(36) := '';

   l_col_rows(1)(37) := '7537076';
   l_col_rows(2)(37) := 'No';
   l_col_rows(3)(37) := NULL;
   l_col_rows(4)(37) := 'HR_PF K RUP 3 : OAB PURGING ELEMENT ENTRIES FOR 2007 WHEN ENROLLING IN OPEN 2008';
   l_col_rows(5)(37) := '';

   l_col_rows(1)(38) := '7452061';
   l_col_rows(2)(38) := 'No';
   l_col_rows(3)(38) := NULL;
   l_col_rows(4)(38) := 'HR_PF K RUP 3 : DEFAULT ISSUES AFTER FAMILY PACK K RUP3';
   l_col_rows(5)(38) := '';

   l_col_rows(1)(39) := '7434754';
   l_col_rows(2)(39) := 'No';
   l_col_rows(3)(39) := NULL;
   l_col_rows(4)(39) := 'HR_PF K RUP 3 : WHEN MAX ERRORS PARAMETER IS SET higher1 ALL EMPS PROCESSED AFTER THE 1ST ERROR FAIL';
   l_col_rows(5)(39) := '';

   l_col_rows(1)(40) := '7395779';
   l_col_rows(2)(40) := 'No';
   l_col_rows(3)(40) := NULL;
   l_col_rows(4)(40) := 'HR_PF K RUP 3 : ANNUAL MIN/MAX AMOUNTS PRORATED INCORRECTLY WHEN ENROLLING ON YEAR START';
   l_col_rows(5)(40) := '';

   l_col_rows(1)(41) := '7378468';
   l_col_rows(2)(41) := 'No';
   l_col_rows(3)(41) := NULL;
   l_col_rows(4)(41) := 'HR_PF K RUP 3 : INTERIM COVERAGE GETS LOST WHEN INCREASING BENEFIT AMOUNT FOR OPEN';
   l_col_rows(5)(41) := '';

   l_col_rows(1)(42) := '6699770';
   l_col_rows(2)(42) := 'No';
   l_col_rows(3)(42) := NULL;
   l_col_rows(4)(42) := 'HR_PF.K.RUP.3';
   l_col_rows(5)(42) := '';

   l_col_rows(1)(43) := '6491682';
   l_col_rows(2)(43) := 'No';
   l_col_rows(3)(43) := NULL;
   l_col_rows(4)(43) := 'HR_PF K RUP 3 : BENMNGLE DID NOT UPDATE BEN ELEMENTS INCORRECT PAYROLL DEDUCTIONS';
   l_col_rows(5)(43) := '';

   l_col_rows(1)(44) := '5337777';
   l_col_rows(2)(44) := 'No';
   l_col_rows(3)(44) := NULL;
   l_col_rows(4)(44) := 'HR_PF.K.RUP.2';
   l_col_rows(5)(44) := '';

   l_col_rows(1)(45) := '5055050';
   l_col_rows(2)(45) := 'No';
   l_col_rows(3)(45) := NULL;
   l_col_rows(4)(45) := 'HR_PF.K.RUP.1';
   l_col_rows(5)(45) := '';

   l_col_rows(1)(46) := '3500000';
   l_col_rows(2)(46) := 'No';
   l_col_rows(3)(46) := NULL;
   l_col_rows(4)(46) := 'HRMS_PF.K';
   l_col_rows(5)(46) := '';

   l_col_rows(1)(47) := '3333633';
   l_col_rows(2)(47) := 'No';
   l_col_rows(3)(47) := NULL;
   l_col_rows(4)(47) := 'HRMS_PF.J';
   l_col_rows(5)(47) := '';

   l_col_rows(1)(48) := '3233333';
   l_col_rows(2)(48) := 'No';
   l_col_rows(3)(48) := NULL;
   l_col_rows(4)(48) := 'HRMS_PF.H';
   l_col_rows(5)(48) := '';

   l_col_rows(1)(49) := '3127777';
   l_col_rows(2)(49) := 'No';
   l_col_rows(3)(49) := NULL;
   l_col_rows(4)(49) := 'HRMS_PF.I';
   l_col_rows(5)(49) := '';

   l_col_rows(1)(50) := '3116666';
   l_col_rows(2)(50) := 'No';
   l_col_rows(3)(50) := NULL;
   l_col_rows(4)(50) := 'HRMS_PF.G';
   l_col_rows(5)(50) := '';

   l_col_rows(1)(51) := '2968701';
   l_col_rows(2)(51) := 'No';
   l_col_rows(3)(51) := NULL;
   l_col_rows(4)(51) := 'HRMS_PF.F';
   l_col_rows(5)(51) := '';

   l_col_rows(1)(52) := '2803988';
   l_col_rows(2)(52) := 'No';
   l_col_rows(3)(52) := NULL;
   l_col_rows(4)(52) := 'HRMS_PF.E';
   l_col_rows(5)(52) := '';

END IF;

   l_sig.title := 'Recommended Patches';
   l_sig.fail_condition := '[Applied] = [No]';
   l_sig.problem_descr := 'There are missing recommended patches.';
   l_sig.solution := 'Please review list above and schedule to apply any unappplied patches as soon as possible. Refer to [124100.1] Benefits Compensation and Benefits Patch List';
   l_sig.success_msg := '';
   l_sig.print_condition := 'ALWAYS';
   l_sig.fail_type := 'W';
   l_sig.print_sql_output := 'Y';
   l_sig.limit_rows := 'N';
   l_sig.include_in_xml :='N';

  -- Check if applied
  IF l_col_rows.exists(1) THEN
    FOR i in 1..l_col_rows(1).count loop
      l_step := '40';
      OPEN get_app_date(l_col_rows(1)(i),l_rel);
      FETCH get_app_date INTO l_app_date;
      CLOSE get_app_date;
      IF l_app_date is not null THEN
        l_step := '50';
        l_col_rows(2)(i) := 'Yes';
        l_col_rows(3)(i) := to_char(l_app_date);
      END IF;
    END LOOP;
  END IF;

--Render
  l_step := '60';

  l_step := '70';
  RETURN process_signature_results(
    'BENPatching',     -- sig ID
    l_sig,                              -- signature information
    l_col_rows,                         -- data
    l_hdr);                             -- headers

debug('End recommended patches signature: check_rec_patches_2');    
    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches_2 at step '||l_step);
  raise;
END check_rec_patches_2;




-------------------------
-- Signatures
-------------------------



PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;
  l_key      VARCHAR2(255);

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Clear FK values if the sig has children
  IF l_sig.child_sigs.count > 0 THEN
    l_key := g_sql_tokens.first;
    WHILE l_key is not null LOOP
      IF l_key like '##$$FK_$$##' THEN 
        g_sql_tokens.delete(l_key);
      END IF;
      l_key := g_sql_tokens.next(l_key);
    END LOOP;
  END IF;
  
  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--#######################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
PROCEDURE validate_parameters(
            p_person_id                    IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_revision                  VARCHAR2(25);
  l_date_char                 VARCHAR2(30);
  l_instance                  V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version              FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host                      V$INSTANCE.HOST_NAME%TYPE;
  l_key                       VARCHAR2(255);
  l_system_function_var       VARCHAR2(2000);
  l_index                     NUMBER:=1;

  invalid_parameters EXCEPTION;



l_exists_val       VARCHAR2(2000);




  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
  l_revision := rtrim(replace('$Revision: 200.7 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2016/01/13 04:13:36 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_rep_info('File Name') := 'ben_analyzer_cp.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS'); 
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=2025944.1" target="_blank">(Note 2025944.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------

-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  IF substr(l_apps_version,1,4) NOT IN ('11.5','12.0','12.1','12.2') THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script is compatible for following version(s): 11i,12.0,12.1,12.2');
	raise invalid_parameters;
  END IF;
  

  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');

debug('begin parameter validation: p_person_id');
IF p_person_id IS NULL OR p_person_id = '' THEN
   print_error('Parameter Person ID is required.');
   raise invalid_parameters;
END IF;
IF p_person_id IS NOT NULL THEN
BEGIN
SELECT distinct PERSON_ID
INTO l_exists_val
FROM PER_ALL_PEOPLE_F
WHERE PERSON_ID = p_person_id;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('This is an invalid person_id.
Get the Person Id by doing the following within Oracle Applications
1. Open the People Form
2. Find the person in question
3. Click on Help menu -> Diagnostics -> Examine
4. Click on the LOV to the right of field
5. Type the letter p
6. Double click on PERSON_ID
7. Record the VALUE that is returned
');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_person_id');






  -- Create global hash for parameters. Numbers required for the output order

debug('begin populate parameters hash table');
   g_parameters(l_index||'. Person ID') := p_person_id;
   l_index:=l_index+1;
   g_parameters(l_index||'. Maximum Rows to Display') := p_max_output_rows;
   l_index:=l_index+1;
   g_parameters(l_index||'. Debug Mode') := p_debug_mode;
   l_index:=l_index+1;
debug('end populate parameters hash table');



  l_key := g_parameters.first;
  -- Print parameters to the log
  print_log('Parameter Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_parameters(l_key));
    l_key := g_parameters.next(l_key);
  END LOOP;
  
  -- Create global hash of SQL token values

debug('begin populate sql tokens hash table');
   g_sql_tokens('##$$PERID$$##') := p_person_id;
debug('end populate sql tokens hash table');



  l_key := g_sql_tokens.first;
  -- Print token values to the log
 
  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;


EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN

   null;



debug('begin add_signature: OVERVIEW');
  add_signature(
      p_sig_id                 => 'OVERVIEW',
      p_sig_sql                => 'select ''Instance Name          = ''|| upper(instance_name) "Instance Summary" from v$instance
                                union
                  select ''Host Name              = ''|| host_name from v$instance
                  union
                                select ''Applications           = ''|| release_name from fnd_product_groups
                                union
                                select ''Instance Creation Date = '' || created from v$database
                                union
                                select ''Database               = '' || banner db_version from v$version where rownum = 1
                                union
                                                                                select ''Platform               = '' || SUBSTR(REPLACE(REPLACE(pcv1.product, ''TNS for ''), '':'' )||pcv2.status, 1, 80)
                    FROM product_component_version pcv1,product_component_version pcv2  WHERE UPPER(pcv1.product) LIKE ''%TNS%'' AND UPPER(pcv2.product) LIKE ''%ORACLE%'' AND ROWNUM = 1
                    union
                                                                                select ''Language               = '' || VALUE FROM V$NLS_PARAMETERS WHERE parameter = ''NLS_LANGUAGE''
                                                                                union
                                                                                select ''Character Set          = '' || VALUE FROM V$NLS_PARAMETERS WHERE parameter = ''NLS_CHARACTERSET''
                                union
                                SELECT ''Product status: PER/HR = '' || L.MEANING
                  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
                  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
                                AND (b.APPLICATION_ID = ''800'')
                                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
                                AND (L.LOOKUP_CODE = I.Status)
                                AND t.language = ''US''    AND l.language = ''US''
                                union
                  SELECT ''Product status: PAY    = '' || L.MEANING
                  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
                  WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
                    AND b.application_id = t.application_id
                                AND (b.APPLICATION_ID = ''801'')
                                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
                                AND (L.LOOKUP_CODE = I.Status)
                                AND t.language = ''US''    AND l.language = ''US''
                                union
                    SELECT ''Product status: BEN    = '' || L.MEANING
                  FROM   fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
                  WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
                    AND b.application_id = t.application_id
                                AND (b.APPLICATION_ID = ''805'')
                                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')
                                AND (L.LOOKUP_CODE = I.Status)
                                AND t.language = ''US''    AND l.language = ''US''
                    union
                                SELECT ''Multi Org              = '' || MULTI_ORG_FLAG FROM FND_PRODUCT_GROUPS
                                union
                  SELECT ''Multi Currency         = '' || MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS
                  union
                  SELECT ''RUP Level              = ''|| RUP_LEVEL || '' applied on '' || LAST_UPDATE_DATE from
(select ''12.2'' release , DECODE(bug_number
                  ,''17001123'', ''17001123 R12.HR_PF.C.delta.3''
                  , ''16169935'', ''16169935 R12.HR_PF.C.delta.2''
                  ,''14040707'', ''14040707 R12.HR_PF.C.delta.1''
                  ,''10124646'', ''10124646 R12.HR_PF.C''
                                  ,''17050005'', ''17050005 R12.HR_PF.C.Delta.4''
                                  ,''17909898'', ''17909898 R12.HR_PF.C.delta.5''
                  ,''19193000'', ''19193000 R12.HR_PF.C.Delta.6''
                   ) RUP_LEVEL , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(SELECT to_char(max(to_number(adb.bug_number)))  FROM ad_bugs adb
WHERE adb.bug_number in (''19193000'',''17909898'',''17050005'',''17001123'',''16169935'',''14040707'',''10124646''))
and rownum < 2
union
select ''12.1'' release ,DECODE(BUG_NUMBER
                  ,''20000288'',''20000288 R12.HR_PF.B.delta.8''
                                  ,''18004477'', ''18004477 R12.HR_PF.B.delta.7''
                                  ,''16000686'', ''16000686 R12.HR_PF.B.delta.6''
                  , ''13418800'', ''13418800 R12.HR_PF.B.delta.5''
                  ,''10281212'', ''10281212 R12.HR_PF.B.delta.4''
                  ,''9114911'', ''9114911 R12.HR_PF.B.delta.3''
                  ,''8337373'', ''8337373 R12.HR_PF.B.delta.2''
                  ,''7446767'', ''7446767 R12.HR_PF.B.delta.1''
                  ,''6603330'', ''6603330 R12.HR_PF.B''
                   ) RUP_LEVEL
                , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''20000288'',''18004477'',''16000686'',''13418800'',''10281212'',''9114911'',''8337373'', ''7446767'', ''6603330''))
and rownum < 2
union
SELECT ''12.0'' release ,DECODE(BUG_NUMBER
                  , ''16077077'', ''16077077 R12.HR_PF.A.delta.11''
                  , ''13774477'', ''13774477 R12.HR_PF.A.delta.10''
                  , ''10281209'', ''10281209 R12.HR_PF.A.delta.9''
                  , ''9301208'', ''9301208 R12.HR_PF.A.delta.8''
                  , ''7577660'', ''7577660 R12.HR_PF.A.delta.7''
                  , ''7004477'', ''7004477 R12.HR_PF.A.delta.6''
                  , ''6610000'', ''6610000 R12.HR_PF.A.delta.5''
                  , ''6494646'', ''6494646 R12.HR_PF.A.delta.4''
                  , ''6196269'', ''6196269 R12.HR_PF.A.delta.3''
                  , ''5997278'', ''5997278 R12.HR_PF.A.delta.2''
                  , ''5881943'', ''5881943 R12.HR_PF.A.delta.1''
                  , ''4719824'', ''4719824 R12.HR_PF.A'') RUP_LEVEL
                  , LAST_UPDATE_DATE
                  FROM ad_bugs
                  WHERE BUG_NUMBER =(select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''16077077'',''13774477'',''10281209'',''9301208'',''7577660'', ''7004477'', ''6610000'', ''6494646'', ''6196269'', ''5997278'', ''5881943'', ''4719824''))
and rownum < 2
union
SELECT ''11.5'' release ,DECODE(BUG_NUMBER
                           , ''2803988'', ''2803988 HRMS_PF.E''
                           , ''2968701'', ''2968701 HRMS_PF.F''
                           , ''3116666'', ''3116666 HRMS_PF.G''
                           , ''3233333'', ''3233333 HRMS_PF.H''
                           , ''3127777'', ''3127777 HRMS_PF.I''
                           , ''3333633'', ''3333633 HRMS_PF.J''
                           , ''3500000'', ''3500000 HRMS_PF.K''
                           , ''5055050'', ''5055050 HR_PF.K.RUP.1''
                           , ''5337777'', ''5337777 HR_PF.K.RUP.2''
                           , ''6699770'', ''6699770 HR_PF.K.RUP.3''
                           , ''7666111'', ''7666111 HR_PF.K.RUP.4''
                           , ''9062727'', ''9062727 HR_PF.K.RUP.5''
                           , ''10015566'', ''10015566 HR_PF.K.RUP.6''
                           , ''12807777'', ''12807777 HR_PF.K.RUP.7''
                           , ''14488556'', ''14488556 HR_PF.K.RUP.8''
                                                   ,''17774746'', ''17774746 HR_PF.K.RUP.9''
                            ) RUP_LEVEL
                        , LAST_UPDATE_DATE
                          FROM ad_bugs
                          WHERE BUG_NUMBER = (select to_char(max(to_number(bug_number))) from ad_bugs WHERE BUG_NUMBER IN (''2803988'',''2968701'',''3116666'',''3233333'',''3127777'',''3333633'',''3500000'',''5055050'',''5337777'',''6699770'',''7666111'',''9062727'',''10015566'',''12807777'',''14488556'',''17774746''))
and rownum < 2
)
where release in (select substr(release_name,1,4) from fnd_product_groups)
',
      p_title                  => 'Instance Summary',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Instance details',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('Y','N')
      );
   l_info.delete;
debug('end add_signature: OVERVIEW');



debug('begin add_signature: Designate_Beneficiaries');
  add_signature(
      p_sig_id                 => 'Designate_Beneficiaries',
      p_sig_sql                => 'SELECT pea.PRTT_ENRT_ACTN_ID ,pea.EFFECTIVE_START_DATE,pea.EFFECTIVE_END_DATE,pea.RQD_FLAG,pea.ACTN_TYP_ID,pen.PRTT_ENRT_RSLT_ID,pen.ENRT_CVG_STRT_DT,pen.ENRT_CVG_THRU_DT,pen.PERSON_ID,pen.PL_ID,pen.LER_ID,pen.BUSINESS_GROUP_ID
FROM     ben_prtt_enrt_actn_f pea,  ben_prtt_enrt_rslt_f pen, (SELECT business_group_id from per_all_people_f where person_id = ##$$PERID$$## and effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY'')) bgi
WHERE  pea.prtt_enrt_rslt_id = pen.prtt_enrt_rslt_id
AND        pea.per_in_ler_id = pen.per_in_ler_id
AND        prtt_enrt_rslt_stat_cd IS NULL
AND        actn_typ_id IN (
                SELECT actn_typ_id
                FROM     ben_actn_typ
                WHERE  type_cd = ''BNF''
                AND       business_group_id = bgi.business_group_id)
AND       pea.effective_end_date = ''31-DEC-4712''
AND       pen.effective_end_date = ''31-DEC-4712''
AND       pen.enrt_cvg_thru_dt = ''31-DEC-4712''
AND       pea.per_in_ler_id IN (
               SELECT per_in_ler_id
               FROM ben_per_in_ler pil,  ben_ler_f ler
               WHERE per_in_ler_stat_cd NOT IN(''BCKDT'',    ''VOIDD'')
              AND ler.typ_cd NOT IN(''IREC'',    ''COMP'',    ''GSP'',    ''ABS'')
              AND ler.ler_id = pil.ler_id)
AND      cmpltd_dt IS NULL
AND      pen.business_group_id = bgi.business_group_id
AND      pea.business_group_id = bgi.business_group_id',
      p_title                  => 'Action item related to Designate Beneficiaries that are left open',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are action item related to Designate Beneficiaries that are left open and you may expand it to include for other action items if necessary (for business groups of this person).',
      p_solution               => '',
      p_success_msg            => 'OK! No action item related to Designate Beneficiaries left open for business groups of this person.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Designate_Beneficiaries');



debug('begin add_signature: PROFILES');
  add_signature(
      p_sig_id                 => 'PROFILES',
      p_sig_sql                => 'select n.user_profile_option_name "Long Name",
      po.profile_option_name "Short Name",
       decode(to_char(pov.level_id),''10001'', ''Site'',''10002'', ''Application'',''10003'', ''Responsibility'',''10005'', ''Server'',''10006'', ''Org'',''10007'', ''Servresp'',''10004'', ''User'', ''???'') "Level" ,
       decode(to_char(pov.level_id),''10001'', ''Site'',
              ''10002'', nvl(app.application_short_name,to_char(pov.level_value)),''10003'', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              ''10005'', svr.node_name,''10006'', org.name,''10007'', pov.level_value ||'', ''|| pov.level_value_application_id ||'', ''|| pov.level_value2,
              ''10004'', nvl(usr.user_name,to_char(pov.level_value)),''???'') "Context", pov.profile_option_value "Profile Value"
        from   fnd_profile_options po,fnd_profile_option_values pov,fnd_profile_options_tl n,
               fnd_user usr,fnd_application app,fnd_responsibility_vl rsp,fnd_nodes svr,hr_operating_units org
        where  ((po.profile_option_name like ''BEN%'' and po.profile_option_name not like ''BEN_CWB%''  and po.profile_option_name not in(''BEN_COUNT_UNPAID_ABSENCE'',''BEN_LF_EVT_TRGR_PROFILE'' ))
		or n.user_profile_option_name in(''Disable Self-Service Personal'',''HR:Allow Use of Eligibility for Self Service Actions'',''HR:OAB New Benefits Model'',''HR:Run BENMNGLE When Processing a Self Service Action''))
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language=''US''
        order by n.user_profile_option_name,pov.level_id',
      p_title                  => 'Profiles',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No profile settings available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PROFILES');



debug('begin add_signature: HR_Invalid');
  add_signature(
      p_sig_id                 => 'HR_Invalid',
      p_sig_sql                => 'select a.owner,a.object_name,b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''   
    AND a.status = ''INVALID''
    and ROWNUM<2000
    order by a.object_name
',
      p_title                  => 'Invalid objects',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Invalid objects identified.',
      p_solution               => 'Advice: Please run adadmin -> Compile apps schema. If you still have invalids review steps from: [1325394.1] Troubleshooting Guide - invalid objects in the E-Business Suite Environment 11i and 12',
      p_success_msg            => 'No invalid objects.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: HR_Invalid');



debug('begin add_signature: Person_Details');
  add_signature(
      p_sig_id                 => 'Person_Details',
      p_sig_sql                => 'select
           ppf.effective_start_date
         , ppf.effective_end_date
         , ppf.full_name || '' ('' || ppf.person_id || '')'' "Full Name (Person Id)"
         , ppf.employee_number
         , ppf.applicant_number
         , ppf.npw_number
         , ppt.system_person_type || '' - '' || ppt.user_person_type|| '' ('' || ppt.person_type_id || '')'' "Person Type (ID)"
         , ppf.attribute_category
         , to_char(ppf.party_id) party_id
         , to_char(ppf.business_group_id) "Bus Group ID"
         , ppf.current_applicant_flag
         , ppf.current_emp_or_apl_flag
         , ppf.current_employee_flag
         , ppf.current_npw_flag
         , decode(to_char(ppf.SEX),''F'',''(F) Female'',''M'',''(M) Male'',''N'',''(N) Unspecified'',''U'',''(U) Unknown'') ppf_sex
         , ppf.email_address
         , ppf.start_date
         , ppf.original_date_of_hire
         , ppf.comment_id
         , to_char(ppf.object_version_number) object_version
         , decode(to_char(ppf.expense_check_send_to_address),''h'',''home'', ''o'',''office'',''p'',''provisional'') mailto
         , ppf.created_by
         , ppf.creation_date
         , ppf.last_updated_by
         , ppf.last_update_date
      from
           per_person_types         ppt
         , per_all_people_f         ppf
      where ppf.person_id = ##$$PERID$$##
        and ppf.person_type_id = ppt.person_type_id',
      p_title                  => 'Person Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Person details exists',
      p_solution               => '',
      p_success_msg            => 'This section lists the People details for each Effective Date Range for Person. Also lists the Person Name, Type and Party Id for each Effective Date Range',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Person_Details');



debug('begin add_signature: BEN_GATHER_SCHEMA');
  add_signature(
      p_sig_id                 => 'BEN_GATHER_SCHEMA',
      p_sig_sql                => 'SELECT substr(UPPER(ARGUMENT_TEXT),1,3) "Schema", ACTUAL_COMPLETION_DATE "Complation Date", ARGUMENT_TEXT
	FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R, FND_LOOKUP_VALUES STAT, FND_LOOKUP_VALUES PHAS
	WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID
	AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID
	AND PT.LANGUAGE = ''US'' and
	STAT.LOOKUP_CODE = R.STATUS_CODE AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE'' AND PHAS.LOOKUP_CODE = R.PHASE_CODE
	AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE'' and PHAS.language=''US'' and STAT.language=''US'' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
	AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE ''GATHER SCHEMA%''
	AND substr(UPPER(ARGUMENT_TEXT),1,3) in (''ALL'',''HR,'',''BEN'')
	and PHAS.MEANING=''Completed'' and STAT.MEANING=''Normal'' and ACTUAL_COMPLETION_DATE>sysdate-30
	ORDER BY 2 desc',
      p_title                  => 'Gather Schema Statistics',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Gather schema statistics never performed for ALL or BEN in last month',
      p_solution               => 'In order to schedule use [419728.1] Concurrent Processing - How To Gather Statistics On Oracle Applications Release 11i and/or Release 12 - Concurrent Process,Temp Tables, Manually',
      p_success_msg            => 'Gather schema statistics was performed for ALL or BEN in last month',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BEN_GATHER_SCHEMA');



debug('begin add_signature: PACKAGES');
  add_signature(
      p_sig_id                 => 'PACKAGES',
      p_sig_sql                => 'SELECT name,decode(type,''PACKAGE'', ''PACKAGE SPEC'',type),
ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 1)
               ))) ,
               ltrim(rtrim(substr(substr(text, instr(text,''Header: '')),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2),
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 3) -
               instr(substr(text, instr(text,''Header: '')), '' '', 1, 2)
               )))
				 FROM dba_source c
				 WHERE owner = ''APPS''
				 AND   name like ''BEN%''
				AND   type in (''PACKAGE BODY'',''PACKAGE'')
				AND   line = 2
				AND   text like ''%$Header%''
				order by name',
      p_title                  => 'Packages',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Packages',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PACKAGES');



debug('begin add_signature: DATABASE_INITIALIZATION_12');
  add_signature(
      p_sig_id                 => 'DATABASE_INITIALIZATION_12',
      p_sig_sql                => 'select name, nvl(value,''null'') "Value" from v$parameter order by name',
      p_title                  => 'Database Initialization Parameters',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Database Initialization Parameters',
      p_solution               => '',
      p_success_msg            => '<ul><li>If you have performance issue please ensure you have correct database initialization parameters as per [396009.1] Database Initialization Parameters for Oracle E-Business Suite Release 12</li>
<li>Use [174605.1] bde_chk_cbo.sql - EBS initialization parameters - Healthcheck</li>
<li>This will help you to identify the difference between actual values and required values. Verify that all Mandatory Parameters - MP are set correctly</li></ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DATABASE_INITIALIZATION_12');



debug('begin add_signature: DATABASE_INITIALIZATION_11i');
  add_signature(
      p_sig_id                 => 'DATABASE_INITIALIZATION_11i',
      p_sig_sql                => 'select name, nvl(value,''null'') "Value" from v$parameter order by name',
      p_title                  => 'Database Initialization Parameters',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Database Initialization Parameters',
      p_solution               => '',
      p_success_msg            => '<ul><li>If you have performance issue please ensure you have correct database initialization parameters as per [216205.1] Database Initialization Parameters for Oracle E-Business Suite Release 11i</li>
<li>Use [174605.1] bde_chk_cbo.sql - EBS initialization parameters - Healthcheck</li>
<li>This will help you to identify the difference between actual values and required values. Verify that all Mandatory Parameters - MP are set correctly</li></ul>',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DATABASE_INITIALIZATION_11i');



debug('begin add_signature: PRODUCTS_INSTALL');
  add_signature(
      p_sig_id                 => 'PRODUCTS_INSTALL',
      p_sig_sql                => 'select t.application_name application, b.application_short_name "Short Name"
		  , to_char(t.application_id) "Application ID"
		  , l.meaning Status
		  , decode(i.patch_level, null, ''11i.'' || b.application_short_name || ''.?'', i.patch_level) "Patch Level"
		  from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
		  where (t.application_id = i.application_id)
		  AND b.application_id = t.application_id
		  and (b.application_id in (''0'', ''50'', ''101'',''178'', ''203'', ''231'', ''275'', ''426'', ''453'', ''800'', ''801'',
			  ''802'', ''803'', ''804'', ''805'', ''808'', ''809'', ''810'', ''821'', ''8301'', ''8302'', ''8303'',''8401'',''8403''))
		  and (l.lookup_type = ''FND_PRODUCT_STATUS'')
		  and (l.lookup_code = i.status )
		  AND t.language = ''US'' AND l.language = ''US'' order by upper(t.application_name)',
      p_title                  => 'Products Install Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No product installed.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PRODUCTS_INSTALL');





debug('begin add_signature: FKPLANS');
  add_signature(
      p_sig_id                 => 'FKPLANS',
      p_sig_sql                => 'select pl.PL_ID,pl.EFFECTIVE_START_DATE,pl.EFFECTIVE_END_DATE,pl.NAME 
from ben_pl_f pl, ben_plip_f prgpl
where pl.pl_id=prgpl.pl_id
and prgpl.pgm_id= ##$$FK1$$##
AND sysdate between pl.effective_start_date and pl.effective_end_date
AND sysdate between prgpl.effective_start_date and prgpl.effective_end_date
order by pl.PL_ID
',
      p_title                  => 'Plans in program',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No plan in this program',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: FKPLANS');

debug('begin add_signature: PROGRAM');
  add_signature(
      p_sig_id                 => 'PROGRAM',
      p_sig_sql                => 'select PGM_ID "##$$FK1$$##",PGM_ID,EFFECTIVE_START_DATE,EFFECTIVE_END_DATE,NAME,business_group_id from ben_pgm_f where business_group_id in (SELECT business_group_id from per_all_people_f where person_id = ##$$PERID$$## and effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY''))
AND sysdate between effective_start_date and effective_end_date
order by PGM_ID',
      p_title                  => 'Programs / Plans',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No program available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('FKPLANS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PROGRAM');



debug('begin add_signature: Enrollments_Overridden');
  add_signature(
      p_sig_id                 => 'Enrollments_Overridden',
      p_sig_sql                => 'Select  pen.sspndd_flag,
            pen.enrt_ovridn_flag, 
            pen.enrt_ovrid_thru_dt, 
            pen.prtt_enrt_rslt_stat_cd, 
            pen.enrt_cvg_thru_dt, 
            pen.effective_start_date, 
            pen.effective_end_date, 
            pen.enrt_cvg_strt_dt, 
            pen.per_in_ler_id, 
            pen.pl_id, pl.name, 
            pen.oipl_id, 
            pen.person_id, 
            pen.prtt_enrt_rslt_id, employee_number, full_name 
from    ben_prtt_enrt_rslt_f pen, per_all_people_f pap, ben_pl_f pl 
where enrt_ovridn_flag = ''Y'' 
and     enrt_ovrid_thru_dt is null 
and     pen.person_id = pap.person_id 
and     pen.pl_id = pl.pl_id 
and     sysdate between pap.effective_start_date and pap.effective_end_date 
and     sysdate between pl.effective_start_date and pl.effective_end_date
',
      p_title                  => 'Enrollments which are overridden and have no Override Thru Date',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are enrollments overridden and have no Override Thru Date.',
      p_solution               => '',
      p_success_msg            => 'OK! No enrollments overridden and with no Override Thru Date.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Enrollments_Overridden');



debug('begin add_signature: JAVA');
  add_signature(
      p_sig_id                 => 'JAVA',
      p_sig_sql                => 'select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=''BEN'' and upper(filename) like upper(''%.class'')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2',
      p_title                  => 'Java Class',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Java Class',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: JAVA');



debug('begin add_signature: PERSON_ISSUE1');
  add_signature(
      p_sig_id                 => 'PERSON_ISSUE1',
      p_sig_sql                => 'select person_id
          ,effective_start_date
		  ,effective_end_date
		  ,full_name || '' ('' || person_id || '')'' "Full Name (Person Id)"
		  ,employee_number
    from  per_all_people_f
    where person_id = ##$$PERID$$##
    and   not exists (
              select person_id
			        ,count(to_char(effective_end_date,''YYYYMMDD'')) l_end_date
 			  from  per_all_people_f where person_id = ##$$PERID$$##
			  and   to_char(effective_end_date,''yyyymmdd'') = ''47121231''
              group by Person_id
              having count(to_char(effective_end_date,''YYYYMMDD'')) = 1
			union
			  select person_id, count(to_char(effective_end_date,''YYYYMMDD'')) l_end_date
              from   per_all_people_f
			  where  person_id = ##$$PERID$$##
              and    to_char(effective_end_date,''yyyymmdd'') = ''47121231''
              group by Person_id
              having count(to_char(effective_end_date,''YYYYMMDD'')) > 1)',
      p_title                  => 'Person Record - Issue with Effective End Date',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'This section lists the People details for which there data corruption with no record end dating with 31st Dec 4712 or two records with Effective end date as 31st Dec 4712',
      p_solution               => 'Correct the Dates for the Person',
      p_success_msg            => 'No person with this issue of missing person with end dating 31st Dec 4712 or multiple Effective end date with 31s Dec 4712.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PERSON_ISSUE1');



debug('begin add_signature: Maintain_Participant_Eligibility_Issue');
  add_signature(
      p_sig_id                 => 'Maintain_Participant_Eligibility_Issue',
      p_sig_sql                => 'SELECT substr(UPPER(ARGUMENT_TEXT),1,3) "Schema", ACTUAL_COMPLETION_DATE "Complation Date", ARGUMENT_TEXT
	FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R, FND_LOOKUP_VALUES STAT, FND_LOOKUP_VALUES PHAS
	WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID
	AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID
	AND PT.LANGUAGE = ''US'' and
	STAT.LOOKUP_CODE = R.STATUS_CODE AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE'' AND PHAS.LOOKUP_CODE = R.PHASE_CODE
	AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE'' and PHAS.language=''US'' and STAT.language=''US'' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
	AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE ''MAINTAIN PARTICIPANT%''
	and PHAS.MEANING=''Completed'' and STAT.MEANING=''Normal'' and ACTUAL_COMPLETION_DATE>sysdate-30
	ORDER BY 2 desc',
      p_title                  => 'Maintain Participant Eligibility last month',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Maintain Participant Eligibility was not performed in last month.',
      p_solution               => 'Please schedule Maintain Participant Eligibility.<br>
Review [259243.1] Oracle Standard Benefits (OSB) Processes: What are They? How Often Should They be Run?',
      p_success_msg            => 'Maintain Participant Eligibility was performed in last month.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Maintain_Participant_Eligibility_Issue');



debug('begin add_signature: BENEFITS_NOT_INSTALLED');
  add_signature(
      p_sig_id                 => 'BENEFITS_NOT_INSTALLED',
      p_sig_sql                => 'select t.application_name application, b.application_short_name "Short Name"
				  , to_char(t.application_id) "Application ID"
				  , l.meaning Status
				  , decode(i.patch_level, null, ''11i.'' || b.application_short_name || ''.?'', i.patch_level) "Patch Level"
				  from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
				  where (t.application_id = i.application_id)
				  AND b.application_id = t.application_id
				  and b.application_id = ''805'' and l.meaning =''Not installed''
				  and (l.lookup_type = ''FND_PRODUCT_STATUS'')
				  and (l.lookup_code = i.status )
				  AND t.language = ''US'' AND l.language = ''US'' order by upper(t.application_name)',
      p_title                  => 'Advanced Benefits Not Installed',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Advanced Benefits is not installed! You cannot use Benefits!',
      p_solution               => '<ul><li>In order to license use Oracle Application Manager (OAM) and select Site Map -> Administration tab -> License Manager</li>
<li>After use adadmin - Generate Application Files menu in order to generate all files for the new licensed product.</li>
</ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BENEFITS_NOT_INSTALLED');



debug('begin add_signature: Discrepancies');
  add_signature(
      p_sig_id                 => 'Discrepancies',
      p_sig_sql                => 'select count(1) "Discrepancies"
     from sys.obj$ do, sys.dependency$ d, sys.obj$ po
     where p_obj#=po.obj#(+)
     and d_obj#=do.obj#
     and do.status=1
     and po.status=1
     and po.stime!=p_timestamp
     and do.type# not in (28,29,30)
     and po.type# not in (28,29,30)',
      p_title                  => 'Potential database errors ORA-03113 or ORA-01041',
      p_fail_condition         => '[Discrepancies] > [0]',
      p_problem_descr          => 'You have dependency timestamp discrepancies between the database objects. This may cause intermittent errors like: ORA-03113: end-of-file on communication channel 
ORA-01041: internal error',
      p_solution               => 'Please follow [1303973.1]  ORA-03113: end-of-file on communication channel',
      p_success_msg            => 'No discrepancy found.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Discrepancies');



debug('begin add_signature: PLANS_NOT_IN_PROGRAM');
  add_signature(
      p_sig_id                 => 'PLANS_NOT_IN_PROGRAM',
      p_sig_sql                => 'select PL_ID,EFFECTIVE_START_DATE,EFFECTIVE_END_DATE,NAME from ben_pl_f where business_group_id in (SELECT business_group_id from per_all_people_f where person_id = ##$$PERID$$## and effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY''))
and pl_id not in (select pl_id from ben_plip_f)
AND sysdate between effective_start_date and effective_end_date',
      p_title                  => 'Plans Not in Programs',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No plan available.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PLANS_NOT_IN_PROGRAM');



debug('begin add_signature: BENEFIT_SHARED');
  add_signature(
      p_sig_id                 => 'BENEFIT_SHARED',
      p_sig_sql                => 'select t.application_name application, b.application_short_name "Short Name"
				  , to_char(t.application_id) "Application ID"
				  , l.meaning Status
				  , decode(i.patch_level, null, ''11i.'' || b.application_short_name || ''.?'', i.patch_level) "Patch Level"
				  from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
				  where (t.application_id = i.application_id)
				  AND b.application_id = t.application_id
				  and b.application_id = ''805'' and l.meaning =''Shared''
				  and (l.lookup_type = ''FND_PRODUCT_STATUS'')
				  and (l.lookup_code = i.status )
				  AND t.language = ''US'' AND l.language = ''US'' order by upper(t.application_name)',
      p_title                  => 'Advance Benefits Shared',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Advanced Benefits is in shared mode! You can use only unrestricted event!',
      p_solution               => '<ul><li>In order to license use Oracle Application Manager (OAM) and select Site Map -> Administration tab -> License Manager</li>
<li>After use adadmin - Generate Application Files menu in order to generate all files for the new licensed product.</li>
</ul>',
      p_success_msg            => '',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BENEFIT_SHARED');



debug('begin add_signature: DISABLED_TRIGGERS');
  add_signature(
      p_sig_id                 => 'DISABLED_TRIGGERS',
      p_sig_sql                => 'select owner, table_name, trigger_name
      from dba_triggers
      where status = ''DISABLED''
      and table_owner in (''HR'',''HXT'',''HXC'',''HRI'',''BEN'')
      and (table_name like ''BEN%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'')
      order by 1, 2, 3',
      p_title                  => 'Disabled triggers',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Disabled triggers',
      p_solution               => 'In order to re-enable use command: alter trigger trigger_name enable
Disabled trigger(s) related to alert (ALR_) are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.',
      p_success_msg            => 'No disabled trigger.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DISABLED_TRIGGERS');



debug('begin add_signature: Recalculate_Participant_Values_Issue');
  add_signature(
      p_sig_id                 => 'Recalculate_Participant_Values_Issue',
      p_sig_sql                => 'SELECT substr(UPPER(ARGUMENT_TEXT),1,3) "Schema", ACTUAL_COMPLETION_DATE "Complation Date", ARGUMENT_TEXT
	FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R, FND_LOOKUP_VALUES STAT, FND_LOOKUP_VALUES PHAS
	WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID
	AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID
	AND PT.LANGUAGE = ''US'' and
	STAT.LOOKUP_CODE = R.STATUS_CODE AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE'' AND PHAS.LOOKUP_CODE = R.PHASE_CODE
	AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE'' and PHAS.language=''US'' and STAT.language=''US'' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
	AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE ''RECALCULATE PARTICIPANT%''	
	and PHAS.MEANING=''Completed'' and STAT.MEANING=''Normal'' and ACTUAL_COMPLETION_DATE>sysdate-30
	ORDER BY 2 desc


',
      p_title                  => 'Recalculate Participant Values in last month',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Recalculate Participant Values was not performed in last month.',
      p_solution               => 'Please schedule Recalculate Participant Values every month.
Review [259243.1] Oracle Standard Benefits (OSB) Processes: What are They? How Often Should They be Run?',
      p_success_msg            => 'Recalculate Participant Values was performed in last month.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Recalculate_Participant_Values_Issue');



debug('begin add_signature: Enrollment_Rates_Overridden');
  add_signature(
      p_sig_id                 => 'Enrollment_Rates_Overridden',
      p_sig_sql                => 'Select   prv.rt_ovridn_flag ,
             prv.rt_ovridn_thru_dt,
             prv.rt_strt_dt,
             prv.rt_end_dt,
             prv.rt_val,
             pen.prtt_enrt_rslt_stat_cd, 
             pen.enrt_cvg_strt_dt,
             pen.enrt_cvg_thru_dt, 
             pen.effective_start_date, 
             pen.effective_end_date, 
             pen.per_in_ler_id, 
             pen.pl_id, pl.name, 
             pen.oipl_id, 
             pen.person_id, 
             pen.prtt_enrt_rslt_id, employee_number, full_name 
from      ben_prtt_enrt_rslt_f pen, per_all_people_f pap, ben_pl_f pl, ben_prtt_rt_val prv
where   prv.rt_ovridn_flag = ''Y'' 
and       prv.rt_ovridn_thru_dt is null 
and       pen.person_id = pap.person_id 
and       pen.pl_id = pl.pl_id 
and       pen.prtt_enrt_rslt_id = prv.prtt_enrt_rslt_id
and       sysdate between pap.effective_start_date and pap.effective_end_date 
and       sysdate between pl.effective_start_date and pl.effective_end_date',
      p_title                  => 'Enrollment rates which are overridden and have no Override Thru Date',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are enrollment rates which are overridden and have no Override Thru Date. ',
      p_solution               => '',
      p_success_msg            => 'OK! No enrollment rates overridden and with no Override Thru Date.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: Enrollment_Rates_Overridden');



debug('begin add_signature: PERSON_ISSUE2');
  add_signature(
      p_sig_id                 => 'PERSON_ISSUE2',
      p_sig_sql                => 'select person_id
          ,effective_start_date
		  ,effective_end_date
		  ,full_name || '' ('' || person_id || '')'' "Full Name (Person Id)", employee_number
    from  per_all_people_f c
    where person_id = ##$$PERID$$##
    and exists ( select a.person_id,a.effective_start_date, a.effective_end_date,count(a.person_id)
	             from per_all_people_f a, per_all_people_f b
                 where a.person_id = b.person_id
                 and a.person_id = c.person_id
                 and trunc(a.effective_end_date) >= trunc(b.effective_start_date+1)
                 and trunc(a.effective_end_date) <= trunc(b.effective_end_date)
                 group by  a.person_id,a.effective_start_date, a.effective_end_date
                 having count(a.person_id) > 1
				)
	union
    select person_id
          ,effective_start_date
		  ,effective_end_date
		  ,full_name || '' ('' || person_id || '')'' "Full Name (Person Id)", employee_number
    from  per_all_people_f e
    where person_id = ##$$PERID$$##
	AND NOT EXISTS (SELECT person_id
                    FROM per_all_people_f c
                    WHERE person_id = e.person_id
                    AND e.person_id = c.person_id
                    AND (SELECT COUNT(*)
                         FROM
                          (SELECT a.person_id,
                                  TO_CHAR(TRUNC(a.effective_start_date),''yyyymmdd''),
                                  TO_CHAR(TRUNC(a.effective_end_date),''yyyymmdd''),
                                  b.effective_start_date,
                                  b.effective_end_date,
                                  COUNT(a.person_id)
                          FROM per_all_people_f a,
                               per_all_people_f b
                          WHERE a.person_id  = b.person_id
                          AND a.person_id    = ##$$PERID$$##
                          AND TRUNC(a.effective_start_date)-1 = TRUNC(b.effective_end_date)
                          AND a.effective_start_date          > b.effective_end_date
                          GROUP BY a.person_id,
                                TO_CHAR(TRUNC(a.effective_start_date),''yyyymmdd''),
                                TO_CHAR(TRUNC(a.effective_end_date),''yyyymmdd''),
                                b.effective_start_date,
                                b.effective_end_date
                          HAVING COUNT(a.person_id) =1
                         ) )  =  (SELECT COUNT(person_id)-1
                                  FROM per_all_people_f d
                                  WHERE d.person_id = c.person_id )
                   )',
      p_title                  => 'Person Record - Overlap or Gap in effective dates',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'This section lists the People details for which there data corruption with <br> 1) Person record with overlapping dates <br> 2) Person Record with gap in effective dates',
      p_solution               => 'Correct the Dates for the Person',
      p_success_msg            => 'No person with this issue with overlapping effective dates or gap in effective dates.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PERSON_ISSUE2');



debug('begin add_signature: FORMS');
  add_signature(
      p_sig_id                 => 'FORMS',
      p_sig_sql                => '	

select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=''BEN'' and upper(filename) like upper(''%.fmb'') and subdir like ''forms%US''
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2',
      p_title                  => 'Forms',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Forms version',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: FORMS');



debug('begin add_signature: LANGUAGES_INSTALLED_DETAILS');
  add_signature(
      p_sig_id                 => 'LANGUAGES_INSTALLED_DETAILS',
      p_sig_sql                => 'SELECT rpad(language_code, 30, '' '') "Language Code             ",
           rpad(decode(INSTALLED_FLAG ,''B'',''Base Installed Language'',''I'',''Additional Installed Language'',''D'',''Not Installed''), 30, '' '') "          Type          ",
           rpad(nls_language, 30, '' '') "     Language     ",
           rpad(nls_territory, 30, '' '') "     Territory    "
      FROM FND_LANGUAGES
      where INSTALLED_FLAG in (''B'',''I'')
      order by LANGUAGE_CODE',
      p_title                  => 'Languages installed',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'This section lists Languages Installed',
      p_solution               => '',
      p_success_msg            => 'Advice: Periodically check if you NLS level is in sync with US level:<br>
Follow [252422.1] Requesting Translation Synchronization Patches<br>
-> this will synchronize your languages with actual US level<br>
Note! This is just an advice. This does not mean your NLS is not synchronized! Follow this step ONLY if you have translation issues.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: LANGUAGES_INSTALLED_DETAILS');



debug('begin add_signature: PERSON_ISSUE3');
  add_signature(
      p_sig_id                 => 'PERSON_ISSUE3',
      p_sig_sql                => 'select person_id
          ,effective_start_date
		  ,effective_end_date
		  ,full_name || '' ('' || person_id || '')'' "Full Name (Person Id)"
		  ,employee_number
	from per_all_people_f
	where person_id = ##$$PERID$$##
	and   date_of_birth is null',
      p_title                  => 'Person Record - Missing Date of Birth',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Date of Birth missing for person. An Employee cannot be entered on a Payroll without a Date of Birth.',
      p_solution               => '',
      p_success_msg            => 'Person is with Date of Birth data.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PERSON_ISSUE3');





debug('begin add_signature: FKPLANS_WITH_OPTIONS');
  add_signature(
      p_sig_id                 => 'FKPLANS_WITH_OPTIONS',
      p_sig_sql                => 'select opt.OPT_ID,NAME
from ben_oipl_f optc, ben_opt_f opt
where optc.opt_id=opt.opt_id
and optc.pl_id= ##$$FK3$$##
AND sysdate between optc.effective_start_date and optc.effective_end_date
AND sysdate between opt.effective_start_date and opt.effective_end_date
order by opt.OPT_ID

   ',
      p_title                  => 'Options',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No option for this plan.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: FKPLANS_WITH_OPTIONS');

debug('begin add_signature: PLANANDPLANTYPE');
  add_signature(
      p_sig_id                 => 'PLANANDPLANTYPE',
      p_sig_sql                => 'select pl.PL_ID "##$$FK3$$##",pl.PL_ID,pl.EFFECTIVE_START_DATE,pl.EFFECTIVE_END_DATE,pl.NAME "Plan Name",type.NAME "Plan Type"
from ben_pl_f pl, ben_pl_typ_f type
where pl.pl_typ_id=type.pl_typ_id
AND pl.business_group_id in (SELECT business_group_id from per_all_people_f where person_id = ##$$PERID$$## and effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY''))
AND sysdate between pl.effective_start_date and pl.effective_end_date
AND sysdate between type.effective_start_date and type.effective_end_date',
      p_title                  => 'Plans with Type / Options',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No plan available',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('FKPLANS_WITH_OPTIONS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PLANANDPLANTYPE');



debug('begin add_signature: PAY_ACTION_PARAMETERS');
  add_signature(
      p_sig_id                 => 'PAY_ACTION_PARAMETERS',
      p_sig_sql                => 'select parameter_name, parameter_value
from pay_action_parameters
order by parameter_name ',
      p_title                  => 'PAY Action Parameters',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'PAY Action Parameters',
      p_solution               => '',
      p_success_msg            => 'General performance checks are available in:<br>
[251981.1] Benefits Performance Check<br>
[169935.1] Troubleshooting Oracle Applications Performance Issues',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PAY_ACTION_PARAMETERS');



debug('begin add_signature: REPORTS');
  add_signature(
      p_sig_id                 => 'REPORTS',
      p_sig_sql                => 'select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=''BEN'' and upper(filename) like upper(''%.rdf'') and subdir like ''rep%US''
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2',
      p_title                  => 'Reports',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Reports',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: REPORTS');



debug('begin add_signature: LDT');
  add_signature(
      p_sig_id                 => 'LDT',
      p_sig_sql                => '	

select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=''BEN'' and upper(filename) like upper(''%.ldt'') and subdir like ''%US''
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2',
      p_title                  => 'LDT',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'LDT',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: LDT');



debug('begin add_signature: CONTACT_DETAILS');
  add_signature(
      p_sig_id                 => 'CONTACT_DETAILS',
      p_sig_sql                => 'select ppf.effective_start_date
           , ppf.effective_end_date
           , ppf.full_name
           , con.contact_person_id
           , c.meaning
           , con.primary_contact_flag
           , con.dependent_flag
           , con.beneficiary_flag
           , con.rltd_per_rsds_w_dsgntr_flag
           , con.personal_flag
           , con.third_party_pay_flag
           , con.created_by
           , CON.LAST_UPDATED_BY
      from  hr_lookups c,
            per_contact_relationships con,
            per_all_people_f ppf
      where c.lookup_type = ''CONTACT''
      and   c.lookup_code = con.contact_type
      and   con.contact_person_id = ppf.person_id
      and   con.person_id = ##$$PERID$$##',
      p_title                  => 'Contact Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Contact details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists Employee Contact details.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CONTACT_DETAILS');



debug('begin add_signature: ODF');
  add_signature(
      p_sig_id                 => 'ODF',
      p_sig_sql                => 'select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=''BEN'' and upper(filename) like upper(''%.odf'')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2',
      p_title                  => 'ODF',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'ODF',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ODF');



debug('begin add_signature: ASSIGNMENT_DETAILS');
  add_signature(
      p_sig_id                 => 'ASSIGNMENT_DETAILS',
      p_sig_sql                => 'select
          to_char(paf.assignment_id) assignment_id
        , paf.assignment_number
        , paf.effective_start_date
        , paf.effective_end_date
        , hr_general.decode_lookup(''YES_NO'',paf.primary_flag) primary_flag
        , paf.assignment_sequence
        , decode(to_char(paf.assignment_type),''A'',''Applicant'',''B'',''Benefits'',''C'',''Contingent'',''E'',''Employee'')
          || '' ('' || paf.assignment_status_type_id || '')''     Asg_Type
        , hr_general.decode_lookup(''PER_ASS_SYS_STATUS'',past.per_system_status)  status
        , to_char(paf.organization_id) organization_id
        , to_char(paf.location_id) location_id
        , to_char(paf.job_id) job_id
        , to_char(paf.position_id) position_id
        , to_char(paf.grade_id) grade_id
        , to_char(paf.period_of_service_id) period_of_service_id
        , to_char(paf.business_group_id) business_group_id
        , to_char(paf.pay_basis_id) pay_basis_id
        , to_char(paf.payroll_id) payroll_id
        , to_char(paf.supervisor_id) supervisor_id
        , to_char(paf.vacancy_id) vacancy_id
        , to_char(paf.object_version_number) object_version_number
        , paf.projected_assignment_end
        , paf.created_by
        , paf.creation_date
        , paf.last_updated_by
        , paf.last_update_date
		    , paf.special_ceiling_step_id
      from per_assignments_f          paf
        , per_assignment_status_types past
      where paf.person_id = ##$$PERID$$##
      and past.assignment_status_type_id = paf.assignment_status_type_id
      order by assignment_id, effective_start_date',
      p_title                  => 'Assignment Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Assignment details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Assignment details for each Effective Date Range.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ASSIGNMENT_DETAILS');



debug('begin add_signature: SQLV');
  add_signature(
      p_sig_id                 => 'SQLV',
      p_sig_sql                => 'select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=''BEN'' and upper(filename) like upper(''%.sql'')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2',
      p_title                  => 'SQL',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'SQL versions',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SQLV');



debug('begin add_signature: ASSIGNMENT_ISSUE1');
  add_signature(
      p_sig_id                 => 'ASSIGNMENT_ISSUE1',
      p_sig_sql                => 'select a.assignment_id,
           a.assignment_number,
		   a.person_id,
		   a.effective_start_date,
		   a.effective_end_date,
		   a.primary_flag
    from per_all_assignments_f a, per_all_assignments_f b
    where a.assignment_id <> b.assignment_id
    and   (a.effective_start_date between b.effective_start_date and b.effective_end_date
           or
           a.effective_end_date between b.effective_start_date and b.effective_end_date)
    and   a.primary_flag = ''Y'' and b.primary_flag = ''Y''
    and   a.person_id = b.person_id
    and   a.person_id = ##$$PERID$$##',
      p_title                  => 'Assignments Issue - Primary Flag',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Assignment with two Primary Assignments active at the same point of time.',
      p_solution               => '',
      p_success_msg            => 'No Assignment with multiple Primary Flag.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ASSIGNMENT_ISSUE1');



debug('begin add_signature: ASSIGNMENT_ISSUE2');
  add_signature(
      p_sig_id                 => 'ASSIGNMENT_ISSUE2',
      p_sig_sql                => 'select c.assignment_id,
           c.assignment_number,
		   c.person_id,
		   c.effective_start_date,
		   c.effective_end_date,
		   c.assignment_status_type_id,
		   d.user_status
    from per_all_assignments_f c, per_assignment_status_types  d
    where c.person_id = ##$$PERID$$##
    and c.assignment_status_type_id = d.assignment_status_type_id
    and c.Primary_flag = ''Y''
    and c.assignment_status_type_id = 1
    and exists (select a.person_id,a.effective_start_date, a.effective_end_date,count(a.person_id)
	             from per_all_assignments_f a, per_all_assignments_f b
                 where a.person_id = b.person_id
                 and a.person_id = c.person_id
                 and trunc(a.effective_end_date) >= trunc(b.effective_start_date+1)
                 and trunc(a.effective_end_date) <= trunc(b.effective_end_date)
                 and a.assignment_id = b.assignment_id
                 and a.assignment_id = c.assignment_id
                 group by  a.person_id,a.effective_start_date, a.effective_end_date
                 having count(a.person_id) > 1
            )
	',
      p_title                  => 'Assignments Issue - Overlap effective date',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Assignment with Primary Active Assignment with overlap of effective date.',
      p_solution               => '',
      p_success_msg            => 'No Assignment with Overlap of effective date.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ASSIGNMENT_ISSUE2');



debug('begin add_signature: ASSIGNMENT_ISSUE3');
  add_signature(
      p_sig_id                 => 'ASSIGNMENT_ISSUE3',
      p_sig_sql                => 'SELECT distinct papf.person_id
          ,paaf.assignment_id
          ,paaf.effective_start_date
          ,paaf.effective_end_date
          ,decode(to_char(paaf.assignment_type),''A'',''Applicant'',''B'',''Benefits'',''C'',''Contingent'',''E'',''Employee'')
                  || '' ('' || paaf.assignment_status_type_id || '')''     Asg_Type
          ,HR_GENERAL.DECODE_LOOKUP(''PER_ASS_SYS_STATUS'',past.per_system_status)  Status
      FROM apps.per_all_people_f papf,
           apps.per_all_assignments_f  paaf,
           apps.per_assignment_status_types past
      WHERE papf.person_id = ##$$PERID$$##
      AND paaf.person_id = papf.person_id
      AND paaf.primary_flag = ''Y''
      AND(paaf.effective_start_date BETWEEN papf.effective_start_date AND papf.effective_end_date
      OR  paaf.effective_end_date BETWEEN papf.effective_start_date AND papf.effective_end_date)
      AND past.assignment_status_type_id = paaf.assignment_status_type_id
      AND paaf.person_id IN
            (SELECT a.person_id
             FROM apps.per_all_assignments_f a
             WHERE a.primary_flag = ''Y''
             AND exists
                (SELECT asub.assignment_id
                 FROM apps.per_all_assignments_f asub
                 WHERE asub.primary_flag = ''Y''
                 and asub.person_id = a.person_id
                 AND asub.effective_start_date > a.effective_end_date)
             AND NOT exists
                (SELECT asub1.assignment_id
                 FROM apps.per_all_assignments_f asub1
                 WHERE asub1.primary_flag = ''Y''
                 AND asub1.person_id = a.person_id
                 AND asub1.effective_start_date = a.effective_end_date + 1))
      ORDER BY 1, 2, 3',
      p_title                  => 'Assignments Issue - Gaps in Primary Assignment',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Assignment records with Gap in Primary Assignment.',
      p_solution               => '',
      p_success_msg            => 'No gaps found in Primary Assignment.',
      p_print_condition        => nvl('FAILURE','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ASSIGNMENT_ISSUE3');



debug('begin add_signature: ASG_ACT_DETAILS');
  add_signature(
      p_sig_id                 => 'ASG_ACT_DETAILS',
      p_sig_sql                => 'SELECT DISTINCT
		( SELECT DISTINCT fcp.user_concurrent_program_name
		  FROM fnd_concurrent_programs_tl fcp
		  WHERE source_lang = ''US''
		  AND fcp.concurrent_program_id =
			  ( SELECT DISTINCT fcr.concurrent_program_id
			    FROM fnd_concurrent_requests fcr
			    WHERE fcr.request_id =
					  ( SELECT DISTINCT ppa.request_id
					    FROM pay_payroll_actions ppa
					    WHERE ppa.payroll_action_id = pact.payroll_action_id))) conc_prog_name
	  ,substrb (act.assignment_id, 1, 9) assign_id
	  ,pact.effective_date eff_date
	  ,decode(pact.action_type
			  ,''A'',''Cash''
			  ,''B'',''Bal Adj''
			  ,''C'',''Costing''
			  ,''CP'',''Cost Pay''
			  ,''H'',''Cheq writ''
			  ,''L'',''Retro by Ele''
			  ,''M'',''Mag txr''
			  ,''O'',''Retropay''
			  ,''P'',''Prepay''
			  ,''Q'',''Quickpay''
			  ,''R'',''Payroll Run''
			  ,''S'',''Retro Cost''
			  ,''T'',''Tfr to GL''
			  ,''U'',''Quick Prepay''
			  ,''V'',''Reversal''
			  ,''X'',''Mag Rept'') act_type
	  ,substrb (act.action_sequence, 1, 6) act_seq
	  ,substrb (act.assignment_action_id, 1, 10) assign_act_id
	  ,substrb (act.source_action_id, 1, 9) source
	  ,substrb (act.action_status, 1, 7) ass_act_sts
	  ,substrb (pact.action_status, 1, 8) pay_act_sts
	  ,substrb (pact.payroll_action_id, 1, 10) pay_act_id
	  ,pact.start_date
	  ,pact.end_date
	  ,pact.legislative_parameters leg_parameters
	  ,pact.creation_date
	 FROM pay_payroll_actions pact
		,pay_assignment_actions act
	 	,per_all_assignments_f paaf
	 WHERE act.payroll_action_id = pact.payroll_action_id
	 AND act.assignment_id = paaf.assignment_id
	 AND paaf.person_id = ##$$PERID$$##
	 ORDER BY assign_id, eff_date DESC, assign_act_id DESC',
      p_title                  => 'Assignment Action Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Assignment Action details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Assignment Action details.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ASG_ACT_DETAILS');



debug('begin add_signature: GRADE_DETAILS');
  add_signature(
      p_sig_id                 => 'GRADE_DETAILS',
      p_sig_sql                => 'select distinct
        substrb(pspf.effective_start_date,1,11) eff_start_date,
        substrb(pspf.effective_end_date,1,11) eff_end_date,
        substrb(pg.grade_id,1,9) grade_id,
        substrb(pg.name,1, 20) grade_name,
        substrb(pps.name,1,20) spine_name,
        substrb(pspf.step_id,1,7) step_id,
        substrb(psp.spinal_point,1,12) spinal_point,
        substrb(pspsf.sequence,1,4) step
    from
        per_all_people_f ppf,
        per_all_assignments_f paf,
        per_spinal_point_placements_f pspf,
        per_spinal_point_steps_f pspsf,
        per_grade_spines_f pgs,
        per_grades pg,
        per_spinal_points psp,
        per_parent_spines pps
    where pg.grade_id =  paf.grade_id
    and ppf.person_id = ##$$PERID$$##
    and ppf.person_id = paf.person_id
    and paf.assignment_id = pspf.assignment_id
    and pgs.parent_spine_id = pspf.parent_spine_id
    and pg.grade_id = pgs.grade_id
    and pps.parent_spine_id = pgs.parent_spine_id
    and pspsf.spinal_point_id = psp.spinal_point_id
    and pspsf.spinal_point_id = psp.spinal_point_id
    and pspsf.grade_spine_id = pgs.grade_spine_id
    and pspsf.step_id = pspf.step_id
    order by eff_start_date',
      p_title                  => 'Grade Step Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'No Grade Step details exists',
      p_solution               => '',
      p_success_msg            => 'This section lists the Grade Step details',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: GRADE_DETAILS');



debug('begin add_signature: PPL_REPORT_DETAILS');
  add_signature(
      p_sig_id                 => 'PPL_REPORT_DETAILS',
      p_sig_sql                => 'select distinct
       full_name,
       employee_number,
       person_id
    from per_all_people_f
    where person_id in (
           select paf.person_id
           from  per_all_assignments_f paf
           start with paf.person_id = ##$$PERID$$##
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           connect by PRIOR paf.person_id = paf.supervisor_id
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           minus
           select paf.person_id
           from  per_all_assignments_f paf
           where paf.person_id =  ##$$PERID$$## )
           and sysdate between effective_start_date and effective_end_date',
      p_title                  => 'People Reporting To This Person',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'No People reporting to this person exists',
      p_solution               => '',
      p_success_msg            => 'This section lists the people reporting.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PPL_REPORT_DETAILS');



debug('begin add_signature: PERSON_REPORT_DETAILS');
  add_signature(
      p_sig_id                 => 'PERSON_REPORT_DETAILS',
      p_sig_sql                => 'select distinct
       full_name,
       employee_number,
       person_id
    from per_all_people_f
    where person_id in (
           select paf.person_id
           from  per_all_assignments_f paf
           start with paf.person_id = ##$$PERID$$##
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           connect by PRIOR paf.supervisor_id = paf.person_id
           and   paf.primary_flag = ''Y''
           and   sysdate between paf.effective_start_date and paf.effective_end_date
           minus
           select paf.person_id
           from  per_all_assignments_f paf
           where paf.person_id = ##$$PERID$$## )
           and sysdate between effective_start_date and effective_end_date',
      p_title                  => 'Who This Person Reports To',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'This Person does not reports to other person',
      p_solution               => '',
      p_success_msg            => 'This section lists who this person reports to.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PERSON_REPORT_DETAILS');



debug('begin add_signature: PER_SEC_PROF_DETAILS');
  add_signature(
      p_sig_id                 => 'PER_SEC_PROF_DETAILS',
      p_sig_sql                => 'select pspa.user_id ,
           pspa.sec_profile_assignment_id,
           pspa.security_group_id,
           pspa.security_profile_id,
           pspa.responsibility_id,
           pspa.responsibility_application_id,
           pspa.start_date,
           pspa.end_date,
           frtl.responsibility_name
    from per_sec_profile_assignments pspa,
         fnd_responsibility_tl frtl
    where pspa.user_id =
         (select fuser.user_id from fnd_user fuser
          where fuser.employee_id = ##$$PERID$$##)
    and pspa.responsibility_id = frtl.responsibility_id
    and frtl.language = ''US''
    order by pspa.start_date, frtl.responsibility_name',
      p_title                  => 'PER Security Profile Assigned to Employee details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Person Security Profiles assigned to employee',
      p_solution               => '',
      p_success_msg            => 'This section lists the Security Profiles assigned.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PER_SEC_PROF_DETAILS');



debug('begin add_signature: LOC_DETAILS');
  add_signature(
      p_sig_id                 => 'LOC_DETAILS',
      p_sig_sql                => 'select paf.assignment_number,
             paf.location_id,
             hla.style,
             hla.description,
             hla.creation_date,
             hla.inactive_date
      from per_all_assignments_f paf,
           hr_locations_all hla
      where paf.person_id = ##$$PERID$$##
      and   paf.assignment_status_type_id = 1
      and   paf.location_id = hla.location_id
      and   paf.effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY'')
      order by paf.assignment_number',
      p_title                  => 'Location Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Location details exists',
      p_solution               => '',
      p_success_msg            => 'This section lists the Location details for each distinct active assignment record',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: LOC_DETAILS');



debug('begin add_signature: PERIOD_SER_DETAILS');
  add_signature(
      p_sig_id                 => 'PERIOD_SER_DETAILS',
      p_sig_sql                => 'select  period_of_service_id
           ,business_group_id
           ,date_start
           ,accepted_termination_date
           ,actual_termination_date
           ,final_process_date
           ,notified_termination_date
           ,leaving_reason
           ,last_standard_process_date
           ,adjusted_svc_date
           ,created_by
           ,creation_date
           ,last_updated_by
           ,last_update_date
           ,object_version_number
    from  per_periods_of_service
    where person_id = ##$$PERID$$##
    order by period_of_service_id',
      p_title                  => 'Periods of Service Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Periods of Service details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Periods of Service details for each effective date range.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PERIOD_SER_DETAILS');



debug('begin add_signature: PERIOD_PLACEMENTS_DETAILS');
  add_signature(
      p_sig_id                 => 'PERIOD_PLACEMENTS_DETAILS',
      p_sig_sql                => 'select period_of_placement_id
         , date_start
         , last_standard_process_date
         , actual_termination_date
         , final_process_date
         , created_by
         , last_updated_by
    from per_periods_of_placement
    where person_id = ##$$PERID$$##
    order by 1,2',
      p_title                  => 'Period of Placements Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Period of Placements details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Periods of Placement details for each Effective Date Range. PER_PERIODS_OF_PLACEMENT is used for CONTINGENT WORKER records in place of table PER_PERIODS_OF_SERVICE.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PERIOD_PLACEMENTS_DETAILS');



debug('begin add_signature: PER_TYPE_USAGE_DETAILS');
  add_signature(
      p_sig_id                 => 'PER_TYPE_USAGE_DETAILS',
      p_sig_sql                => 'select   ptu.person_type_usage_id
           , ptu.effective_start_date
           , ptu.effective_end_date
           , ppt.system_person_type || '' - '' || ppt.user_person_type || '' ('' || ptu.person_type_id || '')'' perType
           , ptu.object_version_number
           , ptu.created_by
           , ptu.creation_date
           , ptu.last_updated_by
           , ptu.last_update_date
    from   per_person_type_usages_f ptu
           , per_person_types ppt
    where    ptu.person_id = ##$$PERID$$##
    and      ptu.person_type_id = ppt.person_type_id
    order by 1,2',
      p_title                  => 'Person Type Usage Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Person Type Usage details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Person Type Usage for each Effective Date Range.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PER_TYPE_USAGE_DETAILS');



debug('begin add_signature: PER_ADDRESS_DETAILS');
  add_signature(
      p_sig_id                 => 'PER_ADDRESS_DETAILS',
      p_sig_sql                => 'select address_id
         , business_group_id
         , style
         , date_from
         , date_to
         , hr_general.decode_lookup(''YES_NO'',primary_flag) primary_flag
         , party_id
         , town_or_city
         , region_1
         , region_2
         , postal_code
         , created_by
         , last_updated_by
         , add_dtls.meaning
    from per_addresses,
         (select lookup_type,language,lookup_code,meaning, enabled_flag,start_date_active,end_date_active
          from fnd_lookup_values
          where lookup_type = ''ADDRESS_TYPE'' and language = ''US'' ) add_dtls
    where person_id = ##$$PERID$$##
    and   add_dtls.lookup_code = address_type
    order by 4',
      p_title                  => 'Person Address Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Person Address details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Address details for each effective date range.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PER_ADDRESS_DETAILS');



debug('begin add_signature: ADDRESS_STYLE_DETAILS');
  add_signature(
      p_sig_id                 => 'ADDRESS_STYLE_DETAILS',
      p_sig_sql                => 'select style,count(*) s_count
    from per_addresses
    group by style',
      p_title                  => 'Address Styles Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Address Styles details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists a count of each address style from table PER_ADDRESSES.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ADDRESS_STYLE_DETAILS');



debug('begin add_signature: PERSON_ANALYSIS_DETAILS');
  add_signature(
      p_sig_id                 => 'PERSON_ANALYSIS_DETAILS',
      p_sig_sql                => 'select person_analysis_id
         , business_group_id
         , analysis_criteria_id
         , date_from
         , date_to
         , object_version_number
         , party_id
         , created_by
         , last_updated_by
    from per_person_analyses
    where person_id = ##$$PERID$$##
    order by 4',
      p_title                  => 'Person Analysis Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Person Analysis details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Person Analysis details for each Effective Date Range.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PERSON_ANALYSIS_DETAILS');



debug('begin add_signature: BENEFITS_PAYROLL_DETAILS');
  add_signature(
      p_sig_id                 => 'BENEFITS_PAYROLL_DETAILS',
      p_sig_sql                => 'select distinct ppf.payroll_name
      from
         hr_organization_information hoi,
         pay_payrolls_f ppf,
         per_all_people_f pf,
         per_organization_units pou
      where hoi.organization_id = pou.organization_id
      and pf.business_group_id = pou.business_group_id
      and hoi.org_information_context like ''Benefit%''
      and ppf.payroll_id = hoi.org_information2
      and pf.person_id = ##$$PERID$$##',
      p_title                  => 'Benefits Payroll Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Benefits Payroll details exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Benefits Payroll details.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BENEFITS_PAYROLL_DETAILS');



debug('begin add_signature: POTENTIAL_LIFE_EVENTS');
  add_signature(
      p_sig_id                 => 'POTENTIAL_LIFE_EVENTS',
      p_sig_sql                => 'SELECT
         bplp.lf_evt_ocrd_dt                  EventDate
       , bl.name || '' ('' || bl.ler_id  || '')'' LifeEvent
       , HR_GENERAL.DECODE_LOOKUP(''BEN_PTNL_LER_FOR_PER_STAT'',bplp.PTNL_LER_FOR_PER_STAT_CD) Status
       , bplp.NTFN_DT                         Notified
       , bplp.DTCTD_DT                        Detected
       , bplp.UNPROCD_DT                      Unprocessed
       , bplp.PROCD_DT                        Processed
       , bplp.VOIDD_DT                        Voided
      FROM
         ben_ptnl_ler_for_per bplp
       , ben_ler_f            bl
       , per_all_people_f     ppf
      WHERE sysdate between ppf.effective_start_date and ppf.effective_end_date
        AND ppf.person_id = bplp.person_id
        AND sysdate between bl.effective_start_date and bl.effective_end_date
        AND bplp.ler_id = bl.ler_id
        AND ppf.person_id = ##$$PERID$$##
      ORDER BY 1 desc',
      p_title                  => 'Potential Life Events',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Potential Life Events exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists Potential Life Events.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: POTENTIAL_LIFE_EVENTS');



debug('begin add_signature: LIFE_EVENT_DATE');
  add_signature(
      p_sig_id                 => 'LIFE_EVENT_DATE',
      p_sig_sql                => 'SELECT bpil.lf_evt_ocrd_dt                  eventDate
       , bl.name || '' ('' || bl.ler_id  || '')'' lifeEvent
       , to_char(bpil.per_in_ler_id)          perInLerId
       , HR_GENERAL.DECODE_LOOKUP(''BEN_PER_IN_LER_STAT'',bpil.per_in_ler_stat_cd) status
       , bpil.STRTD_DT                        started
       , bpil.PROCD_DT                        processed
       , bpil.VOIDD_DT                        voided
       , bpil.BCKT_DT                         backedOut
      FROM
         ben_per_in_ler   bpil
       , ben_ler_f        bl
       , per_all_people_f ppf
      WHERE sysdate between ppf.effective_start_date and ppf.effective_end_date
        AND ppf.person_id = bpil.person_id
        AND sysdate between bl.effective_start_date and bl.effective_end_date
        AND bpil.ler_id = bl.ler_id
        AND ppf.business_group_id in (SELECT business_group_id from per_all_people_f where person_id = ##$$PERID$$## and effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY''))
        AND ppf.person_id = ##$$PERID$$##
      ORDER BY 1 desc, 3 desc',
      p_title                  => 'Life Event Date',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Life Event Date exists',
      p_solution               => '',
      p_success_msg            => 'This section lists Life Event Date.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: LIFE_EVENT_DATE');



debug('begin add_signature: oldPROGRAM_DETAILS');
  add_signature(
      p_sig_id                 => 'oldPROGRAM_DETAILS',
      p_sig_sql                => 'SELECT unique name prgName
	       , PGM_TYP_CD  pgmTypCd
           , HR_GENERAL.DECODE_LOOKUP(''BEN_ACTY_REF_PERD'',ACTY_REF_PERD_CD) actRefPeriod
           , HR_GENERAL.DECODE_LOOKUP(''BEN_ENRT_INFO_RT_FREQ'',ACTY_REF_PERD_CD) enrRateFreq
      FROM ben_pgm_f bpf,ben_prtt_enrt_rslt_f bperf
      WHERE bpf.pgm_id = bperf.pgm_id
        AND bperf.PERSON_ID = ##$$PERID$$##
		AND bperf.prtt_enrt_rslt_stat_cd IS NULL
		AND sysdate between bperf.effective_start_date and bperf.effective_end_date
		AND sysdate between bpf.effective_start_date and bpf.effective_end_date',
      p_title                  => 'Program Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Program exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Activity Reference Period and the Enrollment Rate/Frequency for the programs that this person is or has been enrolled in. This is a factor in the determination of the Rates for this person.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: oldPROGRAM_DETAILS');



debug('begin add_signature: ENROLLMENT_RESULT_DATE');
  add_signature(
      p_sig_id                 => 'ENROLLMENT_RESULT_DATE',
      p_sig_sql                => 'SELECT DISTINCT
         to_char(bperf.PRTT_ENRT_RSLT_ID)         EnrtRsltID
       , to_char(bperf.per_in_ler_id)             perInLerId
       , bpf.name  || '' ('' || bperf.pl_id   || '')'' plan
       , decode(bperf.oipl_id,null,null,opt.name || '' ('' || bperf.oipl_id || '')'') optionInPlan
       , blf.name || '' ('' || blf.ler_id  || '')''   lifeEvent
       , bprv.rt_ovridn_flag                      rateflag
       , bperf.enrt_ovridn_flag                   enrollflag
       , bperf.effective_start_date               enrollstart
       , bperf.effective_end_date                 enrollend
       , bperf.enrt_cvg_strt_dt                   coveragestart
       , bperf.enrt_cvg_thru_dt                   coverageend
       , bprv.rt_strt_dt                          ratestart
       , bprv.rt_end_dt                           rateend
       , peevf.effective_start_date               elementstart
       , peevf.effective_end_date                 elementend
	   , bperf.prtt_enrt_rslt_stat_cd             enrtRsltStatCd
      FROM
         ben_prtt_enrt_rslt_f       bperf
       , ben_prtt_rt_val            bprv
       , pay_element_entry_values_f peevf
       , ben_pl_f                   bpf
       , ben_opt_f                  opt
       , ben_oipl_f                 oipl
       , ben_ler_f                  blf
      WHERE bperf.person_id = ##$$PERID$$##
        AND bperf.prtt_enrt_rslt_id = bprv.prtt_enrt_rslt_id
        AND bprv.element_entry_value_id = peevf.element_entry_value_id (+)
		AND bprv.prtt_rt_val_stat_cd IS NULL
		AND bperf.prtt_enrt_rslt_stat_cd IS NULL
        AND bperf.oipl_id = oipl.oipl_id (+)
        AND bperf.pl_id = bpf.pl_id
        AND oipl.opt_id = opt.opt_id (+)
        AND bperf.ler_id = blf.ler_id
        AND bprv.rt_strt_dt <= bprv.rt_end_dt
        AND sysdate BETWEEN bpf.effective_start_date AND bpf.effective_end_date
		AND sysdate BETWEEN peevf.effective_start_date AND peevf.effective_end_date
        AND sysdate BETWEEN oipl.effective_start_date AND oipl.effective_end_date
		AND sysdate BETWEEN opt.effective_start_date AND opt.effective_end_date
        AND sysdate BETWEEN blf.effective_start_date AND blf.effective_end_date
		AND sysdate BETWEEN bperf.effective_start_date AND bperf.effective_end_date
      ORDER BY 1 DESC,2 DESC,bprv.RT_STRT_DT DESC',
      p_title                  => 'Enrollment Result Date Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Enrollment Result Date exists',
      p_solution               => '',
      p_success_msg            => 'This section lists the Enrollment Result Date Details. The Life Event, Plan and Options (if applicable) are displayed, with their corresponding Id.  Rate and/or Coverage overrides are noted. Start and End Dates for Coverage, Rates and Element Entries are detailed.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ENROLLMENT_RESULT_DATE');



debug('begin add_signature: ENROLLMENT_RESULT_AMOUNT');
  add_signature(
      p_sig_id                 => 'ENROLLMENT_RESULT_AMOUNT',
      p_sig_sql                => 'SELECT DISTINCT
         to_char(bperf.prtt_enrt_rslt_id)       EnrtRsltID
       , to_char(bperf.per_in_ler_id)           perInLerId
       , to_char(peef.creator_id)               creatorId
       , petf.element_name || '' ('' || to_char(peevf.element_entry_id) || '') '' elemEntry
       , blf.name || '' ('' || blf.ler_id  || '')'' lifeEvent
       , to_char(bperf.bnft_amt)                benAmt
       , to_char(bprv.rt_val)                   rateVal
       , to_char(bprv.ann_rt_val)               annRateVal
       , to_char(bprv.cmcd_rt_val)              cmcdRateVal
       , peevf.screen_entry_value               screenEntryVal
      FROM
         ben_prtt_enrt_rslt_f       bperf
       , ben_prtt_rt_val            bprv
       , pay_element_entry_values_f peevf
	   , hr.pay_element_links_f     pelf
       , pay_element_entries_f      peef
       , pay_element_types_f        petf
       , ben_ler_f                  blf
      WHERE bperf.person_id = ##$$PERID$$##
        AND bperf.business_group_id in (SELECT business_group_id from per_all_people_f where person_id = ##$$PERID$$## and effective_end_date = to_date(''12/31/4712'',''MM/DD/YYYY''))
        AND bperf.prtt_enrt_rslt_id = bprv.prtt_enrt_rslt_id
        AND bprv.element_entry_value_id = peevf.element_entry_value_id (+)
        AND bprv.prtt_rt_val_stat_cd IS NULL
		AND bperf.prtt_enrt_rslt_stat_cd IS NULL
        AND peevf.element_entry_id = peef.element_entry_id
        AND bperf.ler_id = blf.ler_id
        AND sysdate BETWEEN blf.effective_start_date AND blf.effective_end_date
		AND sysdate BETWEEN bperf.effective_start_date AND bperf.effective_end_date
		AND sysdate BETWEEN petf.effective_start_date AND petf.effective_end_date
		AND sysdate BETWEEN peef.effective_start_date AND peef.effective_end_date
		AND sysdate BETWEEN pelf.effective_start_date AND pelf.effective_end_date
        AND sysdate BETWEEN peevf.effective_start_date AND peevf.effective_end_date
		AND pelf.element_type_id = petf.element_type_id
        AND peef.element_link_id = pelf.element_link_id
      ORDER BY 1 DESC, 2 DESC',
      p_title                  => 'Enrollment Result Amounts',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Enrollment Result Amounts exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists the Enrollment Result Amount Details by Enrollment Result Id The Creator Id is listed for the element entry, and should be identical to the Enrollment Result Id.  Benefit Amounts are given for  those comp objects with a coverage amount.  Rate and element entry values are provided.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ENROLLMENT_RESULT_AMOUNT');



debug('begin add_signature: DEPENDENT_ENROLLMENT');
  add_signature(
      p_sig_id                 => 'DEPENDENT_ENROLLMENT',
      p_sig_sql                => 'SELECT
         to_char(becd.elig_cvrd_dpnt_id)               eligCvrdDpntId
	   , to_char(becd.prtt_enrt_rslt_id)               EnrtRsltId
       , pil.lf_evt_ocrd_dt                            eventDate
       , bl.name || '' ('' || bl.ler_id  || '')''          lifeEvent
       , to_char(pil.per_in_ler_id)                    perInLerId
       , pgm.name ||''(''|| bperf.pgm_id  || '')''         program
       , pl.name  ||''(''|| bperf.pl_id   || '')''         plan
       , opt.name ||''(''|| bperf.oipl_id || '')''         optionInPlan
       , becd.cvg_strt_dt                              cvgStrtDt
       , becd.cvg_thru_dt                              cvgThruDt
       , ppfd.full_name||''(''||becd.dpnt_person_id||'')'' dpndntFullName
	   , hrl.meaning                                   relationShip
	   , pcr.personal_flag                             personalFlag
	   , becd.ovrdn_flag                               ovrdnFlag
       , becd.ovrdn_thru_dt                            ovrdnThruDt
	   , becd.cvg_pndg_flag                            cvgPndgFlag
	   , dctfn.dpnt_dsgn_ctfn_rqd_flag                 dpntDsgnCtfnRqdFlag
     FROM
       ben_elig_cvrd_dpnt_f becd,
	   ben_cvrd_dpnt_ctfn_prvdd_f dctfn,
	   ben_prtt_enrt_rslt_f bperf,
	   per_all_people_f     ppf,
	   per_all_people_f     ppfd,
       ben_pgm_f            pgm,
       ben_pl_f             pl,
       ben_oipl_f           oipl,
       ben_opt_f            opt,
       ben_ler_f            bl,
	   ben_per_in_ler       pil,
	   per_contact_relationships pcr,
       hr_lookups hrl
   WHERE
	      becd.elig_cvrd_dpnt_id = dctfn.elig_cvrd_dpnt_id (+)
     AND  bperf.prtt_enrt_rslt_id = becd.prtt_enrt_rslt_id
     AND  bperf.person_id = ##$$PERID$$##
	 AND  ppf.person_id = bperf.person_id
	 AND  ppfd.person_id = becd.dpnt_person_id
	 AND  bperf.pgm_id = pgm.pgm_id (+)
     AND  bperf.pl_id = pl.pl_id
     AND  bperf.oipl_id = oipl.oipl_id
     AND  oipl.opt_id = opt.opt_id
     AND  bperf.ler_id = bl.ler_id
     AND  pil.ler_id = bl.ler_id
     AND  bperf.person_id = pil.person_id
	 AND  bperf.person_id = pcr.person_id
     AND  becd.dpnt_person_id = pcr.contact_person_id
     AND  hrl.lookup_type = ''CONTACT''
     AND  pcr.contact_type = hrl.lookup_code
     AND  pil.per_in_ler_stat_cd NOT IN (''VOIDD'', ''BCKDT'')
     AND  sysdate BETWEEN bl.effective_start_date AND bl.effective_end_date
	 AND  sysdate BETWEEN bperf.effective_start_date AND bperf.effective_end_date
	 AND  sysdate BETWEEN ppf.effective_start_date AND ppf.effective_end_date
	 AND  sysdate BETWEEN ppfd.effective_start_date AND ppfd.effective_end_date
     AND  sysdate BETWEEN pgm.effective_start_date AND pgm.effective_end_date
     AND  sysdate BETWEEN pl.effective_start_date AND pl.effective_end_date
	 AND  sysdate BETWEEN oipl.effective_start_date AND oipl.effective_end_date
     AND  sysdate BETWEEN opt.effective_start_date AND opt.effective_end_date
   ORDER BY
	   bperf.person_id,
       becd.dpnt_person_id,
       becd.effective_start_date',
      p_title                  => 'Dependents Enrollments',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Dependents Enrollment exists',
      p_solution               => '',
      p_success_msg            => 'This section lists Dependents Enrollments (Dependents Information with the Flags).',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DEPENDENT_ENROLLMENT');



debug('begin add_signature: BENEFICIARY_ENROLLMENT');
  add_signature(
      p_sig_id                 => 'BENEFICIARY_ENROLLMENT',
      p_sig_sql                => 'SELECT
	    to_char(bnf.pl_bnf_id)                        plBnfId
	  , to_char(bnf.prtt_enrt_rslt_id)                EnrtRsltId
      , pil.lf_evt_ocrd_dt                            eventDate
      , pgm.name ||''(''|| bperf.pgm_id  || '')''         program
      , pl.name  ||''(''|| bperf.pl_id   || '')''         plan
      , opt.name ||''(''|| bperf.oipl_id || '')''         optionInPlan
      , bl.name || '' ('' || bl.ler_id  || '')''          lifeEvent
	  , bnf.dsgn_strt_dt                              dsgnStrtDt
	  , bnf.dsgn_thru_dt                              dsgnThruDt
      , ppfd.full_name||''(''||bnf.bnf_person_id||'')''   bnfFullName
	  , hrl.meaning                                   relationShip
	  , pcr.personal_flag                             personalFlag
	  , bnf.prmry_cntngnt_cd                          prmryCntgntCd
	  , to_char(bnf.pct_dsgd_num)                     pctDsgdNum
	  , to_char(bnf.amt_dsgd_val)                     amtDsgdVal
	  , bnf.amt_dsgd_uom                              amtDsgdUOM
  FROM ben_pl_bnf_f bnf,
       ben_pl_bnf_ctfn_prvdd_f bctfn,
       ben_prtt_enrt_rslt_f bperf,
	   per_all_people_f     ppf,
	   per_all_people_f     ppfd,
       ben_pgm_f            pgm,
       ben_pl_f             pl,
       ben_oipl_f           oipl,
       ben_opt_f            opt,
       ben_ler_f            bl,
	   ben_per_in_ler       pil,
	   per_contact_relationships pcr,
       hr_lookups hrl
  WHERE  bnf.pl_bnf_id = bctfn.pl_bnf_id (+)
    AND  bperf.prtt_enrt_rslt_id = bnf.prtt_enrt_rslt_id
    AND  ppf.person_id = bperf.person_id
    AND  ppfd.person_id = bnf.bnf_person_id
    AND  bperf.pgm_id = pgm.pgm_id (+)
    AND  bperf.pl_id = pl.pl_id
    AND  bperf.oipl_id = oipl.oipl_id
    AND  oipl.opt_id = opt.opt_id
    AND  bperf.ler_id = bl.ler_id
    AND  pil.ler_id = bl.ler_id
    AND  bperf.person_id = pil.person_id
    AND  bperf.person_id = pcr.person_id
    AND  bnf.bnf_person_id = pcr.contact_person_id
    AND  hrl.lookup_type = ''CONTACT''
    AND  pcr.contact_type = hrl.lookup_code
    AND  pil.per_in_ler_stat_cd NOT IN (''VOIDD'', ''BCKDT'')
    AND  bperf.person_id = ##$$PERID$$##
    AND  sysdate BETWEEN bl.effective_start_date AND bl.effective_end_date
    AND  sysdate BETWEEN bperf.effective_start_date AND bperf.effective_end_date
    AND  sysdate BETWEEN ppf.effective_start_date AND ppf.effective_end_date
    AND  sysdate BETWEEN ppfd.effective_start_date AND ppfd.effective_end_date
    AND  sysdate BETWEEN pgm.effective_start_date AND pgm.effective_end_date
    AND  sysdate BETWEEN pl.effective_start_date AND pl.effective_end_date
	AND  sysdate BETWEEN oipl.effective_start_date AND oipl.effective_end_date
    AND  sysdate BETWEEN opt.effective_start_date AND opt.effective_end_date
    ORDER BY
	   bperf.person_id,
	   bnf.pl_bnf_id,
	   bnf.effective_start_date',
      p_title                  => 'Beneficiary Enrollments',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Beneficiary Enrollment exists.',
      p_solution               => '',
      p_success_msg            => 'This section lists Beneficiary Enrollments.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BENEFICIARY_ENROLLMENT');



debug('begin add_signature: PERSON_ASSIGNMENT_PAYROLL');
  add_signature(
      p_sig_id                 => 'PERSON_ASSIGNMENT_PAYROLL',
      p_sig_sql                => '	

SELECT UNIQUE
             pay.payroll_name                     payName
           , ptp.period_type                      perType
           , TO_CHAR(ptp.pay_advice_date,''yyyy'')  payYear
           , MIN(ptp.pay_advice_date)             firstCheckDate
           , MAX(ptp.pay_advice_date)             lastCheckDate
           , COUNT(ptp.pay_advice_date)           numPayPeriods
      FROM per_time_periods ptp,
	       pay_all_payrolls_f pay
      WHERE ptp.payroll_id IN (SELECT paf.PAYROLL_ID
	                            FROM per_assignments_f paf
	                           WHERE paf.person_id = ##$$PERID$$## 
							   AND paf.EFFECTIVE_END_DATE = TO_DATE(''12/31/4712'',''MM/DD/YYYY''))
        AND ptp.payroll_id = pay.payroll_id
        AND TO_NUMBER(TO_CHAR(ptp.pay_advice_date,''yyyy''))
            BETWEEN TO_NUMBER(TO_CHAR(SYSDATE,''yyyy'')-2) and TO_NUMBER(TO_CHAR(SYSDATE,''yyyy'')+2)
        AND ptp.pay_advice_date BETWEEN pay.effective_start_date AND pay.effective_end_date
      GROUP BY pay.payroll_name, ptp.period_type, TO_CHAR(ptp.pay_advice_date,''yyyy'')',
      p_title                  => 'Person Assignment Payroll',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Person Assignment Payroll exists',
      p_solution               => '',
      p_success_msg            => 'This section lists the number of payroll periods for past and future pay periods. This is a factor in the determination of the Rates for this person.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('Y','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: PERSON_ASSIGNMENT_PAYROLL');

    

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
PROCEDURE main(
            p_person_id                    IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;
  l_completion_status  BOOLEAN;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;

  IF g_is_concurrent THEN
     g_rep_info('Calling From'):='Concurrent Program';
  ELSE
     g_rep_info('Calling From'):='SQL Script';
  END IF;
  
  l_step := '10';
  initialize_files;
 
-- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'Benefits';

  l_step := '20';

   validate_parameters(
     p_person_id                    => p_person_id
    ,p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );


  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');

debug('begin section: OVERVIEW');
start_section('Instance Overview');
   set_item_result(run_stored_sig('OVERVIEW'));
   set_item_result(run_stored_sig('PRODUCTS_INSTALL'));
   set_item_result(run_stored_sig('BENEFITS_NOT_INSTALLED'));
   set_item_result(run_stored_sig('BENEFIT_SHARED'));
   set_item_result(run_stored_sig('LANGUAGES_INSTALLED_DETAILS'));
   set_item_result(check_rec_patches_2);
end_section;
debug('end section: OVERVIEW');

debug('begin section: VERSIONS');
start_section('Files Versions');
   set_item_result(run_stored_sig('PACKAGES'));
   set_item_result(run_stored_sig('JAVA'));
   set_item_result(run_stored_sig('FORMS'));
   set_item_result(run_stored_sig('REPORTS'));
   set_item_result(run_stored_sig('LDT'));
   set_item_result(run_stored_sig('ODF'));
   set_item_result(run_stored_sig('SQLV'));
end_section;
debug('end section: VERSIONS');

debug('begin section: DBISSUES');
start_section('Database Issues');
   set_item_result(run_stored_sig('HR_Invalid'));
   set_item_result(run_stored_sig('Discrepancies'));
   set_item_result(run_stored_sig('DISABLED_TRIGGERS'));
end_section;
debug('end section: DBISSUES');

debug('begin section: PERFORMANCE');
start_section('Performance');
   IF g_rep_info('Apps Version') like '12%' THEN
      set_item_result(run_stored_sig('DATABASE_INITIALIZATION_12'));
   END IF;
   IF g_rep_info('Apps Version') like '11%' THEN
      set_item_result(run_stored_sig('DATABASE_INITIALIZATION_11i'));
   END IF;
   set_item_result(run_stored_sig('BEN_GATHER_SCHEMA'));
   set_item_result(run_stored_sig('Maintain_Participant_Eligibility_Issue'));
   set_item_result(run_stored_sig('Recalculate_Participant_Values_Issue'));
   set_item_result(run_stored_sig('PAY_ACTION_PARAMETERS'));
end_section;
debug('end section: PERFORMANCE');

debug('begin section: SETUP');
start_section('Setup');
   set_item_result(run_stored_sig('PROFILES'));
   set_item_result(run_stored_sig('PROGRAM'));
   set_item_result(run_stored_sig('PLANS_NOT_IN_PROGRAM'));
   set_item_result(run_stored_sig('PLANANDPLANTYPE'));
end_section;
debug('end section: SETUP');

debug('begin section: PERSON');
start_section(' Person/Enrollment Information');
   set_item_result(run_stored_sig('Person_Details'));
   set_item_result(run_stored_sig('PERSON_ISSUE1'));
   set_item_result(run_stored_sig('PERSON_ISSUE2'));
   set_item_result(run_stored_sig('PERSON_ISSUE3'));
   set_item_result(run_stored_sig('CONTACT_DETAILS'));
   set_item_result(run_stored_sig('ASSIGNMENT_DETAILS'));
   set_item_result(run_stored_sig('ASSIGNMENT_ISSUE1'));
   set_item_result(run_stored_sig('ASSIGNMENT_ISSUE2'));
   set_item_result(run_stored_sig('ASSIGNMENT_ISSUE3'));
   set_item_result(run_stored_sig('ASG_ACT_DETAILS'));
   set_item_result(run_stored_sig('GRADE_DETAILS'));
   set_item_result(run_stored_sig('PPL_REPORT_DETAILS'));
   set_item_result(run_stored_sig('PERSON_REPORT_DETAILS'));
   set_item_result(run_stored_sig('PER_SEC_PROF_DETAILS'));
   set_item_result(run_stored_sig('LOC_DETAILS'));
   set_item_result(run_stored_sig('PERIOD_SER_DETAILS'));
   set_item_result(run_stored_sig('PERIOD_PLACEMENTS_DETAILS'));
   set_item_result(run_stored_sig('PER_TYPE_USAGE_DETAILS'));
   set_item_result(run_stored_sig('PER_ADDRESS_DETAILS'));
   set_item_result(run_stored_sig('ADDRESS_STYLE_DETAILS'));
   set_item_result(run_stored_sig('PERSON_ANALYSIS_DETAILS'));
   set_item_result(run_stored_sig('BENEFITS_PAYROLL_DETAILS'));
   set_item_result(run_stored_sig('POTENTIAL_LIFE_EVENTS'));
   set_item_result(run_stored_sig('LIFE_EVENT_DATE'));
   set_item_result(run_stored_sig('oldPROGRAM_DETAILS'));
   set_item_result(run_stored_sig('ENROLLMENT_RESULT_DATE'));
   set_item_result(run_stored_sig('ENROLLMENT_RESULT_AMOUNT'));
   set_item_result(run_stored_sig('DEPENDENT_ENROLLMENT'));
   set_item_result(run_stored_sig('BENEFICIARY_ENROLLMENT'));
   set_item_result(run_stored_sig('PERSON_ASSIGNMENT_PAYROLL'));
end_section;
debug('end section: PERSON');

debug('begin section: OPEN');
start_section('Open / Scheduled Event');
   set_item_result(run_stored_sig('Designate_Beneficiaries'));
   set_item_result(run_stored_sig('Enrollments_Overridden'));
   set_item_result(run_stored_sig('Enrollment_Rates_Overridden'));
end_section;
debug('end section: OPEN');

debug('begin section: ACA');
start_section('Affordable Care Act (ACA)');
   set_item_result(check_rec_patches_1);
end_section;
debug('end section: ACA');



  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  print_out('<a href="https://community.oracle.com/thread/3795821" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 

  IF g_is_concurrent THEN
     l_completion_status:=FND_CONCURRENT.SET_COMPLETION_STATUS('NORMAL','');
  END IF;
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);

  IF g_is_concurrent THEN
     l_completion_status:=FND_CONCURRENT.SET_COMPLETION_STATUS('ERROR',g_errbuf);
  END IF; 
   
END main;


BEGIN
 
   null;


   main(
     p_person_id                    => p_person_id
    ,p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );


EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);



END;

/
show errors
exit; 
-- Exit required for bundling project so do not remove