REM $Id: lcm_integration_setup_analyze.sql, 200.2 2015/15/01 23:27:42 jxmccall Exp $
REM +===============================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                         |
REM |                    Redwood Shores, California, USA                            |
REM |                         All rights reserved.                                  |
REM +===============================================================================+
REM | Framework 3.0.13                                                              |
REM |                                                                               |
REM | FILENAME                                                                      |
REM |     lcm_integration_setup_analyze.sql                                         |
REM |                                                                               |
REM | DESCRIPTION                                                                   |
REM |    Wrapper SQL to submit the lcm_int_setup_analyzer_pkg.main procedure        |
REM |                                                                               |
REM | HISTORY                                                                       |
REM |    15-JUN-15 : Kishor Genikala : Initial publication  (v 200.1)               |
REM |    09-SEP-15 : Kishor Genikala :     (v 200.2)                                |
REM |                 Wrapper updated to include Analyzer Bundle                    |
REM |                    perl variables (as per Kyle Harris)                        |
REM +===============================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.1 12.2 
REM 
REM MENU_TITLE: Discrete-LCM integration Key Setup Analyzer
REM
REM MENU_START
REM
REM SQL: Run Discrete-LCM integration Key Setup Analyzer
REM FNDLOAD: Load Discrete-LCM integration Key Setup Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM 
REM 
REM HELP_START  
REM 
REM  Discrete-LCM integration Key Setup Analyzer Help [Doc ID: 1677693.1] 
REM
REM  Compatible: 12.1|12.2  
REM
REM  Explanation of available options:
REM
REM    (1) Run the Discrete-LCM integration Key Setup Analyzer
REM        o Runs the database package lcm_int_setup_analyzer_pkg.main as APPS and creates an HTML report file 
REM           on the database server (typically under /usr/tmp) 
REM
REM    (2) Install Discrete-LCM integration Key Setup Analyzer as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "Purchasing Reports" 
REM
REM 
REM HELP_END 
REM
REM FNDLOAD_START
REM
REM PROD_TOP: INL_TOP
REM PROG_NAME: DISLCMANL
REM APP_NAME: Oracle Landed Cost Management
REM DEF_REQ_GROUP: INL_REPORTS
REM PROG_TEMPLATE: DISLCMANL.ldt
REM PROD_SHORT_NAME: INL
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM lcm_integration_setup_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END


SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
-- PSD #1
PROMPT Submitting Discrete LCM Integration Key Setup Analyzer.

BEGIN

-- PSD #4
  lcm_int_analyzer_pkg.main;

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;