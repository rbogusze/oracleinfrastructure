SET SERVEROUTPUT ON SIZE 1000000
SET DEFINE '~'
WHENEVER SQLERROR EXIT

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.35                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    om_order_analyzer.sql                                                |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+


declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,4);
    
 -- Validation to verify analyzer is run on proper e-Business application version
 -- So will fail before package is created
 if apps_version NOT IN ('12.0','12.1','12.2') then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'           ');
    dbms_output.put_line('*** This Analyzer script is compatible for following version(s): ');
	dbms_output.put_line('***   12.0,12.1,12.2 ');
    dbms_output.put_line('*** Note: the error below is intentional                    ');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness versions 12.0,12.1,12.2');
 end if;

END;
/


CREATE OR REPLACE PACKAGE om_order_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

PROCEDURE main 
(            p_header_id                    IN NUMBER      DEFAULT NULL
           ,p_line_id                      IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 2000
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')
;

 
PROCEDURE main_cp (
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
           ,p_header_id                    IN NUMBER      DEFAULT NULL
           ,p_line_id                      IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 2000
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y'
);

-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------



END om_order_analyzer_pkg;
/
show errors


CREATE OR REPLACE PACKAGE BODY om_order_analyzer_pkg AS
-- $Id: om_order_analyzer.sql, 200.1 2016/01/07 08:37:08 christine.schmehl@oracle.com Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=2038363.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

    l_log_file := 'ONTONESO_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'ONTONESO_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>ONTONESO Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {

  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;

  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">EBS '|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=2038363.1:SCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/om_so_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
	-- removed initCap per Standardization team in 3.0.35
    l_col_headings(i) := replace(l_desc_rec_tbl(i).col_name,'|','<br>');
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_sigxinfo_element     XMLDOM.DOMElement;
l_sigxinfo_node        XMLDOM.DOMNode;
l_xinfo_element        XMLDOM.DOMElement;
l_xinfo_node           XMLDOM.DOMNode;
l_xinfo_name_attr      XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.extra_info.count > 0 THEN
      l_sigxinfo_element := XMLDOM.createElement(l_hidden_xml_doc,'sigxinfo');      
      l_sigxinfo_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_sigxinfo_element));      
      l_key := p_sig.extra_info.first;
      WHILE l_key IS NOT NULL LOOP
         l_xinfo_element := XMLDOM.createElement(l_hidden_xml_doc,'info');      
         l_xinfo_node := XMLDOM.appendChild(l_sigxinfo_node,XMLDOM.makeNode(l_xinfo_element));      
         l_xinfo_name_attr := XMLDOM.setAttributeNode(l_xinfo_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name')); 
         XMLDOM.setAttribute(l_xinfo_element, 'name',l_key);
         l_node := XMLDOM.appendChild(l_xinfo_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,p_sig.extra_info(l_key))));         
         l_key := p_sig.extra_info.next(l_key);
      END LOOP;
   END IF;
   
   IF p_sig.include_in_xml='Y' THEN

      IF p_sig.limit_rows='Y' THEN
         l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
      ELSE
         l_rows := least(p_col_rows(1).COUNT,50);
      END IF;
     
      FOR i IN 1..l_rows LOOP

         l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
         l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
         l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
         XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
         FOR j IN 1..p_col_headings.count LOOP
    
            l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
            l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
            l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
            XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
            l_value := p_col_rows(j)(i);

            IF p_sig_id = 'REC_PATCH_CHECK' THEN
               IF p_col_headings(j) = 'Patch' THEN
                  l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
               ELSIF p_col_headings(j) = 'Note' THEN
                  l_value := replace(replace(p_col_rows(j)(i),'['),']');
               END IF;
            END IF;
		 
   		 -- Rtrim the column value if blanks are not to be preserved
            IF NOT g_preserve_trailing_blanks THEN
               l_value := RTRIM(l_value, ' ');
            END IF;

            l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

          END LOOP;

       END LOOP;
     
     END IF;  --p_sig.include_in_xml='Y'
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml IN ('Y','P')) THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
	   -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;

       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;			
			
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div><br>');
END print_rep_subsection_end;


-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------



-------------------------
-- Recommended Patches
-------------------------




-------------------------
-- Signatures
-------------------------


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;
  l_key      VARCHAR2(255);

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;
  
  -- Clear FK values if the sig has children
  IF l_sig.child_sigs.count > 0 THEN
    l_key := g_sql_tokens.first;
    WHILE l_key is not null LOOP
      IF l_key like '##$$FK_$$##' THEN 
        g_sql_tokens.delete(l_key);
      END IF;
      l_key := g_sql_tokens.next(l_key);
    END LOOP;
  END IF;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
PROCEDURE validate_parameters(
            p_header_id                    IN NUMBER      DEFAULT NULL
           ,p_line_id                      IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 2000
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_revision                  VARCHAR2(25);
  l_date_char                 VARCHAR2(30);
  l_instance                  V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version              FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host                      V$INSTANCE.HOST_NAME%TYPE;
  l_key                       VARCHAR2(255);
  l_system_function_var       VARCHAR2(2000);
  l_index                     NUMBER:=1;

  invalid_parameters EXCEPTION;



l_exists_val       VARCHAR2(2000);



FUNCTION get_ORGID
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: ORGID');
BEGIN
  select org_id
    into l_system_function_var 
  from   oe_order_headers_all ord
  where 
     ORD.HEADER_ID = p_header_id;
  return l_system_function_var;
EXCEPTION WHEN NO_DATA_FOUND THEN
      return null;
END;
debug('end sql token function: ORGID');
END get_ORGID;

FUNCTION get_SALESORDERID
   return VARCHAR2 IS
BEGIN
debug('begin sql token function: SALESORDERID');
BEGIN
   select distinct MSO.SALES_ORDER_ID 
    into l_system_function_var 
    from MTL_SALES_ORDERS              MSO,
         OE_ORDER_HEADERS_ALL          ORD
   where ORD.HEADER_ID                 = p_header_id
   and  MSO.SEGMENT1                  = ORD.ORDER_NUMBER;
   return l_system_function_var;
EXCEPTION WHEN NO_DATA_FOUND THEN
      return null;
END;
debug('end sql token function: SALESORDERID');
END get_SALESORDERID;



BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
  l_revision := rtrim(replace('$Revision: 200.1  $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2016/01/07 08:37:00 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_rep_info('File Name') := 'om_order_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=2038363.1" target="_blank">(Note 2038363.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------

-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails

  IF substr(l_apps_version,1,4) NOT IN ('12.0','12.1','12.2') THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script is compatible for following version(s): 12.0,12.1,12.2');
	raise invalid_parameters;
  END IF;
  

  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');

debug('begin parameter validation: p_header_id');
IF p_header_id IS NULL OR p_header_id = '' THEN
   print_error('Parameter Header ID is required.');
   raise invalid_parameters;
END IF;
IF p_header_id IS NOT NULL THEN
BEGIN
SELECT HEADER_ID
INTO l_exists_val
FROM OE_ORDER_HEADERS_ALL
WHERE HEADER_ID = p_header_id;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('Invalid Header ID parameter provided.  Process cannot continue.');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_header_id');

debug('begin parameter validation: p_line_id');
IF p_line_id IS NOT NULL THEN
BEGIN
SELECT LINE_ID
INTO l_exists_val
FROM OE_ORDER_LINES_ALL
WHERE LINE_ID = p_line_id;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
         print_error('Invalid Line ID parameter provided.  Process cannot continue.');
   raise invalid_parameters;
END;
END IF;
debug('end parameter validation: p_line_id');






  -- Create global hash for parameters. Numbers required for the output order
debug('begin populate parameters hash table');
   g_parameters(l_index||'. Header ID') := p_header_id;
   l_index:=l_index+1;
   g_parameters(l_index||'. Line ID') := p_line_id;
   l_index:=l_index+1;
   g_parameters(l_index||'. Maximum Rows to Display') := p_max_output_rows;
   l_index:=l_index+1;
   g_parameters(l_index||'. Debug Mode') := p_debug_mode;
   l_index:=l_index+1;
debug('end populate parameters hash table');



  l_key := g_parameters.first;
  -- Print parameters to the log
  print_log('Parameter Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_parameters(l_key));
    l_key := g_parameters.next(l_key);
  END LOOP;
  
  -- Create global hash of SQL token values
debug('begin populate sql tokens hash table');
   g_sql_tokens('##$$LINEID$$##') := p_line_id;
   g_sql_tokens('##$$HEADERID$$##') := p_header_id;
   g_sql_tokens('##$$SALESORDERID$$##') := get_SALESORDERID();
   l_system_function_var := null;
   g_sql_tokens('##$$ORGID$$##') := get_ORGID();
   l_system_function_var := null;
debug('end populate sql tokens hash table');



  l_key := g_sql_tokens.first;
  -- Print token values to the log

  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN

null;

   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------


debug('begin add_signature: SALES_ORDER_RA_INTERFACE_LINES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_RA_INTERFACE_LINES',
      p_sig_sql                => 'select distinct
            RAI.INTERFACE_LINE_ID             "Interface Line ID", 
            RAI.BATCH_SOURCE_NAME             "Batch Source",                   
            RAI.INVENTORY_ITEM_ID             "Item ID",
            RAI.QUANTITY                      Qty,
            RAI.QUANTITY_ORDERED              "Qty Ordered",
            RAI.UOM_CODE                      UOM,
            RAI.AMOUNT                        Price,
            trim(RAI.SALES_ORDER_LINE)        "Sales Order Line",
            RAI.ACCOUNTING_RULE_ID            "Accounting Rule ID",
            RAI.INVOICING_RULE_ID             "Invoicing Rule ID",                  
            RAI.LINE_TYPE                     "Line Type",
            RAI.INTERFACE_LINE_ATTRIBUTE1     "Order Number",
            RAI.INTERFACE_LINE_ATTRIBUTE2     "Order Type",
            RAI.INTERFACE_LINE_ATTRIBUTE3     Delivery,
            RAI.INTERFACE_LINE_ATTRIBUTE4     WayBill,
            RAI.INTERFACE_LINE_ATTRIBUTE6     "Line ID",
            RAI.INTERFACE_LINE_ATTRIBUTE7     "Pick LIne ID",
            RAI.INTERFACE_LINE_ATTRIBUTE8     "Bill of Lading",
            RAI.INTERFACE_LINE_ATTRIBUTE10    "Warehouse ID",
            RAI.INTERFACE_LINE_ATTRIBUTE11    "PA ID",   
            RAI.CONVERSION_RATE               "Conversion Rate",
            to_Char(RAI.CONVERSION_DATE,''DD-MON-RR_HH24:MI:SS'') "Conversion Date", 
            RAI.CURRENCY_CODE                 Currency,                
            RAI.TAX_RATE                      "Tax Rate",
            RAI.SALES_TAX_ID                  "Sales Tax ID",
            RAI.VAT_TAX_ID                    "VAT Tax ID",
            RAI.TAX_EXEMPT_FLAG               Exempt,
            RAI.TERRITORY_ID                  TERR_ID
      
FROM
        RA_INTERFACE_LINES_ALL            RAI,
        OE_ORDER_LINES_ALL            LIN,
        OE_ORDER_HEADERS_ALL          ORD,
        OE_TRANSACTION_TYPES_TL       TYP
WHERE   
             RAI.SALES_ORDER = to_char(ORD.ORDER_NUMBER)
        and  RAI.INTERFACE_LINE_ATTRIBUTE2 = TYP.NAME
        and  TYP.TRANSACTION_TYPE_ID       = ORD.ORDER_TYPE_ID
        and  ORD.HEADER_ID                 = LIN.HEADER_ID
        and  RAI.LINE_TYPE                 = ''LINE''
        and  LIN.HEADER_ID                 = ##$$HEADERID$$##
        and  NVL(''##$$LINEID$$##'',0)  in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.REFERENCE_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)
        and NVL(RAI.INTERFACE_LINE_ATTRIBUTE6,0) in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.REFERENCE_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Receivables Interface Lines',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Receivable interface lines for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_RA_INTERFACE_LINES');



debug('begin add_signature: SALES_ORDER_HEADER_PRICE_ADJ');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_HEADER_PRICE_ADJ',
      p_sig_sql                => 'select
ADJ.PRICE_ADJUSTMENT_ID            "Price Adjustment ID",
nvl(ADJ.APPLIED_FLAG,''N'')          "Applied Flag",
ADJ.LIST_HEADER_ID                 "List Header ID",
ADJ.LIST_LINE_ID                   "List Line ID",
ADJ.LIST_LINE_NO                   "List Line Number",   
ADJ.MODIFIER_LEVEL_CODE            "Modifier Level",     
ADJ.LIST_LINE_TYPE_CODE            "List Line Type",
ADJ.CHARGE_TYPE_CODE               "Charge Type Code",             
ADJ.ARITHMETIC_OPERATOR            "Arithmetic Operator",  
ADJ.OPERAND_PER_PQTY               "Operand Per Qty",        
ADJ.ADJUSTED_AMOUNT_PER_PQTY       "Adjustment Amount Per Qty",
ADJ.OPERAND                        "Operand",                      
ADJ.ADJUSTED_AMOUNT                "Adjustment Amount",                             
ADJ.CREDIT_OR_CHARGE_FLAG          "Credit or Charge Flag",   
ADJ.PRINT_ON_INVOICE_FLAG          "Print on Invoice Flag",   
ADJ.ACCRUAL_FLAG                   "Accrual Flag",        
ADJ.INVOICED_FLAG                  "Invoice Flag",              
ADJ.ESTIMATED_FLAG                 "Estimated Flag",
ADJ.UPDATE_ALLOWED                 "Update Allowed Flag",        
ADJ.UPDATED_FLAG                   "Updated  Flag",        
ADJ.APPLIED_FLAG                   "Applied Flag",
ADJ.LOCK_CONTROL                   "Lock Control",                                      
ADJ.PERCENT                        "Percent",            
ADJ.COST_ID                        "Cost ID",               
ADJ.TAX_CODE                       "Tax Code",               
ADJ.PRICING_PHASE_ID               "Pricing Phase ID"
from OE_PRICE_ADJUSTMENTS   ADJ
where  ADJ.HEADER_ID                 = ##$$HEADERID$$##
        and  ADJ.LINE_ID              IS NULL
order by ADJ.APPLIED_FLAG,ADJ.LIST_LINE_TYPE_CODE',
      p_title                  => 'Header Price Adjustments',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Sales Order Header Price Adjustments on this order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_HEADER_PRICE_ADJ');



debug('begin add_signature: SALES_ORDER_MTL_SUPPLY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_MTL_SUPPLY',
      p_sig_sql                => 'select  
-- DROP SHIPMENTS 
  SUP.SUPPLY_TYPE_CODE               "Supply Type",
  SUP.REQ_HEADER_ID                  "Req Header ID",
  SUP.REQ_LINE_ID                    "Req Line ID",
  SUP.PO_HEADER_ID                   "PO Header ID",
  SUP.PO_RELEASE_ID                  "PO Release ID",
  SUP.PO_LINE_ID                     "PO Line ID",
  SUP.PO_LINE_LOCATION_ID            "PO Line Loc ID",
  SUP.PO_DISTRIBUTION_ID             "PO Distribution ID",
  SUP.SHIPMENT_HEADER_ID             "Shipment Header ID",
  SUP.SHIPMENT_LINE_ID               "Shipment Line ID",
  SUP.RCV_TRANSACTION_ID             "Receiving Trx ID",
  SUP.ITEM_ID                        "Item ID",
  SUP.QUANTITY                       QTY,
  to_char(SUP.RECEIPT_DATE,''DD-MON-RR_HH24:MI:SS'')  "Receipt Date",
  to_char(SUP.NEED_BY_DATE,''DD-MON-RR_HH24:MI:SS'')  "Need By Date",
  SUP.DESTINATION_TYPE_CODE          "Destination Type",
  SUP.FROM_ORGANIZATION_ID           "From Org",
  SUP.FROM_SUBINVENTORY              "From Sub",
  SUP.TO_ORGANIZATION_ID             "To Org",
  SUP.TO_SUBINVENTORY                "To Sub",
  SUP.INTRANSIT_OWNING_ORG_ID        "Intrans Owning Org"
from
   MTL_SUPPLY           SUP,
   OE_DROP_SHIP_SOURCES SRC,
   OE_ORDER_LINES_ALL   LIN
where 
     SRC.LINE_ID                   = LIN.LINE_ID
and  SRC.PO_LINE_ID                = SUP.PO_LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select         
--INTERNAL SALES ORDER
  SUP.SUPPLY_TYPE_CODE               SUP_TYPE,
  SUP.REQ_HEADER_ID                  REQ_HEAD_ID,
  SUP.REQ_LINE_ID                    REQ_LINE_ID,
  SUP.PO_HEADER_ID                   PO_HEAD_ID,
  SUP.PO_RELEASE_ID                  PO_REL_ID,
  SUP.PO_LINE_ID                     PO_LINE_ID,
  SUP.PO_LINE_LOCATION_ID            PO_LINE_LOC_ID,
  SUP.PO_DISTRIBUTION_ID             PO_DIST_ID,
  SUP.SHIPMENT_HEADER_ID             SHP_HEAD_ID,
  SUP.SHIPMENT_LINE_ID               SHP_LINE_ID,
  SUP.RCV_TRANSACTION_ID             RCV_TRANS_ID,
  SUP.ITEM_ID                        ITEM_ID,
  SUP.QUANTITY                       QTY,
  to_char(SUP.RECEIPT_DATE,''DD-MON-RR_HH24:MI:SS'') RECPT_DT,
  to_char(SUP.NEED_BY_DATE,''DD-MON-RR_HH24:MI:SS'') NEED_BY_DT,
  SUP.DESTINATION_TYPE_CODE          DEST_TYPE,
  SUP.FROM_ORGANIZATION_ID           FROM_ORG,
  SUP.FROM_SUBINVENTORY              FROM_SUB,
  SUP.TO_ORGANIZATION_ID             TO_ORG,
  SUP.TO_SUBINVENTORY                TO_SUB,
  SUP.INTRANSIT_OWNING_ORG_ID        INTRNS_OWN_ORG
from
   MTL_SUPPLY           SUP,
   OE_ORDER_LINES_ALL   LIN
where 
     LIN.SOURCE_DOCUMENT_LINE_ID       = SUP.REQ_LINE_ID
and  LIN.SOURCE_DOCUMENT_TYPE_ID       = 10                        
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Material Supply',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No associated material supply for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_MTL_SUPPLY');



debug('begin add_signature: SALES_ORDER_LINES_DISPLAY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_DISPLAY',
      p_sig_sql                => 'select 
    substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
     LIN.LINE_ID                   "Line ID",
     LIN.INVENTORY_ITEM_ID         "Item ID",
     substr(ITM.SEGMENT1,1,80)     "Item Name",
     substr(LIN.FLOW_STATUS_CODE,1,22) "Workflow Status",
     nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
     LIN.ORDER_QUANTITY_UOM        "Ordered UOM",
     nvl(LIN.ORDERED_QUANTITY2,0)  "Ordered QTY 2",
     LIN.ORDERED_QUANTITY_UOM2     "Ordered UOM 2",
     LIN.UNIT_SELLING_PRICE        "Selling Price",
     LIN.UNIT_LIST_PRICE           "List Price",
     nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
     nvl(LIN.SHIPPED_QUANTITY2,0)  "Shipped  QTY 2",
     nvl(LIN.SHIPPING_QUANTITY,0)  "Shipping QTY",
     nvl(LIN.SHIPPING_QUANTITY2,0) "Shipping QTY 2",
     nvl(LIN.SHIPPING_QUANTITY_UOM2,0)  "Shipping QTY UOM 2",
     nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
     nvl(FULFILLED_QUANTITY2,0)    "Fulfilled QTY 2",
     nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY",      
     nvl(LIN.CANCELLED_QUANTITY2,0) "Cancelled QTY 2",      
     nvl(LIN.INVOICED_QUANTITY,0)  "Invoiced QTY", 
     substr(LIN.SCHEDULE_STATUS_CODE,1,5)      "Schedule Code",
     nvl(LIN.OPEN_FLAG,''N'')        "Open",
     nvl(LIN.BOOKED_FLAG,''N'')      "Booked",
     nvl(LIN.SHIPPABLE_FLAG,''N'')   "Shipped",
     nvl(LIN.CANCELLED_FLAG,''N'')   "Cancelled",
     nvl(LIN.VISIBLE_DEMAND_FLAG,''N'')  "Visual Demand",
     nvl(LIN.FULFILLED_FLAG, ''N'')  "Fullfilled",
     nvl(LIN.SHIPPING_INTERFACED_FLAG,''N'')    "Shipping Interface",
     decode(nvl(LIN.ATO_LINE_ID,0),0,''N'',''Y'') "ATO Line",
     nvl(LIN.SHIP_MODEL_COMPLETE_FLAG,''N'')  "Ship Model Complete",
     LIN.SHIP_FROM_ORG_ID          "Ship From",
     to_char(LIN.REQUEST_DATE,''DD-MON-RR_HH24:MI:SS'')  "Request Date",
     to_char(LIN.SCHEDULE_SHIP_DATE,''DD-MON-RR_HH24:MI:SS'') "Schedule Ship Date",
     LIN.LINE_TYPE_ID              "Line Type ID",
     LIN.LINE_CATEGORY_CODE        "Line Category",
     LIN.ITEM_TYPE_CODE            "Item Code",
     LIN.ORDERED_ITEM_ID           "Ordered Item ID",
     substr(LIN.ORDERED_ITEM,1,45)              "Ordered Item Name",
     LIN.SOURCE_TYPE_CODE          "Source Type Code",
     LIN.PRICE_LIST_ID             "Price List ID",
     LIN.DEMAND_CLASS_CODE         "Demand Class",
     nvl(LIN.OPTION_FLAG,''N'')                 "Option Flag",
     LIN.TOP_MODEL_LINE_ID                    "Top Model Line ID",
     LIN.ATO_LINE_ID                          "Model Line ID",
     LIN.LINK_TO_LINE_ID                      "Link to Line ID",
     LIN.SPLIT_BY                             "Split By",
     LIN.SPLIT_FROM_LINE_ID                   "Split From",
     LIN.CONFIG_HEADER_ID                     "Config Header ID", 
     nvl(LIN.INVOICE_INTERFACE_STATUS_CODE,''N'') "Invoice Interface",
     LIN.SHIP_TOLERANCE_ABOVE                 "Ship Tolerance Above",
     LIN.SHIP_TOLERANCE_BELOW                 "Ship Tolerance Below",            
     LIN.SHIP_SET_ID                          "Ship Set ID",
     ST2.SET_TYPE                             "Set Type",
     LIN.LINE_SET_ID                          "Line Set ID",
     ST3.SET_TYPE                             "Set Type",
     LIN.ARRIVAL_SET_ID                       "Arrival Set ID",
     ST1.SET_TYPE                             "Set Type",
     LIN.CALCULATE_PRICE_FLAG                 "Calculate Price",
     to_char(LIN.ACTUAL_SHIPMENT_DATE,''DD-MON-RR_HH24:MI:SS'')  "Actual Ship",
     to_char(LIN.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Create Date",
     LIN.ordered_quantity2                    "Ordered QTY 2",
     LIN.ordered_quantity_uom2                "Ordered QTY UOM 2",
     to_char(LIN.LAST_UPDATE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Update Date",
     ITM.TRACKING_QUANTITY_IND                "Tracking QTY",
     ITM.PRIMARY_UOM_CODE                     "Primary UOM",
     ITM.DUAL_UOM_CONTROL                     "Dual UOM",
     ITM.SECONDARY_DEFAULT_IND                "Sec Def Ind",
     ITM.SECONDARY_UOM_CODE                   "Sec UOM",
     ITM.CHILD_LOT_FLAG                       "Child Lot",
     ITM.PARENT_CHILD_GENERATION_FLAG         "Par Child",
     ITM.LOT_DIVISIBLE_FLAG                   "Lot Div",
     ITM.GRADE_CONTROL_FLAG                   "Grad CTRL",
     Decode(ITM.ONT_PRICING_QTY_SOURCE,
            ''P'',''Primary'', ''Secondary'')       "ONT PR QTY",
     ITM.dual_uom_deviation_high              "Dual UOM DEV High",
     ITM.dual_uom_deviation_low               "Dual UOM DEV Low",
     ITM.lot_control_code                     "Lot CTRL Code",
     ITM.location_control_code                "Location CTRL Code",
     ITM.lot_status_enabled                   "Lot Status Enabled",
     LIN.source_document_line_id              "Source Doc Line ID"
from
     OE_ORDER_LINES_ALL                LIN,
     MTL_SYSTEM_ITEMS              ITM,
     OE_SETS                       ST1,
     OE_SETS                       ST2,
     OE_SETS                       ST3
where
     LIN.HEADER_ID                  = ##$$HEADERID$$##
and  LIN.LINE_ID     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
and  LIN.SHIP_FROM_ORG_ID           = ITM.ORGANIZATION_ID(+)
and  LIN.INVENTORY_ITEM_ID          = ITM.INVENTORY_ITEM_ID(+)
and  LIN.ARRIVAL_SET_ID            = ST1.SET_ID(+)
and  LIN.SHIP_SET_ID               = ST2.SET_ID(+)
and  LIN.LINE_SET_ID               = ST3.SET_ID(+)
order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Line(s)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No lines on this order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_DISPLAY');



debug('begin add_signature: SALES_ORDER_HEADER_INFORMATION_DISPLAY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_HEADER_INFORMATION_DISPLAY',
      p_sig_sql                => 'select  distinct ORD.HEADER_ID            "HEADER ID",
            ORD.ORDER_NUMBER                  "ORDER NO",
            ORD.ORDER_TYPE_ID                 "ORDER TYPE",
            TYP.NAME                          "TYPE NAME",
            ORD.SOLD_TO_ORG_ID                "SOLD TO ID",
            substr(CUS.CUSTOMER_NAME,1,20)    "CUST NAME",
            ORD.SHIP_TO_ORG_ID                "SHIP TO ID",
            substr(SHP.NAME,1,12)             "SHIP NAME",
            ORD.INVOICE_TO_ORG_ID             "BILL TO ID",
            to_char(ORD.ORDERED_DATE,''DD-MON-RR_HH24:MI:SS'')  "ORDER DATE",
            nvl(ORD.BOOKED_FLAG,''N'')          "BOOKED",
            nvl(ORD.OPEN_FLAG,''N'')            "OPEN",
            nvl(ORD.CANCELLED_FLAG,''N'')       "CANCELLED",
            nvl(ORD.PARTIAL_SHIPMENTS_ALLOWED,''Y'') "PARTIAL SHIP",
            ORD.SHIP_FROM_ORG_ID                   "SHIP FROM",
            PAR.ORGANIZATION_CODE                  "ORG CODE",
            ORD.FLOW_STATUS_CODE                   "FLOW STATUS",
            ORD.ORDER_CATEGORY_CODE                "ORDER CAT",
            ORD.PRICE_LIST_ID                      "PRICE LIST ID",
            PRC.NAME                               "PRICE LIST NAME",
            ORD.CUST_PO_NUMBER                     "PO NO",
            ORD.SHIP_TOLERANCE_ABOVE               "SHIP TOL ABOVE",
            ORD.SHIP_TOLERANCE_BELOW               "SHIP TOL BELOW",
            HR.NAME                                "OPERATING UNIT"
from
     oe_order_headers_all              ORD,
     MTL_PARAMETERS                    PAR,
     OE_TRANSACTION_TYPES_TL            TYP,
     AR_CUSTOMERS                      CUS,
     OE_SHIP_TO_ORGS_V                 SHP,
     QP_LIST_HEADERS_V                 PRC,
     HR_OPERATING_UNITS                HR
where
     ORD.HEADER_ID                 = (''##$$HEADERID$$##'')
and  ORD.SHIP_FROM_ORG_ID          = PAR.ORGANIZATION_ID(+)
and  ORD.ORDER_TYPE_ID             = TYP.TRANSACTION_TYPE_ID(+)
and  ORD.SHIP_TO_ORG_ID            = SHP.SITE_USE_ID(+)
and  ORD.SOLD_TO_ORG_ID            = CUS.CUSTOMER_ID(+)
and  ORD.PRICE_LIST_ID             = PRC.LIST_HEADER_ID(+)
and  ORD.ORG_ID                    = HR.ORGANIZATION_ID(+)',
      p_title                  => 'Sales Order Header Information',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Sales Order Header Information',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_HEADER_INFORMATION_DISPLAY');



debug('begin add_signature: SALES_ORDER_WSH_TRIPS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_TRIPS',
      p_sig_sql                => 'select distinct 
  TRP.TRIP_ID                      "Trip ID",
  TRP.NAME                         Name,
  TRP.PLANNED_FLAG                 Planned,
  TRP.STATUS_CODE                  "Status Code",
  TRP.VEHICLE_NUMBER               "Vehicle Number",
  TRP.CARRIER_ID                   "Carrier ID",
  TRP.SHIP_METHOD_CODE             "Ship Method",
  TRP.ROUTE_ID                     "Route ID",
  TRP.VEHICLE_ORGANIZATION_ID      "Vehicle Org ID"
FROM 
  WSH_TRIPS                        TRP
where
  TRIP_ID in 
      (select distinct(STP.TRIP_ID)
       FROM
            OE_ORDER_LINES_ALL               LIN,
            WSH_DELIVERY_DETAILS             DET,
            WSH_NEW_DELIVERIES               DEL,
            WSH_DELIVERY_LEGS                LEG,
            WSH_TRIP_STOPS                   STP,
            WSH_DELIVERY_ASSIGNMENTS         ASG
       WHERE
            DEL.DELIVERY_ID                 = ASG.DELIVERY_ID AND
            ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID AND
            DET.SOURCE_LINE_ID              = LIN.LINE_ID AND  
            STP.STOP_ID                     = LEG.PICK_UP_STOP_ID AND
            LEG.DELIVERY_ID                 = DEL.DELIVERY_ID AND 
            LIN.HEADER_ID                   = ##$$HEADERID$$## AND
            NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
       )
order by TRP.TRIP_ID',
      p_title                  => 'Shipping Trips',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no assigned Trips to this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_TRIPS');



debug('begin add_signature: SALES_ORDER_DROP_SHIP_SOURCES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_DROP_SHIP_SOURCES',
      p_sig_sql                => 'select 
 SRC.DROP_SHIP_SOURCE_ID                      "Drop Ship ID",
 SRC.HEADER_ID                                "Header ID",
 SRC.LINE_ID                                  "Line ID",
    to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
 SRC.ORG_ID                                   "Org ID",
 SRC.DESTINATION_ORGANIZATION_ID              "Destination Org ID",
 PAR.ORGANIZATION_CODE                        "Destination Org",
 SRC.REQUISITION_HEADER_ID                    "Req Header ID",
 SRC.REQUISITION_LINE_ID                      "Req Line ID",
 SRC.PO_HEADER_ID                             "PO Header ID",
 SRC.PO_LINE_ID                               "PO Line ID",
 SRC.LINE_LOCATION_ID                         "Line Location ID",
 SRC.PO_RELEASE_ID                            "PO Release ID"
FROM OE_DROP_SHIP_SOURCES    SRC,
     OE_ORDER_LINES_ALL      LIN, 
     MTL_PARAMETERS          PAR
WHERE
     SRC.LINE_ID                      = LIN.LINE_ID
and  SRC.DESTINATION_ORGANIZATION_ID  = PAR.ORGANIZATION_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
order by
     NVL(LIN.TOP_MODEL_LINE_ID,         LIN.LINE_ID),
     NVL(LIN.ATO_LINE_ID,               LIN.LINE_ID),
     NVL(LIN.SORT_ORDER,                ''0000''),
     NVL(LIN.LINK_TO_LINE_ID,           LIN.LINE_ID),
     NVL(LIN.SOURCE_DOCUMENT_LINE_ID,   LIN.LINE_ID),
     LIN.LINE_ID',
      p_title                  => 'Sales Order Drop Ship Sources',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No drop ship sources for this sales orders.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_DROP_SHIP_SOURCES');



debug('begin add_signature: SALES_ORDER_LINE_WF_ACTIVITY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_WF_ACTIVITY',
      p_sig_sql                => 'select substr(WFS.ITEM_KEY,1,45)  "Line ID",
       substr(WFA.DISPLAY_NAME,1,90)  "PROCESS",
       substr(WFA1.DISPLAY_NAME,1,90)     "ACTIVITY",
       substr(WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE),1,15) "RESULT",
       substr(LKP.MEANING,1,30)          "ACT STATUS",
       WFS.NOTIFICATION_ID   "NOTIFICATION ID",
       WFP.PROCESS_NAME      "PROCESS NAME",
       WFP.ACTIVITY_NAME     "ACTIVITY NAME",
       WFS.ACTIVITY_RESULT_CODE   "RESULT CODE",
       to_char(WFS.BEGIN_DATE,''DD-MON-RR_HH24:MI:SS'') "BEGIN DATE",
       to_char(WFS.END_DATE,''DD-MON-RR_HH24:MI:SS'')   "END DATE",
       WFS.ERROR_NAME        "ERROR NAME",
       WFS.BEGIN_DATE             "BEGIN DATE 2",
       WFS.EXECUTION_TIME         "EXECUTION TIME"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP
where 
     WFS.ITEM_TYPE          = ''OEOL''
  and  WFS.item_key           in 
              (select to_char(line_id) from OE_ORDER_LINES_ALL LIN
               where LIN.HEADER_ID = ##$$HEADERID$$##
               and NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                           LIN.TOP_MODEL_LINE_ID,
                                           LIN.ATO_LINE_ID,
                                           LIN.LINK_TO_LINE_ID,
                                           LIN.SERVICE_REFERENCE_LINE_ID)) 
  and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
  and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
  and  WFP.PROCESS_NAME       = WFA.NAME
  and  WFP.PROCESS_VERSION    = WFA.VERSION
  and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
  and  WFP.ACTIVITY_NAME      = WFA1.NAME
  and  WFA1.VERSION = 
      (select max(VERSION)
       from WF_ACTIVITIES WF2
       where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
       and   WF2.NAME      = WFP.ACTIVITY_NAME)
  and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
  and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
ORDER BY WFS.ITEM_KEY,WFS.BEGIN_DATE',
      p_title                  => 'Sales Order Line WF Activity',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Line Workflow Activity found.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_WF_ACTIVITY');



debug('begin add_signature: SALES_ORDER_HEADER_WF_ACTIVITY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_HEADER_WF_ACTIVITY',
      p_sig_sql                => 'select substr(WFS.ITEM_KEY,1,45)  "Item Key",
       substr(WFA.DISPLAY_NAME,1,45)  "PROCESS",
       substr(WFA1.DISPLAY_NAME,1,45)     "ACTIVITY",
       substr(WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE),1,15) "RESULT",
       substr(LKP.MEANING,1,30)          "ACT STATUS",
       WFS.NOTIFICATION_ID   "NOTIFICATION ID",
       WFP.PROCESS_NAME      "PROCESS NAME",
       WFP.ACTIVITY_NAME     "ACTIVITY NAME",
       WFS.ACTIVITY_RESULT_CODE   "RESULT CODE",
       to_char(WFS.BEGIN_DATE,''DD-MON-RR_HH24:MI:SS'') "BEGIN DATE",
       to_char(WFS.END_DATE,''DD-MON-RR_HH24:MI:SS'')   "END DATE",
       WFS.ERROR_NAME        "ERROR NAME"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP
where 
     WFS.ITEM_TYPE          = ''OEOH''
and  WFS.item_key           = to_char((''##$$HEADERID$$##''))
and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
and  WFP.PROCESS_NAME       = WFA.NAME
and  WFP.PROCESS_VERSION    = WFA.VERSION
and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
and  WFP.ACTIVITY_NAME      = WFA1.NAME
and  WFA1.VERSION           = 
                             (select max(VERSION)
                              from WF_ACTIVITIES WF2
                              where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
                              and   WF2.NAME = WFP.ACTIVITY_NAME)
and  LKP.LOOKUP_TYPE        = ''WFENG_STATUS''
and  LKP.LOOKUP_CODE        = WFS.ACTIVITY_STATUS
order by WFS.ITEM_KEY, 
        WFS.BEGIN_DATE, 
        EXECUTION_TIME',
      p_title                  => 'Sales Order Header WF Activity',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'Sales Order Header Workflow Information',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_HEADER_WF_ACTIVITY');



debug('begin add_signature: SALES_ORDER_LINE_PRICE_ADJUSTMENTS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_PRICE_ADJUSTMENTS',
      p_sig_sql                => 'select
    ADJ.PRICE_ADJUSTMENT_ID            "Price Adjustment ID",
    to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
     ADJ.LIST_HEADER_ID                 "List Header ID",             
     ADJ.LIST_LINE_ID                   "List Line ID",  
     ADJ.LIST_LINE_NO                   "List Line Number",   
     ADJ.MODIFIER_LEVEL_CODE            "Modifier Level Code",     
     ADJ.LIST_LINE_TYPE_CODE            "List Line Type",
     ADJ.CHARGE_TYPE_CODE               "Charge Type Code",             
     ADJ.ARITHMETIC_OPERATOR            "Arithmetic Operator",  
     ADJ.OPERAND_PER_PQTY               "Operand Per Qty",        
     ADJ.ADJUSTED_AMOUNT_PER_PQTY       "Adjusted Amount Per Qty",
     ADJ.OPERAND                        Operand,                      
     ADJ.ADJUSTED_AMOUNT                "Adjusted Amount",                             
     ADJ.CREDIT_OR_CHARGE_FLAG          "Credit or Charge Flag",                          
     ADJ.AUTOMATIC_FLAG                 "Automatic Flag",   
     ADJ.PRINT_ON_INVOICE_FLAG          "Print on Invoice",   
     ADJ.ACCRUAL_FLAG                   "Accrual Flag",        
     ADJ.INVOICED_FLAG                  "Invoiced Flag",              
     ADJ.ESTIMATED_FLAG                 "Estimated Flag",
     ADJ.UPDATE_ALLOWED                 "Update Allowed",        
     ADJ.UPDATED_FLAG                   "Updated Flag",         
     ADJ.APPLIED_FLAG                   "Applied Flag", 
     ADJ.LOCK_CONTROL                   "lock Control",                                      
     ADJ.PERCENT                        Percent,            
     ADJ.COST_ID                        "Cost ID",               
     ADJ.TAX_CODE                       "Tax Code",               
     ADJ.PRICING_PHASE_ID               "Pricing Phase"
from OE_PRICE_ADJUSTMENTS   ADJ,
     OE_ORDER_LINES_ALL     LIN
where  ADJ.HEADER_ID             = ##$$HEADERID$$##
  and  LIN.HEADER_ID             = ##$$HEADERID$$##
  and  ADJ.LINE_ID               IS NOT NULL
  and  ADJ.LINE_ID               = LIN.LINE_ID
  and  NVL(''##$$LINEID$$##'',0) in (0,LIN.LINE_ID,
                                       LIN.TOP_MODEL_LINE_ID,
                                       LIN.ATO_LINE_ID,
                                       LIN.LINK_TO_LINE_ID,
                                       LIN.REFERENCE_LINE_ID,
                                       LIN.SERVICE_REFERENCE_LINE_ID)
  and  ADJ.APPLIED_FLAG         = ''Y''
order by LINE,
         ADJ.LIST_LINE_TYPE_CODE',
      p_title                  => 'Applied Line Price Adjustments',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No line price adjustments for this order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_PRICE_ADJUSTMENTS');



debug('begin add_signature: SALES_ORDER_PO_REQUISITIONS_INTERFACE_ALL');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_PO_REQUISITIONS_INTERFACE_ALL',
      p_sig_sql                => 'Select
     RQI.INTERFACE_SOURCE_LINE_ID           "Drop Ship ID",
     to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
     RQI.AUTHORIZATION_STATUS               "Authorization Status",   
     RQI.DELIVER_TO_LOCATION_ID             "Delivery To Loc",
     RQI.PREPARER_ID                        Preparer,
     RQI.DESTINATION_ORGANIZATION_ID        "Destination Org ID",
     RQI.DESTINATION_TYPE_CODE              "Destination Type",
     RQI.INTERFACE_SOURCE_CODE              "Source Code",
     RQI.SOURCE_TYPE_CODE                   "Source Type Code",
     RQI.ITEM_ID                            "Item ID",
     to_char(RQI.NEED_BY_DATE,''DD-MON-RR_HH24:MI:SS'')  "Need By",                               
     RQI.QUANTITY                           Qty,                  
     RQI.UNIT_PRICE                         Price
from  PO_REQUISITIONS_INTERFACE_ALL   RQI,
      OE_DROP_SHIP_SOURCES            SRC,
      OE_ORDER_LINES_ALL              LIN
where  SRC.LINE_ID                      = LIN.LINE_ID
  and  SRC.DROP_SHIP_SOURCE_ID          = RQI.INTERFACE_SOURCE_LINE_ID
  and  LIN.HEADER_ID                 = ##$$HEADERID$$##
  and  NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                           LIN.TOP_MODEL_LINE_ID,
                                           LIN.ATO_LINE_ID,
                                           LIN.LINK_TO_LINE_ID,
                                           LIN.SERVICE_REFERENCE_LINE_ID)
order by
     NVL(LIN.TOP_MODEL_LINE_ID,            LIN.LINE_ID),
     NVL(LIN.ATO_LINE_ID,               LIN.LINE_ID),
     NVL(LIN.SORT_ORDER,                ''0000''),
     NVL(LIN.LINK_TO_LINE_ID,           LIN.LINE_ID),
     NVL(LIN.SOURCE_DOCUMENT_LINE_ID,   LIN.LINE_ID),
     LIN.LINE_ID ',
      p_title                  => 'PO Requisitions Interface',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No PO Requisition Interface records for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_PO_REQUISITIONS_INTERFACE_ALL');



debug('begin add_signature: SALES_ORDER_MTL_RESERVATIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_MTL_RESERVATIONS',
      p_sig_sql                => 'select 
     RES.RESERVATION_ID               "Reservation ID",
     decode(RES.SHIP_READY_FLAG,
        1,''1=Released'',
        2,''2=Submitted'',
        to_char(RES.SHIP_READY_FLAG)) "Ship Ready", 
     RES.DEMAND_SOURCE_HEADER_ID      "Demand Source Header",
     RES.DEMAND_SOURCE_LINE_ID        "Demand Source Line",
     RES.DEMAND_SOURCE_DELIVERY       "Demand Source Delivery",
     to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
     RES.INVENTORY_ITEM_ID            "Item ID",
     ITM.SEGMENT1                     Item,
     RES.PRIMARY_RESERVATION_QUANTITY "Reservation QTY",
     RES.DETAILED_QUANTITY            "Detailed QTY",
     RES.PRIMARY_UOM_CODE             UOM,
     To_char(RES.REQUIREMENT_DATE,''DD-MON-RR_HH24:MI:SS'') "Required Date",
     RES.DEMAND_SOURCE_TYPE_ID        "Demand Source Type",
     RES.ORGANIZATION_ID              Warehouse,
     RES.SUBINVENTORY_CODE            Subinventory,
     RES.LOT_NUMBER                   Lot,
     RES.REVISION                     Revision,
     RES.LOCATOR_ID                   "Locator ID",
     RES.SERIAL_NUMBER                "Serial Number",
     decode(RES.SUPPLY_SOURCE_TYPE_ID,
            5,''5=WIP DJ'',
            RES.SUPPLY_SOURCE_TYPE_ID) "Supply Source",
     WIP.WIP_ENTITY_ID                "WIP ID",
     WIP.WIP_ENTITY_NAME              "Job Name",
     JOB.STATUS_TYPE_DISP             "Job Start",
     RES.SUPPLY_SOURCE_HEADER_ID      "Supply Source Header",      
     RES.SUPPLY_SOURCE_LINE_DETAIL    "Supply Source Line Detail",
     RES.SUPPLY_SOURCE_LINE_ID        "Supply Source Line ID",
     res.secondary_reservation_quantity "Secondary Res Qty",
     inv_convert.inv_um_convert(
                            res.inventory_item_id,
                            res.lot_number,
                            res.organization_id,
                            5,
                            res.primary_reservation_quantity,
                            res.primary_uom_code,
                            res.secondary_uom_code,
                            null,
                            null) "Calc Sec Res Qty",
     res.secondary_uom_code UOM2,
     res.secondary_detailed_quantity  "Sec Detail Qty"
from
     MTL_RESERVATIONS              RES,
     OE_ORDER_LINES_ALL            LIN,
     MTL_SYSTEM_ITEMS              ITM,
     WIP_ENTITIES                  WIP,
     WIP_DISCRETE_JOBS_V           JOB
where
     ##$$SALESORDERID$$##               = RES.DEMAND_SOURCE_HEADER_ID
and  RES.DEMAND_SOURCE_TYPE_ID     in  (2,8,9,21,22)
and  RES.DEMAND_SOURCE_LINE_ID     = LIN.LINE_ID
and  NVL(''##$$LINEID$$##'',0)       in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
and  RES.ORGANIZATION_ID           = ITM.ORGANIZATION_ID
and  RES.INVENTORY_ITEM_ID         = ITM.INVENTORY_ITEM_ID
and  RES.SUPPLY_SOURCE_HEADER_ID   = WIP.WIP_ENTITY_ID
and  WIP.WIP_ENTITY_ID             = JOB.WIP_ENTITY_ID
order by
     NVL(LIN.TOP_MODEL_LINE_ID,         LIN.LINE_ID),
     NVL(LIN.ATO_LINE_ID,               LIN.LINE_ID),
     NVL(LIN.SORT_ORDER,                ''0000''),
     NVL(LIN.LINK_TO_LINE_ID,           LIN.LINE_ID),
     NVL(LIN.SOURCE_DOCUMENT_LINE_ID,   LIN.LINE_ID),
     LIN.LINE_ID,
     RES.RESERVATION_ID',
      p_title                  => 'Material Reservations',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No material reservations for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_MTL_RESERVATIONS');



debug('begin add_signature: SALES_ORDER_RA_INTERFACE_ERRORS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_RA_INTERFACE_ERRORS',
      p_sig_sql                => 'select
 to_number(ril.interface_line_attribute6) Line,
 ril.interface_line_id                    "Interface Line ID",
 ril.line_type                            "Line Type",
 ril.batch_source_name                    "Batch Source",
 ril.quantity                             "Invoiced",
 ril.quantity_ordered                     "Qty Ordered",
 ril.uom_code                             "Ordered UOM",
 ril.unit_selling_price                   "Selling Price",
 ril.amount                               "Amount",
 ril.promised_commitment_amount           "Promised Commitment",
 ril.currency_code                        "Currency",
 ril.purchase_order                       "Customer PO",
 ril.reference_line_id                    "Credit Invoice",
 ril.customer_bank_account_id             "Bank Acc ID",
 ril.receipt_method_id                    "Receipt Method",
 ril.interface_status                     "Status",
 rie.message_text                         "Error Message"
from ra_interface_lines_all ril,
 ra_interface_errors_all rie, 
 oe_order_headers_all ooh,
 OE_ORDER_LINES_ALL            LIN,
 oe_transaction_types_tl ott
where ooh.header_id = ##$$HEADERID$$##
and ooh.order_type_id = ott.transaction_type_id
and ott.language = ( select fl.language_code
 from fnd_languages fl
 where fl.installed_flag = ''B'')
and ril.interface_line_context = ''ORDER ENTRY''
and ril.interface_line_attribute1 = to_char(ooh.order_number)
and ril.interface_line_attribute2 = ott.name
and rie.interface_line_id = ril.interface_line_id
and NVL(''##$$LINEID$$##'',0) in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.REFERENCE_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)
and NVL(ril.INTERFACE_LINE_ATTRIBUTE6,0) in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.REFERENCE_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)
and  LIN.HEADER_ID = ##$$HEADERID$$##
order by ril.interface_line_attribute6',
      p_title                  => 'Invoice Interface Errors',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Invoice Interface Errors for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_RA_INTERFACE_ERRORS');



debug('begin add_signature: SALES_ORDER_WSH_TRIP_STOPS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_TRIP_STOPS',
      p_sig_sql                => 'select distinct 
  STP.STOP_ID                      "Stop ID",
  STP1.STOP_DESCRIPTION            "Stop Description",
  STP.TRIP_ID                      "Trip ID",
  TRP.NAME                         "Trip Name",
  STP.STOP_LOCATION_ID             "Stop Loc ID",
  STP.STATUS_CODE                  Status,
  STP.LOCK_STOP_ID                 "Lock Stop ID",
  STP.PENDING_INTERFACE_FLAG       "Pending Interface",
  to_char(STP.PLANNED_DEPARTURE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Planned Departure Date",
  to_char(STP.ACTUAL_DEPARTURE_DATE,''DD-MON-RR_HH24:MI:SS'')   "Actual Departure Date"
FROM 
  WSH_TRIP_STOPS                   STP,
  WSH_SRS_TRIP_STOPS_V             STP1,
  WSH_TRIPS                        TRP
where
  STP.TRIP_ID                     = TRP.TRIP_ID(+) AND
  STP1.STOP_ID                    = STP.STOP_ID AND
  STP.STOP_ID in 
        (
         (select distinct(LEG.PICK_UP_STOP_ID)
         from   
            OE_ORDER_LINES                   LIN,
            WSH_DELIVERY_DETAILS             DET,
            WSH_NEW_DELIVERIES               DEL,
            WSH_DELIVERY_LEGS                LEG,
            WSH_DELIVERY_ASSIGNMENTS         ASG
         where
         DEL.DELIVERY_ID                 = ASG.DELIVERY_ID AND
         ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID AND
         DET.SOURCE_LINE_ID              = LIN.LINE_ID AND  
         LEG.DELIVERY_ID                 = DEL.DELIVERY_ID AND 
         LIN.HEADER_ID                   = ##$$HEADERID$$## AND
         NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
         )
         UNION
         (select distinct(LEG.DROP_OFF_STOP_ID)
         from   
            OE_ORDER_LINES_ALL               LIN,
            WSH_DELIVERY_DETAILS             DET,
            WSH_NEW_DELIVERIES               DEL,
            WSH_DELIVERY_LEGS                LEG,
            WSH_DELIVERY_ASSIGNMENTS         ASG
         where
         DEL.DELIVERY_ID                 = ASG.DELIVERY_ID AND
         ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID AND
         DET.SOURCE_LINE_ID              = LIN.LINE_ID AND  
         LEG.DELIVERY_ID                 = DEL.DELIVERY_ID AND 
         LIN.HEADER_ID                   = ##$$HEADERID$$## AND
         NVL(''##$$LINEID$$##'',0)       in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
         )
        )',
      p_title                  => 'Trip Stops',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Trip Stops associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_TRIP_STOPS');



debug('begin add_signature: SALES_ORDER_GENERIC_HOLD_DISPLAY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_GENERIC_HOLD_DISPLAY',
      p_sig_sql                => 'SELECT 
  HDF.HOLD_ID                        "HOLD ID",
  HDF.NAME                           "HOLD NAME",
  HDF.TYPE_CODE                      "TYPE CODE",
  HDF.ITEM_TYPE                      "ITEM TYPE",
  HDF.ACTIVITY_NAME                  "ACTIVITY",
  HLD.ORDER_HOLD_ID                  "ORDER HOLD ID",
  HLD.HOLD_SOURCE_ID                 "HOLD SOURCE ID",
  HLD.HOLD_RELEASE_ID                "HOLD RELEASE ID",
  HLD.HEADER_ID                      "HEADER ID",
  HLD.RELEASED_FLAG                  "RELEASE 1",
  HSR.RELEASED_FLAG                  "RELEASE 2",
  HRL.RELEASE_REASON_CODE            "RELEASE CODE",
  decode(HSR.HOLD_ENTITY_CODE,
         ''B'',''Bill To'',
         ''C'',''Customer'',
         ''I'',''Item'',
         ''O'',''Order'',
         ''S'',''Ship To'',
         ''W'',''Warehouse'',
         HSR.HOLD_ENTITY_CODE)       "ENTITY",
  HSR.HOLD_ENTITY_ID                 "ENTITY ID",
  decode(HSR.HOLD_ENTITY_CODE2,
         ''B'',''Bill To'',
         ''C'',''Customer'',
         ''I'',''Item'',
         ''O'',''Order'',
         ''S'',''Ship To'',
         ''W'',''Warehouse'',
         HSR.HOLD_ENTITY_CODE2)      "ENTITY 2",
  HSR.HOLD_ENTITY_ID2                "ENTITY ID 2",
  to_char(HSR.HOLD_UNTIL_DATE,''DD-MON-RR_HH24:MI:SS'') "HOLD UNTIL"
from OE_ORDER_HOLDS_ALL    HLD,
     OE_HOLD_SOURCES_ALL   HSR,
     OE_HOLD_DEFINITIONS   HDF,
     OE_HOLD_RELEASES      HRL
where        HLD.HEADER_ID                 = ##$$HEADERID$$##
        and  HLD.HOLD_SOURCE_ID       = HSR.HOLD_SOURCE_ID
        and  HSR.HOLD_ID              = HDF.HOLD_ID
        and  HLD.HOLD_RELEASE_ID      = HRL.HOLD_RELEASE_ID(+)
        and  HLD.LINE_ID              IS NULL',
      p_title                  => 'Sales Order Generic Hold',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Holds have been applied on this Sales Order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_GENERIC_HOLD_DISPLAY');



debug('begin add_signature: SALES_ORDER_WSH_DELIVERY_LEGS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_DELIVERY_LEGS',
      p_sig_sql                => 'select distinct 
  LEG.DELIVERY_LEG_ID              "Leg ID",
  LEG.SEQUENCE_NUMBER              "Sequence Number",
  LEG.DELIVERY_ID                  "Delivery ID",
  LEG.PICK_UP_STOP_ID              "Pick Up Stop ID",
  LEG.DROP_OFF_STOP_ID             "Drop Off Stop ID"
FROM 
  OE_ORDER_LINES_ALL               LIN,
  WSH_DELIVERY_DETAILS             DET,
  WSH_NEW_DELIVERIES               DEL,
  WSH_DELIVERY_LEGS                LEG,
  WSH_TRIP_STOPS                   STP,
  WSH_DELIVERY_ASSIGNMENTS         ASG,
  WSH_TRIPS                        TRP
where
  DEL.DELIVERY_ID                 = ASG.DELIVERY_ID AND
  ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID AND
  DET.SOURCE_LINE_ID              = LIN.LINE_ID AND  
  STP.STOP_ID(+)                  = LEG.PICK_UP_STOP_ID AND
  STP.TRIP_ID                     = TRP.TRIP_ID AND 
  LEG.DELIVERY_ID(+)              = DEL.DELIVERY_ID AND 
  LIN.HEADER_ID                = ##$$HEADERID$$## AND
  NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
order by
     LEG.DELIVERY_LEG_ID',
      p_title                  => 'Delivery Legs',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Delivery Legs associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_DELIVERY_LEGS');



debug('begin add_signature: SALES_ORDER_LINE_HISTORY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_HISTORY',
      p_sig_sql                => 'select
     HIL.LINE_ID                           "Line ID",
     to_char(HIL.line_number) || 
          decode(HIL.shipment_number, null, null, ''.'' || to_char(HIL.shipment_number))|| 
          decode(HIL.option_number, null, null, ''.'' || to_char(HIL.option_number)) ||
          decode(HIL.component_number, null, null, 
                 decode(HIL.option_number, null, ''.'',null)||
                 ''.''||to_char(HIL.component_number))||
          decode(HIL.service_number,null,null,
                 decode(HIL.component_number, null, ''.'' , null) ||
                        decode(HIL.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(HIL.service_number)) "Line Number",
     nvl(HIL.ORDERED_QUANTITY,0)           "Order Qty",
     nvl(HIL.LATEST_CANCELLED_QUANTITY,0)  "Last Cancel Qty", 
     nvl(HIL.SHIPPING_QUANTITY,0)          "Shipping Qty", 
     nvl(HIL.SHIPPED_QUANTITY,0)           "Shipped Qty", 
     nvl(HIL.FULFILLED_QUANTITY,0)         "Fulfilled Qty",                   
     nvl(HIL.CANCELLED_QUANTITY,0)         "Cancelled Qty",       
     nvl(HIL.INVOICED_QUANTITY,0)          "Invoiced Qty", 
     HIL.ORDER_QUANTITY_UOM                "Ordered Qty",
     substr(HIL.SCHEDULE_STATUS_CODE,1,5)  "Schedule Status",
     nvl(HIL.OPEN_FLAG,''N'')                "Open Flag",
     nvl(HIL.BOOKED_FLAG,''N'')              "Booked Flag",
     nvl(HIL.SHIPPABLE_FLAG,''N'')           "Shippable Flag",
     nvl(HIL.CANCELLED_FLAG,''N'')           "Cancelled Flag",
     nvl(HIL.VISIBLE_DEMAND_FLAG,''N'')      "Demand Visible Flag",
     nvl(HIL.SHIPPING_INTERFACED_FLAG,''N'') "Ship Interface Flag",
     nvl(HIL.FULFILLED_FLAG,''N'')           "Fullfilled Flag",
     HIL.WF_ACTIVITY_CODE                  Activity,
     HIL.WF_RESULT_CODE                    Result,
     HIL.HIST_TYPE_CODE                    "History Type",
     to_char(HIL.HIST_CREATION_DATE, ''DD-MON-RR_HH24:MI:SS'')  "History Create Date",
     HIL.FLOW_STATUS_CODE                  "Flow Status",
     HIL.UNIT_SELLING_PRICE                "Unit Selling Price", 
     HIL.REASON_CODE                       Reason,
     HIL.HIST_COMMENTS                     Comments
from
     OE_ORDER_LINES_HISTORY        HIL
where
     HIL.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)    in (0,HIL.LINE_ID,
                                         HIL.TOP_MODEL_LINE_ID,
                                         HIL.ATO_LINE_ID,
                                         HIL.LINK_TO_LINE_ID,
                                         HIL.SERVICE_REFERENCE_LINE_ID)
order by
     NVL(HIL.ATO_LINE_ID,               HIL.LINE_ID),
     NVL(HIL.SORT_ORDER,                ''0000''),
     NVL(HIL.LINK_TO_LINE_ID,           HIL.LINE_ID),
     NVL(HIL.SOURCE_DOCUMENT_LINE_ID,   HIL.LINE_ID),
     NVL(HIL.SERVICE_REFERENCE_LINE_ID, HIL.LINE_ID),
     HIL.LINE_ID',
      p_title                  => 'Sales Order Line History',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Sales Order Line History for this order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_HISTORY');



debug('begin add_signature: SALES_ORDER_LINE_PRICE_ADJUSTMENTS_UNAPPLIED');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_PRICE_ADJUSTMENTS_UNAPPLIED',
      p_sig_sql                => 'select distinct
    ADJ.PRICE_ADJUSTMENT_ID            "Price Adjustment ID",
    to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
     ADJ.LIST_HEADER_ID                 "List Header ID",             
     ADJ.LIST_LINE_ID                   "List Line ID",  
     ADJ.LIST_LINE_NO                   "List Line Number",   
     ADJ.MODIFIER_LEVEL_CODE            "Modifier Level Code",     
     ADJ.LIST_LINE_TYPE_CODE            "List Line Type",
     ADJ.CHARGE_TYPE_CODE               "Charge Type Code",             
     ADJ.ARITHMETIC_OPERATOR            "Arithmetic Operator",  
     ADJ.OPERAND_PER_PQTY               "Operand Per Qty",        
     ADJ.ADJUSTED_AMOUNT_PER_PQTY       "Adjusted Amount Per Qty",
     ADJ.OPERAND                        Operand,                      
     ADJ.ADJUSTED_AMOUNT                "Adjusted Amount",                             
     ADJ.CREDIT_OR_CHARGE_FLAG          "Credit or Charge Flag",                          
     ADJ.AUTOMATIC_FLAG                 "Automatic Flag",   
     ADJ.PRINT_ON_INVOICE_FLAG          "Print on Invoice",   
     ADJ.ACCRUAL_FLAG                   "Accrual Flag",        
     ADJ.INVOICED_FLAG                  "Invoiced Flag",              
     ADJ.ESTIMATED_FLAG                 "Estimated Flag",
     ADJ.UPDATE_ALLOWED                 "Update Allowed",        
     ADJ.UPDATED_FLAG                   "Updated Flag",         
     ADJ.APPLIED_FLAG                   "Applied Flag", 
     ADJ.LOCK_CONTROL                   "lock Control",                                      
     ADJ.PERCENT                        Percent,            
     ADJ.COST_ID                        "Cost ID",               
     ADJ.TAX_CODE                       "Tax Code",               
     ADJ.PRICING_PHASE_ID               "Pricing Phase"
from OE_PRICE_ADJUSTMENTS   ADJ,
     OE_ORDER_LINES_ALL     LIN
where  ADJ.HEADER_ID             = ##$$HEADERID$$##
  and  LIN.HEADER_ID             = ##$$HEADERID$$##
  and  ADJ.LINE_ID               IS NOT NULL
  and  ADJ.LINE_ID               = LIN.LINE_ID
  and  (''##$$LINEID$$##'' IS NULL OR ''##$$LINEID$$##'' IN  (0,LIN.LINE_ID,
                                       LIN.TOP_MODEL_LINE_ID,
                                       LIN.ATO_LINE_ID,
                                       LIN.LINK_TO_LINE_ID,
                                       LIN.REFERENCE_LINE_ID,
                                       LIN.SERVICE_REFERENCE_LINE_ID))
  and  nvl(ADJ.APPLIED_FLAG,''N'') = ''N''
order by LINE,
         ADJ.LIST_LINE_TYPE_CODE',
      p_title                  => 'Un-Applied Line Price Adjustments',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No un-applied line price adjustments for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_PRICE_ADJUSTMENTS_UNAPPLIED');



debug('begin add_signature: SALES_ORDER_RA_CUSTOMER_TRX');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_RA_CUSTOMER_TRX',
      p_sig_sql                => 'select distinct 
            RAH.CUSTOMER_TRX_ID           "Customer Trx ID",
            RAH.TRX_NUMBER                "Transaction Number",
            RAH.CUST_TRX_TYPE_ID          "Transaction Type ID",
            to_char(RAH.TRX_DATE,''DD-MON-RR_HH24:MI:SS'')   "Transaction Date",
            RAH.BATCH_ID                  "Batch ID",
            RAH.BATCH_SOURCE_ID           "Source ID",
            RAH.BILL_TO_CUSTOMER_ID       "Customer Bill To",
            RAH.BILL_TO_SITE_USE_ID       "Bill To Site",
            RAH.SHIP_TO_CUSTOMER_ID       "Customer Ship To",
            RAH.SHIP_TO_SITE_USE_ID       "Customer Use ID",
            RAH.TERM_ID                   "Term ID",
            RAH.PRIMARY_SALESREP_ID       "Sales Rep ID",
            RAH.PURCHASE_ORDER            "PO Number",
            RAH.INVOICE_CURRENCY_CODE     Currency,
            RAH.AGREEMENT_ID              Agreement,
            RAH.COMPLETE_FLAG             Complete,
            RAH.INVOICING_RULE_ID         "Invoice Rule ID",
            RAH.SHIP_VIA                  "Ship Via",
            RAH.WAYBILL_NUMBER            Waybill,
            RAH.STATUS_TRX                Status 
    
FROM
        RA_CUSTOMER_TRX_ALL                RAH,
        RA_CUSTOMER_TRX_LINES_ALL          RAL,
        OE_ORDER_LINES_ALL            LIN,
        OE_ORDER_HEADERS_ALL          ORD,
        OE_TRANSACTION_TYPES_TL        TYP
WHERE   
             RAH.CUSTOMER_TRX_ID           = RAL.CUSTOMER_TRX_ID
        and  RAL.SALES_ORDER               = to_char(ORD.ORDER_NUMBER)
        and  RAL.INTERFACE_LINE_ATTRIBUTE2 = TYP.NAME
        and  TYP.TRANSACTION_TYPE_ID       = ORD.ORDER_TYPE_ID
        and  ORD.HEADER_ID                 = LIN.HEADER_ID
        and  NVL(''##$$LINEID$$##'',0)  in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.REFERENCE_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)
        and NVL(RAL.INTERFACE_LINE_ATTRIBUTE6,0) in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.REFERENCE_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)
        and LIN.HEADER_ID                  = ##$$HEADERID$$##
ORDER BY
        RAH.TRX_NUMBER',
      p_title                  => 'Invoice Headers',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Invoice Headers for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_RA_CUSTOMER_TRX');



debug('begin add_signature: SALES_ORDER_WIP_JOB_SCHEDULE_INTERFACE');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WIP_JOB_SCHEDULE_INTERFACE',
      p_sig_sql                => 'select 
     WJS.INTERFACE_ID                   "Interface ID",
     WJS.SOURCE_LINE_ID                 "Source Line ID",
     to_char(LIN.line_number) ||
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))||
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null,
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
     WJS.REQUEST_ID                     "Request ID",
     WJS.GROUP_ID                       "Group ID",
     WJS.SOURCE_CODE                    "Source Code",
     WJS.PROCESS_PHASE                  "Process Phase",
     WJS.STATUS_TYPE                    "Status Type",
     WJS.PROCESS_STATUS                 Status,
     WJS.ORGANIZATION_CODE              ORG,
     WJS.LOAD_TYPE                      Load,
     WJS.PRIMARY_ITEM_ID                "Item ID",
     WJS.WIP_SUPPLY_TYPE                "WIP Supply Type",
     WJS.START_QUANTITY                 "Start Qty"
from WIP_JOB_SCHEDULE_INTERFACE WJS,
     OE_ORDER_LINES_ALL         LIN
where WJS.SOURCE_LINE_ID      =  LIN.LINE_ID
  and LIN.HEADER_ID           = ##$$HEADERID$$##
  and NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Wip Job Schedule Interface',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No WIP Jobs associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WIP_JOB_SCHEDULE_INTERFACE');



debug('begin add_signature: SALES_ORDER_PO_INTERFACE_ERRORS_ALL');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_PO_INTERFACE_ERRORS_ALL',
      p_sig_sql                => 'select
  POE.INTERFACE_TRANSACTION_ID     "Interface Transaction ID",   
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  POE.COLUMN_NAME                  "Column Name",                  
  POE.ERROR_MESSAGE                "Error Message",  
  POE.INTERFACE_TYPE               "Interface Type",         
  POE.REQUEST_ID                   "Request ID",
  POE.TABLE_NAME                   "Table Name"
from  
  PO_INTERFACE_ERRORS             POE,
  OE_DROP_SHIP_SOURCES            SRC,
  OE_ORDER_LINES_ALL              LIN,
  PO_REQUISITIONS_INTERFACE_ALL   RQI
where 
     SRC.LINE_ID                      = LIN.LINE_ID
and  SRC.DROP_SHIP_SOURCE_ID          = RQI.INTERFACE_SOURCE_LINE_ID
and  RQI.TRANSACTION_ID               = POE.INTERFACE_TRANSACTION_ID
and  LIN.HEADER_ID                    = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)          in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
order by
     NVL(LIN.TOP_MODEL_LINE_ID,         LIN.LINE_ID),
     NVL(LIN.ATO_LINE_ID,               LIN.LINE_ID),
     NVL(LIN.SORT_ORDER,                ''0000''),
     NVL(LIN.LINK_TO_LINE_ID,           LIN.LINE_ID),
     NVL(LIN.SOURCE_DOCUMENT_LINE_ID,   LIN.LINE_ID),
     LIN.LINE_ID',
      p_title                  => 'PO Interface Errors',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'NO PO Interface errors for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_PO_INTERFACE_ERRORS_ALL');



debug('begin add_signature: SALES_ORDER_WSH_NEW_DELIVERIES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_NEW_DELIVERIES',
      p_sig_sql                => 'select distinct 
  DEL.DELIVERY_ID                  "Delivery ID",
  DEL.NAME                         "Delivery Name",
  DEL.STATUS_CODE                  "Status Code",
  DEL.WAYBILL                      Waybill,
  DEL.PLANNED_FLAG                 Planned,
  to_char(DEL.INITIAL_PICKUP_DATE,''DD-MON-RR_HH24:MI:SS'') "Pickup Date",
  DEL.INITIAL_PICKUP_LOCATION_ID   "Pickup Loc ID",
  to_char(DEL.ULTIMATE_DROPOFF_DATE,''DD-MON-RR_HH24:MI:SS'')  "Drop Off Date",
  DEL.ULTIMATE_DROPOFF_LOCATION_ID "Drop Off Loc ID",
  DEL.SHIP_METHOD_CODE             "Ship Method",
  to_char(DEL.CONFIRM_DATE,''DD-MON-RR_HH24:MI:SS'')  "Confirm Date"
FROM 
  OE_ORDER_LINES_ALL               LIN,
  WSH_DELIVERY_DETAILS             DET,
  WSH_NEW_DELIVERIES               DEL,
  WSH_DELIVERY_ASSIGNMENTS         ASG 
where
  DEL.DELIVERY_ID                 = ASG.DELIVERY_ID AND
  ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID AND
  DET.SOURCE_LINE_ID              = LIN.LINE_ID AND  
  LIN.HEADER_ID                   = ##$$HEADERID$$## AND
  NVL(''##$$LINEID$$##'',0)      in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
order by Del.DELIVERY_ID',
      p_title                  => 'New Deliveries',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no new Deliveries associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_NEW_DELIVERIES');



debug('begin add_signature: SALES_ORDER_RA_CUSTOMER_TRX_LINES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_RA_CUSTOMER_TRX_LINES',
      p_sig_sql                => 'select distinct
            RAL.CUSTOMER_TRX_LINE_ID          "Customer Trx Line ID",
            RAL.LINK_TO_CUST_TRX_LINE_ID      "Link to ID",
            RAL.CUSTOMER_TRX_ID               "Customer Trx ID",
            RAH.TRX_NUMBER                    "Transaction Number",
            RAL.SALES_ORDER_SOURCE            "SO Source",
            RAL.LINE_NUMBER                   "Line Number",                    
            RAL.INVENTORY_ITEM_ID             "Item ID",
            RAL.QUANTITY_ORDERED              "Qty Ordered",
            RAL.QUANTITY_INVOICED             "Qty Invoiced",
            RAL.QUANTITY_CREDITED             "Qty Credited",
            RAL.UOM_CODE                      UOM,
            RAL.UNIT_SELLING_PRICE            Price,  
            RAL.EXTENDED_AMOUNT               "Extended Amt",            
            RAL.REVENUE_AMOUNT                "Revenue Amt",          
            TRIM(RAL.SALES_ORDER_LINE)        "SO Line",
            RAL.LINE_TYPE                     LINE_TYPE,
            RAL.INTERFACE_LINE_ATTRIBUTE1     "Order Number",
            RAL.INTERFACE_LINE_ATTRIBUTE2     "Order Type",
            RAL.INTERFACE_LINE_ATTRIBUTE3     Delivery,
            RAL.INTERFACE_LINE_ATTRIBUTE4     WayBill,
            RAL.INTERFACE_LINE_ATTRIBUTE6     "Line ID",
            RAL.INTERFACE_LINE_ATTRIBUTE8     "Bill Lading",
            RAL.INTERFACE_LINE_ATTRIBUTE10    "Warehouse ID",
            RAL.INTERFACE_LINE_ATTRIBUTE11    "PA ID",
            RAL.TAXABLE_FLAG                  Taxable,          
            RAL.TAX_RATE                      "Tax Rate",
            RAL.VAT_TAX_ID                    "VAT Tax Rate",
            RAL.SALES_TAX_ID                  "Sales Tax ID"
         
FROM
        RA_CUSTOMER_TRX_ALL                RAH,
        RA_CUSTOMER_TRX_LINES_ALL          RAL 
WHERE
        RAH.CUSTOMER_TRX_ID               = RAL.CUSTOMER_TRX_ID
    and RAL.CUSTOMER_TRX_LINE_ID in 
   (select RAL1.CUSTOMER_TRX_LINE_ID 
    FROM
            RA_CUSTOMER_TRX_ALL                RAH1,
            RA_CUSTOMER_TRX_LINES_ALL          RAL1,
            OE_ORDER_LINES_ALL            LIN,
            OE_ORDER_HEADERS_ALL          ORD,
            OE_TRANSACTION_TYPES_TL        TYP
    WHERE   
             RAH1.CUSTOMER_TRX_ID           = RAL1.CUSTOMER_TRX_ID
        and  RAL1.SALES_ORDER               = to_char(ORD.ORDER_NUMBER)
        and  RAL1.INTERFACE_LINE_ATTRIBUTE2 = TYP.NAME
        and  TYP.TRANSACTION_TYPE_ID       = ORD.ORDER_TYPE_ID
        and  ORD.HEADER_ID                 = LIN.HEADER_ID
        and  NVL(''##$$LINEID$$##'',0)  in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.REFERENCE_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)
        and NVL(RAL1.INTERFACE_LINE_ATTRIBUTE6,0) in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.REFERENCE_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)
        and LIN.HEADER_ID                  = ##$$HEADERID$$##)',
      p_title                  => 'Invoice Lines',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Invoice Lines for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_RA_CUSTOMER_TRX_LINES');



debug('begin add_signature: SALES_ORDER_ORDER_TYPE');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_ORDER_TYPE',
      p_sig_sql                => 'select
     MSO.SALES_ORDER_ID     "Sales Order ID",
     ORD.HEADER_ID                 "Header ID",
     ORD.ORDER_NUMBER              "Order Number",
     TYP.NAME                      "Name",
     MSO.SEGMENT3
from
     MTL_SALES_ORDERS              MSO,
     OE_ORDER_HEADERS_ALL          ORD,
     OE_TRANSACTION_TYPES_TL       TYP
where
     ORD.ORDER_TYPE_ID             = TYP.TRANSACTION_TYPE_ID
and  TO_CHAR(ORD.ORDER_NUMBER)     = MSO.SEGMENT1
and  TYP.NAME(+)                   = MSO.SEGMENT2
and  MSO.SEGMENT1                  = ORD.ORDER_NUMBER
and  ORD.HEADER_ID                 = ##$$HEADERID$$##
order by
     ORD.HEADER_ID',
      p_title                  => 'Sales Order Order Type',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Sales Order Type for this order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_ORDER_TYPE');



debug('begin add_signature: SALES_ORDER_WIP_INTERFACE_ERRORS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WIP_INTERFACE_ERRORS',
      p_sig_sql                => 'select
     WIE.INTERFACE_ID                 "Interface ID",
     to_char(LIN.line_number) ||
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))||
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null,
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
     WIE.ERROR_TYPE                   "Error Type",
     WIE.ERROR                        Error
from WIP_INTERFACE_ERRORS       WIE,
     WIP_JOB_SCHEDULE_INTERFACE WJS,
     OE_ORDER_LINES_ALL         LIN
where WIE.INTERFACE_ID        = WJS.INTERFACE_ID
  and WJS.SOURCE_LINE_ID      =  LIN.LINE_ID
  and LIN.HEADER_ID           = ##$$HEADERID$$##
  and NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'WIP Interface Errors',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No WIP Interface Errors for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WIP_INTERFACE_ERRORS');



debug('begin add_signature: SALES_ORDER_LINE_WF_STATUS_ERRORS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_WF_STATUS_ERRORS',
      p_sig_sql                => 'select 
       WFS.ITEM_KEY               "Line ID", 
       WFA.DISPLAY_NAME           "Process Name",
       WFA1.DISPLAY_NAME          ERROR_ACTIVITY_NAME,
       WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE) Result,
       LKP.MEANING                   Status,
       WFS.ERROR_NAME             "Error Name",
       WFS.ERROR_MESSAGE          "Error Message",
       WFS.ERROR_STACK            "Error Stack"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_ITEMS                  WFI,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP
where 
     WFS.ITEM_TYPE          = ''OEOL''
  and  WFS.item_key           in 
              (select to_char(line_id) from OE_ORDER_LINES_ALL LIN
               where LIN.HEADER_ID = ##$$HEADERID$$##
               and NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                           LIN.TOP_MODEL_LINE_ID,
                                           LIN.ATO_LINE_ID,
                                           LIN.LINK_TO_LINE_ID,
                                           LIN.SERVICE_REFERENCE_LINE_ID)
              ) 
  and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
  and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
  and  WFP.PROCESS_NAME       = WFA.NAME
  and  WFP.PROCESS_VERSION    = WFA.VERSION
  and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
  and  WFP.ACTIVITY_NAME      = WFA1.NAME
  and  WFA1.VERSION = 
      (select max(VERSION)
       from WF_ACTIVITIES WF2
       where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
       and   WF2.NAME      = WFP.ACTIVITY_NAME)
  and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
  and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
  and  WFS.ERROR_NAME is not NULL
  and  WFI.PARENT_ITEM_TYPE=''OEOL'' 
  and  WFI.PARENT_ITEM_KEY in 
              (select to_char(line_id) from OE_ORDER_LINES_ALL LIN
               where LIN.HEADER_ID = ##$$HEADERID$$##
               and NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                           LIN.TOP_MODEL_LINE_ID,
                                           LIN.ATO_LINE_ID,
                                           LIN.LINK_TO_LINE_ID,
                                           LIN.SERVICE_REFERENCE_LINE_ID)
              ) 
 order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'Sales Order Line WF Status Errors',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Sales Order Line Workflow Status Errors.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_WF_STATUS_ERRORS');



debug('begin add_signature: SALES_ORDER_PO_REQUISITION_HEADERS_ALL');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_PO_REQUISITION_HEADERS_ALL',
      p_sig_sql                => 'select distinct 
  RQH.REQUISITION_HEADER_ID         "Req Header ID",
  RQH.SEGMENT1                            "Req Number",
  RQH.INTERFACE_SOURCE_LINE_ID            "Drop Ship ID",
  RQH.AUTHORIZATION_STATUS                "Auth Status",               
  RQH.ENABLED_FLAG                        ENABLED,  
  RQH.INTERFACE_SOURCE_CODE               "Source Code",
  RQH.SUMMARY_FLAG                        SUMMARY,
  RQH.TRANSFERRED_TO_OE_FLAG              "XFR to OE",
  RQH.TYPE_LOOKUP_CODE                    "Req Type",
  RQH.WF_ITEM_TYPE                        "Item Type",
  RQH.WF_ITEM_KEY                         "Item Key"
from 
 PO_REQUISITION_HEADERS_ALL      RQH,
 OE_DROP_SHIP_SOURCES            SRC,
 OE_ORDER_LINES_ALL              LIN
where 
     SRC.LINE_ID                      = LIN.LINE_ID
and SRC.REQUISITION_HEADER_ID         = RQH.REQUISITION_HEADER_ID
and  LIN.HEADER_ID                    = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)          in (0,LIN.LINE_ID,
                                           LIN.TOP_MODEL_LINE_ID,
                                           LIN.ATO_LINE_ID,
                                           LIN.LINK_TO_LINE_ID,
                                           LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select distinct  /* INTERNAL REQ */
  RQH.REQUISITION_HEADER_ID         "Req Header ID",
  RQH.SEGMENT1                            "Req Number",
  RQH.INTERFACE_SOURCE_LINE_ID            "Drop Ship ID",
  RQH.AUTHORIZATION_STATUS                "Auth Status",               
  RQH.ENABLED_FLAG                        ENABLED,  
  RQH.INTERFACE_SOURCE_CODE               "Source Code",
  RQH.SUMMARY_FLAG                        SUMMARY,
  RQH.TRANSFERRED_TO_OE_FLAG              "XFR to OE",
  RQH.TYPE_LOOKUP_CODE                    "Req Type",
  RQH.WF_ITEM_TYPE                        "Item Type",
  RQH.WF_ITEM_KEY                         "Item Key"
from 
 PO_REQUISITION_HEADERS_ALL      RQH,
 OE_ORDER_LINES_ALL              LIN
where 
     LIN.SOURCE_DOCUMENT_ID           = RQH.REQUISITION_HEADER_ID
and  LIN.SOURCE_DOCUMENT_TYPE_ID      = 10                        --INTERNAL REQUISITION
and  LIN.HEADER_ID                    = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)       in (0,LIN.LINE_ID,
                                           LIN.TOP_MODEL_LINE_ID,
                                           LIN.ATO_LINE_ID,
                                           LIN.LINK_TO_LINE_ID,
                                           LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select distinct  /* ATO BUY ITEM */
  RQH.REQUISITION_HEADER_ID         "Req Header ID",
  RQH.SEGMENT1                            "Req Number",
  RQH.INTERFACE_SOURCE_LINE_ID            "Drop Ship ID",
  RQH.AUTHORIZATION_STATUS                "Auth Status",               
  RQH.ENABLED_FLAG                        ENABLED,  
  RQH.INTERFACE_SOURCE_CODE               "Source Code",
  RQH.SUMMARY_FLAG                        SUMMARY,
  RQH.TRANSFERRED_TO_OE_FLAG              "XFR to OE",
  RQH.TYPE_LOOKUP_CODE                    "Req Type",
  RQH.WF_ITEM_TYPE                        "Item Type",
  RQH.WF_ITEM_KEY                         "Item Key"
from
  PO_REQUISITION_HEADERS_ALL      RQH,
  MTL_RESERVATIONS                RES,
  MTL_SALES_ORDERS                MSO
where
     ##$$SALESORDERID$$##     = RES.DEMAND_SOURCE_HEADER_ID
and  RES.DEMAND_SOURCE_TYPE_ID     = 2   -- SO
and  RES.SUPPLY_SOURCE_TYPE_ID     = 17  -- Req
and  RES.SUPPLY_SOURCE_HEADER_ID   = RQH.REQUISITION_HEADER_ID',
      p_title                  => 'PO Requisition Headers',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No PO Requisitions associated to this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_PO_REQUISITION_HEADERS_ALL');



debug('begin add_signature: SALES_ORDER_WIP_DISCRETE_JOBS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WIP_DISCRETE_JOBS',
      p_sig_sql                => 'select
     WIP.WIP_ENTITY_ID                  "WIP Entity ID",
     WIV.WIP_ENTITY_NAME                "Job Name",
     WIP.ORGANIZATION_ID                Warehouse,
     WIP.REQUEST_ID                     "Request ID",
     WIP.SOURCE_LINE_ID                 "Line ID",
     to_char(LIN.line_number) ||
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))||
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null,
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
     WIV.STATUS_TYPE_DISP               Status,
     WIP.PRIMARY_ITEM_ID                "Primary Item ID",
     ITM.SEGMENT1                       Item,
     WIP.FIRM_PLANNED_FLAG              Firm,
     WIP.JOB_TYPE                       "Job Type",
     WIV.WIP_SUPPLY_TYPE_DISP           "WIP Supply Type",
     WIP.SCHEDULED_START_DATE           "Schedule Start Date",
     WIP.SCHEDULED_COMPLETION_DATE      "Schedule Completion Date",
     WIP.DATE_RELEASED                  "Release Date",
     WIP.DUE_DATE                       "Due Date",
     WIP.DATE_COMPLETED                 "Completed Date",
     WIP.DATE_CLOSED                    "Closed Date",
     WIP.START_QUANTITY                 "Start Qty",
     WIP.QUANTITY_COMPLETED             "Qty Completed",
     WIP.QUANTITY_SCRAPPED              "Qty Scrapped",
     WIP.NET_QUANTITY                   "Net Qty",
     WIP.LINE_ID                        "WIP Line ID"
from WIP_DISCRETE_JOBS   WIP,
     WIP_DISCRETE_JOBS_V WIV,
     MTL_SYSTEM_ITEMS_B  ITM,
     OE_ORDER_LINES_ALL  LIN
where WIP.WIP_ENTITY_ID       = WIV.WIP_ENTITY_ID
  and WIP.PRIMARY_ITEM_ID     = ITM.INVENTORY_ITEM_ID
  and WIP.ORGANIZATION_ID     = ITM.ORGANIZATION_ID
  and WIP.SOURCE_LINE_ID      =  LIN.LINE_ID
  and LIN.HEADER_ID           = ##$$HEADERID$$##
  and NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'WIP Discrete Jobs',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no WIP Discrete Jobs associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WIP_DISCRETE_JOBS');



debug('begin add_signature: SALES_ORDER_LINE_WF_STATUS_ERROR_PROCESS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_WF_STATUS_ERROR_PROCESS',
      p_sig_sql                => 'select 
       WFS.ITEM_TYPE || ''-'' || WFS.ITEM_KEY               "Error Type", 
       WFA.DISPLAY_NAME           "Error Process Name",
       WFA1.DISPLAY_NAME          ERR_ACTIVITY_NAME,
       WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE) Result,
       LKP.MEANING                "Action Status",
       WFS.NOTIFICATION_ID        "Notification ID",
       WFS.ASSIGNED_USER          "Assigned User",
       to_char(WFS.BEGIN_DATE,''DD-MON-RR_HH24:MI:SS'') "Begin Date",
       to_char(WFS.END_DATE,''DD-MON-RR_HH24:MI:SS'') "End Date"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP,
     WF_ITEMS                  WFI
where 
       WFS.ITEM_TYPE          = WFI.ITEM_TYPE
  and  WFS.item_key           = WFI.ITEM_KEY
  and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
  and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
  and  WFP.PROCESS_NAME       = WFA.NAME
  and  WFP.PROCESS_VERSION    = WFA.VERSION
  and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
  and  WFP.ACTIVITY_NAME      = WFA1.NAME
  and  WFA1.VERSION = 
      (select max(VERSION)
       from WF_ACTIVITIES WF2
       where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
       and   WF2.NAME      = WFP.ACTIVITY_NAME)
  and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
  and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
  and  WFI.PARENT_ITEM_TYPE = ''OEOL''
  and  WFI.PARENT_ITEM_KEY  in               
             (select to_char(line_id) from OE_ORDER_LINES_ALL LIN
               where LIN.HEADER_ID = ##$$HEADERID$$##
               and NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                           LIN.TOP_MODEL_LINE_ID,
                                           LIN.ATO_LINE_ID,
                                           LIN.LINK_TO_LINE_ID,
                                           LIN.SERVICE_REFERENCE_LINE_ID)
              ) 
  and  WFI.ITEM_TYPE in (select WFAE.ERROR_ITEM_TYPE
                         from WF_ITEM_ACTIVITY_STATUSES WFSE,
                         WF_PROCESS_ACTIVITIES     WFPE,
                         WF_ACTIVITIES_VL          WFAE,
                         WF_ACTIVITIES_VL          WFA1E
                         where 
                                WFSE.ITEM_TYPE = ''OEOL''
                           and  WFSE.ITEM_KEY  in 
                                (select to_char(line_id) from OE_ORDER_LINES_ALL LIN
                                 where LIN.HEADER_ID = ##$$HEADERID$$##
                                 and NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                           LIN.TOP_MODEL_LINE_ID,
                                           LIN.ATO_LINE_ID,
                                           LIN.LINK_TO_LINE_ID,
                                           LIN.SERVICE_REFERENCE_LINE_ID)
                                 )   
                           and  WFSE.PROCESS_ACTIVITY   = WFPE.INSTANCE_ID
                           and  WFPE.PROCESS_ITEM_TYPE  = WFAE.ITEM_TYPE
                           and  WFPE.PROCESS_NAME       = WFAE.NAME
                           and  WFPE.PROCESS_VERSION    = WFAE.VERSION
                           and  WFPE.ACTIVITY_ITEM_TYPE = WFA1E.ITEM_TYPE
                           and  WFPE.ACTIVITY_NAME      = WFA1E.NAME
                           and  WFA1E.VERSION = 
                               (select max(VERSION)
                                from WF_ACTIVITIES WF2E
                                where WF2E.ITEM_TYPE = WFPE.ACTIVITY_ITEM_TYPE
                                and   WF2E.NAME      = WFPE.ACTIVITY_NAME)
                           and  WFSE.ACTIVITY_STATUS = ''ERROR'')
  order by WFS.ITEM_KEY, WFS.BEGIN_DATE, WFS.EXECUTION_TIME',
      p_title                  => 'Sales Order Line WF Status for Error Process',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Sales Order Line WF Processes in error.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_WF_STATUS_ERROR_PROCESS');



debug('begin add_signature: SALES_ORDER_LINES_NO_INVOICE');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_NO_INVOICE',
      p_sig_sql                => 'select 
oel.line_id "Line ID", 
oel.ordered_quantity "Ordered Qty",
oel.invoiced_quantity "Invoiced Qty", 
oel.flow_status_code "Line Status", 
oel.open_flag "Line Open",
oeh.flow_status_code "Header Status",
oeh.open_flag "Header Open", 
oeh.org_id "Org ID"
from oe_order_lines_all oel,
     oe_order_headers_all oeh
where oel.invoice_interface_status_code = ''YES''
and oel.line_category_code = ''ORDER''
and   oeh.header_id = ##$$HEADERID$$##
and   oel.header_id = ##$$HEADERID$$##
and not exists ( select 1
                  from ra_customer_trx_lines_all t10
                  where t10.interface_line_context=''ORDER ENTRY''
  and t10.interface_line_attribute6 = to_char(oel.line_id)
              )
and not exists ( select 1
                  from ra_interface_lines_all t11
                  where t11.interface_line_context=''ORDER ENTRY'' 
  and t11.interface_line_attribute6 = to_char(oel.line_id)
              )',
      p_title                  => 'Sales Order Lines without Invoices (Invoice Flag = Y)',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Sales Order line(s) that have not been invoiced.  Their Invoice Flag is set to Yes; however, they have not been interfaced nor invoiced.',
      p_solution               => 'Please log a service request to get a Datafix script to (re)invoice such order lines.  Reference [1951677.1] when logging the SR.',
      p_success_msg            => 'Shipped line(s) have been interfaced to Receivables for Invoicing.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_NO_INVOICE');



debug('begin add_signature: SALES_ORDER_PO_REQUISITION_LINES_ALL');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_PO_REQUISITION_LINES_ALL',
      p_sig_sql                => 'select /* DROP SHIPMENT */
  RQL.REQUISITION_HEADER_ID        "Req Header ID",
  RQL.REQUISITION_LINE_ID          "Req Line ID", 
  ''DROP SHIP''                      "Doc Type",             
  RQL.LINE_NUM                     "Req Line",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  RQL.ITEM_ID                      "Item ID",    
  RQL.ITEM_DESCRIPTION             "Item Desc",
  RQL.UNIT_MEAS_LOOKUP_CODE        UOM, 
  RQL.UNIT_PRICE                   PRICE,
  RQL.QUANTITY                     QTY,           
  RQL.QUANTITY_CANCELLED           "Cancelled Qty",          
  RQL.QUANTITY_DELIVERED           "Delivered Qty",                  
  RQL.CANCEL_FLAG                  Cancelled,   
  RQL.SOURCE_TYPE_CODE             "Source Type",
  RQL.SOURCE_ORGANIZATION_ID       "Source Org",     
  RQL.DESTINATION_CONTEXT          "Dest Type",     
  RQL.DESTINATION_ORGANIZATION_ID  "Dest Org",
  RQL.ENCUMBERED_FLAG              Encumbrance,                 
  RQL.LINE_TYPE_ID                 "Line Type ID",
  to_char(RQL.NEED_BY_DATE,''DD-MON-RR_HH24:MI:SS'')  "Need By",
  RQL.ON_RFQ_FLAG                  RFQ,                                          
  RQL.SUGGESTED_BUYER_ID           "Buyer ID"
from 
  PO_REQUISITION_LINES_ALL         RQL,
  OE_DROP_SHIP_SOURCES             SRC,
  OE_ORDER_LINES_ALL               LIN
where 
     SRC.LINE_ID                      = LIN.LINE_ID
and  RQL.REQUISITION_LINE_ID          = SRC.REQUISITION_LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)       in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select  /* INTERNAL SALES ORDER */
  RQL.REQUISITION_HEADER_ID        "Req Header ID",
  RQL.REQUISITION_LINE_ID          "Req Line ID",     
  ''INTERNAL SO''                     "Doc Type",             
  RQL.LINE_NUM                     "Req Line",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  RQL.ITEM_ID                      "Item ID",    
  RQL.ITEM_DESCRIPTION             "Item Desc",
  RQL.UNIT_MEAS_LOOKUP_CODE        UOM, 
  RQL.UNIT_PRICE                   PRICE,
  RQL.QUANTITY                     QTY,           
  RQL.QUANTITY_CANCELLED           "Cancelled Qty",          
  RQL.QUANTITY_DELIVERED           "Delivered Qty",                  
  RQL.CANCEL_FLAG                  Cancelled,   
  RQL.SOURCE_TYPE_CODE             "Source Type",
  RQL.SOURCE_ORGANIZATION_ID       "Source Org",     
  RQL.DESTINATION_CONTEXT          "Dest Type",     
  RQL.DESTINATION_ORGANIZATION_ID  "Dest Org",
  RQL.ENCUMBERED_FLAG              Encumbrance,                 
  RQL.LINE_TYPE_ID                 "Line Type ID",
  to_char(RQL.NEED_BY_DATE,''DD-MON-RR_HH24:MI:SS'')  "Need By",
  RQL.ON_RFQ_FLAG                  RFQ,                                          
  RQL.SUGGESTED_BUYER_ID           "Buyer ID"
from 
  PO_REQUISITION_LINES_ALL         RQL,
  OE_ORDER_LINES_ALL               LIN
where 
     LIN.SOURCE_DOCUMENT_LINE_ID      = RQL.REQUISITION_LINE_ID 
and  LIN.SOURCE_DOCUMENT_TYPE_ID      = 10                        --INTERNAL REQUISITION
and  LIN.HEADER_ID                    = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)          in (0,LIN.LINE_ID,
                                            LIN.TOP_MODEL_LINE_ID,
                                            LIN.ATO_LINE_ID,
                                            LIN.LINK_TO_LINE_ID,
                                            LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'PO Requisition Lines',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no PO Requisitions associated to this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_PO_REQUISITION_LINES_ALL');



debug('begin add_signature: SALES_ORDER_WF_NOTIFICATIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_NOTIFICATIONS',
      p_sig_sql                => 'select WFN.NOTIFICATION_ID         "Notification ID",
       WFN.TO_USER                 "To User",
       WFN.ORIGINAL_RECIPIENT      "Original Recipient",
       WFN.RECIPIENT_ROLE          "Recipient Role",
       WFN.MAIL_STATUS             "Mail Status",
       WFN.MESSAGE_NAME            "Message Name",
       WFN.STATUS                  "Status",
       WFN.SUBJECT                 "Subject"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_NOTIFICATIONS          WFN
where WFS.ITEM_TYPE          = ''OEOH''
 and  WFS.item_key           = ##$$HEADERID$$##
 and  WFS.NOTIFICATION_ID    is not null
 and  WFN.NOTIFICATION_ID    = WFS.NOTIFICATION_ID
order by WFS.ITEM_KEY, 
         WFS.BEGIN_DATE, 
         EXECUTION_TIME',
      p_title                  => 'Workflow Order Notification Information (WFN)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Sales Order Workflow Notifications for this order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_NOTIFICATIONS');



debug('begin add_signature: SALES_ORDER_WSH_DELIVERY_ASSIGNMENTS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_DELIVERY_ASSIGNMENTS',
      p_sig_sql                => 'select distinct 
  ASG.DELIVERY_ASSIGNMENT_ID       "Delivery Assigned ID",
  ASG.DELIVERY_ID                  "Delivery ID",
  ASG.DELIVERY_DETAIL_ID           "Delivery Detail ID",
  ASG.PARENT_DELIVERY_ID           "Parent Delivery ID",
  ASG.PARENT_DELIVERY_DETAIL_ID    "Parent Delivery Detail ID"
FROM 
  OE_ORDER_LINES_ALL               LIN,
  WSH_DELIVERY_DETAILS             DET,
  WSH_DELIVERY_ASSIGNMENTS         ASG  
where
  ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID AND
  DET.SOURCE_LINE_ID              = LIN.LINE_ID AND  
  LIN.HEADER_ID                   = ##$$HEADERID$$## AND
  NVL(''##$$LINEID$$##'',0)        in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Delivery Assignments',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Delivery Assignments associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_DELIVERY_ASSIGNMENTS');



debug('begin add_signature: SALES_ORDER_LINE_HOLDS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_HOLDS',
      p_sig_sql                => 'SELECT 
  HLD.LINE_ID                        "Line ID",
    to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) "Line Number",
  HDF.HOLD_ID                        "Hold ID",
  HDF.NAME                           "Hold Name",
  HDF.TYPE_CODE                      "Hold Type",
  HDF.ITEM_TYPE                      "Item Type",
  HDF.ACTIVITY_NAME                  "Activity Name",
  HLD.ORDER_HOLD_ID                  "Order Hold ID",
  HLD.HOLD_SOURCE_ID                 "Hold Source ID",
  HLD.HOLD_RELEASE_ID                "Hold Release ID",
  HLD.HEADER_ID                      "Header ID",
  HLD.RELEASED_FLAG                  "Header Released Flag",
  HSR.RELEASED_FLAG                  "Released Flag",
  HRL.RELEASE_REASON_CODE            "Release Reason",
  decode(HSR.HOLD_ENTITY_CODE,
         ''B'',''Bill To'',
         ''C'',''Customer'',
         ''I'',''Item'',
         ''O'',''Order'',
         ''S'',''Ship To'',
         ''W'',''Warehouse'',
         HSR.HOLD_ENTITY_CODE)       ENTITY,
  HSR.HOLD_ENTITY_ID                 ENTITY_ID,
  decode(HSR.HOLD_ENTITY_CODE2,
         ''B'',''Bill To'',
         ''C'',''Customer'',
         ''I'',''Item'',
         ''O'',''Order'',
         ''S'',''Ship To'',
         ''W'',''Warehouse'',
         HSR.HOLD_ENTITY_CODE2)      ENTITY2,
  HSR.HOLD_ENTITY_ID2                ENTITY_ID2,
  to_char(HSR.HOLD_UNTIL_DATE,''DD-MON-RR HH24:MI:SS'')    HOLD_UNTIL
from OE_ORDER_HOLDS_ALL    HLD,
     OE_HOLD_SOURCES_ALL   HSR,
     OE_HOLD_DEFINITIONS   HDF,
     OE_HOLD_RELEASES      HRL,
     OE_ORDER_LINES_ALL    LIN
where        HLD.HEADER_ID             = ##$$HEADERID$$##
        and  LIN.HEADER_ID             = ##$$HEADERID$$##
        and  HLD.LINE_ID               IS NOT NULL
        and  HLD.LINE_ID               = LIN.LINE_ID
        and  NVL(''##$$LINEID$$##'',0)  in (0,LIN.LINE_ID,
                                       LIN.TOP_MODEL_LINE_ID,
                                       LIN.ATO_LINE_ID,
                                       LIN.LINK_TO_LINE_ID,
                                       LIN.REFERENCE_LINE_ID,
                                       LIN.SERVICE_REFERENCE_LINE_ID)
        and  HLD.HOLD_SOURCE_ID       = HSR.HOLD_SOURCE_ID
        and  HSR.HOLD_ID              = HDF.HOLD_ID
        and  HLD.HOLD_RELEASE_ID      = HRL.HOLD_RELEASE_ID',
      p_title                  => 'Line Specific Holds (Lines Only)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no line specific holds for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_HOLDS');



debug('begin add_signature: SALES_ORDER_WF_REQ_APPROVAL_STATUS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_REQ_APPROVAL_STATUS',
      p_sig_sql                => 'select WFS.item_key               "Req Number Key",
       WFA.DISPLAY_NAME           "Process Name",
       WFA1.DISPLAY_NAME          "Activity Name",
       WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE) Result,
       LKP.MEANING                "Activity Status",
       WFS.NOTIFICATION_ID        "Notification ID",
       to_char(WFS.BEGIN_DATE,''DD-MON-RR_HH24:MI:SS'') "Begin Date",
       to_char(WFS.END_DATE,''DD-MON-RR_HH24:MI:SS'') "End Date",
       WFS.ERROR_NAME             "Error Name"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP
where 
     WFS.ITEM_TYPE          = ''REQAPPRV''
and  WFS.item_key       in (select wf_item_key /*DROP SHIPMENTS*/
                           from 
                           PO_REQUISITION_HEADERS  REQ,
                           OE_DROP_SHIP_SOURCES    SRC,
                           OE_ORDER_LINES          LIN
                           where 
                               SRC.LINE_ID                   = LIN.LINE_ID
                           and SRC.REQUISITION_HEADER_ID     = REQ.REQUISITION_HEADER_ID
                           and  LIN.HEADER_ID                = ##$$HEADERID$$##
                           and  NVL(''##$$LINEID$$##'',0)  in (0,LIN.LINE_ID,
                                     LIN.TOP_MODEL_LINE_ID,
                                     LIN.ATO_LINE_ID,
                                     LIN.LINK_TO_LINE_ID,
                                     LIN.SERVICE_REFERENCE_LINE_ID)
                           UNION ALL
                           select wf_item_key /* INTERNAL SALES ORDERSS */
                           from 
                           PO_REQUISITION_HEADERS  REQ,
                           OE_ORDER_LINES_ALL      LIN
                           where 
                                LIN.SOURCE_DOCUMENT_ID           = REQ.REQUISITION_HEADER_ID
                           and  LIN.SOURCE_DOCUMENT_TYPE_ID      = 10                        
                           and  LIN.HEADER_ID                = ##$$HEADERID$$##
                           and  NVL(''##$$LINEID$$##'',0)   in (0,LIN.LINE_ID,
                                     LIN.TOP_MODEL_LINE_ID,
                                     LIN.ATO_LINE_ID,
                                     LIN.LINK_TO_LINE_ID,
                                     LIN.SERVICE_REFERENCE_LINE_ID))                               
and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
and  WFP.PROCESS_NAME       = WFA.NAME
and  WFP.PROCESS_VERSION    = WFA.VERSION
and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
and  WFP.ACTIVITY_NAME      = WFA1.NAME
and  WFA1.VERSION = 
    (select max(VERSION)
     from WF_ACTIVITIES WF2
     where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
     and   WF2.NAME      = WFP.ACTIVITY_NAME)
and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'Requisition Approval Status',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Requisition Workflows associated to this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_REQ_APPROVAL_STATUS');



debug('begin add_signature: SALES_ORDER_DISCRETE JOB TRANSACTIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_DISCRETE JOB TRANSACTIONS',
      p_sig_sql                => 'select
      WIE.wip_entity_name                    "Job Name",
      to_char(LIN.line_number) ||
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))||
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null,
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
      TRN.inventory_item_id                  "Item ID",
      ITM.segment1                           Item,
      TRN.TRANSACTION_QUANTITY               Qty,
      TRN.TRANSACTION_ID                     "Material Trx ID",
      decode(TRN.TRANSACTION_TYPE_ID,
             35, ''WIP Component Issue'',
             44, ''WIP Assy Completion'',
             TRN.TRANSACTION_TYPE_ID)        "Transaction Type",
      TRN.OPERATION_SEQ_NUM                  "Operation Seq number",
      UNT.serial_number                      Serial
from    wip_discrete_jobs  WIP,
      OE_ORDER_LINES_ALL LIN,
      wip_entities WIE,
      mtl_material_transactions TRN,
      mtl_system_items_b ITM,
      mtl_unit_transactions UNT
where WIE.wip_entity_id              = WIP.wip_entity_id
  and LIN.LINE_ID                    = WIP.source_line_id
  and TRN.transaction_source_id      = WIP.wip_entity_id
  and TRN.transaction_source_type_id = 5
  and TRN.inventory_item_id          = ITM.inventory_item_id
  and TRN.organization_id            = ITM.organization_id
  and TRN.transaction_id             = UNT.transaction_id(+)
  and LIN.HEADER_ID           = ##$$HEADERID$$##
  and NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Discrete Job Transactions',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Discrete Job Transactions associated to this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_DISCRETE JOB TRANSACTIONS');



debug('begin add_signature: SALES_ORDER_WSH_ORGANIZATIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_ORGANIZATIONS',
      p_sig_sql                => 'SELECT distinct 
       mp.organization_id                "Organization ID",
       mp.organization_code              "Organization Code",
       decode(mp.primary_cost_method,
              1, ''Standard'',
              2, ''Average'',
              5, ''FIFO'',
              6, ''LIFO'')              "Primary Cost Method",
       decode(mp.wms_enabled_flag,
              ''Y'', ''Yes'',
              ''N'', ''No'')              "WMS Enabled",
       decode(mp.NEGATIVE_INV_RECEIPT_CODE,
              1, ''Yes'',
              2, ''No'')                "Negative Balance",
       mp.cost_organization_id           "Cost Org ID",
       mp.master_organization_id         "Master Org",
       mp.default_cost_group_id          "Default Cost Group ID",
       decode(mp.project_reference_enabled,
              1, ''Yes'',
              2, ''No'')                "Projects Enabled",
       to_char(mp.cost_cutoff_date,''dd-mon-rrrr'') "Cost Cutoff Date",
       decode(mp.eam_enabled_flag,
              ''Y'',''Yes'',
              ''N'',''No'')               "EAM Enabled",
       decode (mp.encumbrance_reversal_flag,
               1, ''Yes'',
               2, ''No'')               "Encumbrance Reversal"
  FROM MTL_PARAMETERS                   MP,
       WSH_DELIVERY_DETAILS             DET
where DET.SOURCE_CODE                 = ''OE''
  and MP.ORGANIZATION_ID              = DET.ORGANIZATION_ID
  and DET.SOURCE_HEADER_ID            = ##$$HEADERID$$##',
      p_title                  => 'Shipping Organizations',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no assigned shipping organizations.',
      p_solution               => 'Refer to Oracle Shipping Delivery Based General Setup Test [732373.1] for assistance on creating Shipping Organizations.',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_ORGANIZATIONS');



debug('begin add_signature: SALES_ORDER_WF_ORDER_LEVEL_ERRORS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_ORDER_LEVEL_ERRORS',
      p_sig_sql                => 'select WFA.DISPLAY_NAME    "Process",
       WFA1.DISPLAY_NAME   "Activity",
       WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE) "Result",
       LKP.MEANING         "Status",
       WFS.ERROR_NAME      "Error Name",
       WFS.ERROR_MESSAGE   "Error Message",
       WFS.ERROR_STACK     "Error Stack"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP
where 
     WFS.ITEM_TYPE          = ''OEOH''
and  WFS.item_key           = ##$$HEADERID$$##
and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
and  WFP.PROCESS_NAME       = WFA.NAME
and  WFP.PROCESS_VERSION    = WFA.VERSION
and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
and  WFP.ACTIVITY_NAME      = WFA1.NAME
and  WFA1.VERSION = 
    (select max(VERSION)
     from WF_ACTIVITIES WF2
     where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
     and   WF2.NAME      = WFP.ACTIVITY_NAME)
and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
and  WFS.ACTIVITY_STATUS = ''ERROR''
order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'Sales Order Workflow Order Level Errors',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Review Sales Order Workflow Order Level Errors for this order.',
      p_solution               => '',
      p_success_msg            => 'No Sales Order Workflow level errors for this order.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_ORDER_LEVEL_ERRORS');



debug('begin add_signature: SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_INVOICE_QTY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_INVOICE_QTY',
      p_sig_sql                => 'select 
    substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
     LIN.LINE_ID                   "Line ID",
     LIN.INVENTORY_ITEM_ID         "Item ID",
     substr(LIN.FLOW_STATUS_CODE,1,22) "Workflow Status",
     nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
     LIN.ORDER_QUANTITY_UOM        "Ordered UOM",
     nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
     nvl(LIN.SHIPPING_QUANTITY,0)  "Shipping QTY",
     nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
     nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY",          
     nvl(LIN.INVOICED_QUANTITY,0)  "Invoiced QTY", 
     nvl(LIN.OPEN_FLAG,''N'')        "Open",
     nvl(LIN.BOOKED_FLAG,''N'')      "Booked",
     nvl(LIN.SHIPPABLE_FLAG,''N'')   "Shipped",
     nvl(LIN.CANCELLED_FLAG,''N'')   "Cancelled",
     nvl(LIN.FULFILLED_FLAG, ''N'')  "Fullfilled",
     nvl(LIN.SHIPPING_INTERFACED_FLAG,''N'')    "Shipping Interface",
     LIN.SHIP_FROM_ORG_ID          "Ship From",
     nvl(LIN.INVOICE_INTERFACE_STATUS_CODE,''N'') "Invoice Interface",
     LIN.SHIP_TOLERANCE_ABOVE                 "Ship Tolerance Above",
     LIN.SHIP_TOLERANCE_BELOW                 "Ship Tolerance Below",            
     to_char(LIN.ACTUAL_SHIPMENT_DATE,''DD-MON-RR_HH24:MI:SS'')  "Actual Ship",
     to_char(LIN.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Create Date",
     to_char(LIN.LAST_UPDATE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Update Date"
from
     OE_ORDER_HEADERS_ALL                ORD,
     OE_ORDER_LINES_ALL                LIN
where
     ORD.HEADER_ID                  = ##$$HEADERID$$##
     and LIN.HEADER_ID              = ##$$HEADERID$$##
     AND LIN.SHIPPED_QUANTITY IS NOT NULL
     AND LIN.ORDERED_QUANTITY != LIN.INVOICED_QUANTITY
     and   NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                          LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
     order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Line Ordered Qty does not equal Invoiced Qty',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Sales Order Line Ordered Qty does not equal the amount invoiced.',
      p_solution               => 'Sales Order Line(s) ordered Qty does not match the Invoiced Qty.  Verify the invoiced quantity is valid.',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_INVOICE_QTY');



debug('begin add_signature: SALES_ORDER_LINE_PROCESS_MESSAGES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_PROCESS_MESSAGES',
      p_sig_sql                => ' select distinct
   to_char(LIN.line_number) || 
           decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
           decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
           decode(LIN.component_number, null, null, 
                  decode(LIN.option_number, null, ''.'',null)||
                  ''.''||to_char(LIN.component_number))||
           decode(LIN.service_number,null,null,
                  decode(LIN.component_number, null, ''.'' , null) ||
                         decode(LIN.option_number, null, ''.'', null ) ||
                         ''.''|| to_char(LIN.service_number)) Line,
        MSG.header_id                                       "Header ID",
        MSG.line_id                                         "Line ID",
        decode(MSG.MESSAGE_SOURCE_CODE,
               ''U'',''U=On-Line(UI)'',
               ''C'',''C=Conc Process'',
               ''W'',''W=Workflow'',
               MSG.MESSAGE_SOURCE_CODE)                     "Message Source",
        MSG.PROCESS_ACTIVITY        "Process Activity",       
        MSG.request_id              "Request ID",
        MST.message_text                                    "Message Text"
 from oe_processing_msgs_vl     MSG,
      oe_processing_msgs_tl     MST,
      oe_order_lines_all        LIN,
      fnd_languages             FLA
 where  MSG.header_id    = ##$$HEADERID$$##
   and  MSG.HEADER_ID      = LIN.HEADER_ID
   and  msg.transaction_id = mst.transaction_id
   and  MST.LANGUAGE                  = FLA.LANGUAGE_CODE 
   and  FLA.INSTALLED_FLAG            = ''B'' 
   and  MSG.LINE_ID        = LIN.LINE_ID
   and  MSG.LINE_ID        is not NULL
   and  NVL(''##$$LINEID$$##'',0)  in (0,LIN.LINE_ID,
                                            LIN.TOP_MODEL_LINE_ID,
                                            LIN.ATO_LINE_ID,
                                            LIN.LINK_TO_LINE_ID,
                                            LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Sales Order Line Process Messages',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No sales order line process messages for this order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_PROCESS_MESSAGES');



debug('begin add_signature: SALES_ORDER_WF_REQ_APPROVAL_NOTIFICATIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_REQ_APPROVAL_NOTIFICATIONS',
      p_sig_sql                => 'select   WFN.NOTIFICATION_ID         "Notification ID",
         WFN.TO_USER                 "To User",   
         WFN.ORIGINAL_RECIPIENT      "Orig Recipient",           
         WFN.RECIPIENT_ROLE          "Recipient Role",                     
         WFN.MAIL_STATUS             "Mail Status",             
         WFN.MESSAGE_NAME            "Message Name",      
         WFN.STATUS                  Status,                    
         WFN.SUBJECT                 Subject
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_NOTIFICATIONS          WFN
where 
     WFS.ITEM_TYPE          = ''REQAPPRV''
and  WFS.item_key       in (select wf_item_key  /* DROP SHIPMENTS */
                           from 
                           PO_REQUISITION_HEADERS  REQ,
                           OE_DROP_SHIP_SOURCES    SRC,
                           OE_ORDER_LINES_ALL      LIN
                           where 
                               SRC.LINE_ID                   = LIN.LINE_ID
                           and SRC.REQUISITION_HEADER_ID     = REQ.REQUISITION_HEADER_ID
                           and  LIN.HEADER_ID                = ##$$HEADERID$$##
                           and  NVL(''##$$LINEID$$##'',0)   in (0,LIN.LINE_ID,
                                     LIN.TOP_MODEL_LINE_ID,
                                     LIN.ATO_LINE_ID,
                                     LIN.LINK_TO_LINE_ID,
                                     LIN.SERVICE_REFERENCE_LINE_ID)
                           UNION ALL
                           select wf_item_key  /* INTERNAL SALES ORDERSS */
                           from 
                           PO_REQUISITION_HEADERS  REQ,
                           OE_ORDER_LINES_ALL      LIN
                           where 
                                LIN.SOURCE_DOCUMENT_ID           = REQ.REQUISITION_HEADER_ID
                           and  LIN.SOURCE_DOCUMENT_TYPE_ID      = 10                        
                           and  LIN.HEADER_ID                = ##$$HEADERID$$##
                           and  NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                     LIN.TOP_MODEL_LINE_ID,
                                     LIN.ATO_LINE_ID,
                                     LIN.LINK_TO_LINE_ID,
                                     LIN.SERVICE_REFERENCE_LINE_ID))                               
and  WFS.NOTIFICATION_ID is not null
and  WFN.NOTIFICATION_ID = WFS.NOTIFICATION_ID
order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'Requisition Approval Notificatioins',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Requisition Workflow Notifications associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_REQ_APPROVAL_NOTIFICATIONS');



debug('begin add_signature: SALES_ORDER_WF_ACTIVITY_ORDER_ERROR');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_ACTIVITY_ORDER_ERROR',
      p_sig_sql                => 'select WFS.ITEM_TYPE || ''-'' || WFS.ITEM_KEY               "Error Type Key", 
       WFA.DISPLAY_NAME           "Error Process Name",
       WFA1.DISPLAY_NAME          "Error Activity Name",
       WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE) "Result",
       LKP.MEANING                "Activity Status",
       WFS.NOTIFICATION_ID        "Notification ID",
       WFS.ASSIGNED_USER          "Assigned User",
       to_char(WFS.BEGIN_DATE,''DD-MON-RR_HH24:MI:SS'') "Begin Date",
       to_char(WFS.END_DATE,''DD-MON-RR_HH24:MI:SS'') "End Date"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP,
     WF_ITEMS                  WFI
where 
       WFS.ITEM_TYPE          = WFI.ITEM_TYPE
  and  WFS.item_key           = WFI.ITEM_KEY
  and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
  and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
  and  WFP.PROCESS_NAME       = WFA.NAME
  and  WFP.PROCESS_VERSION    = WFA.VERSION
  and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
  and  WFP.ACTIVITY_NAME      = WFA1.NAME
  and  WFA1.VERSION = 
      (select max(VERSION)
       from WF_ACTIVITIES WF2
       where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
       and   WF2.NAME      = WFP.ACTIVITY_NAME)
  and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
  and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
  and  WFI.PARENT_ITEM_TYPE = ''OEOH''
  and  WFI.PARENT_ITEM_KEY  = ##$$HEADERID$$##
  and  WFI.ITEM_TYPE in (select WFAE.ERROR_ITEM_TYPE
                         from WF_ITEM_ACTIVITY_STATUSES WFSE,
                         WF_PROCESS_ACTIVITIES     WFPE,
                         WF_ACTIVITIES_VL          WFAE,
                         WF_ACTIVITIES_VL          WFA1E
                         where 
                                WFSE.ITEM_TYPE = ''OEOH''
                           and  WFSE.ITEM_KEY  = (''##$$HEADERID$$##'')
                           and  WFSE.PROCESS_ACTIVITY   = WFPE.INSTANCE_ID
                           and  WFPE.PROCESS_ITEM_TYPE  = WFAE.ITEM_TYPE
                           and  WFPE.PROCESS_NAME       = WFAE.NAME
                           and  WFPE.PROCESS_VERSION    = WFAE.VERSION
                           and  WFPE.ACTIVITY_ITEM_TYPE = WFA1E.ITEM_TYPE
                           and  WFPE.ACTIVITY_NAME      = WFA1E.NAME
                           and  WFA1E.VERSION = 
                               (select max(VERSION)
                                from WF_ACTIVITIES WF2E
                                where WF2E.ITEM_TYPE = WFPE.ACTIVITY_ITEM_TYPE
                                and   WF2E.NAME      = WFPE.ACTIVITY_NAME)
                           and  WFSE.ACTIVITY_STATUS = ''ERROR'')
  order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'Workflow Activity Status for Order Error Process',
      p_fail_condition         => 'RSGT1',
      p_problem_descr          => 'Review Workflow Activity Status for Order Error Process.',
      p_solution               => '',
      p_success_msg            => 'No Sales Order Workflow Activity Errors for this order.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_ACTIVITY_ORDER_ERROR');



debug('begin add_signature: SALES_ORDER_WSH_DELIVERY_DETAILS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_DELIVERY_DETAILS',
      p_sig_sql                => 'select distinct 
  DET.DELIVERY_DETAIL_ID           "Delivery Detail ID",
  DET.RELEASED_STATUS              "Release Status Code",
  decode(DET.RELEASED_STATUS,
    ''Y'',''Y=Staged'',
    ''R'',''R=Ready to Release'',
    ''S'',''S=Rel to Warhouse'',
    ''B'',''B=Backorder'',
    ''P'',''P=Pending Inv'',
    ''C'',''C=Shipped'',
    ''N'',''N=Not Ready'',
    ''D'',''D=Cancelled'',
    ''X'',''X=Not Applicable'',''Unknown: ''||DET.RELEASED_STATUS) "Release Status",
  DET.MOVE_ORDER_LINE_ID            "Move Order Line ID",
  ASG.DELIVERY_ID                   "Delivery ID",
  TRP.TRIP_ID                       "Trip ID",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  DET.SOURCE_LINE_ID                "Line iD",
  DET.INVENTORY_ITEM_ID             "Item ID",
  ITM.SEGMENT1                      Item,
  nvl(DET.SRC_REQUESTED_QUANTITY,0) "Source Qty",
  DET.SRC_REQUESTED_QUANTITY_UOM    "Source UOM",
  nvl(DET.SRC_REQUESTED_QUANTITY2,0) "Source Qty 2",
  DET.SRC_REQUESTED_QUANTITY_UOM2   "Source UOM 2",
  nvl(DET.REQUESTED_QUANTITY,0)     "Requested Qty",
  DET.REQUESTED_QUANTITY_UOM        "Requested UOM",
  nvl(DET.REQUESTED_QUANTITY2,0)    "Requested Qty 2",
  DET.REQUESTED_QUANTITY_UOM2       "Requested UOM 2",
  nvl(DET.SHIPPED_QUANTITY,0)       "Shipped Qty",
  nvl(DET.SHIPPED_QUANTITY2,0)      "Shipped Qty 2",
  nvl(DET.DELIVERED_QUANTITY,0)     "Delivery Qty",
  nvl(DET.DELIVERED_QUANTITY2,0)    "Delivery Qty 2",
  nvl(DET.CANCELLED_QUANTITY,0)     "Cancel Qty",
  nvl(DET.CANCELLED_QUANTITY2,0)    "Cancel Qty 2",
  nvl(DET.INV_INTERFACED_FLAG,''N'')  "Inv Interfaced",
  nvl(DET.OE_INTERFACED_FLAG,''N'')   "OM Interfaced",
  DET.SHIP_TOLERANCE_ABOVE          "Ship Tolerance Above",
  DET.SHIP_TOLERANCE_BELOW          "Ship Tolerance Below",
  DET.SHIP_FROM_LOCATION_ID         "Ship From ID",
  DET.SHIP_TO_LOCATION_ID           "Ship To ID",
  DET.ORGANIZATION_ID               "Warehouse ID",
  DET.SUBINVENTORY                  Subinventory,
  DET.ATTRIBUTE15                   "Org Sub",
  DET.REVISION                      Revision,
  DET.LOT_NUMBER                    Lot,
  DET.SERIAL_NUMBER                 "Serial Number",
  DET.LOCATOR_ID                    "Locator ID",
  DET.SHIP_METHOD_CODE              "Ship Method",
  DET.SPLIT_FROM_DELIVERY_DETAIL_ID "Split From Del ID",
  DET.PICKABLE_FLAG                 Pickable,
  nvl(DET.PICKED_QUANTITY,0)        "Picked Qty",
  nvl(DET.PICKED_QUANTITY2,0)       "Picked Qty 2",
  DET.SHIP_SET_ID                   "Ship Set ID",
  DET.SHIP_MODEL_COMPLETE_FLAG      "Ship Model Complete",
  DET.TRANSACTION_TEMP_ID           "Trx Temp ID",
  DET.TOP_MODEL_LINE_ID             "Top Model Line",
  DET.SOURCE_LINE_SET_ID            "Source Line Set",
  to_char(DET.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Create Date",
  DET.sublot_number                 "Sublot Number",
  DET.CYCLE_COUNT_QUANTITY2         "Cycle Qty",
  DET.QUALITY_CONTROL_QUANTITY      "QC Control Qty",
  DET.QUALITY_CONTROL_QUANTITY2     "QC Control Qty 2",
  DET.SCHEDULED_QUANTITY2           "Scheduled Qty 2",
  to_char(DET.LAST_UPDATE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Update Date",
  DET.source_line_set_id            "Source Line Set ID"
FROM 
  OE_ORDER_LINES_ALL               LIN,
  WSH_DELIVERY_DETAILS             DET,
  WSH_NEW_DELIVERIES               DEL,
  WSH_DELIVERY_LEGS                LEG,
  WSH_TRIP_STOPS                   STP,
  MTL_SYSTEM_ITEMS                 ITM,
  WSH_DELIVERY_ASSIGNMENTS         ASG,
  WSH_TRIPS                        TRP
where
  DEL.DELIVERY_ID(+)              = ASG.DELIVERY_ID AND
  ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID AND
  DET.SOURCE_LINE_ID              = LIN.LINE_ID AND  
  STP.STOP_ID(+)                  = LEG.PICK_UP_STOP_ID AND
  STP.TRIP_ID                     = TRP.TRIP_ID(+) AND 
  LEG.DELIVERY_ID(+)              = DEL.DELIVERY_ID AND 
  LIN.SHIP_FROM_ORG_ID            = ITM.ORGANIZATION_ID(+) AND
  LIN.INVENTORY_ITEM_ID           = ITM.INVENTORY_ITEM_ID(+) AND
  DET.SOURCE_CODE                 = ''OE'' AND
  LIN.HEADER_ID                   = ##$$HEADERID$$## AND
  NVL(''##$$LINEID$$##'',0)         in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
Order by
  DET.SOURCE_LINE_ID, DET.DELIVERY_DETAIL_ID',
      p_title                  => 'Delivery Details',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Delivery Details associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_DELIVERY_DETAILS');



debug('begin add_signature: SALES_ORDER_WSH_DELIVERY_DETAILS_CONTAINERS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_DELIVERY_DETAILS_CONTAINERS',
      p_sig_sql                => 'select distinct
  DET.DELIVERY_DETAIL_ID           "Delivery Detail ID",
  decode(DET.RELEASED_STATUS,
    ''Y'',''Y=Staged'',
    ''R'',''R=Ready to Relese'',
    ''S'',''S=Rel to Warhouse'',
    ''B'',''B=Backorder'',
    ''P'',''P=Pending Inv'',
    ''C'',''C=Shipped'',
    ''N'',''N=Not Ready'',
    ''D'',''D=Cancelled'',
    ''X'',''X=Not Applicable'',''Unknown: ''||DET.RELEASED_STATUS) "Release Status",
  ASG.DELIVERY_ID                   "Delivery ID",
  TRP.TRIP_ID                       "Trip ID",
  DET.INVENTORY_ITEM_ID             "Item ID",
  ITM.SEGMENT1                      Item,
  DET.CONTAINER_FLAG                "Container",
  DET.CONTAINER_NAME                "Container Name",
  DET.CONTAINER_TYPE_CODE           "Container Type",
  DET.FILL_PERCENT                  "Fill Percent",
  DET.GROSS_WEIGHT                  "Gross Weight",
  DET.NET_WEIGHT                    "Net Weight",
  DET.WEIGHT_UOM_CODE               "Weight UOM",
  DET.VOLUME                        Volume,
  DET.VOLUME_UOM_CODE               "Volume UOM",
  nvl(DET.SRC_REQUESTED_QUANTITY,0) "Source Qty",
  nvl(DET.REQUESTED_QUANTITY,0)     "Requested Qty",
  nvl(DET.SHIPPED_QUANTITY,0)       "Shipped Qty",
  nvl(DET.DELIVERED_QUANTITY,0)     "Delivered Qty",
  nvl(DET.CANCELLED_QUANTITY,0)     "Cancelled Qty",
  nvl(DET.INV_INTERFACED_FLAG,''N'')  "INV Interfaced",
  nvl(DET.OE_INTERFACED_FLAG,''N'')   "OM Interfaced",
  DET.SHIP_FROM_LOCATION_ID         "Ship From Loc ID",
  DET.SHIP_TO_LOCATION_ID           "Ship To Loc ID",
  DET.ORGANIZATION_ID               "Warehouse ID",
  DET.SHIP_METHOD_CODE              "Ship Method",
  to_char(DET.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'') "Creation Date",
  DET.FOB_CODE                      "FOB Code",
  DET.FREIGHT_TERMS_CODE            "Freight Terms",
  DET.SPLIT_FROM_DELIVERY_DETAIL_ID "Split From Del Detail ID",
  DET.LPN_ID                        "LPN ID"
FROM 
  WSH_DELIVERY_DETAILS             DET,
  WSH_DELIVERY_LEGS                LEG,
  WSH_TRIP_STOPS                   STP,
  MTL_SYSTEM_ITEMS                 ITM,
  WSH_DELIVERY_ASSIGNMENTS         ASG,
  WSH_TRIPS                        TRP
where
  ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID AND
  DET.ORGANIZATION_ID             = ITM.ORGANIZATION_ID(+) AND
  DET.INVENTORY_ITEM_ID           = ITM.INVENTORY_ITEM_ID(+) AND
  STP.STOP_ID(+)                  = LEG.PICK_UP_STOP_ID AND
  STP.TRIP_ID                     = TRP.TRIP_ID(+) AND 
  LEG.DELIVERY_ID(+)              = ASG.DELIVERY_ID AND 
  DET.SOURCE_CODE                 = ''WSH'' AND
  ASG.DELIVERY_ID IN (select ASG1.DELIVERY_ID
                  from   WSH_DELIVERY_ASSIGNMENTS ASG1,
                         WSH_DELIVERY_DETAILS     DET1,
                         OE_ORDER_LINES_ALL       LIN1
                  where DET1.SOURCE_LINE_ID = LIN1.LINE_ID AND
                        DET1.DELIVERY_DETAIL_ID = ASG1.DELIVERY_DETAIL_ID AND
                        DET1.SOURCE_CODE = ''OE'' AND
  LIN1.HEADER_ID                   = ##$$HEADERID$$## AND
  NVL(''##$$LINEID$$##'',0)    in (0,LIN1.LINE_ID,
                                         LIN1.TOP_MODEL_LINE_ID,
                                         LIN1.ATO_LINE_ID,
                                         LIN1.LINK_TO_LINE_ID,
                                         LIN1.REFERENCE_LINE_ID,
                                         LIN1.SERVICE_REFERENCE_LINE_ID))',
      p_title                  => 'Delivery Details Containers',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Delivery Details Containers associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_DELIVERY_DETAILS_CONTAINERS');



debug('begin add_signature: SALES_ORDER_WF_REQ_APPROVAL_ERRORS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_REQ_APPROVAL_ERRORS',
      p_sig_sql                => 'select WFA.DISPLAY_NAME           "Process Name",
       WFA1.DISPLAY_NAME          "Activity Name",
       WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE) Result,
       LKP.MEANING                "ACtivity Status",
       WFS.ERROR_NAME             "Error Name",
       WFS.ERROR_MESSAGE          "Error Message",
       WFS.ERROR_STACK            "Error Stack"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP
where 
     WFS.ITEM_TYPE          = ''REQAPPRV''
and  WFS.item_key       in (select wf_item_key /* DROP SHIPMENTS */
                           from 
                           PO_REQUISITION_HEADERS  REQ,
                           OE_DROP_SHIP_SOURCES    SRC,
                           OE_ORDER_LINES_ALL      LIN
                           where 
                               SRC.LINE_ID                   = LIN.LINE_ID
                           and SRC.REQUISITION_HEADER_ID     = REQ.REQUISITION_HEADER_ID
                           and  LIN.HEADER_ID                = ##$$HEADERID$$##
                           and  NVL(''##$$LINEID$$##'',0)   in (0,LIN.LINE_ID,
                                     LIN.TOP_MODEL_LINE_ID,
                                     LIN.ATO_LINE_ID,
                                     LIN.LINK_TO_LINE_ID,
                                     LIN.SERVICE_REFERENCE_LINE_ID)
                           UNION ALL
                           select wf_item_key  /* INTERNAL SALES ORDERSS */
                           from 
                           PO_REQUISITION_HEADERS  REQ,
                           OE_ORDER_LINES_ALL      LIN
                           where 
                                LIN.SOURCE_DOCUMENT_ID           = REQ.REQUISITION_HEADER_ID
                           and  LIN.SOURCE_DOCUMENT_TYPE_ID      = 10                        
                           and  LIN.HEADER_ID                = ##$$HEADERID$$##
                           and  NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                     LIN.TOP_MODEL_LINE_ID,
                                     LIN.ATO_LINE_ID,
                                     LIN.LINK_TO_LINE_ID,
                                     LIN.SERVICE_REFERENCE_LINE_ID))                                
and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
and  WFP.PROCESS_NAME       = WFA.NAME
and  WFP.PROCESS_VERSION    = WFA.VERSION
and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
and  WFP.ACTIVITY_NAME      = WFA1.NAME
and  WFA1.VERSION = 
    (select max(VERSION)
     from WF_ACTIVITIES WF2
     where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
     and   WF2.NAME      = WFP.ACTIVITY_NAME)
and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
and  WFS.ERROR_NAME is not NULL
order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'Requisition Approval Errors',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Review the Approval Errors.',
      p_solution               => '',
      p_success_msg            => 'No Requisition Approval Errors exist for this sales order.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_REQ_APPROVAL_ERRORS');



debug('begin add_signature: SALES_ORDER_BOOKED_SO_HDR_NONBOOKED_LINES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_BOOKED_SO_HDR_NONBOOKED_LINES',
      p_sig_sql                => 'SELECT h.order_number "Order Number",
           oel1.header_id "Header ID",
           h.booked_flag "Header Booked",
           substr(to_char(oel1.line_number) || 
          decode(oel1.shipment_number, null, null, ''.'' || to_char(oel1.shipment_number))|| 
          decode(oel1.option_number, null, null, ''.'' || to_char(oel1.option_number)) ||
          decode(oel1.component_number, null, null, 
                 decode(oel1.option_number, null, ''.'',null)||
                 ''.''||to_char(oel1.component_number))||
          decode(oel1.service_number,null,null,
                 decode(oel1.component_number, null, ''.'' , null) ||
                        decode(oel1.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(oel1.service_number)),1,10)  "Line Number",
           oel1.line_id "Line ID",
           oel1.booked_flag "Line Booked",
           to_char(h.last_update_date, ''DD-MON-RR'') "Last Update",
           ou.name "Operating Unit"
    FROM oe_order_headers_all h, 
         oe_order_lines_all oel1, 
         hr_operating_units ou
    WHERE h.open_flag = ''Y''
    AND   h.org_id = ou.organization_id
    AND   h.header_id = ##$$HEADERID$$##
    AND   h.header_id = oel1.header_id
    AND   oel1.open_flag = ''Y''
    AND   oel1.booked_flag <> h.booked_flag
    order by h.last_update_date DESC',
      p_title                  => 'Booked SO Headers with Non-Booked Lines',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'The Sales Order has been Booked (BOOKED_FLAG = Y); however, line(s) exist that are not Booked (BOOKED_FLAG = N).  Lines have to be Booked in order for them to progress.',
      p_solution               => '<ul>
<li>Try to use script ont00166.sql from {17001338}.</li>
<li>This patch delivers the script to start the line/header workflows whose workflow has been created but not started. This script will only start the headers which are in status ''ENTERED''(not yet booked), and lines which are in status either ''ENTERED'' or ''BOOKED''.</li>
</ul>',
      p_success_msg            => 'All line(s) have been BOOKED.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_BOOKED_SO_HDR_NONBOOKED_LINES');



debug('begin add_signature: SALES_ORDER_HEADER_PROCESSING_MSGS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_HEADER_PROCESSING_MSGS',
      p_sig_sql                => 'select distinct
        MSG.header_id                   "Header ID",
    decode(MSG.MESSAGE_SOURCE_CODE,
           ''U'',''U=On-Line(UI)'',
           ''C'',''C=Conc Process'',
           ''W'',''W=Workflow'',
           MSG.MESSAGE_SOURCE_CODE)     "Message Source",
    MSG.PROCESS_ACTIVITY                "Process Activity",       
    MSG.request_id                      "Request ID",
    MST.message_text                    "Message Text"
 from oe_processing_msgs_vl     MSG,
      oe_processing_msgs_tl     MST,
      fnd_languages             FLA
 where  MSG.header_id      = ##$$HEADERID$$##
   and  msg.transaction_id = mst.transaction_id
   and  MST.LANGUAGE                  = FLA.LANGUAGE_CODE 
   and  FLA.INSTALLED_FLAG            = ''B'' 
   and  decode(MSG.LINE_ID,9.99E+125,NULL,MSG.LINE_ID) is NULL',
      p_title                  => 'Header Processing Messages',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Header Processing Messages for this order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_HEADER_PROCESSING_MSGS');



debug('begin add_signature: SALES_ORDER_LINES_OPEN_AND_CANCELLED');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_OPEN_AND_CANCELLED',
      p_sig_sql                => '   select 
     substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
     LIN.LINE_ID                   "Line ID",
     LIN.OPEN_FLAG                 "Open Flag",
     LIN.CANCELLED_FLAG            "Cancelled Flag",
     substr(LIN.FLOW_STATUS_CODE,1,22) "Workflow Status",
     nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
     nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
     nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
     nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY"
     from oe_order_lines_all LIN
    where header_id = ##$$HEADERID$$##
    and LIN.OPEN_FLAG = ''Y''
    and LIN.CANCELLED_FLAG = ''Y''
    order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Lines both Open and Cancelled',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Open Lines also have Cancelled Flag set to Yes.',
      p_solution               => 'Refer to [416276.1] PATCH 19909549:R12.ONT.B WITH IMPROVED LINE CANCEL SCRIPTs ONTD0008.sql and ONTD0061.sql, run the appropriate script against the mentioned line ID to cancel the line.',
      p_success_msg            => 'All line(s) are either BOOKED or CANCELLED.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_OPEN_AND_CANCELLED');



debug('begin add_signature: SALES_ORDER_PO_HEADERS_INTERFACE');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_PO_HEADERS_INTERFACE',
      p_sig_sql                => 'select 
  PHI.INTERFACE_HEADER_ID            "Interface Header ID",      
  PHI.BATCH_ID                       "Batch ID",     
  PHI.INTERFACE_SOURCE_CODE          "Interface Source Code",    
  PHI.PROCESS_CODE                   "Process Code",   
  PHI.ACTION                         "Action",  
  PHI.PO_HEADER_ID                   "PO Header ID", 
  PHI.RELEASE_NUM                    "Release Number",
  PHI.PO_RELEASE_ID                  "PO Release ID",
  PHI.VENDOR_NAME                    "Vendor Name",
  PHI.APPROVAL_STATUS                "Approval Status",
  PHI.FIRM_FLAG                      Firm,
  PHI.FROZEN_FLAG                    Frozen,
  PHI.CLOSED_CODE                    "Closed Code",
  to_char(PHI.CLOSED_DATE,''DD-MON-RR_HH24:MI:SS'')  "Closed Date",
  PHI.APPROVAL_REQUIRED_FLAG         "Approval Req",                                         
  PHI.REFERENCE_NUM                  "Reference Number",    
  PHI.VENDOR_NUM                     "Vendor Number",               
  PHI.WF_GROUP_ID                    "WF Group ID"
from 
     PO_HEADERS_INTERFACE            PHI,
     PO_LINES_INTERFACE              PLI,
     OE_DROP_SHIP_SOURCES            SRC,
     OE_ORDER_LINES_ALL              LIN
where 
     SRC.LINE_ID                   = LIN.LINE_ID
and  SRC.REQUISITION_LINE_ID       = PLI.REQUISITION_LINE_ID
and  PHI.INTERFACE_HEADER_ID       = PLI.INTERFACE_HEADER_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)order by
     NVL(LIN.TOP_MODEL_LINE_ID,            LIN.LINE_ID),
     NVL(LIN.ATO_LINE_ID,               LIN.LINE_ID),
     NVL(LIN.SORT_ORDER,                ''0000''),
     NVL(LIN.LINK_TO_LINE_ID,           LIN.LINE_ID),
     NVL(LIN.SOURCE_DOCUMENT_LINE_ID,   LIN.LINE_ID),
     LIN.LINE_ID',
      p_title                  => 'PO Headers Interface',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no PO Header Interface records associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_PO_HEADERS_INTERFACE');



debug('begin add_signature: SALES_ORDER_SET');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_SET',
      p_sig_sql                => 'select distinct
ST1.SET_ID                    "SET ID",                         
       ST1.SET_NAME                      "SET NAME",                       
       ST1.SET_TYPE                      "SET TYPE",                       
       ST1.HEADER_ID                     "HEADER ID",
       ST1.INVENTORY_ITEM_ID             "ITEM ID",              
       ST1.ORDERED_QUANTITY_UOM          "UOM",           
       ST1.LINE_TYPE_ID                  "LINE TYPE ID",
       nvl(LST.SYSTEM_REQUIRED_FLAG,''N'') "SYS REQD",
       ST1.SET_STATUS                    "STATUS",                                                              
       to_char(ST1.SCHEDULE_SHIP_DATE,''DD-MON-RR_HH24:MI:SS'')  "SCH SHIP DATE",             
       to_char(ST1.SCHEDULE_ARRIVAL_DATE,''DD-MON-RR_HH24:MI:SS'')   "SCH ARV DATE",
       ST1.SHIP_FROM_ORG_ID              "SHIP FROM",      
       ST1.SHIP_TO_ORG_ID                "SHIP TO ID",
       ST1.SHIPMENT_PRIORITY_CODE        "SHIP PRIORITY", 
       ST1.FREIGHT_CARRIER_CODE          "CARRIER",
       ST1.SHIPPING_METHOD_CODE          "SHIP METHOD",
       ST1.SHIP_TOLERANCE_ABOVE          "SHIP TOL ABOVE",           
       ST1.SHIP_TOLERANCE_BELOW          "SHIP TOL BELOW"
from OE_SETS                       ST1,
     OE_LINE_SETS                  LST
where ST1.SET_ID              = LST.SET_ID(+)
and   ST1.HEADER_ID = ##$$HEADERID$$##',
      p_title                  => 'OE Set(s)',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No Sets assigned on this Sales Order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_SET');



debug('begin add_signature: SALES_ORDER_WSH_SERIAL_NUMBERS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_SERIAL_NUMBERS',
      p_sig_sql                => 'select distinct 
  DET.DELIVERY_DETAIL_ID           "Delivery Detail ID",
  DET.RELEASED_STATUS              "Release Status Code",
  decode(DET.RELEASED_STATUS,
    ''Y'',''Y=Staged'',
    ''R'',''R=Ready to Release'',
    ''S'',''S=Rel to Warhouse'',
    ''B'',''B=Backorder'',
    ''P'',''P=Pending Inv'',
    ''C'',''C=Shipped'',
    ''N'',''N=Not Ready'',
    ''D'',''D=Cancelled'',
    ''X'',''X=Not Applicable'',''Unknown: ''||DET.RELEASED_STATUS) "Release Status",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  DET.SOURCE_LINE_ID                "Line ID",
  DET.INVENTORY_ITEM_ID             "Item ID",
  nvl(DET.SRC_REQUESTED_QUANTITY,0) "Source Qty",
  SRC_REQUESTED_QUANTITY_UOM        "Source UOM",
  nvl(DET.REQUESTED_QUANTITY,0)     "Requested Qty",
  SRC_REQUESTED_QUANTITY_UOM        "Requested UOM",
  nvl(DET.SHIPPED_QUANTITY,0)       "Shipped Qty",
  nvl(DET.DELIVERED_QUANTITY,0)     "Delivered Qty",
  nvl(DET.CANCELLED_QUANTITY,0)     "Cancelled Qty",
  nvl(DET.INV_INTERFACED_FLAG,''N'')  "INV Interfaced",
  nvl(DET.OE_INTERFACED_FLAG,''N'')   "OMI Interfaced",
  DET.SHIP_TOLERANCE_ABOVE          "Ship Tolerance Above",
  DET.SHIP_TOLERANCE_BELOW          "Ship Tolerance Below",
  DET.ORGANIZATION_ID               "Warehouse ID",
  DET.SUBINVENTORY                  Subinventory,
  DET.ATTRIBUTE15                   "Org Subinventory",
  DET.REVISION                      Revision,
  DET.LOT_NUMBER                    Lot,
  DET.SERIAL_NUMBER                 Serial,
  DET.LOCATOR_ID                    "Locator ID",
  DET.SPLIT_FROM_DELIVERY_DETAIL_ID "Split From Del Detail ID",
  DET.PICKED_QUANTITY               "Picked Qty",
  substr(wsn.fm_serial_number,1,15)  "From Serial",
  substr(wsn.to_serial_number,1,15)  "To Serial",
  wsn.quantity                      "WSN Qty",
  to_char(wsn.creation_date,''DD-MON-RR_HH24:MI:SS'') "WSN Create Date"
FROM 
  OE_ORDER_LINES_ALL               LIN,
  WSH_DELIVERY_DETAILS             DET,
  WSH_SERIAL_NUMBERS               WSN
where DET.DELIVERY_DETAIL_ID          = WSN.DELIVERY_DETAIL_ID
  and DET.SOURCE_LINE_ID              = LIN.LINE_ID 
  and DET.SOURCE_CODE                 = ''OE''
  and LIN.HEADER_ID                   = ##$$HEADERID$$##
  and NVL(''##$$LINEID$$##'',0)      in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
 -- and (UPPER(nvl(''&det_cnt'',''Y'')) = ''Y'' or rownum <= 10)',
      p_title                  => 'Serial Numbers',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Serial Numbers associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_SERIAL_NUMBERS');



debug('begin add_signature: SALES_ORDER_PO_LINES_INTERFACE');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_PO_LINES_INTERFACE',
      p_sig_sql                => 'select 
  PLI.INTERFACE_LINE_ID              "Interface Line ID",
  PLI.INTERFACE_HEADER_ID            "Interface Header ID",
  PLI.ACTION                         Action,
  PLI.LINE_NUM                       "PO Line",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  PLI.PO_LINE_ID                     "PO Line ID",
  PLI.SHIPMENT_NUM                   "Shipment Num",            
  PLI.SHIPMENT_TYPE                  "Ship Type",
  PLI.REQUISITION_LINE_ID            "Req Line ID",
  PLI.PO_HEADER_ID                   "PO Header ID",
  PLI.LINE_TYPE                      "Line Type",
  PLI.ITEM                           Item,
  PLI.UNIT_OF_MEASURE                UOM,
  PLI.QUANTITY                       Quantity,
  PLI.UNIT_PRICE                     Price,
  PLI.FIRM_FLAG                      Firm,
  PLI.SHIP_TO_ORGANIZATION_CODE      "Ship Org Code",
  PLI.SHIP_TO_ORGANIZATION_ID        "Ship Org ID",
  PLI.SHIP_TO_LOCATION               "Ship To Loc",
  PLI.SHIP_TO_LOCATION_ID            "Ship To Loc ID",
  to_char(PLI.NEED_BY_DATE,''DD-MON-RR_HH24:MI:SS'')  "Need By",
  to_char(PLI.PROMISED_DATE,''DD-MON-RR_HH24:MI:SS'')  Promise,
  PLI.ORGANIZATION_ID                "Warehouse ID"
from PO_LINES_INTERFACE              PLI,
     OE_DROP_SHIP_SOURCES            SRC,
     OE_ORDER_LINES_ALL              LIN
where 
     SRC.LINE_ID                      = LIN.LINE_ID
and  SRC.REQUISITION_LINE_ID          = PLI.REQUISITION_LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)       in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
order by
     NVL(LIN.TOP_MODEL_LINE_ID,            LIN.LINE_ID),
     NVL(LIN.ATO_LINE_ID,               LIN.LINE_ID),
     NVL(LIN.SORT_ORDER,                ''0000''),
     NVL(LIN.LINK_TO_LINE_ID,           LIN.LINE_ID),
     NVL(LIN.SOURCE_DOCUMENT_LINE_ID,   LIN.LINE_ID),
     LIN.LINE_ID',
      p_title                  => 'PO Lines Interface',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no associated PO Lines Interface records for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_PO_LINES_INTERFACE');



debug('begin add_signature: SALES_ORDER_LINES_NO_WORKFLOW');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_NO_WORKFLOW',
      p_sig_sql                => '    select l.org_id,
           h.order_number,
           l.line_id,
           l.flow_status_code,
           l.open_flag,
           l.booked_flag,
           l.creation_date,
           l.line_type_id,
           h.order_type_id,
           l.item_type_code
    from oe_order_lines_all l,
         oe_order_headers_all h,
         wf_items wf
    where h.header_id = ##$$HEADERID$$##
    and  l.header_id = ##$$HEADERID$$##
    and   to_char(##$$HEADERID$$##) = wf.item_key
    and   wf.item_type = ''OEOH''
    and   (l.open_flag = ''Y'' and nvl(l.cancelled_flag, ''N'') = ''N'')
    and not exists(
             select 1 from wf_items itm
             where itm.item_type = ''OEOL''
            and   itm.item_key = to_char(l.line_id))
    order by l.org_id, h.order_number, l.line_id',
      p_title                  => 'Sales Order LInes with no assoiated Workflow',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Open order line(s) exist with no associated workflow.  Open lines must have workflow to progress.',
      p_solution               => '<ul>
<li>Refer to [1641667.1] How does one progress Order Lines in Booked status that are missing Workflow assignment / activity.
</li>
</ul>',
      p_success_msg            => 'All open lines have an associated workflow.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_NO_WORKFLOW');



debug('begin add_signature: SALES_ORDER_HEADER_OPEN_WITH_CLOSED_LINES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_HEADER_OPEN_WITH_CLOSED_LINES',
      p_sig_sql                => '   select 
   ORD.header_id                     "Header ID",
   ORD.ORDER_NUMBER                  "Order Number",
   ORD.OPEN_FLAG                     "Header Open",
   substr(ORD.FLOW_STATUS_CODE,1,22) "Workflow Status",
   substr(WFA.DISPLAY_NAME,1,22)     "Workflow Process",
   substr(LKP.MEANING,1,22)          "Workflow Act Status",
   substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
         decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
         decode(LIN.service_number,null,null,
                decode(LIN.component_number, null, ''.'' , null) ||
                       decode(LIN.option_number, null, ''.'', null ) ||
                       ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
    LIN.LINE_ID                   "Line ID",
    LIN.OPEN_FLAG                 "Line Open",
    substr(LIN.FLOW_STATUS_CODE,1,22) "Line Workflow Status",
    nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
    nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
    nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
    nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY"
     from oe_order_headers_all        ORD,
          oe_order_lines_all          LIN,
          WF_ITEM_ACTIVITY_STATUSES WFS,
              WF_PROCESS_ACTIVITIES     WFP,
              WF_ACTIVITIES_VL          WFA,
              WF_ACTIVITIES_VL          WFA1,
              WF_LOOKUPS                LKP
    where ORD.header_id = ##$$HEADERID$$##
    and LIN.header_id = ##$$HEADERID$$##
    and LIN.OPEN_FLAG = ''N''
    and ORD.FLOW_STATUS_CODE <> ''CLOSED'' 
    and not exists (select ''WorkFlow''
                          from 
                          WF_ITEM_ACTIVITY_STATUSES WFS,
                          WF_ACTIVITIES_VL     WFA,
                          WF_LOOKUPS                LKP
                          where 
                              WFS.item_key           = To_Char(##$$HEADERID$$##)
                              and WFA.DISPLAY_NAME = ''Close - Order''
                              and LKP.MEANING = ''Deferred'')
    and WFS.ITEM_TYPE          = ''OEOH''
    and WFS.item_key           = To_Char(ORD.header_id)
    and WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
    and WFP.activity_item_type = ''OEOH''
    and WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
    and WFP.PROCESS_NAME       = WFA.NAME
    and WFP.PROCESS_VERSION    = WFA.VERSION
    and WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
    and WFP.ACTIVITY_NAME      = WFA1.NAME
    and WFA1.VERSION           = (select max(VERSION)
                                     from WF_ACTIVITIES WF2
                                     where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
                                     and WF2.NAME      = WFP.ACTIVITY_NAME)
    and LKP.LOOKUP_TYPE        = ''WFENG_STATUS''
    and LKP.LOOKUP_CODE        = WFS.ACTIVITY_STATUS
    order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Header Open with all lines Closed',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Sales Order Header Workflow should be in Close - Order, Deferred status since all lines are CLOSED.',
      p_solution               => '<ul>
<li>Refer to [397565.1] Close Sales Order Headers With no Associated Open Lines, Order Header Workflows or Order Line Workflows for details.  
</li>
<li>The document solution is to apply {5601973} which contains a datafix script that will close open sales order headers that exist with no associated open lines, order header workflow or order line workflows.</li>
<li>For all such order headers, the script contained in this patch sets Open Flag to N and Flow Status Code to Closed or Cancelled.  In addition, the script sets Last Update Date to sysdate and Last Updated By to (-5601973) in case the updated records need to be identified afterwards for whatever purpose.</li>
</ul>',
      p_success_msg            => 'Header Workflow is in valid status.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_HEADER_OPEN_WITH_CLOSED_LINES');



debug('begin add_signature: SALES_ORDER_WSH_FREIGHT_COSTS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_FREIGHT_COSTS',
      p_sig_sql                => 'select distinct 
wfc.FREIGHT_COST_ID         "Freight Cost ID",                
wfc.FREIGHT_COST_TYPE       "Freight Name",
lkp.Meaning                 "Freight Type",
''DELIV_DETAIL''              "Freight Level",
wfc.QUANTITY                Qty,       
wfc.UNIT_AMOUNT             "Unit Amount",   
wfc.TOTAL_AMOUNT            "Total Amount",                                    
wfc.DELIVERY_DETAIL_ID      "Entity ID"
from wsh_freight_costs_v              wfc,
     wsh_freight_cost_types           wft,
     fnd_lookup_values                lkp,
     OE_ORDER_LINES_ALL               LIN,
     WSH_DELIVERY_DETAILS             DET
 WHERE
            wfc.freight_cost_type_id      = wft.freight_cost_type_id AND
            wft.freight_cost_type_code    = lkp.lookup_code AND
            lkp.lookup_type               = ''FREIGHT_COST_TYPE'' AND
            DET.SOURCE_LINE_ID            = LIN.LINE_ID AND  
            LIN.HEADER_ID                 = ##$$HEADERID$$## AND
            NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID) AND
            WFC.DELIVERY_DETAIL_ID        = DET.DELIVERY_DETAIL_ID 
UNION ALL
select distinct
wfc.FREIGHT_COST_ID         "Freight Cost ID",                
wfc.FREIGHT_COST_TYPE       "Freight Name",
lkp.Meaning                 "Freight Type",
''DELIVERY''                  "Freight Level",
wfc.QUANTITY                Qty,       
wfc.UNIT_AMOUNT             "Unit Amount",   
wfc.TOTAL_AMOUNT            "Total Amount",                                    
wfc.DELIVERY_ID             "Entitiy ID"
from wsh_freight_costs_v              wfc,
     wsh_freight_cost_types           wft,
     fnd_lookup_values                lkp,
     OE_ORDER_LINES                   LIN,
     WSH_DELIVERY_DETAILS             DET,
     WSH_DELIVERY_ASSIGNMENTS         ASG
 WHERE
            wfc.freight_cost_type_id      = wft.freight_cost_type_id AND
            wft.freight_cost_type_code    = lkp.lookup_code AND
            lkp.lookup_type               = ''FREIGHT_COST_TYPE'' AND
            ASG.DELIVERY_DETAIL_ID        = DET.DELIVERY_DETAIL_ID AND
            DET.SOURCE_LINE_ID            = LIN.LINE_ID AND  
            LIN.HEADER_ID                 = ##$$HEADERID$$## AND
            NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID) AND
            WFC.DELIVERY_ID              = ASG.DELIVERY_ID AND
            WFC.DELIVERY_DETAIL_ID       IS NULL
UNION ALL
select distinct 
wfc.FREIGHT_COST_ID         "Freight Cost ID",                
wfc.FREIGHT_COST_TYPE       "Freight Name",
lkp.Meaning                 "Freight Type",
''LEG''                       "Freight Level",
wfc.QUANTITY                Qty,       
wfc.UNIT_AMOUNT             "Unit Amount",   
wfc.TOTAL_AMOUNT            "Total Amount",                                    
wfc.DELIVERY_LEG_ID         "Entity ID"
from wsh_freight_costs_v              wfc,
     wsh_freight_cost_types           wft,
     fnd_lookup_values                lkp,
     OE_ORDER_LINES                   LIN,
     WSH_DELIVERY_DETAILS             DET,
     WSH_NEW_DELIVERIES               DEL,
     WSH_DELIVERY_LEGS                LEG,
     --WSH_TRIP_STOPS                   STP,
     WSH_DELIVERY_ASSIGNMENTS         ASG
 WHERE
            wfc.freight_cost_type_id      = wft.freight_cost_type_id AND
            wft.freight_cost_type_code    = lkp.lookup_code AND
            lkp.lookup_type               = ''FREIGHT_COST_TYPE'' AND
            DEL.DELIVERY_ID               = ASG.DELIVERY_ID AND
            ASG.DELIVERY_DETAIL_ID        = DET.DELIVERY_DETAIL_ID AND
            DET.SOURCE_LINE_ID            = LIN.LINE_ID AND  
            LEG.DELIVERY_ID               = DEL.DELIVERY_ID AND 
            LIN.HEADER_ID                 = ##$$HEADERID$$## AND
            NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID) AND
            WFC.DELIVERY_LEG_ID          = LEG.DELIVERY_LEG_ID AND
            WFC.DELIVERY_DETAIL_ID       IS NULL AND
            WFC.DELIVERY_ID              IS NULL
UNION ALL
select distinct
wfc.FREIGHT_COST_ID         "Freight Cost ID",                
wfc.FREIGHT_COST_TYPE       "Freight Name",
lkp.Meaning                 "Freight Type",
''STOP''                      "Freight Level",
wfc.QUANTITY                Qty,       
wfc.UNIT_AMOUNT             "Unit Amount",   
wfc.TOTAL_AMOUNT            "Total Amount",                                    
wfc.STOP_ID                 "Entity ID"
from wsh_freight_costs_v              wfc,
     wsh_freight_cost_types           wft,
     fnd_lookup_values                lkp,
     OE_ORDER_LINES                   LIN,
     WSH_DELIVERY_DETAILS             DET,
     WSH_NEW_DELIVERIES               DEL,
     WSH_DELIVERY_LEGS                LEG,
     WSH_TRIP_STOPS                   STP,
     WSH_DELIVERY_ASSIGNMENTS         ASG
 WHERE
            wfc.freight_cost_type_id      = wft.freight_cost_type_id AND
            wft.freight_cost_type_code    = lkp.lookup_code AND
            lkp.lookup_type               = ''FREIGHT_COST_TYPE'' AND
            DEL.DELIVERY_ID               = ASG.DELIVERY_ID AND
            ASG.DELIVERY_DETAIL_ID        = DET.DELIVERY_DETAIL_ID AND
            DET.SOURCE_LINE_ID            = LIN.LINE_ID AND  
            STP.STOP_ID                   = LEG.PICK_UP_STOP_ID AND
            LEG.DELIVERY_ID               = DEL.DELIVERY_ID AND 
            LIN.HEADER_ID                 = ##$$HEADERID$$## AND
            NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID) AND
            WFC.STOP_ID                  = STP.STOP_ID AND
            WFC.DELIVERY_DETAIL_ID       IS NULL AND
            WFC.DELIVERY_ID              IS NULL AND
            WFC.DELIVERY_LEG_ID          IS NULL
UNION ALL
select distinct
wfc.FREIGHT_COST_ID         "Freight Cost ID",                
wfc.FREIGHT_COST_TYPE       "Freight Name",
lkp.Meaning                 "Freight Type",
''TRIP''                      "Freight Level",
wfc.QUANTITY                Qty,       
wfc.UNIT_AMOUNT             "Unit Amount",   
wfc.TOTAL_AMOUNT            "Total Amount",                                   
wfc.TRIP_ID                 "Entity ID"
from wsh_freight_costs_v              wfc,
     wsh_freight_cost_types           wft,
     fnd_lookup_values                lkp,
     OE_ORDER_LINES                   LIN,
     WSH_DELIVERY_DETAILS             DET,
     WSH_NEW_DELIVERIES               DEL,
     WSH_DELIVERY_LEGS                LEG,
     WSH_TRIP_STOPS                   STP,
     WSH_DELIVERY_ASSIGNMENTS         ASG
 WHERE
            wfc.freight_cost_type_id      = wft.freight_cost_type_id AND
            wft.freight_cost_type_code    = lkp.lookup_code AND
            lkp.lookup_type               = ''FREIGHT_COST_TYPE'' AND
            DEL.DELIVERY_ID               = ASG.DELIVERY_ID AND
            ASG.DELIVERY_DETAIL_ID        = DET.DELIVERY_DETAIL_ID AND
            DET.SOURCE_LINE_ID            = LIN.LINE_ID AND  
            STP.STOP_ID                   = LEG.PICK_UP_STOP_ID AND
            LEG.DELIVERY_ID               = DEL.DELIVERY_ID AND 
            LIN.HEADER_ID                 = ##$$HEADERID$$## AND
            NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID) AND
            WFC.TRIP_ID                  = STP.TRIP_ID AND
            WFC.DELIVERY_DETAIL_ID       IS NULL AND
            WFC.DELIVERY_ID              IS NULL AND
            WFC.STOP_ID                  IS NULL AND
            WFC.DELIVERY_LEG_ID          IS NULL',
      p_title                  => 'Freight Costs',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Freight Costs Associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_FREIGHT_COSTS');



debug('begin add_signature: SALES_ORDER_HEADER_CLOSED WITH_OPEN_LINES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_HEADER_CLOSED WITH_OPEN_LINES',
      p_sig_sql                => 'select
ORD.header_id "Header ID",
ORD.ORDER_NUMBER "Order Number",
ORD.OPEN_FLAG "Header Open",
substr(ORD.FLOW_STATUS_CODE,1,22) "Workflow Status",
substr(WFA.DISPLAY_NAME,1,22) "Workflow Process",
substr(LKP.MEANING,1,22) "Workflow Act Status",
substr(to_char(LIN.line_number) ||
decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))||
decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
decode(LIN.component_number, null, null,
decode(LIN.option_number, null, ''.'',null)||
''.''||to_char(LIN.component_number))||
decode(LIN.service_number,null,null,
decode(LIN.component_number, null, ''.'' , null) ||
decode(LIN.option_number, null, ''.'', null ) ||
''.''|| to_char(LIN.service_number)),1,10) "Line Number",
LIN.LINE_ID "Line ID",
LIN.OPEN_FLAG "Line Open",
substr(LIN.FLOW_STATUS_CODE,1,22) "Line Workflow Status",
nvl(LIN.ORDERED_QUANTITY,0) "Ordered QTY",
nvl(LIN.SHIPPED_QUANTITY,0) "Shipped QTY",
nvl(FULFILLED_QUANTITY,0) "Fulfilled QTY",
nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY"
from oe_order_headers_all ORD,
oe_order_lines_all LIN,
WF_ITEM_ACTIVITY_STATUSES WFS,
WF_PROCESS_ACTIVITIES WFP,
WF_ACTIVITIES_VL WFA,
WF_ACTIVITIES_VL WFA1,
WF_LOOKUPS LKP
where ORD.header_id = ##$$HEADERID$$##
and LIN.header_id = ##$$HEADERID$$##
and LIN.OPEN_FLAG = ''Y''
and ORD.FLOW_STATUS_CODE = ''CLOSED''
and WFS.ITEM_TYPE = ''OEOL''
and WFS.item_key = To_Char(ORD.header_id)
and WFS.PROCESS_ACTIVITY = WFP.INSTANCE_ID
and WFP.activity_item_type = ''OEOL''
and WFP.PROCESS_ITEM_TYPE = WFA.ITEM_TYPE
and WFP.PROCESS_NAME = WFA.NAME
and WFP.PROCESS_VERSION = WFA.VERSION
and WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
and WFP.ACTIVITY_NAME = WFA1.NAME
and WFA1.VERSION = (select max(VERSION)
from WF_ACTIVITIES WF2
where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
and WF2.NAME = WFP.ACTIVITY_NAME)
and LKP.LOOKUP_TYPE = ''WFENG_STATUS''
and LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
order by nvl(LIN.line_set_id, 0), LIN.line_number
, nvl(LIN.shipment_number, -1)
, nvl(LIN.option_number, -1)
, nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Header Closed with Open lines',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Sales Order Header Workflow is Closed; however, there are lines which are still open.',
      p_solution               => '<ul>
<li>Verify the sales order line(s) will not progress on there own.  Make sure they are not waiting for the Workflow Background Process to progress them.  
</li>
<li>If the lines cannot be progressed, refer to [806534.1] Order_Header status is CLOSED but exist open lines associated to this header.
</li>
</ul>',
      p_success_msg            => 'Header Workflow is in valid status.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_HEADER_CLOSED WITH_OPEN_LINES');



debug('begin add_signature: SALES_ORDER_PO_HEADERS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_PO_HEADERS',
      p_sig_sql                => 'select 
  POH.PO_HEADER_ID                "PO Header ID",         
  POH.SEGMENT1                    "PO Number",
  POH.ACCEPTANCE_REQUIRED_FLAG    "Accept Req",
  POH.BILL_TO_LOCATION_ID         "Bill To",
  POH.SHIP_TO_LOCATION_ID         "Ship To",
  POH.CLOSED_CODE                 "Closed Code",
  POH.CONFIRMING_ORDER_FLAG       "Confirm Order",
  POH.CURRENCY_CODE               Currency,
  POH.ENABLED_FLAG                Enabled,
  POH.FROZEN_FLAG                 Frozen,                   
  POH.SUMMARY_FLAG                "Summary Flag",               
  POH.TYPE_LOOKUP_CODE            "Type",
  POH.VENDOR_CONTACT_ID           "Venfdor Contact ID",
  POH.VENDOR_ID                   "Venfdor ID",
  POH.VENDOR_SITE_ID              "Venfdor Site",   
  POH.WF_ITEM_TYPE                "Item Type",
  POH.WF_ITEM_KEY                 "Item Key"
from 
    PO_HEADERS           POH,
    OE_DROP_SHIP_SOURCES SRC,
    OE_ORDER_LINES_ALL   LIN
where 
     SRC.LINE_ID                   = LIN.LINE_ID
and  SRC.PO_HEADER_ID              = POH.PO_HEADER_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)      in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select distinct     /* ATO BUY ITEM */
  POH.PO_HEADER_ID                "PO Header ID",         
  POH.SEGMENT1                    "PO Number",
  POH.ACCEPTANCE_REQUIRED_FLAG    "Accept Req",
  POH.BILL_TO_LOCATION_ID         "Bill To",
  POH.SHIP_TO_LOCATION_ID         "Ship To",
  POH.CLOSED_CODE                 "Closed Code",
  POH.CONFIRMING_ORDER_FLAG       "Confirm Order",
  POH.CURRENCY_CODE               Currency,
  POH.ENABLED_FLAG                Enabled,
  POH.FROZEN_FLAG                 Frozen,                   
  POH.SUMMARY_FLAG                "Summary Flag",               
  POH.TYPE_LOOKUP_CODE            "Type",
  POH.VENDOR_CONTACT_ID           "Venfdor Contact ID",
  POH.VENDOR_ID                   "Venfdor ID",
  POH.VENDOR_SITE_ID              "Venfdor Site",   
  POH.WF_ITEM_TYPE                "Item Type",
  POH.WF_ITEM_KEY                 "Item Key"
from
    PO_HEADERS           POH,
    MTL_RESERVATIONS     RES
where ##$$SALESORDERID$$##        = RES.DEMAND_SOURCE_HEADER_ID
and  RES.DEMAND_SOURCE_TYPE_ID     = 2                         -- SO
and  RES.SUPPLY_SOURCE_TYPE_ID     in (1,13)                   -- PO or INV
and  RES.SUPPLY_SOURCE_HEADER_ID   = POH.PO_HEADER_ID',
      p_title                  => 'PO Headers',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no associated PO Headers for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_PO_HEADERS');



debug('begin add_signature: SALES_ORDER_MTL_TRANSACTIONS_INTERFACE');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_MTL_TRANSACTIONS_INTERFACE',
      p_sig_sql                => 'SELECT   
 TMP.TRANSACTION_INTERFACE_ID     "Transaction ID",
 to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
 LIN.LINE_ID                      "Line ID",
 DET.DELIVERY_DETAIL_ID           "Detail Del ID",
 ITM.SEGMENT1                     Item,
 TMP.PICKING_LINE_ID              "Pick Line ID",
 decode(TMP.TRANSACTION_TYPE_ID,
	 52,''52-Stage Trans'',
	 33,''33-SO Issue'',
	 15,''15-RMA Receipt'',
	 18,''18-PO Receipt'',
	 TMP.TRANSACTION_TYPE_ID||''-Unknown'')    "Transaction Type",
 TMP.TRANSACTION_DATE             "Transaction Date",
 TMP.PRIMARY_QUANTITY             "Primary Qty",
 TMP.SUBINVENTORY_CODE            "From Subinventory",
 TMP.LOCATOR_ID                   "From LOcator ID",
 TMP.PROCESS_FLAG                 Process,
 TMP.LOCK_FLAG                    "Lock",
 TMP.TRANSACTION_MODE             "Transaction Mode",
 TMP.CONTENT_LPN_ID               "LPN ID",
 TMP.ERROR_CODE                   "Error Code",    
 TMP.ERROR_EXPLANATION            "Error Explanation",
 TMP.SECONDARY_UOM_CODE           "Secondary UOM Code",
 TMP.SECONDARY_TRANSACTION_QUANTITY "Secondary Trx Qty",
 TMP.ACCT_PERIOD_ID               "Accounting Period",
 OAC.period_name                  "Per Name",
 OAC.open_flag                    "Open Flag",
 to_char(oac.period_start_date,''DD-MON-RR_HH24:MI:SS'')   "Period Start Date",
 to_char(oac.period_close_date,''DD-MON-RR_HH24:MI:SS'')   "Period Close Date",
 to_char(oac.schedule_close_date,''DD-MON-RR_HH24:MI:SS'') "Schedule Close Date"
FROM 
    MTL_TRANSACTIONS_INTERFACE        TMP,
    WSH_DELIVERY_DETAILS              DET,
    OE_ORDER_LINES_ALL                LIN,
    MTL_SYSTEM_ITEMS                  ITM,
    ORG_ACCT_PERIODS                  OAC
WHERE 
      TMP.SOURCE_LINE_ID = LIN.LINE_ID
  and LIN.LINE_CATEGORY_CODE = ''ORDER'' 
  and LIN.SHIP_FROM_ORG_ID   = ITM.ORGANIZATION_ID(+) 
  and LIN.INVENTORY_ITEM_ID  = ITM.INVENTORY_ITEM_ID(+)  
  and DET.SOURCE_LINE_ID     = LIN.LINE_ID
  and TMP.PICKING_LINE_ID    = DET.DELIVERY_DETAIL_ID(+)
  and TMP.ACCT_PERIOD_ID     = OAC.acct_period_id
  and LIN.HEADER_ID          = ##$$HEADERID$$##
  and NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
SELECT 
 TMP.TRANSACTION_INTERFACE_ID     "Transaction ID",
 to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
 LIN.LINE_ID                      "Line ID",
 DET.DELIVERY_DETAIL_ID           "Delivery Det ID",
 ITM.SEGMENT1                     "Item",
 TMP.PICKING_LINE_ID              "Pick Line ID",
 decode(TMP.TRANSACTION_TYPE_ID,
	 52,''Stage Trans'',
	 33,''SO Issue'',
	 15,''RMA Receipt'',
	 18,''PO Receipt'',
	TMP.TRANSACTION_TYPE_ID)    "Transaction Type",
 TMP.TRANSACTION_DATE             "Transaction Date",
 TMP.PRIMARY_QUANTITY             "Primary Qty",
 TMP.SUBINVENTORY_CODE            "From Subinventory",
 TMP.LOCATOR_ID                   "From LOcator ID",
 TMP.PROCESS_FLAG                 Process,
 TMP.LOCK_FLAG                    "Lock",
 TMP.TRANSACTION_MODE             "Transaction Mode",
 TMP.CONTENT_LPN_ID               "LPN ID",
 TMP.ERROR_CODE                   "Error Code",    
 TMP.ERROR_EXPLANATION            "Error Explanation",
 TMP.SECONDARY_UOM_CODE           "Secondary UOM Code",
 TMP.SECONDARY_TRANSACTION_QUANTITY "Secondary Trx Qty",
 TMP.ACCT_PERIOD_ID               "Accounting Period",
 OAC.period_name                  "Per Name",
 OAC.open_flag                    "Open Flag",
 to_char(oac.period_start_date,''DD-MON-RR_HH24:MI:SS'')   "Period Start Date",
 to_char(oac.period_close_date,''DD-MON-RR_HH24:MI:SS'')   "Period Close Date",
 to_char(oac.schedule_close_date,''DD-MON-RR_HH24:MI:SS'') "Schedule Close Date"
FROM 
    MTL_TRANSACTIONS_INTERFACE        TMP,
    WSH_DELIVERY_DETAILS              DET,
    OE_ORDER_LINES                    LIN,
    MTL_SYSTEM_ITEMS                  ITM,
    ORG_ACCT_PERIODS                  OAC
WHERE 
      TMP.TRX_SOURCE_LINE_ID = LIN.LINE_ID
  and LIN.LINE_CATEGORY_CODE = ''RETURN'' 
  and LIN.SHIP_FROM_ORG_ID   = ITM.ORGANIZATION_ID(+) 
  and LIN.INVENTORY_ITEM_ID  = ITM.INVENTORY_ITEM_ID(+)  
  and DET.SOURCE_LINE_ID     = LIN.LINE_ID
  and TMP.PICKING_LINE_ID    = DET.DELIVERY_DETAIL_ID(+)
  and TMP.ACCT_PERIOD_ID     = OAC.acct_period_id
  and LIN.HEADER_ID          = ##$$HEADERID$$##
  and NVL(''##$$LINEID$$##'',0)   in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Material Transactions Interface',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Material Transaction Interface records associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_MTL_TRANSACTIONS_INTERFACE');



debug('begin add_signature: SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_FULFILL_QTY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_FULFILL_QTY',
      p_sig_sql                => 'select 
    substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
     LIN.LINE_ID                   "Line ID",
     LIN.INVENTORY_ITEM_ID         "Item ID",
     substr(LIN.FLOW_STATUS_CODE,1,22) "Workflow Status",
     nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
     LIN.ORDER_QUANTITY_UOM        "Ordered UOM",
     nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
     nvl(LIN.SHIPPING_QUANTITY,0)  "Shipping QTY",
     nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
     nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY",          
     nvl(LIN.INVOICED_QUANTITY,0)  "Invoiced QTY", 
     nvl(LIN.OPEN_FLAG,''N'')        "Open",
     nvl(LIN.BOOKED_FLAG,''N'')      "Booked",
     nvl(LIN.SHIPPABLE_FLAG,''N'')   "Shipped",
     nvl(LIN.CANCELLED_FLAG,''N'')   "Cancelled",
     nvl(LIN.FULFILLED_FLAG, ''N'')  "Fullfilled",
     nvl(LIN.SHIPPING_INTERFACED_FLAG,''N'')    "Shipping Interface",
     LIN.SHIP_FROM_ORG_ID          "Ship From",
     nvl(LIN.INVOICE_INTERFACE_STATUS_CODE,''N'') "Invoice Interface",
     LIN.SHIP_TOLERANCE_ABOVE                 "Ship Tolerance Above",
     LIN.SHIP_TOLERANCE_BELOW                 "Ship Tolerance Below",            
     to_char(LIN.ACTUAL_SHIPMENT_DATE,''DD-MON-RR_HH24:MI:SS'')  "Actual Ship",
     to_char(LIN.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Create Date",
     to_char(LIN.LAST_UPDATE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Update Date"
from
     OE_ORDER_HEADERS_ALL                ORD,
     OE_ORDER_LINES_ALL                LIN
where
     ORD.HEADER_ID                  = ##$$HEADERID$$##
     and LIN.HEADER_ID              = ##$$HEADERID$$##
     AND LIN.SHIPPED_QUANTITY IS NOT NULL
     AND LIN.ORDERED_QUANTITY != LIN.FULFILLED_QUANTITY
     and   NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                          LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
     order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Line Ordered Qty does not equall Fulfilled Qty',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Sales Order Line Ordered Qty does not equal the Fulfilled Qty.',
      p_solution               => 'Ordered Qty does not equal the fulfilled qty.  Verify your fulfilled qty is valid.',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_FULFILL_QTY');



debug('begin add_signature: SALES_ORDER_PO_LINES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_PO_LINES',
      p_sig_sql                => 'select
  POL.PO_HEADER_ID                "PO Header ID",
  POL.PO_LINE_ID                  "PO Line ID",
  POL.LINE_NUM                    "PO Line",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  POL.CATEGORY_ID                 "Category ID",
  POL.CLOSED_CODE                 "Closed Status",
  POL.FIRM_STATUS_LOOKUP_CODE     Firm,
  POL.ITEM_DESCRIPTION            "Item Desc",
  POL.ITEM_ID                     "Item ID",                  
  POL.LINE_TYPE_ID                "Line Type ID",
  POL.QUANTITY                    QTY,
  POL.UNIT_PRICE                  Price
from 
    PO_LINES             POL,
    OE_DROP_SHIP_SOURCES SRC,
    OE_ORDER_LINES_ALL   LIN
where 
     SRC.LINE_ID                   = LIN.LINE_ID
and  SRC.PO_LINE_ID                = POL.PO_LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)       in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
order by
     NVL(LIN.TOP_MODEL_LINE_ID,            LIN.LINE_ID),
     NVL(LIN.ATO_LINE_ID,               LIN.LINE_ID),
     NVL(LIN.SORT_ORDER,                ''0000''),
     NVL(LIN.LINK_TO_LINE_ID,           LIN.LINE_ID),
     NVL(LIN.SOURCE_DOCUMENT_LINE_ID,   LIN.LINE_ID),
     LIN.LINE_ID',
      p_title                  => 'PO Lines',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no associated PO Lines with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_PO_LINES');



debug('begin add_signature: SALES_ORDER_MTL_MATERIAL_TRANSACTIONS_TEMP');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_MTL_MATERIAL_TRANSACTIONS_TEMP',
      p_sig_sql                => 'SELECT distinct 
 TMP.TRANSACTION_TEMP_ID               "Material Trx ID",
 TMP.TRANSACTION_DATE                  "Material Trx Date",
 TMP.MOVE_ORDER_LINE_ID                "Move Line ID",
 TMP.PICK_SLIP_NUMBER                  "Pick Slip",
 to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
 LIN.LINE_ID                      "Line ID",
 ITM.SEGMENT1                     Item,
 TMP.PRIMARY_QUANTITY             "Primary Qty",
 TMP.SUBINVENTORY_CODE            "From Subinventory",
 TMP.LOCATOR_ID                   "From Loc ID",
 TMP.TRANSFER_SUBINVENTORY        "To Subinventory",
 TMP.TRANSFER_TO_LOCATION         "To Loc ID",
 TMP.PROCESS_FLAG                 Process,
 TMP.LOCK_FLAG                    "Lock",
 TMP.TRANSACTION_MODE             "Transaction Mode",
 TMP.ERROR_CODE                   "Error Code",    
 TMP.ERROR_EXPLANATION            "Error Explanation",
 TMP.SECONDARY_UOM_CODE           "Second UOM",
 TMP.SECONDARY_TRANSACTION_QUANTITY "Second Trx Qty",
 lot.lot_number                   "Lot Num",
 lot.primary_quantity             "Lot Primary Qty",
 lot.secondary_quantity           "Lot Secondary Qty",
 inv_convert.inv_um_convert(
    tmp.inventory_item_id,
    lot.lot_number,
    tmp.organization_id,
    5,
    lot.primary_quantity,
    itm.primary_uom_code,
    tmp.secondary_uom_code,
    null, null)                   "Lot Calculated Second Qty"
FROM 
    MTL_MATERIAL_TRANSACTIONS_TEMP    TMP,
    OE_ORDER_LINES_ALL                LIN,
    MTL_SYSTEM_ITEMS                  ITM, 
    mtl_transaction_lots_temp         lot
WHERE 
      TMP.DEMAND_SOURCE_LINE = LIN.LINE_ID
  and LIN.LINE_CATEGORY_CODE = ''ORDER'' 
  and LIN.SHIP_FROM_ORG_ID   = ITM.ORGANIZATION_ID(+) 
  and LIN.INVENTORY_ITEM_ID  = ITM.INVENTORY_ITEM_ID(+)  
  and lot.transaction_temp_id (+)= tmp.transaction_temp_id
  and LIN.HEADER_ID          = ##$$HEADERID$$## 
  and NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
SELECT distinct 
 TMP.TRANSACTION_TEMP_ID               "Material Trx ID",
 TMP.TRANSACTION_DATE                  "Material Trx Date",
 TMP.MOVE_ORDER_LINE_ID                "Move Line ID",
 TMP.PICK_SLIP_NUMBER                  "Pick Slip",
 to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
 LIN.LINE_ID                      "Line ID",
 ITM.SEGMENT1                     Item,
 TMP.PRIMARY_QUANTITY             "Primary Qty",
 TMP.SUBINVENTORY_CODE            "From Subinventory",
 TMP.LOCATOR_ID                   "From Loc ID",
 TMP.TRANSFER_SUBINVENTORY        "To Subinventory",
 TMP.TRANSFER_TO_LOCATION         "To Loc ID",
 TMP.PROCESS_FLAG                 Process,
 TMP.LOCK_FLAG                    "Lock",
 TMP.TRANSACTION_MODE             "Transaction Mode",
 TMP.ERROR_CODE                   "Error Code",    
 TMP.ERROR_EXPLANATION            "Error Explanation",
 TMP.SECONDARY_UOM_CODE           "Second UOM",
 TMP.SECONDARY_TRANSACTION_QUANTITY "Second Trx Qty",
 '' ''                  "Lot Num",
 0                    "Lot Primary Qty",
 0                    "Lot Secondary Qty",
 0                    "Lot Calculated Second Qty"
FROM 
    MTL_MATERIAL_TRANSACTIONS_TEMP    TMP,
    OE_ORDER_LINES_ALL                LIN,
    MTL_SYSTEM_ITEMS                  ITM 
WHERE 
      TMP.TRX_SOURCE_LINE_ID = LIN.LINE_ID
  and LIN.LINE_CATEGORY_CODE = ''RETURN'' 
  and LIN.SHIP_FROM_ORG_ID   = ITM.ORGANIZATION_ID(+) 
  and LIN.INVENTORY_ITEM_ID  = ITM.INVENTORY_ITEM_ID(+)  
  and LIN.HEADER_ID          = ##$$HEADERID$$## 
  and NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Material Transactions Temp - Unpicked Lines',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Unpicked Lines associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_MTL_MATERIAL_TRANSACTIONS_TEMP');



debug('begin add_signature: SALES_ORDER_MTL_MATERIAL_TRANSACTIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_MTL_MATERIAL_TRANSACTIONS',
      p_sig_sql                => 'SELECT
 TRN.TRANSACTION_ID                    "Material Trx ID",
 TRN.TRANSACTION_DATE                  "Material Trx Date",
 TRN.MOVE_ORDER_LINE_ID                "Move Line ID",
 decode(TRN.TRANSACTION_TYPE_ID,
        52,''Stage Trans'',
        53,''Stage Trans INT'',
        33,''SO Issue'',
        34,''SO Issue INT'',
        15,''RMA Receipt'',
        18,''PO Receipt'',
        ''Invalid ''||to_char(TRN.TRANSACTION_TYPE_ID))       "Trx Type",
 TRN.PICK_SLIP_NUMBER                  "Pick Slip",
 TRN.TRX_SOURCE_LINE_ID                "Trx Source Line ID",
 TRN.TRX_SOURCE_LINE_ID                "Line ID",
 TRN.PRIMARY_QUANTITY                  "Primary Qty",
 TRN.SUBINVENTORY_CODE                 "From Subinventory",
 TRN.LOCATOR_ID                        "From Loc ID",
 TRN.TRANSFER_SUBINVENTORY             "To Subinventory",
 TRN.TRANSFER_LOCATOR_ID               "To Loc ID",
 TRN.ORGANIZATION_ID                   "Org ID",
 TRN.PICKING_LINE_ID                   "Picking Line ID",
 TRN.SECONDARY_UOM_CODE                "Secondary UOM",
 TRN.SECONDARY_TRANSACTION_QUANTITY    "Secondary Trx Qty",
 lot.primary_quantity                  "Lot Primary Qty", 
 lot.secondary_transaction_quantity    "Lot Secondary Qty",
 inv_convert.inv_um_convert(
     lot.inventory_item_id,
     lot.lot_number,
     lot.organization_id,
     5,
     lot.primary_quantity,
     itm.primary_uom_code,
     trn.secondary_uom_code,
     null, null)                       "Lot Calv Secondary Qty"
FROM 
    MTL_MATERIAL_TRANSACTIONS         TRN,
    MTL_SYSTEM_ITEMS                  ITM,
    mtl_transaction_lot_numbers         lot
WHERE 
 (TRN.TRX_SOURCE_LINE_ID,TRN.ORGANIZATION_ID,TRN.INVENTORY_ITEM_ID) IN (SELECT DISTINCT LINE_ID,SHIP_FROM_ORG_ID,INVENTORY_ITEM_ID
                               FROM OE_ORDER_LINES_ALL   LIN1
                               WHERE LIN1.HEADER_ID = ##$$HEADERID$$## 
                               and NVL(''##$$LINEID$$##'',0)     in (0,LIN1.LINE_ID,
                                         LIN1.TOP_MODEL_LINE_ID,
                                         LIN1.ATO_LINE_ID,
                                         LIN1.LINK_TO_LINE_ID,
                                         LIN1.REFERENCE_LINE_ID,
                                         LIN1.SERVICE_REFERENCE_LINE_ID))
and TRN.ORGANIZATION_ID   = ITM.ORGANIZATION_ID 
and TRN.INVENTORY_ITEM_ID  = ITM.INVENTORY_ITEM_ID 
and lot.transaction_id (+) = trn.transaction_id
UNION ALL
SELECT   /* DROP SHIP */
 TRN.TRANSACTION_ID                    "Material Trx ID",
 TRN.TRANSACTION_DATE                  "Material Trx Date",
 TRN.MOVE_ORDER_LINE_ID                "Move Line ID",
 decode(TRN.TRANSACTION_TYPE_ID,
        52,''Stage Trans'',
        33,''SO Issue'',
        15,''RMA Receipt'',
        18,''PO Receipt'',
        ''Invalid ''||to_char(TRN.TRANSACTION_TYPE_ID))          "Trx Type",
 TRN.PICK_SLIP_NUMBER                  "Pick Slip",
 TRN.TRX_SOURCE_LINE_ID                "Trx Source Line ID",
 TRN.TRX_SOURCE_LINE_ID                "Line ID",
 TRN.PRIMARY_QUANTITY                  "Primary Qty",
 TRN.SUBINVENTORY_CODE                 "From Subinventory",
 TRN.LOCATOR_ID                        "From Loc ID",
 TRN.TRANSFER_SUBINVENTORY             "To Subinventory",
 TRN.TRANSFER_LOCATOR_ID               "To Loc ID",
 TRN.ORGANIZATION_ID                   "Org ID",
 TRN.PICKING_LINE_ID                   "Picking Line ID",
 TRN.SECONDARY_UOM_CODE                "Secondary UOM",
 TRN.SECONDARY_TRANSACTION_QUANTITY    "Secondary Trx Qty",
 0                                     "Lot Primary Qty", -- Only for OPM
 0                                     "Lot Secondary Qty", -- Only for OPM
 0                                     "Lot Calv Secondary Qty" -- Only for OPM
FROM
    MTL_MATERIAL_TRANSACTIONS         TRN,
    MTL_SYSTEM_ITEMS                  ITM,
    OE_DROP_SHIP_SOURCES              DRP,
    PO_HEADERS_ALL                    POH
WHERE
     TRN.TRANSACTION_TYPE_ID         = 18                        -- PO Receipt
and  TRN.TRANSACTION_SOURCE_TYPE_ID  = 1
and  TRN.TRANSACTION_SOURCE_ID       = POH.PO_HEADER_ID
and  POH.PO_HEADER_ID                = DRP.PO_HEADER_ID
and  DRP.HEADER_ID                   = ##$$HEADERID$$##
and  TRN.ORGANIZATION_ID             = ITM.ORGANIZATION_ID
and  TRN.INVENTORY_ITEM_ID           = ITM.INVENTORY_ITEM_ID
UNION ALL
SELECT   /* PO receipt trx for ATO BUY ITEM */
 TRN.TRANSACTION_ID                    "Material Trx ID",
 TRN.TRANSACTION_DATE                  "Material Trx Date",
 TRN.MOVE_ORDER_LINE_ID                "Move Line ID",
 decode(TRN.TRANSACTION_TYPE_ID,
        52,''Stage Trans'',
        33,''SO Issue'',
        15,''RMA Receipt'',
        18,''PO Receipt'',
        ''Invalid ''||to_char(TRN.TRANSACTION_TYPE_ID))        "Trx Type",
 TRN.PICK_SLIP_NUMBER                  "Pick Slip",
 TRN.TRX_SOURCE_LINE_ID                "Trx Source Line ID",
 TRN.TRX_SOURCE_LINE_ID                "Line ID",
 TRN.PRIMARY_QUANTITY                  "Primary Qty",
 TRN.SUBINVENTORY_CODE                 "From Subinventory",
 TRN.LOCATOR_ID                        "From Loc ID",
 TRN.TRANSFER_SUBINVENTORY             "To Subinventory",
 TRN.TRANSFER_LOCATOR_ID               "To Loc ID",
 TRN.ORGANIZATION_ID                   "Org ID",
 TRN.PICKING_LINE_ID                   "Picking Line ID",
 TRN.SECONDARY_UOM_CODE                "Secondary UOM",
 TRN.SECONDARY_TRANSACTION_QUANTITY    "Secondary Trx Qty",
 0                                     "Lot Primary Qty", -- Only for OPM
 0                                     "Lot Secondary Qty", -- Only for OPM
 0                                     "Lot Calv Secondary Qty" -- Only for OPM
FROM
    MTL_MATERIAL_TRANSACTIONS         TRN,
    MTL_SYSTEM_ITEMS                  ITM,
    MTL_RESERVATIONS                  RES,
    PO_HEADERS_ALL                    POH
WHERE
     ##$$SALESORDERID$$##               = RES.DEMAND_SOURCE_HEADER_ID
and  RES.DEMAND_SOURCE_TYPE_ID     = 2                         -- SO
and  RES.SUPPLY_SOURCE_TYPE_ID     in (1,13)                   -- PO or INV
and  RES.SUPPLY_SOURCE_HEADER_ID   = POH.PO_HEADER_ID          --
and  POH.PO_HEADER_ID              = TRN.TRANSACTION_SOURCE_ID
and  TRN.ORGANIZATION_ID           = ITM.ORGANIZATION_ID
and  TRN.INVENTORY_ITEM_ID         = ITM.INVENTORY_ITEM_ID
and  TRN.TRANSACTION_TYPE_ID       = 18                        -- PO Receipt
and  TRN.TRANSACTION_SOURCE_TYPE_ID  = 1',
      p_title                  => 'Material Transactions - Picked Lines',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Picked Lines Associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_MTL_MATERIAL_TRANSACTIONS');



debug('begin add_signature: SALES_ORDER_WF_PO_APPROVAL_STATUS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_PO_APPROVAL_STATUS',
      p_sig_sql                => 'select WFS.item_key               "PO Number Key",
       WFA.DISPLAY_NAME           "Process Name",
       WFA1.DISPLAY_NAME          "Activity Name",
       WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE) Result,
       LKP.MEANING                "Active Status",
       WFS.NOTIFICATION_ID        "Notification ID",
       to_char(WFS.BEGIN_DATE,''DD-MON-RR_HH24:MI:SS'') "Begin Date",
       to_char(WFS.END_DATE,''DD-MON-RR_HH24:MI:SS'') "End Date",
       WFS.ERROR_NAME             "Error Name"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP
where 
     WFS.ITEM_TYPE          = ''POAPPRV''
and  WFS.item_key           in (select wf_item_key
                               from 
                               PO_HEADERS           POH,
                               OE_DROP_SHIP_SOURCES SRC,
                               OE_ORDER_LINES_ALL   LIN
                               where 
                               SRC.LINE_ID                   = LIN.LINE_ID
                               and  SRC.PO_HEADER_ID              = POH.PO_HEADER_ID
                               and  LIN.HEADER_ID                 = ##$$HEADERID$$##
                               and  NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID))                               
and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
and  WFP.PROCESS_NAME       = WFA.NAME
and  WFP.PROCESS_VERSION    = WFA.VERSION
and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
and  WFP.ACTIVITY_NAME      = WFA1.NAME
and  WFA1.VERSION = 
    (select max(VERSION)
     from WF_ACTIVITIES WF2
     where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
     and   WF2.NAME      = WFP.ACTIVITY_NAME)
and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'PO WF Approval Satus',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no PO workflow approval records associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_PO_APPROVAL_STATUS');



debug('begin add_signature: SALES_ORDER_WF_PO_APPROVAL_NOTIFICATIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_PO_APPROVAL_NOTIFICATIONS',
      p_sig_sql                => 'select   WFN.NOTIFICATION_ID         "Notification ID",
         WFN.TO_USER                 "To User",
         WFN.ORIGINAL_RECIPIENT      "Original Recipient",
         WFN.RECIPIENT_ROLE          "Recipient Role",
         WFN.MAIL_STATUS             "Mail Status",
         WFN.MESSAGE_NAME            "Message Name",
         WFN.STATUS                  Status,
         WFN.SUBJECT                 Subject
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_NOTIFICATIONS          WFN
where 
     WFS.ITEM_TYPE          = ''POAPPRV''
and  WFS.item_key           in (select wf_item_key
                               from 
                               PO_HEADERS           POH,
                               OE_DROP_SHIP_SOURCES SRC,
                               OE_ORDER_LINES_ALL   LIN
                               where 
                               SRC.LINE_ID                   = LIN.LINE_ID
                               and  SRC.PO_HEADER_ID              = POH.PO_HEADER_ID
                               and  LIN.HEADER_ID                 = ##$$HEADERID$$##
                               and  NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID))                               
and  WFS.NOTIFICATION_ID is not null
and  WFN.NOTIFICATION_ID = WFS.NOTIFICATION_ID
order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'PO WF Approval Notifications',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no associated PO WF Approval Notifications for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_PO_APPROVAL_NOTIFICATIONS');



debug('begin add_signature: SALES_ORDER_MTL_UNIT_TRANSACTIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_MTL_UNIT_TRANSACTIONS',
      p_sig_sql                => 'select 
     UNT.TRANSACTION_ID                 "Trx ID",
     UNT.TRANSACTION_DATE               "Material Trx Date",
     UNT.STATUS_ID                      "Status ID",
     UNT.SUBINVENTORY_CODE              Subinventory,
     UNT.LOCATOR_ID                     "Loc ID",
     UNT.SERIAL_NUMBER                  "Serial Number",
     UNT.INVENTORY_ITEM_ID              "Item ID",
     UNT.ORGANIZATION_ID                "Warehouse ID",
     to_char(UNT.TRANSACTION_DATE,''DD-MON-RR_HH24:MI:SS'') "Trx Date",
     UNT.TRANSACTION_SOURCE_ID          "Trx Source ID",
     UNT.TRANSACTION_SOURCE_TYPE_ID     "Trx Source Type ID",
     UNT.RECEIPT_ISSUE_TYPE             "Receipt Issue Type",
     UNT.CUSTOMER_ID                    "Customer ID",
     UNT.SHIP_ID                        "Ship ID"
from MTL_UNIT_TRANSACTIONS UNT
where UNT.TRANSACTION_ID in (select TRN.TRANSACTION_ID
FROM 
    MTL_MATERIAL_TRANSACTIONS         TRN,
    MTL_SYSTEM_ITEMS                  ITM 
WHERE 
 (TRN.TRX_SOURCE_LINE_ID,TRN.ORGANIZATION_ID,TRN.INVENTORY_ITEM_ID) IN (SELECT DISTINCT LINE_ID,SHIP_FROM_ORG_ID,INVENTORY_ITEM_ID
                               FROM OE_ORDER_LINES_ALL         LIN1
                               WHERE LIN1.HEADER_ID = ##$$HEADERID$$##
                               and NVL(''##$$LINEID$$##'',0)    in (0,LIN1.LINE_ID,
                                         LIN1.TOP_MODEL_LINE_ID,
                                         LIN1.ATO_LINE_ID,
                                         LIN1.LINK_TO_LINE_ID,
                                         LIN1.REFERENCE_LINE_ID,
                                         LIN1.SERVICE_REFERENCE_LINE_ID))
and TRN.ORGANIZATION_ID   = ITM.ORGANIZATION_ID 
and TRN.INVENTORY_ITEM_ID  = ITM.INVENTORY_ITEM_ID)
and (UPPER(nvl(''&det_cnt'',''Y'')) = ''Y'' or rownum <= 10)',
      p_title                  => 'Material Unit Transactions',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Material Unit Transactions associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_MTL_UNIT_TRANSACTIONS');



debug('begin add_signature: SALES_ORDER_MTL_TXN_REQUEST_LINES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_MTL_TXN_REQUEST_LINES',
      p_sig_sql                => 'select distinct
 TRL.LINE_ID                         "Move Line ID",
 TRH.REQUEST_NUMBER                  "Move Number",
 TRL.HEADER_ID                       "Move Header ID",
 TRL.LINE_NUMBER                     "Move Line Number",
 decode(TRL.LINE_STATUS,
        1, ''1=Incomplete'',
        2, ''2=Pend Aprvl'',
        3, ''3=Approved'',
        4, ''4=Not Apprvd'',
        5, ''5=Closed'',
        6, ''6=Canceled'',
        7, ''7=Pre Apprvd'',
        8, ''8=Part Aprvd'',
        9, ''9=Cncld Source'') "Move Line Status",
 to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
 TRL.TXN_SOURCE_LINE_ID              "Trx Source Line ID",
 ITM.SEGMENT1                        Item,
 TRL.QUANTITY                        Qty,
 TRL.PRIMARY_QUANTITY                "Primary Qty",           
 TRL.QUANTITY_DELIVERED              "Delivered Qty",
 TRL.QUANTITY_DETAILED               "Detail Qty",
 TRL.MOVE_ORDER_TYPE_NAME            "Move Type Name",
 decode(TRL.TRANSACTION_SOURCE_TYPE_ID,2,''Sales Order'',TRL.TRANSACTION_SOURCE_TYPE_ID) 
                                     "Trx Source Type",  
 TRL.TRANSACTION_TYPE_NAME           "Trx Type Name",       
 TRL.ORGANIZATION_ID                 "Warehouse ID",
 TRL.FROM_SUBINVENTORY_CODE          "From Subinventory",
 TRL.FROM_LOCATOR_ID                 "From Loc ID", 
 TRL.TO_SUBINVENTORY_CODE            "To Subinventory",
 TRL.TO_LOCATOR_ID                   "To Loc ID",          
 TRL.LOT_NUMBER                      "Lot Number",
 TRL.TRANSACTION_HEADER_ID           "Trx Header ID",
 trl.secondary_quantity              "Secondary Qty",
 trl.secondary_quantity_detailed     "Secondary Detailed Qty",
 trl.secondary_quantity_delivered    "Secondary Delivered Qty"
from MTL_TXN_REQUEST_LINES_V   TRL,
     MTL_TXN_REQUEST_HEADERS   TRH,
     WSH_DELIVERY_DETAILS      DET,
     OE_ORDER_LINES_ALL        LIN,
     MTL_SYSTEM_ITEMS          ITM
where TRL.LINE_ID            = DET.MOVE_ORDER_LINE_ID
  and LIN.SHIP_FROM_ORG_ID   = ITM.ORGANIZATION_ID(+) 
  and LIN.INVENTORY_ITEM_ID  = ITM.INVENTORY_ITEM_ID(+)  
  and DET.SOURCE_LINE_ID     = LIN.LINE_ID
  and TRL.HEADER_ID          = TRH.HEADER_ID
  and LIN.HEADER_ID          = ##$$HEADERID$$##
  and NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.REFERENCE_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Move Transactions',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no Move Transactions associated with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_MTL_TXN_REQUEST_LINES');



debug('begin add_signature: SALES_ORDER_WF_PO_APPROVAL_ERRORS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WF_PO_APPROVAL_ERRORS',
      p_sig_sql                => 'select WFA.DISPLAY_NAME           "Process Name",
       WFA1.DISPLAY_NAME          "Activity Name",
       WF_CORE.ACTIVITY_RESULT(WFA1.RESULT_TYPE,WFS.ACTIVITY_RESULT_CODE) Result,
       LKP.MEANING                "Activity Status",
       WFS.ERROR_NAME             "Error Name",
       WFS.ERROR_MESSAGE          "Error Message",
       WFS.ERROR_STACK            "Error Stack"
from WF_ITEM_ACTIVITY_STATUSES WFS,
     WF_PROCESS_ACTIVITIES     WFP,
     WF_ACTIVITIES_VL          WFA,
     WF_ACTIVITIES_VL          WFA1,
     WF_LOOKUPS                LKP
where 
     WFS.ITEM_TYPE          = ''POAPPRV''
and  WFS.item_key           in (select wf_item_key
                               from 
                               PO_HEADERS           POH,
                               OE_DROP_SHIP_SOURCES SRC,
                               OE_ORDER_LINES_ALL   LIN
                               where 
                               SRC.LINE_ID                   = LIN.LINE_ID
                               and  SRC.PO_HEADER_ID              = POH.PO_HEADER_ID
                               and  LIN.HEADER_ID                 = ##$$HEADERID$$##
                               and  NVL(''##$$LINEID$$##'',0)      in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID))                               
and  WFS.PROCESS_ACTIVITY   = WFP.INSTANCE_ID
and  WFP.PROCESS_ITEM_TYPE  = WFA.ITEM_TYPE
and  WFP.PROCESS_NAME       = WFA.NAME
and  WFP.PROCESS_VERSION    = WFA.VERSION
and  WFP.ACTIVITY_ITEM_TYPE = WFA1.ITEM_TYPE
and  WFP.ACTIVITY_NAME      = WFA1.NAME
and  WFA1.VERSION = 
    (select max(VERSION)
     from WF_ACTIVITIES WF2
     where WF2.ITEM_TYPE = WFP.ACTIVITY_ITEM_TYPE
     and   WF2.NAME      = WFP.ACTIVITY_NAME)
and  LKP.LOOKUP_TYPE = ''WFENG_STATUS''
and  LKP.LOOKUP_CODE = WFS.ACTIVITY_STATUS
and  WFS.ERROR_NAME is not NULL
order by WFS.ITEM_KEY, WFS.BEGIN_DATE, EXECUTION_TIME',
      p_title                  => 'PO WF Approval Errors',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Review the PO WF Approval Errors.',
      p_solution               => '',
      p_success_msg            => 'No PO WF Approval Errors for this order.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('N','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WF_PO_APPROVAL_ERRORS');



debug('begin add_signature: SALES_ORDER_WSH_ACCOUNTING_PERIODS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_WSH_ACCOUNTING_PERIODS',
      p_sig_sql                => 'SELECT distinct 
       mp.organization_id               "Org ID",
       mp.organization_code             "Org",
       to_char(STP.PLANNED_DEPARTURE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Plan Dep Date",
       ''''                               "Schedule Date",
       oac.acct_period_id               "Account Period ID",
       oac.period_name                  "Period Name",
       oac.open_flag                    "Open Flag",
       to_char(oac.period_start_date,''DD-MON-RR_HH24:MI:SS'')   "Period Start Date",
       to_char(oac.period_close_date,''DD-MON-RR_HH24:MI:SS'')   "Period Close Date",
       to_char(oac.schedule_close_date,''DD-MON-RR_HH24:MI:SS'') "Period Schedule Close Date"
  FROM MTL_PARAMETERS                   MP,
       ORG_ACCT_PERIODS                 OAC,
       WSH_DELIVERY_DETAILS             DET,
       WSH_DELIVERY_LEGS                LEG,
       WSH_TRIP_STOPS                   STP,
       WSH_DELIVERY_ASSIGNMENTS         ASG,
       WSH_TRIPS                        TRP
where ASG.DELIVERY_DETAIL_ID          = DET.DELIVERY_DETAIL_ID
  and STP.STOP_ID(+)                  = LEG.PICK_UP_STOP_ID
  and STP.TRIP_ID                     = TRP.TRIP_ID(+)
  and LEG.DELIVERY_ID(+)              = ASG.DELIVERY_ID
  and DET.SOURCE_CODE                 = ''OE''
  and MP.ORGANIZATION_ID              = OAC.ORGANIZATION_ID
  and MP.ORGANIZATION_ID              = DET.ORGANIZATION_ID
  and STP.PLANNED_DEPARTURE_DATE      BETWEEN OAC.PERIOD_START_DATE and NVL(OAC.PERIOD_CLOSE_DATE,OAC.SCHEDULE_CLOSE_DATE)
  and DET.SOURCE_HEADER_ID            = ##$$HEADERID$$##
union
SELECT distinct 
       mp.organization_id               "Org ID",
       mp.organization_code             "Org",
       ''''                               "Plan Dep Date",
       to_char(LIN.SCHEDULE_SHIP_DATE,''DD-MON-RR_HH24:MI:SS'')   "Schedule Date",
       oac.acct_period_id               "Account Period ID",
       oac.period_name                  "Period Name",
       oac.open_flag                    "Open Flag",
       to_char(oac.period_start_date,''DD-MON-RR_HH24:MI:SS'')   "Period Start Date",
       to_char(oac.period_close_date,''DD-MON-RR_HH24:MI:SS'')   "Period Close Date",
       to_char(oac.schedule_close_date,''DD-MON-RR_HH24:MI:SS'') "Period Schedule Close Date"
  FROM MTL_PARAMETERS                   MP,
       ORG_ACCT_PERIODS                 OAC,
       WSH_DELIVERY_DETAILS             DET,
       OE_ORDER_LINES_ALL                   LIN
where DET.SOURCE_LINE_ID              = LIN.LINE_ID
  and DET.SOURCE_CODE                 = ''OE''
  and MP.ORGANIZATION_ID              = OAC.ORGANIZATION_ID
  and MP.ORGANIZATION_ID              = DET.ORGANIZATION_ID
  and LIN.SCHEDULE_SHIP_DATE          BETWEEN OAC.PERIOD_START_DATE and NVL(OAC.PERIOD_CLOSE_DATE,OAC.SCHEDULE_CLOSE_DATE)
  and DET.SOURCE_HEADER_ID            = ##$$HEADERID$$##',
      p_title                  => 'Accounting Periods',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'No open Accounting Periods found for this sales order.',
      p_solution               => '<ul>
   <li> Open the appropriate period(s) by going to Inventory > Accounting Close Cycle > Inventory Accounting Period.</li>
</ul>',
      p_success_msg            => 'Accounting Periods are open for this sales order.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_WSH_ACCOUNTING_PERIODS');



debug('begin add_signature: SALES_ORDER_RCV_SHIPMENT_LINES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_RCV_SHIPMENT_LINES',
      p_sig_sql                => 'select  /* DROP SHIPMENTS */  
  SHL.SHIPMENT_LINE_ID                  "Shipment Line ID", 
  SHL.SHIPMENT_HEADER_ID                "Shipment Header ID",    
  SHL.SHIPMENT_LINE_STATUS_CODE         "Shipment Line Status",     
  SHL.QUANTITY_RECEIVED                 "Qty Received",
  SHL.QUANTITY_SHIPPED                  "Qty Shipped",  
  SHL.DESTINATION_TYPE_CODE             "Dest Type",     
  SHL.OE_ORDER_HEADER_ID                "Order Header ID",     
  SHL.OE_ORDER_LINE_ID                  "Order Line ID",    
  SHL.ITEM_ID                           "Item ID",         
  SHL.SHIP_TO_LOCATION_ID               "Ship To Org", 
  SHL.SOURCE_DOCUMENT_CODE              "Source Doc",     
  SHL.REQUEST_ID                        "Request ID"
from
   RCV_SHIPMENT_LINES         SHL,
   OE_DROP_SHIP_SOURCES       SRC,
   OE_ORDER_LINES_ALL         LIN
where 
     SRC.LINE_ID                   = LIN.LINE_ID
and  SRC.PO_LINE_ID                = SHL.PO_LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)       in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
 UNION ALL
select      /* RETURNS */
  SHL.SHIPMENT_LINE_ID                  "Shipment Line ID", 
  SHL.SHIPMENT_HEADER_ID                "Shipment Header ID",    
  SHL.SHIPMENT_LINE_STATUS_CODE         "Shipment Line Status",     
  SHL.QUANTITY_RECEIVED                 "Qty Received",
  SHL.QUANTITY_SHIPPED                  "Qty Shipped",  
  SHL.DESTINATION_TYPE_CODE             "Dest Type",     
  SHL.OE_ORDER_HEADER_ID                "Order Header ID",     
  SHL.OE_ORDER_LINE_ID                  "Order Line ID",    
  SHL.ITEM_ID                           "Item ID",         
  SHL.SHIP_TO_LOCATION_ID               "Ship To Org", 
  SHL.SOURCE_DOCUMENT_CODE              "Source Doc",     
  SHL.REQUEST_ID                        "Request ID"
from
   RCV_SHIPMENT_LINES             SHL,
   OE_ORDER_LINES_ALL             LIN
where 
     SHL.OE_ORDER_LINE_ID          = LIN.LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)       in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select    /* INTERNAL SALES ORDER */ 
  SHL.SHIPMENT_LINE_ID                  "Shipment Line ID", 
  SHL.SHIPMENT_HEADER_ID                "Shipment Header ID",    
  SHL.SHIPMENT_LINE_STATUS_CODE         "Shipment Line Status",     
  SHL.QUANTITY_RECEIVED                 "Qty Received",
  SHL.QUANTITY_SHIPPED                  "Qty Shipped",  
  SHL.DESTINATION_TYPE_CODE             "Dest Type",     
  SHL.OE_ORDER_HEADER_ID                "Order Header ID",     
  SHL.OE_ORDER_LINE_ID                  "Order Line ID",    
  SHL.ITEM_ID                           "Item ID",         
  SHL.SHIP_TO_LOCATION_ID               "Ship To Org", 
  SHL.SOURCE_DOCUMENT_CODE              "Source Doc",     
  SHL.REQUEST_ID                        "Request ID"
from
   RCV_SHIPMENT_LINES         SHL,
   OE_ORDER_LINES_ALL         LIN
where 
     LIN.SOURCE_DOCUMENT_LINE_ID       = SHL.REQUISITION_LINE_ID
and  LIN.SOURCE_DOCUMENT_TYPE_ID       = 10                        
and  LIN.HEADER_ID                     = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)           in (0,LIN.LINE_ID,
                                             LIN.TOP_MODEL_LINE_ID,
                                             LIN.ATO_LINE_ID,
                                             LIN.LINK_TO_LINE_ID,
                                             LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select  /* ATO BUY ITEM */
  SHL.SHIPMENT_LINE_ID                  "Shipment Line ID", 
  SHL.SHIPMENT_HEADER_ID                "Shipment Header ID",    
  SHL.SHIPMENT_LINE_STATUS_CODE         "Shipment Line Status",     
  SHL.QUANTITY_RECEIVED                 "Qty Received",
  SHL.QUANTITY_SHIPPED                  "Qty Shipped",  
  SHL.DESTINATION_TYPE_CODE             "Dest Type",     
  SHL.OE_ORDER_HEADER_ID                "Order Header ID",     
  SHL.OE_ORDER_LINE_ID                  "Order Line ID",    
  SHL.ITEM_ID                           "Item ID",         
  SHL.SHIP_TO_LOCATION_ID               "Ship To Org", 
  SHL.SOURCE_DOCUMENT_CODE              "Source Doc",     
  SHL.REQUEST_ID                        "Request ID"
from
   RCV_SHIPMENT_LINES         SHL,
   MTL_RESERVATIONS           RES,
   PO_HEADERS_ALL             POH
where
     ##$$SALESORDERID$$##               = RES.DEMAND_SOURCE_HEADER_ID
and  RES.DEMAND_SOURCE_LINE_ID     = NVL(NVL(''##$$LINEID$$##'',0),RES.DEMAND_SOURCE_LINE_ID)
and  RES.DEMAND_SOURCE_TYPE_ID     = 2                         -- SO
and  RES.SUPPLY_SOURCE_TYPE_ID     in (1,13)                   -- PO or INV
and  RES.SUPPLY_SOURCE_HEADER_ID   = POH.PO_HEADER_ID          --
and  POH.PO_HEADER_ID              = SHL.PO_HEADER_ID',
      p_title                  => 'Receiving Shipment Lines',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no assassinated Receiving Shipment lines for this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_RCV_SHIPMENT_LINES');



debug('begin add_signature: SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_SHIPPED_QTY');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_SHIPPED_QTY',
      p_sig_sql                => 'select 
    substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
     LIN.LINE_ID                   "Line ID",
     LIN.INVENTORY_ITEM_ID         "Item ID",
     substr(LIN.FLOW_STATUS_CODE,1,22) "Workflow Status",
     nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
     LIN.ORDER_QUANTITY_UOM        "Ordered UOM",
     nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
     nvl(LIN.SHIPPING_QUANTITY,0)  "Shipping QTY",
     nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
     nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY",          
     nvl(LIN.INVOICED_QUANTITY,0)  "Invoiced QTY", 
     nvl(LIN.OPEN_FLAG,''N'')        "Open",
     nvl(LIN.BOOKED_FLAG,''N'')      "Booked",
     nvl(LIN.SHIPPABLE_FLAG,''N'')   "Shipped",
     nvl(LIN.CANCELLED_FLAG,''N'')   "Cancelled",
     nvl(LIN.FULFILLED_FLAG, ''N'')  "Fullfilled",
     nvl(LIN.SHIPPING_INTERFACED_FLAG,''N'')    "Shipping Interface",
     LIN.SHIP_FROM_ORG_ID          "Ship From",
     nvl(LIN.INVOICE_INTERFACE_STATUS_CODE,''N'') "Invoice Interface",
     LIN.SHIP_TOLERANCE_ABOVE                 "Ship Tolerance Above",
     LIN.SHIP_TOLERANCE_BELOW                 "Ship Tolerance Below",            
     to_char(LIN.ACTUAL_SHIPMENT_DATE,''DD-MON-RR_HH24:MI:SS'')  "Actual Ship",
     to_char(LIN.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Create Date",
     to_char(LIN.LAST_UPDATE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Update Date"
from
     OE_ORDER_HEADERS_ALL                ORD,
     OE_ORDER_LINES_ALL                LIN
where
     ORD.HEADER_ID                  = ##$$HEADERID$$##
     and LIN.HEADER_ID              = ##$$HEADERID$$##
     AND LIN.SHIPPED_QUANTITY IS NOT NULL
     AND LIN.ORDERED_QUANTITY != LIN.SHIPPED_QUANTITY
     and   NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                          LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
     order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Line Ordered Qty does not equal Shpped Qty',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Shipped Qty does not equal Ordered Qty.',
      p_solution               => 'Verify the Shipped Qty is within tolerance.',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_SHIPPED_QTY');



debug('begin add_signature: SALES_ORDER_RCV_TRANSACTIONS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_RCV_TRANSACTIONS',
      p_sig_sql                => 'select /* DROP SHIPMENTS */
  RCV.TRANSACTION_ID              "Transaction ID",
  RCV.PARENT_TRANSACTION_ID       "Parent Transaction ID",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  RCV.TRANSACTION_TYPE            "Transaction Type",
  to_char(RCV.TRANSACTION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Transaction Date",
  RCV.DESTINATION_TYPE_CODE       "Dest Type",   
  RCV.INSPECTION_STATUS_CODE      "Inspect Status",
  RCV.INTERFACE_SOURCE_CODE       "Interface Source", 
  RCV.INTERFACE_TRANSACTION_ID    "Interface Trans ID", 
  RCV.LOCATION_ID                 "Loc ID",
  RCV.MVT_STAT_STATUS             "Move Status",
  RCV.ORGANIZATION_ID             "Org ID",
  RCV.OE_ORDER_HEADER_ID          "SO Header ID",
  RCV.OE_ORDER_LINE_ID            "SO Line ID",
  RCV.PO_HEADER_ID                "PO Header ID",
  RCV.PO_LINE_ID                  "PO Line ID",
  RCV.PO_LINE_LOCATION_ID         "Line Loc ID",
  RCV.PO_UNIT_PRICE               "Unit Price",
  RCV.PRIMARY_UNIT_OF_MEASURE     UOM,
  RCV.QUANTITY                    QTY,
  RCV.REQUEST_ID                  "Request ID",
  RCV.SHIPMENT_HEADER_ID          "Shipment Header ID",
  RCV.SHIPMENT_LINE_ID            "Shipment Line ID",
  RCV.SOURCE_DOCUMENT_CODE        "Source Doc Code", 
  RCV.VENDOR_ID                   "Vendor ID",    
  RCV.VENDOR_SITE_ID              "Vendor Site ID"  
from
   RCV_TRANSACTIONS     RCV,
   OE_DROP_SHIP_SOURCES SRC,
   OE_ORDER_LINES_ALL   LIN
where 
     SRC.LINE_ID                   = LIN.LINE_ID
and  SRC.PO_LINE_ID                = RCV.PO_LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
 UNION ALL
select    /* RETURNS */
  RCV.TRANSACTION_ID              "Transaction ID",
  RCV.PARENT_TRANSACTION_ID       "Parent Transaction ID",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  RCV.TRANSACTION_TYPE            "Transaction Type",
  to_char(RCV.TRANSACTION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Transaction Date",
  RCV.DESTINATION_TYPE_CODE       "Dest Type",   
  RCV.INSPECTION_STATUS_CODE      "Inspect Status",
  RCV.INTERFACE_SOURCE_CODE       "Interface Source", 
  RCV.INTERFACE_TRANSACTION_ID    "Interface Trans ID", 
  RCV.LOCATION_ID                 "Loc ID",
  RCV.MVT_STAT_STATUS             "Move Status",
  RCV.ORGANIZATION_ID             "Org ID",
  RCV.OE_ORDER_HEADER_ID          "SO Header ID",
  RCV.OE_ORDER_LINE_ID            "SO Line ID",
  RCV.PO_HEADER_ID                "PO Header ID",
  RCV.PO_LINE_ID                  "PO Line ID",
  RCV.PO_LINE_LOCATION_ID         "Line Loc ID",
  RCV.PO_UNIT_PRICE               "Unit Price",
  RCV.PRIMARY_UNIT_OF_MEASURE     UOM,
  RCV.QUANTITY                    QTY,
  RCV.REQUEST_ID                  "Request ID",
  RCV.SHIPMENT_HEADER_ID          "Shipment Header ID",
  RCV.SHIPMENT_LINE_ID            "Shipment Line ID",
  RCV.SOURCE_DOCUMENT_CODE        "Source Doc Code", 
  RCV.VENDOR_ID                   "Vendor ID",    
  RCV.VENDOR_SITE_ID              "Vendor Site ID"
from
   RCV_TRANSACTIONS     RCV,
   OE_ORDER_LINES_ALL   LIN
where 
     RCV.OE_ORDER_LINE_ID          = LIN.LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select      /* INTERNAL SALES ORDERS */
  RCV.TRANSACTION_ID              "Transaction ID",
  RCV.PARENT_TRANSACTION_ID       "Parent Transaction ID",
  to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)) Line,
  RCV.TRANSACTION_TYPE            "Transaction Type",
  to_char(RCV.TRANSACTION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Transaction Date",
  RCV.DESTINATION_TYPE_CODE       "Dest Type",   
  RCV.INSPECTION_STATUS_CODE      "Inspect Status",
  RCV.INTERFACE_SOURCE_CODE       "Interface Source", 
  RCV.INTERFACE_TRANSACTION_ID    "Interface Trans ID", 
  RCV.LOCATION_ID                 "Loc ID",
  RCV.MVT_STAT_STATUS             "Move Status",
  RCV.ORGANIZATION_ID             "Org ID",
  RCV.OE_ORDER_HEADER_ID          "SO Header ID",
  RCV.OE_ORDER_LINE_ID            "SO Line ID",
  RCV.PO_HEADER_ID                "PO Header ID",
  RCV.PO_LINE_ID                  "PO Line ID",
  RCV.PO_LINE_LOCATION_ID         "Line Loc ID",
  RCV.PO_UNIT_PRICE               "Unit Price",
  RCV.PRIMARY_UNIT_OF_MEASURE     UOM,
  RCV.QUANTITY                    QTY,
  RCV.REQUEST_ID                  "Request ID",
  RCV.SHIPMENT_HEADER_ID          "Shipment Header ID",
  RCV.SHIPMENT_LINE_ID            "Shipment Line ID",
  RCV.SOURCE_DOCUMENT_CODE        "Source Doc Code", 
  RCV.VENDOR_ID                   "Vendor ID",    
  RCV.VENDOR_SITE_ID              "Vendor Site ID"
from
   RCV_TRANSACTIONS     RCV,
   OE_ORDER_LINES_ALL   LIN
where 
     LIN.SOURCE_DOCUMENT_LINE_ID       = RCV.REQUISITION_LINE_ID
and  LIN.SOURCE_DOCUMENT_TYPE_ID       = 10                        
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select /* ATO BUY ITEM */
  RCV.TRANSACTION_ID              "Transaction ID",
  RCV.PARENT_TRANSACTION_ID       "Parent Transaction ID",
  to_char(RES.DEMAND_SOURCE_LINE_ID) Line,
  RCV.TRANSACTION_TYPE            "Transaction Type",
  to_char(RCV.TRANSACTION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Transaction Date",
  RCV.DESTINATION_TYPE_CODE       "Dest Type",   
  RCV.INSPECTION_STATUS_CODE      "Inspect Status",
  RCV.INTERFACE_SOURCE_CODE       "Interface Source", 
  RCV.INTERFACE_TRANSACTION_ID    "Interface Trans ID", 
  RCV.LOCATION_ID                 "Loc ID",
  RCV.MVT_STAT_STATUS             "Move Status",
  RCV.ORGANIZATION_ID             "Org ID",
  RCV.OE_ORDER_HEADER_ID          "SO Header ID",
  RCV.OE_ORDER_LINE_ID            "SO Line ID",
  RCV.PO_HEADER_ID                "PO Header ID",
  RCV.PO_LINE_ID                  "PO Line ID",
  RCV.PO_LINE_LOCATION_ID         "Line Loc ID",
  RCV.PO_UNIT_PRICE               "Unit Price",
  RCV.PRIMARY_UNIT_OF_MEASURE     UOM,
  RCV.QUANTITY                    QTY,
  RCV.REQUEST_ID                  "Request ID",
  RCV.SHIPMENT_HEADER_ID          "Shipment Header ID",
  RCV.SHIPMENT_LINE_ID            "Shipment Line ID",
  RCV.SOURCE_DOCUMENT_CODE        "Source Doc Code", 
  RCV.VENDOR_ID                   "Vendor ID",    
  RCV.VENDOR_SITE_ID              "Vendor Site ID"
from
   RCV_TRANSACTIONS           RCV,
   MTL_RESERVATIONS           RES,
   PO_HEADERS_ALL             POH
where
     ##$$SALESORDERID$$##               = RES.DEMAND_SOURCE_HEADER_ID
and  RES.DEMAND_SOURCE_LINE_ID     = NVL(''##$$LINEID$$##'',RES.DEMAND_SOURCE_LINE_ID)
and  RES.DEMAND_SOURCE_TYPE_ID     = 2                         -- SO
and  RES.SUPPLY_SOURCE_TYPE_ID     in (1,13)                   -- PO or INV
and  RES.SUPPLY_SOURCE_HEADER_ID   = POH.PO_HEADER_ID          --
and  POH.PO_HEADER_ID              = RCV.PO_HEADER_ID',
      p_title                  => 'Receiving Transactions',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no associated Receiving Transactions with this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_RCV_TRANSACTIONS');



debug('begin add_signature: SALES_ORDER_RCV_TRANSACTIONS_INTERFACE');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_RCV_TRANSACTIONS_INTERFACE',
      p_sig_sql                => 'select   /* DROP SHIPMENTS */
  RTI.INTERFACE_TRANSACTION_ID          "Interface Transaction ID",
  RTI.PROCESSING_MODE_CODE              "Process Mode",     
  RTI.PROCESSING_STATUS_CODE            "Process Status",     
  RTI.TRANSACTION_STATUS_CODE           "Transaction Status",      
  to_char(RTI.TRANSACTION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Transaction Date",     
  RTI.TRANSACTION_TYPE                  "Transaction Type",   
  RTI.DESTINATION_TYPE_CODE             "Destination Type",     
  RTI.INSPECTION_STATUS_CODE            "Inspection Status",     
  RTI.INTERFACE_SOURCE_CODE             "Inspection Source",     
  RTI.OE_ORDER_HEADER_ID                "SO Header ID",      
  RTI.OE_ORDER_LINE_ID                  "SO Line ID",    
  RTI.ITEM_ID                           "Item ID",         
  RTI.QUANTITY                          Qty,        
  RTI.PRIMARY_QUANTITY                  "Primary Qty",   
  RTI.PO_UNIT_PRICE                     "PO Unit Price",   
  RTI.SUBINVENTORY                      SUB,     
  RTI.TO_ORGANIZATION_ID                "To Org ID", 
  RTI.RECEIPT_SOURCE_CODE               "Receipt Source",    
  RTI.PARENT_TRANSACTION_ID             "Parent Transaction ID",  
  RTI.SHIPMENT_HEADER_ID                "Shipment Header ID",     
  RTI.SHIPMENT_LINE_ID                  "Shipment Line ID",     
  RTI.SOURCE_DOCUMENT_CODE              "Source Document",     
  RTI.PROCESSING_REQUEST_ID             "Request ID"
from
   RCV_TRANSACTIONS_INTERFACE RTI,
   OE_DROP_SHIP_SOURCES       SRC,
   OE_ORDER_LINES_ALL         LIN
where 
     SRC.LINE_ID                   = LIN.LINE_ID
and  SRC.PO_LINE_ID                = RTI.PO_LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
 UNION ALL
select      /* RETURNS */ 
  RTI.INTERFACE_TRANSACTION_ID          "Interface Transaction ID",
  RTI.PROCESSING_MODE_CODE              "Process Mode",     
  RTI.PROCESSING_STATUS_CODE            "Process Status",     
  RTI.TRANSACTION_STATUS_CODE           "Transaction Status",      
  to_char(RTI.TRANSACTION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Transaction Date",     
  RTI.TRANSACTION_TYPE                  "Transaction Type",   
  RTI.DESTINATION_TYPE_CODE             "Destination Type",     
  RTI.INSPECTION_STATUS_CODE            "Inspection Status",     
  RTI.INTERFACE_SOURCE_CODE             "Inspection Source",     
  RTI.OE_ORDER_HEADER_ID                "SO Header ID",      
  RTI.OE_ORDER_LINE_ID                  "SO Line ID",    
  RTI.ITEM_ID                           "Item ID",         
  RTI.QUANTITY                          Qty,        
  RTI.PRIMARY_QUANTITY                  "Primary Qty",   
  RTI.PO_UNIT_PRICE                     "PO Unit Price",   
  RTI.SUBINVENTORY                      SUB,     
  RTI.TO_ORGANIZATION_ID                "To Org ID", 
  RTI.RECEIPT_SOURCE_CODE               "Receipt Source",    
  RTI.PARENT_TRANSACTION_ID             "Parent Transaction ID",  
  RTI.SHIPMENT_HEADER_ID                "Shipment Header ID",     
  RTI.SHIPMENT_LINE_ID                  "Shipment Line ID",     
  RTI.SOURCE_DOCUMENT_CODE              "Source Document",     
  RTI.PROCESSING_REQUEST_ID             "Request ID"
from
   RCV_TRANSACTIONS_INTERFACE     RTI,
   OE_ORDER_LINES_ALL             LIN
where 
     RTI.OE_ORDER_LINE_ID          = LIN.LINE_ID
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)    in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
UNION ALL
select    /* INTERNAL SALES ORDER  */ 
  RTI.INTERFACE_TRANSACTION_ID          "Interface Transaction ID",
  RTI.PROCESSING_MODE_CODE              "Process Mode",     
  RTI.PROCESSING_STATUS_CODE            "Process Status",     
  RTI.TRANSACTION_STATUS_CODE           "Transaction Status",      
  to_char(RTI.TRANSACTION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Transaction Date",     
  RTI.TRANSACTION_TYPE                  "Transaction Type",   
  RTI.DESTINATION_TYPE_CODE             "Destination Type",     
  RTI.INSPECTION_STATUS_CODE            "Inspection Status",     
  RTI.INTERFACE_SOURCE_CODE             "Inspection Source",     
  RTI.OE_ORDER_HEADER_ID                "SO Header ID",      
  RTI.OE_ORDER_LINE_ID                  "SO Line ID",    
  RTI.ITEM_ID                           "Item ID",         
  RTI.QUANTITY                          Qty,        
  RTI.PRIMARY_QUANTITY                  "Primary Qty",   
  RTI.PO_UNIT_PRICE                     "PO Unit Price",   
  RTI.SUBINVENTORY                      SUB,     
  RTI.TO_ORGANIZATION_ID                "To Org ID", 
  RTI.RECEIPT_SOURCE_CODE               "Receipt Source",    
  RTI.PARENT_TRANSACTION_ID             "Parent Transaction ID",  
  RTI.SHIPMENT_HEADER_ID                "Shipment Header ID",     
  RTI.SHIPMENT_LINE_ID                  "Shipment Line ID",     
  RTI.SOURCE_DOCUMENT_CODE              "Source Document",     
  RTI.PROCESSING_REQUEST_ID             "Request ID"
from
   RCV_TRANSACTIONS_INTERFACE     RTI,
   OE_ORDER_LINES_ALL             LIN
where 
     LIN.SOURCE_DOCUMENT_LINE_ID       = RTI.REQUISITION_LINE_ID
and  LIN.SOURCE_DOCUMENT_TYPE_ID       = 10                        
and  LIN.HEADER_ID                 = ##$$HEADERID$$##
and  NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                         LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)',
      p_title                  => 'Receiving Transactions Interface',
      p_fail_condition         => 'NRS',
      p_problem_descr          => 'There are no association Receiving Transactions Interface records to this sales order.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_RCV_TRANSACTIONS_INTERFACE');



debug('begin add_signature: SALES_ORDER_LINE_SHIPPED_NOT_INTERFACED');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_SHIPPED_NOT_INTERFACED',
      p_sig_sql                => 'select 
    substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
     LIN.LINE_ID                   "Line ID",
     LIN.INVENTORY_ITEM_ID         "Item ID",
     substr(LIN.FLOW_STATUS_CODE,1,22) "Workflow Status",
     nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
     LIN.ORDER_QUANTITY_UOM        "Ordered UOM",
     nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
     nvl(LIN.SHIPPING_QUANTITY,0)  "Shipping QTY",
     nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
     nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY",          
     nvl(LIN.INVOICED_QUANTITY,0)  "Invoiced QTY", 
     nvl(LIN.OPEN_FLAG,''N'')        "Open",
     nvl(LIN.BOOKED_FLAG,''N'')      "Booked",
     nvl(LIN.SHIPPABLE_FLAG,''N'')   "Shipped",
     nvl(LIN.CANCELLED_FLAG,''N'')   "Cancelled",
     nvl(LIN.FULFILLED_FLAG, ''N'')  "Fullfilled",
     nvl(LIN.SHIPPING_INTERFACED_FLAG,''N'')    "Shipping Interface",
     LIN.SHIP_FROM_ORG_ID          "Ship From",
     nvl(LIN.INVOICE_INTERFACE_STATUS_CODE,''N'') "Invoice Interface",
     LIN.SHIP_TOLERANCE_ABOVE                 "Ship Tolerance Above",
     LIN.SHIP_TOLERANCE_BELOW                 "Ship Tolerance Below",            
     to_char(LIN.ACTUAL_SHIPMENT_DATE,''DD-MON-RR_HH24:MI:SS'')  "Actual Ship",
     to_char(LIN.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Create Date",
     to_char(LIN.LAST_UPDATE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Update Date"
from
     OE_ORDER_HEADERS_ALL                ORD,
     OE_ORDER_LINES_ALL                LIN,
     WSH_DELIVERY_DETAILS             DET
where
     ORD.HEADER_ID                  = ##$$HEADERID$$##
     AND LIN.HEADER_ID              = ##$$HEADERID$$##
     AND DET.SOURCE_LINE_ID         = LIN.LINE_ID
     AND DET.SOURCE_CODE            = ''OE''
     AND DET.OE_INTERFACED_FLAG = ''N''
     AND LIN.SHIPPABLE_FLAG = ''Y''
     AND nvl(LIN.SHIPPED_QUANTITY,0) > 0
     and   NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                          LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
     order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Line has been Shipped but not Interfaced to OM',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Sales Order Line has a shipped quantity but has not yet been interfaced to Order Management.',
      p_solution               => 'Refer to [1147826.1] Delivery is ship confirmed successfully, but delivery details do not progress to SHIPPED or INTERFACED.',
      p_success_msg            => 'Any shipped quantities have been interfaced to Order Management.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_SHIPPED_NOT_INTERFACED');



debug('begin add_signature: SALES_ORDER_LINE_CLOSED_SHIPPED_NOT_INTERFACED_OM');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_CLOSED_SHIPPED_NOT_INTERFACED_OM',
      p_sig_sql                => 'select 
    substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
     LIN.LINE_ID                   "Line ID",
     LIN.INVENTORY_ITEM_ID         "Item ID",
     substr(LIN.FLOW_STATUS_CODE,1,22) "Workflow Status",
     nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
     LIN.ORDER_QUANTITY_UOM        "Ordered UOM",
     nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
     nvl(LIN.SHIPPING_QUANTITY,0)  "Shipping QTY",
     nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
     nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY",          
     nvl(LIN.INVOICED_QUANTITY,0)  "Invoiced QTY", 
     nvl(LIN.OPEN_FLAG,''N'')        "Open",
     nvl(LIN.BOOKED_FLAG,''N'')      "Booked",
     nvl(LIN.SHIPPABLE_FLAG,''N'')   "Shipped",
     nvl(LIN.CANCELLED_FLAG,''N'')   "Cancelled",
     nvl(LIN.FULFILLED_FLAG, ''N'')  "Fullfilled",
     nvl(LIN.SHIPPING_INTERFACED_FLAG,''N'')    "Shipping Interface",
     LIN.SHIP_FROM_ORG_ID          "Ship From",
     nvl(LIN.INVOICE_INTERFACE_STATUS_CODE,''N'') "Invoice Interface",
     LIN.SHIP_TOLERANCE_ABOVE                 "Ship Tolerance Above",
     LIN.SHIP_TOLERANCE_BELOW                 "Ship Tolerance Below",            
     to_char(LIN.ACTUAL_SHIPMENT_DATE,''DD-MON-RR_HH24:MI:SS'')  "Actual Ship",
     to_char(LIN.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Create Date",
     to_char(LIN.LAST_UPDATE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Update Date"
from
     OE_ORDER_HEADERS_ALL                ORD,
     OE_ORDER_LINES_ALL                LIN,
     WSH_DELIVERY_DETAILS             DET
where
     ORD.HEADER_ID                  = ##$$HEADERID$$##
     AND LIN.HEADER_ID              = ##$$HEADERID$$##
     AND DET.SOURCE_LINE_ID         = LIN.LINE_ID
     AND DET.SOURCE_CODE            = ''OE''
     AND DET.OE_INTERFACED_FLAG = ''N''
     AND LIN.SHIPPABLE_FLAG = ''Y''
     AND nvl(LIN.SHIPPED_QUANTITY,0) > 0
     AND LIN.FLOW_STATUS_CODE = ''CLOSED''
     and   NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                          LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
     order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Line Closed, Shipped, not Interfaced to OM',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Sales Order Line is Closed; however, its'' shipped quantity has not yet been interfaced to Order Management.',
      p_solution               => '<ul>
<li>Delivery Details can still be interfaced even when the line is CLOSED.  Try to run Interface Trip Stop.</li>  
<li>If it does not interface the line, refer to [1275801.1] Delivery Details are Shipped and not Interfaced to OM but Order Line is Closed.</li>
</ul>',
      p_success_msg            => 'All Closed, Shipped lines have been interfaced to Order Management.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_CLOSED_SHIPPED_NOT_INTERFACED_OM');



debug('begin add_signature: SALES_ORDER_LINE_CLOSED_SHIPPED_NOT_INTERFACED_INI');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINE_CLOSED_SHIPPED_NOT_INTERFACED_INI',
      p_sig_sql                => 'select 
    substr(to_char(LIN.line_number) || 
          decode(LIN.shipment_number, null, null, ''.'' || to_char(LIN.shipment_number))|| 
          decode(LIN.option_number, null, null, ''.'' || to_char(LIN.option_number)) ||
          decode(LIN.component_number, null, null, 
                 decode(LIN.option_number, null, ''.'',null)||
                 ''.''||to_char(LIN.component_number))||
          decode(LIN.service_number,null,null,
                 decode(LIN.component_number, null, ''.'' , null) ||
                        decode(LIN.option_number, null, ''.'', null ) ||
                        ''.''|| to_char(LIN.service_number)),1,10)  "Line Number",
     LIN.LINE_ID                   "Line ID",
     LIN.INVENTORY_ITEM_ID         "Item ID",
     substr(LIN.FLOW_STATUS_CODE,1,22) "Workflow Status",
     nvl(LIN.ORDERED_QUANTITY,0)   "Ordered QTY",
     LIN.ORDER_QUANTITY_UOM        "Ordered UOM",
     nvl(LIN.SHIPPED_QUANTITY,0)   "Shipped QTY",
     nvl(LIN.SHIPPING_QUANTITY,0)  "Shipping QTY",
     nvl(FULFILLED_QUANTITY,0)     "Fulfilled QTY",                  
     nvl(LIN.CANCELLED_QUANTITY,0) "Cancelled QTY",          
     nvl(LIN.INVOICED_QUANTITY,0)  "Invoiced QTY", 
     nvl(LIN.OPEN_FLAG,''N'')        "Open",
     nvl(LIN.BOOKED_FLAG,''N'')      "Booked",
     nvl(LIN.SHIPPABLE_FLAG,''N'')   "Shipped",
     nvl(LIN.CANCELLED_FLAG,''N'')   "Cancelled",
     nvl(LIN.FULFILLED_FLAG, ''N'')  "Fullfilled",
     nvl(LIN.SHIPPING_INTERFACED_FLAG,''N'')    "Shipping Interface",
     LIN.SHIP_FROM_ORG_ID          "Ship From",
     nvl(LIN.INVOICE_INTERFACE_STATUS_CODE,''N'') "Invoice Interface",
     LIN.SHIP_TOLERANCE_ABOVE                 "Ship Tolerance Above",
     LIN.SHIP_TOLERANCE_BELOW                 "Ship Tolerance Below",            
     to_char(LIN.ACTUAL_SHIPMENT_DATE,''DD-MON-RR_HH24:MI:SS'')  "Actual Ship",
     to_char(LIN.CREATION_DATE,''DD-MON-RR_HH24:MI:SS'')  "Create Date",
     to_char(LIN.LAST_UPDATE_DATE,''DD-MON-RR_HH24:MI:SS'')  "Update Date"
from
     OE_ORDER_HEADERS_ALL                ORD,
     OE_ORDER_LINES_ALL                LIN,
     WSH_DELIVERY_DETAILS             DET
where
     ORD.HEADER_ID                  = ##$$HEADERID$$##
     AND LIN.HEADER_ID              = ##$$HEADERID$$##
     AND DET.SOURCE_LINE_ID         = LIN.LINE_ID
     AND DET.SOURCE_CODE            = ''OE''
     AND DET.INV_INTERFACED_FLAG = ''N''
     AND LIN.SHIPPABLE_FLAG = ''Y''
     AND nvl(LIN.SHIPPED_QUANTITY,0) > 0
     AND LIN.FLOW_STATUS_CODE = ''CLOSED''
     and   NVL(''##$$LINEID$$##'',0)     in (0,LIN.LINE_ID,
                                         LIN.TOP_MODEL_LINE_ID,
                                          LIN.ATO_LINE_ID,
                                         LIN.LINK_TO_LINE_ID,
                                         LIN.SERVICE_REFERENCE_LINE_ID)
     order by nvl(LIN.line_set_id, 0), LIN.line_number
 , nvl(LIN.shipment_number, -1)
 , nvl(LIN.option_number, -1)
 , nvl(LIN.service_number, -1)',
      p_title                  => 'Sales Order Line Closed, Shipped, not Interfaced to Inventory',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Sales Order Line is Closed, Shipped but not interfaced to Inventory.',
      p_solution               => '<ul>
<li>Delivery Details can still be interfaced even when the line is CLOSED.  Try to run Interface Trip Stop.  </li>
</ul>',
      p_success_msg            => 'All Closed, Shipped lines have been interfaced to Inventory.',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINE_CLOSED_SHIPPED_NOT_INTERFACED_INI');

  

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
PROCEDURE main(
            p_header_id                    IN NUMBER      DEFAULT NULL
           ,p_line_id                      IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 2000
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

 IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;

  IF g_is_concurrent THEN
     g_rep_info('Calling From'):='Concurrent Program';
  ELSE
     g_rep_info('Calling From'):='SQL Script';
  END IF;

  l_step := '10';
  initialize_files;
  
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'Sales Order';

  l_step := '20';

   validate_parameters(
     p_header_id                    => p_header_id
    ,p_line_id                      => p_line_id
    ,p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );



  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');

debug('begin section: Header');
start_section('Header');
   set_item_result(run_stored_sig('SALES_ORDER_HEADER_INFORMATION_DISPLAY'));
   set_item_result(run_stored_sig('SALES_ORDER_HEADER_WF_ACTIVITY'));
   set_item_result(run_stored_sig('SALES_ORDER_GENERIC_HOLD_DISPLAY'));
   set_item_result(run_stored_sig('SALES_ORDER_ORDER_TYPE'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_NOTIFICATIONS'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_ORDER_LEVEL_ERRORS'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_ACTIVITY_ORDER_ERROR'));
   set_item_result(run_stored_sig('SALES_ORDER_HEADER_PROCESSING_MSGS'));
   set_item_result(run_stored_sig('SALES_ORDER_SET'));
   set_item_result(run_stored_sig('SALES_ORDER_HEADER_OPEN_WITH_CLOSED_LINES'));
   set_item_result(run_stored_sig('SALES_ORDER_HEADER_CLOSED WITH_OPEN_LINES'));
end_section;
debug('end section: Header');

debug('begin section: Lines');
start_section('Lines');
   set_item_result(run_stored_sig('SALES_ORDER_LINES_DISPLAY'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_WF_ACTIVITY'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_HISTORY'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_WF_STATUS_ERRORS'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_WF_STATUS_ERROR_PROCESS'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_HOLDS'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_PROCESS_MESSAGES'));
   set_item_result(run_stored_sig('SALES_ORDER_BOOKED_SO_HDR_NONBOOKED_LINES'));
   set_item_result(run_stored_sig('SALES_ORDER_LINES_OPEN_AND_CANCELLED'));
   set_item_result(run_stored_sig('SALES_ORDER_LINES_NO_WORKFLOW'));
   set_item_result(run_stored_sig('SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_FULFILL_QTY'));
end_section;
debug('end section: Lines');

debug('begin section: Pricing');
start_section('Pricing');
   set_item_result(run_stored_sig('SALES_ORDER_HEADER_PRICE_ADJ'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_PRICE_ADJUSTMENTS'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_PRICE_ADJUSTMENTS_UNAPPLIED'));
end_section;
debug('end section: Pricing');

debug('begin section: Manufacturing');
start_section('Manufacturing');
   set_item_result(run_stored_sig('SALES_ORDER_MTL_SUPPLY'));
   set_item_result(run_stored_sig('SALES_ORDER_MTL_RESERVATIONS'));
   set_item_result(run_stored_sig('SALES_ORDER_WIP_JOB_SCHEDULE_INTERFACE'));
   set_item_result(run_stored_sig('SALES_ORDER_WIP_INTERFACE_ERRORS'));
   set_item_result(run_stored_sig('SALES_ORDER_WIP_DISCRETE_JOBS'));
   set_item_result(run_stored_sig('SALES_ORDER_DISCRETE JOB TRANSACTIONS'));
end_section;
debug('end section: Manufacturing');

debug('begin section: Purchasing');
start_section('Purchasing');
   set_item_result(run_stored_sig('SALES_ORDER_DROP_SHIP_SOURCES'));
   set_item_result(run_stored_sig('SALES_ORDER_PO_REQUISITIONS_INTERFACE_ALL'));
   set_item_result(run_stored_sig('SALES_ORDER_PO_INTERFACE_ERRORS_ALL'));
   set_item_result(run_stored_sig('SALES_ORDER_PO_REQUISITION_HEADERS_ALL'));
   set_item_result(run_stored_sig('SALES_ORDER_PO_REQUISITION_LINES_ALL'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_REQ_APPROVAL_STATUS'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_REQ_APPROVAL_NOTIFICATIONS'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_REQ_APPROVAL_ERRORS'));
   set_item_result(run_stored_sig('SALES_ORDER_PO_HEADERS_INTERFACE'));
   set_item_result(run_stored_sig('SALES_ORDER_PO_LINES_INTERFACE'));
   set_item_result(run_stored_sig('SALES_ORDER_PO_HEADERS'));
   set_item_result(run_stored_sig('SALES_ORDER_PO_LINES'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_PO_APPROVAL_STATUS'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_PO_APPROVAL_NOTIFICATIONS'));
   set_item_result(run_stored_sig('SALES_ORDER_WF_PO_APPROVAL_ERRORS'));
   set_item_result(run_stored_sig('SALES_ORDER_RCV_SHIPMENT_LINES'));
   set_item_result(run_stored_sig('SALES_ORDER_RCV_TRANSACTIONS'));
   set_item_result(run_stored_sig('SALES_ORDER_RCV_TRANSACTIONS_INTERFACE'));
end_section;
debug('end section: Purchasing');

debug('begin section: Shipping');
start_section('Shipping');
   set_item_result(run_stored_sig('SALES_ORDER_WSH_TRIPS'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_TRIP_STOPS'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_DELIVERY_LEGS'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_NEW_DELIVERIES'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_DELIVERY_ASSIGNMENTS'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_ORGANIZATIONS'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_DELIVERY_DETAILS'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_DELIVERY_DETAILS_CONTAINERS'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_SERIAL_NUMBERS'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_FREIGHT_COSTS'));
   set_item_result(run_stored_sig('SALES_ORDER_MTL_TRANSACTIONS_INTERFACE'));
   set_item_result(run_stored_sig('SALES_ORDER_MTL_MATERIAL_TRANSACTIONS_TEMP'));
   set_item_result(run_stored_sig('SALES_ORDER_MTL_MATERIAL_TRANSACTIONS'));
   set_item_result(run_stored_sig('SALES_ORDER_MTL_UNIT_TRANSACTIONS'));
   set_item_result(run_stored_sig('SALES_ORDER_MTL_TXN_REQUEST_LINES'));
   set_item_result(run_stored_sig('SALES_ORDER_WSH_ACCOUNTING_PERIODS'));
   set_item_result(run_stored_sig('SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_SHIPPED_QTY'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_SHIPPED_NOT_INTERFACED'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_CLOSED_SHIPPED_NOT_INTERFACED_OM'));
   set_item_result(run_stored_sig('SALES_ORDER_LINE_CLOSED_SHIPPED_NOT_INTERFACED_INI'));
end_section;
debug('end section: Shipping');

debug('begin section: Invoicing');
start_section('Invoicing');
   set_item_result(run_stored_sig('SALES_ORDER_RA_INTERFACE_LINES'));
   set_item_result(run_stored_sig('SALES_ORDER_RA_INTERFACE_ERRORS'));
   set_item_result(run_stored_sig('SALES_ORDER_RA_CUSTOMER_TRX'));
   set_item_result(run_stored_sig('SALES_ORDER_RA_CUSTOMER_TRX_LINES'));
   set_item_result(run_stored_sig('SALES_ORDER_LINES_NO_INVOICE'));
   set_item_result(run_stored_sig('SALES_ORDER_LINES_ORD_QTY_NOT_EQUAL_INVOICE_QTY'));
end_section;
debug('end section: Invoicing');



  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  print_out('<a href="https://community.oracle.com/message/13621828" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;


PROCEDURE main_cp(
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
           ,p_header_id                    IN NUMBER      DEFAULT NULL
           ,p_line_id                      IN NUMBER      DEFAULT NULL
           ,p_max_output_rows              IN NUMBER      DEFAULT 2000
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y'
)
 IS

BEGIN
  g_retcode := 0;
  g_errbuf := null;
  

   main(
     p_header_id                    => p_header_id
    ,p_line_id                      => p_line_id
    ,p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );


  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


END om_order_analyzer_pkg;
/
show errors
exit;
-- Exit required for bundling project so do not remove