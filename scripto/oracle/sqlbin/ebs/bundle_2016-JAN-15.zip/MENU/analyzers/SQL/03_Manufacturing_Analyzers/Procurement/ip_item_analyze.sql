REM $Id: ip_item_analyze.sql, 200.1 2015/15/01 23:27:42 jxmccall Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.13                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ip_item_analyze.sql                                                  |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the ip_item_analyzer_pkg.main procedure        |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2 
REM 
REM MENU_TITLE: IP Item Analyzer
REM
REM MENU_START
REM
REM SQL: Run IP Item Analyzer
REM FNDLOAD: Load IP Item Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM 
REM 
REM HELP_START  
REM 
REM  IP Item Analyzer Diagnostic Script Help [Doc ID: 1586248.1] 
REM
REM  Compatible: 11i|12.0|12.1|12.2  
REM
REM  Explanation of available options:
REM
REM    (1) Run the IP Item Analyzer Diagnostic Script
REM        o Runs ip_item_analyzer.sql as APPS and creates an HTML report file 
REM           on the database server (typically under /usr/tmp) 
REM
REM    (2) Install IP Item Analyzer Diagnostic Script as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "Purchasing Reports" 
REM
REM 
REM HELP_END 
REM
REM FNDLOAD_START
REM
REM PROD_TOP: PO_TOP
REM PROG_NAME: IPDIAGIA
REM APP_NAME: Purchasing
REM DEF_REQ_GROUP: Purchasing Reports
REM PROG_TEMPLATE: ipiaz.ldt
REM PROD_SHORT_NAME: PO 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ip_item_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END


SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
PROMPT Submitting Ip Item Analyzer.
PROMPT ===========================================================================
PROMPT Enter the org_id for the operating unit.  This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT ou NUMBER DEFAULT -1 -
       PROMPT 'Enter the org_id(required): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the login name of the user having the issue. 
PROMPT This will only be used to validate profile option values.
PROMPT This parameter is required. 
PROMPT ===========================================================================
PROMPT
ACCEPT user_name CHAR -
       PROMPT 'Enter Login name(required): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the responsibility id of the responsibility being used. 
PROMPT This will only be used to validate profile option values.
PROMPT This parameter is required. 
PROMPT ===========================================================================
PROMPT
ACCEPT responsibility_id CHAR -
       PROMPT 'Enter responsibility id(required): '
PROMPT
PROMPT ===========================================================================
PROMPT If you wish to analyze a specific item enter the item number.
PROMPT If left blank, only general validations will be performed
PROMPT ===========================================================================
PROMPT
ACCEPT item_num CHAR PROMPT 'Enter the item number: '
PROMPT
PROMPT ===========================================================================
PROMPT If you wish to analyze a specific transaction enter the PO number.
PROMPT If left blank, only general validations will be performed
PROMPT Only Blanket Orders will be considered.
PROMPT ===========================================================================
PROMPT
ACCEPT trx_num CHAR PROMPT 'Enter the document number: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the line number if a Blanket PO was entered above otherwise
PROMPT leave blank.
PROMPT ===========================================================================
PROMPT
ACCEPT rel_num NUMBER DEFAULT -1 -
       PROMPT 'Enter the Purchase Order Line number: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the maximum number of rows to display on row limited queries
PROMPT ===========================================================================
PROMPT
ACCEPT max_rows NUMBER DEFAULT 50 -
       PROMPT 'Enter the maximum rows to display [50]: '
PROMPT
PROMPT

DECLARE
  l_org_id            NUMBER := &ou;
  l_user_name         VARCHAR2(30) := upper('&user_name');
  l_responsibility_id NUMBER := &responsibility_id;
  l_item_num          VARCHAR2(20) := '&item_num';
  l_trx_num           VARCHAR2(20) := '&trx_num';
  l_line_num          NUMBER := &rel_num;  
  l_max_rows          NUMBER := &max_rows;  
  l_debug_mode        VARCHAR2(1) := 'Y';

BEGIN

  IF l_org_id < 0 THEN
    l_org_id := null;
  END IF;

  IF l_user_name is null THEN
    l_user_name := null;
  END IF;

  IF l_responsibility_id < 0 THEN
    l_responsibility_id := null;
  END IF;
  
  IF l_item_num is null  THEN
    l_item_num := null;
  END IF;

  IF l_trx_num is NULL THEN
    l_trx_num  := null;
	l_line_num := null;
  END IF; 
 
  IF l_line_num < 0 THEN
     l_line_num := null;
  END IF;
  
  IF l_max_rows < 0 THEN
    l_max_rows := 50;
  END IF;



  ip_item_analyzer_pkg.main(
      p_org_id => l_org_id,
      p_user_name => l_user_name,
      p_responsibility_id => l_responsibility_id,	  
      p_item_num => l_item_num,
      p_trx_num => l_trx_num,
      p_line_num => l_line_num,
      p_max_output_rows => l_max_rows,
      p_debug_mode => 'Y');

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
