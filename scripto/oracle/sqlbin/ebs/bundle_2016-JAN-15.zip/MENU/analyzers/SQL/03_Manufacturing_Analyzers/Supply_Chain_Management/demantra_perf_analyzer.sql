SET DEFINE '~'

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.24                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    demantra_perf_analyzer.sql                                           |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM |   28-Oct-2015 Converted to the Analyzer Framework 3.0.29                |
REM +=========================================================================+

-- PSD #1
CREATE OR REPLACE PACKAGE demantra_perf_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-- PSD #10
PROCEDURE main;

-- PSD #16	  
PROCEDURE main_cp (
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
);

-- PSD #1
END demantra_perf_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY demantra_perf_pkg AS
-- PSD #1a
-- $Id: demantra_perf_analyzer.sql, 200.2 2015/15/01 arobert Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
-- Changed g_max_output_rows from 10 to 50 as Wrapper is not passing any parameters 
g_max_output_rows  NUMBER := 50;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #15  
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1618885.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;
l_completion_status  BOOLEAN;



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host             VARCHAR2(40);
  l_my_schema        VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

-- Demantra Specific --

    SELECT fnd_profile.value('MSD_DEM_SCHEMA') 
    INTO l_my_schema 
    FROM dual;

-- Demantra Specific --

	-- PSD #2
    l_log_file := 'DEMANTRA_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'DEMANTRA_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Output Files are located on Host : '||l_host);
    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Demantra Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1554183.1:DEMANTRA_AZ">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/demantra_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
         -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;
         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
-- PSD #4
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel       VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
  SELECT Max(Last_Update_Date) as date_applied
  FROM Ad_Bugs Adb 
  WHERE Adb.Bug_Number like p_ptch
  AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #4a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '20';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := 'N/A';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.0 Oracle Financials Critical & Recommended Patches';
    l_col_rows(5)(1) := '[557869.1]';
 -- If want to go based on more e-Business Application version, just add for example:
 -- ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
  ELSE
    l_step := '30';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '17167654';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.1: Payments Recommended Patch Collection (IBY RPC), Sep 2013';
    l_col_rows(5)(1) := '[1481221.1]';

    l_col_rows(1)(2) := '17176017';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'R12.1: Payables Recommended Patch (Core AP) Collection (AP RPC), Sep 2013';
    l_col_rows(5)(2) := '[1397581.1]';

    l_col_rows(1)(3) := '17176034';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'R12.1: Payables Recommended Patch Collection (ISP) (AP RPC), Sep 2013';
    l_col_rows(5)(3) := '[1397581.1]';

    l_col_rows(1)(4) := '17176060';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'R12.1: Payables Recommended Patch Collection (WF/PCARD) (AP RPC), Sep 2013';
    l_col_rows(5)(4) := '[1397581.1]';

    l_col_rows(1)(5) := '16060007';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'R12.1: Subledger Accounting Recommended Patch Collection (SLA RPC), March 2013';
    l_col_rows(5)(5) := '[1481222.1]';

    l_col_rows(1)(6) := '17202262';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.1: EBusiness Tax Recommended Patch Collection (ZX RPC), Sep 2013';
    l_col_rows(5)(6) := '[1481235.1]';

    l_col_rows(1)(7) := '18234875';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'R12.1: EBusiness Tax Calculation Cumulative Patch';
    l_col_rows(5)(7) := '[1481235.1]';

    l_col_rows(1)(8) := '16234039';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'Oracle Payments PPR Termination Enhancement Patch';
    l_col_rows(5)(8) := '[1543611.1]';

    l_col_rows(1)(9) := '16804401';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Oracle Payments Enhanced Error Message Patch';
    l_col_rows(5)(9) := '';
  -- PSD #4a-end


  END IF;
  -- Check if applied
IF l_col_rows.exists(1) THEN
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i),l_rel);
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;
  END IF;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters IS

  l_from_date    VARCHAR2(25);
  l_to_date     VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;
  l_my_schema    VARCHAR2(40);

  invalid_parameters EXCEPTION;
  
   
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;
    
    -- Demantra Specific --

    SELECT fnd_profile.value('MSD_DEM_SCHEMA') 
    INTO l_my_schema 
    FROM dual;

-- Demantra Specific --

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.2 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2014/05/01 22:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_rep_info('Schema Name') := l_my_schema;
-- PSD #7
  g_rep_info('File Name') := 'demantra_perf_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
-- PSD #7b
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1618885.1" target="_blank">(Note 1618885.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
 
  -- PSD #8a
  -- Create global hash of SQL token values
  
  -- Demantra Specific --
  g_sql_tokens('##$$MYSCHEMA$$##') := l_my_schema;    
  -- Demantra Specific --
  
EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
-- jjg changed from HASH_TBL_4K to HASH_TBL_8K
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_8K;
  l_dynamic_SQL VARCHAR2(32000);
  l_counter NUMBER;
  

BEGIN
-- PSD #9

  
  -------------------------------------------------------------------
  -- EBS Item Import Errors
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'EBS_ITEM_IMPORT_ERRORS',
   'SELECT count(*) "No_of_Item_Import_Records"
    FROM ##$$MYSCHEMA$$##.T_SRC_ITEM_TMPL_ERR',
   'EBS Item Import Errors',
   '[No_of_Item_Import_Records] > [0]',
   'There Is an issue - Error message goes here',
   '<ul>
      Please see [809410.1], ''Demantra Data Load / Import Diagnostics Investigation - EBS and Legacy''
   </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');

  -------------------------------------------------------------------
  -- EBS Location Import Errors
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'EBS_LOCATION_IMPORT_ERRORS',
   'SELECT count(*) "No_of_Location_Import_Records"
   FROM ##$$MYSCHEMA$$##.t_src_loc_tmpl_err',
   'EBS Location Import Errors',
   '[No_of_Location_Import_Records] > [0]',
   'There Is an issue - Error message goes here',
   '<ul>
      Please see [809410.1], ''Demantra Data Load / Import Diagnostics Investigation - EBS and Legacy''
   </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');


  -------------------------------------------------------------------
  -- EBS Sales Import Errors
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'EBS_SALES_IMPORT_ERRORS',
   'SELECT count(*) "Nbr_Sales_Import_Records"
   FROM ##$$MYSCHEMA$$##.t_src_sales_tmpl_err',
   'EBS Sales Data Import Errors',
   '[Nbr_Sales_Import_Records] > [0]',
   'There Is an issue - Error message goes here',
   '<ul>
      Please see [809410.1], ''Demantra Data Load / Import Diagnostics Investigation - EBS and Legacy''
   </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');


  -------------------------------------------------------------------
  -- Legacy Item Import Errors
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'LEGACY_ITEM_IMPORT_ERRORS',
   'SELECT count(*) "Nbr_Legacy_Item_Imp_Records"
    FROM ##$$MYSCHEMA$$##.T_SRC_ITEM_ERR',
   'LEGACY Item Import Errors',
   '[Nbr_Legacy_Item_Imp_Records] > [0]',
   'There Is an issue - Error message goes here',
   '<ul>
      Please see [809410.1], ''Demantra Data Load / Import Diagnostics Investigation - EBS and Legacy''
   </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');



  -------------------------------------------------------------------
  -- LEGACY Location Import Errors
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'LEGACY_LOCATION_IMPORT_ERRORS',
   'SELECT count(*) "Nbr_Legacy_Loc_Imp_Records"
   FROM ##$$MYSCHEMA$$##.t_src_loc_err',
   'LEGACY Location Import Errors',
   '[Nbr_Legacy_Loc_Imp_Records] > [0]',
   'There Is an issue - Error message goes here',
   '<ul>
      Please see [809410.1], ''Demantra Data Load / Import Diagnostics Investigation - EBS and Legacy''
   </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');


  -------------------------------------------------------------------
  -- LEGACY Sales Import Errors   -   JJG where is t_src_sales_err
  --------------------------------------------------------------------
  -- PSD #9a

  -------------------------------------------------------------------
  -- EBS Location Import Errors
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'EBS_LOCATION_IMPORT_ERRORS',
   'SELECT count(*) "Nbr_Location_Import_Records"
   FROM ##$$MYSCHEMA$$##.t_src_loc_tmpl_err',
   'EBS Location Import Errors',
   '[Nbr_Location_Import_Records] > [0]',
   'There Is an issue - Error message goes here',
   '<ul>
      Please see [809410.1], ''Demantra Data Load / Import Diagnostics Investigation - EBS and Legacy''
   </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');


  -------------------------------------------------------------------  
  -- BIIO_CTO_LEVEL_ERR  
  ------------------------------------------------------------------
  -- PSD #9a
  add_signature(
  'BIIO_CTO_LEVEL_ERR',
  'SELECT count(*) "NBR_CTO_Level_Import_Recs"
   FROM ##$$MYSCHEMA$$##.BIIO_CTO_LEVEL_ERR',
  'Demantra CTO Level Import Errors',
  '[NBR_CTO_Level_Import_Recs] > [0]',
  'There Is an issue - Error message goes here',
  '<ul>
      Please see [1347289.1], ''Demantra CTO Import Procedure/Debugging Collection Table(s) Reset''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');


  -------------------------------------------------------------------
  -- BIIO_CTO_POPULATION_ERR
  ------------------------------------------------------------------
  -- PSD #9a
  add_signature(
  'BIIO_CTO_POPULATION_ERR',
  'SELECT count(*) "NBR_CTO_Population_Import_Recs"
   FROM ##$$MYSCHEMA$$##.BIIO_CTO_POPULATION_ERR',
  'Demantra CTO Population Import Errors',
  '[NBR_CTO_Population_Import_Recs] > [0]',
  'There Is an issue - Error message goes here',
  '<ul>
      Please see [1347289.1] ''Demantra CTO Import Procedure/Debugging Collection Table(s) Reset''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');


  -------------------------------------------------------------------
  --  BIIO_CTO_DATA_ERR
  ------------------------------------------------------------------
  -- PSD #9a
  add_signature(
  'BIIO_CTO_DATA_ERR',
  'SELECT count(*) "NBR_CTO_Data_Recs"
   FROM ##$$MYSCHEMA$$##.BIIO_CTO_DATA_ERR',
  'Demantra CTO Population Import Errors',
  '[NBR_CTO_Data_Recs] > [0]',
  'There Is an issue - Error message goes here',
  '<ul>
      Please see [1347289.1] ''Demantra CTO Import Procedure/Debugging Collection Table(s) Reset''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');


  -------------------------------------------------------------------
  -- DEAD_COMBINATIONS
  --------------------------------------------------------------------
  -- PSD #9a
   add_signature(
   'DEAD_COMBINATIONS',
   'SELECT round(decode((select count(*) from ##$$MYSCHEMA$$##.mdp_matrix where nvl(prediction_status,''0'') = ''99''),0,1,(((select count(*) 
    from ##$$MYSCHEMA$$##.mdp_matrix where nvl(prediction_status,''0'') = ''99'') / 
    (select count(*) from ##$$MYSCHEMA$$##.mdp_matrix)) * 100))) "Percent Dead"
    from dual',
   'Dead Combinations',
   '[Percent Dead] > [20]',
   'There are at least 20 percent dead combinations.',
   '<ul>
        Please see the white paper describing this issue provided in [1921705.1]:<br>
          ''Baseline Forecast - Analyze and Verify Forecast Tree, Forecast Results Plus a Very Nice Engine Startup Issues and Errors''<br>
          Verify Proport configuration and the last_date_backup setting of the system compared to max_sales_date where quantity form > 0.
    </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');


  -------------------------------------------------------------------
  -- PERFORMANCE_PARAMETERS
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'PERFORMANCE_PARAMETERS',
   'SELECT ''Y'' "Modified?",
   pname "Parameter",
   decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "Value Number"
   from ##$$MYSCHEMA$$##.aps_params
   where lower(pname) in (''blethreadpoolsize'', ''maxdbconnections'', ''threadpool.query_run.per_user'', ''threadpool.query_run.size'',
                          ''threadpool.update.comb.manual.size'', ''threadpool.update.data.batch.size'', ''threadpool.update.data.manual.size'',
                           ''threadpool.update.record.manual.size'', ''threadpool.update.table.batch.size'', ''threadpool.update.table.manual.size'',
                           ''tunnel.server.threadpool.maxthreads'', ''maxupdatethreads'')
   and 
   ((lower(pname) = ''blethreadpoolsize'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 4)
   or
   (lower(pname) = ''maxdbconnections'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 100)
   or
   (lower(pname) = ''threadpool.query_run.per_user'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 4)
   or
   (lower(pname) = ''threadpool.query_run.per_user'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 4)
   or
   (lower(pname) = ''threadpool.query_run.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 40)
   or
   (lower(pname) = ''threadpool.update.comb.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
   or
   (lower(pname) = ''threadpool.update.data.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
   or
   (lower(pname) = ''threadpool.update.data.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 8)
   or
   (lower(pname) = ''threadpool.update.record.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
   or
   (lower(pname) = ''threadpool.update.table.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
   or
   (lower(pname) = ''threadpool.update.table.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
   or
   (lower(pname) = ''tunnel.server.threadpool.maxthreads'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 100)
   or
   (lower(pname) = ''maxupdatethreads'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 5))',
   'Performance Parameters',
  '[Modified?] != [1]',
   'The parameters that affect worksheet behavior and performance are not set to default values.',
   '<ul>
         If you are experiencing issues that cannot be explained, there are times when retreating to the defaults and testing may help.<br>
         See [1201774.1] ''Oracle Demantra Parameters for Performance.''<br>
         The default parameter settings are: <br>
         BLEThreadPoolSize	(4)<br>
         MaxDBConnections	(100)<br>
         threadpool.query_run.per_user	(4)<br>
         threadpool.query_run.size	(40)<br>
         threadpool.update.comb.manual.size	(2)<br>
         threadpool.update.data.batch.size	(2)<br>
         threadpool.update.data.manual.size	(8)<br>
         threadpool.update.record.manual.size	(2)<br>
         threadpool.update.table.batch.size	(2)<br>
         threadpool.update.table.manual.size	(2)<br>
         tunnel.server.threadpool.maxthreads (100)<br>
    </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');


   
  ---------------------------------------------------------------------
  --  APPLICATION_SERVER_PARAMETERS
  ---------------------------------------------------------------------
  -- PSD #9a
  add_signature(
  'APPLICATION_SERVER_PARAMETERS',
  'SELECT ''Y'' "Modified?",
   pname "Parameter",
   decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "Value Number"
   from ##$$MYSCHEMA$$##.aps_params
   where lower(pname) in (''maxdbconnections'', ''DBIdleTimeOut'', ''threadpool.update.data.batch.size'', ''threadpool.update.table.manual.size'',
   ''threadpool.update.comb.manual.size'', ''threadpool.update.comb.batch.size'', ''threadpool.update.record.manual.size'',
   ''threadpool.update.record.batch.size'', ''threadpool.update.data.manual.size'', ''threadpool.update.table.batch.size'',
   ''threadpool.query_run.size'', ''threadpool.level_method.size'', ''threadpool.copy_paste.size'', ''threadpool.level_method.timeout'')
   and 
   ((lower(pname) = ''maxdbconnections'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != ''100'')
    or
    (lower(pname) = ''DBIdleTimeOut'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
    or
    (lower(pname) = ''threadpool.update.data.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
    or
    (lower(pname) = ''threadpool.update.table.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
    or
    (lower(pname) = ''threadpool.update.comb.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
    or
    (lower(pname) = ''threadpool.update.comb.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
    or
    (lower(pname) = ''threadpool.update.record.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
    or
    (lower(pname) = ''threadpool.update.record.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
    or
    (lower(pname) = ''threadpool.update.data.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 8)
    or
    (lower(pname) = ''threadpool.update.table.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
    or
    (lower(pname) = ''threadpool.level_method.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 25)
    or
    (lower(pname) = ''threadpool.query_run.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 40)
    or
    (lower(pname) = ''threadpool.copy_paste.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 40)
    or
    (lower(pname) = ''threadpool.level_method.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000))',
  'Application Server Parameters',
  '[Modified?] != [1]',
  'The parameters that affect the application server and thus Demantra overall performance are not set to default values.',
  '<ul>
      Configuring the Oracle Demantra Web Platform Server.  You may need to adjust the Web Platform Server parameters settings, shown below. 
          These are the defaults and recommendations for the application server.  They can be changed using the business modeler.<br>
      Increasing the comb.comb.batch.size should have biggest performance impact.  If there are more combinations than dates in the staging table use 
          higher number for comb.batch.size, otherwise use a higher number for record.batch.size.</br>
          Watch carefully for database IO and CPU bottle necks. <br>
      <br>
      Number of threads generated should be: comb.comb.batch.size * record.batch.size<br>
      If there is no CPU overload or IO overload increase the comb.comb.batch.size or record.batch.size by 1 until you see good database throughput.<br>
          Assuming the database is tuned, if one of these are over loaded you probably have reached the capacity of the database.<br><br>
      For more information see [470852.1], ''Oracle Demantra Worksheet Performance - A White Paper''<br><br>
      <br>Parameter description and instructions:<br>
      maxdbconnections = 100: Number of concurrent users multiplied by 2<br>
      DBIdleTimeOut = 300000 (5 minutes): This setting frees up unused database connections sooner, because they overstress the database.<br>
      threadpool.update.data.batch.size = 2: Update threadpool data batch size.<br>
      threadpool.update.table.manual.size = 2: Number of parallel manual update tables that the Applications server can handle per process.<br>
      threadpool.update.comb.manual.size = 2: Number of parallel manual update combinations that the Applications server can handle per table.<br>
      threadpool.update.comb.batch.size = 2: Number of parallel batch (Integration/Ble) update combinations that the Applications server can handle per table.<br>
      threadpool.update.record.manual.size = 2: Number of parallel manual update records that the Applications server can handle per combination.<br>
      threadpool.update.record.batch.size = 2: Number of parallel batch (Integration/Ble) update records that the Applications server can handle per combination.<br>
      threadpool.update.data.manual.size = 8: Update threadpool data manual size.<br>
      threadpool.update.table.batch.size = 2: Number of parallel batch (Integration/Ble) update tables that the Applications server can handle per process.<br>
      threadpool.query_run.size = 40: Use a size that is less than MaxDBConnections and that also leaves space for other system processes.<br>
      threadpool.level_method.size = 25: Use a size that is less than MaxDBConnections and that also leaves space for other system processes.<br>
      threadpool.copy_paste.size = 40: Use a size that is less than MaxDBConnections and that also leaves space for other system processes.<br>
      threadpool.level_method.timeout = 300000 (5 minutes): This setting frees up unused threads.</li>
  </ul>',
 'No issue found. This means Success <br><br>
  Verified the following parameters:<br>
  Increasing the comb.comb.batch.size should have biggest performance impact.  If there are more combinations than dates in the staging table use 
          higher number for comb.batch.size, otherwise use higher number for record.batch.size.</br>
          Watch carefully for database IO and CPU bottle necks. <br>
      <br>
      Number of threads generated should be: comb.comb.batch.size * record.batch.size<br>
      If there is no CPU overload or IO overload bump up by 1 comb.comb.batch.size or record.batch.size until you see good database throughput.<br>
          Assuming the database is tuned, if one of these are over loaded you probably have reached the capacity of the database.<br><br>
      For more information see [470852.1], ''Oracle Demantra Worksheet Performance - A White Paper''<br><br>
      maxdbconnections = 100: Number of concurrent users multiplied by 2<br>
      DBIdleTimeOut = 300000 (5 minutes): This setting frees up unused database connections sooner, because they overstress the database.<br>
      threadpool.update.data.batch.size = 2: Update threadpool data batch size.<br>
      threadpool.update.table.manual.size = 2: Number of parallel manual update tables that the Applications server can handle per process.<br>
      threadpool.update.comb.manual.size = 2: Number of parallel manual update combinations that the Applications server can handle per table.<br>
      threadpool.update.comb.batch.size = 2 Number of parallel batch (Integration/Ble) update combinations that the Applications server can handle per table.<br>
      threadpool.update.record.manual.size = 2: Number of parallel manual update records that the Applications server can handle per combination.<br>
      threadpool.update.record.batch.size = 2: Number of parallel batch (Integration/Ble) update records that the Applications server can handle per combination.<br>
      threadpool.update.data.manual.size = 8: Update threadpool data manual size.<br>
      threadpool.update.table.batch.size = 2: Number of parallel batch (Integration/Ble) update tables that the Applications server can handle per process.<br>
      threadpool.query_run.size = 40: Use a size that is less than MaxDBConnections and that also leaves space for other system processes.<br>
      threadpool.level_method.size = 25: Use a size that is less than MaxDBConnections and that also leaves space for other system processes.<br>
      threadpool.copy_paste.size = 40: Use a size that is less than MaxDBConnections and that also leaves space for other system processes.<br>
      threadpool.level_method.timeout = 300000 (5 minutes): This setting frees up unused threads.<br>',
 'ALWAYS',
 'E');

-------------------------------------------------------------------
-- TIME_CONTROL_APS_PARAMS
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'TIME_CONTROL_APS_PARAMS',
  'SELECT ''Y'' "Modified?",
   pname "Parameter",
   decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "Value Number"
   from ##$$MYSCHEMA$$##.aps_params
   where lower(pname) in (''mindbconnections'', ''dbidletimeout'', ''dbconnectiontimeout'', ''UpdateThreadTimeout'', ''BLEThreadTimeout'',
                          ''threadpool.update.timeout'', ''threadpool.query_run.timeout'', ''UpdateQueueTimeout'', ''threadpool.copy_paste.timeout'',
                          ''threadpool.default.timeout'', ''threadpool.event_manager.timeout'', ''threadpool.external_process_reader.timeout'',
                          ''threadpool.level_method.timeout'', ''threadpool.paste_process.timeout'', ''threadpool.populationRefresher.timeout'',
                          ''QueryMechanisimTimeOut'', ''Server.SessionExpiration'', ''tunnel.server.threadpool.threadTimeout'', ''Server.SessionExpiration'')
   and 
   ((lower(pname) = ''mindbconnections'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 4)
     or
    (lower(pname) = ''dbidletimeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 1800000)
     or
    (lower(pname) = ''dbconnectiontimeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''UpdateThreadTimeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 5000)
     or
    (lower(pname) = ''BLEThreadTimeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 5000)
     or
    (lower(pname) = ''threadpool.update.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''threadpool.query_run.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''threadpool.copy_paste.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
    or
    (lower(pname) = ''threadpool.default.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''UpdateQueueTimeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 5000)
     or
    (lower(pname) = ''threadpool.event_manager.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''threadpool.external_process_reader.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''threadpool.level_method.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''threadpool.paste_process.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''threadpool.populationRefresher.timeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
    (lower(pname) = ''QueryMechanisimTimeOut'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 0)
     or
    (lower(pname) = ''Server.SessionExpiration'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 1200)
     or
    (lower(pname) = ''tunnel.server.threadpool.threadTimeout'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000))',
  'Time Control Parameters in APS_PARAMS',
  '[Modified?] != [1]',
  'The parameters that affect timeouts are not set to default values.',
  '<ul>
      Please review these settings to verify desired changes.<br><br>
      <br>Parameter description and instructions:<br>
      mindbconnections = 0: The minimum number of database connections for the previously mentioned database user.<br>
      DBIdleTimeOut = 300000 (5 minutes): This setting frees up unused database connections sooner, because they overstress the database.<br>
      dbconnectiontimeout = 5000: The database connection timeout period, in milliseconds.<br>
      UpdateQueueTimeout = 5000: The timeout period for the manual update listener, in milliseconds.<br>
      UpdateThreadTimeout = 2: Number of parallel manual update tables that the Applications server can handle per process.<br>
      BLEThreadTimeout = 5000: Timeout after which an idle BLE thread is killed.<br>
      threadpool.copy_paste.timeout = 300000: Idle time- defines the amount of time a thread can be idle before it is terminated.<br>
      threadpool.default.timeout = 30000: Default thread pool timeout.<br>
      threadpool.event_manager.timeout = 300000: Defined the Event Manager threads idle timeout, i.e., the amount of time, in milliseconds, that a thread can be idle before it is terminated.<br>
      threadpool.external_process_reader.timeout = 300000: Defines the External Process Reader threads idle timeout, i.e., the amount of time, in milliseconds, that a thread can be idle before it is terminated.<br>
      threadpool.level_method.timeout = 300000: the idle timeout for each thread (time to live when the thread is not active).<br>
      threadpool.paste_process.timeout = 300000: Idle time- defines the amount of time a thread can be idle before it is terminated.<br>
      threadpool.populationRefresher.timeout = 300000: Idle time- defines the amount of time a thread can be idle before it is terminated. If the population refresher thread pool size is negative this value is meaningless.<br>
      threadpool.query_run.timeout = 300000: Idle time- defines the amount of time a thread can be idle before it is terminated. If the query run thread pool size is negative this value is meaningless.<br>
      threadpool.update.timeout = 60000: Parallel values update thread pool timeout.<br>
      QueryMechanisimTimeOut = null: The timeout period for the query notification listener, in milliseconds.<br>
      Server.SessionExpiration = 1200: Session expiration time, in seconds.<br>
      tunnel.server.threadpool.threadTimeout = 300000: When number of running threads reaches minThreads at runtime, each thread allocated beyond that value will be killed, if it is unused longer than threadTimeout milliseconds.<br>
mail.strings.timeout.group = : Message sent when a task is timed out in a group step. (This parameter also supports non-ASCII characters.)
mail.strings.timeout.user = : Message sent when a task is timed out in a user step. (This parameter also supports non-ASCII characters.)
  </ul>',
 'No issue found. This means Success.  We verified the following parameters:<br><br>
      <br>Parameter description and instructions:<br>
      mindbconnections = 0: The minimum number of database connections for the previously mentioned database user.<br>
      DBIdleTimeOut = 300000 (5 minutes): This setting frees up unused database connections sooner, because they overstress the database.<br>
      dbconnectiontimeout = 5000: The database connection timeout period, in milliseconds.<br>
      UpdateQueueTimeout = 5000: The timeout period for the manual update listener, in milliseconds.<br>
      UpdateThreadTimeout = 2: Number of parallel manual update tables that the Applications server can handle per process.<br>
      BLEThreadTimeout = 5000: Timeout after which an idle BLE thread is killed.<br>
      threadpool.copy_paste.timeout = 300000: Idle time- defines the amount of time a thread can be idle before it is terminated.<br>
      threadpool.default.timeout = 30000: Default thread pool timeout.<br>
      threadpool.event_manager.timeout = 300000: Defined the Event Manager threads idle timeout, i.e., the amount of time, in milliseconds, that a thread can be idle before it is terminated.<br>
      threadpool.external_process_reader.timeout = 300000: Defines the External Process Reader threads idle timeout, i.e., the amount of time, in milliseconds, that a thread can be idle before it is terminated.<br>
      threadpool.level_method.timeout = 300000: the idle timeout for each thread (time to live when the thread is not active).<br>
      threadpool.paste_process.timeout = 300000: Idle time- defines the amount of time a thread can be idle before it is terminated.<br>
      threadpool.populationRefresher.timeout = 300000: Idle time- defines the amount of time a thread can be idle before it is terminated. If the population refresher thread pool size is negative this value is meaningless.<br>
      threadpool.query_run.timeout = 300000: Idle time- defines the amount of time a thread can be idle before it is terminated. If the query run thread pool size is negative this value is meaningless.<br>
      threadpool.update.timeout = 60000: Parallel values update thread pool timeout.<br>
      QueryMechanisimTimeOut = null: The timeout period for the query notification listener, in milliseconds.<br>
      Server.SessionExpiration = 1200: Session expiration time, in seconds.<br>
      tunnel.server.threadpool.threadTimeout = 300000: When number of running threads reaches minThreads at runtime, each thread allocated beyond that value will be killed, if it is unused longer than threadTimeout milliseconds.',
 'ALWAYS',
 'W');


-------------------------------------------------------------------
-- EMAIL_SETUP_CHECK
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'EMAIL_SETUP_CHECK',
  'SELECT pname "Parameter",
   nvl(value_string,''(null)'') "Value String",
   nvl(default_string,''(null)'') "Default String"
   from ##$$MYSCHEMA$$##.aps_params
   where lower(pname) in (''auditmailaddress'', ''mail'', ''mail.server'', ''mail.strings.processterminated'',
                          ''mail.strings.recovery'', ''mail.strings.taskfailuresubject'', ''mail.strings.taskstimedoutsubject'',
                          ''mail.strings.timeout.group'', ''mail.strings.timeout.user'', ''mailAddress'', ''mailProtocol'')',
  'Email Parameters',
  'RS',
  'This verifies your settings of aps_param parameters related to email.',
  'EMAIL Setup Verification of the following parameters.  Click Email Parameters above to review the current values.:
    <ol><li>auditmailaddress</li>
        <li>mail</li>
        <li>mail.server</li>
        <li>mail.strings.processterminated</li>
        <li>mail.strings.recovery</li>
        <li>mail.strings.taskfailuresubject</li>
        <li>mail.strings.taskstimedoutsubject</li>
        <li>mail.strings.timeout.group</li>
        <li>mail.strings.timeout.user</li>
        <li>mailAddress</li>
        <li>mailProtocol</li>
    <ol>
   Important - See [1068368.1], ''DEMANTRA 7.3 MAIL SERVER SETUP - mail-username and mail-password parameters were deprecated''',
  null,
  'ALWAYS',
  'I',
  'RS');


-------------------------------------------------------------------
-- CLUSTER_FACTOR_SALES_DATA
-------------------------------------------------------------------
--
-- PSD #9a

  add_signature(
  'CLUSTER_FACTOR_SALES_DATA',
  'SELECT ui.index_name "Index Name",
   trunc((ut.num_rows/ui.clustering_factor)/(ut.num_rows/ut.blocks),2) "Cluster Factor"
   FROM user_indexes ui, dba_tables ut, user_constraints uc
   WHERE ui.table_owner = ''##$$MYSCHEMA$$##''
   AND ui.table_name=ut.table_name
   AND ut.table_name=uc.table_name
   AND ui.index_name=uc.index_name
   AND UC.CONSTRAINT_TYPE=''P''
   AND ut.table_name=upper(''SALES_DATA'')',
   'Cluster Factor Percent',
   'RS',
   'Cluster Factor represents the percent of index rows that are ordered, given a stated primary key (PK), compared to the 
    related table given the same primary key.  This value is then  compared to the number blocks.  This SQL delivers the percent<br> 
    of rows closer to the number of blocks.  For example, if the SALES_DATA factor is 75%, this means that 75% of the SALES_DATA
    rows are ordered according to the PK.  Lower percent values indicate a need to reorder the table in PK order.',
   '<ul>
        Demantra Development recommends reordering the table in PK order as the factor percent approaches 50%.  In version 12.2.2
        we run the TABLE_REORG.CHECK_REORG function at every appserver restart.<br>
        If the function recommends a reorg then we strongly encourage to reorg the database object.  If you are not on 12.2.2,<br>
        please see [2005086.1], ''Demantra TABLE_REORG procedure.  Did you know that TABLE_REORG has replace REBUILD_SCHEMA mad REBUILD_TABLES?''<br>
        and [1528966.1], ''Demantra How to Use TABLE_REORG to Reorder MDP_MATRIX in Primary Key (PK) Order Action Plan Version 7.3.1.3 and Later.'' Prior to 7.3.1.3 <br>
        See [1085012.1] ''Reordering Columns and Rows in Oracle For Demantra Performance Improvement''.
        See [1629078.1] ''Demantra Large Database Object Diagnosis and Maintenance Best Practices for Best Performance'', this note contains a PDF that explains the cluster factor.
    </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'W',
   'RS');



  ------------------------------------------
  -- Max Extents and Space Issues
  ------------------------------------------
  add_signature(
   'TABLESPACE_CHECK',
   'SELECT s.segment_name object_name,
           s.owner,
           s.tablespace_name tablespace,
           s.segment_type object_type,
           s.extents extents,
           s.max_extents max_extents,
           s.next_extent/1024/1024 next_extent,
           max(fs.bytes)/1024/1024 max,
           sum(fs.bytes)/1024/1024 free
    FROM dba_segments     s,
         dba_free_space   fs
    WHERE s.owner = ''##$$MYSCHEMA$$##''
    AND   fs.tablespace_name = s.tablespace_name
    GROUP BY s.tablespace_name, s.owner, s.segment_type,
           s.segment_name, s.extents, s.max_extents, s.next_extent
    HAVING (s.extents >= (s.max_extents - 2) OR
            s.next_extent > max(fs.bytes))
    ORDER BY extents desc',
   'Potential Space and Extents Issues',
   'RS',
    'The objects listed above are either approaching their
     maximum number or extents, or have a next extent size
     that is larger than the largest available block of
     free space in the tablespace.',
   '<ul>
        Review items indicated and increase the max extents or add additional data files to the tablespace as required.
    </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'W',
   'RS');
   

  -------------------------------------------------------------------
  -- SALES_DATA_CHAIN_ROWS_PERCENT 
  ------------------------------
  -- PSD #9a
  add_signature(
  'SALES_DATA_CHAIN_ROWS_PERCENT',
  'SELECT 1 "YES"
   from dual 
   where exists
   (select decode(num_rows,0,0,round(chain_cnt/(num_rows*100),2))
    from dba_tables
    where decode(num_rows,0,0,round(chain_cnt/(num_rows*100),2)) > ''20''
    and owner = ''##$$MYSCHEMA$$##''
    and table_name = ''SALES_DATA'')',
  'Sales_Data_Chain_Rows_Percent',
  '[YES] = [1]',
  'The presence of migrated or chained rows can severely affect performance.  Any statements that query, update or create chained rows will be adding I/O overhead to 
   the system, impacting performance.  Demantra development suugests that you quickly identify and rectify situations involving chained rows.  Chained rows can also add 
   overhead to the performance of indexes and full-table scans.',
  '<ul>
      If you are on version greater than 7.3.1.3 you can use TABLE_REORG to reduce chaining.  If you are on a version before 7.3.1.4 you will need to either Rebuild the table having chained rows or create a new table using CREATE TABLE AS.  In either case consider increasing PCTFREE.<br>
          For more information see [1356886.1], ''How to check Demantra Performance DataBase and Worksheet Parameters.''
   </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'W');

 -------------------------------------------------------------------
 -- MDP_MATRIX_CHAIN_ROWS_PERCENT
 -------------------------------------------------------------------
 -- PSD #9a
  add_signature(
  'MDP_MATRIX_CHAIN_ROWS_PERCENT',
  'SELECT 1 "YES"
   from dual 
   where exists
   (select decode(num_rows,0,0,round(chain_cnt/(num_rows*100),2))
    from dba_tables
    where decode(num_rows,0,0,round(chain_cnt/(num_rows*100),2)) > ''20''
    and owner = ''##$$MYSCHEMA$$##''
    and table_name = ''MDP_MATRIX'')',
   'MDP_Matrix_Chain_Rows_Percent',
   '[YES] = [1]',
   'The presence of migrated or chained rows can severely affect performance.  Any statements that query, update or create chained rows will be adding I/O overhead to the system, impacting performance.  Demantra development suugests that you quickly identify and rectify situations involving chained rows.  Chained rows can also add overhead to the performance of indexes and full-table scans.',
  '<ul>
      If you are on version greater than 7.3.1.3 you can use TABLE_REORG to reduce chaining.  If you are on a version before 7.3.1.4 you will need to either Rebuild the table having chained rows or create a new table using CREATE TABLE AS.  In either case consider increasing PCTFREE.<br>
          See [1356886.1], ''How to check Demantra Performance DataBase and Worksheet Parameters.''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'W');


-------------------------------------------------------------------
--  DEMANTRA_CHAIN_ROWS_PERCENT 
-------------------------------------------------------------------
-- excludes sales_data and mdp_matrix
-- PSD #9a
  add_signature(
  'DEMANTRA_CHAIN_ROWS_PERCENT',
  'select 1 "Chaining",
          substr(table_name,1,15) "Table",
          decode(num_rows,0,0,round(chain_cnt/(num_rows*100),2)) "Percent",
          avg_row_len "Avg Row Len",
          pct_free "% Free",
          pct_used "% Used"
   from dba_tables
   where decode(num_rows,0,0,round(chain_cnt/(num_rows*100),2)) > ''20''
   and owner = ''##$$MYSCHEMA$$##''
   order by table_name',
  'Demantra_Chain_Rows_Percent',
  '[Chaining] = [1]',
  'The presence of migrated or chained rows can severely affect performance.  Any statements that query, update or create chained rows will be adding I/O overhead to 
   the system, impacting performance.  Demantra development suugests that you quickly identify and rectify situations involving chained rows.  Chained rows can also add 
   overhead to the performance of indexes and full-table scans.',
  '<ul>
      If you are on version later than 7.3.1.3 you can use TABLE_REORG to reduce chaining.  If you are on a version before 7.3.1.4 you will need to
      either Rebuild the table having chained rows or create a new table using CREATE TABLE AS.  In either case consider increasing PCTFREE.
      <br>See [1356886.1], ''How to check Demantra Performance DataBase and Worksheet Parameters.''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'W',
  'Y');
 
 
-------------------------------------------------------------------
-- INTEGRATION_INTERFACE_BLE 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
    'INTEGRATION_INTERFACE_BLE',
    'SELECT pname "Parameter",
            decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0))
     from ##$$MYSCHEMA$$##.aps_params
     where lower(pname) in (''threadpool.update.comb.batch.size'', ''threadpool.update.record.batch.size'', ''threadpool.update.data.manual.size'',
                            ''threadpool.update.table.batch.size'')
     and 
    ((lower(pname) = ''threadpool.update.comb.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
     or
     (lower(pname) = ''threadpool.update.record.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2)
     or
     (lower(pname) = ''threadpool.update.data.manual.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 8)
     or
     (lower(pname) = ''threadpool.update.table.batch.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2))',
   'Integration_Interface_BLE',
   '[FAIL] = [1]',
   'Your parameters for Integration Interface and BLE are not the default values.',
   '<ul>
    Please review following parameters.  You can use more threads during integration interfaces to increase performance.<br>
        threadpool.update.comb.batch.size: Number of parallel manual update combinations, the applications server handle at a table.  The default is 2.<br>
        threadpool.update.table.batch.size: Number of parallel batch(Integration/Ble) update records, app server handle at a combination.  The default is 2.<br>
        threadpool.update.data.manual.size: Update threadpool data manual size.  The default is 8.<br>
        threadpool.update.record.batch.size: Number of parallel batch (Integeration/Ble) update records, app server handle at a comb.  The default is 2.<br>
    If you are having performance issues with loading data, perhaps parallel is not performing correctly.  Try setting threadpool.update.table.batch.size to 1 and test.<br>
        See [2022259.1] ''Troubleshooting BLE Issues'' or see [1627716.1] ''Oracle Demantra BLE Mechanism Explanation and Details.''
    </ul>',
    'No issue found. This means Success.  The following parameters were verified:<br><br>
     threadpool.update.comb.batch.size: Number of parallel manual update combinations, the applications server handle at a table.  The default is 2.<br>
     threadpool.update.table.batch.size: Number of parallel batch(Integration/Ble) update records, app server handle at a combination.  The default is 2.<br>
     threadpool.update.data.manual.size: Update threadpool data manual size.  The default is 8.<br>
     threadpool.update.record.batch.size: Number of parallel batch (Integeration/Ble) update records, app server handle at a comb.  The default is 2.',
    'ALWAYS',
    'E');


-------------------------------------------------------------------  
-- THREADPOOL_CHECK 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'THREADPOOL_CHECK',
  'select pname "Parameter",
    decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "Value"
    from ##$$MYSCHEMA$$##.aps_params
    where pname in (''threadpool.query_run.size'', ''threadpool.level_method.size'', ''threadpool.copy_paste.size'', ''maxdbconnections'')
    and exists
    (select lower(pname) from ##$$MYSCHEMA$$##.aps_params
     where lower(pname) = ''threadpool.query_run.size''
     and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) >=
     (select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) / 10 
      from ##$$MYSCHEMA$$##.aps_params
      where lower(pname) = ''maxdbconnections''))
    or exists
    (select lower(pname) from ##$$MYSCHEMA$$##.aps_params
     where lower(pname) = ''threadpool.query_run.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) >= 
     (select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0))
      from ##$$MYSCHEMA$$##.aps_params where lower(pname) = ''maxdbconnections''))
    or exists
    (select lower(pname) from ##$$MYSCHEMA$$##.aps_params
     where lower(pname) = ''threadpool.level_method.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) >= 
     (select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0))
      from ##$$MYSCHEMA$$##.aps_params where lower(pname) = ''maxdbconnections''))
    or exists
    (select lower(pname) from ##$$MYSCHEMA$$##.aps_params
     where lower(pname) = ''threadpool.copy_paste.size'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) >= 
     (select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0))
      from ##$$MYSCHEMA$$##.aps_params where lower(pname) = ''maxdbconnections''))',
  'Threadpool_Check',
  '[Parameter] = [1]',
  'Caution should be exercised in increasing this number because too big a number potentially could end up in a lot of threads waiting for the database to respond if the database does not have a lot of open connections. However, please note that the MaxDBConnection has to be MORE than  threadpool.query_run.size.  Recommended, 4 X number of concurrent users.',
  '<ul>
       The MaxDBConnections parameter should also be modified accordingly to account for the increase in number of threads for this parameter.  A single user running a worksheet query will have 4 parallel threads accessing the database at the same time.  All users together are limited to 40 threads if threadpool.query_run.per_user = 4 and you have 10 concurrent users.<br>
      This analysis verifies that:<br>
          threadpool.query_run.size <= maxdbconnection<br>
          threadpool.level_method.size <= maxdbconnection<br>
          threadpool.copy_paste.size <= maxdbconnection<br>
      See [1157173.1], ''Demantra Master Note: Essential Development Suggested Performance Advice Plus Reference Docs.''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');


  -------------------------------------------------------------------
  -- COMBINATIONS_DATE_RANGE_CHECK 
  -----------------------------------------------------------------
  -- PSD #9a
  add_signature(
  'COMBINATIONS_DATE_RANGE_CHECK',
  'SELECT 1 "Rows Exist Outside Range"
   FROM dual
   WHERE EXISTS 
   (SELECT ITEM_ID,LOCATION_ID,FROM_DATE,UNTIL_DATE FROM ##$$MYSCHEMA$$##.MDP_MATRIX
   UNION
   SELECT ITEM_ID,LOCATION_ID, MIN(SALES_DATE), MAX(SALES_DATE) 
   FROM ##$$MYSCHEMA$$##.SALES_DATA
   GROUP BY ITEM_ID,LOCATION_ID
   HAVING COUNT(*) > 1)',
  'Combinations_Date_Range_Check',
  '[Rows Exist Outside Range] = [1]',
  'This confirms that you have forecast entries that are outside of the FROM_DATE and UNTIL_DATE range.',
  '<ul>
       During the EP_LOAD process MDP_ADD is updating mdp_matrix cache dates for new or updated SALES_DATA rows.  INSERT_UNITS is run as part of the forecast engine run.  The worksheets and export views both use the FROM_DATE and UNTIL_DATE columns to determine the correct population to include in their queries.<br>
          See [969874.1], ''Not all Members being included in the Demantra Worksheet, Export View is not including all rows.''
   </ul>',
   'No issue found. This means Success',
   'ALWAYS',
   'E');
   
 
-------------------------------------------------------------------
-- UI_WORKSHEET_LIMITATIONS 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'UI_WORKSHEET_LIMITATIONS',
  'select ''Y'' "MODIFIED?",
          pname "Parameter",
          decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "Value"
   from ##$$MYSCHEMA$$##.aps_params
   where lower(pname) in (''client.uilimitations.maxcombs.ws'',''client.uilimitations.maxcells.ws'',''client.uilimitations.maxcells'',
   ''client.uilimitations.maxdiskspace'',''client.uilimitations.warning'',''max.worksheet.db.weight'',
   ''worksheetbeancontentprovider.membercombinationslimit'')
   and 
   ((lower(pname) = ''client.uilimitations.maxcombs.ws'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 2000)
     or
   (lower(pname) = ''client.uilimitations.maxcells.ws'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 100000)
     or
   (lower(pname) = ''client.uilimitations.maxcells'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 300000)
     or
   (lower(pname) = ''client.uilimitations.maxdiskspace'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 200000)
     or
   (lower(pname) = ''client.uilimitations.warning'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 80)
     or
   (lower(pname) = ''max.worksheet.db.weight'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != .5)
     or
   (lower(pname) = ''worksheetbeancontentprovider.membercombinationslimit'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 4)
     or
   (lower(pname) = ''Query.MaxCombinations'' and decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) != 10))',
  'UI_Worksheet_Limitations',
  '[MODIFIED?] != [1]',
  'The parameters that impact worksheet performance have been changed from the default settings.  If you need to return to the default settings, see below.',
  '<ul>
      Default Values:<br>
   <li>client.uilimitations.maxcombs.ws = 2000</li>
   <li>client.uilimitations.maxcells.ws = 100000</li>
   <li>client.uilimitations.maxcells = 300000</li>
   <li>client.uilimitations.maxdiskspace = 200000</li>
   <li>client.uilimitations.warning = 80</li>
   <li>max.worksheet.db.weight = .5</li>
   <li>worksheetbeancontentprovider.membercombinationslimit = 4</li>
   <li>Query.MaxCombinations = 10</li>
   <li>See [1072163.1], ''Does Demantra Have a Limit on the Number of Combinations.''
   </ul>',
  'No issue found. This means Success.  The following parameters were verified:<br><br>
    client.uilimitations.maxcombs.ws = 2000<br>
    client.uilimitations.maxcells.ws = 100000<br>
    client.uilimitations.maxcells = 300000<br>
    client.uilimitations.maxdiskspace = 200000<br>
    client.uilimitations.warning = 80<br>
    max.worksheet.db.weight = .5<br>
    worksheetbeancontentprovider.membercombinationslimit = 4<br>
    Query.MaxCombinations = 10',
  'ALWAYS',
  'W');
 
-------------------------------------------------------------------
--  PREDICTION_STATUS_IMPACT  
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'PREDICTION_STATUS_IMPACT',
  'select substr(prediction_status,1,10) "Prediction Status",
  count(*) "Count"
  from ##$$MYSCHEMA$$##.MDP_MATRIX 
  group by prediction_status',
  'Prediction_Status_Impact',
  'RS',
  'Prediction_status controls how the Analytical Engine uses a combination.',
  '<ul>
       Is status 99 displayed under �Prediction Status�?  Verify your data integrity.<br>
       See [1509754.1], ''The Column Prediction_Status, MDP_Matrix and Engine. How are they Related? Understand Prediction_status Values.''
   </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');
 

-------------------------------------------------------------------
--  PREDICTION_STATUS_ANALYSIS  
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'PREDICTION_STATUS_ANALYSIS',
  'Select level_id "Level",
   prediction_status "Prediction Status",
   count(*) "Count",
   do_fore "Do Forecast",
   do_aggri "Aggregate?",
   aggri_98 "Aggregate Young?",
   aggri_99 "Aggregate Dead?"
   from ##$$MYSCHEMA$$##.MDP_MATRIX
   Group by level_id, prediction_status, do_fore, do_aggri, aggri_98, aggri_99',
  'Prediction_Status_Analysis',
  'RS',
  'MDP_MATRIX contains known combinations which are chosen by the engine, based in part by the prediction status.',
  '<ul>
       <li>Performance is directly impacted by the number of rows selected from this table. Important - See [1509754.1] ''The Column Prediction_Status, MDP_Matrix and Engine. How are they Related? Understand Prediction_status Values''<br>
       Controls how the Analytical Engine uses this combination.  Each combination has one of the following prediction status values:<br><br>
       97 (Create Zero Forecast) A user has set do_fore equal to 2. This status means that the Analytical Engine will insert a Zero forecast for this combination but otherwise ignore it.<br>
       98 (Young) Sales for this combination are too new to be used for prediction.<br>
       99 (Dead) Sales for this combination are not recent enough to be used for prediction.<br>
       1 (Live or Active) Neither young nor dead.
   </ul>',
   null,
  'ALWAYS',
  'W',
  'RS');

 
--------------------------------------------------------------------
-- UPDATE_COMBINATIONS 
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'UPDATE_COMBINATIONS',
  'select trunc(pval) "Update_Dead_Comb",
    decode(pval,''0'',''update only when prediction_status = 1,97,98 and 99 if it has historical rows'',
              ''1'',''update only when prediction_status = 1,97,98,99'',
              ''2'',''update only when prediction_status = 1,97,98 (never update 99)'',
              ''update_dead_comb not set.  This will not be forecasted.'') "Dead Combo Impact"
  from ##$$MYSCHEMA$$##.sys_params
  where lower(pname) = ''update_dead_comb''',
  'Combinations that can be updated by prediction_status based on Update_Dead_Comb',
  'RS',
  'Based on the setting of sys_params.update_dead_comb, combinations will be updated.',
  '<ul>
       Dead Combo Impact:<br><br>
       0 - We update all combinations where prediction_status update only 1,97,98 and 99 if the 99 has historical rows <br>
       1 - We update all combinations where prediction_status update= update only 1,97,98,99 <br>
       2 - Update only 1,97,98 (never update 99)  <br><br>
    Important - See [1509754.1], ''The Column Prediction_Status, MDP_Matrix and Engine. How are they Related?''
  </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');

--------------------------------------------------------------------
-- UPDATE_COMBINATIONS_2 
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'UPDATE_COMBINATIONS_2',
  'select trunc(pval) "Update_Dead_Comb",
    decode(pval,''0'',''update only when prediction_status = 1,97,98 and 99 if it has historical rows'',
                ''1'',''update only when prediction_status = 1,97,98,99'',
                ''2'',''update only when prediction_status = 1,97,98 (never update 99)'',
                ''update_dead_comb not set.  This will not be forecasted.'') "Dead Combo Impact"
  from ##$$MYSCHEMA$$##.sys_params
  where lower(pname) = ''update_dead_comb''',
  'Combinations that can be updated by prediction_status based on Update_Dead_Comb',
  'RS',
  'Based on the setting of sys_params.update_dead_comb, combinations will be updated.',
  'Dead Combo Impact:
    <ol><li>Status 0 - We update all combinations where prediction_status update only 1,97,98 and 99 if the 99 has historical rows</li>
    <li>Status 1 - We update all combinations where prediction_status update= update only 1,97,98,99</li>
    <li>Status 2 - Update only 1,97,98 (never update 99)</li><ol>
   Important - See [1509754.1], ''The Column Prediction_Status, MDP_Matrix and Engine. How are they Related?''',
  null,
  'ALWAYS',
  'W',
  'RS');
 
 
--------------------------------------------------------------------
-- FORECAST_LEVEL_STRUCTURE 
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'FORECAST_LEVEL_STRUCTURE',
  'SELECT  level_id "Level_ID", count(*) "Count"
   FROM ##$$MYSCHEMA$$##.mdp_matrix
   WHERE do_fore = 1 
   AND prediction_status = ''1''
   GROUP BY level_id
   order by level_id',
  'Forecast Structure by level_id',
  'RS',
  'This will provide an understanding at which level of the Forecast Tree the forecast is being generated. This is the nodal tree structure.  Having a majority of combinations higher on the forecast tree might indicate either a poorly designed forecast tree and / or engine parameters that are too strict.',
  '<ul>
     Based on the results, adjust the Forecast Tree to see if choosing a different hierarchy might produce a better forecast for more combinations at
     a lower level.  The treehierarchytest.exe can also be used to validate the forecast tree.<br>
     See [1632458.1] ''Constructing an Effective Forecast Tree Using Correct Using Levels, Hierarchies, min_fore_level, max_fore_level and Proportion of Models.''<br>
     We would like the engine to forecast at least 70% of the combinations in the min_fore_level and if it does not you are advised to revise the forecast tree or further tune the engine in new ways, to reach this desired target.
   </ul>',
   null,
  'ALWAYS',
  'W',
  'RS');
 


-------------------------------------------------------------------
--  INVALID_OBJECTS 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
   'DEMANTRA_INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''##$$MYSCHEMA$$##''
    AND a.status = ''INVALID''',                                    -- SQL
   'Demantra Invalids',                                             -- User signature name (title in report)  
   'RS',                                                            -- Print SQL Output (Y, N, RS = only if rows selected) 
   'Invalid objects exist that are related to Demantra schema',     -- Problem description
   '<ul>
        Recompile the individual objects.
   </ul>',                                                          -- Solution HTML
   'Invalid objects for the Demantra schema were not found.',       -- Success message if printing success (non default)
   'ALWAYS',                                                        -- Print condition ALWAYS, SUCCESS, FAILURE, NEVER
   'E');                                                             -- Warn(W), Err(E), Info(I) 
                                                                   -- Limit output rows to the max rows value
   

-- ImportBlockSize BM - Application Server - App.Server = 5000 The number of rows for each commit, used during import
   
-------------------------------------------------------------------
--  MISSING_SALES_DATA 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'MISSING_SALES_DATA',
  'select count(*) "Qty_Missing"
   from ##$$MYSCHEMA$$##.sales_data
   where sales_date not in (select datet from ##$$MYSCHEMA$$##.inputs)',
  'Missing SALES_DATA',
  '[Qty_Missing] > [0]',
  'This confirms that you have missing dates between SALES_DATA and available dates registered in INPUTS table.',
  '<ul>
       The forecasting process requires all desired forecastable SALES_DATA rows match with a corresponding date in the INPUTS table.<br>
       See [1355195.1], ''ENGINE Warning FillMissingDates() .. no causal or INSERT_UNITS was Not Run.''
   </ul>',
  'No SALES_DATA rows not represented in the INPUTS table.',
  'ALWAYS',
  'W');
 

-------------------------------------------------------------------
--  NO_HISTORY_COMBINATIONS 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'NO_HISTORY_COMBINATIONS',
  'SELECT ITEM_ID "Item", LOCATION_ID "Location" FROM (
          SELECT ITEM_ID,LOCATION_ID,FROM_DATE,UNTIL_DATE FROM ##$$MYSCHEMA$$##.MDP_MATRIX
          UNION
          SELECT ITEM_ID,LOCATION_ID, MIN(SALES_DATE), MAX(SALES_DATE) FROM ##$$MYSCHEMA$$##.SALES_DATA
          GROUP BY ITEM_ID,LOCATION_ID)
          GROUP BY ITEM_ID,LOCATION_ID
          HAVING COUNT(*) > 1
          ORDER BY ITEM_ID,LOCATION_ID',
  'Combinations without history',
  '[Item] != ['' '']',
  'This confirms that you have combinations without history.',
  '<ul>
       The worksheets and export views both use the FROM_DATE and UNTIL_DATE columns to determine the correct population to include in their queries.<br>
       See [969874.1], ''Not all Members being included in the Demantra Worksheet - Export View is not including all rows.''
   </ul>',
   'No Combinations without history found.',
   'ALWAYS',
   'W');


-------------------------------------------------------------------
-- MISSING_MDP_MATRIX 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'MISSING_MDP_MATRIX',
  'select count(*) "PCT Missing / Qty Missing"
   from ##$$MYSCHEMA$$##.mdp_matrix 
   where (item_id,location_id) not in (select distinct item_id,location_id from ##$$MYSCHEMA$$##.sales_data) 
   and (prediction_status = ''1'' or (prediction_status = ''98'' and aggri_98 = 1) or (prediction_status = ''99'' and aggri_99 = 1)) 
   union
   select round(((select count(*)
            from ##$$MYSCHEMA$$##.mdp_matrix
            where ((item_id,location_id) not in (select distinct item_id,location_id from ##$$MYSCHEMA$$##.sales_data))
            and (prediction_status = ''1'' or (prediction_status = ''98'' and aggri_98 = 1) or (prediction_status = ''99'' and aggri_99 = 1))) /
            (select count(*) from ##$$MYSCHEMA$$##.mdp_matrix)) * 100) "Pct of Total"
   from dual',
  'Missing MDP_MATRIX Data',
  '[PCT Missing - Qty Missing] > [0]',
  'This confirms that you have missing combination data in MDP_MATRIX.',
  '<ul>
       This may have happened during the EP_LOAD process MDP_ADD, INSERT_UNITS or some other data manipulation.<br>
       See [969874.1] ''Not all Members being included in the Demantra Worksheet / Export View is not including all rows.''
   </ul>',
  'No missing MDP_MATRIX found. This means Success',
  'ALWAYS',
  'W');

 


-------------------------------------------------------------------
-- APPSERVERURL 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'APPSERVERURL',
  'select nvl(pval,''null'') "Check_Values"
   from ##$$MYSCHEMA$$##.sys_params 
   where lower(pname) in (''appserverurl'', ''appserverlocation'')',
  'AppServerURL and AppServerLocation comparison',
  'RS',
  'AppServerURL must correspond with the browser URL address.',
  '<ul>
       Using Business Modeler, adjust these settings and bounce the appserver.  Note that these changes need to be made on the windows machine and then the WAR file needs to be recreated and<br>
	   redeployed if the web server is on an UNIX/LINUX machine.  Reminder: The application server will need to be bounced.<br>
      See [1999172.1], ''DEMANTRA How to switch from a different webserver to Tomcat.''
   </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');
 
-------------------------------------------------------------------
-- CONNECTION_PARAMETERS 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'CONNECTION_PARAMETERS',
  'select substr(pname,1,30) "Parameter",
   decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "Parameter Value"
   from ##$$MYSCHEMA$$##.aps_params
   where lower(pname) in (''database.password'', ''dbname'', ''dbport'', ''dbuser'', ''tnsname'', ''server.generalurl'', ''servername'')',
  'Connection Focused Parameters',
  'RS',
  'These are set in aps_params.',
  '<ul>
       Compare the database.password to the password parameter in the ds.ini file.  They should be the same.  To test the encypted password setting,
       run the following SQL: select encrypt_string(''yourpasswd'') from dual.  Compare the output to database.password and the ds.ini parameter.<br>
       See [1354934.1], ''Demantra Connection Parameters - How to create a CLONE? Quick Steps for Cloning Demantra Environment.''
   </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');
 
 
-------------------------------------------------------------------
--  MAXDBCONNECTIONS 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'MAXDBCONNECTIONS',
  'select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "MaxDBConnections"
  from ##$$MYSCHEMA$$##.aps_params
  where lower(pname) = ''maxdbconnections''',
  'MaxDBConnection',
   'RS',
   'Connection Pool Settings: You can control the DB connection pool size via MaxDBConnections.  It is important that the application server will have all of
    the required threads to execute the parallel requests, query executions, workflow runs, updates',
  '<ul>
       Review parameter setting threadpool.query_run.size.  MaxDBConnections must be higher then threadpool.query_run.size.
       A rule of thumb will be:<br>
       The number of concurrent users X threadpool.query_run.per_user X 10 - if threadpool.query_run.per_user > 4.<br>
       See [1201774.1], ''Oracle Demantra Parameters for Performance.''
   </ul>',
   null,
   'ALWAYS',
   'W',
   'RS'); 
   
   
-------------------------------------------------------------------
-- THREADPOOL.QUERY_RUN.PER_USER 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'THREADPOOL.QUERY_RUN.PER_USER',
  'select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "threadpool.query_run.per_user"
  from ##$$MYSCHEMA$$##.aps_params
  where lower(pname) = ''threadpool.query_run.per_user''',
   'threadpool.query_run.per_user',
   'RS',
   null,
   '<ul>
        This parameter determines the number of concurrent threads to use for querying datam from tables for each user.<br>
        Number of concurrent users determines this setting.  Experiment, by increasing it in chunks of 4 to determine an optimal value.<br>
        Caution should be exercised in increasing this number: too big a number could result in a lot of threads waiting for the database to<br>
        respond if the database does not have a lot of open connections.  16 seems optimal to some environments and yields the fastest response time<br>
        for paged worksheets if the data server has 8 CPUs.Review parameter setting MaxDBConnections and database setting open_cursors.<br>
        See [1201774.1], ''Oracle Demantra Parameters for Performance.''
   </ul>',
   'Verify threadpool.query_run.per_user',
   'ALWAYS',
   'W',
   'RS'); 

   
   
-------------------------------------------------------------------
-- APPROVALPROCESSSCOPE 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'APPROVALPROCESSSCOPE',
  'select decode(pval,''0'',''Global scope - Approval series are added to every Worksheet (WS).'',
''1'',''Sales Data scope - series are added if other SALES_DATA series are explicitly or implicitly in the Worksheet (WS).'',
''2'',''No scope - series are NOT added.'',
''approvalprocessscope is null'') ApprovalProcessScope
   from ##$$MYSCHEMA$$##.sys_params
   where lower(pname) = ''approvalprocessscope''',
   'ApprovalProcessScope',
   'RS',
   'Courtesy check to verify possible performance parameter',
   '<ul>
        The scope of the forecast approval process.  If you are using General Level worksheets that do not include any sales_data series, set the parameter from 0 to 1.<br>
        This will have a positive performance impact, eliminating the join with sales_data.  Setting worksheet.full.load = 1 if using crosstab worksheets.<br>
         The scope of the forecast approval process.  0 - Global scope - Approval series are added to every WS.<br>
         1 - Sales Data scope - series are added if other SALES_DATA series are explicitly or implicitly in the WS.<br>
         2 - None scope - series are NOT added.<br>
         See [1201774.1], ''Oracle Demantra Parameters for Performance.''
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


-------------------------------------------------------------------
-- CT_WS_CALCSUMMARYEXPRESSIONS
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'CT_WS_CALCSUMMARYEXPRESSIONS',
  'select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "WS calcSummaryExpressions"
  from ##$$MYSCHEMA$$##.aps_params
  where lower(pname) = ''client.worksheet.calcsummaryexpressions''',
   'client.worksheet.calcSummaryExpressions',
   'RS',
   null,
   '<ul>
        This parameter defaults to 1.<br>
        If true, summary line client expressions are supported. Complex summary expressions can have a performance impact.<br>
        If this is set to 0, simple summary expressions (Sum, Max, etc.) are only supported.<br>
        See [1201774.1], ''Oracle Demantra Parameters for Performance.''
   </ul>',
   'client.worksheet.calcSummaryExpressions',
   'ALWAYS',
   'W',
   'RS'); 

   
-------------------------------------------------------------------
-- WS_DATA_COMB_BLOCK_SIZE
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'WS_DATA_COMB_BLOCK_SIZE',
  'select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "worksheet.data.comb.block_size"
  from ##$$MYSCHEMA$$##.aps_params
  where lower(pname) = ''worksheet.data.comb.block_size''',
   'worksheet.data.comb.block_size',
   'RS',
   null,
   '<ul>
        This parameter controls the block size for worksheet data retrieval.  It defaults to 0, downloading all combinations in a single select.<br>
        This setting is appropriate for crosstab worksheets to display all the combinations together.  That is, worksheets in which the levels are
        displayed within the table vs. as dropdowns or within the members browser, Are you using cross tabs  What is the setting of worksheet.full.load<br>
        See [1201774.1], ''Oracle Demantra Parameters for Performance''
   </ul>',
   'client.worksheet.calcSummaryExpressions',
   'ALWAYS',
   'W',
   'RS');



-------------------------------------------------------------------
-- MAXUPDATETHREADS 
-------------------------------------------------------------------
-- PSD #9a

  add_signature(
  'MAXUPDATETHREADS',
  'select decode(nvl(value_number,0),0,nvl(default_number,0),nvl(value_number,0)) "MaxUpdateThreads"
   from ##$$MYSCHEMA$$##.aps_params
   where lower(pname) = ''maxupdatethreads''',
   'MaxUpdateThreads',
   'RS',
   null,
   '<ul>
        Support for parallel integration procedure.  Max number of Parallel Update Threads. Default Threads = 5 (Number of DB Server CPU + 1)<br><br>
        See [1519805.1] ''Demantra WORKSHEET PARAMETERS General, Organized Checklist. A Place to Begin for Maintenance and Proper Diagnostics''
   </ul>',
   null,
   'ALWAYS',
   'W',
   'RS'); 

   
-------------------------------------------------------------------
-- OPTIMIZER_INDEX_CACHING
------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'OPTIMIZER_INDEX_CACHING',
  'select value "Not set to Recommendation"
   from v$parameter
   where lower(name) = ''optimizer_index_caching'' and nvl(value,''0'') not between ''74'' and ''101''',
  'Verify optimizer_index_caching',
  '[Not set to Recommendation] != ['']',
  'Default 100% - the optimizer evaluates index access at the regular cost.',
 '<ul>
      50% makes the index access path look half as expensive.  Demantra Development recommends between 75 and 100.  Your setting is out of typical scope.  
      If not intended please test with a setting within recommended scope.<br>
      See [470852.1], ''Oracle Demantra Worksheet Performance - A White Paper.''
  </ul>',
 'No issue found. This means Success',
 'ALWAYS',
 'W');
   

-------------------------------------------------------------------
-- OPTIMIZER_INDEX_COST_ADJ 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'OPTIMIZER_INDEX_COST_ADJ',
  'select value "Not set to recommendation"
   from v$parameter
    where lower(name) = ''optimizer_index_cost_adj'' and nvl(value,''0'') not between ''24'' and ''51''',
  'Verify optimizer_index_cost_adj',
  '[Not set to recommendation] != ['']',
  'Default 100% - the optimizer evaluates index access at the regular cost.',
  '<ul>
       50% makes the index access path look half as expensive. Normal is between 25 and 50.  Your setting is out of typical scope.  If not intended
       please test with a setting within recommended scope.<br>
       See [470852.1], ''Oracle Demantra Worksheet Performance - A White Paper.''
  </ul>',
 'No issue found. This means Success',
 'ALWAYS',
 'W');
 

-------------------------------------------------------------------
-- OPT_CAPTURE_SQL_PLAN_BASELINES 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'OPT_CAPTURE_SQL_PLAN_BASELINES',
  'select value "Not set to recommendation"
   from v$parameter
   where lower(name) = ''optimizer_capture_sql_plan_baselines'' and trim(nvl(value, null)) != ''FALSE''',
  'Verify optimizer_capture_sql_plan_baselines',
  '[Not set to recommendation] != ['']',
  'Default FALSE.',
 '<ul>
      The optimizer_capture_sql_plan_baselines parameter must be set to FALSE due to performance related issues.<br>
      See [470852.1], ''Oracle Demantra Worksheet Performance - A White Paper.''
  </ul>',
 'No issue found. This means Success',
 'ALWAYS',
 'E');
 
 
-------------------------------------------------------------------
-- OPTIMIZER_USE_SQL_PLAN_BASELINES 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'OPTIMIZER_USE_SQL_PLAN_BASELINES',
  'select value "Not set to recommendation"
   from v$parameter
   where lower(name) = ''optimizer_use_sql_plan_baselines'' and trim(nvl(value, null)) != ''FALSE''',
  'Verify optimizer_use_sql_plan_baselines',
  '[Not set to recommendation] != ['']',
  'Default TRUE.',
  '<ul>
       The optimizer_use_sql_plan_baselines parameter must be set to FALSE due to performance related issues.<br>
       See [470852.1], ''Oracle Demantra Worksheet Performance - A White Paper.''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');
 
 
-------------------------------------------------------------------
-- _B_TREE_BITMAP_PLANS 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  '_B_TREE_BITMAP_PLANS',
  'select value "Not set to recommendation"
   from v$parameter
   where lower(name) = ''_b_tree_bitmap_plans'' and trim(nvl(value, null)) != ''FALSE''',
  'Verify _b_tree_bitmap_plans',
  '[Not set to recommendation] != ['']',
  'Default TRUE.',
  '<ul>
       The _b_tree_bitmap_plans parameter must be set to FALSE due to performance related issues.
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');
 

   
-------------------------------------------------------------------
-- MAX_SALES_DATE_CHECK
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'MAX_SALES_DATE_CHECK',
  'select "Date Mismatch Exists" "FAIL"
   from dual
   where not exists
   (select to_char(to_date(PVAL,''MM-DD-YYYY HH24:MI:SS''),''MON-DD-YYYY'') 
    from ##$$MYSCHEMA$$##.SYS_PARAMS where lower(PNAME) = ''max_sales_date''
    and to_char(to_date(PVAL,''MM-DD-YYYY HH24:MI:SS''),''MON-DD-YYYY'') = (select to_char(to_date(PVAL,''MM-DD-YYYY HH24:MI:SS''),''MON-DD-YYYY'') 
    from ##$$MYSCHEMA$$##.SYS_PARAMS where lower(PNAME) = ''max_fore_sales_date''))
   or not exists
   (select to_char(to_date(PVAL,''MM-DD-YYYY HH24:MI:SS''),''MON-DD-YYYY'') 
    from ##$$MYSCHEMA$$##.SYS_PARAMS 
    where lower(PNAME) = ''max_sales_date''
    and to_char(to_date(PVAL,''MM-DD-YYYY HH24:MI:SS''),''MON-DD-YYYY'') = (select to_char(to_date(value_date,''DD-MM-YYYY HH24:MI:SS''),''MON-DD-YYYY'')
    from ##$$MYSCHEMA$$##.INIT_PARAMS_0 where lower(PNAME) = ''last_date_backup''))',
  'Max_Sales_Date - Max_Fore_Sales_Date',
  '[FAIL] != [1]',
  '<ul>
       max_sales_date: The latest sales date loaded as history in the system.  The analytical engine will use last_date as last date of actual sales.
       Please also set max_fore_sales_date in sys_params to the same as max_sales_date, which should reflect the same date as last_date_backup as 
       found in the init_params_0 table.
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');
 

-------------------------------------------------------------------
-- INSERT_UNITS_CHECK
-------------------------------------------------------------------
-- PSD #9a
   add_signature(
   'INSERT_UNITS_CHECK',
  'select count(*) "PCT Total - QTY_Ins_Units"
   from ##$$MYSCHEMA$$##.MDP_MATRIX 
   where (level_id > 0 and prediction_status <> ''99'' and do_fore <> 0)
   union
   select round((select count(*)
   from ##$$MYSCHEMA$$##.mdp_matrix
   where (level_id > 0 and prediction_status <> ''99'' and do_fore <> 0)) /
   (select count(*) from ##$$MYSCHEMA$$##.mdp_matrix) * 100)
   from dual',
  'Reporting available Combinations for INSERT_UNITS - Percent of total and Quantity Identified',
  '[PCT Total - QTY_Ins_Units] > [0]',
  'Available combinations for Insert_Units.',
  '<ul>
      During the EP_LOAD process MDP_ADD is updating mdp_matrix cache dates for new or updated SALES_DATA rows.  INSERT_UNITS is run as part of the
      forecast engine run. The worksheets and export views both use the FROM_DATE and UNTIL_DATE columns to determine the correct population to
      include in their queries.  See [969874.1], ''Not all Members being included in the Demantra Worksheet / Export View is not including all rows.''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'I');

 
-------------------------------------------------------------------
-- MAXENGMEMORY
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'MAXENGMEMORY',
  'select pname "Parameter", value_string "Value" 
   from ##$$MYSCHEMA$$##.init_params_0 
   where lower(pname) = ''maxengmemory''
   and not exists
  (select value_string from ##$$MYSCHEMA$$##.init_params_0 where lower(pname) = ''maxengmemory'' 
   and value_string = ''100'')',
  'Reporting parameter MaxEngMemory',
  '[Value] != ['' '']',
  'There is an issue with MaxEngineMemory',
  '<ul>
      This parameter should always be set to 100.  As the engine processes individual nodes for a very large branch eventually it reaches the limitations of available memory which results in an error containing the text: threw Matlab exception: A memory allocation request failed.<br>
      As each engine task is completed, the Engine Manager evaluates the amount of memory currently used by all analytical engine processes on the machine.  If this amount in megabytes exceeds the value of MaxEngMemory, the engine instance stops and a new instance is initiated.<br>
      See [1458920.1], ''Demantra Engine Configuration Setup and Processing Walk Through Processing Analysis.''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');
 

-------------------------------------------------------------------
-- BLOCKSIZE_CHECK  
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'BLOCKSIZE_CHECK',
  'SELECT lower(name) "Parameter",
   value "Not_Recommended_Size"
   from v$parameter 
    where lower(name) = ''db_block_size''
    and value != ''16384''',
  'Blocksize Check',
  '[Not_Recommended_Size] != ['' '']',
  'Oracle Demantra Development suggests 16k blocksize.',
  '<ul>
      Consider the following:<br>
      Block size 16k or larger.<br>
      PCTFREE set at 30% to 40%.<br>
      FREELIST increased according to your particular implementation.<br>
      INITRANS increased according to your particular implementation.<br>
      Statistics maintained at a 30% sample or larger.<br>
      Parallel Processing at every possible contention point.<br>
      Redo size appropriate to keep switches at 3-4 per hour.<br>
      No Automatic Segment Management (ASM).<br>
      No Editioning.<br>
      Partitions implemented with proper gathering of RDBMS statistics.<br>
      Large SGA to accommodate multi-block reads.<br>
      Synchronous IO implemented.<br>
      Careful setting of Demantra CBO parameters.</li><br>
      See [1499638.1], ''Demantra DB Health and Performance: Oracle Demantra Database Best Practices - A White Paper / Demantra Performance Clustering Factor Out of Order Ratio TABLE_REORG CHECK_REORG.''<br>
      See [1990353.1], ''Demantra Table Reorganization, Fragmentation, Null Columns, Primary Key, Editioning, Cluster Factor, PCT Fee, Freelist, Initrans, Automatic Segment Management (ASM), Blocksize.''<br>
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');
  

-------------------------------------------------------------------
-- ACL_PRIVILEGE_CHECK
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'ACL_PRIVILEGE_CHECK',
  'select principal "Principal",
   privilege "Privilege",
   is_grant "IS_Grant"
   from dba_network_acl_privileges
   where principal = ''##$$MYSCHEMA$$##''
   and lower(privilege) = ''connect''
   and lower(is_grant) = ''true''',
  'Demantra Network ACL Privilege Check',
  '[Principal] = ['' '']',
  'You have the Network ACL Privilege as granted in the SYS_GRANTS.sql script.',
  '<ul>
       See [1951450.1], ''Demantra Linux Unix: Failed to run Engine in the workflow: Engine Execution could not start (engine failure). ORA-06512.''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');
  

-------------------------------------------------------------------
--  ENCRYPTION_TYPE_CHECK
-------------------------------------------------------------------
-- PSD #9a

  add_signature(
  'ENCRYPTION_TYPE_CHECK',
  'select count(*) "User(s)_Not_SHA-1"
    FROM   ##$$MYSCHEMA$$##.USER_ID
    WHERE  UPPER(encryption_type) not in (''SHA-1'',''DEMANTRA'')',
  'Check ENCRYPTION_TYPE',
  '[User(s)_Not_SHA-1] > [0]',
  'The value of ENCRYPTION_TYPE is incorrect.',
  '<ul>
       Beginning with version 7.3.0.1 a new encryption method was offered, SHA-1 with at least 3 notable effects:<br>
       password - wrong encryption in user_id table, or not encrypted in ds.ini.<br>
       procedures - not enough characters to receive full encrypted line for password<br>
       integration - integration or custom scripts with browsers not updated<br>
       See [1446535.1], ''Invalid Username or Password while attempt to log into the Demantra Business modeler or Web application.''
   </ul>',
  'No issue found. This means Success',
  'ALWAYS',
  'E');
  
  
-------------------------------------------------------------------
-- NLS_DATE_FORMAT_CHECK
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'NLS_DATE_FORMAT_CHECK',
  'SELECT trim(pval) "NLS_DATE_FORMAT" 
   from ##$$MYSCHEMA$$##.db_params
   where lower(pname) = ''nls_date_format''',
  'NLS_DATE_FORMAT Check',
  'RS',
  'Verify the NLS_DATE_FORMAT',
  '<ul>
       This value will affect the behavior of dates within Demantra.  The correct format is: NLS_DATE_FORMAT = MM-DD-YYYY HH24:MI:SS<br>
       See [1466420.1], ''The dm User Default Password No Longer Works.''
  </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');
  

-------------------------------------------------------------------
-- LEGACY Location Import Errors
--------------------------------------------------------------------
-- PSD #9a
--   add_signature(
--    'LEGACY_LOC_IMPORT_ERR',
--    'SELECT ''1'' "Nbr_Legacy_Loc_Imp_Records" from dual',
--    'LEGACY Location Import Errors',
--    'RS',
--    'There Is an issue - Error message goes here',
--    '<ul>
--       <li>Solution to issue goes here</li>
--    </ul>',
--    'No issue found. This means Success',
--    'ALWAYS',
--    'E',
--    'RS');
-- 
-- 
  -------------------------------------------------------------------
  -- TABLESPACES
  --------------------------------------------------------------------
  -- PSD #9a
  add_signature(
   'TABLESPACES',
   'SELECT pname Parameter,
           substr(pval,''1'',''50'') Tablespace
    FROM ##$$MYSCHEMA$$##.sys_params
    where lower(pname) in (''tablespace'', ''indexspace'', ''simulationspace'', ''simulationindexspace'', ''sales_data_engine_space'', ''sales_data_engine_index_space'')',
   'Tablespace Review',
   'RS',
   'Tablespace settings in the sys_params table.',
   '<ul>
        Demantra Development suggests following guidelines as explained in your version of the Oracle Demantra Implementation Guide.
   </ul>',
   null,
   'ALWAYS',
   'I',
   'RS');


-------------------------------------------------------------------
-- LOCKED_DATABASE_OBJECTS 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'LOCKED_DATABASE_OBJECTS',
  'SELECT a.username,
          a.sid,
          a.serial#,
          b.id1,
          c.sql_text
   FROM v$session a, v$lock b, v$sqltext c
   WHERE b.id1 IN (SELECT DISTINCT e.id1 FROM v$session d, v$lock e
                   WHERE d.lockwait = e.kaddr )
   AND a.sid = b.sid
   AND c.hash_value = a.sql_hash_value
   AND b.request =0',
   'Locked Database Objects',
   'RS',
   'This is the output of the indentify locks SQL.',
   '<ul>
        See [18245.1], ''OERR: ORA-54 resource busy and acquire with NOWAIT specified.''<br>
        Another way to capture ORA-54 information is by creating a trace triggered by that error:<br>
        alter system set events = ''54 trace name errorstack forever, level 10'';
   </ul>',
   'There are no locked database objects at this time',
   'ALWAYS',
   'W',
   'RS'); 
  
 
-------------------------------------------------------------------
-- PCT_FREE_CHECK_SALES_DATA
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'PCT_FREE_CHECK_SALES_DATA',
  'SELECT substr(table_name,1,15) "Table Name",
          chain_cnt "Chain Cnt",
          round(chain_cnt/num_rows*100,2) "PCT_chained",
          avg_row_len "Avg Row Len",
          pct_free "% Free",
          pct_used "% Used"
    FROM dba_tables
    WHERE owner = ''##$$MYSCHEMA$$##''
    AND table_name = ''SALES_DATA'')',
   'Table details: Sales_Data',
   'RS',
   '<ul>
        This parameter determines the number of concurrent threads to use for querying datam from tables for each user.
        The USER_TABLES tells you immediately after an ANALYZE, will be null otherwise, how many rows in the table are chained.
        All professional DBAs know that minimizing chained rows is a fundamental job role and they recognize that row migration, chaining,
        is a function of:<br>
        blocksize<br>
        PCFREE<br>
        How to avoid Chained and Migrated Rows?  Increasing PCTFREE can help to avoid migrated rows.  You can execute the DBMS_REPAIR.SEGMENT_FIX_STATUS procedure to implement the new setting on blocks already allocated to the segment as documented in the SQL reference.
   </ul>',
   'ALWAYS',
   'I',
   'RS'); 
  

--------------------------------------------------------------------
-- FORECAST_HISTORY_STATUS
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'FORECAST_HISTORY_STATUS',
  'select status,
          lead,
          last_date,
          start_date,
          last_forecast_date,
          fore_column_name,
          start_forecast_date,
          init_params_table_name,
          engine_profiles_id
   from ##$$MYSCHEMA$$##.forecast_history
   where rownum < ''4''',
  'Forecast_history Analysis',
  'RS',
  'Click on Forecast_History Analysis above to review output.',
  '<ul>
         The status column will reveal the following:<br><br>
     -2: Engine was never executed<br>
     -1: Engine manager is doing some initialization for engine to run<br>
     0: Engine is running normally<br>
     1: Engine run has completed successfully<br>
     2: configuration problems<br><br>
     Lead: The number of future time buckets to forecast out into the horizon<br><br>
     Last_Date:  The sales_date value in the sales_data table that represents the last period of ''demand'' in the database.  Last date of actual
         sales, to be used by the Analytical Engine and the proport mechanism.  No dates after this are used towards the forecast or the proport calculation.<br><br>
     Start_Date: The beginning of forecast history.  The data used to generate the future forecast will begin on this date.<br><br>
     Last_Forecast_Date:  The sales_date value in the sales_data table that represents the period with the furthest amount of sales of ''demand'' in
         the database.  The value should be the value in the Last_Date column plus the Lead column value.<br>
     If you see that there are no forecast buckets, it would be expected that the Last_Forecast_Date would be equal to the Last_Forecast_Date or at 
         least that the Last_Forecast_Date is not equal to the Last_Date plus the Lead value.<br><br>
     Start_Forecast_Date: This is the first date of the future forecast that is to be generated.<br><br>
     See [848205.1], ''No Demantra Forecast Generated - Common Issues.''
  </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');


--------------------------------------------------------------------
-- RUNINSERTUNITS_PARAMETER
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'RUNINSERTUNITS_PARAMETER',
  'select value_float "RunInsertUnits"
   from ##$$MYSCHEMA$$##.init_params_0
  where lower(pname) = ''runinsertunits''',
  'SYS_PARAMS RunInsertUnits Parameter',
  'RS',
  'RunInsertUnits controls the behavior of the Run Insert Units Procedure.',
  '<ul>
       Insert_Units is the procedure that runs at the beginning of the engine creating the future rows or time buckets in the sales_data table based on the Lead parameter.  Current settings:<br>
     1 - Run Insert Units - default.<br>
     3 - Run Insert Units without Rolling Profiles.<br>
     Navigation to change the RunInsertUnits parameter: Business Modeler --> Parameters --> System Parameters --> Engine tab --> Shell
  </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');



--------------------------------------------------------------------
-- MAX_SALES_DATE_SALES_DATA
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'MAX_SALES_DATE_SALES_DATA',
  'select max(sales_date) "Max Sales Date"
   from ##$$MYSCHEMA$$##.sales_data',
  'Maximum SALES_DATE in SALES_DATA table',
  'RS',
  null,
  '<ul>
     This is the MAX(SALES_DATE) from the SALES_DATA table.  Rows returned here show data created in the future. If a different maximum SALES_DATE is expected in the SALES_DATA table<br>
     see [1467517.1]. ''How to Control the MAX_SALES_DATE When Collecting Future Demand.''
  </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');


--------------------------------------------------------------------
-- MAXAVAILABLEFILTERMEMBERS 
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'MAXAVAILABLEFILTERMEMBERS',
  'select trim(pval) "MaxAvailableFilterMembers"
   from ##$$MYSCHEMA$$##.sys_params
  where lower(pname) = ''maxavailablefiltermembers''',
  'SYS_PARAMS MaxAvailableFilterMembers',
  'RS',
  'Maximum number of members that can be retrieved in the worksheet filter screen.',
  '<ul>
       The ability to configure the max selected filters member is accomplished by adjusting the value of MaxSqlInExpressionTokens in the
       AppServer.properties file.  The webserver will need to be restarted after modifying AppServer.properties file.  If you set the
       MaxAvailableFilterMembers too high, it affects the performance.  Setting the value too low limits number of filter members.<br><br>
       See [1113714.1] ''Demantra Performance Solutions - Desktop to RDBMS to Worksheet''
  </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');


--------------------------------------------------------------------
-- KEY_DATE_PARAMETERS 
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'KEY_DATE_PARAMETERS',
  'select pname "Parameter Name",
   pval "Value"
   from ##$$MYSCHEMA$$##.sys_params
   where lower(pname) in (''max_fore_sales_date'', ''max_sales_date'', ''min_fore_sales_date'', ''min_sales_date'')',
  'SYS_PARAMS Key Dates',
  'RS',
  null,
  '<ul>
       MAX_FORE_SALES_DATE - Set the max_fore_sales_date and init_params_0.last_date_backup to the same value as the max_sales_date.<br>
       MAX_SALES_DATE - Insert_units procedure will insert records in the span of time from max_sales_date to max_sales_date + lead only.
       FillMissingDates() will use the values of the max_sales_date and last_date, last_date_backup parameters.<br>
       MIN_SALES_DATE - Represents the minumum sales_date in SALES_DATA.<br>
       MIN_FORE_SALES_DATE - Set to SALES_DATE + Lead (1 day, 1 week, 1 month) = next sales_date.  Please also set max_fore_sales_date in sys_params to the same as max_sales_date, which
	   should reflect the same date as last_date_backup.  Then run again the engine.<br>
       See [1467517.1], ''How to Control the MAX_SALES_DATE When Collecting Future Demand''
  </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');


--------------------------------------------------------------------
-- TABLE_HEALTH 
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'TABLE_HEALTH',
  'SELECT table_name "Table Name",
          tablespace_name "Table Space",
          sample_size "Sample Size",
          num_rows "NBR Rows",
          avg_row_len "AVG Row Length",
          last_analyzed "Last Analyzed",
          chain_cnt "Chain Cnt",
          freelists "Freelists",
          freelist_groups "Freelist Groups",
          blocks "Blocks",
          empty_blocks "Empty Blocks",
          num_freelist_blocks "Freelist Blocks",
          pct_free "PCT Free",
          pct_used "PCT Used",
          ini_trans "ini_trans"
   FROM   DBA_TABLES
   WHERE  last_analyzed IS NOT NULL
   AND    owner = ''##$$MYSCHEMA$$##''
   AND    table_name in (''MDP_MATRIX'', ''SALES_DATA'')
   AND    table_name NOT LIKE ''GLOB_%''
   AND    table_name NOT LIKE ''LOG_%''
   AND    table_name NOT LIKE ''DB%LOG''
   AND    table_name <> ''MDP_LOAD_ASSIST''',
  'Table Health Report',
  'RS',
  'If statistics are not current, this data may be flawed.',
  '<ul>
       If you are using Automatic Segment Space Management (ASSM), the database ignores attempts to change the PCTFREE and PCTUSED setting.
       If the chain count is greater that 20% consider analyzing the table.  If the statistics are current<br> 
       see [1528966.1], ''Demantra How to Use TABLE_REORG to Reorder MDP_MATRIX in Primary Key (PK) Order Action Plan Version 7.3.1.3 and Later.  See 1085012.1 Prior to 7.3.1.3.''
  </ul>',
  null,
  'ALWAYS',
  'W',
  'RS', 
  'N');


-------------------------------------------------------------------
-- HOST_URL_CHECK  
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'HOST_URL_CHECK',
  'select fnd_profile.value(''MSD_DEM_HOST_URL'') "Profile Host URL",
  (select pval from ##$$MYSCHEMA$$##.sys_params where lower(pname) = ''appserverurl'') "AppServerURL",
  (select decode(nvl(value_string,null),null,nvl(default_string,null),nvl(value_string,null))
    from ##$$MYSCHEMA$$##.aps_params where lower(pname) = ''server.generalurl'') "server.general",
  (select ''Values not Equal''
    from dual
    where not exists 
     (select fnd_profile.value(''MSD_DEM_HOST_URL'') from dual 
      where (select fnd_profile.value(''MSD_DEM_HOST_URL'') from dual) = (select pval from ##$$MYSCHEMA$$##.sys_params
                                                                          where lower(pname) = ''appserverurl''))
    or not exists 
     (select fnd_profile.value(''MSD_DEM_HOST_URL'') from dual
      where (select fnd_profile.value(''MSD_DEM_HOST_URL'') from dual) =  
     (select decode(nvl(value_string,null),null,nvl(default_string,null),nvl(value_string,null)) 
      from ##$$MYSCHEMA$$##.aps_params where lower(pname) = ''server.generalurl''))) "Should be Equal"
   from dual',
  'Compare MSD_DEM_HOST_URL, APS_PARAMS.server.generalurl, SYS_PARAMS.AppServerURL',
  'RS',
  null,
  '<ul>
       The values for the MSD_DEM_HOST_URL Profile and parameters AppServerURL and server.generalurl should match.  There should be no ''/'' at the end.<br>
       See [1389807.1], ''How to check problems in ASCP Demantra Supply Download Plan.''
   </ul>',
  null,
  'ALWAYS',
  'E',
  'RS');

-------------------------------------------------------------------
-- URL_REPORT  
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'URL_REPORT',
  'select pname "Parameter Name",  
          pval "Parameter Value"
   from msdem.sys_params
   where lower(pname) in (''appserverurl'', ''enginebaseurl'', ''engineplatform'', ''appserverlocation'', ''externallogouturl'', ''autorunmode'',
                          ''debug'', ''maxavailablefiltermembers'', ''systemstatus'', ''threadmode'')',
  'Verify SYS_PARAMS values',
  'RS',
  null, 
  '<ul>
       Verify the values as set in sys_params.
   </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');


  ------------------------------------------
  -- DB_WARNING_LOG
  ------------------------------------------
  add_signature(
   'DB_WARNING_LOG',
   'SELECT err_date "ERR_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(err_msg,1,70) "ERR_MSG"
    FROM ##$$MYSCHEMA$$##.db_warning_log
    WHERE rownum < 50
    order by err_date desc',
   'DB_WARNING_LOG',
   'RS',
   null,
   '<ul>
        These are the first 50 rows of the db_warning_log.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- DB_EXCEPTION_LOG
  ------------------------------------------
  add_signature(
   'DB_EXCEPTION_LOG',
   'SELECT err_date "ERR_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(err_msg,1,70) "ERR_MSG"
    FROM ##$$MYSCHEMA$$##.db_exception_log
    WHERE rownum < 50
    order by err_date desc',
   'DB_EXCEPTION_LOG',
   'RS',
   null,
   '<ul>
        These are the first 50 rows of the dp_exception_log.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');



  ------------------------------------------
  -- DB_AUDIT_LOG
  ------------------------------------------
  add_signature(
   'DB_AUDIT_LOG',
   'SELECT msg_date "MSG_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(msg,1,70) "MSG"
    FROM ##$$MYSCHEMA$$##.db_audit_log
    WHERE rownum < 50
    order by msg_date desc',
   'DB_AUDIT_LOG',
   'RS',
   null,
   '<ul>
        These are the first 50 rows of the db_audit_log.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- DB_CALL_LOG
  ------------------------------------------
  add_signature(
   'DB_CALL_LOG',
   'SELECT msg_date "MSG_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(msg,1,70) "MSG"
    FROM ##$$MYSCHEMA$$##.db_call_log
    WHERE rownum < 50
    order by msg_date desc',
   'DB_CALL_LOG',
   'RS',
   null,
   '<ul>
        These are the first 50 rows of the db_call_log.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- DB_DETAILED_SECTION_LOG
  ------------------------------------------
  add_signature(
   'DB_DETAILED_SECTION_LOG',
   'SELECT msg_date "MSG_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(msg,1,70) "MSG"
    FROM ##$$MYSCHEMA$$##.db_detailed_section_log
    WHERE rownum < 50
    order by msg_date desc',
   'DB_DETAILED_SECTION_LOG',
   'RS',
   null,
   '<ul>
            These are the first 50 rows of the db_detailed_section_log.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- DB_INFO_LOG
  ------------------------------------------
  add_signature(
   'DB_INFO_LOG',
   'SELECT msg_date "MSG_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(msg,1,70) "MSG"
    FROM ##$$MYSCHEMA$$##.db_info_log
    WHERE rownum < 50
    order by msg_date desc',
   'DB_INFO_LOG',
   'RS',
   null,
   '<ul>
            These are the first 50 rows of the db_info_log.
      </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- DB_SECTION_LOG
  ------------------------------------------
  add_signature(
   'DB_SECTION_LOG',
   'SELECT msg_date "MSG_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(msg,1,70) "MSG"
    FROM ##$$MYSCHEMA$$##.db_section_log
    WHERE rownum < 50
    order by msg_date desc',
   'DB_SECTION_LOG',
   'RS',
   null,
   '<ul>
           These are the first 50 rows of the db_section_log.
     </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- DB_SQL_LOG
  ------------------------------------------
  add_signature(
   'DB_SQL_LOG',
   'SELECT msg_date "MSG_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(msg,1,70) "MSG"
    FROM ##$$MYSCHEMA$$##.db_sql_log
    WHERE rownum < 50
    order by msg_date desc',
   'DB_SQL_LOG',
   'RS',
   null,
   '<ul>
          These are the first 50 rows of the db_sql_log.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- DB_TIMING_LOG
  ------------------------------------------
  add_signature(
   'DB_TIMING_LOG',
   'SELECT msg_date "MSG_DATE",
           substr(proc_name,1,30) "PROC_NAME",
           substr(msg,1,70) "MSG"
    FROM ##$$MYSCHEMA$$##.db_timing_log
    WHERE rownum < 50
    order by msg_date desc',
   'DB_TIMING_LOG',
   'RS',
   null,
   '<ul>
           These are the first 50 rows of the db_timing_log.
     </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- INTEG_STATUS
  ------------------------------------------
  add_signature(
   'INTEG_STATUS',
   'SELECT substr(username,1,15) "USER NAME",
           substr(process,1,30) "PROCESS",
           substr(stage,1,25) "STAGE",
           substr(status,1,25) "STATUS",
           substr(info,1,25) "INFO",
           status_date "STATUS_DATE"
    FROM ##$$MYSCHEMA$$##.integ_status
    WHERE rownum < 50
    order by status_date desc',
   'INTEG_STATUS',
   'RS',
   null,
   '<ul>
           These are the first 50 rows of the integ_status.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- LOG_IT_PARAMS
  ------------------------------------------
  add_signature(
   'LOG_IT_PARAMS',
   'SELECT substr(pname,1,30) "PROCESS NAME",
           log_table "LOG_TABLE",
           logging_level "LOGGING_LEVEL"
    FROM ##$$MYSCHEMA$$##.log_it_params
    order by pname',
   'LOG_IT_PARAMS',
   'RS',
   null,
   '<ul>
          These are the rows of the log_it_params.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- VERSION_DETAILS_HISTORY
  ------------------------------------------
  add_signature(
   'VERSION_DETAILS_HISTORY',
   'SELECT version "VERSION",
           build "BUILD",
           sp "SP",
           upgrade_date "UPGRADE_DATE"
    FROM ##$$MYSCHEMA$$##.version_details_history
    order by upgrade_date desc',
   'VERSION_DETAILS_HISTORY',
   'RS',
   null,
   '<ul>
        This is the version_details_history order by update_date descending.
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');



  ------------------------------------------
  -- WF_PROCESS_LOG
  ------------------------------------------
  add_signature(
   'WF_PROCESS_LOG',
   'select process_id "PROCESS ID",
           schema_id "SCHEMA ID",
           status "STATUS",
           substr(step_id,1,25) "STEP ID",
           num_steps "NBR STEPS",
           record_created "CREATED",
           record_updated "UPDATED"
    from ##$$MYSCHEMA$$##.wf_process_log
    order by record_created',
   'WF_PROCESS_LOG',
   'RS',
   null,
   '<ul>
          This is the first 50 rows of wf_process_log order by record_created descending.
          <br>wf_process_log.status<br>
           -3 = ENDLESS_LOOP<br>
           -2 = FAILED<br>
           -1 = TERMINATED<br>
            0 = COMPLETED<br>
            1 = ACTIVE<br>
            2 = PAUSED<br>
    </ul>',
   null,
   'ALWAYS',
   'W',
   'RS');


  ------------------------------------------
  -- PRE_LOGON_CHECK
  ------------------------------------------
  add_signature(
   'PRE_LOGON_CHECK',
   'select pname "Parameter Name",
           pval "Value"
    from ##$$MYSCHEMA$$##.db_params
    where lower(pname) like ''plpi%''',
   'PRE Logon Settings if present',
   'RS',
   null,
   '<ul>
        Parameters can be set upon Demantra log in.  These are known as pre_logon parameters.  They can also be added to the DB_PARAMS table<br>
        as new pre_logon parameters with the prefix of ''plpi_''.<br>
      ''plpi'' = pre_logon parameter using integer value<br>
      ''plp''  = pre_logon parameter using string  value<br>
        For example:<br> 
          insert into DB_PARAMS (pname, pval) values (''plpi_optimizer_index_cost_adj'',''40'');<br>
          insert into DB_PARAMS (pname, pval) values (''plpi_optimizer_index_caching'', ''75'');<br>
          commit;<br>
        Then rebuild pre_logon via SQL>exec BUILD_PRE_LOGON;  You can use SQL>exec BUILD_PRE_LOGON(''FORCE''); if required.<br>
          You must wait for the job to complete before running PRE_LOGON via SQL>exec pre_logon;<br>
          The new pre_logon procedure should contain additions similar to this :<br>
      vi_plp_optimizer_index_cost_a  := ''40'';<br>
      vi_plp_optimizer_index_cachin  := ''75'';<br>
      See [1906641.1], ''Performance Issue With Chaining After Upgrade To 12.2.3.''
    </ul>',
   'There are no pre_logon parameters set.',
   'ALWAYS',
   'W',
   'RS');



--------------------------------------------------------------------
-- STATSLOWROWLIMIT
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'STATSLOWROWLIMIT',
  'select trim(pval) "StatsLowRowLimit"
   from ##$$MYSCHEMA$$##.db_params
   where lower(pname) = ''statslowrowlimit''',
  'StatsLowRowLimit',
  'RS',
  'This parameter, which will cause EP_CHECK_ITEMS and EP_LOAD_ITEMS to gather stats on the table whenever it has less than 100,000 rows.',
  '<ul>
       You may be concerned that this recommendation would change the stats collection and the potential performance behavior for many tables.<br> 
       This recommendation will change the statistics only if the table has less then 100,000 rows.  All these tables are from ep_load process.<br>
       You can see below the tables list:<br>
       EP_CHECK_ITEMS: - All tables from this query result<br>
       SELECT DISTINCT ept.table_name, ut.num_row<br>
       FROM   e_plan_tree ept, user_tables ut<br>
       WHERE  model_version         = 15<br>
       AND    UPPER(ept.table_name) = UPPER(ut.table_name);<br>
       EP_LOAD_ITEMS: - All tables from this query result<br>
         SELECT UPPER(table_name) table_name<br>
         FROM   ep_model_syntax<br>
         WHERE  dim_type = 1;<br>
  </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');


--------------------------------------------------------------------
-- GATHERSTATISTICSTHRESHOLD
--------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'GATHERSTATISTICSTHRESHOLD',
  'select trim(pval) "Gather_statistic"
   from ##$$MYSCHEMA$$##.sys_params
   where lower(pname) = ''gatherstatisticsthreshold''',
  'GatherStatisticsThreshold for temp tables.',
  'RS',
  'Controlling TEMP table statistics based on the setting of sys_params.GatherStatisticsThreshold',
  '<ul>
         When the paramter = 0 the application server DOES NOT gather statistics on any table it creates, T_COMB% temporary tables.<br>
         If GatherStatisticsThreshold is set to a value larger than zero, for example 5, the the application server was started and a worksheet was<br>
         opened  that contains at least 5 combinations, the T_COMB% temp table WAS analyzed<br>
         If the value is set to -1, the T_COMB% tables are analyzed by force.<br>
         See [2008076.1], ''User Not Able To Save Data In Demantra.''
  </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');


-------------------------------------------------------------------
-- ENCRYPTION_TYPE_CHECK
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'ENCRYPTION_TYPE_CHECK',
  'SELECT distinct ENCRYPTION_TYPE "Encryption_type"
   FROM ##$$MYSCHEMA$$##.USER_ID',
  'Verify Encryption',
  'RS',
  null,
  '<ul>
       This should return SHA-1 only.  Should this return any other value<br>
          see [1485622.1], ''Invalid Username or Password while attempt to log into the Demantra Business Modeler.''
   </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');


-------------------------------------------------------------------
-- DBA_TAB_PRIVS
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'DBA_TAB_PRIVS',
  'select GRANTEE,
          OWNER,
          GRANTOR,
          PRIVILEGE,
          GRANTABLE
   FROM DBA_TAB_PRIVS 
   where grantee = ''##$$MYSCHEMA$$##''',
  'Verify Privileges Granted',
  'RS',
  null,
  '<ul>
       Review the privileges granted.<br>
       See [454369.1], ''Roles and Privileges that are granted to the Demantra 10g database during the install process.''<br>
       And [730883.1], ''Additional Database Privilege needed for Demantra Schema when Running on Oracle 11g Database.''
   </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');


-------------------------------------------------------------------
-- ACL_SUCCESS
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'ACL_SUCCESS',
  'select trim(host) "Host",
   lower_port "Lower_Port",
   upper_port "Upper_Port"
   from dba_network_acls',
  'Verify ACL Granted',
  'RS',
  null,
  '<ul>
       Review the privileges granted.<br>
       See [730883.1], ''Additional Database Privilege needed for Demantra Schema when Running on Oracle 11g Database.''
   </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');


-------------------------------------------------------------------
-- TEMPORARY_TABLES
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'TEMPORARY_TABLES',
  'SELECT OBJECT_TYPE "Type", 
          OBJECT_NAME "Name"
   FROM USER_OBJECTS
   WHERE (SUBSTR (OBJECT_NAME, 1, 3) = ''TMP''
   OR SUBSTR (OBJECT_NAME, 1, 5) = ''TEMP_''
   OR SUBSTR (OBJECT_NAME, 1, 7) = ''EP_TMP_''
   OR SUBSTR (OBJECT_NAME, 1, 9) = ''TEMPTABLE''
   OR SUBSTR (OBJECT_NAME, 1, 8) = ''T_AUDIT_''
   OR SUBSTR (OBJECT_NAME, 1, 6) = ''T_WEB_''
   OR SUBSTR (OBJECT_NAME, 1, 7) = ''T_COMB_''
   OR SUBSTR (OBJECT_NAME, 1, 8) = ''T_DATES_''
   OR SUBSTR (OBJECT_NAME, 1, 7) = ''T_DATE_''
   OR SUBSTR (OBJECT_NAME, 1, 7) = ''T_POPU_''
   OR SUBSTR (OBJECT_NAME, 1, 9) = ''T_UPDATE_''
   OR SUBSTR (OBJECT_NAME, 1, 7) = ''T_BIIO_''
   OR SUBSTR (OBJECT_NAME, 1, 3) = ''DW_''
   OR SUBSTR (OBJECT_NAME, 1, 11) = ''GROUP_LIST_''
   OR SUBSTR (OBJECT_NAME, 1, 6) = ''CROSS_''
   OR SUBSTR (OBJECT_NAME, 1, 8) = ''MAN_INT_''
   OR SUBSTR (OBJECT_NAME, 1, 8) = ''MAN_POP_''
   OR SUBSTR (OBJECT_NAME, 1, 4) = ''PDE_''
   OR SUBSTR (OBJECT_NAME, 1, 12) = ''MDPTEMPTABLE''
   OR SUBSTR (OBJECT_NAME, 1, 15) = ''INTERM_RESULTS_''
   OR SUBSTR (OBJECT_NAME, 1, 14) = ''NODE_FORECAST_''
   OR SUBSTR (OBJECT_NAME, 1, 9) = ''WEB_VIEW_''
   AND SUBSTR (OBJECT_NAME, 1, 16) = ''TMP_EXCLUDE_LIST''
   AND SUBSTR (OBJECT_NAME, 1, 17) = ''CHECK_OBJECT_LIST''
   AND SUBSTR (OBJECT_NAME, 1, 19) = ''EP_COMPILE_PROC_TMP'') 
   AND OBJECT_TYPE IN (''TABLE'', ''VIEW'')',
  'Temporary Database Segments',
  'RS',
  null,
  '<ul>
       The DROP_TEMPS procedure deletes temporary database tables that are created, for example, when modifying worksheets, launching integration profiles, or running the Analytical Engine.  This is the list of tables that are included in the cleanup.  Review the following note before dropping:<br>
          See [1304666.1], ''What Are The Objects Affected by the DROP_TEMPS Procedure?''<br>
          See [1964291.1], ''For RDF temporary segments.''<br><br>
''TMP'', ''TEMP_'', ''EP_TMP_'', ''TEMPTABLE'', ''T_AUDIT_'', ''T_WEB_'', ''T_COMB_'', ''T_DATES_'', ''T_DATE_'', ''T_POPU_'', ''T_UPDATE_''<br>
''T_BIIO_'', ''DW_'', ''GROUP_LIST_'', ''CROSS_'', ''MAN_INT_'', ''MAN_POP_'', ''PDE_'', ''MDPTEMPTABLE'', ''INTERM_RESULTS_'', ''NODE_FORECAST_''<br>
''WEB_VIEW_'', ''TMP_EXCLUDE_LIST%'', ''CHECK_OBJECT_LIST%'', ''EP_COMPILE_PROC_TMP%''
   </ul>',
  null,
  'ALWAYS',
  'W',
  'RS');




-------------------------------------------------------------------
--  MIN_DATE_SALES_DATA 
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'MIN_DATE_SALES_DATA',
  'select min(sales_date) "Min_Sales_Date"
   from ##$$MYSCHEMA$$##.sales_data',
  'Minimum SALES_DATE in SALES_DATA',
  'RS',
  null,
  '<ul>
       Verify the existing history that could be archived.<br>
       See [1423486.1], ''How to Setup Series. Copy Series. Display in a worksheet. Aggregation.''
   </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');


-------------------------------------------------------------------
--  INSTANCE_REPORT  
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'INSTANCE_REPORT',
  'select upper(instance_name) "Instance",
          substr(host_name,1,35) "Host",
          version "Version",
          status "Status",
          log_switch_wait "Log Wait",
          database_status "RDBMS Status",
          release_name "Release Name",
          applications_system_name "Application Name"
   from v$instance,
        fnd_product_groups',
  'Instance Information',
  'RS',
  null,
  '<ul>
       This information is taken directly from v$instance.<br>
       Status reveals the open - close status of the database.  RDBMS Status reveals if the instance is active.
   </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');



-------------------------------------------------------------------
--  CURRENT_SCHEMA
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'CURRENT_SCHEMA',
  'select fnd_profile.value(''MSD_DEM_SCHEMA'') "Demantra Schema"
   from dual',
  'Current Schema',
  'RS',
  null,
  '<ul>
       Verify your chosen schema via the Profile Option MSD: Schema.<br>
       Technical, fnd_profile.value(''MSD_DEM_SCHEMA'').
   </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');


-------------------------------------------------------------------
--  AVAILABLE_SCHEMAS
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'AVAILABLE_SCHEMAS',
  'select owner "Schema Owner",
   table_name "Table"
   from dba_tables 
   where table_name like ''SALES_DATA''',
  'Available Schemas',
  'RS',
  null,
  '<ul>
       Available schemas as indicated by the owners of the SALES_DATA table.
   </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');


-------------------------------------------------------------------
--  ENV_PARAMETERS  
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'ENV_PARAMETERS',
  'select name "Name",
          value "Value"
   from v$parameter
   where name in (''optimizer_mode'',''cursor_sharing'',''db_file_multiblock_read_count'', ''processes'', ''sessions'',''db_name'',''cpu_count'',
                  ''disk_asynch_io'',''service_names'')',
  'V$Parameter Values, CPU Count, Service_Names, etc',
  'RS',
  null,
  '<ul>
       These parameter settings are from v$parameter.  Please note as you review Demantra specific parameters.
   </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');


-------------------------------------------------------------------
--  CONNECTION_PARAMETERS  
-------------------------------------------------------------------
-- PSD #9a
  add_signature(
  'CONNECTION_PARAMETERS',
  'select pname, decode(value_number,null,0,value_number) "Value"
   from ##$$MYSCHEMA$$##.aps_params
   where lower(pname) in (''maxdbconnections'', ''mindbconnections'', ''dbidletimeout'', ''dbconnectiontimeout'')',
  'Connection Specific values from APS_PARAMS',
  'RS',
  null,
  '<ul>
    <li>These parameter settings are from v$parameter.  Please note as you review Demantra specific parameters.</li>
    <ol><li>maxdbconnections<br>
         It is important to make sure that the application server will have all the needed threads to execute all parallel requests; query executions,<br>
         workflow runs, updates, etc.  A rule of thumb will be<br>
         the number of concurrent users * threadpool.query_run.per_user *10 (if threadpool.query_run.per_user > 4).</li>
       <li>mindbconnections<br>
           The minimum number of database connections for the Demantra database user.</li>
       <li>dbidletimeout<br>
           The connection idle timeout period.  Recommended: 300000 (5 minutes).</li>
       <li>dbconnectiontimeout<br>
           The database connection timeout period.
    </li></ol>
   </ul>',
  null,
  'ALWAYS',
  'I',
  'RS');


-------------------------------------------------------------------
--  LOG_SWITCH_PROFILE
-------------------------------------------------------------------
-- PSD #9a

  add_signature(
  'LOG_SWITCH_PROFILE',  
  'SELECT
    SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH:MI:SS''),1,5)  "DAY(Month/Day)"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''00'',1,0)) "H00"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''01'',1,0)) "H01"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''02'',1,0)) "H02"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''03'',1,0)) "H03"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''04'',1,0)) "H04"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''05'',1,0)) "H05"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''06'',1,0)) "H06"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''07'',1,0)) "H07"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''08'',1,0)) "H08"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''09'',1,0)) "H09"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''10'',1,0)) "H10"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''11'',1,0)) "H11"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''12'',1,0)) "H12"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''13'',1,0)) "H13"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''14'',1,0)) "H14"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''15'',1,0)) "H15"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''16'',1,0)) "H16"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''17'',1,0)) "H17"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''18'',1,0)) "H18"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''19'',1,0)) "H19"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''20'',1,0)) "H20"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''21'',1,0)) "H21"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''22'',1,0)) "H22"
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH24:MI:SS''),10,2),''23'',1,0)) "H23"
  , COUNT(*) "TOTAL"
FROM
  v$log_history  a
GROUP BY SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH:MI:SS''),1,5)
ORDER BY SUBSTR(TO_CHAR(first_time, ''MM/DD/RR HH:MI:SS''),1,5) desc',
  'LOG_SWITCH_PROFILE',
  'RS',
  'Please review performance related profile documents.',
  '<ul>
       A checkpoint is when the database writes changed data to disk.  Until the write occurs the data is stored in the log.  TLOG_CHECKPOINT_INTERVAL, LOG_CHECKPOINT_TIMEOUT<br>
	   and redo log size and quantity regulate how often this activity occurs.  If the checkpoint occurs infrequently it will take longer to recover the database in the event<br>
	   of a crash.  This is because the recovery process would have to apply more data from the redo logs.  If the checkpoint occurs too often the database can be<br>
	   overwhelmed with various background processes that become a bottleneck.  Oracle recommends 4-5 log switches per hour.wo LOG_CHECKPOINT parameters you mention govern how<br>
	   often this activity occurs.<br><br>
	   Please see [1035935.6] ''Example of How To Resize the Online Redo Logfiles.''
  </ul>',
   null,
  'ALWAYS',
  'I',
  'RS');

-------------------------------------------
-- End of example signatures
-------------------------------------------	 
-- PSD #9b
-- end	


EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main  IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
  
  -- PSD #11
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'Demantra Performance';

  l_step := '20';
 -- PSD #12
  validate_parameters;

  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #13
  /* 
  start_section('Proactive Recommendations');
     set_item_result(check_rec_patches);
  end_section;
  */

   start_section('Your Environment');
        set_item_result(run_stored_sig('INSTANCE_REPORT'));
        set_item_result(run_stored_sig('CURRENT_SCHEMA'));
        set_item_result(run_stored_sig('AVAILABLE_SCHEMAS'));
        set_item_result(run_stored_sig('ENV_PARAMETERS'));
        set_item_result(run_stored_sig('CONNECTION_PARAMETERS'));
   end_section;

   start_section('Data Specific');
        set_item_result(run_stored_sig('DEAD_COMBINATIONS'));
	set_item_result(run_stored_sig('PREDICTION_STATUS_IMPACT'));
	set_item_result(run_stored_sig('PREDICTION_STATUS_ANALYSIS'));
	set_item_result(run_stored_sig('UPDATE_COMBINATIONS'));
	set_item_result(run_stored_sig('FORECAST_LEVEL_STRUCTURE'));
	set_item_result(run_stored_sig('MISSING_SALES_DATA'));
-- commented the below for performance reasons.  Looking for a better solution.
--	set_item_result(run_stored_sig('MISSING_MDP_MATRIX'));
	set_item_result(run_stored_sig('INSERT_UNITS_CHECK'));
        set_item_result(run_stored_sig('FORECAST_HISTORY_STATUS'));
        set_item_result(run_stored_sig('MAX_SALES_DATE_SALES_DATA'));
        set_item_result(run_stored_sig('UPDATE_COMBINATIONS_2'));
        set_item_result(run_stored_sig('MIN_DATE_SALES_DATA'));
   end_section;  
  
  start_section('Import - Export');
        set_item_result(run_stored_sig('EBS_ITEM_IMPORT_ERRORS'));
	set_item_result(run_stored_sig('LEGACY_ITEM_IMPORT_ERRORS'));
        set_item_result(run_stored_sig('EBS_LOCATION_IMPORT_ERRORS'));
	set_item_result(run_stored_sig('EBS_SALES_IMPORT_ERRORS'));
	set_item_result(run_stored_sig('BIIO_CTO_DATA_ERR'));
	set_item_result(run_stored_sig('BIIO_CTO_POPULATION_ERR'));
        set_item_result(run_stored_sig('BIIO_CTO_LEVEL_ERR'));
        set_item_result(run_stored_sig('STATSLOWROWLIMIT'));
  end_section;
  
  start_section('Parameters/Permissions');
         set_item_result(run_stored_sig('PERFORMANCE_PARAMETERS'));
	 set_item_result(run_stored_sig('APPLICATION_SERVER_PARAMETERS'));
	 set_item_result(run_stored_sig('APPSERVERURL'));
	 set_item_result(run_stored_sig('APPROVALPROCESSSCOPE'));
	 set_item_result(run_stored_sig('OPTIMIZER_INDEX_CACHING'));
         set_item_result(run_stored_sig('OPTIMIZER_INDEX_COST_ADJ'));
         set_item_result(run_stored_sig('OPT_CAPTURE_SQL_PLAN_BASELINES'));
         set_item_result(run_stored_sig('OPTIMIZER_USE_SQL_PLAN_BASELINES'));
         set_item_result(run_stored_sig('_B_TREE_BITMAP_PLANS'));
	 set_item_result(run_stored_sig('MAXENGMEMORY'));
	 set_item_result(run_stored_sig('BLOCKSIZE_CHECK'));
	 set_item_result(run_stored_sig('ACL_PRIVILEGE_CHECK'));
	 set_item_result(run_stored_sig('ENCRYPTION_TYPE_CHECK'));
	 set_item_result(run_stored_sig('NLS_DATE_FORMAT_CHECK'));
	 set_item_result(run_stored_sig('RUNINSERTUNITS_PARAMETER'));
	 set_item_result(run_stored_sig('TIME_CONTROL_APS_PARAMS'));
	 set_item_result(run_stored_sig('HOST_URL_CHECK'));
	 set_item_result(run_stored_sig('GATHERSTATISTICSTHRESHOLD'));
  end_section;  
  
  start_section('Worksheet/Dates');
         set_item_result(run_stored_sig('UI_WORKSHEET_LIMITATIONS'));
 	 set_item_result(run_stored_sig('THREADPOOL_CHECK'));
 	 set_item_result(run_stored_sig('THREADPOOL.QUERY_RUN.PER_USER'));
 	 set_item_result(run_stored_sig('MAXDBCONNECTIONS'));
	 set_item_result(run_stored_sig('MAXUPDATETHREADS'));
	 set_item_result(run_stored_sig('NO_HISTORY_COMBINATIONS'));
  	 set_item_result(run_stored_sig('COMBINATIONS_DATE_RANGE_CHECK'));
         set_item_result(run_stored_sig('CT_WS_CALCSUMMARYEXPRESSIONS'));
         set_item_result(run_stored_sig('WS_DATA_COMB_BLOCK_SIZE'));
         set_item_result(run_stored_sig('MAXAVAILABLEFILTERMEMBERS'));
         set_item_result(run_stored_sig('KEY_DATE_PARAMETERS'));
         set_item_result(run_stored_sig('EMAIL_SETUP_CHECK'));
  end_section;

  start_section('RDBMS');
	 set_item_result(run_stored_sig('TABLESPACE_CHECK'));
         set_item_result(run_stored_sig('TABLESPACES'));
	 set_item_result(run_stored_sig('DEMANTRA_INVALIDS'));
	 set_item_result(run_stored_sig('TABLE_HEALTH'));
	 set_item_result(run_stored_sig('CLUSTER_FACTOR_SALES_DATA'));
	 set_item_result(run_stored_sig('SALES_DATA_CHAIN_ROWS_PERCENT'));
	 set_item_result(run_stored_sig('MDP_MATRIX_CHAIN_ROWS_PERCENT'));
	 set_item_result(run_stored_sig('DEMANTRA_CHAIN_ROWS_PERCENT'));
	 set_item_result(run_stored_sig('PRE_LOGON_CHECK'));
	 set_item_result(run_stored_sig('ACL_SUCCESS'));
	 set_item_result(run_stored_sig('ENCRYPTION_TYPE_CHECK'));
	 set_item_result(run_stored_sig('DBA_TAB_PRIVS'));
	 set_item_result(run_stored_sig('LOCKED_DATABASE_OBJECTS'));
	 set_item_result(run_stored_sig('TEMPORARY_TABLES'));
	 set_item_result(run_stored_sig('LOG_SWITCH_PROFILE'));
  end_section;

   start_section('LOGs + Version');
        set_item_result(run_stored_sig('DB_WARNING_LOG'));
        set_item_result(run_stored_sig('DB_AUDIT_LOG'));
        set_item_result(run_stored_sig('DB_CALL_LOG'));
        set_item_result(run_stored_sig('DB_DETAILED_SECTION_LOG'));
        set_item_result(run_stored_sig('DB_EXCEPTION_LOG'));
        set_item_result(run_stored_sig('DB_INFO_LOG'));
        set_item_result(run_stored_sig('DB_SECTION_LOG'));
        set_item_result(run_stored_sig('DB_SQL_LOG'));
        set_item_result(run_stored_sig('DB_TIMING_LOG'));
        set_item_result(run_stored_sig('INTEG_STATUS'));
        set_item_result(run_stored_sig('LOG_IT_PARAMS'));
        set_item_result(run_stored_sig('VERSION_DETAILS_HISTORY'));
        set_item_result(run_stored_sig('WF_PROCESS_LOG'));
   end_section;  

  
  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/thread/xxxxxx" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
  IF g_is_concurrent THEN
     l_completion_status:=FND_CONCURRENT.SET_COMPLETION_STATUS('NORMAL','');
  END IF;

EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
  IF g_is_concurrent THEN
     l_completion_status:=FND_CONCURRENT.SET_COMPLETION_STATUS('ERROR',g_errbuf);
  END IF;

END main;

-------------------------------------------
-- MAIN ENTRY POINT FOR CONCURRENT PROCESS
-- uncomment to run from concurrent program
-- edit list of variables to match MAIN
-- <package>.main_cp will be what you define program to call
-------------------------------------------
-- PSD #16	
PROCEDURE main_cp(
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2
      ) IS

BEGIN
  g_retcode := 0;
  g_errbuf := null;

-- PSD #17  
  main;

  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


-- PSD #1
END demantra_perf_pkg;
/
show errors
exit;