# $Id: Update.pm 200.3 2015/12/15 kjharris $
# +===========================================================================+
# |  Copyright (c) 2015 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# |
# | FILENAME: Update.pm
# |
# | Container for subs to do analyzer bundle updates 
# | 
# | PLATFORM
# |   Unix Generic
# |
# | NOTES
# |
# | HISTORY
# | 200.0 Creation (Nov-11-2014) 
# | 200.1 Creation (Unzip Fixes, creation of the archive directory) 
# | -- all unzipped files (successful) are moved to update/archive/ 
# | 200.2 
# |  --> Fixed Sorting in Pick List Menus 
# |  --> Added in pages-style / tabbed functionality into pick lists. 
# | 200.3 
# | --> Added alphabetical sorting in pickList 
# | 
# +===========================================================================+

use Cwd; 

# +---------------------------
# | Sub updateMenu
# +---------------------------
# | the menu displayed after the user chooses "updates" from the main menu. 
# |
# +---------------------------
sub updateMenu
{
	my $userSel; 
	until (2 == 1) 
	{
		my $countDepth = $dir =~ tr/\///;
		system("clear"); 
		print "\n\n               ", RESET; 
		print BOLD WHITE ON_BLUE "Analyzer Bundle Updates Menu", RESET, "\n\n"; 
	
		print "   [1] Begin Update\n"; 
		
		print "   ...\n"; 
		print BOLD WHITE ON_BLUE "\n  [B]ack | [H]elp | E[x]it\n"; 
		print BOLD WHITE ON_YELLOW "\n Invalid Selection", RESET if $userSel eq 'invalid'; 
		print "\n  Selection:"; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i;
		
		if ($userSel =~ /^b{1}/i)
		{
			return(); 
		}
		elsif ($userSel == 1)
		{
			#autoUpdate(); 
			beginUpdate(); 
		}
		# elsif	($userSel == 2)
		# {
			# manualUpdate(); 
		# }
		elsif ($userSel =~ /^h{1}/i)
		{ 
				system ("clear"); 
				print "\n"; 
				print BOLD WHITE ON_BLUE "  Updates Menu Help", RESET, "\n"; 
				print qq (
  o [1] Begin Update 
 
  Starts the update process by looking at the MENU/update/ directory for 
  valid bundle zip files. If there is a bundle zip file in that directory 
  which has a higher version than the current version, the user is prompted
  to use that version or check My Oracle Support for a newer version. Once 
  a bundle zip has been established, it is unzipped into MENU/ and a restart
  of Menu.pl is required. Once the restart is completed, a list is provided 
  pick which Analyzers are reinstalled. 

  Press [Enter] to Continue:); 
my $z=<STDIN>;
		
		}
		else
		{
			$userSel = 'invalid'; 
		}
	} #end until loop 

}

# +---------------------------+
# | sub: beginUpdate 
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub beginUpdate 
{
	my ($mode) = (@_);
	# --> check for updated bundle.zip in update dir 
	my ($latestZipFile, $latestZipVer) = getHighVersionBundle(); 
	my $currVer = getBundleVer(); 
	prnt2Log("INFO: running beginUpdate()");
	if ($mode eq 'R')
	{
		my $status; 
		unlink ('.update');
		prnt2Log "\n\n   INFO: Resuming Update. \n"; 
		print "\n\n   INFO: Resuming Update. Press [Enter]: "; 
		<STDIN>; 
		$status = pickListMenu('update'); 
		if ($status == 0) 
		{
			prnt2LogSTDOUT "\n\n   INFO: Update successful \n"; 
			return(0); 
		}
		else 
		{
			prnt2LogSTDOUT "\n\n   ERROR: Update failed. \n"; 
			return(1); 
		}
	}

	my $userSel;
	# if the updated bundle.zip is newer, use it or prompt to check for new? 
	if (defined $latestZipFile)
	{
		system("clear"); 
		until ($userSel =~ /^u{1}$/i || $userSel =~ /^d{1}$/i || $userSel =~ /^b{1}$/i)
		{
			print "   INFO: Found file: $latestZipFile, version: \'$latestZipVer\' \n";
			print "   INFO: You are currently using bundle version: \'$currVer\' \n"; 
			
			my ($minorVersCurr, $minorVersNew); 
			$minorVersCurr = $+ if $currVer =~ /\d{3}\.(\d{1,4})/; 
			$minorVersNew = $+ if $latestZipVer =~ /\d{3}\.(\d{1,4})/; 
			
			print "   WARNING: The current Bundle is newer or equal to $latestZipFile\n\n   Updating is NOT recommended.\n\n" if $minorVersCurr >= $minorVersNew; 
			print "   INFO: The current Bundle is lower than $latestZipFile\n\n   Updating is recommended.\n\n" if $minorVersCurr < $minorVersNew; 
			print "\n  Use this bundle or attempt to download* a newer one?\n    [*requires My Oracle Support connectivity]\n\n";
			print BOLD WHITE ON_BLUE "  [U]se | [B]ack | [D]ownload",RESET ;
			print BOLD WHITE ON_YELLOW "  Invalid Selection", RESET if defined $userSel; 
			print "\n\n   Selection:"; 
			chomp($userSel = <STDIN>); 
			system("clear");
		}
	}
	else #didn't get a zip version 
	{
		until ($userSel =~ /^u{1}$/i || $userSel =~ /^d{1}$/i || $userSel =~ /^b{1}$/i)
		{
			system("clear"); 
			print "\n\n   INFO: No valid Bundle zip file was found in \'MENU/update\' \n   [D]ownload from Doc ID: 1939637.1?\n\n"   ; 
			print BOLD WHITE ON_BLUE "  [D]ownload   [B]ack  ",RESET ;
			print BOLD WHITE ON_YELLOW "  Invalid Selection", RESET if defined $userSel;  
			print "\n\n   Selection:"; 
			chomp($userSel = <STDIN>);
			system("clear"); 
		} 
	}
	
	if ($userSel =~ /^d{1}/i)
	{
		#download 
		my $status = getBundleUpdate(); 
		if ($status == 0) 
		{
			my ($zip) = getHighVersionBundle(); 
			my $status = unzipBundle($zip); #the file name when automatically downloaded will always be bundle.zip  
			if ($status == 0) 
			{
				_reboot(); 
			}
			else
			{
				print "\n\n   ERROR: Unzip failed, cannot continue.\nPress [Enter]:"; 
				<STDIN>; 
				return(); 
			}
		}
		else 
		{
			print "\n\n   ERROR: Failed to download new Bundle. \n   Download the bundle manually from Doc ID: 1939637.1\n   and place the zip into the MENU/update directory. \n   Then retry the update process selecting the [U]se option when prompted.  \n\n   Press [Enter] to Continue:"; 
			<STDIN>;
			return(); 
		}
		
	}
	elsif ($userSel =~ /^b{1}/i)
	{
		return(); 
	}
	
	elsif ($userSel =~ /^u{1}/i)
	{
		#use the existing MENU/update/bundle.zip 
		#unzip $latestZipFile 
		prnt2LogSTDOUT("   INFO: Unzipping new Bundle..\n"); 
		my $status = unzipBundle($latestZipFile); 
		if ($status == 0) 
		{
			_reboot(); 
		}
		else
		{
			print "\n\n   ERROR: Unzip failed, cannot continue.\nPress [Enter]:";
			<STDIN>;
			return(); 
		}
		
	}
	
	
	# -----> if the in-place bundle.zip isn't avail or old, then attempt a download 
	# -------> If the download fails, prompt them to download manually and put it in the update dir 
	# ---> Unzip 
	# --> Run pick list 
	# --> 
	#private sub 
	sub _reboot
	{
		# reboot 
		open (my $fh, '>', '.update' ) || die "beginUpdate(): Cannot create .update: $! \n"; 
		close $fh; 
		print "\n\n   INFO: Next task: Reinstall Concurrent Programs\n   A menu will be displayed upon restart\n\n   Menu.pl needs to be restarted using \'perl Menu.pl\' \n   The update process will resume after the restart. \n\n";
		exit;
	}
}


# +---------------------------+
# | sub:  pickListMenu
# +---------------------------+
# | Desc: Displays the list of installed analyzers 
# +---------------------------+
# | Args: 
# | mode = 'bulk' for bulk load 
# | mode = 'show' for show installed analyzers 
# | mode = 'update" for update pick list. 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub pickListMenu
{
	my ($mode, $dir) = @_; 
	#CCPs is hash: 
	my ($analyzers);
	undef %$analyzers; 
	($analyzers) = getInstalledCCPs() if $mode ne 'bulk';
	my $height = `tput lines`; 
	my $width = `tput cols`;  
	my $pageSize = ($height - 7); 
	
	my $userSel; 
	my $invSel = 0;
	my $change; 
	
	if ($analyzers == 1 && $mode ne 'bulk')
	{
		#no analyzers found 
		system("clear"); 
		print BOLD WHITE ON_BLUE "\n\n   No Analyzer Concurrent Programs Installed", RESET, "\n  Press [Enter] to Continue:";
		<STDIN>; 
		return(); 
	}
	
	if ($mode eq 'update') 
	{
		getNewAnalyzers(\%$analyzers); 
		foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
		{
			#if either of the versions could not be detected, default to reload 
			if ($$analyzers{$ID}->{'CURRFILEVER'} =~ /null|new/ || $$analyzers{$ID}->{'NEWFILEVER'} eq '<null>')
			{
				$$analyzers{$ID}->{'SELECTED'} = '+';
			}
			else
			{
				my ($status, $action) = compVersions($$analyzers{$ID}->{'NEWFILEVER'}, $$analyzers{$ID}->{'CURRFILEVER'}); 
				#action will be replace, same or existing_higher 
				#status of 1 means version check could not be performed 
				
				# print "buggin.. $$analyzers{$ID}->{'FILE'}\n"; 
				# if ($$analyzers{$ID}->{'FILE'} =~ /workflow_analyzer/)
				# {
					# $DB::single = 1; 
				# }
				
				
				if ($status == 0 && $action eq 'replace')
				{
					$$analyzers{$ID}->{'SELECTED'} = '+';
				}
				else
				{
					$$analyzers{$ID}->{'SELECTED'} = ' ';
				}
			}
		}
	}

# The following "if" section is used for updates. If the mode is 'show'
# that is used for the Main Menu Option - show installed analyzers 
#
if ($mode eq 'update')
{
	$pageSize = ($height - 8); 
	my $currPage = 1; 
	my $maxPage = (ceil(scalar(keys %$analyzers)/$pageSize)); 
	my $ID = 1; 
	my $newCount = 0; 
	until (1 == 2) 
	{
		my ($spc1, $spc2, $verLgth); 
		system("clear"); 
		print "\n                         "; 
		print BOLD WHITE ON_BLUE "Update Concurrent Programs", RESET;
		print "        "; 
		print BOLD WHITE ON_GREEN "\n Legend: [+] = Selected To be Updated", RESET;
		print "              "; 
		print BOLD WHITE ON_GREEN " [Page $currPage of $maxPage]",RESET;
		print BOLD WHITE ON_BLUE "\n  \#  SELECTED  FAM: TITLE                             INSTALLED | NEW ", RESET, "\n";   
		$| = 1;
		for ($ID; $ID <= ($pageSize * $currPage); $ID++)
		{
			next if length($$analyzers{$ID}->{'FAM'}) < 3;
			$newCount++ if $$analyzers{$ID}->{'CURRFILEVER'} =~ /NONE/ && $$analyzers{$ID}->{'NEWFILEVER'} =~ /^\d/; 
			print BOLD WHITE ON_GREEN "\n Legend: [+] = Selected To be Installed (New Analyzers)" if $newCount == 1;
			print BOLD WHITE ON_BLUE "\n  \#  SELECTED  FAM: TITLE                             INSTALLED | NEW ", RESET, "\n" if $newCount == 1;
			$spc1 = "  " if $ID > 9;
			$spc1 = "   " if $ID <= 9;
			my $title = $$analyzers{$ID}->{'FAM'} . ': ' . $$analyzers{$ID}->{'CCPTITLE'}; 
			my $length=length($title) + length("[$ID]") + length($spc1);   
			if ($length > 42) 
				{ $title = substr($title, 0, 36); $title .= "..."; } 
			my $tabs; 
			
			$tabs = "\t\t\t\t" if $length > 14 && $length <= 21;
			$tabs = "\t\t\t" if $length > 21 && $length <= 28; 
			$tabs = "\t\t" if $length > 28	&& $length <= 37; 
			$tabs = "\t" if $length > 37;   
			$verLgth = length($$analyzers{$ID}->{'CURRFILEVER'}); 
			$spc2 = "   | " if $verLgth == 5;
			$spc2 = "  | " if $verLgth == 6;
			$spc2 = " | " if $verLgth == 7;
			print " [$ID]", $spc1, "[$$analyzers{$ID}->{'SELECTED'}]","     $title ",$tabs,"$$analyzers{$ID}->{'CURRFILEVER'}",$spc2,"$$analyzers{$ID}->{'NEWFILEVER'}	\n"; 
			# print " ^ $length ^\n"; 
		}
		
		print BOLD WHITE ON_BLUE "\n  [L]oad | [B]ack | [H]elp | E[x]it", RESET;
		print BOLD WHITE ON_GREEN "| [N]ext Page", RESET if $currPage < $maxPage;
		print BOLD WHITE ON_GREEN " | [P]rev Page", RESET if $currPage < $maxPage && $currPage > 1;
		print BOLD WHITE ON_GREEN "| [P]rev Page", RESET if $currPage == $maxPage && $currPage > 1;		
		print BOLD WHITE ON_YELLOW "\n Invalid Selection", RESET if $invSel != 0; 
		print "   \n   ...\n   Toggle Selections by Number\n";
		print "   Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 

	if (defined $$analyzers{$userSel}) 
	{
		if ($$analyzers{$userSel}->{'SELECTED'} =~ /\+/) {$$analyzers{$userSel}->{'SELECTED'} = ' ';}
		else {$$analyzers{$userSel}->{'SELECTED'} = '+';}
		$ID = ($ID - $pageSize); 
	}
	elsif ($userSel =~ /^N{1}/i && $currPage != $maxPage)
	{
		$ID = ($pageSize * $currPage + 1);
		$currPage++;
	}
	elsif ($userSel =~ /^P{1}/i && $currPage != 1)
	{
		$ID = ($ID - ($pageSize * 2));
		$currPage = ($currPage -1); 
	}
	elsif ( $userSel =~ /^b$/i )
	{return;}
	elsif ($userSel =~ /^l$/i)
	{
		print qq(\n\n   Reload the selected "[+]" Analyzers?\n);
		print BOLD WHITE ON_BLUE "  [Y]es | [N]o:", RESET;
		my $cont;
		until ($cont =~ /^y|^n/i)
		{
			chomp($cont = <STDIN>);
		}
		if ( $cont =~ /^y/i )
		{
			my @arrayOfSelected;
			#load an array to pass to floadbulk that contains all the selected analyzers 

			foreach my $ID (keys %$analyzers)
			{
				 if ($$analyzers{$ID}->{'SELECTED'} eq '+')
					{
						push (@arrayOfSelected, $$analyzers{$ID}->{'FILE'}); 
					}
			}
			#foreach (@arrayOfSelected) {print "debug106: $_ \n";}
			floadBulkUpdates(\@arrayOfSelected) if scalar @arrayOfSelected > 0;
			return; 
		}
		else
		{
			$ID = 1;
			$currPage = 1; 
		}
		
	}
	elsif ($userSel =~ /^h$/i) 
	{
			system("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "  Reinstall Existing & New Analyzers as Concurrent Programs Help", RESET, "\n"; 
			print qq (
 o This menu lists and loads analyzers detected as previously installed in the 
   database as concurrent programs, as well as brand new Analyzers
 o Analyzers marked with a "+" will be loaded
 o All new analyzers as well as updated analyzers are marked to 
   be reinstalled by default
 o Selecting "Load" [L] will reinstall the Analyzer's package file (if required)
   and reload the analyzers LDT Program Definition file
 o Loading Analyzers from this menu *only loads the Concurrent Program LDT*, not the 
   Request Group LDT
 o Toggle which analyzers are loaded by selecting the associated number 

   Press [Enter] to Continue:); 
		<STDIN>;
		$ID = ($ID - $pageSize); 
	}
	elsif ($userSel =~ /^x$/i)
	{
		exitLog(); 
	} 
	else
	{
		$ID = ($ID - $pageSize); 
		$invSel = 1; 
		#repeat the menu again 
		#need to write a loop around the line 146 foreach menu to redisplay it 
	}
	$newCount = 0; 
	}#end until (1 == 2)
	
}#end if mode eq 'update' 
elsif ($mode eq 'show') 
{

$pageSize = ($height - 8); 
my $currPage = 1; 
my $maxPage = (ceil(scalar(keys %$analyzers)/$pageSize)); 
my $ID = 1; 
my ($spc1, $spc2, $spc3, $verLgth); 

until (1 == 2) 
	{
		system("clear"); 
		print "\n           "; 
		print BOLD WHITE ON_BLUE "Installed Concurrent Programs", RESET;
		print "        "; 
		print BOLD WHITE ON_GREEN "[Page $currPage of $maxPage]",RESET;
		print BOLD WHITE ON_BLUE "\n  \#    FAM: TITLE                                #ReqGrps  VERSION", RESET; 
		print "\n"; 
		$| = 1;
		for ($ID; $ID <= ($pageSize * $currPage); $ID++)
		{
			next if length($$analyzers{$ID}->{'FAM'}) < 3; 
			$spc1 = "  " if $ID > 9; 
			$spc1 = "   " if $ID <= 9; 
			$spc3 = " " if length($title) == 2; 
			$spc3 = "  " if length($title) == 1; 
			my $title = $$analyzers{$ID}->{'FAM'} . ': ' . $$analyzers{$ID}->{'CCPTITLE'}; 
			if (length $title > 42) 
			{ $title = substr($title, 0, 40); $title .= "..."; } 
			my $tabs; 
			my $length=((length($spc1) + length($title) + length("[$ID]"))); 
			$tabs = "\t\t\t\t\t" if $length <= 20; 
			$tabs = "\t\t\t\t" if $length > 21 && $length <= 29; 
			$tabs = "\t\t\t" if $length >= 30 && $length <= 37; 
			$tabs = "\t\t" if $length >= 38 && $length <= 45; ;  
			$tabs = "\t" if $length >= 46;  
			$verLgth = length($$analyzers{$ID}->{'CURRFILEVER'}); 
			$spc2 = "   | " if $verLgth == 5;
			$spc2 = "  | " if $verLgth == 6;
			$spc2 = " | " if $verLgth == 7;
			print " [$ID]", $spc1,"$title ",$tabs,$spc3,$$analyzers{$ID}->{'CNTREQGRP'},'  ',"$$analyzers{$ID}->{'CURRFILEVER'}\n"; 
			#print " ^ $length ^\n";
		}
		print BOLD WHITE ON_BLUE "\n  [B]ack | [H]elp | E[x]it ", RESET;
		print BOLD WHITE ON_GREEN "| [N]ext Page", RESET if $currPage < $maxPage;
		print BOLD WHITE ON_GREEN " | [P]rev Page", RESET if $currPage < $maxPage && $currPage > 1;
		print BOLD WHITE ON_GREEN "| [P]rev Page", RESET if $currPage == $maxPage && $currPage > 1;
		print BOLD WHITE ON_YELLOW "Invalid Selection", RESET if $invSel != 0; 
		
		print "   \n   ...\n   Select a Number For Details\n";
		print "\n  Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
	if ($userSel =~ /^b$/i)
	{
		return();
	}
	elsif ($userSel =~ /^N{1}/i && $currPage != $maxPage)
	{
		$ID = ($pageSize * $currPage + 1);
		$currPage++;
	}
	elsif ($userSel =~ /^P{1}/i && $currPage != 1)
	{
		$ID = ($ID - ($pageSize * 2));
		$currPage = ($currPage -1); 
	}
	elsif ($userSel =~ /^h$/i) 
	{
			system("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "  Show Installed Concurrent Programs Help", RESET, "\n"; 
			print qq (
 o This lists analyzers detected as installed in the database as 
   concurrent programs
 o Note that the version listed is the version of the code executed 
   as the analyzer is called by the Concurrent Managers. This may or 
   may not be the same as the SQL version of analyzers which use a 
   SQL "wrapper" to call their corresponding stored PLSQL packages.
 o "#ReqGrps" indicates the number of Request Groups which have been assigned to the Analyzer Concurrent Program.  
 o "<null>" or "NO_FILE" in the version column indicates the version 
   could not be determined 

   Press [Enter] to Continue:); 
   <STDIN>;
	 $ID = ($ID - $pageSize); 
	}
	elsif ($userSel =~ /^x{1}$/i)
	{
		exitLog();
	}
	elsif (defined $$analyzers{$userSel}) 
	{
		my $return = showAnalyzerDetails($$analyzers{$userSel}->{'FILE'});
		return() if $return eq 'main'; 
		$ID = ($ID - $pageSize); 
	}
	
	
else
	{
		$ID = ($ID - $pageSize); 
		$invSel = 1; 
		#repeat the menu again 
		#need to write a loop around the line 146 foreach menu to redisplay it 
	}


	}#end until (1 == 2)  
}#end mode eq show 
elsif ($mode eq 'bulk') 
{
	my @validAnalyzers; 
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @validAnalyzers, $File::Find::name if grep (/ANALYZER_BUNDLE_START/, @file); }, $dir );
	my $relVer = getRelVer();
		
		#we have a list of valid analyzer files 
		#from that dir .. now check if they are valid
		foreach my $file (@validAnalyzers)
		{
			my ($compat, $valid) = checkCompat($file, $relVer);
			#version is legit for the release 
			if ($valid == 1)
			{
				#check that the prog template exists; 
				my $analyzer = analyzer MENU::Analyzer($file);
				if ( ! -f ('analyzers/template/' . $analyzer->getProgTemplate())) 
				{
					print "   WARNING: No LDT file exists for ", basename($file), "\n  Concurrent Program for ", $analyzer->getTitle() ," cannot be installed. \n";
					print "   Press [Enter] to Continue: ";
					<STDIN>;
					next; 
				}
				else
				{
						my $CCP = $analyzer->getCCPName(); 
						$$analyzers{$CCP}->{'FILE'} = $file; 
						$$analyzers{$CCP}->{'FAM'} = $analyzer->getFam(); 
						$analyzers{$CCP}->{'CURRFILEVER'} = $analyzer->getFileVer(); 
						$$analyzers{$CCP}->{'CCP'} = $CCP; 
						$$analyzers{$CCP}->{'CCPTITLE'} = $analyzer->getTitle(); 
						$analyzers{$CCP}->{'REQGROUP'} = $analyzer->getReqGroup(); 
						$analyzers{$CCP}->{'PROD'} = $analyzer->getProdShortName(); 
						#so we can sort the values now: 
						$$analyzers{$CCP}->{'SORT'} = $$analyzers{$CCP}->{'FAM'} . ':' . $$analyzers{$CCP}->{'CCPTITLE'}; 
				}
			} 
		} 
		
		
		#sort the hash alpha 
			my @arr =  sort {lc($$analyzers{$a}->{'SORT'}) cmp lc($$analyzers{$b}->{'SORT'})} keys %$analyzers; 
			
			my $id = 0; 
			my %analyzers2; 
			foreach my $ccp (@arr) 
			{
				$id++; 
				# add to the %hash 
				$analyzers2{$id}->{'ID'} = $id; 
				$analyzers2{$id}->{'FILE'} = $$analyzers{$ccp}->{'FILE'}; 
				$analyzers2{$id}->{'FAM'} = $$analyzers{$ccp}->{'FAM'}; 
				$analyzers2{$id}->{'CURRFILEVER'} = $$analyzers{$ccp}->{'CURRFILEVER'};  
				$analyzers2{$id}->{'CCP'} = $ccp; 
				$analyzers2{$id}->{'CCPTITLE'} = $$analyzers{$ccp}->{'CCPTITLE'};
				$analyzers2{$id}->{'REQGROUP'} = $$analyzers{$ccp}->{'REQGROUP'};
				$analyzers2{$id}->{'PROD'} = $$analyzers{$ccp}->{'PROD'};
				$analyzers2{$id}->{'SELECTED'} = '+';
			}

	my $currPage = 1; 
	my $maxPage = (ceil(scalar(keys %analyzers2)/$pageSize)); 
	my $ID = 1; 
	until (1 == 2) 
	{
		my ($spc1, $verLgth); 
		system("clear"); 
		$| = 1;
		print "\n                "; 
		print BOLD WHITE ON_BLUE "Bulk Load Concurrent Programs",RESET;
		print "        "; 
		print BOLD WHITE ON_GREEN "[Page $currPage of $maxPage]",RESET;
		print BOLD WHITE ON_BLUE "\n  \#  SELECTED  FAM: TITLE                                       VERSION", RESET, "\n"; 
			for ($ID; $ID <= ($pageSize * $currPage); $ID++)
			{
				next if length($analyzers2{$ID}->{'FAM'}) < 3;
				$spc1 = "  " if $ID > 9;
				$spc1 = "   " if $ID <= 9;
				my $title = $analyzers2{$ID}->{'FAM'} . ': ' . $analyzers2{$ID}->{'CCPTITLE'};
				my $length=((length($title) + length("[$ID]" + length($spc1))));
				if ($length > 43) 
					{ $title = substr($title, 0, 43); $title .= "..."; } 
				my $tabs; 
				#$tabs = "\t\t\t\t\t" if $length > 12 && $length <= 18; 
				$tabs = "\t\t\t\t" if $length >= 19 && $length <= 24; 
				$tabs = "\t\t\t" if $length > 24 && $length <= 32; 
				$tabs = "\t\t" if $length > 32 && $length <= 40;   
				$tabs = "\t" if $length > 40; 
				$verLgth = length($analyzers2{$ID}->{'CURRFILEVER'}); 
				print " [$ID]", $spc1, "[$analyzers2{$ID}->{'SELECTED'}]","     $title ",$tabs,"$analyzers2{$ID}->{'CURRFILEVER'}\n"; 
			}
		print BOLD WHITE ON_BLUE "\n  [L]oad | [B]ack | [H]elp | E[x]it", RESET;
		print BOLD WHITE ON_GREEN "| [N]ext Page", RESET if $currPage < $maxPage;
		print BOLD WHITE ON_GREEN " | [P]rev Page", RESET if $currPage < $maxPage && $currPage > 1;
		print BOLD WHITE ON_GREEN "| [P]rev Page", RESET if $currPage == $maxPage && $currPage > 1;		
		print BOLD WHITE ON_YELLOW " Invalid Selection", RESET if $invSel != 0; 
		print "   \n   ...\n   Toggle Selections by Number\n";
		print "   Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 

	if (defined $analyzers2{$userSel}) 
	{
		if ($analyzers2{$userSel}->{'SELECTED'} =~ /\+/) {$analyzers2{$userSel}->{'SELECTED'} = ' ';}
		else {$analyzers2{$userSel}->{'SELECTED'} = '+';}
		$ID = ($ID - $pageSize); 
	}
	elsif ($userSel =~ /^N{1}/i && $currPage != $maxPage)
	{
		$ID = ($pageSize * $currPage + 1);
		$currPage++;
	}
	elsif ($userSel =~ /^P{1}/i && $currPage != 1)
	{
		$ID = ($ID - ($pageSize * 2));
		$currPage = ($currPage -1); 
	}
	elsif ( $userSel =~ /^b$/i )
	{return;}
	elsif ($userSel =~ /^l$/i)
	{
		print qq(\n\n   Load the Selected [+] Analyzers?\n);
		print BOLD WHITE ON_BLUE "  [Y]es | [N]o:", RESET;
		my $cont;
		until ($cont =~ /^y|^n/i)
		{
			chomp($cont = <STDIN>);
		}
		if ( $cont =~ /^y/i )
		{
			floadBulk(\%analyzers2); 
			print "   INFO: Done with Bulk Load. Press [Enter] to Continue:"; 
			<STDIN>; 
			return(); 
		}
	}
	elsif ($userSel =~ /^h$/i) 
		{
			system("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "  Bulk Load Concurrent Programs Help", RESET, "\n"; 
			print qq (
   o This lists analyzers selected to be loaded as Concurrent Programs
   o Toggle Selections using numbers, [+] is selected, [ ] is deselected
   o Press [L] to load the selected analyzers into the database using FNDLOAD	 
   o Note that the version listed is the version of the code executed 
     as the analyzer is called by the Concurrent Managers. This may or 
     may not be the same as the SQL version of analyzers which use a 
     SQL "wrapper" to call their corresponding stored PLSQL packages. 
   o "<null>" or "NO_FILE" in the version column indicates the version 
     could not be determined 

     Press [Enter] to Continue:); 
		 <STDIN>;
		 $ID = ($ID - $pageSize); 
		}
	elsif ($userSel =~ /^x$/i)
	{
		exitLog(); 
	} 
	else
	{	
		$ID = ($ID - $pageSize); 
		$invSel = 1; 
		#repeat the menu again 
		#need to write a loop around the line 146 foreach menu to redisplay it 
	}
	}#end until (1 == 2)
}#end if mode eq bulk 
 
} #end pickListMenu

# +---------------------------
# | Sub showAnalyzerDetails 
# +--------------------------- 
# | Args: 
# |
# +---------------------------

sub showAnalyzerDetails
{
	my ($file) = @_; 
	my $cs = $main::connStrg->getConnStrg(); 
	my $analyzer = analyzer MENU::Analyzer($file); 
	my $menu = _runSQL($analyzer->getCCPName()); 
	my $userSel;
	my $invSel = 0;
	my $height = `tput lines`; 
	my $width = `tput cols`;  
	my $pageSize = ($height - 8); 
	my $currPage = 1;
	my $maxPage = (ceil(scalar(keys %$menu)/$pageSize)); 
	my $ID = 1; 
	until (1 == 2) 
	{
		system("clear"); 
		print "\n"; 
		
		#spacing considerations for title: 
		my $titleSpc;  
		for (my $i=0; $i < ($width - 26); $i++)
			{
				$titleSpc = $titleSpc . ' '; 
			} 
	
		print BOLD WHITE ON_BLUE "  Request Groups For:", $analyzer->getTitle(), RESET;
		print BOLD WHITE ON_GREEN " [Page $currPage of $maxPage]" if $maxPage > 1; 
		print "\n"; 
		print BOLD WHITE ON_BLUE "  REQUEST GROUP",$titleSpc,"PRODUCT ", RESET;
		print "\n\n"; 
		
		for ($ID; $ID <= ($pageSize * $currPage); $ID++)
		#for my $key (sort { $a <=> $b } keys %$menu)
		{
			#spacing considerations to right align text to terminal 
			my $spcCnt;
			my $spc;
			my $lengthProd = (length($$menu{$ID}->{PRODUCT}) + length($$menu{$ID}->{PRODSHORTNAME}) + 4); 
			my $lengthTitle = (length("[$ID]") + length($$menu{$ID}->{REQUESTGROUP}) + 5); 
			last if length($$menu{$ID}->{REQUESTGROUP}) < 3;
			if ($width > $length) 
			{
				$spcCnt = -1 * ($lengthTitle - ($width - $lengthProd)); 
			}
			else 
			{
				$spcCnt = 1; 
			}
			for (my $i=0;$i < $spcCnt; $i++)
			{
				$spc = $spc . ' '; 
			} 
			print "  [$ID] $$menu{$ID}->{REQUESTGROUP}",$spc,"[$$menu{$ID}->{PRODUCT}, $$menu{$ID}->{PRODSHORTNAME}]\n"; 
			#print "length: $length spcCnt: $spcCnt spc: \'$spc\'\n"; 
		}
		print "\n"; 
		print BOLD WHITE ON_BLUE "  [B]ack | [M]ain Menu | [H]elp | E[x]it ";
		print BOLD WHITE ON_GREEN "| [N]ext Page", RESET if $currPage < $maxPage;
		print BOLD WHITE ON_GREEN " | [P]rev Page", RESET if $currPage < $maxPage && $currPage > 1;
		print BOLD WHITE ON_GREEN "| [P]rev Page", RESET if $currPage == $maxPage && $currPage > 1;
		print BOLD WHITE ON_YELLOW "| Invalid Selection " if $invSel == 1; 
		print "\n\n  Select a number to see the associated Responsibilities \n"; 
		print "  Selection: "; 
		chomp($userSel = <STDIN>); 
		$invSel = 0; 
	if ($userSel =~ /^x{1}/i)
	{
		exitLog(); 
	}
	elsif ($userSel =~ /^H{1}/i)
	{
		#print Help 
		system("clear"); 
		print "\n"; 
		print BOLD WHITE ON_BLUE "  Analyzer Details Help";
		print qq(
  o Displays a list of Request Groups currently assigned to an Analyzer
  o Choosing a number will show the responsibilities associated with 
    the request group
  o "# of Users Assigned" column shows how many Active Users currently 
    have the responsibility	
  o [B] - Back to the previous screen 
  o [H] - Displays this help 
  o [X] - Exits the application 
  
  Request Group Information: 
  A Concurrent Program cannot be run until it is assigned to a Request Group. 
  A single Request Group can be registered to multiple Responsibilities.

  Press [Enter] to Continue: 
); 
	<STDIN>; 
	$ID = ($ID - $pageSize);
	}
	elsif ($userSel =~ /^B{1}/i)
	{
		return(); 
	}
	elsif (defined $$menu{$userSel})
	{
		#Show Responsibilities for a given request group 
		my $return = showResp($$menu{$userSel}->{REQUESTGROUP}, $$menu{$userSel}->{PRODSHORTNAME}); #my ($reqGroup, $appShortName) = @_; 
		return('main') if $return eq 'main'; 
		$ID = ($ID - $pageSize);
		$ID = 1 if $ID < 0; 
		#print "debug: $ID \n"; <STDIN>; 
	}
	elsif ($userSel =~ /^N{1}/i && $currPage != $maxPage)
	{
		$ID = ($pageSize * $currPage + 1);
		$currPage++;
	}
	elsif ($userSel =~ /^P{1}/i && $currPage != 1)
	{
		$ID = ($ID - ($pageSize * 2));
		$currPage = ($currPage -1); 
	}
	elsif ($userSel =~ /^m{1}/i)
	{
		return('main'); 
	}
	else
	{
		$invSel = 1; 
		$ID = ($ID - $pageSize);
		$ID = 1 if $ID < 0; 
		#$currPage = ($currPage -1); 
	}
	
	
	}#end until 1==2 

# +---------------------------+
# | private sub:  
# +---------------------------+
# | Desc: _runSQL
# +---------------------------+
# | Args: CCP Name 
# +---------------------------+
# | Returns: hash of lines from the spool file. 
# | AppShortName::Request Group Name::Responsibility 
# | $lines{$id}->{REQUESTGROUP}=$rg; 
# | $lines{$id}->{PRODSHORTNAME}=$psn; 
# |	$lines{$id}->{PRODUCT}=$prod; 
# | 
# +---------------------------+

sub _runSQL 
{

my ($ccp) = @_; 
	unlink("sql/ccp_req_groups.lst") if -e "sql/ccp_req_groups.lst"; 
	unlink("sql/ccp_req_groups.sql") if -e "sql/ccp_req_groups.sql"; 
	
my @sql = qq(
SET SERVEROUTPUT ON
SET TERM OFF 
SET VERIFY OFF 
SET HEAD OFF

SPOOL "sql/ccp_req_groups.lst" 
select distinct frg.request_group_name || '^' || fat2.application_name ||  '^' || fa2.application_short_name
FROM fnd_concurrent_programs fcp, fnd_concurrent_programs_tl fcpt, 
     fnd_application_tl fat, fnd_application fa, 
     fnd_application_tl fat2, fnd_application fa2,
     fnd_request_group_units frgu, fnd_request_groups frg
where fcp.CONCURRENT_PROGRAM_ID = fcpt.CONCURRENT_PROGRAM_ID
and fcp.application_id = fat.application_id 
and fat.application_id = fa.application_id 
and frgu.APPLICATION_ID = fa2.application_id
and fat2.application_id = fa2.application_id
and frgu.request_unit_id = fcp.concurrent_program_id 
and frg.request_group_id = frgu.request_group_id 
and upper(fcp.concurrent_program_name) = '$ccp'
/ 
SPOOL OFF;
EXIT); 
	
	open (my $fh, '>', 'sql/ccp_req_groups.sql' ) || die "showAnalyzerDetails(): Cannot create sql/ccp_req_groups.sql: $! \n"; 
	print $fh @sql; 
	close $fh; 
	my $status = system("sqlplus -l -s $cs \@sql\/ccp_req_groups.sql"); 

	my @grps; 
	if (-e "sql/ccp_req_groups.lst") 
	{
		open (my $fh, '<', 'sql/ccp_req_groups.lst' ) || die "showAnalyzerDetails(): Cannot create sql/ccp_req_groups.sql: $! \n";
		my @lst = <$fh>; 
		close $fh; 
		(@grps) = grep(/\^/,@lst); 
	}
	else 
	{
		print "  ERROR: showAnalyzerDetails() did not create a spool file \n"; 
		print "   Press [Enter] to Continue:"; 
		<STDIN>; 
	}

	# unlink("sql/ccp_req_groups.lst") if -e "sql/ccp_req_groups.lst"; 
	# unlink("sql/ccp_req_groups.sql") if -e "sql/ccp_req_groups.sql"; 
	
my %lines; 
my $id = 0;  

foreach my $line (@grps) 
{
	$id++; 
	$line = trim($line); 
	my ($rg, $prod, $psn) = split('\^', $line); 
	
	$lines{$id}->{REQUESTGROUP}=$rg; 
	$lines{$id}->{PRODSHORTNAME}=$psn; 
	$lines{$id}->{PRODUCT}=$prod; 
}	
return(\%lines);
	
}#end _runSQL






	return(); 

}#end showAnalyzerDetails 


# +---------------------------
# | Sub getBundleUpdate
# +--------------------------- 
# | uses wget.sh to download the bundle.zip from DocID: 1939637.1:BUNDLE 
# |
# +---------------------------
sub getBundleUpdate
{
	system("clear"); 
	my $status; 
	#check for wget 
	`which wget >& /dev/null`;
	$status = $?; 
	print "   \n\nERROR: wget executable is required, but not found in the \$PATH \n" if $status > 0; 
	
	#check for unzip 
	`which unzip >& /dev/null`; 
	$status += $?; 
	print "   \n\nERROR: unzip executable is required, but not found in the \$PATH \n" if $status > 0; 
	
	if ($status > 0)
	{
		print "   \n\nERROR: wget and unzip are required in the \$PATH in order \n    to run this update option. \n   Ensure those utilities are available in the UNIX \$PATH environment variable\n    and retry. \n"; 
		print "   \n\nPATH: $ENV{PATH}"; 
	}
	elsif ($status == 0) 
	{
		my $baseURL = hostdomain;
		$baseURL =~ /\.oracle\.com^/ ? $baseURL = 'support.oracle.com' :  $baseURL = 'mosemp.us.oracle.com';
		chmod 0755, "update/wget.sh"; 
		$status = system("update/wget.sh $baseURL"); 
	}
	#Download the bundle to <base>/updates 

	return($status); 
}	#end getBundleUpdate

# +---------------------------+
# | sub:  getHighVersionBundle
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: n/a 
# +---------------------------+
# | Returns: the zip file from MENU/update dir 
# | that has the highest version 
# | 
# +---------------------------+

sub getHighVersionBundle
{
	my @zips; 
	find( sub {return unless /.+?\.zip$/i; push @zips, $File::Find::name;}, "update/" );
	
	my $version = 0; 
	my $highVer = 0;  
	my $highVerFile;  
	for my $file (@zips) 
	{
		#filter the archive dir out 
		next if $file =~ /archive/; 
		#print "version is: $version \n\n"; 
		my @unzip = `unzip -z $file`; 
		($version) = grep(/version/i, @unzip);
		$version = $+ if $version =~ /(\d*\.\d*)/;
		#print "file: $file version: $version\n"; 
		
		if ($version > $highVer)
		{
			$highVer = $version; 
			$highVerFile = $file; 
		}
	}
	$highVer = trim($highVer); 
	return ($highVerFile, $highVer); 
}


	
# +---------------------------
# | Sub manualUpdate
# +---------------------------
# |
# | 
# +---------------------------	
sub manualUpdate
{
my ($currVer, $ver); 
my $userSel = 0; 

sub _rebootManual
	{
		#reboot 
		open (my $fh, '>', '.updateManual' ) || die "manualUpdate(): Cannot create .updateManual: $! \n"; 
		close $fh; 
		print "\n\n   The Perl menu needs to be restarted using \'perl Menu.pl\' \n   The update process will resume after the restart. \n   Press [Enter]: "; 
		<STDIN>; 
		exit; 
	}

	if (-f '.updateManual') 
	{
		print "   INFO: Bundle unzipped successfully. Resuming Update. \n   Press [Enter]: "; 
		<STDIN>;
	
		unlink ('.updateManual');
		pickListMenu('update');
	}
	 
	

until (1 == 2) 
	{
			system("clear");
			print BOLD WHITE ON_BLUE "\n  Manual Download & Update",RESET ; 
			print "\n\n"; 
			#print "   [1] Check bundle.zip version\n"; 
			#print "   [2] Download new bundle.zip\n"; 
			print "   [1] Unzip update/bundle.zip\n"; 
			print "   [2] Reinstall Concurrent Programs\n"; 
			print "\n  ...\n"; 
			print BOLD WHITE ON_BLUE "  [B]ack | [H]elp | E[x]it",RESET ; 
			print BOLD WHITE ON_YELLOW "   Invalid Selection",RESET if $userSel eq 'invalid'; 
			print "\n\n   Selection:"; 
			chomp($userSel=<STDIN>); 

	if ($userSel =~ /^1{1}$/i)
	{
		system("clear"); 
		print "\n\n   INFO: Please ensure that you have downloaded bundle.zip from \n   Doc ID: 1939637.1, named it \'bundle.zip\' and placed it into the\n   \'MENU/update\' directory.\n\n    Press [Enter] to Continue: "; 
		<STDIN>; 
		unzipBundle(); 
		_rebootManual(); 
	}
	elsif ($userSel =~ /^2{1}$/i)
	{
		pickListMenu('update'); 
	}
	elsif ($userSel =~ /^h{1}$/i)
	{
			system ("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "  Manual Download & Update Menu Help", RESET, "\n"; 
			print qq(
 
 o [1] Unzip "update/bundle.zip"
   Unzips the bundle.zip into the base, "MENU" directory. 
   
 o [2] Reinstall Concurrent Programs
    Provides a picklist menu where the user can see which analyzers were 
    previously installed as Concurrent Programs and can choose which ones 
    to reinstall. Reinstalling after an update ensures any new parameters
    are in sync and new features can be used by the Concurrent Program users. 
  
   
     Press [Enter] to Continue:); 
			my $w = <STDIN>; 
	}
	elsif ($userSel =~ /^b{1}$/i)
	{
		return(); 
	}
	elsif ($userSel =~ /^x{1}$/i)
	{
		exitLog(); 
	}		
	else 
	{
		$userSel='invalid'; 
	}
		
		
	}#end until loop 
}#end manualUpdate 

# +---------------------------
# | sub getBundleVer 
# +---------------------------
# | 
# | 
# | 
# +---------------------------
sub getBundleVer
	{
		my $line; 
		open (my $fh, '<', 'Menu.pl' ) || die "getBundleVer(): Cannot open Menu.pl: $! \n"; 
		for (0 .. 2) 
			{
				$line = <$fh>; 
				last if $line =~ /\$Id:/; 
			}
		close $fh; 
		my @ar = split(' ', $line); 
		$ver = $ar[3]; 
		$ver = trim($ver); 
		return ($ver); 
	}
	
# +---------------------------
# | Sub getInstalledCCPs
# +---------------------------
# |#Gets the list of installed analyzers 
# | Returns a hash of Key: CCP Short Name Value: Analyzer File (full path) 
# +---------------------------
sub getInstalledCCPs 
{
	my $cs = $main::connStrg->getConnStrg(); 
	my $progName; 
	my $relVer = getRelVer();
	#build the "IN ('','','') arg and SQL command by grabbing the "PROG_NAME: <name>" line off the header of all valid analyzers.  
	my %analyzers;
	my %instAnalyzers;
	#find all analyzer files 
	my @files; 
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @files, $File::Find::name if (($progName) = grep (/ANALYZER_BUNDLE_START/, @file)); }, 'analyzers/SQL' ); 
	
	foreach (@files) 
	{
		my $currFile = $_;
		#check if the file is compat 
		my ($compat, $valid) = checkCompat($currFile,$relVer);
		if ($valid == 1) 
		{
			my $analyzer = analyzer MENU::Analyzer($currFile);
			my $CCP = $analyzer->getCCPName(); 
			$analyzers{$CCP}=$currFile if length($CCP) && length($currFile); 
		}
	}

	#analyzers hash built: Key: CCP name, value: relative path from MENU dir to
	#	file, ex: analyzers/SQL/03_Manufacturing_Analyzers/Procurement/analyze_all.sql 

	my $in = qq(\(\');
	my $i = 0; 
	for my $key (keys %analyzers)
	{
		$i++; 
		$in .= $key . "\'," if $i == 1;
		$in .= "\'" . $key . "\'," if $i > 1;
	} 
	$in =~ s/,$//; 

	unlink('sql/run.sql') if -f 'sql/run.sql';
	unlink('sql/installed_ccps.lst') if -f 'sql/installed_ccps.lst'; 

my @sql = qq(
set serveroutput on
set term off 
set verify off 
set head off
spool "sql/installed_ccps.lst" 

SELECT 'name:' || cp.concurrent_program_name,'title:' || cp.user_concurrent_program_name,'exe:' || decode(cp.execution_method_code,'I', upper(substr(fe.EXECUTION_FILE_NAME,0,instr(fe.EXECUTION_FILE_NAME,'.')-1)),'Q', '\$'||fav.basepath||'/sql/'||fe.EXECUTION_FILE_NAME||'.sql', cp.execution_method_code), 'CntReqGrp:' || count(rg.request_group_name)
FROM FND_EXECUTABLES fe,FND_APPLICATION_VL fav, fnd_request_groups rg,fnd_request_group_units rgu,fnd_concurrent_programs_vl cp
WHERE fav.application_id = cp.application_id
AND rg.request_group_id = rgu.request_group_id
AND rgu.Request_Unit_Id = cp.concurrent_program_id
and cp.executable_id = fe.executable_id
and fe.application_id = Fav.Application_Id
AND cp.Concurrent_Program_Name in 
$in\) 
group by cp.concurrent_program_name, cp.user_concurrent_program_name,decode(cp.execution_method_code,'I', upper(substr(fe.EXECUTION_FILE_NAME,0,instr(fe.EXECUTION_FILE_NAME,'.')-1)), 'Q', '\$'||fav.basepath||'/sql/'||fe.EXECUTION_FILE_NAME||'.sql', cp.execution_method_code); 
/ 
spool off;
exit); 

	open (my $fh, '>', 'sql/run.sql' ) || die "Cannot open sql/run.sql: $! \n"; 
	print $fh @sql;
	close $fh;
	my $status = system("sqlplus -l -s $cs \@sql\/run.sql"); 
	# check_installed_ccps.lst
	print "   INFO: getInstalledCCPs: SQLPLUS exited with status: $status \n"; 
	
	open (my $fh, '<', 'sql/installed_ccps.lst' ) || die "Cannot open sql/installed_ccps.lst: $! \n"; 
	
	my @ccps; 
	while (my $line = <$fh>)
	{
		$line = trim($line); 
		push @ccps, $line if $line =~/\:/;  
	}
	close $fh; 

	if (! grep /title:/, @ccps) 
		{
			#print "   INFO: getInstalledCCPs did not find any Analyzer Concurrent Programs \n"; 
			return(1);
		}

	#@ccps is the list of installed CCPs(concurrent progs) returned from the above DB query 
	#loop through the @ccps array, which is the spool file.. contents are such: 
	# name:APGDFVAL_SINGLE
	# title:AP Single Transaction Data Validation Analyzer
	# CntReqGrp:1
	# exe:AP_GDF_DETECT_PKG

	
	

	for (my $i=0; $i < $#ccps; $i++)
	{
		my $ccpName; 
		my $line = $ccps[$i]; 
		if ($line =~ /^name:/)
		{
			$ccpName = $+ if $ccps[$i] =~ /^name:(\w+)/;
			$instAnalyzers{$ccpName}->{'CCP'} = $ccpName; 
			#get Title 
			$i++; 
			$instAnalyzers{$ccpName}->{'CCPTITLE'} = $+ if $ccps[$i] =~ /^title:(.+)/; 
			#get Exe 
			$i++; 
			$instAnalyzers{$ccpName}->{'EXECUTABLE'} = $+ if $ccps[$i] =~ /^exe:(\$*.+)/; 
			$instAnalyzers{$ccpName}->{'FILE'} = $analyzers{$ccpName};
			my $analyzer = analyzer MENU::Analyzer($instAnalyzers{$ccpName}->{'FILE'});
			$instAnalyzers{$ccpName}->{'FAM'} = $analyzer->getFam(); 
			$instAnalyzers{$ccpName}->{'SORT'} = $instAnalyzers{$ccpName}->{'FAM'} . ': ' . $instAnalyzers{$ccpName}->{'CCPTITLE'}; 
			$i++; 
			$instAnalyzers{$ccpName}->{'CNTREQGRP'} = $+ if $ccps[$i] =~ /^CntReqGrp:(.+)/; 
		}
	
		next if length($ccpName) < 3; 
			#get versions if file 
		if ($instAnalyzers{$ccpName}->{'EXECUTABLE'} =~ /^\$/)
		{
			#file version checks 
			#convert "$PAY_TOP/sql/retropay_analyzer.sql" to full path 
			my $fullPath = $+ if $instAnalyzers{$ccpName}->{'EXECUTABLE'} =~ /\$(\w+_TOP)\//; 
			$fullPath = $ENV{$fullPath} . '/sql/' . basename($instAnalyzers{$ccpName}->{'EXECUTABLE'});
			my $ver = getFileVer($fullPath);
			if ($ver == 1) 
			{
				$instAnalyzers{$ccpName}->{'CURRFILEVER'} ='<null>';
			}
			elsif ($ver == 2) 
			{
				$instAnalyzers{$ccpName}->{'CURRFILEVER'} = 'NO_FILE'; 
			}
			else 
			{
				#got ver 
				$instAnalyzers{$ccpName}->{'CURRFILEVER'} = $ver;
			}
		}
		else
		{
			my ($status, $ver) = getDBPkgVer($instAnalyzers{$ccpName}->{'EXECUTABLE'});
			if ($status == 0)
			{
				#got ver 
				$instAnalyzers{$ccpName}->{'CURRFILEVER'} = $ver;
			}
			elsif ($status == 2) 
			{
				#package does not exist 
				$instAnalyzers{$ccpName}->{'CURRFILEVER'} ='NO_PACKAGE';
			}
			else
			{
				$instAnalyzers{$ccpName}->{'CURRFILEVER'} ='<null>';
			}
		}
	}#end for (my $i=0; $i < $#ccps; $i++)

	
	my @sortedTitles =  sort {lc($instAnalyzers{$a}->{'SORT'}) cmp lc($instAnalyzers{$b}->{'SORT'})} keys %instAnalyzers; 
	
	my $id; 
	foreach my $ccp (@sortedTitles)
	{
		$id++; 
		$instAnalyzers{$id}->{'FILE'} = $instAnalyzers{$ccp}->{'FILE'}; 
		$instAnalyzers{$id}->{'CURRFILEVER'} = $instAnalyzers{$ccp}->{'CURRFILEVER'}; 
		$instAnalyzers{$id}->{'EXECUTABLE'} = $instAnalyzers{$ccp}->{'EXECUTABLE'}; 
		$instAnalyzers{$id}->{'CCPTITLE'} = $instAnalyzers{$ccp}->{'CCPTITLE'}; 
		$instAnalyzers{$id}->{'CCP'} = $instAnalyzers{$ccp}->{'CCP'}; 
		$instAnalyzers{$id}->{'FAM'} = $instAnalyzers{$ccp}->{'FAM'}; 
		$instAnalyzers{$id}->{'CNTREQGRP'} = $instAnalyzers{$ccp}->{'CNTREQGRP'}; 
		delete($instAnalyzers{$ccp}); 
	}

	#get the NEWFILEVER 
	for my $id (keys %instAnalyzers)
	{
		if (-e $instAnalyzers{$id}->{'FILE'})
		{
			#We need the version of the deps getDeps() 
			my $analyzer = analyzer MENU::Analyzer($instAnalyzers{$id}->{'FILE'});
			my $depFile = $analyzer->getDeps(); 
			$instAnalyzers{$id}->{'FAM'} = $analyzer->getFam(); 
			my $ver; 
			if ($#$depFile == 0) 
			{
				foreach (@$depFile) 
				{
					$ver = getFileVer($_); 
				}
			}
			else 
			{
				$ver = getFileVer($instAnalyzers{$id}->{'FILE'}); 
			}
			
			if ($ver == 1) 
			{
				$instAnalyzers{$id}->{'NEWFILEVER'} ='<null>'; 
			}
			else #got ver 
			{
				$instAnalyzers{$id}->{'NEWFILEVER'} =$ver; 
			}
		}
		else
		{
			$instAnalyzers{$id}->{'FILE'} = 'NO_FILE'; 
		}
	}#END for my $id (keys %instAnalyzers)

	# unlink('sql/installed_ccps.lst') if -e 'sql/installed_ccps.lst'; 
	# unlink('sql/run.sql') if -e 'sql/run.sql';

	return(\%instAnalyzers); 

}#end getInstalledCCPs 
# +---------------------------
# | Sub unzipBundle() 
# +---------------------------
# |
# | 01-OCT-2015: 
# | Create archive dir if it doesn't exist 
# | move all zips into the archive dir 
# +---------------------------
sub unzipBundle
{
	my ($file) = @_; 
	my $status; 
	my $unzip=`which unzip`; 
	#check for unzip 
	my @ar = `unzip -v`; 
	prnt2Log("\nINFO: Running unzipBundle\n\n"); 
	
	if (grep (/Info-ZIP/, @ar)) 
	{
		prnt2LogSTDOUT("   INFO: Found unzip in the \$PATH\n"); 
	}
	else
	{
		prnt2LogSTDOUT("   ERROR: No unzip in the \$PATH. \n   Add \'unzip\' to your \$PATH and try again. \n");
		my $w; 
		print "   Press [Enter] to Continue: \n"; 
		$w=<STDIN>;
		return($status); 
	}

	my $newDir = 'analyzers_' . (strftime "%Y-%m-%d_%H%M%S", localtime); 
	prnt2LogSTDOUT("   INFO: Renaming the \'analyzers\' directory to: $newDir \n"); 
	rename("analyzers", $newDir) if -d 'analyzers'; 
	prnt2LogSTDOUT("   INFO: Unzipping $file.. \n");
	my $cmd = qq(unzip -o $file -d ../ &> /dev/null); 
	$status = system($cmd);
	if ($status > 0) 
	{
		prnt2LogSTDOUT("   ERROR: Unzip exited with status: $status \n");
		print "   Press [Enter] to Continue:"; 
		<STDIN>; 
		return($status); 
	}
	elsif ($status == 0) 
	{
		prnt2LogSTDOUT("   INFO: Unzip successful, status: $status \n");
		
		if (! -d "update/archive") 
		{
			prnt2LogSTDOUT("   INFO: Creating update/archive directory\n\n"); 
			mkdir("update/archive"); 
		}
		my $newFile = "update/archive/" . basename($file); 
		prnt2LogSTDOUT("   INFO: Moving $file to $newFile");
		move($file, $newFile); 
		print "\n\n   Press [Enter] to Continue:"; 
		<STDIN>; 
		return($status); 
	}
}


# +---------------------------+
# | sub: uninstall() 
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub uninstall
{
my $userSel; 

prnt2Log("\nINFO: Running uninstall()\n"); 
until (1 == 2) #endless loop 
	{
		$| = 1;
		system("clear");
		my $count=0; 
		printf "\n              ", RESET;
		printf BOLD WHITE ON_BLUE "Analyzers Uninstall", RESET, "\n\n" if $count == 0;
		printf BOLD WHITE ON_BLUE "\n  Choose an Option:", RESET, "\n\n" if $count == 0; 
		printf "   [1] Uninstall All Analyzers \n"; 
		printf "   [2] Remove Individual Analyzers\n";
		printf "   ...\n"; 
		printf BOLD WHITE ON_BLUE "\n  [B]ack | [H]elp | E[x]it"; 
		print BOLD WHITE ON_YELLOW "   Invalid Selection", RESET if $userSel eq 'invalid'; 
		printf "\n\n  Selection:"; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}/i; 
				
			if ($userSel =~ /^1{1}/i)
			{
				prnt2Log("\nINFO: User Selected to Uninstall all\n"); 
				uninstallAll(); 
			}
			elsif ($userSel =~ /^B{1}/i) 
			{
				return(); 
			}
			elsif ($userSel =~ /^2{1}/i) 
			{
				uninstallPickList(); 
			}
			elsif ($userSel =~ /^H{1}/i) 
			{
				#Help
				system("clear"); 
				print "\n"; 
				printf BOLD WHITE ON_BLUE "  Analyzers \"Remove All\" Help", RESET; 
				print qq(\n   This option removes all remnants of the Analyzers from your system. The\n   following steps are taken: \n   o Remove all Concurrent Program Request Group Entries\n   o Remove all Concurrent Program Definitions\n   o Remove all Concurrent Executable Definitions\n   o Drop all Analyzer Database Objects\n   o Delete all Analyzer Files from <PROD_TOP>/sql\n\n   Note: All Concurrent Program Data Manipulation (DML) is achieved by this\n   script using the FND_PROGRAM API provided by Oracle Development. \n   See the Oracle Developers Guide for more information. \n\n   The Analyzer Bundle 'MENU' directory structure can be manually removed once \n   the uninstall is completed. (This script does not remove the bundle files). \n\n   Press [Enter] to return to the menu: ); 
				<STDIN>; 
			}
			else
			{
				$userSel='invalid'; 
			}
	}
}
####### ##########
#  Subs 
########## #########
	
# +---------------------------
# | sub uninstallPickList 
# | 
# +---------------------------
# +---------------------------+
# | sub:  uninstallPickList
# +---------------------------+
# | Desc: without a mode passed, shows an uninstall picklist to remove analyzers 
# | if mode = show, shows a static list 
# | 
# +---------------------------+
# | Args: <null> (default) or "show" 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub uninstallPickList 
{
	my $analyzers = getInstalledCCPs(); 
	my $userSel; 
	my $invSel = 0;
	my $change; 

	# open (my $fh, '>', 'CCPS.txt' ); 
	# use Data::Dumper; 
	# print $fh Dumper (%$analyzers);
	# close $fh; 
	
	for my $id (keys %$analyzers) 
	{
		$$analyzers{$id}->{'SELECTED'} = ' '; 
		if ($$analyzers{$id}->{'EXECUTABLE'} !~ /^\$/)
		{
			$$analyzers{$id}->{'DROP'} = "drop package $$analyzers{$id}->{'EXECUTABLE'}"; 
		}
	}
	
	if (! defined $$analyzers{'1'}->{'CCPTITLE'})
		{
			print "   INFO: No Analyzers to Remove\n"; 
			print "   Press [Enter] to Continue: "; 
			<STDIN>; 
			return(); 
		}
	#loop forever. Other exit mechanisms are in place. 
	#keeps the menu alive until user specifies
	#Menu entry:
		my $spc; 
		my $currPage = 1; 
		my $height = `tput lines`; 
		my $width = `tput cols`;  
		my $pageSize = ($height - 8);
		my $maxPage = (ceil(scalar(keys %$analyzers)/$pageSize)); 
		my $ID = 1; 
		until (1 == 2)
		{
			system("clear");
			print BOLD WHITE ON_GREEN "\n Legend: [+] = Selected To be Uninstalled   [Page $currPage of $maxPage]"; 
			print BOLD WHITE ON_BLUE "\n #  SELECTED    FAM: TITLE                              ", RESET; 
			print "\n"; 
			$| = 1;
			for ($ID; $ID <= ($pageSize * $currPage); $ID++)
			{
				next if length $$analyzers{$ID}->{'FAM'} < 3; 
				my $title = $$analyzers{$ID}->{'FAM'} . ': ' . $$analyzers{$ID}->{'CCPTITLE'};
				$spc = '  ' if ($ID > 9);
				$spc = '   ' if ($ID < 9);
				
				if (length $title > 59) 
					{ $title = substr($title, 0, 60); $title .= "..."; } 
				my $tabs; 
				my $length=((length($$analyzers{$ID}->{'CCP'}) + length("[$ID]"))); 
				$tabs = "\t\t\t" if $length <= 13;
				$tabs = "\t\t"  if $length >= 14 && $length <=16; 
				$tabs = "\t\t" if $length > 16 && $length <= 20; 
				$tabs = "\t" if $length > 20;
				#debug length: 
				# print "[$ID]",$spc,"[$$analyzers{$ID}->{'SELECTED'}]       $title ($length)\n"; 
				print "[$ID]",$spc,"[$$analyzers{$ID}->{'SELECTED'}]       $title\n"; 
			}
			print BOLD WHITE ON_BLUE "  [U]ninstall | Select [A]ll | [B]ack | [H]elp | E[x]it",RESET; 
			# print BOLD WHITE ON_BLUE "\n  [S]how Analyzers without a Concurrent Program ",RESET; 
			print BOLD WHITE ON_GREEN "\n  [N]ext Page", RESET if $currPage < $maxPage;
			print BOLD WHITE ON_GREEN "| [P]rev Page", RESET if $currPage < $maxPage && $currPage > 1;
			print BOLD WHITE ON_GREEN "\n  [P]rev Page", RESET if $currPage == $maxPage && $currPage > 1;	
			print BOLD WHITE ON_YELLOW "Invalid Selection", RESET if $invSel != 0; 
			print "\n  ...\n   Toggle Selections by Number, [U] to Proceed with Removal\n";
			print "   Selection:"; 
			$invSel = 0; 
			chomp($userSel = <STDIN>);
			exitLog() if $userSel =~ /^x{1}$/i; 

		if (defined $$analyzers{$userSel}) 
		{
			if ($$analyzers{$userSel}->{'SELECTED'} =~ /\+/) {$$analyzers{$userSel}->{'SELECTED'} = ' ';}
			elsif ($$analyzers{$userSel}->{'SELECTED'} eq ' ') {$$analyzers{$userSel}->{'SELECTED'} = '+';}
			$ID = ($ID - $pageSize); 
		}
		elsif ($userSel =~ /^N{1}/i && $currPage != $maxPage)
		{
			$ID = ($pageSize * $currPage + 1);
			$currPage++;
		}
		elsif ($userSel =~ /^P{1}/i && $currPage != 1)
		{
			$ID = ($ID - ($pageSize * 2));
			$currPage = ($currPage -1); 
		}
		elsif ($userSel =~ /^s{1}/i)
		{
			getAnalyzersNoCCP();
			return(); 
		}
		elsif ($userSel =~ /^u{1}/i)
		{
			my $ans; 
			until ($ans =~ /^y|^n/i) 
			{
				print "   Uninstall the Selected [+] Analyzers? [y|n]: "; 
				chomp($ans = <STDIN>); 
			}
		
			if ($ans =~ /^y/i) 
			{
				prnt2Log("INFO: Running uninstallPickList()"); 
				prnt2Log("\n*** *** ***\nINFO: Removing Analyzers:");
				foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
				{
					prnt2Log("\n----\nFILE: $$analyzers{$ID}->{'FILE'}\nConcurrent Program: $$analyzers{$ID}->{'CCPTITLE'} \($$analyzers{$ID}->{'CCP'}\)\n----\n ") if $$analyzers{$ID}->{'SELECTED'} =~ /\+/; 
				}
				prnt2Log("\n*** *** ***\n");
				
				removeReqGroupEntries($analyzers);
				removeConcProgs($analyzers);
				dropObjects($analyzers); 
				deleteFiles('TARGETED', $analyzers);
				return(); 
			}
			$ID = ($ID - $pageSize); 
		}
		elsif ($userSel =~ /^b{1}/i)
		{	
			return(); 
		}
		elsif ($userSel =~ /^a{1}/i)
		{
			for my $id (keys %$analyzers)
			{
				if ($$analyzers{$id}->{'SELECTED'} eq ' ') {$$analyzers{$id}->{'SELECTED'} = '+';}
			}
			$ID = ($ID - $pageSize); 
		}	
		elsif ($userSel =~ /^h{1}/i) 
		{
				system("clear"); 
				print "\n"; 
				print BOLD WHITE ON_BLUE "  Concurrent Program Reinstall Menu Help", RESET, "\n"; 
				print qq (
  INFO: 
  o This menu lists and uninstalls analyzers detected as installed in the 
   database as concurrent programs.
  o Analyzers marked with a "+" will be uninstalled.  
  o Selecting "Uninstall" [U] will remove: 
    -The Concurrent Program Definition 
    -Any Responsibility Group entries 
    -Any database objects associated with the analyzer
    -Any files installed in the <PROD_TOP>/sql for the analyzer
  USAGE: 
  o Toggle which analyzers are loaded by selecting a number 
    -Please note that the presence of a menu item indicates that either a 
     Concurrent Program or Executable definition exists 

	Press [Enter] to Continue:); 
				<STDIN>;
				$ID = ($ID - $pageSize); 
			}
		elsif ($userSel =~ /^x$/i)
		{
			exitLog(); 
		} 
		else
		{
			#invalid selection. 
			$invSel = 1; 
			$ID = ($ID - $pageSize); 
		}
	}#end until (1 == 2)
	
} #end pickListMenu


# +---------------------------
# | sub uninstallAll 
# | 
# +---------------------------
sub uninstallAll 
{
	my $analyzers=getInstalledCCPs();
	my $analyzerDBObjs=getInstalledDBobjs();
	my $sizeAnalyzers = keys %{ $analyzers }; 
	my $sizeAnalyzerDBObjs = keys %{ $analyzerDBObjs }; 
	if ($sizeAnalyzers == 0 && $sizeAnalyzerDBObjs == 0) 
	{
		print "   INFO: No Analyzers to Remove. \n   Press [Enter] To Continue: "; 
		<STDIN>; 
		return(); 
	}
	
	system("clear");
	prnt2Log("\nINFO: Running uninstallAll\n"); 
	prnt2LogSTDOUT("\n  INFO: You are about to remove all Analyzers from this system. \n\n"); 
	print "   The following will be removed: \n"; 
	print qq"   o Analyzer Entries in Concurrent Request Groups\n      [via the plsql API: fnd_program.remove_from_group]\n\n   o Analyzer Concurrent Programs\n     [via the plsql API: fnd_program.delete_program]\n\n   o Analyzer Concurrent Executables\n      [via the plsql API: fnd_program.delete_executable]\n\n   o Analyzer Database Objects   \n\n   o Analyzer Files stored in Product Tops \"sql\" directories\n\n"; 
	my $validAns; 
	my $ans; 
	until ($validAns =~ /^y$/i || $validAns =~ /^n$/i)
	{
		prnt2Log(""); 
		print BOLD WHITE ON_BLUE "  Continue with Uninstall? [Y|N] :",RESET;
		chomp($ans = <STDIN>); 
		$validAns = $ans; 
	}
		if ($validAns =~ /^y$/i)
		{
			#build list of all analyzer CCPs
			if ($$analyzers{'1'}->{'CCPTITLE'})
			{
				prnt2Log("INFO: Running uninstallAll()"); 
				prnt2Log("\nINFO: User Selected To Continue with Uninstall All \n"); 
				#remove CCPs 
				prnt2Log("\n*** *** ***\nINFO: Removing Analyzers:");
				foreach my $ID (sort { $a <=> $b } keys %$analyzers) 
				{
					prnt2Log("\n----FILE: $$analyzers{$ID}->{'FILE'}\nConcurrent Program: $$analyzers{$ID}->{'CCPTITLE'} \($$analyzers{$ID}->{'CCP'}\)\n----\n ") if $$analyzers{$ID}->{'SELECTED'} = '+'; 
				}
				prnt2Log("\n*** *** ***\n");
				removeReqGroupEntries($analyzers);
				removeConcProgs($analyzers);
			}
			
			#check for all DB objects
			 
			dropObjects($analyzerDBObjs); 
			#check & Delete files 
			deleteFiles('all'); 
		}
		else 
		{return();}
			
print "   INFO: Uninstall Complete.\n"; 
print "   Press [Enter] to Continue: "; 
<STDIN>; 
return(); 

}#end uninstallAll


# +---------------------------
# | sub deleteFiles
# | 
# | IF user is using the "uninstall" all option
# | then we'll just check for all possible files by checking an 
# | analyzer's template and removing any files that exist. 
# | Else we can take and return an array of files which exist 
# | 
# | mode: "get" -> return hash with 
# | mode: "all" -> check for and del all possible files from PROD_TOP/sql dirs 
# | mode: "targeted" -> remove files passed in 
# +---------------------------
sub deleteFiles
{
	my ($mode, $analyzers) = @_; 
	my @validAnalyzers; 
	#get the largest Hash Key so we can add to it 
	my $i = getLargestHashKey($analyzers); 
	my $match; 
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @validAnalyzers, $File::Find::name . '::' . $match if (($match) = grep{/PROG_TEMPLATE:\s+?(\w+\.ldt)/} @file) },  'analyzers/SQL' );
	if ($mode eq 'all') 
	{
		foreach (@validAnalyzers) 
		{
			my $f = $_; 
			my ($file, $template) = split('::', $f); 
			$template = $+ if $template =~ /PROG_TEMPLATE:\s+?(\w+\.ldt)/; 
			$template = 'analyzers/template/' . $template; 
			open (my $fh, '<', $template ) || die "Cannot open $template for file: $file $! \n"; 
			my @a=<$fh>; 
			close $fh; 
			if (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a))
			{
				my $analyzerObj = analyzer MENU::Analyzer($file);
				my $prodTop = $ENV{$analyzerObj->getProdTop} . '/sql/';
				my $file2 = $prodTop . basename($file); 
				#print "DEBUG 205: File $file \n" if -f $file; 
				
				if (-f $file2) 
				{
					unlink($file2) or warn "Unable to delete $file2: $!"; 
				}
				else 
				{
					open (my $fh, '<', $file ) || die $!; my @file=<$fh>; close $fh;
					#get the CP_FILE param 
					my ($CPFile) = grep(/REM\s?CP_FILE\:/,@file);
					chomp($CPFile); 
					$CPFile =~ s/REM\s+CP_FILE:\s+//g; 
					$CPFile = $prodTop . $CPFile; 
					if (-f $CPFile)
					{
						unlink($CPFile) or warn "Unable to delete $CPFile: $!"; 
					}
				}
			}
		}	
	}
	elsif ($mode eq 'get') 
		{
			my @exists;
			foreach (@validAnalyzers) 
			{
				my $f = $_; 
				my ($file, $template) = split('::', $f); 
				$template = $+ if $template =~ /PROG_TEMPLATE:\s+?(\w+\.ldt)/; 
				$template = 'analyzers/template/' . $template; 
				open (my $fh, '<', $template ) || die "Cannot open1 $template $! \n"; 
				my @a=<$fh>; 
				close $fh; 
				if (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a))
				{
					my $analyzerObj = analyzer MENU::Analyzer($file);
					my $prodTop = $ENV{$analyzerObj->getProdTop} . '/sql/';
					$file = $prodTop . basename($file);
					if (-f $file) #exists in PROD_TOP/sql, so "installed" 
					{
						my $title = $analyzerObj->getTitle();
						#check to see if the hash already contains this title 
						# so as to not add a duplicate. 
						my $match; 
						for my $id (keys %$analyzers)
						{
							if ($title eq $$analyzers{$id}->{'CCPTITLE'})
							{
								$match = 'Y';
								$$analyzers{$id}->{'FILE_PROD_TOP'}=$file;
								last; 
							}
						}
						if ($match ne 'Y')
						{
							$i++;
							$$analyzers{$i}->{'ID'}=$i; 
							$$analyzers{$i}->{'FILE_PROD_TOP'}=$file; 
							$$analyzers{$i}->{'SELECTED'}='+'; 
							$$analyzers{$i}->{'CCPTITLE'}=$title; 
						}
					}
				}
			}
			return($analyzers); 
		}
	elsif ($mode eq 'TARGETED') 
	{
		for my $id (keys %$analyzers)
		{
			if ($$analyzers{$id}->{'SELECTED'} =~ /\+/ && $$analyzers{$id}->{'EXECUTABLE'} =~ /^\$/ )
			{
				my $prodTop = $+ if $$analyzers{$id}->{'EXECUTABLE'} =~ /\$(\w+?_\w+?)\//; 
				$prodTop = $ENV{$prodTop}; 
				my $file = $prodTop . '/sql/' . basename($$analyzers{$id}->{'EXECUTABLE'}); 
				unlink($file) or warn "Unable to delete \"$file\": $!" if -f $file;
			}
		}
	}
	return(); 
}#END deleteFilesCPP
		
# +---------------------------
# | sub dropObjects
# | 
# | Drops database objects as passed in via a hash with a "DROP" key 
# | objects are dropped if they have SELECTED eq '+'; 
# +---------------------------
sub dropObjects 
{
	my ($analyzers) = @_; 
	my $i = 0; 
	my $cs = $main::connStrg->getConnStrg();
	# use Data::Dumper;
	# print Dumper(@_); 
	# print Dumper(%$analyzers);
	# print "waiting for return: DropObjects \n"; 
	# <STDIN>; 


	unlink "sql/drop.sql" if -f "sql/drop.sql"; 
	#build a SQL File with the drop statements. 
	open (my $fh, '>', 'sql/drop.sql' ) || die "Cannot open sql/drop.sql: $! \n"; 

	for my $id (keys %$analyzers) 
		{
			if ($$analyzers{$id}->{'SELECTED'} =~ /\+/ && length($$analyzers{$id}->{'DROP'}) > 5)
			{ 
				#print $fh "$$analyzers{$id}->{'DROP'} \;\n";
				print $fh "$$analyzers{$id}->{'DROP'}\n";
				$i++; 
			} 
		}
	print $fh "\nexit;"; 
	close $fh; 
	system("clear"); 
	#show the drop statements & give the user a chance to abort 
	if ($i >= 1) 
	{
		print "\n  INFO: About to run the following statments: \n   ...\n\n"; 
		open (my $fh, '<', 'sql/drop.sql' ) || die "Cannot open sql/drop.sql: $! \n";
		while (<$fh>)
		{
			print "    $_"; 
		}
		close $fh;
		print BOLD WHITE ON_BLUE "\n  [B] to go Back or [Enter] to Continue:", RESET; 
		my $cont; 
		chomp($cont=<STDIN>); 
		return if $cont =~ /^b$/i ; 
		#run the SQL 
		my $status = system("sqlplus -L -S $cs \@sql/drop.sql") if length($cont) < 1; 
		#print "   SQLPLUS exited with status: $status, Press [Enter] to Continue:"; 
		#<STDIN>; 
	}

	unlink "sql/drop.sql" if -e "sql/drop.sql";
	return();
}	
	
	
	
# +---------------------------+
# | sub: getInstalledDBobjs 
# +---------------------------+
# | Desc: gets all objects which are possible to create from all SQL files under $PWD+
# | Filters list of all objects by objects that are installed. 
# +---------------------------+
# | Args: none 
# +---------------------------+
# | Returns: %instDBObjs hash: 
# | 
# | 
# | 
# | 
# +---------------------------+
sub getInstalledDBobjs
{
	my @sqlFiles; 
	my $line; 
	my %instDBObjs;
	my $id = 0; 
	my @DBObjs; 
	my @sql;  
	my $cs = $main::connStrg->getConnStrg();
	my $appsUser = $+ if $cs =~ /(\w+?)\//;
	
			find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @sqlFiles, $File::Find::name if grep (/create\s.*?(package\sbody|table|view|function|package)/i, @file) || grep (/create\s*?or\s*?replace/i,@file); }, 'analyzers/SQL' );
		
	foreach (@sqlFiles) 
	{
		my $file = $_; 
		open (my $fh, '<', $file ) || die "Cannot open $file : $! \n";
		while (<$fh>)
		{
			$line = $_; 
			$line = clean($line); 
			$line = <$fh> until eof($fh) || $line =~ /create/i;
			if ($line =~ /^\s*create\s.*?(package\sbody|table|view|function|package)/i || $line =~ /create\s*?or\s*?replace/i)  
			{
				my ($objectName, $objectType);
				$objectType = $+; 
				if (! defined $objectType	)
				{
					for (0..1)
					{
						$line .= <$fh>;
						$line = clean($line);
					} 
					$line =~ /^\s*(create)|(create\sor\sreplace)\s.*?(package\sbody|table|view|function|package)/i; 
					$objectType = $+;
					if (! defined $objectType)
					{
						warn "   WARNING: The Database Object Created by the following file could not be determined:\n   $file \n   ACTION: Manually open/view the file to determine if there are \n   database objects created, then drop those objects manually.\n"; 
						print "   Press [Enter] to Continue:"; 
						my $g = <STDIN>; 
					}
				}
				#keep appending the next line until we have the object name. 
				until (defined $objectName && defined $objectType) 
					{
						$line =~ s/\s{2,}/ /g;
						$line =~ s/apps\.//ig; 
						$objectName = $+ if $line =~ /$objectType\s(\w*)/i;
						$line .= <$fh>;
						$line = clean($line);
						last if eof($fh); 
					}
				
				if (defined $objectName && defined $objectType) 
					{
						next if $objectType eq 'PACKAGE BODY'; 
						$id++; 
						my $statement = "drop " . $objectType . " $appsUser\." . uc($objectName) . ';'; 
						$objectName=uc($objectName); 
						my $dup = 'N'; 
						for my $ids (keys %instDBObjs)
						{
							$dup = 'Y' if ($instDBObjs{$ids}->{'NAME'} eq $objectName && $instDBObjs{$ids}->{'TYPE'} eq $objectType); 
						}
						if ($dup ne 'Y') 
						{
							$instDBObjs{$id}->{'FILE'}=$file; #file where the create statement was found 
							$instDBObjs{$id}->{'DROP'}=$statement;
							$instDBObjs{$id}->{'NAME'}=$objectName;
							$instDBObjs{$id}->{'TYPE'}=$objectType;
							$instDBObjs{$id}->{'SELECTED'}='+';
						}
					}
				}
		}
		close $fh; 
	}
my $i=0; 
my $in = qq(\(\');
	for my $id (keys %instDBObjs)
	{
		$i++; 
		$in .= $instDBObjs{$id}->{'NAME'} . "\'," if $i == 1; ; 
		$in .= "\'" . $instDBObjs{$id}->{'NAME'} . "\'," if $i > 1;
	} 
	$in =~ s/,$//; 
	$in .= qq(\)\;); 

@sql = qq(
set serveroutput off
set term off 
set verify off 
SET PAGESIZE 0

set head off\n\n
spool "sql/installed_objs.lst" 

SELECT object_name ||':'|| object_type
FROM user_objects
WHERE upper(object_name) in 
$in
spool off; 
exit); 

open (my $fh, '>', 'sql/checkObjs.sql' ) || die "Cannot open sql/checkObjs.sql: $! \n"; 
print $fh @sql;  
close $fh;
my $status = system("sqlplus -l -s $cs \@sql\/checkObjs.sql"); 

	open (my $fh1, '<', "sql/installed_objs.lst" ) || die "Cannot open sql/installed_objs.lst: $! \n"; 
	while (<$fh1>)
	{
		my $line = $_; 
		last if $line =~ /selected/; 
		$line = clean($line); 
		$line =~ s/\s{2,}//g; 
		push @DBObjs, $line if length($line) > 1; 
	}
	close $fh1;
	

	#filter the list of instAnalyzers with what's in the DB from installed_objs.lst 
	#object_name ||':'|| object_type 
	for my $ids (keys %instDBObjs)
	{
		#grep to see if the NAME is in @DBObjs;
		if (! grep /$instDBObjs{$ids}->{'NAME'}\:/, @DBObjs )
		{
			#delete $instDBObjs{$ids}->{'DROP'};
			delete $instDBObjs{$ids}; 
		}
	}

	unlink 'sql/checkObjs.sql' if -e 'sql/checkObjs.sql'; 
	unlink 'sql/installed_objs.lst' if -e 'sql/installed_objs.lst'; 

	return (\%instDBObjs); 
} #end Sub getInstalledDBobjs
	
# +---------------------------
#| sub linkObjToAnalyzer
#| Links a DB object (probably a dependency) back to an analyzer Title  
#| 
# +---------------------------
sub linkObjToAnalyzer
{
	my ($objectName, $objectType, $file) = @_; 
	my $title; 
	#check if file is an analyzer SQL 
	open (my $fh, '<', $file ) || warn "Cannot open $file $! \n"; 
	my @a = <$fh>; 
	close ($fh); 
	if (grep(/ANALYZER_BUNDLE_START/, @a))
	{
		#This is an analyzer. get the title
		($title) = grep(/MENU_TITLE:/, @a); 
		$title =~ s/^REM\s+MENU_TITLE:\s*//g; 
		chomp($title);
		return ($title); 
	}
	else 
	{
	my $dir = dirname($file);
	my $fileOnly = basename($file); 
	my @files; 
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @files, $File::Find::name if grep (/ANALYZER_BUNDLE_START/i, @file) &&  grep (/$fileOnly/i,@file); }, $dir );
	
	my $elems = scalar(grep {defined $_} @files); 
	if ($elems >= 1)
	{
		for (0 .. 1) 
		{
			my $analyzerFile = shift @files;
			open (my $fh, '<', $analyzerFile ) || die "Cannot open $analyzerFile $! \n"; 
			my @a = <$fh>; 
			close $fh; 
			($title) = grep(/MENU_TITLE:/, @a); 
			$title =~ s/^REM\s+MENU_TITLE:\s*//g; 
			chomp($title);
			return ($title); 
		}
	}
	else 
	{
		print "   ERROR: Unable to trace origins of object: $objectName Type: $objectType, to a file\n   Press [Enter] to Continue:"; 
		<STDIN>; 
		return("Analyzer UNKNOWN, Object: $objectName($objectType)"); 
	}
}	

}#END linkObjToAnalyzer 



# +---------------------------+
# | sub:  getAnalyzersNoCCP
# +---------------------------+
# | Desc: locates analyzer packages 
# | which have no associated CPP and 
# | provides a menu interface to drop 
# | those packages 
# +---------------------------+
# | Args: none 
# +---------------------------+
# | Returns: none 
# +---------------------------+
sub getAnalyzersNoCCP 
{
	my $cs = $main::connStrg->getConnStrg();
	my @allDBObjs; 
	my $analyzerDBObjs=getInstalledDBobjs();
	
	for my $id (keys %$analyzerDBObjs)
		{
			if (defined($$analyzerDBObjs{$id}->{'NAME'})) 
			{
				push @allDBObjs, $$analyzerDBObjs{$id}->{'NAME'}; 
			}
		} 
		
	#get all the CCP DB objects from my $analyzers = getInstalledCCPs(); 
	my $CCPs = getInstalledCCPs();  

	#@CCPDBObjs the list of analyzer DB objects tied to CCPs 
	my @CCPDBObjs; 
	for my $id (keys %$CCPs)
		{
			if (defined($$CCPs{$id}->{'CCP'}) && $$CCPs{$id}->{'EXECUTABLE'} !~ /^\$/) 
			{
				push @CCPDBObjs, $$CCPs{$id}->{'EXECUTABLE'}; 
			}
		}

	#if the object exists in @allDBObjs, but not in CCPDBObjs, add to @delta array 
	my $match; 
	my %delta; 
	my $i = 0; 
	foreach my $obj (@allDBObjs) 
	{
		#if (($match) = grep (/$obj/, @CCPDBObjs))
		if (! grep (/$obj/, @CCPDBObjs))
		{
			$i++; 
			$delta{$i}->{'OBJNAME'} = $obj;
			$delta{$i}->{'SELECTED'} = ' ';
			$delta{$i}->{'DROP'} = "drop package $obj;";
		}
	}
	
	my $invSel; 
	my $userSel; 
	until (1 == 2) 
	{
		my ($spc1, $spc2, $verLgth); 
		system("clear"); 
		print "          "; 
		print BOLD WHITE ON_BLUE "Analyzer Database Objects Without Concurrent Programs", RESET;
		print BOLD WHITE ON_GREEN "\n\n  Legend: [+] = Selected To be Dropped"; 
		print BOLD WHITE ON_BLUE "\n  \#  SELECTED  OBJECT NAME                  ", RESET; 
		print "\n"; 
		
		$| = 1;
		foreach my $ID (sort { $a <=> $b } keys %delta) 
		{
			$spc1 = "  " if $ID > 9; 
			$spc1 = "   " if $ID <= 9; 
			my $tabs; 
			my $length=((length($delta{$ID}->{'OBJNAME'}) + length("[$ID]"))); 
			$tabs = "\t\t\t\t" if $length > 12 && $length <= 18; 
			$tabs = "\t\t\t" if $length >= 19 && $length <= 28; 
			$tabs = "\t\t" if $length >= 28 && $length <= 34; 

			$tabs = "\t" if $length > 35;  
			print " [$ID]", $spc1, "[$delta{$ID}->{'SELECTED'}]","     $delta{$ID}->{'OBJNAME'} \n";  
		
		}
		
		print BOLD WHITE ON_BLUE "\n  [D]rop Selected | [B]ack | [H]elp | E[x]it", RESET; 
		print BOLD WHITE ON_YELLOW "Invalid Selection", RESET if $invSel != 0; 
		print "   \n   ...\n   Toggle Selections by Number\n";
		print "   Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 

	if ($delta{$userSel} =~ /\d{1,3}/) 
	{
		if ($delta{$userSel}->{'SELECTED'} =~ /\+/) 
		{$delta{$userSel}->{'SELECTED'} = ' ';}
		elsif ($delta{$userSel}->{'SELECTED'} =~ /\s{1}/)
		{$delta{$userSel}->{'SELECTED'} = '+';}
		else
		{$invSel = 1}
	}
	elsif ( $userSel =~ /^b$/i )
	{return;}
	elsif ($userSel =~ /^d$/i)
	{
		if (! grep { $delta{$_}->{'SELECTED'} eq '+' } keys %delta)
		{
			print "   INFO: No Objects Selected. Press [Enter] to Continue:" ;
			<STDIN>; 
		}
		else
		{
			dropObjects(\%delta); 
			return(); 
		}
	}
	elsif ($userSel =~ /^h$/i) 
	{
			system("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "  Drop Analyzer Objects Help", RESET, "\n"; 
			print qq (
 o This menu displays Analyzer objects that are not associated with a Concurrent Program  
 o These objects may have been loaded via a Menu option or outside the bundle by a 
    stand alone (non-bundled) download 
 o Whenever an analyzer which uses a database object is run, the Bundle Menu loads
   the object 

Press [Enter] to Continue:); 
			my $w = <STDIN>;
	}
	elsif ($userSel =~ /^x$/i)
	{
		exitLog(); 
	} 
	else
	{
		$invSel = 1; 
		#repeat the menu again 
		#need to write a loop around the line 146 foreach menu to redisplay it 
	}

	}#end until (1 == 2)

}
#end Sub getAnalyzersNoCCP



# +---------------------------
#| sub removeConcProgs
#| Removes Conc Program and Executables 
#| 
# +---------------------------
sub removeConcProgs
{
	my ($analyzers) = @_;
	print "   INFO: Running removeConcProgs() to remove Concurrent Programs \n"; 
	my $in = qq(\(\');
	my $i = 0; 
	my $cs = $main::connStrg->getConnStrg();
	for my $id (keys %$analyzers)
	{
		if ($$analyzers{$id}->{'SELECTED'} =~ /\+/ && defined($$analyzers{$id}->{'CCP'})) 
		{
			$i++; 
			$in .= $$analyzers{$id}->{'CCP'} . "\'," if $i == 1; ; 
			$in .= "\'" . $$analyzers{$id}->{'CCP'} . "\'," if $i > 1;
		}
	} 
	$in =~ s/,$//; 
	$in .= qq(\)\;); 

	if ($i == 0) 
		{
		#print "   INFO: No Analyzer Concurrent Program Defintions to Remove \n   Press [Enter] to Continue:"; 
		#<STDIN>; 
		return(); 
		}

unlink('sql/get_installed_ccps.sql') if -f 'sql/get_installed_ccps.sql';
unlink('sql/installed_ccps.lst') if -f 'sql/installed_ccps.lst'; 

my @sql = qq(
set serveroutput on
set term off 
set verify off 
set head off\n\n
spool "sql/installed_ccps.lst" 

SELECT fcp.concurrent_program_name ||':'|| fav.application_short_name ||':'|| fe.executable_name
FROM fnd_application_vl fav, fnd_executables fe, fnd_concurrent_programs fcp
WHERE fcp.application_id = fav.application_id 
AND fe.application_id = fav.application_id 
AND fe.executable_id = fcp.executable_id 
AND fcp.concurrent_program_name in 
$in
; 

spool off; 
exit; );

	open (my $fh, '>', 'sql/get_installed_ccps.sql' ) || die "Cannot open sql/get_installed_ccps.sql $! \n"; 
	print $fh @sql;  
	close $fh; 	
	my $status = system("sqlplus -l -s $cs \@sql\/get_installed_ccps.sql");
	open (my $fh1, '<', 'sql/installed_ccps.lst' ) || die "Cannot open sql/installed_ccps.lst: $! \n"; 

	my @a; 
	while (<$fh1>) 
	{
		my $ln = $_; 
		$ln=clean($ln); 
		push @a, $ln if $ln =~ /^\w+\:/; 
	}
	close $fh1; 

	my @sql2;
	my $elems = scalar(grep {defined $_} @a);
	if ($elems > 0)
	{
		foreach (@a)
		{
			last if $_ =~ /selected\./;
			my ($CCP, $appShortName, $exeName) = split(':',$_);
			$exeName =~ s/\s//g; #clean($appShortName) 
			my $statement=qq(exec fnd_program.delete_program(program_short_name => '$CCP', application => '$appShortName');\nexec fnd_program.delete_executable(executable_short_name => '$exeName', application => '$appShortName');); 
			push @sql2, "$statement\n\n"; 
		}
		push @sql2, "\nCOMMIT; \n \/ \n exit;\n\n";
	} 

	unlink "sql/run_fnd_program_del_prog.sql" if -f "sql/run_fnd_program_del_prog.sql"; 
	open (my $fh, '>', 'sql/run_fnd_program_del_prog.sql' ) || die "Cannot open sql/run_fnd_program_del_prog.sql $! \n"; 
	print $fh @sql2;  
	close $fh;
	my $elems = scalar(grep {defined $_} @sql2);
	if ($elems > 0) 
	{	
		my $status = system("sqlplus -l -s $cs \@sql\/run_fnd_program_del_prog.sql");
		#print "   INFO: removeConcProgs(): SQLPLUS command exited with status: $status \n"; 
		#print "   Press [Enter] to Continue:";
		#<STDIN>; 
	} 
	else 
	{
		print "   INFO: removeConcProgs: No Concurrent Programs to Remove \n\n"; 
	}
	
	unlink "sql/run_fnd_program_del_prog.sql" if -f "sql/run_fnd_program_del_prog.sql"; 
	unlink('sql/get_installed_ccps.sql') if -f 'sql/get_installed_ccps.sql';
	unlink('sql/installed_ccps.lst') if -f 'sql/installed_ccps.lst'; 
	return(); 
}#end removeConcProgs
	
# +---------------------------
#| sub removeReqGroupEntries
#| 
#| Uses fnd_program.remove_from_group to delete Concurrent Programs from any request groups 
#| they are associated with
# +---------------------------
sub removeReqGroupEntries
{
	my ($analyzers) = @_; 
	my $in = qq(\(\');
	my $i = 0; 
	my $cs = $main::connStrg->getConnStrg();
	print "\n  INFO: Running removeReqGroupEntries() to remove Request Group Entries. \n";
	
	for my $id (keys %$analyzers)
	{
	if ($$analyzers{$id}->{'SELECTED'} =~ /\+/ && defined($$analyzers{$id}->{'CCP'})) 
		{
			$i++; 
			$in .= $$analyzers{$id}->{'CCP'} . "\'," if $i == 1; ; 
			$in .= "\'" . $$analyzers{$id}->{'CCP'} . "\'," if $i > 1;
		}
	} 
	$in =~ s/,$//; 
	$in .= qq(\)\;); 
	
	if ($i == 0) 
		{
			#print "   INFO: No Analyzer Request Group Entries to Remove \n   Press [Enter] to Continue:"; 
			#<STDIN>; 
			return(); 
		}
		
unlink('sql/get_req_groups.sql') if -f 'sql/get_req_groups.sql';
unlink('sql/installed_req_groups.lst') if -f 'sql/installed_req_groups.lst'; 

my @sql = qq(
set serveroutput on
set term off 
set verify off
set head off\n\n
spool "sql/installed_req_groups.lst" 

SELECT 
cp.concurrent_program_name ||':'|| fav.application_name ||':'|| rg.request_group_name ||':'|| fav.application_short_name
FROM 
FND_APPLICATION_VL fav, 
fnd_request_groups rg,
fnd_request_group_units rgu,
fnd_concurrent_programs cp,
fnd_concurrent_programs_tl cpt
WHERE fav.application_id = rg.application_id
AND rg.request_group_id = rgu.request_group_id
AND rgu.Request_Unit_Id = cp.concurrent_program_id
AND cp.concurrent_program_id = cpt.concurrent_program_id
AND cpt.language = USERENV('LANG')
AND cp.Concurrent_Program_Name in 
$in
; 

spool off; 
exit; );

	open (my $fh, '>', 'sql/get_req_groups.sql' ) || die "Cannot open sql/get_req_groups.sql $! \n"; 
	print $fh @sql;  
	close $fh; 
	my $status = system("sqlplus -l -s $cs \@sql\/get_req_groups.sql");
	print "   ERROR: Unable to run SQL*PLUS for \"sql\get_req_groups.sql\" " if $status != 0; 
	open (my $fh1, '<', 'sql/installed_req_groups.lst' ) || die "Cannot open sql/installed_req_groups.lst: $! \n"; 
	my @a; 
	while (<$fh1>) 
	{
		my $ln = $_; 
		$ln=clean($ln); 
		push @a, $ln if $ln =~ /^\w+\:/; 
	}
	close $fh1; 

	my @sql2;
	my $elems = scalar(grep {defined $_} @a);
	if ($elems > 0)
	{
		push @sql2, "SET ESCAPE ON\n"; 
		foreach (@a)
		{
			my ($CCP, $appName, $reqGrp, $appShortName) = split(':',$_);
			$appShortName =~ s/\s//g; #clean($appShortName) 
			$reqGrp =~ s/&/\\\&/g; 	
			my $statement=qq(exec fnd_program.remove_from_group (program_short_name => '$CCP', program_application => '$appName', request_group => '$reqGrp', group_application =>'$appShortName');); 
			#print "\n****\nCCP: $CCP\nAppName: $appName\nReqGrp: $reqGrp\nShortName: $appShortName\n****\n";
			push @sql2, "$statement\n\n"; 
		}
		push @sql2, "\nCOMMIT; \n \/ \n exit;\n\n";
	} 

	unlink "sql/run_fnd_program_remove_group.sql" if -f "sql/run_fnd_program_remove_group.sql"; 
	open (my $fh, '>', 'sql/run_fnd_program_remove_group.sql' ) || die "Cannot open sql/run_fnd_program_remove_group.sql $! \n"; 
	print $fh @sql2;  
	close $fh;
	my $elems = scalar(grep {defined $_} @sql2);

	if ($elems > 0) 
	{
		my $status = system("sqlplus -l -s $cs \@sql\/run_fnd_program_remove_group.sql");
	} 
	else 
	{
		print "   INFO: No Request Groups to Remove \n\n"; 
	}
	unlink 'sql/run_fnd_program_remove_group.sql' if -f 'sql/run_fnd_program_remove_group.sql';
	unlink('sql/get_req_groups.sql') if -f 'sql/get_req_groups.sql';
	unlink('sql/installed_req_groups.lst') if -f 'sql/installed_req_groups.lst'; 
	return(); 

}#end removeReqGroupEntries sub	

# +---------------------------
# | sub clean 
# | cleans carriage returns off a var 
# +---------------------------
sub clean 
	{
		my ($var) = @_; 
		chomp($var);
		$var =~ s/\n//g;
		$var =~ s/\r//g;
		return($var); 
	}

	
# +---------------------------
# | sub getLargestHashKey
# | 
# | returns the largest key from a given hash. 
# +---------------------------
sub getLargestHashKey
{
	my $hash = shift;
	keys %$hash;
	my ($large_key, $large_val) = each %$hash;
	while (my ($key, $val) = each %$hash) 
	{
		if ($key > $large_key) 
		{
			$large_key = $key;
			$large_key = $key;
		}
	}
	return $large_key; 
}

# +---------------------------+
# | sub:  getNewAnalyzers
# +---------------------------+
# | Desc: searches for the 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: none - but modifies a hash ref of analyzers 
# +---------------------------+

sub getNewAnalyzers
{
	my ($analyzers) = @_; 

	#find all the analyzers_<date> dirs and locate the one created most recently.. 
	my %dirs; 
	# find( sub {return unless -d && $_ =~ /analyzers_/ ; $dirs{(stat($File::Find::name))[9]}->{'DIR'}=$File::Find::name}, cwd() );
	find( sub {return unless -d && $_ =~ /analyzers_/ ; $dirs{$File::Find::name}->{'TIME'}=(stat($File::Find::name))[9]}, cwd() );

	my $mostRecentDir = _getMax(); 
	
	my @old;
	my @new; 
	#get all the SQL files in the most recent analyzers_ dir 
	# find( sub {return unless /\.sql$/; push @old, basename($File::Find::name)}, $mostRecentDir);
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @old, $File::Find::name if grep (/ANALYZER_BUNDLE_START/, @file); }, $mostRecentDir );
	#get all the SQL files in the new "analyzers" dir 
	# find( sub {return unless /\.sql$/; push @new, basename($File::Find::name)}, 'analyzers/SQL');
	find( sub {return unless /\.sql$/; open (my $fh, '<', $_ ) || die $!; my @file=<$fh>; close $fh; push @new, $File::Find::name if grep (/ANALYZER_BUNDLE_START/, @file); }, 'analyzers/SQL' );

	
	my %old; 
	my %new; 
	#create hash with file -> CCPNAME 
	foreach my $file (@new)
	{
		open (my $fh, '<', $file ) || die "Cannot open $file $! \n"; 
		my @a = <$fh>; 
		close $fh; 
		my ($CCP) = grep(/REM PROG_NAME:\s*(\w+)\s*$/, @a); 
		$CCP = $+ if $CCP =~ /REM PROG_NAME:\s*(\w+)\s*$/; 
		# print "$file: ccp \'$CCP\' \n"; 
		# <STDIN>; 
		$new{$file}=$CCP;
	}
	
	foreach my $file (@old)
	{
		open (my $fh, '<', $file ) || die "Cannot open $file $! \n"; 
		my @a = <$fh>; 
		close $fh; 
		my ($CCP) = grep(/REM PROG_NAME:\s*(\w+)\s*$/, @a); 
		$CCP = $+ if $CCP =~ /REM PROG_NAME:\s*(\w+)\s*$/; 
		# print "$file: ccp \'$CCP\' \n"; 
		# <STDIN>; 
		$old{$file}=$CCP;
	}

	#compare %new to %old .. 

	foreach my $newFile (keys %new)
	{
		foreach my $oldFile (keys %old) 
		{
			if ($new{$newFile} eq $old{$oldFile})
			{
				delete $new{$newFile}; 
			}
		}
	}
	
#the %new hash has been filtered down to only new analyzers 
#which is based on the CCP name existing in the newly unzipped 
#analyzers dir and not existing in the old analyzer_<date> dir
	
		#Get the largest ID from $analyzers hash and set ID to it. 
	my $ID = getLargestHashKey(\%$analyzers); 
	
	for my $newFile(keys %new)
	{
			my ($compat, $valid) = checkCompat($newFile);
			if ($valid > 0) 
			{
				my $analyzer = analyzer MENU::Analyzer($newFile);
				next if length($analyzer->getTitle()) < 3; 
				$ID++;
				$$analyzers{$ID}->{'ID'}=$ID;
				# find( sub {print "DEBUG:2412: $newFile\n"; return unless /$newFile/; $$analyzers{$ID}->{'FILE'}=$File::Find::name}, 'analyzers/SQL');
				
				$$analyzers{$ID}->{'CURRFILEVER'}='NONE  '; #intentionally left 2 spaces after "NONE  " for formatting in the menus.
				$$analyzers{$ID}->{'FILE'}=$newFile; 
				$$analyzers{$ID}->{'FAM'}=$analyzer->getFam();
				$$analyzers{$ID}->{'CCP'}=$analyzer->getCCPName();   
				$$analyzers{$ID}->{'NEWFILEVER'}=$analyzer->getFileVer();
				$$analyzers{$ID}->{'CCPTITLE'}=$analyzer->getTitle();
			}
	}

## private sub 
sub _getMax	
{
	my $max = 0; 
	my $maxDir; 
	for my $dir (keys %dirs)
	{
		if ($dirs{$dir}->{'TIME'} > $max)
		{
			$max = $dirs{$dir}->{'TIME'}; 
			$maxDir = $dir; 
		}
	}
	return ($maxDir);  
}	
	
}



	
return (1); 

__END__ 
