

        SET VERIFY OFF
        SET ECHO OFF
        exit; 
