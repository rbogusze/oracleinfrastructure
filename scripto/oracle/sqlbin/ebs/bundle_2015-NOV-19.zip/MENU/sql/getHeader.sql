
SET HEAD OFF; 
SET VERIFY OFF; 
SPOOL 'sql/header.lst'; 
select text from user_source where name = 'AR_AUTOINVOICE_ANALYZER_PKG' and line < 5; 
SPOOL OFF; 
exit; 
	