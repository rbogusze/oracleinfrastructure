
	SPOOL "sql/getReqGrps.lst";
	SET HEAD OFF; 
	SET SERVEROUTPUT ON
	SET TERM OFF
	SET VERIFY OFF
	SELECT fa.application_short_name || ':' || frg.request_group_name || ':' || frg.request_group_code || ':' || fat.application_name || ':' || count(frv.RESPONSIBILITY_NAME)
	FROM fnd_application fa, fnd_request_groups frg, fnd_application_tl fat, FND_RESPONSIBILITY_VL frv
	WHERE frg.application_id = fa.application_id
	AND frv.REQUEST_GROUP_ID (+) = frg.REQUEST_GROUP_ID
	AND fat.application_id = frg.application_id
	AND upper(fa.application_short_name) = 'SQLAP'
	group by fa.application_short_name || ':' || frg.request_group_name || ':' || frg.request_group_code || ':' || fat.application_name; 
	SPOOL OFF;
	EXIT;