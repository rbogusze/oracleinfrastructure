
SPOOL "sql/getReqGrpResp.lst"
SET HEAD OFF 
SET SERVEROUTPUT ON
SET TERM OFF
SET VERIFY OFF
SET FEEDBACK OFF
SELECT frv.RESPONSIBILITY_NAME
FROM fnd_request_groups frg, fnd_application fa, FND_RESPONSIBILITY_VL frv
WHERE fa.application_id = frg.application_id
AND frv.REQUEST_GROUP_ID = frg.REQUEST_GROUP_ID
AND frg.request_group_name = 'Intercompany Drop Ship'
AND fa.application_short_name = 'SQLAP'; 
SPOOL OFF
EXIT
/