REM $Id: ap_accounting_analyze.sql, 200.4 2015/10/23 10:41:02 ARNAL.ROBERT Exp $
REM +==================================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                            |
REM |                    Redwood Shores, California, USA                               |
REM |                         All rights reserved.                                     |
REM +==================================================================================+
REM |                                                                                  |
REM | FILENAME                                                                         |
REM |    ap_accounting_analyze.sql                                                     |
REM |                                                                                  |
REM | DESCRIPTION                                                                      |
REM |    Wrapper SQL to submit the ap_accounting_analyzer_pkg.main procedure                      |
REM |                                                                                  |
REM | HISTORY                                                                          |
REM |                                                                                  |
REM +==================================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Payables Create Accounting Analyzer
REM
REM MENU_START
REM
REM SQL: Run Payables Create Accounting Analyzer
REM FNDLOAD: Load EBS Payables Create Accounting Analyzer as a Concurrent Program
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  Payables Create Accounting Analyzer  [Doc ID: 1665706.1]
REM
REM  Compatible with: [12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package ap_accounting_analyzer_pkg as APPS to create an HTML report 
REM
REM    (2) Install EBS Payables Create Accounting Analyzer as a concurrent program
REM        o Will run FNDLOAD as APPS 
REM        o Will define the analyzer as a concurrent executable/program 
REM        o Will add the analyzer to default request group Payables Reports Only
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: AP_TOP
REM DEF_REQ_GROUP: Payables Reports Only
REM PROG_NAME: APCAANL 
REM PROG_TEMPLATE: AP_Create_AcctgAZ.ldt
REM APP_NAME: Payables
REM PROD_SHORT_NAME: SQLAP 
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ap_accounting_analyzer.sql 
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "~"
PROMPT
PROMPT Submitting EBS Payables Create Accounting.

PROMPT ===========================================================================
PROMPT Enter the INVOICE ID or press enter to leave blank 
PROMPT ===========================================================================
PROMPT
ACCEPT p_invoice_id NUMBER  DEFAULT '-1' PROMPT 'Enter the invoice_id: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the CHECK ID or press enter to leave blank 
PROMPT ===========================================================================
PROMPT
ACCEPT p_check_id NUMBER  DEFAULT '-1' PROMPT 'Enter the check_id: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the maximum number of rows to display on row limited queries [10] 
PROMPT ===========================================================================
PROMPT
ACCEPT p_max_output_rows NUMBER  DEFAULT '10' PROMPT 'Enter the Maximum Rows to Display: '
PROMPT
PROMPT
DECLARE
   p_invoice_id                   NUMBER         := '~p_invoice_id';
   p_check_id                     NUMBER         := '~p_check_id';
   p_max_output_rows              NUMBER         := '~p_max_output_rows';

BEGIN
IF p_invoice_id = -1 THEN
   p_invoice_id := NULL;
END IF;
IF p_check_id = -1 THEN
   p_check_id := NULL;
END IF;

   ap_accounting_analyzer_pkg.main(
     p_invoice_id                   => p_invoice_id
    ,p_check_id                     => p_check_id
    ,p_max_output_rows              => p_max_output_rows  );

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);

END;
/
exit;