REM $Id: ar_periodclose_analyze.sql, 200.1 2015/08/07 11:55:15 vcrisost Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ar_periodclose_analyze.sql                                        |

REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit ar_periodclose_analyzer_pkg.main             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 07-Aug-2015 vcrisost Created                                            |
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Oracle Receivables Period Close Analyzer
REM
REM MENU_START
REM
REM SQL: Run Oracle Receivables Period Close Analyzer
REM FNDLOAD: Load Oracle Receivables Period Close Analyzer
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  Oracle Receivables Period Close Analyzer [Doc ID: 2019636.1]
REM
REM  Compatible with: [12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package ar_periodclose_analyzer_pkg.main as APPS to create an HTML report 
REM
REM    (2) Install Oracle Receivables Period Close Analyzer as a concurrent program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group Payables Reports Only
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: AR_TOP
REM DEF_REQ_GROUP: Receivables All
REM PROG_NAME: ARPERANL
REM PROG_TEMPLATE: arperanl.ldt
REM APP_NAME: Receivables
REM PROD_SHORT_NAME: AR
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ar_periodclose_analyzer.sql 
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END




SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "~"

PROMPT
-- PSD #1
PROMPT Submitting Oracle Receivables Period Close Analyzer
PROMPT ===========================================================================
PROMPT Enter the org_id for the operating unit.  This parameter is required.
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 1 NUMBER DEFAULT -1 -
       PROMPT 'Enter the org_id(required): '

PROMPT
PROMPT ===========================================================================
PROMPT Enter Period Name. This parameter is required.  
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 2 CHAR -
       PROMPT 'Enter Period Name(required): '


PROMPT


DECLARE
-- PSD #3
  l_org_id         NUMBER := '~1';
  l_period_name    VARCHAR2(10) := '~2';

BEGIN

-- PSD #4
  ar_periodclose_analyzer_pkg.main(
      p_org_id => l_org_id,
	    p_period_name => l_period_name );

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit; 
