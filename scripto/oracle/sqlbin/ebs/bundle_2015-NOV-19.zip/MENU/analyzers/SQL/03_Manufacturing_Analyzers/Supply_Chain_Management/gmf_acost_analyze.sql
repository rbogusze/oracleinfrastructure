REM $Id: gmf_acost_analyze.sql, 200.4 2015/15/01 23:27:42 arobert Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    gmf_acost_analyze.sql                                                |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the gmf_acost_analyzer_pkg.main procedure      |
REM |                                                                         |
REM | HISTORY                                                                 |
REM |    03-JUL-15 : Peter Wickham : Initial publication  (v 200.1)           |
REM |    10-AUG-15 : Peter Wickham :     (v 200.3)                            |
REM |                 Wrapper updated to include Analyzer Bundle              |
REM |                    perl variables (as per Kyle Harris)                  |
REM |    13-AUG-15 : Peter Wickham :     (v 200.4)                            |
REM |                 No change in this (Wrapper) file                        |
REM |                 Package create script updated for Analyzer V26 template |  
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 
REM 
REM MENU_TITLE: OPM Actual Costing Analyzer
REM
REM MENU_START
REM
REM SQL    : Run OPM Actual Costing Analyzer
REM FNDLOAD: Load OPM Actual Costing Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM 
REM 
REM HELP_START  
REM 
REM  Process Manufacturing (OPM) Actual Costing Analyzer  [Doc ID: 1629384.1] 
REM
REM  Compatible: 12.0|12.1 
REM
REM  Explanation of available options:
REM
REM    (1) Run OPM Actual Costing Analyzer: 
REM        o Runs gmf_acost_analyzer_pkg.main as APPS and creates an HTML output file
REM
REM    (2) Install OPM Actual Costing Analyzer as a Concurrent Program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable / program 
REM        o Adds the analyzer to the request group: "OPM GMF Request Group"
REM
REM 
REM HELP_END 
REM  
REM FNDLOAD_START 
REM
REM PROD_TOP: GMF_TOP
REM PROG_NAME: GMFACANL
REM DEF_REQ_GROUP: OPM GMF Request Group
REM PROG_TEMPLATE: GMFACAZ.ldt
REM APP_NAME: Process Manufacturing Financials
REM PROD_SHORT_NAME: GMF 
REM
REM FNDLOAD_END
REM
REM DEPENDENCIES_START 
REM 
REM gmf_acost_analyzer.sql
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END
SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
-- PSD #1
PROMPT Submitting GMF Actual Costing Analyzer.
BEGIN

-- PSD #4
  gmf_acost_analyzer_pkg.main;

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
