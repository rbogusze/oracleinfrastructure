SET DEFINE '~'

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.26                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |   ap_oie_analyzer.sql (was ap_oie_detect_pkg.sql)                       |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |   Script to diagnose OIE setup related issues                           |
REM |   Doc ID 1559272.1                                                      |
REM |                                                                         |
REM | HISTORY                                                                 |
REM |   12-Nov-2012 SKPASUPU Created                                          |
REM |   21-Aug-2013 SKPASUPU Added a known corruption                         |
REM |   13-Nov-2013 DAMAL    Fixed bugs, added patches also for Rel 12.2      |
REM |                        Extand list to 200                               |
REM |   21-Sep-2014 DAMAL    Added new patches following note 980053.1        |
REM |   21-Oct-2014 DAMAL    Version 120.4                                    |
REM |   22-Mar-2015 DAMAL    Added new patches released in Feb 15 from        |
REM |                        note 980053.1.  Version 120.5                    |
REM |   26-MAR-2015 AROBERT  Converted to fmw v3                              |
REM +=========================================================================+

CREATE OR REPLACE PACKAGE AP_OIE_DETECT_PKG AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-------------------------------------
-- Procedure and function definitions
-------------------------------------
FUNCTION get_cost_center(p_chart_of_accounts_id IN number,
                       p_ccid in number)
RETURN VARCHAR2;
    
FUNCTION is_account_valid(p_chart_of_accounts_id IN number,
                       p_concatenated_segments in varchar2)
RETURN VARCHAR2;
	
----------------------------------------------------
-- Main entry point to date range concurrent process
----------------------------------------------------
PROCEDURE main_cp(
  errbuf            OUT VARCHAR2,
  retcode           OUT VARCHAR2,
  p_org_ids    IN VARCHAR2 DEFAULT NULL,
  p_per        IN NUMBER DEFAULT NULL,
  p_resp       IN VARCHAR2 DEFAULT NULL,
  p_max_output_rows IN NUMBER   DEFAULT 200,
  p_debug_mode      IN VARCHAR2 DEFAULT 'Y');

-----------------------------------------
-- Main entry point to standalone process
-----------------------------------------
PROCEDURE main(
  p_org_ids    IN VARCHAR2 DEFAULT NULL,
  p_per        IN NUMBER DEFAULT NULL,
  p_resp       IN VARCHAR2 DEFAULT NULL,
  p_max_output_rows IN NUMBER   DEFAULT 200,
  p_debug_mode      IN VARCHAR2 DEFAULT 'Y');

END AP_OIE_DETECT_PKG;
/
show errors

CREATE OR REPLACE PACKAGE BODY AP_OIE_DETECT_PKG AS
-- $Id: ap_oie_analyzer.sql, 200.2 2015/08/10 22:59:31 arobert Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1559272.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

    l_log_file := 'AP_OIE_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'AP_OIE_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1559272.1:CODE">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/oie_latest_ver.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
		 
		 -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
	   -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1.'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2.'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4.'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
			
	   -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);
     -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -- Print actions
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -- Print solution only if passed
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   --Code for Table of Contents of each section  
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;

----
--OIE Related Sub Functions
----
  FUNCTION get_cost_center(p_chart_of_accounts_id IN number,
                           p_ccid in number)
    RETURN VARCHAR2
  IS
  l_cost_ctr_seg_num        NUMBER;
  l_flex_segment_delimiter  VARCHAR2(1);
  l_num_of_segments         NUMBER;
  l_concatenated_segments   VARCHAR2(2000);
  l_def_segments            FND_FLEX_EXT.SEGMENTARRAY;
  
  BEGIN
  
  l_flex_segment_delimiter := FND_FLEX_EXT.GET_DELIMITER(
                                          'SQLGL',
                                          'GL#',
                                          p_chart_of_accounts_id);
  
    IF (NOT FND_FLEX_EXT.GET_SEGMENTS('SQLGL',
                                        'GL#',
                                        p_chart_of_accounts_id,
                                        p_ccid,
                                        l_num_of_segments,
                                        l_def_segments)) THEN
      DBMS_OUTPUT.PUT_LINE ('Not able to get the segments');
    END IF;
        
    l_concatenated_segments :=  FND_FLEX_EXT.concatenate_segments(l_num_of_segments,
                                  l_def_segments,
                                  l_flex_segment_delimiter);
  
  IF (NOT FND_FLEX_APIS.GET_QUALIFIER_SEGNUM(
                                            101,
                                            'GL#',
                                            p_chart_of_accounts_id,
                                            'FA_COST_CTR',
                                            l_cost_ctr_seg_num)) THEN
      DBMS_OUTPUT.PUT_LINE ('Error fetching CC Segment number, No Segment with qualifier FA_COST_CTR');
    END IF;        
    --DBMS_OUTPUT.PUT_LINE ('CC Segment Number : :' || l_cost_ctr_seg_num || ':');
    --DBMS_OUTPUT.PUT_LINE ('CC Segment Value  : :' || l_def_segments(l_cost_ctr_seg_num) || ':');
  
  return(l_def_segments(l_cost_ctr_seg_num));
                                                                 
  END get_cost_center;
  
  FUNCTION is_account_valid(p_chart_of_accounts_id IN number,
                           p_concatenated_segments in varchar2)
    RETURN VARCHAR2
  IS
  BEGIN
  
  if (fnd_flex_keyval.validate_segs(operation=>'CHECK_COMBINATION', 
                                appl_short_name=>'SQLGL', 
                                key_flex_code=>'GL#', 
                                structure_number=>p_chart_of_accounts_id, 
                                concat_segments=>p_concatenated_segments, 
                                VRULE=>'GL_GLOBAL\nDETAIL_POSTING_ALLOWED\nI\nNAME=AP_ALL_POSTING_NA\nY\0\nSUMMARY_FLAG\nI\nNAME=Flex-Parent not allowed\nN', 
                                allow_nulls=>FALSE, 
                                allow_orphans=>FALSE ))
  then
   return('Yes');
  else
   return('No');
  end if;
                                                                 
  END is_account_valid;

  FUNCTION getDocumentID(
    p_document VARCHAR2,
    p_type     VARCHAR2 DEFAULT 'ANY') RETURN jdr_paths.path_docid%TYPE
  IS
    docID    jdr_paths.path_docid%TYPE;
    pathType jdr_paths.path_type%TYPE;
    pathSeq  jdr_paths.path_seq%TYPE;
  BEGIN
    -- Get the ID of the document
    docID := jdr_mds_internal.getDocumentID(p_document);

    -- Verify that we have found a document of the correct type
    IF ((docID <> -1) AND (p_type <> 'ANY')) THEN
      SELECT path_type, path_seq INTO pathType, pathSeq
      FROM jdr_paths WHERE path_docid = docID;

      IF (p_type = 'FILE') THEN
        -- Make sure we are dealing with a document or package file
        IF ((pathType = 'DOCUMENT' AND pathSeq = -1) OR
            (pathType = 'PACKAGE' AND pathSeq = 0)) THEN
          RETURN (docID);
        END IF;
      ELSIF (p_type = 'DOCUMENT') THEN
        -- Make sure we are dealing with a document
        IF (pathType = 'DOCUMENT') THEN
          RETURN (docID);
        END IF;
      ELSIF (p_type = 'PACKAGE') THEN
        IF (pathType = 'PACKAGE') THEN
          RETURN (docID);
        END IF;
      ELSIF (p_type = 'PATH') THEN
        IF ((pathType = 'PACKAGE') AND (pathSeq = -1)) THEN
          RETURN (docID);
        END IF;
      ELSIF (p_type = 'NONPATH') THEN
        IF ((pathType <> 'PACKAGE') OR (pathSeq = 0)) THEN
          RETURN (docID);
        END IF;
      END IF;

      -- No match found
      RETURN (-1);
    END IF;

    RETURN (docID);

  EXCEPTION
    WHEN OTHERS THEN
      RETURN (-1);
  END;
  
-------------------------
-- Recommended patches 
-------------------------
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel       VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN
  -- Column headings
  l_step := '1';
  l_hdr.extend(4);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';

  -- Row col values, release dependent
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '2';
	l_rel := 'R12';
    l_col_rows.extend(34);
    l_col_rows(1)(1) := '6728000';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'REL12.0.6';
    l_col_rows(1)(2) := '7282993';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'REL12.0.5';
    l_col_rows(1)(3) := '6435000';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'REL12.0.4';
    l_col_rows(1)(4) := '6141000';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'REL12.0.3';
     l_col_rows(1)(5) := '5484000';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'REL12.0.2';
    l_col_rows(1)(6) := '5082400';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'REL12.0.1';
    l_col_rows(1)(7) := '4440000';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'REL12';
    l_col_rows(1)(8) := '7294050';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'R12.FIN_PF.A.delta.6';
    l_col_rows(1)(9) := '6836355';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'R12.FIN_PF.A.delta.5';
    l_col_rows(5)(9) := '[980053.1]';
    l_col_rows(1)(10) := '6493602';
    l_col_rows(2)(10) := 'No';
    l_col_rows(3)(10) := NULL;
    l_col_rows(4)(10) := 'R12.FIN_PF.A.delta.4';
    l_col_rows(1)(11) := '6251856';
    l_col_rows(2)(11) := 'No';
    l_col_rows(3)(11) := NULL;
    l_col_rows(4)(11) := 'R12.FIN_PF.A.delta.3';
    l_col_rows(1)(12) := '6000030';
    l_col_rows(2)(12) := 'No';
    l_col_rows(3)(12) := NULL;
    l_col_rows(4)(12) := 'R12.FIN_PF.A.delta.2';
    l_col_rows(1)(13) := '5884587';
    l_col_rows(2)(13) := 'No';
    l_col_rows(3)(13) := NULL;
    l_col_rows(4)(13) := 'R12.FIN_PF.A.delta.1 - Internal';
    l_col_rows(1)(14) := '4175000';
    l_col_rows(2)(14) := 'No';
    l_col_rows(3)(14) := NULL;
    l_col_rows(4)(14) := 'R12.FIN_PF.A';
    l_col_rows(1)(15) := '7293853';
    l_col_rows(2)(15) := 'No';
    l_col_rows(3)(15) := NULL;
    l_col_rows(4)(15) := 'R12.OIE.A.DELTA.6';
    l_col_rows(1)(16) := '6833112';
    l_col_rows(2)(16) := 'No';
    l_col_rows(3)(16) := NULL;
    l_col_rows(4)(16) := 'R12.OIE.A.DELTA.5';
    l_col_rows(1)(17) := '6493806';
    l_col_rows(2)(17) := 'No';
    l_col_rows(3)(17) := NULL;
    l_col_rows(4)(17) := 'R12.OIE.A.DELTA.4';
    l_col_rows(1)(18) := '6250306';
    l_col_rows(2)(18) := 'No';
    l_col_rows(3)(18) := NULL;
    l_col_rows(4)(18) := 'R12.OIE.A.DELTA.3';
    l_col_rows(1)(19) := '5999618';
    l_col_rows(2)(19) := 'No';
    l_col_rows(3)(19) := NULL;
    l_col_rows(4)(19) := 'R12.OIE.A.DELTA.2';
    l_col_rows(1)(20) := '5884349';
    l_col_rows(2)(20) := 'No';
    l_col_rows(3)(20) := NULL;
    l_col_rows(4)(20) := 'R12.OIE.A.DELTA.1';
    l_col_rows(1)(21) := '4442891';
    l_col_rows(2)(21) := 'No';
    l_col_rows(3)(21) := NULL;
    l_col_rows(4)(21) := 'R12.OIE.A';
    l_col_rows(1)(22) := '5348050';
    l_col_rows(2)(22) := 'No';
    l_col_rows(3)(22) := NULL;
    l_col_rows(4)(22) := 'R12.AME.A';
    l_col_rows(1)(23) := '5889626';
    l_col_rows(2)(23) := 'No';
    l_col_rows(3)(23) := NULL;
    l_col_rows(4)(23) := 'R12.AME.A.delta.1';
    l_col_rows(1)(24) := '5997203';
    l_col_rows(2)(24) := 'No';
    l_col_rows(3)(24) := NULL;
    l_col_rows(4)(24) := 'R12.AME.A.delta.2';
    l_col_rows(1)(25) := '6196260';
    l_col_rows(2)(25) := 'No';
    l_col_rows(3)(25) := NULL;
    l_col_rows(4)(25) := 'R12.AME.A.delta.3';
    l_col_rows(1)(26) := '6506440';
    l_col_rows(2)(26) := 'No';
    l_col_rows(3)(26) := NULL;
    l_col_rows(4)(26) := 'R12.AME.A.delta.4';
    l_col_rows(1)(27) := '6835789';
    l_col_rows(2)(27) := 'No';
    l_col_rows(3)(27) := NULL;
    l_col_rows(4)(27) := 'R12.AME.A.delta.5';
    l_col_rows(1)(28) := '7291407';
    l_col_rows(2)(28) := 'No';
    l_col_rows(3)(28) := NULL;
    l_col_rows(4)(28) := 'R12.AME.A.delta.6';
    l_col_rows(1)(29) := '7644754';
    l_col_rows(2)(29) := 'No';
    l_col_rows(3)(29) := NULL;
    l_col_rows(4)(29) := 'R12.AME.A.delta.7';
    l_col_rows(1)(30) := '9349996';
    l_col_rows(2)(30) := 'No';
    l_col_rows(3)(30) := NULL;
    l_col_rows(4)(30) := 'R12.AME.A.delta.8';
    l_col_rows(1)(31) := '12424313';
    l_col_rows(2)(31) := 'No';
    l_col_rows(3)(31) := NULL;
    l_col_rows(4)(31) := 'R12.AME.A.delta.9';
    l_col_rows(1)(32) := '13955167';
    l_col_rows(2)(32) := 'No';
    l_col_rows(3)(32) := NULL;
    l_col_rows(4)(32) := 'R12.AME.A.delta.10';
    l_col_rows(1)(33) := '16664305';
    l_col_rows(2)(33) := 'No';
    l_col_rows(3)(33) := NULL;
    l_col_rows(4)(33) := 'R12.AME.A.delta.11';
    l_col_rows(1)(34) := '8649286';
    l_col_rows(2)(34) := 'No';
    l_col_rows(3)(34) := NULL;
    l_col_rows(4)(34) := 'R12.AP.A.CPC July 2009';
   ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
    l_step := '3';
	l_rel := 'R12';
    l_col_rows.extend(25);
    l_col_rows(1)(1) := '9239090';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'REL12.1.3';
    l_col_rows(1)(2) := '10040337';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'R12.1.3 Mandatory patch';
    l_col_rows(1)(3) := '14098047';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'R12.1.3 OIE-RPC Aug 2012';
    l_col_rows(5)(3) := '[980053.1]';
    l_col_rows(1)(4) := '13563489';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'R12.1.3 PCARD-RPC Jan 2012';
    l_col_rows(1)(5) := '16234880';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'R12.1.3 OIE-RPC Mar 2013';
    l_col_rows(1)(6) := '16213660';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.1.3 PCARD-RPC Mar 2013';
    l_col_rows(1)(7) := '17176060';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'R12.1.3 PCARD-RPC Sep 2013';
    l_col_rows(1)(8) := '19163626';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'R12.1.3 OIE-RPC Aug 2014';
    l_col_rows(1)(9) := '19018819';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'R12.1.3 PCARD-RPC Aug 2014';
    l_col_rows(1)(10) := '20315551';
    l_col_rows(2)(10) := 'No';
    l_col_rows(3)(10) := NULL;
    l_col_rows(4)(10) := 'R12.1.3 OIE-RPC Feb 2015';
    l_col_rows(1)(11) := '20178726';
    l_col_rows(2)(11) := 'No';
    l_col_rows(3)(11) := NULL;
    l_col_rows(4)(11) := 'R12.1.3 PCARD-RPC Feb 2015';

    l_col_rows(1)(12) := '7303033';
    l_col_rows(2)(12) := 'No';
    l_col_rows(3)(12) := NULL;
    l_col_rows(4)(12) := 'REL12.1.2';
    l_col_rows(1)(13) := '7303030';
    l_col_rows(2)(13) := 'No';
    l_col_rows(3)(13) := NULL;
    l_col_rows(4)(13) := 'REL12.1.1 Maint';
    l_col_rows(1)(14) := '7283000';
    l_col_rows(2)(14) := 'No';
    l_col_rows(3)(14) := NULL;
    l_col_rows(4)(14) := 'REL12.1.DELTA.1';
    l_col_rows(1)(15) := '9147733';
    l_col_rows(2)(15) := 'No';
    l_col_rows(3)(15) := NULL;
    l_col_rows(4)(15) := 'R12.FIN_PF.B.DELTA.3';
    l_col_rows(1)(16) := '8402900';
    l_col_rows(2)(16) := 'No';
    l_col_rows(3)(16) := NULL;
    l_col_rows(4)(16) := 'R12.FIN_PF.B.DELTA.2';
    l_col_rows(1)(17) := '7457000';
    l_col_rows(2)(17) := 'No';
    l_col_rows(3)(17) := NULL;
    l_col_rows(4)(17) := 'R12.FIN_PF.B.DELTA.1';
    l_col_rows(1)(18) := '4565490';
    l_col_rows(2)(18) := 'No';
    l_col_rows(3)(18) := NULL;
    l_col_rows(4)(18) := 'R12.FIN_PF.B';
    l_col_rows(1)(19) := '9244833';
    l_col_rows(2)(19) := 'No';
    l_col_rows(3)(19) := NULL;
    l_col_rows(4)(19) := 'R12.OIE.B.DELTA.3';
    l_col_rows(1)(20) := '8517003';
    l_col_rows(2)(20) := 'No';
    l_col_rows(3)(20) := NULL;
    l_col_rows(4)(20) := 'R12.OIE.B.DELTA.2';
    l_col_rows(1)(21) := '7456868';
    l_col_rows(2)(21) := 'No';
    l_col_rows(3)(21) := NULL;
    l_col_rows(4)(21) := 'R12.OIE.B.DELTA.1';
    l_col_rows(1)(22) := '4565278';
    l_col_rows(2)(22) := 'No';
    l_col_rows(3)(22) := NULL;
    l_col_rows(4)(22) := 'R12.OIE.B';
    l_col_rows(1)(23) := '6658013';
    l_col_rows(2)(23) := 'No';
    l_col_rows(3)(23) := NULL;
    l_col_rows(4)(23) := 'R12.AME.B';
    l_col_rows(1)(24) := '7457049';
    l_col_rows(2)(24) := 'No';
    l_col_rows(3)(24) := NULL;
    l_col_rows(4)(24) := 'R12.AME.B.delta.1';
    l_col_rows(1)(25) := '8496475';
    l_col_rows(2)(25) := 'No';
    l_col_rows(3)(25) := NULL;
    l_col_rows(4)(25) := 'R12.AME.B.delta.2';
    l_col_rows(1)(26) := '9244273';
    l_col_rows(2)(26) := 'No';
    l_col_rows(3)(26) := NULL;
    l_col_rows(4)(26) := 'R12.AME.B.delta.3';
    l_col_rows(1)(27) := '11811841';
    l_col_rows(2)(27) := 'No';
    l_col_rows(3)(27) := NULL;
    l_col_rows(4)(27) := 'R12.AME.B.delta.4';
    l_col_rows(1)(28) := '13594830';
    l_col_rows(2)(28) := 'No';
    l_col_rows(3)(28) := NULL;
    l_col_rows(4)(28) := 'R12.AME.B.delta.5';
    l_col_rows(1)(29) := '16040471';
    l_col_rows(2)(29) := 'No';
    l_col_rows(3)(29) := NULL;
    l_col_rows(4)(29) := 'R12.AME.B.delta.6';
  ELSE
    l_step := '3.1';
	l_rel := 'R12';
    l_col_rows.extend(12);
    l_col_rows(1)(1) := '17919161';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'REL12.2.4';
    l_col_rows(1)(2) := '17020683';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'REL12.2.3';
    l_col_rows(1)(3) := '16207672';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'REL12.2.2';
    l_col_rows(1)(4) := '14222221';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'REL12.2.1';
    l_col_rows(1)(5) := '10079002';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'REL12.2.0';
    l_col_rows(1)(6) := '17940003';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.FIN_PF.C.delta.4';
    l_col_rows(1)(7) := '17026955';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'R12.FIN_PF.C.delta.3';
    l_col_rows(1)(8) := '15969696';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'R12.FIN_PF.C.delta.2';
    l_col_rows(1)(9) := '14227186';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'R12.FIN_PF.C.delta.1';
    l_col_rows(1)(10) := '10197302';
    l_col_rows(2)(10) := 'No';
    l_col_rows(3)(10) := NULL;
    l_col_rows(4)(10) := 'R12.FIN_PF.C';
    l_col_rows(1)(11) := '17933923';
    l_col_rows(2)(11) := 'No';
    l_col_rows(3)(11) := NULL;
    l_col_rows(4)(11) := 'R12.OIE.C.delta.4';
    l_col_rows(1)(12) := '17022460';
    l_col_rows(2)(12) := 'No';
    l_col_rows(3)(12) := NULL;
    l_col_rows(4)(12) := 'R12.OIE.C.delta.3';
    l_col_rows(1)(13) := '16188355';
    l_col_rows(2)(13) := 'No';
    l_col_rows(3)(13) := NULL;
    l_col_rows(4)(13) := 'R12.OIE.C.delta.2';
    l_col_rows(1)(14) := '14229062';
    l_col_rows(2)(14) := 'No';
    l_col_rows(3)(14) := NULL;
    l_col_rows(4)(14) := 'R12.OIE.C.delta.1';
    l_col_rows(1)(15) := '10196256';
    l_col_rows(2)(15) := 'No';
    l_col_rows(3)(15) := NULL;
    l_col_rows(4)(15) := 'R12.OIE.C';
    l_col_rows(1)(16) := '18121271';
    l_col_rows(2)(16) := 'No';
    l_col_rows(3)(16) := NULL;
    l_col_rows(4)(16) := 'R12.AME.C.delta.5';
    l_col_rows(1)(17) := '17940182';
    l_col_rows(2)(17) := 'No';
    l_col_rows(3)(17) := NULL;
    l_col_rows(4)(17) := 'R12.AME.C.delta.4';
    l_col_rows(1)(18) := '17028726';
    l_col_rows(2)(18) := 'No';
    l_col_rows(3)(18) := NULL;
    l_col_rows(4)(18) := 'R12.AME.C.delta.3';
    l_col_rows(1)(19) := '16169916';
    l_col_rows(2)(19) := 'No';
    l_col_rows(3)(19) := NULL;
    l_col_rows(4)(19) := 'R12.AME.C.delta.2';
    l_col_rows(1)(20) := '14237507';
    l_col_rows(2)(20) := 'No';
    l_col_rows(3)(20) := NULL;
    l_col_rows(4)(20) := 'R12.AME.C.delta.1';
    l_col_rows(1)(21) := '10192272';
    l_col_rows(2)(21) := 'No';
    l_col_rows(3)(21) := NULL;
    l_col_rows(4)(21) := 'R12.AME.C';
  END IF;
  
  -- Check if applied
  IF l_col_rows.exists(1) THEN
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i),l_rel);
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;
  END IF;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches (Doc Id 980053.1)';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Some recommended patches are not applied '||
    'in this instance'; 
  l_sig.solution := '<ul><li>Please review list above and schedule 
    to apply these patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := 'Recommended patches are applied.';	
  l_sig.print_condition := 'ALWAYS';
  --l_sig.print_scs_msg := 'Y';
  l_sig.fail_type := 'W';       
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;

FUNCTION print_pers(p_path VARCHAR2, p_recursive BOOLEAN DEFAULT FALSE) RETURN VARCHAR2
  IS
    -- Selects documents in the current directory, plus its children
    CURSOR c_alldocs(docid JDR_PATHS.PATH_DOCID%TYPE) IS
      SELECT
        jdr_mds_internal.getDocumentName(path_docid), path_type, path_seq
      FROM
        (SELECT path_docid, path_type, path_seq
         FROM jdr_paths
         START WITH path_owner_docid = docid
         CONNECT BY PRIOR path_docid = path_owner_docid) paths
      WHERE
        (path_type = 'DOCUMENT' AND path_seq = -1) OR
        (path_type = 'PACKAGE' AND path_seq = 0) OR
        (path_type = 'PACKAGE' AND path_seq = -1 AND
         NOT EXISTS (SELECT * FROM jdr_paths
                     WHERE path_owner_docid = paths.path_docid));

    docID    JDR_PATHS.PATH_DOCID%TYPE;
    pathSeq  JDR_PATHS.PATH_SEQ%TYPE;
    pathType JDR_PATHS.PATH_TYPE%TYPE;
    docname  VARCHAR2(1024);
    TYPE output_tbl IS TABLE OF VARCHAR2(1024);
    l_output output_tbl := output_tbl();
    i number := 1;
    counter number := 1;

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_sig        SIGNATURE_REC;


  BEGIN
    --dbms_output.enable(1000000);

  /*print_out('<!------------------------------------------------>
  <div class="div1">
  <div class="div10" id="sect11">Personalizations & Customizations</div>
  <br>
  <div class="div11">
  <div class="div111">OIE Pages</div>
  <table class="table1"><tbody>
  <tr><th>Files</th></tr>
  ');*/

    docID := getDocumentID(p_path, 'ANY');

    -- Nothing to do if the path does not exist
    IF (docID = -1) THEN
      debug('Error: Could not find path for checking personalizations' || p_path);
      return 'E';   
    END IF;

    IF (p_recursive) THEN
      --dbms_output.put_line('Printing contents of ' || p_path || ' recursively');
      OPEN c_alldocs(docID);
      LOOP
        FETCH c_alldocs INTO docname, pathType, pathSeq;
        IF (c_alldocs%NOTFOUND) THEN
          CLOSE c_alldocs;
          EXIT;
        END IF;

        -- Make package directories distinct from files.  Note that when
        -- listing the document recursively, the only packages that are
        -- listed are the ones which contain no child documents or packages
        IF ((pathType = 'PACKAGE') AND (pathSeq = -1)) THEN
          docname := docname || '/';
        END IF;

        -- Print the document, but make sure it does not exceed 255 characters
        -- or else dbms_output will fail
        /*WHILE (length(docname) > 255) LOOP
          dbms_output.put_line(substr(docname, 1, 255));
          docname := substr(docname, 256);
        END LOOP;*/
      l_output.extend();  
      l_output(i) := docname;
      i := i + 1;

        --dbms_output.put_line(docname);
      END LOOP;
      
      l_col_rows.extend(l_output.count);
      
      FOR j IN 1..l_output.count LOOP
       if (regexp_like(l_output(j), '([^a-z])custom')) then
         --print_out(l_output(j));
         l_col_rows(1)(counter) := l_output(j);
         counter := counter + 1;
       end if; 
      END LOOP;

      /*print_out('</tbody></table><br/>');        
      if l_output(1) is null then
        print_out('<div class="divok">
                   <div class="divok1">No action required!</div>
                   No Personalizations or Customizations Found.
                   </div>
                   </div>
                  ');  
      end if;
      
       print_out('</div>
                 </div>
                 <br>
                 <a href="#Top">[Back to top]</a><br>
                 <br>');*/
    END IF;
    
  l_sig.title := 'Personalizations & Customizations';
 l_sig.fail_condition := 'NRS';
  l_sig.problem_descr := 'Listed are the personalized/customized pages'; 
  l_sig.solution := '<ul><li>Please review the personalizations/customizations.</li></ul>';
  l_sig.success_msg := 'No problem found with personalizations';
  l_sig.print_condition := 'SUCCESS';
  l_sig.fail_type := 'W';       
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
   
  l_hdr.extend(1);
  l_hdr(1) := 'Files';
  
  RETURN process_signature_results(
    'PERS_CUST',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_pers '||sqlerrm);
  raise;   
END print_pers;



PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RSGT1 (RS greater than 1), RS (row selected), NRS (no row selected)
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') --should signature be included in DX Summary
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
PROCEDURE validate_parameters (
      p_org_ids    IN VARCHAR2 DEFAULT NULL,
      p_per        IN NUMBER DEFAULT NULL,
      p_resp       IN VARCHAR2 DEFAULT NULL,
      p_max_output_rows IN NUMBER,
      p_debug_mode      IN VARCHAR2) IS

  l_from_date    VARCHAR2(25);
  l_to_date     VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;
  l_step       VARCHAR2(5);
  
  l_resp_key     varchar2(100);
  l_user_id      varchar2(20);
  
  invalid_parameters EXCEPTION;
  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  
   l_step := 1;
  
  g_max_output_rows := nvl(p_max_output_rows,200);
  g_debug_mode := nvl(p_debug_mode, 'Y');

  IF p_org_ids is null THEN
    print_log('No operating unit organization ID specified. '||
      'The org_id parameter is mandatory.');
    raise invalid_parameters;
  END IF;

  l_step := 2;

    if p_resp is not null then
      begin
       select responsibility_key
        into l_resp_key
        from FND_RESPONSIBILITY_VL 
       where ltrim(rtrim(upper(responsibility_name))) like ltrim(rtrim(upper(p_resp))); 
      exception 
       when others then
        l_resp_key := null;
        print_log('Error in getting the responsibility key for responsibility: '||p_resp);
       raise invalid_parameters;
      end;
    end if;

	l_step := 3;
	
    if p_per is not null then
      begin
       select user_id
        into l_user_id
        from FND_USER
       where ltrim(rtrim((employee_id))) like ltrim(rtrim((p_per)))
         and rownum = 1; 
      exception 
       when NO_DATA_FOUND then
        l_user_id := null;
        print_log('No user attached for person ID - '||p_per);
       when others then
        l_resp_key := null;
        print_log('Error in getting the user_id for person ID - '||p_per);
       raise invalid_parameters;
      end;
    end if;

  -----------------------------------------------------------
  -- End of validation
  -----------------------------------------------------------
  
  l_step := 4;
  
-- Revision and date values can be populated by RCS
  l_revision := rtrim(replace('$Revision: 200.2 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/08/10 22:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
 l_step := 5;
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_rep_info('File Name') := 'ap_oie_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1559272.1" target="_blank">(Note 1559272.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  l_step := 6;
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Operating Unit') := rtrim(ltrim(REPLACE(p_org_ids,' ',''),','),',');
  g_parameters('2. Employee Person ID') := rtrim(ltrim(REPLACE(p_per,' ',''),','),',');
  g_parameters('3. Responsibility') := rtrim(ltrim(REPLACE(p_resp,' ',''),','),',');
  g_parameters('4. Max Rows') := g_max_output_rows;
  g_parameters('5. Debug Mode') := g_debug_mode;
  
  l_step := 7;
  -- Create global hash of SQL token values
  g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');
  g_sql_tokens('##$$ORGS$$##') := to_char(p_org_ids);
  g_sql_tokens('##$$EMPID$$##') := to_char(p_per);
  g_sql_tokens('##$$RESP$$##') := l_resp_key;
  g_sql_tokens('##$$USER$$##') := l_user_id;

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN
-- PSD 9
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------
  
----------
--Generic
----------

  add_signature(
   'PRODUCT',
   'SELECT DISTINCT t.application_name product_name,
           SUBSTR(PRODUCT_VERSION,1,14) version,
           SUBSTR(PATCH_LEVEL,1,11) patch_level
      FROM fnd_application a,
           fnd_product_installations p ,
           fnd_application_tl t
     WHERE a.application_id = p.application_id
       AND a.application_id   = t.application_id
       AND p.application_id   = t.application_id
       AND a.application_id  IN (200,101,401,201, 673, 800)
     ORDER BY 1',
   'Product Installation Status and Patchset Level',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');
   
    add_signature(
   'VERSIONS',
   'SELECT name,text
      FROM all_source
     WHERE name IN (''AP_WEB_EXPENSE_WF'', ''AP_WEB_ACCTG_PKG'', ''AP_WEB_DB_AP_INT_PKG'', ''AP_WEB_DB_EXPLINE_PKG'')
       AND line    = 2
     ORDER BY name',
   'OIE Commonly Used PLSQL file versions',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');
   
     add_signature(
   'INVALIDS',
   'select * from all_objects 
   where status=''INVALID'' and (object_name like ''OIE%'' or object_name like ''AP%'')
   order by object_name',
   'OIE and AP Invalid Objects in the System',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  -------------------------------------------
  -- Profile Options
  -------------------------------------------
  add_signature(
   'KEY_PROFILES',
   'select
  user_profile_option_name "PROFILE",
  MAX(DECODE(lev, ''SITE'', value, NULL)) "SITE",
  MAX(DECODE(lev, ''APP'', value, NULL)) "APPLICATION",
  MAX(DECODE(lev, ''RESP'', value, NULL)) "RESPONSIBILITY",
  MAX(DECODE(lev, ''USER'', value, NULL)) "USER"
  from
  (
  SELECT po.profile_option_name "NAME", po.user_profile_option_name,
  DECODE (TO_CHAR (pov.level_id),
  ''10001'', ''SITE'',
  ''10002'', ''APP'',
  ''10003'', ''RESP'',
  ''10005'', ''SERVER'',
  ''10006'', ''ORG'',
  ''10004'', ''USER'',
  null
  ) "LEV",
  DECODE (TO_CHAR (pov.level_id),
  ''10001'', '''',
  ''10002'', app.application_short_name,
  ''10003'', rsp.responsibility_key,
  ''10005'', svr.node_name,
  ''10006'', org.NAME,
  ''10004'', usr.user_name,
  null
  ) "CONTEXT",
  pov.profile_option_value "VALUE"
  FROM fnd_profile_options_vl po,
  fnd_profile_option_values pov,
  fnd_user usr,
  fnd_application app,
  fnd_responsibility rsp,
  fnd_nodes svr,
  hr_operating_units org
  WHERE 1 = 1
  AND pov.application_id(+) = po.application_id
  AND pov.profile_option_id(+) = po.profile_option_id
  AND usr.user_id(+) = pov.level_value
  AND rsp.application_id(+) = pov.level_value_application_id
  AND rsp.responsibility_id(+) = pov.level_value
  AND app.application_id(+) = pov.level_value
  AND svr.node_id(+) = pov.level_value
  AND org.organization_id(+) = pov.level_value
  AND po.profile_option_name in
  (''ICX_DATE_FORMAT_MASK'',                                
  ''ICX_LANGUAGE'',                                
  ''ICX_LIMIT_CONNECT'',                                
  ''ICX_LIMIT_TIME'',                                
  ''ICX_SESSION_TIMEOUT'',                                
  ''ORG_ID'')
  ORDER BY "NAME", pov.level_id, "VALUE"
  )
  where lev is null   
  or (lev = ''SITE'' and context is null)   
  or (lev = ''APP'' and context = ''SQLAP'')   
  or (lev = ''RESP'' and context = ''##$$RESP$$##'')
  or (lev = ''ORG'' and context = ''ORG'')   
  or (lev = ''USER'' and context = ''##$$USER$$##'')
  group by name,user_profile_option_name
  ORDER BY "PROFILE"',
   'Mandatory Key Profile Options',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'OPT_KEY_PROFILES',
   'select
  user_profile_option_name "PROFILE",
  MAX(DECODE(lev, ''SITE'', value, NULL)) "SITE",
  MAX(DECODE(lev, ''APP'', value, NULL)) "APPLICATION",
  MAX(DECODE(lev, ''RESP'', value, NULL)) "RESPONSIBILITY",
  MAX(DECODE(lev, ''USER'', value, NULL)) "USER"
  from
  (
  SELECT po.profile_option_name "NAME", po.user_profile_option_name,
  DECODE (TO_CHAR (pov.level_id),
  ''10001'', ''SITE'',
  ''10002'', ''APP'',
  ''10003'', ''RESP'',
  ''10005'', ''SERVER'',
  ''10006'', ''ORG'',
  ''10004'', ''USER'',
  null
  ) "LEV",
  DECODE (TO_CHAR (pov.level_id),
  ''10001'', '''',
  ''10002'', app.application_short_name,
  ''10003'', rsp.responsibility_key,
  ''10005'', svr.node_name,
  ''10006'', org.NAME,
  ''10004'', usr.user_name,
  null
  ) "CONTEXT",
  pov.profile_option_value "VALUE"
  FROM fnd_profile_options_vl po,
  fnd_profile_option_values pov,
  fnd_user usr,
  fnd_application app,
  fnd_responsibility rsp,
  fnd_nodes svr,
  hr_operating_units org
  WHERE 1 = 1
  AND pov.application_id(+) = po.application_id
  AND pov.profile_option_id(+) = po.profile_option_id
  AND usr.user_id(+) = pov.level_value
  AND rsp.application_id(+) = pov.level_value_application_id
  AND rsp.responsibility_id(+) = pov.level_value
  AND app.application_id(+) = pov.level_value
  AND svr.node_id(+) = pov.level_value
  AND org.organization_id(+) = pov.level_value
  AND po.profile_option_name in
  (''AP_WEB_ALLOW_CREDIT_LINES'',                                
  ''AP_WEB_ALLOW_NON_BASE_REIMB'',                                
  ''AP_WEB_ALLOW_OVERRIDE_APPROVER'',                                
  ''AP_WEB_APPROVER_REQ_CC'',                                
  ''AP_WEB_DESC_FLEX_NAME'',                                
  ''AP_WEB_ENABLE_PROJECT_ACCOUNTING'',                                
  ''AP_WEB_OVERRIDE_APPR_REQ'',                                
  ''AP_WEB_POLICY_GRACE_PERIOD'',                                
  ''AP_WEB_POLICY_VIOLATION_SUBMIT'',                                
  ''AP_WEB_PURPOSE_REQUIRED'',                                
  ''AP_WEB_REPNUM_PREFIX'',                                
  ''AP_WEB_TAX_ENABLE'',                                
  ''OIE_CARRY_ADVANCES_FORWARD'',                                
  ''OIE_ENABLE_ADVANCES'',                                
  ''OIE_ENABLE_ALLOCATION_SPLITTING'',                                
  ''OIE_ENABLE_BAR_CODE'',                                
  ''OIE_ENABLE_COST_CENTER'',                                
  ''OIE_ENABLE_LINE_LEVEL_ACCOUNTING'',                                
  ''OIE_ENABLE_PROJECT_EXPEND_ORG'',                                
  ''SSE_CC_PAYMENT_NOTIFY'',                                
  ''SSE_ENABLE_CREDIT_CARD'',                                
  ''DISPLAY_INVERSE_RATE'',                                
  ''AME_INSTALLED_FLAG'',                                
  ''ICX_PREFERRED_CURRENCY'',                                
  ''PA_TIME_EXP_PROJ_USER'',                                
  ''AMPOOL_CONNECTION_POOL_ENABLED'',                                
  ''AMPOOL_ENABLED'',                                
  ''VO_MAX_FETCH_SIZE'',                                
  ''DEFAULT_COUNTRY'',                                
  ''FND_DISABLE_OA_CUSTOMIZATIONS'',                                
  ''FND_NTF_REASSIGN_MODE'',                                
  ''HR_CROSS_BUSINESS_GROUP'',                                
  ''XLA_MO_SECURITY_PROFILE_LEVEL'',                                
  ''PA_PTE_AUTOAPPROVE_ER'',                                
  ''FND_CUSTOM_OA_DEFINTION'',                                
  ''PRINTER'',                                
  ''UNIQUE:SEQ_NUMBERS'',                                
  ''WF_MAIL_CANCEL'')
  ORDER BY "NAME", pov.level_id, "VALUE"
  )
  where lev is null   
  or (lev = ''SITE'' and context is null)   
  or (lev = ''APP'' and context = ''SQLAP'')   
  or (lev = ''RESP'' and context = ''##$$RESP$$##'')
  or (lev = ''ORG'' and context = ''ORG'')   
  or (lev = ''USER'' and context = ''##$$USER$$##'')
  group by name,user_profile_option_name
  ORDER BY "PROFILE"',
   'Optional Key Profile Options',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');


 -------------------------------------------
  -- Profile Options Data Collection
  -------------------------------------------
  add_signature(
   'KEY_PROFILES_DATA',
   'select
  profile_option_name "PROFILE",
  MAX(DECODE(lev, ''SITE'', value, NULL)) "SITE",
  MAX(DECODE(lev, ''APP'', value, NULL)) "APPLICATION",
  MAX(DECODE(lev, ''RESP'', value, NULL)) "RESPONSIBILITY",
  MAX(DECODE(lev, ''USER'', value, NULL)) "USER"
  from
  (
  SELECT po.profile_option_name "NAME", po.profile_option_name,
  DECODE (TO_CHAR (pov.level_id),
  ''10001'', ''SITE'',
  ''10002'', ''APP'',
  ''10003'', ''RESP'',
  ''10005'', ''SERVER'',
  ''10006'', ''ORG'',
  ''10004'', ''USER'',
  null
  ) "LEV",
  DECODE (TO_CHAR (pov.level_id),
  ''10001'', '''',
  ''10002'', app.application_short_name,
  ''10003'', rsp.responsibility_key,
  ''10005'', svr.node_name,
  ''10006'', org.NAME,
  ''10004'', usr.user_name,
  null
  ) "CONTEXT",
  pov.profile_option_value "VALUE"
  FROM fnd_profile_options po,
  fnd_profile_option_values pov,
  fnd_user usr,
  fnd_application app,
  fnd_responsibility rsp,
  fnd_nodes svr,
  hr_operating_units org
  WHERE 1 = 1
  AND pov.application_id(+) = po.application_id
  AND pov.profile_option_id(+) = po.profile_option_id
  AND usr.user_id(+) = pov.level_value
  AND rsp.application_id(+) = pov.level_value_application_id
  AND rsp.responsibility_id(+) = pov.level_value
  AND app.application_id(+) = pov.level_value
  AND svr.node_id(+) = pov.level_value
  AND org.organization_id(+) = pov.level_value
  AND po.profile_option_name in
  (''ICX_DATE_FORMAT_MASK'',                                
  ''ICX_LANGUAGE'',                                
  ''ICX_LIMIT_CONNECT'',                                
  ''ICX_LIMIT_TIME'',                                
  ''ICX_SESSION_TIMEOUT'',                                
  ''ORG_ID'')
  ORDER BY "NAME", pov.level_id, "VALUE"
  )
  -- where lev is null   
  -- or (lev = ''SITE'' and context is null)   
  -- or (lev = ''APP'' and context = ''SQLAP'')   
  -- or (lev = ''RESP'' and context = ''##$$RESP$$##'')
  -- or (lev = ''ORG'' and context = ''ORG'')   
  -- or (lev = ''USER'' and context = ''##$$USER$$##'')
  group by name,profile_option_name
  ORDER BY "PROFILE"',
   'Mandatory Key Profile Options',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'OPT_KEY_PROFILES_DATA',
   'select
  profile_option_name "PROFILE",
  MAX(DECODE(lev, ''SITE'', value, NULL)) "SITE",
  MAX(DECODE(lev, ''APP'', value, NULL)) "APPLICATION",
  MAX(DECODE(lev, ''RESP'', value, NULL)) "RESPONSIBILITY",
  MAX(DECODE(lev, ''USER'', value, NULL)) "USER"
  from
  (
  SELECT po.profile_option_name "NAME", po.profile_option_name,
  DECODE (TO_CHAR (pov.level_id),
  ''10001'', ''SITE'',
  ''10002'', ''APP'',
  ''10003'', ''RESP'',
  ''10005'', ''SERVER'',
  ''10006'', ''ORG'',
  ''10004'', ''USER'',
  null
  ) "LEV",
  DECODE (TO_CHAR (pov.level_id),
  ''10001'', '''',
  ''10002'', app.application_short_name,
  ''10003'', rsp.responsibility_key,
  ''10005'', svr.node_name,
  ''10006'', org.NAME,
  ''10004'', usr.user_name,
  null
  ) "CONTEXT",
  pov.profile_option_value "VALUE"
  FROM fnd_profile_options po,
  fnd_profile_option_values pov,
  fnd_user usr,
  fnd_application app,
  fnd_responsibility rsp,
  fnd_nodes svr,
  hr_operating_units org
  WHERE 1 = 1
  AND pov.application_id(+) = po.application_id
  AND pov.profile_option_id(+) = po.profile_option_id
  AND usr.user_id(+) = pov.level_value
  AND rsp.application_id(+) = pov.level_value_application_id
  AND rsp.responsibility_id(+) = pov.level_value
  AND app.application_id(+) = pov.level_value
  AND svr.node_id(+) = pov.level_value
  AND org.organization_id(+) = pov.level_value
  AND po.profile_option_name in
  (''AP_WEB_ALLOW_CREDIT_LINES'',                                
  ''AP_WEB_ALLOW_NON_BASE_REIMB'',                                
  ''AP_WEB_ALLOW_OVERRIDE_APPROVER'',                                
  ''AP_WEB_APPROVER_REQ_CC'',                                
  ''AP_WEB_DESC_FLEX_NAME'',                                
  ''AP_WEB_ENABLE_PROJECT_ACCOUNTING'',                                
  ''AP_WEB_OVERRIDE_APPR_REQ'',                                
  ''AP_WEB_POLICY_GRACE_PERIOD'',                                
  ''AP_WEB_POLICY_VIOLATION_SUBMIT'',                                
  ''AP_WEB_PURPOSE_REQUIRED'',                                
  ''AP_WEB_REPNUM_PREFIX'',                                
  ''AP_WEB_TAX_ENABLE'',                                
  ''OIE_CARRY_ADVANCES_FORWARD'',                                
  ''OIE_ENABLE_ADVANCES'',                                
  ''OIE_ENABLE_ALLOCATION_SPLITTING'',                                
  ''OIE_ENABLE_BAR_CODE'',                                
  ''OIE_ENABLE_COST_CENTER'',                                
  ''OIE_ENABLE_LINE_LEVEL_ACCOUNTING'',                                
  ''OIE_ENABLE_PROJECT_EXPEND_ORG'',                                
  ''SSE_CC_PAYMENT_NOTIFY'',                                
  ''SSE_ENABLE_CREDIT_CARD'',                                
  ''DISPLAY_INVERSE_RATE'',                                
  ''AME_INSTALLED_FLAG'',                                
  ''ICX_PREFERRED_CURRENCY'',                                
  ''PA_TIME_EXP_PROJ_USER'',                                
  ''AMPOOL_CONNECTION_POOL_ENABLED'',                                
  ''AMPOOL_ENABLED'',                                
  ''VO_MAX_FETCH_SIZE'',                                
  ''DEFAULT_COUNTRY'',                                
  ''FND_DISABLE_OA_CUSTOMIZATIONS'',                                
  ''FND_NTF_REASSIGN_MODE'',                                
  ''HR_CROSS_BUSINESS_GROUP'',                                
  ''XLA_MO_SECURITY_PROFILE_LEVEL'',                                
  ''PA_PTE_AUTOAPPROVE_ER'',                                
  ''FND_CUSTOM_OA_DEFINTION'',                                
  ''PRINTER'',                                
  ''UNIQUE:SEQ_NUMBERS'',                                
  ''WF_MAIL_CANCEL'')
  ORDER BY "NAME", pov.level_id, "VALUE"
  )
  -- where lev is null   
  -- or (lev = ''SITE'' and context is null)   
  -- or (lev = ''APP'' and context = ''SQLAP'')   
  -- or (lev = ''RESP'' and context = ''##$$RESP$$##'')
  -- or (lev = ''ORG'' and context = ''ORG'')   
  -- or (lev = ''USER'' and context = ''##$$USER$$##'')
  group by name,profile_option_name
  ORDER BY "PROFILE"',
   'Optional Key Profile Options',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  -------------------------------------------
  -- Expense Signatures
  -------------------------------------------
  add_signature(
   'EXPENSE_REPORTS_TEMPLATES',
   'select   
  expense_report_id,   
  report_type,   
  description,   
  inactive_date,   
  web_enabled_flag,  
  org_id,   
  default_parameter_id   
  from ap_expense_reports_all   
  where org_id in (##$$ORGS$$##)',
   'Expense Report Templates',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'EXPENSE_PARAMS',
   'SELECT     
  ou.name ORG_NAME,    
  ep.PREVENT_CASH_CC_AGE_LIMIT,    
  ep.ENFORCE_CC_ACC_LIMIT,    
  ep.ENFORCE_CC_AIR_LIMIT,    
  ep.ENFORCE_CC_CAR_LIMIT,    
  ep.ENFORCE_CC_MEAL_LIMIT,    
  ep.ENFORCE_CC_MISC_LIMIT,    
  ep.ORG_ID,    
  sp.BASE_CURRENCY_CODE,    
  ep.PREVENT_FUTURE_DATED_DAY_LIMIT,    
  ep.FUTURE_DATE_WARNING_DAY_LIMIT,    
  ep.NOTE_LANGUAGE_CODE,    
  ep.CREATION_DATE,    
  ep.CREATED_BY,    
  ep.LAST_UPDATE_LOGIN,    
  ep.LAST_UPDATE_DATE,    
  ep.LAST_UPDATED_BY,    
  lang.description NOTE_LANGUAGE_CODE_DISP  
  FROM AP_EXPENSE_PARAMS_ALL ep,    
  AP_SYSTEM_PARAMETERS_ALL sp,    
  HR_ALL_ORGANIZATION_UNITS ou,    
  FND_LANGUAGES_VL lang  
  WHERE ou.organization_id  = sp.org_id  
  AND ep.org_id             = sp.org_id  
  AND lang.language_code(+) = ep.note_language_code  
  and sp.org_id in (##$$ORGS$$##)',
   'Expense Parameters',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

   -------------------------------------------
  -- Tax Signatures
  -------------------------------------------

  add_signature(
   'TAX',
   'SELECT b.name,  
  b.tax_type,  
  b.tax_rate,  
  b.tax_code_combination_id,  
  b.inactive_date,  
  b.org_id,  
  b.tax_id,  
  b.web_enabled_flag,  
  b.tax_recovery_rule_id,  
  b.tax_recovery_rate,  
  b.start_date,  
  b.enabled_flag,  
  b.awt_rate_type,  
  b.offset_tax_code_id
  FROM fnd_lookup_values a,  
  ap_tax_codes_all b
  WHERE a.lookup_code = b.name
  AND a.lookup_type   = ''ZX_WEB_EXP_TAX_CLASSIFICATIONS''
  AND a.language = ''US''
  AND b.org_id in (##$$ORGS$$##)',
   'Taxes Enabled for Internet Expenses',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  -------------------------------------------
  -- Setup Options Signatures
  -------------------------------------------
  
  add_signature(
   'PAYABLES_OPTIONS',
   'select * from ap_system_parameters_all where org_id in (##$$ORGS$$##)',
   'Payables Options',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'FINANCIAL_OPTIONS',
   'select * from financials_system_params_all where org_id in (##$$ORGS$$##)',
   'Financial Options',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');
   
  add_signature(
   'ACCOUNTING',
   'SELECT *
  FROM  
  (SELECT /* Query for COA which are not yet setup*/    
  coa.id_flex_structure_name chart_of_accounts,    
  coa.description description,    
  id_flex_num chart_of_accounts_id,    
  TO_DATE(NULL) last_update_date,    
  TO_CHAR(NULL) last_updated_by  
  FROM fnd_id_flex_structures_vl coa  
  WHERE coa.application_id       =101  
  AND coa.id_flex_code           =''GL#''  
  AND freeze_flex_definition_flag=''Y''  
  AND enabled_flag               =''Y''  
  AND NOT EXISTS    
  (SELECT 1    
  FROM ap_web_accflex_segments setup    
  WHERE coa.id_flex_num = setup.id_flex_num    
  )  
  AND EXISTS    
  (SELECT 1     
  FROM gl_sets_of_books gl    
  WHERE gl.chart_of_accounts_id = coa.id_flex_num    
  AND rownum                    =1    
  )  
  UNION ALL  
  SELECT DISTINCT /*Query for COA which are already setup*/    
  coa.id_flex_structure_name chart_of_accounts,    
  coa.description description,    
  coa.id_flex_num chart_of_accounts_id,    
  setup.last_update_date,    
  NVL(hr.full_name, NVL(users.description,users.user_name)) last_updated_by  
  FROM fnd_id_flex_structures_vl coa,    
  ap_web_accflex_segments setup,    
  fnd_user users,    
  per_people_x hr  
  WHERE coa.application_id       =101  
  AND coa.id_flex_code           =''GL#''  
  AND freeze_flex_definition_flag=''Y''  
  AND coa.enabled_flag           =''Y''  
  AND coa.id_flex_num            = setup.id_flex_num  
  AND setup.last_updated_by      = users.user_id (+)  
  AND hr.person_id (+)           = users.employee_id  
  AND setup.last_update_date     =    
  (SELECT MAX(last_update_date)    
  FROM ap_web_accflex_segments    
  WHERE id_flex_num = coa.id_flex_num    
  )  
  ) QRSLT
  ORDER BY chart_of_accounts ASC',
   'Chart of Accounts',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');   
  -------------------------------------------
  -- Credit Signatures
  -------------------------------------------
  add_signature(
   'CARD_CODE_SET',
   'select * from AP_CARD_CODE_SETS_ALL where org_id in (##$$ORGS$$##)',
   'Card Code Sets',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'CARD_CODES',
    'select * from AP_CARD_CODES_ALL where org_id in (##$$ORGS$$##)',
   'Card Codes',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'CARD_PROGRAMS',
    'select * from AP_CARD_PROGRAMS_ALL where org_id in (##$$ORGS$$##)',
   'Card Programs',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'CARD_GL_SET',
    'select * from AP_CARD_GL_SETS_ALL where org_id in (##$$ORGS$$##)',
   'Card GL Sets',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'CARD_GL_ACCT',
    'select * from AP_CARD_GL_ACCTS_ALL where org_id in (##$$ORGS$$##)',
   'Card GL Accounts',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'CARD_SUP',
    'select * from AP_CARD_SUPPLIERS_ALL where org_id in (##$$ORGS$$##)',
   'Card Suppliers',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'CARD_PROFILE',
    'select acpr.card_program_name, acpr.card_program_id, acpa.*
  from AP_CARD_PROFILES_ALL acpa,     
  AP_CARD_PROGRAMS_ALL acpr
  where acpa.card_program_id = acpr.card_program_id  
  and acpr.org_id in (##$$ORGS$$##)',
   'Card Profiles',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'CARD_PROFILE_LIMIT',
   'select acpr.card_program_name, acpr.card_program_id, acpa.profile_name,acpla.*
  from AP_CARD_PROFILES_ALL acpa,     
  AP_CARD_PROGRAMS_ALL acpr,     
  AP_CARD_PROFILE_LIMITS_ALL acpla
  where acpa.card_program_id = acpr.card_program_id  
  and acpa.profile_id = acpla.profile_id  
  and acpr.org_id in (##$$ORGS$$##)',
   'Card Profile Limits',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');
   
   ------------------------------------------------------------------------------
  -- Workflow Processes/Activities/Notifications  SIGNATURES
  ------------------------------------------------------------------------------

  add_signature(
   'WORKFLOW_SETUP',
   'select * from (
                   SELECT fi.file_id, filename, version,ve.last_update_date
                   FROM ad_files fi, ad_file_versions ve
                   WHERE UPPER(filename) LIKE UPPER(''apwxwkfl.wft'')
                   AND ve.file_id = fi.file_id
                   order by 4 desc
                   )
                   where rownum < 2',
   'AP Expense Workflow Version',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'AME_SETUP',
   'Select decode(
                   to_char(nvl(fnd_profile.value(''AME_INSTALLATION_LEVEL'')
                   ,''Pre-AME.B'')),''Pre-AME.B'',''Pre-AME.B'',''1'',''Pre-AME.B''
                   ,''1.1'',''Pre-AME.B'',''2'',''Post-AME.B'',''Post-AME.B'') 
                    AME_LEVEL From Dual',
   'AME Setup Details',
   'NRS',
   NULL,
   '<ul>
   <li>Follow [290032.1] to run the respective getAMESetup11510.sql script</li>
   <li>Source KB Article: [290032.1]</li>
   </ul>',
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  ------------------------------------------------------------------------------
  -- Employee Related  SIGNATURES
  ------------------------------------------------------------------------------

  add_signature(
   'HR_INFO',
   'SELECT * 
    FROM
    (SELECT emp.full_name, 
                     emp.employee_num, 
                     emp.default_code_combination_id,
               employee_id person_id,
         emp.set_of_books_id,
         ''Employee'',
         emp.expense_check_address_flag,
         emp.organization_id,
         emp.supervisor_id
         FROM  per_employees_x emp
         WHERE  emp.employee_id = ##$$EMPID$$## 
         AND NOT AP_WEB_DB_HR_INT_PKG.ispersoncwk(emp.employee_id)=''Y''
       UNION ALL
         SELECT cwk.full_name, 
                     cwk.npw_number employee_num,
               cwk.default_code_combination_id,
                     cwk.person_id,
         cwk.set_of_books_id,
         ''Contingent Worker'',
         cwk.expense_check_address_flag,
         cwk.organization_id,
         cwk.supervisor_id
         FROM  per_cont_workers_current_x cwk
         WHERE  cwk.person_id = ##$$EMPID$$##)',
   'Employee HR Information',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'SUP_INFO',
   'SELECT * 
    FROM
    (SELECT emp.full_name, 
                     emp.employee_num, 
                     emp.default_code_combination_id,
               emp.employee_id person_id,
         emp.set_of_books_id,
         ''Employee'',
         emp.expense_check_address_flag,
         emp.organization_id
         FROM  per_employees_x emp,
               per_employees_x sup
         WHERE  sup.employee_id = ##$$EMPID$$##
         AND emp.employee_id = sup.supervisor_id
         AND NOT AP_WEB_DB_HR_INT_PKG.ispersoncwk(emp.employee_id)=''Y''
       UNION ALL
         SELECT cwk.full_name, 
                     cwk.npw_number employee_num,
               cwk.default_code_combination_id,
                     cwk.person_id,
         cwk.set_of_books_id,
         ''Contingent Worker'',
         cwk.expense_check_address_flag,
         cwk.organization_id
         FROM  per_cont_workers_current_x cwk,
               per_cont_workers_current_x sup_cwk
         WHERE  sup_cwk.person_id = ##$$EMPID$$##
         AND cwk.person_id = sup_cwk.supervisor_id)',
   'Supervisor Information',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'USER_INFO',
   'SELECT fu.user_id, fu.user_name, TO_CHAR(fu.start_date, ''DD-MON-YYYY HH24:MI:SS'') User_Start_Date, 
      TO_CHAR(fu.end_date, ''DD-MON-YYYY HH24:MI:SS'') User_End_Date, 
      DECODE(sec.attribute_code,''ICX_HR_PERSON_ID'', ''Yes'', ''No'') Sec_Attribute_Defined,
      FND_PROFILE.VALUE_SPECIFIC(
                         NAME    => ''ICX_PREFERRED_CURRENCY'',
                         USER_ID => fu.user_id,
                         RESPONSIBILITY_ID => null,
                         APPLICATION_ID => null) User_Preferred_Currency
     FROM fnd_user fu, AK_WEB_USER_SEC_ATTR_VALUES sec
     WHERE employee_id = ##$$EMPID$$##
     AND fu.user_id = sec.web_user_id(+)
           AND sec.attribute_code(+) = ''ICX_HR_PERSON_ID'' ',
   'User Information',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'ACCOUNTING_INFO',
   'SELECT GS.chart_of_accounts_id,
         gl.code_combination_id,
         gl.concatenated_segments,
         ap_oie_detect_pkg.is_account_valid(GS.chart_of_accounts_id,gl.concatenated_segments) DEA_Valid,
         ap_oie_detect_pkg.get_cost_center(GS.chart_of_accounts_id,gl.code_combination_id) cost_center
           FROM gl_sets_of_books GS,
                gl_code_combinations_kfv gl,
                per_employees_x emp
          WHERE GS.set_of_books_id = emp.set_of_books_id
          AND gs.chart_of_accounts_id = gl.chart_of_accounts_id
          AND gl.code_combination_id = emp.default_code_combination_id
          AND emp.employee_id = ##$$EMPID$$##',
   'Accounting Information',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  ------------------------------------------------------------------------------
  -- Auditor setup and Audit Rules SIGNATURES
  ------------------------------------------------------------------------------
  add_signature(
   'AUDITORS',
   'select * from AP_AUD_AUDITORS',
   'Auditors',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'RULE_SETUP',
   'select * from AP_AUD_RULE_SETS where rule_set_type = ''RULE''',
   'Audit Rule Setup',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'RULE_ASSIGN',
   'select       
  aara.rule_assignment_id,       
  aara.rule_set_id,       
  aars.rule_set_name,       
  aara.org_id,       
  aara.start_date,       
  aara.end_date 
  from AP_AUD_RULE_ASSIGNMENTS_ALL aara,      
  AP_AUD_RULE_SETS aars
  where aara.rule_set_id = aars.rule_set_id  
  and aars.rule_set_type = ''RULE''  
  and aara.org_id in (##$$ORGS$$##)',
   'Audit Rule Assignments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'LIST_SETUP',
   'select * from AP_AUD_RULE_SETS where rule_set_type = ''AUDIT_LIST''',
   'Audit List Rule',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'LIST_ASSIGN',
   'select       
  aara.rule_assignment_id,       
  aara.rule_set_id,       
  aars.rule_set_name,       
  aara.org_id,       
  aara.start_date,       
  aara.end_date 
  from AP_AUD_RULE_ASSIGNMENTS_ALL aara,      
  AP_AUD_RULE_SETS aars
  where aara.rule_set_id = aars.rule_set_id  
  and aars.rule_set_type = ''RECEIPT''  
  and aara.org_id in (##$$ORGS$$##)',
   'Audit List Rule Assignments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'RECEIPT_SETUP',
   'select * from AP_AUD_RULE_SETS where rule_set_type = ''RECEIPT''',
   'Receipt Rules',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'RECEIPT_ASSIGN',
   'select       
  aara.rule_assignment_id,       
  aara.rule_set_id,       
  aars.rule_set_name,       
  aara.org_id,       
  aara.start_date,       
  aara.end_date 
  from AP_AUD_RULE_ASSIGNMENTS_ALL aara,      
  AP_AUD_RULE_SETS aars
  where aara.rule_set_id = aars.rule_set_id  
  and aars.rule_set_type = ''RECEIPT''  
  and aara.org_id in (##$$ORGS$$##)',
   'Receipt Rule Assignments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'NOTIFY_SETUP',
   'select * from AP_AUD_RULE_SETS where rule_set_type = ''NOTIFY''',
   'Notification Rules',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'NOTIFY_ASSIGN',
   'select       
  aara.rule_assignment_id,       
  aara.rule_set_id,       
  aars.rule_set_name,       
  aara.org_id,       
  aara.start_date,       
  aara.end_date 
  from AP_AUD_RULE_ASSIGNMENTS_ALL aara,      
  AP_AUD_RULE_SETS aars
  where aara.rule_set_id = aars.rule_set_id  
  and aars.rule_set_type = ''HOLD''  
  and aara.org_id in (##$$ORGS$$##)',
   'Notification Rule Assignments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'HOLD_SETUP',
   'select * from AP_AUD_RULE_SETS where rule_set_type = ''HOLD''',
   'Hold Rules',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'HOLD_ASSIGN',
   'select       
  aara.rule_assignment_id,       
  aara.rule_set_id,       
  aars.rule_set_name,       
  aara.org_id,       
  aara.start_date,       
  aara.end_date 
  from AP_AUD_RULE_ASSIGNMENTS_ALL aara,      
  AP_AUD_RULE_SETS aars
  where aara.rule_set_id = aars.rule_set_id  
  and aars.rule_set_type = ''HOLD''  
  and aara.org_id in (##$$ORGS$$##)',
   'Hold Rule Assignments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'POL_CONTEXT',
   'select user_id,selected_org_id from AP_POL_CONTEXT where selected_org_id in (##$$ORGS$$##)',
   'User & Organization Specific Policy Compliance Setup',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'POL_TOLERANCE',
   'select b.exchange_rate_id,a.exchange_rate_tolerance_id, a.currency_code, a.tolerance, b.default_exchange_rates, 
       b.exchange_rate_type, b.exchange_rate_allowance, b.overall_tolerance, b.enabled, b.org_id 
      from AP_POL_EXRATE_TOLERANCES a,
           AP_POL_EXRATE_OPTIONS_ALL b
     where a.exchange_rate_id = b.exchange_rate_id
      and b.org_id in (##$$ORGS$$##)',
   'Exchange Rate Tolerance',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');
   
  add_signature(
   'VAT_SETUP',
   'select * from AP_WEB_VAT_SETUP_ALL where org_id in (##$$ORGS$$##)',
   'VAT-related Setup',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');   

  add_signature(
   'DIST_SET',
   'select a.distribution_set_id,a.distribution_id,b.distribution_set_name,
       b.distribution_method,b.distribution_set_type_code, a.percentage, 
       b.org_id,a.segment1,a.segment2,a.segment3,a.segment4,a.segment5,
       a.segment6,a.segment7,a.segment8,a.segment9,a.segment10
      from OIE_SET_DISTRIBUTIONS a, OIE_DISTRIBUTION_SETS_ALL b
     where a.distribution_set_id = b.distribution_set_id
       and b.org_id in (##$$ORGS$$##)',
   'Distribution Sets',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');  

  add_signature(
   'DUP_DETECTION',
   'select b.rule_id,a.rule_set_id, b.rule_name,b.rule_type,b.description,
       c.rule_set_name,c.description, d.category_code,a.*
      from   OIE_DUP_RULE_ASSIGNMENTS_ALL a,
       OIE_DUP_DETECT_RULES b,
       OIE_DUP_DETECT_RS_SUMMARY c,
       OIE_DUP_DETECT_RS_DETAIL d
     where a.rule_id = b.rule_id
      and c.rule_set_id = a.rule_set_id
      and d.rule_set_id = a.rule_set_id
      and a.org_id in (##$$ORGS$$##)',
   'Duplicate Detection Rules',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');  
   
---------
---GDF
---------

  add_signature(
   'FND_LOOKUP_TYPES',
   'select * from FND_LOOKUP_TYPES
    where lower(lookup_type) like ''expense report status''
    and view_application_id = 0',
   'Audit Expense Report Lookup Type',
   'RS',
   'The lookup type ''Expense Report Status'' was defined more than once in file apoie12alu.ldt',
   '<ul>
    <li>**Any** rows returned indicate duplicates appear to be present, as the selects are tailored to pull the duplicate data, not the original good data</li>
   <li>Follow instructions in [1104883.1]</li>
   <li>Source KB Article: [1104883.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');


  add_signature(
   'FND_LOOKUP_TYPES_TL',
   'select * from FND_LOOKUP_TYPES_TL
    where lower(lookup_type) like ''expense report status''
    and view_application_id = 0',
   'Audit Expense Report Lookup Type TL',
   'RS',
   'The lookup type ''Expense Report Status'' was defined more than once in file apoie12alu.ldt',
   '<ul>
    <li>**Any** rows returned indicate duplicates appear to be present, as the selects are tailored to pull the duplicate data, not the original good data</li>
   <li>Follow instructions in [1104883.1]</li>
   <li>Source KB Article: [1104883.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');


  add_signature(
   'FND_LOOKUP_VALUES',
   'select * from FND_LOOKUP_VALUES
    where lower(lookup_type) like ''expense report status''
    and view_application_id = 0',
   'Audit Expense Report Lookup Type TL',
   'RS',
   'The lookup type ''Expense Report Status'' was defined more than once in file apoie12alu.ldt',
   '<ul>
    <li>**Any** rows returned indicate duplicates appear to be present, as the selects are tailored to pull the duplicate data, not the original good data</li>
   <li>Follow instructions in [1104883.1]</li>
   <li>Source KB Article: [1104883.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'Note403933',
   'select aerh.vouchno, aerh.org_id, aerh.report_header_id,aerh.expense_status_code,ap.payment_status_flag
    from ap_expense_report_headers_all aerh, ap_invoices_all ap
    where aerh.expense_status_code = ''INVOICED''
    and aerh.vouchno > 0 and aerh.total <> 0
    and ap.invoice_id = aerh.vouchno and ap.cancelled_date is null
    and ap.payment_status_flag != ''N''',
   'Paid Expense Report Shows Incorrect Status',
   'RS',
   'Paid Expense Report Shows Incorrect Status',
   '<ul>
    <li>**Any** rows returned indicate that the status of the expense report is incorrect</li>
   <li>Follow instructions in [403933.1]</li>
   <li>Source KB Article: [403933.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');
  ------------------------------------------------------------------------------
  -- Generic
  ------------------------------------------------------------------------------


/*
  -------------------------------------------
  -- Note 390023.1 Generic Case 1
  -------------------------------------------

-- ### An example of loading the extra information fields.  
-- ### Delete existing values, load the new ones into the hash and then
-- ### pass this in to add_signatures

  l_info.delete;
  l_info('Doc ID') := '390023.1';
  l_info('Bug Number') := '9707155';

  add_signature(
   'Note390023.1_case_GEN1',
   'SELECT count(*)
    FROM (
         SELECT bug_number FROM ad_bugs
         UNION
         SELECT patch_name FROM ad_applied_patches
       ) bugs
    WHERE bugs.bug_number like ''9707155''',
    'Reset Patch Not Applied',
    '[count(*)] = [0]',
    'The patch for resetting a document has not been applied',
    'In order to reset stuck documents you will need to apply {9707155} '||
      'which contains the requires data fix scripts',
    null,
    'FAILURE',
    'W',
    'N',
    'Y',
    l_info);


  -------------------------------------------
  -- Note 390023.1 General Case 4
  -------------------------------------------
  l_info.delete;
  add_signature(
   'Note390023.1_case_GEN4',
   'SELECT ''PO/PA'' "Doc Type",
           h.segment1 "Doc Number",
           h.po_header_id "Doc ID",
           h.org_id,
           null "Release Num",
           null "PO Release ID",
           h.type_lookup_code "Type Code",
           h.authorization_status "Athorization Status",
           nvl(h.cancel_flag,''N'') canceled,
           nvl(h.closed_code,''OPEN'') "Closed Code",
           h.change_requested_by "Change Requested By",
           h.revision_num,
           h.wf_item_type, h.wf_item_type "##$$FK1$$##",
           h.wf_item_key, h.wf_item_key "##$$FK2$$##",
           h.approved_date "Approved Date"
    FROM po_headers_all h
    WHERE to_date(''##$$FDATE$$##'') <= (
            SELECT max(ah.action_date) FROM po_action_history ah
            WHERE ah.object_id = h.po_header_id
            AND   ah.object_type_code IN (''PO'',''PA'')
            AND   ah.action_code = ''SUBMIT''
            AND   ah.object_sub_type_code = h.type_lookup_code)
    AND   h.org_id = ##$$ORGID$$##
    AND   h.authorization_status IN (''IN PROCESS'', ''PRE-APPROVED'')
    AND   nvl(h.cancel_flag,''N'') <> ''Y''
    AND   nvl(h.closed_code,''OPEN'') <> ''FINALLY CLOSED''
    AND   nvl(h.change_requested_by,''NONE'') NOT IN (''REQUESTER'',''SUPPLIER'')
    AND   (nvl(h.ENCUMBRANCE_REQUIRED_FLAG, ''N'') <> ''Y'' OR
           h.type_lookup_code <> ''BLANKET'')
    AND   NOT EXISTS (
            SELECT null
            FROM wf_item_activity_statuses ias,
                 wf_notifications n
            WHERE ias.notification_id is not null
            AND   ias.notification_id = n.group_id
            AND   n.status = ''OPEN''
            AND   ias.item_type = ''POAPPRV''
            AND   ias.item_key IN (
                    SELECT i.item_key FROM wf_items i
                    START WITH i.item_type = ''POAPPRV''
                    AND        i.item_key = h.wf_item_key
                    CONNECT BY PRIOR i.item_type = i.parent_item_type
                    AND        PRIOR i.item_key = i.parent_item_key
                    AND     nvl(i.end_date,sysdate+1) >= sysdate))
    AND   NOT EXISTS (
            SELECT 1
            FROM po_lines_all l,
                 po_line_locations_all s,
                 po_distributions_all d
            WHERE  s.line_location_id = d.line_location_id
            AND   l.po_line_id = s.po_line_id
            AND   d.po_header_id = h.po_header_id
            AND   l.matching_basis = ''QUANTITY''
            AND   nvl(d.encumbered_flag, ''N'') = ''Y''
            AND   nvl(s.cancel_flag, ''N'') = ''N''
            AND   nvl(s.closed_code, ''OPEN'') <> ''FINALLY CLOSED''
            AND   nvl(d.prevent_encumbrance_flag, ''N'') = ''N''
            AND   d.budget_account_id IS NOT NULL
            AND   nvl(s.shipment_type,''BLANKET'') = ''STANDARD''
            AND   round(nvl(d.encumbered_amount, 0), 2) <>
                    round((s.price_override * d.quantity_ordered *
                    nvl(d.rate, 1) + nvl(d.nonrecoverable_tax, 0) *
                    nvl(d.rate, 1)), 2)
            UNION
            SELECT 1
            FROM po_lines_all l,
                 po_line_locations_all s,
                 po_distributions_all d
            WHERE  s.line_location_id = d.line_location_id
            AND   l.po_line_id = s.po_line_id
            AND   d.po_header_id = h.po_header_id
            AND   l.matching_basis = ''AMOUNT''
            AND   nvl(d.encumbered_flag, ''N'') = ''Y''
            AND   nvl(s.cancel_flag, ''N'') = ''N''
            AND   nvl(s.closed_code, ''OPEN'') <> ''FINALLY CLOSED''
            AND   nvl(d.prevent_encumbrance_flag, ''N'') = ''N''
            AND   d.budget_account_id IS NOT NULL
            AND   nvl(s.shipment_type,''BLANKET'') = ''STANDARD''
            AND   round(nvl(d.encumbered_amount, 0), 2) <>
                    round((d.amount_ordered +
                    nvl(d.nonrecoverable_tax, 0)) *
                    nvl(d.rate, 1), 2))
    AND   NOT EXISTS (
            SELECT 1
            FROM po_lines_all l,
                 po_line_locations_all s,
                 po_distributions_all d
            WHERE  s.line_location_id = d.line_location_id
            AND   l.po_line_id = s.po_line_id
            AND   d.po_header_id = h.po_header_id
            AND   nvl(d.encumbered_flag, ''N'') = ''Y''
            AND   nvl(d.prevent_encumbrance_flag, ''N'') = ''N''
            AND   d.budget_account_id IS NOT NULL
            AND   nvl(s.shipment_type,''BLANKET'') = ''PLANNED'')
    ORDER BY 1,2',
   'Recent Documents - Candidates for Reset',
   'RS',
   'Recent documents exist which are candidates for reset.  The documents
    listed are all IN PROCESS or PRE-APPROVED approval status
    and do not have an open workflow notification.',
   '<ul><li>Review the results in the Workflow Activity section
         for the documents.</li>
      <li>If multiple documents are stuck with errors in the same
         workflow activity then try the Mass Retry in Doc ID 458216.1.</li>
      <li>For all other document see DocId 390023.1 for details on
         how to reset these documents if needed.</li></ul>', 
   null,
   'FAILURE',
   'E',
   'RS',
   'Y',
   l_info,
   VARCHAR_TBL('Note390023.1_case_GEN4_CHILD1',
     'Note390023.1_case_GEN4_CHILD2'));

    -------------------------------------------
    -- Note 390023.1 General Case 4 - WF Child 1
    -------------------------------------------
    l_info.delete;
    add_signature(
     'Note390023.1_case_GEN4_CHILD1',
     'SELECT DISTINCT
             ac.name Activity,
             ias.activity_result_code Result,
             ias.error_name ERROR_NAME,
             ias.error_message ERROR_MESSAGE,
             ias.error_stack ERROR_STACK
      FROM wf_item_activity_statuses ias,
           wf_process_activities pa,
           wf_activities ac,
           wf_activities ap,
           wf_items i
      WHERE ias.item_type = ''##$$FK1$$##''
      AND   ias.item_key  = ''##$$FK2$$##''
      AND   ias.activity_status     = ''ERROR''
      AND   ias.process_activity    = pa.instance_id
      AND   pa.activity_name        = ac.name
      AND   pa.activity_item_type   = ac.item_type
      AND   i.item_type             = ias.item_type
      AND   i.item_key              = ias.item_key
      AND   i.begin_date            >= ac.begin_date
      AND   i.begin_date            < nvl(ac.end_date, i.begin_date+1)
      AND   (ias.error_name is not null OR 
             ias.error_message is not null OR
             ias.error_stack is not null)
      ORDER BY 1,2',
     'WF Activity Errors for This Document',
     'NRS',
     'No errored WF activities found for the document',
     null,
     null,
     'SUCCESS',
     'I',
     'RS');

    -------------------------------------------
    -- Note 390023.1 General Case 4 - WF Child 2
    -------------------------------------------
    l_info.delete;
    add_signature(
     'Note390023.1_case_GEN4_CHILD2',
     'SELECT DISTINCT
             iav.name Attribute,
             pa.process_name,
             pa.activity_name,
             ias.activity_result_code Result,
             nvl(iav.text_value,
               to_char(iav.number_value)) error_msg
      FROM wf_item_activity_statuses ias,
           wf_process_activities pa,
           wf_item_attribute_values iav
      WHERE ias.item_type = ''##$$FK1$$##''
      AND   ias.item_key  = ''##$$FK2$$##''
      AND   iav.item_type = ias.item_type
      AND   iav.item_key = ias.item_key
      AND   ias.activity_status  = ''ERROR''
      AND   iav.name in (''SYSADMIN_ERROR_MSG'',''PLSQL_ERROR_MSG'')
      AND   (iav.text_value is not null OR 
             iav.number_value is not null)
      AND   ias.process_activity = pa.instance_id
      ORDER BY 1,2',
     'WF Error Attribute Values for This Document',
     'NRS',
     null,
     null,
     null,
     'SUCCESS',
     'I',
     'RS');



  add_signature(
   'WFSTAT_ITEM',
   'SELECT ITEM_TYPE,
        ITEM_KEY,
        PARENT_ITEM_TYPE,
        PARENT_ITEM_KEY,
        PARENT_CONTEXT,
        to_char(BEGIN_DATE,''DD-MON-RR HH24:MI:SS'') BEGIN_DATE,
        to_char(END_DATE,''DD-MON-RR HH24:MI:SS'') END_DATE,
	ROOT_ACTIVITY,
        ROOT_ACTIVITY_VERSION,
        OWNER_ROLE
      FROM wf_items
     WHERE item_type = ''##$$ITMTYPE$$##''
       AND item_key = ''##$$ITMKEY$$##''',
    'WFStat: Workflow Item',
    'NRS',
    'No WF Item Type found for the combination of Item Type / Item Key',
    'This likely due to the WF_ITEMS table being purged',
    NULL,
    'ALWAYS',
    'W',
    'RS');
*/


EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;





---------------------------------
-- MAIN ENTRY POINT
---------------------------------
PROCEDURE main (
      p_org_ids    IN VARCHAR2 DEFAULT NULL,
      p_per        IN NUMBER DEFAULT NULL,
      p_resp       IN VARCHAR2 DEFAULT NULL,
      p_max_output_rows IN NUMBER   DEFAULT 200,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
  
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Internet Expenses (OIE)';

  l_step := '20';
 validate_parameters(
      p_org_ids    ,
      p_per        ,
      p_resp       ,
      p_max_output_rows,
      p_debug_mode);

  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #13
  start_section('Proactive and Preventative Recommendations');
     set_item_result(check_rec_patches);
     set_item_result(run_stored_sig('VERSIONS'));
  end_section;
  
  -- Profile Options Section
  start_section('Profile Options Details');
    set_item_result(run_stored_sig('KEY_PROFILES'));
    set_item_result(run_stored_sig('OPT_KEY_PROFILES'));
  end_section;
  
  -- Employee
	if p_per is not null then
    start_section('Employee Details');
      set_item_result(run_stored_sig('HR_INFO'));
      set_item_result(run_stored_sig('SUP_INFO'));
      set_item_result(run_stored_sig('USER_INFO'));
      set_item_result(run_stored_sig('ACCOUNTING_INFO'));
    end_section;
  end if;
  
  -- Setup Options
    start_section('Setup Options Details');
      set_item_result(run_stored_sig('PAYABLES_OPTIONS'));
      set_item_result(run_stored_sig('FINANCIAL_OPTIONS'));
      set_item_result(run_stored_sig('ACCOUNTING'));
      set_item_result(run_stored_sig('VAT_SETUP'));
    end_section;

  -- Expense Report Templates
    start_section('Expense Report Template Details');
      set_item_result(run_stored_sig('EXPENSE_REPORTS_TEMPLATES'));
      set_item_result(run_stored_sig('EXPENSE_PARAMS'));
    end_section;
	
  -- Tax
    start_section('Tax Details');
      set_item_result(run_stored_sig('TAX'));
    end_section;

  -- Credit Card
    start_section('Credit Card Details');
      /*
      ---Related to PCARD
      set_item_result(run_stored_sig('CARD_CODE_SET'));
      set_item_result(run_stored_sig('CARD_CODES'));
      set_item_result(run_stored_sig('CARD_GL_SET'));
      set_item_result(run_stored_sig('CARD_GL_ACCT'));
      set_item_result(run_stored_sig('CARD_PROFILE'));
      set_item_result(run_stored_sig('CARD_PROFILE_LIMIT'));*/
      set_item_result(run_stored_sig('CARD_PROGRAMS'));
      set_item_result(run_stored_sig('CARD_SUP'));
    end_section;	
	
  -- Workflow Processes/Activites/Notifications
    start_section('Workflow Processes/Activites/Notifications Details');
      set_item_result(run_stored_sig('WORKFLOW_SETUP'));
      set_item_result(run_stored_sig('AME_SETUP'));
    end_section;

  -- Auditor Setup and Audit Rules
    start_section('Auditor Setup and Audit Rules Details');
      set_item_result(run_stored_sig('AUDITORS'));
      set_item_result(run_stored_sig('RULE_SETUP'));
      set_item_result(run_stored_sig('RULE_ASSIGN'));
      set_item_result(run_stored_sig('LIST_SETUP'));
      set_item_result(run_stored_sig('LIST_ASSIGN'));
      set_item_result(run_stored_sig('RECEIPT_SETUP'));
      set_item_result(run_stored_sig('RECEIPT_ASSIGN'));
      set_item_result(run_stored_sig('NOTIFY_SETUP'));
      set_item_result(run_stored_sig('NOTIFY_ASSIGN'));
      set_item_result(run_stored_sig('HOLD_SETUP'));
      set_item_result(run_stored_sig('HOLD_ASSIGN'));
    end_section;

  -- Policy Context
    start_section('Policy Compliance Setup Details');
      set_item_result(run_stored_sig('POL_CONTEXT'));
      set_item_result(run_stored_sig('POL_TOLERANCE'));
    end_section;

  -- Additional
    start_section('Additional Setup Details');
      set_item_result(run_stored_sig('DIST_SET'));
      IF substr(g_rep_info('Apps Version'),1,6) = '12.1.3' THEN
          set_item_result(run_stored_sig('DUP_DETECTION'));
      END IF;
    end_section;

  -- GDF
    start_section('Corruptions where Generic Data Fixes (GDF) Exist');
      set_item_result(run_stored_sig('FND_LOOKUP_TYPES'));
      set_item_result(run_stored_sig('FND_LOOKUP_TYPES_TL'));
      set_item_result(run_stored_sig('FND_LOOKUP_VALUES'));
      set_item_result(run_stored_sig('Note403933'));
    end_section;

  -- Personalizations/customizations
  start_section('Personalizations, Customizations and Invalids');
     set_item_result(run_stored_sig('PRODUCT'));
     set_item_result(run_stored_sig('INVALIDS'));
     set_item_result(print_pers('/oracle/apps/ap/oie',TRUE));
  end_section;
  
   -- Profile Options Data Collection Section
  start_section('Profile Options Data Collection Details');
    set_item_result(run_stored_sig('KEY_PROFILES_DATA'));
    set_item_result(run_stored_sig('OPT_KEY_PROFILES_DATA'));
  end_section;	
  
  -- End of Sections and signatures
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  print_out('<a href="https://community.oracle.com/thread/3349972" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

-------------------------------------------
-- MAIN ENTRY POINT FOR CONCURRENT PROCESS
-- uncomment to run from concurrent program
-- edit list of variables to match MAIN
-- <package>.main_cp will be what you define program to call
-------------------------------------------
PROCEDURE main_cp(
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_org_ids    IN VARCHAR2 DEFAULT NULL,
      p_per        IN NUMBER DEFAULT NULL,
      p_resp       IN VARCHAR2 DEFAULT NULL,
      p_max_output_rows IN NUMBER   DEFAULT 200,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

BEGIN
  g_retcode := 0;
  g_errbuf := null;

  main(
  -- ### Call with all of your parameters except errbuf/retcode
      p_org_ids    => p_org_ids,
      p_per        => p_per,
      p_resp       => p_resp,
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode);

  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


END AP_OIE_DETECT_PKG;
/
show errors
exit;