REM $Id: demantra_perf_analyze.sql, 200.2 2015/15/01 23:27:42 jxmccall Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    demantra_perf_analyze.sql                                            |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the demantra_perf_pkg.main procedure           |
REM |                                                                         |
REM | HISTORY                                                                 |
REM |   28-Oct-2015 Converted to the Analyzer Framework 3.0.29                |
REM +=========================================================================+
REM
REM ANALYZER_BUNDLE_START
REM
REM COMPAT: 11i 12.0 12.1 12.2
REM
REM MENU_TITLE: Demantra Performance and Setup Analyzer
REM
REM MENU_START
REM
REM SQL: Run Demantra Performance and Setup Analyzer Analyzer
REM FNDLOAD: Load Demantra Performance and Setup Analyzer Analyzer as a Concurrent Program
REM
REM MENU_END
REM
REM
REM HELP_START 
REM
REM  V7.3.1: Demantra Performance and Setup Analyzer / Monitoring Tool Help [Doc ID: 1618885.1]
REM
REM  Compatible: 11i 12.0 12.1 12.2
REM
REM  Explanation of available options:
REM
REM    (1) Run V7.3.1: Demantra Performance and Setup Analyzer / Monitoring Tool
REM        o Runs demantra_performance_analyzer.sql as APPS
REM        o Creates an HTML report file under MENU/output
REM
REM    (2) Install V7.3.1: Demantra Performance and Setup Analyzer / Monitoring Tool
REM        as a Concurrent Program
REM        o Runs FNDLOAD as APPS
REM        o Defines the analyzer as a concurrent executable/program
REM        o Adds the analyzer to the request group: "All MSC Reports"
REM
REM
REM HELP_END
REM
REM FNDLOAD_START
REM
REM PROD_TOP: MSD_TOP
REM PROG_NAME: MSCDPA_SQL
REM APP_NAME: Demand Planning
REM DEF_REQ_GROUP: Demand Planning
REM PROG_TEMPLATE: MSCDPA_SQL.ldt
REM PROD_SHORT_NAME: MSD
REM
REM FNDLOAD_END
REM
REM DEPENDENCIES_START
REM
REM demantra_perf_analyzer.sql
REM
REM DEPENDENCIES_END
REM 
REM RUN_OPTS_START
REM
REM RUN_OPTS_END
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END 

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
-- PSD #1
PROMPT Submitting Demantra Performance Analyzer.



BEGIN

-- PSD #4
  demantra_perf_pkg.main;

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
