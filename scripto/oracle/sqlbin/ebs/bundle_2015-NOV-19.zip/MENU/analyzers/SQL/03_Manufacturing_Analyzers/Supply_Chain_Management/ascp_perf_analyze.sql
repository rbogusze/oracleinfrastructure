REM $Id: ascp_perf_analyze.sql, 200.2 2015/15/01 23:27:42 jxmccall Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ascp_perf_analyze.sql                                                |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the ascp_perf_pkg.main procedure               |
REM |                                                                         |
REM | HISTORY                                                                 |
REM |   28-Oct-2015 Converted to the Analyzer Framework 3.0.29                |
REM +=========================================================================+
REM 
REM ANALYZER_BUNDLE_START
REM
REM COMPAT: 11i 12.0 12.1 12.2
REM
REM MENU_TITLE: ASCP Performance Analyzer
REM
REM MENU_START
REM
REM SQL: Run ASCP Performance Analyzer
REM FNDLOAD: ASCP Performance Analyzer as a Concurrent Program
REM
REM MENU_END
REM
REM HELP_START 
REM 
REM  Compatible: 11i|12.0|12.1|12.2
REM 
REM  Run ASCP Performance Analyzer script Help [Doc ID: 1554183.1]
REM
REM  Explanation of available options:
REM
REM    (1) Run ASCP Performance Analyzer
REM        o Runs ascp_perf_analyzer.sql as APPS
REM        o Creates an HTML report file under MENU/output/
REM
REM    (2) Install ASCP Performance Analyzer as a Concurrent Program
REM        o Runs FNDLOAD as APPS
REM        o Defines the analyzer as a concurrent executable/program
REM        o Adds the analyzer to the request group: "All MSC Reports"
REM
REM
REM HELP_END
REM
REM FNDLOAD_START
REM
REM PROD_TOP: MSC_TOP
REM PROG_NAME: MSCAPA
REM APP_NAME: Advanced Supply Chain Planning
REM DEF_REQ_GROUP: All MSC Reports
REM PROG_TEMPLATE: MSCAPA.ldt
REM PROD_SHORT_NAME: MSC
REM
REM FNDLOAD_END
REM
REM DEPENDENCIES_START
REM
REM ascp_perf_analyzer.sql
REM
REM DEPENDENCIES_END
REM 
REM RUN_OPTS_START
REM
REM RUN_OPTS_END
REM
REM OUTPUT_TYPE: STDOUT
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
-- PSD #1
PROMPT Submitting ASCP Performance Analyzer.



BEGIN

-- PSD #4
  ascp_perf_pkg.main;

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
