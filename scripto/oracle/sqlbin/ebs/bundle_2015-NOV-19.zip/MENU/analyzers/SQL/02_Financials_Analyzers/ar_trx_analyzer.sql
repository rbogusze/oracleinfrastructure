SET DEFINE '~'

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.25                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ar_trx_analyzer.sql                                                  |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Transaction Diagnositc Analyzer                                      |
REM | HISTORY                                                                 |
REM | 18-AUG-2015  KOBEID/HRIKSHEI  Created                                   |
REM | 09-OCT-2015  KOBEID/HRIKSHEI  Added signature for Rev Rec run           |
REM |                               Fixed false positive for rule AR_00057    |
REM | 13-OCT-2015  KOBEID/HRIKSHEI  Changed not running REV REC to Warning    |
REM |                               Added query for RA_CUST_TRX_LINE_SALESREPS|
REM |                               Added query for JTF_RS_SALESREPS          |
REM |                               Added query on MTL_SYSTEM_ITEMS           |
REM |                               Modified ADJUSTMENT Totals query to only  |
REM |                               take approved and postable adjustments    |
REM |                               Added Note.1121944.1 for Rev Rec issues   |
REM |                               Added checker for ZX invalid objects      |
REM |                               Added query for ZX file versions          |
REM |                               Added query for AR file versions to       |
REM |                               include .rdf, .pll files                  |
REM | 21-OCT-2015  KOBEID/HRIKSHEI  Corrected rule_id, AR_S_00002 to AR_00045,|
REM |                               AR_00097 to AR_00052 and AR_00022 to      |
REM |                               AR_00079                                  |
REM |                               Added query on AR_DISPUTE_HISTORY         |
REM |                               Added signature for rule AR_S_00006       |
REM |                               Moved orphan record sig to be the last    |
REM |                               rule to be run                            |
REM |                               Added warning for incomplete trx          |
REM |                               Added signature for rule AR_S_00007       |
REM |                                                                         |
REM |                                                                         |
REM |                                                                         |
REM +=========================================================================+

-- PSD #1
CREATE OR REPLACE PACKAGE ar_trx_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-- PSD #10
PROCEDURE main (
    p_customer_trx_id  IN NUMBER DEFAULT null,
    p_includeGL        in VARCHAR2);

-- PSD #16	  
PROCEDURE main_cp (
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_customer_trx_id IN NUMBER   DEFAULT null,
      p_includeGL       in VARCHAR2);

-- PSD #1
END ar_trx_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY ar_trx_analyzer_pkg AS
-- PSD #1a
-- $Id: ar_trx_analyzer.sql, 200.4 2015/10/21 kobeid/hrikshei Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 100000;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #15  
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=2058269.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;


g_customer_trx_id NUMBER;
g_org_id NUMBER;
g_type VARCHAR2(20);
g_includeGL VARCHAR2(1);
g_invoicing_rule_id NUMBER;
g_complete_flag VARCHAR2(1);
g_count NUMBER;


----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'ar_trx_analyzer_'||g_customer_trx_id||'_'|| l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'ar_trx_analyzer_'||g_customer_trx_id||'_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Browser tab title
  -- PSD #2a: 
  -- Example: '<TITLE>WF Analyzer Report</TITLE>'
  print_out('<TITLE>EBS Oracle Receivables Transaction Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=2058269.1:SCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/ar_trx_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
       
      if p_sig.problem_descr is not null then
          l_html := '<div class="divok"><span class="divok1">Information:</span>' || p_sig.problem_descr;
      else
         l_html := '<div class="divok"><span class="divok1"></span>';
      end if;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
-- PSD #4
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;

  CURSOR get_app_date(p_ptch VARCHAR2) IS
  SELECT max(pr.start_date) app_date
  FROM ad_patch_runs pr
  WHERE pr.patch_run_id in (
          SELECT prb.patch_run_id
          FROM   ad_bugs b,
                 ad_patch_run_bugs prb
          WHERE  b.bug_number = p_ptch
          AND    prb.bug_id = b.bug_id
          UNION
          SELECT pr2.patch_run_id
          FROM ad_applied_patches ap,
               ad_patch_drivers pd,
               ad_patch_runs pr2
          WHERE ap.patch_name = p_ptch
          AND   pd.applied_patch_id = ap.applied_patch_id
          AND   pr2.patch_driver_id = pd.patch_driver_id);
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #4a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '20';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := 'N/A';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.0 Oracle Receivables Critical & Recommended Patches';
    l_col_rows(5)(1) := '[1473872.1]';
 -- If want to go based on more e-Business Application version, just add for example:
 -- ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
  ELSE
    l_step := '30';
    l_col_rows.extend(5);
    
    l_col_rows(1)(1) := '20260691';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) :=  NULL;
    l_col_rows(4)(1) := 'R12.1: Receivables Recommended Patch Collection (AR RPC), Feb 2015';
    l_col_rows(5)(1) := '[1980300.1]';
    
    l_col_rows(1)(2) := '21314094';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) :=  NULL;
    l_col_rows(4)(2) := 'R12.1: Receivables Recommended Patch Collection (AR RPC), Aug 2015';
    l_col_rows(5)(2) := '[2042517.1]';
    
    l_col_rows(1)(3) := '20175470';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) :=  NULL;
    l_col_rows(4)(3) := 'R12.1: Subledger Accounting Recommended Patch Collection (SLA), February 2015';
    l_col_rows(5)(3) := '[1481222.1]';
    
    l_col_rows(1)(4) := '21340722';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) :=  NULL;
    l_col_rows(4)(4) := 'R12.1: Subledger Accounting Recommended Patch Collection (SLA), August 2015';
    l_col_rows(5)(4) := '[1481222.1]';

    l_col_rows(1)(5) := '21276870';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'R12.1: E-Business Tax Reports Recommended Patch Collection (ZX), Aug 2015';
    l_col_rows(5)(5) := '[1481235.1]';

    l_col_rows(1)(6) := '21213464';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'R12.1: E-Business Tax Calculations Recommended Patch Collection (ZX), Aug 2015';
    l_col_rows(5)(6) := '[1481235.1]';   

  -- PSD #4a-end


  END IF;
  -- Check if applied
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i));
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please review list above and schedule to apply any unappplied patches as soon as possible '||
    'in this instance.';
  l_sig.solution := '<ul><li>Please check if any of the recommended patches as per [954704.1] has been applied.</li>
    <li>Refer to the note indicated for more information about
    each patch.</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'Y') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters (
      p_customer_trx_id       IN NUMBER,
      p_includeGL IN VARCHAR2) IS

  l_from_date    VARCHAR2(25);
  l_to_date      VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;

  invalid_parameters EXCEPTION;
  
  -- PSD #7a
  -- AR params
  -- PSD #7a-end
  
BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: ' ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.4 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/10/21 15:07:42 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #7
  g_rep_info('File Name') := 'ar_trx_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
-- PSD #7b
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=2058269.1" target="_blank">(Note 2058269.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  
  -- PSD #7a

  IF p_customer_trx_id is null THEN
    print_log('The customer_trx_id parameter is mandatory.');
    raise invalid_parameters;
  ELSE
      g_invoicing_rule_id := NULL;
      g_count := 0;

     BEGIN
        select trx.customer_trx_id, trx.invoicing_rule_id, typ.type, 
               trx.complete_flag
        into   g_customer_trx_id, g_invoicing_rule_id, g_type, g_complete_flag
        from   ra_customer_trx_all trx,
               ra_cust_trx_types_all typ
        where  trx.customer_trx_id = p_customer_trx_id
        and    trx.cust_trx_type_id = typ.cust_trx_type_id
        and    trx.org_id = typ.org_id;

         null;
     EXCEPTION
     WHEN NO_DATA_FOUND then
       print_log('Customer_trx_id does not exist in RA_CUSTOMER_TRX_ALL, but will continue to look for orphan records.');
       g_customer_trx_id := p_customer_trx_id;
       -- raise invalid_parameters; 
     END;
  END IF;

     select count(*) 
     into g_count
     from ra_cust_trx_line_gl_dist_all
     where customer_trx_id = p_customer_trx_id
     and account_set_flag = 'N'; 
  
  IF upper(p_includeGL) not in ('Y','N') THEN
    print_log('Please enter Y or N to include GL tables.');
    raise invalid_parameters;
  ELSE
     g_includeGL := upper(p_includeGL);
  END IF;
 
  print_log('SQL Token Values');
 
  -- PSD #8
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Customer Trx ID') := g_customer_trx_id;
  g_parameters('2. Include GL Tables') := g_includeGL;
  
  -- PSD #8a
  -- Create global hash of SQL token values
  g_sql_tokens('##$$REL$$##') := g_rep_info('Apps Version');
  g_sql_tokens('##$$TRXID$$##') := g_customer_trx_id;
  
  
  -- PSD #7a-end

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN
-- PSD #9
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------
  
  -------------------------------------------------------------------
  -- Example signature that can be used to check for invalid objects
  --------------------------------------------------------------------
  -- PSD #9a
  
  add_signature(
   'INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''AR%'')
    AND a.status = ''INVALID''',
   'Receivables Related Invalid Objects',
   'RS',
   'There are invalid objects related to Receivables.',
   '<ul>
      <li>Recompile the individual objects manually or recompile the
          entire APPS schema with adadmin utility.</li>
      <li>Review any error messages provided.</li>
   </ul>',
   'No Receivables related invalid objects exists in the database.',
   'ALWAYS',
   'W');
   
  add_signature(
   'XLA INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''XLA%'')
    AND a.status = ''INVALID''',
   'Subledger Accounting Related Invalid Objects',
   'RS',
   'There are invalid objects related to Subledger Accounting.',
   '<ul>
      <li>Recompile the individual objects manually or recompile the
          entire APPS schema with adadmin utility.</li>
      <li>Review any error messages provided.</li>
   </ul>',
   'No XLA related invalid objects exists in the database.',
   'ALWAYS',
   'W');

  add_signature(
   'EBTAX INVALIDS',
   'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''ZX%'')
    AND a.status = ''INVALID''',
   'E-Business Tax Related Invalid Objects',
   'RS',
   'There are invalid objects related to E-Business Tax',
   '<ul>
      <li>Recompile the individual objects manually or recompile the
          entire APPS schema with adadmin utility.</li>
      <li>Review any error messages provided.</li>
   </ul>',
   'No eBTax related invalid objects exists in the database.',
   'ALWAYS',
   'W');
  
    add_signature(
   'LEDGER INFORMATION',
   'select a.target_ledger_id ledger_id, a.target_ledger_name name, 
           b.currency_code currency_code,
           b.sla_accounting_method_code SLAM, a.target_ledger_category_code type 
    from   gl_ledger_relationships a,
           gl_ledgers b
    where  a.primary_ledger_id = (select set_of_books_id
                                  from   ra_customer_trx_all
                                  where  customer_trx_id = ##$$TRXID$$##)
    and    a.primary_ledger_id = b.ledger_id',
   'LEDGER INFORMATION',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'AR SYSTEM PARAMETERS',
   'select *
    from   ar_system_parameters_all
    where  org_id  = (select org_id
                      from   ra_customer_trx_all
                      where  customer_trx_id = ##$$TRXID$$##)',
   'AR SYSTEM PARAMETERS',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'HZ_CUST_ACCOUNTS_ALL',
   'select *
    from   hz_cust_accounts_all
    where  cust_account_id  = (select bill_to_customer_id
                               from   ra_customer_trx_all
                               where  customer_trx_id = ##$$TRXID$$##)',
   'HZ_CUST_ACCOUNTS_ALL',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'HZ_CUST_ACCT_SITES_ALL',
   'SELECT   * 
    FROM     HZ_CUST_ACCT_SITES_ALL 
    WHERE    cust_account_id = (select bill_to_customer_id
                                from   ra_customer_trx_all
                                where  customer_trx_id = ##$$TRXID$$##)
    and      org_id in  ( select org_id
                          from   ra_customer_trx_all
                          where  customer_trx_id = ##$$TRXID$$##)
    ORDER BY org_id, cust_account_id, cust_acct_site_id',
   'HZ_CUST_ACCT_SITES_ALL',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'HZ_CUST_SITE_USES_ALL',
   'SELECT * 
    FROM   HZ_CUST_SITE_USES_ALL 
    WHERE  cust_acct_site_id IN (SELECT   cust_acct_site_id 
                                 FROM     HZ_CUST_ACCT_SITES_ALL 
                                 WHERE    cust_account_id = (select bill_to_customer_id
                                                             from   ra_customer_trx_all
                                                             where  customer_trx_id = ##$$TRXID$$##)
    and     org_id in  ( select org_id
                         from   ra_customer_trx_all
                         where  customer_trx_id = ##$$TRXID$$##)) 
    ORDER BY org_id, cust_acct_site_id, site_use_code',
   'HZ_CUST_SITE_USES_ALL',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'HZ_PARTY_SITES',
   'SELECT   * 
    FROM     HZ_PARTY_SITES
    WHERE    party_site_id IN  (SELECT party_site_id
                                FROM   HZ_CUST_ACCT_SITES_ALL
                                WHERE  cust_account_id = (select bill_to_customer_id
                                                          from   ra_customer_trx_all
                                                          where  customer_trx_id = ##$$TRXID$$##)) 
   ORDER BY party_id, party_site_id, location_id',
   'HZ_PARTY_SITES',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');

   add_signature(
   'HZ_LOCATIONS',
   'select location_id, address1, address2, address3, address4,
           city, postal_code, state, province, county, validated_flag           
    from   hz_locations
    where  location_id in (select a.location_id
                           from   hz_party_sites a,
                                  hz_cust_acct_sites_all b
                           where  a.party_site_id = b.party_site_id
                           and    b.cust_account_id = (select bill_to_customer_id
                                                       from   ra_customer_trx_all
                                                       where  customer_trx_id = ##$$TRXID$$##))
    order by location_id',
   'HZ_LOCATIONS',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'HZ_CUST_ACCOUNTS_ALL (BR)',
   'select *
    from   hz_cust_accounts_all
    where  cust_account_id  = (select drawee_id
                               from   ra_customer_trx_all
                               where  customer_trx_id = ##$$TRXID$$##)',
   'HZ_CUST_ACCOUNTS_ALL (BR)',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'HZ_CUST_ACCT_SITES_ALL (BR)',
   'SELECT   * 
    FROM     HZ_CUST_ACCT_SITES_ALL 
    WHERE    cust_account_id = (select drawee_id
                                from   ra_customer_trx_all
                                where  customer_trx_id = ##$$TRXID$$##)
    and      org_id in  ( select org_id
                          from   ra_customer_trx_all
                          where  customer_trx_id = ##$$TRXID$$##)
    ORDER BY org_id, cust_account_id, cust_acct_site_id',
   'HZ_CUST_ACCT_SITES_ALL (BR)',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'HZ_CUST_SITE_USES_ALL (BR)',
   'SELECT * 
    FROM   HZ_CUST_SITE_USES_ALL 
    WHERE  cust_acct_site_id IN (SELECT   cust_acct_site_id 
                                 FROM     HZ_CUST_ACCT_SITES_ALL 
                                 WHERE    cust_account_id = (select drawee_id
                                                             from   ra_customer_trx_all
                                                             where  customer_trx_id = ##$$TRXID$$##)
    and     org_id in  ( select org_id
                         from   ra_customer_trx_all
                         where  customer_trx_id = ##$$TRXID$$##)) 
    ORDER BY org_id, cust_acct_site_id, site_use_code',
   'HZ_CUST_SITE_USES_ALL (BR)',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'HZ_PARTY_SITES (BR)',
   'SELECT   * 
    FROM     HZ_PARTY_SITES
    WHERE    party_site_id IN  (SELECT party_site_id
                                FROM   HZ_CUST_ACCT_SITES_ALL
                                WHERE  cust_account_id = (select drawee_id
                                                          from   ra_customer_trx_all
                                                          where  customer_trx_id = ##$$TRXID$$##)) 
   ORDER BY party_id, party_site_id, location_id',
   'HZ_PARTY_SITES (BR)',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');

   add_signature(
   'HZ_LOCATIONS (BR)',
   'select location_id, address1, address2, address3, address4,
           city, postal_code, state, province, county, validated_flag           
    from   hz_locations
    where  location_id in (select a.location_id
                           from   hz_party_sites a,
                                  hz_cust_acct_sites_all b
                           where  a.party_site_id = b.party_site_id
                           and    b.cust_account_id = (select drawee_id
                                                       from   ra_customer_trx_all
                                                       where  customer_trx_id = ##$$TRXID$$##))
    order by location_id',
   'HZ_LOCATIONS (BR)',
   'NRS',
   null ,
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
  
  add_signature(
   'RA_CUSTOMER_TRX_ALL',
   'SELECT * 
    from RA_CUSTOMER_TRX_ALL
    where customer_trx_id = ##$$TRXID$$##',
   'RA_CUSTOMER_TRX_ALL',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
    
  add_signature(
   'RA_CUST_TRX_TYPES_ALL',
   'SELECT * 
    from RA_CUST_TRX_TYPES_ALL a,
         RA_CUSTOMER_TRX_ALL b
    where a.cust_trx_type_id = b.cust_trx_type_id
    and   b.customer_trx_id = ##$$TRXID$$##
    and   b.org_id = a.org_id',
   'RA_CUST_TRX_TYPES_ALL',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
    'RS');
    
   add_signature(
   'RA_BATCH_SOURCES_ALL',
   'SELECT * 
    from RA_BATCH_SOURCES_ALL a,
         RA_CUSTOMER_TRX_ALL b
    where a.batch_source_id = b.batch_source_id
    and   b.customer_trx_id = ##$$TRXID$$##
    and   b.org_id = a.org_id',
   'RA_BATCH_SOURCES_ALL',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
    'RS');

  add_signature(
   'RA_CUSTOMER_TRX_LINES_ALL',
   'SELECT * 
    from RA_CUSTOMER_TRX_LINES_ALL
    where customer_trx_id = ##$$TRXID$$##
    order by customer_trx_line_id',
   'RA_CUSTOMER_TRX_LINES_ALL',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
    'RS');
    
  add_signature(
   'MTL_SYSTEM_ITEMS_B',
   'SELECT * 
    FROM   MTL_SYSTEM_ITEMS_B  msi
    WHERE  (msi.organization_id, msi.inventory_item_id ) IN (SELECT nvl(ctl.warehouse_id, sp.master_organization_id ), 
                                                                    ctl.inventory_item_id
                                                             FROM   RA_CUSTOMER_TRX_LINES_ALL ctl,
                                                                    OE_SYSTEM_PARAMETERS_ALL sp
                                                             WHERE  ctl.customer_trx_id = ##$$TRXID$$##
                                                             AND    ctl.org_id = sp.org_id
                                                             AND    ctl.line_type = ''LINE'')',
   'MTL_SYSTEM_ITEMS_B',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
    'RS');
    
  add_signature(
   'RA_CUST_TRX_LINE_SALESREPS_ALL',
   'SELECT * 
    from RA_CUST_TRX_LINE_SALESREPS_ALL
    where customer_trx_id = ##$$TRXID$$##
    order by customer_trx_line_id',
   'RA_CUST_TRX_LINE_SALESREPS_ALL',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
  add_signature(
   'JTF_RS_SALESREPS',
   'select *
    from   jtf_rs_salesreps
    where  salesrep_id in (select distinct salesrep_id
                           from   RA_CUST_TRX_LINE_SALESREPS_ALL 
                           WHERE  customer_trx_id = ##$$TRXID$$##)
    order by salesrep_id',
   'JTF_RS_SALESREPS',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
    
  add_signature(
   'ZX_LINES',
   'SELECT   zl.* 
    FROM     ZX_LINES zl,
             RA_CUSTOMER_TRX_LINES_ALL lines 
    WHERE    zl.application_id = 222 
    AND      zl.entity_code    = ''TRANSACTIONS''
    AND      zl.event_class_code in (''INVOICE'',''DEBIT_MEMO'',''CREDIT_MEMO'') 
    AND      zl.trx_id      = lines.customer_trx_id 
    AND      zl.tax_line_id = lines.tax_line_id 
    AND      lines.customer_trx_id = ##$$TRXID$$##',
   'ZX_LINES',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'ZX_LINES_DET_FACTORS',
   'SELECT   zld.* 
    FROM     ZX_LINES_DET_FACTORS zld,
             RA_CUSTOMER_TRX_LINES_ALL lines 
    WHERE    zld.application_id = 222 
    AND      zld.entity_code    = ''TRANSACTIONS''
    AND      zld.event_class_code in (''INVOICE'',''DEBIT_MEMO'',''CREDIT_MEMO'') 
    AND      zld.trx_id      = lines.customer_trx_id 
    AND      zld.trx_line_id = lines.customer_trx_line_id 
    AND      lines.customer_trx_id = ##$$TRXID$$##',
   'ZX_LINES_DET_FACTORS',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');    
    
  add_signature(
   'RA_CUST_TRX_LINE_GL_DIST_ALL',
   'SELECT * 
    from RA_CUST_TRX_LINE_GL_DIST_ALL
    where customer_trx_id = ##$$TRXID$$##
    order by cust_trx_line_gl_dist_id',
   'RA_CUST_TRX_LINE_GL_DIST_ALL',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');

  add_signature(
   'AR_TRANSACTION_HISTORY_ALL',
   'SELECT * 
    from   AR_TRANSACTION_HISTORY_ALL
    where  customer_trx_id = ##$$TRXID$$##
    order by transaction_history_id',
   'AR_TRANSACTION_HISTORY_ALL',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'AR_DISTRIBUTIONS_ALL (TH)',
   'SELECT * 
    from   AR_DISTRIBUTIONS_ALL
    where  source_id  in (select transaction_history_id
                          from   ar_transaction_history_all
                          where  customer_trx_id = ##$$TRXID$$##)
    and    source_table = ''TH''
    order by line_id',
   'AR_DISTRIBUTIONS_ALL (TH)',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');

  add_signature(
   'AR ACCOUNTS',
   'SELECT code_combination_id, concatenated_segments account, 
           gl_control_account control_account, 
           enabled_flag enabled,
           detail_posting_allowed detail_posting, alternate_code_combination_id, 
           start_date_active start_date, 
           end_date_active end_date
    from   gl_code_combinations_kfv
    where  code_combination_id in (select distinct code_combination_id
                                   from   ra_cust_trx_line_gl_dist_all
                                   where  customer_trx_id = ##$$TRXID$$##
                                   and    account_set_flag = ''N'')',
   'AR ACCOUNTS',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'AR ACCOUNTS (BR)',
   'SELECT code_combination_id, concatenated_segments account, 
           gl_control_account control_account, 
           enabled_flag enabled,
           detail_posting_allowed detail_posting, alternate_code_combination_id, 
           start_date_active start_date, 
           end_date_active end_date
    from   gl_code_combinations_kfv
    where  code_combination_id in (select distinct code_combination_id
                               from   ar_distributions_all
                               where  source_id  in (select transaction_history_id
                                                     from   ar_transaction_history_all
                                                     where  customer_trx_id = ##$$TRXID$$##)
                               and    source_table = ''TH'')',
   'AR ACCOUNTS (BR)',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
    
  add_signature(
   'RA_CUST_TRX_LINE_GL_DIST_ALL Totals',
   'SELECT customer_trx_id,
           account_class,
           sum(amount),
           sum(acctd_amount),
           sum(percent)
    from   RA_CUST_TRX_LINE_GL_DIST_ALL
    where customer_trx_id = ##$$TRXID$$##
    and   account_set_flag = ''N''
    GROUP BY customer_trx_id, account_class',
   'RA_CUST_TRX_LINE_GL_DIST_ALL Totals',
   'NRS',
   'No rows selected',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'APPLICATIONS ON TRANSACTION',
   'SELECT *
    FROM   AR_RECEIVABLE_APPLICATIONS_ALL
    where  applied_customer_trx_id = ##$$TRXID$$##',
   'APPLICATIONS ON TRANSACTION',
   'NRS',
   'No receipts or credit memos have been applied to this transaction',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'APPLICATIONS ON TRANSACTION Totals',
   'SELECT application_type,
           sum(amount_applied) sum_amount_applied,
           sum(amount_applied_from) sum_amount_applied_from,
           sum(acctd_amount_applied_from) sum_acctd_amount_applied_from, 
           sum(acctd_amount_applied_to) sum_acctd_amount_applied_to,
           sum(line_applied) sum_line_applied,
           sum(tax_applied) sum_tax_applied,
           sum(freight_applied) sum_freight_applied,
           sum(receivables_charges_applied) sum_charges_applied,
           sum(earned_discount_taken) sum_earned_disc,
           sum(unearned_discount_taken) sum_unearned_disc,
           sum(acctd_earned_discount_taken) sum_acctd_earned_disc,
           sum(acctd_unearned_discount_taken) sum_acctd_unearned_disc
    FROM   AR_RECEIVABLE_APPLICATIONS_ALL 
    WHERE  applied_customer_trx_id = ##$$TRXID$$##
    GROUP  BY application_type',
   'APPLICATIONS ON TRANSACTION Totals',
   'NRS',
   'No receipts or credit memos have been applied to this transaction',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');


    add_signature(
   'TRANSACTION APPLICATIONS',
   'SELECT *
    FROM   AR_RECEIVABLE_APPLICATIONS_ALL
    where  customer_trx_id = ##$$TRXID$$##',
   'TRANSACTION APPLICATIONS',
   'NRS',
   null ,
   null,
   'No rows selected',
   'ALWAYS',
   'I',
   'RS');    
   
    add_signature(
   'APPLICATION DISTRIBUTIONS',
   'SELECT *
    FROM   AR_DISTRIBUTIONS_ALL 
    WHERE  source_id in (select receivable_application_id
                         from   ar_receivable_applications_all
                         where  customer_trx_id = ##$$TRXID$$##
                         UNION
                         select receivable_application_id
                         from   ar_receivable_applications_all
                         where  applied_customer_trx_id = ##$$TRXID$$##)
    AND    source_table = ''RA''
    order by line_id',
   'APPLICATION DISTRIBUTIONS',
   'NRS',
   'No receipts or credit memos have been applied to this transaction',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');   
   
    add_signature(
   'AR_REVENUE_ADJUSTMENTS_ALL',
   'SELECT a.*
    FROM   ar_revenue_adjustments_all a,
           ra_customer_trx_all b
    WHERE  a.customer_trx_id = ##$$TRXID$$##
    AND    a.customer_trx_id = b.customer_trx_id
    AND    a.org_id = b.org_id
    order by revenue_adjustment_id',
   'AR_REVENUE_ADJUSTMENTS_ALL',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');   
   
   add_signature(
   'AR_ACTIVITY_DETAILS',
   'SELECT a.*
    FROM   ar_activity_details a,
           ra_customer_trx_lines_all b
    WHERE  b.customer_trx_id = ##$$TRXID$$##
    AND    a.customer_trx_line_id = b.customer_trx_line_id
    order by a.customer_trx_line_id',
   'AR_ACTIVITY_DETAILS',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'AR_LINE_CONTS_ALL',
   'SELECT a.*
    FROM   ar_line_conts_all a,
           ra_customer_trx_lines_all b
    WHERE  b.customer_trx_id = ##$$TRXID$$##
    AND    a.customer_trx_line_id = b.customer_trx_line_id
    order by a.customer_trx_line_id',
   'AR_LINE_CONTS_ALL',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'AR_ADJUSTMENTS_ALL',
   'SELECT *
    FROM   ar_adjustments_all
    WHERE  customer_trx_id = ##$$TRXID$$##
    order by adjustment_id',
   'AR_ADJUSTMENTS_ALL',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS'); 
   
    add_signature(
   'ADJUSTMENT Totals',
   'SELECT adjustment_type,
           sum(amount) sum_amount,
           sum(line_adjusted) sum_line_adjusted,
           sum(freight_adjusted) sum_freight_adjusted,
           sum(tax_adjusted) sum_tax_adjusted,
           sum(receivables_charges_adjusted) sum_charges_adjusted,
           sum(acctd_amount) sum_acctd_amount
    FROM   ar_adjustments_all
    WHERE  customer_trx_id = ##$$TRXID$$##
    AND    postable = ''Y''
    AND    status = ''A''
    GROUP BY adjustment_type',
   'ADJUSTMENT Totals',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'ADJUSTMENT DISTRIBUTIONS',
   'SELECT *
    FROM   ar_distributions_all
    WHERE  source_id in (select adjustment_id
                         from   ar_adjustments_all
                         where  customer_trx_id = ##$$TRXID$$##)
    and    source_table = ''ADJ''
    order by line_id',
   'ADJUSTMENT DISTRIBUTIONS',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS'); 
   
   add_signature(
   'AR_PAYMENT_SCHEDULES_ALL',
   'SELECT *
    FROM   ar_payment_schedules_all
    WHERE  customer_trx_id = ##$$TRXID$$##
    order by payment_schedule_id',
   'AR_PAYMENT_SCHEDULES_ALL',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS'); 
   
   add_signature(
   'AR_DISPUTE_HISTORY',
   'select *
    from   ar_dispute_history
    where  payment_schedule_id in (select payment_schedule_id 
                                   from   ar_payment_schedules_all
                                   where  customer_trx_id = ##$$TRXID$$##)',
   'AR_DISPUTE_HISTORY',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS'); 
   
   add_signature(
   'RA_RULES',
   'SELECT A.* 
    FROM   RA_RULES A,
           RA_CUSTOMER_TRX_ALL B 
    WHERE  A.rule_id = B.invoicing_rule_id 
    AND    B.invoicing_rule_id is NOT NULL 
    AND    B.customer_trx_id = ##$$TRXID$$##',
   'RA_RULES',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS'); 
   
  add_signature(
   'ACCOUNTING RULES',
   'SELECT A.*
    FROM   RA_RULES A,
           RA_CUSTOMER_TRX_LINES_ALL B 
    WHERE  A.rule_id = B.accounting_rule_id 
    AND    B.accounting_rule_id is NOT NULL 
    AND    B.customer_trx_id = ##$$TRXID$$##',
   'ACCOUNTING RULES',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS'); 

   add_signature(
   'ACCOUNTING RULE PERIODS',
   'SELECT A.* 
    FROM   RA_RULE_SCHEDULES A,
           RA_CUSTOMER_TRX_LINES_ALL B 
    WHERE  A.rule_id = B.accounting_rule_id 
    AND    B.accounting_rule_id is NOT NULL 
    AND    B.customer_trx_id = ##$$TRXID$$##',
   'ACCOUNTING RULE PERIODS',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
   null,
   null,
   'ALWAYS',
   'I',
   'RS'); 
   
   add_signature(
   'XLA_TRANSACTION_ENTITIES',
   'SELECT *
    FROM   xla.xla_transaction_entities
    WHERE  application_id = 222
    AND    entity_code in (''TRANSACTIONS'',''MANUAL'')
    and    nvl(source_id_int_1,-99) = ##$$TRXID$$##
    order by entity_id',
   'XLA_TRANSACTION_ENTITIES',
   'NRS',
   'No rows selected',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'XLA_EVENTS',
   'SELECT * 
    FROM   XLA_EVENTS 
    WHERE  application_id = 222  
    and    entity_id in
           (SELECT entity_id
            FROM   xla.xla_transaction_entities xte
            WHERE  xte.application_id = 222
            AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
            and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order  by event_id',
   'XLA_EVENTS',
   'NRS',
   'No rows selected',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'XLA_AE_HEADERS',
   'SELECT * 
    FROM   XLA_AE_HEADERS
    WHERE application_id = 222
    and    entity_id in (SELECT entity_id
                         FROM   xla.xla_transaction_entities xte
                         WHERE  xte.application_id = 222
                         AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
                         and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order  by ae_header_id',
   'XLA_AE_HEADERS',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');

   add_signature(
   'XLA_AE_LINES',
   'SELECT * 
    FROM   XLA_AE_LINES
    WHERE  ae_header_id in (select ae_header_id
                            from   xla_ae_headers
                            where  application_id = 222
                            and    entity_id in (SELECT entity_id
                                                 FROM   xla.xla_transaction_entities xte
                                                 WHERE  xte.application_id = 222
                                                 AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
                                                 and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
                            )
    order by ae_header_id, ae_line_num',
    'XLA_AE_LINES',
    'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS'); 
   
  add_signature(
   'SLA ACCOUNTS',
   'SELECT code_combination_id, concatenated_segments account, 
           gl_control_account control_account, 
           enabled_flag enabled,
           detail_posting_allowed detail_posting, alternate_code_combination_id, 
           start_date_active start_date, 
           end_date_active end_date
    from   gl_code_combinations_kfv
    where  code_combination_id in (select distinct code_combination_id
                                   from   xla_ae_lines
                                   WHERE  ae_header_id in (select ae_header_id
                                                           from   xla_ae_headers
                                                           where  application_id = 222
                                                           and    entity_id in (SELECT entity_id
                                                                                FROM   xla.xla_transaction_entities xte
                                                                                WHERE  xte.application_id = 222
                                                                                AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
                                                                                and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
                                                            )
                                    )',
   'SLA ACCOUNTS',
   'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'XLA_DISTRIBUTION_LINKS',
   'SELECT * 
    FROM   XLA_DISTRIBUTION_LINKS
    WHERE  ae_header_id in (select ae_header_id
                            from   xla_ae_headers
                            where  application_id = 222
                            and    entity_id in (SELECT entity_id
                                                 FROM   xla.xla_transaction_entities xte
                                                 WHERE  xte.application_id = 222
                                                 AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
                                                 and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
                            )
    order by ae_header_id, ae_line_num',
    'XLA_DISTRIBUTION_LINKS',
    'NRS',
   'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS'); 
   
   add_signature(
   'XLA_ACCOUNTING_ERRORS',
   'select *
    from   xla_accounting_errors
    where  event_id  in
                    (SELECT event_id
                     FROM   xla_events xe,
                            xla.xla_transaction_entities xte
                     WHERE  xte.application_id = 222
                     AND    xe.entity_id = xte.entity_id
                     AND    xe.process_status_code = ''I''
                     AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
                     AND    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order by event_id',
    'XLA_ACCOUNTING_ERRORS',
    'NRS',
    'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
    'ALWAYS',
    'I',
    'RS');
    
   add_signature(
   'XLA_TRANSACTION_ENTITIES (BR)',
   'SELECT *
    FROM   xla.xla_transaction_entities
    WHERE  application_id = 222
    AND    entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
    and    nvl(source_id_int_1,-99) = ##$$TRXID$$##
    order by entity_id',
   'XLA_TRANSACTION_ENTITIES (BR)',
   'NRS',
   null ,
   null,
   'No rows selected',
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'XLA_EVENTS (BR)',
   'SELECT * 
    FROM   XLA_EVENTS 
    WHERE  application_id = 222  
    and    entity_id in
           (SELECT entity_id
            FROM   xla.xla_transaction_entities xte
            WHERE  xte.application_id = 222
            AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
            and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order  by event_id',
   'XLA_EVENTS (BR)',
   'NRS',
   null ,
   null,
   'No rows selected',
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'XLA_AE_HEADERS (BR)',
   'SELECT * 
    FROM   XLA_AE_HEADERS
    WHERE application_id = 222
    and    entity_id in (SELECT entity_id
                         FROM   xla.xla_transaction_entities xte
                         WHERE  xte.application_id = 222
                         AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
                         and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order  by ae_header_id',
   'XLA_AE_HEADERS (BR)',
   'NRS',
   null ,
   null,
   'No rows selected',
   'ALWAYS',
   'I',
   'RS');

   add_signature(
   'XLA_AE_LINES (BR)',
   'SELECT * 
    FROM   XLA_AE_LINES
    WHERE  ae_header_id in (select ae_header_id
                            from   xla_ae_headers
                            where  application_id = 222
                            and    entity_id in (SELECT entity_id
                                                 FROM   xla.xla_transaction_entities xte
                                                 WHERE  xte.application_id = 222
                                                 AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
                                                 and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
                            )
    order by ae_header_id, ae_line_num',
    'XLA_AE_LINES (BR)',
    'NRS',
    null ,
    null,
    'No rows selected',
   'ALWAYS',
   'I',
   'RS'); 
   
  add_signature(
   'SLA ACCOUNTS (BR)',
   'SELECT code_combination_id, concatenated_segments account, 
           gl_control_account control_account, 
           enabled_flag enabled,
           detail_posting_allowed detail_posting, alternate_code_combination_id, 
           start_date_active start_date, 
           end_date_active end_date
    from   gl_code_combinations_kfv
    where  code_combination_id in (select distinct code_combination_id
                                   from   xla_ae_lines
                                   WHERE  ae_header_id in (select ae_header_id
                                                           from   xla_ae_headers
                                                           where  application_id = 222
                                                           and    entity_id in (SELECT entity_id
                                                                                FROM   xla.xla_transaction_entities xte
                                                                                WHERE  xte.application_id = 222
                                                                                AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
                                                                                and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
                                                            )
                                    )',
   'SLA ACCOUNTS (BR)',
   'NRS',
   null,
   null,
   'No rows selected',
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'XLA_DISTRIBUTION_LINKS (BR)',
   'SELECT * 
    FROM   XLA_DISTRIBUTION_LINKS
    WHERE  ae_header_id in (select ae_header_id
                            from   xla_ae_headers
                            where  application_id = 222
                            and    entity_id in (SELECT entity_id
                                                 FROM   xla.xla_transaction_entities xte
                                                 WHERE  xte.application_id = 222
                                                 AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
                                                 and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
                            )
    order by ae_header_id, ae_line_num',
    'XLA_DISTRIBUTION_LINKS (BR)',
    'NRS',
    null ,
    null,
    'No rows selected',
   'ALWAYS',
   'I',
   'RS'); 
   
   add_signature(
   'XLA_ACCOUNTING_ERRORS (BR)',
   'select *
    from   xla_accounting_errors
    where  event_id  in
                    (SELECT event_id
                     FROM   xla_events xe,
                            xla.xla_transaction_entities xte
                     WHERE  xte.application_id = 222
                     AND    xe.entity_id = xte.entity_id
                     AND    xe.process_status_code = ''I''
                     AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
                     AND    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order by event_id',
    'XLA_ACCOUNTING_ERRORS (BR)',
    'NRS',
    null ,
    null,
    'No accounting errors',
    'ALWAYS',
    'I',
    'RS');  
   
    add_signature(
   'GL_JE_HEADERS',
   'SELECT DISTINCT gjh.*
    FROM   gl_je_headers gjh,
           gl_import_references gir,
           xla_ae_lines xal,
           xla_ae_headers xah
    WHERE  gjh.je_header_id = gir.je_header_id
    AND    gir.gl_sl_link_id = xal.gl_sl_link_id
    AND    gir.gl_sl_link_table = xal.gl_sl_link_table
    AND    xal.application_id = xah.application_id
    AND    xal.ae_header_id = xah.ae_header_id
    AND    xah.application_id = 222   
    AND    xah.entity_id IN  (SELECT xte.entity_id
                              FROM   xla.xla_transaction_entities xte
                              WHERE  xte.application_id = 222
                              AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
                              and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order by gjh.je_header_id',
    'GL_JE_HEADERS',
    'NRS',
    'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');  
    
    add_signature(
   'GL_JE_LINES',
   'SELECT DISTINCT gjl.*
    FROM   gl_je_lines gjl,
           gl_import_references gir,
           xla_ae_lines xal,
           xla_ae_headers xah
    WHERE  gjl.je_header_id = gir.je_header_id
    AND    gjl.je_line_num = gir.je_line_num
    AND    gir.gl_sl_link_id = xal.gl_sl_link_id
    AND    gir.gl_sl_link_table = xal.gl_sl_link_table
    AND    xal.application_id = xah.application_id
    AND    xal.ae_header_id = xah.ae_header_id
    AND    xah.application_id = 222   
    AND    xah.entity_id IN  (SELECT xte.entity_id
                              FROM   xla.xla_transaction_entities xte
                              WHERE  xte.application_id = 222
                              AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
                              and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order by gjl.je_header_id, gjl.je_line_num',
    'GL_JE_LINES',
    'NRS',
    'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');   
    
    add_signature(
   'GL_IMPORT_REFERENCES',
   'SELECT DISTINCT gir.*
    FROM   gl_import_references gir,
           xla_ae_lines xal,
           xla_ae_headers xah
    WHERE  gir.gl_sl_link_id = xal.gl_sl_link_id
    AND    gir.gl_sl_link_table = xal.gl_sl_link_table
    AND    xal.application_id = xah.application_id
    AND    xal.ae_header_id = xah.ae_header_id
    AND    xah.application_id = 222   
    AND    xah.entity_id IN  (SELECT xte.entity_id
                              FROM   xla.xla_transaction_entities xte
                              WHERE  xte.application_id = 222
                              AND    xte.entity_code in (''TRANSACTIONS'',''MANUAL'')
                              and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order by gir.je_header_id, gir.je_line_num',
    'GL_IMPORT_REFERENCES',
    'NRS',
    'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS'); 
   
    add_signature(
   'GL PERIODS_STATUSES (GL)',
   'SELECT distinct gps.* 
    FROM   GL_PERIOD_STATUSES gps,
           AR_SYSTEM_PARAMETERS_ALL sys,
    (SELECT   distinct gl_date
     FROM     ra_cust_trx_line_gl_dist_all
     WHERE    customer_trx_id = ##$$TRXID$$##) atg_date 
     WHERE    period_year in (select period_year
                              from   gl_period_statuses gps2
                              where  atg_date.gl_date between gps2.start_date and gps2.end_date)
     AND      NVL(sys.org_id, -99) = (select org_id
                                      from   ra_customer_trx_all
                                      where  customer_trx_id = ##$$TRXID$$##)
     AND      gps.set_of_books_id = sys.set_of_books_id 
     AND      gps.application_id = 101
    ORDER BY gps.period_year, gps.period_num',
    'GL_PERIODS_STATUSES (GL)',
    'NRS',
    'No rows selected.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS'); 
   
    add_signature(
   'GL_JE_HEADERS (BR)',
   'SELECT DISTINCT gjh.*
    FROM   gl_je_headers gjh,
           gl_import_references gir,
           xla_ae_lines xal,
           xla_ae_headers xah
    WHERE  gjh.je_header_id = gir.je_header_id
    AND    gir.gl_sl_link_id = xal.gl_sl_link_id
    AND    gir.gl_sl_link_table = xal.gl_sl_link_table
    AND    xal.application_id = xah.application_id
    AND    xal.ae_header_id = xah.ae_header_id
    AND    xah.application_id = 222   
    AND    xah.entity_id IN  (SELECT xte.entity_id
                              FROM   xla.xla_transaction_entities xte
                              WHERE  xte.application_id = 222
                              AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
                              and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order by gjh.je_header_id',
    'GL_JE_HEADERS (BR)',
    'NRS',
    null ,
    null,
    'No rows selected',
   'ALWAYS',
   'I',
   'RS');  
    
    add_signature(
   'GL_JE_LINES (BR)',
   'SELECT DISTINCT gjl.*
    FROM   gl_je_lines gjl,
           gl_import_references gir,
           xla_ae_lines xal,
           xla_ae_headers xah
    WHERE  gjl.je_header_id = gir.je_header_id
    AND    gjl.je_line_num = gir.je_line_num
    AND    gir.gl_sl_link_id = xal.gl_sl_link_id
    AND    gir.gl_sl_link_table = xal.gl_sl_link_table
    AND    xal.application_id = xah.application_id
    AND    xal.ae_header_id = xah.ae_header_id
    AND    xah.application_id = 222   
    AND    xah.entity_id IN  (SELECT xte.entity_id
                              FROM   xla.xla_transaction_entities xte
                              WHERE  xte.application_id = 222
                              AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
                              and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order by gjl.je_header_id, gjl.je_line_num',
    'GL_JE_LINES (BR)',
    'NRS',
    null ,
    null,
    'No rows selected',
   'ALWAYS',
   'I',
   'RS');   
    
    add_signature(
   'GL_IMPORT_REFERENCES (BR)',
   'SELECT DISTINCT gir.*
    FROM   gl_import_references gir,
           xla_ae_lines xal,
           xla_ae_headers xah
    WHERE  gir.gl_sl_link_id = xal.gl_sl_link_id
    AND    gir.gl_sl_link_table = xal.gl_sl_link_table
    AND    xal.application_id = xah.application_id
    AND    xal.ae_header_id = xah.ae_header_id
    AND    xah.application_id = 222   
    AND    xah.entity_id IN  (SELECT xte.entity_id
                              FROM   xla.xla_transaction_entities xte
                              WHERE  xte.application_id = 222
                              AND    xte.entity_code in (''BILLS_RECEIVABLE'',''MANUAL'')
                              and    nvl(source_id_int_1,-99) = ##$$TRXID$$##)
    order by gir.je_header_id, gir.je_line_num',
    'GL_IMPORT_REFERENCES (BR)',
    'NRS',
    null ,
    null,
    'No rows selected',
   'ALWAYS',
   'I',
   'RS'); 
   
    add_signature(
   'GL PERIODS_STATUSES (AR)',
   'SELECT distinct gps.* 
    FROM   GL_PERIOD_STATUSES gps,
           AR_SYSTEM_PARAMETERS_ALL sys,
    (SELECT   distinct gl_date
     FROM     ra_cust_trx_line_gl_dist_all
     WHERE    customer_trx_id = ##$$TRXID$$##) atg_date 
     WHERE    period_year in (select period_year
                              from   gl_period_statuses gps2
                              where  atg_date.gl_date between gps2.start_date and gps2.end_date)
     AND      NVL(sys.org_id, -99) = (select org_id
                                      from   ra_customer_trx_all
                                      where  customer_trx_id = ##$$TRXID$$##)
     AND      gps.set_of_books_id = sys.set_of_books_id 
     AND      gps.application_id = 222
    ORDER BY gps.period_year, gps.period_num',
    'GL_PERIODS_STATUSES (AR)',
    'NRS',
    'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS'); 

    add_signature(
   'GL PERIODS_STATUSES (BR)',
   'SELECT distinct gps.* 
    FROM   GL_PERIOD_STATUSES gps,
           AR_SYSTEM_PARAMETERS_ALL sys,
    (SELECT   distinct gl_date
     FROM     ar_transaction_history_all
     WHERE    customer_trx_id = ##$$TRXID$$##
     AND      postable_flag = ''Y'') atg_date 
     WHERE    period_year in (select period_year
                              from   gl_period_statuses gps2
                              where  atg_date.gl_date between gps2.start_date and gps2.end_date)
     AND      NVL(sys.org_id, -99) = (select org_id
                                      from   ra_customer_trx_all
                                      where  customer_trx_id = ##$$TRXID$$##)
     AND      gps.set_of_books_id = sys.set_of_books_id 
     AND      gps.application_id = 222
    ORDER BY gps.period_year, gps.period_num',
    'GL_PERIODS_STATUSES (BR)',
    'NRS',
    null ,
    null,
    'No rows selected',
   'ALWAYS',
   'I',
   'RS'); 
    
    add_signature(
   'SLAM for Primary Ledger',
   'SELECT accounting_method_code SLAM_code, amb_context_code,
    substr(rpad(ACCOUNTING_METHOD_TYPE_CODE,8,'' ''),1,8) SLAM_type,
    product_rule_code AAD_code, 
    product_rule_name AAD_name,
    substr(rpad(product_rule_type_code,8,'' ''),1,8) AAD_type,
    to_char(last_update_date, ''YYYY-MON-DD HH24:MI:SS'')  last_update_date,         
    to_char(creation_date, ''YYYY-MON-DD HH24:MI:SS'')  creation_date ,
    to_char(start_date_active, ''YYYY-MON-DD'')  start_date, 
    to_char(end_date_active,''YYYY-MON-DD'') end_date,
    application_id app_id,
    last_updated_by,
    created_by
    FROM    xla_acctg_method_rules_fvl
    where   application_id = 222
    and    accounting_method_code IN 
          (select sla_accounting_method_code 
           from   gl_ledgers 
           where  ledger_id = (select set_of_books_id
                               from   ra_customer_trx_all
                               where  customer_trx_id = ##$$TRXID$$##)
          )',
    'SLAM for Primary Ledger',
    'NRS',
    'No rows selected.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'AAD for Primary Ledger',
   'select
    PRODUCT_RULE_CODE, 
    name , 
    to_char(creation_date, ''DD-MON-YYYY HH24:MI:SS'') creation_date ,
    to_char(last_update_date, ''DD-MON-YYYY HH24:MI:SS'') last_update,
        decode(COMPILE_STATUS_CODE,''Y'',''Compiled'',
                              ''N'',''Not Compiled'',
                              ''I'',''Invalid'',
                              ''R'',''Validating'',
                              ''Invalid - ''||COMPILE_STATUS_CODE) STATUS_CODE,
    ''XLA_00222_AAD_''||product_rule_type_code||''_00000''||product_rule_hash_id||''_PKG'' AAD_Package,    
    PRODUCT_RULE_HASH_ID,
    enabled_flag
    PRODUCT_RULE_TYPE_CODE,
    created_by,
    last_updated_by
    from   xla_product_rules_fvl 
    where  application_id = 222
    and    (PRODUCT_RULE_CODE, amb_context_code) in 
                  (SELECT PRODUCT_RULE_CODE, amb_context_code
                   FROM xla_acctg_method_rules_fvl
                   WHERE upper(application_name)=''RECEIVABLES''
                  and   amb_context_code = ''DEFAULT''
                  and   accounting_method_code IN 
                   (select sla_accounting_method_code 
                    from gl_ledgers 
                    where ledger_id = (select set_of_books_id
                                       from   ra_customer_trx_all
                                       where  customer_trx_id = ##$$TRXID$$##)
          ))',
    'AAD for Primary Ledger',
    'NRS',
    'No rows selected.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'AAD Versions',
   'SELECT a.filename, b.version,
           to_char(b.creation_date,''DD-MON-YYYY HH24:MI:SS'') applied_date
    FROM   ad_files a,
           ad_file_versions b
    WHERE  a.file_id = b.file_id
    AND    a.subdir = ''patch/115/import/US''
    AND    a.filename = ''ARXLAAAD.ldt''
    ORDER BY b.version DESC',
    'AAD Versions',
    'NRS',
    'No rows selected.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');

    add_signature(
   'MFAR Profile',
   'SELECT decode(FND_PROFILE.value(''AR_MFAR_ACTIVATED'')
      ,''Y'',''YES'',''N'',''NO'',''NULL'') MFAR_Extract_Profile
    from dual',
    'MFAR Profile',
    'NRS',
    'No rows selected.  This does not necessarily indicate an error/issue exists.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'GL TRANSFER PKG VERSION',
   'select name, text, type
   from   dba_source
   where  name = ''XLA_TRANSFER_PKG''
   and    line = 2',
   'GL TRANSFER PKG VERSION',
   'NRS',
   'No rows selected.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
    'RDBMS Version',
    'SELECT banner rdbms_version
    from  v$version',
    'RDBMS Version',
    'NRS',
   'No rows selected.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
    add_signature(
   'AR File Versions',
   'SELECT name, text, type
    FROM   dba_source
    where  ((name like ''AR%'')
             or (name like ''RA%''))
    and    line = 2
    and    type in (''PACKAGE'', ''PACKAGE BODY'')',
    'AR File Versions',
    'NRS',
   'No rows selected.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'AR Forms and Reports Versions',
   'select b.filename, a.version, a.creation_date, b.subdir
    from   ad_file_versions a, ad_files b
    where  b.file_id = a.file_id 
    and    b.app_short_name = ''AR''
    and    b.filename like ''%.rdf''
    and    a.creation_date = (select max(c.creation_date) 
                              from   ad_file_versions c 
                              where   c.file_id = a.file_id)
    union
    select b.filename, a.version, a.creation_date, b.subdir
    from   ad_file_versions a, ad_files b
    where  b.file_id = a.file_id
    and    b.app_short_name = ''AR''
    and    b.filename like ''%.pll''
    and    a.creation_date = (select max(c.creation_date) 
                              from   ad_file_versions c 
                              where  c.file_id = a.file_id)
    union
    select b.filename, a.version, a.creation_date, b.subdir
    from   ad_file_versions a, ad_files b
    where  b.file_id = a.file_id
    and    b.app_short_name = ''AR''
    and    b.filename like ''%.fmb''
    and    a.creation_date = (select max(c.creation_date) 
                              from   ad_file_versions c 
                              where   c.file_id = a.file_id)
    order by 1',
   'AR Forms and Reports Versions',
   'NRS',
   'No rows selected.',
    null,
    null,
   'ALWAYS',
   'I',
   'RS');
   
   add_signature(
   'EBTAX File Versions',
   'SELECT name, text, type
    FROM   dba_source
    where  name like ''ZX%''
    and    line = 2
    and    type in (''PACKAGE'', ''PACKAGE BODY'')',
    'EBTAX File Versions',
    'NRS',
    'No rows selected.',
    null,
    null,
    'ALWAYS',
    'I',
    'RS');
    
    add_signature(
   'MISSING EVENT_ID (AR_00046)',
   'select DISTINCT ct.customer_trx_id customer_trx_id, ct.trx_number trx_number
    from   ra_cust_trx_line_gl_dist_all gld ,
           ra_customer_trx_all ct
    WHERE  ct.customer_trx_id = gld.customer_trx_id
    and    gld.posting_control_id = -3
    AND    gld.customer_trx_id = ##$$TRXID$$##
    AND    gld.account_set_flag = ''N''
    and    gld.event_id is null',
   'MISSING EVENT_ID (AR_00046)',
   'RS',
   'You have missing events in RA_CUST_TRX_LINE_GL_DIST_ALL.' ,
   'Please do the following to fix the data corruption:
        <ol><li>Review [798360.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
    add_signature(
   'MISSING EVENT_ID FOR CREDIT MEMO APPLICATION ROWS (AR_00045)',
   'SELECT ra.receivable_application_id, 
           ra.customer_trx_id,
           ct.trx_number
    FROM   ar_receivable_applications_all ra, 
           ra_customer_trx_all ct
    WHERE  ct.customer_trx_id = ##$$TRXID$$##
    AND    ra.posting_control_id = -3
    AND    ra.application_type = ''CM''
    AND    ra.event_id is null
    AND    ra.customer_trx_id = ct.customer_trx_id',
   'MISSING EVENT_ID FOR CREDIT MEMO APPLICATION ROWS (AR_00045)',
   'RS',
   'Credit memo application has missing event_id',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1080037.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'MISSING PAYMENT SCHEDULE RECORDS (AR_S_00003)',
   'select distinct gld.customer_Trx_id 
    from   ra_customer_trx_all ct , 
           ra_cust_trx_types_all ctt ,
           ra_cust_trx_line_gl_dist_all gld
    where  ct.customer_trx_id = ##$$TRXID$$##
    and    ct.cust_trx_type_id = ctt.cust_trx_type_id
    and    ctt.type in (''INV'', ''DM'', ''CM'', ''CB'')
    and    ctt.accounting_affect_flag = ''Y''
    and    gld.customer_trx_id = ct.customer_trx_id
    and    ct.complete_flag = ''Y''
    and    gld.customer_trx_id = ct.customer_trx_id
    and    gld.account_class = ''REC''
    and    gld.account_set_flag = ''N''
    and not exists
    (select ''x'' 
     from ar_payment_schedules_all  ps
     where ps.customer_trx_id = ct.customer_trx_id )',
   'MISSING PAYMENT SCHEDULE RECORDS (AR_S_00003)',
   'RS',
   'Transaction has missing ar_payment_schedules_all records',
   'Please do the following to fix the data corruption:
        <ol><li>Review [2044211.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'DUPLICATE REC ROWS WITH LATEST_REC_FLAG = Y (AR_S_00004)',
   'select customer_trx_id, count(*) 
    from   ra_cust_trx_line_gl_dist_all
    where  customer_trx_id = ##$$TRXID$$##
    and    latest_rec_flag = ''Y''
    and    account_class = ''REC''
    group  by customer_trx_id
    having count(*) >1',
   'DUPLICATE REC ROWS WITH LATEST_REC_FLAG = Y (AR_S_00004)',
   'RS',
   'You have duplicate REC rows with LATEST_REC_FLAG = Y' ,
   'Please do the following to fix the data corruption:
        <ol><li>Review [837325.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
    null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'DUPLICATE TAX DISTRIBUTION ROWS (AR_00007/00008)',
   'SELECT g1.customer_trx_id 
    FROM   ra_cust_trx_line_gl_dist_all g1,
           ra_cust_trx_line_gl_dist_all g2 
    WHERE  g1.customer_trx_id = ##$$TRXID$$##
    AND    g1.customer_trx_id = g2.customer_trx_id 
    AND    g1.account_class = ''TAX''
    AND    g1.posting_control_id = - 3 
    AND    g1.account_set_flag = ''N'' 
    AND    g2.posting_control_id <> - 3 
    AND    g2.account_class = ''TAX'' 
    AND    g2.account_set_flag=''N'' 
    AND    g2.org_id = g1.org_id 
    AND    g1.org_id = g2.org_id 
    GROUP BY g1.customer_trx_id ,g1.org_id 
    HAVING sum (g1.amount) = sum (g2.amount)',
    'DUPLICATE TAX DISTRIBUTION ROWS (AR_00007/00008)',
   'RS',
   'You have duplicate TAX distribution rows in ra_cust_trx_line_gl_dist.' ,
   'Please do the following to fix the data corruption:
        <ol><li>Review [1277053.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
    null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'DUPLICATE UNEARN ROWS IN RA_CUST_TX_LINE_GL_DIST_ALL (AR_00122)',
   'SELECT gld.customer_trx_id, gld.customer_trx_line_id, 
           gld.code_combination_id, gld.amount, 
           gld.acctd_amount, count(*) 
     FROM  ra_customer_trx_all ct, 
           ra_cust_trx_line_gl_dist_all gld 
     WHERE ct.customer_trx_id = ##$$TRXID$$##
     AND   gld.customer_trx_id = ct.customer_trx_id 
     AND   gld.account_class = ''UNEARN''
     AND   gld.rec_offset_flag= ''Y'' 
     AND   gld.ACCOUNT_SET_FLAG = ''N'' 
     AND   gld.POSTING_CONTROL_ID = -3 
     GROUP BY gld.customer_trx_id, gld.customer_trx_line_id, 
           gld.code_combination_id, GLD.AMOUNT, 
           gld.ACCTD_AMOUNT 
     HAVING  count(*) > 1',
   'DUPLICATE UNEARN ROWS IN RA_CUST_TX_LINE_GL_DIST_ALL (AR_00122)',
   'RS',
   'You have duplicate UNEARN rows in ra_cust_trx_line_gl_dist.' ,
   'Please do the following to fix the data corruption:
        <ol><li>Review [1569870.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
    null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'ORPHAN RECORDS IN XLA_EVENTS (AR_00057)',
   'select xte.source_id_int_1 customer_trx_id, xte.entity_id, xe.event_id, 
           xe.event_date, 
           xe.event_type_code, xe.event_status_code
    from   xla_events xe, xla.xla_transaction_entities xte
    where  xte.entity_code = ''TRANSACTIONS''
    and    xte.source_id_int_1 = ##$$TRXID$$##
    and    xte.entity_id = xe.entity_id
    and    xte.application_id = 222
    and    xe.application_id = 222
    and    xe.event_status_code <> ''P''
    and    xe.upg_batch_id is NULL
    and not exists
    (select ''x'' 
     from    ra_cust_Trx_line_gl_dist_all
     where   customer_trx_id = ##$$TRXID$$##
     and     account_set_flag = ''N''
     and     customer_trx_id = xte.source_id_int_1
     and     event_id = xe.event_id
     union
     select ''x'' 
     from   ar_receivable_applications_all
     where  customer_trx_id = ##$$TRXID$$##
     and    customer_trx_id = xte.source_id_int_1
     and    event_id = xe.event_id
     union
     select ''x'' 
     from   ar_receivable_applications_all
     where  applied_customer_trx_id = ##$$TRXID$$##
     and   applied_customer_trx_id = xte.source_id_int_1
     and   event_id = xe.event_id
      )
   order by xe.event_id',
   'ORPHAN RECORDS IN XLA_EVENTS (AR_00057)',
   'RS',
   'You have orphan records in XLA_EVENTS',
   'Please do the following to fix the data corruption:
        <ol><li>Review [972590.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'TRANSACTION ACCTD_AMOUNT INCORRECT (AR_00001)',
   'SELECT * 
    FROM   ra_cust_trx_line_gl_dist_all gld,
           ra_customer_trx_all trx 
    WHERE  trx.customer_trx_id = ##$$TRXID$$##
    AND    trx.customer_trx_id = gld.customer_trx_id 
    AND    gld.account_set_flag = ''N''
    AND    gld.account_class = ''REC''
    AND    gld.acctd_amount <> ( SELECT sum (acctd_amount) 
                                 FROM   ra_cust_trx_line_gl_dist_all gld_other 
                                 WHERE  gld_other.customer_trx_id = gld.customer_trx_id 
                                 AND    gld_other.account_set_flag = ''N'' 
                                 AND    GLD_OTHER.ACCOUNT_CLASS <> ''REC'')',
   'TRANSACTION ACCTD_AMOUNT INCORRECT (AR_00001)',
   'RS',
   'The acctd_amount for the REC row in ra_cust_trx_line_gl_dist_all is incorrect',
   'Please do the following to fix the data corruption:
        <ol><li>Review [987956.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'AMOUNTS AND ACCTD_AMOUNT INCORRECTLY POPULATED (AR_00202)',
   'select distinct ct.customer_Trx_id, ctl.customer_trx_line_id,
           gld.gl_date, gld.event_id 
     from  ra_customer_Trx_all ct,
           ra_cust_Trx_types_all ctt, 
           ra_customer_trx_lines_all ctl,
           ra_cust_Trx_line_gl_dist_all gld 
     where ct.cust_Trx_type_id = ctt.cust_Trx_type_id 
     and   ctt.type = ''INV''
     and   ct.customer_trx_id = ##$$TRXID$$##
     and   ct.customer_trx_id = ctl.customer_Trx_id 
     and   ctl.line_type = ''LINE''
     and   ct.customer_Trx_id = gld.customer_trx_id 
     and   gld.account_set_flag = ''N'' 
     and   gld.account_class in (''UNEARN'',''REV'') 
     and   gld.rec_offset_flag is null 
     and   gld.event_id is not null 
     and   gld.posting_control_id = -3 
     and exists ( select ''x'' 
                  from   ra_cust_Trx_line_gl_dist_all gld_unearn 
                  where  gld_unearn.customer_Trx_id = ctl.customer_Trx_id 
                  and    gld_unearn.customer_Trx_line_id = ctl.customer_Trx_line_id 
                  and    gld_unearn.account_set_flag = ''N''
                  and    gld_unearn.account_class = ''UNEARN'' 
                  and    gld_unearn.rec_offset_flag = ''Y'' 
                  group by gld_unearn.customer_Trx_id , gld_unearn.customer_Trx_line_id 
                  having  sum(gld_unearn.amount) = ctl.extended_amount ) 
      group by ct.customer_trx_id , ctl.customer_Trx_line_id, GLD.GL_DATE, GLD.EVENT_ID 
      HAVING ( SUM(GLD.AMOUNT) <> 0 OR sum(gld.acctd_amount) <> 0)',
   'AMOUNTS AND ACCTD_AMOUNT INCORRECTLY POPULATED (AR_00202)',
   'RS',
   'Amounts and acctd_amounts are incorrectly populated in RA_CUST_TRX_LINE_GL_DIST_ALL for account_Class = ''REV'' when CCID is changed due to rounding difference',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1565612.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'UPGRADED INVOICE CANNOT BE APPLIED TO A RECEIPT (AR_00210)',
   'select  ct.customer_trx_id, ct.trx_number, ct.trx_date, 
            ps.amount_due_remaining ps_amount_due_remaining, 
            ps.acctd_amount_due_remaining ps_acctd_amt_due_remaining, 
            a.amount_due_remaining line_amount_due_remaining, a.acctd_amount_due_remaining lines_acctd_amt_due_remaining, 
            ABS (ps.amount_due_remaining - a.amount_due_remaining) difference_amount, 
            ABS (ps.acctd_amount_due_remaining - a.acctd_amount_due_remaining-nvl(gld.acctd_amount, 0)) difference_acctd_amount, 
            ps.invoice_currency_code, ps.gl_date, ps.status, ct.org_id org_id 
     from   ar_payment_schedules_all ps, 
            ra_cust_trx_line_gl_dist_all gld, 
            ra_customer_trx_all ct, (select customer_trx_id, sum(amount_due_remaining + nvl(chrg_amount_remaining, 0) + 
                                            nvl(frt_adj_remaining, 0)) amount_due_remaining, 
                                            sum(acctd_amount_due_remaining + nvl(chrg_acctd_amount_remaining, 0) + nvl(frt_adj_acctd_remaining, 0)) acctd_amount_due_remaining 
                                     from   ra_customer_trx_lines_all 
                                     where  customer_trx_id = customer_trx_id 
                                     GROUP BY customer_trx_id) a 
     where  ct.customer_trx_id = ##$$TRXID$$##
     and    ct.upgrade_method = ''R12''
     and    ct.customer_trx_id = ct.customer_trx_id 
     and    ps.customer_trx_id = ct.customer_trx_id 
     and    ct.customer_trx_id = a.customer_trx_id 
     and    ct.customer_trx_id = gld.customer_trx_id(+) 
     and    gld.account_class(+) = ''ROUND''
     and((a.amount_due_remaining is not null and nvl(ps.amount_due_remaining,0) <> nvl(a.amount_due_remaining, 0)) 
     or (a.acctd_amount_due_remaining is not null and nvl(ps.acctd_amount_due_remaining-nvl(gld.acctd_amount,0),0) <> nvl(a.acctd_amount_due_remaining, 0) 
     and ps.acctd_amount_due_remaining <> a.acctd_amount_due_remaining))',
   'UPGRADED INVOICE CANNOT BE APPLIED TO A RECEIPT (AR_00210)',
   'RS',
   'Unable to apply a receipt to this upgraded transaction.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1464243.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'POSTED TRANSACTION WITH UNPROCESSED EVENTS IN XLA (AR_00025)',
   'select * 
    from   ra_cust_trx_line_gl_dist_all gld  
    where  customer_trx_id = ##$$TRXID$$##
    and    posting_control_id <> -3
    and    gl_posted_date is not null
    and    event_id is not null
    and exists    (SELECT ''x''
                   FROM   xla_events xe
                   WHERE  xe.application_id = 222
                   and    xe.event_id = gld.event_id 
                   and    xe.process_status_code <> ''P''
                   and    xe.event_type_code IN  (''INV_CREATE'',''INV_UPDATE'',''CM_CREATE'',''CM_UPDATE'',
                                                  ''DM_CREATE'',''DM_UPDATE'',''DEP_CREATE'',''DEP_UPDATE'',
                                                  ''GUAR_CREATE'',''GUAR_UPDATE'',''CB_CREATE''))',
   'POSTED TRANSACTION WITH UNPROCESSED EVENTS IN XLA (AR_00025)',
   'RS',
   'Transaction has been marked as posted in AR; however, it has unprocessed events.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1512968.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'CM APPS AR_DIST OUT OF BALANCE(AR_00052)',
   'select distinct ra.receivable_application_id receivable_application_id , 
           ra.customer_trx_id customer_Trx_id 
           from   ar_receivable_applications_all ra , 
                  ar_distributions_all ard 
           where  ra.customer_trx_id = ##$$TRXID$$##
           and    ra.application_type = ''CM''
           and    ra.posting_control_id = -3 
           and    ra.receivable_application_id = ard.source_id 
           and    ard.source_table = ''RA''
           and not exists ( SELECT SUM(NVL(ARD.ACCTD_AMOUNT_DR,0)) , SUM(NVL(ARD.ACCTD_AMOUNT_CR,0)) 
                            from   ar_distributions_all ard 
                            where   ard.source_id = ra.receivable_Application_id 
                            and    ard.source_table = ''RA''
                            and exists ( select ''x''
                                         from   ar_distributions_All ard 
                                         where  ard.source_id = ra.receivable_application_id 
                                         and    ard.source_table = ''RA'' and ard.ref_customer_trx_line_id <> -6 
                                         and    ard.ref_cust_trx_line_gl_dist_id <> -6 ) 
           group by ard.source_id , ard.source_table 
           HAVING SUM(NVL(ARD.ACCTD_AMOUNT_DR,0)) = SUM(NVL(ARD.ACCTD_AMOUNT_CR,0)))',
   'CM APPS AR_DIST OUT OF BALANCE(AR_00052)',
   'RS',
   'Distributions are getting incorrectly created or imbalanced in AR_DISTRIBUTIONS_ALL for the distributions having ref columns populated values <> -6.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [946753.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'CM DIST WITH AMOUNT = NULL (AR_00307)',
   'select distinct ct.customer_trx_id 
    from   ra_cust_trx_types_all ctt, 
           ra_Customer_trx_all ct 
    where  ct.customer_trx_id = ##$$TRXID$$##
    and    ctt.cust_trx_type_id = ct.cust_trx_type_id 
    and    ctt.type = ''CM''
    and    ct.invoicing_rule_id is not null 
    and    ct.previous_customer_trx_id is not null 
    and exists ( select ''x''
                 from   ra_cust_trx_line_gl_dist_all gld  
                 where  gld.customer_trx_id = ct.customer_trx_id 
                 and    gld.account_set_flag = ''N''
                 and    (gld.amount is null or gld.acctd_amount is null))',
   'CM DIST WITH AMOUNT = NULL (AR_00307)',
   'RS',
   'Distributions are getting imbalanced in AR_DISTIRBUTIONS_ALL since the regular Credit memo distributions created with rules in ra_cust_trx_line_gl_dist_all are having amount and acctd_amount null for the non model records.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [2064509.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'TRX WITH UNBALANCED ACCOUNTING FOR REV ADJ (AR_00030)',
   'select  gld.gl_date,code_combination_id C_CID, account_class  Class,sum(amount) AMT, sum(acctd_amount) ACCTD_AMT 
    from    ra_cust_trx_line_gl_dist_all gld,
            ra_customer_Trx_all ct
    where   ct.customer_trx_id = ##$$TRXID$$##
    and     ct.customer_trx_id = gld.customer_trx_id
    and     gld.account_set_flag = ''N''
    and  exists (select ''x''
                 from   ra_cust_trx_line_gl_dist_all gldin
                 where  gldin.customer_Trx_id = gld.customer_trx_id
                 and    gldin.account_set_flag = ''N''
                 and    gldin.revenue_adjustment_id is not null
                 and    gldin.posting_control_id = -3)
    group by gld.gl_date,code_combination_id, account_class having sign(sum(amount)) <> sign(sum(acctd_amount))',
   'TRX WITH UNBALANCED ACCOUNTING FOR REV ADJ (AR_00030)',
   'RS',
   'Transactions with unbalanced accounting for revenue adjustments.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1512966.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'TRX DIST WITH ACCTD_AMOUNT = NULL (AR_00014)',
   'select distinct gld.customer_trx_id customer_trx_id , 
           ct.exchange_rate exchange_rate,
           gld.cust_trx_line_gl_dist_id cust_trx_line_gl_dist_id,
           gld.amount amount,
           gld.acctd_amount acctd_amount
    from   ra_cust_trx_line_gl_dist_all gld,
           ra_customer_trx_all ct
    where  gld.customer_trx_id = ##$$TRXID$$##
    and    gld.customer_trx_id = ct.customer_trx_id 
    and    gld.account_set_flag = ''N''
    and    gld.posting_control_id = -3
    and    gld.acctd_amount is null
    and    gld.amount is not null',
   'TRX DIST WITH ACCTD_AMOUNT = NULL (AR_00014)',
   'RS',
   'There are records in ra_cust_trx_line_gl_dist_all with acctd_amount = NULL.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [2059651.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'TRX WITH NEGATIVE EXCHANGE RATE (AR_00322)',
   'SELECT customer_trx_id, trx_number, exchange_rate
    FROM   ra_customer_trx_all 
    WHERE  customer_trx_id = ##$$TRXID$$##
    AND    nvl(exchange_rate, 1) < 0',
   'TRX WITH NEGATIVE EXCHANGE RATE (AR_00322)',
   'RS',
   'Transaction has negative exchange_rate',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1912838.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'TABLE AR_DISTRIBUTIONS_ALL SHOWS REF_PREV_CUST_TRX_LINE_ID = NULL (AR_00276)',
   'SELECT ard.* 
    FROM   ar_distributions_all ard 
    WHERE  ard.source_id IN (SELECT receivable_application_id 
                             FROM   ar_receivable_applications_all 
                             WHERE  customer_trx_id = ##$$TRXID$$##
                             and    posting_control_id = -3 
                             and    application_type = ''CM'' ) 
    AND ard.source_table = ''RA'' 
    AND ard.source_type = ''REC'' 
    AND ard.ref_prev_cust_trx_line_id IS NULL',
   'TABLE AR_DISTRIBUTIONS_ALL SHOWS REF_PREV_CUST_TRX_LINE_ID = NULL (AR_00276)',
   'RS',
   'Table ar_distributions_all shows REF_PREV_CUST_TRX_LINE_ID = NULL.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1561204.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'TABLE AR_DISTRIBUTIONS_ALL SHOWS ONE SIDED CM APP ENTRY (AR_00021)',
   'select distinct ra.receivable_application_id receivable_application_id ,
           ra.customer_trx_id  customer_Trx_id
    from   ar_receivable_applications_all ra,
           ar_distributions_all ard
    where  ra.customer_trx_id = ##$$TRXID$$##
    and    ra.application_type = ''CM''
    and    ra.posting_control_id = -3
    and    ra.receivable_application_id = ard.source_id
    and    ard.source_table = ''RA''
    and    ra.customer_trx_id = ra.customer_Trx_id
    and    not exists (select  sum(nvl(ard.acctd_amount_dr,0)) , sum(nvl(ard.acctd_amount_cr,0))
                       from    ar_distributions_all ard
                       where   ard.source_id = ra.receivable_application_id
                       and     ard.source_table  = ''RA''
                       group by ard.source_id , ard.source_table
                       having sum(nvl(ard.acctd_amount_dr,0)) = sum(nvl(ard.acctd_amount_cr,0)))',
   'TABLE AR_DISTRIBUTIONS_ALL SHOWS ONE SIDED CM APP ENTRY (AR_00021)',
   'RS',
   'Table ar_distributions_all shows one sided credit memo application entry.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1960336.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'DISTRIBUTIONS ARE MISSING OR IMBALANCED IN ARD FOR CM APPLICATIONS (AR_00020)',
   'select distinct ra.receivable_application_id receivable_application_id ,
           ra.customer_trx_id  customer_Trx_id
           from ar_receivable_applications_All ra,
           ar_distributions_all ard
    where  ra.application_type = ''CM''
    and    ra.posting_control_id = -3
    and    ra.receivable_application_id = ard.source_id
    and    ard.source_table = ''RA''
    and    ra.customer_trx_id = ra.customer_Trx_id 
    and not exists (select sum(nvl(ard.acctd_amount_dr,0)) , sum(nvl(ard.acctd_amount_cr,0))
                    from   ar_distributions_all ard
                    where  ard.source_id = ra.receivable_Application_id
                    and    ard.source_table  = ''RA''
                    group by ard.source_id, ard.source_table
                    having sum(nvl(ard.acctd_amount_dr,0)) = sum(nvl(ard.acctd_amount_cr,0)))',
   'DISTRIBUTIONS ARE MISSING OR IMBALANCED IN ARD FOR CM APPLICATIONS (AR_00020)',
   'RS',
   'Table ar_distributions_all shows one sided credit memo application entry.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1498234.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'EVENTS ARE PRESENT IN OLDER PERIODS WHICH ARE NOT YET POSTED BUT THE PERIODS ARE CLOSED (AR_00105)',
   'select gld.customer_trx_id customer_trx_id,
           gld.gl_date gl_date, gld.org_id org_id, 
           gld.event_id event_id,
           gps.closing_status gl_closing_status,
           gps.application_id gps_appl_id,
           gld.posting_control_id posting_control_id 
    from   ra_cust_trx_line_gl_dist_all gld, 
           ra_customer_trx_all ct, 
           gl_period_statuses gps 
    Where  ct.customer_trx_id = ##$$TRXID$$##
    and    ct.customer_trx_id = gld.customer_trx_id 
    and    ct.complete_flag = ''Y'' 
    and    gld.posting_control_id = -3 
    and    gld.account_set_flag = ''N''
    and    gld.event_id is not null 
    and not exists (select ''x'' 
                    from   xla_events 
                    Where  application_id = 222 
                    and    event_id = gld.event_id 
                    and    event_status_code = ''P'' 
                    and    process_status_code = ''P'' ) 
    and    gld.gl_date between gps.start_date and gps.end_date 
    and    gps.application_id in (101, 222) 
    and    gps.set_of_books_id = ct.set_of_books_id 
    and    gps.closing_status in (''C'', ''W'') 
    UNION  
    select ra.customer_trx_id customer_trx_id, 
           ra.gl_date gl_date, ra.org_id org_id, 
           ra.event_id event_id, gps.closing_status gl_closing_status, 
           gps.application_id gps_appl_id, 
           ra.posting_control_id posting_control_id 
    from   ar_receivable_applications_all ra, 
           ra_customer_trx_all ct, 
           gl_period_statuses gps 
    Where  ct.customer_trx_id = ##$$TRXID$$##
    and    ct.customer_trx_id = ra.customer_trx_id
    and    ct.complete_flag = ''Y'' 
    and    ra.posting_control_id = -3 
    and    ra.application_type = ''CM'' 
    and    ra.event_id is not null 
    and not exists (select ''x''
                    from   xla_events 
                    where  application_id = 222 
                    and    event_id = ra.event_id 
                    and    event_status_code = ''P'' 
                    and    process_status_code = ''P'')
    and    ra.gl_date between gps.start_date and gps.end_date 
    and    gps.application_id in (101, 222) 
    and    gps.set_of_books_id = ct.set_of_books_id 
    and    gps.closing_status in (''C'', ''W'')',
   'EVENTS ARE PRESENT IN OLDER PERIODS WHICH ARE NOT YET POSTED BUT THE PERIODS ARE CLOSED (AR_00105)',
   'RS',
   'There are events in older period which are not processed, but the periods are closed.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1521061.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'TAX DISTRIBUTIONS ARE PRESENT IN RA_CUSTOMER_TRX_LINES_ALL BUT NOT PRESENT IN GLD (AR_00079)',
   'SELECT * 
    FROM   ar_payment_schedules_all ps 
    WHERE  ps.customer_trx_id = ##$$TRXID$$##
    AND    NUMBER_OF_DUE_DATES = 1
    AND    ps.amount_due_original <> (SELECT sum (ctl.extended_amount) 
                                      FROM   ra_customer_trx_lines_all ctl 
                                      WHERE  ctl.customer_trx_id = ##$$TRXID$$##)',
   'TAX DISTRIBUTIONS ARE PRESENT IN RA_CUSTOMER_TRX_LINES_ALL BUT NOT PRESENT IN GLD (AR_00079)',
   'RS',
   'Tax distribution rows are present in ra_customer_trx_all but not presend in RA_CUST_TRX_LINE_GL_DIST_ALL.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1566061.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'CM UNEARN/REV PAIRS MISSING IN GLD (AR_00199)',
   'select distinct ct.customer_Trx_id 
    from   ra_cust_Trx_types_all ctt, 
           ra_customer_Trx_all ct,
           ra_customer_Trx_lines_all ctl,
           ra_cust_Trx_line_gl_dist_all gld 
    where  ct.customer_trx_id = ##$$TRXID$$##
    and    ctt.cust_Trx_type_id = ct.cust_Trx_type_id 
    and    ctt.type = ''CM''
    and    ct.invoicing_rule_id in (-2,-3) 
    and    ct.customer_Trx_id = ctl.customer_trx_id 
    and    ctl.line_type = ''LINE'' 
    and    ctl.previous_customer_Trx_id is not null 
    and    ctl.previous_Customer_Trx_line_id is not null 
    and    ct.customer_Trx_id = gld.customer_Trx_id 
    and    ctl.customer_Trx_id = gld.customer_Trx_id 
    and    ctl.customer_Trx_line_id = gld.customer_Trx_line_id
    and    gld.account_Class = ''UNEARN''
    and    gld.rec_offset_flag = ''Y'' 
    and    gld.account_set_flag = ''N'' 
    and    not exists (select ''x''
                       from   ra_Cust_Trx_line_gl_dist_all gld_pair 
                       where  gld_pair.customer_trx_id = gld.customer_Trx_id 
                       and    gld_pair.customer_Trx_line_id = gld.customer_Trx_line_id 
                       and    gld_pair.account_set_flag = ''N''
                       and    gld_pair.account_Class in (''UNEARN'',''REV'') 
                       and    GLD.REC_OFFSET_FLAG IS NULL)',
   'CM UNEARN/REV PAIRS MISSING IN GLD (AR_00199)',
   'RS',
   'CM has missing non-model UNEARN/REV pairs in RA_CUST_TRX_LINE_GL_DIST_ALL.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1561204.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'TAX LINES PRESENT IN ZX NOT IN AR (AR_00104)',
   'select distinct ct.customer_trx_id, gld.event_id , gld.gl_date, ct.exchange_rate 
    from   ra_customer_trx_all ct, 
           ra_cust_trx_types_all ctt,
           ra_cust_trx_line_gl_dist_all gld 
    WHERE  ct.customer_trx_id = ##$$TRXID$$##
    and    ct.customer_Trx_id in (SELECT  distinct zl.trx_id 
                              FROM    zx_lines zl,
                                      ra_customer_trx_lines_all lines 
                              WHERE   zl.application_id = 222 
                              AND     zl.entity_code = ''TRANSACTIONS'' 
                              AND     zl.event_class_code IN (''INVOICE'',''DEBIT_MEMO'',''CREDIT_MEMO'') 
                              AND     zl.trx_id = lines.customer_trx_id 
                              AND  NOT EXISTS ( SELECT  zl_in.* 
                                                FROM    zx_lines zl_in,
                                                        ra_customer_trx_lines_all lines_in 
                                                WHERE   zl_in.application_id = 222 
                                                AND     zl_in.entity_code = ''TRANSACTIONS'' 
                                                AND     zl_in.event_class_code IN (''INVOICE'',''DEBIT_MEMO'',''CREDIT_MEMO'') 
                                                AND     zl_in.trx_id = lines_in.customer_trx_id 
                                                AND     zl_in.tax_line_id = lines_in.tax_line_id 
                                                AND     lines_in.customer_trx_id = lines.customer_trx_id )) 
    and   ct.cust_Trx_type_id = ctt.cust_Trx_type_id 
    and   ctt.type in(''INV'',''CM'') 
    and   ct.customer_trx_id = gld.customer_trx_id 
    and   gld.account_set_flag = ''N'' 
    and   gld.posting_control_id = -3 
    AND   NOT EXISTS ( select ''x'' 
                       from ra_cust_trx_line_gl_dist_all gld 
                       where  gld.customer_trx_id = ct.customer_Trx_id 
                       and    gld.account_set_flag =''N'' 
                       and    gld.posting_control_id <> -3 )',
   'TAX LINES PRESENT IN ZX NOT IN AR (AR_00104)',
   'RS',
   'Tax lines present in zx_lines, but not in ra_customer_trx_lines_all.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [2060893.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'CM APP MARKED AS POSTED IN XLA NOT IN AR (AR_00323)',
   'SELECT  DISTINCT ra.receivable_application_id
    FROM    ar_receivable_applications_all ra, 
            ra_customer_trx_all ct
    WHERE   ct.customer_trx_id = ##$$TRXID$$##
    AND     ra.customer_trx_id = ct.customer_trx_id
    AND     ra.application_type = ''CM''
    AND     ra.event_id IS NOT NULL
    AND     EXISTS  (SELECT  ''x''
                    FROM    xla_events
                    WHERE   event_id = ra.event_id
                    AND     event_status_code = ''P''
                    AND     process_status_code = ''P''
                    AND     application_id = 222)
    AND     NOT EXISTS (SELECT  ''x''
                        FROM    xla_ae_headers xah
                        WHERE   xah.event_id = ra.event_id)',
   'CM APP MARKED AS POSTED IN XLA NOT IN AR (AR_00323)',
   'RS',
   'Credit Memo applications are marked as processed in XLA; however, they are showing as unposted in AR.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [2062840.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'UNBALANCED UNPOSTED CM APP AGAINST BR (AR_00027)',
   'select receivable_application_id, ra.customer_trx_id cm_ctid, 
           ra.gl_date, applied_customer_trx_id br_ctid
    from   ar_receivable_applications_all ra, 
           ra_customer_trx_all ct, 
           ar_payment_schedules_all ps 
    where  ct.customer_trx_id = ##$$TRXID$$##
    and    ra.customer_trx_id = ct.customer_trx_id 
    and    ra.application_type = ''CM'' 
    and    ra.applied_payment_schedule_id = ps.payment_schedule_id 
    and    ra.posting_control_id = -3  
    and    ps.class = ''BR'' 
    and exists (select ''x'' 
                from   ar_distributions_all
                where  source_table = ''RA''
                and   source_id = ra.receivable_application_id
                group by source_id, code_combination_id
                having sum(acctd_amount_dr) <> sum(acctd_amount_cr))',
   'UNBALANCED UNPOSTED CM APP AGAINST BR (AR_00027)',
   'RS',
   'Unposted credit memo application rows against Bill Receivables.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1512967.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'MISSING PREVIOUS_CUSTOMER_TRX_LINE_ID FOR CM TAX LINES (AR_00193)',
   'select distinct ct.customer_trx_id 
    from   ra_customer_trx_all ct , 
           ra_cust_trx_types_all ctt , 
           ra_customer_trx_lines_all ctl, 
           ra_cust_trx_line_gl_dist_all gld 
    where  ct.customer_trx_id = ##$$TRXID$$##
    and    ct.cust_trx_type_id = ctt.cust_trx_type_id 
    and    ct.complete_flag=''Y'' 
    and    ctt.type = ''CM'' 
    and    ct.invoicing_rule_id in (-2,-3) 
    and    ct.customer_trx_id = ctl.customer_trx_id 
    and    ctl.line_type = ''TAX'' 
    and    ct.customer_trx_id = gld.customer_trx_id 
    and    gld.account_set_flag = ''N'' 
    and    gld.account_class = ''REC''
    and    gld.latest_rec_flag = ''Y'' 
    and not exists (select ''x'' 
                    from   ra_cust_trx_line_gl_dist_all gld1 
                    where  gld1.account_set_flag = ''N'' 
                    and    gld1.account_class = ''TAX'' 
                    and    gld1.customer_trx_id = ct.customer_trx_id )',
   'MISSING PREVIOUS_CUSTOMER_TRX_LINE_ID FOR CM TAX LINES (AR_00193)',
   'RS',
   'Credit memo tax lines do not have previous_customer_trx_line_id populated.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [2062829.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'AMOUNT POPULATED AS 0 AND ACCTD_AMOUNT <> O IN ARD FOR CM APPS (AR_00220)',
   'select distinct ra.customer_Trx_id 
    from   ar_receivable_applications_all ra, 
           ar_distributions_all ard 
    where  ra.customer_trx_id = ##$$TRXID$$##
    and    ra.application_type = ''CM'' 
    and    ra.posting_control_id = -3
    and    ra.receivable_application_id = ard.source_id 
    and    ard.source_Table = ''RA'' 
    and    ard.amount_dr = 0
    and    ard.acctd_amount_dr <> 0 
    union 
    select distinct ra.customer_Trx_id 
    from   ar_Receivable_applications_all ra,
           ar_distributions_all ard 
    where  ra.customer_trx_id = ##$$TRXID$$##
    and    ra.application_type = ''CM''
    and    ra.posting_control_id = -3 
    and    ra.receivable_application_id = ard.source_id 
    and    ARD.SOURCE_TABLE = ''RA'' 
    and    ard.amount_cr = 0 
    and    ard.acctd_amount_cr <> 0 
    and    ard.source_type not in (''EXCH_GAIN'',''EXCH_LOSS'',''CURR_ROUND'')',
   'AMOUNT POPULATED AS 0 AND ACCTD_AMOUNT <> O IN ARD FOR CM APPS (AR_00220)',
   'RS',
   'Amount populated as 0 and acctd_amount <> 0 in AR_DISTRIBUTIONS_ALL for Credit Memo Applications.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1960336.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'AMOUNT IS POPULATED AS 0, ACCTD_AMOUNT <> O IN GLD (AR_00264)',
   'select distinct customer_Trx_id 
    from   ra_cust_Trx_line_gl_dist_all 
    where  customer_trx_id = ##$$TRXID$$##
    and    posting_Control_id = -3 
    and    account_set_flag = ''N''
    and    amount = 0 
    and    acctd_amount <> 0',
   'AMOUNT IS POPULATED AS 0, ACCTD_AMOUNT <> O IN GLD (AR_00264)',
   'RS',
   'Amount populated as 0 and acctd_amount <> 0 in RA_CUST_TRX_LINE_GL_DIST_ALL.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [2062848.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'TAX ROWS WITH DIFFERENT EVENT_ID IN GLD (AR_00119)',
   'SELECT gldrec.customer_trx_id customer_trx_id,
           gldrec.customer_trx_line_id rec_line_id, 
           gldrec.cust_trx_line_gl_dist_id rec_line_gld_id, 
           gldrec.event_id rec_event_id,
           gldtax.customer_trx_line_id tax_line_id, 
           gldtax.cust_trx_line_gl_dist_id tax_line_gld_id, 
           gldtax.event_id tax_event_id
    FROM   ra_cust_trx_line_gl_dist_all gldrec,
           ra_cust_trx_line_gl_dist_all gldtax
    WHERE  gldrec.customer_trx_id = ##$$TRXID$$##
    AND    gldrec.account_class = ''REC''
    AND    gldrec.latest_rec_flag = ''Y''
    AND    gldrec.account_set_flag = ''N''
    AND    gldrec.event_id IS NOT NULL
    AND    gldtax.account_class = ''TAX''
    AND    gldtax.account_set_flag = ''N''
    AND    gldtax.event_id IS NOT NULL
    AND    gldtax.customer_trx_id = gldrec.customer_trx_id
    AND    gldtax.gl_date = gldrec.gl_date
    AND    gldtax.event_id <> gldrec.event_id
    AND    gldrec.posting_control_id = -3
    AND    gldrec.gl_posted_date is NULL
    AND not exists (SELECT ''x''
                    FROM   xla_events
                    WHERE  event_id = gldtax.event_id
                    AND event_status_code = ''P'')',
   'TAX ROWS WITH DIFFERENT EVENT_ID IN GLD (AR_00119)',
   'RS',
   'Tax rows are populated with different event_id in RA_CUST_TRX_LINE_GL_DIST_ALL.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1569548.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'AMOUNT = NULL IN GLD FOR POSTED RECORDS (AR_00117)',
   'select cm.customer_trx_id, cm.customer_trx_line_id, cm.extended_amount, 
           sum(NVL(cmg.amount,0)) gl_dist_sum, 
           cm.rule_start_date, cmh.trx_number 
    from   ra_customer_trx_all cmh, 
           ra_customer_trx_lines_all cm, 
           ra_cust_trx_line_gl_dist_all cmg 
    where  cmh.customer_trx_id = ##$$TRXID$$##
    and    cmh.complete_flag in (''Y'',''N'') 
    and    cm.line_type = ''LINE''   
    and    cm.customer_trx_line_id = cmg.customer_trx_line_id 
    and    cm.customer_trx_id = cmh.customer_trx_id 
    and    cmg.account_class = ''REV'' 
    and    cmg.account_set_flag = ''N'' 
    and    exists (select ''bad dist'' 
                   from   ra_cust_trx_line_gl_dist_all cmg2 
                   where  cmg2.account_class = ''REV'' 
                   and    cmg2.account_set_flag = ''N'' 
                   and    cmg2.amount IS NULL 
                   and    cmg2.customer_trx_line_id = cm.customer_trx_line_id) 
    GROUP BY cm.customer_trx_id, cm.customer_trx_line_id, 
             cm.extended_amount, cm.rule_start_date, 
             cmh.trx_number',
   'AMOUNT = NULL IN GLD FOR POSTED RECORDS (AR_00117)',
   'RS',
   'Tax rows are populated with different event_id in RA_CUST_TRX_LINE_GL_DIST_ALL.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1588026.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'UNEARN/REV PAIRS NOT EQUAL TO ACCOUNTING RULE DURATION FOR CM (AR_00200)',
   'select     distinct ct.customer_Trx_id
    from       ra_cust_trx_types  ctt,
               ra_customer_trx  ct,
               ra_cust_trx_line_gl_dist  gld_rec
    where      ct.customer_trx_id = ##$$TRXID$$##
    and        ctt.cust_trx_type_id = ct.cust_trx_type_id
    and        ctt.type = ''CM''
    and        ct.invoicing_rule_id in (-2,-3)
    and        ct.customer_trx_id = gld_rec.customer_trx_id
    and        gld_Rec.account_class = ''REC''
    and        gld_rec.account_set_flag = ''N''
    and        gld_rec.latest_rec_flag = ''Y''
   and  exists (select ''x''
                from   ra_customer_trx_lines ctl ,
                       ra_cust_trx_line_gl_dist gld_rev
                where  ctl.customer_Trx_id = ct.customer_Trx_id
                and    ctl.line_type = ''LINE''
                and    ctl.customer_Trx_id = gld_rev.customer_Trx_id
                and    ctl.customer_Trx_line_id = gld_rev.customer_Trx_line_id
                and    gld_rev.account_class = ''REV''
                and    gld_rev.account_set_flag = ''N''
                group by ctl.customer_trx_id,ctl.customer_trx_line_id,
                         ctl.accounting_rule_id,
                         ctl.accounting_rule_duration
                having count(distinct gld_rev.original_gl_date) <> ctl.accounting_rule_duration)',
   'UNEARN/REV PAIRS NOT EQUAL TO ACCOUNTING RULE DURATION FOR CM (AR_00200)',
   'RS',
   'Number UNEARN/REV pairs is not equal to the accounting_rule_duration',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1917656.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   add_signature(
   'REV REC NOT RUN',
   'SELECT  ct.customer_trx_id, ct.trx_number, ct.org_id
    FROM    ra_cust_trx_line_gl_dist_all gld,
            ra_customer_trx_all ct
    WHERE   ct.customer_trx_id = ##$$TRXID$$##
    AND     gld.account_class = ''REC''
    AND     gld.latest_rec_flag = ''Y''
    AND     gld.account_set_flag = ''Y''
    AND     ct.customer_trx_id = gld.customer_trx_id
    AND     ct.complete_flag = ''Y''',
   'REV REC NOT RUN',
   'RS',
   'Revenue Recognition has not been run.',
   'Please perform the following:
        <ol><li>Please run Revenue Recognition.</li>
        <li>If you have issues, Please review [1121944.1].</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'W',
   'RS');
   
   add_signature(
   'TRANSACTION IS NOT COMPLETE',
   'SELECT  customer_trx_id, trx_number, complete_flag, org_id
    FROM    ra_customer_trx_all
    WHERE   customer_trx_id = ##$$TRXID$$##
    AND     complete_flag = ''N''',
   'TRANSACTION IS NOT COMPLETE',
   'RS',
   'This invoice is not complete.',
   'Please perform the following:
        <ol><li>Please complete the invoice.</li>
        <li>If you have issues, Please review [1477458.2].</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'W',
   'RS');
  
   add_signature(
   'INV_UPDATE IS STAMPED AND POSTED IN AR BUT INV_CREATE IS ORPHAN (AR_S_00006)',
   'select DISTINCT ct.customer_trx_id customer_trx_id, 
           ct.trx_number trx_number, gld.event_id 
    from   ra_cust_trx_line_gl_dist_all gld,
           ra_customer_trx_all ct,
           ra_cust_trx_types_all ctt
    WHERE  ct.customer_trx_id = ##$$TRXID$$##
    and    ct.customer_trx_id = gld.customer_trx_id
    and    ct.cust_Trx_type_id = ctt.cust_trx_type_id
    and    ctt.type = ''INV''
    and    gld.posting_control_id <> -3
    AND    gld.account_set_flag = ''N''
    and 1 = ( select count(distinct event_id ) 
              from   ra_cust_trx_line_gl_dist_all
              where  customer_Trx_id = gld.customer_Trx_id
              and    account_set_flag = ''N'')
    and exists (select ''x'' 
                from   xla_events
                where event_id = gld.event_id
                and   event_status_code = ''P''
                and   process_status_code = ''P''
                and   event_type_code <> ''INV_CREATE'')',
   'INV_UPDATE IS STAMPED AND POSTED IN AR BUT INV_CREATE IS ORPHAN (AR_S_00006)',
   'RS',
   'INV_UPDATE event is stamped in the AR tables, but the INV_CREATE is orphan.',
   'Please perform the following:
        <ol><li>Please run Revenue Recognition.</li>
        <li>If you have issues, Please review [1483559.1].</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');
   
   add_signature(
   'PAYMENT TERM HAS TERMS_SEQUENCE_NUMBER <> 1 (AR_S_00007)',
   'select rt.term_id, 
           rtl.sequence_num
    from   ra_terms rt, 
           ra_terms_lines rtl
    where  rt.term_id in (select term_id
                          from   ra_customer_trx_all
                          where  customer_trx_id = ##$$TRXID$$##)
    and    rt.term_id = rtl.term_id
    and    rtl.sequence_num <> 1
    and exists  (select ''x''
                 from   ra_terms_lines rtla
                 where  rtla.term_id = rt.term_id
                 group by rtla.term_id
                 having count(rtla.term_id) = 1)',
   'PAYMENT TERM HAS TERMS_SEQUENCE_NUMBER <> 1 (AR_S_00007)',
   'RS',
   'The payment term for this transaction has terms_sequence_number <> 1 even though there is only one installment.',
   'Please do the following to fix the data corruption:
        <ol><li>Review [1057654.1]</li>
        <li>Run the script provided</li>
        <li>If you need assistance, please log a Service Request.</li></ol>',
   null,
   'FAILURE',
   'E',
   'RS');

   
    -------------------------------------------
    -- End of example signatures
    -------------------------------------------	 
    -- PSD #9b-end	 

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;





---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main (
    p_customer_trx_id IN NUMBER   DEFAULT null,
    p_includeGL       IN VARCHAR2) IS


  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
  
-- PSD #11
-- Title of analyzer output!! - do not add word 'analyzer' at the end as it is appended in code in PSD #5
-- So title will be what you define here for analyzer_title plus Analyzer Report
-- Example: If you assign 'AP Core' to analyzer_title, then title of output will be "AP Core Analyzer Report"
  analyzer_title := 'EBS Oracle Receivables Transaction';

  l_step := '20';
 -- PSD #12
  validate_parameters(
      p_customer_trx_id,
      p_includeGL);
  initialize_files;
      
  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #13
  
   start_section('Ledger Information');
     set_item_result(run_stored_sig('LEDGER INFORMATION'));
  end_section;
  
   start_section('AR System Parameters');
     set_item_result(run_stored_sig('AR SYSTEM PARAMETERS'));
  end_section;
  
IF g_type in ('INV','DM','GUAR','DEP','CB') then
   start_section('Transaction Data');
     set_item_result(run_stored_sig('RA_CUSTOMER_TRX_ALL'));
     set_item_result(run_stored_sig('TRANSACTION IS NOT COMPLETE'));
     set_item_result(run_stored_sig('RA_CUST_TRX_TYPES_ALL'));
     set_item_result(run_stored_sig('RA_BATCH_SOURCES_ALL'));
     set_item_result(run_stored_sig('RA_CUSTOMER_TRX_LINES_ALL'));
     set_item_result(run_stored_sig('MTL_SYSTEM_ITEMS_B'));
     set_item_result(run_stored_sig('RA_CUST_TRX_LINE_SALESREPS_ALL'));
     set_item_result(run_stored_sig('JTF_RS_SALESREPS'));
     set_item_result(run_stored_sig('ZX_LINES'));
     set_item_result(run_stored_sig('ZX_LINES_DET_FACTORS'));
     set_item_result(run_stored_sig('AR ACCOUNTS'));
     set_item_result(run_stored_sig('RA_CUST_TRX_LINE_GL_DIST_ALL'));
     set_item_result(run_stored_sig('REV REC NOT RUN'));
     set_item_result(run_stored_sig('RA_CUST_TRX_LINE_GL_DIST_ALL Totals'));
     set_item_result(run_stored_sig('APPLICATIONS ON TRANSACTION'));
     set_item_result(run_stored_sig('APPLICATIONS ON TRANSACTION Totals'));
     set_item_result(run_stored_sig('APPLICATION DISTRIBUTIONS'));
     set_item_result(run_stored_sig('AR_ADJUSTMENTS_ALL'));
     set_item_result(run_stored_sig('ADJUSTMENT Totals'));
     set_item_result(run_stored_sig('ADJUSTMENT DISTRIBUTIONS'));
     set_item_result(run_stored_sig('AR_PAYMENT_SCHEDULES_ALL'));
     set_item_result(run_stored_sig('AR_DISPUTE_HISTORY'));
     set_item_result(run_stored_sig('AR_REVENUE_ADJUSTMENTS_ALL'));
     set_item_result(run_stored_sig('AR_ACTIVITY_DETAILS'));
     set_item_result(run_stored_sig('AR_LINE_CONTS_ALL'));
     set_item_result(run_stored_sig('RA_RULES'));
     set_item_result(run_stored_sig('ACCOUNTING RULES'));
     set_item_result(run_stored_sig('ACCOUNTING RULE PERIODS'));
  end_section;
ELSE IF g_type = 'CM' THEN
     start_section('Transaction Data');
         set_item_result(run_stored_sig('RA_CUSTOMER_TRX_ALL'));
         set_item_result(run_stored_sig('TRANSACTION IS NOT COMPLETE'));
         set_item_result(run_stored_sig('RA_CUST_TRX_TYPES_ALL'));
         set_item_result(run_stored_sig('RA_BATCH_SOURCES_ALL'));
         set_item_result(run_stored_sig('RA_CUSTOMER_TRX_LINES_ALL'));
         set_item_result(run_stored_sig('MTL_SYSTEM_ITEMS_B'));
         set_item_result(run_stored_sig('RA_CUST_TRX_LINE_SALESREPS_ALL'));
         set_item_result(run_stored_sig('JTF_RS_SALESREPS'));
         set_item_result(run_stored_sig('ZX_LINES'));
         set_item_result(run_stored_sig('ZX_LINES_DET_FACTORS'));
         set_item_result(run_stored_sig('AR ACCOUNTS'));
         set_item_result(run_stored_sig('RA_CUST_TRX_LINE_GL_DIST_ALL'));
         set_item_result(run_stored_sig('REV REC NOT RUN'));
         set_item_result(run_stored_sig('RA_CUST_TRX_LINE_GL_DIST_ALL Totals'));
         set_item_result(run_stored_sig('APPLICATIONS ON TRANSACTION'));
         set_item_result(run_stored_sig('TRANSACTION APPLICATIONS'));
         set_item_result(run_stored_sig('APPLICATIONS ON TRANSACTION Totals'));
         set_item_result(run_stored_sig('APPLICATION DISTRIBUTIONS'));
         set_item_result(run_stored_sig('AR_ADJUSTMENTS_ALL'));
         set_item_result(run_stored_sig('ADJUSTMENT Totals'));
         set_item_result(run_stored_sig('ADJUSTMENT DISTRIBUTIONS'));
         set_item_result(run_stored_sig('AR_PAYMENT_SCHEDULES_ALL'));
         set_item_result(run_stored_sig('AR_REVENUE_ADJUSTMENTS_ALL'));
         set_item_result(run_stored_sig('AR_ACTIVITY_DETAILS'));
         set_item_result(run_stored_sig('AR_LINE_CONTS_ALL'));
         set_item_result(run_stored_sig('RA_RULES'));
         set_item_result(run_stored_sig('ACCOUNTING RULES'));
         set_item_result(run_stored_sig('ACCOUNTING RULE PERIODS'));
     end_section;
    ELSE  
       start_section('Bill Receivable Data');
          set_item_result(run_stored_sig('RA_CUSTOMER_TRX_ALL'));
          set_item_result(run_stored_sig('RA_CUST_TRX_TYPES_ALL'));
          set_item_result(run_stored_sig('RA_BATCH_SOURCES_ALL'));
          set_item_result(run_stored_sig('RA_CUSTOMER_TRX_LINES_ALL'));
          set_item_result(run_stored_sig('MTL_SYSTEM_ITEMS_B'));
          set_item_result(run_stored_sig('RA_CUST_TRX_LINE_SALESREPS_ALL'));
          set_item_result(run_stored_sig('JTF_RS_SALESREPS'));
          set_item_result(run_stored_sig('AR_TRANSACTION_HISTORY_ALL'));
          set_item_result(run_stored_sig('AR ACCOUNTS (BR)'));
          set_item_result(run_stored_sig('AR_DISTRIBUTIONS_ALL (TH)'));
          set_item_result(run_stored_sig('APPLICATIONS ON TRANSACTION'));
          set_item_result(run_stored_sig('APPLICATIONS ON TRANSACTION Totals'));
          set_item_result(run_stored_sig('APPLICATION DISTRIBUTIONS'));
          set_item_result(run_stored_sig('AR_ADJUSTMENTS_ALL'));
          set_item_result(run_stored_sig('ADJUSTMENT Totals'));
          set_item_result(run_stored_sig('ADJUSTMENT DISTRIBUTIONS'));
          set_item_result(run_stored_sig('AR_PAYMENT_SCHEDULES_ALL'));
     end_section;
   END IF;
END IF;

IF g_type in ('INV','DM','GUAR','DEP','CB','CM') then  
  start_section('XLA Data');
     set_item_result(run_stored_sig('XLA_TRANSACTION_ENTITIES'));
     set_item_result(run_stored_sig('XLA_EVENTS'));
     set_item_result(run_stored_sig('XLA_AE_HEADERS'));
     set_item_result(run_stored_sig('XLA_AE_LINES'));
     set_item_result(run_stored_sig('SLA ACCOUNTS'));
     set_item_result(run_stored_sig('XLA_DISTRIBUTION_LINKS'));
     set_item_result(run_stored_sig('XLA_ACCOUNTING_ERRORS'));
  end_section;
ELSE
  start_section('XLA BR Data');
     set_item_result(run_stored_sig('XLA_TRANSACTION_ENTITIES (BR)'));
     set_item_result(run_stored_sig('XLA_EVENTS (BR)'));
     set_item_result(run_stored_sig('XLA_AE_HEADERS (BR)'));
     set_item_result(run_stored_sig('XLA_AE_LINES (BR)'));
     set_item_result(run_stored_sig('SLA ACCOUNTS (BR)'));
     set_item_result(run_stored_sig('XLA_DISTRIBUTION_LINKS (BR)'));
     set_item_result(run_stored_sig('XLA_ACCOUNTING_ERRORS (BR)'));
  end_section;
END IF;


IF g_includeGL = 'Y' then
   IF g_type in ('INV','DM','GUAR','DEP','CB','CM') then  
      start_section('GL Data');
        set_item_result(run_stored_sig('GL_JE_HEADERS'));
        set_item_result(run_stored_sig('GL_JE_LINES'));
        set_item_result(run_stored_sig('GL_IMPORT_REFERENCES'));
        set_item_result(run_stored_sig('GL PERIODS_STATUSES (GL)'));
        set_item_result(run_stored_sig('GL PERIODS_STATUSES (AR)'));
     end_section;
  ELSE
    start_section('GL Data');
       set_item_result(run_stored_sig('GL_JE_HEADERS (BR)'));
       set_item_result(run_stored_sig('GL_JE_LINES (BR)'));
       set_item_result(run_stored_sig('GL_IMPORT_REFERENCES (BR)'));
       set_item_result(run_stored_sig('GL PERIODS_STATUSES (GL)'));
       set_item_result(run_stored_sig('GL PERIODS_STATUSES (BR)'));
    end_section;
  END IF;
END IF;

IF g_type in ('INV','DM','GUAR','DEP','CB','CM') then  
  start_section('Customer Data');
     set_item_result(run_stored_sig('HZ_CUST_ACCOUNTS_ALL'));
     set_item_result(run_stored_sig('HZ_CUST_ACCT_SITES_ALL'));
     set_item_result(run_stored_sig('HZ_CUST_SITE_USES_ALL'));
     set_item_result(run_stored_sig('HZ_PARTY_SITES'));
     set_item_result(run_stored_sig('HZ_LOCATIONS'));
  end_section;
ELSE
  start_section('Customer Data');
     set_item_result(run_stored_sig('HZ_CUST_ACCOUNTS_ALL (BR)'));
     set_item_result(run_stored_sig('HZ_CUST_ACCT_SITES_ALL (BR)'));
     set_item_result(run_stored_sig('HZ_CUST_SITE_USES_ALL (BR)'));
     set_item_result(run_stored_sig('HZ_PARTY_SITES (BR)'));
     set_item_result(run_stored_sig('HZ_LOCATIONS (BR)'));
  end_section;   
END IF;

  start_section('SLA Setup');
     set_item_result(run_stored_sig('SLAM for Primary Ledger'));
     set_item_result(run_stored_sig('AAD for Primary Ledger'));
     set_item_result(run_stored_sig('MFAR Profile'));
     set_item_result(run_stored_sig('AAD Versions'));
     set_item_result(run_stored_sig('GL TRANSFER PKG VERSION'));
  end_section;
  
  start_section('Data Integrity');
     set_item_result(run_stored_sig('MISSING EVENT_ID (AR_00046)'));
     set_item_result(run_stored_sig('MISSING EVENT_ID FOR CREDIT MEMO APPLICATION ROWS (AR_00045)'));
     set_item_result(run_stored_sig('MISSING PAYMENT SCHEDULE RECORDS (AR_S_00003)'));
     set_item_result(run_stored_sig('DUPLICATE REC ROWS WITH LATEST_REC_FLAG = Y (AR_S_00004)'));
     set_item_result(run_stored_sig('DUPLICATE TAX DISTRIBUTION ROWS (AR_00007/00008)'));
     set_item_result(run_stored_sig('DUPLICATE UNEARN ROWS IN RA_CUST_TX_LINE_GL_DIST_ALL (AR_00122)'));
     set_item_result(run_stored_sig('TRANSACTION ACCTD_AMOUNT INCORRECT (AR_00001)'));
     set_item_result(run_stored_sig('AMOUNTS AND ACCTD_AMOUNT INCORRECTLY POPULATED (AR_00202)'));
     set_item_result(run_stored_sig('UPGRADED INVOICE CANNOT BE APPLIED TO A RECEIPT (AR_00210)'));
     set_item_result(run_stored_sig('POSTED TRANSACTION WITH UNPROCESSED EVENTS IN XLA (AR_00025)'));
     set_item_result(run_stored_sig('CM APPS AR_DIST OUT OF BALANCE(AR_00052)'));
     set_item_result(run_stored_sig('CM DIST WITH AMOUNT = NULL (AR_00307)'));
     set_item_result(run_stored_sig('TRX WITH UNBALANCED ACCOUNTING FOR REV ADJ (AR_00030)'));
     set_item_result(run_stored_sig('TRX DIST WITH ACCTD_AMOUNT = NULL (AR_00014)'));
     set_item_result(run_stored_sig('TRX WITH NEGATIVE EXCHANGE RATE (AR_00322)'));
     set_item_result(run_stored_sig('TABLE AR_DISTRIBUTIONS_ALL SHOWS REF_PREV_CUST_TRX_LINE_ID = NULL (AR_00276)'));
     set_item_result(run_stored_sig('TABLE AR_DISTRIBUTIONS_ALL SHOWS ONE SIDED CM APP ENTRY (AR_00021)'));
     set_item_result(run_stored_sig('DISTRIBUTIONS ARE MISSING OR IMBALANCED IN ARD FOR CM APPLICATIONS (AR_00020)'));
     set_item_result(run_stored_sig('TAX DISTRIBUTIONS ARE PRESENT IN RA_CUSTOMER_TRX_LINES_ALL BUT NOT PRESENT IN GLD (AR_00079)'));
     set_item_result(run_stored_sig('CM UNEARN/REV PAIRS MISSING IN GLD (AR_00199)'));
     set_item_result(run_stored_sig('TAX LINES PRESENT IN ZX NOT IN AR (AR_00104)'));
     set_item_result(run_stored_sig('CM APP MARKED AS POSTED IN XLA NOT IN AR (AR_00323)'));
     set_item_result(run_stored_sig('UNBALANCED UNPOSTED CM APP AGAINST BR (AR_00027)'));
     set_item_result(run_stored_sig('MISSING PREVIOUS_CUSTOMER_TRX_LINE_ID FOR CM TAX LINES (AR_00193)'));
     set_item_result(run_stored_sig('AMOUNT POPULATED AS 0 AND ACCTD_AMOUNT <> O IN ARD FOR CM APPS (AR_00220)'));
     set_item_result(run_stored_sig('EVENTS ARE PRESENT IN OLDER PERIODS WHICH ARE NOT YET POSTED BUT THE PERIODS ARE CLOSED (AR_00105)'));
     set_item_result(run_stored_sig('AMOUNT IS POPULATED AS 0, ACCTD_AMOUNT <> O IN GLD (AR_00264)')); 
     set_item_result(run_stored_sig('TAX ROWS WITH DIFFERENT EVENT_ID IN GLD (AR_00119)')); 
     set_item_result(run_stored_sig('AMOUNT = NULL IN GLD FOR POSTED RECORDS (AR_00117)')); 
     set_item_result(run_stored_sig('UNEARN/REV PAIRS NOT EQUAL TO ACCOUNTING RULE DURATION FOR CM (AR_00200)')); 
     set_item_result(run_stored_sig('INV_UPDATE IS STAMPED AND POSTED IN AR BUT INV_CREATE IS ORPHAN (AR_S_00006)'));
     set_item_result(run_stored_sig('PAYMENT TERM HAS TERMS_SEQUENCE_NUMBER <> 1 (AR_S_00007)'));
     IF (g_invoicing_rule_id is NULL or (g_invoicing_rule_id is not null and g_count <>0))  THEN
        set_item_result(run_stored_sig('ORPHAN RECORDS IN XLA_EVENTS (AR_00057)'));
     END IF;
  end_section;
  
  start_section('File Vesions');
     set_item_result(run_stored_sig('RDBMS Version'));
     set_item_result(run_stored_sig('AR File Versions'));
     set_item_result(run_stored_sig('AR Forms and Reports Versions'));
     set_item_result(run_stored_sig('EBTAX File Versions'));
  end_section;
  
  start_section('Proactive Recommendations');
     set_item_result(check_rec_patches);
     set_item_result(run_stored_sig('INVALIDS'));
     set_item_result(run_stored_sig('XLA INVALIDS'));
     set_item_result(run_stored_sig('EBTAX INVALIDS'));
  end_section;
  
  -- Khaled look here: this is where you add more sections (buttons) and new calls to set_item_result

  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  
  print_out('<a href="https://community.oracle.com/message/13327879" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

-------------------------------------------
-- MAIN ENTRY POINT FOR CONCURRENT PROCESS
-- uncomment to run from concurrent program
-- edit list of variables to match MAIN
-- <package>.main_cp will be what you define program to call
-------------------------------------------
-- PSD #16	
PROCEDURE main_cp (
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_customer_trx_id IN NUMBER   DEFAULT null,
      p_includeGL       in VARCHAR2) IS

BEGIN
  g_retcode := 0;
  g_errbuf := null;

-- PSD #17  
  main(
      p_customer_trx_id => p_customer_trx_id,
      p_includeGL => p_includeGL);

  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


-- PSD #1
END ar_trx_analyzer_pkg;
/
show errors
exit; 
-- Exit required for bundling project so do not remove