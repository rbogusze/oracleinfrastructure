SET DEFINE '~'
WHENEVER SQLERROR EXIT

REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.27                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    om_analyzer.sql                                                      |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |                                                                         |
REM | HISTORY                                                                 |
REM +=========================================================================+

declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,2);
    
 -- Validation to verify analyzer is run on proper e-Business application version
 -- So will fail before package is created
 if apps_version < '12' then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'             ***');
    dbms_output.put_line('*** This Analyzer script must run in version 12 or above    ***');
    dbms_output.put_line('*** Note: the error below is intentional                    ***');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness Version 12 or higher');
 end if;

END;
/

-- PSD #1
CREATE OR REPLACE PACKAGE om_analyzer_pkg AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-- PSD #10

PROCEDURE main 
(            p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')
;

-- PSD #16	  
PROCEDURE main_cp (
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
           ,p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y'
);

-- PSD #1
END om_analyzer_pkg;
/
show errors

-- PSD #1
CREATE OR REPLACE PACKAGE BODY om_analyzer_pkg AS
-- PSD #1a
-- $Id: om_analyzer.sql, 200.3 2015/09/24 11:28:37 CHRISTINE.SCHMEHL Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
-- PSD #15  
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1665244.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;



----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'ONTSO_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'ONTSO_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>ONTSO Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {

  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1665244.1:SCRIPT">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/om_latest_version.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
		 
		 -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
	   -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;

       -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;			
			
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -------------------------------------
  -- Print actions for each signature
  -------------------------------------
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

	-----------------------------------------------------
    -- Print solution part of the action - only if passed
	-----------------------------------------------------
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   ----------------------------------------------
   -- Code for Table of Contents of each section  
   ----------------------------------------------
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF;
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended Patches
-------------------------




-------------------------
-- Signatures
-------------------------


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- 'RSGT1' (RS greater than 1), 'RS' (row selected), 'NRS' (no row selected), '[count(*)] > [0]'
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') -- This is for AT use so internal only. Set to Y if want signature result to be printed at end of output file in DX Summary section
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
-- PSD #5
PROCEDURE validate_parameters(
            p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

IS

  l_revision                  VARCHAR2(25);
  l_date_char                 VARCHAR2(30);
  l_instance                  V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version              FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host                      V$INSTANCE.HOST_NAME%TYPE;
  l_key                       VARCHAR2(255);
  l_system_function_var       VARCHAR2(2000);

  invalid_parameters EXCEPTION;



l_exists_val       VARCHAR2(2000);





BEGIN
 
  -- Determine instance info
  BEGIN

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.3  $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/09/24 11:28:34 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #7
  g_rep_info('File Name') := 'om_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
-- PSD #7b
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1665244.1" target="_blank">(Note 1665244.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------

-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  IF substr(l_apps_version,1,2) < '12' THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script must run in version 12 or above.');
	raise invalid_parameters;
  END IF;
  

  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');


debug('begin parameter validation: p_debug_mode');
IF p_debug_mode IS NOT NULL AND p_debug_mode <> '' AND p_debug_mode NOT IN ( 'Y','N') THEN
   print_error('Debug Mode is invalid.  Valid values are Y or N');
   raise invalid_parameters;
END IF;
debug('end parameter validation: p_debug_mode');





  -- PSD #8
  -- Create global hash for parameters. Numbers required for the output order
debug('begin populate parameters hash table');
   g_parameters('1. Maximum Rows to Display')        := p_max_output_rows;
   g_parameters('2. Debug Mode')                     := p_debug_mode;
debug('end populate parameters hash table');



  l_key := g_parameters.first;
  -- Print parameters to the log
  print_log('Parameter Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_parameters(l_key));
    l_key := g_parameters.next(l_key);
  END LOOP;
  
  -- PSD #8a
  -- Create global hash of SQL token values
debug('begin populate sql tokens hash table');
debug('end populate sql tokens hash table');



  l_key := g_sql_tokens.first;
  -- Print token values to the log

  print_log('SQL Token Values');

  WHILE l_key IS NOT NULL LOOP
    print_log(l_key||': '|| g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;

  -- PSD #7a-end

EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_log('Invalid parameters provided. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_log('Error validating parameters: '||sqlerrm);
    raise;
END validate_parameters;


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN

null;
-- PSD #9
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------




debug('begin add_signature: ATO_PTO_MODEL_LINES_INCORRECT_LINK_PARENT_DETAILS');
  add_signature(
      p_sig_id                 => 'ATO_PTO_MODEL_LINES_INCORRECT_LINK_PARENT_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.item_type_code "ITEM TYPE",
           l.flow_status_code "LINE STATUS",
           l.line_category_code "LINE CATEGORY",
           l.top_model_line_id "TOP MODEL LN",
           l.link_to_line_id "LINK TO LN",
           l.ato_line_id "ATO LN",
           to_char(l.last_update_date, ''DD-MON-RR'') "LAST UPDATE",
           hou.name "OPERATING UNIT"
    FROM oe_order_lines_all l, 
         oe_order_headers_all h, 
         hr_operating_units hou
    WHERE h.last_update_date > (sysdate-730)
    AND h.header_id = l.header_id
    AND h.org_id = hou.organization_id
    AND l.open_flag = ''Y''
    AND l.top_model_line_id is not null
    AND (( l.link_to_line_id is not null 
       and not exists (select 1 from oe_order_lines_all l2 
                     where l2.line_id = l.link_to_line_id)) 
    OR (l.ato_line_id is not null
       and not exists (select 1 from oe_order_lines_all l3 
                     where l3.line_id = l.ato_line_id))
    OR (l.top_model_line_id is not null
       and not exists 
         (select 1 from oe_order_lines_all l4 
              where l4.line_id = l.top_model_line_id)))
    order by l.last_update_date DESC',
      p_title                  => 'ATO or PTO Model Lines with incorrect Link to Parent Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ATO_PTO_MODEL_LINES_INCORRECT_LINK_PARENT_DETAILS');

debug('begin add_signature: ATO_PTO_MODEL_LINES_INCORRECT_LINK_PARENT');
  add_signature(
      p_sig_id                 => 'ATO_PTO_MODEL_LINES_INCORRECT_LINK_PARENT',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_order_lines_all l, 
         oe_order_headers_all h 
    WHERE h.last_update_date > (sysdate-730)
    AND h.header_id = l.header_id
    AND l.open_flag = ''Y''
    AND l.top_model_line_id is not null 
    AND (( l.link_to_line_id is not null 
          and not exists 
         (select 1 from oe_order_lines_all l2 
          where l2.line_id = l.link_to_line_id)) 
    OR ( l.ato_line_id is not null
         and not exists 
         (select 1 from oe_order_lines_all l3 
          where l3.line_id = l.ato_line_id))
    OR(l.top_model_line_id is not null
       and not exists 
       (select 1 from oe_order_lines_all l4 
       where l4.line_id = l.top_model_line_id)))',
      p_title                  => 'ATO or PTO Model Lines with incorrect Link to Parent',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'One or more of the Linking IDs (Top / Link_To / ATO) in each row shown above is broken.  Expand the section below and refer to [378221.1] RMA Line stuck in AWAITING_RETURN or AWAITING_RETURN_DISPOSITION for resolution.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('ATO_PTO_MODEL_LINES_INCORRECT_LINK_PARENT_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: ATO_PTO_MODEL_LINES_INCORRECT_LINK_PARENT');



debug('begin add_signature: COUNT_WORKFLOW_JOBS_DEFERRED_STATUS');
  add_signature(
      p_sig_id                 => 'COUNT_WORKFLOW_JOBS_DEFERRED_STATUS',
      p_sig_sql                => 'SELECT s.item_type "ITEM TYPE",
           process_name "PROCESS",
           instance_label "INSTANCE",
           process_version "VERSION",
           count(*) "DEFERRED ACTIVITIES"
    FROM wf_process_activities p, wf_item_activity_statuses s
    WHERE s.activity_status = ''DEFERRED''
    AND s.item_type in (''OEOH'', ''OEOL'')
    AND s.process_activity = p.instance_id
    group by s.item_type, process_name, instance_label, process_version',
      p_title                  => 'Count of WorkFlow Jobs in Deferred Status',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'This query shows the count of OEOH or OEOL Workflow Activities which are in a Status of DEFERRED.
Review the settings indicated above.  No action is needed as this is only informational.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('I','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: COUNT_WORKFLOW_JOBS_DEFERRED_STATUS');





debug('begin add_signature: FULFILLMENT_STUCK_NO_PENDING_LINES_DETAILS');
  add_signature(
      p_sig_id                 => 'FULFILLMENT_STUCK_NO_PENDING_LINES_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           l.header_id "ORDER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           s.set_name "SET NAME",
           s.set_id "SET ID",
           s.set_type "SET TYPE",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM oe_order_lines_all l, 
         oe_order_headers_all h, 
         oe_line_sets ls,
         oe_sets s, 
         hr_operating_units hou
    WHERE h.header_id = l.header_id
    AND  h.last_update_date > (sysdate-730)
    AND   ls.line_id = l.line_id
    AND   ls.set_id = s.set_id
    AND   h.org_id = hou.organization_id
    AND s.set_type = ''FULFILLMENT_SET''
    AND l.open_flag = ''Y''
    AND l.flow_status_code = ''AWAITING_FULFILLMENT''
    AND not exists (select 1 
                    from oe_order_lines_all l2, oe_line_sets ls2
                    where ls2.set_id  = ls.set_id 
                    and  ls2.line_id  = l2.line_id
                    and  l2.line_id  <> l.line_id
                    and l2.flow_status_code not in 
                    (''AWAITING_FULFILLMENT'', ''CLOSED'', ''CANCELLED'', ''FULFILLED''))
    order by l.last_update_date DESC',
      p_title                  => 'Fulfillment Set stuck, but no Pending Lines Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: FULFILLMENT_STUCK_NO_PENDING_LINES_DETAILS');

debug('begin add_signature: FULFILLMENT_STUCK_NO_PENDING_LINES');
  add_signature(
      p_sig_id                 => 'FULFILLMENT_STUCK_NO_PENDING_LINES',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM   oe_order_lines_all l, wsh_delivery_details wdd
    WHERE l.line_id = wdd.source_line_id  
    AND   l.last_update_date > (sysdate-730)
    AND   wdd.source_code=''OE''  
    AND   nvl(l.arrival_set_id,0) <> nvl(wdd.arrival_set_id,0)  
    AND   nvl(l.model_remnant_flag,''N'')=''Y''',
      p_title                  => 'Fulfillment Set stuck, but no Pending Lines',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('FULFILLMENT_STUCK_NO_PENDING_LINES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: FULFILLMENT_STUCK_NO_PENDING_LINES');





debug('begin add_signature: BOOKED_SO_HEADERS_NONBOOKED_LINES_DETAILS');
  add_signature(
      p_sig_id                 => 'BOOKED_SO_HEADERS_NONBOOKED_LINES_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           oel1.header_id "HEADER ID",
           h.booked_flag "HDR BOOKED",
           oel1.line_number "LINE NUMBER",
           oel1.line_id "LINE ID",
           oel1.booked_flag "LINE BOOKED",
           to_char(h.last_update_date, ''DD-MON-RR'') "LAST UPDATE",
           ou.name "OPERATING UNIT"
    FROM oe_order_headers_all h, 
         oe_order_lines_all oel1, 
         hr_operating_units ou
    WHERE h.open_flag = ''Y''
    AND   h.org_id = ou.organization_id
    AND   h.last_update_date > (sysdate-730)
    AND   h.header_id = oel1.header_id
    AND   oel1.open_flag = ''Y''
    AND   oel1.booked_flag <> h.booked_flag
    order by h.last_update_date DESC',
      p_title                  => 'Booked SO Headers with non-booked Lines Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BOOKED_SO_HEADERS_NONBOOKED_LINES_DETAILS');

debug('begin add_signature: BOOKED_SO_HEADERS_NONBOOKED_LINES');
  add_signature(
      p_sig_id                 => 'BOOKED_SO_HEADERS_NONBOOKED_LINES',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           oel1.header_id "HEADER ID",
           h.booked_flag "HDR BOOKED",
           oel1.line_number "LINE NUMBER",
           oel1.line_id "LINE ID",
           oel1.booked_flag "LINE BOOKED",
           to_char(h.last_update_date, ''DD-MON-RR'') "LAST UPDATE",
           ou.name "OPERATING UNIT"
    FROM oe_order_headers_all h, 
         oe_order_lines_all oel1, 
         hr_operating_units ou
    WHERE h.open_flag = ''Y''
    AND   h.org_id = ou.organization_id
    AND   h.last_update_date > (sysdate-730)
    AND   h.header_id = oel1.header_id
    AND   oel1.open_flag = ''Y''
    AND   oel1.booked_flag <> h.booked_flag
    order by h.last_update_date DESC',
      p_title                  => 'Booked SO Headers with non-booked Lines',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('BOOKED_SO_HEADERS_NONBOOKED_LINES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BOOKED_SO_HEADERS_NONBOOKED_LINES');





debug('begin add_signature: CLOSED_SO_HEADERS_PENDING_WF_ACTIVITY_DETAILS');
  add_signature(
      p_sig_id                 => 'CLOSED_SO_HEADERS_PENDING_WF_ACTIVITY_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           h.header_id "HEADER ID",
           h.open_flag "OPEN FLAG",
           h.cancelled_flag "CANC FLAG",
           h.flow_status_code "STATUS",
           to_char(h.last_update_date, ''DD-MON-RR'') "HDR LAST UPDATED",
              (select count(1) from oe_order_lines_all
               where header_id = h.header_id
               and h.last_update_date > (sysdate-730)
               and open_flag = ''Y'') "NO OF OPEN LINES",
           hou.name "OPERATING UNIT"
    FROM wf_items wi, 
         oe_order_headers_all h, 
         hr_operating_units hou
    WHERE h.org_id               = hou.organization_id
    AND   to_number(wi.item_key) = h.header_id
    AND   wi.END_DATE is null
    AND   wi.item_type = ''OEOH''
    AND   h.open_flag = ''N''
    order by h.last_update_date DESC',
      p_title                  => 'Closed SO Headers With Pending WF Activity Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CLOSED_SO_HEADERS_PENDING_WF_ACTIVITY_DETAILS');

debug('begin add_signature: CLOSED_SO_HEADERS_PENDING_WF_ACTIVITY');
  add_signature(
      p_sig_id                 => 'CLOSED_SO_HEADERS_PENDING_WF_ACTIVITY',
      p_sig_sql                => 'SELECT count(*) "No_of_Headers", 
           to_char(min(h.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(h.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM   wf_items wi,
           oe_order_headers_all h
    WHERE to_number(wi.item_key) = h.header_id
    AND    h.last_update_date > (sysdate-730)
    AND    wi.END_DATE is null
    AND    wi.item_type = ''OEOH''
    AND    h.open_flag = ''N''',
      p_title                  => 'Closed SO Headers With Pending WF Activity',
      p_fail_condition         => '[NO_OF_HEADERS] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CLOSED_SO_HEADERS_PENDING_WF_ACTIVITY_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CLOSED_SO_HEADERS_PENDING_WF_ACTIVITY');





debug('begin add_signature: CANCELLED_DROPSHIP_LINES_OPEN_PO_LINES_DETAILS');
  add_signature(
      p_sig_id                 => 'CANCELLED_DROPSHIP_LINES_OPEN_PO_LINES_DETAILS',
      p_sig_sql                => 'SELECT oeh.order_number "ORDER NO",
           oel1.header_id "HEADER ID",
           oel1.line_number "LINE NO",
           oel1.line_id "LINE ID",
           oel1.item_type_code "ITEM TYPE",
           oel1.flow_status_code "LINE STATUS",
           to_char(oel1.last_update_date, ''DD-MON-RR'') "LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM  oe_order_lines_all oel1,oe_order_headers_all oeh, hr_operating_units hou
    WHERE oeh.last_update_date > (sysdate-730)
    AND    oeh.header_id = oel1.header_id
    AND    oeh.org_id = hou.organization_id
    AND    oel1.source_type_code= ''EXTERNAL''
    AND    nvl(oel1.cancelled_flag,''N'') = ''Y''
    AND    exists ( select ''open po link''
                from   oe_drop_ship_sources oed,po_line_locations_all pol
                where  oed.line_id = oel1.line_id
                and    oed.line_location_id = pol.line_location_id
                and    nvl(cancel_flag,''N'')=''N'')
    order by oel1.last_update_date DESC',
      p_title                  => 'Cancelled Dropship Lines With Open PO Lines Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_DROPSHIP_LINES_OPEN_PO_LINES_DETAILS');

debug('begin add_signature: CANCELLED_DROPSHIP_LINES_OPEN_PO_LINES');
  add_signature(
      p_sig_id                 => 'CANCELLED_DROPSHIP_LINES_OPEN_PO_LINES',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(oel1.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(oel1.last_update_date), ''DD-MON-RR'') "LATEST"        
    FROM oe_order_lines_all oel1
    WHERE oel1.last_update_date > (sysdate-730)
    AND    oel1.source_type_code= ''EXTERNAL''
    AND    nvl(oel1.cancelled_flag,''N'') = ''Y''
    AND    exists ( select ''open po link''
                from   oe_drop_ship_sources oed,po_line_locations_all pol
                where  oed.line_id = oel1.line_id
                and    oed.line_location_id = pol.line_location_id
                and    nvl(cancel_flag,''N'')=''N'')',
      p_title                  => 'Cancelled Dropship Lines With Open PO Lines',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and and refer to 
    [566616.1] How to Diagnose Drop Shipment Process and Interface Between Order Management and Purchasing for resolution.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CANCELLED_DROPSHIP_LINES_OPEN_PO_LINES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_DROPSHIP_LINES_OPEN_PO_LINES');





debug('begin add_signature: CANCELLED_ORDER_LINES_PENDING_DELIVERIES_DETAILS');
  add_signature(
      p_sig_id                 => 'CANCELLED_ORDER_LINES_PENDING_DELIVERIES_DETAILS',
      p_sig_sql                => 'SELECT wdd.source_header_number "ORDER NO",
           wdd.source_header_id "HEADER ID",
           l.line_id "LINE ID",
           l.flow_status_code "LINE STATUS",
           l.open_flag "OPEN",
           l.cancelled_flag "CANCELLED",
           to_char(l.last_update_date, ''DD-MON-RR'') "LAST UPDATED",
           wdd.delivery_detail_id "DEL DTL ID",
           wdd.oe_interfaced_flag "OE INTERF",
           decode (wdd.released_status, 
              ''Y'',''Staged'',
              ''R'',''Ready to Release'',
              ''S'',''Rel to Warehouse'',
              ''B'',''Backorder'',
              ''C'',''Shipped'', wdd.RELEASED_STATUS) "DEL STATUS",
        to_char(wdd.creation_date, ''DD-MON-RR'') "CREATED",
        to_char(wdd.last_update_date, ''DD-MON-RR'') "LAST UPDATED"
    FROM wsh_delivery_details wdd, 
         oe_order_lines_all l
    WHERE l.line_id = wdd.source_line_id
    AND wdd.source_code = ''OE''
    AND wdd.released_status <> ''D''
    AND nvl(l.cancelled_flag, ''N'') = ''Y''
    AND wdd.oe_interfaced_flag in (''N'',''P'') 
    order by l.last_update_date DESC',
      p_title                  => 'Cancelled Order Lines With Pending Deliveries Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_ORDER_LINES_PENDING_DELIVERIES_DETAILS');

debug('begin add_signature: CANCELLED_ORDER_LINES_PENDING_DELIVERIES');
  add_signature(
      p_sig_id                 => 'CANCELLED_ORDER_LINES_PENDING_DELIVERIES',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM wsh_delivery_details wdd, oe_order_lines_all l
    WHERE l.line_id = wdd.source_line_id
    AND wdd.source_code = ''OE''
    AND wdd.released_status <> ''D''
    AND nvl(l.cancelled_flag, ''N'') = ''Y''
    AND wdd.oe_interfaced_flag in (''N'',''P'')',
      p_title                  => 'Cancelled Order Lines With Pending Deliveries',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CANCELLED_ORDER_LINES_PENDING_DELIVERIES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_ORDER_LINES_PENDING_DELIVERIES');





debug('begin add_signature: CLOSED_ORDER_LINES_NOT_ALL_DELIVERY_DETAILS_INTERFACED_DETAILS');
  add_signature(
      p_sig_id                 => 'CLOSED_ORDER_LINES_NOT_ALL_DELIVERY_DETAILS_INTERFACED_DETAILS',
      p_sig_sql                => 'SELECT wdd.source_header_number "ORDER NO",
           wdd.source_header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.flow_status_code "LINE STATUS",
           l.open_flag "OPEN",
           l.cancelled_flag "CANCELLED",
           to_char(l.last_update_date, ''DD-MON-RR'') "LAST UPDATED",
           wdd.delivery_detail_id "DEL DTL ID",
           wdd.oe_interfaced_flag "OE INTERF",
           decode (wdd.released_status, 
                  ''Y'',''Staged'',
                  ''R'',''Ready to Release'',
                  ''S'',''Rel to Warehouse'',
                  ''B'',''Backorder'',
                  ''C'',''Shipped'', wdd.RELEASED_STATUS) "DEL STATUS",
           to_char(wdd.creation_date, ''DD-MON-RR'') "CREATED",
           to_char(wdd.last_update_date, ''DD-MON-RR'') "LAST UPDATED"
    FROM wsh_delivery_details wdd, oe_order_lines_all l
    WHERE l.line_id = wdd.source_line_id
    AND wdd.source_code = ''OE''
    AND nvl(wdd.oe_interfaced_flag, ''N'') in (''N'', ''P'')
    AND wdd.released_status <> ''D''
    AND nvl(l.cancelled_flag, ''N'') = ''N''
    AND l.open_flag = ''N''
    order by l.last_update_date DESC',
      p_title                  => 'Closed Order Lines Where Not All Delivery Details Are Interfaced Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CLOSED_ORDER_LINES_NOT_ALL_DELIVERY_DETAILS_INTERFACED_DETAILS');

debug('begin add_signature: CLOSED_ORDER_LINES_NOT_ALL_DELIVERY_DETAILS_INTERFACED');
  add_signature(
      p_sig_id                 => 'CLOSED_ORDER_LINES_NOT_ALL_DELIVERY_DETAILS_INTERFACED',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM wsh_delivery_details wdd, oe_order_lines_all l
    WHERE l.line_id = wdd.source_line_id
    AND wdd.source_code = ''OE''
    AND nvl(wdd.oe_interfaced_flag, ''N'') in (''N'', ''P'')
    AND wdd.released_status <> ''D''
    AND nvl(l.cancelled_flag, ''N'') = ''N''
    AND l.open_flag = ''N''',
      p_title                  => 'Closed Order Lines Where Not All Delivery Details Are Interfaced',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CLOSED_ORDER_LINES_NOT_ALL_DELIVERY_DETAILS_INTERFACED_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CLOSED_ORDER_LINES_NOT_ALL_DELIVERY_DETAILS_INTERFACED');





debug('begin add_signature: CANCELLED_SO_HEADER_INVALID_OPEN_FLAG_DETAILS');
  add_signature(
      p_sig_id                 => 'CANCELLED_SO_HEADER_INVALID_OPEN_FLAG_DETAILS',
      p_sig_sql                => 'SELECT ooh.order_number "ORDER NO", 
           ooh.header_id "HEADER ID",
           ooh.cancelled_flag "CANCELLED FLAG",
           ooh.open_flag "OPEN FLAG",
           ooh.flow_status_code "FLOW STATUS",
            (select decode(wi.end_date, null, ''PENDING'', ''CLOSED'')
            from wf_items wi where item_type = ''OEOH'' 
            and item_key = to_char(ooh.header_id))  "WF STATUS",
            to_char(ooh.last_update_date, ''DD-MON-RR'') "LAST UPDATE",
            ou.name "OPERATING UNIT"
    FROM oe_order_headers_all ooh, 
         hr_operating_units ou
    WHERE ooh.org_id = ou.organization_id
    AND ooh.last_update_date > (sysdate-730) 
    AND ((nvl(ooh.cancelled_flag,''N'') = ''Y''
    AND (ooh.open_flag  = ''Y'' or ooh.flow_status_code <> ''CANCELLED''))
    OR  (ooh.flow_status_code = ''CANCELLED''
    AND  (nvl(ooh.cancelled_flag,''N'') = ''N'' or ooh.open_flag = ''Y'')))
    order by ooh.last_update_date DESC',
      p_title                  => 'Cancelled SO Headers with invalid Open Flag Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_SO_HEADER_INVALID_OPEN_FLAG_DETAILS');

debug('begin add_signature: CANCELLED_SO_HEADER_INVALID_OPEN_FLAG');
  add_signature(
      p_sig_id                 => 'CANCELLED_SO_HEADER_INVALID_OPEN_FLAG',
      p_sig_sql                => 'SELECT count(*) "NO_OF_HEADERS", 
           to_char(min(ooh.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(ooh.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM   oe_order_headers_all ooh
    WHERE ooh.last_update_date > (sysdate-730)
    AND ((nvl(ooh.cancelled_flag,''N'') = ''Y''
        and (ooh.open_flag  = ''Y''
        or ooh.flow_status_code <> ''CANCELLED''))
        or  (ooh.flow_status_code = ''CANCELLED''
        and  (nvl(ooh.cancelled_flag,''N'')   = ''N''
        or   ooh.open_flag   = ''Y'')))',
      p_title                  => 'Cancelled SO Headers with invalid Open Flag',
      p_fail_condition         => '[NO_OF_HEADERS] > [0]',
      p_problem_descr          => 'Possible problems have been found - please review the Detail Rows above',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CANCELLED_SO_HEADER_INVALID_OPEN_FLAG_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_SO_HEADER_INVALID_OPEN_FLAG');





debug('begin add_signature: CLOSED_SO_LINES_PENDING_WF_ACTIVITY_DETAILS');
  add_signature(
      p_sig_id                 => 'CLOSED_SO_LINES_PENDING_WF_ACTIVITY_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           h.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.open_flag "OPEN FLAG",
           l.cancelled_flag "CANC FLAG",
           l.flow_status_code "STATUS",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM wf_items wi, 
         oe_order_headers_all h, 
         oe_order_lines_all l, 
         hr_operating_units hou
    WHERE h.org_id               = hou.organization_id
    AND   l.last_update_date > (sysdate-730)
    AND   l.header_id = h.header_id
    AND   to_number(wi.item_key) = l.line_id
    AND   wi.END_DATE is null
    AND   wi.item_type = ''OEOL''
    AND   l.open_flag = ''N''
  order by l.last_update_date DESC',
      p_title                  => 'Closed SO Lines With Pending WF Activity Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CLOSED_SO_LINES_PENDING_WF_ACTIVITY_DETAILS');

debug('begin add_signature: CLOSED_SO_LINES_PENDING_WF_ACTIVITY');
  add_signature(
      p_sig_id                 => 'CLOSED_SO_LINES_PENDING_WF_ACTIVITY',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM wf_items wi,
         oe_order_lines_all l
    WHERE to_number(wi.item_key) = l.line_id
    AND wi.END_DATE is null
    AND l.last_update_date > (sysdate-730)
    AND wi.item_type = ''OEOL''
    AND l.open_flag = ''N''',
      p_title                  => 'Closed SO Lines With Pending WF Activity ',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CLOSED_SO_LINES_PENDING_WF_ACTIVITY_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CLOSED_SO_LINES_PENDING_WF_ACTIVITY');





debug('begin add_signature: CANCELLED_MODEL_LINES_NONCANCELLED_CHILDREN_DETAILS');
  add_signature(
      p_sig_id                 => 'CANCELLED_MODEL_LINES_NONCANCELLED_CHILDREN_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.item_type_code "ITEM TYPE",
           l.flow_status_code "LINE STATUS",
           l.cancelled_flag "CANCELLED",
           l.shipping_interfaced_flag "SHIPPING INTERF", 
           to_char(l.last_update_date, ''DD-MON-RR'') "LAST UPDATE",
           hou.name
    FROM oe_order_lines_all l, 
         oe_order_headers_all h, 
         hr_operating_units hou
    WHERE h.last_update_date > (sysdate-730)
    AND h.header_id = l.header_id
    AND h.org_id = hou.organization_id
    AND    l.item_type_code in (''MODEL'',''CLASS'',''KIT'')
    AND    nvl(l.cancelled_flag,''N'') = ''Y''
    AND    exists ( select ''open options exists''
                from   oe_order_lines_all oel2
                where  oel2.top_model_line_id = l.top_model_line_id
                and    nvl(oel2.cancelled_flag,''N'')=''N''
                and    oel2.open_flag = ''Y'')',
      p_title                  => 'Cancelled Model Lines with non-Cancelled Children Details',
      p_fail_condition         => 'RSGT1',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_MODEL_LINES_NONCANCELLED_CHILDREN_DETAILS');

debug('begin add_signature: CANCELLED_MODEL_LINES_NONCANCELLED_CHILDREN');
  add_signature(
      p_sig_id                 => 'CANCELLED_MODEL_LINES_NONCANCELLED_CHILDREN',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM   oe_order_lines_all l 
    WHERE  l.last_update_date > (sysdate-730)
    AND    l.item_type_code in (''MODEL'',''CLASS'', ''KIT'') 
    AND    nvl(l.cancelled_flag,''N'') = ''Y''
    AND    exists ( select ''open options exists''
                from   oe_order_lines_all l2 
                where  l2.top_model_line_id = l.top_model_line_id 
                and    nvl(l2.cancelled_flag,''N'')=''N'')',
      p_title                  => 'Cancelled Model Lines with non-Cancelled Children',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'This query shows the count of ATO or PTO Model Lines which are Cancelled, but where at least one Child Line is not Cancelled''.  Possible problems have been found which may require a datafix. Please expand the section below and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CANCELLED_MODEL_LINES_NONCANCELLED_CHILDREN_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_MODEL_LINES_NONCANCELLED_CHILDREN');





debug('begin add_signature: SHIP_SET_STUCK_ONE_LINE_SHIPPED_ONE_NOT_DETAILS');
  add_signature(
      p_sig_id                 => 'SHIP_SET_STUCK_ONE_LINE_SHIPPED_ONE_NOT_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           l.header_id "ORDER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.item_type_code "SET TYPE",
           l.flow_status_code "STATUS",
           l.ship_set_id "SET ID",
           l.shipped_quantity "SHIPPED QTY",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM oe_order_lines_all l,
         oe_order_headers_all h, 
         hr_operating_units hou
    WHERE h.header_id = l.header_id 
    AND h.org_id = hou.organization_id
    AND l.open_flag = ''Y''
    AND l.last_update_date > (sysdate-730)
    AND l.ship_set_id is not null 
    AND nvl(l.shipped_quantity,0)>0 
    AND exists (select ''Other line in the ship set not yet shipped'' 
        	from oe_order_lines_all oel2 
                where oel2.ship_set_id = l.ship_set_id 
                and nvl(oel2.shipped_quantity,0) = 0)
    order by l.last_update_date DESC',
      p_title                  => 'Ship Set stuck - one Line Shipped, one not Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIP_SET_STUCK_ONE_LINE_SHIPPED_ONE_NOT_DETAILS');

debug('begin add_signature: SHIP_SET_STUCK_ONE_LINE_SHIPPED_ONE_NOT');
  add_signature(
      p_sig_id                 => 'SHIP_SET_STUCK_ONE_LINE_SHIPPED_ONE_NOT',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",  
           to_char(min(oel1.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(oel1.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_order_lines_all oel1,
         oe_order_headers_all oeh 
    WHERE oeh.header_id = oel1.header_id 
    AND oel1.open_flag = ''Y''
    AND oel1.last_update_date > (sysdate-730)
    AND oel1.ship_set_id is not null 
    AND nvl(oel1.shipped_quantity,0)>0 
    AND exists (select ''Other line in the ship set not yet shipped'' 
          	from oe_order_lines_all oel2 
                where oel2.ship_set_id = oel1.ship_set_id 
                and nvl(oel2.shipped_quantity,0) = 0)',
      p_title                  => 'Ship Set stuck - one Line Shipped, one not',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('SHIP_SET_STUCK_ONE_LINE_SHIPPED_ONE_NOT_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIP_SET_STUCK_ONE_LINE_SHIPPED_ONE_NOT');





debug('begin add_signature: DUPLICATED_DROPSHIP_SOURCES_DETAILS');
  add_signature(
      p_sig_id                 => 'DUPLICATED_DROPSHIP_SOURCES_DETAILS',
      p_sig_sql                => 'SELECT drop_ship_source_id "SOURCE ID",
           header_id "HEADER ID",
           line_id "LINE ID",
           org_id "ORG ID",
           po_header_id "PO HEADER ID",
           po_line_id "PO LINE ID",
           line_location_id "LINE LOC ID",
           po_release_id  "PO RELEASE ID",
           last_update_date "LAST UPDATED"
    FROM    oe_drop_ship_sources ods1
    WHERE   drop_ship_source_id in (
         SELECT ods.DROP_SHIP_SOURCE_ID
         FROM  OE_DROP_SHIP_SOURCES ods     
         GROUP BY ods.DROP_SHIP_SOURCE_ID
         HAVING count(*) > 1)
order by ods1.last_update_date DESC',
      p_title                  => 'Duplicated Dropship Sources Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DUPLICATED_DROPSHIP_SOURCES_DETAILS');

debug('begin add_signature: DUPLICATED_DROPSHIP_SOURCES');
  add_signature(
      p_sig_id                 => 'DUPLICATED_DROPSHIP_SOURCES',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",
           to_char(min(ods1.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(ods1.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_drop_ship_sources ods1
    WHERE   ods1.last_update_date > (sysdate-730)
    AND     drop_ship_source_id in (
         SELECT ods.DROP_SHIP_SOURCE_ID
         FROM  OE_DROP_SHIP_SOURCES ods     
         GROUP BY ods.DROP_SHIP_SOURCE_ID
         HAVING count(*) > 1)',
      p_title                  => 'Duplicated Dropship Sources',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and and refer to 
   Note ID [739699.1] Unable To Update Schedule Date For Dropship Lines: error ORA-01422 for additional diagnostics.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('DUPLICATED_DROPSHIP_SOURCES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DUPLICATED_DROPSHIP_SOURCES');



debug('begin add_signature: COUNT_WORKFLOW_JOBS_ERRORED_STATUS');
  add_signature(
      p_sig_id                 => 'COUNT_WORKFLOW_JOBS_ERRORED_STATUS',
      p_sig_sql                => 'SELECT s.item_type "ITEM TYPE",
           s.activity_result_code "RESULT CODE",
           p.process_name "PROCESS",
           p.instance_label "INSTANCE",
           p.process_version "VERSIONS",
           count(*) "ERRORED ACTIVITIES"
    FROM wf_process_activities p, wf_item_activity_statuses s
    WHERE s.activity_status = ''ERROR'' 
    AND s.item_type in (''OEOH'', ''OEOL'', ''OMERROR'', ''OEOI'', ''OECOGS'', ''OEOA'', ''OECHGORD'', ''OEBH'', ''OENH'')
    AND s.process_activity = p.instance_id
    group by s.item_type, s.activity_result_code, p.process_name, p.instance_label, p.process_version',
      p_title                  => 'Count of WorkFlow Jobs in Errored Status ',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'This query shows the count of OE Workflow Activities which are in a Status of ERROR.  Please see [255045.1] for tips on reviewing WF Errors.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('E','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: COUNT_WORKFLOW_JOBS_ERRORED_STATUS');





debug('begin add_signature: CANCELLED_CLOSED_SO_HEADERS_OPEN_LINES_DETAILS');
  add_signature(
      p_sig_id                 => 'CANCELLED_CLOSED_SO_HEADERS_OPEN_LINES_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           h.header_id "HEADER ID",
           h.cancelled_flag "HDR CANC FLAG",
           h.open_flag "HDR OPEN FLAG",
           h.flow_status_code "HDR FLOW STATUS",
           to_char(h.last_update_date, ''DD-MON-RR'') "HDR LAST UPDATE",
           l.line_number "LINE NUMBER",
           l.line_id "LINE ID",
           l.cancelled_flag "LINE CANC FLAG",
           l.open_flag "LINE OPEN FLAG",
           l.flow_status_code "LINE FLOW STATUS",
           ou.name "OPERATING UNIT"
    FROM oe_order_headers_all h, 
         oe_order_lines_all l, 
        hr_operating_units ou
    WHERE h.last_update_date > (sysdate-730)
    AND   l.header_id = h.header_id
    AND   h.org_id = ou.organization_id
    AND   h.open_flag = ''N''
    AND   l.open_flag = ''Y''
    order by h.last_update_date DESC',
      p_title                  => 'Cancelled or Closed SO Headers with Open Lines Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_CLOSED_SO_HEADERS_OPEN_LINES_DETAILS');

debug('begin add_signature: CANCELLED_CLOSED_SO_HEADERS_OPEN_LINES');
  add_signature(
      p_sig_id                 => 'CANCELLED_CLOSED_SO_HEADERS_OPEN_LINES',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(h.last_update_date), ''DD-MON-RR'') "EARLIEST", 
           to_char(max(h.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_order_headers_all h, 
         oe_order_lines_all l
    WHERE h.last_update_date > (sysdate-730)
    AND h.header_id = l.header_id
    AND h.open_flag = ''N'' and l.open_flag = ''Y''',
      p_title                  => 'Cancelled or Closed SO Headers with Open Lines Details',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'This check has found one or more hits, but SO Lines owned by a Closed SO Header can still be processed.  Please use the Show Detail Rows button (above) to see the details.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CANCELLED_CLOSED_SO_HEADERS_OPEN_LINES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_CLOSED_SO_HEADERS_OPEN_LINES');





debug('begin add_signature: SALES_ORDER_LINES_MULTIPLE_DROPSHIP_SOURCES_DETAILS');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_MULTIPLE_DROPSHIP_SOURCES_DETAILS',
      p_sig_sql                => 'SELECT OEH.ORDER_NUMBER "ORDER NUMBER", 
           OEH.HEADER_ID "HEADER ID",
           OEL.LINE_NUMBER "LINE NUMBER",
           OED.LINE_ID "LINE ID",
           to_char(oel.creation_date, ''DD-MON-RR'') "LINE CREATED",
           REQ.SEGMENT1 "REQN NUMBER",
           POH.SEGMENT1 "PO NUMBER",
           OEH.ORDERED_DATE "ORDERED DATE",
           hou.name "OPERATING UNIT"
      FROM  OE_DROP_SHIP_SOURCES  OED,    
            OE_ORDER_HEADERS_ALL OEH, 
            PO_HEADERS_ALL POH,           
            PO_REQUISITION_HEADERS_ALL REQ, 
            OE_ORDER_LINES_ALL OEL,       
            hr_operating_units hou 
      where OEH.last_update_date > (sysdate-730)
            AND OED.LINE_ID = OEL.LINE_ID 
            AND OED.HEADER_ID = OEL.HEADER_ID 
            AND OEH.HEADER_ID = OEL.HEADER_ID 
            AND OED.REQUISITION_HEADER_ID = REQ.REQUISITION_HEADER_ID 
            AND OED.PO_HEADER_ID = POH.PO_HEADER_ID 
            and oeh.org_id = hou.organization_id
            AND OEL.OPEN_FLAG    = ''Y''
       	    AND Nvl(OEL.shipped_quantity,0) = 0 
            AND exists 
            (   SELECT   1 
                FROM     oe_drop_ship_sources ods1            
                where ods1.line_id = oed.line_id 
                GROUP BY ods1.line_id  
                HAVING   count(*) > 1 )
            order by oel.creation_date DESC',
      p_title                  => 'Sales Order Lines with Multiple Dropship Sources Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_MULTIPLE_DROPSHIP_SOURCES_DETAILS');

debug('begin add_signature: SALES_ORDER_LINES_MULTIPLE_DROPSHIP_SOURCES');
  add_signature(
      p_sig_id                 => 'SALES_ORDER_LINES_MULTIPLE_DROPSHIP_SOURCES',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(oel.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(oel.creation_date), ''DD-MON-RR'') "LATEST"
    FROM  OE_DROP_SHIP_SOURCES  OED,  
          OE_ORDER_HEADERS_ALL OEH, 
          OE_ORDER_LINES_ALL OEL
    WHERE OEH.last_update_date > (sysdate-730)
            AND OED.LINE_ID = OEL.LINE_ID 
            AND OED.HEADER_ID = OEL.HEADER_ID 
            AND OEH.HEADER_ID = OEL.HEADER_ID 
            AND OEL.OPEN_FLAG    = ''Y''
       	    AND Nvl(OEL.shipped_quantity,0) = 0 
            AND exists 
            (   SELECT   1 
                FROM     oe_drop_ship_sources ods1            
                where ods1.line_id = oed.line_id 
                GROUP BY ods1.line_id  
                HAVING   count(*) > 1 )',
      p_title                  => 'ales Order Lines with Multiple Dropship Sources',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and and refer to 
    [566616.1] How to Diagnose Drop Shipment Process and Interface Between Order Management and Purchasing for resolution.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('SALES_ORDER_LINES_MULTIPLE_DROPSHIP_SOURCES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SALES_ORDER_LINES_MULTIPLE_DROPSHIP_SOURCES');





debug('begin add_signature: MODEL_COMPONENTS_REMANTS_NOT_FLAGGED_DETAILS');
  add_signature(
      p_sig_id                 => 'MODEL_COMPONENTS_REMANTS_NOT_FLAGGED_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.item_type_code "ITEM TYPE",
           l.model_remnant_flag "REMNANT",
           l.top_model_line_id "TOP MODEL LINE",
           l.shipping_interfaced_flag "SHIPPING INTERF",
           to_char(l.creation_date, ''DD-MON-RR'') "CREATED",
           to_char(l.last_update_date, ''DD-MON-RR'') "LAST UPDATE",
           hou.name "OPERATING UNIT"
    FROM oe_order_lines_all l, 
         oe_order_headers_all h, 
         hr_operating_units hou
    WHERE h.last_update_date > (sysdate-730)
    AND h.header_id = l.header_id
    AND h.org_id = hou.organization_id
    AND    l.open_flag = ''Y''
    AND    nvl(l.shipped_quantity,0) = 0
    AND    nvl(l.cancelled_quantity,0) = 0
    AND    nvl(l.model_remnant_flag,''N'')=''N''
    AND    l.top_model_line_id IS NOT NULL
    AND    exists ( select ''Other component already shipped''
                from   oe_order_lines_all oel2
                where  oel2.top_model_line_id = l.top_model_line_id
                and    nvl(oel2.shipped_quantity,0) > 0
                and    nvl(oel2.cancelled_quantity,0) = 0
                and    nvl(oel2.model_remnant_flag,''N'') = ''N'')
    order by l.last_update_date DESC',
      p_title                  => 'Model Components which are Remnants, but not Flagged Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: MODEL_COMPONENTS_REMANTS_NOT_FLAGGED_DETAILS');

debug('begin add_signature: MODEL_COMPONENTS_REMANTS_NOT_FLAGGED');
  add_signature(
      p_sig_id                 => 'MODEL_COMPONENTS_REMANTS_NOT_FLAGGED',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",
           to_char(min(oel1.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(oel1.last_update_date), ''DD-MON-RR'') "LATEST"        
    FROM   oe_order_lines_all oel1
    WHERE  oel1.last_update_date > (sysdate-730)
    AND    oel1.open_flag = ''Y''
    AND    nvl(oel1.shipped_quantity,0) = 0
    AND    nvl(oel1.cancelled_quantity,0) = 0
    AND    nvl(oel1.model_remnant_flag,''N'')=''N''
    AND    oel1.top_model_line_id IS NOT NULL
    AND    exists ( select ''Other component already shipped''
                from   oe_order_lines_all oel2
                where  oel2.top_model_line_id = oel1.top_model_line_id
                and    nvl(oel2.shipped_quantity,0) > 0
                and    nvl(oel2.cancelled_quantity,0) = 0
                and    nvl(oel2.model_remnant_flag,''N'') = ''N'')',
      p_title                  => 'Model Components which are Remnants, but not Flagged',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('MODEL_COMPONENTS_REMANTS_NOT_FLAGGED_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: MODEL_COMPONENTS_REMANTS_NOT_FLAGGED');





debug('begin add_signature: OPEN_ORDER_LINES_DELIVERY_DETAILS_MISSING_DETAILS');
  add_signature(
      p_sig_id                 => 'OPEN_ORDER_LINES_DELIVERY_DETAILS_MISSING_DETAILS',
      p_sig_sql                => 'SELECT nvl((to_char(oeh.order_number)), ''** Missing Record **'') "ORDER ID",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.item_type_code "ITEM TYPE",
           l.flow_status_code "LINE STATUS",
           l.open_flag "OPEN",
           l.cancelled_flag "CANCELLED",
           to_char(l.creation_date, ''DD-MON-RR'') "CREATED",
           to_char(l.last_update_date, ''DD-MON-RR'') "LAST UPDATED"
    FROM   oe_order_lines_all l,
           oe_order_headers_all oeh
    WHERE  oeh.header_id (+) = l.header_id
    AND    l.open_flag = ''Y''
    AND    nvl(l.shipping_interfaced_flag,''N'')=''Y''
    AND    not exists (select ''associated delivery''
                   from   wsh_delivery_details wsh
                   where  wsh.source_line_id = l.line_id
                   and    wsh.source_code = ''OE'')
    order by l.last_update_date DESC',
      p_title                  => 'Open Order Lines Where Delivery Details Are Missing Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_ORDER_LINES_DELIVERY_DETAILS_MISSING_DETAILS');

debug('begin add_signature: OPEN_ORDER_LINES_DELIVERY_DETAILS_MISSING');
  add_signature(
      p_sig_id                 => 'OPEN_ORDER_LINES_DELIVERY_DETAILS_MISSING',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(l.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.creation_date), ''DD-MON-RR'') "LATEST"
    FROM   oe_order_lines_all l
    WHERE  l.open_flag = ''Y''
    AND    nvl(l.shipping_interfaced_flag,''N'')=''Y''
    AND    not exists (select ''x''
                   from   wsh_delivery_details wsh
                   where  wsh.source_line_id = l.line_id
                   and    wsh.source_code = ''OE'')',
      p_title                  => 'Open Order Lines Where Delivery Details Are Missing ',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('OPEN_ORDER_LINES_DELIVERY_DETAILS_MISSING_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_ORDER_LINES_DELIVERY_DETAILS_MISSING');



debug('begin add_signature: WORKFLOW_ITEMS_PASSED_PURGE_DATE');
  add_signature(
      p_sig_id                 => 'WORKFLOW_ITEMS_PASSED_PURGE_DATE',
      p_sig_sql                => 'SELECT WI.ITEM_TYPE,count(*) 
    FROM   WF_ITEMS WI
    WHERE WI.ITEM_TYPE IN (''OEOH'', ''OEOL'', ''OMERROR'', ''OEOI'', ''OECOGS'', ''OEOA'', ''OECHGORD'', ''OEBH'', ''OENH'') 
    AND exists
        (select null
         from WF_ITEM_TYPES WIT
         where WI.END_DATE+nvl(WIT.PERSISTENCE_DAYS,0)<=sysdate
         and WI.ITEM_TYPE = WIT.NAME
         and WIT.PERSISTENCE_TYPE = ''##$$PERSISTENCE_TYPE$$##'')
    AND WI.END_DATE is NOT NULL
    AND NOT EXISTS          
        (SELECT null  
          FROM WF_ITEMS WI2
          WHERE WI2.END_DATE IS NULL
          START WITH WI2.ITEM_TYPE = wi.item_type
          AND WI2.ITEM_KEY         =  wi.item_key
          CONNECT BY PRIOR WI2.ITEM_TYPE = WI2.PARENT_ITEM_TYPE
          AND PRIOR WI2.ITEM_KEY = WI2.PARENT_ITEM_KEY)
    AND NOT EXISTS       
          (SELECT null
           FROM WF_ITEMS WI3
           WHERE WI3.END_DATE IS NULL
           START WITH WI3.ITEM_TYPE = wi.item_type
           AND WI3.ITEM_KEY         = wi.item_key
           CONNECT BY PRIOR  WI3.PARENT_ITEM_TYPE = WI3.ITEM_TYPE
           AND PRIOR  WI3.PARENT_ITEM_KEY = WI3.ITEM_KEY )
    GROUP BY wi.item_type',
      p_title                  => 'WorkFlow Items Which Have passed Their Purge Date',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Workflow Items shown are ready for Purge.  Refer to [878032.1] for additional information / solutions.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: WORKFLOW_ITEMS_PASSED_PURGE_DATE');





debug('begin add_signature: OPEN_SO_HEADERS_WF_FLOW_MISSING_CLOSED_DETAILS');
  add_signature(
      p_sig_id                 => 'OPEN_SO_HEADERS_WF_FLOW_MISSING_CLOSED_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           h.header_id "HEADER ID",
           h.open_flag "OPEN FLAG",
           h.cancelled_flag "CANC FLAG",
           h.flow_status_code "STATUS",
           to_char(h.last_update_date, ''DD-MON-RR'') "LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM oe_order_headers_all h, hr_operating_units hou
    WHEREe h.org_id               = hou.organization_id
    AND h.open_flag = ''Y''
    AND h.last_update_date > (sysdate-730)
    AND nvl(h.cancelled_flag, ''N'') = ''N''
    AND not exists (select ''WF is pending'' from wf_items wi   
                    where to_number(wi.item_key) = h.header_id
                    and wi.item_type = ''OEOH''
                    and wi.END_DATE is null)
    AND nvl(h.transaction_phase_code, ''F'') = ''F''
    order by h.last_update_date DESC',
      p_title                  => 'Open SO Headers Where WF Flow is Missing or Closed Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_HEADERS_WF_FLOW_MISSING_CLOSED_DETAILS');

debug('begin add_signature: OPEN_SO_HEADERS_WF_FLOW_MISSING_CLOSED');
  add_signature(
      p_sig_id                 => 'OPEN_SO_HEADERS_WF_FLOW_MISSING_CLOSED',
      p_sig_sql                => 'SELECT count(*) "No_of_Headers",
           h.flow_status_code "HEADER STATUS",
           to_char(min(h.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(h.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_order_headers_all h
    WHERE h.open_flag = ''Y''
    AND h.last_update_date > (sysdate-730)
    AND nvl(h.cancelled_flag, ''N'') = ''N''
    AND not exists (select ''WF is pending'' 
                    from  wf_items wi
                    where to_number(wi.item_key) = h.header_id
                    and wi.item_type = ''OEOH''
                    and wi.end_date is null)
    AND nvl(h.transaction_phase_code, ''F'') = ''F''
    group by h.flow_status_code',
      p_title                  => 'Open SO Headers Where WF Flow is Missing or Closed',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('OPEN_SO_HEADERS_WF_FLOW_MISSING_CLOSED_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_HEADERS_WF_FLOW_MISSING_CLOSED');





debug('begin add_signature: RELEASED_DELIVERY_DETAILS_MOVE_ORDER_CLOSED_DETAILS');
  add_signature(
      p_sig_id                 => 'RELEASED_DELIVERY_DETAILS_MOVE_ORDER_CLOSED_DETAILS',
      p_sig_sql                => 'SELECT wdd.source_header_number "ORDER NO",
           wdd.delivery_detail_id "DEL DTL ID",
           wdd.move_order_line_id "MO LINE ID",
           to_char(mtrl.last_update_date, ''DD-MON-RR'') "MO LAST UPDATE",
           to_char(wdd.creation_date, ''DD-MON-RR'') "DEL DTL CREATED",
           to_char(wdd.last_update_date, ''DD-MON-RR'') "DEL DTL LAST UPDATED"
    FROM  wsh_delivery_details wdd,
          mtl_txn_request_lines mtrl
    WHERE  wdd.source_code = ''OE''
    AND    wdd.released_status = ''S''
    AND    wdd.move_order_line_id = mtrl.line_id
    AND    mtrl.line_status = 5
    order by wdd.last_update_date DESC',
      p_title                  => 'Released Delivery Details where Move Order is Closed Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: RELEASED_DELIVERY_DETAILS_MOVE_ORDER_CLOSED_DETAILS');

debug('begin add_signature: RELEASED_DELIVERY_DETAILS_MOVE_ORDER_CLOSED');
  add_signature(
      p_sig_id                 => 'RELEASED_DELIVERY_DETAILS_MOVE_ORDER_CLOSED',
      p_sig_sql                => 'SELECT count(*) "No_of_Del_Dtls",  
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM   wsh_delivery_details wdd, mtl_txn_request_lines mtrl
    WHERE  wdd.source_code = ''OE''
    AND    wdd.released_status = ''S''
    AND    wdd.move_order_line_id = mtrl.line_id
    AND    mtrl.line_status = 5',
      p_title                  => 'Released Delivery Details where Move Order is Closed',
      p_fail_condition         => '[No_of_Del_Dtls] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('RELEASED_DELIVERY_DETAILS_MOVE_ORDER_CLOSED_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: RELEASED_DELIVERY_DETAILS_MOVE_ORDER_CLOSED');





debug('begin add_signature: CANCELLED_SO_LINES_INVALID_OPEN_FLAG_DETAILS');
  add_signature(
      p_sig_id                 => 'CANCELLED_SO_LINES_INVALID_OPEN_FLAG_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO", 
           oel1.header_id "HEADER ID",
           oel1.line_number "LINE NUMBER",
           oel1.line_id "LINE ID",
           oel1.cancelled_flag "CANCELLED FLAG",
           oel1.open_flag "OPEN FLAG",
           oel1.flow_status_code "FLOW STATUS",
             (select decode(wi.end_date, null, ''PENDING'', ''CLOSED'')
              from wf_items wi where item_type = ''OEOL'' 
              and item_key = to_char(oel1.line_id)) "WF STATUS",
            (select count(1) from wsh_delivery_details dd
             where dd.source_line_id = oel1.line_id
              and dd.source_code = ''OE''
              and released_status not in (''D'', ''X'')) "No of Del Dtls",
          to_char(oel1.last_update_date, ''DD-MON-RR'') "LAST UPDATE",
          ou.name "OPERATING UNIT"
    FROM oe_order_lines_all oel1, 
         oe_order_headers_all h, 
         hr_operating_units ou
    WHERE oel1.last_update_date > (sysdate-730)
    AND (oel1.open_flag = ''Y'' and nvl(oel1.cancelled_flag,''N'') =''Y'') 
    AND oel1.header_id = h.header_id
    AND h.org_id = ou.organization_id
    order by oel1.last_update_date DESC',
      p_title                  => 'Cancelled SO Lines with invalid Open Flag Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_SO_LINES_INVALID_OPEN_FLAG_DETAILS');

debug('begin add_signature: CANCELLED_SO_LINES_INVALID_OPEN_FLAG');
  add_signature(
      p_sig_id                 => 'CANCELLED_SO_LINES_INVALID_OPEN_FLAG',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(last_update_date), ''DD-MON-RR'') "EARLIEST", 
           to_char(max(last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_order_lines_all l
    WHERE l.last_update_date > (sysdate-730)
    AND l.open_flag = ''Y'' and nvl(l.cancelled_flag,''N'') =''Y''',
      p_title                  => 'Cancelled SO Lines with invalid Open Flag',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found - please review the Detail Rows above.
   If the reported rows are current, please check for errors in the Workflow for the Cancel activity.  
   Verify actual error via output of HTMomse12i Note Id [133464.1] of the order(s).',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('CANCELLED_SO_LINES_INVALID_OPEN_FLAG_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: CANCELLED_SO_LINES_INVALID_OPEN_FLAG');





debug('begin add_signature: BOOKED_DROPSHIP_LINES_NULL_SCHEDULED_SHIP_DATE_DETAILS');
  add_signature(
      p_sig_id                 => 'BOOKED_DROPSHIP_LINES_NULL_SCHEDULED_SHIP_DATE_DETAILS',
      p_sig_sql                => 'SELECT oeh.order_number "ORDER NO",
           oel1.header_id "HEADER ID",
           oel1.line_number "LINE NO",
           oel1.line_id "LINE ID",
           oel1.item_type_code "ITEM TYPE",
           oel1.flow_status_code "LINE STATUS",
           to_char(oel1.last_update_date, ''DD-MON-RR'') "LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM   oe_order_lines_all oel1,
           oe_order_headers_all oeh, 
           hr_operating_units hou
    WHERE  oeh.last_update_date > (sysdate-730)
    AND    oeh.header_id = oel1.header_id
    AND    oeh.org_id = hou.organization_id
    AND    oel1.open_flag = ''Y''
    AND    oel1.source_type_code=''EXTERNAL''
    AND    oel1.flow_status_code = ''AWAITING_RECEIPT''
    AND    oel1.schedule_ship_date is null
    order by oel1.last_update_date DESC',
      p_title                  => 'Booked Dropship Lines With Null Scheduled Ship Date Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BOOKED_DROPSHIP_LINES_NULL_SCHEDULED_SHIP_DATE_DETAILS');

debug('begin add_signature: BOOKED_DROPSHIP_LINES_NULL_SCHEDULED_SHIP_DATE');
  add_signature(
      p_sig_id                 => 'BOOKED_DROPSHIP_LINES_NULL_SCHEDULED_SHIP_DATE',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",  
           to_char(min(oel1.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(oel1.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM   oe_order_lines_all oel1
    WHERE  oel1.open_flag = ''Y''
    AND    oel1.last_update_date > (sysdate-730)
    AND    oel1.source_type_code=''EXTERNAL''
    AND    oel1.flow_status_code = ''AWAITING_RECEIPT''
    AND    oel1.schedule_ship_date is null',
      p_title                  => 'Booked Dropship Lines With Null Scheduled Ship Date',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and and refer to 
    [566616.1] How to Diagnose Drop Shipment Process and Interface Between Order Management and Purchasing for resolution.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('BOOKED_DROPSHIP_LINES_NULL_SCHEDULED_SHIP_DATE_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: BOOKED_DROPSHIP_LINES_NULL_SCHEDULED_SHIP_DATE');





debug('begin add_signature: OPEN_SO_LINES_WF_FLOW_MISSING_CLOSED_DETAILS');
  add_signature(
      p_sig_id                 => 'OPEN_SO_LINES_WF_FLOW_MISSING_CLOSED_DETAILS',
      p_sig_sql                => 'SELECT nvl(to_char(h.order_number), ''** Missing Record **'') "ORDER NO",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.open_flag "OPEN",
           l.booked_flag "BOOKED",
           l.fulfilled_flag "FULFILLED",
           l.flow_status_code "STATUS",
           to_char(h.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM oe_order_headers_all h, 
         oe_order_lines_all l, 
         hr_operating_units hou
    WHERE l.header_id = h.header_id(+)
    AND   l.org_id               = hou.organization_id
    AND   l.open_flag = ''Y''
    AND   l.last_update_date > (sysdate-730)
    AND nvl(l.cancelled_flag, ''N'') = ''N''
    AND not exists (select ''WF is pending'' from wf_items wi
                where to_number(wi.item_key) = l.line_id
                  and wi.item_type = ''OEOL''
                  and wi.END_DATE is null)
    AND nvl(l.transaction_phase_code, ''F'') = ''F''
    order by h.last_update_date DESC',
      p_title                  => 'Open SO Lines Where WF Flow is Missing or Closed Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_LINES_WF_FLOW_MISSING_CLOSED_DETAILS');

debug('begin add_signature: OPEN_SO_LINES_WF_FLOW_MISSING_CLOSED');
  add_signature(
      p_sig_id                 => 'OPEN_SO_LINES_WF_FLOW_MISSING_CLOSED',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           l.flow_status_code "LINE STATUS",
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_order_lines_all l
    WHERE l.open_flag = ''Y''
    AND l.last_update_date > (sysdate-730)
    AND nvl(l.cancelled_flag, ''N'') = ''N''
    AND not exists (select ''WF is pending'' from
                     wf_items wi
                     where to_number(wi.item_key) = l.line_id
                    and wi.item_type = ''OEOL''
                    and wi.end_date is null)
    AND nvl(l.transaction_phase_code, ''F'') = ''F''
    group by l.flow_status_code',
      p_title                  => 'Open SO Lines Where WF Flow is Missing or Closed',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('OPEN_SO_LINES_WF_FLOW_MISSING_CLOSED_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_LINES_WF_FLOW_MISSING_CLOSED');





debug('begin add_signature: MODELS_STATUS_CREATE_CONFIG_ITEM_EXISTS_DETAILS');
  add_signature(
      p_sig_id                 => 'MODELS_STATUS_CREATE_CONFIG_ITEM_EXISTS_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.item_type_code "ITEM TYPE",
           l.flow_status_code "STATUS",
           l.ato_line_id "ATO LINE ID",
           to_char(l.last_update_date, ''DD-MON-RR'') "LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM oe_order_lines_all l, 
         oe_order_headers_all h, 
         hr_operating_units hou
    WHERE h.last_update_date > (sysdate-730)
    AND h.header_id (+) = l.header_id
    AND l.org_id = hou.organization_id
    AND   l.open_flag = ''Y''
    AND   l.item_type_code = ''MODEL''
    AND   l.line_category_code = ''ORDER''
    AND   l.ato_line_id is not null
    AND   exists ( select 1 from oe_order_lines_all l2
               where l2.ato_line_id = l.line_id
			   and nvl(l2.cancelled_flag, ''N'') = ''N''
			   and l2.item_type_code = ''CONFIG'')
    AND not exists ( select ''Exist''
                 from wf_item_activity_statuses was
				 , wf_process_activities wpa
				 where was.item_type = ''OEOL''
				 and   was.item_key = to_char(l.line_id)
				 and   wpa.activity_item_type = was.item_type
				 and   wpa.activity_name = ''CREATE_CONFIG_ITEM''
				 and   wpa.instance_id  = was.process_activity
				 and   was.activity_status = ''COMPLETE''
				 and   was.activity_result_code = ''COMPLETE'')
    order by l.last_update_date DESC',
      p_title                  => 'Models in Status Create Config, but Config Item Exists Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: MODELS_STATUS_CREATE_CONFIG_ITEM_EXISTS_DETAILS');

debug('begin add_signature: MODELS_STATUS_CREATE_CONFIG_ITEM_EXISTS');
  add_signature(
      p_sig_id                 => 'MODELS_STATUS_CREATE_CONFIG_ITEM_EXISTS',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_order_lines_all l
    WHERE l.last_update_date > (sysdate-730)
    AND l.open_flag = ''Y''
    AND   l.item_type_code = ''MODEL''
    AND   l.line_category_code = ''ORDER''
    AND   l.ato_line_id is not null
    AND   exists ( select 1 from oe_order_lines_all l2
               where l2.ato_line_id = l.line_id
			   and nvl(l2.cancelled_flag, ''N'') = ''N''
			   and l2.item_type_code = ''CONFIG'')
    AND not exists ( select ''Exist'' 
                 from wf_item_activity_statuses was,
                      wf_process_activities wpa
				 where was.item_type = ''OEOL''
				 and   was.item_key = to_char(l.line_id)
				 and   wpa.activity_item_type = was.item_type
				 and   wpa.activity_name = ''CREATE_CONFIG_ITEM''
				 and   wpa.instance_id  = was.process_activity
				 and   was.activity_status = ''COMPLETE''
				 and   was.activity_result_code = ''COMPLETE'')',
      p_title                  => 'Models in Status Create Config, but Config Item Exists',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('MODELS_STATUS_CREATE_CONFIG_ITEM_EXISTS_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: MODELS_STATUS_CREATE_CONFIG_ITEM_EXISTS');





debug('begin add_signature: SO_LINE_DELIVERY_DETAIL_SCHEDULED_DATE_MISMATCH_DETAILS');
  add_signature(
      p_sig_id                 => 'SO_LINE_DELIVERY_DETAIL_SCHEDULED_DATE_MISMATCH_DETAILS',
      p_sig_sql                => 'SELECT oeh.order_number "ORDER NO",
           oel1.header_id "ORDER ID",
           oel1.line_number "LINE NO",
           oel1.line_id "LINE ID",
           oel1.item_type_code "ITEM TYPE",
           substr(oel1.flow_status_code,1,25) "LINE STATUS",
           oel1.shipping_interfaced_flag "LINE INTERF",
           to_char(oel1.schedule_ship_date,''DD-MON-RR HH24:MI:SS'') "LINE SCHED",
           to_char(wsh.date_scheduled,''DD-MON-RR HH24:MI:SS'') "DEL DTL SCHED",
           to_char(oel1.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATED",
           to_char(wsh.last_update_date, ''DD-MON-RR'') "DEL DTL LAST UPDATED",
           ou.name "OPERATING UNIT"
    FROM   wsh_delivery_details wsh,
           oe_order_lines_all oel1,
           oe_order_headers_all oeh, 
           hr_operating_units ou
    WHERE  oeh.header_id = oel1.header_id
    AND    oel1.org_id = ou.organization_id
    AND    oel1.open_flag = ''Y''
    AND    nvl(oel1.cancelled_quantity,0)=0
    AND    nvl(oel1.shipping_interfaced_flag,''Y'')=''Y''
    AND    wsh.source_line_id=oel1.line_id
    AND    nvl(oel1.schedule_ship_date,sysdate) <> nvl(wsh.date_scheduled,sysdate)
    AND    wsh.source_code = ''OE''
    order by oel1.last_update_date DESC',
      p_title                  => 'SO Line / Delivery Detail Scheduled Date Mismatch Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SO_LINE_DELIVERY_DETAIL_SCHEDULED_DATE_MISMATCH_DETAILS');

debug('begin add_signature: SO_LINE_DELIVERY_DETAIL_SCHEDULED_DATE_MISMATCH');
  add_signature(
      p_sig_id                 => 'SO_LINE_DELIVERY_DETAIL_SCHEDULED_DATE_MISMATCH',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM   wsh_delivery_details wsh,oe_order_lines_all l
    WHERE  l.open_flag = ''Y''
    AND    nvl(l.cancelled_quantity,0)=0
    AND    nvl(l.shipping_interfaced_flag,''Y'')=''Y''
    AND    wsh.source_line_id=l.line_id
    AND    nvl(l.schedule_ship_date,sysdate) <> nvl(wsh.date_scheduled,sysdate)
    AND    wsh.source_code = ''OE''',
      p_title                  => 'SO Line / Delivery Detail Scheduled Date Mismatch',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('SO_LINE_DELIVERY_DETAIL_SCHEDULED_DATE_MISMATCH_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SO_LINE_DELIVERY_DETAIL_SCHEDULED_DATE_MISMATCH');





debug('begin add_signature: RECEIVED_DROPSHIP_LINES_STUCK_IN_AWAITING_RECEIPT_DETAILS');
  add_signature(
      p_sig_id                 => 'RECEIVED_DROPSHIP_LINES_STUCK_IN_AWAITING_RECEIPT_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.item_type_code "ITEM TYPE",
           l.flow_status_code "LINE STATUS",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATE",
           hou.name "OPERATING UNIT",
           shl.shipment_line_status_code "RCV SHIP STATUS",
           l.ordered_quantity "ORDERED QTY",
           shl.quantity_shipped "SHIPPED QTY",
           shl.quantity_received "RECEIVED QTY",
           to_char(shl.last_update_date, ''DD-MON-RR'') "RCV SHIP UPDATE"
    FROM   oe_order_lines_all l, 
           oe_order_headers_all h,
           OE_DROP_SHIP_SOURCES SRC, 
           rcv_shipment_lines shl, 
           hr_operating_units hou
    WHERE  l.last_update_date > (sysdate-730)
    AND  h.header_id = l.header_id
    AND  h.org_id = hou.organization_id
    AND  l.source_type_code = ''EXTERNAL''
    AND SRC.line_id   = l.line_id
    AND SRC.po_line_id = shl.po_line_id
    AND shipment_line_status_code <> ''EXPECTED''
    AND l.flow_status_code = ''AWAITING_RECEIPT''
    AND l.last_update_date > (sysdate-730)
    order by l.last_update_date DESC',
      p_title                  => 'Received Dropship Lines Stuck in Awaiting Receipt Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: RECEIVED_DROPSHIP_LINES_STUCK_IN_AWAITING_RECEIPT_DETAILS');

debug('begin add_signature: RECEIVED_DROPSHIP_LINES_STUCK_IN_AWAITING_RECEIPT');
  add_signature(
      p_sig_id                 => 'RECEIVED_DROPSHIP_LINES_STUCK_IN_AWAITING_RECEIPT',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM   oe_order_lines_all l, 
           oe_order_headers_all h,
           OE_DROP_SHIP_SOURCES SRC, 
           rcv_shipment_lines shl
    WHERE  l.last_update_date > (sysdate-730)
    AND    h.header_id = l.header_id
    AND    l.source_type_code = ''EXTERNAL''
    AND   SRC.line_id   = l.line_id
    AND   SRC.po_line_id = shl.po_line_id
    AND   shipment_line_status_code <> ''EXPECTED''
    AND   l.flow_status_code = ''AWAITING_RECEIPT''
    AND   l.last_update_date > (sysdate-730)',
      p_title                  => 'Received Dropship Lines Stuck in Awaiting Receipt',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and and refer to 
    [566616.1] How to Diagnose Drop Shipment Process and Interface Between Order Management and Purchasing for resolution.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('RECEIVED_DROPSHIP_LINES_STUCK_IN_AWAITING_RECEIPT_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: RECEIVED_DROPSHIP_LINES_STUCK_IN_AWAITING_RECEIPT');





debug('begin add_signature: OPEN_SO_HEADERS_WF_FLOW_INITIATED_NOT_STARTED_DETAILS');
  add_signature(
      p_sig_id                 => 'OPEN_SO_HEADERS_WF_FLOW_INITIATED_NOT_STARTED_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           h.header_id "HEADER ID",
           h.open_flag "OPEN FLAG",
           h.cancelled_flag "CANC FLAG",
           h.flow_status_code "STATUS",
           to_char(h.last_update_date, ''DD-MON-RR'') "HDR LAST UPDATED",
              (select count(1) from oe_order_lines_all
              where header_id = h.header_id
              and open_flag = ''Y'') "NO OF OPEN LINES",
          hou.name "OPERATING UNIT"
    FROM wf_items wi, oe_order_headers_all h, hr_operating_units hou
    WHERE h.org_id               = hou.organization_id
    AND   h.last_update_date > (sysdate-730)
    AND   to_number(wi.item_key) = h.header_id
    AND   wi.item_type = ''OEOH''
    AND   h.open_flag = ''Y''
    AND not exists (select ''WF is pending'' from
                wf_item_activity_statuses wias
                where to_number(wias.item_key) = h.header_id
                  and wias.item_type = ''OEOH'')
    AND nvl(h.transaction_phase_code, ''F'') = ''F''
    order by h.last_update_date DESC',
      p_title                  => 'Open SO Headers Where WF is Initiated But Not Started Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_HEADERS_WF_FLOW_INITIATED_NOT_STARTED_DETAILS');

debug('begin add_signature: OPEN_SO_HEADERS_WF_FLOW_INITIATED_NOT_STARTED');
  add_signature(
      p_sig_id                 => 'OPEN_SO_HEADERS_WF_FLOW_INITIATED_NOT_STARTED',
      p_sig_sql                => 'SELECT count(*) "No_of_Headers",
           to_char(min(h.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(h.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM wf_items wi, oe_order_headers_all h
    WHERE to_number(wi.item_key) = h.header_id
    AND wi.item_type = ''OEOH''
    AND h.open_flag = ''Y''
    AND h.last_update_date > (sysdate-730)
    AND not exists (select ''WF is pending'' from
              wf_item_activity_statuses wias
         where to_number(wias.item_key) = h.header_id
           and wias.item_type = ''OEOH'')
    AND nvl(h.transaction_phase_code, ''F'') = ''F''',
      p_title                  => 'Open SO Headers Where WF is Initiated But Not Started',
      p_fail_condition         => '[NO_OF_HEADERS] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - Refer to Patch 17001338 and run ont00166.sql to start the Workflow.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('OPEN_SO_HEADERS_WF_FLOW_INITIATED_NOT_STARTED_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_HEADERS_WF_FLOW_INITIATED_NOT_STARTED');





debug('begin add_signature: SHIPPABLE_KITS_MODELS_NOT_OM_INTERFACED_COMPONENTS_ARE_DETAILS');
  add_signature(
      p_sig_id                 => 'SHIPPABLE_KITS_MODELS_NOT_OM_INTERFACED_COMPONENTS_ARE_DETAILS',
      p_sig_sql                => 'SELECT wdd.source_header_number "ORDER NO",
           wdd.source_header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.item_type_code "ITEM TYPE",
           l.flow_status_code "STATUS",
           wdd.delivery_detail_id "DEL DTL ID",
           to_char(wdd.last_update_date, ''DD-MON-RR'') "LAST UPDATE",
           hou.name "OPERATING UNIT"
    FROM wsh_delivery_details wdd, oe_order_lines_all l, hr_operating_units hou
    WHERE l.last_update_date > (sysdate-730)
    AND l.org_id = hou.organization_id
    AND wdd.source_code = ''OE''
    AND wdd.source_line_id = wdd.top_model_line_id
    AND wdd.oe_interfaced_flag in (''N'',''P'')
    AND wdd.source_line_id = l.line_id
    AND l.open_flag = ''N''
    AND exists (select ''x''
                from wsh_delivery_details wdd1
                where wdd.top_model_line_id = wdd1.top_model_line_id
                and wdd1.source_code = ''OE''
                and wdd1.released_status <> ''D''
                and wdd1.oe_interfaced_flag = ''Y''
                and wdd1.released_status = ''C''
                and wdd1.source_line_id <> wdd.top_model_line_id)
    order by wdd.last_update_date DESC',
      p_title                  => 'Shippable Kit Models not OM Interfaced, but Components are Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIPPABLE_KITS_MODELS_NOT_OM_INTERFACED_COMPONENTS_ARE_DETAILS');

debug('begin add_signature: SHIPPABLE_KITS_MODELS_NOT_OM_INTERFACED_COMPONENTS_ARE');
  add_signature(
      p_sig_id                 => 'SHIPPABLE_KITS_MODELS_NOT_OM_INTERFACED_COMPONENTS_ARE',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",
           to_char(min(wdd.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM wsh_delivery_details wdd, 
         oe_order_lines_all l
    WHERE l.last_update_date > (sysdate-730)
    AND wdd.source_code = ''OE''
    AND wdd.source_line_id = wdd.top_model_line_id
    AND wdd.oe_interfaced_flag in (''N'',''P'')
    AND wdd.source_line_id = l.line_id
    AND l.open_flag = ''N''
    AND exists (select ''x''
                from wsh_delivery_details wdd1
                where wdd.top_model_line_id = wdd1.top_model_line_id
                and wdd1.source_code = ''OE''
                and wdd1.released_status <> ''D''
                and wdd1.oe_interfaced_flag = ''Y''
                and wdd1.released_status = ''C''
                and wdd1.source_line_id <> wdd.top_model_line_id)',
      p_title                  => 'Shippable Kit Models not OM Interfaced, but Components are',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('SHIPPABLE_KITS_MODELS_NOT_OM_INTERFACED_COMPONENTS_ARE_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIPPABLE_KITS_MODELS_NOT_OM_INTERFACED_COMPONENTS_ARE');





debug('begin add_signature: INTERNAL_ORDER_SHIPMENTS_MISSING_REQUISITION_DETAILS');
  add_signature(
      p_sig_id                 => 'INTERNAL_ORDER_SHIPMENTS_MISSING_REQUISITION_DETAILS',
      p_sig_sql                => 'SELECT wdd.source_header_number "ORDER NO",
           wdd.source_header_id "HEADER ID",
           ol.line_number "LINE NUMBER",
           wdd.source_line_id "LINE ID",
           wdd.delivery_detail_id "DEL DTL ID",
           to_char(wdd.creation_date, ''DD-MON-RR'') "CREATED",
           ou.name "OPERATING UNIT"
    FROM   wsh_delivery_details wdd,
           oe_order_lines_all ol,
           hr_operating_units ou
    WHERE  ol.last_update_date > (sysdate-730)
    AND    wdd.source_code = ''OE''
    AND    wdd.source_line_id = ol.line_id
    AND    wdd.released_status <> ''D''
    AND    nvl(wdd.inv_interfaced_flag,''N'') in (''N'',''P'')
    AND    wdd.source_line_id = ol.line_id
    AND    ol.org_id = ou.organization_id
    AND    ol.source_document_type_id = 10
    AND    not exists (
          select ''x''
           from   po_requisition_lines_all pl,
                  po_req_distributions_all pd
           where  pl.requisition_line_id = ol.source_document_line_id
           and    pl.requisition_header_id = ol.source_document_id
           and    pl.requisition_line_id = pd.requisition_line_id)
    order by wdd.creation_date DESC',
      p_title                  => 'Internal Order Shipments With Missing Requisition Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INTERNAL_ORDER_SHIPMENTS_MISSING_REQUISITION_DETAILS');

debug('begin add_signature: INTERNAL_ORDER_SHIPMENTS_MISSING_REQUISITION');
  add_signature(
      p_sig_id                 => 'INTERNAL_ORDER_SHIPMENTS_MISSING_REQUISITION',
      p_sig_sql                => 'SELECT count(wdd.delivery_Detail_id) "NO_OF_LINES",
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM   wsh_delivery_details wdd,
           oe_order_lines_all ol
    WHERE  ol.last_update_date > (sysdate-730)
    AND    wdd.source_code = ''OE''
    AND    wdd.source_line_id = ol.line_id
    AND    wdd.released_status <> ''D''
    AND    nvl(wdd.inv_interfaced_flag,''N'') in (''N'',''P'')
    AND    wdd.source_line_id = ol.line_id
    AND    ol.source_document_type_id = 10
    AND    not exists (
         select ''x''
         from   po_requisition_lines_all pl,
                po_req_distributions_all pd
         where  pl.requisition_line_id = ol.source_document_line_id
         and    pl.requisition_header_id = ol.source_document_id
         and    pl.requisition_line_id = pd.requisition_line_id)',
      p_title                  => 'Internal Order Shipments With Missing Requisition',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'These Internal Orders may cause the Inventory Interface/Interface Trip Stop processes to fail with Requisition Line not found.
    please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('INTERNAL_ORDER_SHIPMENTS_MISSING_REQUISITION_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: INTERNAL_ORDER_SHIPMENTS_MISSING_REQUISITION');



debug('begin add_signature: RMA_RECEIVING_STUCK');
  add_signature(
      p_sig_id                 => 'RMA_RECEIVING_STUCK',
      p_sig_sql                => 'SELECT oh.order_number "ORDER NO",
           oh.header_id "HEADER ID",
           ol.line_number "LINE NUMBER",
           ol.line_id "LINE ID", 
           ol.flow_status_code "LINE STATUS",
           ol.ordered_quantity "ORDER QTY",
           decode(nvl(rcv.INSPECTION_STATUS_CODE,0), 
             ''0'',''N'', ''NOT INSPECTED'',''N'', ''INSPECTED'',''Y'', 
              rcv.INSPECTION_STATUS_CODE) "INSPECTED",
           ol.shipped_quantity "RECEIVED QTY",
           ol.fulfilled_quantity "DELIVERED QTY",
           hou.name "OPERATING UNIT"  
    FROM oe_order_headers_all oh, 
         oe_order_lines_all ol, 
         rcv_transactions rcv, 
         hr_operating_units hou 
    WHERE oh.last_update_date > (sysdate-730)
    AND   oh.header_id            = ol.header_id 
    AND   ol.line_id              = rcv.oe_order_line_id 
    AND   oh.org_id = hou.organization_id
    AND   ol.open_flag			 = ''Y'' 
    AND  (( ol.ordered_quantity = 
       (SELECT Sum(rcv.quantity) FROM rcv_transactions rcv 
        WHERE rcv.transaction_type    = ''DELIVER'' 
        AND rcv.oe_order_line_id=ol.line_id)
        AND ol.flow_status_code in (''AWAITING_RETURN_DISPOSITION'',''AWAITING_RETURN'')) 
        OR ( rcv.quantity            = ol.ordered_quantity 
	   and rcv.transaction_type    = ''RECEIVE'' 
	   and ol.flow_status_code     in (''AWAITING_RETURN'')))',
      p_title                  => 'RMAs Where Receiving Transaction is Stuck ',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'There are open SO Lines which are related to Receiving Transactions that are stuck.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: RMA_RECEIVING_STUCK');





debug('begin add_signature: OPEN_SO_LINES_WF_FLOW_INITIATED_NOT_STARTED_DETAILS');
  add_signature(
      p_sig_id                 => 'OPEN_SO_LINES_WF_FLOW_INITIATED_NOT_STARTED_DETAILS',
      p_sig_sql                => 'SELECT nvl(to_char(h.order_number), ''** Missing Record **'') "ORDER NO",
           l.header_id "HEADER ID",
           l.line_number "LINE NO",
           l.line_id "LINE ID",
           l.open_flag "OPEN",
           l.booked_flag "BOOKED",
           l.flow_status_code "STATUS",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATED",
           hou.name "OPERATING UNIT"
    FROM  wf_items wi, 
          oe_order_headers_all h, 
          oe_order_lines_all l, 
          hr_operating_units hou
    WHERE l.org_id               = hou.organization_id
    AND   l.header_id = h.header_id (+)
    AND   to_number(wi.item_key) = l.line_id
    AND   wi.END_DATE is null
    AND   wi.item_type = ''OEOL''
    AND   l.open_flag = ''Y''
    AND   l.last_update_date > (sysdate-730)
    AND not exists (select ''WF is pending'' from
                wf_item_activity_statuses wias
                where to_number(wias.item_key) = l.line_id
                  and wias.item_type = ''OEOL'')
    AND nvl(l.transaction_phase_code, ''F'') = ''F''
    order by l.last_update_date DESC',
      p_title                  => 'Open SO Lines Where WF is Initiated But Not Started Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_LINES_WF_FLOW_INITIATED_NOT_STARTED_DETAILS');

debug('begin add_signature: OPEN_SO_LINES_WF_FLOW_INITIATED_NOT_STARTED');
  add_signature(
      p_sig_id                 => 'OPEN_SO_LINES_WF_FLOW_INITIATED_NOT_STARTED',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(l.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(l.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM wf_items wi, oe_order_lines_all l
    WHERE to_number(wi.item_key) = l.line_id
    AND wi.item_type = ''OEOL''
    AND l.open_flag = ''Y''
    AND l.last_update_date > (sysdate-730)
    AND nvl(l.cancelled_flag, ''N'') = ''N''
    AND not exists (select ''WF is pending'' from
              wf_item_activity_statuses wias
         where to_number(wias.item_key) = l.line_id
           and wias.item_type = ''OEOL'')
    AND nvl(l.transaction_phase_code, ''F'') = ''F''',
      p_title                  => 'Open SO Lines Where WF is Initiated But Not Started',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('OPEN_SO_LINES_WF_FLOW_INITIATED_NOT_STARTED_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_LINES_WF_FLOW_INITIATED_NOT_STARTED');





debug('begin add_signature: DELIVERY_TRIP_STOP_ACTUAL_SHIP_DATE_MISMATCH_DETAILS');
  add_signature(
      p_sig_id                 => 'DELIVERY_TRIP_STOP_ACTUAL_SHIP_DATE_MISMATCH_DETAILS',
      p_sig_sql                => 'SELECT wnd.name "DELIVERY NAME",
           wnd.delivery_id "DELIVERY ID",
           to_char(wnd.initial_pickup_date,''DD-MON-RR HH24:MI:SS'') "DEL PICKUP",
           to_char(wts.actual_departure_date,''DD-MON-RR HH24:MI:SS'') "TRIP DEPART",
           to_char(wts.Creation_date, ''DD-MON-RR'') "TRIP CREATED",
           to_char(wts.last_update_date, ''DD-MON-RR'') "TRIP LAST UPDATED"
    FROM wsh_new_deliveries wnd, 
         wsh_delivery_legs wdl, 
         wsh_trip_stops wts
    WHERE wnd.status_code = ''CL''
    AND wnd.delivery_id = wdl.delivery_id
    AND wdl.pick_up_stop_id = wts.stop_id
    AND wts.stop_location_id = wnd.initial_pickup_location_id
    AND wts.status_code in (''IT'',''CL'')
    AND wts.actual_departure_date <> nvl(wnd.initial_pickup_date,wts.actual_departure_date)
    order by wts.last_update_date DESC',
      p_title                  => 'Delivery / Trip Stop Actual Ship Date Mismatch Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DELIVERY_TRIP_STOP_ACTUAL_SHIP_DATE_MISMATCH_DETAILS');

debug('begin add_signature: DELIVERY_TRIP_STOP_ACTUAL_SHIP_DATE_MISMATCH');
  add_signature(
      p_sig_id                 => 'DELIVERY_TRIP_STOP_ACTUAL_SHIP_DATE_MISMATCH',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(wts.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wts.creation_date), ''DD-MON-RR'') "LATEST"
    FROM wsh_new_deliveries wnd, wsh_delivery_legs wdl, wsh_trip_stops wts
    WHERE wnd.status_code = ''CL''
    AND wnd.delivery_id = wdl.delivery_id
    AND wdl.pick_up_stop_id = wts.stop_id
    AND wts.stop_location_id = wnd.initial_pickup_location_id
    AND wts.status_code in (''IT'',''CL'')
    AND wts.actual_departure_date <> nvl(wnd.initial_pickup_date,wts.actual_departure_date)',
      p_title                  => 'Delivery / Trip Stop Actual Ship Date Mismatch',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('DELIVERY_TRIP_STOP_ACTUAL_SHIP_DATE_MISMATCH_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DELIVERY_TRIP_STOP_ACTUAL_SHIP_DATE_MISMATCH');





debug('begin add_signature: DROPSHIP_LINES_STUCK_IN_AWAITING_RETURN_DETAILS');
  add_signature(
      p_sig_id                 => 'DROPSHIP_LINES_STUCK_IN_AWAITING_RETURN_DETAILS',
      p_sig_sql                => 'SELECT oh.order_number "ORDER NO",
           ol.header_id "HEADER ID",
           ol.line_number "LINE NO",
           ol.line_id "LINE ID",
           ol.item_type_code "ITEM TYPE",
           ol.flow_status_code "LINE STATUS",
           ol.ordered_quantity "ORDERED QTY",
           to_char(ol.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATE",
           mmt.transaction_date "RECEIVED DATE",
           rcv.quantity "RECEIVED QTY",
           hou.name "OPERATING UNIT"
    FROM oe_order_headers_all      oh,  
         oe_order_lines_all        ol,
         rcv_transactions          rcv, 
         mtl_material_transactions mmt,
         hr_operating_units        hou
    WHERE ol.last_update_date > (sysdate-730)
    AND oh.header_id            = ol.header_id
    AND   oh.org_id               = hou.organization_id
    AND   ol.open_flag            = ''Y''
    AND   ol.line_id              = rcv.oe_order_line_id
    AND   ol.line_id              = mmt.trx_source_line_id
    AND   mmt.transaction_type_id = 15
    AND   mmt.rcv_transaction_id  = rcv.transaction_id
    AND   (ol.flow_status_code     = ''AWAITING_RETURN''
           or ol.flow_status_code  = ''AWAITING_RETURN_DISPOSITION'')
    order by ol.last_update_date DESC',
      p_title                  => 'Dropship Lines Stuck awaiting Return or Return Disposition Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DROPSHIP_LINES_STUCK_IN_AWAITING_RETURN_DETAILS');

debug('begin add_signature: DROPSHIP_LINES_STUCK_IN_AWAITING_RETURN');
  add_signature(
      p_sig_id                 => 'DROPSHIP_LINES_STUCK_IN_AWAITING_RETURN',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",
           ol.flow_status_code "LINE STATUS",
           to_char(min(ol.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(ol.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM oe_order_headers_all      oh,
         oe_order_lines_all        ol,
         rcv_transactions          rcv,
         mtl_material_transactions mmt
    WHERE ol.last_update_date > (sysdate-730)
    AND   oh.header_id            = ol.header_id
    AND   ol.open_flag            = ''Y''
    AND   ol.line_id              = rcv.oe_order_line_id
    AND   ol.line_id              = mmt.trx_source_line_id
    AND   mmt.transaction_type_id = 15
    AND   mmt.rcv_transaction_id  = rcv.transaction_id
    AND   (ol.flow_status_code     = ''AWAITING_RETURN''
           or ol.flow_status_code  = ''AWAITING_RETURN_DISPOSITION'')
    group by ol.flow_status_code',
      p_title                  => 'Dropship Lines Stuck awaiting Return or Return Disposition',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and and refer to 
    [566616.1] How to Diagnose Drop Shipment Process and Interface Between Order Management and Purchasing for resolution.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('DROPSHIP_LINES_STUCK_IN_AWAITING_RETURN_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DROPSHIP_LINES_STUCK_IN_AWAITING_RETURN');





debug('begin add_signature: OPEN_SO_HEADERS_WF_FLOW_PENDING_NO_OPEN_LINES_DETAILS');
  add_signature(
      p_sig_id                 => 'OPEN_SO_HEADERS_WF_FLOW_PENDING_NO_OPEN_LINES_DETAILS',
      p_sig_sql                => 'SELECT h.order_number "ORDER NO",
           h.header_id "HEADER ID",
           h.open_flag "OPEN FLAG",
           h.cancelled_flag "CANC FLAG",
           h.flow_status_code "STATUS",
           to_char(h.last_update_date, ''DD-MON-RR'') "HDR LAST UPDATED",
           hou.name
    FROM wf_item_activity_statuses was,   
         wf_process_activities p, 
         oe_order_headers_all h,   
        hr_operating_units hou
    WHERE h.org_id               = hou.organization_id
    AND h.last_update_date > (sysdate-730)
    AND to_number(was.item_key) = h.header_id
    AND was.process_activity = p.instance_id
    AND p.activity_item_type = ''OEOH''
    AND p.activity_name = ''CLOSE_WAIT_FOR_L''
    AND was.activity_status = ''NOTIFIED''
    AND was.item_type = ''OEOH''
    AND not exists (
          select /*+ NO_INDEX (l oe_order_lines_n15) */1 from oe_order_lines_all
          where  header_id = to_number(was.item_key)
          and    open_flag = ''Y'')
    order by h.last_update_date DESC',
      p_title                  => 'Open SO Headers with Pending WF Flow but no Open Lines Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that may have a problem.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_HEADERS_WF_FLOW_PENDING_NO_OPEN_LINES_DETAILS');

debug('begin add_signature: OPEN_SO_HEADERS_WF_FLOW_PENDING_NO_OPEN_LINES');
  add_signature(
      p_sig_id                 => 'OPEN_SO_HEADERS_WF_FLOW_PENDING_NO_OPEN_LINES',
      p_sig_sql                => 'SELECT count(*) "No_of_Headers",  
           to_char(min(h.last_update_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(h.last_update_date), ''DD-MON-RR'') "LATEST"
    FROM  wf_item_activity_statuses was,
          wf_process_activities p, 
          oe_order_headers_all h
    WHERE to_number(was.item_key) = h.header_id
    AND h.last_update_date > (sysdate-730)
    AND was.process_activity = p.instance_id
    AND p.activity_item_type = ''OEOH''
    AND p.activity_name = ''CLOSE_WAIT_FOR_L''
    AND was.activity_status = ''NOTIFIED''
    AND was.item_type = ''OEOH''
    AND not exists (
            select /*+ NO_INDEX (l oe_order_lines_n15) */1 from oe_order_lines_all
            where  header_id = to_number(was.item_key)
            and    open_flag = ''Y'')',
      p_title                  => 'Open SO Headers with Pending WF Flow but no Open Lines',
      p_fail_condition         => '[NO_OF_HEADERS] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('OPEN_SO_HEADERS_WF_FLOW_PENDING_NO_OPEN_LINES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_SO_HEADERS_WF_FLOW_PENDING_NO_OPEN_LINES');





debug('begin add_signature: DELIVERY_DETAILS_ERRORED_WF_SHIP_ACTIVITIES_DETAILS');
  add_signature(
      p_sig_id                 => 'DELIVERY_DETAILS_ERRORED_WF_SHIP_ACTIVITIES_DETAILS',
      p_sig_sql                => 'SELECT wdd.SOURCE_HEADER_NUMBER "ORDER NUMBER",
           wdd.source_header_id "ORDER ID",
           l.line_number "LINE NUMNBER",
           l.line_id "LINE ID",
           l.flow_status_code "LINE STATUS",
           l.open_flag "OPEN FLAG",
           l.cancelled_flag "CANC FLAG",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATE",
           wdd.delivery_detail_id "DEL DTL ID",
           wdd.oe_interfaced_flag "DEL OE INTERF",
           decode (wdd.released_status, 
              ''Y'',''Staged'',           ''R'',''Ready to Release'',
              ''S'',''Rel to Warehouse'', ''B'',''Backorder'',
              ''C'',''Shipped'', wdd.RELEASED_STATUS) "DEL STATUS",
          to_char(wdd.creation_date, ''DD-MON-RR'') "DEL CREATED",
          to_char(wdd.last_update_date, ''DD-MON-RR'') "DEL LAST UPDATE",
          hou.name "OPERATING UNIT"
    FROM wsh_delivery_details wdd, oe_order_lines_all l, hr_operating_units  hou
    WHERE l.line_id = wdd.source_line_id
    AND l.org_id = hou.organization_id
    AND wdd.source_code = ''OE''
    AND nvl(wdd.oe_interfaced_flag, ''N'') in (''N'', ''P'')
    AND wdd.released_status in ( ''C'', ''R'', ''B'', ''S'', ''Y'' )
    AND exists 
      (select 1
       from   wf_item_activity_statuses was,
            wf_process_activities wpa
       where  was.item_type = ''OEOL''
       and    was.item_key  = to_char(l.line_id)
       and    wpa.activity_item_type = was.item_type
       and    wpa.activity_name = ''SHIP_LINE''
       and    wpa.instance_id  = was.process_activity
       and    was.end_date is null
       and    was.activity_status = ''ERROR'')
    order by wdd.last_update_date DESC',
      p_title                  => 'Delivery Details With Errored WF Ship Activities Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DELIVERY_DETAILS_ERRORED_WF_SHIP_ACTIVITIES_DETAILS');

debug('begin add_signature: DELIVERY_DETAILS_ERRORED_WF_SHIP_ACTIVITIES');
  add_signature(
      p_sig_id                 => 'DELIVERY_DETAILS_ERRORED_WF_SHIP_ACTIVITIES',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",  
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM wsh_delivery_details wdd, 
         oe_order_lines_all l
    WHERE l.line_id = wdd.source_line_id
    AND wdd.source_code = ''OE''
    AND nvl(wdd.oe_interfaced_flag, ''N'') in (''N'', ''P'')
    AND wdd.released_status in ( ''C'', ''R'', ''B'', ''S'', ''Y'' )
    AND exists 
     (select 1
      from   wf_item_activity_statuses was,
             wf_process_activities wpa
      where  was.item_type = ''OEOL''
      and    was.item_key  = to_char(l.line_id)
      and    wpa.activity_item_type = was.item_type
      and    wpa.activity_name = ''SHIP_LINE''
      and    wpa.instance_id  = was.process_activity
      and    was.end_date is null
      and    was.activity_status = ''ERROR'')',
      p_title                  => 'Delivery Details With Errored WF Ship Activities',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('DELIVERY_DETAILS_ERRORED_WF_SHIP_ACTIVITIES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: DELIVERY_DETAILS_ERRORED_WF_SHIP_ACTIVITIES');





debug('begin add_signature: OPEN_DELIVERY_DETAILS_MISSING_COMPLETED_WF_SHIP_ACTIVITIES_DETAILS');
  add_signature(
      p_sig_id                 => 'OPEN_DELIVERY_DETAILS_MISSING_COMPLETED_WF_SHIP_ACTIVITIES_DETAILS',
      p_sig_sql                => 'SELECT wdd.SOURCE_HEADER_NUMBER "ORDER NUMBER",
           wdd.source_header_id "ORDER ID",
           l.line_number "LINE NUMBER",
           l.line_id "LINE ID",
           l.flow_status_code "LINE STATUS",
           l.open_flag "OPEN FLAG",
           l.cancelled_flag "CANC FLAG",
           to_char(l.last_update_date, ''DD-MON-RR'') "LINE LAST UPDATE",
           wdd.delivery_detail_id "DEL DTL ID",
           wdd.oe_interfaced_flag "DEL OE INTERF",
           decode (wdd.released_status, 
            ''Y'',''Staged'',           ''R'',''Ready to Release'',
            ''S'',''Rel to Warehouse'', ''B'',''Backorder'',
            ''C'',''Shipped'', wdd.RELEASED_STATUS) "DEL STATUS",
          to_char(wdd.creation_date, ''DD-MON-RR'') "DEL CREATED",
          to_char(wdd.last_update_date, ''DD-MON-RR'') "DEL LAST UPDATE",
         hou.name "OPERATING UNIT"
    FROM wsh_delivery_details wdd, oe_order_lines_all l, hr_operating_units  hou
    WHERE l.line_id = wdd.source_line_id
    AND l.open_flag = ''Y''
    AND l.org_id = hou.organization_id
    AND wdd.source_code = ''OE''
    AND nvl(wdd.oe_interfaced_flag, ''N'') in (''N'', ''P'')
    AND wdd.released_status <> ''D''
    AND not exists 
     (select 1
      from   wf_item_activity_statuses was,
            wf_process_activities wpa
      where  was.item_type = ''OEOL''
       and    was.item_key  = to_char(l.line_id)
       and    wpa.activity_item_type = was.item_type
       and    wpa.activity_name = ''SHIP_LINE''
       and    wpa.instance_id  = was.process_activity
       and    was.end_date is null)
    order by wdd.last_update_date DESC',
      p_title                  => 'Open Delivery Details With Missing or Completed WF Ship Activities Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_DELIVERY_DETAILS_MISSING_COMPLETED_WF_SHIP_ACTIVITIES_DETAILS');

debug('begin add_signature: OPEN_DELIVERY_DETAILS_MISSING_COMPLETED_WF_SHIP_ACTIVITIES');
  add_signature(
      p_sig_id                 => 'OPEN_DELIVERY_DETAILS_MISSING_COMPLETED_WF_SHIP_ACTIVITIES',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",  
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM wsh_delivery_details wdd, 
         oe_order_lines_all l
    WHERE l.line_id = wdd.source_line_id
    AND l.open_flag = ''Y''
    AND wdd.source_code = ''OE''
    AND nvl(wdd.oe_interfaced_flag, ''N'') in (''N'', ''P'')
    AND wdd.released_status <> ''D''
    AND not exists 
     (select 1
      from   wf_item_activity_statuses was,
             wf_process_activities wpa
      where  was.item_type = ''OEOL''
        and    was.item_key  = to_char(l.line_id)
	and    wpa.activity_item_type = was.item_type
	and    wpa.activity_name = ''SHIP_LINE''
	and    wpa.instance_id  = was.process_activity
        and    was.end_date is null)',
      p_title                  => 'Open Delivery Details With Missing or Completed WF Ship Activities',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('OPEN_DELIVERY_DETAILS_MISSING_COMPLETED_WF_SHIP_ACTIVITIES_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: OPEN_DELIVERY_DETAILS_MISSING_COMPLETED_WF_SHIP_ACTIVITIES');





debug('begin add_signature: SHIPPED_DELIVERY_DETAILS_OWNED_OPEN_DELIVERY_DETAILS');
  add_signature(
      p_sig_id                 => 'SHIPPED_DELIVERY_DETAILS_OWNED_OPEN_DELIVERY_DETAILS',
      p_sig_sql                => 'SELECT wdd.SOURCE_HEADER_NUMBER "ORDER NUMBER",
           wdd.source_header_id "ORDER ID",
           wdd.source_line_id "LINE ID",
           wnd.delivery_id "DELIVERY ID",
           wnd.status_code "DELIVERY STATUS",
           wdd.delivery_detail_id "DEL DTL ID",
           decode (wdd.released_status, 
              ''Y'',''Staged'',            ''R'',''Ready to Release'',
              ''S'',''Rel to Warehouse'',  ''B'',''Backorder'',
              ''C'',''Shipped'', wdd.RELEASED_STATUS) "DEL DTL STATUS",
           to_char(wdd.creation_date, ''DD-MON-RR'') "DEL CREATED",
           to_char(wdd.last_update_date, ''DD-MON-RR'') "DEL LAST UPDATE"
      FROM wsh_delivery_details wdd, 
           wsh_delivery_assignments wda,
           wsh_new_deliveries wnd
      WHERE wdd.source_code = ''OE''
      AND wdd.delivery_detail_id = wda.delivery_detail_id
      AND wda.delivery_id = wnd.delivery_id
      AND wdd.released_status = ''C''
      AND wnd.status_code not in (''IT'', ''CL'')
      order by wdd.last_update_date DESC',
      p_title                  => 'Shipped Delivery Details Owned by an Open Delivery Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIPPED_DELIVERY_DETAILS_OWNED_OPEN_DELIVERY_DETAILS');

debug('begin add_signature: SHIPPED_DELIVERY_DETAILS_OWNED_OPEN_DELIVERY');
  add_signature(
      p_sig_id                 => 'SHIPPED_DELIVERY_DETAILS_OWNED_OPEN_DELIVERY',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines", 
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM wsh_delivery_details wdd,
         wsh_delivery_assignments wda,
         wsh_new_deliveries wnd
    WHERE wdd.source_code = ''OE''
    AND wdd.delivery_detail_id = wda.delivery_detail_id
    AND wda.delivery_id = wnd.delivery_id
    AND wdd.released_status = ''C''
    AND wnd.status_code not in (''IT'', ''CL'')',
      p_title                  => 'Shipped Delivery Details Owned by an Open Delivery',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('SHIPPED_DELIVERY_DETAILS_OWNED_OPEN_DELIVERY_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIPPED_DELIVERY_DETAILS_OWNED_OPEN_DELIVERY');





debug('begin add_signature: SHIPPED_DELIVERY_DETAILS_NOT_ELIGIBLE_FOR_OM_INV_INTERFACING_DETAILS');
  add_signature(
      p_sig_id                 => 'SHIPPED_DELIVERY_DETAILS_NOT_ELIGIBLE_FOR_OM_INV_INTERFACING_DETAILS',
      p_sig_sql                => 'SELECT wdd.SOURCE_HEADER_NUMBER "ORDER NUMBER",
           wdd.source_header_id "ORDER ID",
           wdd.source_line_id "LINE ID",
           wnd.delivery_id "DELIVERY ID",
           wdd.delivery_detail_id "DEL DTL ID",
           wts.stop_id "STOP ID",
           wts.trip_id "TRIP ID",
           to_char(wdd.creation_date, ''DD-MON-RR'') "DEL CREATED",
           to_char(wdd.last_update_date, ''DD-MON-RR'') "DEL LAST UPDATE"
    FROM   wsh_delivery_details wdd,     
           wsh_delivery_assignments wda,
           wsh_new_deliveries wnd,       
           wsh_delivery_legs wdl,
           wsh_trip_stops wts
    WHERE  wdd.source_code = ''OE''
    AND    wdd.released_status = ''C''
    AND    (wdd.oe_interfaced_flag in (''N'',''P'') or wdd.inv_interfaced_flag 
              in (''N'',''P''))
    AND    wdd.delivery_detail_id = wda.delivery_detail_id
    AND    wda.delivery_id = wnd.delivery_id
    AND    wnd.delivery_id = wdl.delivery_id
    AND    wdl.pick_up_stop_id = wts.stop_id
    AND    nvl(wts.pending_interface_flag,''X'') <> ''Y''
    order by wdd.last_update_date DESC',
      p_title                  => 'Shipped Delivery Details Not Eligible for OM/INV Interfacing Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIPPED_DELIVERY_DETAILS_NOT_ELIGIBLE_FOR_OM_INV_INTERFACING_DETAILS');

debug('begin add_signature: SHIPPED_DELIVERY_DETAILS_NOT_ELIGIBLE_FOR_OM_INV_INTERFACING');
  add_signature(
      p_sig_id                 => 'SHIPPED_DELIVERY_DETAILS_NOT_ELIGIBLE_FOR_OM_INV_INTERFACING',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",  
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM   wsh_delivery_details wdd,     
           wsh_delivery_assignments wda,
           wsh_new_deliveries wnd,       
           wsh_delivery_legs wdl,
           wsh_trip_stops wts
    WHERE  wdd.source_code = ''OE''
    AND    wdd.released_status = ''C''
    AND    (wdd.oe_interfaced_flag in (''N'',''P'') 
            or wdd.inv_interfaced_flag in (''N'',''P''))
    AND    wdd.delivery_detail_id = wda.delivery_detail_id
    AND    wda.delivery_id = wnd.delivery_id
    AND    wnd.delivery_id = wdl.delivery_id
    AND    wdl.pick_up_stop_id = wts.stop_id
    AND    nvl(wts.pending_interface_flag,''X'') <> ''Y''',
      p_title                  => 'Shipped Delivery Details Not Eligible for OM/INV Interfacing',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('SHIPPED_DELIVERY_DETAILS_NOT_ELIGIBLE_FOR_OM_INV_INTERFACING_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIPPED_DELIVERY_DETAILS_NOT_ELIGIBLE_FOR_OM_INV_INTERFACING');





debug('begin add_signature: SHIPPED_DELIVERY_DETAILS_SHIPPED_QUANTITY_ZERO_DETAILS');
  add_signature(
      p_sig_id                 => 'SHIPPED_DELIVERY_DETAILS_SHIPPED_QUANTITY_ZERO_DETAILS',
      p_sig_sql                => 'SELECT wdd.SOURCE_HEADER_NUMBER "ORDER NUMBER",
           wdd.source_header_id "ORDER ID",
           wdd.source_line_id "LINE ID",
           wdd.delivery_detail_id "DEL DTL ID",
           decode (wdd.released_status, 
              ''Y'',''Staged'',            ''R'',''Ready to Release'',
              ''S'',''Rel to Warehouse'',  ''B'',''Backorder'',
              ''C'',''Shipped'', wdd.RELEASED_STATUS) "DEL DTL STATUS",
         wdd.shipped_quantity "SHIPPED QTY",
         to_char(wdd.creation_date, ''DD-MON-RR'') "DEL CREATED",
         to_char(wdd.last_update_date, ''DD-MON-RR'') "DEL LAST UPDATE"
    FROM wsh_delivery_details wdd
    WHERE wdd.source_code = ''OE''
    AND wdd.released_status = ''C''
    AND nvl(wdd.shipped_quantity,0) = 0
    AND wdd.oe_interfaced_flag = ''N''
    order by wdd.last_update_date DESC',
      p_title                  => 'Shipped Delivery Details Where Shipped Quantity is Zero Details',
      p_fail_condition         => 'RS',
      p_problem_descr          => 'These are the Detailed Rows that May Require a Datafix.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL(),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIPPED_DELIVERY_DETAILS_SHIPPED_QUANTITY_ZERO_DETAILS');

debug('begin add_signature: SHIPPED_DELIVERY_DETAILS_SHIPPED_QUANTITY_ZERO');
  add_signature(
      p_sig_id                 => 'SHIPPED_DELIVERY_DETAILS_SHIPPED_QUANTITY_ZERO',
      p_sig_sql                => 'SELECT count(*) "No_of_Lines",
           to_char(min(wdd.creation_date), ''DD-MON-RR'') "EARLIEST",
           to_char(max(wdd.creation_date), ''DD-MON-RR'') "LATEST"
    FROM wsh_delivery_details wdd
    WHERE wdd.source_code = ''OE''
    AND wdd.released_status = ''C''
    AND nvl(wdd.shipped_quantity,0) = 0
    AND wdd.oe_interfaced_flag = ''N''',
      p_title                  => 'Shipped Delivery Details Where Shipped Quantity is Zero',
      p_fail_condition         => '[NO_OF_LINES] > [0]',
      p_problem_descr          => 'Possible problems have been found which may require a datafix - please review the Detail Rows above and contact the Oracle Order Management Support team if the issue relates to current data.',
      p_solution               => '',
      p_success_msg            => '',
      p_print_condition        => nvl('ALWAYS','ALWAYS'),
      p_fail_type              => nvl('W','W'),
      p_print_sql_output       => nvl('RS','RS'),
      p_limit_rows             => nvl('Y','Y'),
      p_extra_info             => l_info,
      p_child_sigs             => VARCHAR_TBL('SHIPPED_DELIVERY_DETAILS_SHIPPED_QUANTITY_ZERO_DETAILS'),
      p_include_in_dx_summary  => nvl('N','N')
      );
   l_info.delete;
debug('end add_signature: SHIPPED_DELIVERY_DETAILS_SHIPPED_QUANTITY_ZERO');

  

EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;

-----------------------------------------------
-- Diagnostic specific functions and procedures
-----------------------------------------------


---------------------------------
-- MAIN ENTRY POINT
---------------------------------
-- PSD #10
PROCEDURE main(
            p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y')

 IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;

  IF g_is_concurrent THEN
     g_rep_info('Calling From'):='Concurrent Program';
  ELSE
     g_rep_info('Calling From'):='SQL Script';
  END IF;

  l_step := '10';
  initialize_files;
  
  -- PSD #11
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Order Management';

  l_step := '20';
 -- PSD #12

   validate_parameters(
     p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );



  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');
  -- PSD #13
debug('begin section: Sales Order Headers and Lines');
start_section('Sales Order Headers and Lines');
   set_item_result(run_stored_sig('BOOKED_SO_HEADERS_NONBOOKED_LINES'));
   set_item_result(run_stored_sig('CANCELLED_SO_HEADER_INVALID_OPEN_FLAG'));
   set_item_result(run_stored_sig('CANCELLED_CLOSED_SO_HEADERS_OPEN_LINES'));
   set_item_result(run_stored_sig('CANCELLED_SO_LINES_INVALID_OPEN_FLAG'));
   set_item_result(run_stored_sig('INTERNAL_ORDER_SHIPMENTS_MISSING_REQUISITION'));
   set_item_result(run_stored_sig('RMA_RECEIVING_STUCK'));
end_section;
debug('end section: Sales Order Headers and Lines');


debug('begin section: Models');
start_section('Models');
   set_item_result(run_stored_sig('ATO_PTO_MODEL_LINES_INCORRECT_LINK_PARENT'));
   set_item_result(run_stored_sig('CANCELLED_MODEL_LINES_NONCANCELLED_CHILDREN'));
   set_item_result(run_stored_sig('MODEL_COMPONENTS_REMANTS_NOT_FLAGGED'));
   set_item_result(run_stored_sig('MODELS_STATUS_CREATE_CONFIG_ITEM_EXISTS'));
   set_item_result(run_stored_sig('SHIPPABLE_KITS_MODELS_NOT_OM_INTERFACED_COMPONENTS_ARE'));
end_section;
debug('end section: Models');


debug('begin section: Drop/Ship Orders');
start_section('Drop/Ship Orders');
   set_item_result(run_stored_sig('CANCELLED_DROPSHIP_LINES_OPEN_PO_LINES'));
   set_item_result(run_stored_sig('DUPLICATED_DROPSHIP_SOURCES'));
   set_item_result(run_stored_sig('SALES_ORDER_LINES_MULTIPLE_DROPSHIP_SOURCES'));
   set_item_result(run_stored_sig('BOOKED_DROPSHIP_LINES_NULL_SCHEDULED_SHIP_DATE'));
   set_item_result(run_stored_sig('RECEIVED_DROPSHIP_LINES_STUCK_IN_AWAITING_RECEIPT'));
   set_item_result(run_stored_sig('DROPSHIP_LINES_STUCK_IN_AWAITING_RETURN'));
end_section;
debug('end section: Drop/Ship Orders');


debug('begin section: Sales Order Workflow Checks');
start_section('Sales Order Workflow Checks');
   set_item_result(run_stored_sig('CLOSED_SO_HEADERS_PENDING_WF_ACTIVITY'));
   set_item_result(run_stored_sig('CLOSED_SO_LINES_PENDING_WF_ACTIVITY'));
   set_item_result(run_stored_sig('OPEN_SO_HEADERS_WF_FLOW_MISSING_CLOSED'));
   set_item_result(run_stored_sig('OPEN_SO_LINES_WF_FLOW_MISSING_CLOSED'));
   set_item_result(run_stored_sig('OPEN_SO_HEADERS_WF_FLOW_INITIATED_NOT_STARTED'));
   set_item_result(run_stored_sig('OPEN_SO_LINES_WF_FLOW_INITIATED_NOT_STARTED'));
   set_item_result(run_stored_sig('OPEN_SO_HEADERS_WF_FLOW_PENDING_NO_OPEN_LINES'));
end_section;
debug('end section: Sales Order Workflow Checks');


debug('begin section: Deliveries / Delivery Details');
start_section('Deliveries / Delivery Details');
   set_item_result(run_stored_sig('CANCELLED_ORDER_LINES_PENDING_DELIVERIES'));
   set_item_result(run_stored_sig('CLOSED_ORDER_LINES_NOT_ALL_DELIVERY_DETAILS_INTERFACED'));
   set_item_result(run_stored_sig('OPEN_ORDER_LINES_DELIVERY_DETAILS_MISSING'));
   set_item_result(run_stored_sig('RELEASED_DELIVERY_DETAILS_MOVE_ORDER_CLOSED'));
   set_item_result(run_stored_sig('SO_LINE_DELIVERY_DETAIL_SCHEDULED_DATE_MISMATCH'));
   set_item_result(run_stored_sig('DELIVERY_TRIP_STOP_ACTUAL_SHIP_DATE_MISMATCH'));
   set_item_result(run_stored_sig('DELIVERY_DETAILS_ERRORED_WF_SHIP_ACTIVITIES'));
   set_item_result(run_stored_sig('OPEN_DELIVERY_DETAILS_MISSING_COMPLETED_WF_SHIP_ACTIVITIES'));
   set_item_result(run_stored_sig('SHIPPED_DELIVERY_DETAILS_OWNED_OPEN_DELIVERY'));
   set_item_result(run_stored_sig('SHIPPED_DELIVERY_DETAILS_NOT_ELIGIBLE_FOR_OM_INV_INTERFACING'));
   set_item_result(run_stored_sig('SHIPPED_DELIVERY_DETAILS_SHIPPED_QUANTITY_ZERO'));
end_section;
debug('end section: Deliveries / Delivery Details');


debug('begin section: Sets');
start_section('Sets');
   set_item_result(run_stored_sig('FULFILLMENT_STUCK_NO_PENDING_LINES'));
   set_item_result(run_stored_sig('SHIP_SET_STUCK_ONE_LINE_SHIPPED_ONE_NOT'));
end_section;
debug('end section: Sets');


debug('begin section: Other Workflow Checks');
start_section('Other Workflow Checks');
   set_item_result(run_stored_sig('COUNT_WORKFLOW_JOBS_DEFERRED_STATUS'));
   set_item_result(run_stored_sig('COUNT_WORKFLOW_JOBS_ERRORED_STATUS'));
   set_item_result(run_stored_sig('WORKFLOW_ITEMS_PASSED_PURGE_DATE'));
end_section;
debug('end section: Other Workflow Checks');




  -- End of Sections and signatures
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  -- PSD #14
  print_out('<a href="https://community.oracle.com/thread/3551026" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;


PROCEDURE main_cp(
            errbuf                         OUT VARCHAR2
           ,retcode                        OUT VARCHAR2
           ,p_max_output_rows              IN NUMBER      DEFAULT 20
           ,p_debug_mode                   IN VARCHAR2    DEFAULT 'Y'
)
 IS

BEGIN
  g_retcode := 0;
  g_errbuf := null;

-- PSD #17  

   main(
     p_max_output_rows              => p_max_output_rows
    ,p_debug_mode                   => p_debug_mode  );


  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


-- PSD #1
END om_analyzer_pkg;
/
show errors
exit;
-- Exit required for bundling project so do not remove