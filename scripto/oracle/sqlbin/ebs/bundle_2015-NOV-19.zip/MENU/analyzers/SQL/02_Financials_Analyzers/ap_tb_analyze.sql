REM $Id: ap_tb_analyze.sql, 200.2 2015/08/11 10:47:50 arobert Exp skpasupu $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ap_tb_analyze.sql (was run_aptb_diag.sql)                            |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the ap_aptb_detect_pkg.main                    |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 17-JAN-2013 SKPASUPU  Created.                                          |
REM | 25-JUN-2013 SKPASUPU  Generic changed to Daterange Mode                 |
REM | 06-Aug-2013 SKPASUPU Liability Account entered instead of CCID          |
REM | 15-Jan-2014 DAMAL    Ledger_id is required to all modes                 |
REM | 29-Jan-2014 DAMAL    Changed 'Helper' to 'Analyzer'                     |
REM | 17-Mar-2015 AROBERT  Removed Exit and replaced - to for in prompts      |
REM | 11-AUG-2015 AROBERT  Added Bundle messages                              |
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Payables Trial Balance Analyzer
REM
REM MENU_START
REM SQL: Run Payables Trial Balance Analyzer 
REM FNDLOAD: Load Payables Trial Balance Analyzer as a Concurrent Program 
REM MENU_END 
REM
REM HELP_START  
REM 
REM  Payables Trial Balance Analyzer Help [Doc ID: 1553507.1] 
REM
REM Compatible: 12.0|12.1|12.2
REM
REM  Explanation of available options:
REM
REM    (1) Runs ap_aptb_detect_pkg as APPS and outputs an HTML report 
REM
REM    (2) Install Payables Trial Balance Analyzer as a concurrent program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group: 
REM          "Payables Reports Only" 
REM
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: AP_TOP
REM PROG_NAME: APTBVAL
REM DEF_REQ_GROUP: Payables Reports Only
REM APP_NAME: Payables
REM PROG_TEMPLATE: APTBVAL.ldt
REM PROD_SHORT_NAME: SQLAP 
REM
REM FNDLOAD_END  
REM
REM DEPENDENCIES_START 
REM 
REM ap_trial_balance_analyzer.sql
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE 
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT ===========================================================================
PROMPT Enter the Analyzer Mode (Mandatory)
PROMPT Please choose one of the following
PROMPT Transaction (To run it based on invoice_id)
PROMPT Account (To run it based on liability account)
PROMPT Undo (To check the undo datafix on APTB)
PROMPT Daterange (To list all potential problem invoices on APTB)
PROMPT ===========================================================================
PROMPT
ACCEPT mod CHAR PROMPT 'Enter the Analyzer Mode(Transaction/Account/Undo/Daterange): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the Ledger_id (Required for Transaction/Account/Undo/Daterange mode)
PROMPT ===========================================================================
PROMPT
ACCEPT ldgr CHAR PROMPT 'Enter the ledger_id: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the TB_Definition_Code (Required for Transaction/Account/Daterange mode)
PROMPT ===========================================================================
PROMPT
ACCEPT tbcode CHAR PROMPT 'Enter the TB Definition Code: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the Start Date (Required for Transaction/Account/Daterange mode)
PROMPT ===========================================================================
PROMPT
ACCEPT sdate CHAR PROMPT 'Enter the Start Date: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the End Date (Required for Transaction/Account/Daterange mode)
PROMPT ===========================================================================
PROMPT
ACCEPT edate CHAR PROMPT 'Enter the End Date: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the Invoice_id (Required for Transaction mode)
PROMPT ===========================================================================
PROMPT
ACCEPT inv CHAR PROMPT 'Enter the invoice_id(For Transaction Mode): '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the Liability Account (Required for Account/Undo/Daterange mode)
PROMPT For example 01-000-2110-0000-000
PROMPT ===========================================================================
PROMPT
ACCEPT acc CHAR PROMPT 'Enter the Liability Account (For Account/Undo/Daterange Mode): '

DECLARE
  l_ldgr       number        := '&ldgr';
  l_inv        number        := '&inv';
  l_tbcode     VARCHAR2(240) := '&tbcode';
  l_acc        VARCHAR2(240) := '&acc';
  l_sdate      VARCHAR2(240) := '&sdate';
  l_edate      VARCHAR2(240) := '&edate';
  l_mode       VARCHAR2(50)  := '&mod';
  
BEGIN

IF upper(trim(l_mode)) = 'TRANSACTION' THEN
   l_acc := '';
ELSE
   l_inv := '';
END IF;

  ap_aptb_detect_pkg.main(
      p_mode       => l_mode,
      p_ledger_id  => l_ldgr,
      p_invoice_id => l_inv,
      p_tb_code    => l_tbcode,
      p_liab_acc   => l_acc,
      p_start_date => l_sdate,
      p_end_date   => l_edate,
      p_max_output_rows => 20,
      p_debug_mode => 'Y');
      
EXCEPTION 
WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/--added by Bundle.pl
exit;
