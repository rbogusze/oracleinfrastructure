REM $Id: ar_autoinvoice_analyze.sql, 200.1 2015/09/01 11:55:15 vcrisost Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ar_autoinvoice_analyze.sql                                           |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit ar_autoinvoice_analyze_pkg.main                |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 07-Aug-2015 vcrisost Created                                            |
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Oracle Receivables AutoInvoice Analyzer
REM
REM MENU_START
REM
REM SQL: Run Oracle Receivables AutoInvoice Analyzer
REM FNDLOAD: Load Oracle Receivables AutoInvoice Analyzer
REM
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  Oracle Receivables AutoInvoice Analyzer [Doc ID: 1523525.1]
REM
REM  Compatible with: [12.0|12.1|12.2] 
REM 
REM  Explanation of available options:
REM
REM    (1) Runs database package ar_autoinvoice_analyze_pkg.main as APPS to create an HTML report 
REM
REM    (2) Install Oracle Receivables AutoInvoice Analyzer as a concurrent program
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to default request group Payables Reports Only
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: AR_TOP
REM DEF_REQ_GROUP: Receivables All
REM PROG_NAME: ARAUTOINV
REM PROG_TEMPLATE: arautoinv.ldt
REM APP_NAME: Receivables
REM PROD_SHORT_NAME: AR
REM  
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM ar_autoinvoice_analyzer.sql 
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "~"

PROMPT
-- PSD #1
PROMPT Submitting AR AutoInvoice Analyzer
PROMPT ===========================================================================
PROMPT Enter the org_id for the operating unit.  This parameter is required.
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 1 NUMBER DEFAULT -1 -
       PROMPT 'Enter the org_id(required): '

PROMPT
PROMPT =======================================================================================================================================
PROMPT Enter request ID to review transactions created for a specific request, or enter 0 if you do not want to run for a specific request.
PROMPT ======================================================================================================================================
PROMPT
-- PSD #2
ACCEPT 2 NUMBER DEFAULT 0 -
       PROMPT 'Enter Request ID(required): '

PROMPT
PROMPT ===========================================================================
PROMPT Enter the responsibility ID you ran AutoInvoice from. This parameter is required.
PROMPT ===========================================================================
PROMPT
-- PSD #2
ACCEPT 3 NUMBER DEFAULT -1 -
       PROMPT 'Enter Responsibility ID(required): '
PROMPT


DECLARE
-- PSD #3
  l_org_id         NUMBER := '~1';
  l_req_id         NUMBER := '~2';
  l_resp_id        NUMBER := '~3';

BEGIN

-- PSD #4
  AR_AUTOINVOICE_ANALYZER_PKG.main(
      p_org_id => l_org_id,
      p_request_id => nvl(l_req_id,0),
      p_resp_id => l_resp_id);

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit; 
