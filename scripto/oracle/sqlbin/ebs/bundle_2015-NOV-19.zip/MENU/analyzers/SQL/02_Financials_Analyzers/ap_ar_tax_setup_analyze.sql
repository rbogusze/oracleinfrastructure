REM $Id: ap_ar_tax_setup_analyze.sql, 200.4 2015/26/08 23:27:42 armitra Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    tax_setup_analyze.sql                                                          |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the tax_setup_detect_pkg.main procedure      |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 26-AUG-2015 ARMITRA  Created.                                          |
REM +=========================================================================+
REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2 
REM 
REM MENU_TITLE: EBTax Setup and Data Integrity Analyzer
REM
REM MENU_START
REM 
REM SQL: Run EBTax Setup and Data Integrity Analyzer 
REM FNDLOAD: Load EBTax Setup and Data Integrity Analyzer Concurrent Program 
REM 
REM MENU_END 
REM 
REM HELP_START  
REM 
REM  EBTax Setup and Data Integrity Analyzer [Doc ID: 1529429.1]
REM
REM  Compatible: 12.0|12.1|12.2 
REM
REM  Explanation of available options:
REM
REM    (1) Runs EBTax Setup and Data Integrity Analyzer
REM        o Runs tax_setup_detect_pkg.main 
REM        o Creates an HTML report file on the database server, 
REM          typically under /usr/tmp: 
REM          EB-Tax_Analyzer_<hostname>_<instancename>_<date>.html
REM
REM    (2) Runs FNDLOAD to Install EBTax Setup and Data Integrity Analyzer
REM        as a Concurrent Program
REM        o Concurrent Program Name: "APEBTAXAZ"
REM        o Default Request Group: "Payables Reports Only" 
REM 
REM HELP_END 
REM 
REM FNDLOAD_START 
REM PROD_TOP: AP_TOP
REM DEF_REQ_GROUP: Payables Reports Only
REM PROG_NAME: APEBTAXAZ 
REM PROG_TEMPLATE: ebtaxaz.ldt
REM APP_NAME: Payables
REM PROD_SHORT_NAME: SQLAP 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM
REM ap_ar_tax_setup_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END 

SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
PROMPT Submitting Payables and Tax Setup Analyzer.
PROMPT
PROMPT ===========================================================================
PROMPT Enter the Transaction Id. (This parameter is optional, ENTER for none)
PROMPT ===========================================================================
PROMPT
ACCEPT Transaction_Id NUMBER PROMPT 'Enter the Transaction Id of AP/AR Invoice: '
PROMPT ===========================================================================
PROMPT Enter the Application Id. (This parameter is optional, ENTER for none)
PROMPT ===========================================================================
PROMPT
ACCEPT Application_Id NUMBER PROMPT 'Enter the Application Id(200 for AP / 222 for AR): '
PROMPT ===========================================================================
PROMPT Enter the maximum number of rows to display on row limited queries
PROMPT ===========================================================================
PROMPT
ACCEPT max_rows NUMBER DEFAULT 9999 -
       PROMPT 'Enter the maximum rows to display [9999]: '
PROMPT
PROMPT

DECLARE
  l_invoice_id      NUMBER := &Transaction_Id;
  l_appl_ids     NUMBER := &Application_Id;
  l_max_rows    NUMBER := &max_rows;

BEGIN

 if l_invoice_id = 0 Then
  l_invoice_id := NULL;
end if;

if l_appl_ids = 0 Then
  l_appl_ids := NULL;
end if;

 tax_setup_detect_pkg.main(
      p_invoice_id => l_invoice_id,
      p_appl_ids => l_appl_ids,
      p_max_output_rows => l_max_rows,
      p_debug_mode => 'N'); 


  
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
