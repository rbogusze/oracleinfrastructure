REM $Id: hcm_analyzer.sql 200.48 2015/2/10 05:11:16 pkm ship $
REM   
REM  Consolidated script to diagnose issues that can cause problems in your HCM on an environment.
REM
REM   hcm_analyzer.sql
REM   How to run it? Follow the directions found in the Note 1562530.1 EBS Human Capital Management (HCM) Technical Analyzer 
REM   
REM   	sqlplus apps/<password>	@hcm_analyzer.sql run_type (ALL for data collector or ISSUES for analyzer) product (BEN, HR, IRC, OTL, OTA, PAY, SSHR, ALL)
REM
REM   Output file format found in the same directory if run manually in the file you spooled

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 12.0 12.1 12.2
REM 
REM MENU_TITLE: HCM Technical Analyzer for R12
REM
REM MENU_START
REM
REM SQL: Run HCM Technical Analyzer for R12
REM FNDLOAD: Load HCM Technical Analyzer Analyzer for R12 as a Concurrent Program 
REM 
REM MENU_END 
REM
REM HELP_START  
REM 
REM  HCM Technical Analyzer Help (Related Doc ID: 1562530.1) 
REM
REM  Compatible: 12.0 12.1 12.2
REM 
REM  Explanation of available options:
REM
REM    (1) Run HCM Technical Analyzer
REM        o Runs hcm_analyzer.sql as APPS 
REM        o Creates an HTML report in MENU/output 
REM
REM    (2) Install HCM Technical Analyzer as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: 
REM          "Global HRMS Reports & Process" 
REM
REM
REM HELP_END 
REM 
REM FNDLOAD_START 
REM
REM PROD_TOP: PER_TOP
REM PROG_NAME: HCM_ANALYZER_SQL
REM DEF_REQ_GROUP: Global HRMS Reports & Process
REM APP_NAME: Human Resources
REM PROG_TEMPLATE: hcm12.ldt
REM CP_FILE: hcm_analyzer.sql
REM PROD_SHORT_NAME: PER 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM ARG: RUN_TYPE: Enter RUN TYPE [Ex: ISSUES/ALL] DEFAULT: ALL
REM ARG: PRODUCT: Enter Product Code [Ex: HR/PAY/BEN/OTL/OTA/IRC/SSHR/ALL] DEFAULT: ALL
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: STDOUT 
REM
REM ANALYZER_BUNDLE_END

set echo off
undefine v_headerinfo
Define   v_headerinfo     = '$Header: HCM_analyzer.sql 200.48'
undefine v_queries_ver
Define   v_queries_ver    = '05-Mar-2015'
undefine v_scriptlongname
Define   v_scriptlongname = 'HCM Analyzer'

undefine v_nls
undefine v_version
clear columns
variable v_nls		varchar2(50);
variable v_version	varchar2(17);

set arraysize 1
set heading off
set feedback off  
set echo off
set verify off
SET CONCAT ON
SET CONCAT .
SET ESCAPE OFF
SET ESCAPE '\'

set lines 120
set pages 9999
set serveroutput on size 1000000

set head off feedback off
set serveroutput on size 1000000
set feedback off
set verify off
set echo off
set long 2000000000
set linesize 32767
set longchunksize 32767
--set wrap off
set pagesize 0
set timing off
set trimout on
set trimspool on
set heading off
set autoprint off

--Verify RDBMS version

DECLARE

BEGIN
				
	select max(version)
	into :v_version
	from v$instance;

	:v_version := substr(:v_version,1,9);

	if :v_version < '10.2.0.5.0' and :v_version > '4' then
	  dbms_output.put_line(chr(10));
	  dbms_output.put_line('RDBMS Version = '||:v_version);
	  dbms_output.put_line('ERROR - The Script requires RDBMS version 10.2.0 or higher');
	  dbms_output.put_line('ACTION - Type Ctrl-C <Enter> to exit the script.');
	  dbms_output.put_line(chr(10));
	end if;

	null;

	exception
	  when others then
		dbms_output.put_line(chr(10));
		dbms_output.put_line('ERROR  - RDBMS Version error: '|| sqlerrm);
		dbms_output.put_line('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
							 '         Type Ctrl-C <Enter> to exit the script.');
		dbms_output.put_line(chr(10));
END;
/

--Verify NLS Character Set

DECLARE

BEGIN

	select value
	into :v_nls
	from v$nls_parameters
	where parameter = 'NLS_CHARACTERSET';

	if :v_version < '8.1.7.4.0' and :v_version > '4' and :v_nls = 'UTF8' then
	  dbms_output.put_line(chr(10));
	  dbms_output.put_line('RDBMS Version = '||:v_version);
	  dbms_output.put_line('NLS Character Set = '||:v_nls);
	  dbms_output.put_line('ERROR - The HTML functionality of this script is incompatible with this Character Set for RDBMS version 8.1.7.3 and lower');
	  dbms_output.put_line('ACTION - Please report the above error to Oracle Support Services.');
	  dbms_output.put_line(chr(10));
	end if;

	exception
	  when others then
		dbms_output.put_line(chr(10));
		dbms_output.put_line('ERROR  - NLS Character Set error: '|| sqlerrm);
		dbms_output.put_line('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
							 '         Type Ctrl-C <Enter> to exit the script.'  || chr(10) );
		dbms_output.put_line(chr(10));
END;
/



variable st_time 	varchar2(100);
variable et_time 	varchar2(100);



begin
select to_char(sysdate,'hh24:mi:ss') into :st_time from dual;
end;
/

/*
COLUMN host_name NOPRINT NEW_VALUE hostname
SELECT host_name from v$instance;
COLUMN instance_name NOPRINT NEW_VALUE instancename
SELECT instance_name from v$instance;
COLUMN sysdate NOPRINT NEW_VALUE when
select to_char(sysdate, 'YYYY-Mon-DD') "sysdate" from dual;
SPOOL hcm_&&hostname._&&instancename._&&when..html
*/

VARIABLE n		        NUMBER;
VARIABLE HOST        	VARCHAR2(80);
VARIABLE SID         	VARCHAR2(20);
VARIABLE apps_rel  varchar2(50);
VARIABLE hr_status varchar2(20);
VARIABLE pay_status varchar2(20);
VARIABLE v_rup_date varchar2(20);
VARIABLE e1 number;
VARIABLE e2 number;
VARIABLE e3 number;
VARIABLE e4 number;
VARIABLE e5 number;
VARIABLE e6 number;
VARIABLE e7 number;
VARIABLE w1 number;
VARIABLE w2 number;
VARIABLE w3 number;
VARIABLE w4 number;
VARIABLE w5 number;
VARIABLE w6 number;
VARIABLE w7 number;
VARIABLE rup_level_n varchar2(50);
VARIABLE p1 varchar2(50);
VARIABLE p2 varchar2(50);
alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY HH24:MI:SS';





REM ================= Pl/SQL api start ========================================
set termout on
prompt <html lang="en,us"><head><!--


undefine nbsp
define nbsp = ''
column lnbsp new_value nbsp noprint
select chr(38) || 'nbsp' lnbsp from dual;

undefine p_id
define p_id = ''
column lp_id new_value p_id noprint
select chr(38) || 'p_id' lp_id from dual;

undefine lt
define lt = ''
column llt new_value lt noprint
select chr(38) || 'lt' llt from dual;

undefine gt
define gt = ''
column lgt new_value gt noprint
select chr(38) || 'gt' lgt from dual;

undefine AMPER
define AMPER = ''
column lAMPER new_value AMPER noprint
select chr(38) lAMPER from dual;

undefine T_VARCHAR2
undefine T_ROWID
undefine T_NUMBER
undefine T_LONG
undefine T_DATE
undefine T_CHAR
undefine T_CLOB

variable g_hold_output clob;
variable g_curr_loc number;


declare
v_date varchar2(200);
issuep boolean := FALSE;

-- Procedure to output html content
procedure l_o (text varchar2) is
   l_ptext      varchar2(32767);
   l_hold_num   number;
   l_ptext2      varchar2(32767);
   l_hold_num2   number;
begin
   l_hold_num := mod(:g_curr_loc, 32767);
   
   l_hold_num2 := mod(:g_curr_loc, 14336);
   if l_hold_num2 + length(text) > 14000 then
      l_ptext2 := '                                                                                                                                                                                                      ';
      dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
   end if;
   
   l_hold_num2 := mod(:g_curr_loc, 18204);
   if l_hold_num2 + length(text) > 17900 then
      l_ptext2 := '                                                                                                                                                                                                ';
      dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	 
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	
   end if;
   
   if l_hold_num + length(text) > 32759 then
      l_ptext := '<!--' || rpad('*', 32761-l_hold_num,'*') || '-->';
      dbms_lob.write(:g_hold_output, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
   end if;
   dbms_lob.write(:g_hold_output, length(text)+1, :g_curr_loc, text || chr(10));
   :g_curr_loc := :g_curr_loc + length(text)+1;
   
   --dbms_lob.write(:g_hold_output, length(text), :g_curr_loc, text );
   --g_curr_loc := g_curr_loc + length(text);
   
end l_o;


-- Procedure Name: Insert_Style_Sheet
-- Output: Inserts a Style Sheet into the output
procedure Insert_Style_Sheet is
begin
   l_o('<TITLE>HCM Technical Analyzer</TITLE>');
   l_o('<STYLE TYPE="text/css">');
   l_o('<!--');
   l_o('.divTitle {-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;font-family: Calibri;background-color: #152B40;');
  l_o('border: 1px solid #003399;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;color: #F4F4F4;font-size: x-large;font-weight: bold;}');
  l_o('.divTitle1 {font-family: Calibri;font-size: large; font-weight: bold;}');
  l_o('.divSection {-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;font-family: Calibri;');
  l_o('background-color: #CCCCCC;border: 1px solid #DADADA;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;}');
  l_o('.divSectionTitle {');
	l_o('width: 98.5%;font-family: Calibri;font-weight: bold;background-color: #152B40;color: #FFFFFF;padding: 9px;margin: 0px;');
	l_o('box-shadow: 3px 3px 3px #AAAAAA;-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;height: 30px;overflow:hidden;}');
  l_o('.columns       { ');
	l_o('width: 98.5%; font-family: Calibri;font-weight: bold;background-color: #254B72;color: #FFFFFF;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;');
	l_o('-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;height: 30px;}');
	l_o('div.divSectionTitle div   { height: 30px; float: left; }');
	l_o('div.left          { width: 80%; background-color: #152B40; font-size: x-large; border-radius: 6px; }');
	l_o('div.right         { width: 20%; background-color: #152B40; font-size: medium; border-radius: 6px;}');
	l_o('div.clear         { clear: both; }');

l_o('.divItem {-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;font-family: Calibri;');
  l_o('background-color: #F4F4F4;border: 1px solid #EAEAEA;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;}');
l_o('.divItemTitle {font-family: Calibri;font-size: medium;font-weight: bold;color: #336699;border-bottom-style: solid;border-bottom-width: medium;');
  l_o('border-bottom-color: #3973AC;margin-bottom: 9px;padding-bottom: 2px;margin-left: 3px;margin-right: 3px;}');
	l_o('.divwarn {-moz-border-radius: 6px;-webkit-border-radius: 6px;border-radius: 6px;font-family: Calibri;color: #333333;');
	l_o('  background-color: #FFEF95;border: 0px solid #FDC400;padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;font-size: 11pt;}');
	l_o('.diverr {font-family: Calibri;font-size: 11pt;font-weight: bold;color: #333333; background-color: #ffd8d8;');
	l_o('  box-shadow: 3px 3px 3px #AAAAAA; -moz-border-radius: 6px; -webkit-border-radius: 6px;border-radius: 6px;padding: 9px;margin: 0px;}');
	l_o('.graph {font-family: Arial, Helvetica, sans-serif;font-size: small;}');
	l_o('.graph tr {font-family: Arial, Helvetica, sans-serif;font-size: small;background-color: transparent;}');
	l_o('.graph td {font-family: Arial, Helvetica, sans-serif;font-size: small;background-color: transparent;border: 0px transparent;}');
	l_o('.TitleBar, .TitleImg{display:table-cell;width:95%;vertical-align: middle;--border-radius: 6px;font-family: Calibri;background-color: #152B40;');
	l_o('padding: 9px;margin: 0px;box-shadow: 3px 3px 3px #AAAAAA;color: #F4F4F4;font-size: xx-large;font-size: 4 vw;font-weight: bold;overflow:hidden;}');
	l_o('.TitleImg{}');
	l_o('.TitleBar > div{height:25px;}');
	l_o('.TitleBar .Title2{font-family: Calibri;background-color: #152B40;padding: 9px;margin: 0px;color: #F4F4F4;font-size: medium;font-size: 4 vw;}');
	l_o('.divok {border: 1px none #00CC99;font-family: Calibri;font-size: 11pt;font-weight: normal;');
	l_o('  background-color: #ECFFFF;color: #333333;padding: 9px;margin: 0px; box-shadow: 3px 3px 3px #AAAAAA;-moz-border-radius: 6px;');
	l_o('  -webkit-border-radius: 6px;border-radius: 6px;}');
	l_o('.divSum {font-family: Calibri;background-color: #F4F4F4;}');
    l_o('.divSumTitle {font-family: Calibri;font-size: medium;color: #336699;}');
	l_o('A {	COLOR: #0066cc}');
	l_o('A:visited {	COLOR: #0066cc}');
	l_o('A:hover {	COLOR: #0099cc}');
	l_o('A:active {	COLOR: #0066cc}');
	l_o('.detail {	TEXT-DECORATION: none}');
	l_o('.detail2 {	font-size: 12pt; font-weight: bold;}');
   l_o('.ind1 {margin-left: .25in}');
   l_o('.ind2 {margin-left: .50in}');
   l_o('.ind3 {margin-left: .75in}');
   l_o('.tab0 {font-size: 10pt; font-weight: normal}');
   l_o('.tab1 {text-indent: .25in; font-size: 10pt; font-weight: normal}');
   l_o('.tab2 {text-indent: .5in; font-size: 10pt; font-weight: normal}');
   l_o('.tab3 {text-indent: .75in; font-size: 10pt; font-weight: normal}');
   l_o('.error {color: #cc0000; font-size: 10pt; font-weight: normal}');
   l_o('.errorbold {font-weight: bold; color: #cc0000; font-size: 10pt}');
   l_o('.warning {font-weight: normal; color: #336699; font-size: 10pt}');
   l_o('.warningbold {font-weight: bold; color: #336699; font-size: 10pt}');
   l_o('.notice {font-weight: normal; font-style: italic; color: #663366; font-size: 10pt}');
   l_o('.noticebold {font-weight: bold; font-style: italic; color: #663366; font-size: 10pt}');
   l_o('.section {font-weight: normal; font-size: 10pt}');  
   l_o('.sectionred {font-weight: normal; font-size: 11pt; font-weight: bold}');
   l_o('.sectionblue {font-weight: normal; color: #0000FF; font-size: 11pt; font-weight: bold}');
   l_o('.sectionblue1 {font-weight: normal; color: #0000FF; font-size: 11pt; font-weight: bold}');
   l_o('.sectionorange {font-weight: normal; color: #AA4422; font-size: 11pt; font-weight: bold}');
   l_o('.sectionbold {font-weight: bold; font-size: 14pt}');
   l_o('.sectiondb {font-weight: normal; color: #884400; font-size: 11pt; font-weight: bold}');
   l_o('.sectionb {font-weight: normal; color: #000000; font-size: 11pt;  font-family: Calibri}');
   l_o('.BigPrint {font-weight: bold; font-size: 14pt}');
   l_o('.SmallPrint {font-weight: normal; font-size: 8pt}');
   l_o('.BigError {color: #cc0000; font-size: 12pt; font-weight: bold}');
   l_o('.code {font-weight: normal; font-size: 8pt; font-family: Courier New}');
   l_o('span.errbul {color: #EE0000;font-size: large;font-weight: bold;text-shadow: 1px 1px #AAAAAA;}');
   l_o('.legend {font-weight: normal;color: #0000FF;font-size: 9pt; font-weight: bold}');
   l_o('.btn {border: #000000;border-style: solid;border-width: 2px;width:190;height:50;border-radius: 6px;background: linear-gradient(#FFFFFF, #B0B0B0);font-weight: bold;color: blue;margin-top: 5px;margin-bottom: 5px;margin-right: 5px;margin-left: 5px;vertical-align: middle;}');  
   l_o('.toctable {background-color: #F4F4F4;}');
   l_o('span.warbul {color: #FFAA00;font-size: large;font-weight: bold;text-shadow: 1px 1px #AAAAAA;}');
   l_o('body {background-color: white; font: normal 12pt Ariel;}');
   l_o('table {background-color: #000000 color:#000000; font-size: 10pt; font-weight: bold; line-height:1.5; padding:2px; text-align:left}');
   l_o('h1, h2, h3, h4 {color: #00000}');
   l_o('h3 {font-size: 16pt}');
   l_o('td {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt; border-style: solid; border-width: 1; border-color: #DEE6EF}');
   l_o('tr {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt}');
   l_o('th {background-color: #DEE6EF; color: #000000; height: 20; border-style: solid; border-width: 2; border-color: #f7f7e7}');
   l_o('th.rowh {background-color: #CCCC99; color: #336699; height: 20; border-style: solid; border-width: 1; border-top-color: #f7f7e7; border-bottom-color: #f7f7e7; border-left-width: 0; border-right-width: 0}');
   l_o('-->');
   l_o('</style>');
end;



-- Procedure Name: Show_Header
-- Output: Displays Standard Header Information
-- Examples: Show_Header('139684.1', 'Oracle Applications Current Patchsets Comparison to applptch.txt', 'Version 1.0');

procedure Show_Header(p_note varchar2, p_title varchar2, p_ver varchar2, p_queries_ver varchar2) is
   l_instance_name   varchar2(16) := null;
   l_host_name   varchar2(64) := null;
   l_version   varchar2(17) := null;
   l_multiorg   varchar2(4) := null;
   l_user   varchar2(100) := null;   
begin
   DBMS_LOB.CREATETEMPORARY(:g_hold_output,TRUE,DBMS_LOB.SESSION);
   select instance_name
        , host_name
        , version
     into l_instance_name
        , l_host_name
        , l_version
     from v$instance;

   select decode (multi_org_flag, 'Y', 'Yes', 'No') into l_multiorg from fnd_product_groups;

   select user
     into l_user
     from dual;

	  l_o('-->');
	-- Add the ability to display a popup text window
	  l_o('<script language="JavaScript" type="text/javascript">');
	  l_o('function popupText(pText){');
	  l_o('var frog = window.open("","SQL","width=800,height=500,top=100,left=300,location=0,status=0,scrollbars=1,resizable=1")');
	  l_o('var html = "<html><head><"+"/head><body>"+ pText +"<"+"/body><"+"/html>";');
	  l_o('frog.document.open();');
	  l_o('frog.document.write(html);');
	  l_o('frog.document.close();');
	  l_o('}');
  
	l_o('    function displayRow(target)');
	l_o('   {var row = document.getElementById(target);');
	l_o('   	if (row.style.display == '''')  ');
	l_o('   		row.style.display = ''none'';	');
	l_o('   	else ');
	l_o('    		row.style.display = '''';   '); 
	l_o('     }');
	
	l_o(' function displayItem(e, itm_id) {');
    l_o(' var tbl = document.getElementById(itm_id);');
    l_o(' if (tbl.style.display == ""){');
    l_o('    e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));    ');    
    l_o('    tbl.style.display = "none"; }');
    l_o(' else {');
    l_o('     e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660)); ');        
    l_o('     tbl.style.display = ""; }');
    l_o('}');
	
	l_o('function displayItem2(e, itm_id) {');
    l_o(' var tbl = document.getElementById(itm_id);');
    l_o(' if (tbl.style.display == ""){');
    l_o('    e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
    l_o('    e.innerHTML = e.innerHTML.replace("Hide","Show");');
    l_o('    tbl.style.display = "none"; }');
    l_o(' else {');
    l_o('     e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
    l_o('     e.innerHTML = e.innerHTML.replace("Show","Hide");');
    l_o('     tbl.style.display = ""; }');
    l_o('}');
	
	  l_o('function activateTab(pageId) {');
	l_o('     var tabCtrl = document.getElementById(''tabCtrl'');');
	l_o('       var pageToActivate = document.getElementById(pageId);');
	l_o('       for (var i = 0; i < tabCtrl.childNodes.length; i++) {');
	l_o('           var node = tabCtrl.childNodes[i];');
	l_o('           if (node.nodeType == 1) { /* Element */');
	l_o('               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';');
	l_o('           }}}');
	l_o(' function displayItem(e, itm_id) {');
    l_o(' var tbl = document.getElementById(itm_id);');
    l_o(' if (tbl.style.display == ""){');
    l_o('    e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));    ');    
    l_o('    tbl.style.display = "none"; }');
    l_o(' else {');
    l_o('     e.innerHTML =');
    l_o('       e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660)); ');        
    l_o('     tbl.style.display = ""; }}');
	
	l_o('function activateTab2(pageId) {');
	l_o('     var tabCtrl = document.getElementById(''tabCtrl'');');
	l_o('       var pageToActivate = document.getElementById(pageId);');
	l_o('       for (var i = 0; i < tabCtrl.childNodes.length; i++) {');
	l_o('           var node = tabCtrl.childNodes[i];');
	l_o('           if (node.nodeType == 1) { /* Element */');
	l_o('               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';');
	l_o('           } }');
	l_o('        tabCtrl = document.getElementById(''ExecutionSummary2'');');
	l_o('        tabCtrl.style.display = "none";');
	l_o('        tabCtrl = document.getElementById(''ExecutionSummary1'');');
    l_o('        tabCtrl.innerHTML = tabCtrl.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));}');
	
	l_o('function opentabs() {');
    l_o(' var tabCtrl = document.getElementById(''tabCtrl''); ');      
    l_o('   for (var i = 0; i < tabCtrl.childNodes.length; i++) {');
    l_o('       var node = tabCtrl.childNodes[i];');
	l_o(' if (node.nodeType == 1)  {');
	l_o('	   if (node.toString() != ''[object HTMLScriptElement]'') { node.style.display =  ''block'' ; ');
     l_o('      }  }   }  }');
   
    l_o('function closetabs() {');
    l_o(' var tabCtrl = document.getElementById(''tabCtrl'');  ');     
    l_o('   for (var i = 0; i < tabCtrl.childNodes.length; i++) {');
    l_o('       var node = tabCtrl.childNodes[i];');
    l_o('       if (node.nodeType == 1) { /* Element */');
    l_o('           node.style.display =  ''none'' ;  }    }   }');
	
	l_o('function closeall()');
	l_o('{var txt = "s1sql";');
	l_o('var i;                                                                    ');
	l_o('var x=document.getElementById(''s1sql0'');                                      ');
	l_o('for (i=0;i<88;i++)                                                               ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';   ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  ');
	l_o('              }  	}');	
	l_o('for (i=272;i<277;i++)                                                                                         ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';   ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  }  	}');	
	l_o('for (i=472;i<477;i++)                                                                                         ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';   ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  ');
	l_o('              }  	}');	
	l_o('txt = "s1sql100";                                                                                       ');
	l_o('for (i=1;i<300;i++)                                                                                   ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                      ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none''; ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  }}	    ');  
	l_o('txt = "s1sql200";                                                                                       ');
	l_o('for (i=1;i<300;i++)                                                                                   ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                      ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none''; ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Hide","Show"); }  }	}	}     '); 

	
	l_o('function openall()');
	l_o('{var txt = "s1sql";');
	l_o('var i;                                                                    ');
	l_o('var x=document.getElementById(''s1sql0'');                                      ');
	l_o('for (i=0;i<88;i++)                                                               ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''''; 	');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  ');
	l_o('              }  	}');	
	l_o('for (i=272;i<277;i++)                                                                                         ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''''; ');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  ');
	l_o('              }  	}');	
	l_o('for (i=472;i<477;i++)                                                                                         ');
	l_o('{			   x=document.getElementById(txt.concat(i.toString()));                                             ');
	l_o('		   if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = '''';');
	l_o('			x = document.getElementById(txt.concat(i.toString(),''b''));  ');
	l_o('			if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));');
	l_o('			               x.innerHTML = x.innerHTML.replace("Show","Hide"); }  ');
	l_o('              }  	}');	
	l_o('		  }                                                                         ');
	
	
	l_o('    function hideRow(target)');
    l_o('    {var row = document.getElementById(target);');
   	l_o('    row.style.display = ''none'';');
	l_o('    row = document.getElementById(target.concat(''b''));');
	l_o('    row.scrollIntoView();');
	l_o('    row.innerHTML = row.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
    l_o('     }');
	l_o('    function hideRow2(target)');
    l_o('    {var row = document.getElementById(target);');
   	l_o('    row.style.display = ''none'';');
	l_o('    row = document.getElementById(target.concat(''b''));');
	l_o('    row.scrollIntoView();');
	l_o('    row.innerHTML = row.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));');
	l_o('    row.innerHTML = row.innerHTML.replace("Hide","Show");');
    l_o('     }');
	l_o('</script>');
	l_o('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>');
	l_o('<script>');
	l_o('$(document).ready(function(){');
	l_o('var src = $(''img#error_ico'').attr(''src'');');
	l_o('$(''img.error_ico'').attr(''src'', src);');
	l_o('var src = $(''img#warn_ico'').attr(''src'');');
	l_o('$(''img.warn_ico'').attr(''src'', src);');
	l_o('var src = $(''img#check_ico'').attr(''src'');');
	l_o('$(''img.check_ico'').attr(''src'', src);');
	l_o('});</script>');

	Insert_Style_Sheet;
	l_o('</head><body>');
	
	--error icon
	l_o('<div style="display: none;">');
	l_o('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAANYSURBVHjaYvz//z8DDBQwMor+ZWDw+8fA4PKHgcEUiOWB+CEQnwbiPb8ZGDat+///NQMSAAggRpgBQM3OQI25XiGe/jr2Ngwi6hoMbHz8DF/v3mR4dO4cw/HjZxjWHru4C2hQ3+7//3fCDAAIILABhUDNUnJS/UHZSbpKcuIMDCf3Mvy9fo7h7/OnDP+FxRj+i8sx/BOXZTh8+xnDosPnb936/L3yzP//60AGAAQQYwEDA8jZs/M7a/yVvz9n+LdxAcP/v38Z/gId9g/oJBD9F0wzAj2kzrDn43+G7pM3j7xkYEh5+P//TYAAYgL5GeRskM3/Ni1gYEyrZWCcsx9FM9fC/Qzs2fUMP4Heseb6z+AgzmfDycAQw8jIyAYQQExAP7mA/Axy9r8/QOOM7RmYTB0YWOfvBxsA0sxi5gDE9kDD/jP8e/2KQZeXlYGJgcEe6AMJgABiSGNguPN919r/v93l/v/UZfj/XYfh/59T+/+DwO+TEPrnif3/nygy/H8oz/D/niLr/yMawv+1GBieAw0wAgggkAvk2fgFGf6/eMrwD+rkb3GODH9OHQDb/OvkAYbXkY6QcADiP79+Mwj8/c0AVCoKNEAAIIBABjz8dvcGwz8hMbABIMwJdTZIM5u5A4Pwsv0Mf4Caf4Mw0PHPvv4C0gyg9MAFEEAgA04/PHeW4b+EHNgGzgUIzW+ANv88cYCBw8KBQXLlfrD8v/9MDFe//QEZcBtowDeAAAIZsOfEsTPguAZF1e+TB+Ga/wBd8yzMkeH78QMMX48dBBvwGyh25vtfhh8MDBeABnwACCDGQKBfgJwlBT42bmZ/3jL8unOD4S8w+EGaQZHyBxqdIPZfRmaGjV8ZGOZ+/nvyFQPDFKC+QwABxARK20Dn9C0EprC9n4BOVFBn+McvBFTMyvCHgZHhD1DTX0YWht/MrGDNG77+vfuFgWELUPNNoAteAAQQPC+YMjIGAdNaoZOkgI0eLxuDAhsDg9DfPwxPvv5kuPrlF8Ppb38ZDv/4dxKk+R0Dw0GglutAvW8AAogROTfKMzKqg1IYKJEADVMFRRUotEEBBvLzRwaGU1Cb74M0g/QABBCKAWABYPIEpzAGBhFQPIOiChTaoAADYpCmF0A9v2DqAQIMAAqQl7ObLOmtAAAAAElFTkSuQmCC" alt="error_ico">');
	 --warning icon
	l_o('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAJHSURBVHjaYvz//z8DNjAhlnHdv38MgUC8vmT5/yAGHAAggBhABqDj/hgG7+OLvP+DwJEF3v+jLRgKsKkDYYAAYsJiMzMDI0uHkV87A8NpRgYJ9q0MSqIMBQJcjFLYHAAQQBgGAJ2c7BaZpMP26ziYr6zMwGBhwiDvb8BQxAgE6OoBAgjFOb1RDDwTE3mf/v3+5H9nCvf/FEfG/51JjP+fb2T4X+3F8EZFlEEL3QsAAcSEZnuRX3KhFNO7uQxnL3xjuPuQgeHsJQYGCVEGBjtLBmFbFYZyoCNYkPUABBDcgJ5IRmluQZkyeZM0Bobn3QziohBxcRGQyQwMVsZANi9DmKk8gyWyAQABxIRke3VgZhU344tWIOcLg4c9JHo9bIH0XwYGHg4GBjcbBg49SbArOGD6AAKIEeSPrnBGLSFp7UsprauYGa7qAQ34C9YEshlMQ/G/PwwM5V0M/048YAg+fO//BpABAAHEBLW9KzS/k5nhSRlc88K1DAwxJYwMC9cjDGACGujvwMCkIcpQBXQFL0gvQAAxdYQy2hvb23vzC/EwMLzbCrd591FGhmevgPRxRoQrgC6w0WVg0FdkMHVSZogGGQAQQExA20stA0rBAcfwH+FsV4v/DFLAgHQ1+w/XDDPISpuBQU6AIRnoCmGAAGIBGmDCeNuHgYEDyc9AOt4biD3QNP+ByKlKMjCwMzGogNIZQACBDNjS08+QDKQZ8GFQnkOmP/5gOA00QAAggMCxAHSKPpAjx0A6eAQQQIy4sjOxACDAAOXOBcGE78mYAAAAAElFTkSuQmCC" alt="warn_ico">');
	  --check icon
	l_o('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAANbY1E9YMgAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAELSURBVHjaYvz//z8DJQAggJhIUcyYwNjAGMP4nzGcsQEmBhBADCAXEIMZ4hkaGKIZ/h//dvw/QyDDfwZnhskgcYAAIl3zKQYI9mIA+V0dIIDI12zOsAxogC9AAEEUpQIVpQIFgTSG5ig8moEuAAgguObjv4//RzYExeYL2DWD1AEEEANc82uG/1Ufq/4zJAMVBTNMhtt8EarZE1MzCAMEEML5rxkQhhBhMwwDBBAiDEA2PwXie0BDXlURtBmGAQIIwYA6m+E6A0KzF37NIAwQQKgcb6AhgcRrBmGAAMIUAKYwYjWDMEAAMWLLTIyMjOpASg2IbwHlb+LLHwABxEhpbgQIICYGCgFAgAEAGJx1TwQYs20AAAAASUVORK5CYII=" alt="check_ico">');
	l_o('</div>');
	
	l_o('<div class="TitleBar"><div class="Title1">HCM Technical Analyzer</div>');
	l_o('<div class="Title2">Compiled using version 200.48 / Latest version: ');
	l_o('<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1562530.1:HCM_ANALYZER">');
	l_o('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/hcm_technical_latest_version.gif" title="Click here to download the latest version of analyzer" alt="Latest Version Icon"></a></div></div>');
	l_o('<div class="TitleImg"><a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div><br>');	

	l_o('<div class="divSection">');	
	l_o('<div class="divItem">');
	l_o('<div class="divItemTitle">Report Information</div>');
	l_o('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');	


end Show_Header;

-- Display database and application details
procedure overview is
		run_type varchar2(20):='&&1';
        product varchar2(20):='&&2';
		db_ver		VARCHAR2(100); 		
		platform varchar2(100);
		db_charset V$NLS_PARAMETERS.value%type;
		db_lang V$NLS_PARAMETERS.value%type;
		multiOrg FND_PRODUCT_GROUPS.MULTI_ORG_FLAG%type;
		multiCurr FND_PRODUCT_GROUPS.MULTI_CURRENCY_FLAG%type;
		v_hxc_status 	FND_LOOKUPS.MEANING%type;
		v_hxt_status 	FND_LOOKUPS.MEANING%type;
		rup_level varchar2(20);
		v_date varchar2(200);
		v_exists number;
		v_code varchar2(50);
		v_appl varchar2(50);
		frm_ver varchar2(50);
		cursor legislations is
				SELECT DECODE(legislation_code
							   ,null,'Global'
							   ,legislation_code)   leg             
					   , DECODE(application_short_name
							   , 'PER', 'Human Resources'
							   , 'PAY', 'Payroll'
							   , 'GHR', 'Federal Human Resources'
							   , 'CM',  'College Data'
							   , application_short_name)  application        
				  FROM hr_legislation_installations
				  WHERE status = 'I'
				  ORDER BY legislation_code;
		v_wfVer WF_RESOURCES.TEXT%type:='';
		v_crtddt V$DATABASE.CREATED%type;
		v_dx varchar2(32767);
		irc_status varchar2(20);
		cursor bg is
		SELECT o.business_group_id bgi,o.organization_id oi,otl.name name,o3.ORG_INFORMATION9 lc			
			,o3.ORG_INFORMATION10 cc,o4.ORG_INFORMATION2 ef ,to_char(o.date_from , 'DD-MON-YYYY') df,to_char(o.date_to, 'DD-MON-YYYY') dt
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;
Begin
  
  :n := dbms_utility.get_time;
      
  SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, 'TNS for '), ':' )||pcv2.status, 1, 80)
    INTO platform
        FROM product_component_version pcv1,
           product_component_version pcv2
     WHERE UPPER(pcv1.product) LIKE '%TNS%'
       AND UPPER(pcv2.product) LIKE '%ORACLE%'
       AND ROWNUM = 1;
       
 	select banner into db_ver from V$VERSION WHERE ROWNUM = 1;
	select VALUE into db_lang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
	select VALUE into db_charset FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';
  
     
	   SELECT L.MEANING  into :hr_status FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '800') AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
	  SELECT L.MEANING  into :pay_status FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '801') AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
	if :apps_rel like '12.%' then
		select count(*) into v_exists from fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		if v_exists >0 then	
		SELECT L.MEANING  into irc_status  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		end if;
	 end if;      
	if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into rup_level FROM ad_bugs adb
            WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646')
			;
			 SELECT DECODE(bug_number
                  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
				  ,'19193000', 'R12.HR_PF.C.delta.6'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
				  
    elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16000686','13418800','10281212','9114911','8337373', '7446767', '6603330','18004477','20000288');            
                 
           SELECT DECODE(BUG_NUMBER
				  ,'20000288','R12.HR_PF.B.delta.8'
				  ,'18004477', 'R12.HR_PF.B.delta.7'
                  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;            

            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
            
           SELECT DECODE(BUG_NUMBER
                  , '16077077', 'R12.HR_PF.A.delta.11'
                  , '13774477', 'R12.HR_PF.A.delta.10'
                  , '10281209', 'R12.HR_PF.A.delta.9'
                  , '9301208', 'R12.HR_PF.A.delta.8'
                  , '7577660', 'R12.HR_PF.A.delta.7'
                  , '7004477', 'R12.HR_PF.A.delta.6'
                  , '6610000', 'R12.HR_PF.A.delta.5'
                  , '6494646', 'R12.HR_PF.A.delta.4'
                  , '6196269', 'R12.HR_PF.A.delta.3'
                  , '5997278', 'R12.HR_PF.A.delta.2'
                  , '5881943', 'R12.HR_PF.A.delta.1'
                  , '4719824', 'R12.HR_PF.A')
                  , LAST_UPDATE_DATE  
                  into :rup_level_n, :v_rup_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                 
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
            
            if v_exists>0 then         
				   select max(to_number(bug_number)) into rup_level from ad_bugs 
							WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
						   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');                    
								 
				   SELECT DECODE(BUG_NUMBER
                           , '2803988', 'HRMS_PF.E'
                           , '2968701', 'HRMS_PF.F'
                           , '3116666', 'HRMS_PF.G'
                           , '3233333', 'HRMS_PF.H'
                           , '3127777', 'HRMS_PF.I'
                           , '3333633', 'HRMS_PF.J'
                           , '3500000', 'HRMS_PF.K'
                           , '5055050', 'HR_PF.K.RUP.1'
                           , '5337777', 'HR_PF.K.RUP.2'
                           , '6699770', 'HR_PF.K.RUP.3'
                           , '7666111', 'HR_PF.K.RUP.4'
                           , '9062727', 'HR_PF.K.RUP.5'
                           , '10015566', 'HR_PF.K.RUP.6'
                           , '12807777', 'HR_PF.K.RUP.7'
                           , '14488556', 'HR_PF.K.RUP.8'
						   , '17774746', 'HR_PF.K.RUP.9'
                            )  
                        , LAST_UPDATE_DATE  
                          into :rup_level_n, :v_rup_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =rup_level and rownum < 2;
						
				end if;   
      end if;
	
	if :apps_rel like '12.2%' then
			SELECT decode(max(to_number(adb.bug_number)),'10110982','OA Framework 12.2','14222219','OA Framework 12.2.1','15890638','OA Framework 12.2.2' ,'17007206','OA Framework 12.2.3','17909318','OA Framework 12.2.4','OA Framework 12.2') 
			into frm_ver FROM ad_bugs adb         
			WHERE adb.bug_number in ('10110982', '14222219','15890638', '17007206', '17909318')
			;
				  
    elsif :apps_rel like '12.1%' then                       
           SELECT decode(max(to_number(bug_number)),'17774755','OA Framework 12.1.3.2 RPC1','15880118','OA Framework 12.1.3.2','11894708','OA Framework 12.1.3.1' ,'9239090','OA Framework 12.1.3','8919491','OA Framework 12.1.3','Unknown') 
		   into frm_ver FROM ad_bugs         
			WHERE bug_number in ('17774755','15880118','11894708','9239090','8919491'); 
    elsif :apps_rel like '12.0%' then
            SELECT decode(max(to_number(bug_number)),'6728000','OA Framework 12.0.6','6435000','OA Framework 12.0.4','6141000','OA Framework 12.0.3' ,'5484000','OA Framework 12.0.2','5082400','OA Framework 12.0.1','OA Framework 12.0') 
			into frm_ver FROM ad_bugs         
			WHERE bug_number in ('5082400', '5484000' ,'6141000','6435000','6728000');  
    elsif   :apps_rel like '11.5%' then   
            SELECT decode(max(to_number(bug_number)),'2085104','OA Framework 5.5.2C','2227335','OA Framework 5.5.2E','2278688','OA Framework 5.6.0E' ,'2771817','OA Framework 5.7.0H','3875569','OA Framework 11.5.10',
			 '4017300', 'OA Framework 11.5.10 ATG_PF.H RUP1',
			 '4125550', 'OA Framework 11.5.10 ATG_PF.H RUP2',
			 '4334965', 'OA Framework 11.5.10 ATG_PF.H RUP3',
			 '4676589', 'OA Framework 11.5.10 ATG_PF.H RUP4',
			 '5473858', 'OA Framework 11.5.10 ATG_PF.H RUP5',
			 '5903765', 'OA Framework 11.5.10 ATG_PF.H RUP6',
			 '6241631', 'OA Framework 11.5.10 ATG_PF.H RUP7',
			'Unknown') 
			into frm_ver FROM ad_bugs         
			WHERE bug_number in ('2085104','2227335','2278688','2771817','3061106','3875569','4017300', '4125550','4334965', '4676589','5473858','5903765','6241631');    
				  
      end if;	  
	    
	select count(1) into v_exists FROM V$DATABASE;
	if v_exists=1 then	
	SELECT CREATED into v_crtddt FROM V$DATABASE;
	end if;
	select count(1) into v_exists FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';
	if v_exists=1 then
	SELECT TEXT into v_wfVer  FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';	
	end if;		
		
	l_o('<DIV class=divItem><a name="sum"></a>');
	l_o('<DIV id="s1sql0b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql0'');" href="javascript:;">&#9654; Instance Summary</A></DIV>');
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql0" style="display:none" >');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o('   <TH COLSPAN=5 bordercolor="#DEE6EF">');
	l_o('     <B>Instance Summary</B></font></TD>');	
	l_o(' </TR>');
	l_o('<TR><TD>Instance Name = '||:sid||'<br>');
	l_o('Instance Creation Date = '||v_crtddt||'<br>');
	l_o('Server/Platform = '||platform||'<br>');
	l_o('Language/Characterset = '||db_lang||' / '||db_charset||'<br>');
	l_o('Database = '||db_ver||'<br>');
	l_o('Applications = '||:apps_rel||'<br>');
	l_o('OA Framework Version = '||frm_ver||'<br>');
	l_o('Workflow = '||v_wfVer||'<br>');
	l_o('PER '||:hr_status||' - PAY '||:pay_status||'<br><br>');
	if :apps_rel like '11.5%' and v_exists=0 then   
           l_o('no RUP');		
    else
			l_o(:rup_level_n|| ' applied on ' || :v_rup_date ||'<br>');
	end if;
	l_o('<br>Installed legislations<br>');
	l_o('Code   Application');
	l_o('<br>-------------------<br>');
	
	  
	open legislations;
    loop
          fetch legislations into v_code,v_appl;
          EXIT WHEN  legislations%NOTFOUND;
          l_o(v_code||'   '||v_appl||'<br>');		  
    end loop;
	 
    close legislations;	
	
	l_o(' </TABLE> ');
	l_o('</div>');
	
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	l_o('<div id="fordx" style="display:none">');
	l_o('Instance Name = '||:sid||chr(10)||'Instance Creation Date = '||v_crtddt||chr(10)||'Server/Platform = '||platform||chr(10)||'Language/Characterset = '||db_lang||' / '||db_charset);
	l_o('Database = '||db_ver||chr(10)||'Applications = '||:apps_rel||chr(10)||'OA Framework Version = '||frm_ver||chr(10)||'Workflow = '||v_wfVer||chr(10)||'PER '||:hr_status||chr(10)||'PAY '||:pay_status||chr(10));
	l_o('IRC '||irc_status||chr(10));
	l_o(chr(10)||:rup_level_n|| ' applied on ' || :v_rup_date ||chr(10)||chr(10)||'Installed legislations');
	
	for l_rec in legislations loop
	l_o(l_rec.leg||'   '||l_rec.application);
	end loop;
	l_o(chr(10)||lpad('Bus Grp ID',10)||lpad('Org ID',10)||lpad('Organization Name',30)||lpad('Legis',6)||lpad('Curr',6)||lpad('Enabl',7)||' '||lpad('Date From',11) ||' '||lpad('Date To',11));
	for org_rec in bg loop
		l_o(lpad(org_rec.bgi,10)||lpad(org_rec.oi,10)||lpad(org_rec.name,30)||lpad(org_rec.lc,6)||lpad(org_rec.cc,6)||lpad(org_rec.ef,7)||' '||lpad(org_rec.df,11)||' '||lpad(org_rec.dt,11));
	end loop;
	l_o('</div>');
	
	l_o('<DIV class=divItem><a name="db"></a>');
	l_o('<DIV id="s1sql1b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql1'');" href="javascript:;">&#9654; Database Details</A></DIV>');	

	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql1" style="display:none" >');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o('   <TH COLSPAN=5 bordercolor="#DEE6EF">');
	l_o('     <B>Database details</B></font></TD>');
	l_o('     <TD bordercolor="#DEE6EF">');
	l_o('<A class=detail  id="s1sql2b"  onclick="displayItem2(this,''s1sql2'');" href="javascript:;">&#9654; Show SQL Script</A>');
	l_o('   </TD>');
	l_o(' </TR>');
	l_o(' <TR id="s1sql2" style="display:none">');
	l_o('    <TD colspan="5" height="60">');
	l_o('       <blockquote><p align="left">');
	l_o('          SELECT upper(instance_name), host_name<br>');
	l_o('          	FROM   fnd_product_groups, v$instance;<br>');
	l_o('        SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, ''TNS for ''), '':'' )||pcv2.status, 1, 80)<br>');
	l_o('            	FROM product_component_version pcv1,<br>');
	l_o('                   product_component_version pcv2<br>');
	l_o('             	WHERE UPPER(pcv1.product) LIKE ''%TNS%''<br>');
	l_o('               	AND UPPER(pcv2.product) LIKE ''%ORACLE%''<br>');
	l_o('               	AND ROWNUM = 1;<br>');
	l_o('        SELECT banner from V$VERSION WHERE ROWNUM = 1;<br>');
	l_o('        SELECT value FROM V$NLS_PARAMETERS WHERE parameter in (''NLS_LANGUAGE'',''NLS_CHARACTERSET'');');
	l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Hostname</B></TD>');
	l_o(' <TH><B>Platform</B></TD>');
	l_o(' <TH><B>Sid</B></TD>');
	l_o(' <TH><B>Database version</B></TD>');
	l_o(' <TH><B>Language</B></TD>');
	l_o(' <TH><B>Character set</B></TD>');
	l_o('<TR><TD>'||:host||'</TD>'||chr(10)||'<TD>'||platform||'</TD>'||chr(10));
	l_o('<TD>'||:sid||'</TD>'||chr(10)||'<TD>'||db_ver||'</TD>'||chr(10)||'<TD>'||db_lang||'</TD>'||chr(10)||'<TD>'||db_charset ||'</TD></TR>'||chr(10));	 	
	:n := (dbms_utility.get_time - :n)/100;
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=5 bordercolor="#DEE6EF">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE> ');
	l_o('</div>');
	
	if :apps_rel like '11.5%' and (db_ver like '9.2%' or db_ver like '10.1%' or db_ver like '10.2.0.2%' or db_ver like '10.2.0.3%' or db_ver like '11.1.0.6%') then
		l_o('<div class="divwarn">');
		l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Minimum Requirements: Database 10.2.0.4 or 11.1.0.7!<br>');
		l_o('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=883202.1" target="_blank">Note 883202.1</a> Patch Requirements for Sustaining Support for Oracle E-Business Suite Release 11.5.10<br>');
		l_o('</div><br><br>');
		:w1:=:w1+1;
	elsif :apps_rel like '12.0%' and (db_ver like '9.2%' or db_ver like '10.1%' or db_ver like '10.2.0.2%' or db_ver like '10.2.0.3%' or db_ver like '10.2.0.4%' or db_ver like '11.1.0.6%' or db_ver like '11.2.0.1%') then
		l_o('<div class="divwarn">');
		l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Minimum Requirements: Oracle Database 10.2.0.5, 11.1.0.7, or 11.2.0.2!<br>');
		l_o('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1334562.1" target="_blank">Note 1334562.1</a> Minimum Patch Requirements for Extended Support of Oracle E-Business Suite Human Capital Management (HCM) Release 12.0<br>');
		l_o('</div><br><br>');
		:w1:=:w1+1;
	end if;
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	
	 :n := dbms_utility.get_time;
	 
	 SELECT MULTI_ORG_FLAG,MULTI_CURRENCY_FLAG into multiOrg, multiCurr FROM FND_PRODUCT_GROUPS;
		
    
	if upper(product)='OTL' then
		SELECT L.MEANING  into v_hxc_status
		  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '809')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'
		AND l.language = 'US';
		
		SELECT L.MEANING  into v_hxt_status
		  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
      WHERE (b.APPLICATION_ID = I.APPLICATION_ID)
	  AND b.application_id = t.application_id
        AND (b.APPLICATION_ID = '808')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status)
		AND t.language = 'US'
		AND l.language = 'US';
	end if;
    
	l_o('<DIV class=divItem><a name="apps"></a>');
	l_o('<DIV id="s1sql3b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql3'');" href="javascript:;">&#9654; Application Details</A></DIV>');
	
	if upper(product)='OTL' then	

		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql3" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=7 bordercolor="#DEE6EF">');
		l_o('     <B>Application Details</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql4b"  onclick="displayItem2(this,''s1sql4'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql4" style="display:none">');
		l_o('    <TD colspan="7" height="60">');
	else		

		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql3" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=5 bordercolor="#DEE6EF">');
		l_o('     <B>Application Details</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql4b"  onclick="displayItem2(this,''s1sql4'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql4" style="display:none">');
		l_o('    <TD colspan="5" height="60">');
	end if;
	
	l_o('       <blockquote><p align="left">');
	l_o('          SELECT RELEASE_NAME from FND_PRODUCT_GROUPS;<br>');	
	l_o('          SELECT MULTI_ORG_FLAG,MULTI_CURRENCY_FLAG FROM FND_PRODUCT_GROUPS;<br>');
	l_o('          SELECT V.APPLICATION_ID, L.MEANING  <br>');
	l_o('              FROM FND_APPLICATION_ALL_VIEW V, FND_PRODUCT_INSTALLATIONS I, FND_LOOKUPS L<br>');
	l_o('              WHERE (V.APPLICATION_ID = I.APPLICATION_ID)<br>');
  
	if upper(product)='OTL' then
		l_o('                AND (V.APPLICATION_ID in (''800'',''801'',''808'',''809''))<br>');
	else
		l_o('                AND (V.APPLICATION_ID in (''800'',''801''))<br>');
	end if;
  
	l_o('                AND (L.LOOKUP_TYPE = ''FND_PRODUCT_STATUS'')<br>');
	l_o('               AND (L.LOOKUP_CODE = I.Status);<br>');
	l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Release</B></TD>');
	l_o(' <TH><B>HRMS RUP</B></TD>');
	l_o(' <TH><B>MultiOrg Flag</B></TD>');
	l_o(' <TH><B>MultiCurrency Flag</B></TD>');
	
	if upper(product)='OTL' then
				l_o(' <TH><B>HXC Status</B></TD>');
				l_o(' <TH><B>HXT Status</B></TD>');
	end if;
	
	l_o(' <TH><B>HR Status</B></TD>');
	l_o(' <TH><B>PAY Status</B></TD>');

	l_o('<TR><TD>'||:apps_rel||'</TD>'||chr(10));
	
            
    if  :apps_rel like '11.5%'  and v_exists=0 then
					l_o('<TD>no RUP</TD>'||chr(10));			
    else
			l_o('<TD>'||:rup_level_n|| ' applied on ' || :v_rup_date ||'</TD>'||chr(10));
	end if;
	
	
	
	l_o('<TD>'||multiOrg||'</TD>'||chr(10));
	if upper(product)='OTL' then
	    l_o('<TD>'||multiCurr||'</TD>'||chr(10)||'<TD>'||v_hxc_status||'</TD>'||chr(10)||'<TD>'||v_hxt_status);
		l_o('</TD>'||chr(10)||'<TD>'||:hr_status||'</TD>'||chr(10)||'<TD>'||:pay_status||'</TD></TR>'||chr(10));
	else
		l_o('<TD>'||multiCurr||'</TD>'||chr(10)||'<TD>'||:hr_status||'</TD>'||chr(10)||'<TD>'||:pay_status||'</TD></TR>'||chr(10));	 	
	end if;
	
	:n := (dbms_utility.get_time - :n)/100;
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	if upper(product)='OTL' then
		l_o(' <TH COLSPAN=7 bordercolor="#DEE6EF">');
	else
		l_o(' <TH COLSPAN=5 bordercolor="#DEE6EF">');
	end if;
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE> </div> ');
	
	
	if :apps_rel like '11.5%' then
		l_o('<div class="divwarn">');
		l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span>Please note that statutory legislative support expired on November 30th 2013');
		l_o('<span class="sectionb">, please refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1384995.1" target="_blank">Note 1384995.1</a> ');
		l_o(' When Is Statutory Legislative Support for Payroll Going To End For Release 11i<br></div>');
		:w1:=:w1+1;
	end if;
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;

-- Display HCM Products status
procedure product_status is
	run_type varchar2(20):='&1';
	v_appl fnd_application_all_view.application_name%type; 
	v_appls fnd_application_all_view.application_short_name%type; 
	v_applid varchar2(20);
	v_status fnd_lookups.meaning%type;
	v_patch fnd_product_installations.patch_level%type;
	cursor products is
	select t.application_name , b.application_short_name
		, to_char(t.application_id)
		, l.meaning
		, decode(i.patch_level, null, '11i.' || b.application_short_name || '.?', i.patch_level)
		from fnd_application b, fnd_application_tl t, fnd_product_installations i,  fnd_lookup_values l
		where (t.application_id = i.application_id)
		AND b.application_id = t.application_id
		 and (b.application_id in ('0', '50', '101','178', '203', '231', '275', '426', '453', '800', '801', '802', '803', '804', '805', '808', '809', '810', '821', '8301', '8302', '8303','8401','8403'))
		and (l.lookup_type = 'FND_PRODUCT_STATUS')
		and (l.lookup_code = i.status )
		AND t.language = 'US' AND l.language = 'US' order by upper(t.application_name);

begin
if upper(run_type)='ALL' then
		
	l_o('<DIV class=divItem><a name="products"></a>');
	l_o('<DIV id="s1sql5b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql5'');" href="javascript:;">&#9654; Products Status</A></DIV>');

	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql5" style="display:none" >');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
	l_o('     <B>Applications Status</B></font></TD>');
	l_o('     <TD bordercolor="#DEE6EF">');
	l_o('<A class=detail  id="s1sql6b"  onclick="displayItem2(this,''s1sql6'');" href="javascript:;">&#9654; Show SQL Script</A>');
	l_o('   </TD>');
	l_o(' </TR>');
	l_o(' <TR id="s1sql6" style="display:none">');
	l_o('    <TD colspan="4" height="60">');
	l_o('       <blockquote><p align="left">');
	l_o('        select v.application_name , v.application_short_name  <br>');     
	l_o('        , to_char(v.application_id) <br>');
	l_o('        , l.meaning    <br>');             
	l_o('        , decode(i.patch_level, null, ''11i.'' || v.application_short_name || ''.?'', i.patch_level) <br>');
	l_o('        from fnd_application_all_view v, fnd_product_installations i, fnd_lookups l<br>');
	l_o('        where (v.application_id = i.application_id)<br>');
	l_o('        and (v.application_id in <br>');
	l_o('         (''0'', ''50'', ''178'', ''275'', ''426'', ''453'', ''800'', ''801'', ''802'', ''803'', ''804'', ''805'', ''808'', ''809'', ''810'', ''8301'', ''8302'', ''8303''))<br>');
	l_o('        and (l.lookup_type = ''FND_PRODUCT_STATUS'')<br>');
	l_o('        and (l.lookup_code = i.status )');
	l_o('        order by upper(v.application_name);');
    l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Application</B></TD>');
	l_o(' <TH><B>Short Name</B></TD>');
	l_o(' <TH><B>Code</B></TD>');
	l_o(' <TH><B>Status</B></TD>');
	l_o(' <TH><B>Patchset</B></TD>');
		
	:n := dbms_utility.get_time;
	open products;
    loop
          fetch products into v_appl,v_appls,v_applid,v_status,v_patch;
          EXIT WHEN  products%NOTFOUND;
          l_o('<TR><TD>'||v_appl||'</TD>'||chr(10)||'<TD>'||v_appls||'</TD>'||chr(10));
		  if v_appls='HXC' and :apps_rel like '12.%'  then
				l_o('<TD>'||v_applid||'</TD>'||chr(10)||'<TD>'||v_status||'</TD>'||chr(10)||'<TD>-</TD> </TR>'||chr(10));
		  else
				l_o('<TD>'||v_applid||'</TD>'||chr(10)||'<TD>'||v_status||'</TD>'||chr(10)||'<TD>'||v_patch||'</TD> </TR>'||chr(10));
		  end if;	  
    end loop;
    close products;
	
	:n := (dbms_utility.get_time - :n)/100;
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE> ');
	l_o('</div>');
	l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display legislations and status
procedure legislations is
	run_type varchar2(20):='&1';
	v_code varchar2(20); 
	v_appl varchar2(50);
	v_appls varchar2(50);
	v_date varchar2(30);
	v_action varchar2(20);
	cursor legislations is
	select  decode(legislation_code,null,'global',legislation_code), 
	decode(application_short_name , 'PER', 'Human Resources' , 'PAY', 'Payroll' , 'GHR', 'Federal Human Resources' , 'CM',  'College Data' , application_short_name),
    application_short_name,
	decode(action,'F','Force Install','C','Clear','U','Upgrade','I','Install'),
	to_char(last_update_date, 'DD-MON-YYYY')
	from hr_legislation_installations
      where status = 'I' 
      order by legislation_code;
begin
l_o(' <a name="legislations"></a>');
if upper(run_type)='ALL' then
	l_o('<DIV class=divItem>');
	l_o('<DIV id="s1sql7b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql7'');" href="javascript:;">&#9654; Legislations Installed</A></DIV>');
	
	l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql7" style="display:none" >');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
	l_o('     <B>Legislations Installed</B></font></TD>');
	l_o('     <TD bordercolor="#DEE6EF">');
	l_o('<A class=detail  id="s1sql8b"  onclick="displayItem2(this,''s1sql8'');" href="javascript:;">&#9654; Show SQL Script</A>');
	l_o('   </TD>');
	l_o(' </TR>');
	l_o(' <TR id="s1sql8" style="display:none">');
	l_o('    <TD colspan="4" height="60">');
	l_o('       <blockquote><p align="left">');
	l_o('         select decode(legislation_code,null,''global'',legislation_code) <br>');
	l_o('          , decode(application_short_name<br>');
	l_o('          , ''PER'', ''Human Resources''<br>');
	l_o('          , ''PAY'', ''Payroll''<br>');
	l_o('          , ''GHR'', ''Federal Human Resources''<br>');
	l_o('          , ''CM'',  ''College Data''<br>');
	l_o('          , application_short_name) <br>');
	l_o('          , application_short_name <br>');
	l_o('          ,decode(action,''F'',''Force Install'',''C'',''Clear'',''U'',''Upgrade'',''I'',''Install'')<br>');
	l_o('          , last_update_date  <br>');
	l_o('          from hr_legislation_installations <br>');
	l_o('          where status = ''I''<br>');
	l_o('          order by legislation_code;');
	l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Legislation Code</B></TD>');
	l_o(' <TH><B>Application Name</B></TD>');
	l_o(' <TH><B>Application Code</B></TD>');
	l_o(' <TH><B>Action</B></TD>');
	l_o(' <TH><B>Applied Date</B></TD>');
	
	:n := dbms_utility.get_time;
	open legislations;
    loop
          fetch legislations into v_code,v_appl,v_appls,v_action,v_date;
          EXIT WHEN  legislations%NOTFOUND;
          l_o('<TR><TD>'||v_code||'</TD>'||chr(10)||'<TD>'||v_appl||'</TD>'||chr(10));
		  l_o('<TD>'||v_appls||'</TD>'||chr(10));
		  l_o('<TD>'||v_action||'</TD>'||chr(10)||'<TD>'||v_date||'</TD> </TR>'||chr(10));
          
    end loop;
    close legislations;
	
	:n := (dbms_utility.get_time - :n)/100;
	l_o('<tr><td><A class=detail onclick="hideRow(''s1sql7'');" href="javascript:;">Collapse section</a></td></tr>');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE>');
	l_o('</div>');
    
	l_o('<div class="divok">');
   	l_o('<span class="sectionblue1">Advice: </span> Review <A href="#mandatory">mandatory patching section</A>');	
	l_o(' as per <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1160507.1" target="_blank">Note 1160507.1</a> ');
    l_o('Oracle E-Business Suite HCM Information Center - Consolidated HRMS Mandatory Patch list');
    l_o('</div>');
	
    l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

end if;
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display installed languages (NLS)
procedure nls is
    run_type varchar2(20):='&1';
	lang number;
    v_lang_code FND_LANGUAGES.LANGUAGE_CODE%type;
    v_flag varchar2(25);
    v_language FND_LANGUAGES.NLS_LANGUAGE%type;
    cursor languages is
    SELECT LANGUAGE_CODE ,  
             decode(INSTALLED_FLAG ,'B','Base language','I','Installed language'),
             NLS_LANGUAGE
      FROM FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I')
      order by LANGUAGE_CODE;
begin
    select count(1) into lang from FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I') ;
    if lang>1 or upper(run_type)='ALL'  then
			l_o(' <a name="nls"></a>');
			                      
								  l_o('<DIV class=divItem>');
								 l_o('<DIV id="s1sql33b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql33'');" href="javascript:;">&#9654; Installed Languages</A></DIV>');
                                  l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql33" style="display:none" >');
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
                                  l_o('     <B>Languages:</B></font></TD>');
                                  l_o('     <TD bordercolor="#DEE6EF">');
                                  l_o('<A class=detail  id="s1sql34b" onclick="displayItem2(this,''s1sql34'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  l_o('   </TD>');
                                  l_o(' </TR>');
                                  l_o(' <TR id="s1sql34" style="display:none">');
                                  l_o('    <TD colspan="2" height="60">');
                                  l_o('       <blockquote><p align="left">');
                                  l_o('          SELECT LANGUAGE_CODE , <br>');                                   
                                  l_o('                 decode(INSTALLED_FLAG ,''B'',''Base language'',''I'',''Installed language''),<br>');  
                                  l_o('                 NLS_LANGUAGE<br>'); 
                                  l_o('                FROM FND_LANGUAGES <br>'); 
                                  l_o('                where INSTALLED_FLAG in (''B'',''I'')<br>'); 
                                  l_o('                order by LANGUAGE_CODE;<br>'); 
                                  l_o('          </blockquote><br>');
                                  l_o('     </TD>');
                                  l_o('   </TR>');
                                  l_o(' <TR>');
                                  l_o(' <TH><B>Code</B></TD>');
                                  l_o(' <TH><B>Flag</B></TD>');
                                  l_o(' <TH><B>Language</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open languages;
                                  loop
                                        fetch languages into v_lang_code, v_flag, v_language;
                                        EXIT WHEN  languages%NOTFOUND;
                                        l_o('<TR><TD>'||v_lang_code||'</TD>'||chr(10)||'<TD>'||v_flag||'</TD>'||chr(10)||'<TD>'||v_language||'</TD></TR>'||chr(10));
                                  end loop;
                                  close languages;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF">');
                                  l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  l_o(' </TABLE> ');
								  l_o('</DIV>');
                     if lang>1 then               
                                  l_o('<div class="divok">');    
								  l_o('<span class="sectionblue1">Advice: </span> Periodically check if you NLS level is in sync with US level:<br>');
                                  l_o('Follow <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=252422.1" target="_blank" >Note 252422.1</a> ');
								  l_o('Requesting Translation Synchronization Patches<br>');
                                  l_o('-> this will synchronize your languages with actual US level<br>');
                                  l_o('Note! This is just an advice. This does not mean your NLS is not synchronized! Follow this step ONLY if you have translation issues.<br>');								  
								  l_o('</div>');
					end if;
			l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    end if;
	
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;



-- Display HRMS RUP level
procedure rup is
    run_type varchar2(20):='&1';
    rup_level varchar2(20);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_rows number;
	v_exists number;
	issue boolean:=FALSE;
    
-- Display patch
	procedure dpatch (v_leg varchar2, v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	  v_patch2 varchar(10):=v_patch;
	begin		
		select count(1) into v_exists from hr_legislation_installations
					where Legislation_code = v_leg and status='I';
		if v_exists>0 then
					l_o(v_leg||': ');					
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;	
						if (v_exists=0) then             
								 issue:=TRUE;
								 l_o('<div class="divwarn">');
								 l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Not applied ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> ');
								 l_o(v_name||'<br>');	
								 l_o('</div>');
								 :w5:=:w5+1;
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							l_o('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
		end if;
	end;
	
	procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;
						if (v_exists=0) then             
								 issue:=TRUE;
								 l_o('<div class="divwarn">');
								 l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Not installed ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');
								 l_o('</div>');								
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							l_o('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
	end; 
	

begin
     
      
      l_o(' <div class="divItem"><br><b>HRMS RUP and hrglobal</b><br>');
      
	  if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into rup_level FROM ad_bugs adb
			WHERE adb.bug_number in ('19193000','17909898','17050005','17001123','16169935','14040707','10124646')
			;        
                 
            if rup_level='19193000' then
                  
                  if upper(run_type)='ALL' then
                          l_o('<span class="sectionb"><b>Actual level:</b> Patch 19193000 R12.HR_PF.C.delta.6 applied on '||:v_rup_date||'</span><br><br>');
                  end if;
                  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1992028.1" target="_blank"> Note 1992028.1</a> ');
                  l_o('Known Issues on Top of Patch 19193000 - R12.HR_PF.C.DELTA.6 (HRMS 12.2 RUP6) <br><br>');
				  
				   
				l_o('</span>');
            else
                  SELECT DECODE(bug_number
                  ,'17001123', 'R12.HR_PF.C.delta.3'    
                  , '16169935', 'R12.HR_PF.C.delta.2'
                  ,'14040707', 'R12.HR_PF.C.delta.1'
                  ,'10124646', 'R12.HR_PF.C'
				  ,'17050005', 'R12.HR_PF.C.Delta.4'
				  ,'17909898', 'R12.HR_PF.C.delta.5'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '</span><br><br>');
				  l_o('<div class="divwarn">');
                  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19193000">');
				  l_o('Patch 19193000</a> R12.HR_PF.C.DELTA.6</div><br><br>');
				  :w5:=:w5+1;
				  issuep:=TRUE;
							  
				  
            end if;
			l_o('<span class="sectionb">');
			if (:hr_status='Installed') then
					  l_o('<br><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');					 
					  dpatch('AU','19026516', 'AUSTRALIA SUPERSTREAM DATA CAPTURE - PHASE 1');
					  dpatch('CA','20365000','End of Year 2014 Phase 3');
					  dpatch('IN','20733388','R121 TRACKING BUG FOR INDIA 2015-16 BUDGET CHANGES');
					  dpatch('KR','21778035','KOREA CUMULATIVE RELEASE PATCH - KR.76');
					  dpatch('MX','20259629','2014 EOY Phase 1');
					  dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
					  dpatch('NZ','19245681', 'NEW ZEALAND CONSOLIDATED PATCH ABOVE- 12.2.3');
					  dpatch('SG','20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');					  
					  dpatch('US','20365000','End of Year 2014 Phase 3');
					  dpatch('ZA','20812316', 'ZA: COIDA LIMIT CHANGED EFFECTIVE FROM 1 APRIL 2015');				  
					  if issue then
						issuep:=TRUE;
					  end if;				
			end if;
				
			if upper(run_type)='ALL' then                
					l_o('<br><b>HRMS Family Packs history</b>:</span><br>');
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('17909898', 'R12.HR_PF.C.Delta.5');
					dpatch('17050005', 'R12.HR_PF.C.Delta.4');
					dpatch('17001123', 'R12.HR_PF.C.delta.3');
					dpatch('16169935', 'R12.HR_PF.C.delta.2');
					dpatch('14040707', 'R12.HR_PF.C.delta.1');
					dpatch('10124646', 'R12.HR_PF.C');
            end if;
			l_o('</span><br>');
            
      elsif :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('20000288','18004477','16000686','13418800','10281212','9114911','8337373', '7446767', '6603330');            
             if (:hr_status='Installed') then
									  l_o('<span class="sectionb"><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');									  
									  dpatch('AE','17449352', 'AFTER UPGRADE 12.1.3,ORA-00904:"U1": INVALID IDENTIFIER WHEN VIEW ITD BALANCE');
									  dpatch('AU','19026516', 'AUSTRALIA SUPERSTREAM DATA CAPTURE - PHASE 1');
									  dpatch('CA','20365000','End of Year 2014 Phase 3');
									  dpatch('DK','20107803', 'Danish Legislative Changes 2015');
									  dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
									  dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
									  dpatch('IN','21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');
									  dpatch('JP','19862190','H27 TERMINATION TAX RATE CHANGES EFFECTIVE 01-JAN-2015');
									  dpatch('KR','21778035','KOREA CUMULATIVE RELEASE PATCH - KR.76');
									  dpatch('MX','20259629','2014 EOY Phase 1');
									  dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
									  dpatch('US','20365000','End of Year 2014 Phase 3');									  
									  dpatch('ZA','20812316', 'ZA: COIDA LIMIT CHANGED EFFECTIVE FROM 1 APRIL 2015');
									  l_o('</span>');					  
								end if; 		
			if rup_level='20000288' then
				  l_o('<br><br><span class="sectionb"><b>Actual level:</b> Patch 20000288 R12.HR_PF.B.delta.8 applied on '||:v_rup_date||'</span><br><br>');                  
                  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1992029.1" target="_blank"> Note 1992029.1</a> ');
                  l_o('Known Issues on Top of Patch 20000288 - R12.HR_PF.B.DELTA.8 (HRMS 12.1 RUP8)<br><br>');			  
            
            else
                  SELECT DECODE(BUG_NUMBER
                  ,'18004477', 'R12.HR_PF.B.delta.7'
				  ,'16000686', 'R12.HR_PF.B.delta.6'    
                  , '13418800', 'R12.HR_PF.B.delta.5'
                  ,'10281212', 'R12.HR_PF.B.delta.4'
                  ,'9114911', 'R12.HR_PF.B.delta.3'
                  ,'8337373', 'R12.HR_PF.B.delta.2'
                  ,'7446767', 'R12.HR_PF.B.delta.1'
                  ,'6603330', 'R12.HR_PF.B'
                   ) 
                , LAST_UPDATE_DATE   
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  l_o('<br><span class="sectionb"><b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '</span><br><br>');
				  l_o('<div class="divwarn">');
                  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=20000288">');
				  l_o('Patch 20000288</a> R12.HR_PF.B.delta.8</div><br><br>');
				  :w5:=:w5+1;
				  issuep:=TRUE;				
				  
				  if (rup_level='16000686') and (:hr_status='Installed') then
					  l_o('<span class="sectionb"><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
					  dpatch('AE','17449352', 'AFTER UPGRADE 12.1.3,ORA-00904:"U1": INVALID IDENTIFIER WHEN VIEW ITD BALANCE');
					  dpatch('AU','19026516', 'AUSTRALIA SUPERSTREAM DATA CAPTURE - PHASE 1');
					  dpatch('CA','18075556','End of Year 2013 Phase 3');
					  dpatch('DK','18087349', 'E-income File Record 6002 Changes');
					  dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
					  dpatch('HK','17385401','R121 HK.15 HK STATUTORY MPF MIN/MAX RI CHANGES FOR 1 NOV 2013/1 JUNE 2014');
					  dpatch('IE','19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					  dpatch('IN','19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
					  dpatch('KR','18472619','KOREA CUMULATIVE RELEASE PATCH - R12.0.KR.70');
					  dpatch('KW','16787133', 'TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');
					  dpatch('MX','18349603','YE13P2:121:MEXICO YEAREND - 2013 PHASE 2');
					  dpatch('NL','20279973', 'ABP PGGM Calculation Changes 2015');
					  dpatch('SG','17651515','R121.SG.36 - SINGAPORE HRMS CONSOLIDATED PATCH');					  
					  dpatch('US','18285981','R12.PAY.B Q1 2014 Statutory and JIT Update');
					  dpatch('ZA','18318317', 'ZA BUDGET SPEECH CHANGES 2014/15 ');
					  l_o('</span>');					  
				end if; 
				
				  if rup_level='13418800' and (:hr_status='Installed') then
						  l_o('<span class="sectionb"><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
						 dpatch('AU','16365150','R121.AU.20 AUSTRALIA CUMULATIVE RELEASE');
						  dpatch('DK','16002560','DANISH LEGISLATIVE CHANGES 2013 PART-3');
						  dpatch('GB','16373594','TYE13 P11D LEGISLATIVE CHANGES FOR 2012-2013');
						  dpatch('HK','16457605','R121 HK.14 HK STATUTORY MINIMUM WAGE RATE CHANGE 1ST MAY 2013');
						  dpatch('IE','16811074','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');
						  dpatch('IN', '14351982','HRMS R12.1:Budget 2012 Additional Changes for SEC 80CCG AND 80TTA');
						  dpatch('JP','17015507','JAPANESE HRMS CONSOLIDATED PATCH R121.JP.13');						  
						  dpatch('KW','16787133', 'TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');						  
						  dpatch('NL','17309051','Dutch Labour Handicap Discount Calculation to use Full Time Salary');
						  dpatch('SG','17173295','R121.SG.35 - SINGAPORE HRMS CONSOLIDATED PATCH');
						  dpatch('ZA','16543654','ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013 TO R312 480');
						  dpatch('ZA', '16608448','AFTER APPLYING THE RUP5 PATCH SSHR PAYSLIP PAYROLL');
						  l_o('</span>');						  
				  end if;
				  				  
				  
            end if; 
			if upper(run_type)='ALL' then               
					l_o('<span class="sectionb"><br><b>HRMS Family Packs history</b>:</span><br>');
					dpatch('20000288','R12.HR_PF.B.delta.8');
					dpatch('18004477', 'R12.HR_PF.B.delta.7');
				    dpatch('16000686', 'R12.HR_PF.B.delta.6');    
                    dpatch('13418800', 'R12.HR_PF.B.delta.5');
                    dpatch('10281212', 'R12.HR_PF.B.delta.4');
                    dpatch('9114911', 'R12.HR_PF.B.delta.3');
                    dpatch('8337373', 'R12.HR_PF.B.delta.2');
                    dpatch('7446767', 'R12.HR_PF.B.delta.1');
                    dpatch('6603330', 'R12.HR_PF.B');				
					l_o('<br>');				
            end if;
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into rup_level from ad_bugs 
            WHERE BUG_NUMBER IN ('16077077','13774477','10281209','9301208','7577660', '7004477', '6610000', '6494646', '6196269', '5997278', '5881943', '4719824');
            
            if rup_level='16077077' then
                 
                  if upper(run_type)='ALL' then
                          l_o('<span class="sectionb"><b>Actual level:</b> Patch 16077077 R12.HR_PF.A.delta.11</span><br><br>');
                  end if;
                  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1538635.1" target="_blank"> Note 1538635.1</a> ');
                  l_o('Known Issues on Top of Patch 16077077 - r12.hr_pf.a.delta.11</span><br><br>');
				  
				  if (:hr_status='Installed') then
					  l_o('<span class="sectionb"><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
					  dpatch('CA','20365000','End of Year 2014 Phase 3');
					  dpatch('DK','20107803', 'Danish Legislative Changes 2015');
					  dpatch('GB','18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
					  dpatch('HK','17385401','R12.HK.15 HK STATUTORY MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');
					  dpatch('IE','19820820', 'Ireland EIR Code Address Changes For 2015');
					  dpatch('IN','19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
					  dpatch('KR','20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');
					  dpatch('MX','20259629','2014 EOY Phase 1');	
					  dpatch('NL','19071113','Delivers new discount for hiring young employees and updates to Legal Minimum Wages effective July 2014');
					  dpatch('SG','17651515','R12.SG.36 - SINGAPORE HRMS CONSOLIDATED PATCH');					  
					  dpatch('US','20365000','End of Year 2014 Phase 3');
					  dpatch('ZA','19544341', 'ZA: AUGTYE14 REPORTING CHANGES');
					  
					  l_o('</span>');
					  if issue then
						issuep:=TRUE;
					  end if;
				end if;   
            else
                  SELECT DECODE(BUG_NUMBER
                  , '16077077', 'R12.HR_PF.A.delta.11'
                  , '13774477', 'R12.HR_PF.A.delta.10'
                  , '10281209', 'R12.HR_PF.A.delta.9'
                  , '9301208', 'R12.HR_PF.A.delta.8'
                  , '7577660', 'R12.HR_PF.A.delta.7'
                  , '7004477', 'R12.HR_PF.A.delta.6'
                  , '6610000', 'R12.HR_PF.A.delta.5'
                  , '6494646', 'R12.HR_PF.A.delta.4'
                  , '6196269', 'R12.HR_PF.A.delta.3'
                  , '5997278', 'R12.HR_PF.A.delta.2'
                  , '5881943', 'R12.HR_PF.A.delta.1'
                  , '4719824', 'R12.HR_PF.A')
                  , LAST_UPDATE_DATE  
                  into :rup_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =rup_level and rownum < 2;
                  
                  l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '</span><br><br>');
				  l_o('<div class="divwarn">');
                  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=16077077">');
				  l_o('Patch 16077077</a> R12.HR_PF.A.delta.11</div><br><br>');
				  :w5:=:w5+1;
				  issuep:=TRUE;
				  
				  if rup_level='13774477' and (:hr_status='Installed') then
						  l_o('<span class="sectionb"><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
						 dpatch('AU','16365150','R121.AU.20 AUSTRALIA CUMULATIVE RELEASE');
						  dpatch('DK','16002560','DANISH LEGISLATIVE CHANGES 2013 PART-3');
						  dpatch('GB','16373594','TYE13 P11D LEGISLATIVE CHANGES FOR 2012-2013');
						  dpatch('HK','16457605','R12HK.14 HK STATUTORY MINIMUM WAGE RATE CHANGE 1ST MAY 2013');
						  dpatch('IE','16811074','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');
						  dpatch('IN', '17579687','12.0BL: INDIA CONSOLIDATED UPDATE IN.09 ');						  
						  dpatch('KR','18472619','KOREA CUMULATIVE RELEASE PATCH - R12.0.KR.70');
						  dpatch('KW','16787133', 'TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');						 
						  dpatch('NL','17309051','Dutch Labour Handicap Discount Calculation to use Full Time Salary');
						  dpatch('SG','17173295','R12.SG.35 - SINGAPORE HRMS CONSOLIDATED PATCH');
						  dpatch('ZA','16543654','ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013 TO R312 480');
						  dpatch('ZA', '16654857','SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');
						  l_o('</span>');						  
				  end if;
				  
            end if;  
			if upper(run_type)='ALL' then                
					l_o('<span class="sectionb"><br><b>HRMS Family Packs history</b>:</span><br>');
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('13774477', 'R12.HR_PF.A.delta.10');
					dpatch('10281209', 'R12.HR_PF.A.delta.9');
					dpatch( '9301208', 'R12.HR_PF.A.delta.8');
					dpatch('7577660', 'R12.HR_PF.A.delta.7');
					dpatch('7004477', 'R12.HR_PF.A.delta.6');
					dpatch('6610000', 'R12.HR_PF.A.delta.5');
					dpatch('6494646', 'R12.HR_PF.A.delta.4');
					dpatch('6196269', 'R12.HR_PF.A.delta.3');
					dpatch('5997278', 'R12.HR_PF.A.delta.2');
					dpatch('5881943', 'R12.HR_PF.A.delta.1');
					dpatch('4719824', 'R12.HR_PF.A');					
					l_o('<br>');				
            end if;
			
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_rows from ad_bugs 
            WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
            
            if v_rows=0 then
                    l_o('<div class="diverr">');
					l_o('<img class="error_ico"><font color="red">Error:</font> No RUP patch applied!<br><br>');
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17774746">');
					l_o('Patch 17774746</a> HR_PF.K.RUP.9</div><br>');
					:e5:=:e5+1;
            else        
                    select max(to_number(bug_number)) into rup_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('2803988','2968701','3116666','3233333','3127777','3333633',
                   '3500000','5055050','5337777','6699770','7666111','9062727','10015566','12807777','14488556','17774746');
                    if rup_level='17774746' then
                         
                          if upper(run_type)='ALL' then
                                  l_o('<span class="sectionb"><b>Actual level:</b> Patch 17774746 HR_PF.K.RUP.9 applied on '||:v_rup_date||'</span><br><br>');
                          end if;
                          l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                          l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1636768.1" target="_blank"> Note 1636768.1</a> ');
                          l_o('Known Issues on Top of Patch 17774746 - 11i.hr_pf.k.delta.9 (HRMS 11i RUP9)</span><br><br>');
						  
						   l_o('<span class="sectionb"><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');							
							  dpatch('GB','18305045','UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014');					 						  							  
							 
							  l_o('</span>');
							  if issue then
								issuep:=TRUE;
							  end if;
					
                          
                    else
                          SELECT DECODE(BUG_NUMBER
                           , '2803988', 'HRMS_PF.E'
                           , '2968701', 'HRMS_PF.F'
                           , '3116666', 'HRMS_PF.G'
                           , '3233333', 'HRMS_PF.H'
                           , '3127777', 'HRMS_PF.I'
                           , '3333633', 'HRMS_PF.J'
                           , '3500000', 'HRMS_PF.K'
                           , '5055050', 'HR_PF.K.RUP.1'
                           , '5337777', 'HR_PF.K.RUP.2'
                           , '6699770', 'HR_PF.K.RUP.3'
                           , '7666111', 'HR_PF.K.RUP.4'
                           , '9062727', 'HR_PF.K.RUP.5'
                           , '10015566', 'HR_PF.K.RUP.6'
                           , '12807777', 'HR_PF.K.RUP.7'
                           , '14488556', 'HR_PF.K.RUP.8'
						   ,'17774746', 'HR_PF.K.RUP.9'
                            )  
                        , LAST_UPDATE_DATE  
                          into :rup_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =rup_level and rownum < 2;
                          
                          l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || rup_level || ' ' || :rup_level_n || ' applied on ' || v_date || '</span><br><br>');
                          l_o('<div class="divwarn">');
						  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17774746">');
						  l_o('Patch 17774746</a> HR_PF.K.RUP.9</div><br><br>');
						  :w5:=:w5+1;
						  issuep:=TRUE;
						  
						if rup_level = '14488556' and (:hr_status='Installed') then						  
							  l_o('<span class="sectionb"><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
							  dpatch('AU','16319187','11I.AU.20 AUSTRALIA CUMULATIVE RELEASE');
							  dpatch('CA','18075555','End of Year 2013 Phase 3');		
							  dpatch('GB','17964873','UK TAX YEAR END CHANGES 2013 - 2014');							 						  							  
							  dpatch('US','18075555','End of Year 2013 Phase 3');							 
							  l_o('</span>');
							  
						end if; 
						
						  if rup_level='12807777' and (:hr_status='Installed') then
								  l_o('<span class="sectionb"><b>Latest Oracle HRMS Legislative Data Patches:</b><br>');
								 dpatch('AU','16319187','11I.AU.20 AUSTRALIA CUMULATIVE RELEASE');
								 
								  dpatch('DK','16002352','DANISH LEGISLATIVE CHANGES 2013 PART-3');								 
								  dpatch('HK','17539543','HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');
								  dpatch('IE','16811068','IRELAND LOCAL PROPERTY TAX AND REPORT CHANGES');
								  dpatch('IN','17578798','INDIA CONSOLIDATED UPDATE IN.09 ');
								  dpatch('GB','13343360','TYE12 : UK END OF YEAR CHANGES 2011-12');
								  dpatch('JP','17015482', 'JAPANESE HRMS CONSOLIDATED PATCH R115.JP.13');
								  dpatch('KR','16518233','KOREA CUMULATIVE RELEASE PATCH - 11i.KR.69');
								  dpatch('KW','16806105','TRACKING BUG : KUWAIT SOCIAL INSURANCE ENHANCEMENT 2013');								  						  				 
								  dpatch('NL','17309047','Dutch Labour Handicap Discount Calculation');	
								  dpatch('NZ','13627558', ' 11I - NZ STATUTORY UPDATES - 2012 ');								  
								  dpatch('SG','17188127','SINGAPORE CUMULATIVE RELEASE SG.35');
								  dpatch('ZA','16543639', 'ZA: COIDA LIMIT INCREASE AS OF 01-APR-2013');
								  dpatch('ZA','16654854', 'SSHR PAYSLIP PAYROLL INFO IS DUPLICATED IF MULTIPLE PAYROLLS');	
								  l_o('</span>');								  
						  end if;
                    end if;
					if upper(run_type)='ALL' then						
							l_o('<span class="sectionb"><br><b>HRMS Family Packs history</b>:</span><br>');
							dpatch('2803988', 'HRMS_PF.E');
							dpatch('2968701', 'HRMS_PF.F');
							dpatch('3116666', 'HRMS_PF.G');
							dpatch('3233333', 'HRMS_PF.H');
							dpatch('3127777', 'HRMS_PF.I');
							dpatch('3333633', 'HRMS_PF.J');
							dpatch('3500000', 'HRMS_PF.K');
							dpatch('5055050', 'HR_PF.K.RUP.1');
							dpatch('5337777', 'HR_PF.K.RUP.2');
							dpatch('6699770', 'HR_PF.K.RUP.3');
							dpatch('7666111', 'HR_PF.K.RUP.4');
							dpatch('9062727', 'HR_PF.K.RUP.5');
							dpatch('10015566', 'HR_PF.K.RUP.6');
							dpatch('12807777', 'HR_PF.K.RUP.7');
							dpatch('14488556', 'HR_PF.K.RUP.8');
							dpatch('17774746', 'HR_PF.K.RUP.9');				
							l_o('<br>');						
					end if;					
            end if;   
      end if;
      --l_o('</td></tr>');
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');   
end;



-- Display Project level
procedure projects is
    run_type varchar2(20):='&1';
	product varchar2(20):='&2';
    pj_level varchar2(20);
    pj_level_n varchar2(50);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_exists number;
begin

   if upper(product) in ('OTL','ALL') then              
      if :apps_rel like '12.1%' then
                       
            select max(to_number(bug_number)) into pj_level from ad_bugs 
            WHERE BUG_NUMBER IN ('7456340','8504800','9147711','12378114','14162290','17839156');            
            
			
            if pj_level='17839156' then
                  
                  if upper(run_type)='ALL' then
                          l_o(' <a name="projects"></a><b>Projects</b><br>');
						  l_o('<span class="sectionb"><b>Actual level:</b> Patch 17839156 (R12.PJ_PF.B.DELTA.6) Projects Upd Pack 6 for 12.1</span><br><br>');							  
                  end if;
                  
                  
            else
                  SELECT DECODE(BUG_NUMBER,
                 '7456340', '(R12.PJ_PF.B.DELTA.1) Projects Upd Pack 1 for 12.1',
				'8504800', '(R12.PJ_PF.B.DELTA.2) Projects Upd Pack 2 for 12.1',
				'9147711', '(R12.PJ_PF.B.DELTA.3) Projects Upd Pack 3 for 12.1',
			   '12378114', '(R12.PJ_PF.B.DELTA.4) Projects Upd Pack 4 for 12.1',
			   '14162290', '(R12.PJ_PF.B.DELTA.5) Projects Upd Pack 5 for 12.1')
                , LAST_UPDATE_DATE   
                  into pj_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =pj_level and rownum < 2;
                  l_o(' <a name="projects"></a><b>Projects</b><br>');
                  l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || pj_level || ' ' || pj_level_n || ' applied on ' || v_date || '</span><br><br>');
                  l_o('<span class="sectionb"> Latest PJ level is: <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17839156">');
				  l_o('Patch 17839156</a> R12.PJ_PF.B.DELTA.6</span><br>');
				  
            end if; 
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into pj_level from ad_bugs 
            WHERE BUG_NUMBER IN ('6022657','6266113','6512963','7292354');
            
            if pj_level='7292354' then
                  
                  if upper(run_type)='ALL' then
                          l_o(' <a name="projects"></a><b>Projects</b></td><td><br>');
						  l_o('<span class="sectionb"><b>Actual level:</b> Patch 7292354 R12.PJ_PF.A.DELTA.6</span><br>');
                
                  end if;
            else
                  SELECT DECODE(BUG_NUMBER,
                 '6022657', '(R12.PJ_PF.A.DELTA.2) Projects Update Pack 2',
				'6266113', '(R12.PJ_PF.A.DELTA.3) Projects Update Pack 3',
				'6512963', '(R12.PJ_PF.A.DELTA.4) Projects Update Pack 4',
				'7292354', '(R12.PJ_PF.A.DELTA.6) Projects Update Pack 6')
                  , LAST_UPDATE_DATE  
                  into pj_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =pj_level and rownum < 2;
                  l_o('<a name="projects"></a><b>Projects</b><br>');
                  l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || pj_level || ' ' || pj_level_n || ' applied on ' || v_date || '</span><br><br>');
                  l_o('<span class="sectionb"> Latest PJ level is:  <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=7292354">');
				  l_o('Patch 7292354</a> R12.PJ_PF.A.DELTA.6<br></span>');
				  
            end if;   
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
            
            if v_exists=0 then
                    l_o(' <a name="projects"></a><b>Projects</b><br>');
					l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span><span class="sectionb"> No PJ patch applied!</span><br><br>');
                    l_o('<span class="sectionb"> Latest PJ level is: <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=5644830">');
					l_o('Patch 5644830</a> (11i.PJ_PF.M) Rollup 4<br>');
					l_o('</span>');
					:w5:=:w5+1;
					issuep:=TRUE;
            else        
                    select max(to_number(bug_number)) into pj_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('2342093','2484626','3074777','3397153','4027334','4285356','4667949','3485155','4461989','4997599','5105878','5644830');
                    if pj_level='5644830' then
                          
                          if upper(run_type)='ALL' then
                                  l_o(' <a name="projects"></a><b>Projects</b><br>');
								  l_o('<span class="sectionb"><b>Actual level:</b> Patch 5644830 (11i.PJ_PF.M) Rollup 4</span><br><br>');
                          end if;
                                         
                          
                    else
                          SELECT DECODE(BUG_NUMBER,
                         '2342093', 'PJ_PF:CONSOLIDATED 11.5.7 UPGRADE FIXES FOR PROJECT ACCOUNTING PRODUCT FAMILY',
						'2484626',  'FAMILY PACK 11i.PJ_PF.K',    
						'3074777',  'FAMILY PACK 11i.PJ_PF.L',        
						'3397153', '(11i.PJ_PF.L10) Projects Family Pack L10',
						'4027334', '(11.5.10) Projects Consolidated Patch for CU1',
						'4285356', '(11.5.10) Projects Consolidated Patch for CU2',
						'4667949', '(11i.PJ_PF.L10) Rollup 1',
						'3485155', '(11i.PJ_PF.M) Projects Family Pack M',
						'4461989', '(11i.PJ_PF.M) Rollup',
						'4997599', '(11i.PJ_PF.M) Rollup 2',
						'5105878', '(11i.PJ_PF.M) Rollup 3',
						'5644830', '(11i.PJ_PF.M) Rollup 4')
                        , LAST_UPDATE_DATE  
                          into pj_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =pj_level and rownum < 2;
                          l_o('<a name="projects"></a><b>Projects</b><br>');
                          l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || pj_level || ' ' || pj_level_n || ' applied on ' || v_date || '</span><br><br>');
                          l_o('<span class="sectionb"> Latest PJ level is: <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=5644830">');
						  l_o('Patch 5644830</a> (11i.PJ_PF.M) Rollup 4<br></span>');
						  
       
                    end if;                   
            end if;   
      end if;
      
  end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


		
-- Display Mandatory Patching
procedure mandatory is
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_exists number:=0; 
  v_status varchar2(100);  
  issue boolean:=FALSE;
  -- Display patch
	procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	  v_patch2 varchar(10):=v_patch;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch2	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch2;
					end if;
					if v_patch2='17050005' and v_exists=0 then
						select count(1) into v_exists from ad_bugs where bug_number='17909898';
						if v_exists>0 then
							v_patch2:='17909898';
						end if;
					end if;
						if (v_exists=0) then             
								 issue:=TRUE;
								 l_o('<div class="diverr">');
								 l_o('<img class="error_ico"><font color="red">Error: </font>Please plan to install ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');
								 l_o('</div>');
								 :e5:=:e5+1;
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch2 and rownum < 2;
							l_o('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');							
						end if;
	end; 
begin
     
l_o(' <br><br><a name="mandatory"></a><b>Mandatory Patches</b><br>');
	 
select count(1) 
     into v_exists
      from hr_legislation_installations
     where 
	 (substr(application_short_name,1,4)='PAY' 
	 or
	 ( substr(application_short_name,1,4)='PER' and Legislation_code = 'US'))
	 and status='I';
if v_exists>0  and :pay_status='Installed' then	
	l_o('<Table>');
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AU'  and status='I';     
     if v_exists>0 then
                
				l_o('<tr><td>AU Australia</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21238399', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');				
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21267565', 'STATUTORY UPDATES EFFECTIVE 01-JUL-2015');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19764591', 'AU.22 AUSTRALIA CONSOLIDATED PATCH');	
				elsif :apps_rel like '11.5%' then					
					dpatch('14488556', 'HR_PF.K.RUP.8');
					dpatch('17314780','11I.AU.21 AUSTRALIA CUMULATIVE RELEASE');					
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'CN'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>CN China</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('13715802','R12.PER.B - TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');
					dpatch('16741703','R12.PER.B - Prevent Tax payable when under One Yuan (RMB)');									
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('13715802','R12.PER.A - TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');				
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('13717027','TAX ON ENTERPRISE ANNUITY EMPLOYER CONTRIBUTIONS');
					dpatch('14625844','Prevent Tax Payable when under One YUAN (RMB)');					
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'DK'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>DK Denmark</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20218977', 'ABP PGGM Calculation Changes 2015');
					dpatch('20107803', 'Danish Legislative Changes 2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20218977', 'ABP PGGM Calculation Changes 2015');
					dpatch('20107803', 'Danish Legislative Changes 2015');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('16002352', 'Danish Legislative Changes 2013 Part-3');
					dpatch('15945507', 'Danish Legislative Changes 2013 Part 1, 2');
					dpatch('13500283', 'Danish Legislative Changes 2012');					
				end if;		
				l_o('</td></tr>');				
	end if;
	
			select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'FI'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>FI Finland</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('12793751', 'Delivers the Finland legislative changes for 2011 Part-I');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('12793751', 'Delivers the Finland legislative changes for 2011 Part-I');				
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('10393363', 'Delivers the Finland legislative changes for 2011 Part-I');				
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'HK'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>HK Hong Kong</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20768287','TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20768287','TATUTORY MINIMUM WAGE RATE CHANGE EFFECTIVE 01-MAY-2015');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('17385401','R12.PER.A - R12.HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013 1 JUN 2014');										
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('17539543','HK.15 MPF MIN/MAX RI CHANGES FOR 1 NOV 2013');				
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>IE Ireland</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21499442', 'Ireland P35 Version 12 Reporting Changes');
					dpatch('21909181', 'Ireland Pension Tracing Number Changes');
					dpatch('22163081', 'Ireland Budget Changes 2016');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21499442', 'Ireland P35 Version 12 Reporting Changes');
					dpatch('21909181', 'Ireland Pension Tracing Number Changes');
					dpatch('22163081', 'Ireland Budget Changes 2016');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20255656', 'Employer PAYE Reference Reporting Changes');
					dpatch('20235946', 'Employers PAYE Reference Increased To 9 Characters');
					dpatch('20210371', 'USC On Tax Information Screen');
					dpatch('19820820', 'Ireland EIR Code Address Changes For 2015');
					dpatch('20073662', 'Ireland Budget Changes Effective 01-JAN-2015');
					dpatch('18510224','IE MEDICAL INSURANCE CHANGES 2014');
					dpatch('19068744', 'IE SEPA BANK OF IRELAND (BOI) CHANGES');
					dpatch('19060389', 'Ireland P35 Version 11 Reporting Changes');
					dpatch('19684111', 'Ireland P60 Reporting Changes 2014 Onwards');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('16811068', 'Ireland Local Property Tax And Report Changes');
					dpatch('16905146', 'Ireland Local Property Tax P30 Paper Report Changes');
					dpatch('16925013', 'LPT Deducting Over 5 Not 6 Months From July 2013');
					dpatch('16976741', 'IE P30 Paper Report Not Reporting Non Zero USC/LPT');
					dpatch('16999708', 'LPT Deducing From Statutory Redundancy');
					dpatch('17180755', 'IE SEPA FURTHER CHANGES: AIB FORMAT'); 
					dpatch('17542073', 'IE SEPA HSBC BANK CHANGES');
					dpatch('17573671', 'IE SEPA ULSTER BANK CHANGES');
					dpatch('17592973', 'Generating SEPA File For PayPath Payment Method, SEPA Danske Bank Format');
					dpatch('17731547', 'EAP NOVEMBER 2013 ISSUES: P35 XML REPORT CHANGES');
					dpatch('17775887', 'IRELAND SEPA CHANGES: HSBC FORMAT: FEEDBACK FROM HSBC');			
				end if;		
				l_o('</td></tr>');				
	end if;
	
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IN'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>IN India</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21543732','INDIA HRMS CONSOLIDATED PATCH IN.12');										
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19856359','INDIA HRMS CONSOLIDATED UPDATE R12.IN.11');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('13914662','INDIA HRMS CONSOLIDATED UPDATE 11i.IN.08');	
					dpatch('13870875','Form 24Q E-TDS Regular Changes');
					dpatch('14351973','India Budget Changes for Section 80CCG and Section 80TTA');
					dpatch('16359871','Andhra Pradesh professional Tax changes Effective 06-FEB-2013');
					dpatch('16520998','India Budget Changes Gujarat Professional Tax Changes Effective 01-APR-2013');
					dpatch('16669518','Madhya Pradesh Professional Tax Changes Effective 01-APR-2013	');				
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'JP'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>JP Japan</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('17015507','R12.PER.B - JAPANESE HRMS CONSOLIDATED PATCH R121.JP.13');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('13330458','R12.PER.A - JAPANESE HRMS CONSOLIDATED PATCH R12.JP.12');	
					dpatch('13743712','R12.PER.A - H24 UNEMPLOYMENT INSURANCE RATE');					
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('17015482','JAPANESE HRMS CONSOLIDATED UPDATE R115.JP.13');					
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KR'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>KR Korea</td><td>');
                if (:apps_rel like '12.2%') then
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21778035','KOREA CUMULATIVE RELEASE PATCH - KR.76');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21778035','KOREA CUMULATIVE RELEASE PATCH - KR.76');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20533775','KOREA CUMULATIVE RELEASE PATCH - KR.73');					
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('16518233','KOREA CUMULATIVE RELEASE PATCH - 11i.KR.69');
					dpatch('17446056','KOREA 2013 YEA CHANGES: RENT EXEMPTION,MAXIMUM SPECIAL EXEMPTION LIMIT');
					dpatch('18107426','KOREA 2013 YEA CHANGES: SINGLE PARENT EXEMPTION');
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'KW'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>KW Kuwait</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20331815', 'Change in employee social insurance contributions for Kuwait');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20331815', 'Change in employee social insurance contributions for Kuwait');								
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19009589', 'R12.PAY.A - KW Unemployment Insurance');
					dpatch('16787133', 'R12.PAY.A - Kuwait SI changes 2013');
					dpatch('15934773', 'R12.PAY.A - KUWAIT Report changes');					
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('16806105', 'Kuwait SI changes 2013');
					dpatch('15934061', 'KUWAIT Report changes');					
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'MX' and status='I';
     
     if v_exists>0 then
                l_o('<tr><td>MX Mexico</td><td>');
				if (:apps_rel like '12.2%') then					
					dpatch('17050005', 'HRMS RUP4');	
					dpatch('20259629','2014 EOY Phase 1');
					dpatch('20794928','Economic Zone B Minimum Wage');
					dpatch('21911563','MINIMUM WAGE ZONE B');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20259629','2014 EOY Phase 1');
					dpatch('20794928','Economic Zone B Minimum Wage');
					dpatch('21911563','MINIMUM WAGE ZONE B');	
				elsif (:apps_rel like '12.0%') then
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20259629','2014 EOY Phase 1');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('15919087','NOV 2012 MINIMUM WAGE UPDATES');
					dpatch('14776810','2012 Year End Phase 1');
					dpatch('16034967','2013 Year Begin');
					dpatch('16023541','GETTING WRONG VALUES WITH SS QUOTA PRORATED WHEN SENIORITY CHANGES IN MID');
					dpatch('16090552','2012 Year End Phase 2');
					dpatch('16270938','NO ANNUAL TAX ADJUST, ISR IS STILL ZERO FOR THE ISR WITHHELD');
					dpatch('16607347','11I: MEXICO STATE TAX UPDATES 2013');
					dpatch('17500878','11I:MX SEP13: QUINTANA ROO STATE TAX RATE UPDATE');
				end if;				
				l_o('</td></tr>');
				
	end if;  
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NL'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>NL Netherlands</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');	
					dpatch('20279973', 'ABP PGGM Calculation Changes 2015');
					dpatch('20972577', 'Legislative Changes - Legal Minimum Wages effective from 01-Jul-2015');
				elsif (:apps_rel like '12.1%') then						
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20279973', 'ABP PGGM Calculation Changes 2015');
					dpatch('20972577', 'Legislative Changes - Legal Minimum Wages effective from 01-Jul-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20279973', 'ABP PGGM Calculation Changes 2015');			
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('17558120', 'Delivers changes to Dutch Annual Tax Statement for the Employee Report effective 2013');				
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NO'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>NO Norway</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21327657', 'NO: Half tax calculation');	
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21327657', 'NO: Half tax calculation');					
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('14177955', 'Delivers the K27 reimbursement file upload');			
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('14171993', 'Delivers the K27 reimbursement file upload');				
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'NZ'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>NZ New Zealand</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20699005', 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20699005', 'NEW ZEALAND CHANGES EFFECTIVE 01-APR-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('11867792','R12.PER.A - NEW ZEALAND CUMULATIVE RELEASE R12.NZ.08');	
					dpatch('13697009','R12.PER.A - NZ STATUTORY UPDATES 2012');					
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('11867781','NEW ZEALAND CUMULATIVE RELEASE 11i.NZ.08');
					dpatch('13627558','NZ STATUTORY UPDATES 2012');					
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SA'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>SA Saudi Arabia</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('18723486', 'SA Unemployment insurance changes');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('18723486', 'SA Unemployment insurance changes');
					dpatch('19054295', 'Can not create absence');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('18760981', 'Saudi Arabia Unemployment Insurance changes');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');				
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SE'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>SE Sweden</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');										
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('12589129', 'Delivers the Sweden legislative changes for 2011');				
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('10393370', 'Delivers the Sweden legislative changes for 2011');
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'SG'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>SG Singapore</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20752374','SINGAPORE HRMS CONSOLIDATED PATCH RECALIBRATING');				
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('20055967','IRAS and IR21 CHANGES EOY 2014');					
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');
					dpatch('17188127','SG.35 SINGAPORE CONSOLIDATED PATCH');				
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'AE'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>AE United Arab Emirates</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('19819953','ROUTING NUMBER IN UAE LEGISLATION');
					dpatch('20075576','UAE National identifier validation changes and Formula Result rule for KW SI');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('19900524','UAE National identifier validation changes');
					dpatch('19819953','ROUTING NUMBER IN UAE LEGISLATION');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19900524','UAE National identifier validation changes');
					dpatch('19819953','ROUTING NUMBER IN UAE LEGISLATION');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');					
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'GB'  and status='I';
     
     if v_exists>0 then
                v_exists:=0;
				l_o('<tr><td>UK GB United Kingdom</td><td>');
				l_o('<span class="sectionblue1">Advice: </span><span class="sectionb">Periodically review:<br><a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1324671.1" target="_blank">Note 1324671.1</a> ');
				l_o('EBS UK Payroll : Real Time Information (RTI) White Paper and Patch Information </span><br><br>');
				if (:apps_rel like '12.2%') then
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('20513833','RTI GB UPDATE NI CATEGORY ERRORS');
					dpatch('20066028','PENSERVER LEGISLATIVE CHANGES');
					dpatch('20314902','YEAR END 2014-15 / START OF YEAR 2015-16');
					dpatch('20201659','UK YEAR END 2014-15 / START OF YEAR 2015-16');	
					dpatch('19223877','P11D LEGISLATIVE CHANGES for 2014-15');
					dpatch('20591016','SHARED PARENTAL LEAVE AND PAY CHANGES');
					dpatch('20692428','TAX YEAR END BUG FIXES');
					dpatch('20888184','TAX YEAR END BUG FIXES');
					dpatch('21033080','PENSIONS AUTOMATIC ENROLMENT/RE-ENROLMENT LEGISLATIVE CHANGES');
				elsif (:apps_rel like '12.0%') then
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('18776254','RTI CONSOLIDATED PATCH: SEPTEMBER 2014');
					dpatch('18972503','RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES');
					dpatch('18693666','DIRECT EARNINGS ATTACHMENT CHANGES: PHASE2');		
					dpatch('18453569','LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme');
					dpatch('18333366','DIRECT EARNINGS ATTACHMENT CHANGES');
					dpatch('18293592', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/P11D/LGPS CHANGES');
					dpatch('18285764', 'UK YEAR END 2013-14/START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014/LGPS CHANGES');					
					dpatch('18100149','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014');
					dpatch('17274247','RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH');
				elsif :apps_rel like '11.5%' then
					dpatch('17774746', 'HR_PF.K.RUP.9');
					l_o('<div class="divok">');
					l_o('Note: These patches are only available with ACS Service, please refer ');
					l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1597416.1" target="_blank">Note 1597416.1</a> Payroll Legislative Updates for Oracle E-Business Suite 11.5.10:<br>');
					l_o('</div');
					dpatch('18776031','RTI CONSOLIDATED PATCH: SEPTEMBER 2014');
					dpatch('18972450','RTI FULL PAYMENT SUMMARY (FPS) SHOWING ASSIGNMENT CHANGES AS LEAVE DATES');
					dpatch('18449320','LGPS 2014 REPORTING CHANGES - ONLY if you are using LGPS pension scheme');
					dpatch('18333164','DIRECT EARNINGS ATTACHMENT CHANGES');
					dpatch('18305045','UK TAX YEAR END/EYU/P11D CHANGES 2013 - 2014');
					dpatch('18293579','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /P11D/LGPS CHANGES');
					dpatch('18285780','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014 /LGPS CHANGES');
					dpatch('18100105','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014');					
					dpatch('18032762','UK YEAR END 2013-14 / START OF YEAR 2014-15 AND RTI CHANGES EFFECTIVE FROM APRIL 2014:PHASE2 PATCH');					
					dpatch('17964873','UK TAX YEAR END CHANGES 2013 - 2014');
					dpatch('17274234','RTI : REAL TIME INFORMATION CHANGES 2012 - 2013 : CONSOLIDATED PATCH');	
				end if;
				
				l_o('</td></tr>');
	end if;  
	
     select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  (Legislation_code = 'US' ) and status='I';
     
     if v_exists>0 then
				l_o('<tr><td>US United States</td><td>');
                if (:apps_rel like '12.2%') then		
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');
					dpatch('21142484','Q2 2015 Statutory and JIT Update');
					dpatch('21664392','Q3 2015 SQWL and JIT STATUTORY UPDATE');
				elsif (:apps_rel like '12.1%') then		
					dpatch('21142484','Q2 2015 Statutory and JIT Update');
					dpatch('21664392','Q3 2015 SQWL and JIT STATUTORY UPDATE');
				elsif (:apps_rel like '12.0%') then
					dpatch('19507770','Q3 2014 Statutory and JIT Update');
				elsif :apps_rel like '11.5%' then					
					dpatch('21142464','Q2 2015 Statutory and JIT Update');
					dpatch('21664379','Q3 2015 SQWL and JIT STATUTORY UPDATE');
				end if;	                
				l_o('</td></tr>');
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  (Legislation_code = 'US' or Legislation_code = 'CA') and status='I';
     
     if v_exists>0 then	
                l_o('<tr><td>US CA United States and Canada</td><td>');
				if (:apps_rel like '12.2%') then							
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');	
					dpatch('20365000','End of Year 2014 Phase 3');
					dpatch('21911111','End of Year 2015 Phase 1');
				elsif (:apps_rel like '12.1%') then							
					dpatch('20000288', 'R12.HR_PF.B.delta.8');	
					dpatch('20365000','End of Year 2014 Phase 3');
					dpatch('21911111','End of Year 2015 Phase 1');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');					
					dpatch('19701971','End of Year 2014 Phase 1');
					dpatch('20212223','End of Year 2014 Phase 2');
					dpatch('20365000','End of Year 2014 Phase 3');
				elsif :apps_rel like '11.5%' then				
					dpatch('17774746', 'HR_PF.K.RUP.9');
					dpatch('21911110','End of Year 2015 Phase 1');
					dpatch('20364999','End of Year 2014 Phase 3');
					dpatch('20301513','Year Begin 2015 Statutory Update 2');
					dpatch('20212121','Year Begin 2015 Statutory Update');
				end if;	
				l_o('</td></tr>');
	end if;
     	 
	
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PER'
     and  Legislation_code = 'US'  and status='I';
     
     if v_exists>0 then
                
				l_o('<tr><td>US United States HR</td><td>');
                if (:apps_rel like '12.2%') then
					dpatch('18844524','US HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 12.2.3 or Higher');
					dpatch('20979690','US HR 2015 ANNUAL STATUTORY PATCH FOR RELEASE 12.2');
				elsif (:apps_rel like '12.1%') then					
					dpatch('18844524','US HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 12.1 HRMS RUP6');
					dpatch('20979690','US HR 2015 ANNUAL STATUTORY PATCH FOR RELEASE 12.1 HRMS RUP6 or later');
				elsif (:apps_rel like '12.0%') then					
					dpatch('18844524','US HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 12.0');	
				elsif :apps_rel like '11.5%' then					
					dpatch('18844514','UUS HR 2014 ANNUAL STATUTORY PATCH FOR RELEASE 11I');
					dpatch('20979676','US HR 2015 ANNUAL STATUTORY PATCH');
				end if;		
				l_o('</td></tr>');				
	end if;
	
	select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'ZA'  and status='I';     
     if v_exists>0 then                
				l_o('<tr><td>ZA South Africa</td><td>');
                if (:apps_rel like '12.2%') then					
					dpatch('19193000', 'R12.HR_PF.C.Delta.6');	
					dpatch('21499164', 'INTEREST RATE GLOBAL VALUE CHANGE EEFECTIVE FROM 01-AUG-2015');					
				elsif (:apps_rel like '12.1%') then					
					dpatch('20000288', 'R12.HR_PF.B.delta.8');
					dpatch('21966943', 'CHANGES FOR BANK ACCOUNT NUMBER VALIDATION');
					dpatch('21499164', 'INTEREST RATE GLOBAL VALUE CHANGE EEFECTIVE FROM 01-AUG-2015');
				elsif (:apps_rel like '12.0%') then					
					dpatch('16077077', 'R12.HR_PF.A.delta.11');
					dpatch('19544341', 'ZA: AUGTYE14 REPORTING CHANGES');
				elsif :apps_rel like '11.5%' then					
					dpatch('12807777', 'HR_PF.K.RUP.7');	
					dpatch('17366859', 'ZA : Tax Audit report');					
				end if;		
				l_o('</td></tr>');				
	end if;
	
	l_o('</table>');
    
    if issue then
		 issuep:=TRUE;
		 l_o('<span class="sectionb">Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1160507.1" target="_blank">Note 1160507.1</a> ');
		 l_o('Oracle E-Business Suite HCM Information Center - Consolidated HRMS Mandatory Patch List<br></span>');		
	else
        if upper(run_type)='ALL' then
          l_o('<span class="sectionblue1">Advice:</span><span class="sectionb">Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1160507.1" target="_blank">Note 1160507.1</a> ');
		  l_o('Oracle E-Business Suite HCM Information Center - Consolidated HRMS Mandatory Patch List<br></span>');
		end if;
    end if;
	if :apps_rel like '11.5%'  then
		issuep:=TRUE;
		l_o('<div class="divwarn">');
		l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span>Please note that statutory legislative support expired on November 30th 2013');
		l_o('<span class="sectionb">, please refer to <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1384995.1" target="_blank">Note 1384995.1</a> ');
		l_o(' When Is Statutory Legislative Support for Payroll Going To End For Release 11i<br></div>');				
	end if;
	
                 
 end if;      
	
	if :apps_rel like '11.5%'  then
		if upper(product) in ('ALL','BEN') then
				l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Benefits: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=124100.1" target="_blank">Note 124100.1</a> ');
				l_o('Benefits Compensation and Benefits Patch List<br></span>');		
			end if;		
			if upper(product) in ('ALL','IRC') then
				l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> iRecruitment: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=199221.1" target="_blank">Note 199221.1</a> ');
				l_o('Oracle 11i HRMS iRecruitment (iRec) Recommended and Mandatory Patches<br></span>');
			end if;
			if upper(product) in ('ALL','OTL') then
				l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Time and Labor: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=214886.1" target="_blank">Note 214886.1</a> ');
				l_o('Oracle 11i Time and Labor (OTL) Mandatory Patch List<br></span>');
			end if;
			if upper(product) in ('ALL','SSHR') then
				l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Self Service Human Resources: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=108897.1" target="_blank">Note 108897.1</a> ');
				l_o('Recommended Patch List for Self-Service Human Resources (SSHR) in HRMS 11i <br></span>');
			end if;
	elsif (upper(product) in ('ALL','HR')) and ((:apps_rel like '11.5%') or (:apps_rel like '12.0%')) then
			l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Human Resources: Periodically review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=108547.1" target="_blank">Note 108547.1</a> ');
			l_o('Oracle Human Resources Recommended Patches<br></span>');	
	end if;	
	l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> In order to identify recommended patches use My Oracle Support - Recommended Patches</span><br>');	

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display ATG level
procedure atg is
    run_type varchar2(20):='&1';
    atg_level varchar2(20);
    atg_level_n varchar2(50);
    v_date ad_bugs.LAST_UPDATE_DATE%type;
    v_exists number;
begin
      l_o(' <br><br><a name="atg"></a><b>ATG</b><br>');
      if :apps_rel like '12.2%' then
			SELECT max(to_number(adb.bug_number)) into atg_level FROM ad_bugs adb
			WHERE adb.bug_number in ('10110982','14222219','15890638','17007206','17909318')
			;
			if atg_level='17909318' then                  
                  l_o('<span class="sectionb"><b>Actual level:</b> Patch 17909318 R12.ATG_PF.C.delta.4</span><br><br>'); 
            else
				SELECT DECODE(BUG_NUMBER
				 , '10110982', 'R12.ATG_PF.C'
				 , '14222219', 'R12.ATG_PF.C.delta.1'
				 , '15890638', 'R12.ATG_PF.C.delta.2'
				 , '17007206', 'R12.ATG_PF.C.delta.3','17909318', 'R12.ATG_PF.C.delta.4')
					, LAST_UPDATE_DATE   
					  into atg_level_n, v_date
					  FROM ad_bugs 
					  WHERE BUG_NUMBER =atg_level and rownum < 2;
				 l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '</span><br><br>');
                  l_o('<div class="divwarn">');
				  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=17909318">Patch 17909318</a> ');
				  l_o('R12.ATG_PF.C.delta.4<br></div>');
				  :w5:=:w5+1;
				  issuep:=TRUE;
			end if;	  
				
                 
	  elsif :apps_rel like '12.1%' then                       
            select max(to_number(bug_number)) into atg_level from ad_bugs 
            WHERE BUG_NUMBER IN ('6430106','7307198','7651091','8919491');            
                 
            if atg_level='8919491' then                  
                  if upper(run_type)='ALL' then
                          l_o('<span class="sectionb"><b>Actual level:</b> Patch 8919491 R12.ATG_PF.B.delta.3</span><br><br>');
                  end if;
                  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1273640.1" target="_blank"> Note 1273640.1</a> ');
                  l_o('Known ATG issues on Top of 12.1.3 - r12.atg_pf.b.delta.3, Patch 8919491</span>');
                  
            else
                  SELECT DECODE(BUG_NUMBER
                 , '6430106', 'R12.ATG_PF.B'
                 , '7307198', 'R12.ATG_PF.B.delta.1'
                 , '7651091', 'R12.ATG_PF.B.delta.2'
                 , '8919491', 'R12.ATG_PF.B.delta.3')
                , LAST_UPDATE_DATE   
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
                  
                  l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '</span><br><br>');
                  l_o('<div class="divwarn">');
				  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=8919491">Patch 8919491</a> ');
				  l_o('R12.ATG_PF.B.delta.3<br></div>');
				  :w5:=:w5+1;
				  issuep:=TRUE;
            end if; 
            
       elsif :apps_rel like '12.0%' then
            select max(to_number(bug_number)) into atg_level from ad_bugs 
            WHERE BUG_NUMBER IN ('4461237','5907545','5917344','6077669','6272680','6594849','7237006');
            
            if atg_level='7237006' then
                  
                  if upper(run_type)='ALL' then
                          l_o('<span class="sectionb"><b>Actual level:</b> Patch 7237006 R12.ATG_PF.A.delta.6</span><br>');
                  else
                          l_o('<span class="sectionb"><img class="check_ico">OK! You are at latest level available: Patch 7237006 R12.ATG_PF.A.delta.6.</span><br>');
                  end if;
            else
                  SELECT DECODE(BUG_NUMBER
                 , '4461237', 'R12.ATG_PF.A'
                 , '5907545', 'R12.ATG_PF.A.delta.1'
                 , '5917344', 'R12.ATG_PF.A.delta.2'
                 , '6077669', 'R12.ATG_PF.A.delta.3'
                 , '6272680', 'R12.ATG_PF.A.delta.4'
                 , '6594849', 'R12.ATG_PF.A.delta.5'
                 , '7237006', 'R12.ATG_PF.A.delta.6')
                  , LAST_UPDATE_DATE  
                  into atg_level_n, v_date
                  FROM ad_bugs 
                  WHERE BUG_NUMBER =atg_level and rownum < 2;
                  
                  l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '</span><br><br>');
				  l_o('<div class="divwarn">');
                  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=7237006">Patch 7237006</a>');
				  l_o('				  R12.ATG_PF.A.delta.6<br></div>');
				  :w5:=:w5+1;
				  issuep:=TRUE;
            end if;   
            
       elsif   :apps_rel like '11.5%' then   
            select count(1) into v_exists from ad_bugs 
            WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
            
            if v_exists=0 then
                    l_o('<div class="diverr">');
					l_o('<img class="error_ico"><font color="red">Error:</font> No ATG RUP patch applied!</span><br><br>');
                    l_o('Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=6241631">Patch 6241631</a> ');
					l_o('11i.ATG_PF.H RUP7</div><br>');
					issuep:=TRUE;
            else        
                    select max(to_number(bug_number)) into atg_level from ad_bugs 
                    WHERE BUG_NUMBER IN ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631');
                    if atg_level='6241631' then
                          
                          if upper(run_type)='ALL' then
                                  l_o('<span class="sectionb"><b>Actual level:</b> Patch 6241631 11i.ATG_PF.H RUP7<span><br><br>');
                          end if;
                          l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Ensure you applied patches to fix known issues (note periodically updated): ');
                          l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=858801.1" target="_blank"> Note 858801.1</a> ');
                          l_o('Known Issues On Top of 11i.atg_pf.h.delta.7 (RUP7) - 6241631</span>');                    
                          
                    else
                          SELECT DECODE(BUG_NUMBER
                         , '3438354', '11i.ATG_PF.H'
                         , '4017300', '11i.ATG_PF.H RUP1'
                         , '4125550', '11i.ATG_PF.H RUP2'
                         , '4334965', '11i.ATG_PF.H RUP3'
                         , '4676589', '11i.ATG_PF.H RUP4'
                         , '5473858', '11i.ATG_PF.H RUP5'
                         , '5903765', '11i.ATG_PF.H RUP6'
                         , '6241631', '11i.ATG_PF.H RUP7')
                        , LAST_UPDATE_DATE  
                          into atg_level_n, v_date
                          FROM ad_bugs 
                          WHERE BUG_NUMBER =atg_level and rownum < 2;
                          
                          l_o('<span class="sectionb"><b>Actual level:</b> Patch ' || atg_level || ' ' || atg_level_n || ' applied on ' || v_date || '</span><br><br>');
						  l_o('<div class="divwarn">');
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please plan to install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=6241631">');
						  l_o('Patch 6241631</a> 11i.ATG_PF.H RUP7<br></div>');
						  :w5:=:w5+1;
						  issuep:=TRUE;
       
                    end if;                   
            end if;   
      end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display hrglobal information
procedure hrglobal is
    v_exists number;
    v_hrglobal_date ad_patch_runs.end_date%type;
	v_action ad_patch_runs.end_date%type;
    v_hrglobal_patch_opt ad_patch_runs.PATCH_ACTION_OPTIONS%type;
    v_hrglobal_patch ad_applied_patches.patch_name%type;
	cursor get_patches (rupdate date) is
	select distinct PATCH_TYPE,PATCH_NAME,max(trunc(LAST_UPDATE_DATE)) ld from ad_applied_patches where last_update_date> rupdate group by PATCH_TYPE,PATCH_NAME order by max(trunc(LAST_UPDATE_DATE));
begin
      
      --l_o(' <TR><td>Hrglobal</td><td>');
   
      if   :apps_rel like '12%' then
            SELECT count(1) into v_exists
            FROM ad_patch_runs pr
            WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
              AND pr.SUCCESS_FLAG = 'Y'
              AND pr.end_date =(
               SELECT MAX(pr.end_date)
               FROM ad_patch_runs pr
               WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
                 AND pr.SUCCESS_FLAG = 'Y');
      else
            SELECT count(1) into v_exists
            FROM ad_patch_runs pr
            WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
              AND pr.SUCCESS_FLAG = 'Y'
              AND pr.end_date =(
               SELECT MAX(pr.end_date)
               FROM ad_patch_runs pr
               WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
                 AND pr.SUCCESS_FLAG = 'Y');
      end if;
      
      
	  if (v_exists>0)  then
              if   :apps_rel like '12%' then
					  SELECT pr.end_date 
						   , pr.PATCH_ACTION_OPTIONS 
					  into v_hrglobal_date, v_hrglobal_patch_opt 
					  FROM ad_patch_runs pr
					  WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
						AND pr.SUCCESS_FLAG = 'Y'
						AND pr.end_date =(
						 SELECT MAX(pr.end_date)
						 FROM ad_patch_runs pr
						 WHERE pr.PATCH_TOP LIKE '%/per/12.0.0/patch/115/driver'
						   AND pr.SUCCESS_FLAG = 'Y');
			else
						SELECT pr.end_date 
						   , pr.PATCH_ACTION_OPTIONS 
					  into v_hrglobal_date, v_hrglobal_patch_opt 
						FROM ad_patch_runs pr
						WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
						  AND pr.SUCCESS_FLAG = 'Y'
						  AND pr.end_date =(
						   SELECT MAX(pr.end_date)
						   FROM ad_patch_runs pr
						   WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
							 AND pr.SUCCESS_FLAG = 'Y');
			end if;	 
				 
              select ap.patch_name  patchnumber into v_hrglobal_patch
                    from ad_applied_patches ap
                       , ad_patch_drivers pd
                       , ad_patch_runs pr
                       , ad_patch_run_bugs prb
                       , ad_patch_run_bug_actions prba
                       , ad_files f
                    where f.file_id                  = prba.file_id
                      and prba.executed_flag         = 'Y'
                      and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                      and prb.patch_run_id           = pr.patch_run_id
                      and pr.patch_driver_id         = pd.patch_driver_id
                      and pd.applied_patch_id        = ap.applied_patch_id
                      and f.filename = 'hrglobal.drv'
                      and pr.end_date = (select max(pr.end_date)
                                                 from ad_applied_patches ap
                                                    , ad_patch_drivers pd
                                                    , ad_patch_runs pr
                                                    , ad_patch_run_bugs prb
                                                    , ad_patch_run_bug_actions prba
                                                    , ad_files f
                                                  where f.file_id                  = prba.file_id
                                                    and prba.executed_flag         = 'Y'
                                                    and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                    and prb.patch_run_id           = pr.patch_run_id
                                                    and pr.patch_driver_id         = pd.patch_driver_id
                                                    and pd.applied_patch_id        = ap.applied_patch_id
                                                    and f.filename = 'hrglobal.drv');

                l_o('<br><span class="sectionb">Your date of last successful run of hrglobal.drv was with patch '||v_hrglobal_patch|| ' ' || v_hrglobal_patch_opt);
				l_o(' on ' || v_hrglobal_date   ||'<br><br>' );
				
				if  (:hr_status='Installed') then
					if v_hrglobal_date<:v_rup_date then
						l_o('<div class="divwarn">');
						l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You did not performed hrglobal after last HRMS RUP applied!</div><br><br>');
						:w5:=:w5+1;
						issuep:=TRUE;
					else
						l_o('<img class="check_ico">OK! You performed hrglobal after HRMS RUP.<br><br>');
					end if;
					
					select  max( last_update_date) into v_action  from hr_legislation_installations  where (status is not null or action is not null) ;
					l_o('Last time performed DataInstal on ' || v_action   ||'<br><br>' );
					if v_hrglobal_date<v_action then
						l_o('<div class="divwarn">');
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You did not performed hrglobal after running DataInstall!</div><br><br>');
						:w5:=:w5+1;
						issuep:=TRUE;
					else
						l_o('<img class="check_ico">OK! You performed hrglobal after running DataInstall.<br><br>');
					end if;
				end if;
				
                l_o(' To identify the version please run: strings -a $PER_TOP/patch/115/driver/hrglobal.drv | grep Header </span><br><br>');
                l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Please periodically review (note periodically updated): ');
				if   :apps_rel like '12.2%' then
					l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1469456.1" target="_blank"> Note 1469456.1</a> ');
					l_o('DATAINSTALL AND HRGLOBAL APPLICATION: 12.2 SPECIFICS<br>'); 
				else
					l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=145837.1" target="_blank"> Note 145837.1</a> ');
					l_o('Latest Oracle HRMS Legislative Data Patch Available (HR Global / hrglobal)<br>');
				end if;
				l_o('</span>');
				
				l_o('<br><br>List of applied patches after latest HRMS RUP:<br>');
				for ex_rec in get_patches(:v_rup_date) loop
				l_o(ex_rec.PATCH_TYPE || '  '|| ex_rec.PATCH_NAME|| ' applied on '|| to_char(ex_rec.ld,'DD-MON-RR')||'<br>');
				end loop;
				l_o('<br>');
      end if;

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display Data Installed issues
procedure DataInstalled is

    v_exists number;
    v_leg_code varchar2(7);
    v_apps hr_legislation_installations.application_short_name%type;
    v_action hr_legislation_installations.action%type;
    cursor datainstaller_actions is
          select decode(hli.legislation_code
                   ,null,'global'
                   ,hli.legislation_code) 
           , hli.application_short_name                  
           , hli.action                                 
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name
      order by legislation_code desc, application_short_name asc;

begin      
      
      select count(1) into v_exists
      from user_views uv
         , hr_legislation_installations hli
      where uv.view_name in (select view_name from hr_legislation_installations)
      and uv.view_name = hli.view_name;
      
      if v_exists>0 then
                                  								  
								  l_o('<br><A class=detail onclick="displayItem(this,''s1sql36'');" href="javascript:;"><font size="+0.5">&#9654; DataInstaller Actions</font></A>');
                                  l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql36" style="display:none" >');
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
                                  l_o('     <B>DataInstaller actions:</B></font></TD>');
                                  l_o('     <TD bordercolor="#DEE6EF">');
                                  l_o('<A class=detail  id="s1sql37b"  onclick="displayItem2(this,''s1sql37'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  l_o('   </TD>');
                                  l_o(' </TR>');
                                  l_o(' <TR id="s1sql37" style="display:none">');
                                  l_o('    <TD colspan="4" height="60">');
                                  l_o('       <blockquote><p align="left">');
                                  l_o('          select decode(hli.legislation_code <br>');   
                                  l_o('                   ,null,''global''<br>');
                                  l_o('                   ,hli.legislation_code) <br>');           
                                  l_o('           , hli.application_short_name <br>');   
                                  l_o('           , hli.action<br>');                  
                                  l_o('      from user_views uv<br>');
                                  l_o('         , hr_legislation_installations hli<br>');
                                  l_o('      where uv.view_name in (select view_name from hr_legislation_installations)<br>');
                                  l_o('      and uv.view_name = hli.view_name<br>');
                                  l_o('      order by legislation_code desc, application_short_name asc;<br>');
                                  l_o('          </blockquote><br>');
                                  l_o('     </TD>');
                                  l_o('   </TR>');
                                  l_o(' <TR>');
                                  l_o(' <TH><B>Legislation Code</B></TD>');
                                  l_o(' <TH><B>Application Name</B></TD>');
                                  l_o(' <TH><B>Action</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open datainstaller_actions;
                                  loop
                                        fetch datainstaller_actions into  v_leg_code,v_apps ,v_action;
                                        EXIT WHEN  datainstaller_actions%NOTFOUND;
                                        l_o('<TR><TD>'||v_leg_code||'</TD>'||chr(10)||'<TD>'||v_apps||'</TD>'||chr(10)||'<TD>'||v_action||'</TD></TR>'||chr(10));
                                  end loop;
                                  close datainstaller_actions;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
                                  l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  l_o(' </TABLE> ');
                                  
								  l_o('<div class="diverr">');
								  l_o('<img class="error_ico"><font color="red">Error:</font> You have legislations currently selected for install by the DataInstall.');
                                  l_o(' Please resolve hrglobal issues ');
								  l_o('in order to install/upgrade all legislative data selected during DataInstaller.<br>');
                                  l_o('Please review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=140511.1" target="_blank" >Note 140511.1</a> ');
								  l_o('How to Install HRMS Legislative Data Using Data Installer and hrglobal.drv</div><br><br>');
								  issuep:=TRUE;
								  :e5:=:e5+1;
         end if;                                      
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display Statutory Exceptions
procedure Statutory is

    cursor statutory is
    select table_name
           , surrogate_id 
           , true_key
           , exception_text
      from hr_stu_exceptions;
    v_table_name hr_stu_exceptions.table_name%type;
    v_surrogate_id hr_stu_exceptions.surrogate_id%type;
    v_true_key hr_stu_exceptions.true_key%type;
    v_exception_text hr_stu_exceptions.exception_text%type;
    v_exists number;
    
begin    
      select count(1) into v_exists
					  from hr_stu_exceptions;        
     
      if v_exists>0 then
                                
								 
								 l_o('<A class=detail onclick="displayItem(this,''s1sql38'');" href="javascript:;"><font size="+0.5">&#9654; Statutory Exceptions</font></A>');
                                 
                                  l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql38" style="display:none" >');
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
                                  l_o('     <B>Statutory exceptions:</B></font></TD>');
                                  l_o('     <TD bordercolor="#DEE6EF">');
                                  l_o('<A class=detail  id="s1sql39b"  onclick="displayItem2(this,''s1sql39'');" href="javascript:;">&#9654; Show SQL Script</A>');
                                  l_o('   </TD>');
                                  l_o(' </TR>');
                                  l_o(' <TR id="s1sql39" style="display:none">');
                                  l_o('    <TD colspan="4" height="60">');
                                  l_o('       <blockquote><p align="left">');
                                  l_o('          select table_name <br>');                                     
                                  l_o('           , to_char(surrogate_id) surrogate_id<br>'); 
                                  l_o('           , true_key<br>'); 
                                  l_o('           , exception_text<br>'); 
                                  l_o('            from hr_stu_exceptions;<br>'); 
                                  l_o('          </blockquote><br>');
                                  l_o('     </TD>');
                                  l_o('   </TR>');
                                  l_o(' <TR>');
                                  l_o(' <TH><B>Table name</B></TD>');
                                  l_o(' <TH><B>Surrogate ID</B></TD>');
                                  l_o(' <TH><B>True key</B></TD>');
                                  l_o(' <TH><B>Exception</B></TD>');
	
                                  :n := dbms_utility.get_time;
                              
                                  open statutory;
                                  loop
                                        fetch statutory into  v_table_name , v_surrogate_id , v_true_key , v_exception_text;
                                        EXIT WHEN  statutory%NOTFOUND;
                                        l_o('<TR><TD>'||v_table_name||'</TD>'||chr(10)||'<TD>'||v_surrogate_id||'</TD>'||chr(10)||'<TD>');
										l_o(v_true_key||'</TD>'||chr(10)||'<TD>');
                                        l_o(v_exception_text);
                                        l_o('</TD></TR>'||chr(10));
                                  end loop;
                                  close statutory;
                                  
                                  
                                  :n := (dbms_utility.get_time - :n)/100;
                                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                                  l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
                                  l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                                  l_o(' </TABLE> ');
                                  
								  l_o('<div class="diverr">');
								  l_o('<img class="error_ico"><font color="red">Error:</font> You have statutory exceptions. ');
                                  l_o('In order to solve please review:<br>');
                                  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=101351.1" target="_blank" >Note 101351.11</a> ');
								  l_o('HRGLOBAL.DRV:DIAGNOSING PROBLEMS WITH LEGISLATIVE UPDATES - HR_LEGISLATION.INSTALL</div>');
								  issuep:=TRUE;
								  :e5:=:e5+1;
                                  
                                 
         end if;  

     
      
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');       
end;


-- Display geocode patching level
procedure geocode is
  run_type varchar2(20):='&1';
  v_exists number:=0;
  v_patch_date ad_bugs.LAST_UPDATE_DATE%type;
  v_status varchar2(100);
  v_last_date date;
  v_geocode_date date;
  patch varchar2(20);
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin
    
     select count(1) 
     into v_exists
      from hr_legislation_installations
     where (Legislation_code = 'US' or Legislation_code = 'CA') and status='I';
     
     if v_exists>0 then
                v_exists:=0;
                if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
                      SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='21276246' ;
                      patch:='21276246';
                elsif :apps_rel like '12.0%' then
					select count(1) into v_exists from ad_bugs where bug_number='19139617';
                      patch:='19139617';
				elsif :apps_rel like '11.5%' then
                      select count(1) into v_exists from ad_bugs where bug_number='21276241';
                      patch:='21276241';
                end if;
                
                if (v_exists=0) then             
                         issue1:=TRUE;
                else
                          select LAST_UPDATE_DATE  
                          into v_patch_date
                          FROM ad_bugs 
                          where bug_number=patch and rownum < 2;
                          
                          select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%';
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GEOCODE UPGRADE MANAGER%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),upper('Completed Normal'))=0 then								 
                                      issue3:=TRUE;
                                  else
                                         if v_last_date<v_patch_date then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
							
							SELECT count(1) into v_exists
							FROM pay_patch_status
							WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
							AND status        = 'C';
							
							if v_exists=0 then
								issue5:=TRUE;
							else
								SELECT max(applied_date) into v_geocode_date
								FROM pay_patch_status
								WHERE patch_name LIKE 'GEOCODE_ANNUAL_2015%'
								AND status        = 'C';
							end if;
							
              end if;
              
               
              
              if upper(run_type)='ALL' or issue1 or issue2 or issue3 or issue4 or issue5 then 
                        l_o(' <br><br><a name="geocode"></a><b>Geocode</b><br>');
                        
                        if issue1 then
                                :w5:=:w5+1;
								if (:pay_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										elsif :apps_rel like '12.0%' then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><font color="#CC3311">Warning: </font>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ANNUAL GEOCODE UPDATE - 2014<br>');
										elsif :apps_rel like '11.5%' then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015<br>');
										end if;	
										l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Ensure you perform Geocode Upgrade Manager process after the patch.</div><br>');
								elsif (:pay_status='Shared') and (:hr_status='Installed') then
										if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276246">Patch 21276246</a> ANNUAL GEOCODE UPDATE - 2015</div><br>');
										elsif :apps_rel like '12.0%' then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><font color="#CC3311">Warning: </font>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=19139617">Patch 19139617</a> ');
											l_o('ANNUAL GEOCODE UPDATE - 2014</div><br>');
										elsif :apps_rel like '11.5%' then
											l_o('<div class="divwarn">');
											l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are using address validation please install latest geocode <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=21276241">Patch 21276241</a> ANNUAL GEOCODE UPDATE - 2015</div><br>');
										end if;
										l_o('<div class="divwarn">');
										l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records ensure you perform Geocode Upgrade Manager process after the patch.<br>');
										l_o('Review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=745638.1" target="_blank">Note 745638.1</a> ');
										l_o('Requirements for Address Validation with HR Only Installation</div><br>');
								end if;									
                        else
							l_o('<span class="sectionb">Patch '||patch||' Oracle US and Canada Payroll Annual Geocode applied on '||v_patch_date||'</span><br>');
                        end if;
                        
                        if issue2 then
                            :w5:=:w5+1;
							if (:pay_status='Installed') then
								l_o('<div class="divwarn">');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>You never performed Geocode Upgrade Manager process!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								l_o('<div class="divwarn">');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records be aware you never performed Geocode Upgrade Manager process!</div><br>');
							end if;
                        end if;
                        
                        if issue3 then
                            :w5:=:w5+1;
							if (:pay_status='Installed') then
								l_o('<div class="divwarn">');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Your last run of Geocode Upgrade Manager process is not Completed Normal. Please review!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								l_o('<div class="divwarn">');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Geocode Upgrade Manager process performed on '||v_last_date||' with status ' ||v_status||'<br>');								
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records be aware your last run of Geocode Upgrade Manager process completed in error. Please review!</div><br>');
							end if;
                        end if;
                        if issue4 then
                            :w5:=:w5+1;
							if (:pay_status='Installed') then
								l_o('<span class="sectionb">Geocode Upgrade Manager process Completed Normal on '||v_last_date||'</span><br>');
								l_o('<div class="divwarn">');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>You did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then
								l_o('<span class="sectionb">Geocode Upgrade Manager process Completed Normal on '||v_last_date||'</span><br>');
								l_o('<div class="divwarn">');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records be aware you did not performed Geocode Upgrade Manager process after the Geocode patch!</div><br>');
							end if;
                        end if;
                        if (:apps_rel not like '12.0%') then
						if issue5  then
                            :w5:=:w5+1;
							if (:pay_status='Installed') then								
								l_o('<div class="divwarn">');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>GEOCODE_ANNUAL_2015 information not applied!</div><br>');
							elsif (:pay_status='Shared') and (:hr_status='Installed') then								
								l_o('<div class="divwarn">');
								l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>If you are maintaining tax records be aware GEOCODE_ANNUAL_2015 information are not applied!</div><br>');
							end if;
                        elsif not issue1 then
							l_o('<span class="sectionb">GEOCODE_ANNUAL_2015 information applied on '||v_geocode_date||'</span><br>');
                        end if;
						end if;
						
						
						if not issue1 and not issue2 and not issue3 and not issue4 then
							l_o('<span class="sectionb">Geocode Upgrade Manager process Completed Normal on '||v_last_date||'</span><br>');
						end if;
						
                        if issue1 or issue2 or issue3 or issue4 or (issue5 and :apps_rel not like '12.0%') then
                                issuep:=TRUE;
								l_o('<div class="divwarn">');
								if :apps_rel like '12.2%' then
                                    l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=2038283.1" target="_blank">Note 2038283.1</a> ');
                                    l_o('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.2.x');
								elsif :apps_rel like '12.1%' then
                                    l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=2038282.1" target="_blank">Note 2038282.1</a> ');
                                    l_o('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 12.1.x');
                                elsif :apps_rel like '12.0%' then
                                    l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1912683.1" target="_blank">Note 1912683.1</a> ');
                                    l_o('Oracle US and Canada Payroll - 2014 Annual Geocode Readme - Release 12.0.x');
                                else
                                    l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=2038281.1" target="_blank">Note 2038281.1</a> ');
                                    l_o('Oracle US and Canada Payroll - 2015 Annual Geocode Readme - Release 11i');
                                end if;
                                l_o('</div>');         
						else
                                if upper(run_type)='ALL' then
                                        l_o('<span class="sectionb"><img class="check_ico">OK! All checks are <img class="check_ico">OK!</span><br>');	
                                end if;
                        end if;
						
               end if;         
       end if; 
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display Quantum level
procedure Quantum is
  run_type varchar2(20):='&1';
  v_exists number:=0;
  v_status varchar2(100);
  v_last_date date;
  patch varchar2(20);
  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type;	
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  
begin
if (:pay_status='Installed') then    
     select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  (Legislation_code = 'US' or Legislation_code = 'CA') and status='I';
     
     if v_exists>0 then
                select count(1) into v_exists
                from ad_applied_patches ap
                   , ad_patch_drivers pd
                   , ad_patch_runs pr
                   , ad_patch_run_bugs prb
                   , ad_patch_run_bug_actions prba
                   , ad_files f
                where f.file_id                  = prba.file_id
                  and prba.executed_flag         = 'Y'
                  and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                  and prb.patch_run_id           = pr.patch_run_id
                  and pr.patch_driver_id         = pd.patch_driver_id
                  and pd.applied_patch_id        = ap.applied_patch_id
                  and f.filename = 'pyvendor.zip'
                  and pr.end_date = (select max(pr.end_date)
                                             from ad_applied_patches ap
                                                , ad_patch_drivers pd
                                                , ad_patch_runs pr
                                                , ad_patch_run_bugs prb
                                                , ad_patch_run_bug_actions prba
                                                , ad_files f
                                              where f.file_id                  = prba.file_id
                                                and prba.executed_flag         = 'Y'
                                                and prba.patch_run_bug_id      = prb.patch_run_bug_id  
                                                and prb.patch_run_id           = pr.patch_run_id
                                                and pr.patch_driver_id         = pd.patch_driver_id
                                                and pd.applied_patch_id        = ap.applied_patch_id
                                                and f.filename = 'pyvendor.zip');      

                
                if (v_exists=0) then             
                         issue1:=TRUE;
                else
                            if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
								SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='21911111' ;
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='21911111' and rownum < 2;
								end if;		
							elsif :apps_rel like '12.0%' then
								SELECT count(1) into v_exists FROM ad_bugs adb WHERE adb.bug_number ='19701971' ;
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='19701971' and rownum < 2;
								end if;						  
						   elsif :apps_rel like '11.5%'	then
								select count(1) into v_exists from ad_bugs where bug_number='21911110';
								if v_exists=0 then
									issue5:=TRUE;
								else
									select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='21911110' and rownum < 2;
								end if;
						   end if;						
						   select count(1) into v_exists
                            FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%' ;
                            
                            if v_exists=0 then
                                issue2:=TRUE;
                            else
                                  SELECT * 
                                  into v_status, v_last_date
                                  FROM (
                                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                                 ,ACTUAL_COMPLETION_DATE pEndDate        
                                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'QUANTUM DATA UPDATE INSTAL%'
                                  ORDER BY 2 desc)
                                  where rownum < 2;
                            
                                  if instr(upper(v_status),'ERROR')<>0 then 
                                      issue3:=TRUE;
                                  else
                                         if SYSDATE-v_last_date>30 then
                                                issue4:=TRUE;
                                          end if;
                                  end if;
                            end if;
              end if;
              
               
              
              if upper(run_type)='ALL' or issue1 or issue2 or issue3 or issue4 or issue5 then 
                        l_o(' <br><br><a name="quantum"></a><b>Quantum</b><br>');
                        if issue2 or issue4 then
							l_o('<div class="divwarn">');
							if issue2 then
										  l_o('Never performed Quantum Data Update Installer! ');
										  l_o('Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this issue. Please verify with System Administrator.<br>');
										  :w5:=:w5+1;
							end if;
							if issue4 then
										  l_o('Your last run of Quantum Data Update Installer was on ');
										  l_o(v_last_date||' more than 30 days ago. Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this error. Please verify with System Administrator.<br>');
										  :w5:=:w5+1;										  
							end if;
							l_o('</div>');
						end if;
						if issue1 or issue3 or issue5 then
								l_o('<div class="diverr">');
								if issue5 then
										 l_o('<img class="error_ico"><font color="red">Error: </font>You don''t have the patch that delivers latest Quantum version.<br>');
										  l_o('Please install <a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=');
										  if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
											l_o('21911111">Patch 21911111</a><br>');
										  elsif :apps_rel like '12.0%'  then
											l_o('19701971">Patch 19701971</a><br>');										 
										  elsif :apps_rel like '11.5%' then
										     l_o('21911110">Patch 21911110</a><br>');
										  end if;
										  :e5:=:e5+1;
								end if;
								if issue1 then
										  l_o('<img class="error_ico"><font color="red">Error: </font>No Quantum patch applied!<br>');
										  l_o('Ensure you also perform Quantum Data Update Installer.<br>');
										  :e5:=:e5+1;
								end if;				
								
								if issue3 then
										  l_o('<img class="error_ico"><font color="red">Error: </font>Your last run of Quantum Data Update Installer process completed in error. <br>');
										  l_o('Note! If you update Vertex manually using cbmaint and vprtmupd, you can ignore this error. Please verify with System Administrator.<br>');
										  :e5:=:e5+1;
								end if;
								                                               
                                issuep:=TRUE;
								l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                                l_o('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations<br>');
								l_o('</div>');
                        end if;
				
                        l_o('<span class="sectionb">');
						if not issue1 and not issue5 then
							if (:apps_rel like '12.1%') or (:apps_rel like '12.2%') then
								l_o('Patch 21911111 applied on '||v_patch_date||'<br>');
							elsif :apps_rel like '12.0%' then
								l_o('Patch 19701971 applied on '||v_patch_date||'<br>');
							elsif :apps_rel like '11.5%' then
								l_o('Patch 21911110 applied on '||v_patch_date||'<br>');
							end if;
						end if;
						if not issue1 and not issue2 and not issue3 and not issue4 then
							l_o('Your last run of Quantum Data Update Installer was on '||v_last_date||'<br>');                                                           
                        end if;
						l_o('</span><br>'); 
                        
                        l_o('<span class="sectionblue1">Advice: </span><span class="sectionb">Please periodically review: ');
						l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=224273.1" target="_blank">Note 224273.1</a> ');
                        l_o('Oracle Human Resources (HRMS) Payroll - Installing Vertex Quantum for US and Canada Legislations</span><br>');
                        
               end if;         
       end if; 
end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');      
end;

-- Display JIT patching
procedure jit is
  run_type varchar2(20):='&1';
  v_exists number:=0;
  patch varchar2(20); 
-- Display patch
	procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch;
					end if;
						if (v_exists=0) then  
								 l_o('<div class="diverr">');
								 l_o('<img class="error_ico"><font color="red">Error: </font> Please plan to install ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> ');
								 l_o(v_name||'<br></div>');
								:e5:=:e5+1;								 
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch and rownum < 2;
							l_o('<span class="sectionb"><img class="check_ico">OK! Patch '||v_patch||' ' || v_name);
							l_o(' applied on '||v_patch_date||'</span><br>');
							
						end if;
	end;     
begin
    
    select count(1) 
     into v_exists
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'US'  and status='I';
     
     if v_exists>0 then
			l_o('<br><br><a name="jit"></a><b>JIT</b><br>');			
				if (:apps_rel like '12.2%') then
							dpatch('21664392','Q3 2015 SQWL and JIT STATUTORY UPDATE');
						elsif (:apps_rel like '12.1%') then
							dpatch('21664392','Q3 2015 SQWL and JIT STATUTORY UPDATE');
						elsif (:apps_rel like '12.0%') then		
							dpatch('19507770','Q3 2014 Statutory and JIT Update');
						elsif :apps_rel like '11.5%' then					
							dpatch('21664379','Q3 2015 SQWL and JIT STATUTORY UPDATE'); 
				end if;
			            
    end if;   
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display baseline patching status
procedure baseline is
  v_status varchar2(5);
  no_rows number;
  v_exists number;
  issue boolean:=FALSE;
  -- Display patch
	procedure dpatch (v_patch varchar2, v_name varchar2) is
	  v_patch_date   ad_bugs.LAST_UPDATE_DATE%type := null;	  
	begin		
					if :apps_rel like '12.2%' then
						SELECT count(1) into v_exists FROM ad_bugs adb	WHERE adb.bug_number = v_patch	;
					else
						select count(1) into v_exists from ad_bugs where bug_number=v_patch;
					end if;
						if (v_exists=0) then             
								 issue:=TRUE;
								 l_o('<div class="divwarn">');
								 l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Please plan to install ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num='||v_patch||'">Patch '||v_patch||'</a> '||v_name||'<br>');	
								 l_o('</div>');
								 :w5:=:w5+1;
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number=v_patch and rownum < 2;
							l_o('<span class="sectionb">Patch '||v_patch||' ' || v_name||' applied on '||v_patch_date||'</span><br>');
							
						end if;
	end; 

begin
    
    if :apps_rel like '11.5%' or :apps_rel like '12.0%' then
		l_o(' <br><br><b>Baseline patches</b><br>');
		if :apps_rel like '11.5%' then		  
          dpatch('5903765','11i.ATG_PF.H.delta.6');
          select count(1) into no_rows from fnd_product_installations where application_id=203;
		  if no_rows=1 then
				  select status into v_status from fnd_product_installations where application_id=203;
				  if v_status='I' then						
						dpatch('4428060',' - baseline patch for AME');
				  end if;
          end if;
		  select status into v_status from fnd_product_installations where application_id=453;
          if v_status='I' then                
				dpatch('4001448',' - baseline patch for HRI');
          end if; 
		  dpatch('6699770',' - baseline patch for PER, BEN, PSP, IRC, Self Service');          
          select status into v_status from fnd_product_installations where application_id=810;
          if v_status='I' then
                dpatch('7446888',' - baseline patch for OTA');				
          end if; 
          select count(1) into no_rows from fnd_product_installations where status='I' and application_id in (801, 8301) ;
          if no_rows>0 then
                dpatch('7666111',' - baseline patch for PAY, GHR');				
          end if; 
          select status into v_status from fnd_product_installations where application_id=808;
          if v_status='I' then
                dpatch('7226660','  - baseline patch for HXT');				
          end if; 
		  
          if issue then
			  l_o('<div class="divwarn">');
			  l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>You have baseline patches missing.</div><br>');
		  else
			  l_o('<span class="sectionb">HCM Product Level Requirements applied.</span><br>');
		  end if;
              l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Please review ');
              l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1199724.1" target="_blank">Note 1199724.1</a> ');
			  l_o('- E-Business Suite 11.5.10 Minimum Patch Level and Extended Support Information Center</span><br>');
          
		elsif :apps_rel like '12.0%' then
			  dpatch('7004477','R12.HR_PF.A.delta.6 (Minimum baseline)');
			  dpatch('9301208','R12.HR_PF.A.delta.8 (Minimum baseline for those customers whose legislation tax year end / tax year begin schedule must be applied as a prerequisite before processing the legislative Year End (Note 135266.1))');
			  if issue then
					l_o('<div class="divwarn">');
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>You have baseline patches missing.</div><br>');
			  else
				  l_o('<span class="sectionb">HCM Product Level Requirements applied.</span><br>');
			  end if;
			  l_o('<span class="sectionblue1">Advice:</span><span class="sectionb"> Please review ');
              l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1334562.1" target="_blank">Note 1334562.1</a> ');
			  l_o('- Minimum Patch Requirements for Extended Support of Oracle E-Business Suite Human Capital Management (HCM) Release 12.0</span><br>');
		end if;
		if issue then
			  issuep:=TRUE;
		end if;
	
	end if;    
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;

-- Display Organization Chart Feature patch
procedure org_chart is  
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_exists number;
  v_patch_date ad_bugs.LAST_UPDATE_DATE%type;
begin
    if upper(product) in ('SSHR','ALL') and :apps_rel like '12.1%' then
		select count(1) into v_exists from ad_bugs where bug_number='13691576';
			if upper(run_type)='ALL' or v_exists=0 then
					l_o(' <TR><td><a name="org"></a><b>Organization Chart Feature</b></td><td>');		
						if (v_exists=0) then
								 l_o('<div class="divwarn">');
								 l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Not installed ');
								 l_o('<a href="https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=13691576">Patch 13691576</a> Organization Chart in Oracle SSHR<br>');	
								 l_o('Please ignore this warning if you are not using Organization Chart Feature as per ');
								 l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1408355.1" target="_blank">Note 1408355.1</a> Using the Organization Chart Feature in Oracle SSHR');
								 l_o('</div>');
								 :w5:=:w5+1;
						else
							select LAST_UPDATE_DATE  into v_patch_date FROM ad_bugs where bug_number='13691576' and rownum < 2;
							l_o('<span class="sectionb">Patch 13691576 Organization Chart in Oracle SSHR applied on '||v_patch_date||'</span><br>');							
						end if;
					l_o(' </td></tr>');
			end if;
	end if;
end;
	
-- Display performance patches advices
procedure performance is    
begin   
	l_o(' <TR><td><a name="perf"></a><b>Performance</b></td><td>');
    l_o('<span class="sectionblue1">Advice: </span><span class="sectionb"> For performance patches please periodically review: ');
    l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=244040.1" target="_blank">Note 244040.1</a> - Oracle E-Business Suite Recommended Performance Patches</span><br>');
	l_o('<DIV align="center"><A class=detail onclick="displayItem(this,''s1sql45'');" href="javascript:;">&#9654; How to check database patches</A></DIV>');    
    l_o(' <TABLE align="center" border="1" cellspacing="0" cellpadding="2" id="s1sql45" style="display:none" >');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o('   <TH align="left" COLSPAN=4 bordercolor="#DEE6EF">');
    l_o(' <blockquote>-	cd RDBMS_ORACLE_HOME<br>');
    l_o('-	. ./SID_hostname.env<br>');
    l_o('-	export PATH=$ORACLE_HOME/OPatch:$PATH<br>');
    l_o('-	opatch lsinventory<br>');
    l_o('-	Compare results with the patches from ');
	l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=244040.1" target="_blank">Note 244040.1</a> - Oracle E-Business Suite Recommended Performance Patches<br>');
	l_o('</blockquote>');
    l_o(' </TD><TR></TABLE>'); 
                                  
    
   l_o('</td></tr>');
   
  l_o(' </TABLE>  ');
  
  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br></div>');
  
  
end;


-- First main program (it is split in 2 because of "program too long" issue)
begin
declare
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';
	v_rows number;
  
begin  
  :g_curr_loc:=1;
  Show_Header('9999999.999', '&v_scriptlongname', '&v_headerinfo', '&v_queries_ver');
  
  :e1:=0;
  :e2:=0;
  :e3:=0;
  :e4:=0;
  :e5:=0;
  :e6:=0;
  :e7:=0;
  :w1:=0;
  :w2:=0;
  :w3:=0;
  :w4:=0;
  :w5:=0;
  :w6:=0;
  :w7:=0;
  
  select upper(instance_name), host_name into :sid, :host 
  from   v$instance;
  SELECT RELEASE_NAME into :apps_rel from FND_PRODUCT_GROUPS; 
  select to_char(sysdate, 'Dy Month DD, YYYY hh24:mi:ss') into v_date from dual;  

  l_o('<table width="100%" class="graph"><tbody><tr class="top"><td width="33%">');
  l_o('<A class=detail onclick="displayItem(this,''s1sql91'');" href="javascript:;">&#9654; Execution Details</A>') ; 
  l_o('<TABLE style="DISPLAY: none" id=s1sql91><TBODY>');
  l_o('<TR><TH>Host:</TH>');
  l_o('<TD>'||:host||'</TD></TR>');
  l_o('<TR><TH>Instance: </TH>');
  l_o('<TD>'||:sid||'</TD></TR>');
  l_o('<TR><TH>Applications Version: </TH>');
  l_o('<TD>'||:apps_rel||'</TD></TR>');
  l_o('<TR><TH>Execution Date: </TH>');
  l_o('<TD>'||v_date||'</TD></TR>');
  l_o('<TR><TH>Analyzer version: </TH>');
  l_o('<TD>200.48</TD></TR>');
  l_o('</TBODY></TABLE></td>');
  l_o('<td width="33%"><A class=detail onclick="displayItem(this,''s1sql92'');" href="javascript:;">&#9654; Parameters</A>');
  l_o('<TABLE style="DISPLAY: none" id=s1sql92 >');
  l_o('<TBODY><TR>');
  l_o('<TH>Run Type</TH>');
  l_o('<TD>');
  if upper(run_type)='ISSUES' then
          l_o('ISSUES: Health Check (only issues and advices) ');
  else
          if upper(run_type)='ALL' then
                 l_o('ALL: Data Collector (all informations and advices) ');
          else
                l_o('<span class="sectionred"> <b>Incorrect run type option. Correct values: ALL, ISSUES</b></span>');
          end if;
  end if;
  l_o('</TD></TR>');
  l_o('<TR>');
  l_o('<TH>Product</TH>');
  l_o('<TD>');


  case upper(product)
    when 'PAY' then
          l_o('Pay: Payroll');
    when 'HR' then 
          l_o('HR: Human Resources');
    when 'BEN' then
          l_o('BEN: Benefits');
    when 'OTA' then
          l_o('OTA: Learning Management');
	when 'OTL' then
          l_o('OTL: Time and Labor');
    when 'SSHR' then
		  l_o('SSHR: Self Service Human Resources');
	when 'IRC' then
		  l_o('IRC: iRecruitment');
	when 'ALL' then
          l_o('ALL: All HCM products');
    else
          l_o('<span class="sectionred"> Incorrect product option. Correct values: BEN, HR, IRC, OTL, OTA, PAY, SSHR, ALL</span>');
  end case;  
    l_o('</TD></TR></TBODY></TABLE></td>');
	
	l_o('<td width="33%"><div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>');
    l_o('<div id="ExecutionSummary2" style="display:none"></div>');
    l_o('</td></tr></table>');

   l_o('</div><br>');
	l_o('<div class="divItem" id="toccontent">');
	l_o('<div class="divItemTitle">Sections In This Report</div></div>');
    l_o('<div align="center">');
	l_o('<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> / ');
	l_o('<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a></div>');
	l_o('</div><br>');

	l_o('<div id="tabCtrl">');
    l_o('<div id="page1" style="display: block;">');

	l_o('<a name="overview"></a>');
	l_o('<div class="divSection">');
	l_o('<div class="divSectionTitle">');
	l_o('<div class="left"  id="overview" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Instance Overview:'); 
	l_o('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    l_o('<a class="detail" onclick="openall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    l_o('</div><div class="clear"></div></div><br>');
	   
	l_o('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	l_o('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	l_o('<a class=detail2 href="#sum">Instance Summary</a> <br>');
	  l_o('<a class=detail2 href="#db">Database Details</a> <br>');
	  l_o('<a class=detail2 href="#apps">Application Details</a> <br></td><td class="toctable">');
	  if upper(run_type)='ALL' then
			l_o('<a class=detail2 href="#products">Products Status</a> <br>');
			l_o('<a class=detail2 href="#legislations">Legislations Installed</a> <br>');
	  end if;
	  select count(1) into v_rows from FND_LANGUAGES 
		  where INSTALLED_FLAG in ('B','I') ;
	  if v_rows>1 or upper(run_type)='ALL'  then
			 l_o('<a class=detail2 href="#nls">Languages Installed</a> <br>');
	  end if;
	l_o('</td></tr></table></div><br>');

	overview();
	product_status();
	legislations();
	nls();
	l_o('</div></div>');
	l_o('<div id="page2" style="display: none;">');
	l_o('<a name="rup"></a><a name="patching"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">');
	l_o('<div class="left"  id="patching" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Patching: '); 
	l_o('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    l_o('<a class="detail" onclick="openall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    l_o('</div><div class="clear"></div></div><br>');
	

      l_o('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	  l_o('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	  l_o('<a class=detail2 href="#rup">HRMS RUP and hrglobal</a> <br>');	  
      l_o('<a class=detail2 href="#mandatory">Mandatory Patches</a> <br>');
	  if upper(product) in ('OTL','ALL') then
			l_o('<a class=detail2 href="#projects">Projects</a> <br>');
	  end if;
	  l_o('<a class=detail2 href="#atg">ATG</a> <br></td><td class="toctable">');      
      l_o('<a class=detail2 href="#geocode">Geocode</a> <br>');
	  l_o('<a class=detail2 href="#quantum">Quantum</a> <br>');
      l_o('<a class=detail2 href="#jit">JIT</a> <br>');
	  if upper(product) in ('SSHR','ALL') then
			l_o('<a class=detail2 href="#org">Organization Chart Feature</a> <br>');
	  end if;
      l_o('<a class=detail2 href="#perf">Performance patches</a> <br>');      
      l_o('</td></tr></table>');
	l_o('</div><br>');

	rup();
	hrglobal();
	DataInstalled();
	Statutory();	
	mandatory();
	baseline();
	projects();
	atg();	
	geocode();
	Quantum();
	jit();	
	org_chart();
	performance();	
	l_o('</div></div>');
	

	
	
	l_o('<!-');

EXCEPTION

when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
	
	
end;	
end;
/

-- Print CLOB
print :g_hold_output


variable g_hold_output2 clob;
variable g_curr_loc2 number;
declare
   counter      number       := 0;
   failures     number       := 0;   

/* Global defaults for SQL output formatting */
   g_sql_date_format   varchar2(100) := 'DD-MON-YYYY HH24:MI';

/* Global variables set by Set_Client which can be used throughout a script */
   g_user_id      number;
   g_resp_id      number;
   g_appl_id      number;
   g_org_id       number;

/* Global variable set by Set_Client or Get_DB_Apps_Version which can
   be referenced in scripts which branch based on applications release */

   g_appl_version varchar2(10);

   type V2T is table of varchar2(32767);
   

-- Write html format
procedure l_o (text varchar2) is
   l_ptext      varchar2(32767);
   l_hold_num   number;
   l_ptext2      varchar2(32767);
   l_hold_num2   number;
begin
   l_hold_num := mod(:g_curr_loc2, 32767);
   
   l_hold_num2 := mod(:g_curr_loc2, 14336);
   if l_hold_num2 + length(text) > 14000 then
      l_ptext2 := '                                                                                                                                                                                                    ';
      dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc2, l_ptext2);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext2);
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc2, l_ptext2);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext2);
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc2, l_ptext2);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext2);
	  
   end if;
   
   l_hold_num2 := mod(:g_curr_loc2, 18204);
   if l_hold_num2 + length(text) > 17900 then
      l_ptext2 := '                                                                                                                                                                                              ';
      dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc2, l_ptext2);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext2);
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc2, l_ptext2);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext2);	 
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc2, l_ptext2);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext2);
	  dbms_lob.write(:g_hold_output2, length(l_ptext2), :g_curr_loc2, l_ptext2);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext2);	
   end if;
   
   if l_hold_num + length(text) > 32759 then
      l_ptext := '<!--' || rpad('*', 32761-l_hold_num,'*') || '-->';
      dbms_lob.write(:g_hold_output2, length(l_ptext), :g_curr_loc2, l_ptext);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext);
	  dbms_lob.write(:g_hold_output2, length(l_ptext), :g_curr_loc2, l_ptext);
      :g_curr_loc2 := :g_curr_loc2 + length(l_ptext);
   end if;
   dbms_lob.write(:g_hold_output2, length(text)+1, :g_curr_loc2, text || chr(10));
   :g_curr_loc2 := :g_curr_loc2 + length(text)+1;
   
   --dbms_lob.write(:g_hold_output2, length(text), g_curr_loc2, text );
   --g_curr_loc2 := g_curr_loc2 + length(text);
   
end l_o;

-- Display HR profiles settings
procedure profiles is
	  run_type varchar2(20):='&1';
	  product varchar2(20):='&2';
	  v_name fnd_profile_options_tl.user_profile_option_name%type; 
	  v_short_name fnd_profile_options.profile_option_name%type;
	  v_short_name_old fnd_profile_options.profile_option_name%type;
	  v_level varchar2(50);
	  v_level_old varchar2(50);
	  v_context varchar2(300);
	  v_value fnd_profile_option_values.profile_option_value%type;
	  v_id fnd_profile_options.PROFILE_OPTION_ID%type; 
	  v_big_no number :=1;
	  v_big_no2 number :=1;
	
		cursor big_profiles  is
		select n.user_profile_option_name,
		  po.profile_option_name ,
		   decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
		(
				'PER_SECURITY_PROFILE_ID',
				'PER_BUSINESS_GROUP_ID',
				'HR_CROSS_BUSINESS_GROUP',
				'HR_USER_TYPE',
				'ORG_ID',		
				'HR_LOCAL_OR_GLOBAL_NAME_FORMAT',
				'PER_NATIONAL_IDENTIFIER_VALIDATION',
				'PER_USE_TITLE_IN_FULL_NAME',
				'PER_ENABLE_DTW4',
				'DATETRACK:ENABLED'
				)        
		and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
		v_security	varchar2(42);
		v_rows number;
		v_org_name HR_ALL_ORGANIZATION_UNITS.NAME%type;
        
begin
				
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql40b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql40'');" href="javascript:;">&#9654; Profile Settings</A></DIV>');
			
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql40" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
		l_o('     <B>Profile Settings</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql41b"  onclick="displayItem2(this,''s1sql41'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql41" style="display:none">');
		l_o('    <TD colspan="4" height="60">');
		l_o('       <blockquote><p align="left">');
    
		l_o('         select n.user_profile_option_name, <br>');    	
		l_o('               po.profile_option_name ,<br>');
		l_o('         decode(to_char(pov.level_id),<br>');
		l_o('         ''10001'', ''Site'',<br>');
		l_o('         ''10002'', ''Application'',<br>');
		l_o('         ''10003'', ''Responsibility'',<br>');
		l_o('         ''10005'', ''Server'',<br>');
		l_o('         ''10006'', ''Org'',<br>');
		l_o('         ''10007'', ''Servresp'',<br>');
		l_o('          ''10004'', ''User'', ''???'') ,<br>');
		l_o('         decode(to_char(pov.level_id),<br>');
		l_o('          ''10001'', ''Site'',<br>');
		l_o('         ''10002'', nvl(app.application_short_name,to_char(pov.level_value)),<br>');
		l_o('         ''10003'', nvl(rsp.responsibility_name,to_char(pov.level_value)),<br>');
		l_o('          ''10005'', svr.node_name,<br>');
		l_o('         ''10006'', org.name,<br>');
		l_o('         ''10007'', pov.level_value ||'', ''|| pov.level_value_application_id ||'', ''|| pov.level_value2,<br>');
		l_o('          ''10004'', nvl(usr.user_name,to_char(pov.level_value)),<br>');
		l_o('          ''???'') ,<br>');
		l_o('          pov.profile_option_value<br>');
		l_o('         from   fnd_profile_options po,<br>');
		l_o('         fnd_profile_option_values pov,<br>');
		l_o('         fnd_profile_options_tl n,<br>');
		l_o('         fnd_user usr,<br>');
		l_o('         fnd_application app,<br>');
		l_o('         fnd_responsibility_vl rsp,<br>');
		l_o('         fnd_nodes svr,<br>');
		l_o('         hr_operating_units org<br>');
		
		if upper(run_type)='ALL' then
						l_o('         where po.profile_option_name like ''BNE%'' or po.profile_option_name in (<br>');
							l_o('         ''HR_USER_TYPE'',<br>''PER_BUSINESS_GROUP_ID'',<br>''PER_SECURITY_PROFILE_ID'',<br>''HR_CROSS_BUSINESS_GROUP'',<br>');
							l_o('         ''ORG_ID'',<br>''PER_ENABLE_DTW4'',<br>''DATETRACK:ENABLED'',<br>''FND_DISABLE_OA_CUSTOMIZATIONS'',''FND_CUSTOM_OA_DEFINTION''<br>''FND_OA_ENABLE_DEFAULTS''<br>');	
						case upper(product)
							WHEN 'PAY' then						
							l_o('           ,''HR_PAYROLL_CURRENCY_RATES'',<br>''HR_PAYROLL_CONTACT_SOURCE'',<br>''HR_VIEW_PAYSLIP_FROM_DATE'',<br>''HR_MV_HIRE_SKIP_ACT_VALIDATION'',<br>');
							l_o('         ''PAY_PPM_MULTI_ASSIGNMENT_ENABLE'',<br>''PAY_PSS_PAYMENTS_LIST'',<br>''PAY_PSS_PAYMENT_FUNCTION'',<br>''PAY_SIMULATION_ENABLE_FLAG'',<br>');
							l_o('         ''PAY_SIM_MULTI_ASSIGNMENT_ENABLE'',<br>''PAY_KEEP_ENBL_HRACES'',<br>''PAY_PSS_RUN_TYPE_DISPLAY'',<br>''PAY_USE_FF_PTO'',<br>');
							l_o('         ''GB PAYROLL PENSIONS ENROLL CHECK'',<br>''GB_PAYE_NI_AGGREGATION'',<br>''GB_OVERRIDE_SOY'',<br>''GB_DEFAULT_AGG_FLAG'',<br>');
							l_o('         ''GB RTI UPTAKE'',<br>''PAY_IE_P35_REPORTING_YEAR'')<br>');												
							
						WHEN 'HR' then								
								l_o('         ''HR_ALLOW_NEG_ABS_BAL'',<br>''PER_ABSENCE_DURATION_AUTO_OVERWRITE'',<br>''HR_VIEWS_LAYOUT_ABSENCE'',<br>''HR_SCH_BASED_ABS_CALC'',<br>');							 
							  l_o('         ''PER_GLOBAL_APL_NUM'',<br>''PER_GLOBAL_CWK_NUM'',<br>''PER_GLOBAL_EMP_NUM'',<br>''HR_CANCEL_APPLICATION'',<br>''HR_PROPAGATE_DATA_CHANGES'',<br>');      
							  l_o('         ''HR_LOCAL_OR_GLOBAL_NAME_FORMAT'',<br>''PAY_USE_FF_PTO'',''HZ_DQM_ENABLED_FLAG'',<br>''HZ_DQM_IGNORE_CONC_LIMITS'',<br>''HZ_DQM_ENABLE_REALTIME_SYNC'')<br>');
						WHEN 'IRC' then								
							  l_o('         ) or  (po.profile_option_name like ''IRC%'')<br>');
						WHEN 'OTA' then
								l_o('         ) or (po.profile_option_name like ''OTA%'')<br>');
						WHEN 'BEN' then						
								l_o('         ) or  (po.profile_option_name like ''BEN%'')<br>');
						WHEN 'OTL' then							  
							  l_o('         ,''PA_PTE_AUTOAPPROVE_TS'',''PO_SERVICES_ENABLED'',<br>''HR_ABS_OTL_INTEGRATION'',<br>''PER_ACCRUAL_PLAN_ELEMENT_SET'',<br>''PER_ABSENCE_DURATION_AUTO_OVERWRITE'')<br>');
							  l_o('         or  po.profile_option_name like ''HXT%''<br>');
							  l_o('         or po.profile_option_name like ''HXC%''<br>');							  
							 
						WHEN 'SSHR' then							  
							  l_o('         ,''AR_CHANGE_CUST_NAME'',<br>''HR_ALLOW_NEG_ABS_BAL'',<br>''PER_ABSENCE_DURATION_AUTO_OVERWRITE'',<br>''HR_VIEWS_LAYOUT_ABSENCE'',<br>');
							  l_o('         ''HR_SCH_BASED_ABS_CALC'',<br>''PER_GLOBAL_APL_NUM'',<br>''PER_GLOBAL_CWK_NUM'',<br>''PER_GLOBAL_EMP_NUM'',<br>');
							  l_o('         ''HR_CANCEL_APPLICATION'',<br>''HR_PROPAGATE_DATA_CHANGES'',<br>''HR_LOCAL_OR_GLOBAL_NAME_FORMAT'',<br>''PAY_USE_FF_PTO'',<br>');							 
							  l_o('         ''HR_APPRAISEE_ADD_PARTICIPANTS'',<br>''HR_WORKER_APPRAISALS_MENU'',<br>''HR_MANAGER_APPRAISALS_MENU'',<br>''HR_APPLY_COMPETENCIES_TO_PERSON'',<br>');
							  l_o('         ''HR_TALENT_MGMT_SRC_TYPE'',<br>''HR_SAVE_STAY_APPRAISALS_PAGE'',<br>''HR_ALLOW_UPDATES_TO_OBJECTIVE_DETAILS_ADDED_BY_APPRAISEE'',<br>');							  						  
							  l_o('         ''HR_TOTAL_COMP_OBJ_PRECESION'',<br>''HR_ALLOW_APPRAISALS_CROSS_BG'',<br>''PER_WPM_APPRAISAL_UPDATE_AFTER_PERIOD'',<br>');
							  l_o('         ''PER_VIEW_HISTORICAL_PLANS'',<br>''HR_ENABLE_TALENT_PROFILE'',<br>''HR_SELF_SERVICE_HR_LICENSED'',<br>''HR_SUCCESSION_MGMT_LICENSED'',<br>');
							  l_o('         ''PQH_ALLOW_APPROVER_TO_EDIT_TXN'',<br>''BEN_CWB_LICENSE_CHECK'',<br>''OTA_ORACLE_ILEARNING_LICENSED'',<br>''AME_INSTALLED_FLAG'',<br>');
							  l_o('         ''AME_INSTALLATION_LEVEL'',<br>''HR_ABS_OTL_INTEGRATION'',<br>''FND_EXTERNAL_ADF_URL'')<br>');
						WHEN 'ALL' then							  
							  l_o('''HR_PAYROLL_CURRENCY_RATES'',<br>''HR_PAYROLL_CONTACT_SOURCE'',<br>''HR_VIEW_PAYSLIP_FROM_DATE'',<br>''HR_MV_HIRE_SKIP_ACT_VALIDATION'',<br>''HR_ALLOW_NEG_ABS_BAL'',<br>');
							  l_o('''PER_ABSENCE_DURATION_AUTO_OVERWRITE'',<br>''HR_VIEWS_LAYOUT_ABSENCE'',<br>''HR_SCH_BASED_ABS_CALC'',<br>''PER_GLOBAL_APL_NUM'',<br>''PER_GLOBAL_CWK_NUM'',<br>''PER_GLOBAL_EMP_NUM'',<br>');
							  l_o('''HR_CANCEL_APPLICATION'',<br>''HR_PROPAGATE_DATA_CHANGES'',<br>''HR_LOCAL_OR_GLOBAL_NAME_FORMAT'',<br>''PAY_USE_FF_PTO'',<br>''HR_APPRAISEE_ADD_PARTICIPANTS'',<br>');
							  l_o('''HR_WORKER_APPRAISALS_MENU'',<br>''HR_MANAGER_APPRAISALS_MENU'',<br>''HR_APPLY_COMPETENCIES_TO_PERSON'',<br>''HR_TALENT_MGMT_SRC_TYPE'',<br>''HR_SAVE_STAY_APPRAISALS_PAGE'',<br>');
							  l_o('''HR_ALLOW_UPDATES_TO_OBJECTIVE_DETAILS_ADDED_BY_APPRAISEE'',<br>''HR_TOTAL_COMP_OBJ_PRECESION'',<br>''HR_ALLOW_APPRAISALS_CROSS_BG'',<br>''PER_WPM_APPRAISAL_UPDATE_AFTER_PERIOD'',<br>');
							  l_o('''PER_VIEW_HISTORICAL_PLANS'',<br>''HR_ENABLE_TALENT_PROFILE'',<br>''HR_SELF_SERVICE_HR_LICENSED'',<br>''HR_SUCCESSION_MGMT_LICENSED'',<br>');
							  l_o('''PQH_ALLOW_APPROVER_TO_EDIT_TXN'',<br>''BEN_CWB_LICENSE_CHECK'',<br>''OTA_ORACLE_ILEARNING_LICENSED'',<br>''AME_INSTALLED_FLAG'',<br>');
							  l_o('''AME_INSTALLATION_LEVEL'',<br>''HR_ABS_OTL_INTEGRATION'',<br>''PAY_PPM_MULTI_ASSIGNMENT_ENABLE'',<br>''PAY_FR_CHECK_MANDATORY_ASG_ATTRIBUTES'',<br>');								
								l_o('''PAY_PSS_PAYMENT_FUNCTION'',<br>''PAY_SIMULATION_ENABLE_FLAG'',<br>''PAY_SIM_MULTI_ASSIGNMENT_ENABLE'',<br>''PAY_KEEP_ENBL_HRACES'',<br>''PAY_PSS_RUN_TYPE_DISPLAY'',<br>''PAY_USE_FF_PTO'',<br>''PER_ENABLE_DTW4'',<br>');
								l_o('''GB PAYROLL PENSIONS ENROLL CHECK'',<br>''GB_OVERRIDE_SOY'',<br>''GB_DEFAULT_AGG_FLAG'',<br>''GB RTI UPTAKE'',<br>');
								l_o('''PAY_IE_P35_REPORTING_YEAR'',<br>''GB_PAYE_NI_AGGREGATION'',<br>''FND_EXTERNAL_ADF_URL'',<br>');
							  l_o('''FND_DISABLE_OA_CUSTOMIZATIONS'',''FND_CUSTOM_OA_DEFINTION''<br>''FND_OA_ENABLE_DEFAULTS'')<br>');
							  l_o('         or po.profile_option_name like ''HXT%''<br>');
							  l_o('         or po.profile_option_name like ''HXC%''<br>');
							  l_o('         or po.profile_option_name in (''PA_PTE_AUTOAPPROVE_TS'',''PO_SERVICES_ENABLED'')))<br>');
						else
							null;
						end case;
		end if;

		if upper(run_type)='ISSUES' then
							  l_o('         where  (po.profile_option_name in (<br>  list of profiles with issues<br> )<br>');
		end if;
		l_o('          and    pov.application_id = po.application_id<br>');
		l_o('          and    po.profile_option_name = n.profile_option_name<br>');
		l_o('          and    pov.profile_option_id = po.profile_option_id<br>');
		l_o('          and    usr.user_id (+) = pov.level_value<br>');
		l_o('          and    rsp.application_id (+) = pov.level_value_application_id<br>');
		l_o('          and    rsp.responsibility_id (+) = pov.level_value<br>');
		l_o('          and    app.application_id (+) = pov.level_value<br>');
		l_o('          and    svr.node_id (+) = pov.level_value<br>');
		l_o('          and    svr.node_id (+) = pov.level_value2<br>');
		l_o('         and    org.organization_id (+) = pov.level_value<br>');
		l_o('         and    n.language=''US''<br>');
		l_o('         order by n.user_profile_option_name,pov.level_id;<br>');
    
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH width="25%"><B>Long Name</B></TD>');
		l_o(' <TH width="15%"><B>Short Name</B></TD>');
		l_o(' <TH width="15%"><B>Level</B></TD>');
		l_o(' <TH width="30%"><B>Context</B></TD>');
		l_o(' <TH width="15%"><B>Profile Value</B></TD>');
    
    
	:n := dbms_utility.get_time;
	
    v_short_name_old:='x';
    v_level_old:='x';
   	
	if upper(run_type) = 'ALL' then
		  open big_profiles;
          loop
            fetch big_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  big_profiles%NOTFOUND;
                    if v_short_name<>v_short_name_old then
							  if v_big_no>1 then
									v_big_no2 :=v_big_no-1;
									l_o('<tr><td><A class=detail onclick="hideRow2(''s1sql100'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
									l_o('</TABLE></td></TR>');
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%"><B>Level</B></TD>');
							  l_o(' <TD width="35%"><B>Context</B></TD>');
							  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                        l_o('</TD>'||chr(10)||'<TD>' );
                        l_o('</TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        l_o(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        l_o('-');
                    else
                        l_o(v_context );
                    end if;
					begin
					case v_short_name
					when 'PER_SECURITY_PROFILE_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from PER_SECURITY_PROFILES 
									where SECURITY_PROFILE_ID = v_value;
								if v_rows=1 then
										select substr(SECURITY_PROFILE_NAME,1,40) into v_security from PER_SECURITY_PROFILES 
											where SECURITY_PROFILE_ID = v_value;							
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_security);
								else
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					when 'HR_USER_TYPE' then
							case v_value
							when 'INT' then
								l_o('</TD>'||chr(10)||'<TD>INT - HR with Payroll User' );
							when 'PAY' then
								l_o('</TD>'||chr(10)||'<TD>PAY - Payroll User' );
							when 'PER' then
								l_o('</TD>'||chr(10)||'<TD>PER - HR User' );
							else
								l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
							end case;
					when 'ORG_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;
								if v_rows=1 then									
										select NAME into v_org_name from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;										
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_org_name);									
								else
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					when 'PER_BUSINESS_GROUP_ID' then
							if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
								select count(1) into v_rows from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;
								if v_rows=1 then									
										select NAME into v_org_name from HR_ALL_ORGANIZATION_UNITS
											where ORGANIZATION_ID=v_value;										
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - '|| v_org_name);									
								else
										l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
								end if;
							else
								l_o('</TD>'||chr(10)||'<TD>'||v_value||' - null');
							end if;
					else
							l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
					end case;
                    
                    EXCEPTION
					when others then
					  l_o('<br>'||sqlerrm ||' occurred in test');
					  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
					end;
					l_o('</TD></TR>'||chr(10));              
          end loop;
          close big_profiles;
		  
		  v_big_no2 :=v_big_no-1;
		  l_o('<tr><td><A class=detail onclick="hideRow2(''s1sql100'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
									
		  l_o(' </TABLE>');
		  
	end if;
	
EXCEPTION
					when others then
					  l_o('<br>'||sqlerrm ||' occurred in test');
					  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;


-- Display profiles settings
procedure profiles2 is
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name fnd_profile_options_tl.user_profile_option_name%type; 
  v_short_name fnd_profile_options.profile_option_name%type;
  v_short_name_old fnd_profile_options.profile_option_name%type;
  v_level varchar2(30);
  v_level_old varchar2(30);
  v_context varchar2(300);
  v_value fnd_profile_option_values.profile_option_value%type;
  v_id fnd_profile_options.PROFILE_OPTION_ID%type;
  issue0 boolean := FALSE;	
  issue1 boolean := FALSE;
  issue2 boolean := FALSE;
  issue3 boolean := FALSE;
  issue4 boolean := FALSE;
  issue5 boolean := FALSE;
  issue6 boolean := FALSE;
  issue7 boolean := FALSE;
  issue8 boolean := FALSE;
  issue9 boolean := FALSE;
  issue10 boolean := FALSE;
  issue11 boolean := FALSE;
  issue12 boolean := FALSE;
  issue13 boolean := FALSE;
  issue131 boolean := FALSE;
  issue14 boolean := FALSE;
  issue142 boolean := FALSE;
  issue15 boolean := FALSE;
  issue16 boolean := FALSE;
  issue17 boolean := FALSE;
  issue18 boolean := FALSE;
  issue19 boolean := FALSE;
  issue182 boolean := FALSE;
  issue192 boolean := FALSE;
  issue20 boolean := FALSE;
  issue21 boolean := FALSE;
  issue22 boolean := FALSE;
  issue23 boolean := FALSE;
  issue24 boolean := FALSE;
  issue25 boolean := FALSE;
  issue26 boolean := FALSE;  
  v_rows number;
  v_begin_table number;
  v_end_table number;
  v_big_no_old number;
  v_big_no number;
	
	cursor pay_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
              (
              'HR_PAYROLL_CURRENCY_RATES',
				'HR_PAYROLL_CONTACT_SOURCE',
				'HR_VIEW_PAYSLIP_FROM_DATE',
				'HR_MV_HIRE_SKIP_ACT_VALIDATION',
				'PAY_PPM_MULTI_ASSIGNMENT_ENABLE',				
				'PAY_PSS_PAYMENTS_LIST',
				'PAY_PSS_PAYMENT_FUNCTION',
				'PAY_SIMULATION_ENABLE_FLAG',
				'PAY_SIM_MULTI_ASSIGNMENT_ENABLE',
				'PAY_KEEP_ENBL_HRACES',
                'PAY_PSS_RUN_TYPE_DISPLAY',
                'PAY_USE_FF_PTO',
			    'PER_ENABLE_DTW4',
				'GB PAYROLL PENSIONS ENROLL CHECK',
				'GB_PAYE_NI_AGGREGATION',
				'PAY_IE_P35_REPORTING_YEAR',
				'GB_OVERRIDE_SOY',
				'GB_DEFAULT_AGG_FLAG',
				'GB RTI UPTAKE'
			  )
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
    
	cursor irc_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name like 'IRC%'			 
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
		
	cursor hr_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
              (
              'HR_ALLOW_NEG_ABS_BAL',
              'PER_ABSENCE_DURATION_AUTO_OVERWRITE',
              'HR_VIEWS_LAYOUT_ABSENCE',
              'HR_SCH_BASED_ABS_CALC',
              'PER_GLOBAL_APL_NUM',
              'PER_GLOBAL_CWK_NUM',
              'PER_GLOBAL_EMP_NUM','PER_EX_SECURITY_PROFILE',
              'HR_CANCEL_APPLICATION',
              'HR_PROPAGATE_DATA_CHANGES',
              'HR_LOCAL_OR_GLOBAL_NAME_FORMAT',
              'PAY_USE_FF_PTO',
			  'HZ_DQM_ENABLED_FLAG',
			  'HZ_DQM_IGNORE_CONC_LIMITS',
			  'HZ_DQM_ENABLE_REALTIME_SYNC',
			  'HR_EVAL_USER_ACCESS_MIN_CACHE'
			  )
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;	 
	
	cursor ben_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name like 'BEN%'
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;	
	
	cursor ota_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name like 'OTA%'
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;	
	
	cursor sshr_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  po.profile_option_name in
              ('AR_CHANGE_CUST_NAME',
			  'HR_APPRAISEE_ADD_PARTICIPANTS',
			  'HR_WORKER_APPRAISALS_MENU',
			  'HR_MANAGER_APPRAISALS_MENU',
			  'HR_APPLY_COMPETENCIES_TO_PERSON',
			  'HR_TALENT_MGMT_SRC_TYPE',
			  'HR_SAVE_STAY_APPRAISALS_PAGE',
			  'HR_ALLOW_UPDATES_TO_OBJECTIVE_DETAILS_ADDED_BY_APPRAISEE',
			  'HR_TOTAL_COMP_OBJ_PRECESION',
			  'HR_ALLOW_APPRAISALS_CROSS_BG',
			  'PER_WPM_APPRAISAL_UPDATE_AFTER_PERIOD',
			  'PER_VIEW_HISTORICAL_PLANS',
			  'HR_ENABLE_TALENT_PROFILE',
			  'HR_SELF_SERVICE_HR_LICENSED',
			  'HR_SUCCESSION_MGMT_LICENSED',
			  'BEN_CWB_LICENSE_CHECK',
			  'OTA_ORACLE_ILEARNING_LICENSED',
			  'AME_INSTALLED_FLAG',
			  'AME_INSTALLATION_LEVEL',
			  'HR_ABS_OTL_INTEGRATION',
			  'FND_EXTERNAL_ADF_URL',
			  'PQH_ALLOW_APPROVER_TO_EDIT_TXN'
              ) 
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;

	cursor otl_profiles is
	select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  (po.profile_option_name like 'HXT%' 
				or po.profile_option_name like 'HXC%' 
				or po.profile_option_name in ('PA_PTE_AUTOAPPROVE_TS',
				'HR_ABS_OTL_INTEGRATION',
					'PER_ACCRUAL_PLAN_ELEMENT_SET',
					'PER_ABSENCE_DURATION_AUTO_OVERWRITE')
              ) 
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;

	cursor all_profiles is
   select n.user_profile_option_name,
      po.profile_option_name ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', 'Application',
              '10003', 'Responsibility',
              '10005', 'Server',
              '10006', 'Org',
              '10007', 'Servresp',
              '10004', 'User', '???') ,
       decode(to_char(pov.level_id),
              '10001', 'Site',
              '10002', nvl(app.application_short_name,to_char(pov.level_value)),
              '10003', nvl(rsp.responsibility_name,to_char(pov.level_value)),
              '10005', svr.node_name,
              '10006', org.name,
              '10007', pov.level_value ||', '|| pov.level_value_application_id ||', '|| pov.level_value2,
              '10004', nvl(usr.user_name,to_char(pov.level_value)),
              '???') ,
       pov.profile_option_value 
        from   fnd_profile_options po,
               fnd_profile_option_values pov,
               fnd_profile_options_tl n,
               fnd_user usr,
               fnd_application app,
               fnd_responsibility_vl rsp,
               fnd_nodes svr,
               hr_operating_units org
        where  (po.profile_option_name in (              
			  'FND_DISABLE_OA_CUSTOMIZATIONS','FND_CUSTOM_OA_DEFINTION',
			  'FND_OA_ENABLE_DEFAULTS',
			  'ENABLE_SECURITY_GROUPS',
			  'UPLOAD_FILE_SIZE_LIMIT',
			  'APPS_FRAMEWORK_AGENT','APPS_JSP_AGENT'
			,'APPS_WEB_AGENT','APPS_SERVLET_AGENT','APPS_SSO'
			,'FND_FWK_COMPATIBILITY_MODE'
			,'WEB_PROXY_HOST'
			,'WEB_PROXY_PORT'
			,'WEB_PROXY_BYPASS_DOMAINS'
			,'PER_WIP_AUTOMATIC_SAVE'
			,'FND_NATIVE_CLIENT_ENCODING'
			,'ICX_CLIENT_IANA_ENCODING')
               or po.profile_option_name like 'BNE%' )
        and    pov.application_id = po.application_id
        and    po.profile_option_name = n.profile_option_name
        and    pov.profile_option_id = po.profile_option_id
        and    usr.user_id (+) = pov.level_value
        and    rsp.application_id (+) = pov.level_value_application_id
        and    rsp.responsibility_id (+) = pov.level_value
        and    app.application_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value
        and    svr.node_id (+) = pov.level_value2
        and    org.organization_id (+) = pov.level_value
		and    n.language='US'
        order by n.user_profile_option_name,pov.level_id;
        
begin

 if upper(product) ='OTL' or upper(product) ='ALL' then	
 begin
 open otl_profiles;
    loop
            fetch otl_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  otl_profiles%NOTFOUND;
            CASE v_short_name
							  when 'HXT_BATCH_SIZE' then 
								if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
									if v_value<25 then
										issue1:=TRUE;
									end if;
								end if;
							  when 'HXT_HOL_HOURS_FROM_HOL_CAL' then
								if v_value ='Y' then                
								  issue2:=TRUE;
								elsif v_value='N' then
									issue3:=TRUE;
								end if;  
							  when 'HXT_ROLLUP_BATCH_HOURS' then
								if v_value ='Y' then                
								  issue4:=TRUE;
								elsif v_value='N' then
									issue5:=TRUE;
								end if; 
							  when 'HXC_TIMEKEEPER_OVERRIDE' then 
								if v_value='N' then
									issue6:=TRUE;
								end if;     
							  when 'HXC_ALLOW_TERM_SS_TIMECARD' then 
								if v_value='N' then
									issue7:=TRUE;
								end if;    
							  when 'HXC_DEFER_WORKFLOW' then
								if v_value ='Y' then                
								  issue8:=TRUE;
								elsif v_value='N' then
									issue9:=TRUE;
								end if; 
							  when 'HXC_RETRIEVAL_MAX_ERRORS' then
								if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
									if v_value<500 then                
									  issue10:=TRUE;
									elsif v_value<1000 then
										issue11:=TRUE;
									end if; 
								end if;
							  when 'HXC_RETRIEVAL_CHANGES_DATE' then
								if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
									if v_value < 8 then                
									  issue12:=TRUE;
									elsif v_value < 30 then                
									  issue13:=TRUE;
									elsif v_value < 365 then
									  issue131:=TRUE;
									end if; 
								end if;
							  when 'HXC_RETRIEVAL_BATCH_SIZE' then 
								if LENGTH(TRIM(TRANSLATE(v_value, ' +-.0123456789', ' '))) is null then
									if v_value<50 then
										issue14:=TRUE;
									elsif v_value<100 then
										issue142:=TRUE;					
									end if; 
								end if;
							  when 'HXC_RETRIEVAL_OPTIONS' then
								if v_value='BEE Only' then                
								  issue15:=TRUE;
								elsif v_value='OTLR Only' then
									issue16:=TRUE;
								end if; 
							  when 'PA_PTE_AUTOAPPROVE_TS' then 
								if v_value='Y' then
									issue17:=TRUE;
								end if; 
							  else
								null;
							END CASE;			
						 
				   
      end loop;
      close otl_profiles;
  EXCEPTION
					when others then
					  l_o('<br>'||sqlerrm ||' occurred in test');
					  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');					
  end;
  end if;
  
	  
  if upper(product) in('PAY','ALL') then
  	select count(1) 
     into v_rows
      from hr_legislation_installations
     where substr(application_short_name,1,4)='PAY'
     and  Legislation_code = 'IE'  and status='I';     
     if v_rows>0 then
		select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
			where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'   and pov.level_id='10001'
			and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
			if v_rows = 0 then
				issue22:=TRUE;
			else
				select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
					where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'   and pov.level_id='10001' and pov.profile_option_value='2014'
					and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
					if v_rows = 0 then
						issue23:=TRUE;
					end if;				
			end if;
		select   count(distinct pov.profile_option_value)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
					where  po.profile_option_name ='PAY_IE_P35_REPORTING_YEAR'  
					and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
			if v_rows >1 then
				issue24:=TRUE;
			end if;
	 end if;
  end if;  
  
  if upper(product) in('HR','SSHR','ALL') then
		select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='PER_GLOBAL_EMP_NUM'  and  pov.profile_option_value='Y'
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
		if v_rows >1 then
				issue25:=TRUE;
			end if;
  end if;
  
  if upper(product) in ('SSHR','OTA','ALL') then	
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_WORKER_APPRAISALS_MENU' and pov.level_id='10001' and pov.profile_option_value is null 
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;					
					if v_rows>0 then
						issue18:=TRUE;
					end if;
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_WORKER_APPRAISALS_MENU' and pov.level_id='10001' 
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;					
					if v_rows=0 then
						issue18:=TRUE;
					end if;					
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_WORKER_APPRAISALS_MENU' and pov.level_id='10001' and pov.profile_option_value <>'HR_EMPLOYEE_APPRAISALS_MENU' 
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;					
					if v_rows>0 then
						issue182:=TRUE;
					end if;
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_MANAGER_APPRAISALS_MENU' and pov.level_id='10001' and pov.profile_option_value is null
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;	
					if v_rows>0 then
						issue19:=TRUE;
					end if;
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_MANAGER_APPRAISALS_MENU' and pov.level_id='10001' 
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;	
					if v_rows=0 then
						issue19:=TRUE;
					end if;
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='HR_MANAGER_APPRAISALS_MENU' and pov.level_id='10001' and pov.profile_option_value <>'HR_MANAGER_APPRAISALS_MENU'
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;	
					if v_rows>0 then
						issue192:=TRUE;
					end if;
	end if;
	if upper(product) in ('SSHR','ALL') then				
					select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
							where  po.profile_option_name ='AR_CHANGE_CUST_NAME'  and pov.level_id = 10001 and (pov.profile_option_value is null or pov.profile_option_value='N')
							and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;	
					if v_rows>0 then
						issue21:=TRUE;
					end if;
  end if;
    
	select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
	where  po.profile_option_name ='FND_DISABLE_OA_CUSTOMIZATIONS'   and pov.profile_option_value='N'
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
	if v_rows > 0 then
		issue0:=TRUE;
	end if;
	
	select   count(1)  into v_rows from   fnd_profile_options po,  fnd_profile_option_values pov         
	where  po.profile_option_name ='FND_OA_ENABLE_DEFAULTS'   and pov.profile_option_value='N'
	and    pov.application_id = po.application_id  and pov.profile_option_id = po.profile_option_id;
	if v_rows > 0 then
		issue20:=TRUE;
	end if;
	
	SELECT  count(1) into v_rows
         FROM    fnd_profile_options po
                ,fnd_profile_option_values pov
         WHERE   po.profile_option_name = 'ENABLE_SECURITY_GROUPS'
         AND     po.application_id = 0
         AND     po.profile_option_id = pov.profile_option_id
         AND     po.application_id = pov.application_id
         AND     (pov.level_id = 10002  AND  hr_general.chk_application_id (pov.level_value) = 'TRUE')
         AND     pov.profile_option_value = 'Y';
	if v_rows > 0 then
		issue26:=TRUE;
	end if;
	
	v_short_name_old:='x';
    v_level_old:='x';
	v_big_no:=11;
	v_begin_table:=0;
	v_end_table:=0;
	
	open all_profiles;
          loop
            fetch all_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  all_profiles%NOTFOUND;
            if upper(run_type)='ALL' or (issue0 and v_short_name='FND_DISABLE_OA_CUSTOMIZATIONS')  
			or (issue20 and v_short_name='FND_OA_ENABLE_DEFAULTS') or (issue26 and v_short_name='ENABLE_SECURITY_GROUPS') then				 
					 if v_short_name<>v_short_name_old then
							  if v_big_no>11 then  
									l_o('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%"><B>Level</B></TD>');
							  l_o(' <TD width="35%"><B>Context</B></TD>');
							  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                        l_o('</TD>'||chr(10)||'<TD>' );
                        l_o('</TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        l_o(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        l_o('-');
                    else
                        l_o(v_context );
                    end if;
                    l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
                    l_o('</TD></TR>'||chr(10));              
			end if;
		  end loop;
   close all_profiles;
   if v_begin_table<>v_end_table then
		l_o(' </TABLE>');
   end if;
		
	
	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(run_type)='ALL' and upper(product) in ('BEN','ALL')  then
          open ben_profiles;
          loop
            fetch ben_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  ben_profiles%NOTFOUND;            
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									l_o('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%"><B>Level</B></TD>');
							  l_o(' <TD width="35%"><B>Context</B></TD>');
							  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                        l_o('</TD>'||chr(10)||'<TD>' );
                        l_o('</TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        l_o(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        l_o('-');
                    else
                        l_o(v_context );
                    end if;
                    l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
                    l_o('</TD></TR>'||chr(10));              
		  end loop;
          close ben_profiles;  
		  if v_begin_table<>v_end_table then
				l_o(' </TABLE>');
		  end if;
    end if;
	
		
	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(run_type)='ALL' and upper(product) in ('IRC','ALL')  then
          open irc_profiles;
          loop
            fetch irc_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  irc_profiles%NOTFOUND;            
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									l_o('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%"><B>Level</B></TD>');
							  l_o(' <TD width="35%"><B>Context</B></TD>');
							  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                        l_o('</TD>'||chr(10)||'<TD>' );
                        l_o('</TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        l_o(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        l_o('-');
                    else
                        l_o(v_context );
                    end if;
                    l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
                    l_o('</TD></TR>'||chr(10));            
			
		  end loop;
          close irc_profiles;  
		  if v_begin_table<>v_end_table then
				l_o(' </TABLE>');
		  end if;
    end if;
	
	

	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
    if upper(product) in ('HR','SSHR','ALL')  then
          open hr_profiles;
          loop
            fetch hr_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  hr_profiles%NOTFOUND;
			if upper(run_type)='ALL' or (issue25 and v_short_name='PER_GLOBAL_EMP_NUM')  then
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									l_o('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%"><B>Level</B></TD>');
							  l_o(' <TD width="35%"><B>Context</B></TD>');
							  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
                   if v_short_name=v_short_name_old and v_level=v_level_old then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                        l_o('</TD>'||chr(10)||'<TD>' );
                        l_o('</TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
						l_o(v_level ||'</TD>'||chr(10)||'<TD>');						
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        l_o('-');
                    else
                        l_o(v_context );
                    end if;
					if v_short_name<>'HR_LOCAL_OR_GLOBAL_NAME_FORMAT' then
							l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
						else
							if v_value like 'G%' then								
								l_o('</TD>'||chr(10)||'<TD>Global Format' );
							elsif v_value like 'L%' then							
								l_o('</TD>'||chr(10)||'<TD>Local Format' );
							else
								l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
							end if;
					end if;
						
                    
                    l_o('</TD></TR>'||chr(10));              
          end if;
		  end loop;
          close hr_profiles;  
		  if v_begin_table<>v_end_table then
				l_o(' </TABLE>');
		  end if;
    end if;

	
	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(product) in ('SSHR','ALL')  then
          open sshr_profiles;
          loop
            fetch sshr_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  sshr_profiles%NOTFOUND;
             if upper(run_type)='ALL' or ((issue18 or issue182) and v_short_name='HR_WORKER_APPRAISALS_MENU') or (issue21 and v_short_name='AR_CHANGE_CUST_NAME')
				or ((issue19 or issue192) and v_short_name='HR_MANAGER_APPRAISALS_MENU') then
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									l_o('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%"><B>Level</B></TD>');
							  l_o(' <TD width="35%"><B>Context</B></TD>');
							  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                        l_o('</TD>'||chr(10)||'<TD>' );
                        l_o('</TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        l_o(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        l_o('-');
                    else
                        l_o(v_context );
                    end if;
                    l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
                    l_o('</TD></TR>'||chr(10));              
			 end if;
		  end loop;
          close sshr_profiles;  
		  if v_begin_table<>v_end_table then
				l_o(' </TABLE>');
		  end if;
    end if;

	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
   if upper(product) in ('OTA','ALL')  then
          open ota_profiles;
          loop
            fetch ota_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  ota_profiles%NOTFOUND;
			if upper(run_type)='ALL' or ((issue18 or issue182) and v_short_name='HR_WORKER_APPRAISALS_MENU') 
				or ((issue19 or issue192) and v_short_name='HR_MANAGER_APPRAISALS_MENU') then
					if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									l_o('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%"><B>Level</B></TD>');
							  l_o(' <TD width="35%"><B>Context</B></TD>');
							  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
					end if;
					if v_short_name=v_short_name_old and v_level=v_level_old then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                        l_o('</TD>'||chr(10)||'<TD>' );
                        l_o('</TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                        l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                        l_o(v_level ||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_short_name_old:=v_short_name;
                    v_level_old:=v_level;
          
                    if v_context is null then
                        l_o('-');
                    else
                        l_o(v_context );
                    end if;
                    l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
                    l_o('</TD></TR>'||chr(10));
				end if;
		  end loop;
          close ota_profiles;  
		  if v_begin_table<>v_end_table then
				l_o(' </TABLE>');
		  end if;
    end if;
	
	
	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
    if upper(product) in ('OTL','ALL') then
          open otl_profiles;
          loop
            fetch otl_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  otl_profiles%NOTFOUND;
			if upper(run_type)='ALL' or (issue1 and v_short_name='HXT_BATCH_SIZE') 
				or ((issue2 or issue3) and v_short_name='HXT_HOL_HOURS_FROM_HOL_CAL')  
				or ((issue4 or issue5) and v_short_name='HXT_ROLLUP_BATCH_HOURS')
				or (issue6 and v_short_name='HXC_TIMEKEEPER_OVERRIDE')
				or (issue7 and v_short_name='HXC_ALLOW_TERM_SS_TIMECARD')
				or ((issue8 or issue9) and v_short_name='HXC_DEFER_WORKFLOW')
				or ((issue10 or issue11) and v_short_name='HXC_RETRIEVAL_MAX_ERRORS')
				or ((issue2 or issue13) and v_short_name='HXC_RETRIEVAL_CHANGES_DATE')
				or ((issue14 or issue142) and v_short_name='HXC_RETRIEVAL_BATCH_SIZE')
				or ((issue15 or issue16) and v_short_name='HXC_RETRIEVAL_OPTIONS')
				or (issue17 and v_short_name='PA_PTE_AUTOAPPROVE_TS') then
						   if v_short_name<>v_short_name_old then
									  if v_big_no>v_big_no_old then  
											l_o('</TABLE></td></TR>');
											v_end_table:=v_end_table+1;
									  end if;
									  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
									  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
									  l_o('   </TD>');
									  l_o(' </TR>');
									  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
									  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
									  l_o(' <TD width="15%"><B>Short Name</B></TD>');
									  l_o(' <TD width="10%"><B>Level</B></TD>');
									  l_o(' <TD width="35%"><B>Context</B></TD>');
									  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
									  v_begin_table:=v_begin_table+1;
									  v_big_no:=v_big_no+1;
									  
							end if;
						   if v_short_name=v_short_name_old and v_level=v_level_old then
								l_o('<TR><TD></TD>'||chr(10)||'<TD>');
								l_o('</TD>'||chr(10)||'<TD>' );
								l_o('</TD>'||chr(10)||'<TD>');
							else
								l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
								l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
								l_o(v_level ||'</TD>'||chr(10)||'<TD>');
							end if;
							v_short_name_old:=v_short_name;
							v_level_old:=v_level;
				  
							if v_context is null then
								l_o('-');
							else
								l_o(v_context );
							end if;
							l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
							l_o('</TD></TR>'||chr(10));      
				end if;					
          end loop;
          close otl_profiles;
		  if v_begin_table<>v_end_table then
				l_o(' </TABLE>');
		  end if;
    end if;
    

	v_begin_table:=0;
	v_end_table:=0;
	v_big_no_old:=v_big_no;
	if upper(product) in ('ALL','PAY')  then
          open pay_profiles;
          loop
            fetch pay_profiles into v_name,v_short_name,v_level,v_context,v_value;
            EXIT WHEN  pay_profiles%NOTFOUND;
			if upper(run_type)='ALL' or ((issue22 or issue23 or issue24) and v_short_name='PAY_IE_P35_REPORTING_YEAR')  then
			if v_short_name<>v_short_name_old then
							  if v_big_no>v_big_no_old then  
									l_o('</TABLE></td></TR>');
									v_end_table:=v_end_table+1;
							  end if;
							  l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_short_name ||'</TD>'||chr(10));
							  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql100'||v_big_no||'b" onclick="displayItem2(this,''s1sql100'||v_big_no||''');" href="javascript:;">&#9654; Show Records</A>');
							  l_o('   </TD>');
							  l_o(' </TR>');
							  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql100'||v_big_no||'" style="display:none">');
							  l_o(' <TR><TD width="25%"><B>Long Name</B></TD>');
							  l_o(' <TD width="15%"><B>Short Name</B></TD>');
							  l_o(' <TD width="10%"><B>Level</B></TD>');
							  l_o(' <TD width="35%"><B>Context</B></TD>');
							  l_o(' <TD width="15%"><B>Profile Value</B></TD></TR>');
							  v_begin_table:=v_begin_table+1;
							  v_big_no:=v_big_no+1;
							  
			end if;
            if v_short_name=v_short_name_old and v_level=v_level_old then
                l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                l_o('</TD>'||chr(10)||'<TD>' );
                l_o('</TD>'||chr(10)||'<TD>');
            else
                l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
                l_o(v_short_name ||'</TD>'||chr(10)||'<TD>' );
                l_o(v_level ||'</TD>'||chr(10)||'<TD>');
            end if;
            v_short_name_old:=v_short_name;
            v_level_old:=v_level;
            
            if v_context is null then
                l_o('-');
            else
                l_o(v_context );
            end if;
            l_o('</TD>'||chr(10)||'<TD>'     ||v_value );
            l_o('</TD></TR>'||chr(10));
          end if;      
          end loop;
          close pay_profiles;
		  if v_begin_table<>v_end_table then
				l_o(' </TABLE>');
		  end if;
    end if;

		  
    
    :n := (dbms_utility.get_time - :n)/100;
	l_o('<tr><td><A class=detail onclick="hideRow(''s1sql40'');" href="javascript:;">Collapse section</a></td></tr>');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> </div> ');
    
	if upper(run_type)='ALL' and (not issue26) then
				l_o('<div class="divok">');
				l_o('<span class="sectionblue1">Information:</span> Multiple Security Group is NOT enabled.<br></div>');
	end if;
			
    if upper(run_type)='ALL' or issue0 or issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 or issue11 or issue12 or issue13 or issue14 or issue15 or issue16 or issue17 or issue18 or issue19 or issue20 then
		if issue0 or issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 or issue11 or issue12 or issue13 or issue14 or issue15 or issue16 or issue17 or issue18 or issue182 or issue19 or issue192 or issue20 or issue21 
		or issue22 or issue23 or issue24 or issue25 or issue26 then
			
			if issue26 then
				l_o('<div class="divok">');
				l_o('<span class="sectionblue1">Information:</span> Multiple Security Group is enabled.<br></div>');
			end if;
			if issue0 then
				l_o('<div class="divok">');
				l_o('<span class="sectionblue1">Advice:</span> Profile "Disable Self-Service Personal" is set to N at one/several levels, ');
				l_o('so personalization/OA page customization is used. This can cause issues in system behavior (caused by custom personalization).<br> ');
				l_o('If you have issues in web pages, before raising an Service Request, please turn this profile to Y (to disable all personalizations) and retest. ');
				l_o('If the issue is not reproducible, then it is caused by customization.<br>');
				l_o('</div>');
			end if;
			if issue20 then
				l_o('<div class="divwarn">');
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "FND:OA:Enable Defaults" is set to N at one/several levels, ');
				l_o('so default values specified in personalizations and base meta data applied to your pages will not be displayed.<br> ');
				l_o('</div>');
				:w4:=:w4+1;
			end if;
			
			
			if (upper(product)in('SSHR','OTA','ALL')) then
				if (issue18 or issue19) then    
				  l_o('<div class="diverr">');				  
				  if issue18 then
					l_o('<img class="error_ico"><font color="red">Error:</font> Profile "HR: Worker Appraisals Menu" is not set at Site level, ');
					l_o('this may case issues when working with custom responsibility/menu. ');
					:e4:=:e4+1;
				  end if;	
				  if issue19 then
					l_o('<img class="error_ico"><font color="red">Error:</font> Profile "HR: Manager Appraisals Menu" is not set at Site level, ');
					l_o('this may case issues when working with custom responsibility/menu. ');
					:e4:=:e4+1;
				  end if;
				  l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=796769.1" target="_blank" >Note 796769.1</a> ');
				  l_o('Appraisal Not Being Created When Performance Management Plan Is Published <br></div>');
				end if;
				if (issue182 or issue192) then
					  l_o('<div class="divok">');
					   if issue182 then
						l_o('<span class="sectionblue1">Comment: </span> Profile "HR: Worker Appraisals Menu" is not set as Employee Appraisals Menu. ');
						l_o('Custom menu is set here, please make sure it follows the same structure of seeded menu. ');					
					  end if;
					  if issue192 then
						l_o('<span class="sectionblue1">Comment: </span> Profile "HR: Manager Appraisals Menu" is not set as Manager Appraisals Menu. ');
						l_o('Custom menu is set here, please make sure it follows the same structure of seeded menu. ');					
					  end if; 				
					  l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=796769.1" target="_blank" >Note 796769.1</a> ');
					  l_o('Appraisal Not Being Created When Performance Management Plan Is Published <br></div>');
				end if; 				  
			  end if;
			if (upper(product)in('SSHR','ALL')) and (issue21) then    
				  l_o('<div class="divwarn">');	
				  if issue21 then
					l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "HZ: Change Party Name" shoud be set to Yes at Site level. ');
					l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=732008.1" target="_blank" >Note 732008.1</a> ');
					l_o('Modify Employee Information and Receive Error APP-PER_289974 <br>');
					:w4:=:w4+1;
				  end if;
				  l_o('</div>');
			  end if;	  
			
			if (upper(product)='PAY' or upper(product)='ALL') and (issue22 or issue23 or issue24) then    
				  l_o('<div class="divwarn">');
				if issue22 then				
					l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "HR: IE P35 Reporting Year" is not set at Site Level.<br> ');				
					:w4:=:w4+1;
				end if;
				if issue23 then							
							l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "HR: IE P35 Reporting Year" is not set to current tax year 2014.<br> ');
							:w4:=:w4+1;
				end if;
				if issue23 then							
							l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "HR: IE P35 Reporting Year" is set to different values at different levels.<br> ');							
							:w4:=:w4+1;
				end if;				  
				  l_o('</div>');
			  end if;
			
			if (upper(product) in ('HR','SSHR','ALL')) and (issue25) then    
				  l_o('<div class="divok">');
				  l_o('<span class="sectionorange">For Oracle Support:</span> Profile "HR:Use Global Employee Numbering" is set to Yes.<br> ');
				  l_o('This note was followed: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=259160.1" target="_blank">Note 259160.1</a> Step By Step Instructions For Implementing Global Sequencing<br>');
				  l_o('Once a customer implements Global Numbering, they cannot go backwards and revert back to Automatic or Manual Numbering via Business Group Info.<br>');
				  l_o('They must continue to use Global Numbering.<br>');				 					  
				  l_o('</div>');
			  end if;
						
			if upper(product)='OTL' or upper(product)='ALL' then    
				if issue1 or issue6 or issue7 or issue11 or issue13 or issue142 then
					l_o('<div class="divwarn">');
					  if issue1 then
						l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "HXT: Batch Size" is lower than 25 at one/several levels, ');
						l_o('we recommend the value to be 25.<br>');
						:w4:=:w4+1;
					  end if;
					   if issue6 then
						l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "OTL: Allow Change Group Timekeeper" is set to N at ');
						l_o('one/several levels, this will stop you from setting up Timekeeper functionality.<br>');
						:w4:=:w4+1;
					  end if;
					  if issue7 then
						l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "OTL: Allow Self Service Time Entry for Terminated Employees" ');
						l_o('is set to N at one/several levels, ');
						l_o('so Terminated (not finally closed) employees will not be able to enter timecards for their previous periods.<br>');
						:w4:=:w4+1;
					  end if;
					  if issue11 then
						l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "OTL: Max Errors" is less than 1000 at one/several levels. ');
						l_o('Please increase it to 1000.<br>');
						:w4:=:w4+1;
					  end if;
					  if issue13 then
						l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>Profile "OTL: Number of past days for which retrieval considers changes (days)" is less than 30 at one/several levels. ');
						l_o('Recommended value is 365 days.<br>');
						:w4:=:w4+1;
					  end if;
					   if issue142 then
						l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Profile "OTL: Transfer Batch Size" is less than 100 at one/several levels.<br>');
						l_o('Please refer <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1304058.1" target="_blank">Note 1304058.1</a> ');
						l_o('Transfer Time From OTL to BEE Batch Size for Optimal Performance.<br>');
						:w4:=:w4+1;
					  end if;
					  l_o('</div>');
				  end if;
				  if issue131 or issue15 or issue16 or issue2 or issue3 or issue4 or issue5 or issue8 or issue9 then
					l_o('<div class="divok">');
					  if issue131 then
						l_o('<span class="sectionblue1">Advice: </span>Profile "OTL: Number of past days for which retrieval considers changes (days)" is less than 365 at one/several levels. ');
						l_o('Recommended value is 365 days.<br>');
					  end if;				  
					   if issue15 then
						l_o('<span class="sectionblue1">Information:</span> Profile "OTL: Transfer to OTLR and / or BEE" is set to "BEE only" at one/several levels, ');
						l_o('so OTLR Timecards will not be transferred.<br>');
					  end if;      
					  if issue16 then
						l_o('<span class="sectionblue1">Information:</span> Profile "OTL: Transfer to OTLR and / or BEE" is set to "OTLR only" at one/several levels, ');
						l_o('so Non-OTLR Timecards will not be transferred.<br>');
					  end if; 
					  if issue2 then
						l_o('<span class="sectionblue1">Information:</span> Profile "HXT: Holiday Hours from Holiday Calendar" is set to Y ');
						l_o('at one/several levels, this will auto-generate the holidays from the Holiday Calendar.<br>');
					  end if;      
					  if issue3 then
						l_o('<span class="sectionblue1">Information:</span> Profile "HXT: Holiday Hours from Holiday Calendar" is set to N ');
						l_o('at one/several levels, this will auto-generate the holidays from the Workplan.<br>');
					  end if;  
					  if issue4 then
						l_o('<span class="sectionblue1">Information:</span> Profile "HXT: Rollup Batch Hours" is set to Y at one/several levels, ');
						l_o('so Elements will be rolled up when transferring them to BEE.<br>');
					  end if;      
					  if issue5 then
						l_o('<span class="sectionblue1">Information:</span> Profile "HXT: Rollup Batch Hours" is set to N at one/several levels, ');
						l_o('so Elements will be not be rolled up when transferring them to BEE.<br>');
					  end if; 				  
					  if issue8 then
						l_o('<span class="sectionblue1">Information:</span> Profile "OTL: Defer approval process on timecard submission" is set to Y ');
						l_o('at one/several levels, so Workflow will not be automatically invoked when timecards are submitted.<br>');
					  end if;      
					  if issue9 then
						l_o('<span class="sectionblue1">Information:</span> Profile "OTL: Defer approval process on timecard submission" is set to N ');
						l_o('at one/several levels, so Workflow will be invoked automatically for each timecard submitted.<br>');
					  end if;
					  l_o('</div>');
				  end if;
				  if issue10 or issue12 or issue14 or issue17 then
					l_o('<div class="diverr">');
						  if issue10 then
							l_o('<img class="error_ico"><font color="red">Error:</font> Profile "OTL: Max Errors" is less than 500 at one/several levels. ');
							l_o('Please increase it to 1000.<br>');
							:e4:=:e4+1;
						  end if;				  
						  if issue12 then
							l_o('<span class="sectionred">Error: </span>Profile "OTL: Number of past days for which retrieval considers changes (days)" is less than 8 at one/several levels. ');
							l_o('This is a very small period of time to consider changes for timecards. Recommended value is 365 days.<br>');
							:e4:=:e4+1;
						  end if;					 
						  if issue14 then
							l_o('<img class="error_ico"><font color="red">Error:</font> Profile "OTL: Transfer Batch Size" is less than 50 at one/several levels.<br>');
							l_o('Please refer <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1304058.1" target="_blank">Note 1304058.1</a> ');
							l_o('Transfer Time From OTL to BEE Batch Size for Optimal Performance.<br>');
							:e4:=:e4+1;
						  end if;				 
						  if issue17 then
							l_o('<img class="error_ico"><font color="red">Error:</font> Profile "PA: Autoapprove Timesheets" is set to Y at one/several levels. ');
							l_o('Any Projects Timecard will be autoapproved regardless of Approval Style in OTL. This overrides OTL setup.<br>');
							:e4:=:e4+1;
						  end if;       
						l_o('</div>');
				  end if;
			end if;
			
			
		end if;		

		
		 
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
	
end;


-- Display Security profile details
procedure security is
	run_type varchar2(20):='&1';
       
    cursor security is
    select security_profile_id, nvl(security_profile_name,'null') from PER_SECURITY_PROFILES 
	order by upper(security_profile_name);
    v_sec_id PER_SECURITY_PROFILES.security_profile_id%type;
	v_sec_name PER_SECURITY_PROFILES.security_profile_name%type;
begin
       	
    if upper(run_type)='ALL'  then
				
			l_o('<a name="security"></a>');						
						l_o('<DIV class=divItem>');
						l_o('<DIV id="s1sql49b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql49'');" href="javascript:;">&#9654; Security Profile Details</A></DIV>');
                        l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql49" style="display:none" >');
                        l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        l_o('   <TH COLSPAN=1 bordercolor="#DEE6EF">');
                        l_o('     <B>Security Profile Details</B></font></TD>');
                        l_o('     <TD bordercolor="#DEE6EF">');
                        l_o('<A class=detail  id="s1sql50b"  onclick="displayItem2(this,''s1sql50'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        l_o('   </TD>');
                        l_o(' </TR>');
                        l_o(' <TR id="s1sql50" style="display:none">');
                        l_o('    <TD colspan="1" height="60">');
                        l_o('       <blockquote><p align="left">');
                        l_o('        select security_profile_id, security_profile_name from PER_SECURITY_PROFILES  <br>');   
                        l_o('        order by upper(security_profile_name);<br>');  
    
                        l_o('          </blockquote><br>');
                        l_o('     </TD>');
                        l_o('   </TR>');
                        l_o(' <TR>');
                        l_o(' <TH><B>Security Profile ID</B></TD>');                        
                        l_o(' <TH><B>Security Profile Name</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open security;
                          loop
                                fetch security into v_sec_id ,  v_sec_name;
                                EXIT WHEN  security%NOTFOUND;
                                l_o('<TR><TD>'||v_sec_id||'</TD>'||chr(10)||'<TD>'||v_sec_name||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close security;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       

						l_o('<tr><td><A class=detail onclick="hideRow(''s1sql49'');" href="javascript:;">Collapse section</a></td></tr>');
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
						l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						l_o(' </TABLE> </div> ');
						
						l_o('<div class="divok">');
						 l_o('<span class="sectionblue1">Advice:</span> Please review ');
						 l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=394083.1" target="_blank">Note 394083.1</a> ');
						 l_o('Understanding and Using HRMS Security in Oracle HRMS<br>');
						 l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1266051.1" target="_blank">Note 1266051.1</a> ');
						 l_o('Troubleshooting eBusiness Suite HRMS Security Issues<br>');
						 l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1385633.1" target="_blank">Note 1385633.1</a> ');
						 l_o('Security, MultiOrg, and Multi Org Access Control(MOAC) support in relation to Oracle Human Resources applications<br>');		
						l_o('</div>');
						
						l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						
			            
       end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;

-- Display International Payroll usage
procedure international is
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';   
    cursor c_international is
    SELECT   fcr.argument1 international_legislation_code
				,ftv.territory_short_name, fcr.request_date
		FROM     fnd_concurrent_requests fcr
				,fnd_concurrent_programs fcp
				,fnd_territories_tl ftv
		WHERE    fcr.concurrent_program_id = fcp.concurrent_program_id
			 AND ftv.territory_code = fcr.argument1
			 AND ftv.LANGUAGE='US'
			 AND fcp.concurrent_program_name = 'PYINTSTU'; 
	
    v_code fnd_concurrent_requests.argument1%type;
	v_name fnd_territories_tl.territory_short_name%type;
	v_date fnd_concurrent_requests.request_date%type;
begin
       	
    if upper(run_type)='ALL' and upper(product) in ('ALL','PAY','HR')  then
				
			l_o('<a name="international"></a>');						
						l_o('<DIV class=divItem>');
						l_o('<DIV id="s1sql63b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql63'');" href="javascript:;">&#9654; International Payroll Usage</A></DIV>');
                        l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql63" style="display:none" >');
                        l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
                        l_o('     <B>Concurrent process International HRMS Setup</B></font></TD>');
                        l_o('     <TD bordercolor="#DEE6EF">');
                        l_o('<A class=detail  id="s1sql54b"  onclick="displayItem2(this,''s1sql64'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        l_o('   </TD>');
                        l_o(' </TR>');
                        l_o(' <TR id="s1sql64" style="display:none">');
                        l_o('    <TD colspan="1" height="60">');
                        l_o('       <blockquote><p align="left">');
                        l_o('        SELECT   fcr.argument1 international_legislation_code<br>');
						l_o('        ,ftv.territory_short_name, fcr.request_date<br>');
						l_o('        FROM     fnd_concurrent_requests fcr<br>');
						l_o('        ,fnd_concurrent_programs fcp<br>');
						l_o('        ,fnd_territories_tl ftv<br>');
						l_o('        WHERE    fcr.concurrent_program_id = fcp.concurrent_program_id<br>');
						l_o('        AND ftv.territory_code = fcr.argument1<br>');
						l_o('        AND ftv.LANGUAGE=''US''<br>');
						l_o('        AND fcp.concurrent_program_name = ''PYINTSTU'';	<br>');		   
                        l_o('          </blockquote><br>');
                        l_o('     </TD>');
                        l_o('   </TR>');
                        l_o(' <TR>');
                        l_o(' <TH><B>Country code</B></TD>');                        
                        l_o(' <TH><B>Country Name</B></TD>');
						l_o(' <TH><B>Date when concurrent request was performed</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open c_international;
                          loop
                                fetch c_international into v_code, v_name, v_date;
                                EXIT WHEN  c_international%NOTFOUND;
                                l_o('<TR><TD>'||v_code||'</TD>'||chr(10)||'<TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_date||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close c_international;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF">');
						l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						l_o(' </TABLE> </div> ');			
						
						
						l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						
			            
       end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;



-- Display Pay Legislation Rules
procedure pay_rules is
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';   
    cursor rules is
    select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules 
	order by LEGISLATION_CODE;
    V_LEG pay_legislation_rules.LEGISLATION_CODE%type;
	V_RULE_TYPE pay_legislation_rules.RULE_TYPE%type;
	V_RULE_MODE pay_legislation_rules.RULE_MODE%type;
begin
       	
    if upper(run_type)='ALL' and upper(product) in ('ALL','PAY')  then
				
			l_o('<a name="rules"></a>');						
						l_o('<DIV class=divItem>');
						l_o('<DIV id="s1sql53b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql53'');" href="javascript:;">&#9654; Pay Legislation Rules</A></DIV>');
                        l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql53" style="display:none" >');
                        l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                        l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
                        l_o('     <B>Pay Legislation Rules</B></font></TD>');
                        l_o('     <TD bordercolor="#DEE6EF">');
                        l_o('<A class=detail  id="s1sql54b"  onclick="displayItem2(this,''s1sql54'');" href="javascript:;">&#9654; Show SQL Script</A>');
                        l_o('   </TD>');
                        l_o(' </TR>');
                        l_o(' <TR id="s1sql54" style="display:none">');
                        l_o('    <TD colspan="1" height="60">');
                        l_o('       <blockquote><p align="left">');
                        l_o('        select LEGISLATION_CODE, RULE_TYPE, RULE_MODE from pay_legislation_rules  <br>');   
                        l_o('        order by LEGISLATION_CODE;<br>');     
                        l_o('          </blockquote><br>');
                        l_o('     </TD>');
                        l_o('   </TR>');
                        l_o(' <TR>');
                        l_o(' <TH><B>Legislation</B></TD>');                        
                        l_o(' <TH><B>Rule Type</B></TD>');
						l_o(' <TH><B>Rule Mode</B></TD>');
                          
                        :n := dbms_utility.get_time;
                        open rules;
                          loop
                                fetch rules into v_leg, v_rule_type, v_rule_mode;
                                EXIT WHEN  rules%NOTFOUND;
                                l_o('<TR><TD>'||v_leg||'</TD>'||chr(10)||'<TD>'||v_rule_type||'</TD>'||chr(10)||'<TD>'||v_rule_mode||'</TD> </TR>'||chr(10));	  
                          end loop;
                        close rules;
                        
                        :n := (dbms_utility.get_time - :n)/100;
                       

						l_o('<tr><td><A class=detail onclick="hideRow(''s1sql54'');" href="javascript:;">Collapse section</a></td></tr>');
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF">');
						l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
						l_o(' </TABLE> </div> ');			
						
						
						l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');						
			            
       end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display DATETRACK:ENABLED and PER_ENABLE_DTW4 profile settings for HR shared
procedure datatrack is
    run_type varchar2(20):='&1';
    v_level_id  varchar2(50);
    v_appl_id FND_PROFILE_OPTIONS.APPLICATION_ID%type;
    v_level varchar2(50);
    v_value FND_PROFILE_OPTION_VALUES.PROFILE_OPTION_VALUE%type;
    v_level_value FND_PROFILE_OPTION_VALUES.LEVEL_VALUE%type;
    profile_number number;
    issue1 boolean:=FALSE;
    issue2 boolean:=FALSE;
    
    cursor datetrack is
    select 
    decode(to_char(fpov.level_id),
                  '10001', 'Site',
                  '10002', 'Application') ,
    fpo.APPLICATION_ID,
    fpov.LEVEL_VALUE,
     decode(to_char(fpov.level_id),
                  '10001', 'Site',
                  '10002', nvl(app.application_short_name,to_char(fpov.level_value))),
    DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
    DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
    fpov.PROFILE_OPTION_VALUE)) 
    from FND_PROFILE_OPTIONS fpo,
    FND_PROFILE_OPTIONS_TL fpotl,
    FND_PROFILE_OPTION_VALUES fpov,
    FND_APPLICATION app
    where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME
    and    app.application_id (+) = fpov.level_value
    and fpo.PROFILE_OPTION_NAME like 'DATETRACK:ENABLED'
    and fpotl.PROFILE_OPTION_NAME like 'DATETRACK:ENABLED'
    and fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
    and fpotl.LANGUAGE = 'US'
    and fpov.PROFILE_OPTION_ID = 1208
    and fpov.LEVEL_ID IN (10001,10002)
    and   fpov.LEVEL_VALUE != '804';
    

    cursor enabledtw4 is
    select 
    decode(to_char(fpov.level_id),
                  '10001', 'Site',
                  '10002', 'Application') ,
    fpo.APPLICATION_ID ,
    fpov.LEVEL_VALUE,
     decode(to_char(fpov.level_id),
                  '10001', 'Site',
                  '10002', nvl(app.application_short_name,to_char(fpov.level_value))),
    DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
    DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
    fpov.PROFILE_OPTION_VALUE)) 
    from FND_PROFILE_OPTIONS fpo,
    FND_PROFILE_OPTIONS_TL fpotl,
    FND_PROFILE_OPTION_VALUES fpov,
    FND_APPLICATION app
    where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
    and    app.application_id (+) = fpov.level_value
    and   fpotl.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4' 
    and   fpo.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4'
    and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
    and   fpov.LEVEL_ID IN (10001,10002) 
    and   fpotl.LANGUAGE = 'US' 
    and   fpo.APPLICATION_ID = 800;


	
begin
    if (:hr_status='Shared') then
		select count(1) into profile_number
		from FND_PROFILE_OPTIONS fpo, 
		FND_PROFILE_OPTIONS_TL fpotl, 
		FND_PROFILE_OPTION_VALUES fpov
			where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
			and   fpo.PROFILE_OPTION_NAME like 'DATETRACK:ENABLED' 
			and   fpotl.PROFILE_OPTION_NAME like 'DATETRACK:ENABLED' 
			and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
			and   fpotl.LANGUAGE = 'US' 
			and   fpov.PROFILE_OPTION_VALUE='Y'
			and   fpov.PROFILE_OPTION_ID = 1208
			and   fpov.LEVEL_ID IN (10001,10002) 
			and   fpov.LEVEL_VALUE != '804';
		if profile_number>0 then
            issue1:=TRUE;
    end if;
             
	   
    select count(1) into profile_number
    from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov
		where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
		and   fpotl.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4' 
    and   fpo.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4'
		and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
		and   fpov.LEVEL_ID IN (10001,10002) 
		and   fpotl.LANGUAGE = 'US' 
		and   fpo.APPLICATION_ID = 800
    and fpov.PROFILE_OPTION_VALUE<>'N';
		
		if profile_number>0 then
                issue2:=TRUE;
    end if;
		
   		
		  if issue1 then
			:e4:=:e4+1;
			l_o('<DIV class=divItem>');
			l_o('<DIV id="s1sql29b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql29'');" href="javascript:;">&#9654; DateTrack:Enabled</A></DIV>');			
							l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql29" style="display:none" >');
							l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
							l_o('     <B>Incorrect settings</B></font></TD>');
							l_o('     <TD bordercolor="#DEE6EF">');
							l_o('<A class=detail  id="s1sql30b"  onclick="displayItem2(this,''s1sql30'');" href="javascript:;">&#9654; Show SQL Script</A>');
							l_o('   </TD>');
							l_o(' </TR>');
							l_o(' <TR id="s1sql30" style="display:none">');
							l_o('    <TD colspan="4" height="60">');
							l_o('       <blockquote><p align="left">');
							l_o('        select   decode(to_char(fpov.level_id),  <br>');   
							l_o('            ''10001'', ''Site'',<br>');
							l_o('         ''10002'', ''Application''),<br>');
							l_o('                     fpo.APPLICATION_ID, fpov.LEVEL_VALUE, <br>'); 
							l_o('                    decode(to_char(fpov.level_id),');
							l_o('                                 ''10001'', ''Site'',');
							l_o('                                 ''10002'', nvl(app.application_short_name,to_char(fpov.level_value))),');
							l_o('                   DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',');
							l_o('                   DECODE(fpov.PROFILE_OPTION_VALUE,''N'',''No'',');
							l_o('                   fpov.PROFILE_OPTION_VALUE)) ');
							l_o('            from FND_PROFILE_OPTIONS fpo,  <br>'); 
							l_o('             FND_PROFILE_OPTIONS_TL fpotl,  <br>'); 
							l_o('             FND_PROFILE_OPTION_VALUES fpov, <br>'); 
							l_o('             FND_APPLICATION app<br>'); 
							l_o('            where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME  <br>'); 
							l_o('            and    app.application_id (+) = fpov.level_value<br>'); 
							l_o('            and   fpo.PROFILE_OPTION_NAME = ''DATETRACK:ENABLED''  <br>'); 
							l_o('            and   fpotl.PROFILE_OPTION_NAME = ''DATETRACK:ENABLED''  <br>'); 
							l_o('            and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID  <br>'); 
							l_o('            and   fpotl.LANGUAGE = ''US''  <br>'); 
							l_o('            and   fpov.PROFILE_OPTION_VALUE=''Y'' <br>'); 
							l_o('            and   fpov.PROFILE_OPTION_ID = 1208 <br>'); 
							l_o('            and   fpov.LEVEL_ID IN (10001,10002)  <br>'); 
							l_o('            and   fpov.LEVEL_VALUE != ''804''; <br>');
		
							l_o('          </blockquote><br>');
							l_o('     </TD>');
							l_o('   </TR>');
							l_o(' <TR>');
							l_o(' <TH><B>Level</B></TD>');
							l_o(' <TH><B>Application ID</B></TD>');
							l_o(' <TH><B>Level Value</B></TD>');
							l_o(' <TH><B>Context</B></TD>');
							l_o(' <TH><B>Actual Incorrect Value (need to change to NULL)</B></TD>');
							  
							:n := dbms_utility.get_time;
							open datetrack;
							  loop
									fetch datetrack into v_level_id ,  v_appl_id , v_level_value, v_level, v_value ;
									EXIT WHEN  datetrack%NOTFOUND;
									l_o('<TR><TD>'||v_level_id||'</TD>'||chr(10)||'<TD>'||v_appl_id||'</TD>'||chr(10)||'<TD>'||v_level_value||'</TD>'||chr(10));
									l_o('<TD>'||v_level||'</TD>'||chr(10)||'<TD>'||v_value||'</TD> </TR>'||chr(10));	  
							  end loop;
							close datetrack;
							
							:n := (dbms_utility.get_time - :n)/100;
							l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
							l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							l_o(' </TABLE> </div> '); 
							
							l_o('<div class="diverr">');
							l_o('<img class="error_ico"><font color="red">Error:</font> Incorrect profile value for DateTrack:Enabled for above levels.</div><br>');
							
		   end if;
		   
		  if issue2 then
							:e4:=:e4+1;
							l_o('<DIV class=divItem>');
							l_o('<DIV id="s1sql31b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql31'');" href="javascript:;">&#9654; HR: Enable DTW4 defaulting</A></DIV>');
						  
							l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql31" style="display:none" >');
							l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
							l_o('     <B>Incorrect settings</B></font></TD>');
							l_o('     <TD bordercolor="#DEE6EF">');
							l_o('<A class=detail  id="s1sql32b"  onclick="displayItem2(this,''s1sql32'');" href="javascript:;">&#9654; Show SQL Script</A>');
							l_o('   </TD>');
							l_o(' </TR>');
							l_o(' <TR id="s1sql32" style="display:none">');
							l_o('    <TD colspan="4" height="60">');
							l_o('       <blockquote><p align="left">');
							l_o('        select   decode(to_char(fpov.level_id),  <br>');   
							l_o('            ''10001'', ''Site'',<br>');
							l_o('         ''10002'', ''Application''),<br>');
							l_o('                     fpo.APPLICATION_ID, fpov.LEVEL_VALUE, <br>'); 
							l_o('                    decode(to_char(fpov.level_id),');
							l_o('                                 ''10001'', ''Site'',');
							l_o('                                 ''10002'', nvl(app.application_short_name,to_char(fpov.level_value))),');
							l_o('                   DECODE(fpov.PROFILE_OPTION_VALUE,''Y'',''Yes'',');
							l_o('                   DECODE(fpov.PROFILE_OPTION_VALUE,''N'',''No'',');
							l_o('                   fpov.PROFILE_OPTION_VALUE))');
							l_o('            from FND_PROFILE_OPTIONS fpo,  <br>'); 
							l_o('             FND_PROFILE_OPTIONS_TL fpotl,  <br>'); 
							l_o('             FND_PROFILE_OPTION_VALUES fpov, <br>'); 
							l_o('             FND_APPLICATION app<br>'); 
							l_o('            where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME  <br>'); 
							l_o('            and    app.application_id (+) = fpov.level_value<br>'); 
							l_o('            and   fpo.PROFILE_OPTION_NAME = ''PER_ENABLE_DTW4''  <br>'); 
							l_o('            and   fpotl.PROFILE_OPTION_NAME = ''PER_ENABLE_DTW4''  <br>'); 
							l_o('            and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID  <br>'); 
							l_o('            and   fpotl.LANGUAGE = ''US''  <br>'); 
							l_o('            and   fpov.LEVEL_ID IN (10001,10002)  <br>'); 
							l_o('            and   fpov.LEVEL_VALUE = ''800''; <br>');        
							l_o('          </blockquote><br>');
							l_o('     </TD>');
							l_o('   </TR>');
							l_o(' <TR>');
							l_o(' <TH><B>Level</B></TD>');
							l_o(' <TH><B>Application ID</B></TD>');
							l_o(' <TH><B>Level Value</B></TD>');
							l_o(' <TH><B>Context</B></TD>');
							l_o(' <TH><B>Actual Incorrect Value (need to change to N)</B></TD>');
							  
							:n := dbms_utility.get_time;
							open enabledtw4;
							  loop
									fetch enabledtw4 into v_level_id ,  v_appl_id , v_level_value, v_level, v_value ;
									EXIT WHEN  enabledtw4%NOTFOUND;
									l_o('<TR><TD>'||v_level_id||'</TD>'||chr(10)||'<TD>'||v_appl_id||'</TD>'||chr(10)||'<TD>'||v_level_value||'</TD>'||chr(10));
									l_o('<TD>'||v_level||'</TD>'||chr(10)||'<TD>'||v_value||'</TD></TR>'||chr(10));	  
							  end loop;
							close enabledtw4;
							
							:n := (dbms_utility.get_time - :n)/100;
							l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
							l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							l_o(' </TABLE> </div> ');
							l_o('<div class="diverr">');
							l_o('<img class="error_ico"><font color="red">Error:</font> Incorrect profile value for HR: Enable DTW4 defaulting for above levels.</div>');
			end if;		
			
		if issue1 or issue2 then				
			l_o('<div class="diverr">');
			l_o('Please raise a service request with Oracle Support and refer to this section of output.<br>');
			l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1075831.1" target="_blank" >Note 1075831.1</a> ');
			l_o('Within Shared HR Environments What Types of Records Would You Expect to See in HR tables <br>');
            l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1476979.1" target="_blank" >Note 1476979.1</a> ');
			l_o('Shared HR Implementation - Things to check when doing an Oracle Human Resources Shared HR implementation.  <br>');
			l_o('</div>');
			
			l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
        end if;

	end if;
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;




-- Display pay_trigger_events
procedure pay_trigger is
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';	
	v_table pay_trigger_events.table_name%type;
    v_trigger pay_trigger_events.short_name%type;
	v1 pay_trigger_events.generated_flag%type;
	v2 pay_trigger_events.enabled_flag%type;
	v3 pay_trigger_components.enabled_flag%type;
    no_triggers number;
 	issue boolean := FALSE;
  cursor flag_triggers is
	  select pte.table_name, pte.short_name, pte.generated_flag,pte.enabled_flag, ptc.enabled_flag 
		from pay_trigger_events pte,
		pay_trigger_components ptc
		where (short_name like 'PER_%'
			 OR short_name like 'PAY_%')
		and pte.event_id = ptc.event_id(+)
		and (pte.generated_flag<>'Y' or pte.enabled_flag<>'Y' or ptc.enabled_flag<>'Y')
		order by pte.table_name;  

begin
	if upper(product) in ('PAY', 'ALL') then 
	  select count(1) into no_triggers from pay_trigger_events pte,
		pay_trigger_components ptc
		where (short_name like 'PER_%'
			 OR short_name like 'PAY_%')
		and pte.event_id = ptc.event_id(+)
		and (pte.generated_flag<>'Y' or pte.enabled_flag<>'Y' or ptc.enabled_flag<>'Y');
		if no_triggers>0 then
						issue:=TRUE;
		end if;
        
			if issue or upper(run_type)='ALL' then
				l_o(' <a name="pay_trigger_events"></a>');
				l_o('<DIV class=divItem>');
				l_o('<DIV id="s1sql51b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql51'');" href="javascript:;">&#9654; Pay Triggers Events</A></DIV>');		
				l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql51" style="display:none" >');
				l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
				l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
				l_o('     <B>Triggers with flag not set to Y:</B></font></TD>');
				l_o('     <TD bordercolor="#DEE6EF">');
				l_o('<A class=detail  id="s1sql52b"  onclick="displayItem2(this,''s1sql52'');" href="javascript:;">&#9654; Show SQL Script</A>');
				l_o('   </TD>');
				l_o(' </TR>');
				l_o(' <TR id="s1sql52" style="display:none">');
				l_o('    <TD colspan="2" height="60">');
				l_o('       <blockquote><p align="left">');
				
				l_o('          select pte.table_name, pte.short_name, pte.generated_flag,pte.enabled_flag, ptc.enabled_flag <br>');
				l_o('          from pay_trigger_events pte,<br>');
				l_o('          pay_trigger_components ptc<br>');
				l_o('          where (short_name like ''PER_%''<br>');
				l_o('          	 OR short_name like ''PAY_%'')<br>');
				l_o('          and pte.event_id = ptc.event_id(+)<br>');
				l_o('          and (pte.generated_flag<>''Y'' or pte.enabled_flag<>''Y'' or ptc.enabled_flag<>''Y'')<br>');
				l_o('          order by pte.table_name; <br>');

				l_o('          </blockquote><br>');
				l_o('     </TD>');
				l_o('   </TR>');
				l_o(' <TR>');
				l_o(' <TH><B>Table name</B></TD>');		
				l_o(' <TH><B>Trigger Name</B></TD>');
				l_o(' <TH><B>Generated flag</B></TD>');
				l_o(' <TH><B>Enabled flag - events</B></TD>');
				l_o(' <TH><B>Enabled flag - components</B></TD>');
			
				:n := dbms_utility.get_time;
			
				open flag_triggers;
					  loop
						 fetch flag_triggers into v_table,v_trigger,v1,v2,v3;
						 EXIT WHEN  flag_triggers%NOTFOUND;
						 l_o('<TR><TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD>'||chr(10));
						 if v1<>'Y' then
							l_o('<TD><font color="red">'||v1||'</font></TD>'||chr(10));
						 else
							l_o('<TD>'||v1||'</TD>'||chr(10));
						 end if;
						 if v2<>'Y' then
							l_o('<TD><font color="red">'||v2||'</font></TD>'||chr(10));
						 else
							l_o('<TD>'||v2||'</TD>'||chr(10));
						 end if;
						 if v3<>'Y' then
							l_o('<TD><font color="red">'||v3||'</font></TD></TR>'||chr(10));
						 else
							l_o('<TD>'||v3||'</TD>'||chr(10));
						 end if;								 
					  end loop;
				close flag_triggers;    
			 
				:n := (dbms_utility.get_time - :n)/100;
				l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
				l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
				l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
				l_o(' </TABLE> </div> ');
				
				
				if issue  then
					l_o('<div class="divwarn">');
					l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You have trigger(s) with flag not set to Y (not set or set to N).<br>');		
					l_o('</div>');	
					:w4:=:w4+1;					
				elsif upper(run_type)='ALL' then             
					l_o('<div class="divok">');
					l_o('<img class="check_ico">OK!  All triggers have flag set on Y.<br>');
					l_o('</div>');
				end if;
				
				
				l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
			end if;	
	end if;
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');	
end;




-- Display PAY_ACTION parameters
procedure pay_action is
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_pay_name pay_action_parameters.parameter_name%type; 
	v_pay_value pay_action_parameters.parameter_value%type;
	v_min_ini_trans number;
	v_cpu number;
	v_rows number;
	status_leg varchar2(2);
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue8 boolean := FALSE;
	issue9 boolean := FALSE;
	issue10 boolean := FALSE;
	cursor pay_action is
	select parameter_name, nvl(parameter_value,'null') 
      from pay_action_parameters
	  order by parameter_name;

begin
select count(1) 
			 into v_rows
			  from hr_legislation_installations
			 where Legislation_code = 'GB'  and status='I';
if v_rows>0 then
l_o(' <a name="ssp"></a>');
select count(1) into v_rows from ssp_temp_affected_rows;
if upper(run_type)='ALL' or v_rows>0 then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql84b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql84'');" href="javascript:;">&#9654; SSP_TEMP_AFFECTED_ROWS</A></DIV>');
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql84" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('     <B>SSP_TEMP_AFFECTED_ROWS rows</B></font></TD><TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql10b"  onclick="displayItem2(this,''s1sql85'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD></TR><TR id="s1sql85" style="display:none"><TD colspan="1" height="60">');
		l_o(' <blockquote><p align="left">select count(1) from SSP_TEMP_AFFECTED_ROWS</blockquote><br></TD></TR><TR>');
		l_o(' <TH><B>Count of rows</B></TD>');	
		:n := dbms_utility.get_time;
		l_o('<TR><TD>'||v_rows||'</TD></TR>'||chr(10));			
		:n := (dbms_utility.get_time - :n)/100;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
	
		if v_rows>0 then
			l_o('<div class="divwarn">');
			l_o('<img class="warn_ico">For Oracle Support: SSP_TEMP_AFFECTED_ROWS table has rows.</div>');
			:w4:=:w4+1;
		else
				l_o('<div class="divok">');
				l_o('OK! No rows in SSP_TEMP_AFFECTED_ROWS<br>');
				l_o('</div>');
		end if;			
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
	end if;
end if;	

l_o(' <a name="pay_action"></a>');

if upper(product)='PAY' or upper(product)='ALL' then
	
	SELECT SUBSTR(value, 1, 10)
						into v_cpu
						FROM v$parameter
						WHERE name = 'cpu_count';
	select decode(status, null,'N','I')
						into status_leg
						from hr_legislation_installations
						where substr(application_short_name,1,4)='PAY'
						and  Legislation_code = 'US';
						
	select count(1) into v_rows from pay_action_parameters where parameter_name='RANGE_PERSON_ID';
	if v_rows=0 then
		issue1:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='RANGE_PERSON_ID';
		if v_pay_value <>'Y' then
			issue1:=TRUE;
		end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name='LOW_VOLUME';
	if v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='LOW_VOLUME';
		if v_pay_value <>'N' then
			issue2:=TRUE;
		end if;
	end if;
	
	if status_leg='I' then
			select count(1) into v_rows from pay_action_parameters where parameter_name='TAX_LIBRARIES';
			if v_rows=0 then
				issue3:=TRUE;
			elsif v_rows=1 then
				select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='TAX_LIBRARIES';
				if v_pay_value is NULL then
					issue3:=TRUE;
				end if;
			end if;
			select count(1) into v_rows from pay_action_parameters where parameter_name='TAX_DATA';
			if v_rows=0 then
				issue3:=TRUE;
			elsif v_rows=1 then
				select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='TAX_DATA';
				if v_pay_value is NULL then
					issue3:=TRUE;
				end if;
			end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name='THREADS';
	v_pay_value:=1;
	if v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name='THREADS';
	elsif v_rows=0 then
		v_pay_value:=1;
	end if;
	if v_pay_value<1.5*v_cpu or v_pay_value>2*v_cpu then
		issue5:=TRUE;
	end if;						
	SELECT min(ini_trans)
						into v_min_ini_trans
						FROM DBA_TABLES
						WHERE table_name IN ('FF_ARCHIVE_ITEMS'
                          ,'FF_ARCHIVE_ITEM_CONTEXTS'
                          ,'PAY_ACTION_INFORMATION'
                          ,'PAY_ASSIGNMENT_ACTIONS'
                          ,'PAY_ASSIGNMENT_LATEST_BALANCES'
                          ,'PAY_BALANCE_CONTEXT_VALUES'
                          ,'PAY_COSTS'
                          ,'PAY_DEFINED_BALANCES'
                          ,'PAY_ELEMENT_ENTRIES_F'
                          ,'PAY_ELEMENT_ENTRY_VALUES_F'
                          ,'PAY_INPUT_VALUES_F'
                          ,'PAY_PAYROLL_ACTIONS'
                          ,'PAY_PERIODS_OF_SERVICE'
                          ,'PAY_PERSON_LATEST_BALANCES'
                          ,'PAY_POPULATION_RANGES'
                          ,'PAY_PRE_PAYMENTS'
                          ,'PAY_RUN_BALANCES'
                          ,'PAY_RUN_RESULTS'
                          ,'PAY_RUN_RESULT_VALUES'
                          ,'PAY_US_RPT_TOTALS'
                          ,'PER_ALL_ASSIGNMENTS_F'
                          ,'PER_ALL_PEOPLE_F');
	if v_pay_value>v_min_ini_trans then
		issue6:=TRUE;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'RR%BUFFER%SIZE';
	if v_rows=0 then
		issue7:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'RR%BUFFER%SIZE';
		if v_pay_value <100 then
			issue7:=TRUE;
		end if;
	end if;
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'RRV%BUFFER%SIZE';
	if v_rows=0 then
		issue8:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'RRV%BUFFER%SIZE';
		if v_pay_value <100 then
			issue8:=TRUE;
		end if;
	end if;	
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'BAL%BUFFER%SIZE';
	if v_rows=0 then
		issue9:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like 'BAL%BUFFER%SIZE';
		if v_pay_value <100 then
			issue9:=TRUE;
		end if;
	end if;	
	select count(1) into v_rows from pay_action_parameters where parameter_name like 'EE%BUFFER%SIZE';
	if v_rows=0 then
		issue10:=TRUE;
	elsif v_rows=1 then
		select nvl(parameter_value,'null') into v_pay_value from pay_action_parameters where parameter_name like'EE%BUFFER%SIZE';
		if v_pay_value <100 then
			issue10:=TRUE;
		end if;
	end if;	
	
	if upper(run_type)='ALL' or issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql9b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql9'');" href="javascript:;">&#9654; PAY Action Parameters</A></DIV>');
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql9" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('     <B>PAY action parameters</B></font></TD><TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql10b"  onclick="displayItem2(this,''s1sql10'');" href="javascript:;">&#9654; Show SQL Script</A></TD></TR>');
		l_o(' <TR id="s1sql10" style="display:none"><TD colspan="1" height="60"><blockquote><p align="left">select parameter_name, parameter_value <br>');
		l_o('          from pay_action_parameters<br>order by parameter_name</blockquote><br></TD></TR><TR>');
		l_o(' <TH><B>Name</B></TD><TH><B>Value</B></TD>');
	
		:n := dbms_utility.get_time;
		
		open pay_action;
		loop
			fetch pay_action into v_pay_name,v_pay_value;
			EXIT WHEN  pay_action%NOTFOUND;
			l_o('<TR><TD>'||v_pay_name||'</TD>'||chr(10)||'<TD>');
			l_o(v_pay_value);
			l_o('</TD></TR>'||chr(10));
          
		end loop;
		close pay_action;

		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql9'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> </TABLE> </div> ');
	
		if issue1 or issue2 or issue3 or issue4 then
			l_o('<div class="diverr">');
			if issue1 then
				l_o('<img class="error_ico"><font color="red">Error:</font> Please set RANGE_PERSON_ID to Y<br>');
				:e4:=:e4+1;
			end if;
			
			if issue2 then
				l_o('<img class="error_ico"><font color="red">Error:</font> Please set LOW_VOLUME to N<br>');
				:e4:=:e4+1;
			end if;
			
			if issue3 then
				l_o('<img class="error_ico"><font color="red">Error:</font> Please set TAX_LIBRARIES<br>');
				:e4:=:e4+1;
			end if;
			
			if issue4 then
				l_o('<img class="error_ico"><font color="red">Error:</font> Please set TAX_DATA<br>');
				:e4:=:e4+1;
			end if;
			l_o('</div>');
		end if;
		
		if issue5 or issue6 or issue7 or issue8 or issue9 or issue10 then
			l_o('<div class="divwarn">');
			if issue5 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set Threads to 1.5 to 2 times the number of processors, ');
				l_o('meaning between '||ceil(1.5*v_cpu)||' and '||ceil(2*v_cpu)||' <br>');
				l_o('<span class="sectionblue1">Advice:</span> Check <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=359354.1" target="_blank">Note 359354.1</a> ');
				l_o('How to Determine the Best Setting for the THREADS Parameter in the Pay_Action_Parameters Table<br>');
				:w4:=:w4+1;
			end if;
			
			if issue6 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please ensure the number of threads set in PAY_ACTION_PARAMETERS is the same ');
				l_o('or lower than the ini_trans on hot PAY tables <br>');
				:w4:=:w4+1;
			end if;
			
			if issue7 or issue8 or issue9 or issue10 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> If trace files show differences between execute and fetch timings, then worth having a look at buffer sizes:<br>');
				if issue7 then
					l_o(' - Try setting RR BUFFER SIZE to 100.<br>');
				end if;
				if issue8 then
					l_o(' - Try setting RRV BUFFER SIZE to 100.<br>');
				end if;
				if issue9 then
					l_o(' - Try setting BAL BUFFER SIZE to 100.<br>');
				end if;
				if issue10 then
					l_o(' - Try setting EE BUFFER SIZE to 100.<br>');
				end if;
				:w4:=:w4+1;
			end if;
			
			l_o('</div>');
		end if;
		
		l_o('<div class="divok"><span class="sectionblue1">Advice:</span> Please review:<br> ');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=549367.1" target="_blank">Note 549367.1</a> ');
		l_o('Oracle Human Resources Payroll PAY_ACTION_PARAMETERS Comprehensive Overview<br>');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=226987.1" target="_blank">Note 226987.1</a> ');
		l_o('Oracle 11i and R12 Human Resources and Benefits Tuning and System Health Checks<br></div>');
		
		if (not issue1) and (not issue2) and (not issue3) and (not issue4) and (not issue5) and (not issue6) and (not issue7) and (not issue8) and (not issue9) and (not issue10) then
				l_o('<div class="divok">');
				l_o('Verified parameters are correctly set<br>');
				l_o('</div>');
		end if;			
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
	end if;	
end if;

EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;

-- check if is hr org
FUNCTION bg_hr_org_ck (p_org_id IN integer)
  RETURN varchar2
IS
  l_dummy   varchar2 (3);
BEGIN
  SELECT   1
  INTO     l_dummy
  FROM     hr_organization_information hoi
  WHERE    1 = 1
       AND hoi.org_information_context = 'CLASS'
       AND org_information1 = 'HR_ORG'
       AND organization_id = p_org_id;

  l_dummy     := 'Yes';
  return l_dummy;
EXCEPTION
  WHEN no_data_found
  THEN
    l_dummy     := 'No';
    return l_dummy;
END;

-- Display Setup Group settings
procedure setup_group is
    run_type varchar2(20):='&1';
    bg_id number;
    org_id number;
    org_name HR_ALL_ORGANIZATION_UNITS.NAME%type;
    legislation PER_BUSINESS_GROUPS.LEGISLATION_CODE%type;
    currency PER_BUSINESS_GROUPS.CURRENCY_CODE%type;
    profile_number number;
    issue1 boolean := FALSE;
    issue2 boolean := FALSE;
    issue3 boolean := FALSE;
	cursor c_bg is
		SELECT o.business_group_id,otl.name,o.organization_id,o3.ORG_INFORMATION9 legislation_code
			,hr_general_utilities.get_lookup_meaning('EMP_NUM_GEN_METHOD',o3.org_information2)
			,hr_general_utilities.get_lookup_meaning('APL_NUM_GEN_METHOD',o3.org_information3)
			,hr_general_utilities.get_lookup_meaning('CWK_NUM_GEN_METHOD',o3.org_information16)
			,o3.ORG_INFORMATION10 currency_code,o4.ORG_INFORMATION2 enabled_flag ,to_char(o.date_from , 'DD-MON-YYYY'),to_char(o.date_to, 'DD-MON-YYYY')
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;       
	  v_bg_id HR_ALL_ORGANIZATION_UNITS.BUSINESS_GROUP_ID%type;
	  v_bg_id_old HR_ALL_ORGANIZATION_UNITS.BUSINESS_GROUP_ID%type;
	  v_org_id HR_ALL_ORGANIZATION_UNITS.ORGANIZATION_ID%type;
	  v_name HR_ALL_ORGANIZATION_UNITS.NAME%type;
	  v_leg PER_BUSINESS_GROUPS.LEGISLATION_CODE%type;
	  v_emp fnd_lookups.meaning%type;
	  v_apl fnd_lookups.meaning%type;
	  v_cwk fnd_lookups.meaning%type;
	  v_cur PER_BUSINESS_GROUPS.CURRENCY_CODE%type;
	  v_enabled PER_BUSINESS_GROUPS.ENABLED_FLAG%type;
	  v_date_from varchar2(15);
	  v_date_to varchar2(15);
	  v_hr varchar2(3);
	
begin
   
	select count(1) into profile_number
		FROM HR_ALL_ORGANIZATION_UNITS O , 
		HR_ALL_ORGANIZATION_UNITS_TL OTL , 
		HR_ORGANIZATION_INFORMATION O2 ,
		HR_ORGANIZATION_INFORMATION O3 , 
		HR_ORGANIZATION_INFORMATION O4 
		WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
		AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
		AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
		AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
		AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
		AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
		AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
		AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
		AND OTL.LANGUAGE = 'US'
		and O.ORGANIZATION_ID=0;
		if profile_number>0 then
             select o.business_group_id, 
             o.organization_id, 
             otl.name, 
             o3.ORG_INFORMATION9, 
             o3.ORG_INFORMATION10
              into bg_id,org_id,org_name,legislation,currency
            FROM HR_ALL_ORGANIZATION_UNITS O , 
				HR_ALL_ORGANIZATION_UNITS_TL OTL , 
				HR_ORGANIZATION_INFORMATION O2 ,
				HR_ORGANIZATION_INFORMATION O3 , 
				HR_ORGANIZATION_INFORMATION O4 
				WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
				AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
				AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
				AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
				AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
				AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
				AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
				AND OTL.LANGUAGE = 'US'
				and O.ORGANIZATION_ID=0;
            
            if legislation<>'US' then
                issue1:=TRUE;
            end if;
            if currency<>'USD' then
                issue2:=TRUE;
            end if;
            if org_name<>'Setup Business Group' then
                issue3:=TRUE;
            end if;   
            
                 
       end if;
	    if upper(run_type)='ALL' or issue1 or issue2 or issue3 then
				
                  l_o('<a name="setup"></a>');
                 
				 		l_o('<DIV class=divItem>');
						l_o('<DIV id="s1sql65b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql65'');" href="javascript:;">&#9654; Business Group Details</A></DIV>');		
						l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql65" style="display:none" >');
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF"><TH COLSPAN=11 bordercolor="#DEE6EF">');
						l_o('     <B>Business Group details:</B></font></TD><TD bordercolor="#DEE6EF">');
						l_o('<A class=detail  id="s1sql66b"  onclick="displayItem2(this,''s1sql66'');" href="javascript:;">&#9654; Show SQL Script</A>');
						l_o('   </TD></TR><TR id="s1sql66" style="display:none"><TD colspan="11" height="60"><blockquote><p align="left">');
						l_o('SELECT o.business_group_id,otl.name,o.organization_id,o3.ORG_INFORMATION9 legislation_code<br>');
						l_o(',hr_general_utilities.get_lookup_meaning(''EMP_NUM_GEN_METHOD'',o3.org_information2)<br>');
						l_o(',hr_general_utilities.get_lookup_meaning(''APL_NUM_GEN_METHOD'',o3.org_information3)<br>');
						l_o(',hr_general_utilities.get_lookup_meaning(''CWK_NUM_GEN_METHOD'',o3.org_information16)<br>');
						l_o(',o3.ORG_INFORMATION10 currency_code,o4.ORG_INFORMATION2 enabled_flag ,o.date_from ,o.date_to<br>');
						l_o('FROM HR_ALL_ORGANIZATION_UNITS O,HR_ALL_ORGANIZATION_UNITS_TL OTL ,HR_ORGANIZATION_INFORMATION O2 ,HR_ORGANIZATION_INFORMATION O3 , HR_ORGANIZATION_INFORMATION O4 <br>');
						l_o('WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) <br>');
						l_o('AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID <br>');
						l_o('AND O3.ORG_INFORMATION_CONTEXT = ''Business Group Information'' AND O2.ORG_INFORMATION_CONTEXT (+) = ''Work Day Information'' <br>');
						l_o('AND O4.ORG_INFORMATION_CONTEXT = ''CLASS'' AND O4.ORG_INFORMATION1 = ''HR_BG'' AND O4.ORG_INFORMATION2 = ''Y'' AND OTL.LANGUAGE = ''US''<br>');			
						l_o('ORDER BY   1;<br></blockquote><br></TD></TR>');
						l_o(' <TR>');						
						l_o(' <TH><B>Bussines Group ID</B></TD>');
						l_o(' <TH><B>Organization ID</B></TD>');
						l_o(' <TH><B>Organization Name</B></TD>');						
						l_o(' <TH><B>Legislation Code</B></TD>');
						l_o(' <TH><B>Employee number generation</B></TD>');
						l_o(' <TH><B>Applicant number generation</B></TD>');
						l_o(' <TH><B>Contingent worker numb gen</B></TD>');
						l_o(' <TH><B>Currency Code</B></TD>');
						l_o(' <TH><B>Enabled Flag</B></TD>');
						l_o(' <TH><B>Date From</B></TD>');
						l_o(' <TH><B>Date To</B></TD>');
						l_o(' <TH><B>Is HR ORG</B></TD>');						
						
						:n := dbms_utility.get_time;
						 open c_bg;
						  loop
							fetch c_bg into v_bg_id,v_name,v_org_id,v_leg,v_emp,v_apl,v_cwk,v_cur,v_enabled,v_date_from,v_date_to;					
							EXIT WHEN  c_bg%NOTFOUND;
							v_hr:= bg_hr_org_ck(v_org_id);
							l_o('<TR><TD>'||v_bg_id||'</TD>'||chr(10)||'<TD>'||v_org_id||'</TD>'||chr(10));							
							l_o('<TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_leg||'</TD>'||chr(10));
							l_o('<TD>'||v_emp||'</TD>'||chr(10)||'<TD>'||v_apl||'</TD>'||chr(10));
								l_o('<TD>'||v_cwk||'</TD>'||chr(10)||'<TD>'||v_cur||'</TD>'||chr(10)||'<TD>'||v_enabled||'</TD>'||chr(10));
								l_o('<TD>'||v_date_from||'</TD>'||chr(10)||'<TD>'||v_date_to||'</TD>'||chr(10)||'<TD>'||v_hr||'</TD></TR>'||chr(10));	
						  end loop;
						  close c_bg;
						  
						  :n := (dbms_utility.get_time - :n)/100;
					l_o('<tr><td><A class=detail onclick="hideRow(''s1sql65'');" href="javascript:;">Collapse section</a></td></tr>');
					l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
					l_o(' <TH COLSPAN=11 bordercolor="#DEE6EF">');
					l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
					l_o(' </TABLE> </div> ');
				
				if issue1 or issue2 or issue3 then
					 l_o('<div class="diverr">');
					  if issue1 then
							l_o('<img class="error_ico"><font color="red">Error:</font> Current legislation is ' || legislation || ' (is not US).');
							l_o(' Changing the Legislation of the Setup Business Group is never allowed under any condition!<br>');
							:e4:=:e4+1;
					  end if;
					  if issue2 then
							l_o('<img class="error_ico"><font color="red">Error:</font> Current currency is ' || currency || ' (is not USD).');
							l_o(' Changing the Currency of the Setup Business Group is never allowed under any condition!<br>');
							:e4:=:e4+1;
					  end if;
					  if issue3 then
							l_o('<img class="error_ico"><font color="red">Error:</font> Current organization name for Setup Business Group is ' || org_name || ' (is not Setup Business Group).');
							l_o(' Setup Business Group Name should not be changed!<br>');
							:e4:=:e4+1;
					  end if;				  
                        l_o('Please raise a service request with Oracle Support and refer to this section of output.<br>');        
                        l_o('Please review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=815934.1" target="_blank" >Note 815934.1</a> ');
						l_o('After Upgrade - Setup Business Group Name Reverts Back To Setup Business Group<br>');
                        l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=796593.1" target="_blank" >Note 796593.1</a> ');
						l_o('Can the Setup Business Group name be Changed? ');
						l_o('</div>');
                  end if;
                 				  
				  
                  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
            end if;
          
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display Employee numbering
procedure employee_numbering is
    run_type varchar2(20):='&1';
	product varchar2(20):='&2';
    issue1 boolean := FALSE;
    issue2 boolean := FALSE;
	v_rows number;
	cursor c_package is
		select OWNER, NAME, TEXT   from   ALL_SOURCE
		   where  UPPER(NAME) like UPPER('%NUMBER_GENERATION%')
		   and    OWNER = 'APPS'   and    TEXT like '%$Header%'
		   order  by NAME;
	v_owner ALL_SOURCE.OWNER%type;
	v_name ALL_SOURCE.NAME%type;
	v_text ALL_SOURCE.TEXT%type;
	cursor c_formula is
		select FUNCTION_ID,CLASS,NAME,BUSINESS_GROUP_ID,DATA_TYPE,DEFINITION,LAST_UPDATED_BY,LAST_UPDATE_DATE,LEGISLATION_CODE,DESCRIPTION 
		from FF_FUNCTIONS_V 
		   where UPPER(DATA_TYPE) = UPPER('number') 
		   and UPPER(DEFINITION) like UPPER('%NUM%GEN%');	 
	v_funct FF_FUNCTIONS_V.FUNCTION_ID%type;
	v_class FF_FUNCTIONS_V.CLASS%type;
	v_name2 FF_FUNCTIONS_V.NAME%type;
	v_bg FF_FUNCTIONS_V.BUSINESS_GROUP_ID%type;	
	v_bg_old FF_FUNCTIONS_V.BUSINESS_GROUP_ID%type;	
	v_date_type FF_FUNCTIONS_V.DATA_TYPE%type;
	v_definition FF_FUNCTIONS_V.DEFINITION%type;
	v_lby FF_FUNCTIONS_V.LAST_UPDATED_BY%type;
	v_ldate FF_FUNCTIONS_V.LAST_UPDATE_DATE%type;
	v_leg FF_FUNCTIONS_V.LEGISLATION_CODE%type;
	v_desc FF_FUNCTIONS_V.DESCRIPTION%type;
	cursor c_next is
		  SELECT BUSINESS_GROUP_ID, TYPE, NEXT_VALUE 
		   FROM PER_NUMBER_GENERATION_CONTROLS
		   WHERE TYPE IN ('EMP','APL', 'CWK')
		   order by 1,2;
	v_type PER_NUMBER_GENERATION_CONTROLS.TYPE%type;
	v_next PER_NUMBER_GENERATION_CONTROLS.NEXT_VALUE%type;
	
	v_max_e_no varchar2(50);
	v_max_a_no varchar2(50);
	v_max_n_no varchar2(50);
	
begin
    if upper(product) in ('HR','SSHR','ALL') then
	
	select count(1) into v_rows from   ALL_SOURCE
		   where  UPPER(NAME) like UPPER('%NUMBER_GENERATION%')
		   and    OWNER = 'APPS'
		   and    TEXT like '%$Header%';
	if v_rows>0 then
		issue1:=true;
	end if;
    select count(1) into v_rows from FF_FUNCTIONS_V 
		   where UPPER(DATA_TYPE) = UPPER('number') 
		   and UPPER(DEFINITION) like UPPER('%NUM%GEN%'); 
	if v_rows>0 then
		issue1:=true;
	end if;
	
    if upper(run_type)='ALL' or issue1 or issue2 then
		l_o('<a name="employee"></a>');
                 
				 		l_o('<DIV class=divItem>');
						l_o('<DIV id="s1sql67b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql67'');" href="javascript:;">&#9654; Employee Numbering Details</A></DIV>');		
						l_o('<DIV id="s1sql67" style="display: none;">');
						
						if issue1 then
							l_o('<A class=detail onclick="displayItem(this,''s1sql68'');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Custom Number Generation Packages</A>');
							l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql68" style="display:none" >');
							l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
							l_o('     <B>Custom Number Generation Packages:</B></font></TD>');
							l_o('     <TD bordercolor="#DEE6EF">');
							l_o('<A class=detail  id="s1sql69b"  onclick="displayItem2(this,''s1sql69'');" href="javascript:;">&#9654; Show SQL Script</A>');
							l_o('   </TD>');
							l_o(' </TR>');
							l_o(' <TR id="s1sql69" style="display:none">');
							l_o('    <TD colspan="2" height="60">');
							l_o('       <blockquote><p align="left">');			
							l_o('               select OWNER, NAME, TEXT   from   ALL_SOURCE<br>');
							l_o('               where  UPPER(NAME) like UPPER(''%NUMBER_GENERATION%'')<br>');
							l_o('               and    OWNER = ''APPS''   and  TEXT like ''%$Header%''<br>');
							l_o('               order  by NAME;<br>');
							l_o('          </blockquote><br>');
							l_o('     </TD>');
							l_o('   </TR>');
							l_o(' <TR>');
							l_o(' <TH><B>Owner</B></TD>');
							l_o(' <TH><B>Name</B></TD>');
							l_o(' <TH><B>Text</B></TD>');						
							
							:n := dbms_utility.get_time;
							
							open c_package;
								  loop
									fetch c_package into v_owner,v_name,v_text;
									EXIT WHEN  c_package%NOTFOUND;
									l_o('<TR><TD>'||v_owner||'</TD>'||chr(10));							
									l_o('<TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_text||'</TD></TR>'||chr(10));	
								  end loop;
							close c_package;
							
							
							:n := (dbms_utility.get_time - :n)/100;
							l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF">');
							l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							l_o(' </TABLE>  ');
						end if;
						
						if issue2 then
							l_o('<br><br><A class=detail onclick="displayItem(this,''s1sql70'');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Custom Number Generation FF FAST FORMULA</A>');
							l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql70" style="display:none" >');
							l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							l_o('   <TH COLSPAN=9 bordercolor="#DEE6EF">');
							l_o('     <B>Custom Number Generation FF FAST FORMULA:</B></font></TD>');
							l_o('     <TD bordercolor="#DEE6EF">');
							l_o('<A class=detail  id="s1sql48b"  onclick="displayItem2(this,''s1sql71'');" href="javascript:;">&#9654; Show SQL Script</A>');
							l_o('   </TD>');
							l_o(' </TR>');
							l_o(' <TR id="s1sql71" style="display:none">');
							l_o('    <TD colspan="9" height="60">');
							l_o('       <blockquote><p align="left">');
							l_o('select FUNCTION_ID,CLASS,NAME,BUSINESS_GROUP_ID,DATA_TYPE,DEFINITION,LAST_UPDATED_BY,LAST_UPDATE_DATE,LEGISLATION_CODE,DESCRIPTION<br>'); 
							l_o('from FF_FUNCTIONS_V<br>'); 
							l_o('   where UPPER(DATA_TYPE) = UPPER(''number'') <br>');
							l_o('   and UPPER(DEFINITION) like UPPER(''%NUM%GEN%'');<br>');
							l_o('          </blockquote><br>');
							l_o('     </TD>');
							l_o('   </TR>');
							l_o(' <TR>');
							l_o(' <TH><B>Function ID</B></TD>');
							l_o(' <TH><B>Class</B></TD>');
							l_o(' <TH><B>Name</B></TD>');
							l_o(' <TH><B>Business Group ID</B></TD>');
							l_o(' <TH><B>Data Type</B></TD>');
							l_o(' <TH><B>Definition</B></TD>');
							l_o(' <TH><B>Last updated by</B></TD>');
							l_o(' <TH><B>Last update date</B></TD>');	
							l_o(' <TH><B>Legislation code</B></TD>');
							l_o(' <TH><B>Description</B></TD>');
							
							:n := dbms_utility.get_time;
							open c_formula;
								  loop
									fetch c_formula into v_funct,v_class,v_name2,v_bg,v_date_type,v_definition,v_lby,v_ldate,v_leg,v_desc;
									EXIT WHEN  c_formula%NOTFOUND;
									l_o('<TR><TD>'||v_funct||'</TD>'||chr(10)||'<TD>'||v_class||'</TD>'||chr(10));							
									l_o('<TD>'||v_name2||'</TD>'||chr(10)||'<TD>'||v_bg||'</TD>'||chr(10));
									l_o('<TD>'||v_date_type||'</TD>'||chr(10)||'<TD>'||v_definition||'</TD>'||chr(10)||'<TD>'||v_lby||'</TD>'||chr(10));
									l_o('<TD>'||v_ldate||'</TD>'||chr(10)||'<TD>'||v_leg||'</TD>'||chr(10)||'<TD>'||v_desc||'</TD></TR>'||chr(10));	
								  end loop;
							close c_formula;						
							
							:n := (dbms_utility.get_time - :n)/100;
							l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
							l_o(' <TH COLSPAN=9 bordercolor="#DEE6EF">');
							l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
							l_o(' </TABLE><br>');
						end if;
						
						l_o('<br><A class=detail onclick="displayItem(this,''s1sql72'');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Next sequence number used to create a new employee number</A>');
						l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql72" style="display:none" >');
						l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
						l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
						l_o('     <B>Next sequence number details:</B></font></TD>');
						l_o('     <TD bordercolor="#DEE6EF">');
						l_o('<A class=detail  id="s1sql73b"  onclick="displayItem2(this,''s1sql73'');" href="javascript:;">&#9654; Show SQL Script</A>');
						l_o('   </TD>');
						l_o(' </TR>');
						l_o(' <TR id="s1sql73" style="display:none">');
						l_o('    <TD colspan="2" height="60">');
						l_o('       <blockquote><p align="left">');
						l_o('SELECT BUSINESS_GROUP_ID, TYPE, NEXT_VALUE<br>'); 
					    l_o('FROM PER_NUMBER_GENERATION_CONTROLS<br>');
					    l_o('WHERE TYPE IN (''EMP'',''APL'', ''CWK'')<br>');
					    l_o('order by 1,2;<br>');						
						l_o('          </blockquote><br>');
						l_o('     </TD>');
						l_o('   </TR>');
						l_o(' <TR>');
						l_o(' <TH><B>Business Group ID</B></TD>');
						l_o(' <TH><B>Type</B></TD>');
						l_o(' <TH><B>Next Value</B></TD>');						
						v_bg_old:=-1;
						
						:n := dbms_utility.get_time;
						 open c_next;
						  loop
							fetch c_next into v_bg,v_type,v_next;
							EXIT WHEN  c_next%NOTFOUND;
							if  v_bg<>v_bg_old then
								l_o('<TR><TD>'||v_bg||'</TD>'||chr(10));
							else
								l_o('<TR><TD></TD>'||chr(10));
							end if;
							l_o('<TD>'||v_type||'</TD>'||chr(10)||'<TD>'||v_next||'</TD></TR>'||chr(10));
							v_bg_old:=v_bg;							
						  end loop;
						  close c_next;
						  
						  :n := (dbms_utility.get_time - :n)/100;
					l_o('<tr><td><A class=detail onclick="hideRow(''s1sql72'');" href="javascript:;">Collapse section</a></td></tr>');
					l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
					l_o(' <TH COLSPAN=2 bordercolor="#DEE6EF">');
					l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
					l_o(' </TABLE>  ');
					
					l_o('<br><br><A class=detail onclick="displayItem(this,''s1sql74'');" href="javascript:;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9654; Max values for Employee/Applicant/NPW numbers</A>');
					l_o('<DIV id="s1sql74" style="display: none;">');
					SELECT 	MAX(TO_CHAR(employee_number)), MAX(TO_CHAR(applicant_number)),MAX(TO_CHAR(npw_number))
					   into v_max_e_no,v_max_a_no,v_max_n_no
					   FROM PER_ALL_PEOPLE_F;
					l_o('<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MAX Employee Number is: '||v_max_e_no||'<br>');
					l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MAX Applicant Number is: '||v_max_a_no||'<br>');
					l_o('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MAX NPW Number is: '||v_max_n_no||'<br>');
					l_o('</div>');

					l_o('</div></div>');
				
				if issue1 or issue2 then
					 l_o('<div class="divwarn">');
					  if issue1 then
							l_o('<font color="#CC3311">Warning:</font> Custom Number Generation Package available!<br>');
							:w4:=:w4+1;
					  end if;
					  if issue2 then
							l_o('<font color="#CC3311">Warning:</font> Custom Number Generation FF FAST FORMULA available!<br>');
							:w4:=:w4+1;
					  end if;
					  l_o('Custom Number Generation Using FastFormula is used as per internal Note 279458.1 How To Implement Custom Person Numbering Using FastFormula<br>');
					  l_o('DISCLAIMER: While this functionality was released by Oracle HR Development with 11i.HR_PF.H patch 3233333 ');
					  l_o('any implementation making use of this feature is purely a Customization.<br>');
					  l_o('Oracle Support Services will not support these FF Fast Formulas nor the associated Functions.<br>');
					  l_o('It is up to the customer to create and diagnose any code used to implement this functionality.<br>');
					  l_o('</div>');
                  end if;
                 				  
				  
                  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
            end if;
                
       end if;
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;



-- Display database initialization parameters
procedure database is
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_db_parameter v$parameter.name%type; 	
	v_db_value v$parameter.value%type;
	database_version	varchar2(100);
	apps_version	varchar2(50);
	issue1 varchar2(100) := '';
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	cursor db_init is
	select name, nvl(value,'null') from v$parameter 
      where name in ('max_dump_file_size','timed_statistics'
	  ,'user_dump_dest','compatible'
	  ,'sql_trace'
	  ,'utl_file_dir','_optimizer_autostats_job')
      order by name;
	cursor db_init2 is
			select name, nvl(value,'null') from v$parameter order by name;

begin
 

	l_o(' <a name="db_init_ora"></a>');

	select banner into database_version from V$VERSION WHERE ROWNUM = 1;
	apps_version:=:apps_rel;
	
	open db_init;
	loop
          fetch db_init into v_db_parameter,v_db_value;
          EXIT WHEN  db_init%NOTFOUND;
		  CASE v_db_parameter
				when 'compatible' then 
					CASE
						when database_version like '%8.1%' then
							if v_db_value<>'8.1.7' then
								issue1:='Please set Compatible parameter to 8.1.7';
							end if;
						when database_version like '%9.2%' then
							if v_db_value<>'9.2.0' then
								issue1:='Please set Compatible parameter to 9.2.0';
							end if;
						when database_version like '%10.1%' then
							if v_db_value<>'10.1.0' then
								issue1:='Please set Compatible parameter to 10.1.0';
							end if;
						when database_version like '%10.2%' then
							if v_db_value<>'10.2.0' then
								issue1:='Please set Compatible parameter to 10.2.0';
							end if;
						when database_version like '%11.1%' then
							if v_db_value<>'11.1.0' then
								issue1:='Please set Compatible parameter to 11.1.0';
							end if;
						when database_version like '%11.2%' then
							if v_db_value<>'11.2.0' then
								issue1:='Please set Compatible parameter to 11.2.0';
							end if;
						when database_version like '%12.1%' then
							if v_db_value<>'12.1.0' then
								issue1:='Please set Compatible parameter to 12.1.0';
							end if;
						else
							null;
					end case;
				when 'max_dump_file_size' then
					if v_db_value <>'UNLIMITED' then
						issue2:=TRUE;
					end if;
				when '_optimizer_autostats_job' then					
						if database_version like '%11.1%' or database_version like '%11.2%' then
							if v_db_value <>'FALSE' then
								issue3:=TRUE;
							end if;	
						end if;					
				when 'timed_statistics' then					
						if database_version like '%8.1%' or database_version like '%9.2%' or database_version like '%10.1%' or database_version like '%10.2%' then
							if v_db_value <> 'TRUE' then
								issue4:=TRUE;
							end if;	
						end if;								
				else
					null;
			END CASE;
			
          
    end loop;
    close db_init;
	
	if upper(run_type)='ALL' or issue1<>'' or issue2 or issue3 or issue4 then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql11b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql11'');" href="javascript:;">&#9654; Database Initialization Parameters</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="1" id="s1sql11" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('     <B>Database parameters</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql12b"  onclick="displayItem2(this,''s1sql12'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql12" style="display:none">');
		l_o('    <TD colspan="1" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         select name, value from v$parameter <br>');		
		l_o('         order by name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Parameter</B></TD>');
		l_o(' <TH><B>Value</B></TD>');
	
		:n := dbms_utility.get_time;
		open db_init2;
		loop
			fetch db_init2 into v_db_parameter,v_db_value;
			EXIT WHEN  db_init2%NOTFOUND;
			l_o('<TR><TD>'||v_db_parameter||'</TD>'||chr(10)||'<TD>');
			l_o(v_db_value);
			l_o('</TD></TR>'||chr(10));
          
		end loop;
		close db_init2;

		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql11'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
		
		if issue1<>'' or issue3 or issue4 then
			l_o('<div class="divwarn">');		
			if issue1<>'' then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span>'||issue1||'<br>');
				:w2:=:w2+1;
			end if;
							
			if issue3 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set _optimizer_autostats_job to FALSE<br>');
				:w2:=:w2+1;
			end if;
			
			if issue4 then
				l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set timed_statistics to TRUE<br>');
				:w2:=:w2+1;
			end if;		
			l_o('</div>');
		end if;
		
		l_o('<div class="divok">');
		if issue2 then			
			l_o('<span class="sectionblue1">Advice:</span> If you need to run a trace please set Max_dump_file_size = UNLIMITED<br>');
		end if;
		l_o('<span class="sectionblue1">Advice:</span> If you have performance issue please ensure you have correct database initialization parameters as per ');
		if apps_version like '12.%' then
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=396009.1" target="_blank">Note 396009.1</a> Database Initialization Parameters for Oracle E-Business Suite Release 12<br>');
		else 
			l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=216205.1" target="_blank">Note 216205.1</a> Database Initialization Parameters for Oracle Applications Release 11i<br>');
		end if;
		l_o('Use <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=174605.1" target="_blank">Note 174605.1</a> bde_chk_cbo.sql - EBS initialization parameters - Healthcheck<br>');
		l_o('This will help you to identify the difference between actual values and required values. Verify that all Mandatory Parameters - MP are set correctly<br><br>');
		if upper(product) in ('PAY', 'ALL') then
			l_o('Review also <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		end if;
		
		
		if issue1='' and (not issue2) and (not issue3) and (not issue4) then
				l_o('Verified parameters are correctly set');
		end if;	
		l_o('</div>');
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
	end if;
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;


-- Display status, last run of gather schema statistics concurrent request
procedure gather is
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  status_all varchar2(100);
  status_hr varchar2(100);
  status_hxc varchar2(100);
  status_hxt varchar2(100);
  status_pa varchar2(100);
  status_ben varchar2(100);
  status_ota varchar2(100);
  last_date_all date;
  last_date_hr date;
  last_date_hxc date;
  last_date_hxt date;
  last_date_pa date;
  last_date_ben date;
  last_date_ota date;
  last_date_normal date;
  status2 varchar2(100);
  last_date2 date;
  need_run boolean:=FALSE;
  days number;
  no_rows number;
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  issue5 boolean:=FALSE;
  issue6 boolean:=FALSE;
  issue7 boolean:=FALSE;
  issue8 boolean:=FALSE;
  issue9 boolean:=FALSE;
  issue10 boolean:=FALSE;
  issue11 boolean:=FALSE;
  issue12 boolean:=FALSE;
  issue13 boolean:=FALSE;
  issue14 boolean:=FALSE;
  issue15 boolean:=FALSE;
  issue16 boolean:=FALSE;
  issue17 boolean:=FALSE;
  issue18 boolean:=FALSE;
  issue19 boolean:=FALSE;
  issue20 boolean:=FALSE;
  issue21 boolean:=FALSE;
  v_PROG_SCHEDULE_TYPE varchar2(100);
  v_PROG_SCHEDULE varchar2(400);
  v_USER_NAME fnd_user.user_name%type;
  v_START_DATE fnd_concurrent_requests.requested_start_date%type;
  v_ARGUMENT_TEXT FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_all FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_hr FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_hxc FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_hxt FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_pa FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_ben FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_ARGUMENT_TEXT_ota FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
begin
      select count(1) into no_rows
      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL');
        
      if no_rows=0 then
          issue1:=TRUE;
      else
          SELECT * 
          into status_all,last_date_all,v_ARGUMENT_TEXT_all
          FROM (
          SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
           ,ACTUAL_COMPLETION_DATE pEndDate,ARGUMENT_TEXT        
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
            AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
          ORDER BY 2 desc)
          where rownum < 2;
      
          if instr(upper(status_all),upper('Completed Normal'))=0 then 
              issue2:=TRUE;			  
          else
              select  sysdate-last_date_all into days from dual;
              if days>7 then
                    issue3:=TRUE;
              end if;
          end if;
        end if;
        
        
      select count(1) into no_rows
      FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,');
        
      if no_rows=0 then
          issue4:=TRUE;
      else
          SELECT * 
          into status_hr,last_date_hr,v_ARGUMENT_TEXT_hr
          FROM (
          SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
           ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
            AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
          ORDER BY 2 desc)
          where rownum < 2;
      
          if instr(upper(status_hr),upper('Completed Normal'))=0 then 
              issue5:=TRUE;
          else
              select  sysdate-last_date_hr into days from dual;
              if days>7 then
                    issue6:=TRUE;
              end if;
          end if;
        end if;
                        

           
--OTL checks      
      if upper(product) in ('OTL','ALL') then
      -- HXC gather schema statistics
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC');
                
              if no_rows=0 then
                  issue7:=TRUE;
              else
                  SELECT * 
                  into status_hxc,last_date_hxc,v_ARGUMENT_TEXT_hxc
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate,ARGUMENT_TEXT        
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC')
                  ORDER BY 2 desc)
                  where rownum < 2;
                  
                  if instr(upper(status_hxc),upper('Completed Normal'))=0 then 
                      issue8:=TRUE;
                  else
                      select  sysdate-last_date_hxc into days from dual;
                      if days>7 then
                            issue9:=TRUE;
                      end if;
                  end if;
                end if;
              
              -- HXT gather schema statistics
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT');
                
              if no_rows=0 then
                  issue10:=TRUE;
              else
                  SELECT * 
                  into status_hxt,last_date_hxt,v_ARGUMENT_TEXT_hxt
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT')
                  ORDER BY 2 desc)
                  where rownum < 2;
              
                  if instr(upper(status_hxt),upper('Completed Normal'))=0 then 
                      issue11:=TRUE;
                  else
                      select  sysdate-last_date_hxt into days from dual;
                      if days>7 then
                            issue12:=TRUE;
                      end if;
                  end if;
                  
                end if;
              
              -- PA gather schema statistics  
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,');
                
              if no_rows=0 then
                  issue13:=TRUE;
              else
                  SELECT * 
                  into status_pa,last_date_pa,v_ARGUMENT_TEXT_pa
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,')
                  ORDER BY 2 desc)
                  where rownum < 2;
              
                  if instr(upper(status_pa),upper('Completed Normal'))=0 then 
                      issue14:=TRUE;
                  else
                      select  sysdate-last_date_pa into days from dual;
                      if days>7 then
                            issue15:=TRUE;
                      end if;
                  end if;
                  
                end if;
      end if;  


-- BEN checks
      if upper(product) in ('BEN','ALL') then
      -- BEN gather schema statistics
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN');
                
              if no_rows=0 then
                  issue16:=TRUE;
              else
                  SELECT * 
                  into status_ben,last_date_ben,v_ARGUMENT_TEXT_ben
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN')
                  ORDER BY 2 desc)
                  where rownum < 2;
                  
                  if instr(upper(status_ben),upper('Completed Normal'))=0 then 
                      issue17:=TRUE;
                  else
                      select  sysdate-last_date_ben into days from dual;
                      if days>7 then
                            issue18:=TRUE;
                      end if;
                  end if;
                end if;
	 end if;
	 

-- OTA checks
      if upper(product) in ('OTA','ALL') then
      -- OTA gather schema statistics
              select count(1) into no_rows
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA');
                
              if no_rows=0 then
                  issue19:=TRUE;
              else
                  SELECT * 
                  into status_ota,last_date_ota,v_ARGUMENT_TEXT_ota
                  FROM (
                  SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
                   ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
                  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
                    AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA')
                  ORDER BY 2 desc)
                  where rownum < 2;
                  
                  if instr(upper(status_ota),upper('Completed Normal'))=0 then 
                      issue20:=TRUE;
                  else
                      select  sysdate-last_date_ota into days from dual;
                      if days>7 then
                            issue21:=TRUE;
                      end if;
                  end if;
                end if;
	 end if;
	 
      if upper(run_type)='ALL' or issue1 or issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 or issue11 or issue12 or issue13 or issue14 or issue15 or issue16 or issue17 or issue18 or issue19 or issue20 or issue21 then
                    
                    l_o(' <a name="gather"></a>');
                    l_o('<DIV class=divItem>');
					l_o('<DIV id="s1sql13b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql13'');" href="javascript:;">&#9654; Gather Statistics</A></DIV>');                    
                    l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="4" id="s1sql13" style="display:none" >');
                    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                    l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
                    l_o('     <B>Statistics</B></TD>');
                    l_o('     <TD bordercolor="#DEE6EF">');
                    l_o('<A class=detail  id="s1sql14b"  onclick="displayItem2(this,''s1sql14'');" href="javascript:;">&#9654; Show SQL Script</A>');
                    l_o('   </TD>');
                    l_o(' </TR>');
                    l_o(' <TR id="s1sql14" style="display:none">');
                    l_o('    <TD colspan="4" height="60">');
                    l_o('       <blockquote><p align="left">');
                    l_o('          SELECT PHAS.MEANING || '' '' || STAT.MEANING pStatus <br>');                        
                    l_o('                     ,ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT      <br>');  
                    l_o('                      FROM FND_CONC_REQ_SUMMARY_V fcrs<br>');
                    l_o('                     , FND_LOOKUPS STAT<br>');
                    l_o('                     , FND_LOOKUPS PHAS<br>');
                    l_o('                      WHERE STAT.LOOKUP_CODE = FCRS.STATUS_CODE<br>');
                    l_o('                     AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE''<br>');
                    l_o('                     AND PHAS.LOOKUP_CODE = FCRS.PHASE_CODE<br>');
                    l_o('                      AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE''<br>');
                    l_o('                      AND (UPPER(program) LIKE ''GATHER SCHEMA%''<br>');
                    l_o('                      AND substr(UPPER(ARGUMENT_TEXT),1,3) in (''HR,'',''ALL''<br>');
                    case upper(product)
					when 'OTL' then
                        l_o('                      ,''HXC'',''HXT'',''PA,''');    
                    when 'BEN' then
                        l_o('                      ,''BEN''');    
                    when 'OTA' then
                        l_o('                      ,''OTA''');
					when 'ALL' then
						l_o('                      ,''BEN'',''HXC'',''HXT'',''PA,'',''OTA''');
					else
						null;
					end case;
                    l_o('                      ))<br>');
                    l_o('                      ORDER BY 2 desc<br>');

                    l_o('          </blockquote><br>');
                    l_o('     </TD>');
                    l_o('   </TR>');
                    l_o(' <TR>');
                    l_o(' <TH><B>Request</B></TD>');
                    l_o(' <TH><B>Status</B></TD>');
                    l_o(' <TH><B>Last run</B></TD>');
					l_o(' <TH><B>Last Time Completed Normal</B></TD>');
					l_o(' <TH><B>Scheduling</B></TD>');
					
					begin
                    :n := dbms_utility.get_time;
                    
                    l_o('<TR><TD>'||'Gather Schema Statistics for ALL'||'</TD>'||chr(10));
                    if issue1 then
                          l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
						  :p1:='never';
                    elsif issue2 then
							if instr(upper(status_all),'ERROR')=0 then 
                                      issue2:=FALSE;
							end if;		  
							select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
							if no_rows>0 then
								SELECT * 
								  into last_date_normal,v_ARGUMENT_TEXT
								  FROM (
								  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
								  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
								  ORDER BY 1 desc)
								  where rownum < 2;
								  :p1:=last_date_normal;
								  l_o('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_normal||' with parameters:');
								  l_o(v_ARGUMENT_TEXT);
								  l_o('</TD>'||chr(10));
								  select  sysdate-last_date_normal into days from dual;
								  if days>7 then
										issue3:=TRUE;
										last_date_all:=last_date_normal;
								  else
										issue3:=FALSE;
								  end if;
							else
								l_o('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
								l_o('<TD>never</TD>'||chr(10));
								issue2:=TRUE;
								:p1:='never';
							end if;
					else
                          l_o('<TD>'||status_all||'</TD>'||chr(10)||'<TD>'||last_date_all||'</TD>'||chr(10));
						  l_o('<TD>'||last_date_all||' with parameters:');
						  l_o(v_ARGUMENT_TEXT_all);
						  l_o('</TD>'||chr(10));
						  :p1:=last_date_all;
                    end if;
					select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL');
					if no_rows=0 then
								l_o('<TD>no scheduling</TD></TR>'||chr(10));
					else						  
								select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
								SELECT 
									 NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
									 DECODE(NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
									 'PERIODICALLY',
									 'EVERY ' || fcr.resubmit_interval || ' ' ||
									 fcr.resubmit_interval_unit_code || ' FROM ' ||
									 fcr.resubmit_interval_type_code || ' OF PREV RUN',
									 'ONCE',
									 'AT :' ||
									 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
									 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
									 fu.user_name USER_NAME,
									 requested_start_date START_DATE									
									 FROM fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('ALL')
									ORDER BY 2 desc)
									where rownum < 2;
								  
								  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
								  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
					end if;
                    
                    l_o('<TR><TD>'||'Gather Schema Statistics for HR'||'</TD>'||chr(10));
                    if issue4 then
                          l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
						  :p2:='never';
                    elsif issue5 then
							if instr(upper(status_hr),'ERROR')=0 then 
                                      issue5:=FALSE;
							end if;
							select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
							if no_rows>0 then
								SELECT * 
								  into last_date_normal,v_ARGUMENT_TEXT
								  FROM (
								  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
								  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
								  ORDER BY 1 desc)
								  where rownum < 2;
								  :p2:=last_date_normal;
								  l_o('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_normal||' with parameters:');
								  l_o(v_ARGUMENT_TEXT);
								  l_o('</TD>'||chr(10));
								  select  sysdate-last_date_normal into days from dual;
								  if days>7 then
										issue6:=TRUE;
										last_date_hr:=last_date_normal;
								  else
										issue6:=FALSE;
								  end if;
							else
								l_o('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
								l_o('<TD>never</TD>'||chr(10));
								issue5:=TRUE;
								:p2:='never';
							end if;
					else
                          l_o('<TD>'||status_hr||'</TD>'||chr(10)||'<TD>'||last_date_hr||'</TD>'||chr(10));
						  l_o('<TD>'||last_date_hr||' with parameters:');
						  l_o(v_ARGUMENT_TEXT_hr);
						  l_o('</TD>'||chr(10));
						  :p2:=last_date_hr;
                    end if;
					select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,');
					
					if no_rows=0 then
								l_o('<TD>no scheduling</TD></TR>'||chr(10));
					else						  
								select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
								SELECT 
									 NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
									 DECODE(NVL2(fcr.resubmit_interval,
									 'PERIODICALLY',
									 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
									 'PERIODICALLY',
									 'EVERY ' || fcr.resubmit_interval || ' ' ||
									 fcr.resubmit_interval_unit_code || ' FROM ' ||
									 fcr.resubmit_interval_type_code || ' OF PREV RUN',
									 'ONCE',
									 'AT :' ||
									 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
									 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
									 fu.user_name USER_NAME,
									 requested_start_date START_DATE
									 FROM fnd_concurrent_programs_tl fcpt,
									 fnd_concurrent_requests fcr,
									 fnd_user fu,
									 fnd_conc_release_classes fcrc
									 WHERE fcpt.application_id = fcr.program_application_id
									 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
									 AND fcr.requested_by = fu.user_id
									 AND fcr.phase_code = 'P'
									 AND fcr.requested_start_date > SYSDATE
									 AND fcpt.LANGUAGE = 'US'
									 AND fcrc.release_class_id(+) = fcr.release_class_id
									 AND fcrc.application_id(+) = fcr.release_class_app_id
									 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
									AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,')
									ORDER BY 2 desc)
									where rownum < 2;
								  
								  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
								  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
					end if;
                    
					
                    if upper(product) in ('OTL','ALL') then
                          l_o('<TR><TD>'||'Gather Schema Statistics for HXC'||'</TD>'||chr(10));
                          if issue7 then
								  l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue8 then
									if instr(upper(status_hxc),'ERROR')=0 then 
                                      issue8:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  l_o('<TD>'||status_hxc||'</TD>'||chr(10)||'<TD>'||last_date_hxc||'</TD>'||chr(10));
										  l_o('<TD>'||last_date_normal||' with parameters:');
										  l_o(v_ARGUMENT_TEXT);
										  l_o('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue9:=TRUE;
												last_date_hxc:=last_date_normal;
										  else
												issue9:=FALSE;
										  end if;
									else
										l_o('<TD>'||status_hxc||'</TD>'||chr(10)||'<TD>'||last_date_hxc||'</TD>'||chr(10));
										l_o('<TD>never</TD>'||chr(10));
										issue8:=TRUE;
									end if;
							else
								  l_o('<TD>'||status_hxc||'</TD>'||chr(10)||'<TD>'||last_date_hxc||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_hxc||' with parameters:');
								  l_o(v_ARGUMENT_TEXT_hxc);
								  l_o('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC');
							
							if no_rows=0 then
										l_o('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE											 
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXC')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                          
                          l_o('<TR><TD>'||'Gather Schema Statistics for HXT'||'</TD>'||chr(10));
                          if issue10 then
								  l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue11 then
									if instr(upper(status_hxt),'ERROR')=0 then 
                                      issue11:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  l_o('<TD>'||status_hxt||'</TD>'||chr(10)||'<TD>'||last_date_hxt||'</TD>'||chr(10));
										  l_o('<TD>'||last_date_normal||' with parameters:');
										  l_o(v_ARGUMENT_TEXT);
										  l_o('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue12:=TRUE;
												last_date_hxt:=last_date_normal;
										  else
												issue12:=FALSE;
										  end if;
									else
										l_o('<TD>'||status_hxt||'</TD>'||chr(10)||'<TD>'||last_date_hxt||'</TD>'||chr(10));
										l_o('<TD>never</TD>'||chr(10));
										issue11:=TRUE;
									end if;
							else
								  l_o('<TD>'||status_hxt||'</TD>'||chr(10)||'<TD>'||last_date_hxt||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_hxt||' with parameters:');
								  l_o(v_ARGUMENT_TEXT_hxt);
								  l_o('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT');
							
							if no_rows=0 then
										l_o('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE											 
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HXT')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                          
                          l_o('<TR><TD>'||'Gather Schema Statistics for PA'||'</TD>'||chr(10));
                          		if issue13 then
								  l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue14 then
									if instr(upper(status_pa),'ERROR')=0 then 
                                      issue14:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT        
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  l_o('<TD>'||status_pa||'</TD>'||chr(10)||'<TD>'||last_date_pa||'</TD>'||chr(10));
										  l_o('<TD>'||last_date_normal||' with parameters:');
										  l_o(v_ARGUMENT_TEXT);
										  l_o('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue15:=TRUE;
												last_date_pa:=last_date_normal;
										  else
												issue15:=FALSE;
										  end if;
									else
										l_o('<TD>'||status_pa||'</TD>'||chr(10)||'<TD>'||last_date_pa||'</TD>'||chr(10));
										l_o('<TD>never</TD>'||chr(10));
										issue14:=TRUE;
									end if;
							else
								  l_o('<TD>'||status_pa||'</TD>'||chr(10)||'<TD>'||last_date_pa||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_pa||' with parameters:');
								  l_o(v_ARGUMENT_TEXT_pa);
								  l_o('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,');
							
							if no_rows=0 then
										l_o('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('PA,')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                    end if;
					
					if upper(product) in ('BEN','ALL') then
                          l_o('<TR><TD>'||'Gather Schema Statistics for BEN'||'</TD>'||chr(10));
                          	if issue16 then
								  l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue17 then
									if instr(upper(status_ben),'ERROR')=0 then 
                                      issue17:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT       
										  FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  l_o('<TD>'||status_ben||'</TD>'||chr(10)||'<TD>'||last_date_ben||'</TD>'||chr(10));
										  l_o('<TD>'||last_date_normal||' with parameters:');
										  l_o(v_ARGUMENT_TEXT);
										  l_o('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue18:=TRUE;
												last_date_ben:=last_date_normal;
										  else
												issue18:=FALSE;
										  end if;
									else
										l_o('<TD>'||status_ben||'</TD>'||chr(10)||'<TD>'||last_date_ben||'</TD>'||chr(10));
										l_o('<TD>never</TD>'||chr(10));
										issue17:=TRUE;
									end if;
							else
								  l_o('<TD>'||status_ben||'</TD>'||chr(10)||'<TD>'||last_date_ben||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_ben||' with parameters:');
								  l_o(v_ARGUMENT_TEXT_ben);
								  l_o('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN');
							
							if no_rows=0 then
										l_o('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE											
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('BEN')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                    end if;
					
					if upper(product) in ('OTA','ALL') then
                          l_o('<TR><TD>'||'Gather Schema Statistics for OTA'||'</TD>'||chr(10));
                          	if issue19 then
								  l_o('<TD>'||'no run'||'</TD>'||chr(10)||'<TD>'||'no run'||'</TD><TD>no run</TD>'||chr(10));
							elsif issue20 then
									if instr(upper(status_ota),'ERROR')=0 then 
                                      issue20:=FALSE;
									end if;
									select count(1) into no_rows FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal';
									if no_rows>0 then
										SELECT * 
										  into last_date_normal,v_ARGUMENT_TEXT
										  FROM (
										  SELECT ACTUAL_COMPLETION_DATE pEndDate, ARGUMENT_TEXT       
										 FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA')
											and PHAS.MEANING='Completed' and STAT.MEANING='Normal'
										  ORDER BY 1 desc)
										  where rownum < 2;
										  l_o('<TD>'||status_ota||'</TD>'||chr(10)||'<TD>'||last_date_ota||'</TD>'||chr(10));
										  l_o('<TD>'||last_date_normal||' with parameters:');
										  l_o(v_ARGUMENT_TEXT);
										  l_o('</TD>'||chr(10));
										  select  sysdate-last_date_normal into days from dual;
										  if days>7 then
												issue18:=TRUE;
												last_date_ota:=last_date_normal;
										  else
												issue18:=FALSE;
										  end if;
									else
										l_o('<TD>'||status_ota||'</TD>'||chr(10)||'<TD>'||last_date_ota||'</TD>'||chr(10));
										l_o('<TD>never</TD>'||chr(10));
										issue20:=TRUE;
									end if;
							else
								  l_o('<TD>'||status_ota||'</TD>'||chr(10)||'<TD>'||last_date_ota||'</TD>'||chr(10));
								  l_o('<TD>'||last_date_ota||' with parameters:');
								  l_o(v_ARGUMENT_TEXT_ota);
								  l_o('</TD>'||chr(10));
							end if;
							select count(1) into no_rows from fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA');
							
							if no_rows=0 then
										l_o('<TD>no scheduling</TD></TR>'||chr(10));
							else						  
										select * into v_PROG_SCHEDULE_TYPE, v_PROG_SCHEDULE,v_user_name,v_START_DATE from (
										SELECT 
											 NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')) PROG_SCHEDULE_TYPE,
											 DECODE(NVL2(fcr.resubmit_interval,
											 'PERIODICALLY',
											 NVL2(fcr.release_class_id, 'ON SPECIFIC DAYS', 'ONCE')),
											 'PERIODICALLY',
											 'EVERY ' || fcr.resubmit_interval || ' ' ||
											 fcr.resubmit_interval_unit_code || ' FROM ' ||
											 fcr.resubmit_interval_type_code || ' OF PREV RUN',
											 'ONCE',
											 'AT :' ||
											 TO_CHAR(fcr.requested_start_date, 'DD-MON-RR HH24:MI'),
											 'EVERY: ' || fcrc.class_info) PROG_SCHEDULE,
											 fu.user_name USER_NAME,
											 requested_start_date START_DATE											
											 FROM fnd_concurrent_programs_tl fcpt,
											 fnd_concurrent_requests fcr,
											 fnd_user fu,
											 fnd_conc_release_classes fcrc
											 WHERE fcpt.application_id = fcr.program_application_id
											 AND fcpt.concurrent_program_id = fcr.concurrent_program_id
											 AND fcr.requested_by = fu.user_id
											 AND fcr.phase_code = 'P'
											 AND fcr.requested_start_date > SYSDATE
											 AND fcpt.LANGUAGE = 'US'
											 AND fcrc.release_class_id(+) = fcr.release_class_id
											 AND fcrc.application_id(+) = fcr.release_class_app_id
											 and upper(fcpt.user_concurrent_program_name) LIKE 'GATHER SCHEMA%'
											AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('OTA')
											ORDER BY 2 desc)
											where rownum < 2;
										  
										  l_o('<TD>Schedule type: '||v_PROG_SCHEDULE_TYPE||' '||v_PROG_SCHEDULE);
										  l_o(' by user '||v_user_name||' starting date '||v_START_DATE||'</TD></TR>'||chr(10));
							end if;
                    end if;
					
					EXCEPTION
					when others then
					  l_o('<br>'||sqlerrm ||' occurred in test');
					  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');					   
                    end;
					
                    :n := (dbms_utility.get_time - :n)/100;
                    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                    l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
                    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                    l_o(' </TABLE> </div> ');



              l_o('<div class="divwarn">');
              if issue1 and issue4 then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You never performed Gather Schema Statistics for HR!<br> ');
					:w2:=:w2+1;     
              end if;
              
                    
              if issue2 then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL is not Completed Normal. ');
					:w2:=:w2+1;      
              end if;
              
              if issue5 then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for HR is not Completed Normal. ');
					:w2:=:w2+1;     
              end if;
              
			  if issue1 and issue6 then
					l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your never performed gather schema statistics for ALL, and for HR was on '||last_date_hr||'.');
                    l_o('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w2:=:w2+1;
			  end if;
			  
              if issue3 and (issue6 or issue5 or issue4) then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all);
                    l_o('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w2:=:w2+1;                         
              elsif issue3 and issue6 then
                    l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for HR was on '||last_date_hr||'.');
                    l_o('Frequency of this concurrent request depends on payroll cycle, i.e.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc.<br>');                  
					:w2:=:w2+1;                         
              end if;
              
              if upper(product) in ('OTL','ALL') then
                    
                    if issue1 and issue7 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You never performed Gather Schema Statistics for HXC!<br> ');
						  :w2:=:w2+1;
                    end if;
                    if issue8 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for HXC is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
					
					if issue1 and issue9 then
							l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your never performed gather schema statistics for ALL, and for HXC was on '||last_date_hxc||'.');
							 l_o('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
					
                    if issue3 and issue9 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all||' and for HXC was on '||last_date_hxc||'.');
                          l_o('Frequency of this concurrent request should be weekly.<br>');  
						  :w2:=:w2+1;						  
                    end if;
                    
                    if issue1 and issue10 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You never performed Gather Schema Statistics for HXT!<br> ');
						  :w2:=:w2+1;
                    end if;
                    if issue11 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for HXT is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
                    
					if issue1 and issue12 then
							l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your never performed gather schema statistics for ALL and for HXT was on '||last_date_hxt||'.');
							 l_o('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
					  
					if issue3 and issue12 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for HXT was on '||last_date_hxt||'.');
                          l_o('Frequency of this concurrent request should be weekly.<br>');     
						  :w2:=:w2+1;						  
                    end if;
                    
                    if issue1 and issue13 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You never performed Gather Schema Statistics for PA!<br> ');
						  :w2:=:w2+1; 
                    end if;
                    if issue14 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for PA is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
					if issue1 and issue15 then
							l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your never performed gather schema statistics for ALL, and for PA was on '||last_date_pa||'.');
							 l_o('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
                    if issue3 and issue15 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for PA was on '||last_date_pa||'.');
                          l_o('Frequency of this concurrent request should be weekly.<br>');  
						  :w2:=:w2+1;						  
                    end if;
              end if; 
			  if upper(product) in ('BEN','ALL') then
                    
                    if issue1 and issue16 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You never performed Gather Schema Statistics for BEN!<br> ');
						  :w2:=:w2+1;
                    end if;
                    if issue17 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for BEN is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
					
					if issue1 and issue18 then
							l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your never performed gather schema statistics for ALL, and for BEN was on '||last_date_ben||'.');
							 l_o('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
					
                    if issue3 and issue18 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for BEN was on '||last_date_ben||'.');
                          l_o('Frequency of this concurrent request should be weekly.<br>');  
						  :w2:=:w2+1;						  
                    end if;			  
			end if;
			
			if upper(product) in ('OTA','ALL') then
                    
                    if issue1 and issue19 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> You never performed Gather Schema Statistics for OTA!<br> ');
						  :w2:=:w2+1;
                    end if;
                    if issue20 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for OTA is not Completed Normal. Verify the log and schedule it as per ');
						  :w2:=:w2+1;
                    end if;
					
					if issue1 and issue21 then
							l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your never performed gather schema statistics for ALL, and for OTA was on '||last_date_ota||'.');
							 l_o('Frequency of this concurrent request should be weekly.<br>');  
							:w2:=:w2+1;
					  end if;
					
                    if issue3 and issue21 then
                          l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your last run of gather schema statistics for ALL was on ' || last_date_all||', and for OTA was on '||last_date_ota||'.');
                          l_o('Frequency of this concurrent request should be weekly.<br>');  
						  :w2:=:w2+1;						  
                    end if;			  
			end if;
			
            if (issue1 and issue4) or issue2 or issue5 or (issue1 and issue6) or (issue3 and (issue6 or issue5 or issue4)) or (issue1 and issue7) or issue8 or (issue1 and issue9) or (issue3 and issue9) 
			or (issue1 and issue10) or issue11 or  (issue1 and issue12) or(issue3 and issue12) or (issue1 and issue13) or issue14 or (issue1 and issue15) or (issue3 and issue15) 
			or (issue1 and issue16) or issue17 or (issue1 and issue18) or (issue3 and issue18)  or (issue1 and issue19) or issue20 or (issue1 and issue21) or (issue3 and issue21) then
				 l_o('In order to schedule use <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=419728.1" target="_blank" >Note 419728.1</a> ');
				 l_o('Concurrent Processing - How To Gather Statistics On Oracle Applications Release 11i and/or Release 12 - Concurrent Process,Temp Tables, Manually <br>');
				 l_o('Note! You can ignore the warning if you are manually gathering statistics using FND_STATS.GATHER_SCHEMA_STATS.<br>');
			 end if;
            
			l_o('</div>');            
               
			  if not issue1 and not issue2 and not issue3 then
					l_o('<div class="divok">');
					l_o('<img class="check_ico">OK! Gather Scema statistics was performed in last week without errors.<br><br>');
					l_o('</div>');
			  else
					 if issue2 or issue3 or issue4 or issue5 or issue6 or issue7 or issue8 or issue9 or issue10 or issue11 or issue12 or issue13 or issue14 or issue15 or issue16 or issue17 or issue18 or issue19 or issue20 or issue21 then
                         l_o('<div class="divwarn">');
						 l_o('Please review also <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=226987.1" target="_blank" >Note 226987.1</a> ');
						 l_o('Oracle 11i and R12 Human Resources (HRMS) and Benefits (BEN) Tuning and System Health Checks <br>');                         
						 if upper(product) in ('PAY','ALL') then
                              l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=246332.1" target="_blank" >Note 246332.1</a> FLOAUG Presentation: Working with Support on Payroll Performance Issues');
						 end if;
						 l_o('</div>');
					 else
							l_o('<div class="divok">');
							l_o('<img class="check_ico">OK! Gather Scema statistics was performed in last week without errors.<br><br>');
							l_o('</div>');
					 end if;
			  end if;	  
              l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
        end if;
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');  
end;



-- Display hot PAY tables and indexes
procedure pay_tables is
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_table_name dba_tables.table_name%type; 
  v_last_analyzed dba_tables.last_analyzed%type;
	v_pct_free dba_tables.pct_free%type;
  v_ini_trans dba_tables.ini_trans%type;
  v_max_trans dba_tables.max_trans%type;
  v_degree dba_tables.degree%type;
  v_sample varchar2(30);
  v_num_rows dba_tables.num_rows%type;
  v_index_name dba_indexes.index_name%type;
  v_i_ini_trans dba_indexes.ini_trans%type;
  v_thread pay_action_parameters.parameter_value%type;
  v_rows number;
	issue1 boolean := FALSE;
	issue2 boolean := FALSE;
	issue3 boolean := FALSE;
	issue4 boolean := FALSE;
	issue5 boolean := FALSE;
	issue6 boolean := FALSE;
	issue7 boolean := FALSE;
	issue1_el boolean := FALSE;
	issue2_el boolean := FALSE;
	issue3_el boolean := FALSE;
	issue4_el boolean := FALSE;
	issue5_el boolean := FALSE;
	issue6_el boolean := FALSE;
	issue7_el boolean := FALSE;  
  
	cursor hot is
	SELECT table_name, last_analyzed, pct_free, ini_trans, max_trans, ltrim(rtrim(degree))
           , round(((decode(sample_size,0,null,sample_size))/(decode(num_rows,0,null,num_rows)))*100,2) , num_rows
      FROM DBA_TABLES
      WHERE table_name IN ('FF_ARCHIVE_ITEMS'
                          ,'FF_ARCHIVE_ITEM_CONTEXTS'
                          ,'PAY_ACTION_INFORMATION'
                          ,'PAY_ASSIGNMENT_ACTIONS'
                          ,'PAY_ASSIGNMENT_LATEST_BALANCES'
                          ,'PAY_BALANCE_CONTEXT_VALUES'
                          ,'PAY_COSTS'
                          ,'PAY_DEFINED_BALANCES'
                          ,'PAY_ELEMENT_ENTRIES_F'
                          ,'PAY_ELEMENT_ENTRY_VALUES_F'
                          ,'PAY_INPUT_VALUES_F'
                          ,'PAY_PAYROLL_ACTIONS'
                          ,'PAY_PERIODS_OF_SERVICE'
                          ,'PAY_PERSON_LATEST_BALANCES'
                          ,'PAY_POPULATION_RANGES'
                          ,'PAY_PRE_PAYMENTS'
                          ,'PAY_RUN_BALANCES'
                          ,'PAY_RUN_RESULTS'
                          ,'PAY_RUN_RESULT_VALUES'
                          ,'PAY_US_RPT_TOTALS'
                          ,'PER_ALL_ASSIGNMENTS_F'
                          ,'PER_ALL_PEOPLE_F') order by table_name;
  cursor cindexes (t_name varchar2) is
  select index_name, last_analyzed, pct_free, ini_trans, max_trans, degree 
      	FROM dba_indexes
      	WHERE table_name = t_name
        order by index_name;

begin

l_o(' <a name="hot"></a>');

if upper(product)='PAY'  or upper(product)='ALL' then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql17b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql17'');" href="javascript:;">&#9654; Hot PAY Tables</A></DIV>');
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql17" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=7 bordercolor="#DEE6EF">');
		l_o('     <B>Hot Tables</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql18b"  onclick="displayItem2(this,''s1sql18'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql18" style="display:none">');
		l_o('    <TD colspan="1" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         SELECT table_name, last_analyzed, pct_free, ini_trans, max_trans, ltrim(rtrim(degree))<br>');
		l_o('                    , round(((decode(sample_size,0,null,sample_size))/(decode(num_rows,0,null,num_rows)))*100,2) , num_rows<br>');
		l_o('               FROM DBA_TABLES<br>');
		l_o('               WHERE table_name IN (''FF_ARCHIVE_ITEMS''<br>');
		l_o('                                   ,''FF_ARCHIVE_ITEM_CONTEXTS''<br>');
		l_o('                                   ,''PAY_ACTION_INFORMATION''<br>');
		l_o('                                   ,''PAY_ASSIGNMENT_ACTIONS''<br>');
		l_o('                                   ,''PAY_ASSIGNMENT_LATEST_BALANCES''<br>');
		l_o('                                   ,''PAY_BALANCE_CONTEXT_VALUES''<br>');
		l_o('                                   ,''PAY_COSTS''<br>');
		l_o('                                   ,''PAY_DEFINED_BALANCES''<br>');
		l_o('                                   ,''PAY_ELEMENT_ENTRIES_F''<br>');
		l_o('                                   ,''PAY_ELEMENT_ENTRY_VALUES_F''<br>');
		l_o('                                   ,''PAY_INPUT_VALUES_F''<br>');
		l_o('                                   ,''PAY_PAYROLL_ACTIONS''<br>');
		l_o('                                   ,''PAY_PERIODS_OF_SERVICE''<br>');
		l_o('                                   ,''PAY_PERSON_LATEST_BALANCES''<br>');
		l_o('                                   ,''PAY_POPULATION_RANGES''<br>');
		l_o('                                   ,''PAY_PRE_PAYMENTS''<br>');
		l_o('                                   ,''PAY_RUN_BALANCES''<br>');
		l_o('                                   ,''PAY_RUN_RESULTS''<br>');
		l_o('                                   ,''PAY_RUN_RESULT_VALUES''<br>');
		l_o('                                   ,''PAY_US_RPT_TOTALS''<br>');
		l_o('                                   ,''PER_ALL_ASSIGNMENTS_F''<br>');
		l_o('                                   ,''PER_ALL_PEOPLE_F'');<br>');
    
		l_o('        SELECT table_name, index_name, last_analyzed, pct_free, ini_trans, max_trans, degree<br>');
		l_o('                FROM dba_indexes<br>');
		l_o('                WHERE table_name IN (''FF_ARCHIVE_ITEMS''<br>');
		l_o('                                   ,''FF_ARCHIVE_ITEM_CONTEXTS''<br>');
		l_o('                                   ,''PAY_ACTION_INFORMATION''<br>');
		l_o('                                   ,''PAY_ASSIGNMENT_ACTIONS''<br>');
		l_o('                                   ,''PAY_ASSIGNMENT_LATEST_BALANCES''<br>');
		l_o('                                   ,''PAY_BALANCE_CONTEXT_VALUES''<br>');
		l_o('                                   ,''PAY_COSTS''<br>');
		l_o('                                   ,''PAY_DEFINED_BALANCES''<br>');
		l_o('                                   ,''PAY_ELEMENT_ENTRIES_F''<br>');
		l_o('                                   ,''PAY_ELEMENT_ENTRY_VALUES_F''<br>');
		l_o('                                   ,''PAY_INPUT_VALUES_F''<br>');
		l_o('                                   ,''PAY_PAYROLL_ACTIONS''<br>');
		l_o('                                   ,''PAY_PERIODS_OF_SERVICE''<br>');
		l_o('                                   ,''PAY_PERSON_LATEST_BALANCES''<br>');
		l_o('                                   ,''PAY_POPULATION_RANGES''<br>');
		l_o('                                   ,''PAY_PRE_PAYMENTS''<br>');
		l_o('                                   ,''PAY_RUN_BALANCES''<br>');
		l_o('                                   ,''PAY_RUN_RESULTS''<br>');
		l_o('                                   ,''PAY_RUN_RESULT_VALUES''<br>');
		l_o('                                   ,''PAY_US_RPT_TOTALS''<br>');
		l_o('                                   ,''PER_ALL_ASSIGNMENTS_F''<br>');
		l_o('                                   ,''PER_ALL_PEOPLE_F'');<br>');
		l_o('          </blockquote><br>');       

		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Table Name</B></TD>');
		l_o(' <TH><B>Last Analyzed</B></TD>');
		l_o(' <TH><B>Pct Free</B></TD>');
		l_o(' <TH><B>Ini trans</B></TD>');
		l_o(' <TH><B>Max trans</B></TD>');
		l_o(' <TH><B>Degree</B></TD>');
		l_o(' <TH><B>% Sample</B></TD>');
		l_o(' <TH><B>Number of Rows</B></TD>');
	
  
	:n := dbms_utility.get_time;
  
	select count(1) into v_rows from pay_action_parameters where parameter_name='THREADS';
	if v_rows=0 then
		v_thread:=1;
	else	
		select max(parameter_value) into v_thread
			  from pay_action_parameters where parameter_name='THREADS';
	end if;
      
	open hot;
	loop
	  fetch hot into v_table_name,v_last_analyzed,v_pct_free,v_ini_trans,v_max_trans,v_degree,v_sample,v_num_rows;
	  EXIT WHEN  hot%NOTFOUND;
      issue1_el:=FALSE;
      issue2_el:=FALSE;
      issue3_el:=FALSE;
      issue4_el:=FALSE;
      issue5_el:=FALSE;
      if v_last_analyzed-sysdate>7 then
           issue1:=TRUE;
           issue1_el:=TRUE;
      end if;
      if v_ini_trans<10 then
            issue2:=TRUE;
            issue2_el:=TRUE;
      end if;
      if v_ini_trans<v_thread then
            issue3:=TRUE;
            issue3_el:=TRUE;
      end if;
      if v_sample<10 then
            issue4:=TRUE;
            issue4_el:=TRUE;
      end if;
      if v_table_name='PAY_US_RPT_TOTALS'  then
            select count(1) into v_num_rows from PAY_US_RPT_TOTALS;
			if v_num_rows>1000 then
				issue5:=TRUE;
				issue5_el:=TRUE;
			end if;
      end if;
      if issue1_el or issue2_el or issue3_el or issue4_el or issue5_el then
          l_o('<TR><TD><font color="red">'||v_table_name||'</font></TD>'||chr(10));
      else
          l_o('<TR><TD>'||v_table_name||'</TD>'||chr(10));
      end if;
      if issue1_el then
          l_o('<TD><font color="red">'||v_last_analyzed||'</font></TD>'||chr(10));
      else
          l_o('<TD>'||v_last_analyzed||'</TD>'||chr(10));
      end if;
      l_o('<TD>'||v_pct_free||'</TD>'||chr(10));
      if issue2_el or issue3_el then
          l_o('<TD><font color="red">'||v_ini_trans||'</font></TD>'||chr(10));
      else
          l_o('<TD>'||v_ini_trans||'</TD>'||chr(10));
      end if;
      l_o('<TD>'||v_max_trans||'</TD>'||chr(10)||'<TD>'||v_degree||'</TD>'||chr(10));
      if issue4_el then
          l_o('<TD><font color="red">'||v_sample||'</font></TD>'||chr(10));
      else
          l_o('<TD>'||v_sample||'</TD>'||chr(10));
      end if;
      if issue5_el then
          l_o('<TD><font color="red">'||v_num_rows||'</font></TD>'||chr(10));
      else
          l_o('<TD>'||v_num_rows||'</TD>'||chr(10));
      end if;
      
	  l_o('</TD></TR>'||chr(10));
      
      l_o('<tr><td></td><TH COLSPAN=7>');
      
      l_o('<table><tr BGCOLOR=#DEE6E0><td>Index name</td><td>Last analyzed</td><td>Pct free</td><td>Ini trans</td><td>Max trans</td><td>Degree</td></tr>');
            
      open cindexes (v_table_name);
      loop
            fetch cindexes into v_index_name, v_last_analyzed,v_pct_free,v_i_ini_trans,v_max_trans,v_degree;
            EXIT WHEN  cindexes%NOTFOUND;
            issue6_el:=FALSE;
            issue7_el:=FALSE;
            
            if v_last_analyzed-sysdate>7 then                  
                  issue6:=TRUE;
                  issue6_el:=TRUE;
            end if;
            
            if v_i_ini_trans<v_ini_trans+1 then
                  if v_index_name not like 'SYS_IL%' then
					  issue7:=TRUE;
					  issue7_el:=TRUE;
				  end if;
            end if;
            
            if issue6_el or issue7_el then
                l_o('<tr><td><font color="red">'||v_index_name||'</font></td>');
            else
                l_o('<tr><td>'||v_index_name||'</td>');
            end if;
            if issue6_el then
                l_o('<td><font color="red">'||v_last_analyzed||'</font></TD>');
            else
                l_o('<td>'||v_last_analyzed||'</TD>');
            end if;
            l_o('<td>'||v_pct_free||'</td>');
            if issue7_el then
                l_o('<td><font color="red">'||v_i_ini_trans||'</font></TD>');
            else
                l_o('<td>'||v_i_ini_trans||'</TD>');
            end if;
            l_o('<td>'||v_max_trans||'</td><td>'||v_degree||'</td><tr>');
      end loop;
      close cindexes;   
	  
      l_o('</table> </td></tr>');
          
		end loop;
		close hot;

		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql17'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
		
		
		l_o('<div class="divwarn">');
		if issue1 then
			  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Last_Analyzed for tables is more than 1 week. This can be an issue or not depending on your pay period. ');
			  l_o('Last_analyzed should be within a time period associated with the customers pay periods ');
			  l_o(' ie.  If payroll is run weekly, these tables should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc');
			  :w2:=:w2+1;
		end if;
		
		if issue2 then
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set  Ini_trans value to 10 or higher for tables with red!<br>');
			:w2:=:w2+1;
		end if;
		
		if issue3 then
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> The setting of the pay_action_parameters Threads setting ('||v_thread||') must be less then or equal to the Ini_trans setting.  ');
			l_o('If the Ini_trans setting is lower then the Threads setting this could cause system contention.<br>');
			:w2:=:w2+1;
		end if;
    
		if issue4 then
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Sample size should be at least 10% - if performance issue associated with one of these tables (as identified in a trace) may consider analyzing a larger sample.  <br>');
			:w2:=:w2+1;
		end if;
		
		if issue5 then
			  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Pay_US_RPT_Totals table should not contain a large number of records.  ');
			  l_o('This table temporarily stores records until a US Payroll reports completes successfully, then removes records. ');
			  l_o('<br>Records are retained only if a report fails. ');
			  l_o('Review: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=256143.1" target="_blank">Note 256143.1</a> How to remove obsolete data on PAY_US_RPT_TOTALS table<br>');
			  :w2:=:w2+1;
		end if;
		
		if issue6 then
			  l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Last_Analyzed for indexes is more than 1 week. This can be an issue or not depending on your pay period. ');
			  l_o('Last_analyzed should be within a time period associated with the customers pay periods ');
			  l_o(' ie.  If payroll is run weekly, these indexes should be gathered weekly, if bi-weekly Payroll, then stats within last 15 days, etc');
			  :w2:=:w2+1;
		end if;
		
		if issue7 then
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> Please set Ini_trans value for indexes to (Ini_trans of table)+1 <br>');
			:w2:=:w2+1;
		end if;
		
		l_o('<span class="sectionblue1">Advice:</span> Please review:<br> ');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=419075.1" target="_blank">Note 419075.1</a> Payroll Performance Checklist<br>');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=549367.1" target="_blank">Note 246332.1</a> FLOAUG Presentation: Working with Support on Payroll Performance Issues<br>');
		l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=226987.1" target="_blank">Note 226987.1</a> Oracle 11i and R12 Human Resources and Benefits Tuning and System Health Checks<br>');
		l_o('</div>');
		
		if (not issue1) and (not issue2) and (not issue3) and (not issue4) and (not issue5) and (not issue6) then
				l_o('<div class="divok">');
				l_o('Verified values are correctly set<br>');
				l_o('</div>');
		end if;			
		
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
end if;

EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  l_o('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;



-- Second main program (split because "program too long" error)
begin  -- begin1
declare
	run_type varchar2(20):='&1';
  product varchar2(20):='&2';

  begin -- begin MAIN
	:g_curr_loc2:=1;
	DBMS_LOB.CREATETEMPORARY(:g_hold_output2,TRUE,DBMS_LOB.SESSION);
	
	l_o('<BR>'); 	
	l_o('<div id="page3" style="display: none;">');	
	l_o('<a name="settings"></a><a name="profiles"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">');
	l_o('<div class="left"  id="settings" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Settings: '); 
	l_o('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    l_o('<a class="detail" onclick="openall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    l_o('</div><div class="clear"></div></div><br>');
	if upper(run_type)='ALL' then
	l_o('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	l_o('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
		l_o('<a class=detail2 href="#profiles">Profiles Settings</a> <br>');
		l_o('<a class=detail2 href="#security">Security Profile Details</a> <br>');
        l_o('<a class=detail2 href="#ssp">Ssp_temp_affected_rows rows</a> <br>');
		  if upper(product) in ('PAY','HR','ALL') then 
			  l_o('<a class=detail2 href="#international">International Payroll Usage</a> <br>');
		  end if;
		  l_o('</td><td class="toctable">');
		  if upper(product) in ('PAY','ALL') then
			  l_o('<a class=detail2 href="#rules">Pay Legislation Rules</a> <br>');			  
			  l_o('<a class=detail2 href="#pay_trigger_events">Pay Triggers Events</a> <br>');
			  l_o('<a class=detail2 href="#pay_action">Pay Action Parameters</a> <br>');  
		  end if;
		  
		  l_o('<a class=detail2 href="#setup">Business Group Details</a> <br>');
		  if upper(product) in ('HR','SSHR','ALL') then
			  l_o('<a class=detail2 href="#employee">Employee Numbering Details</a> <br>');  
		  end if;
		 l_o('</td></tr></table>');
	l_o('</div><br>');
	end if;
	profiles();
	profiles2();	
	datatrack();
	security();
	international();
	pay_rules();
	pay_trigger();
	pay_action();
	setup_group();
	employee_numbering();
	l_o('</div></div>');
	l_o('<div id="page4" style="display: none;">');
	l_o('<a name="performance"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">');
	l_o('<div class="left"  id="performance" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Performance: '); 
	l_o('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    l_o('<a class="detail" onclick="openall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    l_o('</div><div class="clear"></div></div><br>');
	if upper(run_type)='ALL' then
	l_o('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	  l_o('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	  l_o('<a class=detail2 href="#db_init_ora">Database Initialization Parameters</a> <br>');
      l_o('<a class=detail2 href="#gather">Gather Schema Statistics</a> <br></td>');      
      if product='PAY' or product='ALL' then
          l_o('<td class="toctable"><a class=detail2 href="#hot">Hot Payroll Tables</a><br></td>');
      end if;
      l_o('</tr></table>');
	l_o('</div><br>');
	end if;
	database();
	gather();	
	pay_tables();
	l_o('</div></div>');
	
	l_o('<!-');
		
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test'); 

end;
end;
/

-- Print output
print :g_hold_output2


variable g_hold_output3 clob;
declare
   counter      number       := 0;
   failures     number       := 0;   
   
   

/* Global defaults for SQL output formatting */
   g_sql_date_format   varchar2(100) := 'DD-MON-YYYY HH24:MI';

/* Global variables set by Set_Client which can be used throughout a script */
   g_user_id      number;
   g_resp_id      number;
   g_appl_id      number;
   g_org_id       number;

/* Global variable set by Set_Client or Get_DB_Apps_Version which can
   be referenced in scripts which branch based on applications release */

   g_appl_version varchar2(10);

   type V2T is table of varchar2(32767);
   

-- Write html format
procedure l_o (text varchar2) is
   l_ptext      varchar2(32767);
   l_hold_num   number;
   l_ptext2      varchar2(32767);
   l_hold_num2   number;
begin
   l_hold_num := mod(:g_curr_loc, 32767);
   
   l_hold_num2 := mod(:g_curr_loc, 14336);
   if l_hold_num2 + length(text) > 14000 then
      l_ptext2 := '                                                                                                                                                                                               ';
      dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  
   end if;
   
   l_hold_num2 := mod(:g_curr_loc, 18204);
   if l_hold_num2 + length(text) > 17900 then
      l_ptext2 := '                                                                                                                                                                                              ';
      dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	 
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);
	  dbms_lob.write(:g_hold_output3, length(l_ptext2), :g_curr_loc, l_ptext2);
      :g_curr_loc := :g_curr_loc + length(l_ptext2);	
   end if;
   
   if l_hold_num + length(text) > 32759 then
      l_ptext := '<!--' || rpad('*', 32761-l_hold_num,'*') || '-->';
      dbms_lob.write(:g_hold_output3, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
	  dbms_lob.write(:g_hold_output3, length(l_ptext), :g_curr_loc, l_ptext);
      :g_curr_loc := :g_curr_loc + length(l_ptext);
   end if;
   dbms_lob.write(:g_hold_output3, length(text)+1, :g_curr_loc, text || chr(10));
   :g_curr_loc := :g_curr_loc + length(text)+1;
   
   --dbms_lob.write(:g_hold_output3, length(text), g_curr_loc, text );
   --g_curr_loc := g_curr_loc + length(text);
   
end l_o;


-- Display java classes version
procedure javacl is
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_dir ad_files.subdir%type;
  v_dir_old ad_files.subdir%type;
  v_file ad_files.filename%type;
  v_version ad_file_versions.version%type;
   
  cursor java_vers(prod varchar2) is
  select que.subdir,que.filename, que.version
  from (
     select files.filename filename,files.subdir subdir,
     file_version.version version,
     rank()over(partition by files.filename
       order by file_version.version_segment1 desc,
       file_version.version_segment2 desc,file_version.version_segment3 desc,
       file_version.version_segment4 desc,file_version.version_segment5 desc,
       file_version.version_segment6 desc,file_version.version_segment7 desc,
       file_version.version_segment8 desc,file_version.version_segment9 desc,
       file_version.version_segment10 desc,
       file_version.translation_level desc) as rank1
     from ad_file_versions file_version,
       (
       select filename, app_short_name, subdir, file_id
       from ad_files
       where app_short_name=prod and upper(filename) like upper('%.class')
       ) files
     where files.file_id = file_version.file_id
  ) que
  where rank1 = 1
  order by 1,2;

Begin

  if upper(run_type)='ALL'  then
    l_o('<a name="java"></a>');
	l_o('<DIV class=divItem>');
	l_o('<DIV id="s1sql47b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql47'');" href="javascript:;">');
	if upper(product)='ALL' then
		l_o('&#9654; BEN Java Classes Version</A></DIV>');
	elsif upper(product)='PAY' then
		l_o('&#9654; PAY Java Classes Version</A></DIV>');
	else
		l_o('&#9654; Java Classes Version</A></DIV>');
	end if;
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql47" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql48b"  onclick="displayItem2(this,''s1sql48'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql48" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select que.subdir,que.filename, que.version <br>');  
		l_o('            from (<br>');
		l_o('               select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br>');
		l_o('               rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br>');
		l_o('                 (<br>');
		l_o('                 select filename, app_short_name, subdir, file_id<br>');
		l_o('                 from ad_files<br>');
    CASE upper(product) 
	WHEN 'OTL' then
    	l_o('                 where app_short_name=''HXC'' and upper(filename) like upper(''%.class'')<br>');
    WHEN 'HR' then
        l_o('                 where app_short_name=''PER'' and upper(filename) like upper(''%.class'')<br>');
    WHEN 'SSHR' then
        l_o('                 where app_short_name=''PER'' and upper(filename) like upper(''%.class'')<br>');
	WHEN 'PAY' then
        l_o('                 where app_short_name=''PAY'' and upper(filename) like upper(''%.class'')<br>');
    WHEN 'BEN' then
        l_o('                 where app_short_name=''BEN'' and upper(filename) like upper(''%.class'')<br>');
    WHEN 'OTA' then
        l_o('                 where app_short_name=''OTA'' and upper(filename) like upper(''%.class'')<br>');
	WHEN 'ALL' then
        l_o('                 where app_short_name=''BEN'' and upper(filename) like upper(''%.class'')<br>');
	WHEN 'IRC' then
        l_o('                 where app_short_name=''IRC'' and upper(filename) like upper(''%.class'')<br>');
	ELSE
		null;
	end case;
    
		l_o('                 ) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>');
		l_o('            ) que<br>');
		l_o('            where rank1 = 1<br>');
		l_o('            order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
   case upper(product) 
        when 'PAY' then
              open java_vers('PAY');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
          when 'HR' then
              open java_vers('PER');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
          when 'SSHR' then
              open java_vers('PER');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
		  when 'BEN' then
              open java_vers('BEN');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
		  when 'OTA' then
              open java_vers('OTA');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
		  when 'ALL' then
              open java_vers('BEN');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
		  when 'IRC' then
              open java_vers('IRC');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers; 
		  when 'OTL' then                         
              open java_vers('HXC');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
         else
              null;
    end case;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql47'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;


  if upper(run_type)='ALL' and (:apps_rel like '12.%') and upper(product) in ('IRC','PAY','ALL') then
    l_o('<DIV class=divItem>');
	l_o('<DIV id="s1sql472b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql472'');" href="javascript:;">');
	if upper(product) in ('ALL','IRC') then
		l_o('&#9654; IRC Java Classes Version</A></DIV>');
	elsif upper(product)='PAY' then
		l_o('&#9654; FF Java Classes Version</A></DIV>');	
	end if;
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql472" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql482b"  onclick="displayItem2(this,''s1sql482'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql482" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select que.subdir,que.filename, que.version <br>');  
		l_o('            from (<br>');
		l_o('               select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br>');
		l_o('               rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br>');
		l_o('                 (<br>');
		l_o('                 select filename, app_short_name, subdir, file_id<br>');
		l_o('                 from ad_files<br>');
		if upper(product) in ('PAY') then
			l_o('                 where app_short_name=''FF'' and upper(filename) like upper(''%.class'')<br>');
		else
			l_o('                 where app_short_name=''IRC'' and upper(filename) like upper(''%.class'')<br>');   
		end if;
    
		l_o('                 ) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>');
		l_o('            ) que<br>');
		l_o('            where rank1 = 1<br>');
		l_o('            order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
	   
	   if upper(product) in ('PAY') then
				  open java_vers('FF');
				  v_dir_old:='';
				  loop
						fetch java_vers into v_dir,v_file,v_version;
						EXIT WHEN  java_vers%NOTFOUND;
						if v_dir_old=v_dir then
							l_o('<TR><TD></TD>'||chr(10)||'<TD>');
						else
							l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
						end if;
						v_dir_old:=v_dir;
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
							l_o('</TD></TR>'||chr(10));
					end loop;
				  close java_vers;
		else
				  open java_vers('IRC');
				  v_dir_old:='';
				  loop
						fetch java_vers into v_dir,v_file,v_version;
						EXIT WHEN  java_vers%NOTFOUND;
						if v_dir_old=v_dir then
							l_o('<TR><TD></TD>'||chr(10)||'<TD>');
						else
							l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
						end if;
						v_dir_old:=v_dir;
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
							l_o('</TD></TR>'||chr(10));
					end loop;
				  close java_vers; 		  
		end if;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql472'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;


  
  if upper(run_type)='ALL'  and upper(product) ='ALL' then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql473b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql473'');" href="javascript:;">');		
		l_o('&#9654; PAY Java Classes Version</A></DIV>');	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql473" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql483b"  onclick="displayItem2(this,''s1sql483'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql483" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select que.subdir,que.filename, que.version <br>');  
		l_o('            from (<br>');
		l_o('               select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br>');
		l_o('               rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br>');
		l_o('                 (<br>');
		l_o('                 select filename, app_short_name, subdir, file_id<br>');
		l_o('                 from ad_files<br>');
		l_o('                 where app_short_name=''PAY'' and upper(filename) like upper(''%.class'')<br>');   
    
		l_o('                 ) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>');
		l_o('            ) que<br>');
		l_o('            where rank1 = 1<br>');
		l_o('            order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
              open java_vers('PAY');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql473'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

	  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;


  if upper(run_type)='ALL'  and upper(product) in ('ALL','PAY','IRC') then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql474b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql474'');" href="javascript:;">');
		if :apps_rel like '11.5%' then
			l_o('&#9654; PER and IRC Java Classes Version</A></DIV>');	
		else
			l_o('&#9654; PER Java Classes Version</A></DIV>');	
		end if;
		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql474" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql484b"  onclick="displayItem2(this,''s1sql484'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql484" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select que.subdir,que.filename, que.version <br>');  
		l_o('            from (<br>');
		l_o('               select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br>');
		l_o('               rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br>');
		l_o('                 (<br>');
		l_o('                 select filename, app_short_name, subdir, file_id<br>');
		l_o('                 from ad_files<br>');
		l_o('                 where app_short_name=''PER'' and upper(filename) like upper(''%.class'')<br>');   
    
		l_o('                 ) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>');
		l_o('            ) que<br>');
		l_o('            where rank1 = 1<br>');
		l_o('            order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
              open java_vers('PER');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql474'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

	  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;


  if upper(run_type)='ALL'  and upper(product) ='ALL' then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql475b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql475'');" href="javascript:;">');		
		l_o('&#9654; OTL Java Classes Version</A></DIV>');	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql475" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql485b"  onclick="displayItem2(this,''s1sql485'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql485" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select que.subdir,que.filename, que.version <br>');  
		l_o('            from (<br>');
		l_o('               select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br>');
		l_o('               rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br>');
		l_o('                 (<br>');
		l_o('                 select filename, app_short_name, subdir, file_id<br>');
		l_o('                 from ad_files<br>');
		l_o('                 where app_short_name=''HXC'' and upper(filename) like upper(''%.class'')<br>');   
    
		l_o('                 ) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>');
		l_o('            ) que<br>');
		l_o('            where rank1 = 1<br>');
		l_o('            order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
              open java_vers('HXC');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql475'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

	  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
  
  if upper(run_type)='ALL'  and upper(product) ='ALL' then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql476b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql476'');" href="javascript:;">');		
		l_o('&#9654; OTA Java Classes Version</A></DIV>');	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql476" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>Java version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql486b"  onclick="displayItem2(this,''s1sql486'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql486" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select que.subdir,que.filename, que.version <br>');  
		l_o('            from (<br>');
		l_o('               select files.filename filename,files.subdir subdir,<br>');
		l_o('               file_version.version version,<br>');
		l_o('               rank()over(partition by files.filename<br>');
		l_o('                 order by file_version.version_segment1 desc,<br>');
		l_o('                 file_version.version_segment2 desc,file_version.version_segment3 desc,<br>');
		l_o('                 file_version.version_segment4 desc,file_version.version_segment5 desc,<br>');
		l_o('                 file_version.version_segment6 desc,file_version.version_segment7 desc,<br>');
		l_o('                 file_version.version_segment8 desc,file_version.version_segment9 desc,<br>');
		l_o('                 file_version.version_segment10 desc,<br>');
		l_o('                 file_version.translation_level desc) as rank1<br>');
		l_o('               from ad_file_versions file_version,<br>');
		l_o('                 (<br>');
		l_o('                 select filename, app_short_name, subdir, file_id<br>');
		l_o('                 from ad_files<br>');
		l_o('                 where app_short_name=''OTA'' and upper(filename) like upper(''%.class'')<br>');   
    
		l_o('                 ) files<br>');
		l_o('               where files.file_id = file_version.file_id<br>');
		l_o('            ) que<br>');
		l_o('            where rank1 = 1<br>');
		l_o('            order by 1,2;<br>');  
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>File directory</B></TD>');
		l_o(' <TH><B>Filename</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

	
		:n := dbms_utility.get_time;
    
   
              open java_vers('OTA');
              v_dir_old:='';
              loop
                    fetch java_vers into v_dir,v_file,v_version;
                    EXIT WHEN  java_vers%NOTFOUND;
                    if v_dir_old=v_dir then
                        l_o('<TR><TD></TD>'||chr(10)||'<TD>');
                    else
                        l_o('<TR><TD>'||v_dir||'</TD>'||chr(10)||'<TD>');
                    end if;
                    v_dir_old:=v_dir;
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close java_vers;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql476'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

	  l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
  
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  
end;


-- Display Workflow Errors issues
procedure workflow is
	  run_type varchar2(20):='&1';
	  product varchar2(20):='&2';
	  v_it wf_process_activities.PROCESS_ITEM_TYPE%type; 
	  v_activity wf_process_activities.ACTIVITY_NAME%type;
	  v_ik wf_items.ITEM_KEY%type;
	  v_it_old wf_process_activities.PROCESS_ITEM_TYPE%type; 
	  v_activity_old wf_process_activities.ACTIVITY_NAME%type;
	  v_code wf_item_activity_statuses.activity_result_code%type;	
	  v_date  wf_items.begin_date%type;
	  v_err_name varchar2(10000);
	  v_err_name_old varchar2(10000);
	  v_process_activity wf_item_activity_statuses.process_activity%type;
	  v_big_no number :=1;
	  v_big_no2 number :=1;
	  v_rows number;
	  v_count number;
	
		cursor sshr_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.process_item_type in  ('HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC')
			and ROWNUM<1000
			order by 1,2,4,5;

		cursor otl_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.PROCESS_ITEM_TYPE in  ('HXCEMP', 'HXCSAW')
			and ROWNUM<1000
			order by 1,2,4,5;
		cursor irc_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.PROCESS_ITEM_TYPE in  ('HRSSA','HRSFL','IRC_WF','IRCOFFER','IRC_NTF','IRC_REG')
			and ROWNUM<1000
			order by 1,2,4,5;
		cursor all_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.PROCESS_ITEM_TYPE in  ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'IRC_WF','IRC_REG','OTWF', 'HRCKLTSK', 'HRSSA', 'HRSFL','HRWPM', 'HRRIRPRC', 'PSPERAVL')
			and ROWNUM<1000
			order by 1,2,4,5;
		cursor ota_workflow  is
		select p.process_item_type, p.activity_name, wi.item_key, substr(s.error_message,1,200), wi.begin_date, activity_result_code, s.process_activity
			FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi
			WHERE p.instance_id = s.process_activity
			and wi.item_type = s.item_type
			and wi.item_key = s.item_key
			and activity_status = 'ERROR'
			AND p.PROCESS_ITEM_TYPE in  ('OTWF')
			and ROWNUM<1000
			order by 1,2,4,5;
		        
begin
		case upper(product)
			when 'SSHR' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'					
					AND p.PROCESS_ITEM_TYPE in  ('HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC');	
			when 'HR' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'					
					AND p.PROCESS_ITEM_TYPE in  ('HRCKLTSK', 'HRSSA', 'HRWPM', 'HRRIRPRC');
			when 'OTL' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'
					AND p.PROCESS_ITEM_TYPE in  ('HXCEMP', 'HXCSAW');	
			when 'OTA' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'
					AND p.PROCESS_ITEM_TYPE in  ('OTWF');
			when 'IRC' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'
					AND p.PROCESS_ITEM_TYPE in  ('HRSSA','HRSFL','IRC_WF','IRCOFFER','IRC_NTF','IRC_REG');	
			when 'ALL' then
				select count(1)	into v_rows FROM wf_item_activity_statuses s,wf_process_activities p
					WHERE p.instance_id = s.process_activity
					AND activity_status = 'ERROR'
					AND p.PROCESS_ITEM_TYPE in  ('BENCWBFY', 'SSBEN', 'GHR_SF52', 'HXCEMP', 'HXCSAW', 'IRC_NTF', 'IRCOFFER', 'IRC_WF','IRC_REG','OTWF',  'HRCKLTSK', 'HRSSA', 'HRSFL','HRWPM', 'HRRIRPRC', 'PSPERAVL');	
			else
							null;
		end case;
		
		if upper(run_type)='ALL' or v_rows>0 then	
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql55b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql55'');" href="javascript:;">&#9654; Workflows with Errors</A></DIV>');
			
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql55" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=4 bordercolor="#DEE6EF">');
		l_o('     <B>Workflows with Errors</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql56b"  onclick="displayItem2(this,''s1sql56'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql56" style="display:none">');
		l_o('    <TD colspan="4" height="60">');
		l_o('       <blockquote><p align="left">');
    
		l_o('         select p.process_item_type, p.activity_name, activity_result_code, wi.item_key, substr(s.error_message,1,200), wi.begin_date<br>');
		l_o('         	FROM wf_item_activity_statuses s,wf_process_activities p, wf_items wi<br>');
		l_o('         	WHERE p.instance_id = s.process_activity<br>');
		l_o('         	and wi.item_type = s.item_type<br>');
		l_o('         	and wi.item_key = s.item_key<br>');
		l_o('         	AND activity_status = ''ERROR''<br>');			
		l_o('         	AND p.PROCESS_ITEM_TYPE in <br>');		
		case upper(product)
						WHEN 'SSHR' then
							l_o('     (''HRCKLTSK'', ''HRSSA'', ''HRWPM'', ''HRRIRPRC'')<br>');
						WHEN 'HR' then
							l_o('     (''HRCKLTSK'', ''HRSSA'', ''HRWPM'', ''HRRIRPRC'')<br>');
						WHEN 'OTL' then
							l_o('    (''HXCEMP'', ''HXCSAW'')<br>');							
						WHEN 'OTA' then
							l_o('    (''OTWF'')<br>');
						WHEN 'IRC' then
							l_o('  (''HRSSA'',''HRSFL'',''IRC_WF'',''IRCOFFER'',''IRC_NTF'',''IRC_REG'')<br>');
						WHEN 'ALL' then						
								l_o('    (''BENCWBFY'', ''SSBEN'', ''GHR_SF52'', ''HXCEMP'', ''HXCSAW'', ''IRC_NTF'', ''IRCOFFER'', ''IRC_WF'',''IRC_REG'',<br>');
								l_o('     ''OTWF'', ''HRCKLTSK'', ''HRSSA'', ''HRSFL'',''HRWPM'', ''HRRIRPRC'', ''PSPERAVL'')<br>');
						else
							null;
		end case;
		l_o('         	and ROWNUM<1000<br>');
		l_o('         	order by 1,2,4,5;<br>');    
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH width="15%"><B>Item Type</B></TD>');
		l_o(' <TH width="15%"><B>Activity</B></TD>');
		l_o(' <TH width="50%"><B>Error Message (first 200 characters)</B></TD>');
		l_o(' <TH width="10%"><B>Count of errors</B></TD>');
		l_o(' <TH width="10%"><B>Show Details</B></TD>');
    
    
	:n := dbms_utility.get_time;
	
	if v_rows>0 then
		if v_rows>1000 then
			l_o('<TR><TD COLSPAN=5>You have more than 1000 workflows with errors. Error list truncated.</TD><TR>');
		end if;
	
				v_it_old:='x';
				v_activity_old:='x';
				v_err_name_old:='x';
				case upper(product)
					WHEN 'SSHR' then
						open sshr_workflow;
					WHEN 'HR' then
						open sshr_workflow;
					WHEN 'OTL' then
						open otl_workflow;							
					WHEN 'OTA' then
						open ota_workflow;
					WHEN 'IRC' then
						open irc_workflow;
					WHEN 'ALL' then						
						open all_workflow;
					else
							null;				
				end case;
				loop
						case upper(product)
							WHEN 'SSHR' then
								fetch sshr_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  sshr_workflow%NOTFOUND;
							WHEN 'HR' then
								fetch sshr_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  sshr_workflow%NOTFOUND;
							WHEN 'OTL' then
								fetch otl_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  otl_workflow%NOTFOUND;							
							WHEN 'OTA' then
								fetch ota_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  ota_workflow%NOTFOUND;	
							WHEN 'IRC' then
								fetch irc_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  irc_workflow%NOTFOUND;
							WHEN 'ALL' then						
								fetch all_workflow into v_it,v_activity,v_ik,v_err_name,v_date,v_code,v_process_activity;
								EXIT WHEN  all_workflow%NOTFOUND;
							else
							null;
						end case;
						
								if v_it<>v_it_old or v_activity<>v_activity_old or v_err_name<>v_err_name_old then
										  if v_big_no>1 then
												v_big_no2 :=v_big_no-1;
												l_o('<tr><td><A class=detail onclick="hideRow2(''s1sql200'||v_big_no2||''');" href="javascript:;">Collapse details</a></td></tr>');
												l_o('</TABLE></td></TR>');
										  end if;
										  l_o('<TR><TD>'||v_it||'</TD>'||chr(10)||'<TD>'||v_activity ||'</TD>'||chr(10)||'<TD>');
										  if v_err_name is null then
											l_o('-</TD>'||chr(10));
										  else
											l_o(replace(v_err_name,chr(10),'<br>') ||'</TD>'||chr(10));
										  end if;
										  SELECT count(s.ITEM_KEY) into v_count
												FROM wf_item_activity_statuses s,wf_process_activities p
												WHERE p.instance_id = s.process_activity
												AND activity_status = 'ERROR'												
												AND p.PROCESS_ITEM_TYPE = v_it and p.ACTIVITY_NAME=v_activity and substr(nvl(s.error_message,'null'),1,200)=nvl(v_err_name,'null');
										  l_o('<TD>'||v_count ||'</TD>'||chr(10));
										  l_o('<TD><A style="white-space:nowrap" class=detail id="s1sql200'||v_big_no||'b" onclick="displayItem2(this,''s1sql200'||v_big_no||''');" href="javascript:;">&#9654; Show Details</A>');
										  l_o('   </TD>');
										  l_o(' </TR>');
										  l_o(' <TR><TD COLSPAN=5><TABLE width="100%" border="1" cellspacing="0" cellpadding="2"  id="s1sql200'||v_big_no||'" style="display:none">');
										  l_o(' <TR><TD width="10%"></TD><TD><B>Result</B></TD>');
										  l_o(' <TD><B>Item Key</B></TD>');
										  l_o(' <TD><B>Begin Date</B></TD>');										  
										  l_o(' <TD><B>Command to get error stack</B></TD>');
										  l_o(' <TD><B>Command to run wfstat</B></TD></TR>');										  
										  v_big_no:=v_big_no+1;
										  
								end if;
								
								v_it_old:=v_it;
								v_activity_old:=v_activity;
								v_err_name_old:=v_err_name;

								l_o('<TD></TD>');
								l_o('<TD>'||v_code||'</TD>'||chr(10));
								l_o('<TD>'||v_ik||'</TD>'||chr(10));
								l_o('<TD>'||v_date||'</TD>'||chr(10));
								
								l_o('<TD>select Error_Stack from wf_item_activity_statuses<br> where item_type='''||v_it||'''');
								l_o(' and item_key='''||v_ik||''' and process_activity='||v_process_activity||';</TD>'||chr(10));
								l_o('<TD>@wfstat.sql '||v_it||' '||v_ik||'</TD>'||chr(10));
											   
								l_o('</TR>'||chr(10));              
					  end loop;
					  case upper(product)
						WHEN 'SSHR' then
							close sshr_workflow;
						WHEN 'HR' then
							close sshr_workflow;
						WHEN 'OTL' then
							close otl_workflow;	
						WHEN 'OTA' then
							close ota_workflow;
						WHEN 'IRC' then
							close irc_workflow;
						WHEN 'ALL' then						
							close all_workflow;	
						else
							null;
					end case;
					  
					  v_big_no2 :=v_big_no-1;
					  l_o('<tr><td><A class=detail onclick="hideRow2(''s1sql200'||v_big_no2||''');" href="javascript:;">Collapse records</a></td></tr>');
												
					  l_o(' </TABLE>');
		
	end if;
	:n := (dbms_utility.get_time - :n)/100;
	l_o('<tr><td><A class=detail onclick="hideRow(''s1sql55'');" href="javascript:;">Collapse section</a></td></tr>');
    l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
    l_o(' <TH COLSPAN=4 bordercolor="#DEE6EF">');
    l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
    l_o(' </TABLE> </div> ');
	
	if v_rows=0 then
		l_o('<div class="divok">');    
		l_o('<img class="check_ico">OK! No workflow in error.');
        l_o('</div>');
	else
		l_o('<div class="divwarn">');
		l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>You have '||v_rows||' workflows with errors! Please review the table and run the wfstat.sql command to take details.<br>');
		l_o('<blockquote>');
		if :apps_rel like '11.%' then
			l_o('1. Go to script directory: $FND_TOP/admin/sql<br>');
		else
			l_o('1. Go to script directory: $FND_TOP/sql<br>');
		end if;
		l_o('2. Connect to sqlplus: sqlplus apps/apps_password<br>');
		l_o('3. Spool the upcoming output to your $HOME directory: SQL> spool $HOME/wf_oracle_stat.txt<br>');
		l_o('4. Execute wfstat.sql as adviced in the table: SQL> @wfstat.sql ITEM_TYPE ITEM_KEY<br>');
		l_o('5. Turn spool off: SQL> spool off </blockquote>');
		l_o('</div>');
		:w6:=:w6+1;		
	end if;
	l_o('<div class="divok">');    
	l_o('For generic Workflow issues please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1369938.1" target="_blank">Note 1369938.1</a> ');
	l_o('Workflow Analyzer script for E-Business Suite Workflow Monitoring and Maintenance');
    l_o('</div>');
	
	l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
end if;	

EXCEPTION
					when others then
					  l_o('<br>'||sqlerrm ||' occurred in test');
					  	
end;


-- Display possible purging issues
procedure purging is
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  status varchar2(160);
  last_date date;
  status2 varchar2(160);
  last_date2 date;
  need_run boolean:=FALSE;
  days number;
  no_rows number;
  no_rows_fnd number;
  no_rows_wf number;
  issue1 boolean:=FALSE;
  issue2 boolean:=FALSE;
  issue3 boolean:=FALSE;
  issue4 boolean:=FALSE;
  arg FND_CONC_REQ_SUMMARY_V.ARGUMENT_TEXT%type;
  v_no_rows number;
   

begin
   :n := dbms_utility.get_time;
 
	if upper(product) in ('OTL','ALL') then
        
        select wf_purge.getpurgeablecount('HXCEMP') into no_rows_wf from dual;
        if no_rows_wf>1000 then
            issue1:=TRUE;
        end if;        
    end if;
    
	if upper(product) in ('HR','SSHR','ALL') then
        
        SELECT count(1) into no_rows        
              FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'COMPLETE DEFUNCT HR WORKFLOW%'
				AND upper(PHAS.MEANING || ' ' || STAT.MEANING)=upper('Completed Normal');
                
                if no_rows=0 then
                      issue2:=TRUE;
                else
                      SELECT * 
                      into status2,last_date2, arg
                      FROM (
                      SELECT PHAS.MEANING || ' ' || STAT.MEANING pStatus       
           ,ACTUAL_COMPLETION_DATE pEndDate ,ARGUMENT_TEXT       
          FROM FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_CONCURRENT_REQUESTS R
										, FND_LOOKUP_VALUES STAT
										, FND_LOOKUP_VALUES PHAS 
										WHERE PB.APPLICATION_ID = R.PROGRAM_APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
										AND PB.APPLICATION_ID = PT.APPLICATION_ID AND PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
										AND PT.LANGUAGE = 'US' and
										STAT.LOOKUP_CODE = R.STATUS_CODE
													AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
													AND PHAS.LOOKUP_CODE = R.PHASE_CODE
													AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE' and PHAS.language='US' and STAT.language='US' and PHAS.VIEW_APPLICATION_ID = 0 and STAT.VIEW_APPLICATION_ID = 0
													AND UPPER(USER_CONCURRENT_PROGRAM_NAME) LIKE 'COMPLETE DEFUNCT HR WORKFLOW%'
					  AND upper(PHAS.MEANING || ' ' || STAT.MEANING)=upper('Completed Normal')
                      ORDER BY 2 desc)
                      where rownum < 2;
              
                      select  sysdate-last_date2 into days from dual;
					  if days>180 then
								issue4:=TRUE;
					  end if;
					  
              
                end if; 
   end if;
   
    :n := (dbms_utility.get_time - :n)/100;
    
    if upper(product) in ('HR','SSHR','OTL', 'ALL') then 
        if run_type='ALL' or issue1 or issue2 or issue4 then
                
                l_o(' <a name="purge"></a>');
				l_o('<DIV class=divItem>');
				l_o('<DIV id="s1sql15b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql15'');" href="javascript:;">&#9654; Purging Issues</A></DIV>');              
                l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql15" style="display:none" >');
                l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                l_o('   <TH COLSPAN=1 bordercolor="#DEE6EF">');
                l_o('     <B>Purging issues:</B></TD>');
                l_o('     <TD bordercolor="#DEE6EF">');
                l_o('<A class=detail  id="s1sql16b"  onclick="displayItem2(this,''s1sql16'');" href="javascript:;">&#9654; Show SQL Script</A>');
                l_o('   </TD>');
                l_o(' </TR>');
                l_o(' <TR id="s1sql16" style="display:none">');
                l_o('    <TD colspan="1" height="60">');
                l_o('       <blockquote><p align="left">');
				if upper(product) in ('HR','SSHR', 'ALL') then
                      l_o('          SELECT * FROM <br>');
                      l_o('          (SELECT PHAS.MEANING || '' '' || STAT.MEANING <br>');      
                      l_o('          ,ACTUAL_COMPLETION_DATE, ARGUMENT_TEXT  <br>');   
                      l_o('          FROM FND_CONC_REQ_SUMMARY_V fcrs , FND_LOOKUPS STAT, FND_LOOKUPS PHAS<br>');
                      l_o('          WHERE STAT.LOOKUP_CODE = FCRS.STATUS_CODE<br>');
                      l_o('          AND STAT.LOOKUP_TYPE = ''CP_STATUS_CODE''<br>');
                      l_o('          AND PHAS.LOOKUP_CODE = FCRS.PHASE_CODE<br>');
                      l_o('          AND PHAS.LOOKUP_TYPE = ''CP_PHASE_CODE''<br>');
                      l_o('          AND UPPER(program) LIKE ''COMPLETE DEFUNCT HR WORKFLOW%''<br>');
					  l_o('          AND upper(PHAS.MEANING || '' '' || STAT.MEANING)=upper(''Completed Normal'')<br>');
                      l_o('          ORDER BY 2 desc)<br>');
                      l_o('          where rownum < 2;<br><br>');      
                    
                end if;
                if upper(product) in ('OTL', 'ALL') then
                      l_o('          select wf_purge.getpurgeablecount(''HXCEMP'') from dual; <br>');            
                end if;
                l_o('          </blockquote><br>');
                l_o('     </TD>');
                l_o('   </TR>');
                l_o(' <TR>');
				if upper(product) in ('OTL') then
					l_o(' <TH><B>Purgeable Obsolete Workflow</B></TD>');
					l_o(' <TH><B>Purgeable Workflow Count</B></TD>');
				else
					l_o(' <TH><B>Issue</B></TD>');
					l_o(' <TH><B>Status</B></TD>');
                end if;				
              
				if upper(product) in ('HR','SSHR', 'ALL') then
                        
                       if issue2 then
								l_o('<TR><TD>'||'Complete Defunct HR Workflow Processes'||'</TD>'||chr(10)||'<TD><font color="red">Never completed normal</font></TD></TR>'||chr(10));
						elsif issue4 then
								l_o('<TR><TD>'||'Complete Defunct HR Workflow Processes'||'</TD>'||chr(10)||'<TD>Status: '||status2||' - Last run completed normal: <font color="red">');
								l_o(last_date2||'</font> - Parameters: '||arg||'</TD></TR>'||chr(10));
						else
								l_o('<TR><TD>'||'Complete Defunct HR Workflow Processes'||'</TD>'||chr(10)||'<TD>Status: '||status2||' - Last run completed normal: ');
								l_o(last_date2||' - Parameters: '||arg||'</TD></TR>'||chr(10));
						end if;
						
                end if;
                
                if upper(product) in ('OTL', 'ALL') then
                       if issue1 then
                              l_o('<TR><TD>'||'<font color="red">wf_purge.getpurgeablecount(''HXCEMP'') </font>'||'</TD>'||chr(10)||'<TD><font color="red">'||no_rows_wf||' rows</font></TD></TR>'||chr(10));
                        else
                              l_o('<TR><TD>'||'wf_purge.getpurgeablecount(''HXCEMP'') '||'</TD>'||chr(10)||'<TD>'||no_rows_wf||' rows</TD></TR>'||chr(10));
                        end if;   
                end if;
                
              
                
               
                l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
                l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                l_o(' </TABLE> </div> ');
              
			  
              if upper(product) in ('HR','SSHR', 'ALL') then                      
                  if issue4 then                          
						  l_o('<div class="divok">');
						  l_o('<span class="sectionblue1">Advice: </span>You did not performed ''Complete Defunct HR Workflow Processes'' in last 6 months.<br>  ');
						  l_o('</div>');
                  end if;
				  if issue2 then 
					  l_o('<div class="divwarn">');
                      l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span>''Complete Defunct HR Workflow Processes'' never Completed Normal.<br>  ');
					  :w6:=:w6+1;
                      l_o('</div>');					  
                  end if;
				  if issue2 or issue4 then
                      l_o('<div class="divok">');
					  l_o('Please review <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=370095.1" target="_blank" >Note 370095.1</a> How To Cancel / Delete HR Workflow Transactions / Notifications<br>');					  
					  l_o('</div>');
                  end if;
				  
              end if;
              if upper(product) in ('OTL', 'ALL') then
                      if issue1 then
                          l_o('<div class="divwarn">');
						  l_o('<img class="warn_ico"><span class="sectionorange">Warning: </span> Your Purgeable Workflow count (for HXCEMP) is more than 1000. ');
                          l_o('Please run ''Purge Obsolete Workflow Runtime Data'' with (Item Type = OTL Workflows for Employees) from System Administrator responsibility.<br> ');
						  l_o('</div>');
						  :w6:=:w6+1;
                      end if; 
              end if;
              
              if (not issue2) and (not issue1) and (not issue4) then
                    l_o('<div class="divok">');
					l_o('All verified checks are <img class="check_ico">OK!<br>');
					l_o('</div>');
              end if;
              
			  
              l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
          end if; 
  end if;
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  
end;


-- Display invalid objects
procedure invalids is
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_name dba_objects.object_name%type; 
	v_type dba_objects.object_type%type;
	v_owner dba_objects.owner%type;
	no_invalids number;
	no_errors number;
	inv_error VARCHAR2(250);
	issue boolean := FALSE;

	cursor invalids (prod varchar2) is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like upper(prod) or object_name like 'PER%' or object_name like 'HR/_%' escape '/')
	  order by 1,2;
   cursor invalids_hr is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'PER%' or object_name like 'HR%')
	  order by 1,2;
    cursor invalids_pay is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'PAY%' or object_name like 'FF%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/')
	  order by 1,2;
    cursor invalids_otl is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'PAY%' or object_name like 'HX%' or object_name like 'WF%')
	  order by 1,2;
	cursor invalids_sshr is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' and
      (object_name like 'BEN%' or object_name like 'HR/_%' escape '/' or object_name like 'PAY%' or  object_name like 'PER%' )
	  order by 1,2;
	  
	cursor invalids_all is
	    select owner,object_name,object_type
      from dba_objects
      where status != 'VALID' and object_type != 'UNDEFINED' 
      and ROWNUM<500
	  order by 1,2;
	
	cursor invalid_errors (object varchar2, object_type varchar2, object_owner varchar2) is
	  select nvl(substr(text,1,240) ,'null')
      from   all_errors
		where  name = object
		and    type = object_type
		and    owner = object_owner
		and ROWNUM<5;

begin

  case upper(product) 
        when 'PAY' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'PAY%' or object_name like 'FF%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        when 'HR' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'PER%' or object_name like 'HR%');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        when 'BEN' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'BEN%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        when 'OTA' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'OTA%' or object_name like 'PER%' or object_name like 'HR/_%' escape '/');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
		when 'OTL' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'HX%' or object_name like 'PAY%' or object_name like 'WF%');
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        when 'SSHR' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'BEN%' or object_name like 'HR/_%' escape '/' or object_name like 'PAY%' or  object_name like 'PER%' );
              if no_invalids>0 then
                    issue:=TRUE;
              end if;		
		when 'IRC' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' 
              and (object_name like 'IRC%' or object_name like 'HR/_%' escape '/' or  object_name like 'PER%' );
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
		when 'ALL' then
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED';
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
        else
              select count(1) into no_invalids from dba_objects   where status != 'VALID' and object_type != 'UNDEFINED' ;
              if no_invalids>0 then
                    issue:=TRUE;
              end if;
  end case;
        
	if upper(run_type)='ALL' or issue then
		l_o(' <a name="invalids"></a>');
		l_o('<DIV class=divItem><a name="sum"></a>');
		l_o('<DIV id="s1sql19b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql19'');" href="javascript:;">&#9654; Invalid Objects</A></DIV>');
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql19" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('     <B>Fix next invalid objects:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql20b"  onclick="displayItem2(this,''s1sql20'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql20" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         select owner, object_name, object_type <br>');
		l_o('               from dba_objects<br>');
		l_o('               where status != ''VALID'' and object_type != ''UNDEFINED'' <br>');
		case upper(product)
		WHEN 'HR' then
			l_o('                and (object_name like ''PER%'' or object_name like ''HR%'') <br>');
		WHEN 'PAY' then
			l_o('                and (object_name like ''PAY%'' or object_name like ''FF%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'BEN' then
			l_o('                and (object_name like ''BEN%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'OTA' then
			l_o('                and (object_name like ''OTA%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'OTL' then
			l_o('                and (object_name like ''HX%'' or object_name like ''PAY%'' or object_name like ''WF%'') <br>'); 
		WHEN 'SSHR' then	
			l_o('                and (object_name like ''BEN%'' or object_name like ''PER%'' or object_name like ''PAY%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
        WHEN 'IRC' then
			l_o('                and (object_name like ''IRC%'' or object_name like ''PER%'' or object_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'ALL' then
			l_o('               and ROWNUM<500<br>');			
		ELSE
			null;
		end case;
		l_o('                order by 1,2;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Owner</B></TD>');
		l_o(' <TH><B>Object</B></TD>');
    	l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>Error</B></TD>');
	
		:n := dbms_utility.get_time;
    
    
      case upper(product) 
        when 'PAY' then
              open invalids_pay;
              loop
                    fetch invalids_pay into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_pay%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close invalids_pay;
          when 'HR' then
              open invalids_hr;
              loop
                    fetch invalids_hr into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_hr%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close invalids_hr;
          when 'SSHR' then
              open invalids_sshr;
              loop
                    fetch invalids_sshr into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_sshr%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close invalids_sshr;
			  
		  when 'BEN' then
              open invalids ('BEN');
              loop
                    fetch invalids into v_owner,v_name,v_type;
                    EXIT WHEN  invalids%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close invalids;
		  when 'OTA' then
              open invalids ('OTA');
              loop
                    fetch invalids into v_owner,v_name,v_type;
                    EXIT WHEN  invalids%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close invalids;
		  when 'IRC' then
              open invalids ('IRC');
              loop
                    fetch invalids into v_owner,v_name,v_type;
                    EXIT WHEN  invalids%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close invalids;
		  when 'OTL' then
              open invalids_otl;
              loop
                    fetch invalids_otl into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_otl%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close invalids_otl;
         else
              open invalids_all;
              loop
                    fetch invalids_all into v_owner,v_name,v_type;
                    EXIT WHEN  invalids_all%NOTFOUND;
                    l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'|| v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    select count(1) into no_errors from all_errors where name = v_name and type=v_type and owner=v_owner;
                    if no_errors>0 then
                          open invalid_errors(v_name, v_type, v_owner);
							loop
								fetch invalid_errors into inv_error;
								EXIT WHEN  invalid_errors%NOTFOUND;
								l_o(substr(inv_error,1,240)||'<br>');							  
							end loop;
							close invalid_errors;                          
                    end if;
                		l_o('</TD></TR>'||chr(10));
          		end loop;
              close invalids_all;
        end case;
        
	
		
		:n := (dbms_utility.get_time - :n)/100;
		if issue and no_invalids>10 then
			l_o('<tr><td><A class=detail onclick="hideRow(''s1sql19'');" href="javascript:;">Collapse section</a></td></tr>');
		end if;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
	
		
		if issue then
				l_o('<div class="divwarn">');
				if upper(product)='ALL' then
					l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You have '||no_invalids||' invalid object(s).<br>');	
				else
					l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You have '||no_invalids||' invalid object(s).<br>');
				end if;
				:w3:=:w3+1;
				l_o('<span class="sectionblue1">Advice:</span> Please run adadmin -> Compile apps schema.<br>');
				l_o('If you still have invalids review steps from: <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=1325394.1" target="_blank">Note 1325394.1</a>');
				l_o(' Troubleshooting Guide - invalid objects in the E-Business Suite Environment 11i and 12');
				l_o('</div>');
		elsif upper(run_type)='ALL' then
              l_o('<div class="divok">');
			  l_o('No invalid object for '||product||'<br>');
              l_o('</div>');
        end if;
		
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
		
	end if;	
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  
end;



-- Display invalid intermedia indexes
procedure intermedia is
	run_type varchar2(20):='&1';
	product varchar2(20):='&2';
	v_name dba_objects.object_name%type; 
    no_invalids number;
	issue boolean := FALSE;

	cursor intermedia is
	    select index_name
      from   dba_indexes
      where  index_name in ('HR_LOCATIONS_N1', 'HR_LOCATIONS_SPT','IRC_DOCUMENTS_CTX', 'IRC_DOCUMENTS_CTX1', 'IRC_POSTING_CON_TL_CTX', 'IRC_SEARCH_CRITERIA_CTX', 'PER_ADDRESSES_N4', 'PER_EMPDIR_PEOPLE_N1', 'PER_ADDRESSES_SPT')
      and (status!='VALID' or domidx_status!='VALID' or domidx_opstatus!='VALID');



begin

if upper(product) in ('HR','SSHR','IRC','ALL') then
	l_o(' <a name="indexes"></a>');

	  select count(1) into no_invalids from dba_indexes
		  where  index_name in ('HR_LOCATIONS_N1', 'HR_LOCATIONS_SPT','IRC_DOCUMENTS_CTX', 'IRC_DOCUMENTS_CTX1', 'IRC_POSTING_CON_TL_CTX', 'IRC_SEARCH_CRITERIA_CTX', 'PER_ADDRESSES_N4', 'PER_EMPDIR_PEOPLE_N1', 'PER_ADDRESSES_SPT')
		  and (status!='VALID' or domidx_status!='VALID' or domidx_opstatus!='VALID');
	  if no_invalids>0 then
						issue:=TRUE;
	  end if;
 
        
	if issue or upper(run_type)='ALL' then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql21b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql21'');" href="javascript:;">&#9654; Invalid Special / Intermedia Indexes</A></DIV>');
		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql21" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('     <B>Fix next invalid indexes:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql22b"  onclick="displayItem2(this,''s1sql22'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql22" style="display:none">');
		l_o('    <TD colspan="1" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('         select index_name <br>');
		l_o('          from   dba_indexes<br>');
		l_o('               where  index_name in (''HR_LOCATIONS_N1'', ''HR_LOCATIONS_SPT'',''IRC_DOCUMENTS_CTX'', <br>');
		l_o('               ''IRC_DOCUMENTS_CTX1'',  ''IRC_POSTING_CON_TL_CTX'', ''IRC_SEARCH_CRITERIA_CTX'', <br>');
		l_o('               ''PER_ADDRESSES_N4'', ''PER_EMPDIR_PEOPLE_N1'', ''PER_ADDRESSES_SPT'')<br>');
		l_o('               and (status!=''VALID'' or domidx_status!=''VALID'' or domidx_opstatus!=''VALID'');<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Index Name</B></TD>');
	
		:n := dbms_utility.get_time;
   
		open intermedia;
		loop
				fetch intermedia into v_name;
				EXIT WHEN  intermedia%NOTFOUND;
				l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'</TR>'||chr(10));           
		end loop;
		close intermedia;
       
	
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
		
		
		if issue then
			:e3:=:e3+1;
			l_o('<div class="diverr">');
			l_o('<img class="error_ico"><font color="red">Error:</font> Please fix invalid Special / Intermedia Indexes! Use<br>');
   
				if :apps_rel like '12.%' then
					  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=743720.1" target="_blank">Note 743720.1</a> Oracle Text: Re-installation and Rebuilding of Applications R12 Oracle Text Indexes<br>');
					else
						if :apps_rel like '11.5.10%' then
							  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=312640.1" target="_blank">Note 312640.1</a> Oracle Text: Re-installation of Applications 11i Oracle Text Indexes<br>');
						else
							  l_o('<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=185414.1" target="_blank">Note 185414.1</a> interMedia Text: Re-installation of Applications 11i Text Indexes (11.5.0 - 11.5.9)<br>');
						end if;
				end if;
			l_o('</div>');	
		elsif upper(run_type)='ALL' then
              l_o('<div class="divok">');
			  l_o('<img class="check_ico">OK! No invalid intermedia index.');
              l_o('</div>');
        end if;
		
		
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
  end if;	

end if;
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  
end;


-- Display disabled triggers
procedure triggers is
	run_type varchar2(20):='&1';
    product varchar2(20):='&2';
	v_owner dba_triggers.owner%type; 
	v_table dba_triggers.table_name%type;
    v_trigger dba_triggers.trigger_name%type;
	v_status all_triggers.status%type;
    no_triggers number;
	no_triggers2 number;
 	issue boolean := FALSE;
	issue_alr boolean := FALSE;
	issue_only_alr boolean := FALSE;
	cursor disabled_triggers (prod varchar2) is
	  select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR','HXT','HXC','HRI','BEN')
      and (table_name like upper(prod)||'%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
      order by 1, 2, 3;
  cursor disabled_triggers_pay is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR')
      and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
      order by 1, 2, 3;    
   cursor disabled_triggers_sshr is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR')
      and (table_name like 'PAY%' or table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
      order by 1, 2, 3;    
  cursor disabled_triggers_otl is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR','HXT','HXC')
      and (table_name like 'PAY%' or table_name like 'HX%')
      order by 1, 2, 3; 
  cursor disabled_triggers_all is
	    select owner, table_name, trigger_name 
      from dba_triggers
      where status = 'DISABLED'
      and table_owner in ('HR','HXT','HXC','HRI','BEN')
      order by 1, 2, 3;
  cursor who_triggers is
	  select TABLE_NAME,TRIGGER_NAME,STATUS 
		  from all_triggers 
		  where UPPER(table_name) in 
			 ( 'PER_ALL_PEOPLE_F', 'PER_ALL_ASSIGNMENTS_F', 'PER_PERIODS_OF_SERVICE', 'PER_PERSON_TYPE_USAGES_F', 'PER_ADDRESSES'
			 , 'HR_LOCATIONS_ALL', 'HR_LOCATIONS_ALL_TL', 'HR_ALL_ORGANIZATION_UNITS', 'HR_ALL_ORGANIZATION_UNITS_TL', 'HR_ALL_POSITIONS_F'
			 , 'HR_ALL_POSITIONS_F_TL', 'PER_ALL_POSITIONS', 'PER_JOBS', 'PER_JOBS_TL')
		  and TRIGGER_NAME like '%WHO%'
		  and OWNER like 'APPS%'		  
		  order by table_name, trigger_name;
	cursor ovn_triggers is
	 select TABLE_NAME,TRIGGER_NAME,STATUS 
      from all_triggers 
      where OWNER like 'APPS%'
      and (trigger_name like 'HR%OVN%' or  trigger_name like 'PER%OVN%')
      order by owner, table_name;
begin

	  l_o(' <a name="triggers"></a>');
	  case upper(product) 
			when 'PAY' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'FF%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'HR' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HRI')
				  and (table_name like 'HR%' or table_name like 'PER%');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HRI') and (table_name like 'HR%' or table_name like 'PER%')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'SSHR' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR')
				  and (table_name like 'PAY%' or table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'BEN' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','BEN')
				  and (table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','BEN')
				  and (table_name like 'BEN%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'OTA' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','OTA')
				  and (table_name like 'OTA%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','OTA')
				  and (table_name like 'OTA%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'IRC' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','BEN')
				  and (table_name like 'IRC%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','BEN')
				  and (table_name like 'IRC%' or table_name like 'PER%' or table_name like 'HR/_%' escape '/')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			when 'OTL' then
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HXT','HXC')
				  and (table_name like 'HX%' or table_name like 'PAY%');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HXT','HXC')
				  and (table_name like 'HX%' or table_name like 'PAY%')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
			else
				  select count(1) into no_triggers from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HXT','HXC','HRI','BEN');
				  if no_triggers>0 then
						issue:=TRUE;
				  end if;
				  select count(1) into no_triggers2 from dba_triggers   where status = 'DISABLED'
				  and table_owner in ('HR','HXT','HXC','HRI','BEN')
				  and trigger_name like 'ALR%';
				  if no_triggers2>0 then
						issue_alr:=TRUE;
						if no_triggers2=no_triggers then
							issue_only_alr:=TRUE;
						end if;
				  end if;
	  end case;
	 
        
	if (issue and not issue_only_alr) or upper(run_type)='ALL' then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql76b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql76'');" href="javascript:;">&#9654; Triggers</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="3" id="s1sql76" style="display:none" >');
		l_o(' <TR><TH>');
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql23b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql23'');" href="javascript:;">&#9654; Disabled Triggers</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql23" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>Disabled triggers:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql24b"  onclick="displayItem2(this,''s1sql24'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql24" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select owner, table_name, trigger_name <br> from dba_triggers <br> where status = ''DISABLED'' <br>');
		l_o('                and table_owner in (''HR'',''HXT'',''HXC'',''HRI'',''BEN'') <br>');
		CASE upper(product)
		WHEN 'HR' then
			l_o('                and (table_name like ''PER%'' or table_name like ''HR%'') <br>');
		WHEN 'PAY' then
			l_o('                and (table_name like ''PAY%'' or table_name like ''FF%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'SSHR' then
			l_o('                and (table_name like ''PAY%'' or table_name like ''BEN%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'BEN' then
			l_o('                and (table_name like ''BEN%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'OTA' then
			l_o('                and (table_name like ''OTA%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		WHEN 'OTL' then
			l_o('                and (table_name like ''HX%'' or table_name like ''PAY%'') <br>'); 
		WHEN 'IRC' then
			l_o('                and (table_name like ''IRC%'' or table_name like ''PER%'' or table_name like ''HR/_%'' escape ''/'') <br>'); 
		ELSE
			null;
		end case;
		l_o('                order by 1, 2, 3; <br>');
		l_o('          </blockquote><br>');
		l_o('     </TD></TR><TR>');
		l_o(' <TH><B>Owner</B></TD>');
		l_o(' <TH><B>Table name</B></TD>');
		l_o(' <TH><B>Trigger Name</B></TD>');
	
		:n := dbms_utility.get_time;
    
		CASE upper(product)
		WHEN 'ALL' then
			  open disabled_triggers_all;
			  loop
				 fetch disabled_triggers_all into v_owner,v_table,v_trigger;
				 EXIT WHEN  disabled_triggers_all%NOTFOUND;
				 if v_trigger like 'ALR%' then
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					l_o('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			  end loop;
			  close disabled_triggers_all;
		WHEN 'PAY' then
			 open disabled_triggers_pay;
			  loop
				 fetch disabled_triggers_pay into v_owner,v_table,v_trigger;
				 EXIT WHEN  disabled_triggers_pay%NOTFOUND;
				 if v_trigger like 'ALR%' then
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					l_o('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			  end loop;
			close disabled_triggers_pay;
		WHEN 'OTL' then
			open disabled_triggers_otl;
			loop
			   fetch disabled_triggers_otl into v_owner,v_table,v_trigger;
			   EXIT WHEN  disabled_triggers_otl%NOTFOUND;
			   if v_trigger like 'ALR%' then
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				else
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					l_o('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				end if;
			end loop;
			close disabled_triggers_otl;
		WHEN 'SSHR' then
			open disabled_triggers_sshr;
			loop
			   fetch disabled_triggers_sshr into v_owner,v_table,v_trigger;
			   EXIT WHEN  disabled_triggers_sshr%NOTFOUND;
			   if v_trigger like 'ALR%' then
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
			   else
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					l_o('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
			   end if;
			end loop;
			close disabled_triggers_sshr;
		else
			open disabled_triggers(product);
			loop
				 fetch disabled_triggers into v_owner,v_table,v_trigger;
				 EXIT WHEN  disabled_triggers%NOTFOUND;
				 if v_trigger like 'ALR%' then
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD></TR>'||chr(10));
				 else
					l_o('<TR><TD>'||v_owner||'</TD>'||chr(10)||'<TD>'||v_table||'</TD>'||chr(10));
					l_o('<TD><font color="#CC3311">'||v_trigger||'</font></TD></TR>'||chr(10));
				 end if;
			end loop;
			close disabled_triggers;
		end case;
    
     
		:n := (dbms_utility.get_time - :n)/100;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
		
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql77b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql77'');" href="javascript:;">&#9654; WHO Triggers</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql77" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>WHO triggers:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql78b"  onclick="displayItem2(this,''s1sql78'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD></TR>');
		l_o(' <TR id="s1sql78" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select TABLE_NAME,TRIGGER_NAME,STATUS from all_triggers  where UPPER(table_name) in <br>');
		l_o('	 ( ''PER_ALL_PEOPLE_F'', ''PER_ALL_ASSIGNMENTS_F'', ''PER_PERIODS_OF_SERVICE'', ''PER_PERSON_TYPE_USAGES_F'', ''PER_ADDRESSES''<br>');
		l_o('	 , ''HR_LOCATIONS_ALL'', ''HR_LOCATIONS_ALL_TL'', ''HR_ALL_ORGANIZATION_UNITS'', ''HR_ALL_ORGANIZATION_UNITS_TL'', ''HR_ALL_POSITIONS_F''<br>');
		l_o('	 , ''HR_ALL_POSITIONS_F_TL'', ''PER_ALL_POSITIONS'', ''PER_JOBS'', ''PER_JOBS_TL'')<br>');
		l_o('  and TRIGGER_NAME like ''%WHO%''  and OWNER like ''APPS%''	 order by table_name, trigger_name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD></TR><TR>');
		l_o(' <TH><B>Table name</B></TD>');
		l_o(' <TH><B>Trigger Name</B></TD>');
		l_o(' <TH><B>Status</B></TD>');
	
		:n := dbms_utility.get_time;   

		open who_triggers;
			loop
				 fetch who_triggers into v_table,v_trigger,v_status;
				 EXIT WHEN  who_triggers%NOTFOUND;
				 l_o('<TR><TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD>'||chr(10));
				 if v_status <> 'ENABLED' then
					l_o('<TD><font color="#CC3311">'||v_status||'</font></TD></TR>'||chr(10));
				 else
				    l_o('<TD>'||v_status||'</font></TD></TR>'||chr(10));
				 end if;
			end loop;
			close who_triggers;

		:n := (dbms_utility.get_time - :n)/100;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> ');
		
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql79b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql79'');" href="javascript:;">&#9654; OVN Triggers</A></DIV>');		
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql79" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=2 bordercolor="#DEE6EF">');
		l_o('     <B>OVN triggers:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql80b"  onclick="displayItem2(this,''s1sql80'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql80" style="display:none">');
		l_o('    <TD colspan="2" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select TABLE_NAME,TRIGGER_NAME,STATUS from all_triggers  where OWNER like ''APPS%''<br>');
		l_o('and (trigger_name like ''HR%OVN%'' or  trigger_name like ''PER%OVN%'')  order by owner, table_name; <br>');
		l_o('          </blockquote><br>');
		l_o('     </TD></TR><TR>');
		l_o(' <TH><B>Table name</B></TD>');
		l_o(' <TH><B>Trigger Name</B></TD>');
		l_o(' <TH><B>Status</B></TD>');	
		:n := dbms_utility.get_time;    

		open ovn_triggers;
			loop
				 fetch ovn_triggers into v_table,v_trigger,v_status;
				 EXIT WHEN  ovn_triggers%NOTFOUND;
				 l_o('<TR><TD>'||v_table||'</TD>'||chr(10)||'<TD>'||v_trigger||'</TD>'||chr(10));
				 if v_status <> 'ENABLED' then
					l_o('<TD><font color="#CC3311">'||v_status||'</font></TD></TR>'||chr(10));
				 else
				    l_o('<TD>'||v_status||'</font></TD></TR>'||chr(10));
				 end if;
			end loop;
			close ovn_triggers;

    
     
		:n := (dbms_utility.get_time - :n)/100;
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=1 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE> </div> </th></tr></table> </div> ');
		
		
		if issue and (not issue_alr) then
			l_o('<div class="divwarn">');
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You have disabled trigger(s).<br>');
			l_o('In order to re-enable use command: alter trigger trigger_name enable<br>');
			l_o('</div>');
			:w3:=:w3+1;
		elsif issue_only_alr then
			l_o('<div class="divok">');
			l_o(' You have disabled trigger(s) only related to alert. These are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.<br>');
			l_o('</div>');
   		elsif issue_alr and (not issue_only_alr) then
			l_o('<div class="divwarn">');
			l_o('<img class="warn_ico"><span class="sectionorange">Warning:</span> You have disabled trigger(s).<br>');
			l_o('In order to re-enable use command: alter trigger trigger_name enable<br>');
			l_o('You have disabled trigger(s) related to alert (ALR_). These are event triggers created inside Oracle Alert, so you can ignore them if not using Oracle Alert.<br>');
			l_o('Please focus on non ALR_ disabled triggers.<br>');
			l_o('</div>');
			:w3:=:w3+1;
		elsif upper(run_type)='ALL' and (not issue) then             
            l_o('<div class="divok">');
			l_o('<img class="check_ico">OK! No disabled trigger.<br>');
            l_o('</div>');
        end if;
		
		
		l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
	end if;	
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  	
end;



-- Display desyncronization in database
procedure timestampd is
	run_type varchar2(20):='&1';
 	issue boolean := FALSE;
    v_problems number:=0;
begin
     select count(1) into v_problems
     from sys.obj$ do, sys.dependency$ d, sys.obj$ po
     where p_obj#=po.obj#(+)
     and d_obj#=do.obj#
     and do.status=1 /*dependent is valid*/
     and po.status=1 /*parent is valid*/
     and po.stime!=p_timestamp /*parent timestamp does not match*/
     and do.type# not in (28,29,30) /*dependent type is not java*/
     and po.type# not in (28,29,30) /*parent type is not java*/;
     
 
     IF v_problems>0 or upper(run_type)='ALL' then
              		l_o(' <a name="timestamp"></a>');
                  l_o('<DIV class=divItem><a name="sum"></a>');
				 l_o('<DIV id="s1sql25b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql25'');" href="javascript:;">&#9654; Dependency timestamp discrepancies</A></DIV>');                  
                  l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="0" id="s1sql25" style="display:none" >');
                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                  l_o('   <TH COLSPAN=0 bordercolor="#DEE6EF">');
                  l_o('     <B>Dependency timestamp discrepancies between the database objects:</B></font></TD>');
                  l_o('     <TD bordercolor="#DEE6EF">');
                  l_o('<A class=detail  id="s1sql26b"  onclick="displayItem2(this,''s1sql26'');" href="javascript:;">&#9654; Show SQL Script</A>');
                  l_o('   </TD>');
                  l_o(' </TR>');
                  l_o(' <TR id="s1sql26" style="display:none">');
                  l_o('    <TD colspan="0" height="60">');
                  l_o('       <blockquote><p align="left">');
                  l_o('          select count(1)  <br>');
                  l_o('                from sys.obj$ do, sys.dependency$ d, sys.obj$ po <br>');
                  l_o('                     where p_obj#=po.obj#(+)<br>');
                  l_o('                     and d_obj#=do.obj#<br>');
                  l_o('                     and do.status=1 /*dependent is valid*/<br>');
                  l_o('                     and po.status=1 /*parent is valid*/<br>');
                  l_o('                     and po.stime!=p_timestamp /*parent timestamp does not match*/<br>');
                  l_o('                     and do.type# not in (28,29,30) /*dependent type is not java*/<br>');
                  l_o('                     and po.type# not in (28,29,30) /*parent type is not java*/;<br>');
                  l_o('          </blockquote><br>');
                  l_o('     </TD>');
                  l_o('   </TR>');
                  l_o(' <TR>');
                  l_o(' <TH><B>Number</B></TD>');
                
                  :n := dbms_utility.get_time;
                  
                  l_o('<TR><TD>'||v_problems||'</TD></TR>'||chr(10));
                   
                
                  :n := (dbms_utility.get_time - :n)/100;
                  l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
                  l_o(' <TH COLSPAN=0 bordercolor="#DEE6EF">');
                  l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
                  l_o(' </TABLE> </div> ');
                  
				  
                  if v_problems>0 then
						l_o('<div class="diverr">');
                        l_o('<img class="error_ico"><font color="red">Error:</font> You have dependency timestamp discrepancies between the database objects.<br>');
                        l_o('Please follow <a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER\&sourceId=1562530.1\&id=370137.1" target="_blank">Note 370137.1</a>' );
                        l_o('After Upgrade, Some Packages Intermittently Fail with ORA-04065');                     
                        l_o('</div>');
						:e3:=:e3+1;
                  elsif upper(run_type)='ALL' then
                        l_o('<div class="divok">');
						l_o('<img class="check_ico">OK! No dependency timestamp discrepancies between the database objects found.');
                        l_o('</div>');
                  end if;
				  
				  l_o(' <br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
     end if;
EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  
end;


-- Display packages version
procedure packages is
  run_type varchar2(20):='&1';
  product varchar2(20):='&2';
  v_name dba_source.name%type;
  v_type varchar2(50);
  v_file  varchar2(100);
  v_version varchar2(100);
  v_status varchar2(50);
  wtf_version ad_file_versions.version%type;
  
  cursor package_vers(prod varchar2) is
  SELECT name,decode(type,'PACKAGE', 'PACKAGE SPEC',type),
	ltrim(rtrim(substr(substr(text, instr(text,'Header: ')),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 1),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2) -
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 1)
    ))) ,
    ltrim(rtrim(substr(substr(text, instr(text,'Header: ')),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 3) -
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2)
    )))
				 FROM dba_source c
				 WHERE owner = 'APPS'
				 AND   name like  upper(prod)||'%'
				AND   type in ('PACKAGE BODY','PACKAGE')
				AND   line = 2
				AND   text like '%$Header%'
				order by name;

  cursor package_vers_otl is
  SELECT name,decode(type,'PACKAGE', 'PACKAGE SPEC',type),
	ltrim(rtrim(substr(substr(text, instr(text,'Header: ')),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 1),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2) -
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 1)
    ))) ,
    ltrim(rtrim(substr(substr(text, instr(text,'Header: ')),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 3) -
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2)
    )))
				 FROM dba_source c
				 WHERE owner = 'APPS' AND (name like 'HX%' or 
        name in ('PAGTCX',
        'PA_OTC_API',
        'PAY_BATCH_ELEMENT_ENTRY_API' ,
        'PAY_HR_OTC_RETRIEVAL_INTERFACE' ,
        'PAY_HXC_DEPOSIT_INTERFACE' ,
        'PAY_ZA_SOTC_PKG'  ,
        'PA_OTC_API' , 
        'PA_PJC_CWK_UTILS'  ,
        'PA_TIME_CLIENT_EXTN' ,
        'PO_HXC_INTERFACE_PVT',
        'RCV_HXT_GRP')
        ) 
  AND   type in ('PACKAGE BODY','PACKAGE')
				AND   line = 2
				AND   text like '%$Header%'
				order by name;
  
  cursor package_vers_hr is
  SELECT name,decode(type,'PACKAGE', 'PACKAGE SPEC',type),
	ltrim(rtrim(substr(substr(text, instr(text,'Header: ')),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 1),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2) -
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 1)
    ))) ,
    ltrim(rtrim(substr(substr(text, instr(text,'Header: ')),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 3) -
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2)
    )))
				 FROM dba_source c
				 WHERE owner = 'APPS'
				 AND   (name like  'HR%' or name like 'PER%')
				AND   type in ('PACKAGE BODY','PACKAGE')
				AND   line = 2
				AND   text like '%$Header%'
				order by name;

  cursor package_vers_sshr is
  SELECT name,decode(type,'PACKAGE', 'PACKAGE SPEC',type),
	ltrim(rtrim(substr(substr(text, instr(text,'Header: ')),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 1),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2) -
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 1)
    ))) ,
    ltrim(rtrim(substr(substr(text, instr(text,'Header: ')),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2),
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 3) -
    instr(substr(text, instr(text,'Header: ')), ' ', 1, 2)
    )))
				 FROM dba_source c
				 WHERE owner = 'APPS'
				 AND   (name like 'HR/_%' escape '/' or name like 'PER%')
				AND   type in ('PACKAGE BODY','PACKAGE')
				AND   line = 2
				AND   text like '%$Header%'
				order by name;
  
Begin

  if upper(run_type)='ALL'  then
         
	l_o('<a name="packages"></a>');
	
	l_o('<DIV class=divItem><a name="packages"></a>');
	l_o('<DIV id="s1sql27b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql27'');" href="javascript:;">');
	
	if upper(product) = 'PAY' then	
		l_o('&#9654; PAY Packages version</A></DIV>');
	elsif upper(product) = 'ALL' then
		l_o('&#9654; BEN Packages version</A></div>');
	else	
		l_o('&#9654; Packages version</A></div>');
	end if;
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql27" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('     <B>Packages version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql28b"  onclick="displayItem2(this,''s1sql28'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql28" style="display:none">');
		l_o('    <TD colspan="3" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select Name as Package, <br>');
		l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		l_o('          from dba_source <br>');
    CASE upper(product) 
	WHEN 'OTL' then
        l_o('                where (name like ''HX%'' or <br>');
        l_o('                  name in (''PAGTCX'', <br>');
        l_o('                  ''PA_OTC_API'',<br>');
        l_o('                  ''PAY_BATCH_ELEMENT_ENTRY_API'' ,<br>');
        l_o('                  ''PAY_HR_OTC_RETRIEVAL_INTERFACE'' ,<br>');
        l_o('                  ''PAY_HXC_DEPOSIT_INTERFACE'' ,<br>');
        l_o('                  ''PAY_ZA_SOTC_PKG''  ,<br>');
        l_o('                  ''PA_OTC_API'' , <br>');
        l_o('                  ''PA_PJC_CWK_UTILS''  ,<br>');
        l_o('                  ''PA_TIME_CLIENT_EXTN'' ,<br>');
        l_o('                  ''PO_HXC_INTERFACE_PVT'',<br>');
        l_o('                  ''RCV_HXT_GRP''))<br>');    
    WHEN 'HR'  then    
        l_o('          where (name like ''HR%'' or name like ''PER%'') <br>');
    WHEN 'SSHR'  then    
        l_o('          where name like (''HR/_%'' escape ''/'' or name like ''PER%'') <br>');
    WHEN 'PAY' then
        l_o('          where name like  ''PAY%'' <br>');
    WHEN 'BEN' then
        l_o('          where name like  ''BEN%'' <br>');
    WHEN 'OTA' then
        l_o('          where name like  ''OTA%'' <br>');
	WHEN 'IRC' then
        l_o('          where name like  ''IRC%'' <br>');
	WHEN 'ALL' then
		l_o('          where name like  ''BEN%'' <br>');
	ELSE
		null;
	end case;
    l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
	l_o('          order by Name;<br>');
	l_o('          </blockquote><br>');
	l_o('     </TD>');
	l_o('   </TR>');
	l_o(' <TR>');
	l_o(' <TH><B>Name</B></TD>');
    l_o(' <TH><B>Type</B></TD>');
	l_o(' <TH><B>File</B></TD>');
    l_o(' <TH><B>Version</B></TD>');

	
	:n := dbms_utility.get_time;
    
   
    case upper(product) 
        when 'PAY' then
              open package_vers('PAY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
			  open package_vers('PY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
          when 'HR' then
              open package_vers_hr;
              loop
                    fetch package_vers_hr into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers_hr%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
					l_o(v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers_hr;
          when 'SSHR' then
              open package_vers_sshr;
              loop
                    fetch package_vers_sshr into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers_sshr%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
					l_o(v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers_sshr;        
		 when 'BEN' then
              open package_vers ('BEN');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
					l_o(v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
          when 'OTA' then
              open package_vers ('OTA');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
					l_o(v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
		  when 'ALL' then
              open package_vers ('BEN');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
					l_o(v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
		  when 'IRC' then
              open package_vers ('IRC');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
					l_o(v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
		  when 'OTL' then                         
                select sub.version into wtf_version
                from (
                   select adf.filename filename,
                   afv.version version,
                   rank()over(partition by adf.filename
                     order by afv.version_segment1 desc,
                     afv.version_segment2 desc,afv.version_segment3 desc,
                     afv.version_segment4 desc,afv.version_segment5 desc,
                     afv.version_segment6 desc,afv.version_segment7 desc,
                     afv.version_segment8 desc,afv.version_segment9 desc,
                     afv.version_segment10 desc,
                     afv.translation_level desc) as rank1
                   from ad_file_versions afv,
                     (
                     select filename, app_short_name, subdir, file_id
                     from ad_files
                     where upper(filename) like upper('hxcempwf.wft') and subdir like '%US%'
                     ) adf
                   where adf.file_id = afv.file_id
                ) sub
                where rank1 = 1 and rownum < 2;
               l_o('<TR><TD>hxcempwf.wft</TD>'||chr(10)||'<TD>-</TD>'||chr(10)||'<TD>');
               l_o('hxcempwf.wft</TD>'||chr(10)||'<TD>'||wtf_version);
               l_o('</TD></TR>'||chr(10));
              
              open package_vers_otl;
              loop
                    fetch package_vers_otl into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers_otl%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
					l_o(v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers_otl;
         
		 else
              null;
    end case;
  
   
	:n := (dbms_utility.get_time - :n)/100;
	l_o('<tr><td><A class=detail onclick="hideRow(''s1sql27'');" href="javascript:;">Collapse section</a></td></tr>');
	l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
	l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF">');
	l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
	l_o(' </TABLE></div> ');    

	 l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
  

  if upper(run_type)='ALL' and upper(product) in ( 'PAY', 'ALL') then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql272b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql272'');" href="javascript:;">');
		if upper(product) = 'PAY' then	
			l_o('&#9654; FF Packages version</A></div>');
		elsif upper(product) = 'ALL' then
			l_o('&#9654; IRC Packages version</A></div>');
		end if;
			l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql272" style="display:none" >');
			l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
			l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF">');
			l_o('     <B>Packages version:</B></font></TD>');
			l_o('     <TD bordercolor="#DEE6EF">');
			l_o('<A class=detail  id="s1sql282b"  onclick="displayItem2(this,''s1sql282'');" href="javascript:;">&#9654; Show SQL Script</A>');
			l_o('   </TD>');
			l_o(' </TR>');
			l_o(' <TR id="s1sql282" style="display:none">');
			l_o('    <TD colspan="3" height="60">');
			l_o('       <blockquote><p align="left">');
			l_o('          select Name as Package, <br>');
			l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
			l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
			l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
			l_o('          from dba_source <br>');
		if upper(product) = 'PAY' then
			l_o('          where name like ''FF%'' <br>');
		else   
			l_o('          where name like  ''IRC%'' <br>');
		end if;
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
		l_o('          order by Name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Name</B></TD>');
		l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>File</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;
		
	   
		case upper(product) 
			when 'PAY' then
				  open package_vers('FF');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
				  close package_vers;      
			  when 'ALL' then
				  open package_vers ('IRC');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						l_o(v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
				  close package_vers;		
			 else
				  null;
		end case;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql272'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
  end if;
  

  if upper(run_type)='ALL' and upper(product) in ( 'PAY', 'ALL') then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql273b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql273'');" href="javascript:;">');
		l_o('&#9654; HR Packages version</A></div>');
	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql273" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('     <B>Packages version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql283b"  onclick="displayItem2(this,''s1sql283'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql283" style="display:none">');
		l_o('    <TD colspan="3" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select Name as Package, <br>');
		l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		l_o('          from dba_source <br>');
		l_o('          where (name like ''HR%'' or name like ''PER%'') <br>');
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
		l_o('          order by Name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Name</B></TD>');
		l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>File</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;
		
	   
		open package_vers_hr;
				  loop
						fetch package_vers_hr into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers_hr%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						l_o(v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
		close package_vers_hr;
  
		
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql273'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    end if;
	
  if upper(run_type)='ALL' and upper(product) = 'ALL' then
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql274b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql274'');" href="javascript:;">');		
		l_o('&#9654; OTL Packages version</A></div>');		
		
	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql274" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('     <B>Packages version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql284b"  onclick="displayItem2(this,''s1sql284'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql284" style="display:none">');
		l_o('    <TD colspan="3" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select Name as Package, <br>');
		l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		l_o('          from dba_source <br>');
		l_o('                where (name like ''HX%'' or <br>');
        l_o('                  name in (''PAGTCX'', <br>');
        l_o('                  ''PA_OTC_API'',<br>');
        l_o('                  ''PAY_BATCH_ELEMENT_ENTRY_API'' ,<br>');
        l_o('                  ''PAY_HR_OTC_RETRIEVAL_INTERFACE'' ,<br>');
        l_o('                  ''PAY_HXC_DEPOSIT_INTERFACE'' ,<br>');
        l_o('                  ''PAY_ZA_SOTC_PKG''  ,<br>');
        l_o('                  ''PA_OTC_API'' , <br>');
        l_o('                  ''PA_PJC_CWK_UTILS''  ,<br>');
        l_o('                  ''PA_TIME_CLIENT_EXTN'' ,<br>');
        l_o('                  ''PO_HXC_INTERFACE_PVT'',<br>');
        l_o('                  ''RCV_HXT_GRP''))<br>');    
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
		l_o('          order by Name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Name</B></TD>');
		l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>File</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;
		
	   
		select sub.version into wtf_version
					from (
					   select adf.filename filename,
					   afv.version version,
					   rank()over(partition by adf.filename
						 order by afv.version_segment1 desc,
						 afv.version_segment2 desc,afv.version_segment3 desc,
						 afv.version_segment4 desc,afv.version_segment5 desc,
						 afv.version_segment6 desc,afv.version_segment7 desc,
						 afv.version_segment8 desc,afv.version_segment9 desc,
						 afv.version_segment10 desc,
						 afv.translation_level desc) as rank1
					   from ad_file_versions afv,
						 (
						 select filename, app_short_name, subdir, file_id
						 from ad_files
						 where upper(filename) like upper('hxcempwf.wft') and subdir like '%US%'
						 ) adf
					   where adf.file_id = afv.file_id
					) sub
					where rank1 = 1 and rownum < 2;
				   l_o('<TR><TD>hxcempwf.wft</TD>'||chr(10)||'<TD>-</TD>'||chr(10)||'<TD>');
				   l_o('hxcempwf.wft</TD>'||chr(10)||'<TD>'||wtf_version);
				   l_o('</TD></TR>'||chr(10));
				  
		open package_vers_otl;
				  loop
						fetch package_vers_otl into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers_otl%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						l_o(v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
		close package_vers_otl;
	  
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql274'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');
    
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql276b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql276'');" href="javascript:;">');		
		l_o('&#9654; OTA Packages version</A></div>');		
		
	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql276" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('     <B>Packages version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql286b"  onclick="displayItem2(this,''s1sql286'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql286" style="display:none">');
		l_o('    <TD colspan="3" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select Name as Package, <br>');
		l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		l_o('          from dba_source <br>');
		l_o('                where  where name like  ''OTA%'' <br>');      
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
		l_o('          order by Name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Name</B></TD>');
		l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>File</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;	   
	
				  
		open package_vers('OTA');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						l_o(v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
		close package_vers;	  
	  
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql276'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>'); 
		
		l_o('<DIV class=divItem>');
		l_o('<DIV id="s1sql275b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql275'');" href="javascript:;">');		
		l_o('&#9654; PAY Packages version</A></div>');		
		
	
		l_o(' <TABLE width="95%" border="1" cellspacing="0" cellpadding="2" id="s1sql275" style="display:none" >');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o('   <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('     <B>Packages version:</B></font></TD>');
		l_o('     <TD bordercolor="#DEE6EF">');
		l_o('<A class=detail  id="s1sql285b"  onclick="displayItem2(this,''s1sql285'');" href="javascript:;">&#9654; Show SQL Script</A>');
		l_o('   </TD>');
		l_o(' </TR>');
		l_o(' <TR id="s1sql285" style="display:none">');
		l_o('    <TD colspan="3" height="60">');
		l_o('       <blockquote><p align="left">');
		l_o('          select Name as Package, <br>');
		l_o('          decode(type,''PACKAGE'', ''PACKAGE SPEC'',type) as Type,<br>');
		l_o('          substr(text,instr(text,''$Header: '',1,1)+9 , instr(text,''.p'',1,1) - instr(text,''$Header: '',1,1)-5 ) as FileName ,<br>'); 
		l_o('          substr(text,instr(text,''.p'')+4, instr(text ,'' '' ,instr(text,''.p'')+3, 2)- instr(text,''.p'')-4) as Version<br>');
		l_o('          from dba_source <br>');
		l_o('          where name like  ''PAY%'' <br>');
		l_o('          and instr(text,''$Header'') <>0 and line =2 <br>');
		l_o('          order by Name;<br>');
		l_o('          </blockquote><br>');
		l_o('     </TD>');
		l_o('   </TR>');
		l_o(' <TR>');
		l_o(' <TH><B>Name</B></TD>');
		l_o(' <TH><B>Type</B></TD>');
		l_o(' <TH><B>File</B></TD>');
		l_o(' <TH><B>Version</B></TD>');

		
		:n := dbms_utility.get_time;
		
	   
		open package_vers('PAY');
				  loop
						fetch package_vers into v_name,v_type,v_file,v_version;
						EXIT WHEN  package_vers%NOTFOUND;
						l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>');
						l_o(v_type||'</TD>'||chr(10)||'<TD>');
						l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
						l_o('</TD></TR>'||chr(10));
					end loop;
		close package_vers;	  
		open package_vers('PY');
              loop
                    fetch package_vers into v_name,v_type,v_file,v_version;
                    EXIT WHEN  package_vers%NOTFOUND;
                    l_o('<TR><TD>'||v_name||'</TD>'||chr(10)||'<TD>'||v_type||'</TD>'||chr(10)||'<TD>');
                    l_o(v_file||'</TD>'||chr(10)||'<TD>'||v_version);
                	l_o('</TD></TR>'||chr(10));
          		end loop;
              close package_vers;
		:n := (dbms_utility.get_time - :n)/100;
		l_o('<tr><td><A class=detail onclick="hideRow(''s1sql275'');" href="javascript:;">Collapse section</a></td></tr>');
		l_o(' <TR bgcolor="#DEE6EF" bordercolor="#DEE6EF">');
		l_o(' <TH COLSPAN=3 bordercolor="#DEE6EF">');
		l_o('<i> Elapsed time '||:n|| ' seconds</i> </font></TD> </TR> ');
		l_o(' </TABLE></div> ');
    

		l_o('<br><A href="#top"><font size="-1">Back to Top</font></A><BR> <br>');

	
  end if;

  EXCEPTION
when others then
l_o('<br>'||sqlerrm ||' occurred in test');
  
end;



-- 3rd main program (split because "program too long" error)
begin  -- begin1
declare
	run_type varchar2(20):='&1';
  product varchar2(20):='&2';

  begin -- begin MAIN
	:g_curr_loc:=1;
	DBMS_LOB.CREATETEMPORARY(:g_hold_output3,TRUE,DBMS_LOB.SESSION);
	
	l_o('<BR>'); 	

	l_o('<div id="page5" style="display: none;">');
	l_o('<a name="database"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">');
	l_o('<div class="left"  id="database" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Database Objects: '); 
	l_o('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    l_o('<a class="detail" onclick="openall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    l_o('</div><div class="clear"></div></div><br>');
	if upper(run_type)='ALL' then
	l_o('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	l_o('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	 l_o('<a class=detail2 href="#invalids">Invalid Objects</a> <br>');
      if upper(product) in ('HR','SSHR','IRC','ALL') then
          l_o('<a class=detail2 href="#indexes">Invalid Special / Intermedia Indexes</a> <br>');
      end if;
      l_o('<a class=detail2 href="#triggers">Triggers</a> <br></td><td class="toctable">');
      l_o('<a class=detail2 href="#timestamp">Dependency timestamp discrepancies</a> <br>');
      l_o('<a class=detail2 href="#packages">Packages Versions</a> <br>');
      l_o('<a class=detail2 href="#java">Java Classes Versions</a> <br></td><tr></table>');   
	l_o('</div><br>');
	end if;
	invalids();
	intermedia();
	triggers();
	timestampd();
	packages();	
	javacl();
	l_o('</div></div>');
	
	
	if upper(product) in ('HR','SSHR', 'OTL','IRC','OTA','ALL') then
	l_o('<div id="page6" style="display: none;">');
	l_o('<a name="workflow"></a><a name="stuck"></a><div class="divSection">');
	l_o('<div class="divSectionTitle">');
	l_o('<div class="left"  id="workflow" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">Workflow Details: '); 
	l_o('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    l_o('<a class="detail" onclick="openall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    l_o('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
    l_o('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    l_o('</div><div class="clear"></div></div><br>');
	if upper(run_type)='ALL' then
	l_o('<div class="divItem"><div class="divItemTitle">In This Section</div>');
	l_o('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
	 if product in ('HR','SSHR','OTL','ALL') then
			  l_o('<a class=detail2 href="#purge">Purging</a> <br>');
		  end if;
	  l_o('<a class=detail2 href="#stuck">Workflows with Errors</a> <br></td><tr></table>');       
	l_o('</div><br>');
	end if;
	purging();
	workflow();	
	l_o('</div></div>');
	end if;
	
	
	
EXCEPTION
when others then
  l_o('<br>'||sqlerrm ||' occurred in test');
  

end;
end;
/

-- Print output
print :g_hold_output3


declare
product varchar2(20):='&&2';
cursor get_user(p_user_id number) is
select user_name
from fnd_user
where user_id=p_user_id;
l_user_name fnd_user.user_name%type;

cursor get_node(p_node_id number) is
select node_name,webhost
from fnd_nodes
where node_id=p_node_id;
l_node_name fnd_nodes.node_name%type;
l_webhost fnd_nodes.webhost%type;


cursor get_guest_user_resps(p_user_name varchar2) is
select responsibility_key,secg.security_group_key,RESPONSIBILITY_NAME,resp.start_date,resp.end_date
,rol.EXPIRATION_DATE
,urol.EXPIRATION_DATE user_expiration_date
from fnd_responsibility resp, fnd_responsibility_tl respname
,fnd_user_resp_groups rg
,fnd_user usr
,wf_local_roles rol
,fnd_security_groups secg
,wf_local_user_roles urol
where usr.user_name=p_user_name
and resp.RESPONSIBILITY_ID=respname.RESPONSIBILITY_ID and resp.APPLICATION_ID=respname.APPLICATION_ID and respname.language='US'
and rg.user_id=usr.user_id
and rg.responsibility_id=resp.responsibility_id
and rg.responsibility_application_id=resp.application_id
and sysdate between usr.start_date and nvl(usr.end_date,sysdate)
and sysdate between rg.start_date and nvl(rg.end_date,sysdate)
and sysdate between resp.start_date and nvl(resp.end_date,sysdate)
and secg.security_group_id=rg.security_group_id
and rol.name='FND_RESP|PER|'||resp.responsibility_key||'|'||secg.security_group_key
and urol.user_name=p_user_name
and urol.role_name='FND_RESP|PER|'||resp.responsibility_key||'|'||secg.security_group_key
order by responsibility_key;
l_instance_name v$instance.instance_name%type;
l_instance_version v$instance.version%type;
cursor c_flex_context_default(p_flex_name varchar2,p_application_id number) is
select fdf.title
,fdf.CONTEXT_COLUMN_NAME 
,fdf.DEFAULT_CONTEXT_FIELD_NAME 
,fdf.DEFAULT_CONTEXT_VALUE 
,fdf.DESCRIPTIVE_FLEXFIELD_NAME
from FND_DESCRIPTIVE_FLEXS_VL fdf
where DESCRIPTIVE_FLEXFIELD_NAME =p_flex_name
and application_id=p_application_id;

cursor c_flex_contexts(p_flex_name varchar2,p_application_id number) is
select DESCRIPTIVE_FLEX_CONTEXT_CODE 
from FND_DESCR_FLEX_CONTEXTS 
where DESCRIPTIVE_FLEXFIELD_NAME =p_flex_name
and application_id=p_application_id
order by decode(DESCRIPTIVE_FLEX_CONTEXT_CODE,'Global Data Elements','1',DESCRIPTIVE_FLEX_CONTEXT_CODE);

cursor c_flex_fields(p_flex_name varchar2,p_context varchar2,p_application_id number) is
select fdfc.APPLICATION_COLUMN_NAME 
,fdfc.END_USER_COLUMN_NAME 
,fdfc.ENABLED_FLAG 
,fdfc.DISPLAY_FLAG 
,fdfc.REQUIRED_FLAG 
,fdfc.default_value
,ffvs.FLEX_VALUE_SET_NAME 
from FND_DESCR_FLEX_COL_USAGE_VL fdfc
,FND_FLEX_VALUE_SETS ffvs
where fdfc.DESCRIPTIVE_FLEXFIELD_NAME =p_flex_name
and fdfc.DESCRIPTIVE_FLEX_CONTEXT_CODE=p_context
and fdfc.application_id=p_application_id
and fdfc.FLEX_VALUE_SET_ID =ffvs.FLEX_VALUE_SET_ID 
order by fdfc.COLUMN_SEQ_NUM;

l_retval varchar2(4000);
l_url varchar(2000);
geom     MDSYS.SDO_GEOMETRY;
cursor get_pset(name varchar2) is
select menu_id
from fnd_menus
where menu_name=name;
l_emp_site_vis_pset number;
l_ext_site_vis_pset number;

cursor get_grant(pset number,user varchar2)is
select start_date,end_date
from fnd_grants
where grantee_type='USER'
and grantee_key=user
and menu_id=pset;

cursor get_org_info is
select org.name
,hoi.org_information1
,hoi.org_information3
,hoi.org_information4
,hoi.org_information5
,hoi.org_information6
,hoi.org_information9
,hoi2.org_information3 apl_numbering
,ast.user_status
,ast.external_status
,ppttl.user_person_type
from hr_organization_information hoi
,hr_all_organization_units org
,per_assignment_status_types_tl ast
,per_person_types_tl ppttl
,hr_organization_information hoi2
where hoi.organization_id=org.organization_id
and org.organization_id=org.business_group_id
and hoi.org_information_context='BG Recruitment'
and hoi.org_information7=ast.assignment_status_type_id(+)
and hoi2.ORG_INFORMATION_CONTEXT = 'Business Group Information'
and hoi2.organization_id=org.organization_id
and ast.language(+)=USERENV('LANG')
and hoi.org_information8=ppttl.person_type_id(+)
and ppttl.language(+)=USERENV('LANG');

cursor get_ex_emp is
select menu_name,fme.grant_flag
from fnd_menu_entries fme
,fnd_menus fm
,fnd_form_functions ff
where fme.function_id=ff.function_id
and ff.function_name='IRC_EX_EMP_REGISTRATION'
and fme.MENU_ID=fm.MENU_ID;

l_pset_start_date date;
l_pset_end_date date;
l_guest_user varchar2(30);

l_proxy_server varchar2(255);
l_proxy_port varchar2(255);
l_proxy_bypass varchar2(255);
l_fwk_agent varchar2(255);
issue boolean:=false;

l_doc_name varchar2(4000);
l_customization_name varchar2(4000);

cursor c_alldocs is
  select path_docid from jdr_paths
  where ((path_type = 'DOCUMENT' AND path_seq = -1) OR
    (path_type = 'PACKAGE' AND path_seq = 0))
  start with path_owner_docid = jdr_mds_internal.getDocumentId('/oracle/apps/per/irc')
  connect by prior path_docid = path_owner_docid;


cursor c_cust2(p_document_id number) is
select cl1.path_docid,jdr_mds_internal.getDocumentName(cl1.path_docid) docName,jda.att_value developerMode
from jdr_paths cl1
,    jdr_paths bm1
,    jdr_paths cl2
,    jdr_paths bm2
,    jdr_paths cl3
,    jdr_paths bm3
,    jdr_attributes jda
where cl1.path_name=bm1.path_name
and bm1.path_docid=p_document_id
and bm1.path_docid!=cl1.path_docid
and cl2.path_name=bm2.path_name
and cl1.path_owner_docid=cl2.path_docid
and bm1.path_owner_docid=bm2.path_docid
and cl2.path_name=bm2.path_name
and cl1.path_owner_docid=cl2.path_docid
and bm1.path_owner_docid=bm2.path_docid
and cl3.path_name=bm3.path_name
and cl2.path_owner_docid=cl3.path_docid
and bm2.path_owner_docid=bm3.path_docid
and jda.att_comp_docid=cl1.path_docid
and att_name='developerMode';

cursor c_cust3(p_document_id number) is
select COMP_SEQ,COMP_LEVEL,COMP_GROUPING,COMP_ELEMENT  from JDR_COMPONENTS where comp_element = 'replace' and COMP_DOCID = p_document_id;

Begin
if upper(product) in ('ALL','IRC') then
 dbms_output.put_line('<div id="page7" style="display: none;">');
 dbms_output.put_line('<a name="irc"></a><div class="divSection">');
 dbms_output.put_line('<div class="divSectionTitle">');
	dbms_output.put_line('<div class="left"  id="ircsetup" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">IRecruitment Setup: '); 
	dbms_output.put_line('</font></div><div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF">'); 
    dbms_output.put_line('<a class="detail" onclick="openall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9654; Expand All Checks</font></a>'); 
    dbms_output.put_line('<font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">');
    dbms_output.put_line('<font color="#FFFFFF">&#9660; Collapse All Checks</font></a> ');
    dbms_output.put_line('</div><div class="clear"></div></div><br>');
 dbms_output.put_line('<div class="divItem"><div class="divItemTitle">In This Section</div>');
 dbms_output.put_line('<table border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr><td class="toctable">');
 dbms_output.put_line('<a class=detail2 href="#irc1">Proxy Profile Option Analysis</a> <br>');      
      dbms_output.put_line('<a class=detail2 href="#irc2">Guest User Settings</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#irc3">Ex-employee registration check</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#irc4">iRec Business Group settings</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#irc5">Flex context</a> <br></td><td class="toctable">');
      dbms_output.put_line('<a class=detail2 href="#irc6">Connection tests</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#irc7">Geocode test</a> <br>');
	  dbms_output.put_line('<a class=detail2 href="#irc8">XML Parser</a> <br>');
      dbms_output.put_line('<a class=detail2 href="#irc9">Customizations</a> <br></td></tr></table>');	  
 dbms_output.put_line('</div><br>');
                 
  dbms_output.put_line('<a name="irc1"></a><b>Proxy Profile Option Analysis</b><br>');

l_proxy_server:=rtrim(fnd_profile.value('WEB_PROXY_HOST'));
l_proxy_port:=rtrim(fnd_profile.value('WEB_PROXY_PORT'));
l_proxy_bypass:=rtrim(fnd_profile.value('WEB_PROXY_BYPASS_DOMAINS'));
l_fwk_agent:=rtrim(fnd_profile.value('APPS_FRAMEWORK_AGENT'));
dbms_output.put_line('WEB_PROXY_HOST: '||l_proxy_server);
dbms_output.put_line('<br>WEB_PROXY_PORT: '||l_proxy_port);
dbms_output.put_line('<br>WEB_PROXY_BYPASS_DOMAINS: '||l_proxy_bypass);
dbms_output.put_line('<br>APPS_FRAMEWORK_AGENT: '||l_fwk_agent);

dbms_output.put_line('<div class="divok"><span class="sectionblue1">Advice: </span>If using a proxy server, be sure all of these 3 system profiles (WEB_PROXY_HOST, WEB_PROXY_PORT, WEB_PROXY_BYPASS_DOMAINS) are setup correctly. ');

dbms_output.put_line('<br>The WEB_PROXY_BYPASS_DOMAINS to define the proxy exclusion list must be in the following format *.mydomain1.com;*.mydomain2.com (Note the * asterisk in front and ; semi colon as the separator)</div>');

if(l_proxy_server!='' and l_proxy_port='')then
  dbms_output.put_line('<div class="diverr"><img class="error_ico"><font color="red">Error:</font> You have specified a proxy server, but not a proxy port.</div>');
  :e7:=:e7+1;
end if;

if(instr(l_fwk_agent,l_proxy_server)>0) then
  dbms_output.put_line('<div class="diverr"><img class="error_ico"><font color="red">Error:</font> You appear to have your proxy server set to be your application server. Set the correct proxy server.</div>');
  :e7:=:e7+1;
end if;

if(l_proxy_server='') then
  dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> You do not have a proxy server set. This is generally incorrect.</div>');
  :w7:=:w7+1;
end if;

if(l_proxy_bypass='') then
  dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> You do not have an proxy bypass domains set. This is generally incorrect.</div>');
  :w7:=:w7+1;
end if;

if(l_proxy_server!='' and substr(l_proxy_bypass,1,1)!='*') then
  dbms_output.put_line('<div class="diverr"><img class="error_ico"><font color="red">Error:</font> Your proxy server bypass domains are of the wrong format. They must start with *. e.g. *.oracle.com</div>');
  :e7:=:e7+1;
end if;


open get_pset('IRC_EXT_SITE_VISITOR_PSET');
fetch get_pset into l_ext_site_vis_pset;
close get_pset;
open get_pset('IRC_EMP_SITE_VISITOR_PSET');
fetch get_pset into l_emp_site_vis_pset;
close get_pset;

dbms_output.put_line('<br><br><a name="irc2"></a><b>Guest User Settings</b><br>');

l_guest_user:=substrb(fnd_profile.value('GUEST_USER_PWD'),0,instrb(fnd_profile.value('GUEST_USER_PWD'),'/')-1);
if(l_guest_user!='GUEST') then
  dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> Your guest user is not named GUEST. This is not supported from 11.5.10 onwards</div>');
  :w7:=:w7+1;
  issue:=true;
end if;

dbms_output.put_line('<DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql83b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql83'');" href="javascript:;">&#9654; Guest user</A></DIV>');
dbms_output.put_line(' <div id="s1sql83" style="display:none" >');
dbms_output.put_line('<table><tr><th>Responsibility name</th><th>Responsibility key</th><th>Start date</th><th>End date</th><th>Security group key</th><th>Status</th></tr>');	

  for resp_rec in get_guest_user_resps('GUEST') loop
  dbms_output.put_line('<tr><td>'||resp_rec.RESPONSIBILITY_NAME ||'</td><td> '|| resp_rec.responsibility_key||'</td><td> ');
  dbms_output.put_line(resp_rec.start_date||'</td><td> '|| resp_rec.end_date||'</td><td> '|| resp_rec.security_group_key||'</td><td>');
if(not resp_rec.expiration_date>=trunc(sysdate)) then
  dbms_output.put_line(' has expired<br>');
  issue:=true;
end if;
if(not resp_rec.user_expiration_date>=trunc(sysdate)) then
  dbms_output.put_line(' user role has expired<br>');
  issue:=true;
end if;
if(l_ext_site_vis_pset is not null) then
  if(resp_rec.responsibility_key='IRC_EXT_CANDIDATE') then
    open get_grant(l_ext_site_vis_pset,l_guest_user);
    fetch get_grant into l_pset_start_date, l_pset_end_date;
    if get_grant%notfound then
      close get_grant;
      dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> You have not granted the external site visitor permission set to the guest user.');
      dbms_output.put_line('Users will not be able to connect to the site visitor screens.</div>');
	  :w7:=:w7+1;
	  issue:=true;
    else
      close get_grant;
      if l_pset_start_date>sysdate or sysdate>nvl(l_pset_end_date,sysdate) then
        dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> Your external site visitor permission set grant to the guest user is out of date.</div>');
		:w7:=:w7+1;
		issue:=true;
      else
        dbms_output.put_line('External site visitor permission set granted.<br>');
      end if;
    end if;
  end if;
end if;

if(l_emp_site_vis_pset is not null) then
  if(resp_rec.responsibility_key='IRC_EMP_CANDIDATE') then
    open get_grant(l_emp_site_vis_pset,l_guest_user);
    fetch get_grant into l_pset_start_date, l_pset_end_date;
    if get_grant%notfound then
      close get_grant;
      dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> You have not granted the employee site visitor permission set to the guest user.');
      dbms_output.put_line('Users will not be able to connect to the employee site visitor screens.</div>');
	  :w7:=:w7+1;
	  issue:=true;
    else
      close get_grant;
      if l_pset_start_date>sysdate or sysdate>nvl(l_pset_end_date,sysdate) then
        dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange">Warning: </span> Your employee site visitor permission set grant to the guest user is out of date.</div>');
		:w7:=:w7+1;
		issue:=true;
      else
        dbms_output.put_line('Employee site visitor permission set granted.<br>');
      end if;
    end if;
  end if;
end if;
dbms_output.put_line('</td></tr>');
end loop;
dbms_output.put_line('</table><br> </div></div>');
if not issue then
	dbms_output.put_line('<div class="divok"><img class="check_ico">OK! Verified guest settings are OK.</div>');
else
	dbms_output.put_line('<div class="divwarn"><img class="warn_ico"> <span class="sectionorange">Warning: </span> You have warnings reported for GUEST user.</div>');
end if;

dbms_output.put_line('<br><br><a name="irc3"></a><DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql81b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql81'');" href="javascript:;">&#9660; Ex-employee registration check</A></DIV>');
dbms_output.put_line(' <div id="s1sql81" style="display:block" >');	

dbms_output.put_line('<table><tr><th>Menu</th><th>Granted</th></tr>');
for ex_rec in get_ex_emp loop
dbms_output.put_line('<tr><td>'||ex_rec.menu_name||' </td><td>'||ex_rec.grant_flag || '</td></tr>');
end loop;
dbms_output.put_line('</table><br></div></div> ');

dbms_output.put_line('<br><br><a name="irc4"></a><DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql86b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql86'');" href="javascript:;">&#9660; iRec Business Group settings</A></DIV>');
dbms_output.put_line(' <div id="s1sql86" style="display:block" >');	
dbms_output.put_line('<table><tr><th>Name</th><th>Code</th><th>Openings</th><th>Org</th><th>Loc</th><th>Status</th><th>Candidate Type</th><th>Excluded</th><th>Numbering</th></tr>');
for org_rec in get_org_info loop
  dbms_output.put_line('<tr><td>'|| org_rec.name);
  dbms_output.put_line(' </td><td>'||org_rec.org_information1||' </td><td>');
  dbms_output.put_line(org_rec.org_information3);
  dbms_output.put_line(' '||org_rec.org_information6||' </td><td>');
  dbms_output.put_line(org_rec.org_information4||' </td><td>');
  dbms_output.put_line(org_rec.org_information5);
  dbms_output.put_line(' </td><td> '||org_rec.user_status);
  dbms_output.put_line(' ('||org_rec.external_status||') </td><td> ');
  dbms_output.put_line(  org_rec.user_person_type||' </td><td>');
  dbms_output.put_line(org_rec.org_information9);
  dbms_output.put_line('</td><td>'||org_rec.apl_numbering||'</td></tr>');
end loop;
dbms_output.put_line('</table><br> </div></div><br>');

dbms_output.put_line('<a name="irc5"></a><DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql82b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql82'');" href="javascript:;">&#9654; Flex context</A></DIV>');
dbms_output.put_line(' <div id="s1sql82" style="display:none" >');	
for context_def_rec in c_flex_context_default('IRC_SEARCH_CRITERIA',800) loop
dbms_output.put_line('<br>Flex: '||context_def_rec.title);
dbms_output.put_line('<br>Context default: '||context_def_rec.DEFAULT_CONTEXT_VALUE);
  for flex_contexts_rec in c_flex_contexts (context_def_rec.DESCRIPTIVE_FLEXFIELD_NAME,800) loop
  dbms_output.put_line('  Context: '||flex_contexts_rec.DESCRIPTIVE_FLEX_CONTEXT_CODE);
    dbms_output.put_line('<table><tr><th>Field</th><th>Enabled</th><th>Displayed</th><th>Required</th><th>Value Set</th><th>Default</th></tr>');
    for flex_fields_rec in c_flex_fields(context_def_rec.DESCRIPTIVE_FLEXFIELD_NAME,flex_contexts_rec.DESCRIPTIVE_FLEX_CONTEXT_CODE,800) loop
    dbms_output.put_line('<tr><td>'||flex_fields_rec.APPLICATION_COLUMN_NAME||' ('||flex_fields_rec.END_USER_COLUMN_NAME||')');
    dbms_output.put_line('</td><td>'||flex_fields_rec.ENABLED_FLAG||' </td><td>'||flex_fields_rec.DISPLAY_FLAG||' </td><td> '||flex_fields_rec.REQUIRED_FLAG);
    dbms_output.put_line('</td><td> '||flex_fields_rec.FLEX_VALUE_SET_NAME||' </td><td>'||flex_fields_rec.default_value ||'</td></tr>');
    end loop;
    dbms_output.put_line('</table><br> ');
  end loop;
end loop;
dbms_output.put_line('</div></div>');

dbms_output.put_line('<br><br><a name="irc6"></a><b>External Network Test</b><br>');


begin
l_retval:='No response';
l_url:='http://www.google.com/';
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url,
                            proxy => hr_util_web.proxyforURL(l_url)),0,128);
dbms_output.put_line('<div class="divok">');
dbms_output.put_line(replace(replace(l_retval,'<',' '),'>',' '));
dbms_output.put_line('<br><img class="check_ico">OK! The external network test was a success. This means that you can make external network connections from the database</div>');
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
dbms_output.put_line('<br>The external network test failed. This means that you can not make external network connections from the database,');
dbms_output.put_line('<br>e.g. for location seaching. You may also be unable to make external network conncections from the middle tier,');
dbms_output.put_line('<br>e.g. for resume parsing or background checking</div>');
:w7:=:w7+1;
end;

dbms_output.put_line('<br><br><b>Internal Network Test</b><br>');

begin
l_retval:='No response';
l_url:=fnd_profile.value('APPS_FRAMEWORK_AGENT')||'/OA_HTML/JobPositionSeeker.xsl';
  if(lower(substr(l_url,1,5))='https') then
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url
                           ,proxy => hr_util_web.proxyforURL(substr(l_url,1,2000))
                           ,wallet_path=>'file:'||fnd_profile.value('FND_DB_WALLET_DIR')
                           ,wallet_password=>fnd_preference.eget('#INTERNAL','WF_WEBSERVICES','EWALLETPWD', 'WFWS_PWD')
                           ),0,128);
  else
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url
                           ,proxy => hr_util_web.proxyforURL(substr(l_url,1,2000))
                           ),0,128);
  end if;
dbms_output.put_line('<div class="divok">');
dbms_output.put_line(replace(replace(l_retval,'<',' '),'>',' '));
dbms_output.put_line('<br><img class="check_ico">OK! The internal network test was a success. This means that you can make network connections from the database to the middle tier');
dbms_output.put_line('You need to make sure the network facilitates network connectivity on all nodes (data base and middle tiers).<br>');
dbms_output.put_line('If you use SSL (https), then verify that your wallet manager is configured according to Note 123718.1.</div>');
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
dbms_output.put_line('<br>The internal network test failed. This means that you can not make network connections from the database to the middle tier.<br>');
dbms_output.put_line('This will stop functionality like background checking, resume generation and job postings from working.</div>');
:w7:=:w7+1;

end;


begin
if (length(fnd_profile.value('IRC_BACKGROUND_CHECK_VENDOR_URL'))>1) then
  dbms_output.put_line('<br><br><b>Background Check Network Test</b>');

  l_retval:='No response';
  l_url:=fnd_profile.value('IRC_BACKGROUND_CHECK_VENDOR_URL');
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url,
                            proxy => hr_util_web.proxyforURL(l_url)),0,128);
  dbms_output.put_line('<div class="divok">');
  dbms_output.put_line(replace(replace(l_retval,'<',' '),'>',' '));
  dbms_output.put_line('<br><img class="check_ico">OK! You are able to succesfully communicate from the database to the background check vendor.<br>');
  dbms_output.put_line('This is a good indication, but not a guarantee, that you will be able to connect from the middle tier.<br>');
dbms_output.put_line('Also, if you are using the background check functionality be sure that this site can connect from all nodes (middle tiers and database)</div>');


end if;
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
  dbms_output.put_line('<br><img class="check_ico">You are not able to succesfully communicate from the database to the background check vendor.<br>');
  dbms_output.put_line('This is a strong indication that you will not be able to connect from the middle tier.</div>');
  :w7:=:w7+1;

end;

begin
if (length(fnd_profile.value('IRC_RESUME_PARSING_VENDOR_URL'))>1) then
  dbms_output.put_line('<br><br><b>Resume Parsing Network Test</b><br>');

  l_retval:='No response';
  l_url:=fnd_profile.value('IRC_RESUME_PARSING_VENDOR_URL');
    l_retval:=substr(UTL_HTTP.REQUEST(url   => l_url,
                            proxy => hr_util_web.proxyforURL(l_url)),0,128);
  dbms_output.put_line('<div class="divok">');
  dbms_output.put_line(replace(replace(l_retval,'<',' '),'>',' '));
  dbms_output.put_line('<br><img class="check_ico">OK! You are able to succesfully communicate from the database to the resume parsing vendor.<br>');
  dbms_output.put_line('This is a good indication, but not a guarantee, that you will be able to connect from the middle tier.</div>');

end if;
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
  dbms_output.put_line('<br>You are not able to succesfully communicate from the database to the resume parsing vendor.<br>');
  dbms_output.put_line('This is a strong indication that you will not be able to connect from the middle tier.</div>');
  :w7:=:w7+1;

end;



dbms_output.put_line('<br><br><b>Url_fw.conf file entries</b><br>');
dbms_output.put_line('<div class="divok"><span class="sectionblue1">Advice: </span>Please CHECK for the appropriate entries in the url_fw.conf file<br>');
dbms_output.put_line('The file httpd.conf has the path to the url_fw.conf. Whatever the httpd.conf says, that is where it is. it is usually the same directory as httpd.conf and that is typically $IAS_CONFIG_HOME/Apache/Apache/conf ');
dbms_output.put_line('(Note: url_fw.conf is ONLY on the web tier)<br>');
dbms_output.put_line('Verify the following files are included in the url_fw.conf file, if not, please add to all servers (internal and external):<br>');
dbms_output.put_line('<blockquote> RewriteRule ^/OA_HTML/IRCRESUMEUK1\.xsl$ - [L]<br>');
dbms_output.put_line('RewriteRule ^/OA_HTML/IRCRESUMEUK2\.xsl$ - [L]<br>');
dbms_output.put_line('RewriteRule ^/OA_HTML/IRCRESUMEUS1\.xsl$ - [L]<br>');
dbms_output.put_line('RewriteRule ^/OA_HTML/IRCRESUMEUS2\.xsl$ - [L]<br>');
dbms_output.put_line('RewriteRule ^/OA_HTML/IRCRESUMEUS3\.xsl$ - [L] </blockquote> </div>');



begin
if (length(fnd_profile.value('IRC_GEOCODE_HOST'))>1) then
  dbms_output.put_line('<br><br><a name="irc7"></a><b>eLocation Test</b>');

    geom := irc_location_utility.address2geometry(address_line1 => '500 Oracle pky'
                             ,address_line2=> 'redwood city'
                             ,address_line3 => 'CA'
                            ,country=>'US');
    dbms_output.put_line('<div class="divok">');
	dbms_output.put_line('Latitude: ' || geom.SDO_POINT.y);
    dbms_output.put_line('<br>Longitude: ' || geom.SDO_POINT.x);

  dbms_output.put_line('<br><img class="check_ico">OK! You have succesfully communicated with the eLocation server.</div>');

end if;
exception
  when others then
    dbms_output.put_line('<div class="divwarn"><img class="warn_ico"><span class="sectionorange"> Failed: </span>');
    dbms_output.put_line(substr(sqlerrm,0,128));
  dbms_output.put_line('<br>You have not succesfully communicated with the eLocation server. You will not be able to search by distance to location</div>');
  :w7:=:w7+1;
end;

begin
dbms_output.put_line('<br><br><a name="irc8"></a><b>XMLParser version:</b> '||ecx_utils.XMLVersion);


dbms_output.put_line('<br><br><a name="irc9"></a><DIV class=divItem>');
dbms_output.put_line('<DIV id="s1sql87b" class=divItemTitle><A class=detail onclick="displayItem(this,''s1sql87'');" href="javascript:;">&#9654; Customizations</A></DIV>');
dbms_output.put_line(' <div id="s1sql87" style="display:none" >');

if(fnd_profile.value_specific(name=>'FND_MIGRATED_TO_JRAD',application_id=>800)='N') then
	dbms_output.put_line('Running in AK mode - not checking personalizations<br><br>');
	else
	dbms_output.put_line('Running in MDS Mode<br><br>');

	  for doc_rec in c_alldocs loop
		l_doc_name:=jdr_mds_internal.getDocumentName(doc_rec.path_docid);
		for cust_rec in c_cust2(doc_rec.path_docid) loop
		  dbms_output.put_line(cust_rec.docName);
		  dbms_output.put_line(' Developer Mode:'||cust_rec.developerMode||'<br>');		  
		end loop;		
	  end loop;
	  
	  dbms_output.put_line('<br><br>VO substitutions:<br>');
	  for doc_rec in c_alldocs loop
		l_doc_name:=jdr_mds_internal.getDocumentName(doc_rec.path_docid);
		for cust_rec in c_cust3(doc_rec.path_docid) loop
		  dbms_output.put_line(l_doc_name);
		  dbms_output.put_line(' SEQ:'||cust_rec.COMP_SEQ||'LEVEL'||cust_rec.COMP_LEVEL||'GROUPING' ||cust_rec.COMP_GROUPING||'ELEMENT''||cust_rec.COMP_ELEMENT||<br>');		  
		end loop;		
	  end loop;
	  
dbms_output.put_line('</div></div>');
end if;
end;   

   dbms_output.put_line('</div></div>');
end if; 
dbms_output.put_line('</div>');
EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;
/


declare
v_errors number;
v_warnings number;
product varchar2(20):='&2';
begin
dbms_output.put_line('<br><br><a name="errors"></a>');
	v_errors:=:e1+:e2+:e3+:e4+:e5+:e6+:e7;
	v_warnings:=:w1+:w2+:w3+:w4+:w5+:w6+:w7;
	dbms_output.put_line('<script type="text/javascript">');
	dbms_output.put_line('var auxs;');
	dbms_output.put_line('auxs = document.getElementById("ExecutionSummary1").innerHTML;');
	dbms_output.put_line('document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if v_errors>0 and v_warnings>0 then
		dbms_output.put_line('"('||v_errors||'<img class=\\"error_ico\\"> '||v_warnings||'<img class=\\"warn_ico\\">)</A>";');
	elsif v_errors>0 and v_warnings=0 then
		dbms_output.put_line('"(<img class=\\"error_ico\\">'||v_errors||')</A>";');
	elsif v_errors=0 and v_warnings>0 then
		dbms_output.put_line('"(<img class=\\"warn_ico\\">'||v_warnings||')</A>";');
	elsif v_errors=0 and v_warnings=0 then
		dbms_output.put_line('"(<img class=\\"check_ico\\"> No issues reported)</A>";');
	end if;
	
	dbms_output.put_line('auxs = document.getElementById("ExecutionSummary2").innerHTML;');
	dbms_output.put_line('document.getElementById("ExecutionSummary2").innerHTML = auxs + ');			

	dbms_output.put_line(' "<TABLE width=\\"95%\\"><TR>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Section</B></TD>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Errors</B></TD>"+');
	dbms_output.put_line(' "<TH BGCOLOR=#DEE6EF><B>Warnings</B></TD>"+');
	
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page1'');\\" href=\\"javascript:;\\">Instance Overview</A>"+');
	if :e1>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w1>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');	
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e1||'</TD><TD>'||:w1||'</TD> </TR>"+');
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page2'');\\" href=\\"javascript:;\\">Patching</A>"+');
	if :e5>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w5>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e5||'</TD><TD>'||:w5||'</TD> </TR>"+');
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page3'');\\" href=\\"javascript:;\\">Settings</A>"+');	
	if :e4>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w4>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e4||'</TD><TD>'||:w4||'</TD> </TR>"+');
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page4'');\\" href=\\"javascript:;\\">Performance</A>"+');
	if :e2>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w2>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');	
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e2||'</TD><TD>'||:w2||'</TD> </TR>"+');
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page5'');\\" href=\\"javascript:;\\">Database Objects</A>"+');
	if :e3>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w3>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e3||'</TD><TD>'||:w3||'</TD> </TR>"+');
	if upper(product) in ('HR','SSHR', 'OTL','IRC','OTA','ALL') then
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page6'');\\" href=\\"javascript:;\\">Workflow Details</A>"+');	
	if :e6>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w6>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e6||'</TD><TD>'||:w6||'</TD> </TR>"+');
	end if;
	if upper(product) in ('ALL','IRC')  then
	dbms_output.put_line('"<TR><TD><A class=detail onclick=\\"activateTab2(''page7'');\\" href=\\"javascript:;\\">IRecruitment Setup</A>"+');
	if :e7>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\">"+');
			elsif :w7>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\">"+');		
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\">"+');
			end if;	
	dbms_output.put_line('"</TD><TD>'||:e7||'</TD><TD>'||:w7||'</TD> </TR>"+');     
    end if;	
			
	dbms_output.put_line(' "</TABLE></div>";');     	


	dbms_output.put_line('auxs = document.getElementById("toccontent").innerHTML;');
	dbms_output.put_line('document.getElementById("toccontent").innerHTML = auxs + ');
	dbms_output.put_line('"<div align=\\"center\\">"+');
	-- Tabs 
	
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page1'')\\" >"+');
			dbms_output.put_line('"<b>Instance Overview</b> "+');
			if :e1>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w1>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	 
	  
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page2'')\\" >"+');
			dbms_output.put_line('"<b>Patching</b>"+');
			if :e5>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w5>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;
			
	
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page3'')\\" >"+');
			dbms_output.put_line('"<b>Settings</b> "+');
			if :e4>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w4>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	 
			
	
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page4'')\\" >"+');
			dbms_output.put_line('"<b>Performance</b> "+');
			if :e2>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w2>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	
	
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page5'')\\" >"+');
			dbms_output.put_line('"<b>Database Objects and Versions</b> "+');
			if :e3>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w3>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	
			
	  if upper(product) in ('HR','SSHR', 'OTL','IRC','OTA','ALL') then
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page6'')\\" >"+');
			dbms_output.put_line('"<b>Workflow Details</b> "+');
			if :e6>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w6>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	
      end if;
	  if upper(product) in ('ALL','IRC')  then
			dbms_output.put_line('"<button class=\\"btn\\" OnClick=\\"activateTab(''page7'')\\" >"+');
			dbms_output.put_line('"<b>IRecruitment Setup</b> "+');
			if :e7>0 then
				dbms_output.put_line(' "<img class=\\"error_ico\\"></button>"+');
			elsif :w7>0 then
				dbms_output.put_line(' "<img class=\\"warn_ico\\"></button>"+');
			else
				dbms_output.put_line(' "<img class=\\"check_ico\\"></button>"+');
			end if;	
      end if;
      dbms_output.put_line('"</div>";');
	  

			dbms_output.put_line('auxs = document.getElementById("overview").innerHTML;');
			dbms_output.put_line('document.getElementById("overview").innerHTML = auxs + ');
			if :e1>0 and :w1>0 then
				dbms_output.put_line(' "'||:e1||' <img class=\\"error_ico\\">  '||:w1||' <img class=\\"warn_ico\\"> ";');
			elsif :e1>0 then
				dbms_output.put_line(' "'||:e1||' <img class=\\"error_ico\\"> ";');
			elsif :w1>0 then
				dbms_output.put_line(' "'||:w1||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;						
	
			dbms_output.put_line('auxs = document.getElementById("patching").innerHTML;');
			dbms_output.put_line('document.getElementById("patching").innerHTML = auxs + ');
			if :e5>0 and :w5>0 then
				dbms_output.put_line(' "'||:e5||' <img class=\\"error_ico\\">  '||:w5||' <img class=\\"warn_ico\\"> ";');
			elsif :e5>0 then
				dbms_output.put_line(' "'||:e5||' <img class=\\"error_ico\\"> ";');
			elsif :w5>0 then
				dbms_output.put_line(' "'||:w5||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;		
						
	
			dbms_output.put_line('auxs = document.getElementById("settings").innerHTML;');
			dbms_output.put_line('document.getElementById("settings").innerHTML = auxs + ');
			if :e4>0 and :w4>0 then
				dbms_output.put_line(' "'||:e4||' <img class=\\"error_ico\\">  '||:w4||' <img class=\\"warn_ico\\"> ";');
			elsif :e4>0 then
				dbms_output.put_line(' "'||:e4||' <img class=\\"error_ico\\"> ";');
			elsif :w4>0 then
				dbms_output.put_line(' "'||:w4||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;	
					
	 
			dbms_output.put_line('auxs = document.getElementById("performance").innerHTML;');
			dbms_output.put_line('document.getElementById("performance").innerHTML = auxs + ');
			if :e2>0 and :w2>0 then
				dbms_output.put_line(' "'||:e2||' <img class=\\"error_ico\\">  '||:w2||' <img class=\\"warn_ico\\"> ";');
			elsif :e2>0 then
				dbms_output.put_line(' "'||:e2||' <img class=\\"error_ico\\"> ";');
			elsif :w2>0 then
				dbms_output.put_line(' "'||:w2||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;			
	
			dbms_output.put_line('auxs = document.getElementById("database").innerHTML;');
			dbms_output.put_line('document.getElementById("database").innerHTML = auxs + ');
			if :e3>0 and :w3>0 then
				dbms_output.put_line(' "'||:e3||' <img class=\\"error_ico\\">  '||:w3||' <img class=\\"warn_ico\\"> ";');
			elsif :e3>0 then
				dbms_output.put_line(' "'||:e3||' <img class=\\"error_ico\\"> ";');
			elsif :w3>0 then
				dbms_output.put_line(' "'||:w3||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;		
	
	  if upper(product) in ('HR','SSHR', 'OTL','IRC','OTA','ALL') then
			dbms_output.put_line('auxs = document.getElementById("workflow").innerHTML;');
			dbms_output.put_line('document.getElementById("workflow").innerHTML = auxs + ');
			if :e6>0 and :w6>0 then
				dbms_output.put_line(' "'||:e6||' <img class=\\"error_ico\\">  '||:w6||' <img class=\\"warn_ico\\"> ";');
			elsif :e6>0 then
				dbms_output.put_line(' "'||:e6||' <img class=\\"error_ico\\"> ";');
			elsif :w6>0 then
				dbms_output.put_line(' "'||:w6||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;				
      end if;
	  if upper(product) in ('IRC','ALL') then
			dbms_output.put_line('auxs = document.getElementById("ircsetup").innerHTML;');
			dbms_output.put_line('document.getElementById("ircsetup").innerHTML = auxs + ');
			if :e7>0 and :w7>0 then
				dbms_output.put_line(' "'||:e7||' <img class=\\"error_ico\\">  '||:w7||' <img class=\\"warn_ico\\"> ";');
			elsif :e7>0 then
				dbms_output.put_line(' "'||:e7||' <img class=\\"error_ico\\"> ";');
			elsif :w7>0 then
				dbms_output.put_line(' "'||:w7||' <img class=\\"warn_ico\\"> ";');
			else
				dbms_output.put_line(' " <img class=\\"check_ico\\"> ";');
			end if;				
      end if;
	
	  dbms_output.put_line('</script>');
	
	

EXCEPTION
when others then
dbms_output.put_line('<br>'||sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1<br>');
end;
/


-- Print duration of script

begin
select to_char(sysdate,'hh24:mi:ss') into :et_time from dual;
end;
/

declare
	st_hr1 varchar2(10);
	st_mi1 varchar2(10);
	st_ss1 varchar2(10);
	et_hr1 varchar2(10);
	et_mi1 varchar2(10);
	et_ss1 varchar2(10);
	hr_fact varchar2(10);
	mi_fact varchar2(10);
	ss_fact varchar2(10);
	vss number;
	vse number;
	vt number;
begin
	dbms_output.put_line('<br><br><hr><br><TABLE width="50%"><THEAD><STRONG>HCM Analyzer Performance Data</STRONG></THEAD>');
    dbms_output.put_line('<TBODY><TR><TH>Started at:</TH><TD>'||:st_time||'</TD></TR>');
    dbms_output.put_line('<TR><TH>Complete at:</TH><TD>'||:et_time||'</TD></TR>');
    	
	st_hr1 := substr(:st_time,1,2);
	st_mi1 := substr(:st_time,4,2);
	st_ss1 := substr(:st_time,7,2);
	et_hr1 := substr(:et_time,1,2);
	et_mi1 := substr(:et_time,4,2);
	et_ss1 := substr(:et_time,7,2);
	
	vss:=st_hr1*60*60 + st_mi1*60+st_ss1;
	vse:=et_hr1*60*60 + et_mi1*60+et_ss1;
	
	
	dbms_output.put_line('<TR><TH>Total time taken to complete the script:</TH>');
	if vse>vss then	
			vt:=vse-vss;			
	else
			vt:=24*60*60-vss +vse;
	end if;
	
	if (vt > 3600) then
								dbms_output.put_line('<TD>'||trunc(vt/3600)||' hours, '||trunc((vt-((trunc(vt/3600))*3600))/60)||' minutes, '||trunc(vt-((trunc(vt/60))*60))||' seconds</TD></TR>');
	elsif (vt > 60) then
								dbms_output.put_line('<TD>'||trunc(vt/60)||' minutes, '||trunc(vt-((trunc(vt/60))*60))||' seconds</TD></TR>');
	elsif (vt < 60) then
								dbms_output.put_line('<TD>'||trunc(vt)||' seconds</TD></TR>');
	end if;
			
	dbms_output.put_line('</TBODY></TABLE>');
EXCEPTION
when others then
  dbms_output.put_line('<br>');
  dbms_output.put_line(sqlerrm ||' occurred in test');
  dbms_output.put_line('<br>Please report the above error as comment in HCM Analyzer Note 1562530.1');
  dbms_output.put_line('<br>');	
end;
/

-- Display feedback and communities reference
declare
		db_ver    	  VARCHAR2(100);
		db_charset V$NLS_PARAMETERS.value%type;
		db_lang V$NLS_PARAMETERS.value%type;
		rup_level varchar2(20);
		v_exists number;
		platform varchar2(100);		
		cursor legislations is
				SELECT DECODE(legislation_code
							   ,null,'Global'
							   ,legislation_code)  leg              
					   , DECODE(application_short_name
							   , 'PER', 'Human Resources'
							   , 'PAY', 'Payroll'
							   , 'GHR', 'Federal Human Resources'
							   , 'CM',  'College Data'
							   , application_short_name) application         
				  FROM hr_legislation_installations
				  WHERE status = 'I'
				  ORDER BY legislation_code;
		v_wfVer WF_RESOURCES.TEXT%type:='';
		v_crtddt V$DATABASE.CREATED%type;
		irc_status varchar2(20);
		v1_1320920 varchar2(30);
		v2_1320920 varchar2(30);
		cursor bg is
		SELECT o.business_group_id bgi,o.organization_id oi,otl.name name,o3.ORG_INFORMATION9 lc			
			,o3.ORG_INFORMATION10 cc,o4.ORG_INFORMATION2 ef ,to_char(o.date_from , 'DD-MON-YYYY') df,to_char(o.date_to, 'DD-MON-YYYY') dt
			FROM HR_ALL_ORGANIZATION_UNITS O , 
			HR_ALL_ORGANIZATION_UNITS_TL OTL , 
			HR_ORGANIZATION_INFORMATION O2 ,
			HR_ORGANIZATION_INFORMATION O3 , 
			HR_ORGANIZATION_INFORMATION O4 
			WHERE O.ORGANIZATION_ID = OTL.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O2.ORGANIZATION_ID (+) 
			AND O.ORGANIZATION_ID = O3.ORGANIZATION_ID 
			AND O.ORGANIZATION_ID = O4.ORGANIZATION_ID 
			AND O3.ORG_INFORMATION_CONTEXT = 'Business Group Information' 
			AND O2.ORG_INFORMATION_CONTEXT (+) = 'Work Day Information' 
			AND O4.ORG_INFORMATION_CONTEXT = 'CLASS' 
			AND O4.ORG_INFORMATION1 = 'HR_BG' AND O4.ORG_INFORMATION2 = 'Y' 
			AND OTL.LANGUAGE = 'US'
			ORDER BY   1;
	cursor c_pay is select parameter_name, nvl(parameter_value,'null') param_value
      from pay_action_parameters
      where parameter_name in ('BAL BUFFER SIZE','EE_BUFFER_SIZE','RR_BUFFER_SIZE','RRV_BUFFER_SIZE','CHUNK SIZE','RANGE_PERSON_ID','THREADS','TRACE','LOW_VOLUME');
      max_dump v$parameter.value%type;
	  
FUNCTION compare_versions(p_ver1 IN VARCHAR2, p_ver2 IN VARCHAR2)
  RETURN INTEGER IS
    l_ver1     VARCHAR2(100) := p_ver1;
    l_ver2     VARCHAR2(100) := p_ver2;
    l_seg1     VARCHAR2(20);
    l_seg2     VARCHAR2(20);
    l_seg1_num NUMBER;
    l_seg2_num NUMBER;
    l_idx      NUMBER;

  BEGIN

    IF (l_ver1 = l_ver2 OR (l_ver1 is null and l_ver2 is null)) THEN
      RETURN(0);
    ELSIF (l_ver1 is null) THEN
      RETURN(-1);
    ELSIF (l_ver2 is null) THEN
      RETURN(1);
    END IF;

    WHILE l_ver1 is not null AND l_ver2 is not null LOOP
      l_idx := instr(l_ver1, '.');
      IF l_idx <> 0 THEN
        l_seg1 := substr(l_ver1, 1, l_idx -1);
        l_ver1 := substr(l_ver1, l_idx+1);
      ELSE
        l_seg1 := l_ver1;
        l_ver1 := null;
      END IF;
      l_idx := instr(l_ver2, '.');
      IF l_idx <> 0 THEN
        l_seg2 := substr(l_ver2, 1, l_idx -1);
        l_ver2 := substr(l_ver2, l_idx+1);
      ELSE
        l_seg2 := l_ver2;
        l_ver2 := null;
      END IF;
      BEGIN
        l_seg1_num := to_number(l_seg1);
        l_seg2_num := to_number(l_seg2);
        IF l_seg1_num < l_seg2_num THEN
          RETURN(-1);
        ELSIF l_seg1_num > l_seg2_num THEN
          RETURN(1);
        END IF;
      EXCEPTION WHEN VALUE_ERROR THEN
        IF l_seg1 < l_seg2 THEN
          RETURN(-1);
        ELSIF l_seg1 > l_seg2 THEN
          RETURN(1);
        END IF;
      END;
    END LOOP;
    IF l_ver1 is null AND l_ver2 is null THEN
      RETURN(0);
    ELSIF l_ver1 is null THEN
      RETURN(-1);
    ELSIF l_ver2 is null THEN
      RETURN(1);
    END IF;
  EXCEPTION WHEN OTHERS THEN
    dbms_output.put_line('Error: '||sqlerrm);
  END compare_versions;

begin
	
	dbms_output.put_line('<br><hr><a name="feedback"></a><table border="2" name="NoteBox" cellpadding="1" bordercolor="#C1A90D" bgcolor="#CCCCCC" cellspacing="1"><br>');
	dbms_output.put_line('<b>Still have questions or suggestions?</b><br>  <A HREF="https://community.oracle.com/message/12181012#12181012"  target="_blank">');
	dbms_output.put_line('<img src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback.png" title="Click here to provide feedback"/></a><br>');
	dbms_output.put_line('Click the button above to ask questions about and/or provide feedback on the HCM Technical Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!<br>');
	
	SELECT SUBSTR(REPLACE(REPLACE(pcv1.product, 'TNS for '), ':' )||pcv2.status, 1, 80)
    INTO platform
        FROM product_component_version pcv1,
           product_component_version pcv2
     WHERE UPPER(pcv1.product) LIKE '%TNS%'
       AND UPPER(pcv2.product) LIKE '%ORACLE%'
       AND ROWNUM = 1;
	select VALUE into db_lang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
	select VALUE into db_charset FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';
	select banner into db_ver from V$VERSION WHERE ROWNUM = 1;
	select count(1) into v_exists FROM V$DATABASE;
	if v_exists=1 then	
	SELECT CREATED into v_crtddt FROM V$DATABASE;
	end if;
	select count(1) into v_exists FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';
	if v_exists=1 then
	SELECT TEXT into v_wfVer  FROM WF_RESOURCES  WHERE TYPE = 'WFTKN'  AND NAME = 'WF_VERSION'  AND LANGUAGE = 'US';	
	end if;	
	if :apps_rel like '12.%' then
		select count(*) into v_exists from fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		if v_exists >0 then	
		SELECT L.MEANING  into irc_status  FROM fnd_application b, fnd_application_tl t, FND_PRODUCT_INSTALLATIONS I, fnd_lookup_values L
		  WHERE (b.APPLICATION_ID = I.APPLICATION_ID) AND b.application_id = t.application_id   AND (b.APPLICATION_ID = '821')
			AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')  AND (L.LOOKUP_CODE = I.Status) AND t.language = 'US'	AND l.language = 'US';
		else
		  irc_status:='Not available';
		end if;
	else
	  irc_status:='Not available';
	 end if;  
	
	dbms_output.put_line('<!-- ######BEGIN DX SUMMARY######');
	dbms_output.put_line('<diagnostic><run_details>');
    dbms_output.put_line('<detail name="Instance">'||:sid||'</detail>');
    dbms_output.put_line('<detail name="Instance Date">'||v_crtddt||'</detail>');
    dbms_output.put_line('<detail name="Platform">'||platform||'</detail>');
    dbms_output.put_line('<detail name="File Version">200.48</detail>');
    dbms_output.put_line('<detail name="Language">'||db_lang||' / '||db_charset||'</detail>');
    dbms_output.put_line('<detail name="Database">'||db_ver||'</detail>');
	dbms_output.put_line('<detail name="Application">'||:apps_rel||'</detail>');
    dbms_output.put_line('<detail name="Workflow">'||v_wfVer||'</detail>');
    dbms_output.put_line('<detail name="PER">'||:hr_status||'</detail>');
    dbms_output.put_line('<detail name="PAY">'||:pay_status||'</detail>');
    dbms_output.put_line('<detail name="IRC">'||irc_status||'</detail>');	
	dbms_output.put_line('<detail name="RUP">'||:rup_level_n|| ' applied on ' || :v_rup_date||'</detail>');
  dbms_output.put_line('</run_details>');
  dbms_output.put_line('<parameters>');
    for l_rec in legislations loop
	dbms_output.put_line('<parameter name="Legislation">'||l_rec.leg||'   '||l_rec.application||'</parameter>');
	end loop;
	for org_rec in bg loop
		dbms_output.put_line('<parameter name="BG"><![CDATA['||lpad(org_rec.bgi,10)||' | '||lpad(org_rec.oi,10)||' | '||lpad(org_rec.name,30)||' | '||lpad(org_rec.lc,6)||' | '||lpad(org_rec.cc,6)||' | '||lpad(org_rec.ef,7)||' | '||lpad(org_rec.df,11)||' | '||lpad(org_rec.dt,11)||']]></parameter>');
	end loop;
	for c_rec in c_pay loop
		dbms_output.put_line('<parameter name="PERF">'||c_rec.parameter_name||': '||c_rec.param_value||'</parameter>');
	end loop;
	select nvl(value,'null') into max_dump from v$parameter  where lower(name) ='max_dump_file_size';
	dbms_output.put_line('<parameter name="PERF">Max_dump_file_sixe: '||max_dump||'</parameter>');
	dbms_output.put_line('<parameter name="PERF">Gather Schema Statistics for ALL - last time completed normally: '||:p1||'</parameter>');
	dbms_output.put_line('<parameter name="PERF">Gather Schema Statistics for HR - last time completed normally: '||:p2||'</parameter>');
  dbms_output.put_line('</parameters> <issues><signature id="INSTSUM"><failure row="1">d</failure></signature>');
  if :apps_rel like '12.1%' then
			  select que.version into v1_1320920
			  from (
				 select file_version.version version,
				 rank()over(partition by files.filename
				   order by file_version.version_segment1 desc,
				   file_version.version_segment2 desc,file_version.version_segment3 desc,
				   file_version.version_segment4 desc,file_version.version_segment5 desc,
				   file_version.version_segment6 desc,file_version.version_segment7 desc,
				   file_version.version_segment8 desc,file_version.version_segment9 desc,
				   file_version.version_segment10 desc,
				   file_version.translation_level desc) as rank1
				 from ad_file_versions file_version,
				   (
				   select filename, app_short_name, subdir, file_id
				   from ad_files
				   where upper(filename) like upper('DirectReportsVO.xml')
				   ) files
				 where files.file_id = file_version.file_id
			  ) que
			  where rank1 = 1;
			  select substr(text,instr(text,'.p')+4, instr(text ,' ' ,instr(text,'.p')+3, 2)- instr(text,'.p')-4) into v2_1320920
			  from dba_source where  name like  'HR_TERMINATION_SS' and instr(text,'$Header') <>0 and instr(text,'.p') <>0 and (owner like 'APPS%')  and type ='PACKAGE BODY'  
			  and line =2;  
			  if compare_versions(v1_1320920,'120.5.12010000.5')<0 or compare_versions(v2_1320920,'120.2.12010000.6')<0 then
				dbms_output.put_line('<signature id="NOTE1320920"><failure row="1">');
				dbms_output.put_line('<column name="vDirectReportsVO">'||v1_1320920||'</column>');
				dbms_output.put_line('<column name="vHR_TERMINATION_SS">'||v2_1320920||'</column>');
				dbms_output.put_line('</failure></signature>');
			  end if;
  end if;
  
  dbms_output.put_line('</issues></diagnostic>');
  dbms_output.put_line('######END DX SUMMARY######-->');
end;
/

REM  ==============SQL PLUS Environment setup===================

Spool off

set termout on

exit
;
