REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM | Framework 3.0.27                                                        |
REM |                                                                         |
REM | FILENAME                                                                |
REM |    ap_ar_tax_setup_analyzer.sql                                               |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM | Script to diagnose data integrity issues in EBTax Setup.                |
REM |                                                                         |
REM | HISTORY                                                                 |
REM |   27-Jan-2013 ARMITRA Created                                         |
REM |   14-Feb-2013 ARMITRA Modified the queries and added the signatures   |
REM |   18-Feb-2013 ARMITRA Added the signatures  for Tax Tolerance Not Upgraded |
REM |   22-Feb-2013 ARMITRA Added the URL and detail steps for OIE          |
REM |   24-Feb-2013 ARMITRA Added the SQL to identify Tax Code Description Mismatch           |
REM |   26-Feb-2013 ARMITRA Added the SQL to identify Missing Tax Rate , Tax and Regime |
REM |   01-Mar-2013 ARMITRA Added the Detail Action plan for Pre-Install Check-In |
REM |   03-Mar-2013 ARMITRA Changed the Title To EBTax Setup and Data Integrity Analyzer|
REM |   04-Mar-2013 ARMITRA Added the Datafix to be applied directly from 1316316.1|
REM |   12-Mar-2013 ARMITRA Added the Checking of New ZX RPC                       |
REM |   12-Mar-2013 ARMITRA Added the Impacted Areas                               |
REM |   21-Mar-2013 ARMITRA Added the new section for Tax Group , Tax and Event Class  |
REM |   04-Apr-2013 ARMITRA Added the Reupgrade script Reference for Tax Group , Tax Code  |
REM |   02-May-2013 ARMITRA Added the Code to identify missing Reporting Codes Setup     |
REM |   10-May-2013 ARMITRA Added the Code to identify Out of Sync TIPV Amount     |
REM |   02-Jan-2015 ARMITRA Added the code for Associations created for Member State Set up at the party Tax profile level|
REM |   22-Feb-2015 ARMITRA Added Customer is missing seeded tax classification codes in UI |
REM |   19-Mar-2015 ARMITRA converted to last version                          |
REM |   23-Apr-2015 ARMITRA modified queries in Section 20 , 28 and 29         | 
REM |   06-May-2015 ARMITRA modified Framework to 3.0.21                       |
REM |   15-May-2015 AROBERT Added concurrent request functionality             |
REM |   15-Jun-2015 ARMITRA Added Tax Reporting Issues                         |
REM |   22-Jun-2015 ARMITRA Added Bank Account and Payment Document Issues     |
REM |   29-Jun-2015 ARMITRA Added Supplier Related Issues                      |
REM |   30-Jun-2015 ARMITRA Added Payables Setup Related Issues                |
REM |   16-Jul-2015 ARMITRA Added Financials Options and Supplier Merge Issues |
REM +=========================================================================+
 
SET DEFINE '~'
SET SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT

declare

apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
	
BEGIN
 SELECT max(release_name) INTO apps_version
 FROM fnd_product_groups;

 apps_version := substr(apps_version,1,2);
    
-- Validation to verify analyzer is run on proper e-Business application version
-- So will fail before package is created
 if apps_version < '12' then 
	dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** WARNING WARNING WARNING WARNING WARNING WARNING WARNING ***');
    dbms_output.put_line('***************************************************************');
    dbms_output.put_line('*** This instance is eBusiness Suite version '|| apps_version ||'             ***');
    dbms_output.put_line('*** This Analyzer script must run in version 12 or above    ***');
    dbms_output.put_line('*** Note: the error below is intentional                    ***');
    raise_application_error(-20001, 'ERROR: The script requires eBusiness Version 12 or higher');
 end if;

END;
/
 
CREATE OR REPLACE PACKAGE tax_setup_detect_pkg AUTHID CURRENT_USER AS

-----------------------------------
-- Type declarations
-----------------------------------
TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

TYPE ledgers_tbl IS TABLE OF NUMBER;
-----------------------------------------
-- Main entry point to standalone process
-----------------------------------------
PROCEDURE main(
      p_invoice_id      in NUMBER default null, --Parameterised By Arnab Mitra
      p_appl_ids         in NUMBER default null,--Parameterised By Arnab Mitra
      p_max_output_rows in NUMBER default 9999,
      p_debug_mode      in VARCHAR2 default 'Y');


------------------------------------------
-- Main entry point for concurrent process
------------------------------------------
PROCEDURE main_cp (
      errbuf            out VARCHAR2,
      retcode           out VARCHAR2,	
      p_invoice_id in NUMBER default NULL,
      p_appl_ids in NUMBER default NULL,
      p_max_output_rows in NUMBER default 9999,
      p_debug_mode      in VARCHAR2 default 'Y');

END tax_setup_detect_pkg;
/
show errors


-- PSD #1

CREATE OR REPLACE PACKAGE BODY apps.tax_setup_detect_pkg AS
-- $Id: tax_setup_detect_pkg.sql,v 200.8 2015/11/05 00:58:26 armitra Exp $


----------------------------------
-- Output File Global Variables --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1529429.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;


-----------------------------------
-- Global Var declarations
-----------------------------------
g_invoice_id      NUMBER;
g_appl_ids		  NUMBER;--Parameterised by Arnab Mitra
g_check_id        NUMBER;
g_vendor_id       NUMBER;
g_mode            VARCHAR2(10);
g_start_date      DATE;
g_end_date        DATE;
g_org_ids         VARCHAR2(150);
g_trx_type        VARCHAR2(10);
g_validations     VARCHAR2(10);
g_conc_process    BOOLEAN := false;
g_process_start_time  TIMESTAMP;
g_parent_sig_count NUMBER;
APP_EXCEPTION     EXCEPTION;

----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));

  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;

PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;

PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;

----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

	-- PSD #2
    l_log_file := 'EB-Tax_AP_AR_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'EB-Tax_AP_AR_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';


    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
    dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file : '||l_file_location||'/'||l_log_file);
	
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Payables and EB Tax Setup Analyzer including AP and AR Transaction Level Details Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;

  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------


	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  -- PSD #3
-- Arnab Mitra Added blogs.oracle.com/ebs/resource/Proactive/zx_latest_ver.gif
-- Arnab <itra Added 1529429.1:TAX_SETUP_DETECT_PKG 
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1529429.1:TAX_SETUP_DETECT_PKG">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/zx_latest_ver.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN

    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
		 
		 -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;

          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL &amp; info)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
		  -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.1.'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2.'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4.'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
			
			-- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);
-- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -- Print actions
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -- Print solution only if passed
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;

  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;
	  
  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   --Code for Table of Contents of each section  
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF; 
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF; 
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;

-------------------------
-- Recommended patches 
-------------------------
-- PSD #4
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel       VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- PSD #4a
  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '20';
	l_rel := 'R12';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := 'N/A';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'R12.0 Oracle Financials Critical & Recommended Patches';
    l_col_rows(5)(1) := '[557869.1]';
 -- If want to go based on more e-Business Application version, just add for example:
 -- ELSIF substr(g_rep_info('Apps Version'),1,4) = '12.1' THEN
  ELSE
    l_step := '30';
	l_rel := 'R12';
    l_col_rows.extend(5);
    l_col_rows(1)(1) := '21213464';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'NEW! R12.1: E-Business Tax Recommended Patch Collection (ZX RPC), Aug 2015';
    l_col_rows(5)(1) := '[1481235.1]';

    l_col_rows(1)(2) := '21276870';--Added By Arnab Mitra on 01-Apr-2015
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'NEW! R12.1: E-Business Tax Reporting Ledger Recommended Patch Collection (ZX), Aug 2015';--Added By Arnab Mitra on 01-Apr-2015
    l_col_rows(5)(2) := '[1481235.1]';
  END IF;
  
  -- Check if applied
IF l_col_rows.exists(1) THEN
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i),l_rel);
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;
END IF;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='Y';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RSGT1 (RS greater than 1), RS (row selected), NRS (no row selected)
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'Y') --should signature be included in DX Summary
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


/*
PROCEDURE GAB_print_rpc_info IS
  l_rpc_core     VARCHAR2(1);
  l_rpc_supp     VARCHAR2(1);
  l_core_date    DATE;
  l_supp_date    DATE;
  l_core_bug     VARCHAR2(10) := '17176017';
  l_supp_bug     VARCHAR2(10) := '17202262';

  CURSOR get_app_date(p_ptch VARCHAR2) IS
  SELECT max(pr.start_date) app_date
  FROM ad_patch_runs pr
  WHERE pr.patch_run_id in (
          SELECT prb.patch_run_id
          FROM   ad_bugs b,
                 ad_patch_run_bugs prb
          WHERE  b.bug_number = p_ptch
          AND    prb.bug_id = b.bug_id
          UNION
          SELECT pr2.patch_run_id
          FROM ad_applied_patches ap,
               ad_patch_drivers pd,
               ad_patch_runs pr2
          WHERE ap.patch_name = p_ptch 
          AND   pd.applied_patch_id = ap.applied_patch_id
          AND   pr2.patch_driver_id = pd.patch_driver_id);

BEGIN
  l_rpc_core := check_patch(l_core_bug);
  l_rpc_supp := check_patch(l_supp_bug);

  IF l_rpc_core = 'Y' OR l_rpc_supp = 'Y' THEN
    print_out('<span class="boldsmall" indent=1><br/>');
    IF l_rpc_core = 'Y' THEN
      OPEN get_app_date(l_core_bug);
      FETCH get_app_date INTO l_core_date;
      CLOSE get_app_date;
      IF l_core_date is not null THEN
        print_out('AP RPC Applied: '||
          to_char(l_core_date,'DD-Mon-YYYY')||'<br/>');
      END IF;
    END IF;
    IF l_rpc_supp = 'Y' THEN
      OPEN get_app_date(l_supp_bug);
      FETCH get_app_date INTO l_supp_date;
      CLOSE get_app_date;
      IF l_supp_date is not null THEN
        print_out('EBTax RPC Applied: '||
          to_char(l_supp_date,'DD-Mon-YYYY')||'<br/>');
      END IF;
    END IF;
    print_out('</span>');
  END IF;

  IF l_rpc_core = 'N' OR l_rpc_supp = 'N' THEN
    print_out('<br/><br/>');
    IF l_rpc_core = 'N' THEN
      print_error('Warning: The AP Core Recommended Patch Collection (RPC), '||
        l_core_bug||', has not been applied to this instance.');
    END IF;
    IF l_rpc_supp = 'N' THEN
      print_error('Warning: The EBTax Recommended Patch Collection (RPC), '||
        l_supp_bug||', has not been applied to this instance.');
    END IF;
    print_error('Please see note '||
      '<a href=" http://support.oracle.com/rs?type=doc'||'&id='||1397581.1||'" target="_blank">1397581.1</a>'||
      ' for details on the critical Payables RPC patch releases.');
  END IF;
END GAB_print_rpc_info;
*/

--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
PROCEDURE validate_parameters (
      p_invoice_id in NUMBER,--Parameterised by Arnab Mitra
      p_appl_ids in NUMBER,--Parameterised by Arnab Mitra
      p_max_output_rows in NUMBER,
      p_debug_mode in VARCHAR2) IS

  CURSOR chk_date(c_ledger_id NUMBER, c_date DATE) IS
    SELECT l.name
    FROM gl_ledgers l
    WHERE l.ledger_id = c_ledger_id
    AND   NOT EXISTS (
            SELECT 1 FROM gl_period_statuses ps
            WHERE  ps.ledger_id = l.ledger_id
            AND   ps.application_id = 200
            AND   c_date BETWEEN ps.start_date AND ps.end_date
            AND   ps.closing_status IN ('O','F'));

  l_dummy        NUMBER;
  l_org_list     VARCHAR2(150);
  l_org          VARCHAR2(10);
  l_org_num      NUMBER;
  l_step         VARCHAR2(30);
  l_ledger_id    NUMBER;
  l_ledger_name  GL_LEDGERS.NAME%TYPE;
  l_ledgers      LEDGERS_TBL := ledgers_tbl();
  
  l_run_date     VARCHAR2(30);
  l_date         DATE;
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;
  l_step         VARCHAR2(5);
  invalid_parameters EXCEPTION;  

  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  p_contract_NUM VARCHAR2(120);


BEGIN
    
  -- Determine instance info
  BEGIN
    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
-- Revision and date values can be populated by RCS
-- PSD #6
  l_revision := rtrim(replace('$Revision: 200.8 $','$',''));
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/11/05 10:25:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
-- PSD #7
  g_rep_info('File Name') := 'tax_setup_detect_pkg.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?id=1529429.1" target="_blank">(Note 1529429.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');
  g_parameters('1. Transaction Id') := p_invoice_id;--Parameterised by Arnab Mitra
  g_parameters('2. Application ID')    := p_appl_ids;--Parameterised by Arnab Mitra
/*
  -- Create global hash for parameters. Numbers required for the output order
  g_parameters('1. Invoice Id') := p_invoice_id;
  g_parameters('2. Start Date') := to_char(to_date(p_start_date,'DD/MM/YYYY'),'DD-MON-YYYY'); 
  g_parameters('3. End Date')   := to_char(to_date(p_end_date,'DD/MM/YYYY'),'DD-MON-YYYY');  
  g_parameters('4. Org IDs')    := p_org_ids;
*/
  
  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  -- PSD #7a
  -- PSD #15
  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');
  
-- Validation to verify analyzer is run on proper e-Business application version
-- In case validation at the beginning is updated/removed, adding validation here also so execution fails
  IF substr(l_apps_version,1,2) < '12' THEN
	print_log('eBusiness Suite version = '||l_apps_version);
	print_log('ERROR: This Analyzer script must run in version 12 or above.');
	raise invalid_parameters;
  END IF;

/*
should use this part only when having parameters passes 
  -- Create global hash of SQL token values
  g_sql_tokens('##$$ORGS$$##') := to_char(p_org_ids);
  g_sql_tokens('##$$IVIEW$$##'):= 'SELECT /*+ qb_name(iview) */ /*DISTINCT d.invoice_id '||
               'FROM ap_invoice_distributions_all d '||
               'WHERE d.org_id in ('||p_org_ids||') '||
               'AND   d.accounting_date BETWEEN '||
               '        to_date('''||to_char(g_start_date,'DD-MON-YYYY')||''') AND '||
               '        to_date('''||to_char(g_end_date,'DD-MON-YYYY')||''')';
  g_sql_tokens('##$$CVIEW$$##'):= 'SELECT /*+ qb_name(cview) */ /*DISTINCT ph.check_id '||
               'FROM ap_payment_history_all ph '||
               'WHERE ph.org_id in ('||p_org_ids||') '||
               'AND   ph.accounting_date BETWEEN '||
               '        to_date('''||to_char(p_start_date,'DD-MON-YYYY')||''') AND '||
               '        to_date('''||to_char(p_end_date,'DD-MON-YYYY')||''')';
*/

--Arnab Mitra Added the following Logic to validate the Invoice or Transaction ID against the corresponding Application ID
  IF (p_appl_ids is null and p_invoice_id is NOT NULL) THEN
    print_log('No Application ID specified. You need to mention Application either 200 for Payables or 222 for Receivables. '||
   ' The Application ID parameter is mandatory once you mention the Transaction ID.');
    dbms_output.put_line('No Application ID specified. You need to mention Application ID either 200 for Payables or 222 for Receivables.');
    raise invalid_parameters;
  END IF;

IF (p_appl_ids is Not null and p_invoice_id is NULL) THEN
    print_log('No Transaction or Invoice ID specified.'||' The Transaction ID parameter is mandatory once you mention the Application ID.');
    dbms_output.put_line('No Transaction ID specified. The Transaction ID parameter is mandatory since you mention the Application ID.');
    raise invalid_parameters;
  END IF;

IF (p_appl_ids is Not null and p_appl_ids not in (200,222)) THEN
    print_log('Invalid Application ID specified.'||' The Application ID must be either 200 for Payables or 222 for Receivables.');
    dbms_output.put_line('Invalid Application ID specified. The Application ID must be either 200 for Payables or 222 for Receivables.');
    raise invalid_parameters;
  END IF;


If p_appl_ids = 200
Then
 g_sql_tokens('##$$IVIEW$$##'):= 'SELECT /*+ qb_name(iview) */ DISTINCT d.invoice_id '||
               'FROM ap_invoice_distributions_all d '||
               'WHERE d.invoice_id in ('||p_invoice_id||')';

End If;

If p_appl_ids = 222
Then
 g_sql_tokens('##$$TRXVIEW$$##'):= 'SELECT /*+ qb_name(trxview) */ DISTINCT d.customer_trx_id '||
               'FROM RA_CUSTOMER_TRX_ALL d '||
               'WHERE d.customer_trx_id in ('||p_invoice_id||')';

End If;


IF p_invoice_id is Not Null and p_appl_ids = 200 THEN
    

select distinct org_id into l_org_num from ap_invoice_distributions_all where invoice_id=p_invoice_id;

Begin
mo_global.set_policy_context('S',l_org_num);--Added By Arnab for MO Security Control
end;

End If;

    
EXCEPTION WHEN OTHERS THEN
  print_log('Error in validate parameters: '||sqlerrm);
  raise;
END validate_parameters;


--------------------------------------------
-- Prepare the SQL with the parameter values
--------------------------------------------
FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2,
  p_appl_ids IN Number,
  p_invoice_id IN NUMBER) RETURN VARCHAR2 IS

  l_sql VARCHAR2(20000);

BEGIN
  -- Assign signature to working variable
  l_sql := P_SIGNATURE_SQL;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  --IF g_mode = 'DATERANGE' THEN--Commented By Arnab
  IF p_appl_ids  = 200 THEN--Parameterised by Arnab Mitra
    l_sql := replace(l_sql,'##$$IVIEW$$##',
               'SELECT /*+ qb_name(iview)  */ DISTINCT d.invoice_id '||
               'FROM ap_invoice_distributions_all d '||
               'WHERE d.invoice_id in ('||p_invoice_id||')');
  END IF;

  IF p_appl_ids  = 222 THEN--Parameterised by Arnab Mitra
    l_sql := replace(l_sql,'##$$TRXVIEW$$##',
               'SELECT /*+ qb_name(trxview)  */ DISTINCT d.customer_trx_id'||
               'FROM RA_CUSTOMER_TRX_ALL d '||
               'WHERE d.customer_trx_id in ('||p_invoice_id||')');
  END IF;

  

  --l_sql := replace(l_sql,'##$$INV$$##', nvl(to_char(p_invoice_id),'null'));
  --l_sql := replace(l_sql,'##$$PMT$$##', nvl(to_char(g_check_id),'null'));
  --l_sql := replace(l_sql,'##$$VND$$##', nvl(to_char(g_vendor_id),'null'));
  --l_sql := replace(l_sql,'##$$SDT$$##', to_char(g_start_date,'DD-MON-YYYY'));
  --l_sql := replace(l_sql,'##$$EDT$$##', to_char(g_end_date,'DD-MON-YYYY'));
  --l_sql := replace(l_sql,'##$$ORGS$$##', g_org_ids);
  RETURN l_sql;
END prepare_sql;

----------------------------------------------------------------------
-- Runs a single Signature SQL using DBMS_SQL and prints a report
----------------------------------------------------------------------
/*
FUNCTION  run_signature(
  p_signature in SIGNATURE_REC,
  p_index in INTEGER,
  p_invoice_id in NUMBER default NULL) RETURN BOOLEAN IS

  l_sql            VARCHAR2(20000);
  l_fix            VARCHAR2(2000) := null;
  l_note_url       VARCHAR2(200) := null;
  l_sig_title      VARCHAR2(3000);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_row_cols       COL_LIST_TBL := col_list_tbl();
  l_col_headings   HEADINGS_TBL := headings_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;
  

BEGIN
  -- Massage the fix text
  l_step := '10';
  l_fix := p_signature.fix_text;
  IF p_signature.note_number is not null THEN
    l_step := '10.1';
    l_note_url :=
      '<a href=" http://support.oracle.com/rs?type=doc'
      ||'&id='||p_signature.note_number||'" target="_blank">'||p_signature.note_number||'</a>';
    l_fix := replace(l_fix,p_signature.note_number, l_note_url);
    IF l_fix is null THEN
      l_step := '10.1.1';
      l_fix := '<b>Note: </b>Please follow the instructions provided in note '||
        l_note_url;
    END IF;
  END IF;

  l_step := '20';
  IF l_fix is not null THEN
    l_step := '20.1';
    IF l_fix not like '%Note%' THEN
      l_step := '20.1.1';
      l_fix := '<b>Note: </b>'||l_fix;
    ELSE
      l_step := '20.1.2';
      l_fix := replace(l_fix, 'Note:','<b>Note:</b>');
    END IF;
    IF (regexp_like(l_fix, '[^a-z]APLIST', 'i') AND
       NOT (upper(l_fix) like '%SUPPORT.ORACLE.COM%')) THEN
      l_step := '20.1.3';
      l_fix := regexp_replace(l_fix, '([^a-z])APLIST',
        '\1<a href="https://support.oracle.com/oip/faces/secure/km/DocumentDisplay.jspx'
        ||'?id=1231565.1">APList</a>',1,1,'i');
    END IF;
  END IF;

  -- Create signature title
  l_step := '30';
  l_sig_title := '<b>Results for Signature # '||to_char(p_index)||': </b>';
  IF p_invoice_id is not null THEN
    l_step := '30.0';
    l_sig_title := 'Invoice ID: '||to_char(p_invoice_id)||' '||l_sig_title;
  END IF;
  IF p_signature.script_name is not null THEN
    l_step := '30.1';
    l_sig_title := l_sig_title||'<b>Script: </b>'||p_signature.script_name||' ';
  END IF;
  IF p_signature.bug_number is not null THEN
    l_step := '30.2';
    l_sig_title := l_sig_title||'<b>Bug: </b>'||p_signature.bug_number||' ';
  END IF;
  IF p_signature.note_number is not null THEN
    l_step := '30.3';
    l_sig_title := l_sig_title||'<b>Note: </b>'||l_note_url;
  END IF;
  IF p_signature.impact_areas.count > 0 THEN
    l_sig_title := l_sig_title||'<br/><strong>Impact Area(s): </strong>';
    FOR i IN 1..p_signature.impact_areas.count LOOP
      IF i < p_signature.impact_areas.count THEN
        l_sig_title := l_sig_title||p_signature.impact_areas(i)||', ';
      ELSE
        l_sig_title := l_sig_title||p_signature.impact_areas(i);
      END IF; 
    END LOOP;
  END IF;
  l_sig_title := l_sig_title||'<br/>';


  -- Prepare the Signature SQL
  l_step := '40';
  l_sql := prepare_sql(
             p_signature.signature_sql,
             nvl(p_invoice_id,g_invoice_id));

  -- Open cursor and parse signature
  l_step := '40.1';
  c := dbms_sql.open_cursor;

  l_step := '40.2';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);

  -- Get column count and descriptions
  l_step := '40.3';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);

  -- Register arrays to bulk collect results and set headings
  l_step := '40.4';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '40.4.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_row_cols.extend();
    dbms_sql.define_array(c, i, l_row_cols(i), g_max_output_rows, 1);
  END LOOP;

  -- Execute and Fetch
  l_step := '40.5';

  start_timer(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE_AND_FETCH(c);
  debug('('||to_char(p_index)||') Script ('||to_char(p_signature.sig_id)
    ||'): '||p_signature.script_name);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '40.6';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '40.6.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_row_cols(i));
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '40.7';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;

  -- Print results....
  l_step := '50';
  IF l_rows_fetched > 0 THEN
    IF p_invoice_id is not null THEN
      print_out('<blockquote>');
    END IF;
    print_out('<hr/>');
    print_out(l_sig_title);
    print_out('<hr/>');
    print_out(p_signature.problem_text||'<br>');
    IF l_rows_fetched < g_max_output_rows THEN
      l_step := '50.1';
      print_out('<span class="boldsmall">A total of '||l_rows_fetched||
        ' instances for the Setup.');
    ELSE
      l_step := '50.2';
      print_out('<span class="boldsmall">Multiple instances of this '||
        'problem were found.');
      print_out('  Displaying only the first '||to_char(g_max_output_rows));
    END IF;
    print_out('</span>&nbsp;&nbsp<span class="italsmall">Elapsed: '||
      format_elapsed(g_query_elapsed)||'</span>');
    print_out('<br/><br/>');
    print_out('<table>');
    -- Print Headings
    l_step := '50.3';
    print_out('<tr>');
    FOR i IN 1..l_col_headings.count LOOP
      print_out('<th id='||to_char(i)||'>'||nvl(l_col_headings(i),'&nbsp;')||'</th>');
    END LOOP;
    print_out('</tr>');

    l_step := '50.4';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
     print_out('<tr>');
     FOR j IN 1..l_col_cnt LOOP
       print_out('<td>'||l_row_cols(j)(i)||'</td>');
     END LOOP;
     print_out('</tr>');
    END LOOP;
    print_out('<tr><td class="fix" colspan="'||to_char(l_col_cnt)||'">'||
      l_fix||'</td></tr>');

    l_step := '50.5';
    IF p_signature.undoes_accounting = 'Y' THEN
      print_out('<tr><td class="fix" colspan="'||to_char(l_col_cnt)||
        '"><b>IMPORTANT: This fix will undo accounting.</b> For '||
        'transactions posted in <b>closed periods</b> the reversing '||
        'and corrected events will be accounted in the current open period.<br/>'||
        'For a deeper understanding of the undo accounting process '||
        'please refer to note '||
        '<a href="https://support.oracle.com/oip/faces/secure/km/'||
        'DocumentDisplay.jspx?id=753695.1">753695.1</a>.'||
        '</td></tr>');
    END IF;
    -- Added for displaying SQL query
    print_out('<tr><td colspan="'||to_char(l_col_cnt)||'">'||
      '<input type="button" value="Show SQL" onclick="displaySQL(this, '||' '||')"/></td></tr>'||
      '<tr><td style="display:none" colspan="'||to_char(l_col_cnt)||'" '||
      'id="sig'||p_signature.sig_id ||'">'||
      '<pre><p align="left">     '||l_sql||'
      </pre></td></tr>');

    print_out('</table><br/><br/>');
    IF p_invoice_id is not null THEN
      print_out('</blockquote>');
    END IF;
  END IF;
  return l_rows_fetched > 0;
EXCEPTION
  WHEN OTHERS THEN
    IF substr(l_step,1,2) = '50' THEN
      print_out('</table><br/><br/>');
      IF p_invoice_id is not null THEN
        print_out('</blockquote>');
      END IF;
    END IF;
    print_log('ERROR: Failed to execute Signature at index '||p_index||
      ', BUG = '||p_signature.bug_number||
      ', NOTE = '||p_signature.note_number||
      ', SCRIPT = '||p_signature.script_name);
    print_log('SQL = '||l_sql);
    print_log('MODE = '||g_mode||', INVOICE_ID = '||nvl(p_invoice_id,g_invoice_id)||
      ', CHECK_ID = '|| g_check_id||', START_DATE = '|| g_start_date||
      ' , END_DATE = '||g_end_date||', Step = '||l_step||
      ', sqlerrm = '||sqlerrm);
    print_error('ERROR: Failed to execute Signature at index '||
      p_index||'.  See the log file for full details.');
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    RETURN l_rows_fetched > 0;
END run_signature;
*/

-------------------------------------------
-- Main procedure for processing signatures
-------------------------------------------

/********************************************************************************
    The following load signatures into memory tables these are called
    in validate_parameters based on the parameters passed in.

    General (transaction independent) signatures are loaded into
    g_gen_signatures.  Invoice based signatures into g_inv_signatures
    and payment/check related signatures into g_pmt_signatures.

    To add a signature, go to the bottom of the appropriate
    load procedure section and call:

    add_signature(
        <signature_table>,  -- g_gen_signatures, g_inv_signatures, g_pmt_signatures,
                            -- g_supplier_signatures
        '<BUG_NUMBER>',
        '<NOTE_NUMBER>',
        '<SCRIPT_NAME>',
        '<PROBLEM_TEXT>',
        '<FIX_TEXT>',
        '<UNDOES_ACCTG (Y/N)>',
        '<IMPACT_AREAS TBL OF IMPACT AREAS>',
        '<SIGNATURE SQL Text>');

    If the query is invoice, payment or supplier related it should have a
    condition of the form below where table.column contains the invoice
    or check id of the transaction:

   AND   table.invoice_id = nvl(##$$INV$$##, table.invoice_id)
    or
   AND   table.check_id = nvl(##$$PMT$$##, table.check_id)
    or
   AND   table.vendor_id = nvl(##$$VND$$##, table.vendor_id)

    Each payment or invoice signature SQL should also contain the
    following condition on the driving transaction table:

   AND   table.org_id in (##$$ORGS$$##)

    Each payment or invoice signature should also contain the following date 
    conditions, where table is the driving transaction table:

      For invoice related signatures:
   AND   EXISTS (
           SELECT 1 FROM ap_invoice_distributions_all dates
           WHERE dates.invoice_id = table.invoice_id
           AND   dates.accounting_date BETWEEN
                   nvl(to_date(''##$$SDT$$##''), dates.accounting_date) AND
                   nvl(to_date(''##$$EDT$$##''), dates.accounting_date))

      For payment related signatures:
   AND   EXISTS (
           SELECT 1 FROM ap_payment_history_all dates
           WHERE dates.check_id = table.check_id
           AND   dates.accounting_date BETWEEN
                   nvl(to_date(''##$$SDT$$##''), dates.accounting_date) AND
                   nvl(to_date(''##$$EDT$$##''), dates.accounting_date))

For performance reasons using the above to limit by transaction or org
and date range has generally been replaced by including a dynamically 
created view to limit the invoice or check transactions. The view will either return
a single transaction id, or all transactions associated with the date range
and operating unit parameters. 

To do this include the following in the FROM clause

Invoices:

  (
    ##$$IVIEW$$##
  )  invs

AR Invoices:

  (
    ##$$TRXVIEW$$##
  )  trxs

Payments: 
  (
    ##$$CVIEW$$##
  )  chks

And then include a link to this view from the driving table:
   AND table.invoice_id = invs.invoice_id
OR 
   AND table.check_id = chks.check_id

********************************************************************************/


---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN

  -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------
  
  /*-------------------------------------------------------------------
  Use this call in order to create new signatures:
  
  add_signature(
  '2', -- Unique Signature identifier
  'sql in work', -- The text of the signature query
  '',     -- Signature title
  '[count(*)] > [0]',     -- fail condition: RS, NRS, [col] operand [val]
  '',     -- Problem description
  '',     -- Problem solution
  '',      -- Message on success
  '',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  '',       -- Warn(W), Err(E), Info(I)
  '',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info);
  --------------------------------------------------------------------*/
  
  add_signature(
  '1_ZX_File_Vers', -- Unique Signature identifier
  'select text from all_source where name like ''ZX%'' and line=2 and text like ''%Header%''', -- The text of the signature query
  'EBTax Database Packages',     -- Signature title
  'NRS',     -- fail condition: RS, NRS, [col] operand [val]
  'This is for the information purpose to get the file versions of EBTax Database Packages.',     -- Problem description
  '',     -- Problem solution
  'This is for the information purpose to get the file versions of EBTax Database Packages.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'I',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info);
  
/*
add_signature(g_gen_signatures,
    70,
    'No RCA Bug Available',
    'No Note',
    ' ',
    '<strong><font color = "ff0000">EBTax Package Versions</font></strong>',
    'This is for the information purpose to get the file versions of EBTax Database Packages.',
    'N',
    impact_area_tbl(' '),
    'select text from all_source where name like ''ZX%'' and line=2'
  );
*/

  add_signature(
  '2_INVALIDS', -- Unique Signature identifier
      'select object_name,object_type,file_version,
LTRIM(MAX(SYS_CONNECT_BY_PATH(text,'' , ''))
       KEEP (DENSE_RANK LAST ORDER BY curr),'' , '') AS elements
from (SELECT object_name,text,name,object_type,file_version,
               ROW_NUMBER() OVER (PARTITION BY object_name ORDER BY text) AS curr,
               ROW_NUMBER() OVER (PARTITION BY object_name ORDER BY text) -1 AS prev
        FROM   (SELECT a.object_name,b.name,    
           b.text,object_type,(
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) File_Version 
           FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''ZX%'')
    AND a.status = ''INVALID'')errors)a
GROUP BY object_name,object_type,file_version
CONNECT BY prev = PRIOR curr AND name = PRIOR name
START WITH curr = 1', -- The text of the signature query
  'EBTAX Invalids',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Checking for EBTax related Invalid objects',     -- Problem description
  'Invalid objects exists for EBTax - please check the list and work on solve them.',     -- Problem solution
  'No EBTax invalid exists.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
  p_include_in_dx_summary => 'Y');


    
/*    
add_signature(g_gen_signatures,
    71,
    'No RCA Bug Available',
    'No Note',
    ' ',
    '<strong><font color = "ff0000">EBTax Related Invalid Objects</font></strong>',
    'There exist invalid EBTax related objects',
    'N',
    impact_area_tbl(' '),
    'SELECT a.object_name,
           decode(a.object_type,
             ''PACKAGE'', ''Package Spec'',
             ''PACKAGE BODY'', ''Package Body'',
             a.object_type) type,
           (
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) "File Version",
           b.text "Error Text"
    FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''ZX%'')
    AND a.status = ''INVALID'''
  );
*/

  add_signature(
  '3_Miss_TAX', -- Unique Signature identifier
  'SELECT tax_regime_code,
      MIN(effective_from) effective_from
   FROM zx_update_criteria_results results
   WHERE NOT EXISTS
      (SELECT 1 FROM zx_regimes_b WHERE tax_regime_code = results.tax_regime_code
      )
   GROUP BY tax_regime_code', -- The text of the signature query
  'Retrieve the missing Tax Regime for Migrated Tax',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax under the specified Regime cannot be Calculated.',     -- Problem description
  'Please follow the Section 11 of this note - [1316316.1] - and Log an SR to get a Datafix.',     -- Problem solution
  'No missing Tax Regime for Migrated Tax',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
 
/* 
add_signature(g_gen_signatures,
    72,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Retrieve the missing Tax Regime for Migrated Tax</font></strong>',
    'Please follow the Section 11 Of (Doc ID <a href= target="_blank">1316316.1</a>) and Log an SR to get Datafix.',
    'N',
    impact_area_tbl('Tax  under the specified Regime can not be Calculated '),
    'SELECT tax_regime_code,
       min(effective_from) effective_from
  FROM zx_update_criteria_results results
WHERE NOT EXISTS
        (SELECT 1 FROM zx_regimes_b
          WHERE tax_regime_code = results.tax_regime_code)
GROUP BY tax_regime_code'
  );
*/
    
  add_signature(
  '4_No_TAX', -- Unique Signature identifier
  'SELECT tax_regime_code,
      tax,
      MIN(effective_from) effective_from
    FROM zx_update_criteria_results results
    WHERE NOT EXISTS
      (SELECT 1
      FROM zx_taxes_b
      WHERE tax_regime_code = results.tax_regime_code
      AND tax               = results.tax
      )
    GROUP BY tax_regime_code,
      tax', -- The text of the signature query
  'Retrieve the missing Tax for Migrated Tax',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Tax calculation for above Regime and Tax combination',     -- Problem description
  'Please follow the Section 11 of this note - [1316316.1] - and Log an SR to get Datafix.',     -- Problem solution
  'All 11i taxes are migrated to R12.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
    
    

/*
add_signature(g_gen_signatures,
    73,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Retrieve the missing Tax for Migrated Tax</font></strong>',
    'Please follow the Section 11 Of (Doc ID <a href= target="_blank">1316316.1</a>) and Log an SR to get Datafix.',
    'N',
    impact_area_tbl('No Tax calculation for following Regime and Tax combination'),
    'SELECT tax_regime_code,
       tax,
       min(effective_from) effective_from
  FROM zx_update_criteria_results results
WHERE NOT EXISTS
         (SELECT 1 FROM zx_taxes_b
           WHERE tax_regime_code = results.tax_regime_code
             AND tax = results.tax)
GROUP BY tax_regime_code, tax'
  );
*/

  add_signature(
  '5_Miss_Tax_Rate', -- Unique Signature identifier
  'SELECT tax_regime_code,
    tax,
    tax_status_code,
    tax_code tax_rate_code,
    tax_code_id tax_rate_id,
    tax_class,
    org_id
  FROM zx_update_criteria_results results
  WHERE NOT EXISTS
    (SELECT 1
    FROM zx_rates_b
    WHERE tax_class               IN(''OUTPUT'',''INPUT'')
    AND tax_regime_code            = results.tax_regime_code
    AND tax                        = results.tax
    AND tax_status_code            = results.tax_status_code
    AND NVL(source_id,tax_rate_id) = results.tax_code_id
    )
  ORDER BY org_id,
    tax_code_id', -- The text of the signature query
  'Retrieving the missing Tax Rate for Migrated Tax',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Tax calculation for above Regime,Tax,Status and Rate combination',     -- Problem description
  'Please follow the Section 11 of this note - [1316316.1] - and Log an SR to get Datafix.',     -- Problem solution
  'There are no missing Tax Rate for Migrated Tax',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

/*    
 add_signature(g_gen_signatures,
    74,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Retrieve the missing Tax Rate for Migrated Tax</font></strong>',
    'Please follow the Section 11 Of (Doc ID <a href= target="_blank">1316316.1</a>) and Log an SR to get Datafix.',
    'N',
   impact_area_tbl('No Tax calculation for following Regime,Tax,Status and Rate combination'),
    'SELECT tax_regime_code,
       tax,
       tax_status_code,
       tax_code tax_rate_code,
       tax_code_id tax_rate_id,
       tax_class,
       org_id
  FROM zx_update_criteria_results results
WHERE NOT EXISTS
        (SELECT 1 FROM zx_rates_b
          WHERE tax_class in(''OUTPUT'',''INPUT'')
            AND tax_regime_code = results.tax_regime_code
            AND tax = results.tax
            AND tax_status_code = results.tax_status_code
            AND Nvl(source_id,tax_rate_id) = results.tax_code_id)
ORDER BY org_id, tax_code_id'
  );
*/

  add_signature(
  '6_Miss_TAX_STATUS', -- Unique Signature identifier
  'SELECT tax_regime_code,
      tax,
      tax_status_code,

      MIN(effective_from) effective_from
    FROM zx_update_criteria_results results
    WHERE NOT EXISTS
      (SELECT 1
      FROM zx_status_b
      WHERE tax_regime_code = results.tax_regime_code
      AND tax               = results.tax
      AND tax_status_code   = results.tax_status_code
      )
    GROUP BY tax_regime_code,
      tax,
      tax_status_code', -- The text of the signature query
  'Retrieving the missing Tax Status for Migrated Tax',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Tax calculation for above Regime,Tax and Status combination',     -- Problem description
  'Please follow the Section 11 of this note - [1316316.1] - and Log an SR to get Datafix.',     -- Problem solution
  'All combination of Regime,Tax and Status have been migrated to R12.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y'); 
  
/*
  add_signature(g_gen_signatures,
    75,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Retrieve the missing Tax Status for Migrated Tax</font></strong>',
    'Please follow the Section 11 Of (Doc ID <a href= target="_blank">1316316.1</a>)and  Log an SR to get Datafix.',
    'N',
    impact_area_tbl('No Tax calculation for following Regime,Tax and Status combination'),
    'SELECT tax_regime_code,
       tax,
       tax_status_code,
       min(effective_from) effective_from
  FROM zx_update_criteria_results results
WHERE NOT EXISTS
         (SELECT 1 FROM zx_status_b
           WHERE tax_regime_code = results.tax_regime_code
             AND tax = results.tax
             AND tax_status_code = results.tax_status_code)
GROUP BY tax_regime_code, tax, tax_status_code'
  );
*/

  add_signature(
  '7_RR_info', -- Unique Signature identifier
  'SELECT /*+parallel(zl)*/ 
      Trx_Id,
      COUNT(DISTINCT trx_id)
    FROM zx_lines zl
    WHERE application_id  = 200
    AND entity_code       = ''AP_INVOICES''
    AND record_type_code  = ''MIGRATED''
    AND historical_flag   = ''Y''
    AND (tax_regime_code IS NULL
    OR tax_regime_id     IS NULL
    OR tax               IS NULL
    OR tax_id            IS NULL
    OR tax_status_id     IS NULL
    OR tax_status_code   IS NULL
    OR tax_rate_id       IS NULL
    OR tax_rate_code     IS NULL
    OR tax_rate          IS NULL)
    GROUP BY Trx_Id', -- The text of the signature query
  'Migrated Tax Lines that have NULL Regime-to-Rate information in ZX_LINES',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Migrated Tax Lines have NULL Regime-to-Rate information in ZX_LINES.Migrated Invoice validation or Tax Calculation fails with errors like:
  <ol>
    <li> Tax/Tax_Id cannot be NULL,</li>
    <li> Tax does not exist,</li>
    <li> Tax Rate Code does not exist, etc.</ol>',     -- Problem description
  'Migrated Tax Lines have NULL Regime-to-Rate information in ZX_LINES. 
  <br>Please follow the Section 17 of this note - [1316316.1] - and Log an SR to get Data Fix.<br/>Apply the SQL scripts following the steps given in the action_plan.txt FILE Pop_Regime_To_Rate.zip',     -- Problem solution
  'Migrated Tax Lines have no NULL values on the Regime-to-Rate information in ZX_LINES',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    76,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Migrated Tax Lines have NULL Regime-to-Rate information in ZX_LINES.Migrated Invoice validation fails with errors like (1) Tax/Tax_Id cannot be NULL, (2) Tax does not exist, (3) Tax Rate Code does not exist, etc.</font></strong>',
    'Please follow the Section 17 Of (Doc ID <a href= target="_blank">1316316.1</a>) and Log an SR to get Data Fix. <br/>Apply the SQL scripts following the steps given in the action_plan.txt FILE Pop_Regime_To_Rate.zip',
    'N',
    impact_area_tbl('No Tax Calculation','Invoice Validation'),
    'SELECT /*+parallel(zl)*//*
       Trx_Id,COUNT(DISTINCT trx_id)
  FROM zx_lines zl
 WHERE application_id = 200
   AND entity_code = ''AP_INVOICES''
   AND record_type_code = ''MIGRATED''
   AND historical_flag = ''Y''
   AND (tax_regime_code IS NULL OR
        tax_regime_id IS NULL OR
        tax IS NULL OR
        tax_id IS NULL OR
        tax_status_id IS NULL OR
        tax_status_code IS NULL OR
        tax_rate_id IS NULL OR
        tax_rate_code IS NULL OR
        tax_rate IS NULL)group by Trx_Id'
  );
*/


  add_signature(
  '8_AUTO_TAX_CALC_NO', -- Unique Signature identifier
  'SELECT APS.VENDOR_NAME,
      APS.VENDOR_ID,
      APSS.VENDOR_SITE_CODE,
      APSS.VENDOR_SITE_ID,
      APSS.AUTO_TAX_CALC_FLAG
    FROM AP_SUPPLIER_SITES_ALL APSS,
      AP_SUPPLIERS APS
    WHERE APS.VENDOR_ID          = APSS.VENDOR_ID
    AND APSS.AUTO_TAX_CALC_FLAG  =''N''
    AND APSS.AUTO_TAX_CALC_FLAG IS NOT NULL
    AND APS.EMPLOYEE_ID         IS NOT NULL', -- The text of the signature query
  'Suppliers having Tax not calculated',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Employee specific automatic tax calculation can not be done.',     -- Problem description
  'Tax not calculating for the following supplier with supplier type EMPLOYEE because AUTO_TAX_CALC_FLAG is NO at supplier site level. <br>Please follow the Section 14 of this note - [1316316.1] - and apply the Datafix to correct the issue.</BR>
  If you want to enable AUTO_TAX_CALC_FLAG to Y for specific supplier you need to pass the vendor_id in the Update statement.',     -- Problem solution
  'AUTO_TAX_CALC_FLAG is set properly at supplier site level.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'N');
  
/*  
add_signature(g_gen_signatures,
    77,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Tax not calculating for the following supplier with supplier type EMPLOYEE because AUTO_TAX_CALC_FLAG is NO at supplier site level</font></strong>',
    'Please follow the Section 14 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the Datafix to correct the issue.</BR>
If you want to enable AUTO_TAX_CALC_FLAG to Y for specific supplier you need to pass the vendor_id in the Update statement.',
    'N',
    impact_area_tbl('Employee specific automatic tax calculation can not be done'),
    'SELECT APS.VENDOR_NAME,
       APS.VENDOR_ID,
       APSS.VENDOR_SITE_CODE, 
       APSS.VENDOR_SITE_ID,
       APSS.AUTO_TAX_CALC_FLAG
  FROM AP_SUPPLIER_SITES_ALL APSS,
       AP_SUPPLIERS APS
 WHERE APS.VENDOR_ID = APSS.VENDOR_ID
   AND APSS.AUTO_TAX_CALC_FLAG=''N''
   AND APSS.AUTO_TAX_CALC_FLAG IS NOT NULL
   AND APS.EMPLOYEE_ID IS NOT NULL'
  );
*/

  add_signature(
  '9_TAXREGIME', -- Unique Signature identifier
  'SELECT *
    FROM
      (SELECT DECODE(COUNT(det_factor_templ_code),0,0,COUNT(det_factor_templ_code)) regime_count
      FROM zx_det_factor_templ_b
      WHERE det_factor_templ_code = ''TAXREGIME''
      ) a
    WHERE a.regime_count = 0', -- The text of the signature query
  'Checking if TAXREGIME is available as a determining factor template code',     -- Signature title
  '[regime_count] = [0]',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax not calculating after upgrading from 11.5.9 to 12.1.1, because TAXREGIME is not available as a determining factor template code',     -- Problem description
  'Please follow the Section 12 of this note - [1316316.1] - and apply the code-fix {8747425} to fix this issue.',     -- Problem solution
  'TAXREGIME is available as a determining factor template code.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    78,
    '8747425',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Tax not calculating after upgrading from 11.5.9 to 12.1.1, because TAXREGIME is not available as a determining factor template code</font></strong>',
    'Please follow the Section 12 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply Code-fix  Patch 8747425 to fix this issue.',
    'N',
    impact_area_tbl('When creating a new Configuration Owner Tax Option in E-Business Tax the only Regime Determination Set that is available is STCC','Determine Applicable Regimes value is not available in LoV'),
    'select * from
(
select decode(count(det_factor_templ_code),0,0,count(det_factor_templ_code)) regime_count from  
 zx_det_factor_templ_b
 WHERE det_factor_templ_code = ''TAXREGIME'' ) a
 where a.regime_count=0'
 );
*/

  add_signature(
  '10_ACCT_FLEX', -- Unique Signature identifier
  'SELECT DETERMINING_FACTOR_CLASS_CODE,
      TAX_PARAMETER_CODE
    FROM ZX_DET_FACTOR_TEMPL_DTL
    WHERE DET_FACTOR_TEMPL_ID IN
      (SELECT DET_FACTOR_TEMPL_ID
      FROM ZX_DET_FACTOR_TEMPL_B
      WHERE DET_FACTOR_TEMPL_CODE = ''EX Acct String Range-Party FC''
      AND RECORD_TYPE_CODE        = ''MIGRATED''
      )
    AND DETERMINING_FACTOR_CLASS_CODE = ''ACCOUNTING_FLEXFIELD''
    AND TAX_PARAMETER_CODE           IS NULL', -- The text of the signature query
  'Account based Tax Rules are not evaluated that are created with new conditions under migrated Determining Factor Set EX Acct String Range-Party FC',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Account based Tax Rules are not evaluated which are created with new conditions under migrated Determining Factor Set EX Acct String Range-Party FC',     -- Problem description
  'Please follow the Section 9 Of this note - [1316316.1] -  and apply  {9546116} to fix this issue and populate the missing Tax Parameter Code.',     -- Problem solution
  'Account based Tax Rules are created with new conditions under migrated Determining Factor Set EX Acct String Range-Party FC',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  

/*  
add_signature(g_gen_signatures,
    79,
    '9546116',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Account based Tax Rules are not evaluated that are created with new conditions under migrated Determining Factor Set EX Acct String Range-Party FC</font></strong>',
    'Please follow the Section 9 Of (Doc ID <a href= target="_blank">1316316.1</a>)  and apply  Patch:9546116 to fix this issue and populate the missing Tax Parameter Code',
    'N',
    impact_area_tbl('Tax calculation is not following the Tax Rules which are created with new conditions under migrated Determining Factor Set EX Acct String Range-Party FC'),
    'SELECT DETERMINING_FACTOR_CLASS_CODE,TAX_PARAMETER_CODE
  FROM ZX_DET_FACTOR_TEMPL_DTL 
 WHERE DET_FACTOR_TEMPL_ID IN
         (SELECT DET_FACTOR_TEMPL_ID
            FROM ZX_DET_FACTOR_TEMPL_B
           WHERE DET_FACTOR_TEMPL_CODE = ''EX Acct String Range-Party FC''
             AND RECORD_TYPE_CODE = ''MIGRATED'')
   AND DETERMINING_FACTOR_CLASS_CODE = ''ACCOUNTING_FLEXFIELD''
   AND TAX_PARAMETER_CODE is Null'
  );
*/


  add_signature(
  '11_ZX_TRX_BIZ_FC_CODE_NOT_EXIST', -- Unique Signature identifier
  'SELECT fc_code_1.classification_code,
         fc_code_1.classification_id,
         fc_code_1.classification_type_code,
         fc_code_1.classification_type_id,
         Count(*) No_of_records
    FROM zx_fc_codes_denorm_b fc_code_1,
         (SELECT DISTINCT classification_code, 
                 classification_id,
                 classification_type_code, 
                 classification_type_id 
            FROM zx_fc_codes_denorm_b 
           WHERE (classification_type_code, 
                  classification_type_id) 
                 IN (SELECT DISTINCT classification_type_code, 
                            classification_type_id 
                       FROM zx_fc_types_b fc_typ)
         ) fc_code_2
   WHERE fc_code_1.classification_type_code = fc_code_2.classification_type_code
     AND fc_code_1.classification_type_id = fc_code_2.classification_type_id
     AND fc_code_1.classification_code = fc_code_2.classification_code
     AND fc_code_1.classification_id = fc_code_2.classification_id
   GROUP BY	fc_code_1.classification_type_code,
         fc_code_1.classification_type_id,
         fc_code_1.classification_code,
         fc_code_1.classification_id
  HAVING Count(*) < 
          (SELECT Count(*) no_of_languages
             FROM fnd_languages
            WHERE installed_flag IN (''I'',''B''))', -- The text of the signature query
  'Expense Report / Payables Import fails with error ZX_TRX_BIZ_FC_CODE_NOT_EXIST',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Expense Report Export / Payables Import Failing because of missing CLASSIFICATION CODES in ZX_FC_CODES_DENORM_B ',     -- Problem description
  'Please follow Section 10 of this note - 1316316.1 - and apply the data-fix {10093528} to fix this issue',     -- Problem solution
  'There is no missing CLASSIFICATION CODES in ZX_FC_CODES_DENORM_B .',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    80,
    '10093528',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Import fails with error ZX_TRX_BIZ_FC_CODE_NOT_EXIST</font></strong>',
    'Please follow Section 10 the (Doc ID <a href= target="_blank">1316316.1</a>) and apply data-fix Patch:10093528  to fix this issue',
    'N',
    impact_area_tbl('Expense Report Export Failing','Payables Import Failing'),
    'SELECT fc_code_1.classification_code
  FROM zx_fc_codes_denorm_b fc_code_1,
       (SELECT DISTINCT classification_code,
               classification_id, 
               classification_type_code,
               classification_type_id
          FROM zx_fc_codes_denorm_b
         WHERE (classification_type_code,
                classification_type_id)
                 IN (SELECT DISTINCT classification_type_code,
                            classification_type_id
                       FROM zx_fc_types_b fc_typ) 
       ) fc_code_2
 WHERE fc_code_1.classification_type_code = fc_code_2.classification_type_code
   AND fc_code_1.classification_type_id = fc_code_2.classification_type_id
   AND fc_code_1.classification_code = fc_code_2.classification_code
   AND fc_code_1.classification_id = fc_code_2.classification_id
 GROUP BY fc_code_1.classification_type_code,
       fc_code_1.classification_type_id,
       fc_code_1.classification_code,
       fc_code_1.classification_id
HAVING Count(*) <
         (SELECT Count(*) no_of_languages
            FROM fnd_languages
           WHERE installed_flag IN (''I'',''B''))'
);
*/

  add_signature(
  '12_RECOVERY', -- Unique Signature identifier
  'SELECT *
    FROM zx_rates_b_tmp rates
    WHERE rates.tax_rate_code IN
      (SELECT rates1.tax_rate_code
      FROM zx_rates_b rates1
      WHERE rates.tax_regime_code = rates1.tax_regime_code
      AND rates.tax               = rates1.tax
      AND rates.tax_status_code   = rates1.tax_status_code
      AND rates.content_owner_id  = rates1.content_owner_id
      AND rates1.record_type_code = ''MIGRATED''
      AND rates1.rate_type_code  <> ''RECOVERY''
      AND sysdate BETWEEN NVL(rates1.effective_from,sysdate-1) AND NVL(rates1.effective_to,sysdate)
      AND rownum = 1
      )
    AND NOT EXISTS
      (SELECT 1
      FROM zx_rates_b rates2
      WHERE rates2.tax_regime_code = rates.tax_regime_code
      AND rates2.tax               = rates.tax
      AND rates2.tax_status_code   = rates.tax_status_code
      AND rates2.content_owner_id  = rates.content_owner_id
      AND rates2.rate_type_code   <> ''RECOVERY''
      AND rates2.default_rate_flag = ''Y'')', -- The text of the signature query
  'Checking Default Rate Flag Setup',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Default rate flag incorrect for non recovery based rates. Hence Non Recovery Tax rate can not be calculated.',     -- Problem description
  'Please follow the Section 13 Of this note - [1316316.1] - for the solution action plan.',     -- Problem solution
  'Default rate flag is correct for non recovery based rates.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


/*
add_signature(g_gen_signatures,
    81,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Default rate flag incorrect for non recovery based rates</font></strong>',
    'Please follow the Section 13 Of (Doc ID <a href= target="_blank">1316316.1</a>) for the solution action plan.',
    'N',
    impact_area_tbl('Non Recovery Tax rate can not be calculated'),
    'select * from zx_rates_b_tmp rates where rates.tax_rate_code in ( select rates1.tax_rate_code from zx_rates_b rates1 where rates.tax_regime_code = rates1.tax_regime_code
 and rates.tax = rates1.tax and rates.tax_status_code = rates1.tax_status_code
and rates.content_owner_id = rates1.content_owner_id and rates1.record_type_code = ''MIGRATED''
and rates1.rate_type_code <> ''RECOVERY''and sysdate between nvl(rates1.effective_from,sysdate-1) and nvl(rates1.effective_to,sysdate)and rownum = 1)
and not exists (select 1 from zx_rates_b rates2
 where rates2.tax_regime_code = rates.tax_regime_code
and rates2.tax = rates.tax and rates2.tax_status_code = rates.tax_status_code
and rates2.content_owner_id = rates.content_owner_id
and rates2.rate_type_code <> ''RECOVERY''and rates2.default_rate_flag = ''Y'' )'
);
*/

  add_signature(
  '13_OIE_Enabled', -- Unique Signature identifier
  'select Tax_Regime_Code, Tax, Tax_Rate_Code,record_type_code, count(*) count from 
    zx_rates_b zr
    where zr.active_flag= ''Y''
    AND zr.effective_to is NULL
    AND zr.rate_type_code=''PERCENTAGE''
    AND zr.record_type_code NOT IN (''MIGRATED'',''SEEDED'',''EBTAX_CONTENT_UPLOAD'')
    and not exists
    (select 1 from ZX_WEBEXP_CLASSIFICATIONS_V
    where lookup_code=Upper(zr.Tax_Rate_code)) 
    GROUP BY Tax_Regime_Code, Tax, Tax_Rate_Code, record_type_code
    order by Tax_Regime_Code, Tax, Tax_Rate_Code, record_type_code', -- The text of the signature query
  'Checking if Tax is OIE Enabled',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax cannot be calculated because they are not OIE Enabled',     -- Problem description
  'Please add them in Lookup Type ZX_WEB_EXP_TAX_CLASSIFICATIONS as follows:
  <li>Go to Application Developer Responsibility.Navigate to Applications->Lookups.Open Application Object Library.</li>
  <li>Search the Lookup Type ZX_WEB_EXP_TAX_CLASSIFICATIONS. Add the Tax Rate Code as the value of Code, Meaning and Description.</li>',     -- Problem solution
  'TAX is OIE Enabled.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    82,
    'No RCA Bug Available-User Mistake',
    'N.A',
    ' ',
    '<strong><font color = "ff0000">Tax cannot be calculated because they are not OIE Enabled</font></strong>',
    'Please add them in Lookup Type ZX_WEB_EXP_TAX_CLASSIFICATIONS.
<BR/>Go to Application Developer Responsibility.Navigate to Applications->Lookups.Open Application Object Library.
<BR/>Search the Lookup Type ZX_WEB_EXP_TAX_CLASSIFICATIONS.Add the Tax Rate Code as the value of Code , Meaning and Description',
    'N',
    impact_area_tbl('Tax can not be calculated for Oracle Internet Expense'),
    'select Tax_Regime_Code, Tax, Tax_Rate_Code,record_type_code, count(*) count from 
zx_rates_b zr
where zr.active_flag= ''Y''
AND zr.effective_to is NULL
AND zr.rate_type_code=''PERCENTAGE''
AND zr.record_type_code NOT IN (''MIGRATED'',''SEEDED'',''EBTAX_CONTENT_UPLOAD'')
and not exists
(select 1 from ZX_WEBEXP_CLASSIFICATIONS_V
where lookup_code=Upper(zr.Tax_Rate_code)) 
GROUP BY Tax_Regime_Code, Tax, Tax_Rate_Code, record_type_code
order by Tax_Regime_Code, Tax, Tax_Rate_Code, record_type_code'
);
*/

  add_signature(
  '13_Tax_Tolerance', -- Unique Signature identifier
  'SELECT *
    FROM zx_evnt_cls_options
    WHERE application_id                = 200
    AND entity_code                     = ''AP_INVOICES''
    AND record_type_code                = ''MIGRATED''
    AND NVL(allow_override_flag,''N'') <> ''Y''', -- The text of the signature query
  'Checking If Tax Tolerance is upgraded to Configuration Owner Tax Options',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax Tolerance is not upgraded to Configuration Owner Tax Options In R12.',     -- Problem description
  'If this is your LIVE instance, please follow the Section 15 of this note - [1316316.1] - and apply the sugested Datafix to correct the issue.<BR/>
  </BR>Preinstall checkin for this issue is {13019385}.
  <BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] - [1448102.1] - have been applied prior to running the main upgrade driver for Release 12.1.  
  This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product. Please ensure ALL listed EBTax(ZX) patches are applied but we also strongly recommend that ALL patches for licensed products are applied, 
  to ensure you have the smoothest possible upgrade.',     -- Problem solution
  'Tax Tolerance got upgraded successfully in Configuration Owner Tax Options ',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    83,
    '13019385',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Tax Tolerance is not upgraded to Configuration Owner Tax Options In R12</font></strong>',
    'If this is your LIVE instance, Please follow the Section 15 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the Datafix to correct the issue.<BR/>
</BR>Preinstall checkin for this issue is Patch:13019385.
<BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] (Doc ID <a href=" http://support.oracle.com/rs?type=doc'||'&id='||1448102.1||'" target="_blank">1448102.1</a>) have been applied prior to running the main upgrade driver for Release 12.1.  
<BR/>This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product.  Please ensure ALL listed EBTax(ZX) patches are applied but we strongly recommend that ALL patches for licensed products are applied, 
to ensure you have the smoothest possible upgrade.',
    'N',
    impact_area_tbl('Unable to view Tax tolerances in R12 which were present in 11i'),
    'select * from zx_evnt_cls_options
WHERE application_id = 200
AND entity_code = ''AP_INVOICES''
AND record_type_code = ''MIGRATED''
AND NVL(allow_override_flag,''N'') <> ''Y'''
);
*/

  add_signature(
  '14_TAX_Code', -- Unique Signature identifier
  'SELECT DISTINCT Tax_Rate_Name,
      Tax_Rate_Id,
      Description
    FROM ZX_RATES_TL ZRT
    WHERE DESCRIPTION IS NULL
    AND EXISTS
      (SELECT 1
      FROM AP_TAX_CODES_ALL AP,
        ZX_RATES_B ZRB
      WHERE AP.TAX_ID     = ZRB.SOURCE_ID
      AND AP.DESCRIPTION IS NOT NULL
      AND ZRB.TAX_CLASS   = ''INPUT''
      AND ZRB.TAX_RATE_ID = ZRT.TAX_RATE_ID)', -- The text of the signature query
  'Suppliers Tax Code Description is Different between 11i And R12',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Checking if Suppliers Tax Code Description is Different between 11i and R12.',     -- Problem description
  'If this is your LIVE instance, Please follow the Section 16 of this note - [1316316.1] - and apply the GDF patch to correct the issue.
  <BR/>Preinstall checkin for this issue is {13963357}.
  <BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] - [1448102.1] - have been applied prior to running the main upgrade driver for Release 12.1.  
  This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product. Please ensure ALL listed EBTax(ZX) patches are applied but we also strongly recommend that ALL patches for licensed products are applied, 
  to ensure you have the smoothest possible upgrade.',     -- Problem solution
  'Suppliers Tax Code Description migrated in R12 .',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*
add_signature(g_gen_signatures,
    84,
    '13963357',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Suppliers Tax Code Description is Different  In 11i And R12</font></strong>',
    'If this is your LIVE instance, Please follow the Section 16 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the GDF patch to correct the issue.<BR/>Preinstall checkin for this issue is Patch:13963357.
<BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] (Doc ID <a href=" http://support.oracle.com/rs?type=doc'||'&id='||1448102.1||'" target="_blank">1448102.1</a>) have been applied prior to running the main upgrade driver for Release 12.1.  
<BR/>This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product.  Please ensure ALL listed EBTax(ZX) patches are applied but we strongly recommend that ALL patches for licensed products are applied,to ensure you have the smoothest possible upgrade.',
    'N',
    impact_area_tbl('Unable to find 11i Tax description in R12'),
    'SELECT distinct Tax_Rate_Name,Tax_Rate_Id,Description FROM ZX_RATES_TL ZRT
WHERE DESCRIPTION IS NULL
AND EXISTS (SELECT 1
FROM AP_TAX_CODES_ALL AP, ZX_RATES_B ZRB
WHERE AP.TAX_ID = ZRB.SOURCE_ID
AND AP.DESCRIPTION is NOT NULL
AND ZRB.TAX_CLASS = ''INPUT''
AND ZRB.TAX_RATE_ID = ZRT.TAX_RATE_ID)'
);
*/


  add_signature(
  '15_Event_CLASS', -- Unique Signature identifier
  'SELECT mapping.application_id,
      mapping.entity_code,
      mapping.event_class_code,
      sys.org_id,
      ptp.party_tax_profile_id
    FROM ZX_PARTY_TAX_PROFILE ptp,
      AP_SYSTEM_PARAMETERS_ALL SYS,
      ZX_EVNT_CLS_MAPPINGS mapping
    WHERE mapping.application_id = 200
    AND ptp.party_id             = sys.org_id
    AND ptp.PARTY_TYPE_CODE      =''OU''
    AND ptp.record_type_code     =''MIGRATED''
    AND NOT EXISTS
      (SELECT 1
      FROM ZX_EVNT_CLS_OPTIONS opt
      WHERE opt.FIRST_PTY_ORG_ID = ptp.party_tax_profile_id
      AND opt.APPLICATION_ID     = mapping.application_id
      AND opt.ENTITY_CODE        = mapping.entity_code
      AND opt.EVENT_CLASS_CODE   = mapping.event_class_code)', -- The text of the signature query
  'Checking if Event Class Options Are Migrated to R12 for Payables',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Unable to find Event Class Option in R12',     -- Problem description
  'If this is your LIVE instance, Please follow the Section 18 of this note - [1316316.1] - and apply the Fix to correct the issue.
  <BR/>Preinstall checkin for this issue is {8495719}.
  <BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] - [1448102.1] - have been applied prior to running the main upgrade driver for Release 12.1.  
  This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product. Please ensure ALL listed EBTax(ZX) patches are applied but we also strongly recommend that ALL patches for licensed products are applied, 
  to ensure you have the smoothest possible upgrade.',     -- Problem solution
  'Event Class Options of Payables are Migrated to R12.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    85,
    '8495719',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Event Class Options Are Not Migrated For Payables</font></strong>',
    'If this is your LIVE instance, Please follow the Section 18 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the Fix to correct the issue.<BR/>Preinstall checkin for this issue is Patch: 8495719.
<BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] (Doc ID <a href=" http://support.oracle.com/rs?type=doc'||'&id='||1448102.1||'" target="_blank">1448102.1</a>) have been applied prior to running the main upgrade driver for Release 12.1.  
<BR/>This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product.  Please ensure ALL listed EBTax(ZX) patches are applied but we strongly recommend that ALL patches for licensed products are applied,to ensure you have the smoothest possible upgrade.',
    'N',
    impact_area_tbl('Unable to find Event Class Option in R12'),
    'SELECT mapping.application_id,
       mapping.entity_code,
       mapping.event_class_code,
       sys.org_id,
       ptp.party_tax_profile_id
  FROM ZX_PARTY_TAX_PROFILE ptp,
       AP_SYSTEM_PARAMETERS_ALL sys,
       ZX_EVNT_CLS_MAPPINGS mapping
WHERE mapping.application_id = 200
   AND ptp.party_id = sys.org_id
   AND ptp.PARTY_TYPE_CODE =''OU''
   AND ptp.record_type_code=''MIGRATED''
   AND NOT EXISTS (SELECT 1
                     FROM ZX_EVNT_CLS_OPTIONS opt
                    WHERE opt.FIRST_PTY_ORG_ID = ptp.party_tax_profile_id
                      AND opt.APPLICATION_ID   = mapping.application_id
                      AND opt.ENTITY_CODE      = mapping.entity_code
                      AND opt.EVENT_CLASS_CODE = mapping.event_class_code
                  )'
);
*/


  add_signature(
  '16_P_Tax_Codes', -- Unique Signature identifier
  'SELECT NAME,
      ORG_ID,
      ENABLED_FLAG,
      START_DATE,
      INACTIVE_DATE
    FROM AP_TAX_CODES_ALL
    WHERE TAX_TYPE NOT IN (''TAX_GROUP'',''AWT'')
    AND NOT EXISTS
      (SELECT 1 FROM ZX_RATES_B WHERE SOURCE_ID = TAX_ID AND TAX_CLASS = ''INPUT'')', -- The text of the signature query
  'Checking if 11i Payables Tax Codes are Migrated',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Unable to find 11i Tax Codes in R12. Hence unable to calculate tax.',     -- Problem description
  'Please follow the Section 19 of this note - [1316316.1] - and apply the solution
  <BR/>Preinstall checkins for this issues are {13963357} and {14588757}.
  <BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] - [1448102.1] - have been applied prior to running the main upgrade driver for Release 12.1.  
  This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product. Please ensure ALL listed EBTax(ZX) patches are applied but we also strongly recommend that ALL patches for licensed products are applied, 
  to ensure you have the smoothest possible upgrade.',     -- Problem solution
  '11i Payables Tax Codes are Migrated to R12 correctly.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    86,
    '14588757',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">11i Payables Tax Codes are not Migrated</font></strong>',
    'Please follow the Section 19 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the solution<BR/>Preinstall checkins for this issues are Patch:13963357 and Patch:14588757.
<BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] (Doc ID <a href=" http://support.oracle.com/rs?type=doc'||'&id='||1448102.1||'" target="_blank">1448102.1</a>) have been applied prior to running the main upgrade driver for Release 12.1.  
<BR/>This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product.  Please ensure ALL listed EBTax(ZX) patches are applied but we strongly recommend that ALL patches for licensed products are applied,to ensure you have the smoothest possible upgrade.',
    'N',
    impact_area_tbl('Unable to find 11i Tax Codes in R12','Unable to calculate Tax'),
    'SELECT NAME, ORG_ID, ENABLED_FLAG, START_DATE, INACTIVE_DATE
FROM AP_TAX_CODES_ALL
WHERE TAX_TYPE NOT IN (''TAX_GROUP'',''AWT'')
AND NOT EXISTS (SELECT 1 FROM ZX_RATES_B
WHERE SOURCE_ID = TAX_ID
AND TAX_CLASS = ''INPUT'')'
);
*/

  add_signature(
  '17_AP_Tax_Group', -- Unique Signature identifier
  'SELECT NAME, ORG_ID, START_DATE, INACTIVE_DATE, ENABLED_FLAG
 FROM AP_TAX_CODES_ALL VAT
 WHERE TAX_TYPE = ''TAX_GROUP''
 AND NOT EXISTS (SELECT 1 FROM ZX_CONDITION_GROUPS_B GRP
        WHERE (NAME = CONDITION_GROUP_CODE
             OR NAME||''-''||''XIP'' = CONDITION_GROUP_CODE
            )
        AND DET_FACTOR_TEMPL_CODE = ''STCC'')', -- The text of the signature query
  'Checking if 11i Payables Tax Groups are Migrated',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Unable to find 11i Tax Group in R12. Hence unable to calculate tax.',     -- Problem description
  'Please follow the Section 20 of this note - [1316316.1] - and  apply the solution<BR/>
  Preinstall checkins for this issues are {13963357} and {14789335}.
  <BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] - [1448102.1] - have been applied prior to running the main upgrade driver for Release 12.1.  
  This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product. Please ensure ALL listed EBTax(ZX) patches are applied but we also strongly recommend that ALL patches for licensed products are applied, 
  to ensure you have the smoothest possible upgrade.',     -- Problem solution
  '11i Payables Tax Groups are Migrated successfully.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    87,
    '14588757',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">11i Payables Tax Groups are not Migrated</font></strong>',
    'Please follow the Section 20 Of (Doc ID <a href= target="_blank">1316316.1</a>) and  apply the solution<BR/>Preinstall checkins for this issues are Patch:13963357 and Patch:14588757.
<BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] (Doc ID <a href=" http://support.oracle.com/rs?type=doc'||'&id='||1448102.1||'" target="_blank">1448102.1</a>) have been applied prior to running the main upgrade driver for Release 12.1.  
<BR/>This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product.  Please ensure ALL listed EBTax(ZX) patches are applied but we strongly recommend that ALL patches for licensed products are applied,to ensure you have the smoothest possible upgrade.',
    'N',
    impact_area_tbl('Unable to find 11i Tax Group in R12','Unable to calculate Tax'),
    'SELECT NAME, ORG_ID, START_DATE, INACTIVE_DATE, ENABLED_FLAG
FROM AP_TAX_CODES_ALL VAT
WHERE TAX_TYPE = ''TAX_GROUP''
AND NOT EXISTS (SELECT 1 FROM ZX_CONDITION_GROUPS_B GRP
       WHERE NAME = CONDITION_GROUP_CODE
       AND DET_FACTOR_TEMPL_CODE = ''STCC'')'
);
*/


add_signature(
  '17_AR_Tax_Group', -- Unique Signature identifier
  'SELECT TAX_CODE, ORG_ID, START_DATE, END_DATE, ENABLED_FLAG
FROM AR_VAT_TAX_ALL VAT
WHERE TAX_TYPE = ''TAX_GROUP''
AND NOT EXISTS (SELECT 1 FROM ZX_CONDITION_GROUPS_B GRP
      WHERE (SUBSTR(VAT.TAX_CODE,1,40) = SUBSTR(CONDITION_GROUP_CODE,1,40)
       OR VAT.TAX_CODE||''-''||''XOP'' = CONDITION_GROUP_CODE)
      AND DET_FACTOR_TEMPL_CODE = ''STCC'') ', -- The text of the signature query
  'Checking if 11i Receivables Tax Groups are Migrated',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Unable to find 11i Tax Group in R12. Hence unable to calculate tax.',     -- Problem description
  'Please follow the Section 20 of this note - [1316316.1] - and  apply the solution<BR/>
  Preinstall checkins for this issues are {13963357} and {14789335}.
  <BR/>If this is a TEST UPGRADE then you can avoid this issue in your next testing cycle by ensuring all the patches from the Oracle E-Business Suite Pre-install Patches Report [Video] - [1448102.1] - have been applied prior to running the main upgrade driver for Release 12.1.  
  This report, which is updated regularly and always contains the most up to date information, splits the essential patches out by product. Please ensure ALL listed EBTax(ZX) patches are applied but we also strongly recommend that ALL patches for licensed products are applied, 
  to ensure you have the smoothest possible upgrade.',     -- Problem solution
  '11i Receivables Tax Groups are Migrated successfully.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


  add_signature(
  '18_use_tax_classification_flag', -- Unique Signature identifier
  'SELECT org_id,
      application_id,
      record_type_code,
      USE_TAX_CLASSIFICATION_FLAG
    FROM ZX_PRODUCT_OPTIONS_ALL
    WHERE NVL(use_tax_classification_flag,''N'')!=''Y''
    AND record_type_code = ''MIGRATED''
    AND application_id IN ( 200,201,222,275,401,660)', -- The text of the signature query
  'Checking if user can update Application Tax Options For Migrated Tax Options',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Unable to update the Application Tax Options in Tax Manager.',     -- Problem description
  'Please follow the Section 21 of this Note - [1316316.1] - and  apply the solution.',     -- Problem solution
  'Application Tax Options For Migrated Tax Options can be updated in Tax Manager.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    88,
    'No RCA Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Can Not Update Application Tax Options For Migrated Tax Options</font></strong>',
    'Please follow the Section 21 Of (Doc ID <a href= target="_blank">1316316.1</a>) and  apply the solution.',
    'N',
    impact_area_tbl('Unable to update the Application Tax Options in Tax Manager'),
    'select org_id,application_id,record_type_code,USE_TAX_CLASSIFICATION_FLAG from  ZX_PRODUCT_OPTIONS_ALL
where nvl(use_tax_classification_flag,''N'')!=''Y''
and record_type_code=''MIGRATED''
and application_id in ( 200,201,222,275,401,660)'
);
*/


  add_signature(
  '19_TAX_Rep_Codes', -- Unique Signature identifier
  'SELECT REPORTING_CODE,
      EFFECTIVE_FROM
    FROM
      ( SELECT DISTINCT FIN_SYS_PARAM.VAT_COUNTRY_CODE REPORTING_CODE,
        REPORT_TYPES.EFFECTIVE_FROM EFFECTIVE_FROM,
        REPORT_TYPES.REPORTING_TYPE_ID REPORTING_TYPE_ID
      FROM FINANCIALS_SYSTEM_PARAMS_ALL FIN_SYS_PARAM,
        ZX_REPORTING_TYPES_B REPORT_TYPES
      WHERE REPORT_TYPES.REPORTING_TYPE_CODE = ''MEMBER STATE''
      AND FIN_SYS_PARAM.VAT_COUNTRY_CODE    IS NOT NULL
      AND NOT EXISTS
        (SELECT 1
        FROM ZX_REPORTING_CODES_B
        WHERE REPORTING_TYPE_ID            = REPORT_TYPES.REPORTING_TYPE_ID
        AND FIN_SYS_PARAM.VAT_COUNTRY_CODE = REPORTING_CODE_CHAR_VALUE
        )
      )', -- The text of the signature query
  'Checking if Tax Reporting Codes Set up is Upgraded',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax Reporting Codes Set up not Upgraded. Hence unable to show invoices in EU Audit Trail report ',     -- Problem description
  'Please follow the Section 22 of this note - [1316316.1] - and  apply the solution.',     -- Problem solution
  'Tax Reporting Codes Set up is Upgraded successfully.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    89,
    'No RCA Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Tax Reporting Codes Set up not Upgraded</font></strong>',
    'Please follow the Section 22 Of (Doc ID <a href= target="_blank">1316316.1</a>) and  apply the solution.',
    'N',
    impact_area_tbl('Unable to show invoices in EU Audit Trail report'),
    'SELECT REPORTING_CODE,
       EFFECTIVE_FROM
FROM (
       SELECT DISTINCT FIN_SYS_PARAM.VAT_COUNTRY_CODE REPORTING_CODE,
                       REPORT_TYPES.EFFECTIVE_FROM EFFECTIVE_FROM,
                       REPORT_TYPES.REPORTING_TYPE_ID REPORTING_TYPE_ID
       FROM FINANCIALS_SYSTEM_PARAMS_ALL FIN_SYS_PARAM,
            ZX_REPORTING_TYPES_B REPORT_TYPES
       WHERE REPORT_TYPES.REPORTING_TYPE_CODE = ''MEMBER STATE''
       AND FIN_SYS_PARAM.VAT_COUNTRY_CODE IS NOT NULL
       AND NOT EXISTS (
                       SELECT 1
                       FROM ZX_REPORTING_CODES_B
                       WHERE REPORTING_TYPE_ID = REPORT_TYPES.REPORTING_TYPE_ID
                       AND FIN_SYS_PARAM.VAT_COUNTRY_CODE = REPORTING_CODE_CHAR_VALUE
                      )
     )'
);
*/

  add_signature(
  '20_TAX_dist_sync_check', -- Unique Signature identifier
  'SELECT
      /*+ leading(ap,zx,apd) parallel(ap) parallel(zx) parallel(apd)
      use_nl(zx,apd) index(apd AP_INVOICE_DISTRIBUTIONS_N29) */
      DISTINCT ap.invoice_Id TRX_ID
    FROM zx_rec_nrec_dist zx,
      ap_invoices_all ap,
      ap_invoice_distributions_all apd
    WHERE NVL(ap.historical_flag,''N'') = ''Y''
    AND ap.cancelled_date              IS NULL
    AND apd.invoice_id                  = ap.invoice_id
    AND apd.detail_tax_dist_id          = zx.rec_nrec_tax_dist_id
    AND zx.trx_id                       = ap.invoice_id
    AND zx.application_id               = 200
    AND zx.entity_code                  = ''AP_INVOICES''
    AND zx.event_class_code            IN (''STANDARD INVOICES'',''PREPAYMENT INVOICES'',''EXPENSE REPORTS'')
    AND zx.internal_organization_id     = ap.org_id
    GROUP BY ap.invoice_id,
      apd.detail_tax_dist_id,
      zx.rec_nrec_tax_amt
    HAVING zx.rec_nrec_tax_amt <> SUM(apd.amount)
    UNION
    SELECT
      /*+ leading(ap,zxs,zxl) parallel(ap) parallel(zxs) parallel(zxl)
      use_nl(zxs,zxl) index(zxl,ZX_LINES_N2) */
      DISTINCT ap.invoice_Id TRX_ID
    FROM zx_lines_summary zxs,
      ap_invoices_all ap,
      zx_lines zxl
    WHERE NVL(ap.historical_flag,''N'') = ''Y''
    AND ap.cancelled_date              IS NULL
    AND zxs.trx_id                      = ap.invoice_id
    AND zxs.application_id              = 200
    AND zxs.entity_code                 = ''AP_INVOICES''
    AND zxs.event_class_code           IN (''STANDARD INVOICES'',''PREPAYMENT INVOICES'',''EXPENSE REPORTS'')
    AND zxs.internal_organization_id    = ap.org_id
    AND zxl.application_id              = zxs.application_id
    AND zxl.entity_code                 = zxs.entity_code
    AND zxl.event_class_code            = zxs.event_class_code
    AND zxl.trx_id                      = zxs.trx_id
    AND zxl.summary_tax_line_id         = zxs.summary_tax_line_id
    GROUP BY ap.invoice_Id,
      zxl.summary_tax_line_id,
      zxs.tax_amt
    HAVING zxs.tax_amt <> SUM(zxl.tax_amt)', -- The text of the signature query
  'Checking if amount of the migrated TIPV tax distributions are not in sync between ZX_REC_NREC_DIST and AP_INVOICE_DISTRIBUTIONS_ALL<',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'If such invoices are validated after Upgrade in R12, they go on Dist Variance Hold.',     -- Problem description
  'Please follow the Section 23 of this Note - [1316316.1]- and apply the solution.',     -- Problem solution
  'The migrated TIPV tax distributions are in sync between ZX_REC_NREC_DIST and AP_INVOICE_DISTRIBUTIONS_ALL.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'N', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    90,
    'No RCA Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">The amount of the migrated TIPV tax distributions are not in sync
     between ZX_REC_NREC_DIST and AP_INVOICE_DISTRIBUTIONS_ALL</font></strong>',
    'Please follow the Section 23 Of (Doc ID <a href= target="_blank">1316316.1</a>) and  apply the solution.',
    'N',
    impact_area_tbl('If such invoices are validated after Upgrade in R12, they go on Dist Variance Hold.'),
    'SELECT /*+ leading(ap,zx,apd) parallel(ap) parallel(zx) parallel(apd)
               use_nl(zx,apd) index(apd AP_INVOICE_DISTRIBUTIONS_N29) */
/*               DISTINCT ap.invoice_Id  TRX_ID
          FROM zx_rec_nrec_dist zx,
               ap_invoices_all ap,
               ap_invoice_distributions_all apd
         WHERE NVL(ap.historical_flag,''N'') = ''Y''
           AND ap.cancelled_date IS NULL
           AND apd.invoice_id = ap.invoice_id
           AND apd.detail_tax_dist_id = zx.rec_nrec_tax_dist_id
           AND zx.trx_id = ap.invoice_id
           AND zx.application_id = 200
           AND zx.entity_code = ''AP_INVOICES''
           AND zx.event_class_code IN (''STANDARD INVOICES'',''PREPAYMENT INVOICES'',''EXPENSE REPORTS'')
           AND zx.internal_organization_id = ap.org_id
         GROUP BY ap.invoice_id, apd.detail_tax_dist_id, zx.rec_nrec_tax_amt
        HAVING zx.rec_nrec_tax_amt <> sum(apd.amount)
         UNION
        SELECT /*+ leading(ap,zxs,zxl) parallel(ap) parallel(zxs) parallel(zxl)
                use_nl(zxs,zxl) index(zxl,ZX_LINES_N2) */
/*               DISTINCT ap.invoice_Id  TRX_ID
          FROM zx_lines_summary zxs,
               ap_invoices_all ap,
               zx_lines zxl
         WHERE NVL(ap.historical_flag,''N'') = ''Y''
           AND ap.cancelled_date IS NULL
           AND zxs.trx_id = ap.invoice_id
           AND zxs.application_id = 200
           AND zxs.entity_code = ''AP_INVOICES''
           AND zxs.event_class_code IN (''STANDARD INVOICES'',''PREPAYMENT INVOICES'',''EXPENSE REPORTS'')
           AND zxs.internal_organization_id = ap.org_id
           AND zxl.application_id = zxs.application_id
           AND zxl.entity_code = zxs.entity_code
           AND zxl.event_class_code = zxs.event_class_code
           AND zxl.trx_id = zxs.trx_id
           AND zxl.summary_tax_line_id = zxs.summary_tax_line_id
         GROUP BY ap.invoice_Id, zxl.summary_tax_line_id, zxs.tax_amt
        HAVING zxs.tax_amt <> sum(zxl.tax_amt)'
);
*/


  add_signature(
  '21_Rep_Code_ID', -- Unique Signature identifier
  'SELECT *
    FROM ZX_REPORT_CODES_ASSOC ASSOC
    WHERE ASSOC.ENTITY_CODE              = ''ZX_PARTY_TAX_PROFILE''
    AND ASSOC.REPORTING_CODE_ID         IS NULL
    AND ASSOC.REPORTING_CODE_CHAR_VALUE IS NOT NULL
    AND ASSOC.REPORTING_TYPE_ID         IN
      (SELECT REPORTING_TYPE_ID
      FROM ZX_REPORTING_TYPES_B TYPES
      WHERE TYPES.REPORTING_TYPE_CODE = ''MEMBER STATE'')', -- The text of the signature query
  'Reporting Code Issue',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Associations created for Member State Set up at the party Tax profile level by user sometimes are not populated with Reporting Code unique identifier causing issues with Intra EU Audit Trail Report.',     -- Problem description
  'Please follow the Section 25 of this note - [1316316.1] - and apply the solution.',     -- Problem solution
  'Reporting Code ID populated OK.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
  /*
add_signature(g_gen_signatures,
    91,
    'No RCA Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Associations created for Member State Set up at the party Tax profile level by user sometimes are not 
populated with Reporting Code unique identifier causing issues with Intra EU Audit Trail Report</font></strong>',
    'Please follow the Section 25 Of (Doc ID <a href= target="_blank">1316316.1</a>) and  apply the solution.',
    'N',
    impact_area_tbl('Issues with Intra EU Audit Trail Report'),
    'Select * from ZX_REPORT_CODES_ASSOC ASSOC
WHERE ASSOC.ENTITY_CODE              = ''ZX_PARTY_TAX_PROFILE''
  AND ASSOC.REPORTING_CODE_ID         IS NULL
  AND ASSOC.REPORTING_CODE_CHAR_VALUE IS NOT NULL
  AND ASSOC.REPORTING_TYPE_ID         IN
      (
      SELECT REPORTING_TYPE_ID
        FROM ZX_REPORTING_TYPES_B TYPES
       WHERE TYPES.REPORTING_TYPE_CODE = ''MEMBER STATE''
      )'
);
*/

  add_signature(
  '22_ZX_PARTY_TAX_PROFILE', -- Unique Signature identifier
  'SELECT *
    FROM ZX_REPORT_CODES_ASSOC
    WHERE ENTITY_CODE      = ''ZX_PARTY_TAX_PROFILE''
    AND REPORTING_TYPE_ID IN
      (SELECT REPORTING_TYPE_ID
      FROM ZX_REPORTING_TYPES_B
      WHERE REPORTING_TYPE_CODE = ''MEMBER STATE''
      )
    AND REPORTING_CODE_CHAR_VALUE IS NULL
    AND REPORTING_CODE_ID         IS NOT NULL', -- The text of the signature query
  'Upgrade Associations for Member State Set up at the party Tax profile level',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Associations created for Member State Set up at the party Tax profile level during upgrade are not being visible in the Reporting Code tab under Party tax profile for the Legal Establishment causing issues with Intra EU Audit Trail Report.',     -- Problem description
  'Please follow the Section 26 of this note - [1316316.1] - and apply the solution.',     -- Problem solution
  'Associations created for Member State Set up at the party Tax profile level during upgrade are OK',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    92,
    '14528148',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Associations created for Member State Set up at the party Tax profile level during upgrade are 
not being visible in the Reporting Code tab under Party tax profile for the Legal Establishment causing issues with Intra EU Audit Trail Report.</font></strong>',
    'Please follow the Section 26 Of (Doc ID <a href= target="_blank">1316316.1</a>) and  apply the solution.',
    'N',
    impact_area_tbl('Issues with Intra EU Audit Trail Report'),
    'Select * from ZX_REPORT_CODES_ASSOC
WHERE ENTITY_CODE = ''ZX_PARTY_TAX_PROFILE''
AND REPORTING_TYPE_ID IN (SELECT REPORTING_TYPE_ID
                            FROM ZX_REPORTING_TYPES_B
                           WHERE REPORTING_TYPE_CODE = ''MEMBER STATE'')
AND REPORTING_CODE_CHAR_VALUE IS NULL
AND REPORTING_CODE_ID IS NOT NULL'
);
*/

  add_signature(
  '23_ALLOW_RATE_OVERRIDE_FLAG', -- Unique Signature identifier
  'SELECT tax_status_code,
      tax_status_id,
      tax_regime_code,
      tax
    FROM zx_status_b
    WHERE record_type_code                   =''MIGRATED''
    AND NVL(ALLOW_RATE_OVERRIDE_FLAG,''N'') <> ''Y''
    ORDER BY tax_status_id,
      tax_regime_code,
      tax', -- The text of the signature query
  'Checking if Tax Rate can be entered manually in Tax Details window.',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'User is unable to manually enter the Tax Rate in Tax Details Window of Invoice Workbench.',     -- Problem description
  'Please follow the Section 27 of this note - [1316316.1] - and apply the solution.',     -- Problem solution
  'Tax Rate OK',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
/*
add_signature(g_gen_signatures,
    93,
    'No RCA Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">User is unable to manually enter the Tax Rate in Tax Details Window of Invoice Workbench.</font></strong>',
    'Please follow the Section 27 Of (Doc ID <a href= target="_blank">1316316.1</a>) and  apply the solution.',
    'N',
    impact_area_tbl('User is unable to manually enter the Tax Rate in Tax Details Window of Invoice Workbench'),
    'select tax_status_code,tax_status_id,tax_regime_code,tax from zx_status_b
where record_type_code=''MIGRATED''
And NVL(ALLOW_RATE_OVERRIDE_FLAG,''N'') <> ''Y''
order by tax_status_id,tax_regime_code,tax'
);
*/


  add_signature(
  '24_TAX_CLASS', -- Unique Signature identifier
  'select org_id,application_id,record_type_code,tax_method_code,object_version_number,def_option_hier_1_code,def_option_hier_2_code,def_option_hier_3_code,
def_option_hier_4_code,def_option_hier_5_code,def_option_hier_6_code,def_option_hier_7_code
from zx_product_options_all
where  tax_method_code = ''EBTAX''
AND application_id in (200, 201,222)', -- The text of the signature query
  'Input Tax Classification Codes Issue',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'User can not choose input tax classification codes in Supplier Site Tax Classifications LOV after updating Application Tax Options in R12.',     -- Problem description
  'Please follow the Section 28 of this note -  [1316316.1] - and  apply the solution.',     -- Problem solution
  'Input Tax Classification Codes can be selected in Supplier Site Tax Classifications LOV',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  


  add_signature(
  '25_Jurisd_dates', -- Unique Signature identifier
  'select RATES.TAX_RATE_CODE, RATES.CONTENT_OWNER_ID, RATES.ACTIVE_FLAG,
to_char(RATES.EFFECTIVE_FROM, ''dd-mm-yyyy'') RATE_EFF_FROM, RATES.TAX_JURISDICTION_CODE, RATES.TAX_CLASS,
RATES.RECOVERY_TYPE_CODE, to_char(jur.effective_from, ''dd-mm-yyyy'') JUR_EFF_FROM
from zx_jurisdictions_b jur, zx_rates_b_tmp rates
where jur.record_type_code = ''MIGRATED''
and rates.record_type_code = ''MIGRATED''
and rates.tax_jurisdiction_code = jur.tax_jurisdiction_code
and rates.tax_regime_code = jur.tax_regime_code
and rates.tax = jur.tax
and jur.effective_from > rates.effective_from
and rates.effective_from < TO_DATE(''01-01-1952'',''DD-MM-YYYY'')
and rates.content_owner_id = -99
order by rates.tax_regime_code, RATES.CONTENT_OWNER_ID, RATES.ACTIVE_FLAG,
RATES.EFFECTIVE_FROM, RATES.TAX_JURISDICTION_CODE, RATES.TAX_CLASS,
RATES.RECOVERY_TYPE_CODE', -- The text of the signature query
  'Tax Jurisdiction Dates Issue',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Effective Dates of Jurisdictions are not in sync with Rates after Setup Migration.',     -- Problem description
  'Please follow the Section 29 of this note - [1316316.1] - and  apply the solution.',     -- Problem solution
  'Effective Dates of Jurisdictions are in sync with Rates after Setup Migration.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
/*  
add_signature(g_gen_signatures,
    95,
    'No RCA Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Effective Dates of Jurisdictions are not in sync with Rates after Setup Migration.</font></strong>',
    'Please follow the Section 29 Of (Doc ID <a href= target="_blank">1316316.1</a>) and  apply the solution.',
    'N',
    impact_area_tbl('User is unable to calculate tax because of mismatch in Efeective Start Date between Jurisdiction and Regime to Rate'),
    'SELECT tax_regime_code, tax, tax_status_code,content_owner_id, MIN(effective_from) effective_from
FROM zx_rates_b
WHERE record_type_code = ''MIGRATED''
AND tax_jurisdiction_code IS NOT NULL
AND content_owner_id = -99
AND effective_from < TO_DATE(''01-01-1952'',''DD-MM-YYYY'')
GROUP BY tax_regime_code,tax,tax_status_code,content_owner_id'
);
*/


  add_signature(
  '26_AUTO_TAX_CALC_FLAG_NO', -- Unique Signature identifier
  'SELECT APS.VENDOR_NAME,
      APS.VENDOR_ID,
      APSS.VENDOR_SITE_CODE,
      APSS.VENDOR_SITE_ID,
      APSS.AUTO_TAX_CALC_FLAG
    FROM AP_SUPPLIER_SITES_ALL APSS,
      AP_SUPPLIERS APS
    WHERE APS.VENDOR_ID          = APSS.VENDOR_ID
    AND APSS.AUTO_TAX_CALC_FLAG  =''N''
    AND APSS.AUTO_TAX_CALC_FLAG IS NOT NULL
    AND APS.EMPLOYEE_ID         IS NULL', -- The text of the signature query
  'Non Employee Supplier With Calculate tax set as  NO at Site Level',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax not calculated for the following Non Employee suppliers because AUTO_TAX_CALC_FLAG is NO at supplier site level',     -- Problem description
  'Please follow the Section 30 of this note - [1316316.1] - and apply the solution to correct the issue.',     -- Problem solution
  'Tax can be automatically calculated for Non Employee type suppliers',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'N');
  
/*  
add_signature(g_gen_signatures,
    96,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Tax not calculating for the following supplier with Non Employee supplier type because AUTO_TAX_CALC_FLAG is NO at supplier site level</font></strong>',
    'Please follow the Section 30 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the solution to correct the issue.</BR>',
    'N',
    impact_area_tbl('For Non-Employee type supplier automatic tax calculation can not be done'),
    'SELECT APS.VENDOR_NAME,
       APS.VENDOR_ID,
       APSS.VENDOR_SITE_CODE, 
       APSS.VENDOR_SITE_ID,
       APSS.AUTO_TAX_CALC_FLAG
  FROM AP_SUPPLIER_SITES_ALL APSS,
       AP_SUPPLIERS APS
 WHERE APS.VENDOR_ID = APSS.VENDOR_ID
   AND APSS.AUTO_TAX_CALC_FLAG=''N''
   AND APSS.AUTO_TAX_CALC_FLAG IS NOT NULL
   AND APS.EMPLOYEE_ID IS NULL'
  );
*/


  add_signature(
  '27_DEFAULT_FLG_EFF_TO', -- Unique Signature identifier
  'SELECT tax_regime_code,
      tax
    FROM zx_rates_b
    WHERE (effective_to          IS NOT NULL
    AND effective_to              = TRUNC(effective_to)
    AND effective_to             <> effective_from )
    OR (default_flg_effective_to IS NOT NULL
    AND default_flg_effective_to  = TRUNC(default_flg_effective_to)
    AND default_flg_effective_to <> default_flg_effective_from)
    AND ( (record_type_code = ''MIGRATED'' and object_version_number <> 1) OR record_type_code != ''MIGRATED'' )
    UNION
    SELECT tax_regime_code,
      tax
    FROM zx_rules_b
    WHERE ( effective_to IS NOT NULL
    AND effective_to      = TRUNC(effective_to)
    AND effective_to     <> effective_from )
    AND ( (record_type_code = ''MIGRATED'' and object_version_number <> 1) OR record_type_code != ''MIGRATED'' )
    UNION
    SELECT tax_regime_code,
      tax
    FROM zx_status_b
    WHERE ( effective_to IS NOT NULL
    AND effective_to      = TRUNC(effective_to)
    AND effective_to     <> effective_from )
    AND ( (record_type_code = ''MIGRATED'' and object_version_number <> 1) OR record_type_code != ''MIGRATED'' )
    UNION
    SELECT tax_regime_code,
      tax
    FROM zx_jurisdictions_b
    WHERE ( effective_to IS NOT NULL
    AND effective_to      = TRUNC(effective_to)
    AND effective_to     <> effective_from
    AND ( (record_type_code = ''MIGRATED'' and object_version_number <> 1) OR record_type_code != ''MIGRATED'' ))', -- The text of the signature query
  'Check for DEFAULT_FLG_EFF_TO AND EFFECTIVE_TO VALUES IN ZX Setup TABLE HAVING INCORRECT VALUES',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax calculation error: The system cannot determine the default tax rate for tax and tax status. Either specify a default tax rate code for this tax status and
  date or to define appropriate rate determination rules',     -- Problem description
  'Please follow the Section 31 Of [1316316.1] and apply the solution to correct the issue.',     -- Problem solution
  'DEFAULT_FLG_EFF_TO AND EFFECTIVE_TO VALUES in ZX Setup table OK.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
  
/*add_signature(g_gen_signatures,
    97,
    '10006022',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">DEFAULT_FLG_EFF_TO AND EFFECTIVE_TO VALUES IN ZX Setup TABLE HAVING INCORRECT VALUES</font></strong>',
    'Please follow the Section 31 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the solution to correct the issue.</BR>',
    'N',
    impact_area_tbl('Tax calculation error: The system cannot determine the default tax rate for tax and tax status. Either specify a default tax rate code for this tax status and
  date or to define appropriate rate determination rules '),
    'select tax_regime_code,tax from zx_rates_b
WHERE (effective_to IS NOT NULL AND effective_to = TRUNC(effective_to) AND effective_to <> effective_from )
OR (default_flg_effective_to IS NOT NULL AND default_flg_effective_to = TRUNC(default_flg_effective_to) AND default_flg_effective_to <> default_flg_effective_from)
union
select tax_regime_code,tax from zx_rules_b
WHERE ( effective_to IS NOT NULL
       AND effective_to = TRUNC(effective_to)
       AND effective_to <> effective_from
      )
union
select tax_regime_code,tax from zx_status_b
WHERE (    effective_to IS NOT NULL
       AND effective_to = TRUNC(effective_to)
       AND effective_to <> effective_from
      )
union
select tax_regime_code,tax from zx_jurisdictions_b      
WHERE (    effective_to IS NOT NULL
       AND effective_to = TRUNC(effective_to)
       AND effective_to <> effective_from
      )'
  );
*/


  add_signature(
  '28_TAX_Calculation', -- Unique Signature identifier
  'select * from zx_id_tcc_mapping_all
    WHERE (    effective_to IS NOT NULL
           AND effective_to = TRUNC(effective_to)
           AND effective_to <> effective_from
          )', -- The text of the signature query
  'Checking DEFAULT_FLG_EFF_TO AND EFFECTIVE_TO VALUES IN ZX Setup TABLE HAVING INCORRECT VALUES',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax calculation error: The system cannot determine the default tax rate for tax and tax status. Either specify a default tax rate code for this tax status and date or to define appropriate rate determination rules ',     -- Problem description
  'Please follow the Section 31 of this note - [1316316.1] - and apply the solution to correct the issue.',     -- Problem solution
  'There is no issue of Effective To Date in zx_id_tcc_mapping_all.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
  
/*add_signature(g_gen_signatures,
    98,
    '10006022',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">DEFAULT_FLG_EFF_TO AND EFFECTIVE_TO VALUES IN ZX Setup TABLE HAVING INCORRECT VALUES</font></strong>',
    'Please follow the Section 31 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the solution to correct the issue.</BR>',
    'N',
    impact_area_tbl('Tax calculation error: The system cannot determine the default tax rate for tax and tax status. Either specify a default tax rate code for this tax status and
  date or to define appropriate rate determination rules '),
    'select * from zx_id_tcc_mapping_all
WHERE (    effective_to IS NOT NULL
       AND effective_to = TRUNC(effective_to)
       AND effective_to <> effective_from
      )'
  );
*/

  add_signature(
  '29_Seeded_Tax', -- Unique Signature identifier
  'SELECT tax_rate_code
    FROM zx_rates_b_tmp
    WHERE record_type_code = ''SEEDED''
    AND NOT EXISTS
      (SELECT 1 FROM zx_input_classifications_v ssifications_v WHERE lookup_code = tax_rate_code)', -- The text of the signature query
  'Checking for Missing Seeded Tax Classification Codes',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Missing seeded tax classification codes in UI',     -- Problem description
  'Please follow the Section 33 of this note - [1316316.1] - and apply the solution to correct the issue.',     -- Problem solution
  'No Missing seeded tax classification codes in UI',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
  
/*add_signature(g_gen_signatures,
    99,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Customer is missing seeded tax classification codes in UI</font></strong>',
    'Please follow the Section 33 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the solution to correct the issue.</BR>',
    'N',
    impact_area_tbl('Customer is missing seeded tax classification codes in UI'),
    'Select tax_rate_code from zx_rates_b_tmp where record_type_code = ''SEEDED''
   and not exists (select 1 from zx_input_classifications_v where lookup_code = tax_rate_code)'
  );
*/

  add_signature(
  '30_duplic_Tax_classif', -- Unique Signature identifier
  'SELECT tax_classification_code
    FROM zx_id_tcc_mapping_all
    WHERE tax_rate_code_id IN
      (SELECT source_id FROM zx_rates_b_tmp WHERE record_type_code = ''SEEDED'' )', -- The text of the signature query
  'Checking for Duplicate Tax Classification Codes',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'User is able to find some duplicate tax classification codes in UI',     -- Problem description
  'Please follow the Section 33 of this note - [1316316.1] - and apply the solution to correct the issue.',     -- Problem solution
  'No duplicate tax classification codes in UI.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
  
/*add_signature(g_gen_signatures,
    100,
    'No RCA Bug Available',
    '1316316.1',
    ' ',
    '<strong><font color = "ff0000">Customer is able to find some duplicate tax classification codes in UI</font></strong>',
    'Please follow the Section 33 Of (Doc ID <a href= target="_blank">1316316.1</a>) and apply the solution to correct the issue.</BR>',
    'N',
    impact_area_tbl('Customer is able to find some duplicate tax classification codes in UI'),
    'select tax_classification_code from zx_id_tcc_mapping_all where tax_rate_code_id in (select source_id from zx_rates_b_tmp where record_type_code = ''SEEDED'')'
  );
*/

add_signature(
  '31_duplic_Tax_classif', -- Unique Signature identifier
  'Select tcc_mapping_id,org_id,org_id,tax_class,tax_rate_code_id,tax_classification_code FROM zx_id_tcc_mapping_all tcc 
   WHERE EXISTS (SELECT 1 FROM zx_rates_b rate 
                  WHERE rate.tax_rate_id = tcc.tax_rate_code_id 
                    AND rate.rate_type_code = ''RECOVERY'')', -- The text of the signature query
  'Checking for Duplicate Tax Classification Codes in Invoice Workbench',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'User is able to find some duplicate tax classification codes in Invoice Workbench Invoice Line TCC LOV',     -- Problem description
  'Please follow the Section 8 of this note - [1316316.1] - and apply the solution to correct the issue.',     -- Problem solution
  'No duplicate tax classification codes in Invoice Lines TCC LOV.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

add_signature(
  '32_wrong_rounding_rule', -- Unique Signature identifier
  'SELECT /*+ parallel(zptp) */ zptp.party_id,zptp.rounding_rule_code,zptp.party_type_code,zptp.party_tax_profile_id
 FROM zx_party_tax_profile zptp
where zptp.rounding_rule_code in (''U'',''D'',''N'')
  and zptp.party_type_code in (''THIRD_PARTY_SITE'')
  and zptp.party_id in
      (select assi.party_site_id
         from ap_supplier_sites_all assi)', -- The text of the signature query
  'Checking for wrong rounding rule in Party Tax Profile which is causing Tax Calculation error',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'User is unable to calculate tax since wrong rounding rule in Party Tax Profile',     -- Problem description
  'Please follow the Section 35 of this note - [1316316.1] - and apply the solution to correct the issue.',     -- Problem solution
  'Rounding Rule Code having proper value in Party Tax Profile.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');



add_signature(
  '33_status_dates', -- Unique Signature identifier
  'SELECT tax_status_code,effective_from,tax,tax_regime_code
FROM ZX_STATUS_B_TMP ST
WHERE record_type_code = ''MIGRATED''
   AND EXISTS (SELECT 1 
                 FROM ZX_RATES_B RATE2
                WHERE RATE2.TAX_REGIME_CODE = ST.TAX_REGIME_CODE
                  AND RATE2.TAX = ST.TAX
                  AND RATE2.TAX_STATUS_CODE = ST.TAX_STATUS_CODE
                  AND RATE2.RECORD_TYPE_CODE = ST.RECORD_TYPE_CODE
                  AND RATE2.CONTENT_OWNER_ID = ST.CONTENT_OWNER_ID
                  AND RATE2.EFFECTIVE_FROM < ST.EFFECTIVE_FROM)', -- The text of the signature query
  'Tax status effective_from is later than that of the rates',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Tax status effective_from is later than that of the rates after Setup Migration.',     -- Problem description
  'Please follow the Section 45 of this note - [1316316.1] - and  apply the solution.',     -- Problem solution
  'Tax status effective_from is earlier than that of the rates after Setup Migration.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


------------------------------------------------------------------------------
-- POPULATE TAX REPORTING SIGNATURES--ARNAB MITRA
------------------------------------------------------------------------------
  add_signature(
  '32_No_Legal_Reporting_Status_AP', -- Unique Signature identifier
  'SELECT distinct ZL.trx_id,ZL.trx_number,ZL.trx_date,ZL.event_class_code,ZL.tax_regime_code,ZL.tax,ZL.tax_id
FROM
  (SELECT
    /*+ qb_name(appview) */
    zl.application_id,
    zl.trx_id,
    ZL.TRX_NUMBER,
    zl.trx_date,
    zl.entity_code,
    zl.event_class_code,
    zl.trx_line_id,
    zl.ledger_id,
    zl.internal_organization_id,
    zl.legal_entity_id,zl.tax_regime_code,zl.tax,zl.tax_id,
    zl.establishment_id,
    ZL.TAX_EVENT_TYPE_CODE,
    zl.HQ_ESTB_REG_NUMBER,
    zl.HQ_ESTB_PARTY_TAX_PROF_ID,
    ZL.legal_reporting_status
  FROM zx_lines zl
  WHERE  zl.application_id                        IN (200,222)
  AND zl.entity_code                             IN (''AP_INVOICES'',''TRANSACTIONS'')
  ) ZL ,(
            ##$$IVIEW$$##
          ) invs
WHERE ZL.application_id           = 200
AND ZL.trx_id=invs.invoice_id
AND ZL.entity_code              = ''AP_INVOICES''
AND ZL.event_class_code         IN (''STANDARD INVOICES'', ''EXPENSE REPORTS'', ''PREPAYMENT INVOICES'')
AND ZL.legal_reporting_status  IS NULL', -- The text of the signature query
  'Retrieve Payables Tax Legal Reporting Status having no values',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Legal Reporting Status code is attached with the Payables Tax',     -- Problem description
  'Go through the globalization Note- [1392535.1] and follow the action plan provided in the Section Issue A.2 to correct the setup',     -- Problem solution
  'Legal Reporting Status code is attached with the Payables Tax',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '32_No_Legal_Reporting_Status_AR', -- Unique Signature identifier
  'SELECT distinct ZL.trx_id,ZL.trx_number,ZL.trx_date,ZL.event_class_code,ZL.tax_regime_code,ZL.tax,ZL.tax_id
FROM
  (SELECT
    /*+ qb_name(appview) */
    zl.application_id,
    zl.trx_id,
    ZL.TRX_NUMBER,
    zl.trx_date,
    zl.entity_code,
    zl.event_class_code,
    zl.trx_line_id,
    zl.ledger_id,
    zl.internal_organization_id,
    zl.legal_entity_id,zl.tax_regime_code,zl.tax,zl.tax_id,
    zl.establishment_id,
    ZL.TAX_EVENT_TYPE_CODE,
    zl.HQ_ESTB_REG_NUMBER,
    zl.HQ_ESTB_PARTY_TAX_PROF_ID,
    ZL.legal_reporting_status
  FROM zx_lines zl
  WHERE  zl.application_id                        IN (200,222)
  AND zl.entity_code                             IN (''AP_INVOICES'',''TRANSACTIONS'')
  ) ZL ,(
            ##$$TRXVIEW$$##
          ) trxs
WHERE ZL.application_id           = 222
AND ZL.trx_id=trxs.customer_trx_id
AND ZL.entity_code              = ''TRANSACTIONS''
AND ZL.event_class_code         = ''INVOICE''
AND ZL.event_class_code         IN (''VALIDATE_FOR_TAX'', ''FREEZE_FOR_TAX'')
AND ZL.legal_reporting_status  IS NULL', -- The text of the signature query
  'Retrieve Receivables Tax Legal Reporting Status having no values',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Legal Reporting Status code is attached with the Receivables Tax',     -- Problem description
  'Go through the globalization Note- [1392535.1] and follow the action plan provided in the Section Issue A.2 to correct the setup',     -- Problem solution
  'Legal Reporting Status code is attached with the Receivables Tax',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '33_Null_Vat_Registration', -- Unique Signature identifier
  'SELECT hzp.party_id,
       hzp.party_name
FROM zx_party_tax_profile ptp,
  hz_parties hzp,
  (SELECT
    /*+ qb_name(appview) */
    reg.party_tax_profile_id,
    reg.registration_number
  FROM zx_registrations reg
 ) reg
WHERE ptp.party_id               = hzp.party_id
AND ptp.party_type_code          = ''THIRD_PARTY''
AND reg.party_tax_profile_id(+)  = ptp.party_tax_profile_id
AND ptp.rep_registration_number IS NULL
AND reg.registration_number     IS NULL', -- The text of the signature query
  'Retrieve Customers having no VAT Registration Number',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The VAT REGISTRATION NUMBER is Null for the mentioned Customers',     -- Problem description
  'Apply RCA Patch as mentioned in section 36 of Note- [1316316.1] ',     -- Problem solution
  'All customers are associated with VAT Registration Number',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');



add_signature(
  '33_Null_Vat_Registration_Site', -- Unique Signature identifier
  'SELECT hzs.party_site_id,
  hzl.CITY,
  hzl.COUNTY,
  hzl.STATE,
  hzl.PROVINCE,
  hzl.ADDRESS1,
  hzl.COUNTRY,
  hzl.POSTAL_CODE
FROM zx_party_tax_profile ptp,
  (SELECT
    /*+ qb_name(appview) */
    hzcs.party_site_id
  FROM hz_cust_acct_sites_all hzcs
  ) hzcs,
  HZ_PARTY_SITES hzs,
  HZ_LOCATIONS hzl,
  (SELECT
    /*+ qb_name(appview) */
    reg.party_tax_profile_id,
    reg.registration_number
  FROM zx_registrations reg
  ) reg
WHERE ptp.party_id               = hzcs.party_site_id
AND hzcs.party_site_id           = hzs.party_site_id
AND hzs.LOCATION_ID              = hzl.LOCATION_ID
AND ptp.party_type_code          = ''THIRD_PARTY_SITE''
AND reg.party_tax_profile_id(+)  = ptp.party_tax_profile_id
AND ptp.rep_registration_number IS NULL
AND reg.registration_number     IS NULL', -- The text of the signature query
  'Retrieve Customers Sites having no VAT Registration Number',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The VAT REGISTRATION NUMBER is Null for the mentioned Customer Sites',     -- Problem description
  'Apply RCA Patch as mentioned in section 36 of Note- [1316316.1] ',     -- Problem solution
  'All customers Sites are associated with VAT Registration Number',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '34_Null_Tax_Link_Id', -- Unique Signature identifier
  'SELECT DISTINCT ARCS.cash_receipt_id ,zx_det.customer_trx_id,
  ARCS.RECEIPT_NUMBER ,
  zx_det.trx_date 
FROM AR_DISTRIBUTIONS_ALL ARD,
  AR_DISTRIBUTIONS_ALL ARDTAX,
  RA_CUSTOMER_TRX_ALL ZX_DET,
  AR_CASH_RECEIPTS_ALL ARCS,
  (SELECT
    /*+ qb_name(appview) */
    app.receivable_application_id,
    app.applied_customer_trx_id,
    app.cash_receipt_id,
    APP.ORG_ID
  FROM AR_RECEIVABLE_APPLICATIONS_ALL APP
  WHERE app.status    = ''APP''
  AND APP.GL_POSTED_DATE IS NOT NULL
  ) APP,(
            ##$$TRXVIEW$$##
          ) trxs
WHERE zx_det.customer_trx_id      = app.applied_customer_trx_id
AND zx_det.customer_trx_id      = trxs.customer_trx_id
AND ARcs.cash_receipt_id          = app.cash_receipt_id
AND NVL(ARcs.confirmed_flag, ''Y'') = ''Y''
AND ((ard.source_type             = ''EDISC'' AND (ardtax.source_type_secondary = ''EDISC'' OR ardtax.source_type = ''EDISC_NON_REC_TAX''))
OR (ard.source_type               = ''REC'' AND ardtax.source_type_secondary IN (''PAYMENT'', ''ASSIGNMENT'', ''RECONCILE'', ''ASSIGNMENT_RECONCILE''))
OR (ard.source_type               = ''UNEDISC'' AND (ardtax.source_type_secondary = ''UNEDISC'' OR ardtax.source_type = ''UNEDISC_NON_REC_TAX'')))
AND ard.source_id                 = app.receivable_application_id
AND ard.source_table              = ''RA''
AND ard.source_type              IN (''EDISC'', ''UNEDISC'', ''REC'')
AND ardtax.source_id              = app.receivable_application_id
AND ardtax.source_table           = ''RA''
AND ardtax.source_type           IN (''TAX'', ''DEFERRED_TAX'', ''EDISC_NON_REC_TAX'', ''UNEDISC_NON_REC_TAX'')
AND (ardtax.tax_link_id          IS NULL OR ard.tax_link_id IS NULL)', -- The text of the signature query
  'Retrieve Tax Link ID populated with NULL values on Receipt Application Distributions',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The tax information(Tax Link ID) populated with NULL values on Receipt Application Distributions',     -- Problem description
  'Follow section 37 of Note- [1316316.1]  and Log SR to to get data fix from AR Development',     -- Problem solution
  'Receipt Application Distributions having Tax Link ID populated',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '35_Null_Tax_Link_Id_Adjustment', -- Unique Signature identifier
  'SELECT DISTINCT ADJ.adjustment_id,ADJ.CUSTOMER_TRX_ID,
  ADJ.ADJUSTMENT_NUMBER,
  ZX_DET.trx_date
FROM AR_DISTRIBUTIONS_ALL ARD,
  AR_DISTRIBUTIONS_ALL ARDTAX,
  ZX_RATES_VL ZX_RATE,
  RA_CUSTOMER_TRX_ALL ZX_DET,
  (SELECT
    /*+ qb_name(appview) */
    ADJ.ADJUSTMENT_NUMBER,
    ADJ.STATUS,
    ADJ.CUSTOMER_TRX_ID,
    ADJ.ADJUSTMENT_ID,
    ADJ.DOC_SEQUENCE_ID,
    ADJ.TYPE
  FROM AR_ADJUSTMENTS_ALL ADJ
  WHERE ADJ.STATUS = ''A''
  AND ADJ.TYPE    IN (''INVOICE'',''CHARGES'',''LINE'',''TAX'')
  ) ADJ,(
            ##$$TRXVIEW$$##
          ) trxs
WHERE ZX_DET.CUSTOMER_TRX_ID = ADJ.CUSTOMER_TRX_ID
AND ZX_DET.CUSTOMER_TRX_ID = trxs.CUSTOMER_TRX_ID
AND ZX_DET.COMPLETE_FLAG     = ''Y''
AND ARDTAX.SOURCE_ID         = ADJ.ADJUSTMENT_ID
AND ARDTAX.SOURCE_TABLE      = ''ADJ''
AND ARDTAX.SOURCE_TYPE      IN (''TAX'',''DEFERRED_TAX'', ''ADJ_NON_REC_TAX'',''FINCHRG_NON_REC_TAX'')
  --AND ARDTAX.SOURCE_TYPE  = ''TAX''
AND zx_rate.tax_rate_id             = ardtax.tax_code_id
AND ARD.SOURCE_ID(+)                = ARDTAX.SOURCE_ID
AND NVL(ARD.SOURCE_TABLE,''ADJ'')     = ''ADJ''
AND NVL(ARD.SOURCE_TYPE,''ADJ'')     IN (''ADJ'',''REC'',''FINCHRG'')
AND NVL(ARD.REF_ACCOUNT_CLASS,''$'') <> ''TAX''
AND ((ARDTAX.TAX_LINK_ID           IS NOT NULL
AND ARD.TAX_LINK_ID                IS NULL)
OR (ARDTAX.TAX_LINK_ID             IS NULL
AND ARD.TAX_LINK_ID                IS NOT NULL))
AND NOT EXISTS
  (SELECT 1
  FROM AR_DISTRIBUTIONS_ALL ARDSUB
  WHERE ardsub.source_type                 = ''ADJ''
  AND NVL(ardsub.REF_ACCOUNT_CLASS,''REV'') <> ''TAX''
  AND ardtax.REF_ACCOUNT_CLASS             = ardsub.REF_ACCOUNT_CLASS
  AND ardsub.tax_link_id                   = ardtax.tax_link_id
  AND ardsub.source_id                     = ardtax.source_id
  AND ROWNUM                               =1
  )', -- The text of the signature query
  'Retrieve Tax Link ID populated with NULL values on Adjustment Distributions',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The tax information(Tax Link ID) populated with NULL values on Adjustment Distributions',     -- Problem description
  'Follow section 38 of Note- [1316316.1] and Log SR to to get data fix from AR Development',     -- Problem solution
  'Adjustment Distributions having Tax Link ID populated',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '36_Null_Acct_Tax_Dists_AP', -- Unique Signature identifier
  'SELECT DISTINCT zxd.trx_id ,
  xla_ent.transaction_number,
  xla_event.transaction_date,
  gl.ledger_id,
  gl.name 
FROM
  (SELECT
    /*+ qb_name(appview) */
    DISTINCT zxd.application_id,
    zxd.trx_id
  FROM zx_rec_nrec_dist zxd
  WHERE zxd.application_id          = 200
  AND zxd.ENTITY_CODE               = ''AP_INVOICES''
  AND ZXD.EVENT_CLASS_CODE         IN (''STANDARD INVOICES'', ''EXPENSE REPORTS'', ''PREPAYMENT INVOICES'')
  AND zxd.posting_flag              = ''A''
  ) zxd,(
            ##$$IVIEW$$##
          ) invs,
  xla.XLA_TRANSACTION_ENTITIES xla_ent,
  XLA_EVENTS xla_event,
  XLA_AE_HEADERS xla_head,
  XLA_AE_LINES xla_line,
  XLA_DISTRIBUTION_LINKS xla_dist,
  gl_ledgers gl
WHERE xla_ent.application_id            = zxd.application_id
AND xla_ent.entity_code                 = ''AP_INVOICES''
AND NVL(xla_ent.source_id_int_1,-99)    = zxd.trx_id
AND zxd.trx_id                          = invs.invoice_id
AND xla_event.entity_id                 = xla_ent.entity_id
AND xla_event.application_id            = xla_ent.application_id
AND xla_head.event_id                   = xla_event.event_id
AND xla_head.ledger_id                  = gl.ledger_id
AND xla_head.application_id             = xla_ent.application_id
AND xla_head.balance_type_code          = ''A''
AND xla_line.ae_header_id               = xla_head.ae_header_id
AND xla_line.application_id             = xla_head.application_id
AND XLA_LINE.ACCOUNTING_CLASS_CODE     IN (''RTAX'',''NRTAX'',''SELF_ASSESSED_RTAX'',''SELF_ASSESSED_TAX'')
AND xla_dist.application_id             = xla_line.application_id
AND xla_dist.ae_header_id               = xla_line.ae_header_id
AND xla_dist.ae_line_num                = xla_line.ae_line_num
AND (( xla_dist.tax_line_ref_id        IS NULL)
OR ( XLA_DIST.TAX_REC_NREC_DIST_REF_ID IS NULL))', -- The text of the signature query
  'Retrieve the tax information (Tax Reference IDS) populated with NULL value on Accounting Tax Distributions for Payable Invoices',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The tax information(Tax Reference IDS) having Null values on Accounting Tax Distributions for Payable Invoices',     -- Problem description
  'Follow section 39 of Note- [1316316.1] and Log SR to to get data fix from AP Development',     -- Problem solution
  'The tax information(Tax Reference IDS) populated with values on Accounting Tax Distributions for Payable Invoices',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '37_No_XDL_Tax_Dists_AP', -- Unique Signature identifier
  'SELECT DISTINCT zxd.trx_id,
  xla_ent.transaction_number,
  xla_event.transaction_date,
  gl.ledger_id,
  gl.name
FROM
  (SELECT
    /*+ qb_name(appview) */
    DISTINCT zxd.application_id,
    zxd.trx_id
  FROM zx_rec_nrec_dist zxd
  WHERE zxd.application_id          = 200
  AND zxd.ENTITY_CODE               = ''AP_INVOICES''
  AND ZXD.EVENT_CLASS_CODE         IN (''STANDARD INVOICES'', ''EXPENSE REPORTS'', ''PREPAYMENT INVOICES'')
  AND zxd.posting_flag              = ''A''
  ) zxd,(
            ##$$IVIEW$$##
          ) invs,
  xla.XLA_TRANSACTION_ENTITIES xla_ent,
  XLA_EVENTS xla_event,
  XLA_AE_HEADERS xla_head,
  XLA_AE_LINES xla_line,
  gl_ledgers gl
WHERE xla_ent.application_id         = zxd.application_id
AND xla_ent.entity_code              = ''AP_INVOICES''
AND NVL(xla_ent.source_id_int_1,-99) = zxd.trx_id
AND zxd.trx_id                       = invs.invoice_id
AND xla_event.entity_id              = xla_ent.entity_id
AND xla_event.application_id         = xla_ent.application_id
AND xla_head.event_id                = xla_event.event_id
AND xla_head.ledger_id               = gl.ledger_id
AND xla_head.application_id          = xla_ent.application_id
AND xla_head.balance_type_code       = ''A''
AND xla_line.ae_header_id            = xla_head.ae_header_id
AND xla_line.application_id          = xla_head.application_id
AND XLA_LINE.ACCOUNTING_CLASS_CODE  IN (''RTAX'',''NRTAX'',''SELF_ASSESSED_RTAX'',''SELF_ASSESSED_TAX'')
AND NOT EXISTS
  (SELECT 1
  FROM xla_distribution_links xla_dist
  WHERE xla_dist.application_id = xla_line.application_id
  AND xla_dist.ae_header_id     = xla_line.ae_header_id
  AND xla_dist.ae_line_num      = xla_line.ae_line_num
  AND xla_dist.event_id         = xla_head.event_id
  )', -- The text of the signature query
  'Retrieve Accounting Tax Distributions not created for Payable Invoices',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The Accounting Tax Distributions not created for Payable Invoices',     -- Problem description
  'Follow section 40 of Note- [1316316.1] and Log SR to to get data fix from AP Development',     -- Problem solution
  'Accounting Tax Distributions created for Payable Invoices',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '36_Null_Acct_Tax_Dists_AR', -- Unique Signature identifier
  'SELECT DISTINCT ar_dist.customer_trx_id,
  xla_ent.transaction_number,
  xla_event.transaction_date,
  gl.ledger_id,
  gl.name
FROM
  (SELECT
    /*+ qb_name(appview) */
    ar_dist.customer_trx_id,
    ar_dist.cust_trx_line_gl_dist_id
  FROM ra_cust_trx_line_gl_dist_all ar_dist
  WHERE ar_dist.account_class = ''TAX''
  AND ar_dist.gl_posted_date IS NOT NULL
  ) ar_dist,(
            ##$$TRXVIEW$$##
          ) trxs,
  xla.xla_transaction_entities xla_ent,
  xla_events xla_event,
  xla_ae_headers xla_head,
  xla_ae_lines xla_line,
  xla_distribution_links xla_dist,
  gl_ledgers gl
WHERE xla_ent.application_id              = 222
AND ar_dist.customer_trx_id               = trxs.customer_trx_id
AND xla_ent.entity_code                   = ''TRANSACTIONS''
AND xla_ent.source_id_int_1               = ar_dist.customer_trx_id
AND xla_event.application_id              = xla_ent.application_id
AND xla_event.entity_id                   = xla_ent.entity_id
AND xla_head.application_id               = xla_event.application_id
AND xla_head.ledger_id                    = gl.ledger_id
AND xla_head.event_id                     = xla_event.event_id
AND xla_head.balance_type_code            = ''A''
AND xla_line.application_id               = xla_head.application_id
AND xla_line.ae_header_id                 = xla_head.ae_header_id
AND XLA_LINE.ACCOUNTING_CLASS_CODE       IN (''DEFERRED_TAX'',''TAX'')
AND xla_dist.application_id               = xla_line.application_id
AND xla_dist.ae_header_id                 = xla_line.ae_header_id
AND xla_dist.ae_line_num                  = xla_line.ae_line_num
AND xla_dist.source_distribution_id_num_1 = ar_dist.cust_trx_line_gl_dist_id
AND XLA_DIST.TAX_LINE_REF_ID             IS NULL', -- The text of the signature query
  'Retrieve the tax information (Tax Reference IDS) populated with NULL value on Accounting Tax Distributions for Receivables Invoices',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The tax information(Tax Reference IDS) having Null values on Accounting Tax Distributions for Receivables Invoices',     -- Problem description
  'Follow section 41 of Note- [1316316.1] and Log SR to to get data fix from AR Development',     -- Problem solution
  'The tax information(Tax Reference IDS) populated with values on Accounting Tax Distributions for Receivables Invoices',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '37_No_XDL_Tax_Dists_AR', -- Unique Signature identifier
  'SELECT DISTINCT ar_dist.customer_trx_id,
  xla_ent.transaction_number,
  xla_event.transaction_date,
  gl.ledger_id,
  gl.name
FROM
  (SELECT
    /*+ qb_name(appview) */
    ar_dist.customer_trx_id,
    ar_dist.cust_trx_line_gl_dist_id
  FROM ra_cust_trx_line_gl_dist_all ar_dist
  WHERE ar_dist.account_class = ''TAX''
  AND ar_dist.gl_posted_date IS NOT NULL
  ) ar_dist,(
            ##$$TRXVIEW$$##
          ) trxs,
  xla.xla_transaction_entities xla_ent,
  xla_events xla_event,
  xla_ae_headers xla_head,
  xla_ae_lines xla_line,
  gl_ledgers gl
WHERE xla_ent.application_id        = 222
AND xla_ent.entity_code             = ''TRANSACTIONS''
AND xla_ent.source_id_int_1         = ar_dist.customer_trx_id
AND ar_dist.customer_trx_id         = trxs.customer_trx_id
AND xla_event.application_id        = xla_ent.application_id
AND xla_event.entity_id             = xla_ent.entity_id
AND xla_head.application_id         = xla_event.application_id
AND xla_head.ledger_id              = gl.ledger_id
AND xla_head.event_id               = xla_event.event_id
AND xla_head.balance_type_code      = ''A''
AND xla_line.application_id         = xla_head.application_id
AND xla_line.ae_header_id           = xla_head.ae_header_id
AND XLA_LINE.ACCOUNTING_CLASS_CODE IN (''DEFERRED_TAX'',''TAX'')
AND NOT EXISTS
  (SELECT 1
  FROM xla_distribution_links xla_dist
  WHERE xla_dist.ae_header_id = xla_line.ae_header_id
  AND xla_dist.ae_line_num    = xla_line.ae_line_num
  AND xla_dist.application_id = xla_line.application_id
  AND xla_dist.event_id       = xla_head.event_id
  )', -- The text of the signature query
  'Retrieve Accounting Tax Distributions not created for Receivables Invoices',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The Accounting Tax Distributions not created for Receivables Invoices',     -- Problem description
  'Follow section 42 of Note- [1316316.1] and Log SR to to get data fix from AR Development',     -- Problem solution
  'Accounting Tax Distributions created for Receivables Invoices',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '38_Tax_Status_Incomplete_AR', -- Unique Signature identifier
  'SELECT ZLDF.TRX_ID,
  ZLDF.TRX_NUMBER,
  zldf.trx_date,
  ZLDF.EVENT_CLASS_CODE,
  ZLDF.LEDGER_ID,
  GL.NAME
FROM
  (SELECT
    /*+ qb_name(appview) */
    zldf.trx_id,
    ZLDF.TRX_NUMBER,
    zldf.trx_date,
    zldf.entity_code,
    zldf.event_class_code,
    zldf.ledger_id,
    zldf.internal_organization_id,
    ZLDF.TAX_EVENT_TYPE_CODE,
    zldf.bill_third_pty_acct_id,
    zldf.bill_third_pty_acct_site_id,
    zldf.record_type_code
  FROM zx_lines_det_factors zldf
  WHERE ZLDF.APPLICATION_ID         = 222
  AND ZLDF.ENTITY_CODE              = ''TRANSACTIONS''
  AND ZLDF.EVENT_CLASS_CODE        IN ( ''INVOICE'',''DEBIT_MEMO'',''CREDIT_MEMO'')
  ) ZLDF,(
            ##$$TRXVIEW$$##
          ) trxs,
  GL_LEDGERS GL
WHERE ZLDF.TAX_EVENT_TYPE_CODE NOT IN (''VALIDATE_FOR_TAX'',''FREEZE_FOR_TAX'')
AND ZLDF.LEDGER_ID                = GL.LEDGER_ID
AND ZLDF.TRX_ID         = trxs.customer_trx_id
AND EXISTS
  (SELECT 1
  FROM RA_CUSTOMER_TRX_ALL TRX
  WHERE TRX.COMPLETE_FLAG = ''Y''
  AND TRX.CUSTOMER_TRX_ID = ZLDF.TRX_ID
  AND trx.org_id          = zldf.internal_organization_id
  )', -- The text of the signature query
  'Retrieve Receivable Invoices with COMPLETED status are appearing with INCOMPLETE status on Tax tables',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The Receivable Invoices with COMPLETED status are appearing with INCOMPLETE status on Tax tables',     -- Problem description
  'Follow section 43 of Note- [1316316.1] and Apply GDF Patch',     -- Problem solution
  'The Receivable Invoices with COMPLETED status having Complete status on Tax tables',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '39_Third_Party_Acct_Mismatch_AR', -- Unique Signature identifier
  'SELECT DISTINCT ZLDF.TRX_ID,
  ZLDF.TRX_NUMBER,
  zldf.trx_date,
  ZLDF.EVENT_CLASS_CODE,
  ZLDF.LEDGER_ID,
  GL.NAME
FROM RA_CUSTOMER_TRX_ALL trx,
  (SELECT
    /*+ qb_name(appview) */
    zldf.trx_id,
    ZLDF.TRX_NUMBER,
    zldf.trx_date,
    zldf.entity_code,
    zldf.event_class_code,
    zldf.ledger_id,
    zldf.internal_organization_id,
    ZLDF.TAX_EVENT_TYPE_CODE,
    zldf.bill_third_pty_acct_id,
    zldf.bill_third_pty_acct_site_id,
    zldf.record_type_code
  FROM zx_lines_det_factors zldf
  WHERE ZLDF.APPLICATION_ID          = 222
  AND ZLDF.ENTITY_CODE               = ''TRANSACTIONS''
  AND ZLDF.EVENT_CLASS_CODE         IN ( ''INVOICE'',''DEBIT_MEMO'',''CREDIT_MEMO'')
  ) zldf,(
            ##$$TRXVIEW$$##
          ) trxs,
  GL_LEDGERS GL
WHERE ZLDF.RECORD_TYPE_CODE           = ''MIGRATED''
AND ZLDF.LEDGER_ID                    = GL.LEDGER_ID
AND trx.customer_trx_id               = zldf.trx_id
AND zldf.trx_id                       = trxs.customer_trx_id
AND TRX.ORG_ID                        = ZLDF.INTERNAL_ORGANIZATION_ID
AND (trx.bill_to_customer_id         <> zldf.bill_third_pty_acct_id
OR ZLDF.BILL_THIRD_PTY_ACCT_ID       IS NULL
OR (zldf.bill_third_pty_acct_site_id IS NULL
AND TRX.BILL_TO_SITE_USE_ID          IS NOT NULL))', -- The text of the signature query
  'Retrieve Third Party Account and Account Site information on Tax Data not matching with Receivable Invoices',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The Third Party Account and Account Site information on Tax Data not matching with Receivable Invoices',     -- Problem description
  'Follow section 44 of Note- [1316316.1] and Apply the GDF Patch.',     -- Problem solution
  'The Third Party Account and Account Site information on Tax Data is matching with Receivable Invoices',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '40_Incorrect_Offset_Tax_AP', -- Unique Signature identifier
  'SELECT DISTINCT INV.APPLICATION_ID,INV.LEGAL_ENTITY_ID,INV.SET_OF_BOOKS_ID,INV.INVOICE_DATE,INV.INVOICE_ID
                        FROM AP_INVOICES_ALL INV,AP_SUPPLIER_SITES_ALL APSUP,(
            ##$$IVIEW$$##
          ) invs        WHERE INV.VENDOR_SITE_ID = APSUP.VENDOR_SITE_ID
                        AND NVL(APSUP.OFFSET_TAX_FLAG,''Y'') = ''N''
                        AND INV.HISTORICAL_FLAG            = ''Y''
                        AND INV.INVOICE_ID                     = invs.invoice_id
                        AND EXISTS
                          (SELECT 1
                          FROM ZX_LINES ZX
                          WHERE ZX.APPLICATION_ID     = INV.APPLICATION_ID
                          AND ZX.LEGAL_ENTITY_ID      = INV.LEGAL_ENTITY_ID
                          AND ZX.LEDGER_ID            = INV.SET_OF_BOOKS_ID
                          AND ZX.TRX_DATE             = INV.INVOICE_DATE
                          AND ZX.ENTITY_CODE           = ''AP_INVOICES''
                          AND ZX.EVENT_CLASS_CODE     IN (''STANDARD INVOICES'', ''PREPAYMENT INVOICES'', ''EXPENSE REPORTS'')
                          AND ZX.TRX_ID               = INV.INVOICE_ID
                          AND ZX.RECORD_TYPE_CODE      = ''MIGRATED''
                          AND NVL(ZX.OFFSET_FLAG,''Y'')  = ''N''
                          AND ZX.OFFSET_TAX_RATE_CODE IS NOT NULL
                          )', -- The text of the signature query
  'Retrieve Offset Tax Rate Code incorrectly populated on migrated Tax Lines for the Payable Invoices',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The Offset Tax Rate Code incorrectly populated on migrated Tax Lines for the Payable Invoices',     -- Problem description
  'Follow section 32 of Note- [1316316.1] and Apply GDF Patch',     -- Problem solution
  'The Offset Tax Rate Code correctly populated on migrated Tax Lines for the Payable Invoices',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '41_Incorrect_HQ_Reg_AP', -- Unique Signature identifier
  'SELECT DISTINCT zl.trx_id,
  zl.trx_number,
  zl.trx_date,
  zl.legal_entity_id,
  zl.application_id
FROM
  (SELECT
    /*+ qb_name(appview) */
    zl.application_id,
    zl.trx_id,
    ZL.TRX_NUMBER,
    zl.trx_date,
    zl.entity_code,
    zl.event_class_code,
    zl.trx_line_id,
    zl.ledger_id,
    zl.internal_organization_id,
    zl.legal_entity_id,
    zl.establishment_id,
    ZL.TAX_EVENT_TYPE_CODE,
    zl.HQ_ESTB_REG_NUMBER,
    zl.HQ_ESTB_PARTY_TAX_PROF_ID,
    ZL.legal_reporting_status
  FROM zx_lines zl
  WHERE  zl.application_id                        IN (200)
  AND zl.entity_code                             IN (''AP_INVOICES'')
  ) ZL,(
            ##$$IVIEW$$##
          ) invs
WHERE ZL.trx_id=invs.invoice_id
AND EXISTS
  (SELECT 1
  FROM ZX_REGISTRATIONS REG,
    XLE_ETB_PROFILES ETB,
    ZX_PARTY_TAX_PROFILE PTP
  WHERE PTP.PARTY_ID                        = ETB.PARTY_ID
  AND PTP.PARTY_TYPE_CODE                   = ''LEGAL_ESTABLISHMENT''
  AND ETB.MAIN_ESTABLISHMENT_FLAG           = ''Y''
  AND ETB.LEGAL_ENTITY_ID                   = zl.LEGAL_ENTITY_ID
  AND (NVL(zl.HQ_ESTB_REG_NUMBER,''XX'')     <> NVL(PTP.REP_REGISTRATION_NUMBER,REG.REGISTRATION_NUMBER)
  OR NVL(zl.HQ_ESTB_PARTY_TAX_PROF_ID,-99) <> PTP.PARTY_TAX_PROFILE_ID )
  AND REG.PARTY_TAX_PROFILE_ID(+)           = PTP.PARTY_TAX_PROFILE_ID
  )', -- The text of the signature query
  'Retrieve the HQ Establishment Registration Number populated with NULL or incorrect value on Tax Lines',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The HQ Establishment Registration Number populated with NULL or incorrect value on Tax Lines',     -- Problem description
  'Follow section 34 of Note- [1316316.1] and Apply the GDF Patch',     -- Problem solution
  'The HQ Establishment Registration Number populated with correct value on Tax Lines',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '41_Incorrect_HQ_Reg_AR', -- Unique Signature identifier
  'SELECT DISTINCT zl.trx_id,
  zl.trx_number,
  zl.trx_date,
  zl.legal_entity_id,
  zl.application_id
FROM
  (SELECT
    /*+ qb_name(appview) */
    zl.application_id,
    zl.trx_id,
    ZL.TRX_NUMBER,
    zl.trx_date,
    zl.entity_code,
    zl.event_class_code,
    zl.trx_line_id,
    zl.ledger_id,
    zl.internal_organization_id,
    zl.legal_entity_id,
    zl.establishment_id,
    ZL.TAX_EVENT_TYPE_CODE,
    zl.HQ_ESTB_REG_NUMBER,
    zl.HQ_ESTB_PARTY_TAX_PROF_ID,
    ZL.legal_reporting_status
  FROM zx_lines zl
  WHERE  zl.application_id                        IN (222)
  AND zl.entity_code                             IN (''TRANSACTIONS'')
  ) ZL,(
            ##$$TRXVIEW$$##
          ) trxs
WHERE ZL.trx_id=trxs.customer_trx_id
AND EXISTS
  (SELECT 1
  FROM ZX_REGISTRATIONS REG,
    XLE_ETB_PROFILES ETB,
    ZX_PARTY_TAX_PROFILE PTP
  WHERE PTP.PARTY_ID                        = ETB.PARTY_ID
  AND PTP.PARTY_TYPE_CODE                   = ''LEGAL_ESTABLISHMENT''
  AND ETB.MAIN_ESTABLISHMENT_FLAG           = ''Y''
  AND ETB.LEGAL_ENTITY_ID                   = zl.LEGAL_ENTITY_ID
  AND (NVL(zl.HQ_ESTB_REG_NUMBER,''XX'')     <> NVL(PTP.REP_REGISTRATION_NUMBER,REG.REGISTRATION_NUMBER)
  OR NVL(zl.HQ_ESTB_PARTY_TAX_PROF_ID,-99) <> PTP.PARTY_TAX_PROFILE_ID )
  AND REG.PARTY_TAX_PROFILE_ID(+)           = PTP.PARTY_TAX_PROFILE_ID
  )', -- The text of the signature query
  'Retrieve the HQ Establishment Registration Number populated with NULL or incorrect value on Tax Lines',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The HQ Establishment Registration Number populated with NULL or incorrect value on Tax Lines',     -- Problem description
  'Follow section 34 of Note- [1316316.1] and Apply the GDF Patch',     -- Problem solution
  'The HQ Establishment Registration Number populated with correct value on Tax Lines',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

add_signature(
  '42_Incorrect_ESTB_ID_AP', -- Unique Signature identifier
  'SELECT zl.trx_id,
  zl.trx_number,
  zl.trx_date,
  zl.event_class_code,
  zl.establishment_id "Current Establishment ID",
  etb.establishment_id "Correct Establishment ID"
FROM
  (SELECT
    /*+ qb_name(appview) */
    zl.application_id,
    zl.trx_id,
    ZL.TRX_NUMBER,
    zl.trx_date,
    zl.entity_code,
    zl.event_class_code,
    zl.trx_line_id,
    zl.ledger_id,
    zl.internal_organization_id,
    zl.legal_entity_id,
    zl.establishment_id,
    ZL.TAX_EVENT_TYPE_CODE,
    zl.HQ_ESTB_REG_NUMBER,
    zl.HQ_ESTB_PARTY_TAX_PROF_ID,
    ZL.legal_reporting_status
  FROM zx_lines zl
  WHERE zl.application_id                        IN (200)
  AND zl.entity_code                             IN (''AP_INVOICES'')
  ) zl,(
            ##$$IVIEW$$##
          ) invs,
  xle_etb_profiles etb
WHERE zl.application_id                        = 200
AND  ZL.trx_id   = invs.invoice_id
AND zl.entity_code                             = ''AP_INVOICES''
AND zl.event_class_code                       IN (''STANDARD INVOICES'', ''EXPENSE REPORTS'', ''PREPAYMENT INVOICES'')
AND zl.legal_entity_id                         = etb.legal_entity_id
AND (zl.establishment_id IS NULL OR etb.establishment_id <> zl.establishment_id)
AND etb.main_establishment_flag                = ''Y''
AND NVL(etb.main_effective_from, zl.trx_date) <= zl.trx_date
AND NVL(etb.main_effective_to, zl.trx_date)   >= zl.trx_date', -- The text of the signature query
  'Retrieve the Establishment ID populated with NULL or incorrect value on Tax Lines',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The Establishment ID populated with NULL or incorrect value on Tax Lines',     -- Problem description
  'Apply the data fix patch: 14317362',     -- Problem solution
  'The Establishment ID populated with correct value on Tax Lines',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


------------------------------------------------------------------------------
-- POPULATE Payables Options SIGNATURES--ARNAB MITRA
------------------------------------------------------------------------------
add_signature(
  '1_FIN_OPTIONS_SOB_Mismatch', -- Unique Signature identifier
  'select f.set_of_books_id,a.set_of_books_id,f.org_id
from ap_system_parameters_all a,financials_system_params_all f
 Where f.org_id = a.org_id
 and f.set_of_books_id != a.set_of_books_id', -- The text of the signature query
  'Retrieve wrong value for Set Of Books Id in Financial Options',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'No Primary Key row found for value in ORGANIZATION_CODE. Not able to select the OU in Financials Options Form.',     -- Problem description
  'Go through the Note- [1913271.1] and follow the action plan provided.',     -- Problem solution
  'There is no issue with SOB in Financials Options in Payables Setup.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


------------------------------------------------------------------------------
-- POPULATE Payment Document and Bank Account SIGNATURES--ARNAB MITRA
------------------------------------------------------------------------------

add_signature(
  '1_Missing_Payment_Doc', -- Unique Signature identifier
  'SELECT t.PAYMENT_DOCUMENT_ID,
  t.PAYMENT_DOCUMENT_NAME,
  t.PPAYMENT_INSTRUCTION_ID,
  t.PINTERNAL_BANK_ACCOUNT_ID,
  t.PAPER_STOCK_TYPE,
  t.ATTACHED_REMITTANCE_STUB_FLAG,
  t.NUMBER_OF_LINES_PER_REMIT_STUB,
  t.NUMBER_OF_SETUP_DOCUMENTS,
  t.format_code,
  t.FIRST_AVAILABLE_DOCUMENT_NUM,
  t.LAST_AVAILABLE_DOCUMENT_NUMBER,
  t.LAST_ISSUED_DOCUMENT_NUMBER,
  t.MANUAL_PAYMENTS_ONLY_FLAG,
  t.PAYMENT_DOC_CATEGORY
    From
  (SELECT s.check_stock_id PAYMENT_DOCUMENT_ID,
    s.name
    || '' ''
    || TO_CHAR(s.org_id) PAYMENT_DOCUMENT_NAME,
    to_number(NULL) PPAYMENT_INSTRUCTION_ID,
    ce.ce_bank_account_id PINTERNAL_BANK_ACCOUNT_ID,
    ''PRENUMBERED'' PAPER_STOCK_TYPE,
    NVL(f.print_check_stub,''N'') ATTACHED_REMITTANCE_STUB_FLAG,
    NVL(f.invoices_per_stub,5) NUMBER_OF_LINES_PER_REMIT_STUB,
    s.num_setup_checks NUMBER_OF_SETUP_DOCUMENTS,
    iby.format_code,
    1 FIRST_AVAILABLE_DOCUMENT_NUM,
    s.last_available_document_num LAST_AVAILABLE_DOCUMENT_NUMBER,
    s.last_document_num LAST_ISSUED_DOCUMENT_NUMBER,
    DECODE(s.disbursement_type_lookup_code, ''RECORDED'', ''Y'', ''N'') MANUAL_PAYMENTS_ONLY_FLAG,
    s.DOC_CATEGORY_CODE PAYMENT_DOC_CATEGORY,
    s.ATTRIBUTE_CATEGORY,
    s.ATTRIBUTE1,
    s.ATTRIBUTE2,
    s.ATTRIBUTE3,
    s.ATTRIBUTE4,
    s.ATTRIBUTE5,
    s.ATTRIBUTE6,
    s.ATTRIBUTE7,
    s.ATTRIBUTE8,
    s.ATTRIBUTE9,
    s.ATTRIBUTE10,
    s.ATTRIBUTE11,
    s.ATTRIBUTE12,
    s.ATTRIBUTE13,
    ''GSI_R12_UPGRD'' ATTRIBUTE14,
    s.ATTRIBUTE15,
    s.INACTIVE_DATE,
    RANK() OVER (PARTITION BY s.check_stock_id order by iby.format_code) create_doc
  FROM iby_formats_b iby,
    ap_payment_programs pp,
    ap_check_stocks_all s,
    ap_check_formats f,
    ce_upg_bank_accounts ce
  WHERE ce.source_application_id = 200
  AND iby.reference_format_code  = pp.program_name
  AND s.bank_account_id = ce.source_pk_id
  AND pp.program_id     = f.format_payments_program_id
  AND f.check_format_id = s.check_format_id
  AND NOT EXISTS
    (SELECT 1
    FROM ce_payment_documents
    WHERE payment_document_id = s.check_stock_id
    OR (payment_document_name = s.name|| '' ''|| TO_CHAR(s.org_id)
    AND internal_bank_account_id = ce.ce_bank_account_id)
    )
  ) t
WHERE t.create_doc = 1', -- The text of the signature query
  'Retrieve the documents assocated with custom formats which are not upgraded',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Documents assocated with custom formats which are not upgraded',     -- Problem description
  'Go through the Note- [549024.1] and follow the action plan provided',     -- Problem solution
  'Documents assocated with custom formats are upgraded',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '2_Orphan_Ext_Bank_Account', -- Unique Signature identifier
  'SELECT ext_bank_account_id ,
  bank_account_num ,
  bank_id ,
  branch_id ,
  currency_code ,
  country_code ,
  bank_account_type ,
  account_suffix
FROM iby_ext_bank_accounts eba
WHERE NOT EXISTS
  (SELECT ''OWNER''
  FROM iby_account_owners
  WHERE account_owner_party_id <> -99
  AND ext_bank_account_id       = eba.ext_bank_account_id
  )
AND NOT EXISTS
  (SELECT ''ASSIGNMENT''
  FROM iby_pmt_instr_uses_all
  WHERE instrument_type = ''BANKACCOUNT''
  AND instrument_id     = eba.ext_bank_account_id
  )
AND NOT EXISTS
  (SELECT ''UPGRADE_ASSIGNMENT''
  FROM IBY_UPG_INSTRUMENTS
  WHERE instrument_type = ''BANKACCOUNT''
  AND instrument_id     = eba.ext_bank_account_id
  )', -- The text of the signature query
  'Retrieve external bank accounts which are orphan for which assignment and owner does not exists ',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Orphan external bank accounts for which assignment and owner does not exists',     -- Problem description
  'Go through the Note- [1466998.1] and follow the action plan provided in Issue Description 7',     -- Problem solution
  'There is no orphan external bank accounts for which assignment and owner does not exists',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '3_Ext_Bank_Account_Exists', -- Unique Signature identifier
  'SELECT *
FROM iby_pmt_instr_uses_all ASSIGN
WHERE ASSIGN.ext_pmt_party_id = 0
AND ASSIGN.instrument_type    = ''BANKACCOUNT''
AND ASSIGN.PAYMENT_FUNCTION   = ''PAYABLES_DISB''
AND ASSIGN.PAYMENT_FLOW       = ''DISBURSEMENTS''', -- The text of the signature query
  'Retrieve External Bank Account not attached to the payee',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'External Bank Account not attached to the payee and when the user tries to create an error would be displayed as External Bank Account already exists',     -- Problem description
  'Go through the Note- [1466998.1] and follow the action plan provided in Issue Description 2',     -- Problem solution
  'There is no issue with External Bank Account to be attached to the Payee',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '4_Upgrade_Bank_Account_Assignments', -- Unique Signature identifier
  'SELECT *
FROM iby_upg_instruments upg
WHERE upg.ext_party_id   = 0
AND upg.instrument_type  = ''BANKACCOUNT''
AND upg.PAYMENT_FUNCTION = ''PAYABLES_DISB''', -- The text of the signature query
  'Retrieve upgraded bank account assignments which Users can not find',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Users can not find some of the upgraded bank account assignments',     -- Problem description
  'Go through the Note- [1466998.1] and follow the action plan provided in Issue Description 2',     -- Problem solution
  'There is no upgraded bank account assignments which user cannot find',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '5_Supplier_Bank_Account_Inactive', -- Unique Signature identifier
  'SELECT *
FROM iby_external_payees_all
WHERE org_id IS NULL
AND org_type IS NOT NULL
UNION
SELECT *
FROM iby_external_payees_all
WHERE org_type IS NULL
AND org_id     IS NOT NULL
UNION
SELECT * FROM iby_external_payees_all WHERE inactive_date IS NOT NULL', -- The text of the signature query
  'Retrieve Payees which show error as Supplier Bank Account attached to document payable is end dated',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Users faces an issue while processing payments as Supplier Bank Account attached to document payable is end dated',     -- Problem description
  'Go through the Note- [1466998.1] and follow the action plan provided in Issue Description 9',     -- Problem solution
  'Supplier Bank Account attached to document payable is active',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

add_signature(
  '6_No_Alternate_Bank_Account', -- Unique Signature identifier
  'SELECT eba.ext_bank_account_id,
  eba.bank_id,
  eba.branch_id,
  eba.bank_account_num,
  eba.bank_account_name_alt,
  ba.bank_account_name_alt bank_account_name_alt_new,
  ba.account_holder_name_alt
FROM ap_bank_accounts_all ba,
  ap_bank_branches bb,
  ce_upg_bank_rec bank,
  ce_upg_bank_rec branch,
  iby_ext_bank_accounts eba
WHERE ba.bank_branch_id         <> 1
AND ba.account_type             IN (''SUPPLIER'', ''EXTERNAL'')
AND ba.bank_branch_id            = bb.bank_branch_id
AND bank.source_application_id   = 200
AND bank.source_pk_id            = ba.bank_branch_id
AND bank.bank_entity_type        = ''BANK''
AND branch.source_application_id = 200
AND branch.source_pk_id          = ba.bank_branch_id
AND branch.bank_entity_type      = ''BRANCH''
AND bank.party_id                = eba.bank_id
AND branch.party_id              = eba.branch_id
AND ba.bank_account_num          = eba.bank_account_num
AND eba.bank_account_name_alt   IS NULL
AND (ba.bank_account_name_alt   IS NOT NULL
OR ba.account_holder_name_alt   IS NOT NULL)', -- The text of the signature query
  'Retrieve External Bank Accouts for which Alternate bank account name field has not been migrated to R12 for which Alternate bank account name exists in 11i',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'External Bank Accouts for which Alternate bank account name field has not been migrated to R12 for which Alternate bank account name exists in 11i',     -- Problem description
  'Go through the Note- [1466998.1] and follow the action plan provided in Issue Description 1',     -- Problem solution
  'External Bank Accouts having Alternate bank account name field value successfully migrated from 11i ',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');
  
 
add_signature(
  '7_Multiple_Primary_Bank_Account', -- Unique Signature identifier
  'SELECT *
FROM
  (SELECT o.account_owner_id,
    o.ext_bank_account_id,
    rank() over(PARTITION BY o.ext_bank_account_id ORDER BY o.account_owner_party_id) primary_rank
  FROM iby_account_owners o
  WHERE primary_flag = ''Y''
  )
WHERE primary_rank > 1', -- The text of the signature query
  'Retrieve Bank account details with multiple primary Bank account owners',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'External Bank Accouts having Duplicate Primary Bank Account Owners. Bank accounts are shown in duplicate in Supplier -> Entry -> Banking Details screen',     -- Problem description
  'Go through the Note- [1466998.1] and follow the action plan provided in Issue Description 5',     -- Problem solution
  'There is no Bank Account having multiple primary bank account owner',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '8_Multiple_Bank_Account_Instr_Assignments', -- Unique Signature identifier
  'SELECT instrument_payment_use_id,
  ext_pmt_party_id,
  instrument_id,
  order_of_preference,
  payment_function,
  instrument_type,
  RANK() OVER (PARTITION BY ext_pmt_party_id, payment_function, instrument_type 
  ORDER BY order_of_preference, instrument_payment_use_id DESC) new_rank
FROM iby_pmt_instr_uses_all
WHERE (ext_pmt_party_id) IN
  (SELECT ext_pmt_party_id
  FROM iby_pmt_instr_uses_all
  WHERE payment_function = ''PAYABLES_DISB''
  AND instrument_type    = ''BANKACCOUNT''
  GROUP BY ext_pmt_party_id,
    order_of_preference
  HAVING COUNT(order_of_preference) > 1
  )
AND payment_function = ''PAYABLES_DISB''
AND instrument_type  = ''BANKACCOUNT''', -- The text of the signature query
  'Retrieve External Bank Accounts having same priority for Multiple Bank Account Instruments Assignments',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Mulitple Bank Accounts having Same priority Bank Account Instrument Assignment Priority',     -- Problem description
  'Go through the Note- [1466998.1] and follow the action plan provided in Issue Description 3',     -- Problem solution
  'There is no External Bank Accounts having same priority for Multiple Bank Account Istruments Assignments',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '9_Duplicate_Ext_Bank_Account', -- Unique Signature identifier
  'SELECT ext_bank_account_id, bank_account_num, bank_id, branch_id, currency_code, country_code, bank_account_type, ACCOUNT_SUFFIX,  RANK() OVER (PARTITION BY
       bank_account_num,bank_id,branch_id,currency_code, country_code
       ORDER BY end_date DESC, creation_date, start_date, ext_bank_account_id )num
       FROM
       iby_ext_bank_accounts WHERE (bank_account_num, nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code) IN ( SELECT bank_account_num,  nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code FROM iby_ext_bank_accounts where country_code <> ''JP'' and country_code <> ''NZ'' GROUP BY 
       bank_account_num, bank_id, branch_id, currency_code, country_code HAVING
       Count(*)>1)
UNION
SELECT ext_bank_account_id, bank_account_num, bank_id, branch_id, currency_code, country_code, bank_account_type, ACCOUNT_SUFFIX, RANK() OVER (PARTITION BY
       bank_account_num,bank_id,branch_id,currency_code, country_code, bank_account_type
       ORDER BY end_date DESC, creation_date, start_date, ext_bank_account_id )num
       FROM
       iby_ext_bank_accounts WHERE (bank_account_num, nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code, nvl(bank_account_type,''XX'')) IN ( SELECT bank_account_num,  nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code, nvl(bank_account_type,''XX'') FROM iby_ext_bank_accounts where country_code = ''JP'' GROUP BY 
       bank_account_num, bank_id, branch_id, currency_code, country_code, bank_account_type HAVING
       Count(*)>1)
UNION
SELECT ext_bank_account_id, bank_account_num, bank_id, branch_id, currency_code, country_code, bank_account_type, ACCOUNT_SUFFIX, RANK() OVER (PARTITION BY
       bank_account_num,bank_id,branch_id,currency_code, country_code, ACCOUNT_SUFFIX
       ORDER BY end_date DESC, creation_date, start_date, ext_bank_account_id )num
       FROM
       iby_ext_bank_accounts WHERE (bank_account_num, nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code, nvl(ACCOUNT_SUFFIX,''XX'')) IN ( SELECT bank_account_num,  nvl(bank_id,-99),nvl(branch_id,-99),
       nvl(currency_code,''XX''), country_code, nvl(ACCOUNT_SUFFIX,''XX'') FROM iby_ext_bank_accounts where country_code = ''NZ'' GROUP BY 
       bank_account_num, bank_id, branch_id, currency_code, country_code, ACCOUNT_SUFFIX HAVING
       Count(*)>1)', -- The text of the signature query
  'Retrieve Duplicate External Bank Accounts',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Upgrade creates duplicate external bank accounts in R12. Due to this, users cannot update external bank accounts',     -- Problem description
  'Go through the Note- [1265353.1] and follow the action plan provided',     -- Problem solution
  'There is no Duplicate External Bank Account present',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

add_signature(
  '10_Dup_Pay_Profile', -- Unique Signature identifier
  'SELECT payment_profile_id from
(SELECT system_profile_code, bep_account_id, payment_profile_id,
Rank() over (PARTITION BY SYSTEM_PROFILE_CODE, BEP_ACCOUNT_ID ORDER BY CREATION_DATE, PAYMENT_PROFILE_ID) NUM
FROM IBY_ACCT_PMT_PROFILES_B WHERE SYSTEM_PROFILE_CODE IN (
SELECT system_profile_code FROM IBY_ACCT_PMT_PROFILES_B
WHERE system_profile_code IN (SELECT system_profile_code FROM IBY_SYS_PMT_PROFILES_B WHERE bepid IS null)
AND Nvl(INACTIVE_DATE, SYSDATE+10) > SYSDATE
GROUP BY system_profile_code, bep_account_id HAVING Count(*)>1 ))duplicates
WHERE num>1', -- The text of the signature query
  'Retrieve the Duplicate Payment Process Profile coming in Payment Worbench',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Duplicate Payment Process Profile coming in Payment Worbench',     -- Problem description
  'Go through the Note- [1375640.1] and Log an SR to get the Datafix script <u>Dup_acct_profiles.sql</u> from Payment Development ',     -- Problem solution
  'There is no Duplicate Payment Process Profile ',     -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

------------------------------------------------------------------------------
-- POPULATE SUPPLIER/PARTY SIGNATURES
------------------------------------------------------------------------------
  
  
add_signature(
  '1_IBY_BANK_CHARGE_BEARER', -- Unique Signature identifier
  'SELECT  assi.vendor_id,
	assi.vendor_site_id,
	assi.vendor_site_code,
	assi.org_id,	
	iep.ext_payee_id,
	iep.bank_charge_bearer
FROM    iby_external_payees_all iep,
        ap_supplier_sites_all assi
WHERE   iep.supplier_site_id = assi.vendor_site_id
AND     iep.bank_charge_bearer  IN 
        (SELECT lookup_code
         FROM   fnd_lookup_values_vl
         WHERE  lookup_type = ''BANK CHARGE BEARER'')', -- The text of the signature query
  'Retrieve the invalid bank charge bearer on the table IBY_EXTERNAL_PAYEES_ALL',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Due to invalid bank charge bearer User may get the error message UPDATE_VENDOR_SITE IBY_LOOKUP_VAL_ERROR (LOOKUPTYPE=IBY_BANK_CHARGE_BEARER)(VALUE=I)',     -- Problem description
  'Log an SR to get the Datafix script <u>bank_charge_bearer.sql</u> from Payables Development',     -- Problem solution
  'Valid bank charge bearer on the table IBY_EXTERNAL_PAYEES_ALL',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '2_DUP_EMP_ID', -- Unique Signature identifier
  'select aps.vendor_id, 
       aps.employee_id, 
       aps.vendor_name, 
       papf.full_name, 
       papf.party_id, 
       aps.party_id
  from ap_suppliers aps, 
       per_all_people_f papf
 where aps.employee_id = papf.person_id
   and aps.employee_id in 
       (select employee_id 
          from ap_suppliers 
         group by employee_id 
        having count(*) > 1)', -- The text of the signature query
  'Retrieve the same Employee Id associated to multiple Suppliers',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Multiple suppliers are associated with same employee causing issues when creating Expense Reports ',     -- Problem description
  'Log an SR to get the Datafix script <u>dup_emp_id_on_aps.sql</u> from Payables Development',     -- Problem solution
  'There is no Employee Id associated to multiple Suppliers ',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

add_signature(
  '3_MISMATCH_AWT_SITE', -- Unique Signature identifier
  'SELECT pv.vendor_id,
     pv.vendor_name,
     pvs.vendor_site_id,
     pvs.vendor_site_code,
     pvs.org_id
FROM po_vendors_obs pv, po_vendor_sites_obs pvs,ap_suppliers supp,ap_supplier_sites_all sites
WHERE pv.vendor_id = pvs.vendor_id 
AND pv.vendor_id=supp.vendor_id
AND pvs.vendor_site_id=sites.vendor_site_id
AND sites.vendor_id=supp.vendor_id
AND NVL(pv.allow_awt_flag,''N'') = ''N''
AND pvs.allow_awt_flag = ''Y''
AND sites.allow_awt_flag = ''N''
AND NVL(supp.allow_awt_flag,''N'') = ''N''', -- The text of the signature query
  'Retrieve the cases when system disabled the AWT on the Supplier Site during R12 Upgrade',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Since AWT was disabled on the Supplier entity system disabled the AWT on the Supplier Site during R12 Upgrade ',     -- Problem description
  'Go through the Note- [1914173.1] and log an SR to get the Datafix ',     -- Problem solution
  'AWT is not disabled during Upgrade at Supplier Site Level.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

add_signature(
  '4_DUP_PARTY_SITE_NAME', -- Unique Signature identifier
  'SELECT hzps.party_site_id,party_id,Location_Id,End_Date_Active,Identifying_Address_Flag,
status,party_site_name,created_by_module,application_id,
  party_site_name
  || ''_''
  || (rank() over (partition BY 
                       hzps.party_id, 
                       hzps.party_site_name 
                   order by
                       hzps.party_site_id)) 
   new_party_site_name
   FROM hz_party_sites hzps
 WHERE (party_site_name, party_id) IN
  (SELECT party_site_name,
          party_id
     FROM hz_party_sites ps
    WHERE ps.party_site_id IN 
          (SELECT assi.party_site_id
             FROM ap_supplier_sites_all assi)
    GROUP BY party_site_name,
             party_id
   HAVING COUNT(*) > 1
  )
ORDER BY party_id', -- The text of the signature query
  'Retrieve the duplicate Party Site Name for a Party',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Because of duplicate Party Site Name user may get error message Address already Exists while updating Supplier Address ',     -- Problem description
  'Log an SR to get the Datafix script <u>dup_address_name_in_r12.sql</u> from Payables Development ',     -- Problem solution
  'There is no duplicate Party Site Name exists for a Party.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '5_NO_DEFAULT_PAY_METHOD', -- Unique Signature identifier
  'select aps.party_id, aps.vendor_id, aps.vendor_name, payee.EXT_PAYEE_ID, 
       ''NULLPAYMENTMETHOD'' payment_method_code       
  from iby_external_payees_all payee,
       ap_suppliers aps
 where aps.party_id = payee.payee_party_id
   and payee.party_site_id is null
   and payee.supplier_site_id is null
   and payee.org_id is null 
   and not exists (select ''No payment method''
                     from IBY_EXT_PARTY_PMT_MTHDS pmt
		    where pmt.EXT_PMT_PARTY_ID = payee.EXT_PAYEE_ID
          and pmt.PRIMARY_FLAG = ''Y''
                  )', -- The text of the signature query
  'Retrieve the Supplier Records having no Default Payment Method',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Default Payment Method is not populated for Supplier ',     -- Problem description
  'Log an SR to get the Datafix script <u>aps_no_default_pmt_meth_fix.sql</u> from Payables Development ',     -- Problem solution
  'There is no Supplier having no default Payment Method',     -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '6_AR_Orphan_BA_Assign', -- Unique Signature identifier
  'SELECT actown.ext_bank_account_id,ibypye.payment_Function,
      ibypye.ext_payee_id,
      ibypye.payee_party_id
    FROM iby_account_owners actown,
      iby_external_payees_all ibypye
    WHERE actown.account_owner_party_id = ibypye.payee_party_id
    AND ibypye.payment_Function = ''AR_CUSTOMER_REFUNDS''
    AND NOT EXISTS
      (SELECT 1
      FROM iby_pmt_instr_uses_all
      WHERE ext_pmt_party_id = ibypye.ext_payee_id
      AND instrument_id      = actown.ext_bank_account_id
      AND payment_flow       = ''DISBURSEMENTS''
      )', -- The text of the signature query
  'Retrieve Orphan Bank Accounts for AR Refunds',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'There are Orphan Bank Accounts for AR Refunds. Due to this payments are rejected with the message Supplier Bank Account attached to document payable is end dated ',     -- Problem description
  'Log an SR to get the Datafix script <u>AR_Orphan_BA_Assign.sql</u> from Payments Development ',     -- Problem solution
  'There is no Orphan Bank Accounts for AR Refunds',     -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '7_Dup_Invoice_Supplier_Merge', -- Unique Signature identifier
  'select  dv.entry_id,
        dv.vendor_id C_VENDOR_ID,
        DV.VENDOR_SITE_ID C_OLD_VENDOR_SITE_ID,
        INV.INVOICE_ID ,
        duplicate_vendor_id,
        DUPLICATE_VENDOR_SITE_ID ,
        inv.invoice_currency_code ,
        invoice_num,
        invoice_amount ,
        amount_paid ,
        DISCOUNT_AMOUNT_TAKEN ,
        inv.payment_status_flag ,
        INVOICE_DATE ,
        inv.DESCRIPTION ,
        dv.org_id,
        dv.process
  FROM   ap_duplicate_vendors_all dv,
         ap_suppliers a,
         ap_suppliers b,
         ap_supplier_sites_all c,
         ap_supplier_sites_all d,
         ap_invoices_all inv
WHERE  dv.process_flag=''N''
AND    inv.vendor_id = duplicate_vendor_id
AND    inv.vendor_site_id = duplicate_vendor_site_id
AND    inv.org_id = dv.org_id
AND    a.vendor_id=dv.vendor_id
AND    c.vendor_site_id=nvl(dv.vendor_site_id,duplicate_vendor_site_id)
AND    b.vendor_id=dv.duplicate_vendor_id
AND    d.vendor_site_id=dv.duplicate_vendor_site_id
AND    d.org_id = dv.org_id
and    DV.PROCESS <> ''P''
and INV.PAYMENT_STATUS_FLAG= DECODE(DV.PAID_INVOICES_FLAG,''N'',''N'',INV.PAYMENT_STATUS_FLAG)', -- The text of the signature query
  'Retrieve  all the invoice numbers for FROM VENDORS for which merge has not been successful',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'There are dulicate invoices for which Supplier Merge is unsuccessful',     -- Problem description
  'Refer Note- [1357813.1] and follow the action plan to correct the Duplicate Invoice Number ',     -- Problem solution
  'There is no Duplicate Invoice Number which can cause unsuccessful Supplier Merge',     -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


------------------------------------------------------------------------------
-- POPULATE INVOICE BEHAVIOR SIGNATURES
------------------------------------------------------------------------------


 add_signature(
  '2_Pay_File_Ver', -- Unique Signature identifier
  'select text from all_source where name like ''AP%'' and line=2 and text like ''%Header%''', -- The text of the signature query
  'Payables Database Packages',     -- Signature title
  'NRS',     -- fail condition: RS, NRS, [col] operand [val]
  'This is for the information purpose to get the file versions of Payables Database Packages.',     -- Problem description
  '',     -- Problem solution
  'This is for the information purpose to get the file versions of Payables Database Packages.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'I',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info);
  

  add_signature(
  '2_INVALIDS_AP', -- Unique Signature identifier
      'select object_name,object_type,file_version,
LTRIM(MAX(SYS_CONNECT_BY_PATH(text,'' , ''))
       KEEP (DENSE_RANK LAST ORDER BY curr),'' , '') AS elements
from (SELECT object_name,text,name,object_type,file_version,
               ROW_NUMBER() OVER (PARTITION BY object_name ORDER BY text) AS curr,
               ROW_NUMBER() OVER (PARTITION BY object_name ORDER BY text) -1 AS prev
        FROM   (SELECT a.object_name,b.name,    
           b.text,object_type,(
             SELECT ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 1)
               ))) || '' - '' ||
               ltrim(rtrim(substr(substr(c.text, instr(c.text,''Header: '')),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2),
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 3) -
               instr(substr(c.text, instr(c.text,''Header: '')), '' '', 1, 2)
               )))
             FROM dba_source c
             WHERE c.owner = a.owner
             AND   c.name = a.object_name
             AND   c.type = a.object_type
             AND   c.line = 2
             AND   c.text like ''%$Header%''
           ) File_Version 
           FROM dba_objects a,
         dba_errors b
    WHERE a.object_name = b.name(+)
    AND a.object_type = b.type(+)
    AND a.owner = ''APPS''
    AND (a.object_name like ''AP%'')
    AND a.status = ''INVALID'')errors)a
GROUP BY object_name,object_type,file_version
CONNECT BY prev = PRIOR curr AND name = PRIOR name
START WITH curr = 1', -- The text of the signature query
  'Payables Invalids',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'Checking for Payables related Invalid objects',     -- Problem description
  'Invalid objects exists for Payables - please check the list and work on solve them.',     -- Problem solution
  'No Payables invalid exists.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'E',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');



    
    
add_signature(
  '1_Eff_Payment', -- Unique Signature identifier
  'SELECT p.invoice_id, p.org_id, p.amount,p.check_id
FROM ap_invoice_payments_all P,(
            ##$$IVIEW$$##
          ) invs
    WHERE P.invoice_id            = invs.invoice_id
    AND NVL(P.reversal_flag,''N'') <> ''Y''
    AND P.amount                 IS NOT NULL
    AND EXISTS   (SELECT ''non void check'' FROM ap_checks_all A  WHERE A.check_id = P.check_id  AND void_date   IS NULL)', -- The text of the signature query
  'Checking whether the Invoice has any Effective Payment or not',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since it is already paid.You may also get the error message APP-SQLAP-10228 This Invoice Has An Effective Payment',     -- Problem description
  'You need to void the Payment first and then try to cancel the Invoice.Refer Note- [1561331.1] and follow Section C2 of CheckList for cancellation ',     -- Problem solution
  'The invoice has no effective payment(s)',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');

add_signature(
  '2_Selected_Payment', -- Unique Signature identifier
  'SELECT a.invoice_id , a.checkrun_id,a.org_id, b.checkrun_name,b.status 
FROM ap_payment_schedules_all a,ap_inv_selection_criteria_all b,(
            ##$$IVIEW$$##
          ) invs
WHERE invs.invoice_id=a.invoice_id
and a.checkrun_id is not Null 
and a.checkrun_id=b.checkrun_id', -- The text of the signature query
  'Checking whether the Invoice has been selected by any PPR',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since it is already selected by PPR.',     -- Problem description
  'You need to either terminate the PPR or confirm. Refer Note- [1561331.1] and follow Section C3 of CheckList for cancellation ',     -- Problem solution
  'The invoice is not selected by any PPR',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '3_Credited_Invoice', -- Unique Signature identifier
  'SELECT distinct ail.invoice_id credit_memo_invoice_id,ail.corrected_inv_id standard_invoice_id,ail.org_id
FROM   ap_invoice_lines_all AIL,(
            ##$$IVIEW$$##
          ) invs
WHERE invs.invoice_id=ail.corrected_inv_id   
AND  ( NVL( AIL.discarded_flag, ''N'' ) <> ''Y'' AND NVL( AIL.cancelled_flag, ''N'' ) <> ''Y'' )
AND    AIL.corrected_inv_id is not null   AND   AIL.corrected_inv_id!=AIL.invoice_id 
union    
SELECT distinct ai.invoice_id credit_memo_invoice_id,ai.credited_invoice_id standard_invoice_id,ai.org_id
FROM   ap_invoices_all AI ,(
            ##$$IVIEW$$##
          ) invs
WHERE invs.invoice_id=AI.credited_invoice_id    
AND  AI.credited_invoice_id is not null AND  NVL(AI.quick_credit, ''N'') = ''Y''
AND  AI.cancelled_date is null and AI.credited_invoice_id!=AI.invoice_id', -- The text of the signature query
  'Checking whether the Invoice has been credited or corrected to any Credit Memo',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since it is already applied to the Credit Memo.',     -- Problem description
  'You need to cancel the Credit Memo first and then try to cancel the Standard Invoice. Refer Note- [1561331.1] and follow Section C5 of CheckList for cancellation ',     -- Problem solution
  'The invoice is not applied to any Credit Memo',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


 add_signature(
  '4_Prepay_Applied', -- Unique Signature identifier
  'SELECT ail.invoice_id,ail.prepay_invoice_id,ABS(SUM(ail.amount)) Applied_Amount
FROM ap_invoice_lines_all ail ,(
            ##$$IVIEW$$##
          ) invs
WHERE ail.invoice_id = invs.invoice_id   
AND ail.line_type_lookup_code = ''PREPAY''
AND  ( NVL( AIL.discarded_flag, ''N'' ) <> ''Y'' AND NVL( AIL.cancelled_flag, ''N'' ) <> ''Y'' ) 
GROUP BY ail.invoice_id, ail.prepay_invoice_id 
having ABS(SUM(amount)) > 0', -- The text of the signature query
  'Checking whether the Prepayment has been applied on the Standard Invoice',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since there is a Prepayment Amount applied in it.',     -- Problem description
  'You need to unapply the Prepayment first and then try to cancel the Standard Invoice. Refer Note- [1561331.1] and follow Section C6 of CheckList for cancellation ',     -- Problem solution
  'The invoice is no Prepayment applied in the Standard Invoice',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y'); 

add_signature(
  '5_PO_Finally_Closed', -- Unique Signature identifier
  'SELECT ail.invoice_id,ail.org_id,ail.po_line_location_id,ail.po_line_id,ail.po_header_id
          FROM   ap_invoice_lines_all AIL,
           po_line_locations_ALL PL,(
            ##$$IVIEW$$##
          ) invs
    WHERE  AIL.invoice_id = invs.invoice_id
    AND    AIL.po_line_location_id = PL.line_location_id
    AND    AIL.org_id = PL.org_id AND NVL(fnd_profile.value(''FV_ENABLED''), ''N'')=''N''
    AND    PL.closed_code = ''FINALLY CLOSED''', -- The text of the signature query
  'Checking whether the Invoice is matched to a Finally Closed PO',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since Invoice is matched to a Finally Closed PO.',     -- Problem description
  'You need to enter a Credit Memo with the same charge accounts that of invoice matched to Finally Closed PO and make a Zero payment selecting Credit memo and the invoice.
If the standard invoice is already paid enter a Credit memo with the same charge accounts that of invoice matched to Finally Closed PO and take a Refund of the Payment. 
Refer Note- [1561331.1] and follow Section C7 of CheckList for cancellation ',     -- Problem solution
  'The invoice is not matched to the Finally Closed PO',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y'); 



add_signature(
  '6_PO_Negative_Billed', -- Unique Signature identifier
  'SELECT aiv.invoice_id,AIV.invoice_type_lookup_code,AID.po_distribution_id,count(*)
   FROM ap_invoice_distributions_all AID,
          po_distributions_ap_v POD,
      po_line_locations_all PLL,
      po_lines_all PL,
          ap_invoices AIV,(
            ##$$IVIEW$$##
          ) invs
    WHERE POD.po_distribution_id = AID.po_distribution_id
      AND POD.line_location_id = PLL.line_location_id
      AND PLL.po_line_id = PL.po_line_id
      AND AIV.invoice_id=AID.invoice_id
      AND NVL(AID.reversal_flag, ''N'') <> ''Y''
      AND AID.invoice_id = invs.invoice_id
       -- Bug 5590826. For amount related decode
      AND AID.line_type_lookup_code IN (''ITEM'', ''ACCRUAL'', ''IPV'')   
   HAVING (DECODE(AIV.invoice_type_lookup_code,''PREPAYMENT'',
             SUM(NVL(POD.quantity_financed, 0)),SUM(NVL(POD.quantity_billed, 0))
       ) -
             SUM(round(decode(AID.dist_match_type,
                             ''PRICE_CORRECTION'', 0,
                             ''AMOUNT_CORRECTION'', 0,
                             ''ITEM_TO_SERVICE_PO'', 0,
                             ''ITEM_TO_SERVICE_RECEIPT'', 0,
                              nvl( AID.quantity_invoiced, 0 ) +
                              nvl( AID.corrected_quantity,0 )
                 ) *
                   po_uom_s.po_uom_convert(AID.matched_uom_lookup_code,
                                   nvl(PLL.unit_meas_lookup_code,
                           PL.unit_meas_lookup_code),
                       PL.item_id), 15)
            ) < 0
           OR DECODE(AIV.invoice_type_lookup_code,''PREPAYMENT'',
              SUM(NVL(POD.amount_financed, 0)),SUM(NVL(POD.amount_billed, 0))) -
              SUM(NVL(AID.amount, 0)) < 0 )
    GROUP BY aiv.invoice_id,AIV.invoice_type_lookup_code,AID.po_distribution_id', -- The text of the signature query
  'Checking whether the Invoice Cancelling will cause Negative Billing or not in the respective PO',     -- Signature title
  '[count(*)] > [0]',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since it will cause Quantity Billed or Amount Billed to less than 0',     -- Problem description
  'You need to find all the invoices matched to the same PO. If there exists the Credit Memo you need to cancel the Credit Memo first and then try to cancel the Standard Invoice.
  Refer Note- [1561331.1] and follow Section C8 of CheckList for cancellation ',     -- Problem solution
  'The invoice cancellation activity will not cause Negative Billing',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y'); 

  
add_signature(
  '7_ENC_Unapproved_PO', -- Unique Signature identifier
  'select aid.invoice_id,aid.po_distribution_id
              from   po_headers_all POH,
                 po_distributions_all POD,
                 ap_invoice_distributions_all AID,
                 ap_invoices_all AI,financials_system_params_all fsp,(
            ##$$IVIEW$$##
          ) invs
          where  AI.invoice_id = AID.invoice_id
          and    AI.invoice_id = invs.invoice_id
          and    NVL(fsp.purch_encumbrance_flag,''N'')=''Y''
          and    NVL(fsp.org_id, -99) = NVL(AI.org_id, -99)
          and    AID.po_distribution_id = POD.po_distribution_id
          and    POD.po_header_id = POH.po_header_id
          and    POH.approved_flag <> ''Y''
          and    rownum = 1', -- The text of the signature query
  'Checking whether the invoice is matched to an unapproved PO whereas the encumbrance is on',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since invoice is matched to an unapproved PO whereas the encumbrance is on.',     -- Problem description
  'You need to approve the PO and then try to cancel the Invoice.Refer Note- [1561331.1] and follow Section C9 of CheckList for cancellation ',     -- Problem solution
  'The invoice is not matched to the unappoved PO while Encumbrance is on.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y'); 



add_signature(
  '8_AP_AR_Netting', -- Unique Signature identifier
  'Select fn.batch_id,fn.batch_name,fn.batch_number,fn.batch_status_code,fn.total_netted_amt,ap.invoice_id,ap.org_id 
from fun_net_batches_all fn,ap_payment_schedules_all ap,(
            ##$$IVIEW$$##
          ) invs
where fn.checkrun_id=ap.checkrun_id
and ap.invoice_id = invs.invoice_id', -- The text of the signature query
  'Checking whether the invoice is stuck in AP AR Netting Batch',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be cancelled since invoice is stuch in AP AR Netting Batch.',     -- Problem description
  'You need to Cancel or complete the Netting Batch. Refer Note- [1561331.1] and follow Section C12 of CheckList for cancellation ',     -- Problem solution
  'The invoice is not stuck in AP AR Netting Batch.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y'); 



add_signature(
  '9_DIST_ACCT_Invalid1', -- Unique Signature identifier
  'SELECT  D.invoice_id,D.dist_code_combination_id, D.accounting_date,''DIST ACCT VALID''
FROM    ap_invoice_distributions_all D,(
            ##$$IVIEW$$##
          ) invs
WHERE   D.invoice_id = invs.invoice_id
AND  D.posted_flag in (''N'', ''P'') AND ((EXISTS (select ''x'' from gl_code_combinations C
where c.alternate_code_combination_id is null
and D.dist_code_combination_id = C.code_combination_id (+)
and (C.code_combination_id is null or C.detail_posting_allowed_flag = ''N''
or C.start_date_active > D.accounting_date or C.end_date_active < D.accounting_date
or C.template_id is not null or C.enabled_flag <> ''Y''or C.summary_flag <> ''N''
)))
OR (D.dist_code_combination_id = -1))
AND ROWNUM = 1', -- The text of the signature query
  'Checking whether the invoice is having Invalid Distribution Account or not',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be validated since distribution account is invalid.',     -- Problem description
  'Please refer section 4.1 Accounting Holds of Doc Id 1472606.1 and follow the Hold Removal(Fix) for Dist Acct Invalid.',     -- Problem solution
  'The invoice does not have any Invalid Distribution Account.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '9_DIST_ACCT_Invalid2', -- Unique Signature identifier
  'SELECT  D.Invoice_id,D.dist_code_combination_id, D.accounting_date,''DIST ACCT VALID''
FROM    ap_invoice_distributions_all D,(
            ##$$IVIEW$$##
          ) invs
WHERE   D.invoice_id = invs.invoice_id
AND  D.posted_flag in (''N'', ''P'') AND ((EXISTS (select ''x'' from gl_code_combinations C
where c.alternate_code_combination_id is not null
and D.dist_code_combination_id = C.code_combination_id (+)
and (C.code_combination_id is null or C.detail_posting_allowed_flag = ''N''
or C.start_date_active > D.accounting_date or C.end_date_active < D.accounting_date or C.template_id is not null
or C.enabled_flag <> ''Y''or C.summary_flag <> ''N'')
)) OR (D.dist_code_combination_id = -1))
AND ROWNUM = 1 and not exists
(SELECT ''Y''  FROM gl_code_combinations glcc WHERE glcc.code_combination_id = D.dist_code_combination_id
AND glcc.alternate_code_combination_id IS NOT NULL AND EXISTS(
SELECT ''Account Valid'' FROM gl_code_combinations a
WHERE a.code_combination_id = glcc.alternate_code_combination_id
AND a.enabled_flag=''Y'' AND a.detail_posting_allowed_flag = ''Y''
AND D.accounting_date BETWEEN NVL(a.start_date_active, D.accounting_date)
AND NVL(a.end_date_active, D.accounting_date)))', -- The text of the signature query
  'Checking whether the invoice is having Invalid Distribution Account or not',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be validated since distribution account is invalid.',     -- Problem description
  'Please refer section 4.1 Accounting Holds of Doc Id 1472606.1 and follow the Hold Removal(Fix) for Dist Acct Invalid.',     -- Problem solution
  'The invoice does not have any Invalid Distribution Account.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');



add_signature(
  '10_PO_MATCHING_REQUIRED', -- Unique Signature identifier
  'SELECT api.invoice_id,''PO REQUIRED''
FROM ap_invoices_all api, ap_supplier_sites_all pov,(
            ##$$IVIEW$$##
          ) invs
WHERE EXISTS (select /*+ index(apd AP_INVOICE_DISTRIBUTIONS_U1) */ ''X''
from ap_invoice_distributions_all apd
where apd.invoice_id = api.invoice_id
and apd.line_type_lookup_code in ( ''ITEM'', ''ACCRUAL'')
and apd.po_distribution_id is null
and apd.pa_addition_flag <> ''T'' and nvl(apd.reversal_flag,''N'')=''N'')
AND   nvl(pov.hold_unmatched_invoices_flag, ''X'') = ''Y''
AND   api.invoice_type_lookup_code not in (''PREPAYMENT'', ''INTEREST'')
AND   api.vendor_site_id = pov.vendor_site_id
AND   api.org_id = pov.org_id AND   api.invoice_id = invs.invoice_id', -- The text of the signature query
  'Checking whether the invoice needs to be matched or not',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be validated since it is not matched to PO or Receipt.',     -- Problem description
  'Please refer section 4.4 Matchting Holds of Doc Id 1472606.1 and follow the Hold Removal(Fix) for MATCHING REQUIRED.',     -- Problem solution
  'The invoice should not have PO REQUIRED or MATCHING REQUIRED Hold.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '11_NO_EXCHANGE_RATE', -- Unique Signature identifier
  'SELECT I.invoice_id,I.org_id,I.invoice_num,I.exchange_rate
FROM   ap_invoices I,ap_system_parameters asp,(
            ##$$IVIEW$$##
          ) invs
WHERE  I.invoice_id = invs.invoice_id
AND    I.invoice_currency_code <> asp.base_currency_code
AND    I.set_of_books_id=asp.set_of_books_id
AND    I.org_id=asp.org_id
AND    I.exchange_rate is null', -- The text of the signature query
  'Checking whether the Foreign Currency invoice having Exchange Rate populated or not',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above Foreign currency invoice(s) can not be validated since it has not the Exchange Rate populated.',     -- Problem description
  'Please refer section 4.6 Miscellaneous Holds of Doc Id 1472606.1 and follow the Hold Removal(Fix) for NO RATE.',     -- Problem solution
  'The invoice should not have NO RATE Hold.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(
  '12_DIST_VARIANCE_HOLD', -- Unique Signature identifier
  'SELECT ail.invoice_id,  ''Dist Variance Hold.'' Hold
FROM   ap_invoice_lines_all AIL, ap_invoice_distributions_all D,(
            ##$$IVIEW$$##
          ) invs
WHERE  AIL.invoice_id = D.invoice_id(+)
AND    AIL.invoice_id = invs.invoice_id
AND    AIL.line_number = D.invoice_line_number(+)
AND    (NVL(D.line_type_lookup_code, ''ITEM'') <> ''RETAINAGE''
OR (AIL.line_type_lookup_code = ''RETAINAGE RELEASE'' and D.line_type_lookup_code = ''RETAINAGE''))
AND (AIL.line_type_lookup_code NOT IN (''ITEM'', ''RETAINAGE RELEASE'')
or (AIL.line_type_lookup_code  IN (''ITEM'', ''RETAINAGE RELEASE'')
and (D.prepay_distribution_id IS NULL or (D.prepay_distribution_id IS NOT NULL
and D.line_type_lookup_code NOT IN (''PREPAY'', ''REC_TAX'', ''NONREC_TAX'')))))
 GROUP BY AIL.invoice_id, AIL.line_number, AIL.amount
HAVING AIL.amount <> nvl(SUM(nvl(D.amount,0)),0)', -- The text of the signature query
  'Checking whether Invoice Amount is not equal to the sum of the invoice distributions amounts or not',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be validated since Invoice Amount is not equal to the sum of the invoice distributions amounts .',     -- Problem description
  'Please refer section 4.5 Variance Holds of Doc Id 1472606.1 and follow the Hold Removal(Fix) for DIST VARIANCE.',     -- Problem solution
  'The invoice should not have DIST VARIANCE Hold.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');



add_signature(
  '13_LINE_VARIANCE_HOLD', -- Unique Signature identifier
  'SELECT a.invoice_id,a.invoice_amount,''Line Total <> Invoice Amount''
          FROM   ap_invoice_lines_all AIL, ap_invoices_all A,(
            ##$$IVIEW$$##
          ) invs
          WHERE  AIL.invoice_id = A.invoice_id
          AND    AIL.invoice_id = invs.invoice_id
          AND    ((AIL.line_type_lookup_code <> ''TAX''
                   and (AIL.line_type_lookup_code NOT IN (''AWT'',''PREPAY'')
                        or NVL(AIL.invoice_includes_prepay_flag,''N'') = ''Y'') OR
                  (AIL.line_type_lookup_code = ''TAX''
                  /* bug 5222316 */
                   and (AIL.prepay_invoice_id IS NULL
                        or (AIL.prepay_invoice_id is not null
                            and NVL(AIL.invoice_includes_prepay_flag, ''N'') = ''Y'')))))
               --    and AIL.prepay_invoice_id IS NULL)))
          GROUP BY A.invoice_id, A.invoice_amount, A.net_of_retainage_flag
          HAVING A.invoice_amount <>
                  nvl(SUM(nvl(AIL.amount,0) + decode(A.net_of_retainage_flag,
                                 ''Y'', nvl(AIL.retained_amount,0),0)),0)', -- The text of the signature query
  'Checking whether Invoice Amount is not equal to the sum of the invoice Lines amounts or not',     -- Signature title
  'RS',     -- fail condition: RS, NRS, [col] operand [val]
  'The above invoice(s) can not be validated since Invoice Amount is not equal to the sum of the invoice lines amounts .',     -- Problem description
  'Please refer section 4.5 Variance Holds of Doc Id 1472606.1 and follow the Hold Removal(Fix) for LINE VARIANCE.',     -- Problem solution
  'The invoice should not have LINE VARIANCE Hold.',      -- Message on success
  'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  'W',       -- Warn(W), Err(E), Info(I)
  'Y',      -- Y/N/RS - when to print data;
  'Y', -- limit_rows Y/N
  l_info,
	p_include_in_dx_summary => 'Y');


add_signature(	
    'APP_PO_14144', -- Unique Signature identifier	
    'SELECT pol.line_location_id,pol.shipment_num,ail.invoice_id	
     FROM  po_line_locations_all pol,ap_invoice_lines_all ail,(
            ##$$IVIEW$$##
          ) invs	
     WHERE invs.invoice_id=ail.invoice_id
     AND pol.po_header_id= ail.po_header_id	
     AND shipment_type=''PLANNED''	
     AND NOT EXISTS (SELECT ''Scheduled Release''
                     FROM po_line_locations_all porl	
                     WHERE porl.po_header_id=pol.po_header_id	
                     AND porl.SOURCE_SHIPMENT_ID =pol.line_location_id	
                     AND shipment_type =''SCHEDULED'')', -- The text of the signature query	
     'Checking whether Invoice Matched to Planned PO Shipment cannot be validated because of Error APP-PO-14144',     -- Signature title	
     'RS',     -- fail condition: RS, NRS, [col] operand [val]	
     'The invoice(s) matched to above shipments can not be validated because of Error APP-PO-14144.',     -- Problem description	
     'Refer Note- [1579786.1] and apply the solution ',     -- Problem solution	
     ' There is no invoice matched to planned shipments for which shipment releases were not created',      -- Message on success	
     'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER	
     'W',       -- Warn(W), Err(E), Info(I)	
     'Y',      -- Y/N/RS - when to print data;	
     'Y', -- limit_rows Y/N	
     l_info,	
     p_include_in_dx_summary => 'Y');






------------------------------------------------------------------------------
-- POPULATE PAYMENT SIGNATURES
------------------------------------------------------------------------------
 

  


end load_signatures;
-- END LOAD PROCEDURES --


------------------------------------------------------
------------------------------------------------------
-- PUBLIC PROCEDURES
------------------------------------------------------
------------------------------------------------------


------------------------------------------
-- Main process driver and entry point
------------------------------------------

PROCEDURE main(
      p_invoice_id in NUMBER default NULL,
      p_appl_ids in NUMBER default NULL,
      p_max_output_rows in NUMBER default 9999,
      p_debug_mode      in VARCHAR2 default 'Y') IS


  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';

  dbms_output.put_line('You have entered Invoice/Transaction Id as : '||p_invoice_id||'');
  dbms_output.put_line('You have entered Application ID as : '||p_appl_ids||'');

  initialize_files;

  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called  

 If p_appl_ids is Null
 Then 
  analyzer_title := 'EBS Payables and EBTax Setup/Data Integrity';
 ELSIF p_appl_ids =200
  Then
   analyzer_title := 'EBS Payables and EBTax Setup including AP Transaction Level Data Integrity';
ELSIF p_appl_ids =222
  Then
   analyzer_title := 'EBS Payables and EBTax Setup including AR Transaction Level Data Integrity';
End If;

  l_step := '20';


--dbms_output.put_line('You have entered Application ID as : '||&p_appl_ids||'');




  
  validate_parameters(p_invoice_id,p_appl_ids,
      p_max_output_rows, p_debug_mode);
      
  l_step := '30';
  print_rep_title(analyzer_title);
  

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Proactive section
  l_step := '60';

  --new
  print_out('<div id="tabCtrl">', 'N');
  
  start_section('Proactive Recommendations');
  l_step := '61';
  IF 
    ((substr(g_rep_info('Apps Version'),1,4) = '12.0') OR 
    (substr(g_rep_info('Apps Version'),1,4) = '12.1')) THEN
     set_item_result(check_rec_patches);
  END IF; 
  l_step := '63';
     --set_item_result(run_stored_sig('IBY_INVALIDS'));
  l_step := '66';
  end_section;


  start_section('EBTax Setup Checks');

      set_item_result( run_stored_sig('1_ZX_File_Vers'));   
      set_item_result( run_stored_sig('2_INVALIDS'));   
      set_item_result( run_stored_sig('3_Miss_TAX'));   
      set_item_result( run_stored_sig('4_No_TAX'));   
      set_item_result( run_stored_sig('5_Miss_Tax_Rate'));   
      set_item_result( run_stored_sig('6_Miss_TAX_STATUS'));   
      set_item_result( run_stored_sig('7_RR_info'));   
      set_item_result( run_stored_sig('8_AUTO_TAX_CALC_NO'));   
      set_item_result( run_stored_sig('9_TAXREGIME'));   

      set_item_result( run_stored_sig('10_ACCT_FLEX'));   
      set_item_result( run_stored_sig('11_ZX_TRX_BIZ_FC_CODE_NOT_EXIST'));   
      set_item_result( run_stored_sig('12_RECOVERY'));   
      set_item_result( run_stored_sig('13_Tax_Tolerance'));   
      set_item_result( run_stored_sig('14_TAX_Code'));   
      
      set_item_result( run_stored_sig('15_Event_CLASS'));   
      set_item_result( run_stored_sig('16_P_Tax_Codes'));   
      set_item_result( run_stored_sig('17_AP_Tax_Group'));
      set_item_result( run_stored_sig('17_AR_Tax_Group'));   
      set_item_result( run_stored_sig('18_use_tax_classification_flag'));   
      set_item_result( run_stored_sig('19_TAX_Rep_Codes'));   
      set_item_result( run_stored_sig('20_TAX_dist_sync_check'));   
      set_item_result( run_stored_sig('21_Rep_Code_ID'));   
      set_item_result( run_stored_sig('22_ZX_PARTY_TAX_PROFILE'));   
      set_item_result( run_stored_sig('23_ALLOW_RATE_OVERRIDE_FLAG'));   
      set_item_result( run_stored_sig('24_TAX_CLASS'));   
      set_item_result( run_stored_sig('25_Jurisd_dates'));   
      set_item_result( run_stored_sig('26_AUTO_TAX_CALC_FLAG_NO'));   
      set_item_result( run_stored_sig('27_DEFAULT_FLG_EFF_TO'));   
      set_item_result( run_stored_sig('29_Seeded_Tax'));   
      set_item_result( run_stored_sig('30_duplic_Tax_classif')); 
      set_item_result( run_stored_sig('31_duplic_Tax_classif'));
      set_item_result( run_stored_sig('32_wrong_rounding_rule'));
      set_item_result( run_stored_sig('33_status_dates'));

      
 
     
  end_section;

  IF (p_appl_Ids is NOT NULL and p_invoice_id is NOT NULL)

  THEN
  

    IF p_appl_ids =200
    THEN
      start_section('Payables Tax Reporting Issues');
      set_item_result( run_stored_sig('32_No_Legal_Reporting_Status_AP'));
      set_item_result( run_stored_sig('36_Null_Acct_Tax_Dists_AP'));
      set_item_result( run_stored_sig('37_No_XDL_Tax_Dists_AP'));
      set_item_result( run_stored_sig('40_Incorrect_Offset_Tax_AP'));
      set_item_result( run_stored_sig('41_Incorrect_HQ_Reg_AP'));
      set_item_result( run_stored_sig('42_Incorrect_ESTB_ID_AP'));
      end_section;

     start_section('Invoice Checks');

        
      set_item_result( run_stored_sig('1_Eff_Payment'));
      set_item_result( run_stored_sig('2_Selected_Payment'));   
      set_item_result( run_stored_sig('3_Credited_Invoice'));
      set_item_result( run_stored_sig('4_Prepay_Applied'));
      set_item_result( run_stored_sig('5_PO_Finally_Closed'));
      set_item_result( run_stored_sig('6_PO_Negative_Billed'));
      set_item_result( run_stored_sig('7_ENC_Unapproved_PO'));
      set_item_result( run_stored_sig('8_AP_AR_Netting'));
      set_item_result( run_stored_sig('9_DIST_ACCT_Invalid1'));
      set_item_result( run_stored_sig('9_DIST_ACCT_Invalid2'));
      set_item_result( run_stored_sig('10_PO_MATCHING_REQUIRED'));
      set_item_result( run_stored_sig('11_NO_EXCHANGE_RATE'));
      set_item_result( run_stored_sig('12_DIST_VARIANCE_HOLD'));
      set_item_result( run_stored_sig('13_LINE_VARIANCE_HOLD'));
      set_item_result( run_stored_sig('APP_PO_14144'));

      
     
  end_section;


    END IF;

    IF p_appl_ids =222
    THEN
      start_section('Receivables Tax Reporting Issues');   
      set_item_result( run_stored_sig('32_No_Legal_Reporting_Status_AR')); 
      set_item_result( run_stored_sig('33_Null_Vat_Registration')); 
      set_item_result( run_stored_sig('33_Null_Vat_Registration_Site'));
      set_item_result( run_stored_sig('34_Null_Tax_Link_Id'));
      set_item_result( run_stored_sig('35_Null_Tax_Link_Id_Adjustment'));
      set_item_result( run_stored_sig('36_Null_Acct_Tax_Dists_AR'));
      set_item_result( run_stored_sig('37_No_XDL_Tax_Dists_AR'));
      set_item_result( run_stored_sig('38_Tax_Status_Incomplete_AR'));
      set_item_result( run_stored_sig('39_Third_Party_Acct_Mismatch_AR'));
      set_item_result( run_stored_sig('41_Incorrect_HQ_Reg_AR'));
     end_section;
   END IF;
 
END IF;

 



start_section('Payables Setup Checks');
  set_item_result( run_stored_sig('2_INVALIDS_AP'));
  set_item_result( run_stored_sig('2_Pay_File_Ver'));
  set_item_result( run_stored_sig('1_FIN_OPTIONS_SOB_Mismatch'));   
  set_item_result( run_stored_sig('1_Missing_Payment_Doc'));
  set_item_result( run_stored_sig('2_Orphan_Ext_Bank_Account'));
  set_item_result( run_stored_sig('3_Ext_Bank_Account_Exists'));
  set_item_result( run_stored_sig('4_Upgrade_Bank_Account_Assignments'));
  set_item_result( run_stored_sig('5_Supplier_Bank_Account_Inactive'));
  set_item_result( run_stored_sig('6_No_Alternate_Bank_Account'));
  set_item_result( run_stored_sig('7_Multiple_Primary_Bank_Account'));
  set_item_result( run_stored_sig('8_Multiple_Bank_Account_Instr_Assignments'));
  set_item_result( run_stored_sig('9_Duplicate_Ext_Bank_Account'));
  set_item_result( run_stored_sig('10_Dup_Pay_Profile'));
  set_item_result( run_stored_sig('1_IBY_BANK_CHARGE_BEARER'));  
  set_item_result( run_stored_sig('2_DUP_EMP_ID'));
  set_item_result( run_stored_sig('3_MISMATCH_AWT_SITE'));
  set_item_result( run_stored_sig('4_DUP_PARTY_SITE_NAME'));
  set_item_result( run_stored_sig('5_NO_DEFAULT_PAY_METHOD'));
  set_item_result( run_stored_sig('6_AR_Orphan_BA_Assign'));
  set_item_result( run_stored_sig('7_Dup_Invoice_Supplier_Merge'));

end_section;





  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  print_out('<a href="https://community.oracle.com/message/12218512#12218512" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
 
  close_files;   

EXCEPTION WHEN OTHERS THEN
  g_errbuf := 'Error in procedure MAIN (step: '||l_step||') '||sqlerrm;
  g_retcode := '2';
  print_log(g_errbuf);
  print_error(g_errbuf||' See log file for more details.');
  close_files;
END main;

--------------------------------------
-- Entry point for concurrent process
--------------------------------------

PROCEDURE main_cp (
	  errbuf            out VARCHAR2,
      retcode           out VARCHAR2,	
      p_invoice_id in NUMBER default NULL,
      p_appl_ids in NUMBER default NULL,
      p_max_output_rows in NUMBER default 9999,
      p_debug_mode      in VARCHAR2 default 'Y') IS
	  
BEGIN
  g_retcode := 0;
  g_errbuf := null;

  main(
      p_invoice_id => p_invoice_id, 
      p_appl_ids => p_appl_ids,
      p_max_output_rows  => p_max_output_rows,
      p_debug_mode => p_debug_mode);

      retcode := g_retcode;
      errbuf := g_errbuf;

EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


END; -- Package body
/
show errors

exit;