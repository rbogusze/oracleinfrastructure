SET DEFINE '~'

REM +=======================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                 |
REM |                    Redwood Shores, California, USA                    |
REM |                         All rights reserved.                          |
REM +=======================================================================+
REM | Framework 3.0.26                                                      |
REM |                                                                       |
REM | FILENAME                                                              |
REM |   ap_trial_balance_analyzer.sql (was ap_aptb_detect_pkg.sql)          |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM |   Script to diagnose APTB related issues.                             |
REM |   Doc ID 1553507.1                                                    |
REM |                                                                       |
REM | HISTORY                                                               |
REM |   17-Jan-2013 SKPASUPU Created                                        |
REM |   03-Jun-2013 SKPASUPU Concurrent Program Enabled                     |
REM |   25-Jun-2013 SKPASUPU Validations added on parameters                |
REM |   06-Aug-2013 SKPASUPU Liability Account entered instead of CCID      |
REM |   16-Oct-2013 SKPASUPU Enhancements on TBH                            |
REM |   10-Jan-2014 ALUMPE   Remove unused p_resp parameter, fix parameter  |
REM |                        sort order in output, include account param    | 
REM |                        instead of just CCID, fixed parameter logging  | 
REM |   15-Jan_2014 DAMAL    Add check for Ledgr_id in Undo and Daterange   |
REM |                        modes and add it in the error for missing      |
REM |                        required parameters. Fixed issue with 12382509 |
REM |   29-Jan-2014 DAMAL    Changed 'Helper' to 'Analyzer'                 | 
REM |   12-Jun-2014 AROBERT  Added condition to NON_PAYABLES_SOURCE_IN_GL   | 
REM |                        for period_name                                |
REM |                        Changed 11iTB_DATA_NOT_IN_11iACCNTD_TABLES     |
REM |                        so FUTURE lines are not returned               |
REM |                        Added GL_TRANSFERRED_FUTURE_LINE_DATA_MISSING  |
REM |                        _FROM_TRIAL_BALANCE                            | 
REM |   18-Jun-2014 AROBERT  Added validation to verify AP_UNDO_EVENT_LOG   | 
REM |                        table exist for Undo mode                      | 
REM |   19-Jun-2014 ALUMPE   Fixed the grammar and capitalization in many   | 
REM |                        of the titles and problem descriptions         | 
REM |   31-MAR-2015 AROBERT  Converted to framework v3                      |
REM |   20-APR-2014 SHORGAN  Added ledger_id and balance_type_code condition| 
REM |                        to problem signagure                           | 
REM |                        DATA_WITH_INCORRECT_AMOUNT_BETWEEN_AP_AND_XLA  | 
REM |   06-MAY-2015 AROBERT  Fixed recommended 12.2 patches which is none   |
REM |                        right now                                      | 
REM +=======================================================================+


CREATE OR REPLACE PACKAGE AP_APTB_DETECT_PKG AUTHID CURRENT_USER AS

TYPE section_rec IS RECORD(
  name           VARCHAR2(255),
  result         VARCHAR2(1), -- E,W,S
  error_count    NUMBER,
  warn_count     NUMBER,
  success_count  NUMBER,
  print_count    NUMBER);

TYPE rep_section_tbl IS TABLE OF section_rec INDEX BY BINARY_INTEGER;
TYPE hash_tbl_2k     IS TABLE OF VARCHAR2(2000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_4k     IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(255);
TYPE hash_tbl_8k     IS TABLE OF VARCHAR2(8000) INDEX BY VARCHAR2(255);
TYPE col_list_tbl    IS TABLE OF DBMS_SQL.VARCHAR2_TABLE;
TYPE varchar_tbl     IS TABLE OF VARCHAR2(255);

TYPE signature_rec IS RECORD(
  sig_sql          VARCHAR2(32000),
  title            VARCHAR2(255),
  fail_condition   VARCHAR2(4000),
  problem_descr    VARCHAR2(4000),
  solution         VARCHAR2(4000),
  success_msg      VARCHAR2(4000),
  print_condition  VARCHAR2(8),
  fail_type        VARCHAR2(1),
  print_sql_output VARCHAR2(2),
  limit_rows       VARCHAR2(1),
  extra_info       HASH_TBL_4K,
  child_sigs       VARCHAR_TBL := VARCHAR_TBL(),
  include_in_xml   VARCHAR2(1));

TYPE signature_tbl IS TABLE OF signature_rec INDEX BY VARCHAR2(255);

-------------------------------------
-- Procedure and function definitions
-------------------------------------

----------------------------------------------------
-- Main entry point to date range concurrent process
----------------------------------------------------
PROCEDURE main_cp(
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_mode       IN VARCHAR2 DEFAULT NULL,
      p_ledger_id  IN NUMBER DEFAULT NULL,
      p_org_ids    IN VARCHAR2 DEFAULT NULL,
      p_tb_code    IN VARCHAR2 DEFAULT NULL,
      p_start_date IN VARCHAR2 DEFAULT NULL,
      p_end_date   IN VARCHAR2 DEFAULT NULL,
      p_invoice_id IN NUMBER DEFAULT NULL,
      p_liab_acc   IN varchar2 DEFAULT NULL,
      p_max_output_rows IN NUMBER   DEFAULT 200,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y');

-----------------------------------------
-- Main entry point to standalone process
-----------------------------------------
PROCEDURE main(
      p_org_ids    IN VARCHAR2 DEFAULT NULL,
      p_mode       IN VARCHAR2 DEFAULT NULL,
      p_ledger_id  IN NUMBER DEFAULT NULL,
      p_invoice_id IN NUMBER DEFAULT NULL,
      p_tb_code    IN VARCHAR2 DEFAULT NULL,
      p_liab_acc   IN varchar2 DEFAULT NULL,
      p_start_date IN VARCHAR2 DEFAULT NULL,
      p_end_date   IN VARCHAR2 DEFAULT NULL,
      p_max_output_rows IN NUMBER   DEFAULT 200,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y');
	  
END AP_APTB_DETECT_PKG;
/
show errors

CREATE OR REPLACE PACKAGE BODY APPS.AP_APTB_DETECT_PKG AS
-- $Id: AP_APTB_DETECT_PKG.sql, 200.4 2015/08/11 22:37:27 arobert Exp $

----------------------------------
-- Global Variables             --
----------------------------------
g_sect_no NUMBER := 1;
g_log_file         UTL_FILE.FILE_TYPE;
g_out_file         UTL_FILE.FILE_TYPE;
g_print_to_stdout  VARCHAR2(1) := 'N';
g_is_concurrent    BOOLEAN := (to_number(nvl(FND_GLOBAL.CONC_REQUEST_ID,0)) >  0);
g_debug_mode       VARCHAR2(1);
g_max_output_rows  NUMBER := 10;
g_family_result    VARCHAR2(1);
g_errbuf           VARCHAR2(1000);
g_retcode          VARCHAR2(1);

g_query_start_time TIMESTAMP;
g_query_elapsed    INTERVAL DAY(2) TO SECOND(3);
g_analyzer_start_time TIMESTAMP;
g_analyzer_elapsed    INTERVAL DAY(2) TO SECOND(3);

g_signatures      SIGNATURE_TBL;
g_sections        REP_SECTION_TBL;
g_section_toc	  VARCHAR2(32767);
g_section_sig     NUMBER;
sig_count         NUMBER;
g_sql_tokens      HASH_TBL_2K;
g_rep_info        HASH_TBL_2K;
g_parameters      HASH_TBL_2K;
g_exec_summary      HASH_TBL_2K;
g_item_id         INTEGER := 0;
g_sig_id        INTEGER := 0;
g_parent_sig_id   INTEGER := 0;
g_parent_sig_count NUMBER;
analyzer_title VARCHAR2(255);
g_mos_patch_url   VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/ui/patch/PatchDetail.jspx?patchId=';
g_mos_doc_url     VARCHAR2(255) :=
  'https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1553507.1&id=';
g_hidden_xml      XMLDOM.DOMDocument;
g_preserve_trailing_blanks BOOLEAN := false;


----------------------------------------------------------------
-- Debug, log and output procedures                          --
----------------------------------------------------------------

PROCEDURE enable_debug IS
BEGIN
  g_debug_mode := 'Y';
END enable_debug;

PROCEDURE disable_debug IS
BEGIN
  g_debug_mode := 'N';
END disable_debug;

PROCEDURE print_log(p_msg IN VARCHAR2) is
BEGIN
  IF NOT g_is_concurrent THEN
    utl_file.put_line(g_log_file, p_msg);
    utl_file.fflush(g_log_file);
  ELSE
    fnd_file.put_line(FND_FILE.LOG, p_msg);
  END IF;

  IF (g_print_to_stdout = 'Y') THEN
    dbms_output.put_line(substr(p_msg,1,254));
  END IF;
EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line(substr('Error in print_log: '||sqlerrm,1,254));
  raise;
END print_log;

PROCEDURE debug(p_msg VARCHAR2) is
 l_time varchar2(25);
BEGIN
  IF (g_debug_mode = 'Y') THEN
    l_time := to_char(sysdate,'DD-MON-YY HH24:MI:SS');

    IF NOT g_is_concurrent THEN
      utl_file.put_line(g_log_file, l_time||'-'||p_msg);
    ELSE
      fnd_file.put_line(FND_FILE.LOG, l_time||'-'||p_msg);
    END IF;

    IF g_print_to_stdout = 'Y' THEN
      dbms_output.put_line(substr(l_time||'-'||p_msg,1,254));
    END IF;

  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in debug');
  raise;
END debug;


PROCEDURE print_out(p_msg IN VARCHAR2
                   ,p_newline IN VARCHAR  DEFAULT 'Y' ) is
BEGIN
  IF NOT g_is_concurrent THEN
    IF (p_newline = 'N') THEN
       utl_file.put(g_out_file, p_msg);
    ELSE
       utl_file.put_line(g_out_file, p_msg);
    END IF;
    utl_file.fflush(g_out_file);
  ELSE
     IF (p_newline = 'N') THEN
        fnd_file.put(FND_FILE.OUTPUT, p_msg);
     ELSE
        fnd_file.put_line(FND_FILE.OUTPUT, p_msg);
     END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_out');
  raise;
END print_out;


PROCEDURE print_error (p_msg VARCHAR2) is
BEGIN
  print_out('<div class="diverr">'||p_msg);
  print_out('</div>');
END print_error;



----------------------------------------------------------------
--- Time Management                                          ---
----------------------------------------------------------------

PROCEDURE get_current_time (p_time IN OUT TIMESTAMP) IS
BEGIN
  SELECT localtimestamp(3) INTO p_time
  FROM   dual;
END get_current_time;

FUNCTION stop_timer(p_start_time IN TIMESTAMP) RETURN INTERVAL DAY TO SECOND IS
  l_elapsed INTERVAL DAY(2) TO SECOND(3);
BEGIN
  SELECT localtimestamp - p_start_time  INTO l_elapsed
  FROM   dual;
  RETURN l_elapsed;
END stop_timer;

FUNCTION format_elapsed (p_elapsed IN INTERVAL DAY TO SECOND) RETURN VARCHAR2 IS
  l_days         VARCHAR2(3);
  l_hours        VARCHAR2(2);
  l_minutes      VARCHAR2(2);
  l_seconds      VARCHAR2(6);
  l_fmt_elapsed  VARCHAR2(80);
BEGIN
  l_days := EXTRACT(DAY FROM p_elapsed);
  IF to_number(l_days) > 0 THEN
    l_fmt_elapsed := l_days||' days';
  END IF;
  l_hours := EXTRACT(HOUR FROM p_elapsed);
  IF to_number(l_hours) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_hours||' Hrs';
  END IF;
  l_minutes := EXTRACT(MINUTE FROM p_elapsed);
  IF to_number(l_minutes) > 0 THEN
    IF length(l_fmt_elapsed) > 0 THEN
      l_fmt_elapsed := l_fmt_elapsed||', ';
    END IF;
    l_fmt_elapsed := l_fmt_elapsed || l_minutes||' Min';
  END IF;
  l_seconds := EXTRACT(SECOND FROM p_elapsed);
  IF length(l_fmt_elapsed) > 0 THEN
    l_fmt_elapsed := l_fmt_elapsed||', ';
  END IF;
  l_fmt_elapsed := l_fmt_elapsed || l_seconds||' Sec';
  RETURN(l_fmt_elapsed);
END format_elapsed;


----------------------------------------------------------------
--- File Management                                          ---
----------------------------------------------------------------

PROCEDURE initialize_files is
  l_date_char        VARCHAR2(20);
  l_log_file         VARCHAR2(200);
  l_out_file         VARCHAR2(200);
  l_file_location    V$PARAMETER.VALUE%TYPE;
  l_instance         VARCHAR2(40);
  l_host         VARCHAR2(40);
  NO_UTL_DIR         EXCEPTION;
  
BEGIN
get_current_time(g_analyzer_start_time);

  IF NOT g_is_concurrent THEN

    SELECT to_char(sysdate,'YYYY-MM-DD_hh_mi') INTO l_date_char from dual;
	
	SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

    l_log_file := 'AP_TB_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.log';
    l_out_file := 'AP_TB_Analyzer_'||l_host||'_'||l_instance||'_'||l_date_char||'.html';

    SELECT decode(instr(value,','),0,value,
           SUBSTR (value,1,instr(value,',') - 1))
    INTO   l_file_location
    FROM   v$parameter
    WHERE  name = 'utl_file_dir';

	-- Set maximum line size to 10000 for encoding of base64 icon
    IF l_file_location IS NULL THEN
      RAISE NO_UTL_DIR;
    ELSE
      g_out_file := utl_file.fopen(l_file_location, l_out_file, 'w',10000);
      g_log_file := utl_file.fopen(l_file_location, l_log_file, 'w',10000);
    END IF;

    dbms_output.put_line('Files are located on Host : '||l_host);
	dbms_output.put_line('Output file : '||l_file_location||'/'||l_out_file);
    dbms_output.put_line('Log file:     '||l_file_location||'/'||l_log_file);
  END IF;
EXCEPTION
  WHEN NO_UTL_DIR THEN
    dbms_output.put_line('Exception: Unable to identify a valid output '||
      'directory for UTL_FILE in initialize_files');
    raise;
  WHEN OTHERS THEN
    dbms_output.put_line('Exception: '||sqlerrm||' in initialize_files');
    raise;
END initialize_files;


PROCEDURE close_files IS
BEGIN
  debug('Entered close_files');
  print_out('</BODY></HTML>');
  IF NOT g_is_concurrent THEN
    debug('Closing files');
    utl_file.fclose(g_log_file);
    utl_file.fclose(g_out_file);
  END IF;
END close_files;


----------------------------------------------------------------
-- REPORTING PROCEDURES                                       --
----------------------------------------------------------------

----------------------------------------------------------------
-- Prints HTML page header and auxiliary Javascript functions --
-- Notes:                                                     --
-- Looknfeel styles for the o/p must be changed here          --
----------------------------------------------------------------

PROCEDURE print_page_header is
BEGIN
  -- HTML header
  print_out('
<HTML><HEAD>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">');

  -- Page Title
  print_out('<TITLE>Analyzer Report</TITLE>');

  -- Styles
  print_out('
<STYLE type="text/css">
body {
  background-color:#ffffff;
  font-family:Arial;
  font-size:12pt;
  margin-left: 30px;
  margin-right: 30px;
  margin-top: 25px;
  margin-bottom: 25px;
}
tr {
  font-family: Tahoma, Helvetica, Geneva, sans-serif;
  font-size: small;
  color: #3D3D3D;
  background-color: white;
  padding: 5px;
}
tr.top {
  vertical-align:top;
}
tr.master {
  padding-bottom: 20px;
  background-color: white;
}
th {
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  text-align: left;
  background-color: #BED3E9;
  color: #3E3E3E;
  padding: 5px;
}
th.master {
  font-family: Arial, Helvetica, sans-serif;
  padding-top: 10px;
  font-size: inherit;
  background-color: #BED3E9;
  color: #35301A;
}
th.rep {
  white-space: nowrap;
  width: 5%;
}
td {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  background-color: inherit;
  text-indent: 0px;
}
td.hlt {
  padding: inherit;
  font-family: inherit;
  font-size: inherit;
  font-weight: bold;
  color: #333333;
  background-color: #FFE864;
  text-indent: 0px;
}

a {color: #0066CC;}
a:visited { color: #808080;}
a:hover { color: #0099CC;}
a:active { color: #0066CC;}

.detail {
  text-decoration:none;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.detailsmall {
  text-decoration:none;
  font-size: xx-small;
}
.table1 {
   border: 1px solid #EAEAEA;
  vertical-align: middle;
  text-align: left;
  padding: 3px;
  margin: 1px;
  width: 100%;
  font-family: Arial, Helvetica, sans-serif;
  border-spacing: 1px;
  background-color: #F5F5F5;
}
.toctable {
  background-color: #F4F4F4;
}
.TitleBar {
font-family: Calibri;
background-color: #152B40;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
color: #F4F4F4;
font-size: xx-large;
font-weight: bold;
overflow:hidden;
}
.TitleImg {
float: right;
vertical-align: top;
padding-top: -10px;
}

.Title1{
font-size: xx-large;
}

.Title2{
font-size: medium;
}
.divSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #CCCCCC;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow:hidden;
}
.divSectionTitle {
width: 98.5%;
font-family: Calibri;
font-weight: bold;
background-color: #152B40;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
overflow:hidden;
}
.columns       { 
width: 98.5%; 
font-family: Calibri;
font-weight: bold;
background-color: #254B72;
color: #FFFFFF;
padding: 9px;
margin: 0px;
box-shadow: 3px 3px 3px #AAAAAA;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
height: 30px;
}
div.divSectionTitle div   { height: 30px; float: left; }
div.left          { width: 75%; background-color: #152B40; font-size: x-large; border-radius: 6px; }
div.right         { width: 25%; background-color: #152B40; font-size: medium; border-radius: 6px;}
div.clear         { clear: both; }
<!--End BBURBAGE code for adding the logo into the header -->
.sectHideShow {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}

.sectHideShowLnk {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  background-color: #254B72;
  color: #1D70AD;
}
.divSubSection {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #E4E4E4;
  border: 1px solid #DADADA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divSubSectionTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: large;
  font-weight: bold;
  background-color: #888888;
  color: #FFFFFF;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divItem {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #F4F4F4;
  border: 1px solid #EAEAEA;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
}
.divItemTitle {
  font-family: Arial, Helvetica, sans-serif;
  font-size: medium;
  font-weight: bold;
  color: #336699;
  border-bottom-style: solid;
  border-bottom-width: medium;
  border-bottom-color: #3973AC;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divwarn {
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  font-family: Arial, Helvetica, sans-serif;
  color: #333333;
  background-color: #FFEF95;
  border: 0px solid #FDC400;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  font-size: small;
}
.divwarn1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #9B7500;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.diverr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: white;
  background-color: #F04141;
  box-shadow: 3px 3px 3px #AAAAAA;
   -moz-border-radius: 6px;
   -webkit-border-radius: 6px;
  border-radius: 6px;
  margin: 3px;
}
.divuar {
  border: 0px solid #CC0000;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #FFD8D8;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divuar1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divok {
  border: 1px none #00CC99;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: normal;
  background-color: #ECFFFF;
  color: #333333;
  padding: 9px;
  margin: 3px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divok1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #006600;
  margin-bottom: 9px;
  padding-bottom: 2px;
  margin-left: 3px;
  margin-right: 3px;
}
.divsol {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: #D9E6F2;
  color: #333333;
  padding: 9px;
  margin: 0px;
  box-shadow: 3px 3px 3px #AAAAAA;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
}
.divtable {
  font-family: Arial, Helvetica, sans-serif;
  box-shadow: 3px 3px 3px #AAAAAA;
  overflow: auto;
}
.graph {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.graph tr {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  background-color: transparent;
}
.baruar {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #CC0000;
  background-color: transparent;
}
.barwarn {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  font-weight: bold;
  color: #B38E00;
  background-color: transparent;
}
.barok {
  border-style: none;
  background-color: white;
  text-align: right;
  padding-right: 0.5em;
  width: 300px;
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
  color: #25704A;
  font-weight: bold;
  background-color: transparent;
}
.baruar div {
  border-top: solid 2px #0077DD;
  background-color: #FF0000;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FF9999;
  border-bottom-color: #CC0000;
}
.barwarn div {
  border-top: solid 2px #0077DD;
  background-color: #FFCC00;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #FFFF66;
  border-bottom-color: #ECBD00;
}
.barok div {
  border-top: solid 2px #0077DD;
  background-color: #339966;
  border-bottom: solid 2px #002266;
  text-align: right;
  color: white;
  float: left;
  padding-top: 0;
  height: 1em;
  font-family: Arial, Helvetica, sans-serif;
  font-size: x-small;
  border-top-color: #00CC66;
  border-bottom-color: #006600;
}
span.errbul {
  color: #EE0000;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
span.warbul {
  color: #FFAA00;
  font-size: large;
  font-weight: bold;
  text-shadow: 1px 1px #AAAAAA;
}
.legend {
  font-weight: normal; 
  color: #0000FF; 
  font-size: 9pt; 
  font-weight: bold
}
.solution {
  font-weight: normal; 
  color: #0000FF; 
 font-size: small; 
  font-weight: bold
}
.regtext {
  font-weight: normal; 
 font-size: small; 
}
.btn {
	display: inline-block;
	border: #000000;
	border-style: solid; 
	border-width: 2px;
	width:190px;
	height:54px;
	border-radius: 6px;	
	background: linear-gradient(#FFFFFF, #B0B0B0);
	font-weight: bold;
	color: blue; 
	margin-top: 5px;
    margin-bottom: 5px;
    margin-right: 5px;
    margin-left: 5px;
	vertical-align: middle;
}  

</STYLE>');
  -- JS and end of header
  print_out('
<script type="text/javascript">

   function activateTab(pageId) {
	     var tabCtrl = document.getElementById(''tabCtrl'');
	       var pageToActivate = document.getElementById(pageId);
	       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
	           var node = tabCtrl.childNodes[i];
	           if (node.nodeType == 1) { /* Element */
	               node.style.display = (node == pageToActivate) ? ''block'' : ''none'';
	           }
	        }
	   }

	   
   function displayItem(e, itm_id) {
     var tbl = document.getElementById(itm_id);
	 if (tbl == null) {
       if (e.innerHTML == e.innerHTML.replace(
             String.fromCharCode(9660),
             String.fromCharCode(9654))) {
       e.innerHTML =
         e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
       }
       else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654))
       }
     }
     else {
       if (tbl.style.display == ""){
          e.innerHTML =
             e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none"; }
       else {
          e.innerHTML =
            e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
          e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
          tbl.style.display = ""; }
     }
   }
   
   
   //Pier: changed function to support automatic display if comming from TOC
   function displaySection(ee,itm_id) { 
 
     var tbl = document.getElementById(itm_id + ''contents'');
     var e = document.getElementById(''showhide'' + itm_id + ''contents'');

     if (tbl.style.display == ""){
        // do not hide if coming from TOC link
        if (ee != ''TOC'') {
          e.innerHTML =
          e.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654));
          e.innerHTML = e.innerHTML.replace("Hide SQL","Show SQL");
          tbl.style.display = "none";
        } 
     } else {
         e.innerHTML =
           e.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
         e.innerHTML = e.innerHTML.replace("Show SQL","Hide SQL");
         tbl.style.display = ""; }
     //Go to section if comming from TOC
     if (ee == ''TOC'') {
       window.location.hash=''sect'' + itm_id;
     }
   }
</script>');
-- JQuery for icons
print_out('
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

var src = $(''img#error_ico'').attr(''src'');
$(''img.error_ico'').attr(''src'', src);

var src = $(''img#warn_ico'').attr(''src'');
$(''img.warn_ico'').attr(''src'', src);

var src = $(''img#check_ico'').attr(''src'');
$(''img.check_ico'').attr(''src'', src);
	});
</script>'); 
 
     print_out('</HEAD><BODY>');
	 
 
-- base64 icons definition	 
 --error icon
  print_out('<div style="display: none;">');
    print_out('<img id="error_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMi1jMDAxIDYzLjEzOTQzOSwgMjAxMC8xMC8xMi0wODo0NTozMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDExLjAgV2luZG93cyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDNEY2MDBGRjlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDNEY2MDEwMDlDRjMxMUU0OUM5M0EyMkI2RkNEMkQyMiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM0RjYwMEZEOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkM0RjYwMEZFOUNGMzExRTQ5QzkzQTIyQjZGQ0QyRDIyIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+X+gwwwAAAspJREFUeNpUk11Ik1EYx/9nbrNJfi6dCm1aF0poF4UaNNgs6YtIigiC6EJCAonsJgiKriOwi7qrSCOCCCWlG015Z4o6XasuJOdHtPArTbN0m9v7nvf0nNdpeeDh7OP9/Z///znnZUIIbK5GxnI5cEYHajSggspFFaYaoepWgY42IRbx32KbAgQfJfDaqfMna8s8buwqKYU1IxORqRC+B4MYHAygdeBzFwk1vROic5vADYILnYUPzjXUle9xOgB/D/iXIPjcDIQ9D8LhhO7Yjb6JWTzv+zg+vhq7FRCizRBoBKTtx9fv3a7dG5uD3t4MwTk4GdPJkty5sTMKVILu3wL3/aH+H8CVsBAhk8wsbcvOekczWP0dsCfKNjitRUFqw13EKc7hNAGvI8NtAy4xxqwmylQjM0vbukZyBz0wVXhheaYYAhI2V3qpPCQmoC8uoDzdAhPgoQT5qAcmY12tQj3uFPFyiFgZhDasCLlU/8YeH1LEdDFE2AXxtdgi+kvtYh8wRwIHpAOXNTMbYn4GetJy9HI1tGGf0Tnh92HxYvXGHKi0hIosroIezSWBLCkQjk6NQc/JMwRk2ZK2JWyt8sL+UoFGsCqLzM9GErRD3oc0KTASDn6AyHcaHWzN/+Cf1Dk+5MOOQ14UvFKM/3VhwmhUkwITJBCVAt1DAwHjrOVRqf7eLVgjN7MXqhEb9CEy0GsIqPRbIMaxDnwigRV2lrLQlxeNp93HKrUlJCbHwGn8EpaHoiWPU37mLAXtEeDpKvcvAI+Ie2+Sd5vsNLXQDev5QxaLSqBn5tDDFmhg0AjizAw1xWLAbyJ8ag14S3CIHMxvvQsVjJ2gu1Z3pCDLvT/durPIClsO18zTkThG1xLaSJSv9q3rPQR3LgNBQr4Ru8z+fxtdjKVWATcL7dlXV5Z+ZafQTGlGCwmKHqeYZur4GngIOcsk+FeAAQAH74+14hNYkgAAAABJRU5ErkJggg==" alt="error_ico">');
 --warning icon
    print_out('<img title="warning" id="warn_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAOCAYAAAAmL5yKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33'||
	'jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAfBJREFUeNp8kd1L02EUxz/nt5EjlZY25ksktQWhZZEaKtoqUEYLzcLCNCQ3gq4y8QX0WvItrD8gyG6CoCzIKy8rDEQIoasoCqxFhBBERWzndDHcKtcOfHngPM/3jUfMjGxz86I8VKVDlfnBe3aG/42ZbcJsD5GluxEzM3t2J2Ld9fRne2dmOFmcXYh74nDbdVgWSvIW2OOj37tVyrIF2CSgSrS1q2//ll9LAAQCUF9LRfshBkREcla4cYGCW5cKPyR/rNlkLN9ix8Um+8Tij7Gxk3wJ+qjMWUGVgbbotTJn/TYrL7/z5j2srEKJD442UNwcZERE3FkrzHRJef72ncMVtZchPo3fl9r7dwAKjTXgL+RcXQUNWQVUGeu4Mpovn8ZBvxEOpb433GyQhAIPtDbhqS5lREQ8GzwxM6bOS2VRedVqbPy+i1fVoElIppxJZqAJGJlCX7zj7NO39iidQJWpzquTLtaG0+S5B9AzKMzNZwQchfZjOPt8jIpIIYAz0SmhmlAosq2oANYX0s6Lz4WPn2FxSTIpEtB0AA7upu5EgG4AR5WhhtNDEJ8Gy8RuqTfKfNByxNLkDaHGKtjlJSoixW5VauX1KfD80VmhNwK94X/IidTd3lLIcwgCAbcqT2ZmiapCLpj9fX79yTLg/T0AA6H+hDXGjwAAAAAASUVORK5CYII=" alt="warn_ico">');
  --check icon
    print_out('<img id="check_ico" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAANCAYAAACgu+4kAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83Mz'||
	'aLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAMRJREFUeNqkkjEOgkAQRd96GY7gAajEWBALEzXRhHAJqr0Dd/AqJFZa2dnZSGVjY/EtkEUC0UU3mWYz7/3J7hhJ/HNGQ5rN1lizNjILY92lJK9ig2WFinshYkRILonh8J6qIgQEv8NjdsCsakqxpIgU24GXH2AIHFw8Cr1LWsmHfrj6wRouUXbLRIKYk7vk4wuedOFaUI1f0kg8kp3AvUGCuCDOKLtmX5NbAknUY3OigaPPcGcPmJIT+8O9i0RI7gtL4jkALy1qUf+xbKAAAAAASUVORK5CYII=" alt="check_ico">');
   print_out('</div>');

END print_page_header;
	 
----------------------------------------------------------------
-- Prints report title section                                --
-- ===========================                                --
-- To change look & feel:                                     --
-- Change css class divtitle which is the container box and   --
-- defines the backgrownd color and first line font           --
-- Change css class divtitle1 which defines the font on the   --
-- testname (second line)                                     --
----------------------------------------------------------------

PROCEDURE print_rep_title(p_analyzer_title varchar2) is
BEGIN

  -- Print title
  print_page_header;
  print_out('<!----------------- Title ----------------->
<div class="TitleBar">
<div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div>
    <div class="Title1">'|| p_analyzer_title || ' Analyzer Report' ||'</div>
    <div class="Title2">Compiled using version ' ||  g_rep_info('File Version') || ' / Latest version: ' || '<a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=1553507.1:CODE">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/aptb_latest_ver.gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div>
</div>
<br>');
END print_rep_title;


----------------------------------------------------------------
-- Prints Report Information placeholder                      --
----------------------------------------------------------------

PROCEDURE print_toc(
  ptoctitle varchar2 DEFAULT 'Report Information') IS
  l_key  VARCHAR2(255);
  l_html VARCHAR2(4000);
BEGIN
  g_sections.delete;
    print_out('<!------------------ TOC ------------------>
    <div class="divSection">');
  -- Print Run details and Parameters Section
  print_out('<div class="divItem" id="runinfo"><div class="divItemTitle">' ||
    'Report Information</div>');
	print_out('<span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span>');
	-- print_out('<p>');  
  print_out(
   '<table width="100%" class="graph"><tbody> 
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,''RunDetails'');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="table1" id="RunDetails" style="display:none">
      <tbody>');
  -- Loop and print values
  l_key := g_rep_info.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_rep_info(l_key)||'</td></tr>');
    l_key := g_rep_info.next(l_key);
  END LOOP;
  print_out('</tbody></table></td>');
  print_out('<td width="30%"><p>
    <a class="detail" href="javascript:;" onclick="displayItem(this,''Parameters'');"><font color="#0066CC">
       &#9654; Parameters</font></a></p>
       <table class="table1" id="Parameters" style="display:none">
       <tbody>');
  l_key := g_parameters.first;
  WHILE l_key IS NOT NULL LOOP
    print_out('<tr><th class="rep">'||l_key||'</th><td>'||
      g_parameters(l_key)||'</td></tr>');
    l_key := g_parameters.next(l_key);
  END LOOP;
    print_out('</tbody></table></td>');  
    print_out('<td width="30%"><p>
    <div id="ExecutionSummary1"><a class="detail" href="javascript:;" onclick="displayItem(this,''ExecutionSummary2'');"><font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none">   </div>');   
 
  print_out('</td></tr></table>
    </div><br/>');

  -- Print out the Table of Contents holder
  print_out('<div class="divItem" id="toccontent"><div class="divItemTitle">' ||
    ptoctitle || '</div></div>
	<div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
	</div></div><br><br>');
END print_toc;

----------------------------------------------------------------
-- Prints report TOC contents at end of script                --
----------------------------------------------------------------

PROCEDURE print_toc_contents(
     p_err_label  VARCHAR2 DEFAULT 'Checks Failed - Critical',
     p_warn_label VARCHAR2 DEFAULT 'Checks Failed - Warning',
     p_pass_label VARCHAR2 DEFAULT 'Checks Passed') IS

  l_action_req BOOLEAN := false;
  l_cnt_err  NUMBER := 0;
  l_cnt_warn NUMBER := 0;
  l_cnt_succ NUMBER := 0;
  l_tot_cnt  NUMBER;
  l_loop_count NUMBER;
     
BEGIN
 
  -- Script tag, assign old content to var, reassign old content and new stuff
  print_out('
<script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs + ');

  l_loop_count := g_sections.count;
	
  -- Loop through sections and generate HTML
  FOR i in 1 .. l_loop_count LOOP
      -- Add to counts
      l_cnt_err := l_cnt_err + g_sections(i).error_count;
      l_cnt_warn := l_cnt_warn + g_sections(i).warn_count;
      l_cnt_succ := l_cnt_succ + g_sections(i).success_count;
      -- Print Section name
		print_out('"<button class=''btn'' OnClick=activateTab(''page' || to_char(i) || ''')>' ||     
        g_sections(i).name || '" +');
      -- Print if section in error, warning or successful
      IF g_sections(i).result ='E' THEN 
	  print_out('" <img class=''error_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
      ELSIF g_sections(i).result ='W' THEN
        print_out('" <img class=''warn_ico''>" +');
        l_action_req := true;
		--g_retcode := 1;
	  ELSIF g_sections(i).result ='S' THEN
        print_out('" <img class=''check_ico''>" +');
        l_action_req := true;
		--g_retcode := 0;
      -- Print end of button
       
    END IF;
	print_out('"</button>" +');
  END LOOP;
  -- End the div
  print_out('"</div>";');
  -- End
  print_out('activateTab(''page1'');');
  
  -- Loop through sections and generate HTML for start sections
    FOR i in 1 .. l_loop_count LOOP
		print_out('auxs = document.getElementById("sect_title'||i||'").innerHTML;
				document.getElementById("sect_title'||i||'").innerHTML = auxs + ');
		if g_sections(i).error_count>0 and g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''>  '||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).error_count>0 then
				print_out(' "'||g_sections(i).error_count||' <img class=''error_ico''> ";');
			elsif g_sections(i).warn_count>0 then
				print_out(' "'||g_sections(i).warn_count||' <img class=''warn_ico''> ";');
			elsif g_sections(i).result ='S' then
				print_out(' " <img class=''check_ico''> ";');
			else
				print_out(' " ";');
			end if;						
	END LOOP;

	-- Loop through sections and generate HTML for execution summary
	print_out('auxs = document.getElementById("ExecutionSummary1").innerHTML;
				document.getElementById("ExecutionSummary1").innerHTML = auxs + ');
	if l_cnt_err>0 and l_cnt_warn>0 then
		print_out(' "('||l_cnt_err||' <img class=''error_ico''> '||l_cnt_warn||' <img class=''warn_ico''>)</A>";');
	elsif l_cnt_err>0 and l_cnt_warn=0 then
		print_out(' "(<img class=''error_ico''>'||l_cnt_err||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn>0 then
		print_out(' "(<img class=''warn_ico''>'||l_cnt_warn||')</A>";');
	elsif l_cnt_err=0 and l_cnt_warn=0 then
		print_out(' "(<img class=''check_ico''> No issues reported)</A>";');
	end if;
		
	print_out('auxs = document.getElementById("ExecutionSummary2").innerHTML;
				document.getElementById("ExecutionSummary2").innerHTML = auxs + ');
	print_out('" <table width=''100%'' class=''table1''><TR><TH class=''rep''><B>Section</B></TH><TH class=''rep''><B>Errors</B></TH><TH class=''rep''><B>Warnings</B></TH></TR>"+');
	  
    FOR i in 1 .. l_loop_count LOOP
			print_out('"<TR><TH class=''rep''><A class=detail onclick=activateTab(''page' || to_char(i) || '''); href=''javascript:;''>'||g_sections(i).name||'</A> "+');
			if g_sections(i).error_count>0 then
				print_out(' "<img class=''error_ico''>"+');
			elsif g_sections(i).warn_count>0 then
				print_out(' "<img class=''warn_ico''>"+');	
			elsif g_sections(i).result ='S' then
				print_out(' "<img class=''check_ico''>"+');
			end if;	
			print_out('"</TH><TD>'||g_sections(i).error_count||'</TD><TD>'||g_sections(i).warn_count||'</TD> </TR>"+'); 
	END LOOP;
	print_out('" </TABLE></div>";'); 
		
	print_out('function openall()
	{var txt = "restable";
	 var i;
	 var x=document.getElementById(''restable1'');
	 for (i=0;i<='||g_sig_id||';i++)  
	  {
	  x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null ))
		    {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
	         x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL"); 
			 }
	  x=document.getElementById(txt.concat(i.toString())); 
	    if (!(x == null ))
		  {document.getElementById(txt.concat(i.toString())).style.display = ''''; }
	  }
	}
	 
	function closeall()
	{var txt = "restable";
	var txt2 = "tbitm";
	var i;
	var x=document.getElementById(''restable1'');
	for (i=0;i<='||g_sig_id||';i++)  
	{	
			x=document.getElementById(txt2.concat(i.toString()));   
	       if (!(x == null ))
		    {document.getElementById(txt2.concat(i.toString())).style.display = ''none'';}
		   x = document.getElementById(txt2.concat(i.toString(),''b''));  
			   if (!(x == null ))
				{x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}
				 
			x = document.getElementById(txt.concat(i.toString(),''b''));  
	       if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }
			
			x=document.getElementById(txt.concat(i.toString())); 
	       if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = ''none'';}  	
		   }}
		 
	 function opentabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1 && node.toString() != ''[object HTMLScriptElement]'') { /* Element */
               node.style.display =  ''block'' ;
           }
        }
   }
   
    function closetabs() {
     var tabCtrl = document.getElementById(''tabCtrl'');       
       for (var i = 0; i < tabCtrl.childNodes.length; i++) {
           var node = tabCtrl.childNodes[i];
           if (node.nodeType == 1) { /* Element */
               node.style.display =  ''none'' ;
           }
        }
   }
		</script> ');	
	
EXCEPTION WHEN OTHERS THEN
  print_log('Error in print_toc_contents: '||sqlerrm);
  raise;
END print_toc_contents;

----------------------------------------------------------------
-- Evaluates if a rowcol meets desired criteria               --
----------------------------------------------------------------

FUNCTION evaluate_rowcol(p_oper varchar2, p_val varchar2, p_colv varchar2) return boolean is
  x   NUMBER;
  y   NUMBER;
  n   boolean := true;
BEGIN
  -- Attempt to convert to number the column value, otherwise proceed as string
  BEGIN
    x := to_number(p_colv);
    y := to_number(p_val);
  EXCEPTION WHEN OTHERS THEN
    n := false;
  END;
  -- Compare
  IF p_oper = '=' THEN
    IF n THEN
      return x = y;
    ELSE
      return p_val = p_colv;
    END IF;
  ELSIF p_oper = '>' THEN
    IF n THEN
      return x > y;
    ELSE
      return p_colv > p_val;
    END IF;
  ELSIF p_oper = '<' THEN
    IF n THEN
      return x < y;
    ELSE
      return p_colv < p_val;
    END IF;
  ELSIF p_oper = '<=' THEN
    IF n THEN
      return x <= y;
    ELSE
      return p_colv <= p_val;
    END IF;
  ELSIF p_oper = '>=' THEN
    IF n THEN
      return x >= y;
    ELSE
      return p_colv >= p_val;
    END IF;
  ELSIF p_oper = '!=' OR p_oper = '<>' THEN
    IF n THEN
      return x != y;
    ELSE
      return p_colv != p_val;
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in evaluate_rowcol');
  raise;
END evaluate_rowcol;

---------------------------------------------
-- Expand [note] or {patch} tokens         --
---------------------------------------------

FUNCTION expand_links(p_str VARCHAR2) return VARCHAR2 IS
  l_str VARCHAR2(32000);
  l_s VARCHAR2(20);
Begin
  -- Assign to working variable
  l_str := p_str;
  -- First deal with patches
  l_str := regexp_replace(l_str,'({)([0-9]*)(})',
    '<a target="_blank" href="'||g_mos_patch_url||'\2">Patch \2</a>',1,0);
  -- Same for notes
  l_str := regexp_replace(l_str,'(\[)([0-9]*\.[0-9])(\])',
    '<a target="_blank" href="'||g_mos_doc_url||'\2">Doc ID \2</a>',1,0);
  return l_str;
END expand_links;

--------------------------------------------
-- Prepare the SQL with the substitution values
--------------------------------------------

FUNCTION prepare_sql(
  p_signature_sql IN VARCHAR2
  ) RETURN VARCHAR2 IS
  l_sql VARCHAR2(32767);
  l_key VARCHAR2(255);
BEGIN
  -- Assign signature to working variable
  l_sql := p_signature_sql;
  --  Build the appropriate SQL replacing all applicable values
  --  with the appropriate parameters
  l_key := g_sql_tokens.first;
  WHILE l_key is not null LOOP
    l_sql := replace(l_sql, l_key, g_sql_tokens(l_key));
    l_key := g_sql_tokens.next(l_key);
  END LOOP;
  RETURN l_sql;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in prepare_sql');
  raise;
END prepare_sql;

----------------------------------------------------------------
-- Set partial section result                                 --
----------------------------------------------------------------
PROCEDURE set_item_result(result varchar2) is
BEGIN
  IF g_sections(g_sections.last).result in ('U','I') THEN
          g_sections(g_sections.last).result := result;
      ELSIF g_sections(g_sections.last).result = 'S' THEN
        IF result in ('E','W') THEN
          g_sections(g_sections.last).result := result;
        END IF;   
      ELSIF g_sections(g_sections.last).result = 'W' THEN
        IF result = 'E' THEN
          g_sections(g_sections.last).result := result;
        END IF;
      END IF;
  -- Set counts
  IF result = 'S' THEN
    g_sections(g_sections.last).success_count :=
       g_sections(g_sections.last).success_count + 1;
  ELSIF result = 'W' THEN
    g_sections(g_sections.last).warn_count :=
       g_sections(g_sections.last).warn_count + 1;
  ELSIF result = 'E' THEN
    g_sections(g_sections.last).error_count :=
       g_sections(g_sections.last).error_count + 1;
  END IF;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in set_item_result: '||sqlerrm);
  raise;
END set_item_result;

----------------------------------------------------------------------
-- Runs a single SQL using DBMS_SQL returns filled tables
-- Precursor to future run_signature which will call this and
-- the print api. For now calls are manual.
----------------------------------------------------------------------

PROCEDURE run_sig_sql(
   p_raw_sql      IN  VARCHAR2,     -- SQL in the signature may require substitution
   p_col_rows     OUT COL_LIST_TBL, -- signature SQL column names
   p_col_headings OUT VARCHAR_TBL, -- signature SQL row values
   p_limit_rows   IN  VARCHAR2 DEFAULT 'Y') IS

  l_sql            VARCHAR2(32767);
  c                INTEGER;
  l_rows_fetched   NUMBER;
  l_step           VARCHAR2(20);
  l_col_rows       COL_LIST_TBL := col_list_tbl();
  l_col_headings   VARCHAR_TBL := varchar_tbl();
  l_col_cnt        INTEGER;
  l_desc_rec_tbl   DBMS_SQL.DESC_TAB2;

BEGIN
  -- Prepare the Signature SQL
  l_step := '10';
  l_sql := prepare_sql(p_raw_sql);
  -- Add SQL with substitution to attributes table
  l_step := '20';
  c := dbms_sql.open_cursor;
  l_step := '30';
  DBMS_SQL.PARSE(c, l_sql, DBMS_SQL.NATIVE);
  -- Get column count and descriptions
  l_step := '40';
  DBMS_SQL.DESCRIBE_COLUMNS2(c, l_col_cnt, l_desc_rec_tbl);
  -- Register arrays to bulk collect results and set headings
  l_step := '50';
  FOR i IN 1..l_col_cnt LOOP
    l_step := '50.1.'||to_char(i);
    l_col_headings.extend();
    l_col_headings(i) := initcap(replace(l_desc_rec_tbl(i).col_name,'|','<br>'));
    l_col_rows.extend();
    dbms_sql.define_array(c, i, l_col_rows(i), g_max_output_rows, 1);
  END LOOP;
  -- Execute and Fetch
  l_step := '60';
  get_current_time(g_query_start_time);
  l_rows_fetched := DBMS_SQL.EXECUTE(c);
  l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
  debug(' Rows fetched: '||to_char(l_rows_fetched));
  l_step := '70';
  IF l_rows_fetched > 0 THEN
    FOR i in 1..l_col_cnt LOOP
      l_step := '70.1.'||to_char(i);
      DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
    END LOOP;
  END IF;
  IF nvl(p_limit_rows,'Y') = 'N' THEN
    WHILE l_rows_fetched = g_max_output_rows LOOP
      l_rows_fetched := DBMS_SQL.FETCH_ROWS(c);
      debug(' Rows fetched: '||to_char(l_rows_fetched));
      FOR i in 1..l_col_cnt LOOP
        l_step := '70.2.'||to_char(i);
        DBMS_SQL.COLUMN_VALUE(c, i, l_col_rows(i));
      END LOOP;
    END LOOP;
  END IF;
  g_query_elapsed := stop_timer(g_query_start_time);
--  g_query_total := g_query_total + g_query_elapsed;

  -- Close cursor
  l_step := '80';
  IF dbms_sql.is_open(c) THEN
    dbms_sql.close_cursor(c);
  END IF;
  -- Set out parameters
  p_col_headings := l_col_headings;
  p_col_rows := l_col_rows;
EXCEPTION
  WHEN OTHERS THEN
    print_error('PROGRAM ERROR<br />
      Error in run_sig_sql at step '||
      l_step||': '||sqlerrm||'<br/>
      See the log file for additional details<br/>');
    print_log('Error at step '||l_step||' in run_sig_sql running: '||l_sql);
    print_log('Error: '||sqlerrm);
    l_col_cnt := -1;
    IF dbms_sql.is_open(c) THEN
      dbms_sql.close_cursor(c);
    END IF;
    g_errbuf := 'toto '||l_step;
END run_sig_sql;

PROCEDURE generate_hidden_xml(
  p_sig_id          VARCHAR2,
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL)    -- signature SQL column names       
IS

l_hidden_xml_doc       XMLDOM.DOMDocument;
l_hidden_xml_node      XMLDOM.DOMNode;
l_diagnostic_element   XMLDOM.DOMElement;
l_diagnostic_node      XMLDOM.DOMNode;
l_issues_node          XMLDOM.DOMNode;
l_signature_node       XMLDOM.DOMNode;
l_signature_element    XMLDOM.DOMElement;
l_node                 XMLDOM.DOMNode;
l_row_node             XMLDOM.DOMNode;
l_failure_node         XMLDOM.DOMNode;
l_run_details_node     XMLDOM.DOMNode;
l_run_detail_data_node XMLDOM.DOMNode;
l_detail_element       XMLDOM.DOMElement;
l_detail_node          XMLDOM.DOMNode;
l_detail_name_attribute XMLDOM.DOMAttr;
l_parameters_node      XMLDOM.DOMNode;
l_parameter_node       XMLDOM.DOMNode;
l_col_node             XMLDOM.DOMNode;
l_parameter_element    XMLDOM.DOMElement;
l_col_element          XMLDOM.DOMElement;
l_param_name_attribute XMLDOM.DOMAttr;
l_failure_element      XMLDOM.DOMElement;
l_sig_id_attribute     XMLDOM.DOMAttr;
l_col_name_attribute   XMLDOM.DOMAttr;
l_row_attribute        XMLDOM.DOMAttr;
l_key                  VARCHAR2(255);
l_match                VARCHAR2(1);
l_rows                 NUMBER;
l_value                VARCHAR2(2000);


BEGIN

l_hidden_xml_doc := g_hidden_xml;

IF (XMLDOM.isNULL(l_hidden_xml_doc)) THEN
   l_hidden_xml_doc := XMLDOM.newDOMDocument;
   l_hidden_xml_node := XMLDOM.makeNode(l_hidden_xml_doc);
   l_diagnostic_node := XMLDOM.appendChild(l_hidden_xml_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'diagnostic')));

   l_run_details_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'run_details')));   
   l_key := g_rep_info.first;
   WHILE l_key IS NOT NULL LOOP
   
     l_detail_element := XMLDOM.createElement(l_hidden_xml_doc,'detail');
     l_detail_node := XMLDOM.appendChild(l_run_details_node,XMLDOM.makeNode(l_detail_element));
     l_detail_name_attribute:=XMLDOM.setAttributeNode(l_detail_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_detail_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_detail_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_rep_info(l_key))));

     l_key := g_rep_info.next(l_key);

   END LOOP;

   l_parameters_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'parameters')));
   l_key := g_parameters.first;
   WHILE l_key IS NOT NULL LOOP

     l_parameter_element := XMLDOM.createElement(l_hidden_xml_doc,'parameter');
     l_parameter_node := XMLDOM.appendChild(l_parameters_node,XMLDOM.makeNode(l_parameter_element));
     l_param_name_attribute:=XMLDOM.setAttributeNode(l_parameter_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
     XMLDOM.setAttribute(l_parameter_element, 'name', l_key);
     l_node := XMLDOM.appendChild(l_parameter_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,g_parameters(l_key))));

     l_key := g_parameters.next(l_key);


   END LOOP;
   
   l_issues_node := XMLDOM.appendChild(l_diagnostic_node,XMLDOM.makeNode(XMLDOM.createElement(l_hidden_xml_doc,'issues')));   

END IF;


 IF p_sig_id IS NOT NULL THEN

   l_issues_node := XMLDOM.getLastChild(XMLDOM.getFirstChild(XMLDOM.makeNode(l_hidden_xml_doc)));

   l_signature_element := XMLDOM.createElement(l_hidden_xml_doc,'signature');
   l_sig_id_attribute := XMLDOM.setAttributeNode(l_signature_element,XMLDOM.createAttribute(l_hidden_xml_doc,'id'));
   l_signature_node := XMLDOM.appendChild(l_issues_node,XMLDOM.makeNode(l_signature_element));
   XMLDOM.setAttribute(l_signature_element, 'id',p_sig_id);

   IF p_sig.limit_rows='Y' THEN
      l_rows := least(g_max_output_rows,p_col_rows(1).COUNT,50);
   ELSE
      l_rows := least(p_col_rows(1).COUNT,50);
   END IF;
   
   FOR i IN 1..l_rows LOOP

      l_failure_element := XMLDOM.createElement(l_hidden_xml_doc,'failure');
      l_row_attribute := XMLDOM.setAttributeNode(l_failure_element,XMLDOM.createAttribute(l_hidden_xml_doc,'row'));     
      l_failure_node := XMLDOM.appendChild(l_signature_node,XMLDOM.makeNode(l_failure_element));
      XMLDOM.setAttribute(l_failure_element, 'row', i);   
    
      FOR j IN 1..p_col_headings.count LOOP
 
         l_col_element := XMLDOM.createElement(l_hidden_xml_doc,'column');
         l_col_name_attribute := XMLDOM.setAttributeNode(l_col_element,XMLDOM.createAttribute(l_hidden_xml_doc,'name'));
         l_col_node := XMLDOM.appendChild(l_failure_node,XMLDOM.makeNode(l_col_element));
         XMLDOM.setAttribute(l_col_element, 'name',p_col_headings(j));
 
         l_value := p_col_rows(j)(i);

         IF p_sig_id = 'REC_PATCH_CHECK' THEN
            IF p_col_headings(j) = 'Patch' THEN
               l_value := replace(replace(p_col_rows(j)(i),'{'),'}');
            ELSIF p_col_headings(j) = 'Note' THEN
               l_value := replace(replace(p_col_rows(j)(i),'['),']');
            END IF;
         END IF;
		 
		 -- Rtrim the column value if blanks are not to be preserved
          IF NOT g_preserve_trailing_blanks THEN
            l_value := RTRIM(l_value, ' ');
          END IF;

         l_node := XMLDOM.appendChild(l_col_node,XMLDOM.makeNode(XMLDOM.createTextNode(l_hidden_xml_doc,l_value)));

      END LOOP;
    END LOOP;
    
  END IF;  

  g_hidden_xml := l_hidden_xml_doc;


END generate_hidden_xml;


PROCEDURE print_hidden_xml
IS

l_hidden_xml_clob      clob;
l_offset               NUMBER := 1;
l_length               NUMBER;

l_node_list            XMLDOM.DOMNodeList;
l_node_length          NUMBER;

BEGIN

IF XMLDOM.isNULL(g_hidden_xml) THEN

   generate_hidden_xml(p_sig_id => null,
                       p_sig => null,
                       p_col_headings => null,
                       p_col_rows => null);
                       
END IF;                      

dbms_lob.createtemporary(l_hidden_xml_clob, true);

--print CLOB
XMLDOM.WRITETOCLOB(g_hidden_xml, l_hidden_xml_clob); 

print_out('<!-- ######BEGIN DX SUMMARY######','Y');

LOOP
   EXIT WHEN (l_offset > dbms_lob.getlength(l_hidden_xml_clob) OR dbms_lob.getlength(l_hidden_xml_clob)=0);
   
      print_out(dbms_lob.substr(l_hidden_xml_clob,2000, l_offset),'N');

      l_offset := l_offset + 2000;
      
   END LOOP;
   
print_out('######END DX SUMMARY######-->','Y');  --should be a newline here

dbms_lob.freeTemporary(l_hidden_xml_clob);      
XMLDOM.FREEDOCUMENT(g_hidden_xml);

END print_hidden_xml;

----------------------------------------------------------------
-- Once a signature has been run, evaluates and prints it     --
----------------------------------------------------------------
FUNCTION process_signature_results(
  p_sig_id          VARCHAR2,      -- signature id
  p_sig             SIGNATURE_REC, -- Name of signature item
  p_col_rows        COL_LIST_TBL,  -- signature SQL row values
  p_col_headings    VARCHAR_TBL,    -- signature SQL column names
  p_is_child        BOOLEAN    DEFAULT FALSE
  ) RETURN VARCHAR2 IS             -- returns 'E','W','S','I'

  l_sig_fail      BOOLEAN := false;
  l_row_fail      BOOLEAN := false;
  l_fail_flag     BOOLEAN := false;
  l_html          VARCHAR2(32767) := null;
  l_column        VARCHAR2(255) := null;
  l_operand       VARCHAR2(3);
  l_value         VARCHAR2(4000);
  l_step          VARCHAR2(255);
  l_i             VARCHAR2(255);
  l_curr_col      VARCHAR2(255) := NULL;
  l_curr_val      VARCHAR2(4000) := NULL;
  l_print_sql_out BOOLEAN := true;
  l_inv_param     EXCEPTION;
  l_rows_fetched  NUMBER := p_col_rows(1).count;
  l_printing_cols NUMBER := 0;
  l_is_child      BOOLEAN;
  l_error_type    VARCHAR2(1);

BEGIN
  -- Validate parameters which have fixed values against errors when
  -- defining or loading signatures
  l_is_child := p_is_child;
    IF (NOT l_is_child) THEN
       g_family_result := '';
    END IF;
  l_step := 'Validate parameters';
  
  IF (p_sig.fail_condition NOT IN ('RSGT1','RS','NRS')) AND
     ((instr(p_sig.fail_condition,'[') = 0) OR
      (instr(p_sig.fail_condition,'[',1,2) = 0) OR
      (instr(p_sig.fail_condition,']') = 0) OR
      (instr(p_sig.fail_condition,']',1,2) = 0))  THEN
    print_log('Invalid value or format for failure condition: '||
      p_sig.fail_condition);
    raise l_inv_param;
  ELSIF p_sig.print_condition NOT IN ('SUCCESS','FAILURE','ALWAYS','NEVER') THEN
    print_log('Invalid value for print_condition: '||p_sig.print_condition);
    raise l_inv_param;
  ELSIF p_sig.fail_type NOT IN ('E','W','I') THEN
    print_log('Invalid value for fail_type: '||p_sig.fail_type);
    raise l_inv_param;
  ELSIF p_sig.print_sql_output NOT IN ('Y','N','RS') THEN
    print_log('Invalid value for print_sql_output: '||p_sig.print_sql_output);
    raise l_inv_param;
  ELSIF p_sig.limit_rows NOT IN ('Y','N') THEN
    print_log('Invalid value for limit_rows: '||p_sig.limit_rows);
    raise l_inv_param;
  ELSIF p_sig.print_condition in ('ALWAYS','SUCCESS') AND
        p_sig.success_msg is null AND p_sig.print_sql_output = 'N' THEN
    print_log('Invalid parameter combination.');
    print_log('print_condition/success_msg/print_sql_output: '||
      p_sig.print_condition||'/'||nvl(p_sig.success_msg,'null')||
      '/'||p_sig.print_sql_output);
    print_log('When printing on success either success msg or SQL output '||
        'printing should be enabled.');
    raise l_inv_param;
  END IF;
  -- For performance sake: first make trivial evaluations of success
  -- and if no need to print just return
  l_step := '10';
  IF (p_sig.print_condition IN ('NEVER','FAILURE') AND
	 ((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'RS' AND l_rows_fetched = 0) OR
      (p_sig.fail_condition = 'NRS' AND l_rows_fetched > 0))) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (p_sig.print_condition IN ('NEVER','SUCCESS') AND
		((p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
        (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
         (p_sig.fail_condition = 'NRS' AND l_rows_fetched = 0))) THEN
    return p_sig.fail_type;
  END IF;

  l_print_sql_out := (nvl(p_sig.print_sql_output,'Y') = 'Y' OR
					 (p_sig.print_sql_output = 'RSGT1' AND l_rows_fetched > 1) OR
                     (p_sig.print_sql_output = 'RS' AND l_rows_fetched > 0) OR
                      p_sig.child_sigs.count > 0 AND l_rows_fetched > 0);

  -- Determine signature failure status
  IF p_sig.fail_condition NOT IN ('RSGT1','RS','NRS') THEN
    -- Get the column to evaluate, if any
    l_step := '20';
    l_column := upper(substr(ltrim(p_sig.fail_condition),2,instr(p_sig.fail_condition,']') - 2));
    l_operand := rtrim(ltrim(substr(p_sig.fail_condition, instr(p_sig.fail_condition,']')+1,
      (instr(p_sig.fail_condition,'[',1,2)-instr(p_sig.fail_condition,']') - 1))));
    l_value := substr(p_sig.fail_condition, instr(p_sig.fail_condition,'[',2)+1,
      (instr(p_sig.fail_condition,']',1,2)-instr(p_sig.fail_condition,'[',1,2)-1));

    l_step := '30';
    FOR i IN 1..least(l_rows_fetched, g_max_output_rows) LOOP
      l_step := '40';
      FOR j IN 1..p_col_headings.count LOOP
        l_step := '40.1.'||to_char(j);
        l_row_fail := false;
        l_curr_col := upper(p_col_headings(j));
        l_curr_val := p_col_rows(j)(i);
        IF nvl(l_column,'&&&') = l_curr_col THEN
          l_step := '40.2.'||to_char(j);
          l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          IF l_row_fail THEN
            l_fail_flag := true;
          END IF;
        END IF;
      END LOOP;
    END LOOP;
  END IF;

  -- Evaluate this signature
  l_step := '50';
  l_sig_fail := l_fail_flag OR
				(p_sig.fail_condition = 'RSGT1' AND l_rows_fetched > 1) OR
                (p_sig.fail_condition = 'RS' AND l_rows_fetched > 0) OR
                (p_sig.fail_condition = 'NRS' and l_rows_fetched = 0);

  l_step := '55';
  IF (l_sig_fail AND p_sig.include_in_xml='Y') THEN
     generate_hidden_xml(p_sig_id => p_sig_id,
                         p_sig => p_sig,
                         p_col_headings => p_col_headings,
                         p_col_rows => p_col_rows);
  END IF;

  -- If success and no print just return
  l_step := '60';
  IF ((NOT l_sig_fail) AND p_sig.print_condition IN ('FAILURE','NEVER')) THEN
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  ELSIF (l_sig_fail AND (p_sig.print_condition IN ('SUCCESS','NEVER'))) THEN
    return p_sig.fail_type;
  END IF;

  -- Print container div
  l_html := '<div class="divItem" id="sig'||p_sig_id||'">';

  -- Print title div
  l_step := '70';
   	g_sig_id := g_sig_id + 1;
	l_html := l_html || ' <div class="divItemTitle">' || '<a name="restable'||p_sig.title||'b"></a> <a id="restable'||to_char(g_sig_id)||'b'||'" class="detail" href="javascript:;" onclick="displayItem(this, ''restable' ||
      to_char(g_sig_id) ||''');">&#9654; '||p_sig.title||'</a>';
	
  -- Keep the counter of the parent signature to use as anchore in the table of contents
    IF (NOT l_is_child) THEN
       g_parent_sig_id := g_sig_id;
    END IF;  
	
  -- Print collapsable/expandable extra info table if there are contents
  l_step := '80';
  IF p_sig.extra_info.count > 0 OR p_sig.sig_sql is not null THEN
    g_item_id := g_item_id + 1;
    l_step := '90';
    -- Print the triangle and javascript
    l_html := l_html || '
      <a class="detailsmall" id="tbitm' || to_char(g_item_id) || 'b" href="javascript:;" onclick="displayItem(this, ''tbitm' ||
      to_char(g_item_id) ||''');"><font color="#0066CC">(Show SQL)</font></a></div>';
    -- Print the table with extra information in hidden state
    l_step := '100';
    l_html := l_html || '
      <table class="table1" id="tbitm' || to_char(g_item_id) ||
      '" style="display:none">
      <tbody><tr><th>Item Name</th><th>Item Value</th></tr>';
    -- Loop and print values
    l_step := '110';
    l_i := p_sig.extra_info.FIRST;
    WHILE l_i IS NOT NULL LOOP
      l_step := '110.1.'||l_i;
      l_html := l_html || '<tr><td>' || l_i || '</td><td>'||
        p_sig.extra_info(l_i) || '</td></tr>';
      l_step := '110.2.'||l_i;
      l_i := p_sig.extra_info.next(l_i);
    END LOOP;
    IF p_sig.sig_sql is not null THEN
      l_step := '120';
      l_html := l_html || '
         <tr><td>SQL</td><td><pre>'|| prepare_sql(p_sig.sig_sql) ||
         '</pre></td></tr>';
    END IF;
  ELSE -- no extra info or SQL to print
    l_step := '130';
    l_html := l_html || '</div>';
  END IF;

  l_step := '140';
  l_html := l_html || '</tbody></table>';

  -- Print the header SQL info table
  print_out(expand_links(l_html));
  l_html := null;

  IF l_print_sql_out THEN
    IF p_sig.child_sigs.count = 0 THEN
      -- Print the actual results table
      -- Table header
      l_step := '150';
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Column headings
      l_html := l_html || '<tr>';
      l_step := '160';
      FOR i IN 1..p_col_headings.count LOOP
        l_html := l_html || '
          <th>'||nvl(p_col_headings(i),'&nbsp;')||'</th>';
      END LOOP;
      l_html := l_html || '</tr>';
      -- Print headers
      print_out(expand_links(l_html));
      -- Row values
      l_step := '170';
      FOR i IN 1..l_rows_fetched LOOP
        l_html := '<tr>';
        l_step := '170.1.'||to_char(i);
        FOR j IN 1..p_col_headings.count LOOP
          -- Evaluate if necessary
          l_step := '170.2.'||to_char(j);
          l_row_fail := false;
          l_step := '170.3.'||to_char(j);
          l_curr_col := upper(p_col_headings(j));
          l_step := '170.4.'||to_char(j);
          l_curr_val := p_col_rows(j)(i);
          l_step := '170.5.'||to_char(j);
          IF nvl(l_column,'&&&') = l_curr_col THEN
            l_step := '170.6.'||
              substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
            l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
          END IF;
		  
	   -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
          -- Print
          l_step := '170.7.'||to_char(j);
          IF l_row_fail THEN
            l_html := l_html || '
              <td class="hlt">' || l_curr_Val || '</td>';
          ELSE
            l_html := l_html || '
              <td>' || l_curr_val || '</td>';
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
      END LOOP;
	  
	l_html := '<tr><th colspan="100%"><b><i><font style="font-size:x-small; color:#333333">';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font></i></b><br>';
	  l_html := l_html || '</th></tr>';
      print_out(l_html);

      -- End of results and footer
      l_step := '180';
      l_html :=  '</tbody></table></div>';
      l_step := '190';
      print_out(l_html);
--
    ELSE -- there are children signatures
      -- Print master rows and call appropriate processes for the children
      -- Table header
      l_html := '<div class="divtable"><table class="table1" id="restable' || to_char(g_sig_id) ||
      '" style="display:none"><tbody>';
      -- Row values
      l_step := '200';
      FOR i IN 1..l_rows_fetched LOOP
        l_step := '200.2.'||to_char(i);
        -- Column headings printed for each row
        l_html := l_html || '<tr>';
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.2.'||to_char(j);
          IF upper(nvl(p_col_headings(j),'XXX')) not like '##$$FK_$$##' THEN
            l_html := l_html || '
              <th class="master">'||nvl(p_col_headings(j),'&nbsp;')||'</th>';
          END IF;
        END LOOP;
        l_step := '200.3';
        l_html := l_html || '</tr>';
        -- Print headers
        print_out(expand_links(l_html));
        -- Print a row
        l_html := '<tr class="master">';

        l_printing_cols := 0;
        FOR j IN 1..p_col_headings.count LOOP
          l_step := '200.4.'||to_char(j);

          l_curr_col := upper(p_col_headings(j));
          l_curr_val := p_col_rows(j)(i);

          -- If the col is a FK set the global replacement vals
          IF l_curr_col like '##$$FK_$$##' THEN
            l_step := '200.5';
            g_sql_tokens(l_curr_col) := l_curr_val;
          ELSE -- printable column
            l_printing_cols := l_printing_cols + 1;
            -- Evaluate if necessary
            l_row_fail := false;
            IF nvl(l_column,'&&&') = l_curr_col THEN
              l_step := '200.6'||
                substr('['||l_operand||']['||l_value||']['||l_curr_val||']',1,96);
              l_row_fail := evaluate_rowcol(l_operand, l_value, l_curr_val);
            END IF;
			
	   -- Encode blanks as HTML space if this analyzer is set so by g_preserve_trailing_blanks
       -- this ensures trailing blanks added for padding are honored by browsers
       -- affects only printing, DX summary handled separately
       IF g_preserve_trailing_blanks THEN
         l_curr_Val := RPAD(RTRIM(l_curr_Val,' '),
          -- pad length is the number of spaces existing times the length of &nbsp; => 6
         (length(l_curr_Val) - length(RTRIM(l_curr_Val,' '))) * 6 + length(RTRIM(l_curr_Val,' ')),
         '&nbsp;');
       ELSE
         l_curr_Val := RTRIM(l_curr_Val, ' ');
       END IF;
	   
            -- Print
            IF l_row_fail THEN
              l_html := l_html || '
                <td class="hlt">' || l_curr_Val || '</td>';
            ELSE
              l_html := l_html || '
                <td>' || l_curr_val || '</td>';
            END IF;
          END IF;
        END LOOP;
        l_html := l_html || '</tr>';
        print_out(expand_links(l_html));
        l_html := null;
        FOR i IN p_sig.child_sigs.first..p_sig.child_sigs.last LOOP
          print_out('<tr><td colspan="'||to_char(l_printing_cols)||
            '"><blockquote>');
          DECLARE
            l_col_rows  COL_LIST_TBL := col_list_tbl();
            l_col_hea   VARCHAR_TBL := varchar_tbl();
            l_child_sig SIGNATURE_REC;
            l_result    VARCHAR2(1);
          BEGIN
           l_child_sig := g_signatures(p_sig.child_sigs(i));
           print_log('Processing child signature: '||p_sig.child_sigs(i));
           run_sig_sql(l_child_sig.sig_sql, l_col_rows, l_col_hea,
             l_child_sig.limit_rows);
           l_result := process_signature_results(p_sig.child_sigs(i),
             l_child_sig, l_col_rows, l_col_hea, TRUE);
           set_item_result(l_result);

		   -- show parent signature failure based on result from child signature(s)
         IF l_result in ('W','E') THEN
             l_fail_flag := true;
           IF l_result = 'E' THEN
             l_error_type := 'E';
           ELSIF (l_result = 'W') AND ((l_error_type is NULL) OR (l_error_type != 'E')) THEN
             l_error_type := 'W';
           END IF;
           g_family_result := l_error_type;
         END IF;

          EXCEPTION WHEN OTHERS THEN
            print_log('Error processing child signature: '||p_sig.child_sigs(i));
            print_log('Error: '||sqlerrm);
            raise;
          END;

          print_out('</blockquote></td></tr>');
        END LOOP;
      END LOOP;
      --l_sig_fail := (l_sig_fail OR l_fail_flag);

      -- End of results and footer
      l_step := '210';
      l_html :=  '</tbody></table></div>
        <font style="font-size:x-small; color:#333333">';
      l_step := '220';
      IF p_sig.limit_rows = 'N' OR l_rows_fetched < g_max_output_rows THEN
        l_html := l_html || l_rows_fetched || ' rows selected';
      ELSE
        l_html := l_html ||'Displaying first '||to_char(g_max_output_rows);
      END IF;
      l_html := l_html ||' - Elapsed time: ' || format_elapsed(g_query_elapsed) || '
        </font><br>';
      print_out(l_html);
    END IF; -- master or child
  END IF; -- print output is true

  -- Print actions
  IF l_sig_fail THEN
    l_step := '230';
    IF p_sig.fail_type = 'E' THEN
      l_html := '<div class="divuar"><span class="divuar1"><img class="error_ico"> Error:</span>' ||
        p_sig.problem_descr;
    ELSIF p_sig.fail_type = 'W' THEN
      l_html := '<div class="divwarn"><span class="divwarn1"><img class="warn_ico"> Warning:</span>' ||
        p_sig.problem_descr;
    ELSE
      l_html := '<div class="divok"><span class="divok1">Information:</span>' ||
        p_sig.problem_descr;
    END IF;

    -- Print solution only if passed
    l_step := '240';
    IF p_sig.solution is not null THEN
      l_html := l_html || '
        <br><br><span class="solution">Findings and Recommendations:</span><br>
        ' || p_sig.solution;
    END IF;

    -- Close div here cause success div is conditional
    l_html := l_html || '</div>';
  ELSE
    l_step := '250';
    IF p_sig.success_msg is not null THEN
      IF p_sig.fail_type = 'I' THEN
        l_html := '
          <br><div class="divok"><div class="divok1">Information:</div>'||
          nvl(p_sig.success_msg, 'No instances of this problem found') ||
          '</div>';
      ELSE
        l_html := '
          <br><div class="divok"><div class="divok1"><img class="check_ico"> All checks passed.</div>'||
          nvl(p_sig.success_msg,
          'No instances of this problem found') ||
          '</div>';
      END IF;
    ELSE
      l_html := null;
    END IF;
  END IF;
  
  -- DIV for parent
 IF p_sig.child_sigs.count > 0 and NOT (l_is_child) THEN
        IF g_family_result = 'E' THEN 
           l_html := l_html || '
             <div class="divuar"><div class="divuar1"><img class="error_ico"> There was an error reported in one of the child checks. Please expand the section for more information.</div></div>';	
        ELSIF g_family_result = 'W' THEN
           l_html := l_html || '
             <div class="divwarn"><div class="divwarn1"><img class="warn_ico"> There was an issue reported in one of the child checks. Please expand the section for more information.</div></div>';	
        END IF;     
      END IF;

  -- Add final tags
  l_html := l_html || '
    </div>' || '<br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br>' || '<br>';
	 
   --Code for Table of Contents of each section  
   g_section_sig := g_section_sig + 1;
   sig_count := g_section_sig;  
   
   IF NOT (l_is_child) THEN
     -- for even # signatures
   g_parent_sig_count := g_parent_sig_count + 1;
   IF MOD(g_parent_sig_count, 2) = 0 THEN

   -- link to the parent sections only
   g_section_toc := g_section_toc || '<td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF; 
	   
   g_section_toc := g_section_toc || '</td></tr>';
   
   ELSE
   -- for odd # signatures start the row
   -- link to the parent sections only
   g_section_toc := g_section_toc || '<tr class="toctable"><td>' || '<a href="#restable'||to_char(g_parent_sig_id)||'b">'||p_sig.title||'</a> ';
   
   	  IF ((l_sig_fail) AND (p_sig.fail_type ='E' OR l_error_type = 'E')) OR (g_family_result = 'E') THEN
         g_section_toc := g_section_toc || '<img class="error_ico">';      
       ELSIF ((l_sig_fail) AND (p_sig.fail_type ='W' OR l_error_type = 'W')) OR (g_family_result = 'W') THEN
         g_section_toc := g_section_toc ||'<img class="warn_ico">';        
       END IF; 
	   
   g_section_toc := g_section_toc || '</td>';   
    
	END IF;

  END IF;
   
	 
  -- Increment the print count for the section	   
  l_step := '260';
  g_sections(g_sections.last).print_count :=
       g_sections(g_sections.last).print_count + 1;

  -- Print
  l_step := '270';
  print_out(expand_links(l_html));
   
	 
  IF l_sig_fail THEN
    l_step := '280';
    return p_sig.fail_type;
  ELSE
    l_step := '290';
    IF p_sig.fail_type = 'I' THEN
      return 'I';
    ELSE
      return 'S';
    END IF;
  END IF;
  

  
EXCEPTION
  WHEN L_INV_PARAM THEN
    print_log('Invalid parameter error in process_signature_results at step '
      ||l_step);
    raise;
  WHEN OTHERS THEN
    print_log('Error in process_signature_results at step '||l_step);
    g_errbuf := l_step;
    raise;
END process_signature_results;

----------------------------------------------------------------
-- Creates a report section                                   --
-- For now it just prints html, in future it could be         --
-- smarter by having the definition of the section logic,     --
-- signatures etc....                                         --
----------------------------------------------------------------

PROCEDURE start_section(p_sect_title varchar2) is
  lsect section_rec;
  
BEGIN
  lsect.name := p_sect_title;
  lsect.result := 'U'; -- 'U' stands for undefined which is a temporary status
  lsect.error_count := 0;
  lsect.warn_count := 0;
  lsect.success_count := 0;
  lsect.print_count := 0;
  g_sections(g_sections.count + 1) := lsect;
  g_section_toc := null;
  g_section_sig := 0;
  sig_count := null;
  g_parent_sig_count := 0;
  
  -- Print section header
  print_out('
  <div id="page'||g_sect_no|| '" style="display: none;">');
  print_out('
<div class="divSection">
<div class="divSectionTitle" id="sect' || g_sections.last || '">
<div class="left"  id="sect_title' || g_sections.last || '" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">' || p_sect_title || ': 
</font> 
</div>
       <div class="right" font style="font-weight: normal; font-size: small;" align="right" color="#FFFFFF"> 
          <a class="detail" onclick="openall();" href="javascript:;">
          <font color="#FFFFFF">&#9654; Expand All Checks</font></a> 
          <font color="#FFFFFF">&nbsp;/ &nbsp; </font><a class="detail" onclick="closeall();" href="javascript:;">
          <font color="#FFFFFF">&#9660; Collapse All Checks</font></a> 
       </div>
  <div class="clear"></div>
</div><br>');	

  -- Table of Content DIV
  -- Making DIV invisible by default as later has logic to show TOC only if have 2+ signatures
   print_out('<div class="divItem" style="display: none" id="toccontent'|| g_sections.last||'"></div><br>');
  -- end of TOC DIV		
    		
    print_out('<div id="' || g_sections.last ||'contents">');

-- increment section #
  g_sect_no:=g_sect_no+1;

END start_section;


----------------------------------------------------------------
-- Finalizes a report section                                 --
-- Finalizes the html                                         --
----------------------------------------------------------------

PROCEDURE end_section (
  p_success_msg IN VARCHAR2 DEFAULT 'All checks passed.') IS
  
  l_loop_count NUMBER;
  
BEGIN
  IF g_sections(g_sections.last).result = 'S' AND
     g_sections(g_sections.last).print_count = 0 THEN
    print_out('<div class="divok">'||p_success_msg||'</div>');
  END IF;
  print_out('</div></div><br><font style="font-size:x-small;">
    <a href="#top"><font color="#0066CC">Back to top</font></a></font><br><br>');
   print_out('</div>');
   
 -- Printing table for Table of Content and contents
 -- IF is to print end tag of table row for odd number of sigs
	 
	 IF SUBSTR (g_section_toc, length(g_section_toc)-5, 5) != '</tr>'
		THEN g_section_toc := g_section_toc || '</tr>';
		
	 end if;	
	 
	 g_section_toc := '<table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0">' || g_section_toc || '</table>';
	 
 -- Printing 'In This Section' only have 2 or more signatures
	 IF sig_count > 1
	    THEN
	   print_out('
		<script type="text/javascript">
		var a=document.getElementById("toccontent'|| g_sections.last||'");
		a.style.display = "block";
		  a.innerHTML = ''' || '<div class="divItemTitle">In This Section</div>' || g_section_toc ||'''; </script> ');
	end if;	  
 
END end_section;

----------------------------------------------------------------
-- Creates a report sub section                               --
-- workaround for now in future normal sections should        --
-- support nesting                                            --
----------------------------------------------------------------

PROCEDURE print_rep_subsection(p_sect_title varchar2) is
BEGIN
  print_out('<div class="divSubSection"><div class="divSubSectionTitle">' ||
    p_sect_title || '</div><br>');
END print_rep_subsection;

PROCEDURE print_rep_subsection_end is
BEGIN
  print_out('</div<br>');
END print_rep_subsection_end;


-------------------------
-- Recommended patches 
-------------------------
FUNCTION check_rec_patches RETURN VARCHAR2 IS

  l_col_rows   COL_LIST_TBL := col_list_tbl(); -- Row values
  l_hdr        VARCHAR_TBL := varchar_tbl(); -- Column headings
  l_app_date   DATE;         -- Patch applied date
  l_extra_info HASH_TBL_4K;   -- Extra information
  l_step       VARCHAR2(10);
  l_sig        SIGNATURE_REC;
  l_rel       VARCHAR2(3);

  CURSOR get_app_date(p_ptch VARCHAR2, p_rel VARCHAR2) IS			  
   SELECT Max(Last_Update_Date) as date_applied
    FROM Ad_Bugs Adb 
    WHERE Adb.Bug_Number like p_ptch
    AND ad_patch.is_patch_applied(p_rel, -1, adb.bug_number)!='NOT_APPLIED';
	
BEGIN
  -- Column headings
  l_step := '10';
  l_hdr.extend(5);
  l_hdr(1) := 'Patch';
  l_hdr(2) := 'Applied';
  l_hdr(3) := 'Date';
  l_hdr(4) := 'Name';
  l_hdr(5) := 'Note';

  -- Row col values is release dependent
     -- Last parameter (4 in this case) matches number of characters of the Apps Version (12.0)
     -- So if checking for '11.5.10.2' then parameter will need to be 9
	     -- ie: IF substr(g_rep_info('Apps Version'),1,9) = '11.5.10.2'
  IF substr(g_rep_info('Apps Version'),1,4) = '12.0' THEN
    l_step := '2';
	l_rel := 'R12';
    l_col_rows.extend(11);
    l_col_rows(1)(1) := '13864126';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'XLA Trial Balance Upgrade Package';
    l_col_rows(5)(1) := '[553484.1]';
    l_col_rows(1)(2) := '13843627';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'This patch delivers an XLA package '||
      'which contains the logic required to upload trial balance '||
      'data into XLA_TRIAL_BALANCES';
    l_col_rows(5)(2) := '[1463703.1]';
    l_col_rows(1)(3) := '9926320';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'XLA Trial Balance Report Package for AP';
    l_col_rows(5)(3) := '[553484.1]';
    l_col_rows(1)(4) := '9162536';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'XLA Trial Balance Report Package';
    l_col_rows(5)(4) := '[553484.1]';
    l_col_rows(1)(5) := '14709461';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'XLA Trial Balance Rebuild Report Package for AP';
    l_col_rows(5)(5) := '[1463703.1]';
    l_col_rows(1)(6) := '13330611';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'XML for Trial Balance';
    l_col_rows(5)(6) := '[553484.1]';
    l_col_rows(1)(7) := '9162536';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Invoices view used by Trial Balance';
    l_col_rows(5)(7) := '[553484.1]';
    l_col_rows(1)(8) := '13330611';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'Open Account Payables Balances Listing Group by Account';
    l_col_rows(5)(8) := '[444044.1]';
    l_col_rows(1)(9) := '13330611';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Open Account Payables Balances Listing Group by Third Party';
    l_col_rows(5)(9) := '[444044.1]';
    l_col_rows(1)(10) := '12382509';
    l_col_rows(2)(10) := 'No';
    l_col_rows(3)(10) := NULL;
    l_col_rows(4)(10) := 'XML Publisher';
    l_col_rows(5)(10) := '[553484.1]';
    l_col_rows(1)(11) := '9162536';
    l_col_rows(2)(11) := 'No';
    l_col_rows(3)(11) := NULL;
    l_col_rows(4)(11) := 'Includes Summary/Detail Report Mode change and Trial Balance Remodel Phase 4';
    l_col_rows(5)(11) := '[553484.1]';
  ELSE
    l_step := '3';
	l_rel := 'R12';
    l_col_rows.extend(11);
    l_col_rows(1)(1) := '13864126';
    l_col_rows(2)(1) := 'No';
    l_col_rows(3)(1) := NULL;
    l_col_rows(4)(1) := 'XLA Trial Balance Upgrade Package';
    l_col_rows(5)(1) := '[553484.1]';
    l_col_rows(1)(2) := '13843627';
    l_col_rows(2)(2) := 'No';
    l_col_rows(3)(2) := NULL;
    l_col_rows(4)(2) := 'This IS a XLA PRIVATE PACKAGE, '||
                 'which contains ALL THE logic required TO upload trial balance data INTO xla_trial_balances';
    l_col_rows(5)(2) := '[1463703.1]';
    l_col_rows(1)(3) := '9926320';
    l_col_rows(2)(3) := 'No';
    l_col_rows(3)(3) := NULL;
    l_col_rows(4)(3) := 'XLA Trial Balance Report Package for AP';
    l_col_rows(5)(3) := '[553484.1]';
    l_col_rows(1)(4) := '9023641';
    l_col_rows(2)(4) := 'No';
    l_col_rows(3)(4) := NULL;
    l_col_rows(4)(4) := 'XLA Trial Balance Report Package';
    l_col_rows(5)(4) := '[553484.1]';
    l_col_rows(1)(5) := '13843627';
    l_col_rows(2)(5) := 'No';
    l_col_rows(3)(5) := NULL;
    l_col_rows(4)(5) := 'XLA Trial Balance Rebuild Report Package for AP';
    l_col_rows(5)(5) := '[1463703.1]';
    l_col_rows(1)(6) := '13616412';
    l_col_rows(2)(6) := 'No';
    l_col_rows(3)(6) := NULL;
    l_col_rows(4)(6) := 'XML for Trial Balance';
    l_col_rows(5)(6) := '[553484.1]';
    l_col_rows(1)(7) := '9162536';
    l_col_rows(2)(7) := 'No';
    l_col_rows(3)(7) := NULL;
    l_col_rows(4)(7) := 'Invoices view used by Trial Balance';
    l_col_rows(5)(7) := '[553484.1]';
    l_col_rows(1)(8) := '13616412';
    l_col_rows(2)(8) := 'No';
    l_col_rows(3)(8) := NULL;
    l_col_rows(4)(8) := 'Open Account Payables Balances Listing Group by Account';
    l_col_rows(5)(8) := '[444044.1]';
    l_col_rows(1)(9) := '13616412';
    l_col_rows(2)(9) := 'No';
    l_col_rows(3)(9) := NULL;
    l_col_rows(4)(9) := 'Open Account Payables Balances Listing Group by Third Party';
    l_col_rows(5)(9) := '[444044.1]';
    l_col_rows(1)(10) := '12382509';
    l_col_rows(2)(10) := 'No';
    l_col_rows(3)(10) := NULL;
    l_col_rows(4)(10) := 'XML Publisher';
    l_col_rows(5)(10) := '[553484.1]';
    l_col_rows(1)(11) := '9162536';
    l_col_rows(2)(11) := 'No';
    l_col_rows(3)(11) := NULL;
    l_col_rows(4)(11) := 'Includes Summary/Detail Report Mode change and Trial Balance Remodel Phase 4';
    l_col_rows(5)(11) := '[553484.1]';
  END IF;
  
  -- Check if applied
  IF l_col_rows.exists(1) THEN
  FOR i in 1..l_col_rows(1).count loop
    l_step := '40';
    OPEN get_app_date(l_col_rows(1)(i),l_rel);
    FETCH get_app_date INTO l_app_date;
    CLOSE get_app_date;
    IF l_app_date is not null THEN
      l_step := '50';
      l_col_rows(2)(i) := 'Yes';
      l_col_rows(3)(i) := to_char(l_app_date);
    END IF;
  END LOOP;
  END IF;

  --Render
  l_step := '60';

  l_sig.title := 'Recommended Patches';
  l_sig.fail_condition := '[Applied] = [No]';
  l_sig.problem_descr := 'Please check if any of the recommended patches were not applied '||
    'in this instance';
  l_sig.solution := '<ul><li>Please review list above and schedule
    to apply any unappplied patches as soon as possible</li>
    <li>Refer to the note indicated for more information about
    each patch</li></ul>';
  l_sig.success_msg := null;
  l_sig.print_condition := 'ALWAYS';
  l_sig.fail_type := 'W';
  l_sig.print_sql_output := 'Y';
  l_sig.limit_rows := 'N';
  l_sig.include_in_xml :='N';

  l_step := '70';
  RETURN process_signature_results(
    'REC_PATCH_CHECK',     -- sig ID
    l_sig,                 -- signature information
    l_col_rows,            -- data
    l_hdr);                -- headers
EXCEPTION WHEN OTHERS THEN
  print_log('Error in check_rec_patches at step '||l_step);
  raise;
END check_rec_patches;


PROCEDURE add_signature(
  p_sig_id           VARCHAR2,     -- Unique Signature identifier
  p_sig_sql          VARCHAR2,     -- The text of the signature query
  p_title            VARCHAR2,     -- Signature title
  p_fail_condition   VARCHAR2,     -- RSGT1 (RS greater than 1), RS (row selected), NRS (no row selected)
  p_problem_descr    VARCHAR2,     -- Problem description
  p_solution         VARCHAR2,     -- Problem solution
  p_success_msg      VARCHAR2    DEFAULT null,      -- Message on success
  p_print_condition  VARCHAR2    DEFAULT 'ALWAYS',  -- ALWAYS, SUCCESS, FAILURE, NEVER
  p_fail_type        VARCHAR2    DEFAULT 'W',       -- Warning(W), Error(E), Informational(I) is for use of data dump so no validation
  p_print_sql_output VARCHAR2    DEFAULT 'RS',      -- Y/N/RS - when to print data
  p_limit_rows       VARCHAR2    DEFAULT 'Y',       -- Y/N
  p_extra_info       HASH_TBL_4K DEFAULT CAST(null AS HASH_TBL_4K), -- Additional info
  p_child_sigs       VARCHAR_TBL DEFAULT VARCHAR_TBL(),
  p_include_in_dx_summary   VARCHAR2    DEFAULT 'N') --should signature be included in DX Summary
 IS

  l_rec signature_rec;
BEGIN
  l_rec.sig_sql          := p_sig_sql;
  l_rec.title            := p_title;
  l_rec.fail_condition   := p_fail_condition;
  l_rec.problem_descr    := p_problem_descr;
  l_rec.solution         := p_solution;
  l_rec.success_msg      := p_success_msg;
  l_rec.print_condition  := p_print_condition;
  l_rec.fail_type        := p_fail_type;
  l_rec.print_sql_output := p_print_sql_output;
  l_rec.limit_rows       := p_limit_rows;
  l_rec.extra_info       := p_extra_info;
  l_rec.child_sigs       := p_child_sigs;
  l_rec.include_in_xml   := p_include_in_dx_summary;
  g_signatures(p_sig_id) := l_rec;
EXCEPTION WHEN OTHERS THEN
  print_log('Error in add_signature procedure: '||p_sig_id);
  raise;
END add_signature;


FUNCTION run_stored_sig(p_sig_id varchar2) RETURN VARCHAR2 IS

  l_col_rows COL_LIST_TBL := col_list_tbl();
  l_col_hea  VARCHAR_TBL := varchar_tbl();
  l_sig      signature_rec;

BEGIN
  print_log('Processing signature: '||p_sig_id);
  -- Get the signature record from the signature table
  BEGIN
    l_sig := g_signatures(p_sig_id);
  EXCEPTION WHEN NO_DATA_FOUND THEN
    print_log('No such signature '||p_sig_id||' error in run_stored_sig');

    raise;
  END;

  -- Run SQL
  run_sig_sql(l_sig.sig_sql, l_col_rows, l_col_hea,
              l_sig.limit_rows);

  -- Evaluate and print
  RETURN process_signature_results(
       p_sig_id,               -- signature id
       l_sig,                  -- Name/title of signature item
       l_col_rows,             -- signature SQL row values
       l_col_hea);             -- signature SQL column names
 
	   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in run_stored_sig procedure for sig_id: '||p_sig_id);
  print_log('Error: '||sqlerrm);
  print_error('PROGRAM ERROR<br/>
    Error for sig '||p_sig_id||' '||sqlerrm||'<br/>
    See the log file for additional details');
  return null;
END run_stored_sig;


--########################################################################################
--     Beginning of specific code of this ANALYZER 
--########################################################################################

----------------------------------------------------------------
--- Validate Parameters                                      ---
----------------------------------------------------------------
PROCEDURE validate_parameters (
      p_org_ids    IN VARCHAR2,
      p_ledger_id  IN NUMBER,
      p_mode       IN VARCHAR2,
      p_invoice_id IN NUMBER,
      p_tb_code    IN VARCHAR2,
      p_liab_acc   IN varchar2,
      p_start_date IN VARCHAR2,
      p_end_date   IN VARCHAR2,
      p_max_output_rows IN NUMBER,
      p_debug_mode      IN VARCHAR2) IS

  l_from_date    VARCHAR2(25);
  l_to_date     VARCHAR2(25);
  l_revision     VARCHAR2(25);
  l_date_char    VARCHAR2(30);
  l_instance     V$INSTANCE.INSTANCE_NAME%TYPE;
  l_apps_version FND_PRODUCT_GROUPS.RELEASE_NAME%TYPE;
  l_host         V$INSTANCE.HOST_NAME%TYPE;
  
  l_step         VARCHAR2(4) := '0';
  l_start_date VARCHAR2(25);
  l_end_date   VARCHAR2(25);
  l_view_name    VARCHAR2(100);
  l_dynamic_sql  VARCHAR2(1000);
  l_ccid         NUMBER;
  l_table_name  VARCHAR2(30);
  
  invalid_parameters EXCEPTION;
  no_tb              EXCEPTION;
  no_transaction     EXCEPTION;
  no_account         EXCEPTION;
  no_undo            EXCEPTION;
  no_daterange       EXCEPTION;
  no_undo_table      EXCEPTION;
   
BEGIN
 
  -- Determine instance info
  BEGIN
  
  l_step := '1';

    SELECT max(release_name) INTO l_apps_version
    FROM fnd_product_groups;

    SELECT instance_name, host_name
    INTO l_instance, l_host
    FROM v$instance;

  EXCEPTION WHEN OTHERS THEN
    print_log('Error in validate_parameters gathering instance information: '
      ||sqlerrm);
    raise;
  END;
  
  l_step := '2';
  l_start_date := p_start_date;--to_char(nvl(p_start_date,sysdate-30),'DD-MON-YYYY'); --
  l_end_date := p_end_date;--to_char(nvl(p_end_date,sysdate),'DD-MON-YYYY');--
  
-- Revision and date values can be populated by RCS
  l_revision := rtrim(replace('$Revision: 200.4 $','$',''));  
  l_revision := ltrim(replace(l_revision,'Revision:',''));
  l_date_char := rtrim(replace('$Date: 2015/08/11 22:05:55 $','$',''));
  l_date_char := ltrim(replace(l_date_char,'Date:',''));
  l_date_char := to_char(to_date(l_date_char,'YYYY/MM/DD HH24:MI:SS'),'DD-MON-YYYY');
 
-- Create global hash for report information
  g_rep_info('Host') := l_host;
  g_rep_info('Instance') := l_instance;
  g_rep_info('Apps Version') := l_apps_version;
  g_rep_info('File Name') := 'ap_trial_balance_analyzer.sql';
  g_rep_info('File Version') := l_revision;   
  g_rep_info('Execution Date') := to_char(sysdate,'DD-MON-YYYY HH24:MI:SS');
  g_rep_info('Description') := ('The ' || analyzer_title ||' Analyzer ' || '<a href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=1553507.1&id=1553507.1" target="_blank">(Note 1553507.1)</a> ' || ' is a self-service health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer.');

  ------------------------------------------------------------------------------
  -- NOTE: Add code here for validation to the parameters of your diagnostic
  ------------------------------------------------------------------------------
  
  l_step := '3';
  
  g_max_output_rows := nvl(p_max_output_rows,20);
  g_debug_mode := nvl(p_debug_mode, 'Y');
 
  l_step := '4';
  -- TB is null
  IF (p_tb_code is null AND upper(ltrim(rtrim(p_mode))) <> 'UNDO') THEN
     raise NO_TB;
  END IF;

  l_step := '4.1';
  -- Transaction mode is Invoice and the required parameters are not supplied
  IF upper(ltrim(rtrim(p_mode))) = 'TRANSACTION' AND (p_invoice_id is null
  OR p_start_date is null OR p_end_date is null
  OR p_ledger_id is null OR p_tb_code is null) THEN
     raise NO_TRANSACTION;
  END IF;

  l_step := '4.2';
  -- Transaction mode is Account and the required parameters are not supplied
  IF upper(ltrim(rtrim(p_mode))) = 'ACCOUNT' AND (p_liab_acc is null
  OR p_start_date is null OR p_end_date is null
  OR p_ledger_id is null OR p_tb_code is null) THEN
     raise NO_ACCOUNT;
  END IF;

  l_step := '4.3';
  -- Transaction mode is Undo and the required parameters are not supplied
  IF upper(ltrim(rtrim(p_mode))) = 'UNDO' AND (p_liab_acc is null OR p_ledger_id is null) THEN
     raise NO_UNDO;
  END IF;
  
  l_step := '4.4';
  -- Transaction mode is Undo and AP_UNDO_EVENT_LOG table does not exist
  IF upper(ltrim(rtrim(p_mode))) = 'UNDO' THEN
    BEGIN
      SELECT table_name INTO l_table_name
      FROM dba_tables
      WHERE table_name = 'AP_UNDO_EVENT_LOG';
    EXCEPTION WHEN NO_DATA_FOUND THEN
      raise NO_UNDO_TABLE;
    END;
  END IF;

  l_step := '4.5';
  -- Transaction mode is Generic and the required parameters are not supplied
  IF upper(ltrim(rtrim(p_mode))) = 'DATERANGE' AND (p_liab_acc is null
  OR p_start_date is null OR p_end_date is null
  OR p_tb_code is null OR p_ledger_id is null) THEN
     raise NO_DATERANGE;
  END IF;

  l_step := '4.6';
  IF (p_liab_acc is not null) THEN
    BEGIN
      SELECT concatenated_segs_view_name
      INTO l_view_name
      FROM fnd_id_flexs
      WHERE application_id = 101
      AND   id_flex_code = 'GL#'
      AND   id_flex_name = 'Accounting Flexfield';

       l_dynamic_sql :=
         'SELECT ccid.code_combination_id
          FROM '||l_view_name||' ccid,
                  gl_ledgers gls
          WHERE ccid.concatenated_segments = '''||ltrim(rtrim(p_liab_acc))||'''
          AND   gls.ledger_id = '||p_ledger_id||'
          AND   gls.chart_of_accounts_id = ccid.chart_of_accounts_id
          AND   ccid.gl_account_type = ''L''';
       EXECUTE IMMEDIATE l_dynamic_sql INTO l_ccid;
    EXCEPTION WHEN OTHERS THEN
      print_out('Liability Account passed:'||p_liab_acc||' - cannot be found in '||
        l_view_name||'. Process cannot continue.'||l_dynamic_sql);
      print_log('Liability Account passed:'||p_liab_acc||' - cannot be found in '||
        l_view_name||'. Process cannot continue.'||l_dynamic_sql);
      RAISE;
    END;
  END IF;
  
  l_step := '5';

  -- Create global hash for parameters. Numbers required for the output order
  g_parameters(' 1. Analyzer Mode') := p_mode;
  g_parameters(' 2. Ledger ID') := p_ledger_id;
  g_parameters(' 3. TB Definition Code') := p_tb_code;
  g_parameters(' 4. Start Date') := l_start_date;
  g_parameters(' 5. End Date') := l_end_date;
  g_parameters(' 6. Invoice ID') := p_invoice_id;
  g_parameters(' 7. Liability Account') := p_liab_acc||' (ID='||l_ccid||')';
  g_parameters(' 8. Max Rows') := g_max_output_rows;
  g_parameters(' 9. Debug Mode') := g_debug_mode;
  g_parameters('10. Application') := rtrim(ltrim(REPLACE(p_org_ids,' ',''),','),',');
  
  -- Create global hash of SQL token values
  g_sql_tokens('##$$MODE$$##')  := p_mode;
  g_sql_tokens('##$$LDGR$$##')  := p_ledger_id;
  g_sql_tokens('##$$TBDEF$$##') := p_tb_code;
  g_sql_tokens('##$$START$$##') := l_start_date;
  g_sql_tokens('##$$END$$##')   := l_end_date;
  g_sql_tokens('##$$REL$$##')   := g_rep_info('Apps Version');
  g_sql_tokens('##$$INV$$##')   := nvl(to_char(p_invoice_id),'NULL');
  g_sql_tokens('##$$ACC$$##')   := l_ccid;--p_liab_acc;
  g_sql_tokens('##$$ORGID$$##') := to_char(p_org_ids);

   l_step := '6';
   
EXCEPTION
  WHEN INVALID_PARAMETERS THEN
    print_out('Wrong responsibility provided. Process cannot continue.');
    print_log('Wrong responsibility provided. Process cannot continue.');
    raise;
  WHEN NO_TB THEN
    print_out('No TB Definition Code provided. Process cannot continue.');
    print_log('No TB Definition Code provided. Process cannot continue.');
    raise;
  WHEN NO_TRANSACTION THEN
    print_out('Not all required parameters for Transaction Mode provided. '||
      'Required parameters - Invoice ID, Ledger ID, TB Code, '||
      'Start Date, End Date. Process cannot continue.');
    print_log('Not all required parameters for Transaction Mode provided. '||
      'Required parameters - Invoice ID, Ledger ID, TB Code, '||
      'Start Date, End Date. Process cannot continue.');
    raise;
  WHEN NO_ACCOUNT THEN
    print_out('Not all required parameters for Account Mode provided. '||
      'Required parameters - Liability Account, Ledger ID, TB Code, '||
      'Start Date, End Date. Process cannot continue.');
    print_log('Not all required parameters for Account Mode provided. '||
      'Required parameters - Liability Account, Ledger ID, TB Code, '||
      'Start Date, End Date. Process cannot continue.');
    raise;
  WHEN NO_UNDO THEN
    print_out('Not all required parameters for Undo Mode provided. '||
      'Required parameters - Liability Account, Ledger ID. '||
      'Process cannot continue.');
    print_log('Not all required parameters for Undo Mode provided. '||
      'Required parameters - Liability Account, Ledger ID. '||
      'Process cannot continue.');
    raise;
 WHEN NO_UNDO_TABLE THEN
    print_out('AP_UNDO_EVENT_LOG table is not found indicating that undo '||
      'accounting has not been run.');
    print_out('There are no relevant validations for UNDO mode');
    print_log('AP_UNDO_EVENT_LOG table is not found indicating that undo '||
      'accounting has not been run.');
    print_log('There are no relevant validations for UNDO mode');
    raise;
  WHEN NO_DATERANGE THEN
    print_out('Not all required parameters for Daterange Mode provided. '||
      'Required parameters - Liability Account, Ledger ID, TB Code, '||
      'Start Date, End Date. Process cannot continue.');
    print_log('Not all required parameters for Daterange Mode provided. '||
      'Required parameters - Liability Account, Ledger ID, TB Code, '||
      'Start Date, End Date. Process cannot continue.');
    raise;
  WHEN OTHERS THEN
    print_out('Error validating parameters: '||  l_step ||' : '||sqlerrm);
    print_log('Error validating parameters: '||  l_step ||' : '||sqlerrm);
    raise;
END validate_parameters;



---------------------------------------------
-- Load signatures for this ANALYZER       --
---------------------------------------------
PROCEDURE load_signatures IS
  l_info  HASH_TBL_4K;
BEGIN
   -----------------------------------------
  -- Add definition of signatures here ....
  ------------------------------------------

  -------------------------------------------
  -- File Versions
  -------------------------------------------
  add_signature(
   'FILE_VERSIONS',
   'SELECT name , text
    FROM dba_source
    WHERE name IN (''XLA_TB_BALANCE_PKG'', ''XLA_TB_AP_REPORT_PVT'',
            ''XLA_TB_DATA_MANAGER_PVT'', ''XLA_TB_REPORT_PVT'')
    AND   type = ''PACKAGE BODY''
    AND   text like ''%$Header%''',
   'File Versions of Trial Balance Code',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');
  
  
  -------------------------------------------
  -- TB Definition Data
  -------------------------------------------
  add_signature(
   'XLA_TB_DEFINITIONS_B',
   'SELECT * FROM XLA_TB_DEFINITIONS_B WHERE definition_code = ''##$$TBDEF$$##''',
   'Report Definition',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLA_TB_DEFINITIONS_TL',
   'SELECT * FROM XLA_TB_DEFINITIONS_TL WHERE definition_code = ''##$$TBDEF$$##''',
   'Report Definition Description',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLA_TB_DEFN_DETAILS',
   'SELECT * FROM XLA_TB_DEFN_DETAILS WHERE definition_code = ''##$$TBDEF$$##''',
   'Report Definition Details',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLA_TB_SUMMARY',
   'SELECT xtb.definition_code, xeh.ledger_id, decode(xeh.upg_batch_id,
           NULL,''NOT UPGRADE'', ''UPGRADE'') Upgraded, min(xtb.creation_date),
           count(*)
      FROM xla_trial_balances xtb, xla_ae_headers xeh
     WHERE xtb.ae_header_id = xeh.ae_header_id(+)
     AND   xtb.definition_code = ''##$$TBDEF$$##''
     group by xtb.definition_code, xeh.ledger_id, decode(xeh.upg_batch_id, NULL,
              ''NOT UPGRADE'',
              ''UPGRADE'')
     order by 2,1',
   'Report Definition Rebuild Summary Data',
   'NRS',
   'Report Definition Rebuild Summary Data',
   '<ul>
<li>It is recommended that the TB data is rebuilt before analyzing the data.  Rebuild will ensure there are no synchronization issues.</li>
<li>Rebuild Trial Balance.</li>
<li>Please see Metalink note 553484.1 for more information.</li>
<li>Source KB Article: [553484.1]</li></ul>',
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  -------------------------------------------
  -- Invoice Data
  -------------------------------------------
  add_signature(
   'AP_INVOICES_ALL',
   'SELECT * FROM ap_invoices_all WHERE invoice_id = ##$$INV$$##',
   'AP_INVOICES_ALL',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'AP_INVOICE_DISTRIBUTIONS_ALL',
    'SELECT * FROM ap_invoice_distributions_all WHERE invoice_id = ##$$INV$$##
     order by invoice_line_number, invoice_distribution_id',
   'AP_INVOICE_DISTRUBUTIONS_ALL',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APCHECKSALL_PAYMENTS_ON_THE_INVOICE',
    'SELECT * FROM ap_checks_all
      WHERE check_id in (SELECT distinct check_id
                           FROM ap_invoice_payments_all
                          WHERE invoice_id = ##$$INV$$##)
      order by check_id',
   'AP_CHECKS_ALL - Payments on the Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APINVOICEPAYMENTSALL_INVOICE_PAYMENTS',
    'SELECT * FROM ap_invoice_payments_all
      WHERE invoice_id = ##$$INV$$##
      order by check_id, invoice_payment_id',
   'AP_INVOICE_PAYMENTS_ALL - Invoice Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APPAYMENTHISTORYALL',
    'SELECT pay_hist.*
       FROM ap_invoice_payments_all inv_pay,
            ap_payment_history_all pay_hist
      WHERE inv_pay.invoice_id = ##$$INV$$##
      AND   inv_pay.check_id = pay_hist.check_id
      order by pay_hist.check_id, pay_hist.payment_history_id',
   'AP_PAYMENT_HISTORY_ALL',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APPAYMENTHISTDISTS',
    'SELECT pay_dist.*
       FROM ap_invoice_payments_all inv_pay,
            ap_payment_hist_dists pay_dist
      WHERE inv_pay.invoice_id = ##$$INV$$##
      AND   inv_pay.invoice_payment_id = pay_dist.invoice_payment_id
      order by pay_dist.payment_history_id , pay_dist.payment_hist_dist_id',
   'AP_PAYMENT_HIST_DISTS',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APINVOICEPREPAYSALL',
    'SELECT * FROM ap_invoice_prepays_all WHERE invoice_id = ##$$INV$$##',
   'AP_INVOICE_PREPAYS_ALL',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APPREPAYHISTORYALL',
   'SELECT DISTINCT pre_hist.*
    FROM ap_invoice_distributions_all inv_dist,
            ap_prepay_history_all pre_hist
     WHERE inv_dist.invoice_id = ##$$INV$$##
     AND   inv_dist.accounting_event_id = pre_hist.accounting_event_id',
   'AP_PREPAY_HISTORY_ALL',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APPREPAYAPPDISTS',
   'SELECT DISTINCT pre_dist.*
    FROM ap_prepay_app_dists pre_dist,
         ap_invoice_distributions_all inv_dist
    WHERE inv_dist.invoice_id = ##$$INV$$##
    AND   inv_dist.invoice_distribution_id = pre_dist.invoice_distribution_id',
   'AP_PREPAY_APP_DISTS',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APACCOUNTINGEVENTSALL_INVOICE',
   'SELECT * FROM ap_accounting_events_all
    WHERE source_table = ''AP_INVOICES''
    AND   source_id = ##$$INV$$##',
   'AP_ACCOUNTING_EVENTS_ALL - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APAEHEADERSALL_INVOICE',
   'SELECT aeh.*
    FROM ap_accounting_events_all eve,
         ap_ae_headers_all aeh
    WHERE eve.source_table = ''AP_INVOICES''
    AND   eve.source_id = ##$$INV$$##
    AND   eve.accounting_event_id = aeh.accounting_event_id',
   'AP_AE_HEADERS_ALL - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APAELINESALL_INVOICE',
   'SELECT ael.*
    FROM ap_accounting_events_all eve,
         ap_ae_headers_all aeh,
         ap_ae_lines_all ael
    WHERE eve.source_table = ''AP_INVOICES''
    AND   eve.source_id = ##$$INV$$##
    AND   eve.accounting_event_id = aeh.accounting_event_id
    AND   aeh.ae_header_id = ael.ae_header_id',
   'AP_AE_LINES_ALL - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APLIABILITYBALANCE_INVOICE',
   'SELECT *
    FROM ap_liability_balance alb
    WHERE alb.invoice_id = ##$$INV$$##
    AND   alb.ae_header_id IN (
            SELECT DISTINCT apae.ae_header_id
            FROM ap_ae_headers_all apae,
                 ap_accounting_events_all ev
            WHERE ev.source_table = ''AP_INVOICES''
            AND   ev.source_id = ##$$INV$$##
            AND   apae.accounting_event_id = ev.accounting_event_id)',
   'AP_LIABILITY_BALANCE - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APACCOUNTINGEVENTSALL_PAYMENTS',
   'SELECT *
    FROM ap_accounting_events_all ev
    WHERE ev.source_table = ''AP_CHECKS''
    AND   ev.source_id IN (
            SELECT aip.check_id
            FROM ap_invoice_payments_all aip
            WHERE aip.invoice_id = ##$$INV$$##)',
   'AP_ACCOUNTING_EVENTS_ALL - Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APAEHEADERSALL_PAYMENTS',
   'SELECT aeh.*
    FROM ap_accounting_events_all eve,
         ap_ae_headers_all aeh
    WHERE eve.source_table = ''AP_CHECKS''
    AND   eve.source_id IN (
            SELECT aip.check_id
            FROM ap_invoice_payments_all aip
            WHERE aip.invoice_id = ##$$INV$$##)
    AND   eve.accounting_event_id = aeh.accounting_event_id',
   'AP_AE_HEADERS_ALL - Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APAELINESALL_PAYMENTS',
   'SELECT ael.*
    FROM ap_accounting_events_all eve,
         ap_ae_headers_all aeh,
         ap_ae_lines_all ael
    WHERE eve.source_table = ''AP_CHECKS''
    AND   eve.source_id IN (
            SELECT aip.check_id
            FROM ap_invoice_payments_all aip
            WHERE aip.invoice_id = ##$$INV$$##)
    AND   eve.accounting_event_id = aeh.accounting_event_id
    AND   aeh.ae_header_id = ael.ae_header_id',
   'AP_AE_LINES_ALL - Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'APLIABILITYBALANCE_PAYMENTS',
   'SELECT *
    FROM ap_liability_balance alb
    WHERE alb.invoice_id = ##$$INV$$##
    AND   alb.ae_header_id IN (
            SELECT DISTINCT apae.ae_header_id
            FROM ap_ae_headers_all apae,
                 ap_accounting_events_all ev
            WHERE ev.source_table = ''AP_CHECKS''
            AND   ev.source_id IN (
                    SELECT aip.check_id
                    FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
                    AND   apae.accounting_event_id = ev.accounting_event_id)',
   'AP_LIABILITY_BALANCE - Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLATRANSACTIONENTITIES_INVOICE',
   'SELECT *
    FROM XLA.xla_transaction_entities ent
    WHERE ent.application_id = 200
    AND   ent.entity_code = ''AP_INVOICES''
    AND   nvl(source_id_int_1,-99) = ##$$INV$$##
    AND   ent.ledger_id = ##$$LDGR$$##',
   'XLA_TRANSACTION_ENTITIES - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLAEVENTS_INVOICE',
   'SELECT * FROM xla_events WHERE application_id = 200 and entity_id = ##$$INV$$## order by event_id',
   'XLA_EVENTS - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLAAEHEADERS_INVOICE',
   'SELECT * FROM xla_ae_headers xah
    WHERE xah.application_id = 200
    AND   xah.entity_id in (
            SELECT entity_id
            FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1,-99) = ##$$INV$$##
            AND   ent.ledger_id = ##$$LDGR$$##)
    AND   xah.ledger_id = ##$$LDGR$$##
    ORDER BY xah.event_id, xah.ae_header_id',
   'XLA_AE_HEADERS - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLAAELINES_INVOICE',
   'SELECT xal.*
    FROM xla_ae_headers xah , xla_ae_lines xal
    WHERE xah.application_id = 200
    AND   xah.entity_id in (
            SELECT entity_id
            FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1,-99) = ##$$INV$$##
            AND   ent.ledger_id = ##$$LDGR$$##)
    AND   xal.application_id = 200
    AND   xal.ae_header_id = xah.ae_header_id
    AND   xal.accounting_class_code = ''LIABILITY''
    AND   xah.ledger_id = ##$$LDGR$$##
    ORDER BY xah.event_id, xal.ae_header_id , xal.ae_line_num',
   'XLA_AE_LINES - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLADISTRIBUTIONLINKS_LIABILITY_LINES_FOR_INVOICE',
   'SELECT xdl.*
    FROM xla_ae_headers xah , xla_ae_lines xal,
         xla_distribution_links xdl
    WHERE xah.application_id = 200
    AND   xah.entity_id in (
            SELECT entity_id
            FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1,-99) = ##$$INV$$##
            AND   ent.ledger_id = ##$$LDGR$$##)
    AND   xal.application_id = 200
    AND   xal.ae_header_id = xah.ae_header_id
    AND   xal.accounting_class_code = ''LIABILITY''
    AND   xdl.application_id = 200
    AND   xdl.ae_header_id = xal.ae_header_id
    AND   xdl.ae_line_num = xal.ae_line_num
    AND   xah.ledger_id = ##$$LDGR$$##
    ORDER BY xdl.ae_header_id , xdl.ae_line_num',
   'XLA_DISTRIBUTION_LINKS - Liability Lines For Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLATRIALBALANCES_INVOICE',
   'SELECT xtb.*
    FROM xla_trial_balances xtb,
         (
           SELECT DISTINCT xah.ae_header_id,
                  xah.accounting_date,
                  xah.entity_id
           FROM xla_ae_headers xah
           WHERE xah.application_id = 200
           AND   xah.ledger_id = ##$$LDGR$$##
           AND   xah.event_id IN (
                   SELECT event_id FROM xla_events
                   WHERE entity_id in (
                           SELECT entity_id FROM XLA.xla_transaction_entities ent
                           WHERE ent.application_id = 200
                           AND   ent.entity_code = ''AP_INVOICES''
                           AND   nvl(source_id_int_1,-99) = ##$$INV$$##
                           AND   ent.ledger_id = ##$$LDGR$$##))
         ) dat
    WHERE xtb.definition_code = upper(''##$$TBDEF$$##'')
    AND   xtb.ledger_id = ##$$LDGR$$##
    AND   xtb.gl_date = trunc(dat.accounting_date)
    AND   xtb.source_entity_id = dat.entity_id
    AND   xtb.ae_header_id = dat.ae_header_id',
   'XLA_TRIAL_BALANCES - Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLATRANSACTIONENTITIES_PAYMENTS_ON_THE_INVOICE',
   'SELECT *
    FROM XLA.xla_transaction_entities ent
    WHERE ent.application_id = 200
    AND   ent.entity_code = ''AP_PAYMENTS''
    AND   nvl(source_id_int_1,-99) IN (
            SELECT distinct check_id FROM ap_invoice_payments_all aip
            WHERE aip.invoice_id = ##$$INV$$##)
    AND   ent.ledger_id = (
            SELECT inv.set_of_books_id FROM ap_invoices_all inv
            WHERE inv.invoice_id = ##$$INV$$## AND rownum < 2)',
   'XLA_TRANSACTION_ENTITIES - Payments on the Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLAEVENTS_PAYMENTS',
   'SELECT *
    FROM xla_events xe
    WHERE xe.application_id = 200
    AND   xe.entity_id IN (
            SELECT entity_id FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_PAYMENTS''
            AND   nvl(source_id_int_1,-99) IN (
                    SELECT distinct check_id FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
            AND   ent.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2))
    ORDER BY xe.entity_id, xe.event_id',
   'XLA_EVENTS - Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLAAEHEADERS_PAYMENTS',
   'SELECT *
    FROM xla_ae_headers xah
    WHERE xah.application_id = 200
    AND   xah.event_id IN (
            SELECT event_id FROM xla_events xe
            WHERE xe.application_id = 200
            AND   xe.entity_id IN (
                    SELECT entity_id FROM XLA.xla_transaction_entities ent
                    WHERE ent.application_id = 200
                    AND   ent.entity_code = ''AP_PAYMENTS''
                    AND   nvl(source_id_int_1,-99) IN (
                            SELECT distinct check_id FROM ap_invoice_payments_all aip
                            WHERE aip.invoice_id = ##$$INV$$##)
                    AND   ent.ledger_id = (
                            SELECT inv.set_of_books_id FROM ap_invoices_all inv
                            WHERE inv.invoice_id = ##$$INV$$##
                            AND   rownum < 2)))
    AND   xah.ledger_id = ##$$LDGR$$##
    ORDER BY xah.event_id, xah.ae_header_id',
   'XLA_AE_HEADERS - Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLAAELINES_PAYMENTS',
   'SELECT xal.*
    FROM xla_ae_headers xah , xla_ae_lines xal
    WHERE xah.application_id = 200
    AND   xah.event_id IN (
            SELECT event_id
            FROM xla_events xe
            WHERE xe.application_id = 200
            AND   xe.entity_id IN (
                    SELECT entity_id
                    FROM XLA.xla_transaction_entities ent
                    WHERE ent.application_id = 200
                    AND   ent.entity_code = ''AP_PAYMENTS''
                    AND   nvl(source_id_int_1,-99) IN (
                            SELECT distinct check_id FROM ap_invoice_payments_all aip
                            WHERE aip.invoice_id = ##$$INV$$##)
                    AND   ent.ledger_id = (
                            SELECT inv.set_of_books_id FROM ap_invoices_all inv
                            WHERE inv.invoice_id = ##$$INV$$##
                            AND   rownum < 2)))
    AND   xal.application_id = 200
    AND   xal.ae_header_id = xah.ae_header_id
    AND   xal.accounting_class_code = ''LIABILITY''
    AND   xah.ledger_id = ##$$LDGR$$##
    ORDER BY xal.ae_header_id , xal.ae_line_num',
   'XLA_AE_LINES - Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLADISTRIBUTIONLINKS_LIABILITY_LINES_FOR_PAYMENTS',
   'SELECT xdl.*
    FROM xla_ae_headers xah , xla_ae_lines xal , xla_distribution_links xdl
    WHERE xah.application_id = 200
    AND   xah.event_id IN (
            SELECT event_id FROM xla_events xe
            WHERE xe.application_id = 200
            AND   xe.entity_id IN (
                    SELECT entity_id FROM XLA.xla_transaction_entities ent
                    WHERE ent.application_id = 200
                    AND   ent.entity_code = ''AP_PAYMENTS''
                    AND   nvl(source_id_int_1,-99) IN (
                            SELECT distinct check_id FROM ap_invoice_payments_all aip
                            WHERE aip.invoice_id = ##$$INV$$##)
                    AND   ent.ledger_id = (
                            SELECT inv.set_of_books_id FROM ap_invoices_all inv
                            WHERE inv.invoice_id = ##$$INV$$##
                            AND   rownum < 2)))
    AND   xal.application_id = 200
    AND   xal.ae_header_id = xah.ae_header_id
    AND   xal.accounting_class_code = ''LIABILITY''
    AND   xdl.application_id = 200
    AND   xdl.ae_header_id = xal.ae_header_id
    AND   xdl.ae_line_num = xal.ae_line_num
    AND   xah.ledger_id = ##$$LDGR$$##',
   'XLA_DISTRIBUTION_LINKS - Liability Lines For Payments',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'XLATRIALBALANCES_PAYMENTS_ON_INVOICE',
   'SELECT xtb.*
    FROM xla_trial_balances xtb,
         (
           SELECT DISTINCT xah.ae_header_id,
                  xah.accounting_date,
                  xah.entity_id
           FROM xla_ae_headers xah
           WHERE xah.application_id = 200
           AND   xah.ledger_id = ##$$LDGR$$##
           AND   xah.entity_id IN (
                   SELECT entity_id FROM XLA.xla_transaction_entities ent
                   WHERE ent.application_id = 200
                   AND   ent.entity_code = ''AP_PAYMENTS''
                   AND   nvl(source_id_int_1,-99) IN (
                           SELECT distinct check_id FROM ap_invoice_payments_all aip
                           WHERE aip.invoice_id = ##$$INV$$##)
                   AND   ent.ledger_id = (
                           SELECT inv.set_of_books_id FROM ap_invoices_all inv
                           WHERE inv.invoice_id = ##$$INV$$##
                           AND   rownum < 2))
         ) dat
    WHERE xtb.definition_code = upper(''##$$TBDEF$$##'')
    AND   xtb.ledger_id = ##$$LDGR$$##
    AND   xtb.source_entity_id = dat.entity_id
    AND   xtb.ae_header_id = dat.ae_header_id',
   'XLA_TRIAL_BALANCES - Payments on Invoice',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'INVOICE_REMAINING_AMOUNTS_IN_11i_TB',
   'SELECT code_combination_id, vendor_id,
           sum(nvl(accounted_cr,0)) - sum(nvl(accounted_dr,0)) "REMAINING AMOUNT"
    FROM AP_LIABILITY_BALANCE
    WHERE invoice_id = ##$$INV$$##
    GROUP BY code_combination_id , vendor_id',
   'Remaining Amount for Invoice in 11i Trial Balance',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   '11iACCNTD_DATA_NOT_IN_11i_TB',
   'SELECT ''Missing Records APLB'' category,
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id org_id,
            ai.invoice_date,
            ai.invoice_type_lookup_code,
            ai.invoice_amount,
            ai.base_amount,
            aeh.accounting_event_id,
            aae.event_type_code,
            aeh.ae_header_id,
            aeh.gl_transfer_flag,
            ael.ae_line_id,
            ael.ae_line_number,
            ael.ae_line_type_code,
            ael.code_combination_id,
            ael.currency_code,
            ael.entered_dr,
            ael.entered_cr,
            ael.accounted_dr,
            ael.accounted_cr,
            ael.description,
            ael.gl_sl_link_id,
            aeh.set_of_books_id
     FROM ap_accounting_events_all aae,
          ap_ae_headers_all aeh,
          ap_ae_lines_all ael,
          ap_invoices_all ai
     WHERE aae.accounting_event_id = aeh.accounting_event_id
     AND   aeh.ae_header_id = ael.ae_header_id
     AND   ael.ae_line_type_code = ''LIABILITY''
     AND   ael.reference2 = ai.invoice_id
     AND   aeh.gl_transfer_flag = ''Y''
     AND   NOT EXISTS (
             SELECT /*+ parallel(aplb1) */ 1 FROM ap_liability_balance aplb1
             WHERE aplb1.ae_line_id = ael.ae_line_id
             AND   aplb1.ae_header_id = ael.ae_header_id
             AND   aplb1.set_of_books_id = aeh.set_of_books_id
             AND   aplb1.code_combination_id = ael.code_combination_id)
     AND   NOT EXISTS (
             SELECT 1 FROM xla_events xe
             WHERE xe.application_id = 200
             AND   xe.event_id = aeh.accounting_event_id
             AND   xe.upg_batch_id = -9999)
     AND   EXISTS (
             SELECT tiv.invoice_id
             FROM ap_invoices_all tiv,
                  hz_parties hzp,
                  hz_party_sites hzps,
                  ap_suppliers as1,
                  xla_transaction_entities_upg xte
             WHERE xte.entity_code = ''AP_INVOICES''
             AND   xte.ledger_id = ai.set_of_books_id
             AND   xte.application_id = 200
             AND   nvl(xte.source_id_int_1,-99) = tiv.invoice_id
             AND   tiv.party_id = hzp.party_id
             AND   tiv.vendor_id = as1.vendor_id(+)
             AND   ai.party_site_id = hzps.party_site_id(+)
             AND   ((as1.employee_id is null AND
                     hzps.party_site_id is not null) OR
                    (as1.employee_id is not null))
             AND   (tiv.payment_status_flag = ''Y'' OR
                    tiv.cancelled_date is not null)
             AND  tiv.invoice_id = ai.invoice_id)
     AND   ai.invoice_id = ##$$INV$$##
     UNION ALL
     SELECT ''Lines Created in 11i, Transferred to GL in R12'',
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_date,
            ai.invoice_type_lookup_code,
            ai.invoice_amount,
            ai.base_amount,
            aeh.accounting_event_id,
            aae.event_type_code,
            aeh.ae_header_id,
            aeh.gl_transfer_flag,
            ael.ae_line_id,
            ael.ae_line_number,
            ael.ae_line_type_code,
            ael.code_combination_id,
            ael.currency_code,
            ael.entered_dr,
            ael.entered_cr,
            ael.accounted_dr,
            ael.accounted_cr,
            ael.description,
            ael.gl_sl_link_id,
            aeh.set_of_books_id
     FROM ap_accounting_events_all aae,
          ap_ae_headers_all aeh,
          ap_ae_lines_all ael,
          ap_invoices_all ai
     WHERE aae.accounting_event_id = aeh.accounting_event_id
     AND   aeh.ae_header_id = ael.ae_header_id
     AND   ael.ae_line_type_code = ''LIABILITY''
     AND   ael.reference2 = ai.invoice_id
     AND   nvl(aeh.gl_transfer_flag, ''N'') <> ''Y''
     AND   EXISTS (
             SELECT 1 FROM xla_ae_headers xah
             WHERE xah.application_id = 200
             AND   xah.upg_batch_id is not null
             AND   xah.gl_transfer_status_code = ''Y''
             AND   xah.event_id = aeh.accounting_event_id
             AND   xah.Completion_Acct_Seq_Value = aeh.ae_header_id
             AND   xah.group_id is not null)
     AND   NOT EXISTS (
             SELECT /*+ parallel(aplb1) */ 1 FROM ap_liability_balance aplb1
             WHERE aplb1.ae_line_id = ael.ae_line_id
             AND   aplb1.ae_header_id = ael.ae_header_id
             AND   aplb1.set_of_books_id = aeh.set_of_books_id
             AND   aplb1.code_combination_id = ael.code_combination_id)
     AND   NOT EXISTS (
             SELECT 1 FROM xla_events xe
             WHERE xe.application_id = 200
             AND   xe.event_id = aeh.accounting_event_id
             AND   xe.upg_batch_id = -9999)
     AND   ai.invoice_id = ##$$INV$$##
     UNION ALL
     SELECT ''Non-Fully Paid Non-Canceled Invoices'',
            ai.invoice_id,
            ai.invoice_num,
            ai.org_id,
            ai.invoice_date,
            ai.invoice_type_lookup_code,
            ai.invoice_amount,
            ai.base_amount,
            aeh.accounting_event_id,
            aae.event_type_code,
            aeh.ae_header_id,
            aeh.gl_transfer_flag,
            ael.ae_line_id,
            ael.ae_line_number,
            ael.ae_line_type_code,
            ael.code_combination_id,
            ael.currency_code,
            ael.entered_dr,
            ael.entered_cr,
            ael.accounted_dr,
            ael.accounted_cr,
            ael.description,
            ael.gl_sl_link_id,
            aeh.set_of_books_id
     FROM ap_accounting_events_all aae,
          ap_ae_headers_all aeh,
          ap_ae_lines_all ael,
          ap_invoices_all ai
     WHERE aae.accounting_event_id = aeh.accounting_event_id
     AND   aeh.ae_header_id = ael.ae_header_id
     AND   ael.ae_line_type_code = ''LIABILITY''
     AND   ael.reference2 = ai.invoice_id
     AND   aeh.gl_transfer_flag = ''Y''
     AND   ai.cancelled_date is null
     AND   ai.payment_status_flag <> ''Y''
     AND   ai.invoice_amount <> 0
     AND   NOT EXISTS (
             SELECT /*+ parallel(aplb1) */ 1 FROM ap_liability_balance aplb1
             WHERE aplb1.ae_line_id = ael.ae_line_id
             AND   aplb1.ae_header_id = ael.ae_header_id
             AND   aplb1.set_of_books_id = aeh.set_of_books_id
             AND   aplb1.code_combination_id = ael.code_combination_id)
     AND   NOT EXISTS (
             SELECT 1 FROM xla_events xe
             WHERE xe.application_id = 200
             AND   xe.event_id = aeh.accounting_event_id
             AND   xe.upg_batch_id = -9999)
     AND   ai.invoice_id = ##$$INV$$##',
   '11i Accounted Data Present in 11i Headers/Lines Not in 11i Trial Balance',
   'RS',
   NULL,
   '<ul>
   <li>GDF Corruption: Missing records in AP_Liability_Balance</li>
   <li>Follow the instructions provided in note 1321370.1</li>
   <li>Source KB Article: [1321370.1]</li>
   </ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   '11iTB_DATA_NOT_IN_11iACCNTD_TABLES',
   'SELECT aplb.*
    FROM ap_liability_balance aplb
    WHERE 1=1
    AND NOT EXISTS (
	    SELECT 1
        FROM AP_AE_HEADERS_ALL aeh,
        ap_ae_lines_all ael
        WHERE ael.ae_header_id = aplb.ae_header_id
        AND ael.ae_line_id = aplb.ae_line_id
 -- AND TO_NUMBER(NVL(ael.reference2,0)) = aplb.invoice_id
 -- AND ael.ae_line_type_code = ''LIABILITY''
        AND ael.ae_header_id = aeh.ae_header_id
        )
        AND NOT EXISTS (
		    SELECT 1
            FROM ax.ax_sle_HEADERS aeh,
            ax.ax_sle_lines ael
            WHERE aeh.sle_header_id = ael.sle_header_id 
            AND ael.sle_header_id = aplb.sle_header_id
            AND ael.sle_line_num = aplb.sle_line_num
            )',
   '11i Trial Balance Data not in 11i Headers/Lines',
   'RS',
   '11i TB Data Not in 11i Accounting Tables',
   '<ul>
   <li>All data in ap_liability_balance table should exist in ap_ae_lines_all.</li>
   <li>This is a data corruption for which GDF is available.</li>
   <li>Follow instructions in the note 1513199.1</li>
   <li>Source KB Article: [1513199.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');
   
/*  add_signature(
   '11iDATA_GLTrx_IN_R12_MISSING_11iTB',
   'SELECT *
    FROM xla_ae_headers xah
    WHERE xah.gl_transfer_status_code = ''Y''
    AND   xah.accounting_entry_status_code = ''F''
    AND   xah.upg_batch_id IS NOT NULL
    AND   xah.group_id IS NOT NULL
    AND   xah.gl_transfer_date IS NOT NULL
    AND   xah.ledger_id = ##$$LDGR$$##
    AND   xah.entity_id IN (
            SELECT ent.entity_id FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1 , -99) = ##$$INV$$##
            AND   ent.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND rownum < 2)
            UNION ALL
            SELECT ent1.entity_id FROM XLA.xla_transaction_entities ent1
            WHERE ent1.application_id = 200
            AND   ent1.entity_code = ''AP_PAYMENTS''
            AND   nvl(ent1.source_id_int_1 , -99) IN (
                    SELECT distinct check_id FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
            AND   ent1.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2))
    AND   EXISTS (
            SELECT 1 FROM xla_ae_lines xal
            WHERE xal.application_id = 200
            AND   xal.ae_header_id = xah.ae_header_id
            AND   xal.accounting_class_code = ''LIABILITY'')
    AND   NOT EXISTS (
            SELECT 1
            FROM ap_liability_balance aplb,
                 ap_ae_headers_all aeh
            WHERE aplb.invoice_id = ##$$INV$$##
            AND   aeh.ae_header_id = aplb.ae_header_id
            AND   aeh.accounting_event_id = xah.event_id)',
   '11i Data Transferred to GL in R12, Missing Data in 11i Trial Balance',
   'NRS',
   NULL,
   NULL,
   NULL,
   'FAILURE',
   'I',
   'RS',
   'Y');*/

  add_signature(
   '11i_DATA_NOT_IN_R12_ACCNTD_TABLES',
   'SELECT aplb.*
    FROM ap_liability_balance aplb
    WHERE aplb.invoice_id = ##$$INV$$##
    AND   EXISTS (
            SELECT 1
            FROM xla_ae_headers xah,
                 ap_ae_headers_all aeh
            WHERE aplb.ae_header_id = xah.completion_acct_seq_value
            AND   200 = xah.completion_acct_seq_version_id
            AND   xah.upg_source_application_id = 200
            AND   xah.application_id = 200
            AND   xah.event_id = aeh.accounting_event_id
            AND   aeh.ae_header_id = aplb.ae_header_id
            AND   NOT EXISTS (
                    SELECT 1 FROM xla_ae_lines xal
                    WHERE aplb.ae_line_id = xal.ae_line_num
                    AND   xal.application_id = 200
                    AND   xal.ae_header_id = xah.ae_header_id))',
   '11i Accounted Data not in R12 Headers/lines',
   'RS',
   NULL,
   '11i Data not in R12 Accounting Tables',
   '<ul>
   <li>All data in ap_liability_balance table should exist in ap_ae_lines_all or AX tables and that data should be upgraded to the R12 XLA tables.</li>
   <li>Corruption/differences in the R11i accounting data and the ap_liability_balance data could cause the upgrade to R12 to fail.</li>
   <li>Follow instructions in the note 1513199.1</li>
   <li>Source KB Article: [1513199.1]</li></ul>',
   'FAILURE',
   'E',
   'RS',
   'Y');

/*  add_signature(
   'INVOICE_PAYMENT_AMOUNTS_IN_XLADISTRIBUTIONLINKS',
   'SELECT code_combination_id,
           sum(nvl(invoice_amount,0)) "Total Invoice",
           sum(nvl(payment_amount,0)) "Total Payment"
    FROM (
           SELECT xal.code_combination_id,
                  sum(nvl(xdl.unrounded_accounted_cr,0))-
                    sum(nvl(xdl.unrounded_accounted_dr,0)) "INVOICE_AMOUNT",
                  0 "PAYMENT_AMOUNT"
           FROM xla_ae_headers xah,
                xla_ae_lines xal,
                xla_distribution_links xdl
           WHERE xah.application_id = 200
           AND   xah.ledger_id = ##$$LDGR$$##
           AND   xah.upg_batch_id is null
           AND   xah.event_id IN (
                   SELECT accounting_event_id
                   FROM ap_invoice_distributions_all
                   WHERE invoice_id = ##$$INV$$##)
           AND   xal.application_id = 200
           AND   xal.ae_header_id = xah.ae_header_id
           AND   xal.accounting_class_code = ''LIABILITY''
           AND   xdl.application_id = xal.application_id
           AND   xdl.ae_header_id = xal.ae_header_id
           AND   xdl.ae_line_num = xal.ae_line_num
           GROUP BY xal.code_combination_id
           UNION ALL
           SELECT xal.code_combination_id,
                  0,
                  sum(nvl(xdl.unrounded_accounted_dr,0)) -
                    sum(nvl(xdl.unrounded_accounted_cr,0)) "PAYMENT AMOUNT"
           FROM xla_ae_headers xah,
                xla_ae_lines xal,
                xla_distribution_links xdl
           WHERE xah.application_id = 200
           AND   xah.ledger_id = ##$$LDGR$$##
           AND   xah.upg_batch_id is null
           AND   xah.event_id IN (
                   SELECT accounting_event_id
                   FROM ap_invoice_payments_all
                   WHERE invoice_id = ##$$INV$$##)
           AND   xal.application_id = 200
           AND   xal.ae_header_id = xah.ae_header_id
           AND   xal.accounting_class_code = ''LIABILITY''
           AND   xdl.application_id = xal.application_id
           AND   xdl.ae_header_id = xal.ae_header_id
           AND   xdl.ae_line_num = xal.ae_line_num
           AND   xdl.applied_to_source_id_num_1 = ##$$INV$$##
           GROUP BY xal.code_combination_id
         )
    GROUP BY code_combination_id',
   'Invoice / Payment Amounts in XLA_DISTRIBUTION_LINKS',
   'NRS',
   NULL,
   NULL,
   NULL,
   'FAILURE',
   'I',
   'RS',
   'Y');*/

  add_signature(
   'MIN_AND_MAX_ACCOUNTING_DATE_IN_TRIAL_BALANCE_FOR_INVOICEPAYMENT',
   'SELECT to_char(min(gl_date),''DD-MON-YYYY'') "Start Date",
           to_char(max(gl_date),''DD-MON-YYYY'') "As of Date"
    FROM xla_trial_balances xtb
    WHERE xtb.definition_code = upper(''##$$TBDEF$$##'')
    AND   xtb.ledger_id = ##$$LDGR$$##
    AND   not (trunc(gl_date) BETWEEN ''##$$START$$##''  AND   ''##$$END$$##'')
    AND   nvl(xtb.applied_to_entity_id,xtb.source_entity_id) in (
            SELECT entity_id FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1,-99) = ##$$INV$$##
            AND   ent.ledger_id = ##$$LDGR$$##)',
   'Min and Max Accounting Date in Trial Balance For Invoice/payment',
   'NRS',
   'Incorrect min and max accounting date used for the trial balance',
   '<ul>
<li>Please run Trial Balance to include ALL invoice and payment event dates if this invoice has to be included in the report.</li>
</ul>',
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'REMAINING_AMOUNT_FOR_INVOICE_PER_PARTY_FROM_TRIAL_BALANCE',
   'SELECT xte.source_id_int_1 "Invoice Id",
           xtb.party_id,
          sum(nvl(xtb.ACCTD_UNROUNDED_CR,0)) -
            sum(nvl(xtb.ACCTD_UNROUNDED_DR,0)) "Remaining Amount"
    FROM xla_trial_balances xtb, xla.xla_transaction_entities xte
    WHERE nvl(xtb.APPLIED_TO_ENTITY_ID,xtb.SOURCE_ENTITY_ID) = xte.entity_id
    AND   xte.entity_id in (
            SELECT entity_id
            FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1,-99) = ##$$INV$$##
            AND   ent.ledger_id = ##$$LDGR$$##)
    AND   xtb.definition_code = upper(''##$$TBDEF$$##'')
    AND   xtb.ledger_id = ##$$LDGR$$##
    GROUP BY xte.source_id_int_1, xtb.party_id',
   'Remaining Amount For Invoice Per Party From Trial Balance',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');


  add_signature(
   'DATA_MARKED_AS_TRANSFERRED_TO_GL_BUT_NOT_EXISTS_IN_GL',
   'SELECT DISTINCT xah.*
    FROM xla_ae_headers xah,
         xla_ae_lines xal,
         (
           SELECT ent.entity_id
           FROM xla.xla_transaction_entities ent
           WHERE ent.application_id = 200 AND ent.entity_code = ''AP_INVOICES''
           AND   nvl(source_id_int_1 , -99) = ##$$INV$$##
           AND   ent.ledger_id = (
                   SELECT inv.set_of_books_id
                   FROM ap_invoices_all inv
                   WHERE inv.invoice_id = ##$$INV$$##
                   AND   rownum < 2)
           UNION ALL
           SELECT ent1.entity_id FROM XLA.xla_transaction_entities ent1
           WHERE ent1.application_id = 200
           AND   ent1.entity_code = ''AP_PAYMENTS''
           AND   nvl(ent1.source_id_int_1 , -99) IN (
                   SELECT distinct check_id FROM ap_invoice_payments_all aip
                   WHERE aip.invoice_id = ##$$INV$$##)
           AND   ent1.ledger_id = (
                   SELECT inv.set_of_books_id FROM ap_invoices_all inv
                   WHERE inv.invoice_id = ##$$INV$$## AND rownum < 2)
         ) dat
    WHERE xah.application_id = 200
    AND   xah.ledger_id = ##$$LDGR$$##
    AND   xah.entity_id = dat.entity_id
    AND   xah.gl_transfer_status_code = ''Y''
    AND   xah.upg_batch_id is null
    AND   xal.application_id = 200
    AND   xal.ae_header_id = xah.ae_header_id
    AND   NOT EXISTS (
            SELECT 1
            FROM gl_import_references gir,
                 gl_je_headers gh
            WHERE gir.gl_sl_link_id = xal.gl_sl_link_id
            AND   gir.gl_sl_link_table = xal.gl_sl_link_table
            AND   gh.je_header_id = gir.je_header_id
            AND   gh.je_batch_id = gir.je_batch_id
            AND   gh.ledger_id > 0
            AND   gh.ledger_id = xah.ledger_id)',
   'Data Marked As Transferred to Gl, but Not Exists in GL',
   'RS',
   'Header marked as transferred to GL, but does not exist in GL',
   '<ul>
<li>This could be due to bug 6945231.</li>
<li>Apply patch 6945231:R12.XLA.A to prevent future occurences. Log a SR with Oracle Support for Datafix.</li>
</ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'DATA_MULTIPOSTED_TO_GLFOR_INVOICE',
   'SELECT gir.gl_sl_link_id , gir.gl_sl_link_table
    FROM gl_import_references gir,
         gl_je_headers gh,
         (
           SELECT distinct xal.gl_sl_link_id , xal.gl_sl_link_table
           FROM xla_ae_headers xah,
                xla_ae_lines xal,
                ap_invoice_distributions_all inv_dist
           WHERE xah.application_id = 200
           AND   xah.ledger_id = ##$$LDGR$$##
           AND   xah.upg_batch_id is null
           AND   xah.accounting_entry_status_code = ''F''
           AND   xah.event_id = inv_dist.accounting_event_id
           AND   inv_dist.invoice_id = ##$$INV$$##
           AND   xal.application_id = 200
           AND   xal.ae_header_id = xah.ae_header_id
           AND   xal.ae_line_num > 0
         ) dat
    WHERE gir.gl_sl_link_id = dat.gl_sl_link_id
    AND   gir.gl_sl_link_table = dat.gl_sl_link_table
    AND   gir.je_header_id = gh.je_header_id
    AND   gh.ledger_id > 0
    AND   gh.ledger_id = ##$$LDGR$$##
    AND   gh.accrual_rev_je_header_id is null
    GROUP BY gir.gl_sl_link_id, gir.gl_sl_link_table
    HAVING count(1) > 1',
   'Data Multiposted to GL(for Invoice)',
   'RS',
   'There are lines posted more than once to GL (for Invoice)',
   '<ul>
<li>Apply patch 6694500:R12.XLA.A to prevent future occurences. Log a SR with Oracle Support for Datafix.</li>
</ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'DATA_MULTIPOSTED_TO_GLFOR_PAYMENTS_ON_INVOICE',
   'SELECT gir.gl_sl_link_id,
           gir.gl_sl_link_table
    FROM gl_import_references gir,
         gl_je_headers gh,
         (
           SELECT distinct xal.gl_sl_link_id , xal.gl_sl_link_table
           FROM xla_ae_headers xah,
                xla_ae_lines xal,
                ap_invoice_payments_all inv_pay
           WHERE xah.application_id = 200
           AND   xah.ledger_id = ##$$LDGR$$##
           AND   xah.upg_batch_id is null
           AND   xah.event_id = inv_pay.accounting_event_id
           AND   xah.accounting_entry_status_code = ''F''
           AND   inv_pay.invoice_id = ##$$INV$$##
           AND   xal.application_id = 200
           AND   xal.ae_header_id = xah.ae_header_id
           AND   xal.ae_line_num > 0
         ) dat
    WHERE gir.gl_sl_link_id = dat.gl_sl_link_id
    AND   gir.gl_sl_link_table = dat.gl_sl_link_table
    AND   gir.je_header_id = gh.je_header_id
    AND   gh.ledger_id > 0 AND gh.ledger_id = ##$$LDGR$$##
    AND   gh.accrual_rev_je_header_id is null
    GROUP BY gir.gl_sl_link_id , gir.gl_sl_link_table
    HAVING count(1) > 1',
   'Data Multiposted to Gl(for Payments on Invoice)',
   'RS',
   'There are lines posted more than once to GL(for Payments on Invoice)',
   '<ul>
<li>Accounting for Payment has been posted more than once to GL.</li>
<li>Apply patch 6694500:R12.XLA.A to prevent future occurences. Log a SR with Oracle Support for Datafix.</li>
</ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'DATA_WITH_INCORRECT_AMOUNT_BETWEEN_AP_AND_XLA',
   'SELECT ''INVOICE'' "Source",
           aid.invoice_id "Invoice Id",
           aid.invoice_distribution_id "Distribution Id",
           aid.accounting_event_id "Event Id",
           nvl(aid.base_amount,aid.amount) "Ap Amount",
           sum(nvl(xdl.unrounded_accounted_cr, 0)) -
             sum(nvl(xdl.unrounded_accounted_dr, 0)) "Xla Amount"
    FROM ap_invoice_distributions_all aid,
         xla_distribution_links xdl,
         xla_ae_headers xh, xla_ae_lines xl
    WHERE aid.invoice_id = ##$$INV$$##
    AND   aid.accounting_event_id = xh.event_id
    AND   aid.posted_flag = ''Y''
    AND   xh.ledger_id = ##$$LDGR$$##
    AND   xh.balance_type_code = ''A''
    AND   xh.application_id = 200
    AND   xdl.application_id = 200
    AND   xdl.ae_header_id = xl.ae_header_id
    AND   xdl.event_id = xh.event_id
    AND   xdl.ae_line_num = xl.ae_line_num
    AND   xdl.source_distribution_id_num_1 = aid.invoice_distribution_id
    AND   xdl.source_distribution_type = ''AP_INV_DIST''
    AND   xl.accounting_class_code = ''LIABILITY''
    AND   xl.ae_header_id = xh.ae_header_id
    AND   xl.application_id = 200
    GROUP BY ''INVOICE'', aid.invoice_id , aid.invoice_distribution_id,
               aid.accounting_event_id , nvl(aid.base_amount, aid.amount)
    HAVING abs(nvl(aid.base_amount, aid.amount)) <>
             abs(sum(nvl(xdl.unrounded_accounted_cr,0)) -
               sum(nvl(xdl.unrounded_accounted_dr,0)))
    UNION ALL
    SELECT ''PREPAYMENT'' "Source",
           aph.invoice_id "Invoice Id",
           aprp.prepay_app_dist_id "Distribution Id",
           aprp.accounting_event_id "Event Id",
           nvl(aprp.base_amount, aprp.amount) "Ap Amount",
           sum(nvl(xdl.unrounded_accounted_cr, 0)) -
             sum(nvl(xdl.unrounded_accounted_dr, 0)) "Xla Amount"
    FROM ap_prepay_history_all aph,
         ap_prepay_app_dists aprp,
         xla_distribution_links xdl,
         xla_ae_headers xh,
         xla_ae_lines xl
    WHERE aph.invoice_id = ##$$INV$$##
    AND   aprp.accounting_event_id = aph.accounting_event_id
    AND   aprp.accounting_event_id = xh.event_id
    AND   xh.ledger_id = ##$$LDGR$$##
    AND   xh.balance_type_code = ''A''
    AND   xh.application_id = 200
    AND   xdl.application_id = 200
    AND   xdl.ae_header_id = xl.ae_header_id
    AND   xdl.event_id = xh.event_id
    AND   xdl.ae_line_num = xl.ae_line_num
    AND   xdl.source_distribution_id_num_1 = aprp.prepay_app_dist_id
    AND   xl.accounting_class_code = ''LIABILITY''
    AND   xdl.source_distribution_type = ''AP_PREPAY''
    AND   xl.ae_header_id = xh.ae_header_id
    AND   xl.application_id = 200
    GROUP BY ''PREPAYMENT'', aph.invoice_id, aprp.prepay_app_dist_id,
             aprp.accounting_event_id, nvl(aprp.base_amount, aprp.amount)
    HAVING abs(nvl(aprp.base_amount, aprp.amount)) <>
              abs(sum(nvl(xdl.unrounded_accounted_cr,0)) -
                sum(nvl(xdl.unrounded_accounted_dr,0)))
    UNION ALL
    SELECT ''PAYMENT'' "Source", a.invoice_id "Invoice Id",
           apd.payment_hist_dist_id "Distribution Id",
           apd.accounting_event_id "Event Id",
           nvl(apd.invoice_dist_base_amount, apd.invoice_dist_amount) "Ap Amount",
           sum(nvl(xdl.unrounded_accounted_dr, 0)) -
             sum(nvl(xdl.unrounded_accounted_cr, 0)) "Xla Amount"
    FROM (
           SELECT DISTINCT p.invoice_id,
                  p.accounting_event_id
           FROM ap_invoice_payments_all p
           WHERE p.invoice_id = ##$$INV$$##
         ) a,
         ap_payment_hist_dists apd,
         xla_distribution_links xdl,
         xla_ae_headers xh,
         xla_ae_lines xl
    WHERE apd.accounting_event_id = a.accounting_event_id
    AND   apd.accounting_event_id = xh.event_id
    AND   xh.ledger_id = ##$$LDGR$$##
    AND   xh.balance_type_code = ''A''
    AND   xh.application_id = 200
    AND   xdl.application_id = 200
    AND   xdl.ae_header_id = xl.ae_header_id
    AND   xdl.event_id = xh.event_id
    AND   xdl.ae_line_num = xl.ae_line_num
    AND   xdl.source_distribution_id_num_1 =
            decode(apd.reversal_flag,
              ''Y'', apd.reversed_pay_hist_dist_id,
              apd.payment_hist_dist_id)
    AND   xl.accounting_class_code = ''LIABILITY''
    AND   xl.ae_header_id = xh.ae_header_id AND xl.application_id = 200
    GROUP BY ''PAYMENT'', a.invoice_id, apd.payment_hist_dist_id,
             apd.accounting_event_id,
             nvl(apd.invoice_dist_base_amount, apd.invoice_dist_amount)
    HAVING abs(nvl(apd.invoice_dist_base_amount, apd.invoice_dist_amount)) <>
             abs(sum(nvl(xdl.unrounded_accounted_dr,0)) -
               sum(nvl(xdl.unrounded_accounted_cr,0)))',
   'Data with Incorrect Amount Between AP and XLA',
   'RS',
   'There are invoices with different amounts in AP and XLA',
   '<ul>
<li>There is a mismatch between AP amounts and XLA amounts in Entered currency.</li>
<li>Log a SR with Oracle Support and upload this report.</li>
</ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'GL_TRANSFERRED_DATA_MISSING_FROM_TRIAL_BALANCE',
   'SELECT distinct xah.*
    FROM xla_ae_headers xah
    WHERE xah.application_id = 200
    AND   xah.ledger_id = ##$$LDGR$$##
    AND   xah.entity_id IN (
            SELECT ent.entity_id FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1 , -99) = ##$$INV$$##
            AND   ent.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2)
            UNION ALL
            SELECT ent1.entity_id FROM XLA.xla_transaction_entities ent1
            WHERE ent1.application_id = 200
            AND   ent1.entity_code = ''AP_PAYMENTS''
            AND   nvl(ent1.source_id_int_1 , -99) IN (
                    SELECT distinct check_id FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
            AND   ent1.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2))
    AND   xah.gl_transfer_status_code = ''Y''
    AND   EXISTS (
            SELECT 1 FROM xla_ae_lines xal
            WHERE xal.application_id = 200
            AND   xal.ae_header_id = xah.ae_header_id
            AND   xal.accounting_class_code = ''LIABILITY'')
    AND   NOT EXISTS (
            SELECT 1 FROM xla_trial_balances xtb
            WHERE xtb.definition_code = upper(''##$$TBDEF$$##'')
            AND   xtb.ledger_id = ##$$LDGR$$##
            AND   xtb.ae_header_id = xah.ae_header_id
            AND   xtb.source_entity_id = xah.entity_id
            AND   xtb.gl_date = trunc(xah.accounting_date))',
   'Gl Transferred Data Missing From Trial Balance',
   'RS',
   'There are headers missing from the trial balance',
   '<ul>
<li>Missing accounting headers in XLA_TRIAL_BALANCES table.</li>
<li>Rebuild Trial Balance.</li>
<li>Please see Metalink note 553484.1 for more information.</li>
<li>Source KB Article: [553484.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');
   
  add_signature(
   'GL_TRANSFERRED_FUTURE_LINE_DATA_MISSING_FROM_TRIAL_BALANCE',
   'SELECT distinct xah.*
    FROM xla_ae_lines xal,
     xla_ae_headers xah
    WHERE xal.application_id = 200
    AND xah.application_id = 200
    AND xal.ae_header_id = xah.ae_header_id
    AND xah.ledger_id = ##$$LDGR$$##
    AND xal.accounting_class_code IN (''FUTURE_DATED_PMT'')
    AND xah.entity_id IN (
      SELECT ent1.entity_id
      FROM XLA.xla_transaction_entities ent1
      WHERE ent1.application_id = 200
      AND ent1.entity_code = ''AP_PAYMENTS''
      AND NVL(ent1.source_id_int_1 , -99) IN (
         SELECT DISTINCT check_id
         FROM ap_invoice_payments_all aip
         WHERE aip.invoice_id = ##$$INV$$##)
         AND ent1.ledger_id = (
            SELECT inv.set_of_books_id
            FROM ap_invoices_all inv
            WHERE inv.invoice_id = ##$$INV$$##
            AND rownum < 2)
    )
    AND xah.gl_transfer_status_code = ''Y''
    AND NOT EXISTS (
	    SELECT 1
        FROM xla_trial_balances xtb
        WHERE xtb.definition_code = upper(''##$$TBDEF$$##'')
        AND xtb.ledger_id         = ##$$LDGR$$##
        AND xtb.ae_header_id      = xah.ae_header_id
        AND xtb.code_combination_id = xal.code_combination_id
        AND xtb.source_entity_id  = xah.entity_id)',
   'Gl Transferred Future Line Data Missing From Trial Balance',
   'RS',
   'There are headers missing from the trial balance for future lines',
   '<ul>
<li>Missing accounting headers in XLA_TRIAL_BALANCES table for future payments.</li>
<li>Rebuild Trial Balance.</li>
<li>Please see Metalink note 1662127.1 for more information.</li>
<li>Source KB Article: [1662127.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');    

  add_signature(
   'EVENTS_NOT_YET_ACCOUNTED',
   'SELECT *
    FROM xla_events
    WHERE application_id = 200
    AND   entity_id in (
            SELECT ent.entity_id FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1 , -99) = ##$$INV$$##
            AND   ent.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2)
            UNION ALL
            SELECT ent1.entity_id FROM XLA.xla_transaction_entities ent1
            WHERE ent1.application_id = 200
            AND   ent1.entity_code = ''AP_PAYMENTS''
            AND   nvl(ent1.source_id_int_1 , -99) IN (
                    SELECT distinct check_id FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
            AND   ent1.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2))
    AND event_status_code = ''U''',
   'Events not Yet Accounted',
   'RS',
   'There are events which are not yet accounted',
   '<ul>
<li>There are unaccounted event(s) for this invoice/payment.</li>
<li>Run Create Accounting to account these event(s).</li>
</ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'LIABILITY_NOT_TRANSFERRED_TO_GL',
   'SELECT distinct xah.*
    FROM xla_ae_headers xah,
         xla_ae_lines xal
    WHERE xah.application_id = 200
    AND   xah.entity_id IN (
            SELECT ent.entity_id FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1 , -99) = ##$$INV$$##
            AND   ent.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2)
            UNION ALL
            SELECT ent1.entity_id FROM XLA.xla_transaction_entities ent1
            WHERE ent1.application_id = 200
            AND   ent1.entity_code = ''AP_PAYMENTS''
            AND   nvl(ent1.source_id_int_1 , -99) IN (
                    SELECT distinct check_id FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
            AND   ent1.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2))
    AND   xal.application_id = 200
    AND   xal.ae_header_id = xah.ae_header_id
    AND   xal.accounting_class_code = ''LIABILITY''
    AND   xah.gl_transfer_status_code IN (''N'',''E'')
    AND   xah.ledger_id = ##$$INV$$##
    ORDER BY xah.event_id, xah.ae_header_id',
   'Liability Not Transferred to Gl',
   'RS',
   'Headers exist where the liability is not transferred to GL',
   '<ul>
<li>There are untransferred accounting for this invoice/payment.</li>
<li>Run Transfer Journal Entries to GL to transfer the entries to GL.</li>
</ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'PAYMENT_LIABILITY_DATA_MISSING_APPLIED_TO_ATTRIBUTES',
   'SELECT xdl.*
    FROM xla_ae_headers xah , xla_ae_lines xal , xla_distribution_links xdl
    WHERE xah.application_id = 200
    AND   xah.entity_id IN (
            SELECT ent1.entity_id FROM XLA.xla_transaction_entities ent1
            WHERE ent1.application_id = 200
            AND   ent1.entity_code = ''AP_PAYMENTS''
            AND   nvl(ent1.source_id_int_1 , -99) IN (
                    SELECT distinct check_id FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
            AND   ent1.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2))
    AND   xal.application_id = 200
    AND   xal.ae_header_id = xah.ae_header_id
    AND   xal.accounting_class_code = ''LIABILITY''
    AND   xdl.application_id = 200
    AND   xdl.ae_header_id = xal.ae_header_id
    AND   xdl.ae_line_num = xal.ae_line_num
    AND   xah.upg_batch_id is null
    AND   xdl.applied_to_entity_id is null
    AND   xah.ledger_id = ##$$LDGR$$##
    ORDER BY xdl.ae_header_id , xdl.ae_line_num',
   'Payment Liability Data Missing Applied to Attributes',
   'RS',
   'Lines exist with missing "applied to" attributes in XLA_DISTRIBUION_LINKS',
   '<ul>
<li>RCA: Bug 7293021 There are distribution links missing Applied to Attributes.</li>
<li>Please log a SR with Oracle Support and upload this report.</li>
</ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'DUPLICATE_DATA_FOR_INVOICE_PAYMENT_IN_TRIAL_BALANCE',
   'SELECT xtb.ae_header_id, xtb.source_entity_id, xtb.applied_to_entity_id,
            xtb.party_id , xtb.party_site_id, xtb.code_combination_id,
            xtb.record_type_code, xtb.event_class_code, nvl(xtb.acctd_rounded_cr,0),
            nvl (xtb.acctd_rounded_dr,0) , count(1)
       FROM xla_trial_balances xtb
      WHERE xtb.definition_code = upper(''##$$TBDEF$$##'')
      AND   xtb.ledger_id = ##$$LDGR$$##
      AND   nvl(xtb.applied_to_entity_id,xtb.source_entity_id) in (SELECT entity_id
                               FROM XLA.xla_transaction_entities ent
                              WHERE ent.application_id = 200
                              AND   ent.entity_code = ''AP_INVOICES''
                              AND   nvl(source_id_int_1,-99) = ##$$INV$$##
                              AND   ent.ledger_id = ##$$LDGR$$##)
      GROUP BY xtb.ae_header_id, xtb.source_entity_id, xtb.applied_to_entity_id,
               xtb.party_id ,xtb.party_site_id, xtb.code_combination_id,
               xtb.record_type_code, xtb.event_class_code, nvl(xtb.acctd_rounded_cr,0),
               nvl(xtb.acctd_rounded_dr,0)
      having count(1) > 1',
   'Duplicate Data For Invoice / Payment in Trial Balance',
   'RS',
   'Duplicate data exists for invoice(s)/payment(s) in the trial balance',
   '<ul>
<li>There is duplciate data in XLA_TRIAL_BALANCES.</li>
<li>Rebuild Trial Balance.</li>
<li>Please see Metalink note 553484.1 for more information.</li>
<li>Source KB Article: [553484.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'LIABILITY_ACCOUNT_USED_FOR_OTHER_LINES',
   'SELECT DISTINCT gcc.concatenated_segments, xal.code_combination_id,
                     xal1.accounting_class_code
    FROM xla_ae_headers xah,
         xla_ae_lines xal,
         xla_ae_lines xal1,
         gl_code_combinations_kfv gcc
    WHERE xah.application_id = 200
    AND   xah.ledger_id = ##$$LDGR$$##
    AND   xah.entity_id IN (
            SELECT ent.entity_id FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1 , -99) = ##$$INV$$##
            AND   ent.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND rownum < 2)
            UNION ALL
            SELECT ent1.entity_id FROM XLA.xla_transaction_entities ent1
            WHERE ent1.application_id = 200
            AND   ent1.entity_code = ''AP_PAYMENTS''
            AND   nvl(ent1.source_id_int_1 , -99) in (
                    SELECT distinct check_id FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
            AND   ent1.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2))
    AND   xah.ae_header_id = xal.ae_header_id
    AND   xal.application_id = xah.application_id
    AND   xal1.application_id = xah.application_id
    AND   xal1.ae_header_id = xah.ae_header_id
    AND   xal1.code_combination_id = xal.code_combination_id
    AND   xal1.accounting_class_code <> xal.accounting_class_code
    AND   xal.accounting_class_code = ''LIABILITY''
    AND   xal.code_combination_id = gcc.code_combination_id',
   'Liability Account Used For Other Lines',
   'RS',
   'Non-liability lines exist which are using the liability account',
   '<ul>
<li>There are Non-liability type accounting lines that use Liability account.</li>
<li>Ensure the latest Trial Balance patch is applied and rebuild Trial Balance.</li>
<li>Please see Metalink note 553484.1 for more information.</li>
<li>Source KB Article: [553484.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'LIABILITY_ACCOUNT_NOT_DEFINED_FOR_THE_DEFINITION_CODE',
   'SELECT distinct gcc.concatenated_segments, xal.code_combination_id
    FROM xla_ae_headers xah , xla_ae_lines xal , gl_code_combinations_kfv gcc
    WHERE xah.application_id = 200
    AND   xah.ledger_id = ##$$LDGR$$##
    AND   xah.entity_id IN (
            SELECT ent.entity_id
            FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1 , -99) = ##$$INV$$##
            AND   ent.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2)
            UNION ALL
            SELECT ent1.entity_id FROM XLA.xla_transaction_entities ent1
            WHERE ent1.application_id = 200
            AND   ent1.entity_code = ''AP_PAYMENTS''
            AND   nvl(ent1.source_id_int_1 , -99) in (
                    SELECT distinct check_id FROM ap_invoice_payments_all aip
                    WHERE aip.invoice_id = ##$$INV$$##)
            AND   ent1.ledger_id = (
                    SELECT inv.set_of_books_id FROM ap_invoices_all inv
                    WHERE inv.invoice_id = ##$$INV$$##
                    AND   rownum < 2))
    AND   xah.ae_header_id = xal.ae_header_id
    AND   xal.application_id = xah.application_id
    AND   xal.accounting_class_code = ''LIABILITY''
    AND   xal.code_combination_id = gcc.code_combination_id
    AND   NOT EXISTS (
            SELECT 1 FROM xla_tb_defn_details det
            WHERE det.definition_code = upper(''##$$TBDEF$$##'')
            AND   det.code_combination_id = xal.code_combination_id)
    AND   NOT EXISTS (
             SELECT 1 FROM xla_tb_def_seg_ranges xsr
             WHERE xsr.definition_code = upper(''##$$TBDEF$$##'')
             AND   nvl(gcc.SEGMENT1,''***'') BETWEEN
                     nvl(xsr.SEGMENT1_FROM, nvl(gcc.SEGMENT1,''***'')) AND
                     nvl(xsr.SEGMENT1_TO, nvl(gcc.SEGMENT1,''***''))
             AND   nvl(gcc.SEGMENT2,''***'') BETWEEN
                     nvl(xsr.SEGMENT2_FROM, nvl(gcc.SEGMENT2,''***'')) AND
                     nvl(xsr.SEGMENT2_TO, nvl(gcc.SEGMENT2,''***''))
             AND   nvl(gcc.SEGMENT3,''***'') BETWEEN
                     nvl(xsr.SEGMENT3_FROM, nvl(gcc.SEGMENT3,''***'')) AND
                     nvl(xsr.SEGMENT3_TO, nvl(gcc.SEGMENT3,''***''))
             AND   nvl(gcc.SEGMENT4,''***'') BETWEEN
                     nvl(xsr.SEGMENT4_FROM, nvl(gcc.SEGMENT4,''***'')) AND
                     nvl(xsr.SEGMENT4_TO, nvl(gcc.SEGMENT4,''***''))
             AND   nvl(gcc.SEGMENT5,''***'') BETWEEN
                     nvl(xsr.SEGMENT5_FROM, nvl(gcc.SEGMENT5,''***'')) AND
                     nvl(xsr.SEGMENT5_TO, nvl(gcc.SEGMENT5,''***''))
             AND   nvl(gcc.SEGMENT6,''***'') BETWEEN
                     nvl(xsr.SEGMENT6_FROM, nvl(gcc.SEGMENT6,''***'')) AND
                     nvl(xsr.SEGMENT6_TO, nvl(gcc.SEGMENT6,''***''))
             AND   nvl(gcc.SEGMENT7,''***'') BETWEEN
                     nvl(xsr.SEGMENT7_FROM, nvl(gcc.SEGMENT7,''***'')) AND
                     nvl(xsr.SEGMENT7_TO, nvl(gcc.SEGMENT7,''***''))
             AND   nvl(gcc.SEGMENT8,''***'') BETWEEN
                     nvl(xsr.SEGMENT8_FROM, nvl(gcc.SEGMENT8,''***'')) AND
                     nvl(xsr.SEGMENT8_TO, nvl(gcc.SEGMENT8,''***''))
             AND   nvl(gcc.SEGMENT9,''***'') BETWEEN
                     nvl(xsr.SEGMENT9_FROM, nvl(gcc.SEGMENT9,''***'')) AND
                     nvl(xsr.SEGMENT9_TO, nvl(gcc.SEGMENT9,''***''))
             AND   nvl(gcc.SEGMENT10,''***'') BETWEEN
                     nvl(xsr.SEGMENT10_FROM, nvl(gcc.SEGMENT10,''***'')) AND
                     nvl(xsr.SEGMENT10_TO, nvl(gcc.SEGMENT10,''***''))
             AND   nvl(gcc.SEGMENT11,''***'') BETWEEN
                     nvl(xsr.SEGMENT11_FROM, nvl(gcc.SEGMENT11,''***'')) AND
                     nvl(xsr.SEGMENT11_TO, nvl(gcc.SEGMENT11,''***''))
             AND   nvl(gcc.SEGMENT12,''***'') BETWEEN
                     nvl(xsr.SEGMENT12_FROM, nvl(gcc.SEGMENT12,''***'')) AND
                     nvl(xsr.SEGMENT12_TO, nvl(gcc.SEGMENT12,''***''))
             AND   nvl(gcc.SEGMENT13,''***'') BETWEEN
                     nvl(xsr.SEGMENT13_FROM, nvl(gcc.SEGMENT13,''***'')) AND
                     nvl(xsr.SEGMENT13_TO, nvl(gcc.SEGMENT13,''***''))
             AND   nvl(gcc.SEGMENT14,''***'') BETWEEN
                     nvl(xsr.SEGMENT14_FROM, nvl(gcc.SEGMENT14,''***'')) AND
                     nvl(xsr.SEGMENT14_TO, nvl(gcc.SEGMENT14,''***''))
             AND   nvl(gcc.SEGMENT15,''***'') BETWEEN
                     nvl(xsr.SEGMENT15_FROM, nvl(gcc.SEGMENT15,''***'')) AND
                     nvl(xsr.SEGMENT15_TO, nvl(gcc.SEGMENT15,''***''))
             AND   nvl(gcc.SEGMENT16,''***'') BETWEEN
                     nvl(xsr.SEGMENT16_FROM, nvl(gcc.SEGMENT16,''***'')) AND
                     nvl(xsr.SEGMENT16_TO, nvl(gcc.SEGMENT16,''***''))
             AND   nvl(gcc.SEGMENT17,''***'') BETWEEN
                     nvl(xsr.SEGMENT17_FROM, nvl(gcc.SEGMENT17,''***'')) AND
                     nvl(xsr.SEGMENT17_TO, nvl(gcc.SEGMENT17,''***''))
             AND   nvl(gcc.SEGMENT18,''***'') BETWEEN
                     nvl(xsr.SEGMENT18_FROM, nvl(gcc.SEGMENT18,''***'')) AND
                     nvl(xsr.SEGMENT18_TO, nvl(gcc.SEGMENT18,''***''))
             AND   nvl(gcc.SEGMENT19,''***'') BETWEEN
                     nvl(xsr.SEGMENT19_FROM, nvl(gcc.SEGMENT19,''***'')) AND
                     nvl(xsr.SEGMENT19_TO, nvl(gcc.SEGMENT19,''***''))
             AND   nvl(gcc.SEGMENT20,''***'') BETWEEN
                     nvl(xsr.SEGMENT20_FROM, nvl(gcc.SEGMENT20,''***'')) AND
                     nvl(xsr.SEGMENT20_TO, nvl(gcc.SEGMENT20,''***''))
             AND   nvl(gcc.SEGMENT21,''***'') BETWEEN
                     nvl(xsr.SEGMENT21_FROM, nvl(gcc.SEGMENT21,''***'')) AND
                     nvl(xsr.SEGMENT21_TO, nvl(gcc.SEGMENT21,''***''))
             AND   nvl(gcc.SEGMENT22,''***'') BETWEEN
                     nvl(xsr.SEGMENT22_FROM, nvl(gcc.SEGMENT22,''***'')) AND
                     nvl(xsr.SEGMENT22_TO, nvl(gcc.SEGMENT22,''***''))
             AND   nvl(gcc.SEGMENT23,''***'') BETWEEN
                     nvl(xsr.SEGMENT23_FROM, nvl(gcc.SEGMENT23,''***'')) AND
                     nvl(xsr.SEGMENT23_TO, nvl(gcc.SEGMENT23,''***''))
             AND   nvl(gcc.SEGMENT24,''***'') BETWEEN
                     nvl(xsr.SEGMENT24_FROM, nvl(gcc.SEGMENT24,''***'')) AND
                     nvl(xsr.SEGMENT24_TO, nvl(gcc.SEGMENT24,''***''))
             AND   nvl(gcc.SEGMENT25,''***'') BETWEEN
                     nvl(xsr.SEGMENT25_FROM, nvl(gcc.SEGMENT25,''***'')) AND
                     nvl(xsr.SEGMENT25_TO, nvl(gcc.SEGMENT25,''***''))
             AND   nvl(gcc.SEGMENT26,''***'') BETWEEN
                     nvl(xsr.SEGMENT26_FROM, nvl(gcc.SEGMENT26,''***'')) AND
                     nvl(xsr.SEGMENT26_TO, nvl(gcc.SEGMENT26,''***''))
             AND   nvl(gcc.SEGMENT27,''***'') BETWEEN
                     nvl(xsr.SEGMENT27_FROM, nvl(gcc.SEGMENT27,''***'')) AND
                     nvl(xsr.SEGMENT27_TO, nvl(gcc.SEGMENT27,''***''))
             AND   nvl(gcc.SEGMENT28,''***'') BETWEEN
                     nvl(xsr.SEGMENT28_FROM, nvl(gcc.SEGMENT28,''***'')) AND
                     nvl(xsr.SEGMENT28_TO, nvl(gcc.SEGMENT28,''***''))
             AND   nvl(gcc.SEGMENT29,''***'') BETWEEN
                     nvl(xsr.SEGMENT29_FROM, nvl(gcc.SEGMENT29,''***'')) AND
                     nvl(xsr.SEGMENT29_TO, nvl(gcc.SEGMENT29,''***''))
             AND   nvl(gcc.SEGMENT30,''***'') BETWEEN
                     nvl(xsr.SEGMENT30_FROM, nvl(gcc.SEGMENT30,''***'')) AND
                     nvl(xsr.SEGMENT30_TO, nvl(gcc.SEGMENT30,''***'')))',
   'Liability Account Not Defined For the Definition Code',
   'RS',
   'Liability lines where the liability account is not defined in the trial '||
     'balance definition code',
   '<ul>
<li>There exists account(s) which are not not defined for the given Trial
    Balance Definition Code.</li>
<li>Assign the Liability accounts returned to the Trial Balance Definition.</li>
<li>Please see Metalink note 553484.1 for more information.</li>
<li>Source KB Article: [553484.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'MANUAL_EVENT_DATA_EXISTS_IN_TRIAL_BALANCE',
   'SELECT xtb.*
    FROM xla_trial_balances xtb,
         xla_Ae_headers xah
    WHERE xtb.definition_code = upper(''##$$TBDEF$$##'')
    AND   xtb.ledger_id = ##$$LDGR$$##
    AND   nvl(xtb.applied_to_entity_id,xtb.source_entity_id) in (
            SELECT entity_id
            FROM XLA.xla_transaction_entities ent
            WHERE ent.application_id = 200
            AND   ent.entity_code = ''AP_INVOICES''
            AND   nvl(source_id_int_1,-99) = ##$$INV$$##
            AND   ent.ledger_id = ##$$LDGR$$##)
    AND   xah.application_id = 200
    AND   xah.ae_header_id = xtb.ae_header_id
    AND   xah.event_type_code = ''MANUAL''
    AND   xah.upg_batch_id = -9999',
   'Manual Event Data Exists in Trial Balance',
   'RS',
   'Lines exist for which there is manual event data in the trial balance',
   '<ul>
<li>Manual Accounting Header Data Exists in Trial Balance for this invoice/payment.</li>
<li>Rebuild Trial Balance after latest patch..</li>
<li>Please see Metalink note 553484.1 for more information.</li>
<li>Source KB Article: [553484.1]</li></ul>',
   NULL,
   'FAILURE',
   'E',
   'RS',
   'Y');

  -------------------------------------------
  -- Account
  -------------------------------------------
  add_signature(
   'DIFF_FOR_GJL_XEL',
   'SELECT gjl2.ledger_id,
           gjl2.period_name,
           gjl2.start_date,
           gjl_acct_dr,
           gjl_acct_cr,
           xel_acct_dr,
           xel_acct_cr,
           (nvl(xel2.xel_acct_dr,0) + nvl(xel2.xel_acct_cr,0)) -
             (nvl(gjl2.gjl_acct_dr,0) + nvl(gjl2.gjl_acct_cr,0)) difference
    FROM (
           SELECT gjh.ledger_id,
                  gjh.period_name,
                  gps.start_date,
                  gjl.code_combination_id,
                  sum(accounted_dr) gjl_acct_dr,
                  sum(accounted_cr) gjl_acct_cr
           FROM gl_je_lines gjl,
                gl_je_headers gjh,
                gl_je_batches gjb,
                gl_period_statuses gps
           WHERE gjl.je_header_id = gjh.je_header_id
           AND   gps.period_name(+) = gjh.period_name
           AND   gps.ledger_id(+) = gjh.ledger_id
           AND   gps.application_id = 200
           AND   gjb.je_batch_id = gjh.je_batch_id
           AND   code_combination_id = (##$$ACC$$##)
           AND   gjh.ledger_id = ##$$LDGR$$##
           AND   gjh.je_source = ''Payables''
           AND   trunc(gjl.effective_date) BETWEEN
                   ''##$$START$$##''  AND   ''##$$END$$##''
           GROUP BY gjh.ledger_id,gjh.period_name, gps.start_date,
                    gjl.code_combination_id
         ) gjl2,
         (
           SELECT xeh.ledger_id,
                  xeh.period_name,
                  gps.start_date,
                  xel.code_combination_id,
                  sum(xel.accounted_dr) xel_acct_dr,
                  sum(xel.accounted_cr) xel_acct_cr
           FROM xla_ae_lines xel,
                xla_ae_headers xeh,
                gl_period_statuses gps
           WHERE xel.application_id = 200
           AND   xeh.ae_header_id = xel.ae_header_id
           AND   xeh.gl_transfer_status_code = ''Y''
           AND   gps.period_name(+) = xeh.period_name
           AND   gps.ledger_id(+) = xeh.ledger_id
           AND   gps.application_id(+) = 200
           AND   code_combination_id = (##$$ACC$$##)
           AND   xeh.ledger_id = ##$$LDGR$$##
           AND   trunc(xeh.accounting_date) BETWEEN
                   ''##$$START$$##'' AND   ''##$$END$$##''
           GROUP BY xeh.ledger_id, xeh.period_name, gps.start_date,
                        xel.code_combination_id
         ) xel2
    WHERE xel2.ledger_id = gjl2.ledger_id
    AND   xel2.period_name = gjl2.period_name
    AND   (nvl(xel2.xel_acct_dr,0) + nvl(xel2.xel_acct_cr,0)) !=
            (nvl(gjl2.gjl_acct_dr,0) + nvl(gjl2.gjl_acct_cr,0))
    ORDER BY gjl2.start_date desc',
   'Periods with Differences between GL_JE_LINES and XLA_AE_LINES',
   'RS',
   'There are periods with differences between the GL and XLA lines tables',
   '<ul>
<li>The XLA_JE_LINES and GL_JE_LINES have differences by period for this account and ledger.</li>
<li>Please review the sections below for further explanation of those differences.</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'DIFF_FOR_XTB_XEL',
   'SELECT xtb.*
    FROM (
           SELECT xeh.ledger_id,
                  xeh.ae_header_id,
                  xeh.accounting_date,
                  xeli.code_combination_id,
                  sum(accounted_dr) xel_dr,
                  sum(accounted_cr) xel_cr,
                  count(*)
           FROM xla_ae_lines xeli, xla_ae_headers xeh
           WHERE xeli.ae_header_id = xeh.ae_header_id
           AND   xeh.application_id = 200
           AND   xeli.accounting_class_code = ''LIABILITY''
           AND   xeh.event_type_code != ''MANUAL''
           AND   xeh.gl_transfer_status_code = ''Y''
           GROUP BY xeh.ledger_id, xeh.ae_header_id, xeh.accounting_date,
                    xeli.code_combination_id
         ) xel,
         (
           SELECT definition_code,
                  ledger_id,
                  code_combination_id,
                  ae_header_id,
                  gl_date,
                  sum(acctd_unrounded_dr) xtb_dr,
                  sum(acctd_unrounded_cr) xtb_cr,
                  count(*)
           FROM xla_trial_balances tb
           WHERE tb.definition_code = ''##$$TBDEF$$##''
           AND   tb.ledger_id = ##$$LDGR$$##
           AND   tb.code_combination_id = (##$$ACC$$##)
           AND   trunc(tb.gl_date) BETWEEN ''##$$START$$##'' AND   ''##$$END$$##''
           GROUP BY definition_code, ledger_id, code_combination_id,
                    ae_header_id, gl_date
         ) xtb
    WHERE xtb.ae_header_id = xel.ae_header_id(+)
    AND   nvl(xtb.xtb_dr, 0) - nvl(xtb.xtb_cr, 0) =
            nvl(xel.xel_dr(+),0)- nvl(xel.xel_cr(+),0)
    AND   xtb.ledger_id = xel.ledger_id(+)
    AND   xtb.code_combination_id = xel.code_combination_id(+)
    AND   trunc(xtb.gl_date) = trunc(xel.accounting_date(+))
    AND   xel.ae_header_id is null
    ORDER BY xtb.definition_code, gl_date desc',
   'Data in the xla_trial_balances table that does not match/exist in xla_ae_lines (Excluding MANUAL/UNDO entries)',
   'RS',
   'There are lines in the trial balance that do not exist in XLA_JE_LINES',
   '<ul>
<li>The XLA_TRIAL_BALANCES AND XLA_JE_LINES liability account data does not match.</li>
<li>Check to make sure the account is included in the Report Definition, the latest patches are applied, and rebuild the Trial Balance.</li>
<li>Please see note 553484.1 for more information.</li>
<li>Source KB Article: [553484.1]</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'DIFF_FOR_XEL_XTB',
   'SELECT xel.*
    FROM (
           SELECT xeh.ledger_id,
                  xeh.ae_header_id,
                  xeh.accounting_date,
                  xeli.code_combination_id,
                  sum(accounted_dr) xel_dr,
                  sum(accounted_cr) xel_cr,
                  count(*)
           FROM xla_ae_lines xeli,
                xla_ae_headers xeh
           WHERE xeli.ae_header_id = xeh.ae_header_id
           AND   xeh.application_id = 200
           AND   xeli.accounting_class_code = ''LIABILITY''
           AND   xeh.event_type_code != ''MANUAL''
           AND   xeh.gl_transfer_status_code = ''Y''
           AND   xeh.ledger_id = ##$$LDGR$$##
           AND   xeli.code_combination_id = (##$$ACC$$##)
           AND   trunc(xeh.accounting_date) BETWEEN
                   ''##$$START$$##'' AND   ''##$$END$$##''
           GROUP BY xeh.ledger_id, xeh.ae_header_id, xeh.accounting_date,
                       xeli.code_combination_id
         ) xel,
         (
           SELECT definition_code,
                  ledger_id,
                  code_combination_id,
                  ae_header_id,
                  gl_date,
                  sum(acctd_unrounded_dr) xtb_dr,
                  sum(acctd_unrounded_cr) xtb_cr,
                  count(*)
           FROM xla_trial_balances tb
           WHERE tb.definition_code = ''##$$TBDEF$$##''
           GROUP BY definition_code, ledger_id, code_combination_id,
                       ae_header_id, gl_date
         ) xtb
    WHERE xtb.ae_header_id(+) = xel.ae_header_id
    AND   nvl(xtb.xtb_dr(+), 0) - nvl(xtb.xtb_cr(+), 0) =
            nvl(xel.xel_dr,0)- nvl(xel.xel_cr,0)
    AND   xtb.ledger_id(+) = xel.ledger_id
    AND   xtb.code_combination_id(+) = xel.code_combination_id
    AND   trunc(xtb.gl_date(+)) = trunc(xel.accounting_date)
    AND   xtb.ae_header_id is null
    ORDER BY accounting_date desc',
   'Data in the xla_ae_lines table that does not match/exist in xla_trial_balances table (Excluding MANUAL/UNDO entries)',
   'RS',
   'There are lines in XLA_JE_LINES that do not exist in the trial balance',
   '<ul>
     <li>The XLA_TRIAL_BALANCES AND XLA_JE_LINES liability
         account data does not match.</li>
     <li>Check to make sure the account is included in the Report
         Definition, the latest patches are applied, and rebuild
         the Trial Balance.</li>
    <li>Please see note 553484.1 for more information.</li>
    <li>Source KB Article: [553484.1]</li>
   </ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'XEL_MANUAL_ENTRIES',
   'SELECT xeh.ledger_id,
           xeh.period_name,
           xel.code_combination_id,
           sum(accounted_dr) xel_dr,
           sum(accounted_cr) xel_cr,
           count(*)
    FROM xla_ae_lines xel,
         xla_ae_headers xeh,
         xla_events xe
    WHERE xe.application_id = 200
    AND   xe.event_type_code = ''MANUAL''
    AND   xeh.ledger_id = ##$$LDGR$$##
    AND   xel.code_combination_id = (##$$ACC$$##)
    AND   trunc(xeh.accounting_date) BETWEEN
            ''##$$START$$##'' AND   ''##$$END$$##''
    AND   xel.accounting_class_code = ''LIABILITY''
    AND   xeh.event_id = xe.event_id
    AND   xeh.ae_header_id = xel.ae_header_id
    GROUP BY xeh.ledger_id, xeh.period_name, xel.code_combination_id
    ORDER BY xeh.ledger_id, xeh.period_name',
   'Manual Entries in the Subledger for account by period',
   'RS',
   'There are manual entries in the subledger for the period',
   '<ul>
<li>Manual Entries can impact the Accounts Payable Trial Balance.</li>
<li>Please see Document Ids 753695.1 and 605707.1 for more information on
     how Manual entries can impact the Accounts Payable Trial Balance.</li>
<li>Source KB Article: [753695.1]</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'MISSING_FROM_SITV',
   'SELECT *
    FROM xla_trial_balances tb
    WHERE NOT EXISTS (
            SELECT 1
            FROM ap_sla_invoices_transaction_v tiv,
                 xla.xla_transaction_entities xte
            WHERE nvl(tb.applied_to_entity_id,tb.source_entity_id)=xte.entity_id
            AND   xte.entity_code=''AP_INVOICES''
            AND   nvl(xte.source_id_int_1,-99)=tiv.invoice_id
            AND   xte.application_id = tb.source_application_id)
    AND   tb.source_application_id=200
    AND   tb.ledger_id = ##$$LDGR$$##
    AND   tb.code_combination_id = (##$$ACC$$##)
    AND   trunc(tb.gl_date) BETWEEN ''##$$START$$##'' AND ''##$$END$$##''
    ORDER BY tb.definition_code, tb.ledger_id',
   'Check for data in xla_trial_balances and NOT in AP_SLA_INVOICES_TRANSACTION_V',
   'RS',
   'There are lines in XLA which are not in the trial balance view',
   '<ul>
<li>Manual Entries can impact the Accounts Payable Trial Balance.</li>
<li>Please see Document Ids 753695.1 and 605707.1 for more information on
     how Manual entries can impact the Accounts Payable Trial Balance.</li>
<li>Source KB Article: [753695.1]</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'PARTY_SITE_ID_MISSING',
   'SELECT ai.*
    FROM ap_invoices_all ai,
         hz_parties hzp,
         hz_party_sites hzps,
         ap_suppliers as1
    WHERE ai.party_site_id is null
    AND   nvl(ai.historical_flag, ''N'') = ''N''
    AND   ai.vendor_id = as1.vendor_id(+)
    AND   ai.party_id = hzp.party_id
    AND   ai.party_site_id = hzps.party_site_id(+)
    AND   ai.set_of_books_id = ##$$LDGR$$##
    AND   trunc(ai.gl_date) BETWEEN 
            ''##$$START$$##'' AND ''##$$END$$##''
    AND   as1.employee_id is null
    AND   hzps.party_site_id is null',
   'Check for invoices with bug 7871425 (party_site_id is NULL for non-employees)',
   'RS',
   'There are invoices for non-employees which have a null party_site_id',
   '<ul>
<li>Invoices for non-employees have the ap_invoices_all party_site_id column set to NULL</li>
<li>Please create an SR for Oracle Support referecing this issue and provide this output along with the Invoice Data Collection (APList) output for one invoice with this issue.</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'Note553484.1',
   'SELECT xte.entity_id,
           xe.event_id,
           xe.event_date,
           ai.invoice_id,
           ai.vendor_id,
           ai.vendor_site_id,
           ai.party_id,
           ai.party_site_id
    FROM ap_invoices_all ai,
         xla_events xe,
         xla.xla_transaction_entities xte
    WHERE ai.invoice_type_lookup_code = ''PAYMENT REQUEST''
    AND   ai.vendor_id < 0
    AND   xte.entity_code = ''AP_INVOICES''
    AND   xte.source_id_int_1 = ai.invoice_id
    AND   xte.ledger_id = ##$$LDGR$$##
    AND   trunc(xe.event_date) BETWEEN ''##$$START$$##'' AND   ''##$$END$$##''
    AND   xe.entity_id = xte.entity_id
    ORDER BY ai.invoice_id, xe.event_id',
   'Check for invoices with bug 7019211 (Payment Request Invoices)',
   'RS',
   'There are payment request invoices invoices with bug 7019211',
   '<ul>
<li>Make sure you are on the latest code to have the Payment Request Invoices correctly reported on the Trial Balance.</li>
<li>Please see note 553484.1 for latest Trial Balance code patches.</li>
<li>Source KB Article: [553484.1]</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'NOT_TRANSFERRED_ENTRIES',
   'SELECT xte.entity_code, xte.source_id_int_1, xte.ledger_id,
           xte.transaction_number, xeh.ae_header_id, xeh.period_name,
           xeh.event_type_code, xeh.balance_type_code,
           xeh.accounting_entry_status_code, xeh.gl_transfer_status_code
    FROM xla_ae_headers xeh, xla.xla_transaction_entities xte
    WHERE xte.application_id = 200
    AND   xeh.application_id = 200
    AND   xte.entity_id = xeh.entity_id
    AND   xeh.gl_transfer_status_code != ''Y''
    AND   xeh.accounting_entry_status_code = ''F''
    AND   trunc(xeh.accounting_date) BETWEEN ''##$$START$$##'' AND   ''##$$END$$##''
    AND   xeh.ledger_id = ##$$LDGR$$##
    AND   EXISTS (
            SELECT 1 FROM xla_ae_lines xel
            WHERE xel.application_id = 200
            AND   xel.ae_header_id = xeh.ae_header_id
            AND   xel.code_combination_id = (##$$ACC$$##))
    ORDER BY xeh.ae_header_id desc',
   'Untransferred Accounting entries for account by period',
   'RS',
   'Untransferred accounting entries exist for the period',
   '<ul>
<li>Accounting must be transferred to be included in the Accounts Payable Trial Balance.</li>
<li>Please see note 459002.1 for instructions on Journal Entry transfer.</li>
<li>Source KB Article: [459002.1]</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  -------------------------------------------
  -- Note 107066.1
  -------------------------------------------
  add_signature(
   'Note107066.1',
   'SELECT gps.start_date, gjh.period_name, gjb.je_batch_id, gjb.name gjb_name,
           gjh.ledger_id, gjh.je_header_id,gjh.je_source, gjh.status, gjh.name gjh_name,
           sum(gjl.accounted_dr) sum_accounted_dr,sum(gjl.accounted_cr) sum_accounted_cr,
           count(*)
    FROM gl_je_lines gjl,
         gl_je_headers gjh,
         gl_je_batches gjb,
         gl_period_statuses gps
    WHERE gjl.je_header_id = gjh.je_header_id
    AND   gjb.je_batch_id = gjh.je_batch_id
    AND   gjh.je_source = ''Payables''
    AND   gps.ledger_id = gjh.ledger_id
    AND   gps.application_id = 101
    AND   gjh.ledger_id = ##$$LDGR$$##
    AND   gjl.code_combination_id = (##$$ACC$$##)
    AND   gjh.status != ''P''
    AND   gjh.period_name = gps.period_name
    AND   trunc(gjl.effective_date) BETWEEN ''##$$START$$##'' AND ''##$$END$$##''
    GROUP BY gps.start_date, gjh.period_name, gjb.je_batch_id, gjb.name, gjh.ledger_id,
             gjh.je_header_id,gjh.je_source, gjh.status, gjh.name
    ORDER BY gps.start_date desc',
   'Unposted entries in GL for account by period',
   'RS',
   'There are unposted entries in GL for the account and period)',
   '<ul>
<li>There are Payables Source GL entries NOT posted to GL.</li>
<li>ALL Payables Source GL entries must be posted to reconcile AP to GL.</li>
<li>Please post all unposted entries. See note 107066.1 "General Ledger FAQ for Journal Posting" for any issues posting.</li>
<li>Source KB Article: [107066.1]</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'NON_PAYABLES_SOURCE_IN_GL',
   'SELECT gps.start_date, gjh.period_name, gjb.je_batch_id, gjb.name gjb_name,
           gjh.ledger_id, gjh.je_header_id, gjh.je_source,gjh.status, gjh.name gjh_name,
           sum(gjl.accounted_dr) sum_accounted_dr,sum(gjl.accounted_cr) sum_accounted_cr,
           count(*)
    FROM gl_je_lines gjl, gl_je_headers gjh, gl_je_batches gjb,
         gl_period_statuses gps
    WHERE gjl.je_header_id = gjh.je_header_id
    AND   gjb.je_batch_id = gjh.je_batch_id
    AND   gjh.je_source != ''Payables''
    AND   gps.ledger_id = gjh.ledger_id
    AND   gps.application_id = 101
    AND   gjh.ledger_id = ##$$LDGR$$##
    AND   gjl.code_combination_id = (##$$ACC$$##)
	AND   gps.period_name = gjl.period_name 
    AND   trunc(gjl.effective_date) BETWEEN ''##$$START$$##'' AND   ''##$$END$$##''
    GROUP BY gps.start_date, gjh.period_name, gjb.je_batch_id, gjb.name,
               gjh.ledger_id, gjh.je_header_id, gjh.je_source, gjh.status,
               gjh.name
    ORDER BY gps.start_date desc',
    'Non-Payables Source entries in GL for account by period',
   'RS',
   'There are non Payables source entries in GL for the account and period',
   '<ul>
<li>The GL Liability account total includes NON-Payables source entries.</li>
<li>Exclude the NON-Payables source totals when reconciling the account between AP and GL.</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'IN_GL_MISSING_FROM_SLA',
   'SELECT /*+ parallel (gh) parallel(gl) parallel(imp) leading (gl) */
           imp.gl_sl_link_id,
           gjb.je_batch_id,gjb.name,gjb.group_id, imp.je_header_id FROM gl_je_lines gl,
           gl_import_references imp, gl_je_headers gh, gl_je_batches gjb
    WHERE 1=2
    AND   gl.je_header_id = gh.je_header_id
    AND   gl.effective_date BETWEEN ''##$$START$$##'' AND   ''##$$END$$##''
    AND   gl.code_combination_id in (##$$ACC$$##)
    AND   gh.ledger_id = ##$$LDGR$$##
    AND   gh.je_from_sla_flag = ''Y''
    AND   gh.je_source = ''Payables''
    AND   nvl(gh.accrual_rev_je_header_id,0) = 0
    AND   gjb.je_batch_id = gh.je_batch_id
    AND   gl.je_header_id = imp.je_header_id
    AND   gl.je_line_num = imp.je_line_num
    AND   imp.gl_sl_link_table = ''XLAJEL''
    AND   imp.gl_sl_link_id is not null
    AND   NOT EXISTS (
            SELECT 1 FROM xla_ae_lines xel
            WHERE xel.gl_sl_link_id = imp.gl_sl_link_id
            AND   xel.gl_sl_link_table = imp.gl_sl_link_table)',
    'In GL, missing from SLA',
   'RS',
   'There are lines in GL which are missing from SLA',
   '<ul>
<li>The GL Liability account total includes NON-Payables source entries.</li>
<li>Please see note 883557.1 for more details on detecting and fixing GL Transfer issues.</li>
<li>Source KB Article: [883557.1]</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');
   
  ------------------------------------------------------------------------------
  -- Undo
  ------------------------------------------------------------------------------
  add_signature(
   'UNDO_QUERY',
   'SELECT ''REVERSE'' TYPE,
           undo.event_id,
           undo.*,
           rxte.entity_id rxte_entity_id,
           rxte.entity_code rxte_entity_code,
           rxte.source_id_int_1 rxte_source_id_int_1,
           rxte.transaction_number rxte_transaction_number,
           rxte.creation_date rxte_creation_date,
           rev_xe.event_id,
           rev_xe.event_type_code,
           rev_xe.event_status_code,
           rev.*,
           fnd_flex_ext.get_segs(
             ''SQLGL'',
             ''GL#'',
             gl.chart_of_accounts_id,
             rev.rxel_code_combination_id) account_num
    FROM (
           SELECT rundo.e2 rundo_event_id,
                  rxeh.entity_id rxeh_entity_id,
                  rxeh.event_id rxeh_event_id,
                  rxeh.ae_header_id rxeh_ae_header_id,
                  rxeh.ledger_id rxeh_ledger_id,
                  rxeh.accounting_date rxeh_accounting_date,
                  rxeh.gl_transfer_status_code rxeh_gl_transfer_status_code,
                  rxel.code_combination_id rxel_code_combination_id,
                  sum(nvl(rxel.accounted_dr,0)) -
                    sum(nvl(rxel.accounted_cr,0)) rxel_net_accounted
           FROM xla_ae_lines rxel,
                xla_ae_headers rxeh,
                ap_undo_event_log rundo
           WHERE rxeh.application_id(+) = 200
           AND   rxel.application_id(+) = 200
           AND   rxel.ae_header_id(+) = rxeh.ae_header_id
           AND   rundo.e2 = rxeh.event_id(+)
           AND   rxel.accounting_class_code(+) = ''LIABILITY''
           GROUP BY rundo.e2, rxeh.entity_id, rxeh.event_id,
                    rxeh.ae_header_id, rxeh.ledger_id,
                    rxeh.accounting_date, rxeh.gl_transfer_status_code,
                    rxel.code_combination_id
         ) rev,
         xla_events rev_xe,
         xla.xla_transaction_entities rxte,
         gl_ledgers gl,
         ap_undo_event_log undo
    WHERE undo.e2 = rev.rundo_event_id(+)
    AND   undo.e2 = rev_xe.event_id(+)
    AND   rxte.ledger_id = gl.ledger_id(+)
    AND   rxte.entity_id(+) = rev.rxeh_entity_id
    AND   rxte.application_id(+) =200
    AND   rev.rxel_code_combination_id = ##$$ACC$$##
    UNION
    SELECT ''ORIGINAL'' TYPE,
           undo.event_id,
           undo.*,
           oxte.entity_id oxte_entity_id,
           oxte.entity_code oxte_entity_code,
           oxte.source_id_int_1 oxte_source_id_int_1,
           oxte.transaction_number oxte_transaction_number,
           oxte.creation_date oxte_creation_date,
           orig_xe.event_id,
           orig_xe.event_type_code,
           orig_xe.event_status_code,
           orig.*,
           fnd_flex_ext.get_segs(
             ''SQLGL'',
             ''GL#'',
             gl.chart_of_accounts_id,
             orig.oxel_code_combination_id) account_num
    FROM (
           SELECT oundo.e3 oundo_event_id,
                  oxeh.entity_id oxeh_entity_id,
                  oxeh.event_id oxeh_event_id,
                  oxeh.ae_header_id oxeh_ae_header_id,
                  oxeh.ledger_id oxeh_ledger_id,
                  oxeh.accounting_date oxeh_accounting_date,
                  oxeh.gl_transfer_status_code oxeh_gl_transfer_status_code,
                  oxel.code_combination_id oxel_code_combination_id,
                  sum(nvl(oxel.accounted_dr,0)) -
                    sum(nvl(oxel.accounted_cr,0)) oxel_net_accounted
           FROM xla_ae_lines oxel,
                xla_ae_headers oxeh,
                ap_undo_event_log oundo
           WHERE oxeh.application_id(+) = 200
           AND   oxel.application_id(+) = 200
           AND   oxel.ae_header_id(+) = oxeh.ae_header_id
           AND   oundo.e3 = oxeh.event_id(+)
           AND   oxel.accounting_class_code(+) = ''LIABILITY''
           GROUP BY oundo.e3, oxeh.entity_id, oxeh.event_id,
                    oxeh.ae_header_id, oxeh.ledger_id, oxeh.accounting_date,
                    oxeh.gl_transfer_status_code, oxel.code_combination_id
         ) orig,
         xla_events orig_xe,
         xla.xla_transaction_entities oxte,
         gl_ledgers gl,
         ap_undo_event_log undo
    WHERE undo.e3 = orig.oundo_event_id(+)
    AND   undo.e3 = orig_xe.event_id(+)
    AND   oxte.entity_id(+) = orig.oxeh_entity_id
    AND   oxte.ledger_id = gl.ledger_id(+)
    AND   oxte.application_id(+) = 200
    AND   orig.oxel_code_combination_id = ##$$ACC$$##
    UNION
    SELECT ''NEW'' TYPE,
           undo.event_id,
           undo.*,
           nxte.entity_id nxte_entity_id,
           nxte.entity_code nxte_entity_code,
           nxte.source_id_int_1 nxte_source_id_int_1,
           nxte.transaction_number nxte_transaction_number,
           nxte.creation_date nxte_creation_date,
           new_xe.event_id,
           new_xe.event_type_code,
           new_xe.event_status_code,
           new.*,
           fnd_flex_ext.get_segs(
             ''SQLGL'',
             ''GL#'',
             gl.chart_of_accounts_id,
             new.nxel_code_combination_id) account_num
    FROM (
           SELECT nundo.event_id nundo_event_id,
                  nxeh.entity_id nxeh_entity_id,
                  nxeh.event_id nxeh_event_id,
                  nxeh.ae_header_id nxeh_ae_header_id,
                  nxeh.ledger_id nxeh_ledger_id,
                  nxeh.accounting_date nxeh_accounting_date,
                  nxeh.gl_transfer_status_code nxeh_gl_transfer_status_code,
                  nxel.code_combination_id nxel_code_combination_id,
                  sum(nvl(nxel.accounted_dr,0)) -
                    sum(nvl(nxel.accounted_cr,0)) nxel_net_accounted
           FROM xla_ae_lines nxel,
                xla_ae_headers nxeh,
                ap_undo_event_log nundo,
                (
                  SELECT event_id, MAX(e3) max_e3 FROM ap_undo_event_log GROUP BY event_id
                ) nundo2
           WHERE nxeh.application_id(+) = 200
           AND   nxel.application_id(+) = 200
           AND   nxel.ae_header_id(+) = nxeh.ae_header_id
           AND   nundo.event_id = nxeh.event_id(+)
           AND   nxel.accounting_class_code(+) = ''LIABILITY''
           AND   nundo.event_id = nundo2.event_id
           AND   nundo.e3 = nundo2.max_e3
           GROUP BY nundo.event_id, nxeh.entity_id, nxeh.event_id,
                    nxeh.ae_header_id, nxeh.ledger_id, nxeh.accounting_date,
                    nxeh.gl_transfer_status_code, nxel.code_combination_id
         ) NEW,
         xla_events new_xe,
         xla.xla_transaction_entities nxte,
         gl_ledgers gl,
         ap_undo_event_log undo
    WHERE undo.event_id = new.nundo_event_id(+)
    AND   undo.event_id = new_xe.event_id(+)
    AND   nxte.ledger_id = gl.ledger_id(+)
    AND   nxte.entity_id(+) = new_xe.entity_id
    AND   nxte.application_id = 200
    AND   new.nxel_code_combination_id = ##$$ACC$$##
    ORDER BY 2 DESC,1',
   'Undo Entries in the System',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'UNDO_SUM',
   'SELECT *
    FROM (
           SELECT ''REVERSE'' UNDO_TYPE,
                  rxeh_period_name,
                  fnd_flex_ext.get_segs(
                    ''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    rev.rxel_code_combination_id) account_num,
                  rev.rxel_code_combination_id,
                  sum(rxel_net_accounted) sum_rxel_net_accounted
           FROM (
                  SELECT rundo.e2 rundo_event_id,
                         rxeh.entity_id rxeh_entity_id,
                         rxeh.event_id rxeh_event_id,
                         rxeh.ae_header_id rxeh_ae_header_id,
                         rxeh.ledger_id rxeh_ledger_id,
                         rxeh.period_name rxeh_period_name,
                         rxeh.accounting_date rxeh_accounting_date,
                         rxeh.gl_transfer_status_code rxeh_gl_transfer_status_code,
                         rxel.code_combination_id rxel_code_combination_id,
                         sum(nvl(rxel.accounted_dr,0)) -
                           sum(nvl(rxel.accounted_cr,0)) rxel_net_accounted
                  FROM xla_ae_lines rxel,
                       xla_ae_headers rxeh,
                       ap_undo_event_log rundo
                  WHERE rxeh.application_id(+) = 200
                   AND   rxel.application_id(+) = 200
                   AND   rxel.ae_header_id(+) = rxeh.ae_header_id
                   AND   rundo.e2 = rxeh.event_id(+)
                   AND   rxel.accounting_class_code(+) = ''LIABILITY''
                   GROUP BY rundo.e2, rxeh.entity_id, rxeh.event_id,
                            rxeh.ae_header_id, rxeh.ledger_id, rxeh.period_name,
                            rxeh.accounting_date, rxeh.gl_transfer_status_code,
                            rxel.code_combination_id
                ) rev,
                xla_events rev_xe,
                xla.xla_transaction_entities rxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.e2 = rev.rundo_event_id(+)
           AND undo.e2 = rev_xe.event_id(+)
           AND rxte.ledger_id = gl.ledger_id(+)
           AND rxte.entity_id(+) = rev.rxeh_entity_id
           AND rxte.application_id(+) =200
           GROUP BY ''REVERSE'', rxeh_period_name, rev.rxel_code_combination_id,
                    fnd_flex_ext.get_segs(
                      ''SQLGL'',
                      ''GL#'',
                      gl.chart_of_accounts_id,
                      rev.rxel_code_combination_id)
           UNION
           SELECT ''ORIGINAL'' TYPE,
                  oxeh_period_name,
                  fnd_flex_ext.get_segs(
                    ''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    orig.oxel_code_combination_id) account_num,
                  orig.oxel_code_combination_id,
                  sum(oxel_net_accounted)
           FROM (
                  SELECT oundo.e3 oundo_event_id,
                         oxeh.entity_id oxeh_entity_id,
                         oxeh.event_id oxeh_event_id,
                         oxeh.ae_header_id oxeh_ae_header_id,
                         oxeh.ledger_id oxeh_ledger_id,
                         oxeh.period_name oxeh_period_name,
                         oxeh.accounting_date oxeh_accounting_date,
                         oxeh.gl_transfer_status_code oxeh_gl_transfer_status_code,
                         oxel.code_combination_id oxel_code_combination_id,
                         sum(nvl(oxel.accounted_dr,0)) -
                           sum(nvl(oxel.accounted_cr,0)) oxel_net_accounted
                  FROM xla_ae_lines oxel,
                       xla_ae_headers oxeh,
                       ap_undo_event_log oundo
                  WHERE oxeh.application_id(+) = 200
                  AND oxel.application_id(+) = 200
                  AND oxel.ae_header_id(+) = oxeh.ae_header_id
                  AND oundo.e3 = oxeh.event_id(+)
                  AND oxel.accounting_class_code(+) = ''LIABILITY''
                  GROUP BY oundo.e3, oxeh.entity_id, oxeh.event_id,
                           oxeh.ae_header_id, oxeh.ledger_id, oxeh.period_name,
                           oxeh.accounting_date, oxeh.gl_transfer_status_code,
                           oxel.code_combination_id
                ) orig,
                xla_events orig_xe,
                xla.xla_transaction_entities oxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.e3 = orig.oundo_event_id(+)
           AND undo.e3 = orig_xe.event_id(+)
           AND oxte.entity_id(+) = orig.oxeh_entity_id
           AND oxte.ledger_id = gl.ledger_id(+)
           AND oxte.application_id(+) = 200
           GROUP BY ''ORIGINAL'', oxeh_period_name, orig.oxel_code_combination_id,
                    fnd_flex_ext.get_segs(
                      ''SQLGL'',
                      ''GL#'',
                      gl.chart_of_accounts_id,
                      orig.oxel_code_combination_id)
           UNION
           SELECT ''NEW'' TYPE,
                  nxeh_period_name,
                  fnd_flex_ext.get_segs(
                    ''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    new.nxel_code_combination_id) account_num,
                  new.nxel_code_combination_id,
                  sum( nxel_net_accounted)
           FROM (
                  SELECT nundo.event_id nundo_event_id,
                         nxeh.entity_id nxeh_entity_id,
                         nxeh.event_id nxeh_event_id,
                         nxeh.ae_header_id nxeh_ae_header_id,
                         nxeh.ledger_id nxeh_ledger_id,
                         nxeh.period_name nxeh_period_name,
                         nxeh.accounting_date nxeh_accounting_date,
                         nxeh.gl_transfer_status_code nxeh_gl_transfer_status_code,
                         nxel.code_combination_id nxel_code_combination_id,
                         sum(nvl(nxel.accounted_dr,0)) -
                           sum(nvl(nxel.accounted_cr,0)) nxel_net_accounted
                  FROM xla_ae_lines nxel,
                       xla_ae_headers nxeh,
                       ap_undo_event_log nundo,
                       (
                          SELECT event_id, MAX(e3) max_e3
                          FROM ap_undo_event_log
                          GROUP BY event_id
                       ) nundo2
                  WHERE nxeh.application_id(+) = 200
                  AND nxel.application_id(+) = 200
                  AND nxel.ae_header_id(+) = nxeh.ae_header_id
                  AND nundo.event_id = nxeh.event_id(+)
                  AND nxel.accounting_class_code(+) = ''LIABILITY''
                  AND nundo.event_id = nundo2.event_id
                  AND nundo.e3 = nundo2.max_e3
                  GROUP BY nundo.event_id, nxeh.entity_id, nxeh.event_id,
                           nxeh.ae_header_id, nxeh.ledger_id, nxeh.period_name,
                           nxeh.accounting_date, nxeh.gl_transfer_status_code,
                           nxel.code_combination_id
                ) new,
                xla_events new_xe,
                xla.xla_transaction_entities nxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.event_id = new.nundo_event_id(+)
           AND undo.event_id = new_xe.event_id(+)
           AND nxte.ledger_id = gl.ledger_id(+)
           AND nxte.entity_id(+) = new_xe.entity_id
           AND nxte.application_id = 200
           GROUP BY ''NEW'', nxeh_period_name, new.nxel_code_combination_id,
                    fnd_flex_ext.get_segs(
                      ''SQLGL'',
                      ''GL#'',
                      gl.chart_of_accounts_id,
                      new.nxel_code_combination_id)
         )
    WHERE rxel_code_combination_id = ##$$ACC$$##
    ORDER BY 2 DESC, 1',
   'Summary of Undo amounts',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  add_signature(
   'UNTRANSFERRED_REVERSE',
   'SELECT count(*),
           rxeh_gl_transfer_status_code
    FROM (
           SELECT ''REVERSE'' type,
                  undo.event_id,
                  undo.*,
                  rxte.entity_id rxte_entity_id,
                  rxte.entity_code rxte_entity_code,
                  rxte.source_id_int_1 rxte_source_id_int_1,
                  rxte.transaction_number rxte_transaction_number,
                  rxte.creation_date rxte_creation_date,
                  rev_xe.event_id,
                  rev_xe.event_type_code,
                  rev_xe.event_status_code,
                  rev.*,
                  fnd_flex_ext.get_segs(
                    ''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    rev.rxel_code_combination_id) account_num
           FROM (
                  SELECT rundo.e2 rundo_event_id,
                         rxeh.entity_id rxeh_entity_id,
                         rxeh.event_id rxeh_event_id,
                         rxeh.ae_header_id rxeh_ae_header_id,
                         rxeh.ledger_id rxeh_ledger_id,
                         rxeh.accounting_date rxeh_accounting_date,
                         rxeh.gl_transfer_status_code rxeh_gl_transfer_status_code,
                         rxel.code_combination_id rxel_code_combination_id,
                         sum(nvl(rxel.accounted_dr,0)) -
                           sum(nvl(rxel.accounted_cr,0)) rxel_net_accounted
                   FROM xla_ae_lines rxel,
                        xla_ae_headers rxeh,
                        ap_undo_event_log rundo
                   WHERE rxeh.application_id(+) = 200
                   AND   rxel.application_id(+) = 200
                   AND   rxel.ae_header_id(+) = rxeh.ae_header_id
                   AND   rundo.e2 = rxeh.event_id(+)
                   AND   rxel.accounting_class_code(+) = ''LIABILITY''
                   GROUP BY rundo.e2, rxeh.entity_id, rxeh.event_id,
                            rxeh.ae_header_id, rxeh.ledger_id,
                            rxeh.accounting_date, rxeh.gl_transfer_status_code,
                            rxel.code_combination_id
                ) rev,
                xla_events rev_xe,
                xla.xla_transaction_entities rxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.e2 = rev.rundo_event_id(+)
           AND   undo.e2 = rev_xe.event_id(+)
           AND   rxte.ledger_id = gl.ledger_id(+)
           AND   rxte.entity_id(+) = rev.rxeh_entity_id
           AND   rxte.application_id(+) =200
           AND   rev.rxel_code_combination_id = ##$$ACC$$##
           UNION
           SELECT ''ORIGINAL'' TYPE,
                  undo.event_id,
                  undo.*,
                  oxte.entity_id oxte_entity_id,
                  oxte.entity_code oxte_entity_code,
                  oxte.source_id_int_1 oxte_source_id_int_1,
                  oxte.transaction_number oxte_transaction_number,
                  oxte.creation_date oxte_creation_date,
                  orig_xe.event_id,
                  orig_xe.event_type_code,
                  orig_xe.event_status_code,
                  orig.*,
                  fnd_flex_ext.get_segs(
                    ''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    orig.oxel_code_combination_id) account_num
           FROM (
                  SELECT oundo.e3 oundo_event_id,
                         oxeh.entity_id oxeh_entity_id,
                         oxeh.event_id oxeh_event_id,
                         oxeh.ae_header_id oxeh_ae_header_id,
                         oxeh.ledger_id oxeh_ledger_id,
                         oxeh.accounting_date oxeh_accounting_date,
                         oxeh.gl_transfer_status_code oxeh_gl_transfer_status_code,
                         oxel.code_combination_id oxel_code_combination_id,
                         sum(nvl(oxel.accounted_dr,0)) -
                           sum(nvl(oxel.accounted_cr,0)) oxel_net_accounted
                  FROM xla_ae_lines oxel,
                       xla_ae_headers oxeh,
                       ap_undo_event_log oundo
                  WHERE oxeh.application_id(+) = 200
                  AND   oxel.application_id(+) = 200
                  AND   oxel.ae_header_id(+) = oxeh.ae_header_id
                  AND   oundo.e3 = oxeh.event_id(+)
                  AND   oxel.accounting_class_code(+) = ''LIABILITY''
                  GROUP BY oundo.e3, oxeh.entity_id, oxeh.event_id,
                           oxeh.ae_header_id, oxeh.ledger_id,
                           oxeh.accounting_date, oxeh.gl_transfer_status_code,
                           oxel.code_combination_id
                ) orig,
                xla_events orig_xe,
                xla.xla_transaction_entities oxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.e3 = orig.oundo_event_id(+)
           AND   undo.e3 = orig_xe.event_id(+)
           AND   oxte.entity_id(+) = orig.oxeh_entity_id
           AND   oxte.ledger_id = gl.ledger_id(+)
           AND   oxte.application_id(+) = 200
           AND   orig.oxel_code_combination_id = ##$$ACC$$##
           UNION
           SELECT ''NEW'' TYPE,
                  undo.event_id,
                  undo.*,
                  nxte.entity_id nxte_entity_id,
                  nxte.entity_code nxte_entity_code,
                  nxte.source_id_int_1 nxte_source_id_int_1,
                  nxte.transaction_number nxte_transaction_number,
                  nxte.creation_date nxte_creation_date,
                  new_xe.event_id,
                  new_xe.event_type_code,
                  new_xe.event_status_code,
                  new.*,
                  fnd_flex_ext.get_segs(
                    ''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    new.nxel_code_combination_id) account_num
           FROM (
                  SELECT nundo.event_id nundo_event_id,
                         nxeh.entity_id nxeh_entity_id,
                         nxeh.event_id nxeh_event_id,
                         nxeh.ae_header_id nxeh_ae_header_id,
                         nxeh.ledger_id nxeh_ledger_id,
                         nxeh.accounting_date nxeh_accounting_date,
                         nxeh.gl_transfer_status_code nxeh_gl_transfer_status_code,
                         nxel.code_combination_id nxel_code_combination_id,
                         sum(nvl(nxel.accounted_dr,0)) -
                           sum(nvl(nxel.accounted_cr,0)) nxel_net_accounted
                  FROM xla_ae_lines nxel,
                       xla_ae_headers nxeh,
                       ap_undo_event_log nundo,
                       (
                         SELECT event_id,
                                max(e3) max_e3
                         FROM ap_undo_event_log
                         GROUP BY event_id
                       ) nundo2
                  WHERE nxeh.application_id(+) = 200
                  AND   nxel.application_id(+) = 200
                  AND   nxel.ae_header_id(+) = nxeh.ae_header_id
                  AND   nundo.event_id = nxeh.event_id(+)
                  AND   nxel.accounting_class_code(+) = ''LIABILITY''
                  AND   nundo.event_id = nundo2.event_id
                  AND   nundo.e3 = nundo2.max_e3
                  GROUP BY nundo.event_id, nxeh.entity_id, nxeh.event_id,
                           nxeh.ae_header_id, nxeh.ledger_id,
                           nxeh.accounting_date, nxeh.gl_transfer_status_code,
                           nxel.code_combination_id
                ) NEW,
                xla_events new_xe,
                xla.xla_transaction_entities nxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.event_id = new.nundo_event_id(+)
           AND   undo.event_id = new_xe.event_id(+)
           AND   nxte.ledger_id = gl.ledger_id(+)
           AND   nxte.entity_id(+) = new_xe.entity_id
           AND   nxte.application_id = 200
           AND   new.nxel_code_combination_id = ##$$ACC$$##
         )
    WHERE rxeh_gl_transfer_status_code <> ''Y''
    GROUP BY rxeh_gl_transfer_status_code',
   'Untransferred Reverse Type Event Journal Entries',
   'RS',
   'There are reversing entries created by the undo that are not
    transferred.<BR>The reversal accounting needs to transferred
    and posted in GL for any related invoice(s) to be correctly reconciled.',
   '<ul>
    <li>Run the Transfer Journal Entries to GL program with Process
        Category parameter = Blank or Manual to pick up the reversing entries.</li>
    <li>Please see note 753695.1 for more details.</li>
    <li>Source KB Article: [753695.1]</li>
    </ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'UNACCOUNTED_NEW',
   'SELECT count(*),
           event_status_code
    FROM (
           SELECT ''REVERSE'' type,
                  undo.event_id,
                  undo.*,
                  rxte.entity_id rxte_entity_id,
                  rxte.entity_code rxte_entity_code,
                  rxte.source_id_int_1 rxte_source_id_int_1,
                  rxte.transaction_number rxte_transaction_number,
                  rxte.creation_date rxte_creation_date,
                  rev_xe.event_id,
                  rev_xe.event_type_code,
                  rev_xe.event_status_code,
                  rev.*,
                  fnd_flex_ext.get_segs(
                    ''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    rev.rxel_code_combination_id ) account_num
           FROM (
                  SELECT rundo.e2 rundo_event_id,
                         rxeh.entity_id rxeh_entity_id,
                         rxeh.event_id rxeh_event_id,
                         rxeh.ae_header_id rxeh_ae_header_id,
                         rxeh.ledger_id rxeh_ledger_id,
                         rxeh.accounting_date rxeh_accounting_date,
                         rxeh.gl_transfer_status_code rxeh_gl_transfer_status_code,
                         rxel.code_combination_id rxel_code_combination_id,
                         sum(nvl(rxel.accounted_dr,0)) -
                           sum(nvl(rxel.accounted_cr,0)) rxel_net_accounted
                  FROM xla_ae_lines rxel,
                       xla_ae_headers rxeh,
                       ap_undo_event_log rundo
                  WHERE rxeh.application_id(+) = 200
                  AND   rxel.application_id(+) = 200
                  AND   rxel.ae_header_id(+) = rxeh.ae_header_id
                  AND   rundo.e2 = rxeh.event_id(+)
                  AND   rxel.accounting_class_code(+) = ''LIABILITY''
                  GROUP BY rundo.e2, rxeh.entity_id, rxeh.event_id,
                           rxeh.ae_header_id, rxeh.ledger_id, rxeh.accounting_date,
                           rxeh.gl_transfer_status_code, rxel.code_combination_id
                ) rev,
                xla_events rev_xe,
                xla.xla_transaction_entities rxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.e2 = rev.rundo_event_id(+)
           AND   undo.e2 = rev_xe.event_id(+)
           AND   rxte.ledger_id = gl.ledger_id(+)
           AND   rxte.entity_id(+) = rev.rxeh_entity_id
           AND   rxte.application_id(+) =200
           AND   rev.rxel_code_combination_id = ##$$ACC$$##
           UNION
           SELECT ''ORIGINAL'' TYPE,
                  undo.event_id,
                  undo.*,
                  oxte.entity_id oxte_entity_id,
                  oxte.entity_code oxte_entity_code,
                  oxte.source_id_int_1 oxte_source_id_int_1,
                  oxte.transaction_number oxte_transaction_number,
                  oxte.creation_date oxte_creation_date,
                  orig_xe.event_id,
                  orig_xe.event_type_code,
                  orig_xe.event_status_code,
                  orig.*,
                  fnd_flex_ext.get_segs(
                    ''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    orig.oxel_code_combination_id) account_num
           FROM (
                  SELECT oundo.e3 oundo_event_id,
                         oxeh.entity_id oxeh_entity_id,
                         oxeh.event_id oxeh_event_id,
                         oxeh.ae_header_id oxeh_ae_header_id,
                         oxeh.ledger_id oxeh_ledger_id,
                         oxeh.accounting_date oxeh_accounting_date,
                         oxeh.gl_transfer_status_code oxeh_gl_transfer_status_code,
                         oxel.code_combination_id oxel_code_combination_id,
                         sum(nvl(oxel.accounted_dr,0)) -
                           sum(nvl(oxel.accounted_cr,0)) oxel_net_accounted
                  FROM xla_ae_lines oxel,
                       xla_ae_headers oxeh,
                       ap_undo_event_log oundo
                  WHERE oxeh.application_id(+) = 200
                  AND   oxel.application_id(+) = 200
                  AND   oxel.ae_header_id(+) = oxeh.ae_header_id
                  AND   oundo.e3 = oxeh.event_id(+)
                  AND   oxel.accounting_class_code(+) = ''LIABILITY''
                  GROUP BY oundo.e3, oxeh.entity_id, oxeh.event_id,
                           oxeh.ae_header_id, oxeh.ledger_id,
                           oxeh.accounting_date, oxeh.gl_transfer_status_code,
                           oxel.code_combination_id
                ) orig,
                xla_events orig_xe,
                xla.xla_transaction_entities oxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.e3 = orig.oundo_event_id(+)
           AND   undo.e3 = orig_xe.event_id(+)
           AND   oxte.entity_id(+) = orig.oxeh_entity_id
           AND   oxte.ledger_id = gl.ledger_id(+)
           AND   oxte.application_id(+) = 200
           AND   orig.oxel_code_combination_id = ##$$ACC$$##
           UNION
           SELECT ''NEW'' TYPE,
                  undo.event_id,
                  undo.*,
                  nxte.entity_id nxte_entity_id,
                  nxte.entity_code nxte_entity_code,
                  nxte.source_id_int_1 nxte_source_id_int_1,
                  nxte.transaction_number nxte_transaction_number,
                  nxte.creation_date nxte_creation_date,
                  new_xe.event_id,
                  new_xe.event_type_code,
                  new_xe.event_status_code,
                  new.*,
                  fnd_flex_ext.get_segs(''SQLGL'',
                    ''GL#'',
                    gl.chart_of_accounts_id,
                    new.nxel_code_combination_id) account_num
           FROM (
                  SELECT nundo.event_id nundo_event_id,
                         nxeh.entity_id nxeh_entity_id,
                         nxeh.event_id nxeh_event_id,
                         nxeh.ae_header_id nxeh_ae_header_id,
                         nxeh.ledger_id nxeh_ledger_id,
                         nxeh.accounting_date nxeh_accounting_date,
                         nxeh.gl_transfer_status_code nxeh_gl_transfer_status_code,
                         nxel.code_combination_id nxel_code_combination_id,
                         sum(nvl(nxel.accounted_dr,0)) -
                           sum(nvl(nxel.accounted_cr,0)) nxel_net_accounted
                  FROM xla_ae_lines nxel,
                       xla_ae_headers nxeh,
                       ap_undo_event_log nundo,
                       (
                         SELECT event_id,
                                max(e3) max_e3
                         FROM ap_undo_event_log
                         GROUP BY event_id
                       ) nundo2
                  WHERE nxeh.application_id(+) = 200
                  AND   nxel.application_id(+) = 200
                  AND   nxel.ae_header_id(+) = nxeh.ae_header_id
                  AND   nundo.event_id = nxeh.event_id(+)
                  AND   nxel.accounting_class_code(+) = ''LIABILITY''
                  AND   nundo.event_id = nundo2.event_id
                  AND   nundo.e3 = nundo2.max_e3
                  GROUP BY nundo.event_id, nxeh.entity_id, nxeh.event_id,
                           nxeh.ae_header_id, nxeh.ledger_id,
                           nxeh.accounting_date, nxeh.gl_transfer_status_code,
                           nxel.code_combination_id
                ) NEW,
                xla_events new_xe,
                xla.xla_transaction_entities nxte,
                gl_ledgers gl,
                ap_undo_event_log undo
           WHERE undo.event_id = new.nundo_event_id(+)
           AND   undo.event_id = new_xe.event_id(+)
           AND   nxte.ledger_id = gl.ledger_id(+)
           AND   nxte.entity_id(+) = new_xe.entity_id
           AND   nxte.application_id = 200
           AND   new.nxel_code_combination_id = ##$$ACC$$##
         )
    WHERE event_status_code <> ''P''
    GROUP BY event_status_code',
   'Unaccounted Undo Accounting Events',
   'RS',
   'There are accounting events that have been undone, which are not accounted',
   'Once an event is undone, the new accounting needs to be created 
    and transferred for any related invoice(s) to be correctly reconciled.
<ul>
<li>Run the Create Accounting program with ransfer to GL option to create and transfer the new accounting.</li>
<li>Please see note 753695.1 for more details.</li>
<li>Source KB Article: [753695.1]</li>
</ul>',
   null,
   'FAILURE',
   'E',
   'RS',
   'Y');
   
  ------------------------------------------------------------------------------
  -- Generic
  ------------------------------------------------------------------------------

  add_signature(
   'GEN_FIRST',
   'WITH tb AS (
      SELECT /*+ parallel(xtb) full(xtb)*/
             xtb.definition_code,
             nvl(xtb.applied_to_entity_id,xtb.source_entity_id) entity_id,
             xtb.code_combination_id,
             xtb.source_application_id,
             sum(nvl(xtb.entered_unrounded_cr,0)) -
               sum(nvl( xtb.entered_unrounded_dr,0)) entered_unrounded_rem_amount,
             sum(nvl(xtb.entered_rounded_cr,0)) -
               sum(nvl( xtb.entered_rounded_dr,0)) entered_rounded_rem_amount,
             sum(nvl(xtb.acctd_unrounded_cr,0)) -
                sum(nvl( xtb.acctd_unrounded_dr,0)) acctd_unrounded_rem_amount,
             sum(nvl(xtb.acctd_rounded_cr,0)) -
                sum(nvl(xtb.acctd_rounded_dr,0)) acctd_rounded_rem_amount,
             xtb.ledger_id,
             xtb.party_id,
             xtb.balancing_segment_value,
             xtb.natural_account_segment_value,
             xtb.cost_center_segment_value,
             xtb.intercompany_segment_value,
             xtb.management_segment_value
       FROM xla_trial_balances xtb
       WHERE xtb.definition_code = ''##$$TBDEF$$##''
       AND   xtb.source_application_id=200
       AND   xtb.code_combination_id = ''##$$ACC$$##''
       AND   xtb.gl_date BETWEEN ''##$$START$$##'' AND ''##$$END$$##''
       GROUP BY xtb.definition_code,
                nvl(xtb.applied_to_entity_id,xtb.source_entity_id),
                xtb.code_combination_id, xtb.source_application_id,
                xtb.ledger_id, xtb.party_id, xtb.balancing_segment_value,
                xtb.natural_account_segment_value, xtb.cost_center_segment_value,
                xtb.intercompany_segment_value, xtb.management_segment_value
       HAVING SUM (nvl(xtb.acctd_rounded_cr,0)) <> SUM (nvl(xtb.acctd_rounded_dr,0))
    )
    SELECT /*+ leading(tb) */
           tb.source_application_id,
           tb.entity_id,
           xte.entity_code,
           xte.transaction_number,
           tiv.invoice_num "INVOICE_NUMBER",
           xte.source_id_int_1 "INVOICE_ID",
           to_char(tiv.invoice_amount) "INVOICE_AMOUNT",
           to_char(tiv.base_amount) "INVOICE_BASE_AMOUNT",
           tiv.payment_status "PAYMENT_STATUS",
           tb.acctd_unrounded_rem_amount "UN_ROUNDED_REMAINING_AMOUNT",
           tb.acctd_rounded_rem_amount "ROUNDED_REMAINING_AMOUNT",
           tiv.invoice_date "INVOICE_DATE",
           tiv.cancelled_date "CANCELLED_DATE",
           tiv.description "INVOICE_DESCRIPTION",
           tiv.party_name PARTY_NAME,
           tb.code_combination_id "CODE_COMBINATION_ID",
           tiv.party_site_name "PARTY_SITE_NAME",
           gcc.concatenated_segments "GL_ACCOUNT",
           tb.ledger_id
    FROM ap_sla_invoices_transaction_v tiv,
         xla_transaction_entities_upg xte,
         tb,
         gl_code_combinations_kfv gcc,
         gl_ledgers gl
    WHERE tb.entity_id =xte.entity_id
    AND   tb.source_application_id =200
    AND   xte.entity_code =''AP_INVOICES''
    AND   xte.application_id =tb.source_application_id
    AND   xte.ledger_id =tb.ledger_id
    AND   nvl(xte.source_id_int_1,-99)=tiv.invoice_id
    AND   tb.code_combination_id = gcc.code_combination_id
    AND   xte.ledger_id = gl.ledger_id
    AND   tiv.payment_status = ''Fully Paid''
    ORDER BY tb.code_combination_id',
   'Generic TB issues',
   'NRS',
   NULL,
   NULL,
   NULL,
   'SUCCESS',
   'I',
   'RS',
   'Y');

  -------------------------------------------
  -- GDF
  -------------------------------------------
  add_signature(
   'Note874710.1',
   'SELECT ac.check_id,
            ac.check_number,
            ac.org_id,
            aph.payment_history_id,
            aph.transaction_type,
            aph.posted_flag,
            aph.historical_flag,
            xe.event_id,
            xe.event_type_code,
            xe.event_status_code,
            xe.process_status_code,
            xe.event_date,
            aph.related_event_id,
            xe.upg_batch_id
     FROM ap_payment_history_all aph,
          xla_events xe,
          ap_checks_all ac,
          (
           SELECT DISTINCT ph.check_id
           FROM ap_payment_history_all ph
           WHERE ph.accounting_date BETWEEN ''##$$START$$##'' AND ''##$$END$$##''
          ) chks
     WHERE aph.transaction_type LIKE ''%ADJUSTED''
     AND   nvl(aph.historical_flag, ''N'') = ''N''
     AND   (aph.accounting_event_id = aph.related_event_id OR
            aph.related_event_id is null)
     AND   aph.accounting_event_id = xe.event_id
     AND   xe.application_id = 200
     AND   aph.check_id = ac.check_id
     AND   ac.status_lookup_code <> ''VOIDED''
     AND   ac.void_date is null
     AND   ac.check_id = chks.check_id',
   'Payments with Incorrect Related Event ID',
   'RS',
   'Payments exist with either a null RELATED_EVENT_ID or the value
    is the same as the same transaction''s EVENT_ID',
   '<ul>
    <li>Payment with incorrect related event id (it is null or is
        same as accounting event id of the same transaction)</li>
    <li>Apply the GDF patch following the instructions provided in note 874710.1</li>
    <li>Source KB Article: [874710.1]</li></ul>',
    null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'Note1118703.1',
   'WITH ctrl AS (
       SELECT DISTINCT
              aip.check_id
       FROM (
             SELECT DISTINCT ph.check_id
             FROM ap_payment_history_all ph
             WHERE ph.accounting_date BETWEEN ''##$$START$$##'' AND ''##$$END$$##''
            ) chks,
            ap_invoice_payments_all aip,
            ap_invoice_payments_all aip2,
            ap_checks_all ac1
       WHERE ac1.void_date is not null
       AND   ac1.status_lookup_code = ''VOIDED''
       AND   ac1.check_id = aip2.check_id
       AND   aip.check_id != aip2.check_id
       AND   aip2.invoice_id = aip.invoice_id
       AND   aip.check_id = chks.check_id
     )
     SELECT /*+ ordered use_nl(ac, aph, xe, xh, xl) */
            ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.check_date,
            xe.event_id,
            xe.event_type_code,
            sum(nvl(entered_cr,   0)) - sum(nvl(entered_dr,   0)) acctd_amt,
            ac.amount,
            ''Case 1'' case
     FROM ctrl,
          ap_checks_all ac,
          ap_payment_history_all aph,
          xla_events xe,
          xla_ae_headers xh,
          xla_ae_lines xl,
          ap_system_parameters_all asp
     WHERE xl.application_id = 200
     AND   aph.check_id = ac.check_id
     AND   ac.check_id = ctrl.check_id
     AND   ac.void_date is null
     AND   EXISTS (
             SELECT 1 FROM ap_invoice_payments_all aip
             WHERE aip.check_id = ac.check_id
             GROUP BY aip.check_id
             HAVING   sum(aip.amount) = ac.amount)
     AND   aph.accounting_event_id = xe.event_id
     AND   aph.posted_flag = ''Y''
     AND   xe.event_id = xh.event_id
     AND   xh.upg_batch_id is null
     AND   xe.event_type_code IN(''PAYMENT CREATED'', ''REFUND RECORDED'',
             ''PAYMENT CLEARED'')
     AND   xe.event_status_code = ''P''
     AND   xe.application_id = 200
     AND   xh.application_id = 200
     AND   xh.ledger_id = asp.set_of_books_id
     AND   xh.ae_header_id = xl.ae_header_id
     AND   asp.org_id = ac.org_id
     AND   xl.accounting_class_code IN(''CASH_CLEARING'', ''CASH'',
             ''FUTURE_DATED_PMT'')
     AND   decode(xe.event_type_code,
             ''PAYMENT CLEARED'',xl.accounting_class_code,
             ''YES'') != ''CASH''
     GROUP BY ac.org_id, ac.check_id, ac.check_date, ac.check_number,
              ac.amount, xe.event_id, xe.event_type_code
     HAVING   abs(abs(sum(nvl(entered_cr,0)) -
              sum(nvl(entered_dr,0))) - abs(ac.amount)) > 1
     UNION ALL
     SELECT /*+ ordered use_nl(ac, aph, aphd, xh) */
            ac.check_id,
            ac.check_number,
            ac.org_id,
            ac.check_date,
            aph.accounting_event_id,
            aph.transaction_type,
            0 acctd_amt,
            ac.amount,
            ''Case 2''
     FROM ctrl,
          ap_checks_all ac,
          ap_payment_history_all aph,
          ap_payment_hist_dists aphd,
          xla_ae_headers xh,
          ap_system_parameters_all asp
     WHERE ac.amount <> 0
     AND aph.check_id = ac.check_id
     AND ac.check_id = ctrl.check_id
     AND ac.void_date is null
     AND asp.org_id = ac.org_id
     AND aphd.accounting_event_id = aph.accounting_event_id
     AND aphd.accounting_event_id = xh.event_id
     AND xh.application_id = 200
     AND xh.upg_batch_id is null
     AND aphd.pay_dist_lookup_code IN( ''CASH'', ''FINAL PAYMENT ROUNDING'')
     AND aph.transaction_type IN (''PAYMENT CREATED'',''REFUND RECORDED'')
     AND aph.posted_flag = ''Y''
     GROUP BY ac.org_id, ac.check_id, ac.check_date,
              ac.check_number, ac.amount, aph.accounting_event_id,
              aph.transaction_type
     HAVING sum(aphd.invoice_dist_base_amount) = 0',
   'Checks accounted with incorrect amounts due to bugs 8975671 and 9257606',
   'RS',
   'Reissue Checks are accounted with incorrect amounts',
   '<ul>
    <li>Checks accounted with incorrect amounts due to bugs 8975671 and 9257606</li>
    <li>Apply the GDF patch following the instructions provided in note 1118703.1</li>
    <li>Source KB Article: [1118703.1]</li></ul>',
    null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'GDF14637911',
   'WITH ctrl AS (
           SELECT /*+ parallel(ael) full(ael) */
                  ael.reference2 "INVOICE_ID",
                  COUNT(DISTINCT ael.third_party_id) "NUMBER_OF_PARTIES"
             FROM ap_ae_lines_all ael
            WHERE ael.ae_line_type_code = ''LIABILITY''
            GROUP BY ael.reference2
           HAVING COUNT(DISTINCT ael.third_party_id) > 1)
      SELECT DISTINCT
             inv_pay_info.orig_invoice,
             inv_pay_info.ael_source_table,
             inv_pay_info.ael_source_id,
             xte.*,
             tiv.invoice_num,
             tiv.party_name
        FROM xla_transaction_entities_upg xte,
             AP_SLA_INVOICES_TRANSACTION_V tiv,
    (SELECT /*+parallel(dat)*/DISTINCT
                    ctrl.invoice_id "ORIG_INVOICE",
       inv.invoice_id xte_source_id,
      ''AP_INVOICES'' xte_source_table,
      inv.invoice_id ael_source_id,
      ''AP_INVOICES'' ael_source_table,
      inv.set_of_books_id
       FROM ctrl,
      ap_invoices_all inv
              WHERE ctrl.invoice_id = inv.invoice_id
         UNION
      SELECT /*+parallel(dat)*/DISTINCT
        ctrl.invoice_id "ORIG_INVOICE",
      invpay.check_id xte_source_id,
      ''AP_PAYMENTS'' xte_source_table,
        invpay.invoice_payment_id ael_source_id,
        ''AP_INVOICE_PAYMENTS'' ael_source_table,
        invpay.set_of_books_id
         FROM ctrl,
        ap_invoice_payments_all invpay
        WHERE ctrl.invoice_id = invpay.invoice_id
          ) inv_pay_info
       WHERE xte.application_id = 200
         AND inv_pay_info.orig_invoice = tiv.invoice_id
         AND xte.ledger_id = inv_pay_info.set_of_books_id
         AND xte.entity_code = inv_pay_info.xte_source_table
         AND nvl(xte.source_id_int_1 , -99) = inv_pay_info.xte_source_id
         AND nvl(xte.source_id_int_2 , -99) = -99
         AND nvl(xte.source_id_int_3 , -99) = -99
         AND nvl(xte.source_id_int_4 , -99) = -99
         AND nvl(xte.SOURCE_ID_CHAR_1,'' '') = '' ''
         AND nvl(xte.SOURCE_ID_CHAR_2,'' '') = '' ''
         AND nvl(xte.SOURCE_ID_CHAR_3,'' '') = '' ''
         AND nvl(xte.SOURCE_ID_CHAR_4,'' '') = '' '' ',
   'Upgraded invoices with multiple parties',
   'RS',
   'Upgraded invoices with exist with multiple parties',
   '<ul>
    <li>Upgraded invoices with multiple parties</li>
    <li>Apply the GDF patch 14637911 following the instructions in patch read me</li>
    </ul>',
    null,
   'FAILURE',
   'E',
   'RS',
   'Y');

     add_signature(
   'Note1276043.1',
   'WITH invs AS (
      SELECT DISTINCT d.invoice_id
      FROM ap_invoice_distributions_all d
      WHERE d.accounting_date BETWEEN ''##$$START$$##'' AND ''##$$END$$##'')
    SELECT /*+ ordered use_nl(ai) */
           ai.invoice_id,
           ai.invoice_num,
           ai.org_id,
           ai.cancelled_date,
           ''header base amount issue'' reason
    FROM invs,
         ap_invoices_all ai,
         ap_system_parameters_all asp
    WHERE ai.exchange_rate is not null
    AND   ai.org_id = asp.org_id
    AND   ap_utilities_pkg.ap_round_currency(
             invoice_amount * exchange_rate, base_currency_code)
             <> base_amount
    AND   ai.invoice_id = invs.invoice_id
    UNION ALL
    SELECT /*+ ordered us_nl(ai) */
           ai.invoice_id,
           ai.invoice_num,
           ai.org_id,
           ai.cancelled_date,
           ''lines base amount issue''
    FROM  invs,
          ap_invoices_all ai,
          ap_system_parameters_all asp
    WHERE ai.exchange_rate is not null
    AND   ai.org_id = asp.org_id
    AND   ap_invoices_utility_pkg.get_approval_status(
            ai.invoice_id,ai.invoice_amount, ai.payment_status_flag,
            ai.invoice_type_lookup_code) <> ''NEVER APPROVED''
    AND   ai.invoice_type_lookup_code <> ''PO PRICE ADJUST''
    AND   NOT EXISTS (
            SELECT /*+ no_unnest */ ''Adjustment corrections exists''
            FROM ap_invoice_distributions_all aid
            WHERE aid.invoice_id = ai.invoice_id
            AND   aid.dist_match_type=''ADJUSTMENT_CORRECTION'')
    AND   ai.invoice_amount = (
            SELECT sum(ail.amount) +
                     decode(nvl(ai.net_of_retainage_flag,''N''),
                       ''Y'',sum(nvl(retained_amount,0)),0)
            FROM ap_invoice_lines_all ail
            WHERE ail.invoice_id = ai.invoice_id
            AND   ail.line_type_lookup_code <> ''AWT''
            AND   ((ail.prepay_invoice_id is not null AND
                    nvl(ail.invoice_includes_prepay_flag, ''N'') = ''Y'') OR
                   ail.prepay_invoice_id is null))
    AND   nvl(ai.base_amount,0) <> (
            SELECT sum(nvl(base_amount,0))  +
                     decode(nvl(ai.net_of_retainage_flag,''N''),
                       ''Y'',ap_utilities_pkg.ap_round_currency(
                       sum(nvl(retained_amount,0))*ai.exchange_rate,
                       asp.base_currency_code), 0)
            FROM AP_INVOICE_LINES_ALL ail
            WHERE ail.invoice_id = ai.invoice_id
            AND   ail.line_type_lookup_code <> ''AWT''
            AND   ((ail.prepay_invoice_id is not null AND
                    nvl(ail.invoice_includes_prepay_flag, ''N'') = ''Y'') OR
                   ail.prepay_invoice_id is null))
    AND   ai.invoice_id = invs.invoice_id
    UNION ALL
    SELECT /*+ ordered use_nl(ai, ail) */
           ai.invoice_id,
           ai.invoice_num,
           ai.org_id,
           ai.cancelled_date,
           ''dists base amount issue''
    FROM invs,
         ap_invoices_all ai,
         ap_invoice_lines_all ail
    WHERE ai.exchange_rate is not null
    AND   ai.invoice_id = ail.invoice_id
    AND   ail.base_amount is not null
    AND   ai.invoice_type_lookup_code <> ''PO PRICE ADJUST''
    AND   NOT EXISTS (
            SELECT /*+ no_unnest */ ''unvalidated dists exists''
            FROM ap_invoice_distributions_all aid1
            WHERE aid1.invoice_id = ai.invoice_id
            AND   (aid1.dist_match_type=''ADJUSTMENT_CORRECTION'' OR
                   nvl(aid1.match_status_flag,''N'') = ''N''))
    AND   ail.amount = (
            SELECT /*+ no_unnest */ sum(aid2.amount)
            FROM AP_INVOICE_DISTRIBUTIONS_ALL aid2
            WHERE aid2.invoice_id = ail.invoice_id
            AND   aid2.invoice_line_number = ail.line_number)
    AND   (ail.line_type_lookup_code in (''ITEM'',''FREIGHT'',''MISCELLANEOUS'') OR
           ai.cancelled_date is not null)
    AND   ail.base_amount <> (
            SELECT /*+ no_unnest */ sum(nvl(aid.base_amount,0))
            FROM ap_invoice_distributions_all aid
            WHERE aid.invoice_id = ail.invoice_id
            AND   aid.invoice_line_number = ail.line_number)
    AND   ai.invoice_id = invs.invoice_id
    UNION ALL
    SELECT /*+ ordered use_nl(ai) */
           ai.invoice_id,
           ai.invoice_num,
           ai.org_id,
           ai.cancelled_date,
           ''opposite signs''
    FROM invs,
         ap_invoices_all ai
    WHERE ai.exchange_rate is not null
    AND   ai.invoice_type_lookup_code <> ''PO PRICE ADJUST''
    AND   NOT EXISTS (
            SELECT /*+ no_unnest */ ''Adjustment corrections exists''
            FROM ap_invoice_distributions_all aid1
            WHERE aid1.invoice_id = ai.invoice_id
            AND   aid1.dist_match_type=''ADJUSTMENT_CORRECTION'')
    AND   EXISTS(
            SELECT /*+ no_unnest */ ''opposite signs''
            FROM ap_invoice_distributions_all aid
            WHERE aid.invoice_id = ai.invoice_id
            AND aid.base_amount is not null
            AND ((aid.amount > 0 AND aid.base_amount <0) OR
                 (aid.amount < 0 AND aid.base_amount >0)))
    AND   ai.invoice_id = invs.invoice_id
    UNION ALL
    SELECT /*+ ordered use_nl(ai) */
           ai.invoice_id,
           ai.invoice_num,
           ai.org_id,
           ai.cancelled_date,
           ''wrong variance''
    FROM invs,
         ap_invoices_all ai
    WHERE nvl(ai.historical_flag,''N'') <> ''Y''
    AND   ai.exchange_rate is not null
    AND   ai.cancelled_date is null
    AND   ai.invoice_type_lookup_code <> ''PO PRICE ADJUST''
    AND   NOT EXISTS (
            SELECT /*+ no_unnest */ ''Adjustment corrections exists''
            FROM ap_invoice_distributions_all aid1
            WHERE aid1.invoice_id = ai.invoice_id
            AND   aid1.dist_match_type=''ADJUSTMENT_CORRECTION'')
    AND   EXISTS (
            SELECT /*+ no_unnest */ ''wrong variance''
            FROM ap_invoice_distributions_all aid
            WHERE aid.invoice_id = ai.invoice_id
            AND   (aid.po_distribution_id is not null OR
                   aid.rcv_transaction_id is not null)
            AND   nvl(aid.dist_match_type,''NOT_MATCHED'') IN
                    (''ITEM_TO_PO'',''ITEM_TO_RECEIPT'',
                     ''ITEM_TO_SERVICE_PO'',''ITEM_TO_SERVICE_RECEIPT'',
                     ''QTY_CORRECTION'',''AMOUNT_CORRECTION'')
            AND   nvl(aid.reversal_flag,''N'') <> ''Y''
            AND   aid.line_type_lookup_code in (''ITEM'',''ACCRUAL'')
            AND   abs(aid.base_amount -
                    (SELECT /*+ no_unnest */ ap_utilities_pkg.ap_round_currency(
                              aid1.amount * nvl(rt.currency_conversion_rate,pod.rate),
                              asp.base_currency_code)
                     FROM ap_invoice_distributions_all aid1,
                          po_distributions_all pod,
                          rcv_transactions rt,
                          ap_system_parameters_all asp
                     WHERE aid1.invoice_distribution_id = aid.invoice_distribution_id
                     AND aid1.po_distribution_id = pod.po_distribution_id
                     AND aid1.rcv_transaction_id = rt.transaction_id (+)
                     AND aid1.org_id = asp.org_id))
                    > .99)
    AND   ai.invoice_id = invs.invoice_id',
   'Invoice Issues with Amounts and Base Amounts',
   'RS',
   'Invoice related issues with amounts and base amounts',
   '<ul>
    <li>Identifies a series of invoice related issues with amounts and base amounts</li>
    <li>See note 1276043.1 for the complete list of issues addressed in this query</li>
    <li>Apply the GDF patch following the instructions provided in note 1276043.1</li>
    <li>Source KB Article: [1276043.1]</li>
    </ul>',
    null,
   'FAILURE',
   'E',
   'RS',
   'Y');

  add_signature(
   'Note1061563.1',
   'WITH invs AS (
      SELECT DISTINCT d.invoice_id
      FROM ap_invoice_distributions_all d
      WHERE d.accounting_date BETWEEN ''##$$START$$##'' AND ''##$$END$$##''),
    man_nonrev_awt_on_rev_itm AS (
      SELECT /*+ leading(invs) use_nl(aid, aid_item) */
             aid.invoice_id,
             aid.invoice_line_number,
             aid.invoice_distribution_id,
             aid.amount,
             sum(aid.amount)
               over(partition by aid.invoice_id, aid.invoice_line_number)
                line_wise_sum
      FROM invs,
           ap_invoice_distributions_all aid,
           ap_invoice_distributions_all aid_item
      WHERE aid.invoice_id = invs.invoice_id
      AND   aid.invoice_id = aid_item.invoice_id
      AND   aid.awt_related_id = aid_item.invoice_distribution_id
      AND   aid.line_type_lookup_code = ''AWT''
      AND   aid.awt_flag = ''M''
      AND   nvl(aid.historical_flag, ''N'') = ''N''
     AND   aid.awt_related_id is not null
      AND   nvl(aid.reversal_flag, ''N'') = ''N''
      AND   aid_item.reversal_flag = ''Y''
     ),
     zero_amt_awt_no_nonrev_itm as (
       SELECT /*+ leading(invs) use_nl(aid) */
              aid.invoice_id,
              aid.invoice_line_number,
              aid.invoice_distribution_id,
              aid.amount,
              sum(aid.amount)
                over(partition by aid.invoice_id, aid.invoice_line_number)
                line_wise_sum,
              sum(aid.amount)
                over(partition by aid.invoice_id)
                inv_wise_sum
       FROM invs,
            ap_invoice_distributions_all aid
       WHERE aid.invoice_id = invs.invoice_id
       AND   aid.line_type_lookup_code = ''AWT''
       AND   aid.awt_related_id is null
       AND   aid.historical_flag = ''Y''
       AND   nvl(aid.reversal_flag, ''N'') = ''N''
       AND   NOT EXISTS (
               SELECT 1 FROM ap_invoice_distributions_all aidx
               WHERE aidx.invoice_id = aid.invoice_id
               AND   aidx.line_type_lookup_code not in (''AWT'',''ERV'',''TERV'')
               AND   aidx.prepay_distribution_id is null
               AND   nvl(aidx.reversal_flag, ''N'') = ''N''
               AND   sign(aidx.amount) <> sign(aid.amount)
               AND   abs(aidx.amount) >= abs(aid.amount))
     )
     SELECT /*+ ordered use_nl(aid) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null related_id,
            aid.awt_invoice_payment_id,
            ''1'' category
     FROM invs,
          ap_invoice_distributions_all aid
     WHERE aid.line_type_lookup_code = ''AWT''
     AND   nvl(aid.historical_flag,''N'') = ''N''
     AND   aid.awt_related_id is null
     AND   aid.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, aid) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null,
            aid.awt_invoice_payment_id,
            ''2''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid
     WHERE aid.line_type_lookup_code = ''AWT''
     AND   aid.historical_flag = ''Y''
     AND   aid.awt_related_id is null
     AND   ai.invoice_id = aid.invoice_id
     AND   ai.payment_status_flag IN (''N'',''P'')
     AND   ai.historical_flag = ''Y''
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, aid) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null,
            aid.awt_invoice_payment_id,
            ''3''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid
     WHERE ai.invoice_id = invs.invoice_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   aid.historical_flag = ''Y''
     AND   aid.awt_related_id is null
     AND   ai.invoice_id = aid.invoice_id
     AND   ai.payment_status_flag = ''Y''
     AND   ai.historical_flag = ''Y''
     AND   EXISTS (
             SELECT /*+ no_unnest ordered use_nl(aph, xe) */ 1
             FROM ap_invoice_payments_all aip,
                  ap_payment_history_all aph,
                  xla_events xe
             WHERE  aip.invoice_id = ai.invoice_id
             AND   aip.check_id = aph.check_id
             AND   xe.event_id = aph.accounting_event_id
             AND   xe.application_id = 200
             AND   (aph.posted_flag = ''N'' OR
                    (aph.posted_flag = ''Y'' AND
                     EXISTS (
                       SELECT 1 FROM xla_ae_headers xh
                       WHERE xh.event_id = xe.event_id
                       AND   xh.application_id = 200
                       AND   nvl(xh.upg_batch_id, -9999) = -9999))))
     UNION ALL
     SELECT /*+ ordered use_nl(aid) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null,
            aid.awt_invoice_payment_id,
            ''4''
     FROM invs,
          ap_invoice_distributions_all aid
     WHERE aid.line_type_lookup_code = ''AWT''
     AND   nvl(aid.historical_flag,''N'') = ''N''
     AND   aid.awt_related_id is not null
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aid_parent
             WHERE aid_parent.invoice_id = aid.invoice_id
             AND   aid.awt_related_id = aid_parent.invoice_distribution_id)
     AND   aid.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(aid, aid_item) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null,
            aid.awt_invoice_payment_id,
            ''5''
     FROM invs,
          ap_invoice_distributions_all aid,
          ap_invoice_distributions_all aid_item
     WHERE aid.invoice_id = aid_item.invoice_id
     AND   aid.awt_related_id = aid_item.invoice_distribution_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   aid.awt_flag = ''A''
     AND   nvl(aid.historical_flag, ''N'') = ''N''
     AND   aid.awt_related_id is not null
     AND   nvl(aid.reversal_flag, ''N'') = ''N''
     AND   aid_item.reversal_flag = ''Y''
     AND   aid.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(aid, aid_erv) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            aid_erv.related_id,
            aid.awt_invoice_payment_id,
            ''6''
     FROM invs,
          ap_invoice_distributions_all aid,
          ap_invoice_distributions_all aid_erv
     WHERE aid.invoice_id = aid_erv.invoice_id
     AND   aid.awt_related_id = aid_erv.invoice_distribution_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   aid.awt_flag = ''A''
     AND   nvl(aid.historical_flag, ''N'') = ''N''
     AND   aid_erv.line_type_lookup_code in (''TERV'', ''ERV'')
     AND   aid.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai, aid_awt, aid_item, xe_item) */
            aid_awt.invoice_id,
            aid_awt.org_id,
            aid_awt.invoice_distribution_id,
            aid_awt.invoice_line_number,
            aid_awt.distribution_line_number,
            aid_awt.posted_flag,
            aid_awt.awt_flag,
            null related_id,
            aid_awt.awt_invoice_payment_id,
            ''7''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid_awt,
          ap_invoice_distributions_all aid_item,
          xla_events xe_item,
          ap_system_parameters_all param
     WHERE aid_awt.line_type_lookup_code = ''AWT''
     AND   aid_item.invoice_distribution_id = aid_awt.awt_related_id
     AND   ai.invoice_id = aid_awt.invoice_id
     AND   ai.invoice_id = aid_item.invoice_id
     AND   xe_item.event_id = aid_item.accounting_event_id
     AND   xe_item.application_id = 200
     AND   (nvl(ai.payment_status_flag, ''N'') <> ''Y'' OR
            EXISTS (
              SELECT /*+ no_unnest ordered use_nl(aip, aph, xe) */ 1
              FROM ap_invoice_payments_all aip,
                   ap_payment_history_all aph,
                   xla_events xe
              WHERE aip.invoice_id = ai.invoice_id
              AND   aip.check_id = aph.check_id
              AND   xe.event_id = aph.accounting_event_id
              AND   xe.application_id = 200
              AND   (aph.posted_flag = ''N'' OR
                     (aph.posted_flag = ''Y'' AND
                      EXISTS (
                        SELECT 1 FROM xla_ae_headers xh
                        WHERE xh.event_id = xe.event_id
                        AND   xh.application_id = 200
                        AND   nvl(xh.upg_batch_id, -9999) = -9999)))))
     AND   xe_item.event_type_code like ''%ADJUSTED''
     AND   ai.historical_flag = ''Y''
     AND   param.org_id = ai.org_id
     AND   aid_awt.parent_reversal_id is null
     AND   param.automatic_offsets_flag = ''N''
     AND   EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aidx
             WHERE aidx.accounting_event_id = xe_item.event_id
             AND   aidx.invoice_id = aid_item.invoice_id
             HAVING sum(aidx.amount) = 0)
     AND   ai.invoice_id = invs.invoice_id
     UNION ALL
     SELECT /*+ ordered use_nl(ai) */
            aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null related_id,
            aid.awt_invoice_payment_id,
            ''8''
     FROM invs,
          ap_invoices_all ai,
          ap_invoice_distributions_all aid
     WHERE ai.invoice_id = invs.invoice_id
     AND   aid.invoice_id = ai.invoice_id
     AND   aid.line_type_lookup_code = ''AWT''
     AND   aid.awt_related_id is null
     AND   ai.cancelled_date is null
     AND   (aid.awt_flag = ''M'' OR
            (aid.awt_flag = ''A'' AND aid.historical_flag = ''Y''))
     AND   NOT EXISTS (
             SELECT /*+ no_unnest */ 1 FROM ap_invoice_distributions_all aidx
             WHERE aidx.invoice_id = aid.invoice_id
             AND   aidx.line_type_lookup_code not in (''AWT'',''ERV'',''TERV'')
             AND   aidx.prepay_distribution_id is null
             AND   abs(aidx.amount) >= abs(aid.amount))
     AND   (nvl(ai.payment_status_flag, ''N'') <> ''Y'' OR
            EXISTS (
              SELECT /*+ no_unnest */ 1
              FROM ap_invoice_payments_all aip,
                   ap_payment_history_all aph,
                   xla_events xe
              WHERE  aip.invoice_id = ai.invoice_id
              AND   aip.check_id = aph.check_id
              AND   xe.event_id = aph.accounting_event_id
              AND   xe.application_id = 200
              AND   (aph.posted_flag = ''N'' OR
                     (aph.posted_flag = ''Y'' AND
                      EXISTS (
                        SELECT 1 FROM xla_ae_headers xh
                        WHERE xh.event_id = xe.event_id
                        AND   xh.application_id = 200
                        AND   nvl(xh.upg_batch_id, -9999) = -9999)))))
     UNION
     SELECT aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null related_id,
            aid.awt_invoice_payment_id,
            ''9''
     FROM ap_invoice_distributions_all aid
     WHERE aid.invoice_distribution_id IN (
             SELECT invoice_distribution_id FROM man_nonrev_awt_on_rev_itm
             WHERE line_wise_sum = 0)
     UNION
     SELECT aid.invoice_id,
            aid.org_id,
            aid.invoice_distribution_id,
            aid.invoice_line_number,
            aid.distribution_line_number,
            aid.posted_flag,
            aid.awt_flag,
            null related_id,
            aid.awt_invoice_payment_id,
            ''10''
     FROM ap_invoice_distributions_all aid
     WHERE aid.invoice_distribution_id IN (
             SELECT invoice_distribution_id FROM zero_amt_awt_no_nonrev_itm
             WHERE (line_wise_sum = 0 OR
                    inv_wise_sum = 0))',
   'Automatic Withholding Tax (AWT) Distributions with Missing AWT_RELATED_ID',
   'RS',
   'Automatic withholding tax (AWT) distributions with missing AWT_RELATED_ID',
   '<ul>
    <li>Automatic withholding tax (AWT) distributions with missing AWT_RELATED_ID</li>
    <li>Apply the GDF patch following the instructions provided in note 1061563.1</li>
    <li>Source KB Article: [1061563.1]</li>
    </ul>',
    null,
   'FAILURE',
   'E',
   'RS',
   'Y');


   
EXCEPTION WHEN OTHERS THEN
  print_log('Error in load_signatures');
  raise;
END load_signatures;





---------------------------------
-- MAIN ENTRY POINT
---------------------------------
PROCEDURE main (
      p_org_ids    IN VARCHAR2 DEFAULT NULL,
      p_mode       IN VARCHAR2 DEFAULT NULL,
      p_ledger_id  IN NUMBER DEFAULT NULL,
      p_invoice_id IN NUMBER DEFAULT NULL,
      p_tb_code    IN VARCHAR2 DEFAULT NULL,
      p_liab_acc   IN varchar2 DEFAULT NULL,
      p_start_date IN VARCHAR2 DEFAULT NULL,
      p_end_date   IN VARCHAR2 DEFAULT NULL,
      p_max_output_rows IN NUMBER   DEFAULT 200,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS

  l_sql_result VARCHAR2(1);
  l_step       VARCHAR2(5);
  l_analyzer_end_time   TIMESTAMP;

BEGIN

  -- re-initialize values 
  g_sect_no := 1;
  g_sig_id := 0;
  g_item_id := 0;
  
  l_step := '10';
  initialize_files;
  
  -- Title of analyzer!! - do not add word 'analyzer' at the end as it is appended in code where title is called   
  analyzer_title := 'EBS Payables Trial Balance';

  l_step := '20';
 validate_parameters(
      p_org_ids,
      p_ledger_id,
      p_mode,
      p_invoice_id,
      p_tb_code,
      p_liab_acc,
      p_start_date,
      p_end_date,
      p_max_output_rows,
      p_debug_mode);

  l_step := '30';
  print_rep_title(analyzer_title);

  l_step := '40';
  load_signatures;

  l_step := '50';
  print_toc('Sections In This Report');

  -- Start of Sections and signatures
  l_step := '60';
  print_out('<div id="tabCtrl">');

  start_section('Proactive and Preventative Recommendations');
  IF 
     ((substr(g_rep_info('Apps Version'),1,4) = '12.0') OR 
     (substr(g_rep_info('Apps Version'),1,4) = '12.1')) THEN
     set_item_result(check_rec_patches);
  END IF; 
     set_item_result(run_stored_sig('FILE_VERSIONS'));
  end_section;
  -- Start of Sections and signatures
  
  -- TB Section
  IF p_tb_code is not null THEN
  start_section('Trial Balance Report Definition Data');
	set_item_result(run_stored_sig('XLA_TB_DEFINITIONS_B'));
    set_item_result(run_stored_sig('XLA_TB_DEFINITIONS_TL'));
    set_item_result(run_stored_sig('XLA_TB_DEFN_DETAILS'));
    set_item_result(run_stored_sig('XLA_TB_SUMMARY'));
  end_section;
  END IF;
  
  -- Transaction mode is Invoice
  IF upper(ltrim(rtrim(p_mode))) = 'TRANSACTION' AND p_invoice_id is not null
  AND p_start_date is not null AND p_end_date is not null
  AND p_ledger_id is not null AND p_tb_code is not null THEN
    start_section('Invoice Details');
	  set_item_result(run_stored_sig('INVOICE_REMAINING_AMOUNTS_IN_11i_TB'));
      set_item_result(run_stored_sig('11iACCNTD_DATA_NOT_IN_11i_TB'));
      --set_item_result(run_stored_sig('11iTB_DATA_NOT_IN_11iACCNTD_TABLES'));
      --set_item_result(run_stored_sig('11iDATA_GLTrx_IN_R12_MISSING_11iTB'));
      set_item_result(run_stored_sig('11i_DATA_NOT_IN_R12_ACCNTD_TABLES'));
      --set_item_result(run_stored_sig('INVOICE_PAYMENT_AMOUNTS_IN_XLADISTRIBUTIONLINKS'));
      set_item_result(run_stored_sig('MIN_AND_MAX_ACCOUNTING_DATE_IN_TRIAL_BALANCE_FOR_INVOICEPAYMENT'));
      set_item_result(run_stored_sig('REMAINING_AMOUNT_FOR_INVOICE_PER_PARTY_FROM_TRIAL_BALANCE'));
      set_item_result(run_stored_sig('DATA_MARKED_AS_TRANSFERRED_TO_GL_BUT_NOT_EXISTS_IN_GL'));
      set_item_result(run_stored_sig('DATA_MULTIPOSTED_TO_GLFOR_INVOICE'));
      set_item_result(run_stored_sig('DATA_MULTIPOSTED_TO_GLFOR_PAYMENTS_ON_INVOICE'));
      set_item_result(run_stored_sig('DATA_WITH_INCORRECT_AMOUNT_BETWEEN_AP_AND_XLA'));
      set_item_result(run_stored_sig('GL_TRANSFERRED_DATA_MISSING_FROM_TRIAL_BALANCE'));
	  set_item_result(run_stored_sig('GL_TRANSFERRED_FUTURE_LINE_DATA_MISSING_FROM_TRIAL_BALANCE'));
      set_item_result(run_stored_sig('EVENTS_NOT_YET_ACCOUNTED'));
      set_item_result(run_stored_sig('LIABILITY_NOT_TRANSFERRED_TO_GL'));
      set_item_result(run_stored_sig('PAYMENT_LIABILITY_DATA_MISSING_APPLIED_TO_ATTRIBUTES'));
      set_item_result(run_stored_sig('DUPLICATE_DATA_FOR_INVOICE_PAYMENT_IN_TRIAL_BALANCE'));
      set_item_result(run_stored_sig('LIABILITY_ACCOUNT_USED_FOR_OTHER_LINES'));
      set_item_result(run_stored_sig('LIABILITY_ACCOUNT_NOT_DEFINED_FOR_THE_DEFINITION_CODE'));
      set_item_result(run_stored_sig('MANUAL_EVENT_DATA_EXISTS_IN_TRIAL_BALANCE'));	
      set_item_result(run_stored_sig('AP_INVOICES_ALL'));
      set_item_result(run_stored_sig('AP_INVOICE_DISTRIBUTIONS_ALL'));
      set_item_result(run_stored_sig('APCHECKSALL_PAYMENTS_ON_THE_INVOICE'));
      set_item_result(run_stored_sig('APINVOICEPAYMENTSALL_INVOICE_PAYMENTS'));
      set_item_result(run_stored_sig('APPAYMENTHISTORYALL'));
      set_item_result(run_stored_sig('APPAYMENTHISTDISTS'));
      set_item_result(run_stored_sig('APINVOICEPREPAYSALL'));
      set_item_result(run_stored_sig('APPREPAYHISTORYALL'));
      set_item_result(run_stored_sig('APPREPAYAPPDISTS'));
      set_item_result(run_stored_sig('APACCOUNTINGEVENTSALL_INVOICE'));
      set_item_result(run_stored_sig('APAELINESALL_INVOICE'));
      set_item_result(run_stored_sig('APLIABILITYBALANCE_INVOICE'));
      set_item_result(run_stored_sig('APACCOUNTINGEVENTSALL_PAYMENTS'));
      set_item_result(run_stored_sig('APAEHEADERSALL_PAYMENTS'));
      set_item_result(run_stored_sig('APAELINESALL_PAYMENTS'));
      set_item_result(run_stored_sig('APLIABILITYBALANCE_PAYMENTS'));
      set_item_result(run_stored_sig('XLATRANSACTIONENTITIES_INVOICE'));
      set_item_result(run_stored_sig('XLAEVENTS_INVOICE'));
      set_item_result(run_stored_sig('XLAAEHEADERS_INVOICE'));
      set_item_result(run_stored_sig('XLAAELINES_INVOICE'));
      set_item_result(run_stored_sig('XLATRIALBALANCES_INVOICE'));
      set_item_result(run_stored_sig('XLATRANSACTIONENTITIES_PAYMENTS_ON_THE_INVOICE'));
      set_item_result(run_stored_sig('XLAEVENTS_PAYMENTS'));
      set_item_result(run_stored_sig('XLAAEHEADERS_PAYMENTS'));
      set_item_result(run_stored_sig('XLAAELINES_PAYMENTS'));
      set_item_result(run_stored_sig('XLADISTRIBUTIONLINKS_LIABILITY_LINES_FOR_PAYMENTS'));
      set_item_result(run_stored_sig('XLATRIALBALANCES_PAYMENTS_ON_INVOICE'));
    end_section;
  END IF;

  -- Transaction mode is Account
  IF upper(ltrim(rtrim(p_mode))) = 'ACCOUNT' AND p_liab_acc is not null
  AND p_start_date is not null AND p_end_date is not null
  AND p_ledger_id is not null AND p_tb_code is not null THEN
    start_section('Liability Account Details');
      set_item_result(run_stored_sig('DIFF_FOR_GJL_XEL'));
      set_item_result(run_stored_sig('DIFF_FOR_XTB_XEL'));
      set_item_result(run_stored_sig('DIFF_FOR_XEL_XTB'));
      set_item_result(run_stored_sig('XEL_MANUAL_ENTRIES'));
      set_item_result(run_stored_sig('MISSING_FROM_SITV'));
      set_item_result(run_stored_sig('PARTY_SITE_ID_MISSING'));
      set_item_result(run_stored_sig('Note553484.1'));
      set_item_result(run_stored_sig('NOT_TRANSFERRED_ENTRIES'));
      set_item_result(run_stored_sig('Note107066.1'));
      set_item_result(run_stored_sig('NON_PAYABLES_SOURCE_IN_GL'));
      set_item_result(run_stored_sig('IN_GL_MISSING_FROM_SLA'));
    end_section;
  END IF;

  -- Transaction mode is undo
  IF upper(ltrim(rtrim(p_mode))) = 'UNDO' AND p_liab_acc is not null THEN
    start_section('Undo Table Details');
      set_item_result(run_stored_sig('UNDO_QUERY'));
      set_item_result(run_stored_sig('UNDO_SUM'));
      set_item_result(run_stored_sig('UNTRANSFERRED_REVERSE'));
      set_item_result(run_stored_sig('UNACCOUNTED_NEW'));
    end_section;
  END IF;

  -- Transaction mode is Generic
  IF upper(ltrim(rtrim(p_mode))) = 'DATERANGE' AND p_liab_acc is not null
  AND p_start_date is not null AND p_end_date is not null
  AND p_tb_code is not null THEN
    start_section('GDF Details - Daterange');
      set_item_result(run_stored_sig('GEN_FIRST'));
      set_item_result(run_stored_sig('Note874710.1'));
      set_item_result(run_stored_sig('Note1118703.1'));
      set_item_result(run_stored_sig('GDF14637911'));
      set_item_result(run_stored_sig('Note1276043.1'));
      set_item_result(run_stored_sig('Note1061563.1'));
    end_section;
  END IF;
  
  print_out('</div>');

  -- End of report, print TOC
  l_step := '140';
  print_toc_contents;
  
  g_analyzer_elapsed := stop_timer(g_analyzer_start_time);
  get_current_time(l_analyzer_end_time);
  
  print_out('<hr><br><table width="40%"><thead><strong>Performance Data</strong></thead>');
  print_out('<tbody><tr><th>Started at:</th><td>'||to_char(g_analyzer_start_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Complete at:</th><td>'||to_char(l_analyzer_end_time,'hh24:mi:ss.ff3')||'</td></tr>');
  print_out('<tr><th>Total time:</th><td>'||format_elapsed(g_analyzer_elapsed)||'</td></tr>');
  print_out('</tbody></table>');
  
  print_out('<br><hr>');
  print_out('<strong>Still have questions or suggestions?</strong><br>');
  print_out('<a href="https://community.oracle.com/thread/3287641" target="_blank">');
  print_out('<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback for this Analyzer">');
  print_out('</a><br><span class="regtext">');
  print_out('Click the button above to ask questions about and/or provide feedback on the ' || analyzer_title ||  ' Analyzer. Share your recommendations for enhancements and help us make this Analyzer even more useful!');  
  print_out('</span>');

  print_hidden_xml;
  
  close_files; 
  
EXCEPTION WHEN others THEN
  g_retcode := 2;
  g_errbuf := 'Error in main at step '||l_step||': '||sqlerrm;
  print_log(g_errbuf);
   
END main;

-------------------------------------------
-- MAIN ENTRY POINT FOR CONCURRENT PROCESS
-- uncomment to run from concurrent program
-- edit list of variables to match MAIN
-- <package>.main_cp will be what you define program to call
-------------------------------------------
PROCEDURE main_cp(
      errbuf            OUT VARCHAR2,
      retcode           OUT VARCHAR2,
      p_mode       IN VARCHAR2 DEFAULT NULL,
      p_ledger_id  IN NUMBER DEFAULT NULL,
      p_org_ids    IN VARCHAR2 DEFAULT NULL,
      p_tb_code    IN VARCHAR2 DEFAULT NULL,
      p_start_date IN VARCHAR2 DEFAULT NULL,
      p_end_date   IN VARCHAR2 DEFAULT NULL,
      p_invoice_id IN NUMBER DEFAULT NULL,
      p_liab_acc   IN varchar2 DEFAULT NULL,
      p_max_output_rows IN NUMBER   DEFAULT 200,
      p_debug_mode      IN VARCHAR2 DEFAULT 'Y') IS
	  
BEGIN
  g_retcode := 0;
  g_errbuf := null;

  main(
      p_org_ids => p_org_ids,
      p_mode => p_mode,
      p_ledger_id => p_ledger_id,
      p_invoice_id => p_invoice_id,
      p_tb_code => p_tb_code,
      p_liab_acc => p_liab_acc,
      p_start_date => to_char(to_date(p_start_date,'RRRR/MM/DD HH24:MI:SS'),'DD-MON-RRRR'),
      p_end_date => to_char(to_date(p_end_date,'RRRR/MM/DD HH24:MI:SS'),'DD-MON-RRRR'),
      p_max_output_rows => p_max_output_rows,
      p_debug_mode => p_debug_mode);

  retcode := g_retcode;
  errbuf  := g_errbuf;
EXCEPTION WHEN OTHERS THEN
  retcode := '2';
  errbuf := 'Error in main_cp: '||sqlerrm||' : '||g_errbuf;
END main_cp;


END AP_APTB_DETECT_PKG; -- Package body
/
show errors
exit;