REM $Id: p2p_analyze.sql, 200.1 2015/15/01 23:27:42 jxmccall Exp $
REM +=========================================================================+
REM |                 Copyright (c) 2001 Oracle Corporation                   |
REM |                    Redwood Shores, California, USA                      |
REM |                         All rights reserved.                            |
REM +=========================================================================+
REM |                                                                         |
REM | FILENAME                                                                |
REM |    p2p_analyze.sql                                                          |
REM |                                                                         |
REM | DESCRIPTION                                                             |
REM |    Wrapper SQL to submit the p2p_analyzer_pkg.main procedure      |
REM |                                                                         |
REM | HISTORY                                                                 |
REM | 01-JUL-2015 JXMCCALL  Created.                                          |
REM +=========================================================================+

REM ANALYZER_BUNDLE_START 
REM 
REM COMPAT: 11i 12.0 12.1 12.2 
REM 
REM MENU_TITLE: Procure To Pay Analyzer
REM
REM MENU_START
REM
REM SQL: Run Procure To Pay Analyzer
REM FNDLOAD: Load Procure To Pay Analyzer as a Concurrent Program 
REM
REM MENU_END 
REM 
REM 
REM HELP_START  
REM 
REM  Procure To Pay Analyzer Analyzer Help [Doc ID: 2040474.1] 
REM
REM  Compatible: 11i|12.0|12.1|12.2  
REM
REM  Explanation of available options:
REM
REM    (1) Run the Procure To Pay Analyzer 
REM        o Runs p2p_analyze.sql as APPS and creates an HTML report file 
REM           on the database server (typically under /usr/tmp) 
REM
REM    (2) Install Procure To Pay Analyzer as a Concurrent Program 
REM        o Runs FNDLOAD as APPS 
REM        o Defines the analyzer as a concurrent executable/program 
REM        o Adds the analyzer to the request group: "Purchasing Reports" 
REM
REM 
REM HELP_END 
REM
REM FNDLOAD_START
REM
REM PROD_TOP: PO_TOP
REM PROG_NAME: P2PAZ
REM APP_NAME: Purchasing
REM DEF_REQ_GROUP: Purchasing Reports
REM PROG_TEMPLATE: P2PAZ.ldt
REM PROD_SHORT_NAME: PO 
REM
REM FNDLOAD_END 
REM
REM DEPENDENCIES_START 
REM 
REM p2p_analyzer.sql
REM
REM DEPENDENCIES_END
REM  
REM RUN_OPTS_START
REM
REM RUN_OPTS_END 
REM
REM OUTPUT_TYPE: UTL_FILE
REM
REM ANALYZER_BUNDLE_END



SET SERVEROUTPUT ON SIZE 1000000
SET ECHO OFF 
SET VERIFY OFF
SET DEFINE "&"

PROMPT
PROMPT Submitting Procure to Pay Analyzer.
PROMPT ===========================================================================
PROMPT Enter the org_id for the operating unit.  This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT ou NUMBER DEFAULT -1 -
       PROMPT 'Enter the org_id: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the requisition number. This parameter is optional.
PROMPT ===========================================================================
PROMPT
ACCEPT req_num CHAR PROMPT 'Enter the requisition number: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the document type.  This parameter is required.  Valid values are
PROMPT 'PO', 'PA', or 'RELEASE'.
PROMPT ===========================================================================
PROMPT
ACCEPT trx_type CHAR PROMPT 'Enter the document type: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the purchase order number. This parameter is required.
PROMPT ===========================================================================
PROMPT
ACCEPT po_num CHAR PROMPT 'Enter the purchase order number: '
PROMPT
PROMPT ===========================================================================
PROMPT If the document type is RELEASE, enter the release number otherwise
PROMPT leave blank
PROMPT ===========================================================================
PROMPT
ACCEPT rel_num NUMBER DEFAULT -1 -
       PROMPT 'Enter the release number: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the Invoice number. This parameter is optional.
PROMPT ===========================================================================
PROMPT
ACCEPT inv_num CHAR PROMPT 'Enter the invoice number: '
PROMPT
PROMPT ===========================================================================
PROMPT Enter the maximum number of rows to display on row limited queries
PROMPT ===========================================================================
PROMPT
ACCEPT max_rows NUMBER DEFAULT 50 -
       PROMPT 'Enter the maximum rows to display [50]: '
PROMPT
PROMPT

DECLARE
  l_org_id      NUMBER := &ou;
  l_req_num     VARCHAR2(20) := '&req_num';
  l_trx_type    VARCHAR2(15) := upper('&trx_type');
  l_po_num      VARCHAR2(20) := '&po_num';
  l_rel_num     NUMBER := &rel_num;
  l_invoice_num VARCHAR2(20) := '&inv_num'; 
  l_max_rows    NUMBER := &max_rows;

BEGIN

  IF l_org_id < 0 THEN
    l_org_id := null;
  END IF;

  IF l_rel_num < 0 THEN
    l_rel_num := null;
  END IF;
  
  IF l_max_rows < 0 THEN
    l_max_rows := 50;
  END IF;

  p2p_analyzer_pkg.main_single(
      p_org_id => l_org_id,
      p_req_num => l_req_num,
      p_trx_type => l_trx_type,
      p_po_num => l_po_num,
      p_release_num => l_rel_num,
      p_invoice_num => l_invoice_num,
      p_max_output_rows => l_max_rows,
      p_debug_mode => 'Y');

EXCEPTION WHEN OTHERS THEN
  dbms_output.put_line('Error encountered: '||sqlerrm);
END;
/
exit;
