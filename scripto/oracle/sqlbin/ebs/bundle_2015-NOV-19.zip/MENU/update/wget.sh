#!/bin/sh
# +-------------------
#| wget.sh for Perl Menu.pl Analyzer Bundle. 
#| 
#| Args: $1, $2 = MOS Username, password 
#| 
#| Script downloads the bundle.zip attached to docID 1939637.1 
#| 
#| Needs to find wget in the $PATH 
#| 
# +-------------------
DATE=$(date +%m-%d-%y-%H:%M);
printf "\n   ..."; 
printf "\n   $DATE Running Analyzer Bundle update \'wget\' script"; 
printf "\n   ...\n\n"; 

DATE2=$(date +%d-%b-%Y-%H_%M_%S);
BUNDLE="BUNDLE.$DATE2.zip";

LANG=C
export LANG

# SSO username and password 
# Can be edited and set here or script will prompt for them. 
printf "   Enter your My Oracle Support username (e-mail): \n"; 
printf "   Username:"; 
read SSO_USERNAME; 

# Path to wget command
WGET=`which wget`; 
$WGET -V >& /dev/null;
STATUS=$?; 

if [ "$STATUS" -ne 0 ] 
	then 
		printf "   ERROR:\'wget\' not found in the \$PATH\n    Add the location of wget to the \$PATH and try again.\n"; 
	  exit 1; 
fi 

printf "   Enter your My Oracle Support password: \n"; 
printf "   Password:"; 
stty -echo;
read SSO_PASSWORD; 
stty echo; 

#Internal vs External usage: 
BASEURL=$1; 

# Location of cookie file
COOKIE_FILE=/tmp/$$.cookies

# Log file
LOGFILE=logs/wgetlog-$DATE.log

clear; 

#Check wget 
printf "   INFO: Check permissions and existence of \'wget\' executable\n\n"; 

TRY=3;
VALID=NO;

while [ $TRY -gt 0 ] && [ $VALID == 'NO' ] 
do 
	if [ -f $WGET ] && [ -x $WGET ]

	then
		{
			printf "   INFO: $WGET exists and has execute permissions.\n\n"; 
			TRY=0; VALID=YES; 
		}
			else
		{	
				printf "   ERROR: \'$WGET\' does not exist or does not have execute permissions\n";
				printf "   Please enter a valid wget execuable location:\n"; 
				read WGET; 
				TRY=$((TRY-1)); 
				if [ "$TRY" -eq 0 ] 
				then 
					printf "   Unable to get location of \'wget\'. Exiting. \nwget is available (free) from:\n   \"http://www.gnu.org/software/wget/\" \n\n"; 
					exit 1; 
				fi
		} 
	fi
done 
printf "   **DONE: Check permissions and existence of wget executable** \n"; 

#Check Unzip 
which unzip >& /dev/null; 
UNZIP=$?; 

if [ "$UNZIP" -eq 0 ]
	then 
	printf "   INFO: UNZIP exists\n"; 
	UNZIP=Y; 
	else
	printf "   INFO: UNZIP does not exist in the \$PATH. Will not be able to automatically check zip file integrity\n\n"; 
	printf "   Press ENTER to continue:"; 
	read OK; 
	UNZIP=N; 
fi 

# Contact updates site so that we can get SSO Params for logging in
# SSO_RESPONSE=`wget --tries=2 --user-agent="Mozilla/5.0" https://$BASEURL/epmos/main/downloadattachmentprocessor?attachid=1939637.1:BUNDLE 2>&1|grep Location`
SSO_RESPONSE=`wget --tries=2 --user-agent="Mozilla/5.0" https://$BASEURL/epmos/main/downloadattachmentprocessor?attachid=1939637.1:BUNDLE 2>&1|grep Location`
STATUS="$?"; 

if [ "$STATUS" -ne 0 ]
	then 
	#failure is either: bad user/pass or fail to connect.. so try ping. if ping fails, exit, else continue and ask again for user/pass 
	ping -c 1 $BASEURL; 
	STATUS="$?"; 
	
	if [ "$STATUS" -ne 0 ]
	 then 
		printf "   ERROR: wget.sh cannot connect to $BASEURL. \n   INFO: Wget requires Internet connectivity to $BASEURL in order\n    to automatically download the bundle zip \n"; 
		printf "   Press [Enter] to Continue: "; 
		read what; 
		exit 1; 
	 fi 
fi 

# Extract request parameters for SSO
SSO_TOKEN=`echo $SSO_RESPONSE| cut -d '=' -f 2|cut -d ' ' -f 1`
SSO_SERVER=`echo $SSO_RESPONSE| cut -d ' ' -f 2|cut -d 'p' -f 1,2`
SSO_AUTH_URL=sso/auth
AUTH_DATA="ssousername=$SSO_USERNAME&password=$SSO_PASSWORD&site2pstoretoken=$SSO_TOKEN"

# The following command to authenticate uses HTTPS. This will work only if the wget in the environment
# where this script will be executed was compiled with OpenSSL. Remove the --secure-protocol option
# if wget was not compiled with OpenSSL
# Depending on the preference, the other options are --secure-protocol= auto|SSLv2|SSLv3|TLSv1
$WGET --no-check-certificate --user-agent="Mozilla/5.0" --post-data $AUTH_DATA --save-cookies=$COOKIE_FILE --keep-session-cookies https://login.oracle.com/sso/auth -O sso.out >> $LOGFILE 2>&1

#check $COOKIE_FILE 
# 4 lines = failed login 
# > 4 lines = good login 

CNT=`wc -l $COOKIE_FILE | awk '{print $1}'`; 
ATTEMPT=0; 
if [ "$CNT" -lt 5 ] 
	then 
		while [ "$CNT" -lt 5 -a "$ATTEMPT" -le 2 ]  
			do 
				ATTEMPT=$((ATTEMPT+1)); 
				SSO_PASSWORD=''; 
				printf "\n\n\n   ERROR: My Oracle Support Authentication Failed\n\n   Please enter SSO_USERNAME (My Oracle Support username)\n->" ; 
				read SSO_USERNAME; 
				printf "   Please enter SSO_PASSWORD (My Oracle Support password)\n>"; 

			 while IFS= read -r -s -n1 pass; 
				do
					if [[ -z $pass ]]; then
					 echo
					 break
					else
					 echo -n '*'; 
					 SSO_PASSWORD=${SSO_PASSWORD}$pass 
					fi
				done
				AUTH_DATA="ssousername=$SSO_USERNAME&password=$SSO_PASSWORD&site2pstoretoken=$SSO_TOKEN"
				rm $COOKIE_FILE; 
				$WGET --no-check-certificate --user-agent="Mozilla/5.0" --secure-protocol=auto --post-data $AUTH_DATA --save-cookies=$COOKIE_FILE --keep-session-cookies $SSO_SERVER$SSO_AUTH_URL -O sso.out >> $LOGFILE 2>&1
				CNT=`wc -l $COOKIE_FILE | awk '{print $1}'`;
			done 
fi  

if [ "$CNT" -gt 5 ] 
	then 
	#download 
	printf "\n   INFO: Downloading Files \n"; 

	wget --user-agent="Mozilla/5.0" --load-cookies=$COOKIE_FILE --save-cookies=$COOKIE_FILE --keep-session-cookies "https://$BASEURL/epmos/main/downloadattachmentprocessor?attachid=1939637.1:BUNDLE" -O update/$BUNDLE >> $LOGFILE 2>&1; 
	unzip -l "update/$BUNDLE" &> /dev/null;
	STATUS=$?; 
	
	else 
	printf "   ERROR: Unable to download $BUNDLE. \n   Check $LOGFILE for details. \n   Press enter to continue: "; 
	read anykey; 
	STATUS=1; 
fi 

if [ "$STATUS" != 0 ]
	then 
	printf "   ERROR: Bundle failed to download. \n   Possible causes:\n   o Bad (mistyped) user credentials\n   o No Internet Connection to My Oracle Support\n"; 
	 
	printf "   Press enter to continue: "; 
	read anykey; 
elif [ "$STATUS" == 0 ]
	then 
		printf "   INFO: New Bundle download successful \n   The latest Bundle is located at: \'MENU/update/$BUNDLE\' \n\n"; 
		printf "   Press [Enter] to continue: "; 
		read anykey; 
fi 

rm sso.out
rm "$COOKIE_FILE";
printf "\n\n   INFO: wget complete. Check $LOGFILE for details\n";
exit $STATUS; 
