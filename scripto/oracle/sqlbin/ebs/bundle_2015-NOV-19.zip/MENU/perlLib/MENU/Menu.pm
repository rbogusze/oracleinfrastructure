# $Id: Menu.pm 200.1 2014/11/20 kjharris $
# *===========================================================================+
# |  Copyright (c) 2014 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# |
# | FILENAME: Menu.pm
# |
# | 
# | PLATFORM
# |   Unix Generic
# |
# | NOTES
# |
# | HISTORY
# | 200.0 Creation (13-NOV-2014) 
# | 200.1: Added version checking subs (22-MAY-2015) 
# +===========================================================================+

# +---------------------------+
# | sub:  checkCompat 
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub checkCompat
{
	my ($file, $relVer) = @_; 
	my ($compat, $valid) = ("null", 0);

	$relVer = getRelVer() if (! $relVer);

	#in case the file passed was not a full path.. 
	if (! -e $file) 
	{
		find( sub {return unless /\.sql$|\.info$/; $file = $File::Find::name if "$file" eq "$_" }, 'analyzers/SQL' );
	}
	
	my $analyzer = analyzer MENU::Analyzer($file);
	$compat = $analyzer->getCompat();
	$compat =~ s/\s/|/g; 
	$compat =~ s/\|$//; 
	$relVer = substr $relVer, 0, 4;
	if ($relVer =~ /$compat/i)
	{
		$valid = 1; #true 
	}
	else 
	{
		$valid = 0; #false 
	}
	
	return($compat, $valid); 
}#END checkCompat 



# +---------------------------+
# | sub:  displayDirs
# +---------------------------+
# | Desc: Show the product dirs in a menu format 
# +---------------------------+
# | Args: $dir to show 
# +---------------------------+
# | Returns: nada 
# +---------------------------+
sub displayDirs 
{
	my ($dir) = @_; 
	chomp($dir); 
	my @dirs; 
	my %menu; 
	my $userSel; 
	my $ver = getBundleVer(); 

	until (1 == 2) 
	{
		@dirs = `ls -d $dir/*`;
		@dirs = sort @dirs;
		my $countDepth = $dir =~ tr/\///;
		system("clear"); 
		my $count=0; 
		printf "\n       ", RESET if $countDepth == 1;
		printf BOLD WHITE ON_BLUE "E-Business Suite Support Analyzers Main Menu (bundle ver: $ver)", RESET, "\n" if $countDepth == 1;
		printf BOLD WHITE ON_BLUE "\n   Choose a Product:", RESET, "\n\n" if $count < 1; 
		foreach my $d (@dirs) 
		{	
			$count++; 
			chomp($d); 
			$d =~ s/\/$//; 
			$menu{$count}=$d; 
			$d =~ s/\d{2}\_//g;
			$d =~ s/\_/ /g;
			$d = $+ if $d =~ /^.+\/(.+)/; 
			print "   [$count] $d \n"; 
		}
		printf "   ...\n";
		if ($countDepth == 1)
		{
			print "   [L] Bulk FNDLOAD ALL Analyzers\n   [C] Check For An Updated Analyzer Bundle\n"; 
			print "   [S] Show Installed Analyzers\n   [U] Uninstall Analyzers\n\n";
		}
		printf BOLD WHITE ON_BLUE "\n   [B]ack | [M]ain Menu | E[x]it" if $countDepth > 1;
		printf BOLD WHITE ON_BLUE "   [H]elp | E[x]it" if $countDepth == 1; 
		print BOLD WHITE ON_YELLOW "   Invalid Selection", RESET if $userSel eq 'invalid'; 
		printf "\n\n  Selection:"; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 
		
		if ($userSel =~ /^b{1}$/i && $countDepth > 1) 
		{
			$dir = $+ if $dir =~ /^(.+)\/.+/;
			displayDirs($dir);
		}
		elsif ($userSel =~ /^b{1}$/i && $countDepth < 2)
		{
			$userSel = 'invalid';
		}
		elsif ($userSel =~ /^L{1}/i) 
		{
			# bulkMenu($dir); 
			pickListMenu('bulk',$dir); 
			$count=0; 
		}
		elsif ($userSel =~ /^U{1}/i) 
		{
			uninstall(); 
		}
		elsif ( $userSel =~/^m{1}$/i ) 
		{
			displayDirs('analyzers/SQL');  
		}
		elsif ( $userSel =~/^c{1}$/i ) 
		{
			updateMenu();
		}
		elsif ( $userSel =~/^s{1}$/i ) 
		{
			pickListMenu('show'); 
		}
		elsif (exists $menu{$userSel})
		{
			my @dirs1 = `ls $menu{$userSel}`; 
			foreach (@dirs1){chomp($_);} 
			#my $join = $menu{$userSel} . '/' . $dirs1[0]; 
			if ( -d ($menu{$userSel} . '/' . $dirs1[0]) ) 
			{
				displayDirs($menu{$userSel}); 
			}
			else 
			{ 
				displayFiles($menu{$userSel}); 
			} 
		}
		
		elsif ($userSel =~ /^H{1}/i) 
		{
			system ("clear"); 
			print "\n"; 
			print BOLD WHITE ON_BLUE "   Main Menu Help", RESET, "\n"; 
				print qq (
  o Options 1-5 displays a sub-menu of available Analyzers for that Product Family
  o From the sub-menu, individual Analyzers can be selected, then *executed or *loaded as
    Concurrent Programs 
      *Not all Analyzers have run and load options 
  o [L]oad 
    -Loads all the Analyzers in Bulk mode as Concurrent Programs 
  o [C]heck For An Updated Analyzer Bundle 
    -Starts the update process to update to the latest Analyzer Bundle 
  o [S]how Installed Analyzers 
    -Shows Analyzers currently installed as Current Programs 
  o [U]ninstall Analyzers 
    -Starts the Uninstall process (remove Concurrent Programs & Packages) 

  Press [Enter] to continue:); 
	<STDIN>; 
		}
		else
		{
			$userSel='invalid' unless $userSel =~ /^L{1}/i; 
			$count=0; 
		}
	}
}
	
# +---------------------------+
# | sub: displayFiles
# +---------------------------+
# | Desc: shows the analyzer files in a given 
# | dir 
# +---------------------------+
# | Args: $dir  
# +---------------------------+
# | Returns: nada 
# +---------------------------+
sub displayFiles
	{
		my ($dir) = @_; 
		my @files = `ls $dir`; 
		my %files; 
		my $userSel; 
		my %menu; 
		my $valid; 
		my $relVer = getRelVer();
		my $count = 0;
	#filter out any files which aren't analyzer files  
	my $elemCnt = scalar(@files); 
	for (my $i=0; $i != $elemCnt; $i++)
	{
		my $check = shift @files;  
		my $title; 
		chomp($check); 
		chomp($dir); 
		open my $fh, '<', "$dir\/$check" or die "    ERROR: Could not open $dir\/$check: $!";
		my @currFile = <$fh>; 
		close $fh; 
		($title) = grep(/MENU_TITLE:\s+(.+)$/i, @currFile); 
		$title = $+ if $title =~ /MENU_TITLE:\s+(.+)$/i; 
		undef @currFile; 
		my ($compat, $valid) = checkCompat($check, $relVer); 
		 
		if (defined $title && $valid == 1)
		{
			$count++; 
			#split title into ~60 char chunks to forego line wraps 
			if (length($title) > 70) 
			{
				my @splitUp = split(/\s/, $title); 
				my $line1 = ''; my $line2;
				$line1 .= (shift@splitUp) . ' ' until length($line1) > 60 ; 
				$line2 .= $_ . ' ' foreach (@splitUp); 
				$title = $line1 . "\n       " . $line2;
			}
			$menu{$count}->{'TITLE'} = $title . "\n       " . '[' . $check . ']'; 
			$menu{$count}->{'FILE'} = $check; 
			#push (@files, $title . "\n       " . '[' . $check . ']'); 
		}
	}

	my $ID = 1; 
	my ($height, $width) = split(' ', `stty size`); 
	my $pageSize = ($height - 8)/3; 
	my $currPage = 1; 
	my $maxPage = (ceil(scalar(keys %menu)/$pageSize));
	my $debug = scalar(keys %menu)/$pageSize; 

	until (1 == 2) 
	{
		system("clear"); 
		print BOLD WHITE ON_BLUE "\n   Select a Number For Available Options", RESET;
		print BOLD WHITE ON_GREEN " [Page $currPage of $maxPage]",RESET if $maxPage > 1;
		print "\n"; 
		# for ($ID; $ID <= ($pageSize * $currPage); $ID++)
		for ($ID; $ID <= ($pageSize * $currPage); $ID++)
		{
			next if length($menu{$ID}->{'TITLE'}) < 5;
			print "   [$ID] $menu{$ID}->{'TITLE'}\n\n";
		}
		print "   ...\n   [L] Bulk FNDLOAD Analyzers Listed in This Menu\n"; 
		# my $countDepth = $dir =~ tr/\///;
		printf BOLD WHITE ON_BLUE "\n   [B]ack | [M]ain Menu | E[x]it"; 
		print BOLD WHITE ON_GREEN "| [N]ext Page", RESET if $currPage < $maxPage;
		print BOLD WHITE ON_GREEN " | [P]rev Page", RESET if $currPage < $maxPage && $currPage > 1;
		print BOLD WHITE ON_GREEN "| [P]rev Page", RESET if $currPage == $maxPage && $currPage > 1;
		print BOLD WHITE ON_YELLOW "   Invalid Selection", RESET if $userSel eq 'invalid';
		print "\n\n   Selection:"; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i;
		
		if ( $userSel =~ /^b{1}$/i ) 
		{
			$dir = $+ if $dir =~ /(^.+)\/.+/;
			displayDirs($dir); 
		}
		elsif ( $userSel =~ /^N{1}/i ) 
		{
			if ($currPage == $maxPage) 
			{
				$userSel = 'invalid';
				$ID = ($ID - $pageSize);
			}
			else
			{
				$ID = floor($pageSize * $currPage + 1);
				$currPage++;
			}
		}
		elsif ( $userSel =~ /^P{1}/i ) 
		{
			if ($currPage == 1) 
			{
				$userSel = 'invalid';
				$ID = 0; 
			}
			else 
			{
				$ID = ceil($ID - ($pageSize * 2));
				$currPage = ($currPage -1);
			} 
		}
		elsif ( $userSel =~ /^L{1}/i ) 
		{
			pickListMenu('bulk',$dir);
			$ID = 0; 
		}
		elsif ( $userSel =~/^m{1}$/i )
		{
			displayDirs('analyzers/SQL');
		}
		elsif (exists $menu{$userSel})
		{
			#my $file = $+ if $menu{$userSel} =~ /\[(.+\.sql)\]/; 
			fileMenu($dir, $menu{$userSel}->{'FILE'});
		}
		else
		{
			$userSel='invalid'; 
			$count=0; 
		}
	}
}
	
# +---------------------------+
# | sub:  fileMenu
# +---------------------------+
# | Desc: shows the menu header from an 
# | analyzer file 
# +---------------------------+
# | Args: $dir and file 
# +---------------------------+
# | Returns: nada 
# +---------------------------+

sub fileMenu
{
	my ($dir, $file) = @_; 
	chomp($dir); 
	chomp($file); 
	my $analyzer = analyzer MENU::Analyzer($file);
	my $title = $analyzer->getTitle();
	my $menu = $analyzer->getMenu();
	my $runOpts = $analyzer->getRunOpts();
	my $fload = $analyzer->getFNDLOADOpts();
	my $help = $analyzer->getHelp();
	my $outputType = $analyzer->getOutputType();
	my $userSel;
	my %menu;
	my $invSel = 0;

	until ( 1 == 2 )
		{
		my $count = 0;
		foreach (@$menu) 
		{	
			$count++;
			$menu{$count}=$_;
			if ($count == 1)
			{
				system("clear");
				print "\n";
				print BOLD WHITE ON_BLUE "   $title",RESET;
				print "\n\n"; 
				print BOLD WHITE ON_BLUE, "  Options for: $file",RESET;
				print "\n";
			}
			print "\n"; 
			print "   [$count]$_\n";
		}

		print BOLD WHITE ON_BLUE "\n   [B]ack | [M]ain Menu | [H]elp | E[x]it ";
		print BOLD WHITE ON_YELLOW "   Invalid Selection", RESET if $invSel != 0; 
		#print "\n   ...\n\n   Selection:";
		print "\n   \n   Selection:";
		$invSel = 0;
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 
		
		if ( $userSel =~ /^b{1}$/i )
		{
			displayFiles($dir);
		}
		elsif ( $userSel =~ /^h{1}$/i )
		{
			system("clear"); 
			print "\n"; 
			foreach (@$help)
			{
				print "   $_\n";
			}
			printf "\n\n    Press [Enter] to Continue: ";
			<STDIN>;
		}
		elsif ( $userSel =~/^m{1}$/i ) 
		{
			displayDirs('analyzers/SQL');  
		}
		
		elsif (exists $menu{$userSel})
		{
			#printf "user selected $menu{$userSel} \n"; 
			if ( $menu{$userSel} =~ /SQL/ )
			{
				printf "   INFO: Calling runSQL() \n"; 
				runSQL($dir, $file, $outputType, $runOpts);
			}
			elsif ( $menu{$userSel} =~ /FNDLOAD/ ) 
			{
				#Run Load.pl 
				printf "   INFO: Calling floadSingle() \n";
				floadSingle($file, $fload); 
			}
		}
	else
	{
		$invSel = 1; 
		#repeat the menu again 
		#need to write a loop around the line 146 foreach menu to redisplay it 
	}
	}#end until loop 
}# end fileMenu sub 
#END fileMenu 

# +------------
# | sub trim
# | 
# + ------------
sub trim
{
	my ($v) = @_; 
	chomp($v); 
	$v =~ s/^REM//ig; 
	$v =~ s/^\s+//g; 
	$v =~ s/\s+$//g;
	return $v; 
}

# +---------------------------+
# | sub:  bulkMenu
# +---------------------------+
# | Desc: display all the analyzers that can be 
# | loaded from a given directory 
# +---------------------------+
# | Args: $dir 
# +---------------------------+
# | Returns: nada 
# +---------------------------+
sub bulkMenu
{
	my ($dir)=@_; 
	my $validAnalyzers = getAnalyzersForBulk($dir); 
	my $invSel; 
	my $count = 0;
	my $userSelBulkMenu; 
	
	use Data::Dumper; 
	print Dumper (@$validAnalyzers); exit; 
	until ( my $exitNow eq 'Y' )
	{
		$count = 0;
		foreach (@$validAnalyzers) 
		{
			my $analyzer = analyzer MENU::Analyzer($_); 
			my $title = $analyzer->getTitle; 
			my $reqGrp = $analyzer->getReqGroup; 
			my $file = $+ if $_ =~ /.+\/(.+)$/; 
			$count++; 
			system("clear") if $count == 1; 
			print "\n"; 
			print BOLD WHITE ON_BLUE "                   Bulk Load Menu                \n" if $count ==1; 
			print "   The following are selected for bulk loading: \n\n" if $count == 1;  
			print BOLD WHITE ON_BLUE "   $title", RESET; 
			print "\n   File: \"$file\"\n   Request Group: \"$reqGrp\"\n\n"; 
		}
		printf BOLD WHITE ON_BLUE "\n   [L]oad | [B]ack | [H]elp | E[x]it"; 
		print BOLD WHITE ON_YELLOW "   Invalid Selection", RESET if $invSel != 0;
		printf "\n\n   Selection:"; 
		$invSel = 0; 
		chomp($userSelBulkMenu = <STDIN>);
		exitLog() if $userSelBulkMenu =~ /^x{1}$/i; 
		
		if ( $userSelBulkMenu =~ /b/i )
		{	
			$exitNow='Y'; 
			return; 
		}
		#printf "user selected $menu{$userSelBulkMenu} \n"; 
		elsif ( $userSelBulkMenu =~ /^l{1}$/i )
		{
			floadBulk($validAnalyzers); 
			print "   INFO: Done with Bulk Load. Press [Enter] to Continue:"; 
			<STDIN>; 
			return; 
		}
		elsif ( $userSelBulkMenu =~ /^h{1}$/i ) 
		{
			printf BOLD WHITE ON_BLUE "\n Bulk Load Menu Help", RESET;  
			print qq(
 

   Press [Enter] to continue:); 
			<STDIN>;
		}
		elsif ( $userSelBulkMenu =~ /^x{1}$/i )
		{
			exitLog(); 
		} 
		else	
		{
			$invSel = 1; 
			#repeat the menu again 
			#need to write a loop around the line 146 foreach menu to redisplay it 
		}
	}#end until loop 
	
}
#end bulkMenu 


# +---------------------------
# | 
# | mode is either "s" or "b" for single or bulk 
# | in bulk, we are passing the full path and filename together from the basedir
# | in single, we are passing dir and file separately. 
# +---------------------------
sub runDepen
{
	my ($file) = @_; 
	my $cs = $main::connStrg->getConnStrg(); 
	#1 Run dependencies which, so far, never take params 
	my $analyzer = analyzer MENU::Analyzer($file);
	my ($depen) = $analyzer->getDeps(); 

	my $status = 0; 
		
	if (scalar @$depen > 0) 
	{
		foreach my $depFile ( @$depen )
		{
			# print "571: $depFile \n"; 
			$depFile=trim($depFile);
			# print "573: $depFile \n"; exit; 
			#INSERT Version checking here 
			# Some dependencies may not be packages.. only object_types of packages 
			# can be version-checked in the database. 
			# 
			# check object type 
			
			my $isPkg = checkObjectCreates($depFile); 
			#if object_type == package, version check. 
			my $load; 
			if (uc($isPkg) eq 'PACKAGE') 
			{
				#what if this comes back != 0? 
				$load = versCheckDBToFile($depFile); 
			}
			else 
			{
				$load = 0; 
			}
			
			if ($load == 2) 
			{
				#The dependency file could not be version checked in the 
				#DB 
				my $cont; 
				until ( $cont =~ /^y|^n/i)
				{
					print qq( 
   ERROR: Unable to version check $depFile
   Continue to load this Analyzer Dependency?  
   
   INFO: By selecting 'N', the associated Concurrent Program 
    will not be loaded. 

   [Y|N]: );
				$cont = <STDIN>; 
					chomp ($cont); 
				}
				if ($cont =~ /^y/i ) 
				{
					$load = 0; 
				}
				elsif ($cont =~ /^n/i ) 
				{
					next; 
					$status += 1; 
				}
			}
			elsif ($load == 1)
			{
				#version in DB is already higher or equal so don't load it. 
				print "   INFO: A equal or higher version of dependency file\, ", basename($file),"\, is already loaded.\n" ; 
			}
			elsif ($load == 0) 
			{
				my $runCmd = "sqlplus -l -s $cs \@" . $depFile; 
				#$runCmd .= $depFile;
				prnt2LogSTDOUT("   INFO: About to run dependency..\n   Dependency: \"$depFile\"\n   Analyzer:$file\n\n");
				my $stat = system($runCmd); 
				prnt2LogSTDOUT("   INFO: Dependency File exited with status: $stat \n");
				
				if ( $stat != 0 )
				{
					prnt2LogSTDOUT("   ERROR: Dependency file failed to run:\n    $depFile \n    The Concurrent Program for $file may not work as expected. \n\n");
					print "   Continue? [Y|N]: ";
					my $cont = <STDIN>; 
					chomp ($cont); 
					if ( $cont =~ /^n/i ) 
					{
						$status += 1; 
					}
				}
			}
		}
		print "   INFO: Done with all dependencies. \n\n "; 
	}
	else 
	{
		print "   INFO: Analyzer: ", basename($file), " has no dependencies. \n"; 
	}
	
	return ($status); 
	
}
#End runDepen

# +---------------------------+
# | sub: verChkBeforeLoad
# +---------------------------+
# | Desc: version checks an analyzer before
# | it's loaded as a conc program
# +---------------------------+
# | Args: main analyzer file to be loaded
# +---------------------------+
# | Returns: 
# | 
# | 0 = Load 
# | 1 = Don't load (version verified as already higher)
# | 2 = Unknown, couldn't validate version 
# +---------------------------+
sub verChkBeforeLoad
{
	my ($file) = @_; 
	my $execMethod; 
	my $analyzer = analyzer MENU::Analyzer($file);
	my $progTemplate = 'analyzers/template/' . $analyzer->getProgTemplate;
	my $prodTop = $analyzer->getProdTop . '/sql/';
	# check execution type Q or I from the prog LDT 
	# Q = SQL (PROD_TOP/sql/file.sql), I = plsql pkg (db package)  
	open (my $fh, '<', $progTemplate ) || die "verChkBeforeLoad(): Cannot open $progTemplate $! \n"; 
	my @a=<$fh>;
	close $fh; 
	my $check; 
	if (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a))
	{
		#file execution
		$check = versionCheckFiles($file); 
		$execMethod = 'Q'; 
		#what's returned: 0,1,2 (load, don't load, unable to version check) 
	}
	elsif (grep(/EXECUTION_METHOD_CODE\s\=\s\"I\"/, @a))
	{
		#DB pkg execution
		$check = versCheckDBToFile($file); 
		$execMethod = 'I'; 
		#what's returned: 0,1,2 (load, don't load, unable to version check) 
	}
	elsif (grep(/^\s*create\s.*package\sbody|table|view|function|package/, @a))
	{
		#catch-all for packages which do not have menu headers 
		$check = versCheckDBToFile($file);
	}
	else 
	{
		$check = 2;
	}
	
	return($check, $execMethod, $prodTop);

}#end verChkBeforeLoad


# +---------------------------+
# | sub:  checkObjectCreates
# +---------------------------+
# | Desc: checks if a SQL creates a package 
# +---------------------------+
# | Args: a SQL file 
# +---------------------------+
# | Returns: W = sql wrapper 
# | S = anonymous SQL block file 
# | <type> = object creation script 
# +---------------------------+
sub checkObjectCreates
{
	my ($file) = @_; 
	my @fileArr; 
	my $objType; 
	open (my $fh, '<', $file ) || die "checkObjectCreates(): Cannot open $file $! \n"; 
	
	@fileArr = <$fh>; 
	
	if ($#fileArr < 300)
	{
		#wrapper SQL  
		# print "wrapper\n"; 
		return 'W';  
	}
	else 
	{
		foreach my $line (@fileArr)
		{
			$objType = $+ if ($line =~ /^\s*create\s.*?(package\sbody|table|view|function|package)/i || $line =~ /create\s*?or\s*?replace\s.*?(package\sbody|table|view|function|package)/i);
			return ($objType) if defined $objType; 
		}
	} 
		
	# while (my $line = <$fh>)
	# {
		# $objType = $+ if ($line =~ /^\s*create\s.*?(package\sbody|table|view|function|package)/i || $line =~ /create\s*?or\s*?replace\s.*?(package\sbody|table|view|function|package)/i); 
		# print "debug 584: $objType, $line \n";
		# last if defined $objType; 
	# } 
	# close $fh; 

	return 'S' if (! defined $objType);  
	
	
	# if ($objType =~ /package/i)
	# {
		# return('Y'); 
	# }
	# else
	# {
		# return('N'); 
	# }
	
}

# +---------------------------+
# | sub:  runSQL
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub runSQL
{
	my ($dir, $file, $outputType, $runOptsRef, $depenRef) = @_; 
	my $scriptArgs; 
	my $ans; 
	my $cs = $main::connStrg->getConnStrg(); 
	my $runCmd = "sqlplus -l -s $cs \@"; 
	#@$runOptsRef @$depenRef 
	my $relVer = getRelVer();
	my ($compat, $valid) = checkCompat($file,$relVer); 
	#add a trailing slash so we can append the file to the dir 
	if ($dir !~ /.+\/$/) 
	{
		$dir.='/'; 
	}
	if ($valid != 1)
	{
		printf "   ERROR: This Analyzer is not compatible with your E-Business Suite Release ($relVer) \n   Compatible Releases: $compat\n\n   Press [Enter] to Continue: "; 
		my $wait = <STDIN>; 
		return 1; 
	}

	#verChkBeforeLoad checks for the execution type 
	# of the ccp and from that can deduce what 
	# the file is (SQL (anon. block) or plsql pkg) 
	#if check == 0, version is higher.. run 
	# check == 1 || 2 , version is lower or version was 
	# not able to be checked.. prompt what to do 
	
	my ($check, $execMethod, $prodTop) = verChkBeforeLoad($dir . $file);
	
	if ($check == 1 && $execMethod eq 'Q') 
	{
		print "   INFO: The version of this file is higher in the $prodTop than in the bundle. It is recommended to exit the Menu and run the file from $prodTop. \n\n   Run the older bundle file now?\n";
		until ($ans =~ /^y|^n/i)
		{
			print "[Y|N]:"; 
			chomp($ans = <STDIN>);
		}
		if ($ans =~ /^y/i) 
		{
			$check = 0; 
		}
		else
		{
			print "   INFO: User decided to not proceed with the running of $file \n\n   Press [Enter] to continue:"; 
			<STDIN>; 
			return(); 
		}
	}
	elsif ($check == 1 && $execMethod eq 'I') 
	{
		print "   INFO: The version of this file is higher in the database than in the bundle. It is recommended to exit the Menu and run the package from the database. \n\n   Run the older bundle file now?\n";
		until ($ans =~ /^y|^n/i)
		{
			print "   [Y|N]:"; 
			chomp($ans = <STDIN>);
		}
		if ($ans =~ /^y/i) 
		{
			$check = 0; 
		}
		else
		{
			print "   INFO: User decided to not proceed with the running of $file \n\n   Press [Enter] to continue:"; 
			<STDIN>;
			return(); 
		}
	}
	# elsif ($check == 3) # a return of 3 means the SQL is a wrapper 
	# {
		# print "   INFO: Unable to version check file: \n   $file\n   Do you wish to run the file without version checking?\n";
		# until ($ans =~ /^y|^n/i)
		# {
			# print "   [Y|N]:"; 
			# chomp($ans = <STDIN>);
		# }
		# if ($ans =~ /^y/i) 
		# {
			# $check = 0; 
		# }
		# else
		# {
			# print "   INFO: User decided to not proceed with the running of $file \n\n   Press [Enter] to continue:"; 
			# <STDIN>; 
			# return(); 
		# }
	# }

#we should have already kicked out if the check was not reconciled by now 
# but just in case.. 
return if ($check != 3 && $check != 0); 
	
	#always run runDepen, it will figure out if there's no dependencies.. 
	my $checkDepens = runDepen($dir . $file); 
	
	if ($checkDepens > 0)
	{
		print "   runSQL(): Analyzer dependencies for $file failed. \n   Running of $file will not succeed, thus exiting. \n   Press [Enter] to Continue:"; 
		<STDIN>; 
		return(); 
	}
	
	if (scalar @$runOptsRef > 0) 
	{
		$runCmd = "sqlplus -l -s $cs \@";
		foreach (@$runOptsRef)
		{
			my $line = $_;
			if ( $line =~ /ARG:/)
			{
				my $default = $+ if $line =~ /DEFAULT:(.+)$/;
				$default=trim($default);
				my $prompt = $+ if $line =~ /.+?:.+?:(.+)\s?DEFAULT/;
				#get user input
				printf "$prompt (Enter for default: $default): " if length $default > 0;
				printf "$prompt: " if length $default < 1;
				my $userInput; 
				chomp($userInput=<STDIN>);  
				$userInput = $default if length($userInput) == 0 && length $default > 0;
				$scriptArgs .= ' ' . $userInput;
			}
			$scriptArgs = trim($scriptArgs);
			#print "DEBUG 458: scriptArgs: $scriptArgs \$dir: $dir\n";
		}
		$runCmd = $runCmd . $dir . $file . ' ' . $scriptArgs;
	}
	else 
	{
		$runCmd = "sqlplus -l -s $cs \@"; 
		$runCmd .= $dir . $file; 
	}

	my $prntCmd;
	if ( $outputType =~ /STDOUT/i ) 
	{
		#check for args / process args RUN_OPTS_START 
		my $reportName = $+ if $file =~ /(\w+)\.\w?/; 
		$reportName.="_" . $ENV{CONTEXT_NAME} . "_" . (strftime "%Y-%m-%d_%H%M%S", localtime) . ".html"; 
		 #printf "DEBUG: Running $file using command: $runCmd\n"; 
		
		$prntCmd = $runCmd; 
		$prntCmd =~ s/(?<=\s).+?\/.+?(?=\s\@)/\*\*\*\*\/\*\*\*\*/; 
		prnt2LogSTDOUT("\n   INFO: runSQL(): Running: $prntCmd\n\n"); 
		
		my $status = system("$runCmd 2>&1 | tee output/$reportName");  
		prnt2LogSTDOUT("\n   INFO: Analyzer exited with status: $status \n\n   INFO: Done Running $file \n\n"); 
		#system("mv $reportName ./output/") if -f $reportName; 
		prnt2Log ("Report File: output/$reportName"); 
		printf BOLD WHITE ON_BLUE "   Report File: output/$reportName"; 
		printf "\n\n   Press [Enter] to Continue:"; 
		<STDIN>; 
	}
	elsif ( $outputType =~ /^UTL/i )
	{
		$prntCmd = $runCmd;
		$prntCmd =~ s/(?<=\s).+?\/.+?(?=\s\@)/\*\*\*\*\/\*\*\*\*/; 
		prnt2Log("\nINFO: runSQL(): Running: $prntCmd\n");  
		my $status = system($runCmd);  
		prnt2LogSTDOUT("\n   INFO: Analyzer exited with status: $status \n"); 
		printf "\n   Press [Enter] to Continue:"; 
		<STDIN>; 
	}
}

##### 
# Version Checking Subs 
##### 
# +---------------------------+
# | sub: compVersions
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub compVersions
{
	my ($newFile, $existingFile) = @_; 
	
	#kick rocks if nothing passed in 
	return 1 if ! $newFile && ! $existingFile; 
	
	my $majorNew = $+ if $newFile =~ /(\d+?)\.\d+?/; 
	my $minorNew = $+ if $newFile =~ /\d+?\.(\d+)$/; 
	my $majorExisting = $+ if $existingFile =~ /(\d+?)\.\d+?/;
	my $minorExisting = $+ if $existingFile =~ /\d+?\.(\d+)$/;

	if ($majorNew > $majorExisting) 
		{
			#file is higher/newer 
			return(0, 'replace'); 
		}
	elsif ($minorNew > $minorExisting && $majorNew == $majorExisting)
		{
				return(0, 'replace');
		}
	elsif ($minorNew == $minorExisting && $majorNew == $majorExisting)
		{
			return(0, 'same');
		}
	else
		{
			return(0, 'existing_higher'); 
		}
		
	#we did not return yet, so we were unable to compare versions 
	return(1);
}

# +---------------------------+
# | sub: versCheckDBToFile
# +---------------------------+
# | Desc: takes a package-creation SQL file and 
# | checks to see if the package in the DB is > == < the file 
# +---------------------------+
# | Args: full path to SQL file which creates a package. 
# +---------------------------+
# | Returns: 
# | "0" = load
# | "1" = don't load 
# | "2" = unable to compare (versions not found.. etc..)  
# | "3" = No compare .. SQL file 
# +---------------------------+
sub versCheckDBToFile
{
	my ($file) = @_; 
	my $isPkg = checkObjectCreates($file);  
	my ($status, $inst); 
	
	if (uc($isPkg) eq 'PACKAGE')
	{
		($status, $inst) = getFilePkgVer($file, 1); 
	# --If 1 fails, no point in trying anything else. 
		if ($status == 0) 
		{
			my $dbVer; 
			#we have a file version 'VER', package name 'NAME', db object_name, 
			($status, $dbVer) = getDBPkgVer($$inst{$file}->{'NAME'});
			if ($status == 0) 
			{
				my $checkResult; 
				($status, $checkResult) = compVersions($$inst{$file}->{'VER'},$dbVer); 
				
				return(0) if $checkResult eq 'replace';
				return(1) if $checkResult eq 'existing_higher';
				return(1) if $checkResult eq 'same';
			}
			elsif ($status == 2) 
			{
				#the package does not exist; 
				return (0); 
			}
			else 
			{
				print "   ERROR: Failed to get version from database for: $$inst{$file}->{'NAME'} \n"; 
				return(2); 
			}
		}
		else 
		{
			print "   ERROR: Failed to get version from file: $file \n";
			return(2); 
		}
	}#end checking for a package ver 
	else 
	{
		#if isPkg eq 'W' (wrapper) or 'S' (anon sql block) then we should tell
		#the calling sub there was nothing to compare but that was expected. 
		return(3); 
	}
	
}#end versCheckDBToFile 


# +---------------------------+
# | sub:  getFilePkgVer
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: $file = file to get version from 
# | $mode = 1 if we need to check for a package body specifically 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub getFilePkgVer 
{
	my ($file, $mode) = @_; 
	my %instAnalyzers; 
	my $cs = $main::connStrg->getConnStrg();
	my $appsUser = $+ if $cs =~ /(\w+?)\//; 
	open (my $fh, '<', $file ) || die "Cannot open $file : $! \n";
	
	if ($mode == 1)
	{
		while (my $line = <$fh>)
		{
			$line = clean($line);
			next unless $line =~ /^\s*create\s.*?package\sbody/i;
			until ((defined $objectName && defined $ver) || eof($fh))
			{
				$ver = $+ if $line =~ /(\d{1,3}\.\d{1,3})/; 
				$objectName = $+ if $line =~ /^\s*create\s.*?package\sbody\s*\w*\.*(\w*)/i;
				$line = <$fh>; 
			}
			$instAnalyzers{$file}->{'FILE'}=$file; #file where the create statement was found 
			$instAnalyzers{$file}->{'NAME'}=uc($objectName);
			$instAnalyzers{$file}->{'VER'}=$ver if defined $ver;
		}
	}
	else 
	{
		while (my $line = <$fh>)
		{
			$line = clean($line); 
			# $Id: AP_PCLOSE_DETECT_PKG.sql,v 120.14 2015/02/23 19:48:10 alumpe Exp $ 
			$line = <$fh> until eof($fh) || $line =~ /create/i || $line =~ /\$Id:|\$Header:/;
			if ($line =~ /^\s*create\s.*(package\sbody|table|view|function|package)/i)
			{
				my ($objectName, $objectType);
				$objectType = $+;
				if (! defined $objectType)
				{
					for (0..1)
					{
						$line .= <$fh>;
						$line = clean($line);
					} 
					$line =~ /^\s*create\s.*(package\sbody|table|view|function|package)/i; 
					$objectType = $+;
					if (! defined $objectType)
					{
						warn "   getFilePkgVer(): WARNING: The Database Object Created by the following file could not be determined:\n   $file \n   ACTION: Manually open/view the file to determine if there are \n   database objects created, then drop those objects manually.\n"; 
						print "   Press [Enter] to Continue:";
						<STDIN>; 
					}
				}
				#keep appending the next line until we have the object name.
				until (defined $objectName && defined $objectType)
					{
						$line =~ s/\s{2,}/ /g;
						$line =~ s/apps\.//ig; 
						$objectName = $+ if $line =~ /$objectType\s(\w*)/i;
						$line .= <$fh>;
						$line = clean($line);
						last if eof($fh); 
					}
				
				if (defined $objectName && defined $objectType) 
				{
					next if $objectType eq 'PACKAGE BODY'; 
					$objectName=uc($objectName); 
					my $statement = "drop " . $objectType . " $appsUser\." . $objectName . ';'; 
					
					my $dup = 'N'; 
					for my $ids (keys %instAnalyzers)
					{
						$dup = 'Y' if ($instAnalyzers{$ids}->{'NAME'} eq $objectName && $instAnalyzers{$ids}->{'TYPE'} eq $objectType); 
					}
					if ($dup ne 'Y') 
					{
				
						$instAnalyzers{$file}->{'FILE'}=$file; #file where the create statement was found 
						$instAnalyzers{$file}->{'DROP'}=$statement;
						$instAnalyzers{$file}->{'NAME'}=$objectName;
						$instAnalyzers{$file}->{'TYPE'}=$objectType;
					}
				}
			}
			if ($line =~ /\$Id:|\$Header:/) 
			{
				my $ver = $+ if $line =~ /(\d{1,3}\.\d{1,3})/; 
				$instAnalyzers{$file}->{'VER'}=$ver if defined $ver;
			}
		}
	}#end else 
	close $fh; 

	if ($instAnalyzers{$file}->{'VER'} =~ /\d{3}\.\d{1,3}/)
	{
		return(0, \%instAnalyzers); 
	}
	else  
	{
		return 1; 
	}
}

# +---------------------------+
# | sub: getDBPkgVer 
# +---------------------------+
# | Desc: 
# +---------------------------+	
# | Args: 
# +---------------------------+
# | Returns: 0 = "found version" 
# | 1 = "
# | 2 = " 
# +---------------------------+
sub getDBPkgVer
{
	my ($pkg) = @_; 
	my $cs = $main::connStrg->getConnStrg();
	my $ver; 
	#create the select and put it into a tmp file 
	open (my $fh, '>', 'sql/getHeader.sql' ) || die "Cannot open \'sql/getHeader.sql\' $! \n"; 
	
	$pkg=uc($pkg); 
	
	print $fh qq(
SET HEAD OFF; 
SET VERIFY OFF; 
SPOOL 'sql/header.lst'; 
select text from user_source where name = \'$pkg\' and line < 5; 
SPOOL OFF; 
exit; 
	); 
	close $fh; 

	my $status; 
	if (-f 'sql/getHeader.sql') 
	{
		$status = system("sqlplus -l -s $cs \@sql/getHeader.sql > /dev/null 2>&1"); 
		print "ERROR: getDBPkgVer(): SQL*PLUS connection failed. Unable to compare package versions. Press [Enter] to continue:" if $status != 0; 
		<STDIN> if $status != 0; 
	
		open (my $fh1, '<', 'sql/header.lst' ) || die "Cannot open $file $! \n"; 
		my @spool = <$fh1>; 
		close $fh1; 
	
		#if the spool file contains less than 10 lines
		#we did not get any rows selected. 
		#we have to do this because if the DB lang is not english
		#we cannot depend on the message being "no rows selected". 
		return(2) if $#spool < 10; 
	
	for my $i (0..$#spool) 
	{
		next unless ($spool[$i] =~ /^PACKAGE\sBODY/); 
		until ($i == $#spool || $ver =~ /\d{1,3}\.\d{1,3}/) 
		{
			$ver = $+ if $spool[$i] =~ /\$Id\:.+?(\d{1,3}\.\d{1,3})/; 
			$ver = $+ if $spool[$i] =~ /\$Header\:.+?(\d{1,3}\.\d{1,3})/; 
			$i++; 
		}

		last if $ver =~ /\d{1,3}\.\d{1,3}/; 
	}
	
		if ($ver =~ /\d{1,3}\.\d{1,3}/)
		{
			return(0, $ver);
		} 
		else 
		{
			return(1);
		}  

	}
}

# +---------------------------+
# | sub: versionCheckFiles
# +---------------------------+
# | Desc:  
# +---------------------------+
# | Args: full path to analyzer SQL file 
# | 
# +---------------------------+
# | Returns: 
# | "0" = copy the file, version is higher than PROD_TOP/sql 
# | "1" = don't copy, the version is lower (or equal) than PROD_TOP/sql  
# | "2" = unable to compare (versions not found.. etc..) 
# +---------------------------+
sub versionCheckFiles
{
	my ($file) = @_; 
	
	#open the $file passed, check for a version 
	#get the line "REM PROD_TOP: " to check 
	#if the file exists in PROD_TOP/sql and if so, check the version 
	
	open (my $fh, '<', $file ) || die "versionCheckFiles(): Cannot open $file $! \n";
	my @a = <$fh>;
	close $fh;
	
	my ($prodTop) = grep(/PROD_TOP:/, @a);
	$prodTop =~ s/^REM\s+?PROD_TOP:\s*//g;
	chomp($prodTop);
	
	my $newVer; 
	($newVer) = grep(/\$Id:/,@a); 
	($newVer) = grep(/\$Header:/,@a) if ! $newVer; 
	$newVer = $+ if $newVer =~ /(\d{1,3}\.\d{1,3})/; 
	my $fp = $ENV{$prodTop} . '/sql/' . basename($file);
	
	#if the file does not exist, return now (advise the calling sub to copy the file) 
	return (0) if ! -f $fp; 
	
	undef @a; 
	open (my $fh1, '<', $fp ) || die "versionCheckFiles(): Cannot open $file $! \n";
	@a = <$fh1>;
	close $fh1; 
	
	my $existingVer; 
	($existingVer) = grep(/\$Id:/,@a); 
	($existingVer) = grep(/\$Header:/,@a) if ! $existingVer; 
	$existingVer = $+ if $existingVer =~ /(\d{1,3}\.\d{1,3})/;
	
	my ($status, $action) = compVersions($newVer, $existingVer);

	if ($status == 0) 
	{
		#print "action: $action \n"; 
		return(0) if $action eq 'replace' || $action eq 'same'; 
		return(1) if $action eq 'existing_higher'; 
	}
	else 
	{
		print "   ERROR: Failed to get version from:\n $file \nor $fp \n"; 
		return(2); 
	}
	
}#end versionCheckFiles

# +---------------------------+
# | sub: getFileVer 
# +---------------------------+
# | Desc: gets the first instance of $Id: or $Header: from a given file 
# +---------------------------+
# | Args: single, full path to file. 
# +---------------------------+
# | Returns: the version or "1" if failed, returns 2 if the file doesn't exist 
# | "1" usually means that the file version couldn't be detected, whereas 2 is always "did not exist" 
# +---------------------------+

sub getFileVer
{
	my ($file) = @_;  

	if (-e $file) 
	{
		open (my $fh, '<', $file ) || die "getFileVer(): Cannot open $file $! \n";
		@a = <$fh>;
		close $fh; 
	}
	else
	{
		$file = basename($file); 
		my $analyzer = analyzer MENU::Analyzer($file);
		my $file2 = $analyzer->getCPFile;
		if (length($file2) > 1) 
		{		
		#account for CP_FILE param 
		#$DB::single = 1;
		$file = basename($file); 
		#my $dir = dirname($file);
		$file = $analyzer->getCPFile;
		my $prodTop = $analyzer->getProdTop; 
		$file = $ENV{$prodTop} . '/sql/' . $file2; 
			if (-e $file) 
			{
				open (my $fh, '<', $file ) || die "getFileVer(): Cannot open $file $! \n";
				@a = <$fh>;
				close $fh;
			}
			else 
			{
				return(2);
			} 
		}
	} 
	
	my $ver; 
	($ver) = grep(/\$Id:/,@a); 
	($ver) = grep(/\$Header:/,@a) if ! $ver; 
	$ver = $+ if $ver =~ /(\d{1,3}\.\d{1,3})/;
	
	if ($ver =~ /(\d{1,3}\.\d{1,3})/) 
	{
		return ($ver); 
	}
	else
	{
		return 1; 
	}

}

# +---------------------------+
# | sub:  showNewAnalyzers
# +---------------------------+
# | Desc: prints the README.txt lines to 
# | show the new Analyzers in the bundle 
# +---------------------------+
# | Args: none 
# +---------------------------+
# | Returns: nothing 
# +---------------------------+
sub showNewAnalyzers 
{
	system("clear"); 
	print BOLD WHITE ON_BLUE "\n", "  New Analyzers in this Bundle: ", RESET, "\n"; 
	open (my $fh, '<', 'README.txt' ) || die "showNewAnalyzers(): Cannot open README.txt $! \n"; 
	while (my $line = <$fh>) 
	{
		next until $line =~ /^New Analyzers/;
		$line = <$fh> for (1..2);
		until ($line =~ /^\=/)
		{
			print "   $line"; 
			$line = <$fh>; 
		}
	}
	close $fh; 
	print "   Press [Enter] to Continue:";
	<STDIN>; 
	system("clear");
	return(); 
}

# +---------------------------+
# | sub: prnt2LogSTDOUT
# +---------------------------+
# | Desc: Print to main log and STDOUT 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub prnt2LogSTDOUT
{
	$| = 1;
	open (my $fh, '>>', $main::log) || die "sub prnt2LogSTDOUT() Cannot open $logFile $! \n";

	my @arr = @_; 
	foreach my $line (@arr)
	{
		$line =~ s/^\s{1,10}//; 
		print $fh $line; 
	}
	#print $fh "@_";
	print "@_";
	close($fh);
}


# +---------------------------+
# | sub: prnt2Log
# +---------------------------+
# | Desc: prints only to log 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub prnt2Log
{
	$| = 1;
	open (my $fh, '>>', $main::log) || die "sub prnt2Log(): Cannot open $logFile $! \n"; 
	print $fh "@_";
	close($fh);
}

# +---------------------------+
# | sub: exitLog 
# +---------------------------+
# | Desc: shows the log location and exits; 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub exitLog
{
	open (my $fh, '>>', $main::log ) || die "exitLog(): Cannot open $main::log $! \n";
	print $fh "\n\n*****Menu.pl session end:", (strftime "%H:%M:%S %Y-%m-%d", localtime), "*****\n\n"; 
	print "\n\n   INFO: Menu.pl Log: $main::log \n\n";
		
	exit; 
}

return 1; 

__END__ 

