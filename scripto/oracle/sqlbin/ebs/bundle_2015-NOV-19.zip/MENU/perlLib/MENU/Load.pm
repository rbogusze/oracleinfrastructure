# $Id: Load.pm 200.1 2015/10/22 kjharris $
# *===========================================================================+
# |  Copyright (c) 2014 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# |
# | FILENAME: Load.pm
# |
# | 
# | PLATFORM
# |   Unix Generic
# |
# | NOTES
# |
# | HISTORY
# | 200.0 Creation (OCT-16-2014) 
# | 200.1 
# | ->Print out CCP information when calling fnd_program.add_to_group 
# +===========================================================================+

use File::Copy qw(move);

# +---------------------------
# | Subs 
# +---------------------------


# +---------------------------+
# | sub:  floadBulkUpdates
# +---------------------------+
# | Desc: Loads all analyzers provided in a flat array WITHOUT any request groups
# +---------------------------+
# | Args: array of analyzers to load 
# +---------------------------+
# | Returns: 
# +---------------------------+

sub floadBulkUpdates 
{
	my ($analyzers)=@_; 
	my $check;
	my $status; 
	my $ans; 
	foreach my $file (@$analyzers)
		{
		  # my $file = $_ ; 
			$check = verChkBeforeLoad($file); 
			
			if ($check == 2) 
			{
				print "   INFO: Unable to version check file: \n   $file\n   Do you wish to load the file without version checking?\n";
				until ($ans =~ /^y|^n/i)
				{
					print "[Y|N]:"; 
					<STDIN>;
				}
				if ($ans =~ /^y/i) 
				{
					$check = 0; 
				}
				else
				{
					print "   INFO: User decided to not proceed with the load of $file \n\n"; 
				}
			}

			if ($check == 0) 
			{
				my $status = runDepen($file); 
				next if $status > 0;
				createProgLDT($file); 
				copySQL($file);
			}
			elsif ($check == 1) 
			{
				print "   INFO: No FNDLOAD actions for $file because the system already contains a higher version\n"; 
			}
		}#end foreach 
		
	if (scalar @$analyzers > 0)
		{
			runFNDLOAD();
		
			foreach my $file (@$analyzers)
			{
				addToGroup($file); 
			} 
			
		}
}#End floadBulkUpdates 

# +---------------------------+
# | sub:  floadBulk
# +---------------------------+
# | Desc: Loads all analyzers provided from a hash 
# | 
# | Hash format: 
# | 
# | 'FILE' => 'analyzers/SQL/01_E-Business_Suite_Core_Analyzers/db_param_analyzer.sql',
# | 'ID' => 4,
# | 'CCPTITLE' => 'Database Parameter Settings Analyzer',
# | 'CCP' => 'DB_PARAM_SQL',
# | 'CURRFILEVER' => '200.2',
# | 'FAM' => 'ATG'
# | 
# +---------------------------+
# | Args: array ref 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub floadBulk 
{
	my ($analyzers)=@_; 

	my $ans = printWarning(); 
	displayDirs('analyzers/SQL') if $ans == 2;  
	#printReqGroups will optionally print 
	#all the CCP info into a text file / log 
	printReqGroups($analyzers); 

	return() if $ans == 1; 
	
	for my $id (keys %$analyzers) 
	{
		if (length($$analyzers{$id}->{'FILE'}) < 3)
		{
			delete($$analyzers{$id}) ; 
		}
	}
	for my $id (keys %$analyzers)
	{
		my $file = basename($$analyzers{$id}->{'FILE'}); 
		my $check = verChkBeforeLoad($$analyzers{$id}->{'FILE'}); 
		
		if ($check == 2) 
		{
			print "   INFO: Unable to version check file: \n  $file\n   Do you wish to load the file without version checking?\n";
			until ($ans =~ /^y|^n/i)
			{
				print BOLD WHITE ON_BLUE "   [Y]es | [N]o:", RESET;
				<STDIN>;
			}
			if ($ans =~ /^y/i) 
			{
				$check = 0; 
			}
			else
			{
				print "   INFO: User decided to not proceed with the load of $file \n\n"; 
			}
		}

		if ($check == 0) 
		{
    	prnt2Log("\nINFO: About to load $file as a Concurrent Program\n*** *** ***"); 
			prnt2Log("\nTITLE: $$analyzers{$id}->{'CCPTITLE'}\nPROGRAM: $$analyzers{$id}->{'CCP'}\nPRODUCT: $$analyzers{$id}->{'PROD'}\nREQUEST GROUP: $$analyzers{$id}->{'REQGROUP'}\n*** *** ***\n\n");
			my $status = runDepen($$analyzers{$id}->{'FILE'}); 
			next if $status > 0; 
			createProgLDT($$analyzers{$id}->{'FILE'}); 
			copySQL($$analyzers{$id}->{'FILE'});
		}
		elsif ($check == 1) 
		{
			print "   INFO: No FNDLOAD actions for $file because the system already contains a higher version\n"; 
		}
	}

	if (keys %$analyzers > 0)
	{
		runFNDLOAD();
		for my $id (keys %$analyzers)
		{
			addToGroup($$analyzers{$id}->{'FILE'}); 
		} 
	}

}
# # #End floadBulk# # # 

# +---------------------------+
# | sub: printWarning
# +---------------------------+
# | Desc: prints the warning before CCPs are bulkloaded 
# +---------------------------+
# | Args: none 
# +---------------------------+
# | Returns: none 
# +---------------------------+
sub printWarning
{

system("clear"); 

print qq(
  +-----------------------------------------------------------------+
                             Attention                               
  +-----------------------------------------------------------------+
   You are about to bulk load Analyzers as Concurrent Programs and 
   register those Concurrent Programs with default Request Groups.
   Those default Request Groups are: 
    o Seeded into all E-Business Suite Installations 
    o Available to specific Responsibilities
    o In the same Product Area (FND, AP, MFG, etc.) as the Analyzer 
      being loaded 

   Select [C]ontinue to see the list of analyzers included in this 
   bulk load and the default Request Group for each.

   Select [M]ain Menu if you wish to register an Analyzer with a 
   specific Request Group, navigate to the Product, then the Analyzer
   to find single FNDLOAD option where you can optionally change
   the Request Group. 
  +-----------------------------------------------------------------+); 

	my $ans; 
	until ($ans =~ /^c{1}|^m{1}|^b{1}/i)  
	{
		print BOLD WHITE ON_BLUE "\n  [C]ontinue  [B]ack  [M]ain Menu "; 
		print "\n   Selection: "; 
		$ans = <STDIN>; 
		chomp($ans); 
	}
	return (0) if $ans =~ /^c{1}/i; 
	return (1) if $ans =~ /^b{1}/i; 
	return (2) if $ans =~ /^m{1}/i; 
}

# +---------------------------+
# | sub: printReqGroups
# +---------------------------+
# | Desc: 
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub printReqGroups 
{
	my ($analyzers) = @_; 

	my $ans; 
	
	until ($ans =~ /^y{1,3}|^n{1,2}/i) 
	{
		# system("clear"); 
		print "   Would you like a log of each Concurrent Program Created? \n   (Includes Request Group Information)\n";
		print BOLD WHITE ON_BLUE "   [Y]es | [N]o:", RESET;
		chomp($ans = <STDIN>); 
	}
		#getReqGroup 
	if ($ans =~ /^y/i)
	{
		$CCPlog = 'logs/' . "ConcurrentInfo_" . (strftime "%Y-%m-%d_%H%M%S", localtime) . ".log"; 
		open (my $fh, '>', "$CCPlog" ) || die "printReqGroups(): Cannot open $CCPlog: $! \n"; 
		print $fh "+--------------------------------+\n Generated on ", (strftime "%d %h %Y %H:%M:%S", localtime)," \n+--------------------------------+\n"; 
		for my $id (keys %$analyzers) 
		{
			next if length($$analyzers{$id}->{'CCPTITLE'}) < 3; 
			print $fh "\n\n"; 
			my $dash = '+'; 
			my $cnt = length($$analyzers{$id}->{'CCPTITLE'});
			for (my $i = 0; $i < $cnt; $i++)
			{
				$dash .= '-'; 
			}
			$dash .= "+\n"; 	
			print $fh " ", $$analyzers{$id}->{'CCPTITLE'}, "\n", $dash; 
			print $fh " -Concurrent Program Name: ", $$analyzers{$id}->{'CCP'}, "\n";
			print $fh " -Product Short Name: ", $$analyzers{$id}->{'PROD'}, "\n";  
			print $fh " -Request Group: ", $$analyzers{$id}->{'REQGROUP'}, "\n"; 
			print $fh "$dash\n"; 
		}
		close $fh;
		print "   INFO: The Concurrent Program Information Log is:\n   $CCPlog \n\n";
		print "   Press [Enter] to Continue: "; 
		<STDIN>; 
	}
}


# +---------------------------+
# | sub: floadSingle 
# +---------------------------+
# | Desc: Loads a single analyzer as a concurrent program
# +---------------------------+
# | Args: 
# +---------------------------+
# | Returns: 
# +---------------------------+
sub floadSingle
{
	my ($file, $floadRef) = @_;
	my $cs = $main::connStrg->getConnStrg(); 
	my $prodTop;
	my $reqGroup;
	my $progName;
	my $progTemplate;
	my $relVer = getRelVer();

	if (! -e $file) 
	{
		find( sub {return unless /\.sql$/; $file = $File::Find::name if "$file" eq "$_" }, 'analyzers/SQL' );
	}

	my $check = verChkBeforeLoad($file); 
		
	if ($check == 2) 
	{
		print "   INFO: Unable to version check file: \n   $file\n   Do you wish to load the file without version checking?\n";
		until ($ans =~ /^y|^n/i)
		{
			print "[Y|N]:"; 
			<STDIN>;
		}
		if ($ans =~ /^y/i) 
		{
			$check = 0; 
		}
		else
		{
			print "   INFO: User decided to not proceed with the load of $file\n   Press [Enter] to Continue:";
			<STDIN>; 
			return();
		}
	}
	elsif ($check == 1) 
	{
		print "   INFO: No FNDLOAD actions for $file because the system already contains a higher version\n   Press [Enter] to Continue:"; 
		<STDIN>; 
		return(); 
	}
	
#if the check == 0, we did not return yet.. and the following code executes: 	

#####
#Check for compat
###
my ($compat, $valid) = checkCompat($file,$relVer); 

if ($valid != 1)
	{
		printf "   ERROR: This Analyzer is not compatible with your E-Business Suite Release ($relVer) \n   Compatible Releases: $compat\n\n   Press [Enter] to Continue: "; 
		my $wait = <STDIN>;
		return 1;
	}

#####
#Check if the user wants to use a diff request group other than the default and tell them what they are about to do. 
###
my $analyzer = analyzer MENU::Analyzer($file);
my $title = $analyzer->getTitle();
my $deps = $analyzer->getDeps();
my $reqGrp = $analyzer->getReqGroup();
my $prodTop = $analyzer->getProdTop();
my $CCPName = $analyzer->getCCPName() ;
my $prodShortName = $analyzer->getProdShortName();
my $reqGrpApp = $analyzer->getAppName(); 

my $userSel; 
my $loop = 'Y'; 
#system("clear"); 

	until ($loop eq 'N')
	{
		my ($reqGrpCode); 
		system("clear");
		my $filename = basename($file);
		#just in case 
		chomp($title); 
		chomp($filename); 
		print "\n   INFO: About to FNDLOAD the following analyzer as a Concurrent Program\n   The following parameters will be used. Only the request group is optional \n   and configurable:\n\n"; 
		print BOLD WHITE ON_BLUE "   $title \[$filename\]", RESET, "\n\n   o Request Group: \"$reqGrp\"\n   o Request Group Application: \"$reqGrpApp\"\n   o Concurrent Program Executable Name: $CCPName \n   o Product Short Name: $prodShortName\n   o Product Top: $prodTop \n\n";
		printf BOLD WHITE ON_BLUE "\n   [L]oad | [C]hange Request Group | [B]ack | [N]o Request Group\n";
		print BOLD WHITE ON_YELLOW "   Invalid Selection", RESET if $userSel == 123; 
		printf "\n   Selection:";
		chomp($userSel = <STDIN>);

		if ($userSel =~ /^b$/i)
		{
			my $dir = dirname($file);
			my $file = basename($file);
			fileMenu($dir, $file);
		}
		elsif ($userSel =~ /^n$/i) #no Req Group Load 
		{
			print "\n   Load this Analyzer with no request group?\n   [A request group is required before the Concurrent Program may be run]\n   [Y|N]:";
			chomp(my $resp = <STDIN>);
			
			if ($resp =~ /^y/i) 
			{
				my $status = runDepen($file); 
				next if $status > 0; 
				createProgLDT($file);
				copySQL($file);
				runFNDLOAD($cs);
				return; 
			}
		} 
		elsif ($userSel =~ /^c$/i)
		{	
			until (1 == 2)
			{
				system("clear"); 
				my $psn; 
				print "\n   Enter a product short name which contains \n   the desired Request Group.\n   Product Short Name examples: \"FND\", \"SQLAP\", \"XDO\", etc.\n   Product Short Names are in the FND_APPLICATION table\n   Product Short Name: "; 
				chomp($psn=<STDIN>); 
				my ($h) = getReqGroups($psn); 
				if ($h != 1) 
				{
					#$a[0]=, $a[1]=, $a[2]=, $a[3]=
					# return($$groups{$ID}->{'REQ_GRP'}, $$groups{$ID}->{'PROD'}, $$groups{$ID}->{'APP_NAME'}, $$groups{$ID}->{'REQ_GRP_CODE'}) if $$groups{$ID}->{'SEL'} =~ /\+/; 
					my (@a) = reqGrpPickList(\%$h);
					
					if (scalar @a >= 3)
					{
						#reqGrpCode could be null 
						#got back good values
						$reqGrp = $a[0]; #request group name 
						#$a[1]; prod short name, but we don't need it.   
						$reqGrpApp = $a[2]; #request group application (full app name from fnd_application_tl) 
						$reqGrpCode = $a[3]; #need this so we can give the warning. 
						last; 
					}
					else
					{
					#user aborted pick list.. 
						print "   INFO: User Aborted the Request Group List.\n"; 
						print "   Press [Enter] to Continue \n"; 
						<STDIN>; 
						last; 
					}
				}
			}#end until() 
	
		
		}#elsif ($userSel =~ /^c$/i)
		elsif ($userSel =~ /^l$/i)
		{
			prnt2Log("\nINFO: About to load $file as a Concurrent Program\n*** *** ***"); 
			prnt2Log("\nTITLE: $title\nPROGRAM: $CCPName\nPRODUCT: $prodShortName\nREQUEST GROUP: $reqGrp\n*** *** ***\n\n");
			
			my $status = runDepen($file); 
			next if $status > 0;
			createProgLDT($file);
			runFNDLOAD($cs);
			#addToGroup needs: 4 params: CCPName, CCP Prog Name (short name), Request Group, Request Group App Name (long name) 
			#print "Fix: line 410 load.pm";<STDIN>; 
			# print "reqGrp: $reqGrp, reqGrpApp: $reqGrpApp, reqGrpCode: $reqGrpCode\n"; exit; 
			addToGroup($file, $reqGrpApp, $reqGrp, 'single');
			copySQL($file);
			return; 
		}
		else
		{
			$userSel = 123; 
		}
	}#end UNTIL loop; 
	
}	#END floadSingle 


# +---------------------------+
# | sub:  validateReqGrp
# +---------------------------+
# | Desc: checks to see if a request group 
# | exists and is valid for a given product 
# +---------------------------+
# | Args: a request group to be validated 
# +---------------------------+
# | Returns: hash:  $h{$prod}=$grp;
# +---------------------------+
sub validateReqGrp
	{
		unlink 'sql/req_groups.lst' if -e 'sql/req_groups.lst'; 
		#unlink 'sql/check_req_group.sql' if -e 'sql/check_req_group.sql'; 
		my ($wantedReqGrp) = @_; 
		#my $cs = $main::connStrg->getConnStrg();
		my $cs = $main::connStrg->getConnStrg(); 
		my %h; 
		
		if (! -f "sql/check_req_group.sql") 
			{
				open(my $fh, '>', 'sql/check_req_group.sql' ) || die "Cannot open 'sql/check_req_group.sql': $! \n"; 
				print $fh qq(
SET SERVEROUTPUT ON
SET TERM OFF
SET VERIFY OFF
SET HEAD OFF

SPOOL "sql/req_groups.lst";

SELECT fa.application_short_name || ':' || frg.request_group_name || ':' || frg.request_group_code
FROM FND_APPLICATION FA, FND_REQUEST_GROUPS FRG
WHERE frg.application_id = fa.application_id
AND frg.request_group_name = '&1';
SPOOL OFF;
EXIT;);
close $fh;  
			}
		
		my $status = system("sqlplus -L -S $cs \@sql/check_req_group.sql \"$wantedReqGrp\""); 
		warn "sqlplus failed while checking for a valid request group" if $status != 0; 
		
		if (-f 'sql/req_groups.lst')
		{
		open (my $fh, '<', 'sql/req_groups.lst' ) || die "Cannot open 'sql/req_groups.lst': $! \n"; 
		while (my $line = <$fh>) 
			{
				next unless $line =~ /$wantedReqGrp/; 
				chomp($line); 
				my ($prod, $grp, $rgCode) = split(':', $line); 
				$prod = trim($prod); 
				$grp = trim($grp); 
				$rgCode = trim($rgCode); 
				
				$h{$prod}=$grp;
				$h{$prod}->{'REQ_GRP_CODE'}=$rgCode; 
			}
		close $fh; 
		}
		else
		{
			print "   WARNING: Unable to run SQL*PLUS to check the Request Group \n   A spool file was not created from the command: \n  sqlplus -L -S <connect string> \@sql/check_req_group.sql \"$wantedReqGrp\" "; 
			print "   Press [Enter] to Continue: "; 
			<STDIN>; 
		}
		unlink 'sql/req_groups.lst' if -e 'sql/req_groups.lst'; 
		return(\%h); 
	}

# +---------------------------
# | sub getRelVer() 
# | Determine Release from Context File 
# +---------------------------
sub getRelVer
{
	my $contextFile = $ENV{"CONTEXT_FILE"}; 
	my $relVer; 
	open my $fh, '<', $contextFile or die "   ERROR: Could not open $contextFile: $!";

	while (<$fh>) 
		{
			$relVer = $1 if $_ =~ /s_apps_version\">(\d{2}.+)<\/config_option\>/;
			last if defined $relVer; 
		}
	close $fh; 

	#Validate Release Version 
	die "   ERROR: Unable to determine Release Version from Context File\n" if $relVer !~ /^11\.5|^12\.0|^12\.1|^12.2/;  
	return ($relVer); 
}
#END getRelVer 


# +---------------------------+
# | sub:copySQL  
# +---------------------------+
# | Desc: Checks the EXECUTION_METHOD_CODE of the analyzer's 
# | LDT and if EXECUTION_METHOD_CODE = I, copy the file to PROD_TOP
# +---------------------------+
# | Args: the file to be cp'd
# +---------------------------+
# | Returns: 
# +---------------------------+

sub copySQL
{
	my $relVer = getRelVer(); 
	#get relVer .. 12.2 has special copy considerations 
	my ($file) = @_; 
	my $replace = versionCheckFiles($file);
	find( sub {return unless /$file/; $file = $File::Find::name;}, "analyzers/SQL" ) if (my $i = $file =~ tr/\///) == 0; 
	my $analyzer = analyzer MENU::Analyzer($file);
	my $progTemplate = 'analyzers/template/' . $analyzer->getProgTemplate;  
	open (my $fh, '<', $progTemplate ) || die "copySQL(): Cannot open $progTemplate $! \n"; 
	my @a=<$fh>; 
	close $fh; 
	my $prodTop; 
	my $ans; 
	
	if ($analyzer->getCPFile)
	{
		$file = $analyzer->getCPFile; 
		find( sub {return unless /$file/; $file = $File::Find::name;}, "analyzers/SQL" );
	}

	if (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a) && $replace == 0)
	{
		$prodTop = $ENV{$analyzer->getProdTop} . '/sql/';
		prnt2LogSTDOUT("\n   INFO: Copying file: $file to $prodTop ..\n"); 
		copy($file, $prodTop) or prnt2LogSTDOUT("Unable to copy $file to $prodTop: $!"); 
	}
	elsif (grep(/EXECUTION_METHOD_CODE\s\=\s\"Q\"/, @a) && $replace == 2)
	{
		print "\n\n   WARNING: Unable to version check: ",basename($file)," \n";
		until ($ans =~ /^y|^n/i) 
		{
			print "   Copy the file without version checking? [Y|N]:"; 
			$ans = <STDIN>; 
			chomp($ans); 
			print "   Invalid answer. \n" if $ans !~ /^y|^n/i; 
		}
		if ($ans =~ /^y/i)
		{
			$prodTop = $ENV{$analyzer->getProdTop} . '/sql/';
			prnt2LogSTDOUT("\n   INFO: Copying file: $file to $prodTop ..\n"); 
			copy($file, $prodTop) or prnt2LogSTDOUT("Unable to copy $file to $prodTop: $!");
		}
		else
		{
			prnt2LogSTDOUT("   INFO: Did not copy $file to $prodTop \n"); 
		}
	}
	
	#in all releases, even 12.2, the above "copy"
	#got the file to the primary/current file system
	#But in 12.2, we need to do another copy 
	if ($relVer =~ /^12\.2/i && ($replace == 0 || $ans =~ /^y/i)) 
	{
		my $otherFS = getFSVars(); #/oracle/VISION/12.2/fs2 
		#append PROD_TOP/sql 
		my $prod = $analyzer->getProdTop; 
		$prod =~ s/_TOP//;
		$prod = lc($prod); 
		$prodTop = $otherFS . '/EBSapps/appl/' . $prod . '/12.0.0/sql/';
		copy($file, $prodTop) or warn "Unable to copy $file to $prodTop: $!"; 
	}

}
#END copySQL

# +---------------------------
# | sub getFSVars() 
# | gets both FS vars from the CONTEXT_FILE for 12.2 so
# | both file systems are updated when copying SQL to PROD_TOP/sql 
# +---------------------------
sub getFSVars
	{
		my $contextFile = $ENV{"CONTEXT_FILE"}; 
		my $otherBase; 
		open my $fh, '<', $contextFile or die "   ERROR: Could not open $contextFile: $!";

		while (<$fh>) 
		{
			$otherBase = $1 if $_ =~ /s_other_base\">(.+?)<\/OTHER_BASE\>/;
			last if defined $otherBase; 
		}
		close $fh; 

	#Validate Release Version 
	warn "   ERROR: Unable to determine secondary 12.2 File System from Context File (s_other_base)\n" if ! -d $otherBase;  
	return ($otherBase); 
	
	}

# +---------------------------+
# | sub:  runFNDLOAD() 
# +---------------------------+
# | Desc: runs FNDLOAD for any files in the LDT/run dir 
# +---------------------------+
# | Args: nada 
# +---------------------------+
# | Returns: nada 
# +---------------------------+

sub runFNDLOAD
{
# +=============================================================+ 
# | afcpprog.lct is for loading the program
# | afcpreqg.lct is for registering the program
# | FNDLOAD %%SQL_USER%%/%%SQL_PASS%% O Y UPLOAD $FND_TOP/patch/115/import/afcpreqg.lct <REQ_LDT>
# | FNDLOAD %%SQL_USER%%/%%SQL_PASS%% O Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct <PROG_LDT>
# +=============================================================+ 
my $cs = $main::connStrg->getConnStrg();
my $status; 
my $runDir = 'analyzers/LDT/run'; 
my @progList; 
#my @reqGrpList; 
#find( sub {return unless $_ =~ /_REQGRP.ldt/; push @reqGrpList, $File::Find::name;}, $runDir );
find( sub {return unless $_ =~ /\.ldt/; push @progList, $File::Find::name if -f $_;}, $runDir );

return if (scalar @progList) == 0; # we may not always have a reqgrp ldt, but should always have a proggrp ldt.  

print "   INFO: Running FNDLOAD \n"; 

#load the prog LDTs first
while ((scalar @progList) > 0) 
	{
		my $file = shift @progList; 
		prnt2Log("\nINFO: running FNDLOAD: \"FNDLOAD ****\/**** O Y UPLOAD \$FND_TOP/patch/115/import/afcpprog.lct $file \"\n\n"); 
		$status=system("FNDLOAD $cs O Y UPLOAD \$FND_TOP/patch/115/import/afcpprog.lct $file"); 
		#Check status 
		if ($status == 0) 
		{
			prnt2LogSTDOUT ("\n   INFO: FNDLOAD for $file successful \n\n"); 
		}
		else
		{
			prnt2LogSTDOUT ("\n   ERROR: FNDLOAD failed for $file\n\n");
		}
		my $filename = basename($file);
		#move $file, "analyzers/LDT/$filename";
		system("mv $file \"analyzers/LDT/$filename\""); 
	}

		print BOLD WHITE ON_BLUE "   INFO: Logs for FNDLOAD:" . cwd() . '/logs/' . RESET "\n"; 
		prnt2Log("INFO: Logs for FNDLOAD: ", cwd(),"/logs/"); 
		print "\n\n   Press [Enter] to Continue:"; 
		<STDIN>;
		my $s = system("ls *.log > /dev/null 2>&1;");
		system("mv *.log logs/") if $s == 0; 
	
	return(); 
}
#END runFNDLOAD() 

###	
## createProgLDT: takes Release Version / Load.pl mode (single=script/family=<fam>/family=<all>)
## Determines which analyzers need to be processed, then creates the request group LDT for that list. 
## There are no customizations or off-standard changes needed or possible to the program group LDT
## There is no variable instantiation done, we simply match the top part of the template, which is release-specific to
## the bottom, generic part of the template which is generic. 
###

# +---------------------------
# |
# | createProgLDT($relVer, $mode, $analyzers); 
# +---------------------------
sub createProgLDT
	{
	my ($file) = @_;  
	my $relVer = getRelVer();
	my $analyzer = analyzer MENU::Analyzer($file);
	my $progTemplate = $analyzer->getProgTemplate();
	my $CCPName = $analyzer->getCCPName();
	my @newFile; 
	my @newFile1; 
	my $topTemplate; 
	
	$CCPName.="\.ldt"; 
	#printf "REL VER: $relVer \n"; 
	$relVer =~ /^11\.5.?/ ? $topTemplate = '11iProg.ldt' : 
	$relVer =~ /^12\.0.?/ ? $topTemplate = '120Prog.ldt' : 
	$relVer =~ /^12\.1.?/ ? $topTemplate = '121Prog.ldt' : 
	$relVer =~ /^12\.2.?/ ? $topTemplate = '122Prog.ldt' : die "   ERROR: Unable to determine release from context file. \n"; 
	#Copy top 1/2 (release-specific data definition) into an Array 
	open(my $FH1, "<", "analyzers/template/$topTemplate") || die "   Cannot open3: analyzers/template/$topTemplate\": $!";
	@newFile=<$FH1>; 
	close $FH1; 
	#Copy bottom 1/2 (program data, analyzer-specific) into the same array 
	open(my $FH2, "<", "analyzers/template/$progTemplate") || die "   Cannot open4: analyzers/template/$progTemplate\": $!";
	@newFile1=<$FH2>;
	close $FH2; 
	
	 my $time = (strftime "%Y-%m-%d_%H%M%S\n\n", localtime); 
	 $time=trim($time); 
	 #$time =~ s/\n//g; 
	 rename("analyzers/LDT/$CCPName", "analyzers/LDT/" . $CCPName . "\." . $time) if -e "analyzers/LDT/$CCPName"; 
	
	open(my $FH3, ">", "analyzers/LDT/run/$CCPName") || die "   Cannot open5: analyzers/LDT/run/$CCPName\": $!";
	print $FH3 @newFile;
	print $FH3 @newFile1; 
	close $FH3; 
	return (); 	

}#end  createProgLDT()


# +---------------------------+
# | sub: addToGroup
# +---------------------------+
# | Desc: adds a file's concurrent program to a request group 
# +---------------------------+
# | Args: analyzer file with a bundle header 
# +---------------------------+
# | Returns: int (status )
# +---------------------------+
sub addToGroup
{
	#From the EBS Dev Guide: 
	# program_short_ name 	The short name used as the developer name of the concurrent program.
	# program_ application 	The application that owns the concurrent program.
	# request_group 	The request group to which to add the concurrent program.
	# group_ application 	The application that owns the request group.	

	my ($file,$appName,$reqGroup,$mode) = @_; 
	my $cs = $main::connStrg->getConnStrg(); 
	my $analyzer = analyzer MENU::Analyzer($file);
	#ccpname and prodShortName are constant no matter if defining a request 
	# group or using one from the SQL Header 
	my $ccpName = $analyzer->getCCPName();
	my $prodShortName = $analyzer->getProdShortName();
	#we use this if we only have a file passed in 
	#this equates to using all default params for request group & fndload
	if ($mode ne 'single')
	{
		$appName = $analyzer->getAppName(); 
		$reqGroup = $analyzer->getReqGroup(); 
	}

	if (length $appName < 1 || length $reqGroup < 1 || length $prodShortName < 1 || length $ccpName < 1) 
	{
		print "   ERROR: addToGroup(): unable to get all parameters from $file. \n"; 
		print "   ERROR: Unable to add request group entry for $file \n   Press [Enter] to Continue:"; 
		<STDIN>; 
		return(1); 
	}
	
	unlink('sql/add_to_group.sql') if -f 'sql/add_to_group.sql';

	my $spool = 'sql/add_to_group.' . (strftime "%Y-%m-%d_%H%M%S", localtime) . '.lst';
	my @sql = qq(
SPOOL "$spool";
SET DEFINE OFF;
SET SERVEROUTPUT ON;

BEGIN

fnd_program.add_to_group(program_short_name => '$ccpName', program_application => '$prodShortName', request_group => '$reqGroup', group_application => '$appName'); 

EXCEPTION
   WHEN DUP_VAL_ON_INDEX THEN
   dbms_output.put_line('\n   INFO: Program: $ccpName already included in Request Group: $reqGroup'); 

END; 
/
SPOOL OFF; 
exit); 
		open (my $fh, '>', 'sql/add_to_group.sql' ) || die "addToGroup(): Cannot open sql/add_to_group.sql \n"; 
		print $fh @sql;
		close $fh;
	
	print qq(
   INFO: Adding Concurrent Program to Request Group:
    o Program: $ccpName
    o Concurrent Program Product: $prodShortName
    o Request Group: $reqGroup 
    o Request Group Application: $appName

		);
	my $status = system("sqlplus -l -s $cs \@sql/add_to_group.sql"); 
	
	print "   INFO: addToGroup(): SQLPLUS exited with status: $status \n";

		#check for errors in the $spool file and only stop if there's an error 
		if (checkSQL("$spool") > 0)
		{
			print "  ERROR: The addToGroup() failed to add $ccpName to $reqGroup \n   Check the sql/add_to_group spool file for details.\n"; 
		}
	
	unlink('sql/add_to_group.sql') if -e 'sql/add_to_group.sql';
	return($status); 
}#end Sub addToGroup(); 


# +---------------------------+
# | sub: getReqGroups
# +---------------------------+
# | Desc: gets request groups for 
# | given product short name $prodSN
# +---------------------------+
# | Args: PRODUCT_SHORT_NAME 
# +---------------------------+
# | Returns: hashref
# | 'APP_NAME' => 'Payroll',
# | 'REQ_GRP' => 'Global SLA/Payroll Processes',
# | 'PROD' => 'PAY',
# | 'REQ_GRP_CODE' => 'GLB_SLA_PAYROLL_PROCESS
# | 'COUNT' => '<count of responsibilities having the req. group>';  
# +---------------------------+
sub getReqGroups
{
	my ($prodSN) = @_; 
	my %reqGrps; 
	my $cs = $main::connStrg->getConnStrg(); 
	#make sure there's no trailing spaces 
	$prodSN = trim($prodSN); 
	$prodSN = uc($prodSN); 
	print "   INFO: Getting Request Groups for \'$prodSN\' ...\n"; 
	open (my $fh, '>', 'sql/getReqGrps.sql' ) || die "getReqGroups(): Cannot open \'sql/getReqGrps.sql\': $! \n"; 
	
	print $fh qq(
	SPOOL "sql/getReqGrps.lst";
	SET HEAD OFF; 
	SET SERVEROUTPUT ON
	SET TERM OFF
	SET VERIFY OFF
	SELECT fa.application_short_name || ':' || frg.request_group_name || ':' || frg.request_group_code || ':' || fat.application_name || ':' || count(frv.RESPONSIBILITY_NAME)
	FROM fnd_application fa, fnd_request_groups frg, fnd_application_tl fat, FND_RESPONSIBILITY_VL frv
	WHERE frg.application_id = fa.application_id
	AND frv.REQUEST_GROUP_ID (+) = frg.REQUEST_GROUP_ID
	AND fat.application_id = frg.application_id
	AND upper(fa.application_short_name) = '$prodSN'
	group by fa.application_short_name || ':' || frg.request_group_name || ':' || frg.request_group_code || ':' || fat.application_name; 
	SPOOL OFF;
	EXIT;);
	close $fh; 
	
	my $status = system("sqlplus -L -S $cs \@sql/getReqGrps.sql"); 
	
	print "   INFO: SQL*PLUS command for sql/getReqGrps.sql exited with status: $status \n"; 
	if (checkSQL('sql/getReqGrps.lst'))
	{
		print "   INFO: Request Group Select failed. \n"; 
	}
	else
	{
		if (-f 'sql/getReqGrps.lst')
		{
			open (my $fh1, '<', 'sql/getReqGrps.lst' ) || die "Cannot open 'sql/req_groups.lst': $! \n"; 
			my $id = 0; 
			while (my $line = <$fh1>) 
			{
				next unless $line =~ /^$prodSN/; 
				$id++; 
				chomp($line); 
				#my ($prod, $grp, $rgCode, $appName, $count) = split(':', $line); 
				($reqGrps{$id}->{'PROD'}, $reqGrps{$id}->{'REQ_GRP'}, $reqGrps{$id}->{'REQ_GRP_CODE'}, $reqGrps{$id}->{'APP_NAME'}, $reqGrps{$id}->{'COUNT'}) = split(':', $line); 
				 $reqGrps{$id}->{'COUNT'}=trim($reqGrps{$id}->{'COUNT'}); 
				$reqGrps{$id}->{'SEL'}=' '; 
				
				if ($reqGrps{$id}->{'COUNT'} eq '' || $reqGrps{$id}->{'COUNT'} eq ' ') 
				{
					$reqGrps{$id}->{'COUNT'} = 0; 
				}
				
			}
			close $fh1;
		}
		# print Dumper(%reqGrps); 
		# <STDIN>; 
	}#end else 
	if (keys %reqGrps)
	{
		return(\%reqGrps); 
	}
	else
	{
		print "\n\n   INFO: No Request Groups found. Is $prodSN a valid Product Short Name?\n"; 
		print "   Press [Enter] to Continue: "; <STDIN>; 
		return(1); 
	}
}

# +---------------------------+
# | sub: checkSQL
# +---------------------------+
# | Desc: checks if a spool file 
# | contains an ORA- error 
# +---------------------------+
# | Args: spool file  
# +---------------------------+
# | Returns: 0 (success) or 1 (failed) 
# +---------------------------+
sub checkSQL
{
	my ($spoolFile) = @_; 
	open (my $fh, '<', $spoolFile ) || die "checkSQL(): Cannot open $spoolFile: $! \n"; 
	my @f = <$fh>; 
	close $fh; 
	
	if (grep(/ORA\-/, @f)) 
	{
		my @err = grep(/ORA\-/i, @f); 
		print "\n   INFO: SQL statment returned 1 or more ORA- errors: \n";
		print "   $_ \n" foreach(@err); 
		print "\n   Check $spoolFile for the errors. \n   Press [Enter] to Continue:"; 
		<STDIN>; 
		return(1); 
	}
	else 
	{
		print "\n   INFO: SQL statement completed. (No ORA- errors) \n";
		return(0); 
	}
}#end checkSQL() 

# +---------------------------+
# | sub: reqGrpPickList
# +---------------------------+
# | Desc: pick list to allow 
# | user to select a request group 
# | from a given product short name  
# +---------------------------+
# | Args: hash ref of request groups: 
# | 'APP_NAME' => 'Payroll',
# | 'REQ_GRP' => 'Global SLA/Payroll Processes',
# | 'PROD' => 'PAY',
# | 'REQ_GRP_CODE' => 'GLB_SLA_PAYROLL_PROCESS
# +---------------------------+
# | Returns: 
# +---------------------------+
sub reqGrpPickList
{
	my ($groups) = @_; 
	my ($height, $width) = split(' ', `stty size`); 
	my $pageSize = ($height - 8); 
	my $currPage = 1; 
	my $maxPage = (ceil(scalar(keys %$groups)/$pageSize)); 
	my $ID = 1; 
	my $invSel = 0; 
	my $userSel;
	my $newCount = 0; 
	
	if (! keys %$groups)
	{
		print "   INFO: No Request Groups Found \n"; 
		print "   Press [Enter] to Continue:"; 
		<STDIN>; 
		return(); 
	}
	
	until (1 == 2) 
	{
		my ($spc1, $spc2, $verLgth); 
		system("clear"); 
		print "\n"; 
		print BOLD WHITE ON_BLUE "  Select Request Group for: $$groups{1}->{'APP_NAME'} ($$groups{1}->{'PROD'})", RESET;
		print BOLD WHITE ON_GREEN " [Page $currPage of $maxPage]",RESET if $maxPage > 1;
		print "\n\n"; 
		print BOLD WHITE ON_BLUE "  #  SELECTED  REQUEST GROUP                   # of Responsibilities", RESET, "\n";   
		$| = 1;
		for ($ID; $ID <= ($pageSize * $currPage); $ID++)
		{
			next if length($$groups{$ID}->{'PROD'}) < 3;
			$spc1 = "  " if $ID > 9;
			$spc1 = "   " if $ID <= 9;
			my $title = $$groups{$ID}->{'REQ_GRP'}; 
			if (length $title > 38) 
				{ $title = substr($title, 0, 36); $title .= "..."; } 
			my $tabs; 
			my $length=((length($title) + length("[$ID]"))); 
			$tabs = "\t\t\t\t" if $length < 13; 
			$tabs = "\t\t\t" if $length >= 13 && $length <= 20; 
			$tabs = "\t\t" if $length >= 21 && $length <= 28; 
			$tabs = "\t" if $length >= 29 && $length <= 35; 
			print " [$ID]", $spc1, "[$$groups{$ID}->{'SEL'}]","     $title",$tabs,"$$groups{$ID}->{'COUNT'}\n"; 
		  #print " ^ $length ^\n"; 
		}
		
		print BOLD WHITE ON_BLUE "\n  [U]se Selected | [B]ack | [H]elp | E[x]it", RESET;
		print BOLD WHITE ON_GREEN "| [N]ext Page", RESET if $currPage < $maxPage;
		print BOLD WHITE ON_GREEN " | [P]rev Page", RESET if $currPage < $maxPage && $currPage > 1;
		print BOLD WHITE ON_GREEN "| [P]rev Page", RESET if $currPage == $maxPage && $currPage > 1;
		print BOLD WHITE ON_YELLOW "\n Invalid Selection", RESET if $invSel != 0; 
		print "   \n   ...\n   Enter # to Select, then [U]se to continue\n";
		print "   Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i; 
		
		if (defined $$groups{$userSel}) 
		{
			if (length($$groups{$userSel}->{'REQ_GRP'}) < 2) 
			{
				$invSel = 1; 
				$ID = ($ID - $pageSize);
				next; 
			}

			if ($$groups{$userSel}->{'COUNT'} == 0)
			{
				print "\n   INFO: This Request Group is not assigned to any Responsibilities. \n   Choose another Request Group or add it to a Responsibility first. \n   Press [Enter] to Continue:" ; 
				<STDIN>; 
				#deselect all 
				#for my $i (keys %$groups) {$$groups{$i}->{'SEL'} = ' ';} 
			}
				
			if ($$groups{$userSel}->{'COUNT'} > 0)
			{
				my $ans; 
				until ($ans =~ /^y|^n/i)
				{
					#system("clear"); 
					print "\n   INFO: Request Group: \"$$groups{$userSel}->{'REQ_GRP'}\"\n         is assigned to ",$$groups{$userSel}->{'COUNT'}," responsibilities\n"; 
					print "\n   Would you like to see the list of responsibilities? [Y|N]: ";
					chomp($ans=<STDIN>);
				}
				showResp($$groups{$userSel}->{'REQ_GRP'},$$groups{$userSel}->{'PROD'}) if $ans =~ /^y/i; 
						#deselect all 
				for my $i (keys %$groups) {$$groups{$i}->{'SEL'} = ' ';} 
				$$groups{$userSel}->{'SEL'} = '+'; 
			}
		
			$ID = ($ID - $pageSize);
		}
		elsif ( $userSel =~ /^n{1}/i) #next page 
		{
			if ($currPage == $maxPage) 
			{
				$invSel = 1;
				$ID = ($ID - $pageSize);
			}
			else
			{
				$ID = ($pageSize * $currPage + 1);
				$currPage++;
			}
		}
		elsif ( $userSel =~ /^p{1}/i) #previous page 
		{
			if ($currPage == 1) 
			{
				$invSel = 1;
				$ID = 0; 
			}
			else 
			{
				$ID = ($ID - ($pageSize * 2));
				$currPage = ($currPage -1);
			} 
		}
		
		elsif ($userSel =~ /^b{1}$/i)
		{
			print "   INFO: Selection of new Request Group was aborted. \n"; 
			print "   (Select [U]se to choose the selected request group.) \n"; 
			print "   Press [Enter] to Continue:"; 
			<STDIN>; 
			#user quit without finalizing selection 
			return(1); 
		}
		elsif ($userSel =~ /^h{1}$/i)
		{
			system("clear"); 
			print qq (
   This list shows all Request Groups for the product entered.  
   
   Select a Request Group which has at least 1 responsibility assigned 
   by entering the corresponding number on the left. Then select [U]se
   to proceed to the confirmation screen. 

   Selecting [B]ack returns to the Load screen with no Request Group 
   selected. 
   
   If you wish to see the responsibilities which have the Request Group
   assigned, 

			\n   Press [Enter] to Continue:);
			<STDIN>; 
			$ID = ($ID - $pageSize);
		}
		elsif ($userSel =~ /^u{1}$/i)
		{
			foreach my $ID (keys %$groups)
			{
				return($$groups{$ID}->{'REQ_GRP'}, $$groups{$ID}->{'PROD'}, $$groups{$ID}->{'APP_NAME'}, $$groups{$ID}->{'REQ_GRP_CODE'}) if $$groups{$ID}->{'SEL'} =~ /\+/; 
			}
			print "   INFO: No group selected. Press [Enter] to Continue:"; 
			<STDIN>; 
			$ID = ($ID - $pageSize);
		}
		else 
		{
		  $invSel = 1; 
			$ID = ($ID - $pageSize);
		}
	}
}

# +---------------------------+
# | sub: showResp 
# +---------------------------+
# | Desc: Shows which responsibilities 
# | are associated with a particular 
# | request group / product 
# +---------------------------+
# | Args: request group / prod(*?) 
# +---------------------------+
# | Returns: <nada>
# +---------------------------+
sub showResp
{
	my ($reqGroup, $appShortName) = @_; 
	my ($height, $width) = split(' ', `stty size`); 
	my $pageSize = ($height - 7); 
	my $currPage = 1; 
	my $ID = 1; 
	my $invSel = 0; 
	my $userSel;
	my $newCount = 0; 
	my $cs = $main::connStrg->getConnStrg(); 
	
	open (my $fh, '>', 'sql/getReqGrpResp.sql' ) || die "showResp(): Cannot open \'sql/getReqGrpResp.sql\': $! \n"; 
	
	print $fh qq(
SPOOL "sql/getReqGrpResp.lst"
SET HEAD OFF 
SET SERVEROUTPUT ON
SET TERM OFF
SET VERIFY OFF
SET FEEDBACK OFF
SELECT frv.RESPONSIBILITY_NAME
FROM fnd_request_groups frg, fnd_application fa, FND_RESPONSIBILITY_VL frv
WHERE fa.application_id = frg.application_id
AND frv.REQUEST_GROUP_ID = frg.REQUEST_GROUP_ID
AND frg.request_group_name = '$reqGroup'
AND fa.application_short_name = '$appShortName'; 
SPOOL OFF
EXIT
/);
	close $fh; 

	my $status = system("sqlplus -L -S $cs \@sql/getReqGrpResp.sql"); 
	
	print "   INFO: SQL*PLUS command for sql/getReqGrpResp.sql exited with status: $status \n"; 
	if (checkSQL('sql/getReqGrpResp.lst'))
	{
		#this should probably never happen .. but.. 
		print "   INFO: showResp(): No Responibilities Found for App Short Name: $appShortName Request Group: $reqGroup\n"; 
		print "   Press [Enter] to Continue:"; <STDIN>; 
		return(); 
	}
	
	
	#convert spool file into %hash 
	my @resp; 
	
	open (my $fh1, '<', "sql/getReqGrpResp.lst" ) || die "showResp(): Cannot open \"sql/getReqGrpResp.lst\":  $! \n"; 
	@resp = <$fh1>; 
	close $fh1; 

	
	my $maxPage = (ceil(scalar(@resp)/$pageSize)); 
	my $i; 
	until (1 == 2) 
	{
		my ($spc1, $spc2, $verLgth); 
		system("clear"); 
		print "\n"; 
		print BOLD WHITE ON_BLUE "  Responsibilities for $appShortName: $reqGroup", RESET;
		print BOLD WHITE ON_GREEN " [Page $currPage of $maxPage]",RESET if $maxPage > 1;
		print "\n"; 
		$| = 1;
		for ($i; $i <= ($pageSize * $currPage); $i++)
		{	
			$resp[$i] = trim($resp[$i]); 
			next if length($resp[$i]) < 1; 
			print "  $resp[$i]\n"; 
			#print " ^ $length ^\n"; 
		}
		
		print BOLD WHITE ON_BLUE "\n  [B]ack | [H]elp | E[x]it", RESET;
		print BOLD WHITE ON_GREEN "| [N]ext Page", RESET if $currPage < $maxPage;
		print BOLD WHITE ON_GREEN " | [P]rev Page", RESET if $currPage < $maxPage && $currPage > 1;
		print BOLD WHITE ON_GREEN "| [P]rev Page", RESET if $currPage == $maxPage && $currPage > 1;
		print BOLD WHITE ON_YELLOW " | Invalid Selection", RESET if $invSel != 0; 
		print "\n   Selection:"; 
		$invSel = 0; 
		chomp($userSel = <STDIN>);
		exitLog() if $userSel =~ /^x{1}$/i;
		if ( $userSel =~ /^h{1}/i)
		{
			system("clear"); 
			print qq (
   This screen shows all responsibilities which have 
   the Request Group, "$reqGroup", assigned 
   to them. Loading an Analyzer into a Request Group 
   gives these responsibilities (and any users with 
   the given responsibility) access to run and view the 
   Analyzer output.   

			\n   Press [Enter] to Continue:);
			<STDIN>; 
			$i = ($i - $pageSize);
		}
		elsif ( $userSel =~ /^p{1}/i)
		{
			if ($currPage == 1) 
			{
				$invSel = 1;
				$i = 0; 
			}
			else 
			{
				$i = ($i - ($pageSize * 2));
				$currPage = ($currPage -1);
			} 
		}
		elsif ( $userSel =~ /^n{1}/i)
		{
			if ($currPage == $maxPage) 
			{
				$invSel = 1;
				$i = ($i - $pageSize);
			}
			else
			{
				$i = ($pageSize * $currPage + 1);
				$currPage++;
			}
		}
		elsif ( $userSel =~ /^b{1}/i)
		{
			return(); 
		}
		else
		{
			$i = ($i - $pageSize);
			$invSel = 1; 
		}
	}

}


return 1; 

__END__


